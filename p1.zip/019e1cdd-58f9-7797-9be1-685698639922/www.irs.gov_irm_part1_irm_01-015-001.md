---
url: "https://www.irs.gov/irm/part1/irm_01-015-001"
title: "1.15.1 The Records and Information Management Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-015-001#main-content)

- 1.15.1  [The Records and Information Management Program](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261453637344)
  - 1.15.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261482840096)
    - 1.15.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261483418464)
    - 1.15.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261483424208)
    - 1.15.1.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261455132464)
    - 1.15.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261482554432)
    - 1.15.1.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261453823024)
    - 1.15.1.1.6  [Acronyms and Terms](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261453820400)
    - 1.15.1.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261453733296)
  - 1.15.1.2  [Records Management as it Relates to Other Programs](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261454121760)
  - 1.15.1.3  [Oversight Responsibilities](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261453681056)
    - 1.15.1.3.1  [Responsibilities of the IRS Records Officer](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261453677264)
    - 1.15.1.3.2  [Responsibilities of the PGLD Records Specialist Manager](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261482012208)
    - 1.15.1.3.3  [Responsibilities of the RIM Records Specialist](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261454068608)
    - 1.15.1.3.4  [Responsibilities of Headquarters Business Unit IRCs](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261482616480)
    - 1.15.1.3.5  [Responsibilities of the Information Resource Coordinator (IRC)](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261482161072)
    - 1.15.1.3.6  [Responsibilities of All IRS Employees and Contractors](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261487131712)
    - 1.15.1.3.7  [Responsibilities of the National Archives and Records Administration (NARA)](https://www.irs.gov/irm/part1/irm_01-015-001#idm140261454644784)

# Part 1. Organization, Finance, and Management

# Chapter 15. Records and Information Management

# Section 1. The Records and Information Management Program

* * *

## 1.15.1 The Records and Information Management Program

#### Manual Transmittal

January 09, 2025

#### Purpose

(1) This transmits revised IRM 1.15.1, Records and Information Management, The Records and Information Management Program.

#### Material Changes

(1) IRM references, website links, editorial updates and word revisions, in compliance with the IRS Style Guide, were made throughout this IRM section.

#### Effect on Other Documents

IRM 1.15.1, dated March 7, 2024, is superseded.

#### Audience

All IRS divisions and functions

#### Effective Date

(01-09-2025)

Michael J. Oser

Acting Director, Identity and Records Protection (IRP)

**1.15.1.1** **(01-09-2025)**

### Program Scope and Objectives

1. **Purpose:** This section describes the Records and Information Management (RIM) Program, as an integral function within the IRS, as well as the roles and responsibilities of those employees who manage the program. Records and information management is the application of systematic controls to all recorded information that the IRS generates as original documentation and subsequently requires in order to conduct business. This recorded documentation falls under the statutory definition of "federal records" . Records are considered media (or format) neutral. Consequently, procedures for records and information management apply to official IRS recorded information in all format types. See Title 44 United States Code (USC) 2901(2) for a definition of "records management" , and 3301 for a definition of "federal records" .

2. The program scope consists of managing the entire life cycle of records, regardless of format (e.g., paper, digital, audio, photographic, micrographic, cartographic, geo-spatial); that is, creation or receipt, maintenance, disposal (destruction), retirement or transfer of (permanent) records to the National Archives and Records Administration (NARA), including regional archives and NARA-managed satellite archives.

3. **Audience:** These procedures apply to **all** IRS employees and contractors.

4. **Policy Owner:** Director, Identity and Records Protection - Records and Information Management (RIM).

5. **Program Owner:** The Records and Information Management (RIM) Program office, under Privacy, Governmental Liaison and Disclosure (PGLD), is the program office responsible for oversight of the Servicewide records management policy.

6. **Primary Stakeholders:** The Records and Information Management (RIM) Program office, under PGLD, promotes responsible recordkeeping practices for IRS employees and contractors to follow in accordance with federal laws, regulations, and procedures.


**1.15.1.1.1** **(10-13-2023)**

#### Background

1. In keeping with the Federal Records Act of 1950, as amended, and pursuant to Title 44, USC 3102, the IRS established a records management program - renamed Records and Information Management (RIM) Program - to ensure the economical and efficient management of its records. The program provides for the application, on a continuing basis, of sound management practices and techniques in the creation, maintenance, retrieval, preservation, and disposition of all records.

2. The mission of the RIM Program is to provide guidance and oversee related functions and processes which ensure that IRS records are available where and when they are needed, to whom they are needed, for only as long as they are needed, in order to conduct business, adequately document IRS activities, and protect the interests of the federal government and the American taxpayer. All IRS records are required under statute to be efficiently managed until final disposition. The RIM Program provides guidance to meet this requirement. Major goals of the program are to provide IRS business units with records and information guidance that they can use to efficiently run their organizations as required by NARA laws and regulations. These goals are accomplished by:



> 1. Creating only necessary records while minimizing filing of duplicates;
>
> 2. Organizing and controlling records efficiently through inventories and files planning, including the creation of file plans for each business unit;
>
> 3. Storing and managing records through the use of electronic storage like SharePoint Online, Teams Channels, Exchange Online and approved recordkeeping systems and local files area storage, and NARA-operated Federal Records Centers (FRC) or commercial storage areas; and
>
> 4. Ensuring the proper access, preservation, and timely disposition of all records according to records control schedules, general records schedules, and applicable federal statutes.


**1.15.1.1.2** **(10-13-2023)**

#### Authority

1. The following laws set forth basic legal requirements for Federal records management and closely related activities at the IRS that are codified at 5 USC 552, 552a, 553; 18 USC 641, 798, 2071; 26 USC 6103, 7213; 31 USC 3523; 40 USC 11101-11703; and 44 USC Chapters 21, 29-35:



01. Administrative Procedure Act of June 11, 1946, Ch. 324, 60 Stat. 237;

02. Budget and Accounting Procedures Act of 1950, Pub. L. No. 80-784 (September 12, 1950);

03. Electronic Freedom of Information Act Amendments of 1996, Pub. L. No. 104-231 (October 2, 1996);

04. Federal Records Act of 1950, Act of June 30, 1949, Ch. 288, Title V, 64 Stat. 583, which requires, among other things, that the head of each federal agency establish and maintain an active, continuing program for the economical and efficient management of agency records; amended in 2014, the Act expressly expands the definition of federal records to include electronic records;

05. Federal Records Management Amendments of 1976, Pub. L. No. 94-575 (October 21, 1976);

06. Freedom of Information Act, Pub. L. No. 89-487 (July 4, 1966) (as amended);

07. Government Paperwork Elimination Act, Pub. L. No. 105-277 (Division C) (October 21, 1998);

08. Information Technology Management Reform Act of 1996, Pub. L. No. 104-106 (Division E) (February 10, 1996);

09. National Archives and Records Administration (NARA) Act of 1984, Pub. L. No. 98-497 (October 19, 1984);

10. Paperwork Reduction Act of 1980, Pub. L. No. 96-511 (December 11, 1980) (as amended);

11. Paperwork Reduction Act of 1995, Pub. L. No. 104-13 (May 22, 1995);

12. Paperwork Reduction Reauthorization Act of 1986, Pub. L. No. 99-591 (October 18, 1986) (as amended);

13. Presidential and Federal Records Act Amendments of 2014, Pub. L. No. 113-187 (November 26, 2014), modernizes records management by focusing more directly on electronic records;

14. Privacy Act of 1974, Pub. L. No. 93-579 (December 31, 1974) (as amended);

15. Records Disposal Act of 1943, Act of July 7, 1943, Ch. 192, 57 Stat. 380 (as amended);

16. Tax Reform Act of 1976, Pub. L. No. 94-455 (October 4, 1976) (as amended), providing for punishment by imprisonment, fine or both of IRS employees and contractors who disclose tax information to unauthorized individuals or who access tax information in an unauthorized fashion;

17. Act of June 25, 1948, Ch. 645, 1, 62 Stat. 795 (as amended), which prohibits the concealment, removal, or mutilation of federal records and punishes same by fine or imprisonment or both, and which is set forth at 18 USC 2071. See also 18 USC 641, 793-794, 798, and 952; and

18. 44 USC Chapter 31, Records Management by Federal Agencies.


2. The following Executive Orders, regulations, agency orders, and policy documents set forth additional legal requirements and guidance for federal records management and closely related activities at the IRS:



01. Relating to the Civil Service Commission and Labor-Management in the Federal Service, Executive Order 12107, 44 Fed. Reg. 1,055 (January 3, 1979) (as amended), which supersedes Executive Order 10561 providing that official personnel folders are records of the Office of Personnel Management (OPM) and permitting OPM to prescribe regulations therefore;

02. National Industrial Security Program, Executive Order 12829, 58 Fed. Reg. 3,479 (January 8, 1993) (as amended);

03. Classified National Security Information, Executive Order 13526 (December 29, 2009);

04. Personnel Records, 5 Code of Federal Regulations (CFR), Part 293, which contains a basic personnel records and files system for federal agencies;

05. Records Management, 36 Code of Federal Regulations (CFR) Chapter XII, Subchapter B;

06. Management’s Responsibility for Enterprise Risk Management and Internal Control, [Office of Management and Budget (OMB) Circular A-123](https://www.whitehouse.gov/wp-content/uploads/legacy_drupal_files/omb/memoranda/2016/m-16-17.pdf) (July 15, 2016);

07. Management of Reporting and Data Integrity Risk, [Appendix A to OMB Circular A-123](https://www.whitehouse.gov/wp-content/uploads/2018/06/M-18-16.pdf) (June 6, 2018);

08. A Risk Management Framework for Government Charge Card Programs [Appendix B to OMB Circular A-123](https://www.whitehouse.gov/wp-content/uploads/2019/08/Issuance-of-Revised-Appendix-B-to-OMB-Circular-A-123.pdf) (August 27, 2019);

09. Management of Information as a Strategic Resource, [OMB Circular A-130](https://obamawhitehouse.archives.gov/sites/default/files/omb/assets/OMB/circulars/a130/a130revised.pdf) (revised);

10. Records Management, General Accounting Office Policy and Procedures Manual for Guidance of Federal Agencies, Title 8, Transmittal Sheet 8-8 (February 1991);

11. Federal Register: This is the official daily publication for rules, proposed rules, and notices of federal agencies and organizations, as well as Executive Orders and other Presidential documents. This document is used to retrieve the IRS privacy act system of records;

12. Update to Transition to Electronic Records, OMB/NARA M-23-07 (December 23, 2022): This memorandum supersedes Transition to Electronic Records, OMB/NARA M-19-21 and Managing Government Records Directive, OMB/NARA M-12-18. It establishes deadlines for all agencies to adopt electronic recordkeeping requirements, including the creation and management of all (temporary and permanent) federal records in electronic formats, and to close agency-operated paper storage facilities and transfer those records to FRCs operated by NARA or commercial storage facilities;

13. Document 12990, IRS Records Control Schedules (RCS), Catalog 57810D: These provide disposal authorizations for records accumulated by organizations/business units within IRS;

14. Document 12829, General Records Schedules (GRS), Catalog 54713E: The Archivist of the United States (NARA) issues the GRS to provide disposal authorization for temporary administrative records common to all agencies of the federal government. They include records relating to civilian personnel, fiscal accounting, procurement, communications, printing, and other common functions, and certain non-textual records. Document 12829 (GRS), along with Document 12990 (RCS), constitute IRS’s comprehensive RCS Manual; and

15. Policy Statement 1-125, Permanent records of significant changes to organizations, policies, or programs are to be created, preserved, and transferred to the National Archives and Records Administration (NARA), located in IRM 1.2.1.2.22.


**1.15.1.1.3** **(08-04-2017)**

#### Responsibilities

1. This IRM is used by **all** IRS employees and contractors to help comply with paper and electronic records management requirements.


**1.15.1.1.4** **(10-13-2023)**

#### Program Management and Review

1. The RIM Program is evaluated using the following reviews and reports:



   - **Records Management Self-Assessment (RMSA)**: The annual RMSA asks questions that assess compliance with records management statutes and regulations, as well as NARA policies and guidance.

   - **Federal Electronic Records and Email Management Reporting**: This report not only evaluates federal agency email management, it also seeks to assess the current state of all electronic records management at federal agencies (including email and permanent electronic records).

   - **Senior Agency Official for Records Management (SAORM) Annual Report**: This report gathers data on agency progress towards the goals of the OMB/NARA Update to Transition to Electronic Records memo (M-23-07) and other important records management initiatives as identified by NARA.

   - **Form 14377, Records and Information Management Virtual Program Review Self Assessment Checklist**: This checklist is utilized as a self-assessment tool to assist the field site offices with records management policies and procedures. In addition, it measures RIM goals to stimulate better fiscal management.

   - **Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist**: PGLD requires all business unit information resource coordinator (IRC) contacts complete this form on a quarterly basis. The purpose of the form is to ensure and document IRS recordkeeping compliance as defined by NARA. Completing the Form 14377-A identifies to PGLD:IRP:RIM potential gaps for training opportunities to assist the business unit with their recordkeeping responsibilities.


**1.15.1.1.5** **(10-13-2023)**

#### Program Controls

1. **Records Management Mandatory Briefing**: Every IRS employee and contractor must protect the information they handle daily to carry out their job responsibilities. They must annually take the Records Management Mandatory Briefing Integrated Talent Management (ITM) course #62965, Records Management Awareness, to ensure IRS records management is efficient, effective, and compliant with all applicable records management laws and regulations.


**1.15.1.1.6** **(08-04-2017)**

#### Acronyms and Terms

1. The table lists commonly used acronyms and terms:




| **Acronym** | **Term** |
| --- | --- |
| BU | Business Unit |
| CFR | Code of Federal Regulations |
| FRC | Federal Records Center |
| GRS | General Records Schedules, Document 12829 |
| IRC | Information Resource Coordinator |
| IRP | Identity and Records Protection |
| NARA | National Archives and Records Administration |
| OMB | Office of Management and Budget |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| POD | Post of Duty |
| RCP | Records Center Program |
| RCS | Records Control Schedules, Document 12990 |
| RIM | Records and Information Management |
| TD | Treasury Directive |
| USC | United States Code |


**1.15.1.1.7** **(10-13-2023)**

#### Related Resources

1. Employees will find the following websites helpful on records and information management:



   - Records and Information Management SharePoint

   - [44 USC Chapter 29](https://www.archives.gov/about/laws/records-management.html), Records Management by the Archivist of the United States

   - [44 USC Chapter 31](https://www.archives.gov/about/laws/fed-agencies.html), Records Management by Federal Agencies

   - [44 USC Chapter 33](https://www.archives.gov/about/laws/disposal-of-records.html), Disposal of Records

   - [OMB/NARA M-12-18](https://www.archives.gov/files/records-mgmt/m-12-18.pdf), Managing Government Records Directive

   - [OMB/NARA M-19-21](https://www.archives.gov/files/records-mgmt/policy/m-19-21-transition-to-federal-records.pdf), Transition to Electronic Records

   - [OMB/NARA M-23-07](https://www.whitehouse.gov/wp-content/uploads/2022/12/M_23_07-M-Memo-Electronic-Records_final.pdf), Update to Transition to Electronic Records

   - Document 12829, General Records Schedules

   - Document 12990, IRS Records Control Schedules

   - Is It A Record? flowchart

   - [36 CFR Chapter XII](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Subchapter B, Records Management codes

   - [Treasury Directive 80-05](https://home.treasury.gov/about/general-information/orders-and-directives/td80-05), Records and Information Management Program

   - Other IRMs that relate to the RIM Program: IRM 1.15.2, Types of Records and Their Life Cycle; IRM 1.15.3, Disposing of Records; IRM 1.15.4, Retiring and Requesting Records; IRM 1.15.5, Transferring/Removing Records; IRM 1.15.6, Managing Electronic Records.



     ### Note:



     IRM 1.15.7, Files Management, is referenced under RIM as it relates to other programs.


**1.15.1.2** **(02-05-2021)**

### Records Management as it Relates to Other Programs

1. The following programs and activities relate to records management or recordkeeping programs:



1. **Correspondence Management** — Correspondence is any written or documented oral communication. Anytime correspondence is generated, an original record is created.



      ### Example:



      Letters, memoranda, notes, email, Instant Messaging, audio cassettes, and contact memoranda.





      ### Note:



      Guidelines on IRS correspondence are included in IRM 1.10.1, IRS Correspondence Manual.

2. **Files Management** includes proper maintenance, selection, retrieval, retention, and disposition of files. Guidelines for managing files are contained in IRM 1.15.7, Files Management.



      ### Reminder:



      Accurate files management is a sound foundation of a good recordkeeping system.

3. **Publishing Management** involves the printing and publishing of IRS documents. Since most documents are ultimately record-related, proper retention and disposition procedures are especially important to this program. Coordinate with the Multimedia Publishing staff, the Servicewide IRS Records Officer, and the RIM staff to ensure the proper recordkeeping practices are met.



      ### Note:



      Guidelines on Publishing Management are included in IRM 1.17.





      ### Note:



      See IRM 1.18.5, National Distribution Center (NDC) for guidelines on the order fulfillment services and distribution of products to IRS internal and external customers. The NDC uses two software systems for order fulfillment activities and includes ordering for Specialty Programs such as security products and training materials (Training Publication Distribution System (TPDS) products).

4. **Forms Management** involves designing and standardizing IRS forms. Effective records management is important when designing and evaluating forms.

5. **Security and Disclosure** — An effective records and information management program is vital to ensure information is protected. Under the Privacy Act and Internal Revenue Code 6103, taxpayer information is to be retained and disposed of properly to maintain confidentiality and prevent disclosure.



      ### Note:



      Guidelines on Disclosure of Official Information are included in IRM 11.3.





      ### Note:



      Guidelines on Physical Security Program are included in IRM 10.2.





      ### Note:



      Guidelines on Classified National Security Information are included in IRM 10.9.1. Procedures for the protection of classified information (i.e., top secret, secret, confidential).





      ### Note:



      Guidelines on Information Technology (IT) Security are included in IRM 10.8. All aspects of security for the protection of information technology resources (includes Personally Identifiable Information (PII) and Sensitive But Unclassified (SBU) information).

6. **Internal Management Documents** (IMD) define all documents within the IMD system. They convey written policy, delegate authority, and provide information, instructions, and guidelines required for developing, revising, clearing, and issuing IMDs throughout the Internal Revenue Service. See IRM 1.11, Internal Management Documents Systems, for guidelines in the IMD program.


**1.15.1.3** **(10-13-2023)**

### Oversight Responsibilities

1. The Servicewide IRS Records Officer (also referred to as the IRS Records Officer) and staff, Records Specialist Manager, Records Specialists, Headquarters Business Unit Information Resource Coordinators (BU/IRCs), and local Business Unit Information Resources Coordinators (IRCs) have oversight responsibilities for the RIM Program. Tasks for each are listed in _IRM 1.15.1.3.1_, IRM 1.15.1.3.2, _IRM 1.15.1.3.3_, _IRM 1.15.1.3.4_, and _IRM 1.15.1.3.5_, respectively.


**1.15.1.3.1** **(10-13-2023)**

#### Responsibilities of the IRS Records Officer

1. The IRS Records Officer is located within Privacy, Governmental Liaison and Disclosure (PGLD), Identity and Records Protection (IRP), Records and Information Management (RIM). The IRS Records Officer is delegated authority by the Commissioner under:



1. IRS Delegation Order 1-37, Certify Destruction of IRS Records for Court Purposes (found in IRM 1.2.2.2.30), also delegated to the Records Specialists - to certify in writing that a particular accession of IRS records has been destroyed,

2. IRS Delegation Order 1-50, Servicewide Records Management (formerly Delegation Order 46, and also found in IRM 1.2.2.2.38) - to direct and conduct IRS records management and disposal activities,

3. IRS Delegation Order 11-2, Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents (formerly Delegation Order 156, and also found in IRM 1.2.2.12.2) - to act as the sole authority to facilitate NARA appraisal activities of IRS records under [Internal Revenue Code 6103(I)(17)](https://www.govinfo.gov/content/pkg/USCODE-2011-title26/pdf/USCODE-2011-title26-subtitleF-chap61-subchapB-sec6103.pdf),

4. IRS Delegation Order 11-2, Reference Chart, found in IRM 1.2.2-2 Exhibit DO 11-2, IRC 6103(l)(17), to submit to the National Archives and Records Administration, upon written request, from the Archivist, to the extent necessary for officers and employees’ appraisal of records for destruction or retention.


2. The IRS Records Officer:



01. Plans, develops, promotes, and establishes IRS policy, standards and procedures, and guidelines to carry out the scope and mission of the RIM Program;

02. Develops policies and procedures for related operations that provide for effective controls over the IRS records and data;

03. Plans, schedules, administers, directs, prioritizes, and conducts major RIM operations throughout the IRS;

04. Plans, directs and conducts comprehensive and long-range projects or studies of records and information management practices;

05. Serves as senior liaison for the IRS with NARA, the Department of the Treasury, other government agencies, and private industry on all records and information management matters that impact upon the entire IRS;

06. Serves as the IRS Records Management Officer under Treasury Directive (TD) 80–05;

07. Develops new records control schedules and reviews existing schedules (at least annually) based on any necessary changes consistent with IRS procedures and legal requirements;

08. Participates in records reviews, program evaluations, special studies, task forces, etc., in Headquarters and field organizations;

09. Provides technical guidance and assistance in fostering the mission of the RIM Program;

10. Advises Records Specialists of new initiatives, like RCS/GRS changes, electronic records management requirements, records related updates from Counsel and changes in records’ policy, which will require an unplanned increase in the retiring and servicing of records at the FRCs;

11. Reviews Systems of Records Notices (SORN) and Privacy and Civil Liberties Impact Assessments (PCLIA) prior to publication for appropriate disposition treatment;

12. Provides oversight and monitoring of Records Center Program (RCP) services and all off-site NARA-held holdings of IRS records, using various tools provided by the Archives and Records Center Information System (ARCIS);

13. Transfers permanent records to NARA;

14. Promotes awareness and understanding of records and information management through training, publicity, and related support activities; and

15. Provides oversight and monitoring of disposition of electronic records of the IRS at all organizational levels using Capital Planning and Investment Control (CPIC) strategies, and advising on E-300 language, participating in the Enterprise Life Cycle (ELC) process, and using electronic records management tools.


**1.15.1.3.2** **(10-13-2023)**

#### Responsibilities of the PGLD Records Specialist Manager

1. The Records Specialist Manager:



1. Ensures that the IRS business unit organizations coordinate annual contact with the business unit (BU) IRCs for the purpose of assessing program records and information management compliance. This compliance includes, but is not limited to, BU assignment of IRCs to conduct periodic inventories, complete annual files planning activities, complete quarterly Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist, assistance with disposal approvals for their BU, changes to BU master file plans, the promotion of the creation of BU local file plans, and carry out other associated duties as required;

2. Ensures that posts of duty (PODs) and BUs in area of coverage designate IRC responsibilities to identifiable staff and communicate information effectively to the Records Specialist. The assignment of IRCs is a requirement in the annual Management Control Accountability Process (MCAP);

3. Designates Records Specialists who serve as the primary responsible official(s) for directing and advising management and employees on RIM responsibilities and requirements for PODs within their area of coverage, including ensuring safeguards are in place for both physical and electronic records management;

4. Advises the IRS Records Officer of the designated Records Specialists and their area of coverage, including BU oversight responsibilities;

5. Oversees and supports the Records Specialist team on all their roles and responsibilities as outlined in _IRM 1.15.1.3.3_;

6. Serves as the IRS Super-Administrator Archival Records Center Information System (ARCIS), and grants/removes access to, trains users, resets passwords, and approves input requests into the ARCIS system; and

7. Serves as the IRS NARA/FRC Liaison who oversees all IRS/FRC activities; resolves all issues in the FRCs with the IRS/NARA account representative and FRC directors; completes and certifies the FRC monthly billing reports; completes and submits the quarterly FRC disposal reports to the FRCs.


**1.15.1.3.3** **(10-13-2023)**

#### Responsibilities of the RIM Records Specialist

1. The Records Specialist Manager designates the Records Specialists who:



01. Assists the IRS Records Officer in implementing an effective RIM Program;

02. Maintains a contact directory of the designated IRC assigned for the IRS functional organizations within area of coverage and ensures the accuracy of the IRC contacts on a quarterly basis. Reviews the IRS Discovery Directory to identify the functional organizations in order to verify/obtain IRCs for area of coverage;

03. Conducts and/or participates in RIM Program activities, ensuring the adequate and timely training of IRCs and local IRS personnel in Federal records management requirements. This includes, but is not limited to, site assistance or virtual visits to PODs in their area of coverage to assess records conditions and provide related support, Continuing Professional Education (CPE) training courses, and attention to new IRCs in need of baseline records management assistance. See Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist, a quarterly evaluation checklist filled in by all business units to identify potential training needs and provide recommendations based on their responses;

04. Certifies to the PGLD Records Specialist Manager completion of the ITM Course Number 15701, Introduction to Records Management for Information Resource Coordinators, within three months of appointment;

05. Annually coordinates and assists IRCs and local offices in the conduct of records inventories for their area of coverage;

06. Evaluates records management problems and resolves local ones which need attention. Refers all other Servicewide problems to the PGLD Records Specialist Manager and IRS Records Officer for attention and/or resolution;

07. Participates in local area or local business function studies and recommends actions to improve the RIM Program;

08. Assists customers in establishing and developing disposition information for revising or updating existing records control schedules or developing new records series, including the identification of new or revised disposition authorities for electronic information systems. Coordinates with and/or advises the IRS Records Officer, as appropriate;

09. Serves as liaisons with NARA FRC and IRS BU (including campus files activities) on records disposition matters, including the retirement, retrieval, and coordination of disposal activities;

10. Reviews, coordinates, and facilitates the approval of all records retirements, transfers, retrievals, refiles, and disposals. Tracks and monitors records requests to and from the FRCs. Develops monthly billing reports;

11. Assists others in fostering the mission of the RIM Program;

12. Promotes awareness of records management through training, publicity, and related support activities. Ensures an annual Communications Plan is approved by the IRS Records Officer;

13. Maintains documentation of all assigned RIM Program activities in the area of coverage, including but not limited to, records transfer and retrieval forms, disposal notices, files plans, training files, program promotion materials, communications plans, and comprehensive listing of IRCs;

14. Assists customers in implementing and improving methods in the creation, storage, access, retrieval, preservation and disposal of documents and other information;

15. Assists offices in the area to mitigate disasters affecting records;

16. Assists customers in selecting suitable media for information or data which they collect and store;

17. Participates in Servicewide studies having records component;

18. Conducts annual reviews of IRS PODs to ensure compliance with RIM responsibilities, including training, records inventories and files planning activities, and verification that records control schedules continue to meet customers' program and administrative needs. This is accomplished through the quarterly distribution of Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist;

19. Participates in space planning activities to effect efficient storage and ensure compliance with IRS and Department of the Treasury records management requirements;

20. Reviews purchase requests and use of records equipment and supplies to effect efficient storage and ensure compliance with IRS and Department of the Treasury records management requirements; and

21. Identifies permanent records in area of coverage for transfer to NARA.


### Reminder:

The IRS Records Officer and all Records Specialists are authorized to inspect IRS records, related paperwork, and any indexes, box listings, or shipping documents and procedures to confirm the use of appropriate retention and disposal authorities and that program objectives are met.

### Reminder:

The IRS Records Officer and the Records Specialists are delegated the authority to certify in writing that a particular accession of IRS records has been destroyed, under Delegation Order 1-37, Certify Destruction of IRS Records for Court Purposes, located in IRM 1.2.2.2.30.

### Caution:

Although Records Specialists have access to IRS records, their inspection of investigative records is limited. The inspection cannot include the examination of the contents of individual investigative case files including, but not limited to, those that are Grand Jury or involve undercover or covert operations (including informants). The only legitimate access to individual investigative case files is allowable when appraising records, determining compliance with retention requirements, or administering Internal Revenue Code Section 6103 (1)(17) activities as required.

2. See Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist, for additional information on ensuring an efficient and effective RIM Program.


**1.15.1.3.4** **(02-05-2021)**

#### Responsibilities of Headquarters Business Unit IRCs

1. Each IRS Headquarters organization/Business Unit is responsible for designating a primary Headquarters Business Unit Information Resource Coordinators (BU/IRCs), point of contact for records, and advising the Records Specialist and IRS Records Officer. This BU/IRC acts as the main contact for the IRS Records Officer when dealing with RIM issues across a single business or organizational unit. Differences in scheduling new records or any changes that must be made to an existing RCS that affects an entire BU will be coordinated through this individual. The BU/IRC is the records representative for their functional organization and may speak or act with full authority within the organization. This person should not be confused with the (local) IRC who is responsible for records activities within their function/organization, post of duty.



### Example:



The Headquarters BU/IRC is appointed and directed by the Commissioner, Deputy Commissioner, or chief, for a division or office and reports directly to an executive.

2. Each BU/IRC:



1. Assists the IRS Records Officer and the Records Specialist in implementing an effective RIM Program;

2. Identifies new or revised records series and recommends retention and disposal time frames to their Records Specialist and the IRS Records Officer;

3. Assists in the coordination of records inventories for the business unit and supports the activity working with the Records Specialist and the IRS Records Officer to get the annual inventory and files plan accomplished;

4. Certifies to their Records Specialist completion of the ITM, Course Number 15701, Introduction to Records Management for Information Resource Coordinators, within three months of appointment;

5. Brings issues to the attention of the Records Specialist and IRS Records Officer; and

6. Assists in the coordination of records disposal approvals/disapprovals for the Business Unit.


**1.15.1.3.5** **(10-13-2023)**

#### Responsibilities of the Information Resource Coordinator (IRC)

1. Each IRS functional organization, i.e., POD or functional BU (in the case of larger activities) is required to designate an Information Resource Coordinator (IRC) to be responsible for local records activities and is required to notify the Records Specialists Manager and Records Specialist of changes to assignment as they occur. At least once annually, BU managers must provide organizational and contact information to their local Records Specialists. This information is necessary to update records servicing authorities and to ensure the systemic control over local records processes (e.g., the annual files planning process, and periodic records inventorying).

2. IRCs are required to notify their local Records Specialists of any new records that must be scheduled or any changes that must be made to their existing RCS. In addition, the IRC is responsible for assisting the local Records Specialists in implementing an effective RIM Program within their function/organization. The IRC is the records liaison representative for their functional organization and may speak or act with full authority within the organization. At a minimum there should be one IRC in every POD where a BU is located. However, for small PODs where there is only a shared office, there should be at least one local IRC who may not be in that POD, but located in the same area with oversight of that office.



### Example:



A functional organization may be an Assistant Commissioner, area, division, office, BU, POD, or section.

3. Each IRC:



01. Assists employees with records disposition and inventory questions;

02. Develops and/or reviews local files plans at least annually and submits them to their local Records Specialist;

03. Certifies to their Records Specialist completion of the ITM, Course Number 15701, Introduction to Records Management for Information Resource Coordinators, within three months of appointment;

04. Conducts periodic inventories necessary to validate files plans and identify new records series (new types of records not identified in the RCSs);

05. Coordinates the approval for the disposal of records in their area of coverage by completing or coordinating the completion of NA Form 13001, Notice of Eligibility for Disposal, to approve/disapprove the destruction of records eligible for disposal at the FRC and by completing or coordinating the completion of Form 11671, Certificate of Records Disposal, to document the destruction or deletion of in-house federal records eligible for disposal;

06. Maintains documentation on disposed records, records retirements and transfers, retrievals, and files plans;

07. Plans orderly in-house disposition of inactive records in compliance with records control schedules, IRS and Department of the Treasury policies, and federal regulations and assists, as needed, with the customer request services from FMSS shred coordinator;

08. Ensures that records eligible for storage at a FRC are packed in standard boxes and that Standard Form (SF) 135, Records Transmittal and Receipt and required box listing is accurately prepared;

09. Identifies new or revised records series and recommends retention and disposal time frames to the Records Specialist; and

10. Brings other issues or concerns to the attention of the Records Specialist or the IRS Records Officer.


### Note:

Local IRC activities are collateral duties.

**1.15.1.3.6** **(02-05-2021)**

#### Responsibilities of All IRS Employees and Contractors

1. Each IRS employee and contractor must:



1. Manage the records they create and/or maintain in accordance with policies outlined in IRM 1.15.1 through IRM 1.15.7;

2. Assure the integrity and confidentiality of the records in their custody and with which they use to do their jobs. Managers are responsible for ensuring that their employees comply with these requirements;

3. Return records requested from the FRC promptly when finished with the records;

4. Certify the completion of the ITM, Course Number 62965, Records Management Mandatory Briefing; and

5. Work with local IRCs to the extent possible to resolve records and information management issues (local IRCs will confer with their designated Records Specialists as needed to assist with resolving Employee and Contractors record related issues).


**1.15.1.3.7** **(10-13-2023)**

#### Responsibilities of the National Archives and Records Administration (NARA)

1. NARA is the oversight agency responsible for appraising all federal records, approving their disposition, providing program assistance, evaluating records management programs, and serving as the final custodian of permanent records. FRCs operating under an OMB-approved reimbursable program as the Records Center Program (RCP), are a functional operation within the NARA organization that provide low cost off-site storage of records to all federal agencies.

2. NARA operates two different types of records facilities:



1. **FRCs** provide temporary storage and reference services for records that are needed infrequently by the customer but are not yet eligible for disposal or transfer to the National Archives. IRS records stored in an FRC remain in the legal custody of the IRS.

2. **NARA** permanently preserves select historical IRS records or IRS records of continuing value (e.g., rights and interests) permanently. Only a small percentage of these records have been identified and are scheduled as "PERMANENT" in the IRS RCS, specifically RCS 36. When transferring permanent records to NARA, the IRS transfers all legal custody of those records to NARA. NARA ensures preservation of permanent records and provides reference service to the IRS and its customers. NARA will withhold information that is restricted under statute (e.g., Internal Revenue Code Section 6103) from the public.



      ### Note:



      _The IRS must identify all records access and use restrictions for NARA on official transfer documentation (i.e., a completed Transfer Request (TR) via the Electronic Records Archives (ERA))_.


3. Other functions of NARA include the offering of records management training courses, issuing the GRS, and establishing standards for media preservation.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-015-001#addtoany "Show all")

A2A