---
url: "https://www.irs.gov/irm/part1/irm_01-004-051"
title: "1.4.51 Insolvency | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-051#main-content)

- 1.4.51  [Insolvency](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993645249216)
  - 1.4.51.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993616261440)
    - 1.4.51.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993616250976)
    - 1.4.51.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993616249024)
    - 1.4.51.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614833232)
    - 1.4.51.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614830416)
    - 1.4.51.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993643967856)
    - 1.4.51.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993643964816)
    - 1.4.51.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993643921120)
  - 1.4.51.2  [Role of the Field Insolvency Manager and Centralized Insolvency Operation Manager](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993644026608)
    - 1.4.51.2.1  [Acting Manager Assignments and Designations](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615933600)
    - 1.4.51.2.2  [Communication of Expectations](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615929072)
    - 1.4.51.2.3  [Group Meetings](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615921648)
    - 1.4.51.2.4  [End of Month (EOM) Processing](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615908368)
    - 1.4.51.2.5  [Functional Role](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615903680)
  - 1.4.51.3  [General Managerial Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614624400)
    - 1.4.51.3.1  [Administrative](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614623392)
      - 1.4.51.3.1.1  [Employee Performance File (EPF)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614608960)
      - 1.4.51.3.1.2  [Employee Drop File (EDF)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614595520)
      - 1.4.51.3.1.3  [Medical Information](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614593088)
    - 1.4.51.3.2  [Protecting Taxpayer Rights](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614590080)
      - 1.4.51.3.2.1  [Direct Contact For Taxpayers With/or Requesting Representation](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614754656)
      - 1.4.51.3.2.2  [Recording Taxpayer Interviews](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614746320)
      - 1.4.51.3.2.3  [Fair Tax Collection Practices](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614744416)
      - 1.4.51.3.2.4  [Ex Parte Communication With Appeals/Managerial Oversight](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614729056)
    - 1.4.51.3.3  [IDRS Security](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615177232)
    - 1.4.51.3.4  [Employee Safety/Security](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615170496)
    - 1.4.51.3.5  [Working With NTEU](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615166400)
    - 1.4.51.3.6  [Functional Security Reviews](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615160592)
    - 1.4.51.3.7  [Case Related](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615157952)
      - 1.4.51.3.7.1  [Payment of Damages](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615145744)
  - 1.4.51.4  [Employee Development / Training](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615075136)
  - 1.4.51.5  [Performance Management](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615063472)
    - 1.4.51.5.1  [Performance Evaluations](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615061744)
    - 1.4.51.5.2  [Reviews (Overview)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615032144)
      - 1.4.51.5.2.1  [Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993615014848)
      - 1.4.51.5.2.2  [Requirements for Annual Performance Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614998048)
      - 1.4.51.5.2.3  [Field and Office Observations](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614994320)
      - 1.4.51.5.2.4  [Time Utilization Reviews](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614979648)
      - 1.4.51.5.2.5  [Work Submitted for Approval/Closure](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614974272)
      - 1.4.51.5.2.6  [After Hours Review](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614971360)
    - 1.4.51.5.3  [Use of Statistical Data / Section 1204 / ROTERs](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614966128)
      - 1.4.51.5.3.1  [Tax Enforcement Results (TERs)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614951952)
      - 1.4.51.5.3.2  [Regulation 801 / Quantity & Quality Measures](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614949488)
    - 1.4.51.5.4  [Retention Standard](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614942816)
    - 1.4.51.5.5  [Within Grade Increase](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614938608)
    - 1.4.51.5.6  [Evaluation Due Dates](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614932432)
    - 1.4.51.5.7  [Discipline/Disciplinary Actions](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614930256)
  - 1.4.51.6  [Telework](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614923504)
    - 1.4.51.6.1  [Managing Telework](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614919120)
    - 1.4.51.6.2  [Interaction With Employees On Telework](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614901888)
  - 1.4.51.7  [Recognition and Awards](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614892016)
  - 1.4.51.8  [Insolvency Workload Management](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614886976)
    - 1.4.51.8.1  [Total Inventory Management (TIM)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614578800)
    - 1.4.51.8.2  [Using AIS](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614576592)
    - 1.4.51.8.3  [Case Management Tools](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614566976)
  - 1.4.51.9  [Assigning Work](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614437808)
    - 1.4.51.9.1  [Case Assignment Guide](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614432592)
    - 1.4.51.9.2  [Case Grade](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614415664)
    - 1.4.51.9.3  [Maintaining Inventories](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614409584)
      - 1.4.51.9.3.1  [Inventory Adjustments](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614407744)
    - 1.4.51.9.4  [Reassignment of Departing Employee Inventory](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614399312)
  - 1.4.51.10  [Initial Case Processing](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614395600)
  - 1.4.51.11  [Protection of the Government's Interest](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614388176)
    - 1.4.51.11.1  [Proofs of Claim Filing](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614385824)
    - 1.4.51.11.2  [Adequate Protection](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614376064)
    - 1.4.51.11.3  [341 Hearings](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614372288)
    - 1.4.51.11.4  [Plan Review](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614369952)
    - 1.4.51.11.5  [Compliance Monitoring](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614363984)
    - 1.4.51.11.6  [Bankruptcy Fraud](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614358544)
    - 1.4.51.11.7  [NFTL Refiles](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614356016)
    - 1.4.51.11.8  [Unfiled Returns](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614353520)
  - 1.4.51.12  [Automated Proof of Claim (APOC)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614348096)
  - 1.4.51.13  [Insolvency and IDRS](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614335248)
  - 1.4.51.14  [Closed Cases](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614213888)
  - 1.4.51.15  [Controls](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614199664)
    - 1.4.51.15.1  [ASED Accounts](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614189040)
    - 1.4.51.15.2  [CSED Accounts](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614174224)
  - 1.4.51.16  [Quality](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614166304)
    - 1.4.51.16.1  [NQRS](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614149264)
    - 1.4.51.16.2  [EQ Consistency Reviews](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614143968)
    - 1.4.51.16.3  [Employee Case Documentation](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614139296)
  - 1.4.51.17  [Operational Reviews and Employee Engagement](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614132192)
    - 1.4.51.17.1  [Frequency and Planning](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614125104)
    - 1.4.51.17.2  [Documentation](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614105056)
    - 1.4.51.17.3  [Leadership and Human Capital-Employee Satisfaction](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614094864)
      - 1.4.51.17.3.1  [Employee Engagement](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614069536)
      - 1.4.51.17.3.2  [Customer Service and Collaboration-Customer Satisfaction](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614050224)
      - 1.4.51.17.3.3  [Program Management-Business Results](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614035424)
    - 1.4.51.17.4  [Administrative / Compliance Reviews](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993614015712)
  - 1.4.51.18  [Director Performance Reviews and Employee Engagement.](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613999360)
    - 1.4.51.18.1  [Planning and Documentation](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613996224)
  - Exhibit  1.4.51-1  [Suggested Action Steps for Unacceptable Performance](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613973536)
  - Exhibit  1.4.51-2  [Pattern Letter for Incomplete Claim for Damages and/or Attorney's Fees](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613934304)
  - Exhibit  1.4.51-3  [Pattern Letter for Approval of a Claim for Damages and/or Attorney's Fees](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613924976)
  - Exhibit  1.4.51-4  [Pattern Letter for Denial of a Claim for Damages and/or Attorney's Fees](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613910272)
  - Exhibit  1.4.51-5  [Sample Annual/Mid-year Review Schedule](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613900240)
  - Exhibit  1.4.51-6  [Insolvency Group Manager's EQRS Review Documents, Form 6850-BU, and Narrative, General Guide](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613848352)
  - Exhibit  1.4.51-7  [Action Steps for Acceptable Level of Competence Determination if an Employee Within Grade Increase (WGI) is due.](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613817568)
  - Exhibit  1.4.51-8  [Guide for Litigation Transcript System (LTS) Reports (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613788896)
  - Exhibit  1.4.51-9  [Guide for Court Closure Follow-Up Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613771360)
  - Exhibit  1.4.51-10  [Guide for Tech Review Follow-Up Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613759456)
  - Exhibit  1.4.51-11  [Guide for LAMS Closed Case Listing Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613743936)
  - Exhibit  1.4.51-12  [Guide for Pending Refunds Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613741952)
  - Exhibit  1.4.51-13  [Guide for LAMS Not Found on AIS Case Listing Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613736560)
  - Exhibit  1.4.51-14  [Guide for Non-Master File Listing Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613733120)
  - Exhibit  1.4.51-15  [Guide for Lien Research Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613720656)
  - Exhibit  1.4.51-16  [Guide for Aged Cases Report (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613707360)
  - Exhibit  1.4.51-17  [Guide for Case Assignment Reports (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613700608)
  - Exhibit  1.4.51-18  [Guide for Unpostable Reports (CIO)](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613689680)
  - Exhibit  1.4.51-19  [CAG Pre-Assignment Factors](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613677424)
  - Exhibit  1.4.51-20  [CAG Pre-Assignment Difficulty Indicators](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613654384)
  - Exhibit  1.4.51-21  [Post-Assignment Difficulty Indicators Factor 5: Case Action](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613592864)
  - Exhibit  1.4.51-22  [Post-Assignment Difficulty Indicators Factor 6: Communication](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613568768)
  - Exhibit  1.4.51-23  [Post- Assignment Difficulty Indicators Factor 7: Supervisory Controls](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613535120)
  - Exhibit  1.4.51-24  [Case Assignment Profile Matrix](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613515200)
  - Exhibit  1.4.51-25  [CAG Post-Assignment](https://www.irs.gov/irm/part1/irm_01-004-051#idm139993613493472)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 51. Insolvency

* * *

## 1.4.51 Insolvency

#### Manual Transmittal

June 25, 2025

#### Purpose

(1) This transmits a revised IRM 1.4.51, Resource Guide for Managers, Insolvency.

#### Material Changes

(1) This transmits a revised IRM 1.4.51 Resources Guide for Manager, Insolvency.

1. Throughout - IRM been updated to comply with January 2025 Executive Order and OPM guidance.

2. Throughout - Editorial changes were made to ensure compliance with IRM Style Guide and Section 508.


#### Effect on Other Documents

This material supersedes IRM 1.4.51 dated February 4, 2025.

#### Audience

Small Business/Self-Employed, Specialty Collection - Insolvency Management

#### Effective Date

(06-25-2025)

Thomas D. Kramer

Director Collection Policy

Small Business/Self-Employed

**1.4.51.1** **(02-12-2020)**

### Program Scope and Objectives

1. **Purpose**. This Internal Revenue Manual (IRM) section discusses responsibilities of managers in Field Insolvency (FI) and Centralized Insolvency Operation (CIO). While many topics are touched upon in this chapter, comprehensive guidance about all of them cannot be included here. Remain alert for references to other resources, such as related IRMs and websites and access that guidance to ensure a thorough understanding of topics. Specifically, IRM 1.4.51:



1. Describes general administrative responsibilities required of Specialty Collection - Insolvency (SCI)managers.

2. Describes employee performance and development procedures.

3. Prescribes internal control requirements.

4. Provides guidance to group managers on the assignment and approval of work.

5. Provides guidance for operational reviews by Territory / Operation Managers, Department Managers and Director.


2. **Audience**. This IRM section is designed for use by Small Business/Self-Employed (SB/SE), Specialty Collection - Insolvency (SCI) management.

3. **Policy Owner**. Director, Collection Policy, SB/SE.

4. **Program Owner**. Collection Policy, SB/SE, Insolvency is the program owner of this IRM.

5. **Primary Stakeholders**. The primary stakeholder is SB/SE Collection, Specialty Collection - Insolvency (SCI).

6. **Program Goals**. This guidance is provided to communicate the managerial responsibilities to Specialty Collection Insolvency group managers including performance management, assignment of work, approval of work, promoting quality casework, and internal group controls.


**1.4.51.1.1** **(02-12-2020)**

#### Background

1. Internal Revenue Manual (IRM) 1.4.51, Resource Guide for Managers, Insolvency, contains procedures, guidance, and information for Specialty Collection Insolvency group managers. The content includes general administrative responsibilities, performance management, internal controls, assignment of work, approval of work, quality reviews, and program reviews.


**1.4.51.1.2** **(02-12-2020)**

#### Authority

01. 5 USC Part III, Government Organizations and Employees

02. IRS Restructuring & Reform Act of 1998:



    - IRC 1203, Termination of employment for misconduct

    - IRC 1204, Basis for evaluation of IRS employees


03. IRC 6304, Fair Tax Collection Practices

04. IRC 6320, Notice and Opportunity for Hearing Upon Filing of Notice of Lien

05. IRC 6330, Notice and Opportunity for Hearing Before Levy

06. IRC 6331, Levy and Distraint

07. IRC 6672, Failure to Collect and Pay Over Tax or Attempt to Evade or Defeat Tax

08. IRC 7213A, Unauthorized Inspection of Returns or Return Information

09. IRC 7521, Procedures Involving Taxpayer Interviews

10. 26 CFR 601.106, Appeals Functions

11. 31 USC 3302, Custodians of Money

12. 31 USC Chapter 53, Monetary Transactions

13. Equal Employment Opportunity Commission (EEOC) Management Directive 715 (MD-715)

14. Rev. Proc. 2012-18, Ex part Communications Between Appeals and Other IRS Employees


**1.4.51.1.3** **(02-04-2025)**

#### Roles and Responsibilities

1. The Director, Collection Policy is the executive responsible for the policies and procedures to be employed by collection personnel.

2. The Director, Specialty Collection - Insolvency (SCI) is responsible for program oversight.

3. Insolvency Group Managers, Department, and Territory / Operation Managers are responsible for ensuring the guidance and procedures described in this IRM are complied with.


**1.4.51.1.4** **(02-04-2025)**

#### Program Management and Review

1. **Program Reports**. Group managers are required to generate and approve end of month reports. Group managers are required to submit quarterly certifications of compliance with Section 1204 of the Internal Revenue Service Restructuring and Reform Act of 1998, prohibiting the use of tax enforcement results. Reports housed on the Automated Insolvency System (AIS) are used for group controls in the following areas: imminent collection and assessment statutes, no touch/activity, higher graded duties, and Notice of Federal Tax Lien (NFTL) determinations. Reports to help Specialty Collection Insolvency managers are discussed throughout this IRM chapter, including in the exhibits. The required AIS Business Objects reports are described in IRM 5.9.16.1.4(1), Program Reports, _IRM 1.4.51.8.3_, Case Management Tools and Field Insolvency Report Job Aid. Group managers are responsible for establishing and maintaining each of their employees’ Employee Performance File (EPF).

2. **Program Effectiveness**.



1. Operational reviews are conducted on a yearly basis. See _IRM 1.4.51.17_, Operational Review and Employee Engagement, and _IRM 1.4.51.18_, Director Performance Review and Employee Engagement, for more information. Operational Reviews are conducted within Specialty Collection - Insolvency (SCI) and also are conducted in Collaboration with Headquarters Collection.

2. National quality reviews are conducted on a monthly basis. Consistency reviews are conducted at least annually. See _IRM 1.4.51.16.1_, NQRS and _IRM 1.4.51.16.2_, EQ Consistency Reviews, for more information.


**1.4.51.1.5** **(02-12-2020)**

#### Program Controls

1. SCI Managers are required to follow program management procedures and controls addressed in _IRM 1.4.51.5.2_, Reviews (Overview), _IRM 1.4.51.15_, Controls, and _IRM 1.4.51.16_, Quality.


**1.4.51.1.6** **(02-12-2020)**

#### Terms and Acronyms

1. Frequently used terms used in this IRM along with their definition include:




| **Term** | **Definition** |
| --- | --- |
| Bargaining Unit employee | An employee who is covered by the current National Agreement with the National Treasury Employees Union (NTEU). |
| National Agreement | The contract between the IRS and the National Treasury Employees Union (NTEU) which covers bargaining unit employees. |
| Pyramiding | An in-business taxpayer, not current with Federal Tax Deposits (FTDs) and with two or more balance due trust fund modules assigned to Field Collection. |
| Representative | A person who is authorized to represent a taxpayer before the IRS. |

2. Acceptable acronyms and abbreviations are found in the ReferenceNet Acronym Database, which may be viewed at: ReferenceNet Legal and Tax Research Services.

3. Acronyms used specifically in this IRM section are listed below:




| **Acronym** | **Definition** |
| --- | --- |
| ACS | Automated Collection System |
| ADS | Automated Discharge System |
| AIS | Automated Insolvency System |
| ALS | Automated Lien System |
| APOC | Automated Proof of Claim |
| ASED | Assessment Statute Expiration Date |
| ATFR | Automated Trust Fund Recovery |
| AUR | Automated Underreporter |
| BAPCPA | Bankruptcy Abuse Prevention and Consumer Protection Act of 2005 |
| BCCP | Bankruptcy Code Compliance Program |
| BEC | Bankruptcy Exam Coordinator |
| BFS | Bureau of the Fiscal Service |
| BOD | Business Operating Division |
| BU | Bargaining Unit |
| CAG | Case Assignment Guide |
| CASS | Collection Automation Support & Security |
| CIO | Centralized Insolvency Operation |
| CJE | Critical Job Element |
| CPM | Confirmed Plan Monitoring |
| CSED | Collection Statute Expiration Date |
| DDR | Discharge Determination Report |
| EDF | Employee Drop File |
| EEO | Equal Employment Opportunity |
| ENS | Electronic Noticing System |
| EPF | Employee Performance File |
| EPOC | Electronic Proof of Claim |
| EQRS | Embedded Quality Review System |
| FI | Field Insolvency |
| FTD | Federal Tax Deposit |
| GM | Group Manager |
| GRS | General Records Schedule |
| HCO | Human Capital Office |
| ICS | Integrated Collection System |
| IIP | Insolvency Interface Program |
| IRC | Internal Revenue Code |
| LAMS | Litigation Accounts Management System |
| LR | Labor Relations |
| LTS | Litigation Transcript System |
| NFTL | Notice of Federal Tax Lien |
| NMF | Non-Master File |
| NTEU | National Treasury Employees Union |
| NQRS | National Quality Review System |
| OI | Other Investigation |
| POC | Proof of Claim |
| ROTERs | Records of Tax Enforcement Results |
| RRA 98 | Restructuring and Reform Act of 1998 |
| SERP | Servicewide Electronic Research Program |
| SETR | Single Entry Time Reporting |
| TAS | Taxpayer Advocate Service |
| TFRP | Trust Fund Recovery Penalty |
| TIN | Taxpayer Identification Number |
| TM | Territory Manager |
| WGI | Within Grade Increase |


**1.4.51.1.7** **(06-25-2025)**

#### Related Resources

1. Document 11678, National Agreement - Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU).

2. Document 12990, Records and Information Management Records Control Schedules.

3. Document 12656, Field Insolvency Embedded Quality Job Aid.

4. Document 13097, Centralized Insolvency Operations Technical Team Leader’s Procedural Guide.

5. Document 13219, Automated Insolvency System (AIS) - User Guide.

6. Document 13163, Automated Proof of Claim (APOC) and APOC Amends - User Guide.

7. IRM resources:




| **IRM** | **Title** |
| --- | --- |
| IRM 1.2.1 | Servicewide Policy Statements |
| IRM 1.2.2 | Servicewide Delegations of Authority |
| IRM 1.4.1 | Management Roles and Responsibilities |
| IRM 1.4.1.3 | Administrative Responsibilities |
| IRM 1.5.2 | Uses of Section 1204 Statistics |
| IRM 1.15 | Records and Information Management |
| IRM 5.9.5 | Opening a Bankruptcy Case |
| IRM 5.9.12 | Bankruptcy and Other Insolvencies, Insolvency Automated Processes |
| IRM 5.13.1 | Embedded Quality Collection Field Organizations Administrative Guidelines |
| IRM 6.430.2 | Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs) |
| IRM 6.751 | Discipline and Disciplinary Actions |
| IRM 6.800.2 | IRS Telework Program |
| IRM 10.8.34 | IDRS Security Controls |
| IRM 21.10.1 | Embedded Quality (EQ) Program for Accounts Management, Campus Collection, Campus Examination, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support |
| IRM 25.1.8 | Fraud Handbook, Field Collection |

8. Web Resources:




| Number | Web References |
| --- | --- |
| 1 | Critical Job Elements |
| 2 | Embedded Quality Review System |
| 3 | Embedded Quality Review System (EQRS) |
| 4 | Human Capital Office (HCO) |
| 5 | iManage |
| 6 | Internal Management Documents (IMD) for Interim Guidance Memo (IGM) |
| 7 | My SB/SE |
| 8 | [New Manager Orientation (NMO) Support Center](https://irsgov.sharepoint.com/sites/iManage/SitePages/New-Manager-Orientation-Support-Center.aspx%20) |
| 9 | Office of Professional Responsibility |
| 10 | Document 11043, RRA 98 Section 1203 All Employee Guide |
| 11 | Servicewide Electronic Research Program (SERP) |
| 12 | Telework |
| 13 | Unauthorized access (UNAX) |

9. General Records Schedule (GRS) 2.2, Employee Management Records.


**1.4.51.2** **(06-25-2025)**

### Role of the Field Insolvency Manager and Centralized Insolvency Operation Manager

1. Fundamental responsibilities for all managers are discussed in IRM 1.4.1, Management Roles and Responsibilities. An SCI manager must provide oversight and direction in a number of areas, which will result in accomplishing the mission of the IRS. Oversight responsibilities include, but are not limited to:




| **SCI Manager Oversight Responsibilities** |
| --- |
| 1\. Ensuring case actions are timely and in accordance with current law, policies, and procedures. |
| 2\. Ensuring employees maintain high standards of professionalism in all correspondence and telephone contacts with the public, internal customers, external customers, and coworkers. |
| 3\. Ensuring taxpayer rights are observed and taxpayers and/or their representatives are advised of those rights and how to exercise them. |
| 4\. Ensuring employees are aware of the role of the Taxpayer Advocate Service and the Low Income Tax Clinics (refer to Pub 4134, Low Income Taxpayer Clinic List), and the service these functions provide is properly communicated with taxpayers and/or their representative. |
| 5\. Ensuring employees are aware of ongoing changes to the laws, policies, and procedures that relate to their responsibilities (preferably during group meetings). |
| 6\. Addressing system issues that impact either internal or external customer needs. |
| 7\. Ensuring cases are assigned timely and employee workload:- Reflects current priorities.- Reflects employee experience and skill level.- Addresses Servicewide objectives.- Protects public interests.- Allows for effective case processing |
| 8\. Helping employees make the appropriate next case decision. |
| 9\. Providing ongoing employee feedback that is candid and meaningful and will establish a basis for determining an accurate assessment of performance and developmental needs. |
| 10\. Issuing the Critical Job Elements (CJE) timely and evaluating employee performance against their CJEs |
| 11\. Creating and maintaining a work environment that will promote team work, positive working relationships, and increased employee satisfaction. |
| 12\. Ensuring employees have necessary functioning equipment and supplies. |
| 13\. Ensuring employees are accountable for the appropriateness of their actions. |

2. Responsibilities also include:



1. Developing employees.

2. Evaluating employee performance and providing counseling.

3. Addressing employee conduct issues.

4. Fostering good working relationships.

5. Defining goals and course of action.

6. Assigning and directing work.

7. Instructing employees in the application of procedures and guidelines.

8. Displaying integrity in all actions.


3. Managers are empowered to address performance deficiencies within their group. This may be accomplished through reviews and/or by requiring concurrence with performing specific actions.



### Example:



It is found that Notice of Federal Tax Lien (NFTL) re-filing determinations are not being made in accordance with IRM 5.9.5.9.2, Refiling Notices of Federal Tax Lien (NFTLs). The manager can require the employee to notify him or her at case closure of Automated Insolvency System (AIS) history documentation of the NFTL refiling determination.





### Note:



For additional direction regarding performance issues see _Exhibit 1.4.51-1_, Suggested Action Steps for Unacceptable Performance.

4. Managers oversee group remittance processing activities, including monitoring Form 5919, Teller's Error Advice, sent to their group. See IRM 5.1.2.5.6, Responding to Form 5919.

5. Managers are responsible for ensuring employees have access to the IDRS command codes necessary to perform their assigned tasks and required research. When an employee is expected to be away from their terminal for more than two weeks or longer the employee should lock their profile to avoid being locked out by Data Security. The CC LOKME is used to lock IDRS. Refer to ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡, for additional information.

6. Managers coordinate IDRS security with their assigned Unit Security Representative (USR), otherwise known by their organizational title: Data Security Analyst (DSA). See IRM 5.1.25.2, IDRS Security Personnel, for additional information.



### Note:



Managers are responsible for addressing the USR/DSA emails regarding IDRS related inquires within five business days.


**1.4.51.2.1** **(02-12-2020)**

#### Acting Manager Assignments and Designations

1. You must designate with a formal delegation an acting manager during your periods of absence. Managerial tasks to be performed and those to be deferred may depend on the duration of the assignment. Refer to Document 11678, National Agreement - IRS/NTEU, for certain restrictions on performance evaluations. Assignments should be agreed on between you and the acting manager in advance. Specific expectations should be given at the beginning of each assignment. This will form the basis for your feedback on performance of the acting assignment.

2. For the delegated acting manager you must utilize discretion to determine whether inventory level needs to be adjusted for the action. Factors to consider are:



   - length of acting assignment and

   - duties to be performed during this assignment.


3. You may designate specific tasks even though you are not absent. This enables a manager to provide developmental assignments to employees aspiring to the next level to gain useful experience. In this situation, no "acting" assignment or delegation exists; therefore tasks reserved to managers (i.e., managerial approvals, callbacks requested by the taxpayer) cannot be delegated.


**1.4.51.2.2** **(11-17-2022)**

#### Communication of Expectations

1. When a new group is established or a new manager is assigned to an existing group, a meeting with the employees must be held within the first 30 days. At this meeting the manager will communicate expectations to include the following topics:



   - Safety and security

   - Group procedures

   - Case work

   - Use of time in the office and telework

   - Timeliness of case activity

   - Reasonable time frames for case actions. (See IRM 5.9.5.5, Initial Processing Actions, IRM 5.9.5.4, Automated Insolvency System (AIS) Documentation, and IRM 5.9.16, Insolvency Case Monitoring, for timeliness and time frames.)

   - Case Review Schedule


### Reminder:

These expectations should also be reviewed at the beginning of each fiscal year.

### Note:

This meeting is considered a 7114 meeting. Local National Treasury Employees Union (NTEU) chapter(s) must be notified of the meeting in accordance with Article 8, Union Rights, of the National Agreement - IRS/NTEU.

2. When a new employee is assigned to an existing group, the group manager must meet with the new employee to discuss managerial expectations (see (1) above) and ensure appropriate Business Entitlement Access Request System (BEARS) are completed and processed. This meeting is considered a 7114 meeting. See the Note in (1) above.


**1.4.51.2.3** **(02-12-2020)**

#### Group Meetings

1. Regular group meetings will be held as necessary to review items such as the following:




| **Examples of items that may be discuss during group meetings** |
| --- |
| Directives from the Director, Territory / Operation Manager, Department Manager, and Headquarters |
| Procedural memoranda |
| IRM changes |
| Case resolution techniques |
| Case resolution techniques |
| Changes in condition of employment |
| Automation issues |
| Mandated topics not available on other media |
| General group (employee) concerns |
| IRS employee engagement issues |
| Annual IRS Employee Survey results |
| Complex cases to brainstorm ideas to assist in taking appropriate closing actions |
| Case resolution techniques in order to share best practices |





### Note:



Regular group meetings are not ordinarily considered 7114 meetings. The Union entitlement arises where there is a discussion of a personnel policy, practice, or other general condition of employment.





### Example:



A discussion at a group meeting on the need to make timely TFRP determinations or how to handle a particular type of case would not ordinarily be considered 7114 issues. A group meeting addressing changes in condition of employment would ordinarily be considered a 7114 meeting.

2. Managers should seek guidance and advice from their servicing Labor Relations (LR) Section if they are unsure whether an agenda item for a group meeting constitutes a 7114 issue. Article 8, Section 1, Union Rights, of the National Agreement - IRS/NTEU also provides guidance on 7114 Meetings. For regularly scheduled formal discussions and non-recurring formal discussion, provide the Union a notice and meeting agenda no less than five workdays in advance.


**1.4.51.2.4** **(02-04-2025)**

#### End of Month (EOM) Processing

1. Managers are responsible for reviewing time reported by their employees to ensure accuracy. Using Integrated Collection System (ICS), verify time prior to End of Month (EOM) processing (i.e., no later than close of business on the last Friday of the monthly reporting period). Consider the following:



1. Be alert for, and/or address as appropriate, issues such as: potentially excessive administrative time, discrepancies related to credit, compensatory, holiday, training time, etc.

2. Perform weekly time verification and checks for all employees.

3. Refer to IRM 5.2.1, Collection Time Reporting, for specific information about Group Manager (GM) responsibilities related to time reporting.


### Note:

Only Field Insolvency (FI) employees report time to ICS, CIO employees input their time in SETR.

**1.4.51.2.5** **(02-12-2020)**

#### Functional Role

1. The Insolvency function is comprised of two operations, Field Insolvency (FI) and the Centralized Insolvency Operation (CIO), which must work together to provide customer service while addressing employee satisfaction in delivering improved business results. Three separate business units are directly involved in bankruptcy processing:



   - Specialty Collection - Insolvency (FI and CIO)

   - Collection Policy, Insolvency

   - SB/SE Counsel


2. **Field Insolvency (FI).** FI has many offices throughout the country. FI:



   - Works all aspects of Chapter 11, Chapter 12, Assignments, and Receiverships.

   - Completes initial case review of Chapter 7 Asset (7A) and Chapter 13 cases.

   - Works Chapter 7 No Asset (7N) Large Dollar cases referred to them from CIO.

   - Refers Chapter 9 and Chapter 15 cases to Counsel for procedural guidance after clerical processing has been completed.

   - Responds to "complex issues" on any case regardless of chapter. (See IRM 5.9.1.4(6), Complex and Non-Complex Issues Worked by FI.)


3. **Centralized Insolvency Operation (CIO).** The CIO is located in Philadelphia. The CIO:



   - Performs initial clerical processing on cases for all bankruptcy chapters.

   - Works Chapter 7 No Asset (7N) cases from 341 notice to closure including screening large dollar cases for exempt and abandoned property.

   - Works Chapter 7 Asset (7A) and Chapter 13 cases after initial case review until closure.

   - Forwards Chapter 9 and Chapter 15 Insolvency Interface Program (IIP) reports and Chapter 11 Status 22 reports to FI to work.

   - Completes mirroring of accounts.

   - Reinstates all installment agreements at case closure, when the case meets IA reinstatement criteria.

   - Sends complex issues to FI to work.


4. **Collection Policy.** Collection Policy, Insolvency establishes and oversees policy for the entire Insolvency program. Collection Policy, Insolvency:




| **Example of areas oversees by Collection Policy, Insolvency** |
| --- |
| Owns IRM 5.9, IRM 5.17.8 - 5.17.11, and IRM 1.4.51. |
| Prepares IRM Procedural Updates (IPU) and Interim Guidance Memorandums (IGM). |
| Owns AIS and all associated subsystems (APOC, EPOC, ENS, ADS, and IIP). |
| Makes all policy decisions affecting Insolvency as an enterprise covering both the CIO and Field. |
| Reviews FI and CIO procedures, alerts, training materials, and job aids. |
| Owns the Bankruptcy Law Advisory Rules Engine (BLARE) information system and participates on the BLARE rules committee. |
| Submits requests for systems updates. |
| Responds to suggestions made through Form 13380, I Suggest, Servicewide Electronic Research Program (SERP) Feedback, and the Employee Suggestion Program. |
| Interacts with other National Office analysts on issues that impact bankruptcy processing. |
| Clears IRM bankruptcy sections written for other programs, such as Field Collection and Examination. |
| Handles technical questions from FI and CIO. |
| Performs operational reviews of FI and CIO. |

5. **SB/SE Counsel Coordination.** If an issue arises jeopardizing the government's best interests that cannot be resolved by Insolvency's contacting the debtor's attorney directly, Insolvency, depending on IRM criteria, may coordinate action(s) with Area Counsel, Department of Justice (DOJ), or other legal functions. (See IRM 5.9.4.15, Referrals - Representing IRS in Bankruptcy Court, IRM 5.9.4.15.1, Direct Referrals, IRM 5.9.4.15.2, Referrals to Counsel (Non-Direct Referrals), and IRM 5.9.4.15.3, Significant Bankruptcy Case Referrals.)


**1.4.51.3** **(11-17-2022)**

### General Managerial Responsibilities

1. IRM 1.4.1.3, Administrative Responsibility, contains information about general managerial responsibilities. Place special emphasis on responsibilities shown in the following sections.


**1.4.51.3.1** **(02-12-2020)**

#### Administrative

1. Group managers are responsible for oversight of certain administration functions for their employees including but not limited to:



1. Overseeing the time reporting process.

2. Maintenance of time and attendance records.

3. Certifying overtime records.

4. Approving scheduled and unscheduled leave.

5. Controlling and approving travel.

6. Maintaining safe working conditions.

7. Holding group meetings.

8. Keeping employees current on all applicable policies and procedures.


2. Other Administrative tasks include, but are not limited to:



   - Ensuring group End of Month reports are completed correctly (verified, generated, and approved) by the due date.

   - Completing quarterly Section 1204 self certifications.

   - Oversight of supply procurement.

   - Maintaining Employee Performance File (EPF) and Drop Files for each employee.



     ### Caution:



     Managers may delegate certain duties to a secretary / administrative assistant; however, they retain oversight responsibility for those tasks.


3. Items managers must update individually with each employee annually include, but are not limited to:



   - Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard

   - Form 11386, IRS Telework Agreement for Bargaining Unit (BU)



     ### Note:



     Per IRM 6.800.2.1.3.2, Manager Responsibilities, under (1)(i), while managers must review all Telework Agreements every year, if there are no changes to the existing Telework Agreement, there is no need to take any action to have the employee update it annually.

   - Form 7995, Outside Employment or Business Activity Request

   - Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Election


4. Resources:



   - IRM 1.4.1.3, Administrative Responsibilities

   - Document 12990, Records and Information Management Record Control Schedules

   - New Manager Orientation

   - iManage


**1.4.51.3.1.1** **(11-17-2022)**

##### Employee Performance File (EPF)

1. Managers are responsible for establishing and maintaining an EPF for each of their employees. The EPF is a system consisting of all performance ratings and other performance-related records maintained in accordance with 5 CFR 293, Subpart D.

2. Managers are responsible for ensuring the effective use of the EPF by:



1. Ensuring that the proper documents are included in each EPF.



      ### Note:



      See IRM 6.430.2.3.5, Employee Performance File (EPF).

2. Ensuring that filing and purging of performance related documents and records are in compliance with requirements.

3. Keeping all performance records and documents secured.

4. Forwarding EPF records of employees transferring to other Treasury Bureaus or to a different post of duty or manager within the IRS.

5. The National Archives and Records Administration (NARA) approved General Records Schedule (GRS) 2.2, Employee Management Records, Item 70, Employee performance file system records, provides mandatory records retention and disposition instructions for administrative functions that are common to all government agencies to prevent inadvertent/unlawful destruction of records.


3. Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard, is maintained in the EPF. Managers must update the form annually and ensure it is signed and dated. (See IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers.)

4. Recordations are included in the EPF. A recordation is defined as a manager's written record evaluating an employee in a positive or negative manner. For BU employees, a recordation must be furnished to an employee within fifteen (15) workdays of the time the manager becomes aware, or should have been aware, of the event that it addresses. If it is not furnished within fifteen (15) workdays, it cannot become part of the EPF.

5. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request, is maintained in the EPF. Electronic signatures may be used on Form 6850-BU, processed through HR Connect, however paper copies of the form must be maintained in the EPF.

6. The EPF is maintained in addition to and **separate** from the Employee Drop File (EDF). The EPF is not the same as the Official Personnel File (OPF). (See IRM 1.4.1.8.4, Official Personnel File (OPF).)

7. For additional information regarding the specific items to be placed in the EPF and the retention period, refer to:



   - Human Capital Office (HCO)

   - Document 11678, National Agreement - IRS/NTEU, Article 12, Performance Appraisal System:

   - IRM 6.430.2.3.5, Employee Performance File (EPF)

   - The assigned Labor Relations Specialist

   - [HR Connect](https://hrconnect.treasury.gov/)

   - General Records Schedule (GRS) 2.2, Employee Management Records, Item 70, Employee performance file system records


**1.4.51.3.1.2** **(02-12-2020)**

##### Employee Drop File (EDF)

1. In addition to the EPF, a second file should be established for each employee. This is referred to as the Drop File. The Employee Drop File is for other documentation not related to performance.

2. The Drop File should contain anything that is not performance related, such as leave counseling and copies of disciplinary actions. Questions about the use of a Drop File can be directed to the Labor Relations office.


**1.4.51.3.1.3** **(02-12-2020)**

##### Medical Information

1. Employee medical information must be maintained separately from the EPF and EDF.

2. For more information, see:



   - IRM 6.630.1.5.4, Safeguarding Medical Information

   - Human Capital Office


**1.4.51.3.2** **(11-17-2022)**

#### Protecting Taxpayer Rights

1. A primary responsibility of managers is to monitor employee practices and actions to ensure that taxpayer rights are always observed. In fact, Congress has now directed the IRS to ensure that all employees are aware of taxpayer rights. See **Consolidated Appropriations Act, 2016, Pub. L. No. 114-113, div. Q, tit. IV, subtit. A, sec. 401(a), 129 Stat. 2242, 3117 (codified as 26 U.S.C. 7803(a)(3))**.

2. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see [Taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights). (See Pub 1, Your Rights as a Taxpayer):



01. The Right to Be Informed: Taxpayers have the right to know what they need to do to comply with the tax laws. They are entitled to clear explanations of the laws and IRS procedures in all tax forms, instructions, publications, notices, and correspondence. They have the right to be informed of IRS decisions about their tax accounts and to receive clear explanations of the outcomes.

02. The Right to Quality Service: Taxpayers have the right to receive prompt, courteous, and professional assistance in their dealings with the IRS, to be spoken to in a way they can easily understand, to receive clear and easily understandable communications from the IRS, and to speak to a supervisor about inadequate service.

03. The Right to Pay No More than the Correct Amount of Tax: Taxpayers have the right to pay only the amount of tax legally due, including interest and penalties, and to have the IRS apply all tax payments properly.

04. The Right to Challenge IRS’s Position and Be Heard: Taxpayer have the rights to raise objections and provide additional documentation in response to formal IRS actions or proposed actions, to expect that the IRS will consider their timely objection and documentation promptly and fairly, and to receive a response if the IRS does not agree with their position.

05. The Right to Appeal an IRS Decision in an Independent Forum: Taxpayers are entitled to a fair and impartial administrative appeal of most IRS decisions, including many penalties, and have the right to receive a written response regarding the Office of Appeals’ decision. Taxpayers generally have the right to take their cases to court.

06. The Right to Finality: Taxpayers have the right to know the maximum amount of time they have to challenge the IRS’s position as well as the maximum amount of time the IRS has to audit a particular tax year or collect a tax debt. Taxpayers have the right to know when the IRS has finished an audit.

07. The Right to Privacy: Taxpayers have the right to expect that any IRS inquiry, examination, or enforcement action will comply with the law and be no more intrusive than necessary, and will respect all due process rights, including search and seizure protections and will provide, where applicable, a collection due process hearing.

08. The Right to Confidentiality: Taxpayers have the right to expect that any information they provide to the IRS will not be disclosed unless authorized by the taxpayer or by law. Taxpayers have the right to expect appropriate action will be taken against employees, return preparer, and others who wrongfully use or disclose taxpayer return information.

09. The Right to Retain Representation: Taxpayers have the right to retain an authorized representative of their choice to represent them in their dealings with the IRS. Taxpayers have the right to seek assistance from a Low Income Taxpayer Clinic if they cannot afford representation.

10. The Right to a Fair and Just Tax System: Taxpayers have the right to expect the tax system to consider facts and circumstances that might affect their underlying liabilities, ability to pay, or ability to provide information timely. Taxpayers have the right to receive assistance from the Taxpayer Advocate Service if they are experiencing financial difficulty or if the IRS has not resolved their tax issues properly and timely through its normal channels.


3. Ensure that all employees are aware of the role the Taxpayer Advocate Service (TAS), and that this information is properly communicated to taxpayers and their representatives, as appropriate. TAS is an independent organization within the IRS that ensures tax problems that have not been resolved through normal channels are promptly and fairly handled. To determine if a case meets TAS criteria, see IRM 13.1.7.3, TAS Case Criteria. Access to TAS can be obtained by calling their toll-free number 877-777-4778, researching Pub 1546, The Taxpayer Advocate Service Is Your Voice at the IRS, or visiting their website [Taxpayer Advocate Service](https://www.irs.gov/taxpayer-advocate).

4. Section 1203 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA 98) calls for the termination of any employee of the IRS if there is a final administrative or judicial determination that the employee willfully committed any act or omission described below:



01. Failing to obtain required approval signatures when making certain seizures.

02. Providing a sworn false statement in a "material matter" concerning a taxpayer.

03. Violating the constitutional rights of or discriminating against taxpayers, taxpayer's representatives or other employees of the IRS.

04. Falsifying or destroying documents to cover a mistake concerning a taxpayer.

05. Receiving a criminal conviction or civil judgment for assault or battery on a taxpayer, taxpayer's representative or another employee of the IRS.

06. Violating the Internal Revenue Code (IRC), IRS regulations or policies to retaliate against or harass taxpayers, taxpayers’ representatives, or other IRS employees.

07. Willful misuse of IRC 6103, Confidentiality and Disclosure or Returns and Return Information, to conceal information from Congressional inquiry.

08. Failing to file a federal tax return on or before its due date, unless it is due to reasonable cause.

09. Understating federal tax liability, unless it is due to reasonable cause.

10. Threatening an audit for personal gain or benefit.


5. There is an important distinction between evaluating performance under CJE 2, Taxpayer Rights, and evaluating compliance with the Retention Standard for the Fair and Equitable Treatment of Taxpayers. See the Human Capitol Office website for more information.

6. Resources:



   - Form 6774, Receipt of Critical Job Elements and Retention Standard

   - IRM 6.430.2.4.7, Rating Performance Against The Retention Standard for The Fair and Equitable Treatment of Taxpayers

   - IRM 6.430.2.2.5, Discussing The Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRC 1203 and non 1203 Misconduct

   - Retention Standard Resources: Employees Evaluated by CJEs Policy, Guidance and Memoranda

   - Office of Professional Responsibility

   - Pub 947, Practice Before the IRS and Power of Attorney

   - IRM 5.1.23, Taxpayer Representation

   - Taxpayer Bill of Rights: Taxpayer Bill of Rights


**1.4.51.3.2.1** **(02-12-2020)**

##### Direct Contact For Taxpayers With/or Requesting Representation

1. Managers should ensure that their group is in conformance with IRC 7521, Procedures Involving Taxpayers Interviews. It is important to ensure that employees comply with the guidelines about direct contact with taxpayers who are represented by a power or attorney. Specifically, employees are required to:



1. Stop the interview with a taxpayer (unless required by court order) whenever a taxpayer requests to consult with a representative who is permitted to represent taxpayers before the IRS (e.g., accountant, CPA, attorney, or enrolled agent).

2. Obtain managerial approval to contact the taxpayer instead of the representative, if the representative is responsible for unreasonably delaying or hindering the completion of a collection action. See IRM 5.1.23.6, By-Passing a Taxpayer’s Authorized Representative.


### Exception:

Per IRM 5.1.23.6(6), By-Passing a Taxpayer’s Authorized Representative, the IRS may work directly with a taxpayer to resolve an issue on the taxpayer's account if: 1) The taxpayer initiates the contact to resolve the issue on the account 2) The taxpayer expresses a specific desire to resolve the issue without the involvement of the representative after the IRS employee has advised the taxpayer of the current representation, and 3) The taxpayer's desire to have the IRS work directly with the taxpayer instead of the representative is properly documented in the case file.

2. Examples of steps managers can take to ensure compliance by their employees are:



   - Group meetings

   - Case reviews

   - Workload reviews

   - Field visitations

   - Office visitations

   - Taxpayer/representative inquiries (if necessary)


**1.4.51.3.2.2** **(02-12-2020)**

##### Recording Taxpayer Interviews

1. A taxpayer or representative may request to use audio or video equipment to record an in-person interview. See IRM 5.1.12.3, Recording Taxpayer Interviews, for information on responding to such requests. The right to make an audio recording does not extend to telephone interviews.


**1.4.51.3.2.3** **(02-04-2025)**

##### Fair Tax Collection Practices

1. IRC 6304, Fair Tax Collection Practices, imposes certain restrictions with respect to tax collection. During a case review or upon receiving a complaint from a taxpayer, managers may identify a potential violation of those restrictions. Potential employee violations of IRC 6304 must be reported to the assigned Labor Relations (LR) Specialist by the close of the next business day following notification of the alleged violation. You are not required to report instances to Labor Relations where you have determined the employee’s conduct is **not** a potential violation of IRC 6304, Fair Tax Collection Practices. Document the AIS history with your discussions or correspondence associated with the complainant.

2. To ensure collected data is complete and accurate, use the following IRC 6304 issue codes when reporting the potential violation. Labor Relations uses these codes for tracking on the Automated Labor and Employee Relations Tracking System (ALERTS).



   - **141 - Contact with TP at Unusual Time/Place:** Contacting a taxpayer before 8:00 am or after 9:00 pm, or at an unusual location or time, or location known or which should be known to be inconvenient to the taxpayer.

   - **142 - Contact TP without Rep:** Contacting a taxpayer directly without the consent of the taxpayer’s Power of Attorney.

   - **143 - Contact at a TP Employer, Prohibited:** Contacting a taxpayer at their place of employment when it is known or should be known that the taxpayer’s employer prohibits the taxpayer from receiving such communication.

   - **144 - Taxpayer Harassment:** Any allegation of taxpayer harassment should be reviewed along with the Internal Revenue Code (IRC 6304) because the provision is intended to be applied in a general manner when evaluating the alleged employee misconduct. Conduct which is intended to harass a taxpayer, or conduct which uses or threatens to use violence or harm is an absolute violation of the IRC.

   - **145 - Taxpayer Abuse:** Any allegation of taxpayer abuse should be reviewed along with the Internal Revenue Code (IRC 6304) because the provision is intended to be applied in a general manner when evaluating the alleged employee misconduct. The use of obscene or profane language towards a taxpayer is an absolute violation of the IRC.

   - **146 - Continuous Phone Harassment:** Causing a taxpayer’s telephone to ring continuously with harassing intent.

   - **147 - Phone Call without ID Disclosure:** Contacting a taxpayer by telephone without providing a meaningful disclosure of the IRS employee’s identity.


3. If violations are confirmed, work with a LR Specialist to determine the next appropriate action.

4. Resources:



   - IRM 5.1.10.6, Fair Tax Collection Practices

   - IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRM 6.430.2.4.7, Rating Performance Against The Retention Standard for the Fair and Equitable Treatment of Taxpayers


**1.4.51.3.2.4** **(02-12-2020)**

##### Ex Parte Communication With Appeals/Managerial Oversight

1. An **ex parte communication**” is a communication that takes place between any Appeals employee and employees of other IRS functions, without the taxpayer/representative being given an opportunity to participate in the communication. The term includes all forms of communication, oral or written. Written communications include those that are manually or electronically generated. Rev. Proc. 2012-18, Ex Parte Communications Between Appeals and Other IRS Employees, applies to communications that take place after May 15, 2012, and clarifies the rules regarding ex-parte communications.



### Note:



For additional information on the ex-parte communication rules, see IRM 8.1.10 Ex-Parte Communications.

2. Prior to approving Collection Due Process (CDP) cases for transmittal to Appeals, review Form 14461, Transmittal of the CDP/Equivalent Hearing Request.



   - Ensure that narrative statements are limited to a neutral list of documents and neutral statements regarding actions taken and documented in the case history without any further discussion regarding the strengths and weaknesses of the taxpayer’s appeal.

   - Ensure that no prohibited ex-parte communications are included before approving the transmittal of the case to Appeals.


3. Managers must also ensure that no prohibited ex-parte communications are included in Trust Fund Recovery Penalty (TFRP) case files or the AIS/Automated Trust Fund Recovery Program (ATFR) case history before approving the transmittal of the case to Civil Enforcement Advice and Support Operations (CEASO).

4. If a taxpayer submits a written appeal after a (non-TFRP) Penalty Abatement Request is denied, and Appeals consideration is necessary, employees will forward the appeal to their manager for review and concurrence. The manager ensures that the AIS history is attached to the appeal request and that no prohibited ex-parte communications are included before approving the transmittal of the case to Appeals. If the case history contains commentary that is determined to violate the ex-parte communication rules, take appropriate action, which could include sharing the information with the taxpayer, and affording the taxpayer a reasonable period of time within which to respond, or other remedy within the discretion of Appeals at the time it is sent to Appeals.

5. If the appeal contains new information that requires additional investigation or Integrated Collection System (ICS) documentation, the caseworker must secure managerial concurrence of the decision to sustain penalty abatement denial. If the caseworker is unable to make contact with the taxpayer within a reasonable time period, the caseworker will forward the case file to the GM and the GM will take the following actions:



   - Prepare a letter to the taxpayer that identifies the new information and a brief summary of the results of the additional investigation.

   - Document issuance of the letter to the taxpayer in the case history and attach a copy of the letter to the taxpayer appeal.

   - Ensure that the case history is attached to the appeal request and that no prohibited ex parte communications are included before approving the transmittal of the case to Appeals.


6. Fast Track Mediation (FTM) can be used for TFRP protests and certain Offers in Compromise. The prohibition against ex-parte communications between Appeals employees and originating function employees does **not apply** to FTM because the Appeals employees are not acting in their traditional Appeals settlement role. Ex-parte communications, such as a private caucus between the Appeals mediator and Collection employees during the course of the mediation session, are permissible under the ex-parte communication rules.

7. Resources:



   - IRM 5.1.9.5, Communications with Appeals

   - IRM 5.1.9.3.3.2, Sending Hearing Request to Appeals

   - IRM 8.1.10.5, Opportunity to Participate

   - IRM 5.1.15.16.4, Penalty Relief Denial and Appeals

   - IRM 5.7.6, Trust Fund Penalty Assessment Action


**1.4.51.3.3** **(02-12-2020)**

#### IDRS Security

1. Integrated Data Retrieval System (IDRS) security briefings are included in the mandatory Annual On-Line Briefings. IDRS security should also be reinforced through discussions at group/unit meetings.

2. Employees should be reminded to complete Form 11377-E, Taxpayer Data Access, if an account is inadvertently accessed or otherwise applicable.

3. IRM 10.8.34, IDRS Security Controls, requires managers to review periodic IDRS Security reports for their groups. In Insolvency, primary responsibility for those reviews rests with Collection Automation Support & Security (CASS). Managers may be contacted by a CASS representative if they are unable to resolve a potentially questionable access made by an employee.

4. Generally, CASS will contact the manager via secure e-mail. If contacted, the manager should take the following steps:



   - Take appropriate action to determine whether or not there was a business reason for the access. Actions may include conversations with the employee, review of case inventory, review of IDRS case controls, use of IDRS Online Reports Services (IORS) queries, review of audit trails, determining if access was by automated process, etc.

   - Provide feedback about their findings to CASS within five business days of their request


5. Resources:



   - IRM 10.8.34, IDRS Security Controls

   - Form 11377-E, Taxpayer Data Access

   - Unauthorized Access of Taxpayer Accounts (UNAX).


**1.4.51.3.4** **(02-12-2020)**

#### Employee Safety/Security

1. Safety and security is a high priority. Managers must become familiar with their responsibilities to ensure workplace safety for everyone.

2. See IRM 5.1.3, Safety, Security, and Control, for information about safety and security topics.

3. Resources:



   - Employee Resources

   - [Employee Compensation Operations & Management Portal (ECOMP)](https://www.ecomp.dol.gov/#/)


**1.4.51.3.5** **(02-12-2020)**

#### Working With NTEU

1. Group Managers who supervise bargaining unit (BU) employees must:



1. Notify the requisite chapter(s) regarding 7114 meetings when they plan to discuss changes in personnel policies, practices and working conditions with their employees. Generally, five workdays notice is provided. See Article 8, Union Rights, of the National Agreement.

2. Make sure employees have the opportunity to be represented at formal discussions regarding employee grievances. See IRM 6.771.1, Agency Grievance System (AGS), and Document 11678 National Agreement - IRS/NTEU, other personnel matters, and conduct issues.


2. See Article 8 of the National Agreement - IRS/NTEU for more information about how to identify 7114 meetings. Contact a LR Specialist if assistance is needed to determine if a meeting is a 7114 meeting.

3. Resources:



   - IRM 1.4.1.4, Agreements with NTEU, or contact the assigned Labor Relations Specialist.

   - IRM 6.771.1, Agency Grievance System (AGS)

   - National Agreement - IRS/NTEU


**1.4.51.3.6** **(02-04-2025)**

#### Functional Security Reviews

1. Insolvency managers (or their designated representative) will conduct annual security reviews. The policy requirement for functional reviews, as well as Form 12149 Functional Security Reviews is rescinded. SCI should develop their own reviews or data collection instrument to assess policy implementation and compliance. For additional information see IRM 10.5.1.5.1, Clean Desk Policy and IRM 10.5.1.6.1, Protecting and Safeguarding SBU Data.

2. If a manager's reviews reflect that an employee repeatedly fails to observe security protocols, the manager should contact the LR specialist to determine the next appropriate action.


**1.4.51.3.7** **(02-12-2020)**

#### Case Related

1. **Casework**. Managers must ensure Insolvency case actions comply with the requirements of the Bankruptcy Code Compliance Program (BCCP) while protecting the government's interest and educating debtors on their payment and filing responsibilities.

2. **Stay Violations**. Insolvency managers oversee resolutions of Bankruptcy Code stay violations ensuring corrective actions are initiated no later than **two work days** after identification by Insolvency caseworkers or notification from taxpayers, their representatives, other government agencies, or other IRS functions. IRM 5.9.3.5, Automatic Stay, gives an in depth discussion of the nature of stay violations.

3. **Discharge Violations**. When violations of the discharge injunction are identified, Insolvency managers must ensure caseworkers initiate resolutions of the violations no later than **two work days** after identification or notification. If the IRS receives adequate notice of the bankruptcy discharge, violations may occur after Insolvency has adjusted an account through the Automated Discharge System (ADS) or has made a manual adjustment. Violations can also arise while Insolvency's adjustment requests are pending. IRM 5.9.17.9, Discharge Injunction, provides more information on this topic.

4. **Review of Closed Cases**. Referrals from other IRS functions must be reviewed by Insolvency when a taxpayer facing collection claims a liability is no longer due because of a bankruptcy discharge. Insolvency must provide guidance concerning the dischargeability of periods to all other IRS functions.

5. **AIS Documentation**. Insolvency managers must direct subordinates to document all actions related to the IRS's involvement in a bankruptcy proceeding in the AIS history, also known as the History screen. Insolvency is the primary repository of bankruptcy-related case actions for all functions of the IRS. (See IRM 5.9.5.4, Automated Insolvency System (AIS) documentation.)

6. **Objections**. Whenever possible Insolvency administratively resolves objections to the IRS's actions in bankruptcy, usually involving proofs of claim, that otherwise would be handled by the US Attorney, Department of Justice (DOJ), or Area Counsel. Case specific matters that cannot be resolved administratively, such as objections to plan confirmation or requests for conversion or dismissal, are referred to Area Counsel, the US Attorney, or DOJ.

7. **Damage Claims**. Insolvency managers must process administrative damage claims pursuant to Treas. Reg. 301.7433-2, Civil cause of action for violation of section 362 or 524 of the Bankruptcy Code. (See _IRM 1.4.51.3.7.1_, Payment of Damages, below)


**1.4.51.3.7.1** **(06-25-2025)**

##### Payment of Damages

01. **Overview**. The Commissioner of the IRS has authority to pay damages and attorney's fees from general appropriations in the settlement of the IRS’s liabilities on claims for violations of the automatic stay and discharge injunction. Awards are categorized as either:



    1. Litigative: an award in the form of a settlement or judgment resulting from a lawsuit; or

    2. Administrative: an award premised on an agency's claim authority.


### Note:

Payment requests are processed through the Bureau of the Fiscal Service (BFS), and the treatment of the two categories of awards differs slightly. (See paragraphs (17) and (18) below.

02. **Processing Office**. The processing office (FI or CIO) assigned to the case when the violation occurred will be responsible for processing claims for payment of damages up until a referral to Counsel is required. At that point the case becomes a complex issue and will be handled to conclusion by the assigned Field Insolvency office.

03. **Who Must File a Claim**. The debtor, debtor's representative, or trustee must file a claim with the IRS. The IRS will directly pay the damages and/or attorney's fees if certain criteria are met.

04. **Willfulness**. The IRS can only be held liable for damages and attorney's fees if it commits a "willful violation" of the stay or discharge injunction. For a violation to be willful, the IRS must know about the stay or discharge and initiate or continue collection activities. If the IRS lacked notice of the stay or discharge injunction, the violation would not be willful. Even when the IRS knows about a stay or discharge injunction, a good faith belief that it is inapplicable might be relevant. If the IRS had a good faith (but erroneous) belief that the stay or discharge did not apply (e.g., the IRS reasonably determined that the liability is excepted from discharge), consult Counsel regarding whether damages should apply. _Taggart v. Lorenzen_, 587 U.S. 554, 557 (2019), holding that a bankruptcy court cannot impose contempt sanctions if there was an objectively reasonable basis for concluding that the creditor's conduct might be lawful. (Taggart did not deal with willful violations of the stay or discharge injunction, but a similar standard may apply in these situations.)

05. **Identifying Willfulness**. To determine if a willful violation has occurred, Insolvency must verify if the IRS received notice of the bankruptcy or discharge order and:



    - Subsequently engaged in collection activities, or

    - Failed to halt its collection activities.


06. **Time frames**. Generally for a claim to be considered, the IRS must have failed to take appropriate action within the time frames of the Bankruptcy Code Compliance Program (BCCP). Those time frames are reflected in the chart below:




    | **Time Limits** | **Required Actions** |
    | :-: | :-: |
    | Two work days | Initiate corrective action on violations of the automatic stay or discharge injunction. |
    | Five work days | Process initial bankruptcy petition information and ensure input of TC 520. |
    | 10 work days | Review damage claim applications for damages and attorney's fees for completeness and willfulness determination. |
    | 30 calendar days | Process discharge/dismissal notices and initiate closing procedures. |
    | 60 calendar days | Provide the debtor with a written response concerning the acceptance or denial of the claim application. |

07. **Exceptions to Time frames**. Regardless of general time frames, if an IRS employee initiates a collection action with knowledge of the stay or discharge, the action is a willful violation.



    ### Example:



    If a debtor tells an employee that they are in bankruptcy, and the employee proceeds with a seizure, the collection action is a willful violation.

08. **Claim Applications**. Because no standard IRS form for requesting payment of a claim has been published, a claim request must be submitted by letter. Field Insolvency offices must provide a claimant the nature of the information to be included in the application letter and where to send the claim. Share the following website, which provides additional information: [Claims for relief and damages for violations of bankruptcy automatic stay or discharge injunction](https://www.irs.gov/businesses/small-businesses-self-employed/claims-for-relief-and-damages-for-violations-of-bankruptcy-automatic-stay-or-discharge-injunction). To be considered complete, a claim must be in writing and include the following:



    1. The name, taxpayer identification number, current address, and current home and work telephone numbers (with an identification of any convenient times to be contacted) of the taxpayer making the claim;

    2. The location of the bankruptcy court in which the underlying bankruptcy case was filed and the case number of the case in which the violation occurred;

    3. A description, in reasonable detail, of the violation (include copies of any available substantiating documentation or correspondence with the IRS;

    4. A description of the injuries incurred by the taxpayer filing the claim (include copies of any available substantiating documentation or evidence);

    5. The dollar amount of the claim, including any damages that have not yet been incurred but which are reasonably foreseeable (include copies of any available documentation or evidence); and

    6. The signature of the taxpayer or duly authorized representative.


### Note:

Administrative costs, as defined in Treas. Reg. 301.7433-1(b)(2)(ii), Administrative costs, including attorneys’ fees, are not recoverable as actual, direct economic damages, but these costs may be recoverable under IRC 7430, Awarding of Costs and Certain Fees. See criteria in Treas. Reg. 301.7430-8, _Administrative costs incurred in damage action for violations of section 362 and 524 of the Bankruptcy Code_.

### Note:

Pro se debtors may not claim attorney's fees.

09. **Evaluating Claims**. The IRS evaluates all claim applications for damages and attorneys' fees arising from willful violations of the automatic stay (11 USC 362, Automatic stay) or the discharge injunction (11 USC 524, Effect of discharge). Claims must be evaluated within ten work days from the date of the claim's receipt by the IRS. Insolvency must review the claim to determine:



    1. The completeness of information provided;

    2. Evidence the IRS actions were willful; and

    3. Damages and attorneys' fees are reasonable and adequately substantiated. (Guidance from Counsel may be required.)


10. **Incomplete Claims**. Incomplete claims must be returned to the claimant with a letter of explanation identifying the incomplete items. See _Exhibit 1.4.51-2_, Pattern Letter for Incomplete Claim for Damages and/or Attorney’s Fees.

11. **Non-Willful Violations**. When Insolvency determines a willful violation of the automatic stay or discharge injunction did not occur, processing of the claim must halt. Insolvency must promptly forward its recommendation for rejection to Counsel.



    ### Note:



    Claims for violations are generally rejected when the claimant has not established actual damages or attorney's fees.

12. **Delegated Authorities**. Delegation Order 25-10 found in IRM 1.2.2.15.10 Delegation Order 25-10 (formerly DO-254), Payment of Claims for Damages and Attorneys’ Fees Resulting from Violations of the Automatic Stay and Discharge Injunctions of the Bankruptcy Code, outlines approval authorities based on dollar amounts.

13. **Referral to Counsel**. Any claim for more than $1,000 must be referred to Counsel for a legal opinion prior to its final disposition. A claim for any dollar amount that has been denied in part or in whole must be referred to Counsel for a legal opinion.

14. **Denied Claims**. If payment of a claim is denied wholly or partially by Insolvency, the rejecting office must prepare a rejection recommendation stating the reasons for the rejection and refer the claim application to Counsel. If Counsel renders an opinion contrary to the rejection recommendation, only a Territory / Operation Manager has the authority to disregard the Counsel opinion.

15. **Written Notification**. Upon receipt and evaluation of a complete application, Insolvency must send the claimant a written response within 60 calendar days of the receipt date stating the claim has been either rejected or accepted. See _Exhibit 1.4.51-3_, Pattern Letter for Approval of a Claim for Damages and/or Attorney’s Fees, and _Exhibit 1.4.51-4_, Pattern Letter for Denial of a Claim for Damages and/or Attorney’s Fees, for the applicable pattern letters.

16. **Civil Damages**. If a taxpayer's administrative damage claim is disallowed by Insolvency, or six months pass without a decision by the IRS or Insolvency, the taxpayer may file a civil action for the damages as provided for in IRC 7433, Civil Damages for Certain Unauthorized Collection Actions. If the debtor is an individual, the debtor may also request damages for violations of the bankruptcy automatic stay, whether or not an administrative claim has been filed.



    1. The maximum damage award for reckless and intentional disregard of the code is $1 million.

    2. Negligent disregard carries a maximum award of $100,000.


17. **Payment of Administrative Claims**. When the claim application for administrative damages and/or attorney's fees is approved in whole or in part, Insolvency must follow the procedures set forth in IRM 25.3.3.9.4, Reimbursement of Damages and Costs. Pattern letters applying specifically to Insolvency must be substituted. (See paragraph 15 above.)

18. **Payment of Litigative Claims**. Procedures in IRM 25.3.3.9.4, Reimbursement of Damages and Cost, should be followed when the claim application is for litigative damages and/or attorney's fees with the exception of the forms to be used. For litigative award funding refer to the Bureau of the Fiscal Service (BFS) forms, which should be used:



    - [BFS FS Form 194, Judgment Fund Transmittal](https://fiscal.treasury.gov/files/judgment-fund/form-194.pdf)

    - [BFS FS Form 196, Judgment Fund Award Data Sheet](https://fiscal.treasury.gov/files/judgment-fund/form-196.pdf)

    - [BFS FS Form 197, Judgment Fund Voucher for Payment](https://fiscal.treasury.gov/files/judgment-fund/form-197.pdf)


### Note:

More information can be found at the BFS website: [https://fiscal.treasury.gov/judgment-fund/forms.html](https://fiscal.treasury.gov/judgment-fund/forms.html).

19. **Separate Payment Requests for Damages and Attorney's Fees**. When both payment of damages and attorney's fees have been authorized, Insolvency must request funding separately. For example if BFS FS Forms 196 and 197 are used for the damages award, then BFS FS Forms 196 and 197 must be used for payment of attorney's fees.

20. **Documentation**. The AIS history must include detailed information on all aspects of claims for damages and/or attorney's fees including the items listed in the table below:




    | History items that must be addressed in the AIS case history: |
    | --- |
    | The date the claim was received by the IRS; |
    | A summary of the issues cited in the claim; |
    | The dollar amount being sought broken down by damages and attorney's fees; |
    | A listing of documentation received by from the claimant; |
    | Results of the review for claim application completeness; |
    | Dates of correspondence sent to the claimant along with a summary of the correspondence's content |
    | Names of management officials involved in approving/denying the claims along with the dates of their involvement; |
    | Date referral sent to Counsel; |
    | A summary of Counsel's opinion(s); |
    | Delegated authority's final determination to approve or deny the claim; |
    | The dollar amount(s) to be paid broken down by damages and attorney's fees if claim approved; |
    | Date appropriate forms are prepared and forwarded to BFS for funding if claim approved; |
    | Date denial letter sent to claimant if claim denied; |
    | Date check mailed to claimant if direct deposit not requested; |
    | Claimant's response if received; and |
    | Any other information relevant to the claim application and review process. |





    ### Note:



    In addition, paper or electronic files of all forms and correspondence pertaining to the claim must be retained until the possibility of litigation expires. For partially or wholly denied claims, this is two years from the date of the violation.


**1.4.51.4** **(02-12-2020)**

### Employee Development / Training

1. See IRM 1.4.1.6, Employee Development, for a full discussion of managerial responsibilities.

2. Group Manager roles and responsibilities in the area of employee development and training include but are not limited to:



1. Overseeing orientation of new employees

2. Overseeing training for new employees (formal and on-the-job)

3. Training and developing other employees including professional/technical and clerical staff

4. Assisting and advising employees preparing a Career Learning Plan (CLP), if desired by the employee. For obtaining additional information, please visit Career Learning Plan (CLP)

5. Delegating acting managerial assignments

6. Continuing education for employees to maintain and update knowledge and proficiency in technical areas

7. Providing opportunities such as details to facilitate career development

8. Ensuring employees have a working knowledge of tools to perform their duties, (e.g., AIS, ATFR, Automated Lien System (ALS), etc.)


3. More information can be found at the Human Capital Office website



   - Servicewide Training and Briefing Programs

   - Policy and Procedural Guidance

   - Other related training resource sites, the IRS Learning Center, etc.


4. For BU employees, also see Document 11678, National Agreement - IRS/NTEU, (Articles 7, Personnel Records, 12, Performance Appraisal System, 16, Details and Non-Competitive Temporary Promotions, and 30, Training) or contact a Human Resources Specialist.

5. Resources:



   - IRM 1.4.1.6, Employee Development

   - Integrated Talent Management

   - Human Capital Office


**1.4.51.5** **(02-12-2020)**

### Performance Management

1. The three balanced measures are: Employee Satisfaction, Customer Satisfaction, and Business Results. These three balanced measures are part of every individual and organizational performance evaluation system within the IRS.

2. IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs), contains detailed guidance about evaluating performance. Refer to that IRM as well as the information following when evaluating performance.


**1.4.51.5.1** **(02-12-2020)**

#### Performance Evaluations

01. Preparing performance evaluations is one of a manager’s most important responsibilities. In carrying out this task, the manager will observe how the employees are performing their duties and responsibilities to ensure that they are working efficiently and effectively to accomplish assigned tasks.

02. Because managers are responsible for implementing the policies and directives relative to performance evaluations, they should thoroughly familiarize themselves with all facets of performance appraisal/evaluation information including, but not limited to:



    1. Performance expectations

    2. Mid-year and periodic performance reviews

    3. Annual ratings

    4. Acceptable level of competence

    5. Unacceptable/ minimally successful performance

    6. Competitive promotion appraisals

    7. Employee performance folders (EPF)

    8. Performance and recognition awards


03. A formal performance evaluation serves:



    1. As a record of performance to support, recommend and initiate actions such as within-grade increases, promotions, award recommendations, reassignments, details, and adverse actions such as demotion or separation.

    2. To provide an employee with a basis for additional training and development.

    3. As a tool to improve the performance of individual employees.


04. For employees new to the government, the first year of employment is a probationary period during which the employee must demonstrate successful performance and the capability to be promoted to the next grade level (if applicable). See IRM 6.430.2.4.3, Employees Serving Probationary Periods.

05. Work closely with employees who are performing poorly, including probationary employees. Provide them with guidance/direction designed to assist them in improving performance. If performance improves, document the improvement accordingly. If performance fails to improve, refer to IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs), and seek appropriate advice to determine next steps.

06. Documentation of performance:



    1. Providing feedback to the employee (positive and constructive) is essential to maintaining and/or improving their performance.

    2. Keep an employee's overall performance in mind when discussing work and other activities. Let them know when some aspect of performance may influence their performance rating, a promotional opportunity or other personnel action.

    3. Recordation serves as a snapshot of employee performance. Adequate documentation will be a reminder of changes in performance over the rating period.


### Reminder:

Notify employees of decreased work performance per guidance in IRM 6.430.2.3.3, Acknowledging Decreased Work Performance.

07. When writing review narratives be concise, but descriptive enough to provide an accurate picture of the strengths, developmental needs, and accomplishments of the employee in each CJE. (See IRM 6.430.2.4.6, Completing Appraisal Narratives.)

08. Performance evaluations provide a uniform means for a written evaluation and rating of each employee's proficiency.



    - IRM 1.5, Managing Statistics in a Balanced Measurement System, describes how balanced measures are used to support individual as well as organizational performance. The three balanced measures are: Employee Satisfaction, Customer Satisfaction and Business Results. These three balanced measures are part of every individual and organizational performance evaluation system within the IRS.

    - IRM 1.5.2, Use of IRC 1204 Statistics, provides specific guidance for SB/SE use of measures. This IRM provides information about the prohibition on the use of records of tax enforcement results (ROTERs) to evaluate employees or to impose or suggest production quotas or goals.


09. Formal employee evaluations represent the sum of what managers have observed in each employee's work, using feedback, reviews, field visitations, and other techniques discussed in this manual. Consider the following when evaluating performance for an annual appraisal:



    - Position description

    - Critical Job Elements (CJEs)

    - Mid-year and other progress reviews

    - Employee’s work products (management briefings, memos)

    - Employee’s self-assessment

    - Feedback from taxpayers and other customers

    - Team assignments and contributions to work group

    - Special Achievements


10. Each employee will receive an annual performance evaluation. See information about Performance Appraisal Due Dates in the National Agreement - IRS/NTEU, Article 12, Exhibit 12-1.



    ### Note:



    A sample Annual/Mid-year Review Schedule has been provided in _Exhibit 1.4.51-5_, Sample Annual/Mid year Review Schedule. Managers can tailor this sample to the criteria for their group to ensure appraisals are completed timely.

11. Employees may submit a self-assessment, limited to four (4) pages in length, no later than the last workday of their annual appraisal rating period. See IRM 6.430.2.4.5, Self-Assessment, and IRM 6.430.2.6, Conducting the Performance Appraisal Meeting.

12. Use only the work requirements of the particular position or specific work standards established by the IRS to make Acceptable Level of Competence Determinations (i.e. determination that employee is performing at a fully successful level.)

13. For information on the suggested steps to make unacceptable performance determinations see _Exhibit 1.4.51-1_, Suggested Action Steps for Unacceptable Performance.

14. Resources:



    - Human Capital Office (HCO). This website houses the CJE Resource Center, Manager Guide for Employee Performance Awards information, forms, etc.

    - Document 11678, National Agreement - IRS/NTEU, Articles 7, Personnel Records, 12, Performance Appraisal System, 17, Acceptable Level of Competence Determinations, 18, Awards, and 40, Unacceptable Performance

    - IRM 1.4.1, Management Roles and Responsibilities

    - IRM 6.430.2.3.3, Acknowledging Decreased Work Performance

    - IRM 6.432.1, Addressing Poor Performance

    - IRM 6.451, Employee Performance and Utilization

    - Other portions of IRM, Part 6, Human Resources Management

    - The assigned Labor Relations specialist


**1.4.51.5.2** **(02-04-2025)**

#### Reviews (Overview)

1. Providing ongoing employee feedback that is candid and meaningful is essential to employee satisfaction and is an integral part of the group manager’s responsibilities. Reviews of employee work should serve to:



1. Assess the employee’s effectiveness in meeting the expectations established in their Critical Job Elements.

2. Determine the employee’s efficiency in carrying out the laws, procedures, and policies of the IRS.

3. Identify and address performance problems.

4. Evaluate the employee's ability to properly plan and schedule field, office, and Telework activity.

5. Ensure the employee is taking timely and appropriate actions to bring the case to a prompt and proper resolution.

6. Assess employee effectiveness in developmental case assignments.

7. Determine the employee's effectiveness in meeting the IRS Retention Standard for the Fair and Equitable Treatment of Taxpayers. Careful review of cases should occur in order to provide a quality product and excellent taxpayer customer service.

8. Ensure taxpayers’ rights are observed. See _IRM 1.4.51.3.2_ above.


2. All reviews relating to an employee's case work must be in writing. Managers must use EQRS to review individual cases, but other types of performance observation lend themselves to other methods. For reviews that consider employee activity across multiple cases (e.g., time utilization, office/field observation) a summary narrative, such as a memorandum, may be substituted. The EQRS Individual Feedback Report provides a record of ratings and the narrative comments in which the employee’s performance is summarized. Become familiar with Document 12656, Field Insolvency Embedded Quality Job Aid and Campus Quality Master Attribute Job Aid (MAJA), which provides specific guidance related to Embedded Quality attributes and how to use them.

3. At the beginning of the fiscal year, group managers will develop a review schedule for the group that includes all mandatory reviews and optional reviews. Optional reviews may include additional office or field visitations, time and workload reviews, etc. The review schedule should provide for a fair and accurate assessment of the employee's overall performance throughout the rating period.

4. Mandatory reviews represent the minimum review requirements that must be completed for each employee. It is intended that the minimum requirements will provide managers with an opportunity to spend more time reviewing and developing employees that need additional feedback and assistance. Mandatory reviews include:



1. One or more annual field visitations or observation at a 341 hearing, whenever applicable and possible.

2. One or more time utilization reviews with each employee.

3. Mid-Year appraisals/reviews. The mid-year appraisal should occur at the midpoint (six-months) of the employee's appraisal period.

4. Annual performance case reviews. See _IRM 1.4.51.5.2.2_, Requirements for Annual Performance Case Reviews.


5. When necessary, based on case reviews, other forms of review, field or office observation, etc., managers have the authority to require their employees to obtain their approval before taking subsequent case actions.



### Example:



Employees who inappropriately extend deadlines or delay case actions can be required to obtain managerial approval of their extensions in the future so as not to delay timely case resolution.

6. Group managers will continually review information gathering activities by their employees.

7. For additional guidance on preparing reviews, narratives and appraisals see:



   - IRM 1.4.1.8, Evaluation Performance

   - IRM 5.1.3.7.1, Information Gathering Guidelines

   - IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CLEs)


**1.4.51.5.2.1** **(02-04-2025)**

##### Case Reviews

01. Choose a sufficient number of cases for review to ensure a thorough evaluation of each employee’s performance. The Specialty Collection - Insolvency Director will provide guidance on the number of minimum yearly case reviews. Reviews should be tailored to individual needs. Managers should increase the number of case reviews when an employees performance declines. Scheduling of the analysis may be announced or unannounced at the option of local management. (Article 12, Section 4.L)



    ### Note:



    See _IRM 1.4.51.5.2.2_, Requirements for Annual Performance Case Reviews.

02. Ensure case selection contains a mix of cases representative of the employees assigned inventory.

03. Work submitted for approval or closure also provides an opportunity to evaluate individual performance as well as the overall quality of the group's product. When reviewing cases submitted for approval or closure, look for performance that reflects an employee's adherence to IRM standards as well as other established policies and procedures.



    ### Caution:



    Confine written reviews to work performed during the employees rating period.

04. Use the Embedded Quality Review System (EQRS) for individual case reviews. The review items on the EQRS Individual Feedback Report correspond with the performance standards of an employee’s critical job elements. In general, deficiencies relating to a critical job element should be noted as an area of special concern if found in 25% or more of the cases reviewed. There may be instances where a single deficiency (e.g., expired statute) is critical. The attribute narrative should summarize the employee's performance for each individual case reviewed.

05. Managers must also summarize the employee's overall performance on all cases reviewed, including the results of time utilization reviews, field/office visitations, etc., as part of the mid-year and/or annual performance assessment. Narrative feedback should address positive aspects, as well as areas for improvement, of an employee's performance. See _Exhibit 1.4.51-6_, Insolvency Group Manager’s EQRS Review Document, Form 6850 BU, and Narrative, General Guide.

06. As part of the case review, prepare the EQRS Individual Feedback Report in duplicate and include all applicable case data. Both the manager and the employee must sign it. Give the original Individual Feedback Report to the employee for action on case recommendations. Retain the duplicate in the EPF for follow-up. Discuss all recommended actions entered on the Individual Feedback Report with the employee to ensure that there is a complete understanding regarding the observations and direction.

07. If managers have directed specific case actions, a follow-up review should be scheduled 60-90 days after the initial review to ensure their instructions are being followed and the case is moving toward resolution. If the actions are time sensitive, a shorter follow-up review may be warranted. The follow-up review will generally be limited to the cases in which a follow-up review has been scheduled unless there is need to see other cases to document a performance trend. Using EQRS, prepare a narrative conveying the results of the follow-up review.

08. Written performance feedback (Individual Feedback Report, 6067, memorandum, etc.) must be provided to the employee within 15 work days. The 15 day time frame starts from the time the supervisor becomes aware of, or should have been aware of, the event addressed in the recordation/feedback item. If the review is not shared with the employee within the 15 work day period, the review must not be used for any evaluative purpose. You may be required to perform a review of another case in order to meet the minimum number of required cases reviews. Also, the data collection instruments for reviews not shared with the employee within the 15 work day requirement must also be deleted from the EQRS system.

09. Although managers may suggest or request specific actions in the case history, they should avoid making numerous case decisions for the employee. Documentation of an evaluative nature should not be entered in the case history.

10. As part of any case review, determine if the assigned grade level is still accurate. See _IRM 1.4.51.9.1_, Case Assignment Guide.

11. It is important to ensure that employees comply with guidelines about direct contact with taxpayers with representatives. During case reviews ensure that taxpayer rights have been observed, particularly with respect to direct contact provisions. See IRM 5.1.23.4.2.3, Written Communication to a Taxpayer’s Representative, and IRM 5.1.23.6, By-Passing a Taxpayer's Representative.

12. Resources:



    - Embedded Quality Review System (EQRS)

    - Critical Job Elements (CJE)

    - IRM 5.13.1, Embedded Quality Collection Field Organizations Administrative Guidelines

    - IRM 6.430.2.4.9, Rating CJEs

    - IRM 21.10.1, Quality Assurance - Embedded Quality (EQ) Program for Accounts Management, Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support.


**1.4.51.5.2.2** **(02-12-2020)**

##### Requirements for Annual Performance Case Reviews

1. Select a sufficient number of cases for review that meet the criteria in _IRM 1.4.51.5.2.1_, Case Reviews. Review at least half of the cases prior to the mid-year progress review.

2. Review plans should be tailored to fit the needs of individual employees.

3. Use EQRS attributes, case summary narratives, and performance summaries for all reviews conducted during the rating period to create performance feedback. Feedback must indicate to the employee how they are meeting or not meeting the EQRS attributes and aspects of the critical job elements.

4. Provide the employee with the narrative within 15 work days and place a copy of the document in the EPF.


**1.4.51.5.2.3** **(02-12-2020)**

##### Field and Office Observations

1. Observing the employee during face-to-face contacts, either at 341 hearings or office meetings, provides an excellent opportunity for the manager to assess an employee’s:



1. Ability to conduct interviews.

2. Ability to communicate and interact with taxpayers.

3. Knowledge of policies and procedures, including observance of taxpayer’s rights listed in _IRM 1.4.51.3.2_, Protecting Taxpayer Rights, above.

4. Ability to deliver fair and courteous treatment to all taxpayers.


2. Conduct one or more annual field visitations, 341 observations, or office observations with each employee, whenever applicable and possible.

3. During observations, managers will evaluate the employee for:



01. Ability to secure material information necessary to determine appropriate case direction.

02. Delivery of fair and courteous treatment of taxpayers.

03. Ability to address the various rights of the taxpayer (Pub 1, Your Rights as a Taxpayer, Pub 594, The IRS Collection Process, IRC 6320, Notice and opportunity for hearing upon filing of notice of lien, IRC 6330, Notice and opportunity for hearing before levy, and Collection Appeals Program).

04. Ability to recognize and respond to taxpayer concerns, issues and interests.

05. Pre-contact preparation including appropriate questions at the 341 hearing.

06. Itinerary planning.

07. Effective use of time.

08. Ability to manage difficult, unexpected, complex or unusual circumstances.

09. Ability to appropriately recognize and address "Third Party Contact" situations.

10. Observation of proper disclosure requirements.


4. Provide feedback based on all observations using a summary narrative, such as a memorandum.

5. Resources:



   - CJE Resource Center

   - IRM 5.1.1.12, Third Party Contacts

   - IRM 25.27.1, Third Party Contact Program



     ### Note:



     Refer to IRM 25.27.1, Third-Party Contacts, for general servicewide guidance on third party contacts. Refer to IRM 5.1.1.12, Third Party Contact, for third party contact information specific to Collection casework.

   - IRM 6.430.2.2.1, Retention Standard for the Fair and Equitable Treatment of Taxpayer

   - IRM 11.3.1, Introduction to Disclosure


**1.4.51.5.2.4** **(06-25-2025)**

##### Time Utilization Reviews

1. Conduct one or more Time Utilization Review annually with each employee. Use the Time Utilization Review to measure the overall effectiveness of the employee's office, field, and/or Telework. Make observations regarding work quality as appropriate, but the purpose of this review is to evaluate employee performance in effective use of time and accuracy of documentation.

2. Conduct the Time Utilization Review within fifteen (15) workdays of the day selected.

3. Time Utilization Reviews should be unannounced. Document the review with a memorandum or Form 6067, Employee Performance Folder Record, to summarize the observations.

4. During the Time Utilization Review consider the following factors:



   - Evaluate whether time spent on case actions matches the time charged as well as the nature and complexity of what is required in each case.

   - Evaluate whether the case actions taken are likely to move the case toward resolution.

   - Identify unproductive/inefficient activity and make recommendations for improvement.


5. Documents should be shared with the employee and maintained as part of the EPF to be used in preparation of the Mid-Year/Annual Appraisal.


**1.4.51.5.2.5** **(02-04-2025)**

##### Work Submitted for Approval/Closure

1. When work is submitted for approval, managers have an opportunity to evaluate an employees' performance. This also enables the manager to prevent deficiencies. Check for accuracy and level of quality before approving reports of currently not collectible taxes, discharge determinations, collection determination from exempt, abandoned or excluded property (EAEP), no liability determinations requests for adjustment, seizure documents, TFRP investigations and recommendations, fraud referrals, and any other document prior to submission to another function. The quality of the work that leaves a manager’s group is a reflection on the group manager.


**1.4.51.5.2.6** **(02-04-2025)**

##### After Hours Review

1. An after hours review allow managers to determine whether documents, property, and monies are being adequately protected when not in the custody of authorized IRS personnel. Managers can accomplish this by being the last to leave a work area and checking the area after the close of the business day. Managers could also accomplish after hours reviews by periodically arriving early to work ahead of the staff to review the work space for compliance. (See IRM 10.5.1.5.1, Clean Desk Policy.

2. Managers periodically must review functional areas after hours to determine if sensitive but unclassified (SBU) date, including Personally Identifiable Information (PII) and tax information, is appropriately containerized and properly disposed. This includes PII left in printing trays. Also check to see whether cabinets, safes, and other containers are appropriately secured. Limited areas, secure areas, and office doors are to be secured and verified as well. If weaknesses are identified, managers must take immediate action to safeguard information, property, or rooms/facility, counsel employees as appropriate, and/or request assistance from appropriate local Facilities Management & Security Services (FMSS) Physical Security staff in developing corrective measures.

3. The after hours review may be completed by a designee (e.g. the Commissioner’s Representative) of the group manager in posts of duty where the manager is not in the same location with the employee.

4. If your reviews reflect that employees repeatedly fail to observe security protocols, contact your Labor Relations specialist to determine the next appropriate action.


**1.4.51.5.3** **(11-17-2022)**

#### Use of Statistical Data / Section 1204 / ROTERs

1. Section 1204 of the IRS Restructuring and Reform Act of 1998 (RRA 98) prohibits the use of Records of Tax Enforcement Results (ROTERs) to evaluate employees or to impose/suggest production quotas/goals for any employee.

2. IRM 1.5.1, The IRS Balanced Performance Measurement System, provides guidance to prevent the use of statistics to:



1. Evaluate employees, or

2. Impose or suggest production quotas or goals with respect to such employees.


3. ROTERs are data, statistics, compilations of information or other numerical or quantitative recordations of the tax enforcement results reached in one or more cases. Managers are prohibited from using records of tax enforcement results to evaluate any employee who exercises judgment with regard to determining tax liability or ability to pay. This prohibition includes:



   - Required or requested performance ratings (annual, mid-year, ad hoc)

   - Self-assessments

   - Award recommendations

   - Assessment of an employee's qualifications for promotion, reassignment, or other change in duties

   - Assessment of an employee's eligibility for incentives, allowances or bonuses

   - Ranking for release/recall and reduction in force


### Note:

ROTERs**do not include** tax enforcement results of individual cases when used to determine whether an employee exercised appropriate judgment in pursuing enforcement of the tax laws based upon a review of the employee’s work on that individual case.

4. Managers are also prohibited from using ROTERs to impose or suggest production goals or quotas for employees or groups of employees. Examples of prohibited ROTERs include:



   - Number of Proofs of Claim filed

   - Number of delinquent returns secured

   - Number of delinquent returns secured with full payment

   - Number of seizures made

   - Number of levies issued


5. Resources:



   - IRM 1.5.1, The IRS Balanced Performance Measurement System

   - IRM 1.5.2, Uses of Section 1204 Statistics

   - IRM 1.5.3.4, Section 1204 Quarterly Certification Requirements

   - Section 1204 and 1204 Documentation Tool


**1.4.51.5.3.1** **(02-12-2020)**

##### Tax Enforcement Results (TERs)

1. A tax enforcement result (TER) is the outcome produced by an IRS employee's exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of tax laws.

2. TERs may be discussed in employee reviews (but not employee evaluations) to determine if the employee exercised appropriate judgment, used time efficiently and applied the laws in one or more cases properly. See IRM 1.5.2.10.1, Permitted Use of TERs.


**1.4.51.5.3.2** **(02-12-2020)**

##### Regulation 801 / Quantity & Quality Measures

1. Regulation 801, Balanced System for Measuring Organizational and Employee Performance with IRS, implements the provisions of Section 1204 of the IRS Restructuring and Reform Act of 1998 (RRA 98), provides rules relating to the establishment of a balanced performance measurement system and sets forth rules governing the use of ROTERs.

2. Quantity measures consist of outcome-neutral production and resource data that do not contain information regarding the tax enforcement result (TER) reached in any case involving particular taxpayers. Examples of quantity measures include, but are not limited to:



   - Cases started

   - Cases closed

   - Time per case


3. Performance measures based in whole or in part on quantity measures will not be used to evaluate the performance of any non-supervisory employee who is responsible for exercising judgment with respect to tax enforcement results.

4. The quality review of the handling of collection cases focuses on such factors as whether employees devoted an appropriate amount of time to a matter, properly analyzed the facts, complied with statutory, regulatory, and IRS procedures, etc.

5. Resources:



   - IRM 1.5.2.12, Quantity Measures

   - IRM 1.5.2.13, Quality Measures


**1.4.51.5.4** **(02-12-2020)**

#### Retention Standard

1. Regulation 801 provides that, in addition to all other criteria required to be used in the evaluation of employee performance, all employees of the IRS will be evaluated on whether they provided fair and equitable treatment to taxpayers.

2. Form 6774, Receipt of Critical Job Elements and Retention Standard, is maintained in the EPF.

3. Resources:



   - IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRM 6.430.2.4.7, Rating Performance Against The Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - Documenting Employee Performance


**1.4.51.5.5** **(02-12-2020)**

#### Within Grade Increase

1. An employee shall be advanced in pay to the next higher step of their grade upon meeting the following requirements:



1. Required waiting period completed;

2. No equivalent increase in pay received during the required waiting period; and

3. Fully successful performance in each of the critical job elements of their position.


2. Use only the work requirements of the particular position or specific work standards established by the IRS to make Acceptable Level of Competence Determinations (i.e. determination that employee is performing at a fully successful level.).



### Reminder:



See IRM 6.430.2.5.4, Within Grade Increase (WGI) Determination.

3. For information on steps to follow when an employee is not meeting an acceptable level of competence, _Exhibit 1.4.51-7_, Action Steps for Acceptable Level of Competence Determination if an Employee Within Grade Increase (WGI) is Due.


**1.4.51.5.6** **(02-12-2020)**

#### Evaluation Due Dates

1. Each employee will receive an annual performance evaluation. The due date of an evaluation for any particular employee is based upon the last digit of the employee’s Social Security Number (SSN). Refer to Document 11678, National Agreement - IRS/NTEU, Article 12, Exhibit 12-1, Performance Appraisal Due Dates SSNs Aligned To Monthly Periods.


**1.4.51.5.7** **(02-12-2020)**

#### Discipline/Disciplinary Actions

1. Discipline is defined as measures taken by management that are intended to correct employee misconduct, and encourage employee conduct in compliance with the standards of conduct, policies, goals, work procedures, and office practices of the IRS and the Federal Service. Employees must adhere to all known conditions and standards of conduct established to provide for the orderly and efficient administration of the IRS.

2. Employees who fail to comply with standards of conduct, work procedures, and office practices will be subject to disciplinary action designed to correct the violation and motivate the employee to become a productive member of the IRS.

3. Managers are responsible for establishing and maintaining effective discipline within their work group. Managers must explain the work requirements and other standards employees are expected to meet.

4. When disciplinary action is required, it must be fair, equitable, impartial, and as timely as possible.

5. A guide to assist managers in determining appropriate penalties to correct improper conduct can be found in IRM 6.751.1-1, IRS Guide To Penalty Determinations..

6. Ensure to discuss and coordinate all proposed disciplinary actions with a Labor Relations Specialist.

7. Resources:



   - IRM 6.751, Discipline and Disciplinary Actions

   - IRM 6.752, Disciplinary Suspensions and Adverse Actions

   - Document 11678, National Agreement-IRS/NTEU, Articles 38, Disciplinary Actions, and 39, Adverse Actions


**1.4.51.6** **(02-04-2025)**

### Telework

1. Telework is a program that permits employees to work at home or at other approved locations other than the assigned post of duty.

2. There are three (3) forms of Telework:



1. Frequent

2. Recurring

3. Ad Hoc


3. See Document 11678, National Agreement - IRS/NTEU, Article 50, Section 1.B, Types of Telework, for more information about the types of Telework visit the IRS Telework Program.


**1.4.51.6.1** **(02-12-2020)**

#### Managing Telework

1. Managing an employee participating in Telework is essentially no different than managing an employee in the office. Managers should ensure that their actions are in compliance with the National Agreement - IRS/NTEU. The employee on Telework is still held accountable for the Rules of Conduct, Critical Job Elements, Time and Attendance, Ethics, and all other regulations applicable to their position.



### Note:



Per Article 50, Section 1.F of the National Agreement - IRS/NTEU: Telework is not a replacement for dependent/family care.

2. Managers should ensure that employees are responsive to all customers. Employees must check voice mail (VMS) and email (when accessible) to ensure external as well as internal customers (including managers) receive responses timely. It is appropriate for an employee to check their VMS and email prior to going to lunch and some time prior to ending their day. Employees supplied with pagers and cell phones should be expected to be more responsive.

3. Managers have the right to direct a Telework employee to report to the office when necessary. For example, when having meetings, which include group meetings, case reviews, training, etc. This should be planned so that the employee has ample time to report to the office during their regular commute time. When an employee plans or decides to make field calls during a Telework day the manager should be informed. This is referenced under Article 50, Section 5.A.2 of the National Agreement - IRS/NTEU.

4. Article 50 of the National Agreement - IRS/NTEU addresses Telework issues. Sections pertinent to the management of employees in a Telework environment are listed below:



1. A supervisor’s official relationship with, authority over, and accountability for an employee participating in the IRS’ Telework Program is no different than their relationship with, authority over, and accountability for employees who are not participating in the Telework Program. Consistent with the provision of this Article, the supervisor retains the authority to review, determine, and approve participation in this program. (Article 50, Section 1.A.5).

2. Employees may telework more than 80 hours each month if they have elected to participate in Frequent Telework. (Article 50, Section 1.B.1). Employees approved for a Frequent Telework arrangement will be provided equipment consistent with Article 50, Section 7.B.

3. Employees approved for a Recurring Telework arrangement may work at the approved telework site for 80 hours or less per month (Article 50, Section 1.B.2).

4. Employees may participate in an "Ad Hoc" Telework Program. This allows the employee with nonrecurring projects or work assignments to work at a Telework site, subject to approval by their supervisor. (Article 50, Section 1.B.3).

5. Participants may be permitted to work at home or other Telework work sites full days or a portion of a day.



      ### Reminder:



      Unless as otherwise provided by Article 50, Section 1.C of the National Agreement - IRS/NTEU: there is no limitation on how the work schedule may be configured as long as the scheduling is not disruptive to the work that remains in the office or cause an unreasonable burden on those who choose not to work a Telework arrangement.

6. Management has the right to meet with employees to give assignments and to review work as necessary at either the official duty station, approved Telework location, or a mutually agreed upon site. (Article 50, Section 4.C.) This does not mean that 24 hour notification or union presence is required, but 24 hour notification is suggested.

7. Employees must provide the supervisor and/or clerk in advance with all the specific information regarding their work schedule, type of work to be performed and location of the alternate work place. This includes the obligation to inform the supervisor when they are unable to perform work due to illness or other circumstances during the Telework tour of duty (TOD) and requesting appropriate leave. (Article 50, Section 5.A.1.)

8. Employees must call the office to report time, to retrieve messages, and to notify the supervisor and/or clerk of changes in work locations. (Article 50, Section 5.A.)

9. In order to ensure accountability, a participating employee and the supervisor must communicate at least one time during each pay period to verify the employee’s time and attendance. (Article 50, Section 6.F.)


5. If it is determined that an employee's work appears to be degrading from "Fully Successful" or is below a "Fully Successful" rating, managers should review Article 50, Section 2, Eligibility, of the National Agreement - IRS/NTEU to determine whether the employee's continuation on Telework is appropriate. This occurs when any Critical Job Element (CJE) rating equals "2" or below.



### Note:



When considering removing an employee from Telework, ensure that the reasons for removal are well documented. This documentation may include but is not limited to EQRS Individual and/or Cumulative Feedback Reports, Form 6850-BU, or memoranda. Managers must ensure that the employee is aware of the situation and should then monitor the employees work product closely and develop a plan for improving that employee’s work, just as would be done for an employee not on Telework. There is no prohibition per the National Agreement - IRS/NTEU on any type of performance review following a period in which an employee has worked at their Telework site. Reviews may include "Time Utilization" , "Time and Activity" , or other performance based review. Ensure this also conforms with any applicable local Area agreement as well. The types and amount of time expended on Telework should be comparable to time in the office. For example, there should not be increased amounts of administrative or miscellaneous time, or increased time charged to cases with minimal actions taken.

6. Resources:



   - IRM 6.800.2, IRS Telework Program

   - The IRS Telework Program website.


**1.4.51.6.2** **(02-12-2020)**

#### Interaction With Employees On Telework

1. A manager’s official relationship with, authority over, and accountability for an employee participating in the IRS’ Telework Program is no different than that for employees who are not participating in the program.

2. Manager responsibilities include:



1. Meeting with employees at least once a year for the purpose of discussing, reviewing, and updating the Telework Agreement, if needed.

2. Directing Telework employees to report to the office due to special circumstances.

3. Meeting with employees to give assignments and review their work as necessary at the official duty station, approved work site that includes their home, or mutually agreed upon site.

4. Inspecting the employee's work site when appropriate. Managers may visit the Telework site, with twenty four (24) hours notice, to ensure privacy considerations are in place to safeguard SBU data, including PII and tax information within a telework environment. Refer to IRM 10.5.1.6.12, Telework.



      ### Reminder:



      Work site inspections are not expected to be routinely conducted. Inspect as necessary to verify Information Systems (IS) and privacy requirements are in place.

5. As with all employees, be proactive in identifying opportunities to rate CJE 1, Workplace Interaction/Involvement/Environment.


3. For an employee to remain on the Telework program, they must:



1. Remain "Fully Successful" or above.

2. Not be subject to a conduct investigation in which management has sufficient evidence of serious wrongdoing that would impact the integrity and efficiency of the IRS.

3. Continue to stay in compliance with Article 50, Section 2, Eligibility, of the National Agreement - IRS/NTEU.


### Note:

If any of the above circumstances do not apply, the employee may be suspended from Telework pending resolution of the performance and/or conduct investigation situations. For further information, contact the assigned Labor Relations Specialist. Refer to the National Agreement - IRS/NTEU, Article 50. Coordinate proposed changes to Telework arrangements with a LR specialist.

**1.4.51.7** **(11-17-2022)**

### Recognition and Awards

1. Awards are opportunities for group managers to recognize and reinforce positive performance and behavior.

2. Managers are responsible for maintaining a working knowledge of the awards process.

3. Complete information regarding awards can be found on the Human Capital website at: Awards and Recognition Program

4. Resources:



   - IRM 6.451.1, Policies, Authorities, Categories, and Approvals

   - IRM 1.4.1.8.3, Recognition and Awards

   - Document 11678, National Agreement - IRS/NTEU, Article 18, Awards

   - The Human Resources Specialist


**1.4.51.8** **(02-12-2020)**

### Insolvency Workload Management

1. Managers are responsible for effectively managing the group's workload in order to encourage positive work flow and case movement. To accomplish this they must:



1. Ensure priority cases are worked.

2. Assign cases based on grade and priority level.

3. Balance inventories within the group.

4. Ensure case activity is progressing toward resolution.

5. Initiate methods to improve production, work processes, and/or to increase the quality of the work directed.


2. Managers must monitor key Insolvency processes to minimize the risk of damage claims by ensuring bankruptcy freeze codes are input and released on IDRS timely.

3. Managers should review the number of cases on the Court Closure Follow-Up report needed to monitor inventories identified as "at risk" for backlogs or lack of timely processing. Closure actions on discharged and dismissed cases must be initiated within 30 days of notice. As a part of closing actions, managers must ensure liens are released timely when release is appropriate. IRM 5.9.17.18, Release of Federal Tax Liens, provides procedures for lien releases which may include requests for manual lien release.



### Note:



When collection is being pursued on dischargeable liabilities after case closure, Notices of Federal Tax Lien (NFTL) should not be released.

4. Adherence to the following areas can promote efficiency in the flow of Insolvency work:



   - Educating caseworkers to the range of information available in the AIS database and explanation of the screens and fields AIS Business Objects reports access to format reports

   - Eliminating unnecessary or low value tasks to streamline processing as long as the elimination does not violate IRM requirements

   - Delegating management duties to a Field Insolvency employee whose ratings exceed fully successful (Field Insolvency)

   - Delegating of management duties to team leads (Centralized Insolvency Operation)

   - Identifying potential or actual bottlenecks in workflow

   - Developing contingency plans to prioritize work during predictable seasonal increases in receipts and manual refund processing

   - Accessibility of all cases to the group

   - Respecting assignment of duties by operation established in IRM 5.9 and IRM 1.4.51

   - Elevating system change requests through the management chain up to Collection Policy


**1.4.51.8.1** **(02-12-2020)**

#### Total Inventory Management (TIM)

1. Strive for currency of inventory by encouraging employees to take the right action at the right time on each case.

2. Communicate to employees that it is expected that they work their inventory as a whole.


**1.4.51.8.2** **(02-12-2020)**

#### Using AIS

1. AIS is the primary case management system for Insolvency managers. Managers should familiarize themselves with the AIS Business Objects reports.

2. Use AIS to:



1. Assist employees in managing their inventories.

2. Identify cases with which the employees may need assistance such as listed in IRM 1.4.51.8.3, Case Management Tools.


3. **Assigning Roles**. Roles, that relate to specific permissions, for all AIS activities must be requested using the BEARS system. When submitting the Online BEARS the user should request the appropriate level of access based on their assigned duties. Manager's should review these requests and approve/deny them as necessary. After approval, an email will be sent to the AIS Administrators for the system and if approved the user's information will be added/deleted/updated. A second level AIS Administrator will add the employees SEID into the correct Role Group. At least once per year, managers should review their employees' Role Group on the Employee Information screen on AIS to ensure the correct level of permissions. To access the Employee Information screen from the AIS Main Menu:



1. Under "Support" tab, select "Organization" .

2. Select "Employees" .

3. "Search" the employee to be viewed.

4. Select "Submit Search" .

5. Select "Role Information" tab to assign employee roles.


### Reminder:

It is critical that the AIS profile accounts of employees that leave Insolvency, either through separation or transfer to a new operation, be inactivated immediately. When they are not inactivated quickly, there is potential for new and old case inventory to go un-monitored and un-worked. An AIS Administrator can inactivate the employee’s profile account, when working submitted or systemic Online BEARS entitlement removal request, as soon as the employee’s manager reassigns the employee’s CAG and transfers the employee’s inventory.

**1.4.51.8.3** **(06-25-2025)**

#### Case Management Tools

01. Managers are expected to use tools available to ensure cases in their inventory are handled with professionalism according to both the IRC and bankruptcy laws and rules and with the intent of protecting the rights of the debtor and the interests of the government.

02. The Automated Insolvency System (AIS) Reports are now found within the Business Objects Enterprise (BOE) application. Access to BOE would require a BEARS **add user** request for **Standard User**.

03. Reports are tools for managing inventory. The Director determines which BOE reports are required to be worked, and how often they should be worked by employees. Field Insolvency Report Job Aid and the Automated Insolvency System (AIS) User Guide, list all mandatory and ad hoc reports for FI caseworkers and managers, provide information on access, generating inventory reports and examples of the different types of reports. Both documents are available on the Insolvency Knowledge Management Base.

04. Mandatory FI Reports are core inventory management reports that FI caseworkers and group managers must use to control individual and group inventories. FI caseworkers and group managers are required to generate and work mandatory FI reports in the frequency outlined in IRM 1.4.51.8.3, Case Management Tools. Reports must be retained based on the retention schedule.



    **Mandatory Reports for Managers:**






    | Frequency | FI Manager Reports | Retention Requirement |
    | --- | --- | --- |
    | Bi-Weekly | Bar Date with Expedite Flags Report | Two months |
    | Monthly | - Pending refund report<br>      <br>    - APOC open amends<br>      <br>    - Follow-up report<br>      <br>    - No follow-up report<br>      <br>    - Unpostable report<br>      <br>    - Lien research report<br>      <br>    - Case grade report | One quarter |
    | Quarterly | - Court closure report<br>      <br>    - ASED follow up report<br>      <br>    - LAMS-not found on AIS (chapters 9, 11, 12, 15 and cases referred to CIO)<br>      <br>    - LAMS-closed cases (chapter 9, 11, 12, 13, 15 and cases referred by CIO<br>      <br>    - NMF Listing Report | Six Months |
    | Semi-annual | - NDS CSED follow-up report<br>      <br>    - Lien refile report | One year |
    | Annual | ICS "Employee Case Type" OI inventory report | One year |

05. The following reports will be rolled down to FI Managers from SCI Director’s Staff and/or SCI Technical Analyst. FI Managers will assign the reports listed below to caseworkers to perform the required case actions.




    | **Number** | **Report** |
    | --- | --- |
    | 1 | Unpostable Report |
    | 2 | LAMS Closed Case Listing and LAMS not found on AIS |
    | 3 | BMF Listing Report |

06. AD Hoc FI Reports are commonly used supplemental reports that FI caseworkers and group managers may use to assist in controlling individual and group inventories. Although working core mandatory reports will provide sufficient controls on individual and group inventories, FI Ad Hoc reports are helpful in identifying specific subsets of cases, confirming that specific cases were addressed through the core mandatory reports, and working special projects. There is no IRM prescribed frequency to use AD Hoc FI reports. Specialists and managers may use the reports as needed or based on personal preference. Managers may periodically direct FI caseworkers to generate and work an AD Hoc reports based on specific individual or group inventory needs.




    | **Frequency** | **FI Managers Report** | **Retention Requirement** |
    | --- | --- | --- |
    | No mandatory frequency for Ad Hoc Reports. Managers may use as needed to assist in managing inventory. | - APOC flag<br>      <br>    - LTS reports<br>      <br>    - POC follow-up report<br>      <br>    - Referral to counsel report<br>      <br>    - LAMS post-petition<br>      <br>    - Plan review report<br>      <br>    - Delinquent case report<br>      <br>    - Aged case report<br>      <br>    - Employee history review (used for time utilization review)<br>      <br>    - LT1714 follow-up report<br>      <br>    - OI inventory report<br>      <br>    - Large/Any dollar report<br>      <br>    - Case receipts by court key minus NL cases (used for CAG analysis)<br>      <br>    - Case receipts by alpha split<br>      <br>    - Open inventory report<br>      <br>    - CAG assignment report<br>      <br>    - Inventory receipts by chapter | None |

07. Printing and Working CIO Reports. The CIO Technical Support and Operation Support team is accountable for the following report actions.




    | **Report** | **Action** | **Frequency** |
    | --- | --- | --- |
    | IIP errors report | Generate and work | Daily |
    | IIP status reports | Generate and works all reports for status 22 reports for chapter 11. Status 22 reports for chapter 11 are given to FI for appropriate action. | Daily |
    | Litigation accounts management System (LAMS) Reports | Generate all report for cases in CIO inventory. | Quarterly (or as available) |
    | Potential Invalid TIN (PIT) Report | Generate reports for all chapters, except 9 & 15. Chapter 9 and 15 PIT reports are distributed to FI for necessary action. | Daily |
    | Aged Case Report | Generate and work reports for chapter 7 no asset, chapter 7 asset and chapter 13 cases assigned to CIO inventory. | Annually<br> <br>### Note:<br>PACER match may be used in conjunction with the aged report. |
    | Automated Discharge System (ADS) | Generate | Twice a week |
    | ADS Error Report | Generate and work | Twice a week |
    | Litigation Transcript System (LTS) | Generate | Weekly |

08. In addition to the reports listed above, CIO may work the following reports:




    | **Number** | **Report** |
    | --- | --- |
    | 1 | Court Closure |
    | 2 | Follow-up Report |
    | 3 | Pending Refund Report |
    | 4 | NMF Listing |
    | 5 | Lien Research |
    | 6 | Case Assignment |
    | 7 | Unpostable Report |





    ### Note:



    For additional information about these reports, see Exhibits in IRM 1.4.51, Insolvency.

09. With Territory / Operation Manager's or Department Manager's approval, AIS Business Objects reports may be updated with additional Business Objects reports. To be approved the new reports must serve the purposes of the original AIS Business Objects reports and increase efficiency.

10. As each case on a report is worked, the caseworker should document the AIS history in accordance with IRM 5.9.5.4(2), History Documentation. Each case on a report should be checked off when action has been completed and the history is documented.

11. Minimum retention of completed reports must comply with requirements established in Document 12990, Records and Information Management Records Control Schedules, RCS 32, item 35(B). Consult with Privacy, Governmental Liaison and Disclosure (PGLD) before deviating from the retention standards in Document 12990. Formal Retention Standards, for completed reports are as follows:



    - Weekly reports are retained for one month, except LTS reports that are retained for one cycle.

    - Bi-weekly reports are retained for two months.

    - Monthly reports are retained for one quarter.

    - Quarterly reports are retained for six months.

    - Semi-annual and annual reports are retained for one year.


### Note:

Retention schedules are only applicable for Managers. Managers will be responsible for establishing the controls to ensure employees are generating and working reports. Caseworkers are responsible for generating and working their reports according to the corresponding schedules. They also need to retain their reports until all required case actions are completed. Group Managers may request employees send them reports as part of specific group expectations. If the managers identify a deficiency in employees’ performance during the performance review cycle, the manager may request the employee submit their reports to their attention including notations about the actions taken.

12. The chart below lists actions which are **Mandatory** in bankruptcy case processing. The chart separates duties overseen by managers in Field Insolvency, overseen by managers at the CIO, and duties which are supervised by managers in both functions. The links to exhibits and IRM references cited within the chart provide cross references to report tools or IRM procedures for meeting those actions.




    | **Field Insolvency** | **Both** | **CIO** |
    | --- | --- | --- |
    | Meet bar dates.<br> See Field Insolvency Report Job Aid | Resolve stay violations timely.<br> See IRM 5.9.3.5, Automatic Stay. | Work DDRs timely.<br> See IRM 5.9.17.4, Time Frames for Required Actions. |
    | Monitor plan filings and review plans.<br> See Field Insolvency Report Job Aid. | Case monitoring. See IRM 5.9.16.2, Litigation Transcript System and _Exhibit 1.4.51-8_, Guide for the Litigation Transcript System (LTS) Reports.). | Run IIP processes C and D.<br> See IRM 5.9.12.5, Insolvency Interface Program (IIP). |
    | Attend 341 hearings when appropriate.<br> See IRM 5.9.2.5, First Meeting of Creditors. | Protect collection statutes.<br> See Field Insolvency Report Job Aid. | Run IIP process J.<br> See IRM 5.9.12.5, Insolvency Interface Program (IIP). |
    | Protect assessment statutes.<br> See Field Insolvency Report Job Aid. | Ensure timely responses to the Taxpayer Advocate.<br> See IRM 5.9.3.8, Taxpayer Advocate Service (TAS). | Work trustee refund turnover requests.<br> See IRM 5.9.6.2.3, Chapter 7 Tax Refunds to Trustees. |
    | Respond to claim objections timely and follow-up.<br> See Field Insolvency Report Job Aid. | Generate and work litigation transcripts and initiate case closure timely.<br> See Field Insolvency Report Job Aid and IRM 5.9.16.2, Litigation Transcript. | Work IIP error reports and PIT reports.<br> See IRM 5.9.12.5.2, Potentially Invalid TIN (PIT) List. |
    | Submit plan objection referrals timely and follow-up.<br> See Field Insolvency Report Job Aid. | Generate and work Aged Case Report annually.<br> See IRM 5.9.16.6, Aged Case Reports. | Work IIP status reports.<br> See IRM 5.9.12.5.1, IIP Status Reports. |
    | Address adequate protection when appropriate.<br> See IRM 5.9.8.6, Adequate Protection.<br> See IRM 5.9.9.4, Adequate Protection in the Chapter 12 Case. | Work LAMS Not Found on AIS Case Listing report.<br> See Field Insolvency Report Job Aid and IRM 5.9.16.4.2, LAMS Not Found on AIS Case Listing report (field Insolvency and CIO).<br> Work LAMS Closed Case Listing.<br> See Field Insolvency Report Job Aid and IRM 5.9.16.4.1, LAMS Closed Case Listing | Run IIP 2 (ADS).<br> See IRM 5.9.12.6, Automated Discharge System. |
    | File administrative claims.<br> See IRM 5.9.8.13, Post-petition/Pre-confirmation BMF Monitoring<br> See IRM 5.9.8.14.1, Post-petition Debts - Chapter 11 Individuals.<br> See IRM 5.9.8.19.4.2, Post-Confirmation Tax Liabilities of the Individual Debtor (Post-BAPCPA).<br> See IRM 5.9.13.11, Administrative Claims. | Release liens timely.<br> See Field Insolvency Job Aid).<br> See IRM 5.9.17.5.2, Collection from Exempt, Abandoned, or Excluded Property (EAEP). | Work ADS process K and L errors.<br> See IRM 5.9.12.6, Automated Discharge System. |
    | Monitor plan payments.<br> See Field Insolvency Report Job Aid | Load cases to AIS and ensure TC 520 input timely.<br> See IRM 5.9.12.5, Insolvency Interface Program (IIP).<br> See IRM 5.9.12.7, Electronic Noticing System. | Distribute time sensitive mail timely.<br> See IRM 5.9.11.4.2, Time Sensitive Mail. |
    | Address delinquent plans.<br> See Field Insolvency Report Job Aid | Address follow-up actions timely.<br> See Field Insolvency Report Job Aid | Mirror MFT 31 accounts for all chapters.<br> See ≡ ≡ ≡ ≡ ≡ ≡ ≡≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡. |
    | When incomplete prompt determination request received, advise requester of missing documentation when all documentation received, submit package to Exam.<br> See IRM 5.9.4.9.1, Processing Prompt Determination Requests. | Review and sign manual refund requests.<br> See IRM 5.9.16.3, Manual Refunds. | Receive and review prompt determination requests for acceptable submission; send complete packages to Exam and incomplete packages to Field Insolvency.<br> See IRM 5.9.4.9.1, Processing Prompt Determination Requests. |
    | Pursue exempt, abandoned, or excluded property when appropriate.<br> See IRM 5.9.17.5, Exempt Abandoned. or Excluded Property (EAEP). | Work Non-Master File (NMF) listing.<br> See Field Insolvency Report Job Aid and _Exhibit 1.4.51-14_, Guide for Non-Master File Listing Report (CIO). | Work trustee refund turnover requests.<br> See IRM 5.9.6.2.3, Chapter 7 Tax Refunds to Trustees. |
    | Submit fraud referrals.<br> See IRM 5.9.4.12.1, Fraud Referrals. | Identify cases mis-assigned by CAG or left unassigned by CAG and assign them manually.<br> See _Exhibit 1.4.51-17_, Guide for Case Assignment Reports ( CIO). | See information under column named both |
    | Secure delinquent returns.<br> See IRM 5.9.4.16, Unfiled Pre-Petition Returns.<br> See IRM 5.9.4.17, Unfiled Post-Petition Returns..<br> See Field Insolvency Report Job Aid | Verify correct case grade assignments through CAG.<br> See Field Insolvency Report Job Aid and _Exhibit 1.4.51-17_, Guide for Case Assignment Reports (CIO) | See information under column named both |
    | Initiate referrals to Field Collection when applicable.<br> See Field Insolvency Report Job Aid. | Identify fraud.<br> See IRM 5.9.4.12, Bankruptcy Fraud. | See information under column named both |
    | Request TFRP investigations from Field Collection timely or begin in-house TFRP investigations timely.<br> See IRM 5.9.3.10, Trust Fund Recovery Penalty and Field Insolvency Report Job Aid. | Address significant cases.<br> For CIO see IRM 5.9.6.10.3(2), Large Dollar 7N Case Assignments, CIO screening. | See information under column named both |
    | Address significant cases.<br> See IRM 5.9.4.15.3, Significant Bankruptcy Case Referrals. | Post all payments received regardless of the Chapter.<br> See IRM 5.9.15, Payments in Bankruptcy. | See information under column named both |
    | Take appropriate actions on post-petition liabilities.<br> See Field Insolvency Report Job Aid and IRM 5.9.16.2.2, New Assessment Reports. | See information under column named Field Insolvency | See information under column named Field Insolvency |


**1.4.51.9** **(12-08-2020)**

### Assigning Work

1. Insolvency ensures fairness and integrity in case assignment through using an equitable process for all taxpayers by using an automated system, the Electronic Noticing System (ENS) to load bankruptcy cases directly from the court. See IRM 5.9.12.7, Electronic Noticing System. In addition, the Case Assignment Guide, described below in _IRM 1.4.51.9.1_, Case Assignment Guide, explains the automated grading and assignment of new cases received by Insolvency. These automated systems ensure no one individual can control the enforcement selection decision making process which aligns with IRM 1.2.1.2.36, Policy Statement 1-236 (Rev. 1), Fairness and Integrity in Enforcement Selection. Adherence to the principles in this policy statement ensures the IRS is meeting its commitment in the IRS Mission Statement by enforcing the tax law with integrity and fairness to all. An important component of fairness and integrity in enforcement selection includes the assignment of work by the group manager. The purpose of this section is to provide a framework for the assignment of work to ensure case assignments are consistent with the goals and objectives of the IRS.

2. Managers are responsible for ensuring that cases are assigned at the proper grade, based on all indicators of case difficulty.



### Note:



Developmental Bankruptcy Specialist (GS-07) and trainee Bankruptcy Specialist (GS-05) will be assigned cases with a case grade of GS-09 because Insolvency cases generally are not graded below Bankruptcy Specialist journey level (GS-09). See IRM 1.4.51.9.2(1), Case Grade. Managers will carefully select the cases assigned to these employees to ensure that cases are appropriate for the experience level of the employee and for development of the employee into a GS-09 Bankruptcy Specialist, capable of performing all aspects of the position independently. The manager or on the job instructor, if one is assigned, will provide closer than normal supervision and review the work of these employees frequently to ensure that the employee is developing and making progress toward the full performance level of GS-09 Bankruptcy Specialist.

3. Managers must review inventory and case grade reports monthly to ensure employees are not working over 25% direct time above grade. If employees works higher grade cases, the manager should track the higher graded work to ensure the 25% threshold is not exceeded. Employees who exceed 25% level for a four-month period may be entitled to a temporary promotion.


**1.4.51.9.1** **(02-04-2025)**

#### Case Assignment Guide

1. The Case Assignment Guide (CAG) was developed to promote consistency in the assignment of graded Insolvency cases.

2. AIS automates the grading and assignment of new cases received by Insolvency. The level of difficulty or grade of a case is based on characteristics apparent upon initial receipt. The pre-assignment grade is only an initial prediction and should be adjusted when post-assignment factors justify a change. See _Exhibit 1.4.51-19_, CAG Pre-Assignment Factors, and _Exhibit 1.4.51-20_, CAG Pre-Assignment Difficulty Indicators. Automated CAG uses the following four factors in the pre-assignment process:



   - Business Operating Division (BOD)

   - File source

   - Chapter

   - Balance due information


3. Post-assignment factors are used either to reassign a case or to assign certain issues or tasks to an appropriately graded employee. Managers should be familiar with the post-assignment factors and take steps to reassign cases to the appropriate grade level of employee when the following post-assignment factors are identified:



   - Case action

   - Communication

   - Supervisory control


### Note:

See _Exhibit 1.4.51-21_, Post-Assignment Difficulty Indicators Factor 5: Case Action, _Exhibit 1.4.51-22_, Post-Assignment Difficulty Indicators Factor 6: Communication, and _Exhibit 1.4.51-23_, Post Assignment Difficulty Indicators Factor 7: Supervisory Controls.

4. Managers must designate employee assignment numbers for the inventories under their responsibility. All bankruptcy court jurisdictions must have an employee number assigned for every combination of chapter, case grade and alpha assignment. Once the inventory assignments have been designated, the manager must ensure the employee assignment information is entered in AIS for Automated CAG to work effectively. The Case Assignment Profile Matrix stores employee information so Automated CAG can assign cases to the appropriate employee. Employee assignment information cannot overlap. _Exhibit 1.4.51-24_, Case Assignment Profile Matrix, contains a template to be used as a guide in preparing the matrix. A template should be prepared for each court jurisdiction.

5. Automated CAG generates a suite of reports to assist Insolvency managers in monitoring the flow of newly assigned cases and in balancing inventories. These reports identify unassigned cases that may have to be manually assigned and are tools for selecting cases for review. (See _Exhibit 1.4.51-17_, Guide for Case Assignment Reports (CIO).)

6. CAG has a Manager Only menu option whose access is limited to certain employee assigned roles. This option allows Insolvency managers to supervise the assignment of work and facilitates conducting case reviews. Managers, particularly those in Field Insolvency, play a pivotal role in both the pre-assignment and post-assignment processes. They must monitor inventory receipts to ensure new cases are properly graded and assigned. They must also verify previously assigned cases are reassigned and re-graded timely when appropriate. Corrective actions must be taken immediately by the manager or designated employee in the following situations:



1. When case dockets are ungraded, managers must input the appropriate information to grade and/or assign cases.

2. When cases are converted from one chapter to another, the cases must be manually reassigned and re-graded.

3. Errors from IIP Processes C and D must be resolved promptly because these errors can prevent Automated CAG from grading and assigning cases. Once the errors are resolved, CAG assigns the case when IIP is next run.


7. The Case Grade Report should be reviewed by Insolvency managers at least monthly to identify the distribution of graded case assignments. The report provides a list of employee assignment numbers and reflects the inventory distribution for each including the percentage of cases for each grade assignment. Reviewing this report will assist managers in monitoring inventories to ensure graded cases are assigned at the appropriate levels. See Field Insolvency Report Job Aid. Review of this report may also identify ungraded cases that require grading. In order to see the specific cases that need grading run the Ungraded Case Follow Up Report. See _Exhibit 1.4.51-17_, Guide for Case Assignment Reports ( CIO), for more information.


**1.4.51.9.2** **(06-15-2023)**

#### Case Grade

1. Cases are issued with a case grade of 07, 09, 11, or 12. These case grade levels reflect the anticipated level of difficulty. _Exhibit 1.4.51-20_, CAG Pre-Assignment Difficulty Indicators, reflects the criteria used to determine the case difficulty level.

2. Managers are responsible for reviewing and maintaining the correct case grade. Case grade levels can be either increased or decreased. There are systemic processes in place to predict the grade level of a case. If the predicted case grade does not appear to be accurate, the manager may re-grade the case per the Case Assignment Guide criteria in _Exhibit 1.4.51-25_, CAG Post-Assignment. This can be done at any time: upon receipt, upon assignment to an employee, and during case reviews. Employees should be encouraged to bring mis-graded cases to their manager’s attention.

3. Managers will not normally change the grade of a case unless it meets factors at the lower or high level. Document in the case history the reason for changing the grade of a case.

4. Managers should change the grade of a case if receipt of additional information or case circumstances warrant. If additional explanation is needed, the manager should write a narrative history as well.

5. When it is determined that the difficulty level of a case has changed, the manager may adjust the grade level.

6. Managers may need to consider a reassignment of the case if a grade level change is made.


**1.4.51.9.3** **(06-25-2025)**

#### Maintaining Inventories

1. Group managers are responsible for monitoring inventory levels to ensure each employee has an appropriate number of cases that can be resolved most effectively and efficiently based on his/her grade level, experience, and expertise.


**1.4.51.9.3.1** **(02-04-2025)**

##### Inventory Adjustments

1. An inventory adjustment is a percentage-based adjustment to the standard range. It is based on an evaluation of time spent on activities other than work on assigned cases (direct case time) and normal overhead. Examples of situations where a manager may consider an inventory adjustment are:



1. Collateral assignments (e.g., NTEU Representative, EEO Counselor/Investigator, details out of office, instructing assignments, coaching, etc.).

2. Customer Service assignments (e.g., Servicing walk-in taxpayers during filing season, ACS walk-in taxpayers).

3. Automation support.


### Note:

When an adjustment to an employee’s inventory is warranted because of any of these circumstances, use the projected time expenditure by the employee to determine the appropriate adjustment. A manager reviews a GS-12 employee’s time over the last six months and determine the employee appropriately spent 25% of their time on collateral assignments. An adjustment of 25% is indicated in this case.

### Example:

A manager reviews a GS-12 employee’s time over the last six months and determine the employee appropriately spent 25% of his/her time on collateral assignments. An adjustment of 25% is indicated in this case.

2. Inventory levels may be re-adjusted as warranted. Managers should perform quarterly reviews of actual time their employees spend on collateral assignments and make adjustments as needed. Adhere to these guidelines when considering any adjustments to employee inventories.

3. When additional cases need to be assigned, managers should look to the following sources for additional work:



   - Other employees

   - Other groups (with concurrence from the Territory / Operation / Department Manager)


**1.4.51.9.4** **(10-04-2013)**

#### Reassignment of Departing Employee Inventory

1. Where inventory will be abandoned for periods of 90 days or more (for example an employee is reassigned, on extended leave, or long term detail) the group manager will consider performing the following actions:



1. Holding assignment of additional work (after confirmation of the employee’s effective date for detail, reassignment, retirement, etc.).

2. Reviewing all inventory with the departing employee (including cases on the AIS system) and identifying those which can be resolved prior to the employee leaving, or reassigned to the remaining employees in the group. The transfer of these cases should be completed within a reasonable period of time, normally within 45 days. When appropriate, re-grade cases based on the post assignment criteria.


**1.4.51.10** **(02-12-2020)**

### Initial Case Processing

1. **Insolvency Interface Program (IIP)**. The CIO must run IIP processes C and D daily to ensure new cases are processed timely. If IIP is unavailable the manager must direct employees to input bankruptcy freeze codes (TC 520s) with appropriate closing codes manually within **five work days** of receiving notification of new bankruptcies. (See IRM 5.9.5.6.1, Closing Codes, for TC 520 closing codes.)



1. Caseworkers must add bankruptcy court case information into AIS as soon as Insolvency receives electronic notice, paper notice, or referral information from other internal sources (e.g., Automated Collection System (ACS), Customer Service, or Accounts Management). Adding new cases to AIS is a CIO duty. However, Field Insolvency caseworkers are not prohibited from loading new cases that come to their attention through the identification of a stay violation.

2. The Potentially Invalid TIN (PIT) and Cross-Reference TIN Reports must be worked daily. The court debtor name and TIN data must match the master file information to allow the TC 520 to post to the correct taxpayer's account. The CIO will work all of these reports except for those pertaining to Chapter 9 and Chapter 15 cases. Cases that cannot be resolved by the CIO must be transferred to Field Insolvency for resolution.

3. IIP generates reports identifying cases in status 22 - ACS, status 24 - Federal Payment Levy Program (FPLP), status 60 - installment agreements (IA), status 26 - field revenue officer (RO), and status 71 - Offer in Compromise (OIC). The CIO works all status reports except those pertaining to Chapter 9 cases, Chapter 15 cases, and some Chapter 11 cases. Cases that cannot be resolved by the CIO must be transferred to Field Insolvency for resolution. (See IRM 5.9.12.5.1, IIP Status Reports.)

4. TC 520 closing codes in the 60 - 67 series, 81, and 83 - 85 series are input taking into consideration court rules, standing orders, and the IRS's mission to increase compliance. Only the CIO is authorized to change closing code designations on IIP and may only do so with approval from Collection Policy.

5. Managers are to analyze the impact on work processes when the TC 520 closing code used by their group changes.


**1.4.51.11** **(02-12-2020)**

### Protection of the Government's Interest

1. **Receipt of Notices**. Insolvency must protect the interests of the government during bankruptcy proceedings. Following the procedures listed below will increase appropriate and timely processing actions.


**1.4.51.11.1** **(02-12-2020)**

#### Proofs of Claim Filing

1. **Timely Claims**. In most cases to be timely, a proof of claim (POC) must be filed before 180 days (the government bar date) from after the date of the order of relief (which is the date the bankruptcy petition was filed in voluntary cases). (See 11 USC 502, Allowance of claims or interests, and Bankruptcy Rule 3002, Filing Proof of Claim or Interest.) Claims prepared through Automated Proof of Claim (APOC) processing should be filed prior to the first meeting of creditors. A full discussion of time frames for filing claims can be found in IRM 5.9.13.7, Bar Dates.

2. **"Proof Required" and "Bar Date" fields on AIS**. The "Proof Required" field on AIS is not protected. Anyone with update capabilities can change the field from "Yes" (a claim is required) to "No" (a claim is NOT required). Caseworkers can also alter the bar date field. Inappropriate alteration of the bar date may give the impression more time is available to file a POC than legally exists. The audit trail available in the CAG Manager's Only menu records information when the Proof Required or Bar Date fields are updated.

3. **Missed Bar Dates**. If a bar date has expired, the person identifying the missed bar date will, within 10 days, complete Part A of Form 14167, Bar Date Expiration Report, and will enter a statement in the case history indicating that a preliminary Form 14167 has been prepared. If not prepared by the group manager, the completed Form 14167 should be forwarded to the group manager for review. Within 60 days of identification, the group manager will review the case history, and any other relevant information, determine if further administrative action is warranted, and whether disciplinary action is appropriate. The group manager will complete Part B of Form 14167 with the results of the investigation. If disciplinary action is warranted, the manager will prepare a memo that details why the Bar Date expired, and why disciplinary action is warranted. The Form 14167 and memo should be prepared and routed as follows:



1. Field Insolvency: from group manager to Territory Manager. The Territory Manager will review the memo and determine if disciplinary action is warranted. Form 14167 will be forwarded to the Director, Specialty Collection - Insolvency for signature. After signature, the case history will be updated to indicate that the final Form 14167 has been processed and the investigation completed.

2. Centralized Insolvency Operation: from unit manager to Department Manager. The Department Manager will review the memo and forward to the Operation Manager for concurrence of no action/potential disciplinary action. The Operation Manager will forward the Form 14167 to the Director, Specialty Collection - Insolvency for signature if disciplinary action is warranted.


### Note:

The report will not be required for expired bar dates in cases where the IRS did not receive notification of the bankruptcy prior to the last day for filing a proof of claim as defined in Bankruptcy Rule 3002(c), Time for Filing, or Bankruptcy Rule 3003(c), Filing Proof of Claim, whichever is applicable.

### Reminder:

All Forms 14167 will be retained for 2 years.

**1.4.51.11.2** **(02-12-2020)**

#### Adequate Protection

1. **Secured Assets**. Where valid NFTLs have been filed and the criteria in ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ are met, Insolvency should pursue adequate protection of the government's interest in assets that will lose significant value during the life of the plan.



### Note:



Adequate protection primarily concerns Chapter 11 and Chapter 12 cases, because debtors in those cases are generally operating an ongoing business and using property subject to liens such as inventory or accounts receivable. Pursuit of adequate protection is possible in Chapter 13 cases, but requesting a lift of the stay is often a more appropriate tactic.


**1.4.51.11.3** **(02-12-2020)**

#### 341 Hearings

1. **Attendance by Insolvency**. Representatives from Insolvency should attend 341 first meeting of creditors when appropriate and staffing allows. (See IRM 5.9.2.5, First Meeting of Creditors.)


**1.4.51.11.4** **(02-12-2020)**

#### Plan Review

1. **Significant Cases**. Significant cases must be referred to Counsel regardless of chapter. (See IRM 5.9.4.15.3, Significant Bankruptcy Case Referrals.) The AIS history must annotate if Counsel has assumed the responsibility for plan review.

2. **Review and Documentation**. IRM 5.9 provides detailed text and procedures for reviewing and documenting plans. (See IRM 5.9.5.4(3), Chapter 13 Plan Documentation, IRM 5.9.5.4(4), Chapter 11 and Chapter 12 Plan Documentation, IRM 5.9.8.17.1, The Plan of Reorganization, IRM 5.9.9.5, Chapter 12 Plans, IRM 5.9.9.5.2, Plan Modification, IRM 5.9.9.6, Reasons to Object to the Plan, and IRM 5.9.10.5, The Chapter 13 Plan.)



### Note:



If review of a plan is not documented in the AIS history, it is considered not to have been done.

3. **Confirmed and Amended Plans**. If proposed plan provisions affecting the treatment of the IRS are deemed inadequate by the Field Insolvency caseworker, the AIS history must include documentation of the confirmed plan or a statement that an inadequate plan has been confirmed. When a confirmed plan is amended, where the amendment affects the interests of the IRS, the amended plan must be documented in the AIS History and the Confirmed Plan Monitoring (CPM) screen updated.


**1.4.51.11.5** **(02-12-2020)**

#### Compliance Monitoring

1. **Multiyear Plans**. Insolvency caseworkers should monitor post-petition compliance by the debtor when long term plans are confirmed. Some debtors make high payments mandated by trustees by lowering their withholding or by failing to make federal tax deposits, leading to unpaid post-petition taxes. The Bankruptcy Abuse Prevention and Consumer Protection Act of 2005 (BAPCPA) added provisions to address post-petition tax compliance in bankruptcy cases.



   - Any case filed on or after October 17, 2005, under any chapter, is subject to dismissal or conversion if the debtor fails to file a post-petition returns. (See 11 USC 521(j).)

   - In Chapter 11 cases filed on or after October 17, 2005, failure to file a post-petition return is an express ground for dismissing or converting a case. (See 11 USC 1112(b)(4)(I).)

   - Because fewer options are available to address post-petition compliance in Chapter 12, (e.g., no provision in the Bankruptcy Code for filing post-petition claims), Insolvency should seek guidance from Counsel when appropriate.


### Note:

For additional information see IRM 5.9.8.13, Post-petition/Pre-confirmation BMF Monitoring, IRM 5.9.8.14.1, Post-petition Debts - Chapter 11 Individuals, IRM 5.9.9.10, Monitoring Compliance, and IRM 5.9.10.9, Post-Petition Tax Liabilities, for more information.

**1.4.51.11.6** **(02-04-2025)**

#### Bankruptcy Fraud

1. **Fraud Detection**. All caseworkers, regardless of grade or position title, should review cases with an eye for indications of bankruptcy fraud. However, Field Insolvency is responsible for referring accounts to the Fraud Enforcement Advisor (FEA) or to Counsel when warranted. (See IRM 5.9.4.12, Bankruptcy Fraud, and IRM 5.9.17.8.2, The Fraud or Willful Evasion Exception to Discharge.)


**1.4.51.11.7** **(02-12-2020)**

#### NFTL Refiles

1. **NFTL Refile**. Procedures outlining the issues involved and the reviews required for potential NFTL refiles are found in IRM 5.9.5.9.2, Refiling Notices of Federal Tax Lien (NFTL), IRM 5.9.8.19.2, Monitoring the Plan and Reviewing for Refiling of the Notice of Federal Tax Lien (NFTL), and IRM 5.9.17.5.3(12), Notice of Federal Tax Lien (NFTL) Refiles.


**1.4.51.11.8** **(02-12-2020)**

#### Unfiled Returns

1. **Estimated Claims**. Estimated claims for unfiled, unassessed tax periods impact collection of the correct amount of tax, because estimated claims prompt delinquent debtors to file tax returns. However, estimated claims filed by the IRS can be the source of objections if debtors and their representatives are not aware of the unfiled returns.

2. **BAPCPA Change**. The IRS has addressed compliance requirements brought about by BAPCPA by including annotations on claims and sending courtesy copies of Letter 1714, Request For Missing Tax Returns, to trustees to provide information regarding unfiled returns. The Letter 1714, courtesy copy alerts the trustee that the IRS may be amending its POC or filing a motion to dismiss or convert the bankruptcy. The trustee may wish to delay distributions or plan confirmation until this tax administration issue has been resolved.

3. **Correcting the AIS CPM Screen**. Managers must ensure estimated claims are amended when debtors' returns are filed and assessed if the debtors' returns do not reflect the amounts shown on our estimated claim. To avoid an objection, Managers can ensure the caseworker amended the claim when a return is received. Whenever a claim is amended, the AIS CPM screen must be adjusted to reflect the amended claim period(s), so collected funds are appropriately applied to tax rather than transferred to unidentified remittance.


**1.4.51.12** **(02-04-2025)**

### Automated Proof of Claim (APOC)

1. The APOC program systemically calculates and classifies liabilities to populate AIS proofs of claim fields so Forms B410, Proof of Claim, can be produced for the bankruptcy court. A full discussion on employee instructions for generating and perfecting APOC data is found in IRM 5.9.14, Automated Proofs of Claim (APOC). This IRM 1.4.51 subsection deals with manager reports and APOC permissions, topics not covered in IRM 5.9.14.

2. Managers can access APOC by accessing a case and selecting the "APOC" tab.

3. Cases that were selected for APOC processing but did not make it through the process will need to be “Restored to AIS” by an Insolvency Manager. Managers should select the "Restore APOC" button located on the APOC Case Detail screen to restore these cases when necessary.

4. **APOC Reports**. The following is a list of APOC reports that may be reviewed by managers, for a list of mandatory reports see the Field Insolvency Report Job Aid posted at Knowledge Management under Field Insolvency BOE Report Schedule for Group Managers.



1. Flagged Cases report. The Flagged Cases report lists all cases that have unresolved flags. Most flags should be worked at least **five** calendar days before the 341 meeting.

2. Period Detail Flag - Credits Posted After Petition Date report. The Period Detail Flag - Credits Posted After Petition Date report lists all modules with a TC designated as Pay in the Payment Designation Tables and the TC date is greater than the Petition Date. Since these credits could be in **"Violation of the Automatic Stay"** caseworkers should work the cases on this report within **"five"** calendar days of APOC identifying the flagged condition.

3. Period Detail Flag - Lien Recorded Date Blank or After the Petition Date report. The Period Detail Flag - Lien Recorded Date Blank or After the Petition Date report lists all modules with a notice of lien date that is either not recorded on AIS, or the date recorded is greater than the Petition Date. Since these NFTLs could be in **"Violation of the Automatic Stay"**, the caseworker should work the cases on this report within **"five"** calendar days of APOC identifying the flagged condition.

4. Period Detail Flag - Secured Period report. The Period Detail Flag - Secured Period report lists all modules classified by APOC as "Secured" based on AIS Lien records. The caseworker should work the cases on this report within **"10"** calendar days of APOC identifying the flagged condition for all chapters other than Chapter 7 and Chapter 13.

5. APOC Summary report. This report provides the manager with statistical data relating to the processing of cases through APOC.


**1.4.51.13** **(06-25-2025)**

### Insolvency and IDRS

1. Group managers are responsible for ensuring that their employees have access to the Integrated Data Retrieval System (IDRS) command codes necessary to perform their assigned tasks and required research.

2. Examples of the tasks Insolvency performs on the IDRS are:



1. Account research for a filing compliance check

2. Assigning a case to another area (e.g., assign a case to a revenue officer or the Automated Collection System (ACS))

3. Resolving incompatible data (e.g., matching data from the bankruptcy petition to a taxpayer’s name and social security number on the IRS’s master file)

4. Accessing account information to prepare adjustment requests

5. Inputting or reversing bankruptcy freezes

6. Inputting account adjustments other than bankruptcy freeze actions (CIO only)


3. Whenever practical, Insolvency groups should not be included with IDRS data security work groups from other functions within SB/SE (for example, Civil Enforcement Advice and Support Operations (CEASO) or Field Collection (FC)). If the physical office accommodates two or more Insolvency groups, all of the Insolvency groups in the same office can be under the same IDRS group code. To change, consolidate, or request a new group code, the IDRS-Unit Security Representative (USR) or the Functional Security Coordinator (FSC) must be contacted. By keeping Insolvency separate from other groups, managers can identify and oversee command codes needed to perform Insolvency specific duties.

4. Managers must ensure required security measures are in place regarding on-line IDRS account adjustments.

5. Managers should monitor command code usage by all members of the group. See table below:



**Suggested profiles for insolvency employees:**






| **Bankruptcy Specialists (GS-1101), Revenue Officer Advisors (GS-1169), and Tax Examining Technicians (GS-0592) command codes**: |
| --- |
| - ACTON<br>     <br>   - AMDIS<br>     <br>   - ASGNB<br>     <br>   - ASGNI<br>     <br>   - BMFOL<br>     <br>   - BMFPG<br>     <br>   - BRTVU<br>     <br>   - CFINK<br>     <br>   - COMPA<br>     <br>   - EFTAD<br>     <br>   - EMFOL<br>     <br>   - ENMOD<br>     <br>   - ESTAB<br>     <br>   - FFINQ<br>     <br>   - FIEMP<br>     <br>   - FRM34<br>     <br>   - FRM49<br>     <br>   - FRM77<br>     <br>   - IADIS<br>     <br>   - IAGRE<br>     <br>   - IMFOB<br>     <br>   - IMFOL<br>     <br>   - INOLE<br>     <br>   - INTST<br>     <br>   - IRPTR<br>     <br>   - LEVYS<br>     <br>   - MESSG<br>     <br>   - MFREQ<br>     <br>   - MFTRA<br>     <br>   - NAMEE<br>     <br>   - NAMEI<br>     <br>   - NAMES<br>     <br>   - RECON<br>     <br>   - REQ77<br>     <br>   - RTVUE<br>     <br>   - STATB<br>     <br>   - STATI<br>     <br>   - STAUP<br>     <br>   - SUMRY<br>     <br>   - TERUP<br>     <br>   - TPIIP<br>     <br>   - TRDBV<br>     <br>   - TXMOD<br>     <br>   - UNLCE<br>     <br>   - UPCAS<br>     <br>   - UPDIS<br>     <br>   - UPTIN |







**Other command codes that may be used by CIO**






| **Additional CIO Bankruptcy Specialists (GS-1101) and CIO Tax Examining Technicians (GS-0592) command codes (used for account adjustments, issuing letters, inputting refunds, etc.)**: |
| --- |
| - ADD24<br>     <br>   - ADD34<br>     <br>   - ADJ54<br>     <br>   - BNCHG<br>     <br>   - DRT24<br>     <br>   - ENREQ<br>     <br>   - IAORG<br>     <br>   - IAREV<br>     <br>   - INCHG<br>     <br>   - LETER<br>     <br>   - LPAGD<br>     <br>   - LPAGE<br>     <br>   - REQ54<br>     <br>   - RFUND<br>     <br>   - TERUP |







**Command codes used by Tax Examining Technicians**






| **Support Tax Examining Technicians (GS-0592) command codes**: |
| --- |
| - ACTON<br>     <br>   - AMDIS<br>     <br>   - BMFOL<br>     <br>   - COMPA<br>     <br>   - ENMOD<br>     <br>   - FIEMP<br>     <br>   - FRM77<br>     <br>   - IADIS<br>     <br>   - IMFOB<br>     <br>   - IMFOL<br>     <br>   - INOLES<br>     <br>   - INTST<br>     <br>   - IRPTR<br>     <br>   - MESSG<br>     <br>   - MFREQ<br>     <br>   - MFTRA<br>     <br>   - NAMEE<br>     <br>   - NAMEI<br>     <br>   - NAMES<br>     <br>   - RECON<br>     <br>   - REQ77<br>     <br>   - RTVUE<br>     <br>   - SUMRY<br>     <br>   - TERUP<br>     <br>   - TRDBV<br>     <br>   - TXMOD |







### Note:



The command codes listed for the Support Examining Technicians **must** be in their profiles for the corresponding programs to work properly. This is true for anyone running IIP, ADS, or APOC.

6. A command code is considered "sensitive" if it can be used to adjust account balances, change the status of a tax module or account, or affect the tax liability. Sensitive command code combinations give an employee the ability to perform more than one type of transaction where the intentional mishandling of a taxpayer’s account may occur (e.g., change the entity or address information of an account and transfer payments).




| **Managers who sign manual refunds are restricted from having the below command codes in their personal profiles:** |
| --- |
| - ADC24<br>     <br>   - ADC34<br>     <br>   - ADD24<br>     <br>   - ADD34<br>     <br>   - ADD48<br>     <br>   - ADJ54<br>     <br>   - AMCLS<br>     <br>   - BNCHG<br>     <br>   - DRT24<br>     <br>   - DRT48<br>     <br>   - FRM34<br>     <br>   - INCHG<br>     <br>   - REFAP<br>     <br>   - RFUND<br>     <br>   - URAPL<br>     <br>   - URREF<br>     <br>   - XSAPL<br>     <br>   - XSREF |

7. The following chart lists common IDRS command codes and their functions.




| **Insolvency Activity** | **Research Command Code** | **Action Command Code** |
| --- | --- | --- |
| Address Change | ENMOD | ENREQ, INCHG, BNCHG |
| Adjustments to Tax, Penalty, Interest, and Credit Reference Changes to IDRS Accounts | TXMOD | REQ54 / ADJ54<br> REQ77 / FRM77 |
| Controlling a Case | TXMOD | ACTON |
| Credit Transfers | TXMOD | ADD24 / ADC24 / DRT24<br> ADD34 / ADC34 / FRM34<br> ADD48 / ADC48 / DRT48 |
| Delinquent Account Issues | IMFOLI, TXMOD | N/A |
| Delete Transactions, Same Day Input | TXMOD | TERUP |
| Dummy Account | SUMRY | MFREQ |
| Entity Information and/or Changes | ENMOD, INOLET | ENREQ, INCHG, BNCHG |
| Exam Issues | AMDISA | N/A |
| Fact of Filing | IMFOLI | FFINQ |
| History Items | TXMOD | ACTON |
| Installment Agreements | IADIS | IAORG, IAREV |
| Interest and Penalty Bal Due Computations | TXMOD | INTST, COMPA |
| Reassigning an Account | TXMOD | TSIGN |
| Requesting Returns, Transcripts | TXMOD, IMFOLI | ESTAB, MFTRA |
| Social Security Number Research | INOLET | NAMES |
| Tax Module Research | TXMOD<br> SUMRY<br> IMFOL<br> BMFOL<br> RTVUE<br> BRTVU | N/A |
| Unpostables | TXMOD | UPTIN, UPCAS, UPDIS |
| Display Taxpayer Name, Address, Spouse Cross Reference Data, Filing Requirements, DOB, BOD, etc. | INOLE | N/A |
| Request IRP Transcripts for Specific TIN and Tax Year | IRPTR | N/A |
| EIN Research | INOLET | NAMEE |
| Online Display of Tax Return Information | RTVUE, BRTVU | N/A |
| Employee Master File Online | EMFOL | N/A |
| Update the Status of Modules that Are or Have Been Balance Due Modules | STAUP | N/A |
| Research for Trust Fund Recovery Penalty Assessment | UNLCE | N/A |
| Enter IDRS | SINON | N/A |
| Exit IDRS | SINOF | N/A |
| Display All Command Codes in Your Profile | SFDISP | N/A |

8. Resources:



   - IDRS Command Codes Job Aid on SERP

   - Document 6209, IRS Processing Codes and Information

   - IRM 10.8.34, IDRS Security Controls

   - IRM 2.3, IDRS Terminal Responses

   - IRM 2.4, IDRS Terminal Input


**1.4.51.14** **(02-04-2025)**

### Closed Cases

1. Dismissal actions must be initiated within 30 calendar days of the IRS’s receiving notification of dismissal.

2. Managers must ensure case discharge processing begins no later than 30 calendar days after receipt of the discharge notice for all cases except non-liquidating corporate Chapter 11 cases or individual Chapter 11 cases commenced prior to October 17, 2005. Discharge actions on non-liquidating corporate Chapter 11 cases or individual Chapter 11 cases commenced prior to October 17, 2005, must be initiated within 30 calendar days of plan completion.



### Note:



Investigation into the pursuit of exempt, abandoned, or excluded property is considered to be an initiation of the discharge process.

3. The IRS will initiate closing actions required for the release of liens on discharged taxes within 30 days of receipt of notice of the discharge order. The lien will systemically release once all adjustments have posted to IDRS. Generally, manually requesting a lien release is not required. However, if a certificate of release will not be systemically issued, the release should be requested manually on the Automated Lien System (ALS). Monthly checking of the Lien Research report will identify liens that have not been released so corrective actions can be taken. See _Exhibit 1.4.51-15_, Guide for Lien Research Report ( CIO) and the Field Insolvency Report Job Aid. In the instance of individual Chapter 11 cases filed prior to BAPCPA or non-individual Chapter 11 cases filed at any time, closing actions will be initiated within 30 calendar days from plan completion. In these Chapter 11 cases, manually requesting the lien release may be required if the adjustments will not result in a systemic release within 30 days of receipt of the final plan payment.



### Note:



Under IRC 6325, Release of Lien or Discharge of Property, if the assessments for any periods are fully satisfied via full payment, were abated other than due to a bankruptcy discharge, or have become legally unenforceable because the Collection Statute Expiration Date (CSED) has expired, the IRS must release any liens securing these periods within 30 days.

4. If exempt, excluded, or abandoned assets are identified, Insolvency managers should ensure prompt action is taken to determine if such assets are worth pursuing, including appropriate investigation and valuation of the assets. (See IRM 5.9.17.5.3, Addressing Lien Issues, for specific time frames.) Once a determination is made not to pursue such assets, managers should ensure that caseworkers are initiating closing actions to adjust the dischargeable modules within 30 days of the determination, which will result in a systemic release of the lien. Generally, manually requesting a lien release is not required. However, if a certificate of release will not be systemically issued, the release should be requested manually on ALS. Monthly checking of the Lien Research report will identify NFTLs that have not been released so corrective actions can be taken.

5. Chapter 7 and Chapter 13 cases discharged by the court will be run through ADS by the CIO twice a week. ADS processing allows all discharged cases in these chapters to be reviewed by the same standards. Some circumstances may warrant a case's remaining open even though the court has entered a discharge. IRM 5.9.5.4(6), Classifications and Summary Histories, explains procedures for these cases. A majority of cases are closed systemically as either non-dischargeable and a TC 521 is input, or dischargeable and a TC 971 is input followed by a TC 521 after a two-cycle delay. Discharge determination reports (DDRs) are generated for cases that cannot be fully processed without caseworker intervention. Insolvency caseworkers must begin resolving DDRs within 30 calendar days of the IRS’s receiving notification of discharge. (See IRM 5.9.17.4, Time Frames for Required Actions.) Those DDRs for accounts assigned to the CIO and involving complex issues should be forwarded to the appropriate Field Insolvency office for resolution. The review frequency for DDR resolutions on specific cases is set by the CIO Operation Manager. IRM 5.9.18, Automated Discharge System (ADS), outlines procedures for running ADS and resolving DDRs.

6. A Field Insolvency caseworker evaluates the government's interest in exempt, excluded, or abandoned property if an NFTL:



1. Was filed before the bankruptcy action began;

2. Is valid; and

3. Contains Unpaid Balance of Assessments (UBA) that exceed the established tolerance.


7. Attempts to collect the value of the interest may be made through direct contact with the taxpayer or taxpayer's representative, or the case may be referred to Field Collection via an Other Investigation (OI).



### Reminder:



Excluded property in the form of Employee Retirement Income Security Account (ERISA) style pension plans with anti-alienation clauses does not require the IRS to have an NFTL on file before pursuing collection action. Field Insolvency caseworkers work these cases themselves usually eliminating the need to issue an OI. (See IRM 5.9.17.5.4, Insolvency Levy Procedures for Excluded Retirement Plans.)


**1.4.51.15** **(02-12-2020)**

### Controls

1. An important aspect of workload management and quality control for Insolvency managers is the establishment of group controls and reviews. Use the EQ managerial review process to conduct case reviews.

2. Use AIS and BOE reports to monitor and maintain controls in these areas:



   - Pyramiding

   - Collection Statute Expiration Date (CSED)

   - Assessment Statute Expiration Date (ASED)

   - Large Dollar

   - No touch/activity for specific time period

   - Higher graded duties


3. Take corrective actions when warranted. Any negative trends identified should be addressed on an employee by employee basis. Managers should also utilize the Tech Review Follow-Up report to monitor ongoing case activities.

4. Insolvency must protect assessment statute expiration dates (ASEDs) and collection statute expiration dates (CSEDs). For information on ASEDs and CSEDs including the effect of BAPCPA on cases filed on or after October 17, 2005, see IRM 5.9.5.7, Serial Filers, IRM 5.9.4.3.1, BAPCPA and BRA 94’s Effect on Assessments, and IRM 5.9.6-6, TC 520 Input Guide for Trustee Turnover Requests.



### Note:



Statutes, while usually suspended for the debtor during the pendency of a bankruptcy, are not suspended for the non-debtor spouse, with exceptions occurring in community property states. If action is warranted against a non-debtor spouse and time allows, consideration should be given to creating MFT 31 mirror modules so assessment or collection may proceed.

5. Once established, these control reports can be utilized to identify cases needing regular review and follow-up by the manager. Reviews should address issues such as:



1. Are timely and effective actions being taken to appropriately resolve the case?

2. Is the accuracy of high priority cases (CSED, ASED) being verified?

3. Are taxpayer rights being observed?

4. Is the employee providing good customer service?


**1.4.51.15.1** **(02-04-2025)**

#### ASED Accounts

01. A Trust Fund Recovery Penalty (TFRP) Assessment Statute Expiration Date (ASED) is generally three years from the date a return is filed or the due date of the return, whichever is later, for quarterly periods involving trust fund 941s, collected excise taxes, and annual 943s and 944s with trust fund tax. (See IRM 5.19.14.2.2, Trust Fund Recovery Penalty Statute of Limitations.)

02. Generate the ASED Follow-Up report from AIS Business Objects at least quarterly to identify accounts where the ASED for the TFRP will expire within the next twelve months.

03. Caseworker identification and history documentation of debtors with trust fund liabilities upon initial case review is essential because the ASED may be imminent. (See IRM 5.9.6.11.3, Initial Case Review of the 7A Business Case by FI, IRM 5.9.8.4, Initial Case Review for Chapter 11, and IRM 5.9.9.3.2(8), TFRP Actions for Debtors.)

04. Where trust fund taxes are an issue and a TFRP investigation has not been initiated by Field Collection, Field Insolvency must identify and document potentially responsible officers for the IRC 6672, Failure to Collect and Pay Over Tax, or Attempt to Evade or Defeat Tax, penalty. (See IRM 5.9.5.4(2), History Documentation.)

05. Managers must ensure information concerning in-business individuals and entities responsible for paying trust fund taxes are documented on AIS and tracked appropriately throughout the life of the bankruptcy.

06. If an ASED is identified as having expired while a case is governed by the bankruptcy freeze, the procedures in IRM 5.7.3.9, Reporting Expiration of the TFRP Statute, should be followed by Insolvency caseworkers.

07. The automatic stay indirectly prevents the IRS from assessing non-agreed proposed deficiencies on pre-petition periods because the time to file a Tax Court petition is tolled by the stay against the commencement or continuation of a Tax Court case. Examination staff monitor these unagreed proposals via a computer system called the Insolvency Noticing System (INS) generated by the Examination Returns Control System (ERCS). The Bankruptcy Exam Coordinator (BEC) in Technical Services, normally a revenue agent, coordinates with the Insolvency function to ensure the "Open Exam" field on the AIS Taxpayer screen indicates "Yes" when an examination is pending.

08. Revenue agents and office examiners are instructed to contact the BEC when they identify TC 520s on audit transcripts or learn through the audit process a taxpayer is in bankruptcy. The information is passed on to Insolvency so the case can be added to AIS or updated and monitored until the proposed deficiency may be assessed.



    ### Note:



    Assessment is allowed if the debtor agrees with the proposed deficiency, the court closes the bankruptcy case thereby lifting the automatic stay, or the court establishes the liability.

09. A process similar to that of field Examination governs Campus controlled cases. Campus exam cases are usually controlled by Campus correspondence units and the Automated Underreporter (AUR) units. Insolvency must coordinate actions with the lead of each SB/SE Campus group for correspondence cases and with the lead of each Campus AUR group.

10. Campus Examination employees have access to AIS to monitor modules with open controls on IDRS. Campus employees contact Insolvency caseworkers with the status of underreporter proposed deficiencies if they have not received agreements to their statutory notices of deficiency. Cases pertaining to pre-petition periods receiving no response are classified as unagreed cases and are barred from assessment during the pendency of the bankruptcy if the bankruptcy petition was filed prior to the expiration of the time period for filing a petition in tax court.

11. Some Campus Exam units have been provided with read-only access to AIS and have received sufficient training to allow them to determine the status of a case without contacting Insolvency. Other Campus Exam units without AIS access or skills may monitor the proposed assessments in suspense status and contact Insolvency periodically for an update of the bankruptcy status.

12. Tax Equality and Fiscal Responsibility Act (TEFRA) generally applies to partnership examinations for partnership taxable years beginning prior to January 1, 2018. After a partner files a bankruptcy petition, the IRS has at least one year to assess a TEFRA deficiency. While the bankruptcy rules provide the IRS is to receive notice of all Chapter 11 cases, no specific requirement exists for the debtor to provide the government notice of the bankruptcy in all TEFRA cases. These cases require immediate Insolvency attention when they are identified. Insolvency should consult the Bankruptcy Exam Coordinator (BEC) for guidance.

13. Insolvency caseworkers are charged with:



    1. Recognizing imminent ASEDs

    2. Initiating actions to ensure ASEDs are protected;

    3. Monitoring trust fund ASEDs as long as the taxpayer is complying with the terms of a Chapter 11 plan (See IRM 5.9.8.11, Trust Fund Considerations in Chapter 11);

    4. Coordinating with Field Collection if appropriate (See IRM 5.9.6.15, Trust Fund Recovery Penalty, and IRM 5.9.8.11, Trust Fund Considerations in Chapter 11); and

    5. Notifying the BEC when a bankruptcy case with a pending deficiency assessment closes allowing the BEC to proceed with the assessment before the ASED expires.


**1.4.51.15.2** **(02-04-2025)**

#### CSED Accounts

1. Generate a report from AIS Business Objects at least semi-annually to identify accounts for which the Collection Statute Expiration Date (CSED) will expire within the next twelve months. (See Field Insolvency Report Job Aid) Review those cases to:



1. Verify the accuracy of the CSED, and take corrective action if needed, including updating the CSED field on the AIS Taxpayer screen with the correct CSED, and/or taking actions as described in paragraph (2) below.

2. Ensure that timely and effective action is taken.


2. The CSED displayed may be invalid in certain cases. The CSED shown is always for the earliest assessment on the module. If that assessment is paid, the true CSED is for a later assessment (for example, an adjustment or deficiency assessment). If that is the case, request command code CSEDR to eliminate erroneous CSEDs from future monthly reports.

3. **CSED Extensions**. Typically the time for which a bankruptcy stay is in effect plus six months is added to the collection statute after the stay of collection is terminated. IRM 5.9.4.3, ASED/CSED, provides more information on CSED computations.

4. **Imminent and Expired CSEDs**. The procedures outlined in IRM sections 5.1.19.5 through 5.1.19.5.6 should be followed when addressing imminent (CSED will expire in 12 months or less) or expired CSEDs under the bankruptcy freeze, substituting the words "Insolvency caseworker(s)" for "revenue officer(s)" .



   - If the statute expires, see IRM 5.16.1.2.2.5, Report of Statute Expiration.

   - Should a CSED expire without prior approval, follow procedures in IRM 5.1.19.5.5, Collection Statutes That Expire Without Prior Approval. The memo should be prepared and routed as follows: a) Field Insolvency from group manager to Territory Manager, and, if warranted, to the Director. b) Centralized Insolvency Operation from unit manager to Department Manager, to Operation Manager, and, if warranted, to the Director.


**1.4.51.16** **(02-04-2025)**

### Quality

1. The IRS vision focuses on three high level goals: service to each taxpayer, service to all taxpayers, and productivity through a quality work environment. The IRS has developed a set of Balanced Measures in three major areas: Customer Satisfaction, Employee Satisfaction, and Business Results. Business Results is comprised of measures of quality and quantity. In reaching our goals we consider our impact on customer and employee satisfaction while we strive to improve quality and achieve quantifiable results. The Embedded Quality (EQ) process was developed to support Balanced Measures objectives.



1. EQ is a tool designed to assist managers in identifying areas of strength and need in their employees’ individual performance. Employee performance is evaluated against attributes that are designed to identify actions that move cases toward closure through appropriate and timely case activity. The attributes link individual performance to organizational goals and are used by both managers and National Quality Reviewers to assess significant case actions.

2. EQ enables the manager to measure the quality of both individual and group performance. It allows National Quality Review to assess the quality of the function to facilitate recommendations for improvement through policy changes, training, and updated procedural guidelines.

3. The focus of EQ is on improving performance while the performance occurs. The attributes can be measured on open or closed cases. EQ is designed to identify gaps in quality case work at the earliest point in activity. It assists the manager in targeting corrective steps that positively impact performance.

4. To conduct employee case reviews, managers use the Embedded Quality Review System (EQRS) to rate case actions against the attributes. EQRS also provides managers with tools to capture and share review feedback to show employees how they performed in relation to both the attributes and their CJEs. This should assist managers in providing employees with specific examples of how to sustain or enhance their performance.


2. An important aspect of workload management and quality control for Insolvency managers is the establishment of group controls and reviews. Use the EQ managerial review process to conduct case reviews.

3. Managers are responsible for the quality of all work assigned to their group and for all work which leaves their group regardless of the methods used. Managers must devise a system of quality control which works for them. Consider the following:



1. Encourage employees to work with their manager to improve the quality of their work.

2. Solicit suggestions from the group to address ways that can improve the quality of the work.

3. Develop a plan to ensure a high level of quality in the group.

4. Use Embedded Quality Review System (EQRS) reports available through EQ systems as diagnostic tools to focus attention on specific quality issues and identify training needs. The EQRS application used by front line managers and the NQRS application used by centralized reviewers mirror each other and feature numerous reporting capabilities. The SCI Director and their staff will compare NQRS to EQRS cumulative results to identify opportunities for improvement in each measurement..



      ### Example:



      If specific aspects of NQRS reports for a certain Area Office start to decline, area, territory / operation or department, and even group results for the same aspect measured under the managerial EQ review can be viewed to help isolate potential root causes.


4. Ensure appropriate time is devoted to coaching and mentoring employees, as well as providing guidance that will assist in resolving their most difficult assignments.

5. Reviews can help determine an employee’s needs for training and development. This will help decide how much time to devote to each employee.

6. Choose from the following reviews and controls in designing a plan:



1. Attendance to FMC (face to face or via ZOOM).

2. Office observations.

3. Spot reviews of open and closed cases.

4. Formal inventory analysis.

5. Time utilizations.

6. Reviews of work submitted for approval.

7. Initial contact reviews.

8. TFRP cases pending determination or recommendation.

9. Regular reviews of high priority cases (ie. discharge determinations, collection determinations of EAEP, referrals to Counsel or DOJ, objection to plans CSED, ASED, ).


**1.4.51.16.1** **(08-11-2015)**

#### NQRS

1. National quality reviewers use a similar web-based system called the National Quality Review System (NQRS). A cornerstone of EQ is that quality reviewers and managers use the same basic set of attributes. This should minimize the concern that national reviewers are applying different criteria than managers when reviewing cases. However the national quality reviews will **not** be used to evaluate individual employee performance. NQRS attributes are not linked to employee CJEs; instead each attribute is mapped to one of five Quality Measurement Categories:



1. Timeliness

2. Professionalism

3. Procedural Accuracy

4. Regulatory Accuracy

5. Customer Accuracy


**1.4.51.16.2** **(02-12-2020)**

#### EQ Consistency Reviews

1. Consistency Reviews will be conducted to assist users in rating EQ attributes consistently by using the Attribute Job Aids, EQ website guidance, Critical Job Elements, and IRMs. Managers may participate in one or more EQ consistency reviews each year. The goal of consistency reviews is to improve the understanding and application of the EQ rating guidelines. Group managers and Territory managers within a territory will review the same case, compare attribute results, and discuss how rating guidelines can be applied to achieve consistency on attributes where significant rating inconsistencies occurred.

2. Territory managers will schedule and conduct EQRS consistency reviews with group managers annually. The Area Director may add additional reviews when consistency among managers needs improvement. Consistency reviews require all managers within a territory to review the same case to compare attribute results and discuss how rating guidelines can be applied to achieve consistency. Refer to IRM 5.13.1.1.3, Roles and Responsibilities, and IRM 21.10.1, Embedded Quality (EQ) Program for Accounts Management, Campus Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support, for review procedures and guidelines.

3. Document the review by preparing a written narrative to include the date the review was completed, observations, and actions taken to achieve consistent application of EQ attributes.

4. Refer to IRM 5.13.1, Embedded Quality Collection Field Organizations Administrative Guidelines, and IRM 21.10.1, Quality Assurance - Embedded Quality (EQ) Program for Accounts Management, Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support for information and guidance about EQ.


**1.4.51.16.3** **(02-12-2020)**

#### Employee Case Documentation

1. It is extremely important that case documentation is timely, clear, accurate, and complete.

2. Managers must direct subordinates to document all actions related to the IRS's involvement in a bankruptcy proceeding in the AIS History screen. Insolvency is the primary repository of bankruptcy-related case actions for all functions of the IRS. (See IRM 5.9.5.4, Automated Insolvency System (AIS) Documentation.)

3. Incomplete documentation will negatively affect:



1. Subsequent employee case actions.

2. Ability to review and evaluate case activity.

3. Actions by other employees.

4. Quality Review System results.

5. Cases presented in legal proceedings.


### Example:

Ensure that employees clearly document the reason(s) why they have determined that the filing of a NFTL is not appropriate.

**1.4.51.17** **(02-04-2025)**

### Operational Reviews and Employee Engagement

1. The purpose of operational reviews is to evaluate the business unit’s performance toward achieving organizational goals and compliance with administrative requirements. Operational reviews are used to monitor and document progress toward achieving organizational goals and objectives.

2. Operational reviews are expected to be participatory. Optimally, they will encourage participation from each level of management and employees in SCI, providing an opportunity for stakeholders to address business priorities, objectives and timely implementation of actions designed to accomplish these objectives. The context of operational reviews is to provide high-level feedback to the functions reviewed. Operational reviews also may be a component of a manager’s performance appraisal.

3. In SCI, Territory / Operation / Department Managers ordinarily will perform operational reviews of their respective assigned areas. This high-level review assesses the department's / group's performance, provides guidance and direction intended to improve business results, fosters effective casework, managerial engagement and may assist in assessing managerial effectiveness. Additionally, the review may be used to identify trends, assess skills, determine training needs, and assess the department's / group's overall performance, including efficiencies and quality. DM / GM communication and leadership of the group also may be addressed in this process. A primary focus of the operational review should be on assisting the department or group manager improve performance and quality of case actions

4. Territory / Operation / Department Managers have oversight responsibility for program delivery as well as administrative/compliance conformance.



   - **Program Delivery** focuses on department / group operations and ensuring appropriate guidance and direction is provided to Department / Group Managers to assist them in successfully delivering the program outlined in the Business Plan and Letters of Engagement.

   - **Administrative/Compliance Conformance** focuses on ensuring adherence to servicewide managerial requirements and law, regulation, policy, or any other requirement established by the Program Director. Such items may or may not be directly related to program delivery


**1.4.51.17.1** **(02-04-2025)**

#### Frequency and Planning

01. Operational and/or administrative/compliance reviews must be conducted during the fiscal year as a single phase comprehensive review or an on-going series of multi-phased reviews that focus on specific aspects of the group's performance.

02. When developing a department / group operational review plan, consider the experience level of the DM / GM and the Department's / Group's overall current performance. Additionally, Territory / Operation / Department Managers that are new to the existing departments / groups should conduct a review that will increase their familiarity with the departments / groups in the territory / operation / department. The review plan will be tailored to the needs of each department / group to assess progress on objectives, safeguard the continued development of employee skills, timely and accurate customer service, and the continued enhancement of department's / group's performance in quality and productivity.

03. Provide a framework for the department / group operational reviews at the beginning of each fiscal year based on the above criteria.

04. Confer with the Director for concurrence on a plan that is tailored for each department's / group's unique circumstances. Plan the review based on analysis of territory / operation / department and group performance results and program trends. A variety of management information systems (MIS) reports can assist in determining areas of focus for the review.

05. Information from periodic DM or GM briefings may be incorporated in a multi- phased approach. Briefings are an optional method used to ensure periodic communication on group progress and other areas of interest.

06. Feedback about operational review findings is expected to occur continuously throughout the review cycle.

07. When determining how to maximize the benefits of the operational review, SCI Managers (Territory / Operation / Department) may take into consideration the known strengths and opportunities for improvement for the department / group being reviewed. Territory / Operation / Department Managers should exercise their professional judgement when selecting the supplemental review elements supporting the strategic plan by providing the Department / Group manager with actionable guidance and measurable goals.

08. Critical items that should be addressed in each department / group operational review should be aligned to the Servicewide Balance Measure and management responsibilities. See table below:




    | **Balance Measure** | **Management Responsibilities** |
    | --- | --- |
    | Customer Satisfaction | Customer Service and Collaboration |
    | Employee Satisfaction | Leadership and Human Capital |
    | Business Results | Program Management |

09. Several review elements can be performed remotely using the appropriate computer applications. Examples of review items which may be performed remotely include but are not limited to:



    - case reviews

    - performance appraisals

    - Leadership Succession Review plans

    - EQRS

    - inventory reports


10. In addition, you may delegate review elements to your administrative assistant or a SMRP candidate as developmental assignment.



    ### Example:



    Review of employees personal file (EPFs) to determine if the files contain the required documents can be performed by the Territory / Operation / Department’s administrative assistant by designating the employee as proxy in the eEPF system.





    ### Reminder:



    The Program Director has the discretion to establish one or more of the functional elements described in sections _IRM 1.4.51.17.3_, Leadership and Human Capital-Employee Satisfaction to _IRM 1.4.51.17.4_, Administrative / Compliance Review as mandatory for a specific review.


**1.4.51.17.2** **(02-04-2025)**

#### Documentation

1. When using a comprehensive review option, one narrative will be prepared to document findings conclusions and recommendations.

2. When using the multi-phase approach, prepare a narrative to document each component at the time the review is completed. Territory / Operation / Department Managers may choose to review program aspects across the territory / operation / department and provide department / group specific feedback or review targeted aspects for a specific department / group.



### Example:



Territory / Operation / Department Managers may conduct reviews of specific program aspects, such as discharged cases with unreleased NFTL, or providing department / group specific feedback.

3. The narrative should be written with the DM / GM as the intended audience. Attachments that provide additional detail may be used as appropriate. Action items communicated to the department / group manager must include a description of the action to be performed and a due date for completion.

4. The format of the operational review generally will begin with identifying the department / group reviewed, the evaluative period, and a summary of the review. Any due dates for a response will be communicated in the summary of the review. The narrative should address each responsibility contained in the Management Performance Agreement. While each SCI Territory / Operation / Department Manager may choose their own format for the narrative, the narrative may be outlined as follows:



   - Introduction

   - Leadership and Human Capital

   - Employee Engagement

   - Customer Service and Collaboration-Customer Satisfaction

   - Program Management-Business Results

   - Administrative Compliance

   - Conclusion


5. Each responsibility should be supported by a review component. The narrative for each responsibility should address whether the responsibility is being met and provide actions the manager will take to ensure the objective is met, if necessary. During the review, the DM / GM will be provided with an opportunity to describe their process related to the elements reviewed and the SCI Territory / Operation / Department Manager can address the effectiveness of those processes and make recommendations where necessary.

6. The narrative should be shared with the department / group manager within **60 days** of completing the actual review.


**1.4.51.17.3** **(06-25-2025)**

#### Leadership and Human Capital-Employee Satisfaction

1. Department / Group managers are responsible for creating a workplace culture of professionalism where employees are treated with dignity and respect. Assess the DM’s / GM’s performance management in providing meaningful feedback to employees by completing performance reviews which encourage employee engagement and the timely completion of mid-year and annual performance evaluations. When rating this responsibility, determine if the DM / GM is completing the required reviews timely, address the feedback provided by the DM / GM to the employee and whether the employees are providing feedback.

2. Critical items in each department / group operational review will be aligned to the Servicewide Balance Measure and management responsibilities. See table below




| **Employee Satisfaction Components** | **Review Description** |
| --- | --- |
| Case reviews | - The Program Director, Territory, Operation, Department managers will determine what is the appropriate sample size for case reviews based on the current number of departments / groups and prior/current year EQ/NQ results.<br>     <br>   - The reviews will assess whether the case is moving toward a logical resolution, if the employee is using appropriate workload management techniques, and whether there are any trends that may be adversely impacting group performance.<br>     <br>   - The Territory / Operation / Department review is a high-level review that considers if actions taken on the case are appropriate and are effectively moving the case toward a logical and appropriate resolution.<br>     <br>   - As part of the case review process, customer service considerations may be assessed by :<br>     <br>     <br>     <br>     1. determining if timely initial case analysis was conducted and whether the employee has been responsive to the taxpayer, the debtor’s attorney, or trustee requests. These can be indicators that customers are receiving timely actions and are receiving fair and equitable treatment from the employee to assist in bringing their case to an appropriate resolution.<br>        <br>     2. the accuracy of the GM's EQ attribute review and if proper direction was given by the GM as part of the review may verify whether the employee appropriately observed the taxpayer’s rights to representation.<br>        <br>   - Territory / Operation / Department Managers may also include “mirror” reviews of cases which the GM has already reviewed to assess the accuracy of the GM's EQ attribute review and if proper direction was given by the GM as part of the review<br>     <br>   - Territory / Operation / Department Managers may utilize the EQ review reports to help determine if the GM reviewed the appropriate number and mix of cases during the mid-year and annual appraisal segments. This also may be accomplished at the mid-year if the Territory / Operation / Department Manager has elected to approve the mid-year appraisal of each employee. (See _IRM 1.4.51.5.2.2_, Requirements for Annual Performance Case Reviews.)<br>     <br>   - Ensure that managers are addressing TP rights, particularly when attending First Meeting of Creditors (FMC) or during telephonic contact with the taxpayer. |
| Communication | - Look for indicators that DMs / GMs are effectively communicating procedure and policy changes affecting overall quality of work.<br>     <br>   - Assess the quality of DMs / GMs guidance concerning effective case resolution.<br>     <br>   - Review group meeting minutes to determine if area and territory / operation / department information is shared as appropriate. This may include addressing issues identified during survey discussions, dissemination of appropriate EEO practices including, but not limited to: reasonable accommodation, hardships, EEO, etc. Discussion of training, employee development, Career Learning Plan (CLP), timely feedback to employee, timely evaluations, inventory ranges and assignment practices.<br>     <br>### Note:<br>These areas may be addressed during periodic briefings and can be confirmed when the employees assigned to the GM or DM complete their mandatory briefings. Territory / Operation / Department Managers may also wish to conduct focus group, town halls and/or individual discussions to evaluate whether key information and messages are delivered in a timely and appropriate fashion. These mechanisms have a direct impact over employee satisfaction, which is a component of IRS Balance Measures. |
| Employee Performance File | - Determine if the OPM guidelines for document retention and items included in EPF have been followed.<br>     <br>   - Evaluate whether performance documentation supports the appraisal rating.<br>     <br>   - Verify that the appropriate reviews have been conducted and at the appropriate time. |
| Annual Appraisal/Performance Document Approval | - Territory / Operation / Department Managers are responsible for ensuring timely feedback and appropriate ratings of employees. This should be an ongoing process during the year through approval of the annual rating.<br>     <br>   - Ensure consistency between the Form 12450, Responsibilities and Commitments, Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request, with critical job element rating/narrative and the performance documentation contained in the EPF.<br>     <br>   - Ensure that the GM has a review schedule that includes all required reviews such as mid-year and annual appraisals. A mutually agreeable review schedule should be established at the beginning of each fiscal year.<br>     <br>   - Ensure that GMs conduct mid-year reviews between the 5th and 7th month of the rating cycle. Annual reviews/ratings must be completed for bargaining and non-bargaining employees within the scheduled time limits shown in Exhibit, 6.430.2-4 Performance Appraisal Due Dates. Discuss GM compliance with review schedules during periodic briefings and document compliance in the operational review annual narrative. |


**1.4.51.17.3.1** **(06-25-2025)**

##### Employee Engagement

1. Employee engagement is “a human resources concept that describes the level of enthusiasm and dedication a worker feels toward their job”. Engagement is not a thing in itself but the outcome of an environment where leaders listen to and lead employees, help them develop, provide them with the tools and the support they need to do their jobs, and implement their solutions where possible. Each management responsibility includes a component of employee engagement. High levels of employee engagement correlates to higher levels of quality and productivity with an enhanced result of achieving the goals and objectives of SCI. The four pillars of engagement are:



   - Listen: Foster a culture in which all employees feel valued, respected and ideas are heard.

   - Develop: Promote career progression and rotation opportunities that share knowledge, retain talent, accelerate advancement on top performers and build future leaders.

   - Lead: Ensure managers are trained and equipped to effectively lead, manage and engage their teams.

   - Support: Assist employees in quickly resolving issues by providing them with the resources and tools needed to provide exemplary customer service.


2. The engagement part of the operational review assesses the DM’s / GM’s actions in leveraging employee feedback and collaboration with stakeholders in resolving issues and communicating changes affecting their departments / groups. Evaluate if the DM / GM is communicating performance expectations through scheduling recurrent meetings and written communications. The DM / GM should establish additional channels and opportunities to listen to employees’ ideas and issues and demonstrate how their feedback is thoughtfully considered. Address the DM’s / GM’s approach in promoting access to training and developmental opportunities for all employees. Ensure DM / GM discuss with their employees the different vehicles available for employee’s advancement such Career Learning Plan (CLP) and Leadership Succession Review (LSR) and other servicewide training programs.




| **Employee Engagement Pillars** | **Review Description** |
| --- | --- |
| Listen | - Confirm the DM /GM is conducting meaningful meetings to communicate expectations by reviewing group meeting minutes and other communications issued by the DM / GM. Look for proactive methods to increase and promote employee engagement such as roundtable sessions, one-on-one sessions focused on topics of interest, whether employees are provided an opportunity to either present or lead the group meeting. Ensure recent changes in procedures and policies are being communicated in a timely manner.<br>     <br>   - Territory / Operations Managers should schedule town hall meetings with each group (could be more than one group when they are located in the same POD). The town hall can be combined with a lunch and learn activity to create a positive team spirit, increase participation and collaboration. |
| Develop and Lead | - Assess the use of developmental tools such as CLP, LSR and acting DM/GM opportunities. Ensure DM / GM follow-up on developmental activities established in CLPs. Confirm that DM / GM has an equitable process for affording OJI, classroom instructor details, temporary assignments, etc.<br>     <br>   - Assess the DM’s / GM’s employee recognition program when using discretionary time off awards, e-cards, and other non-monetary recognition tools. |
| Support | - Ensure DM / GM assess employee skill gaps and provide opportunities for improvement with workshops, online trainings, coaching and mentoring.<br>     <br>   - Confirm that DM / GM is timely addressing requests for reasonable accommodations according to current policies and procedures.<br>     <br>   - Ensure employees have the most current information during natural disasters and discuss annually the emergency occupancy plan.<br>     <br>   - Encourage DM / GM to periodically take time to celebrate accomplishments. |


**1.4.51.17.3.2** **(02-04-2025)**

##### Customer Service and Collaboration-Customer Satisfaction

1. Customer satisfaction is measured by the customer’s perception and level of overall satisfaction with their interaction experience. Customers are both internal and external to the IRS. High customer satisfaction translates into work group efficiencies and improving the public’s trust in the tax system. Customer satisfaction is the cornerstone to the IRS’s mission to provide top quality service to taxpayers by helping them understand their tax responsibilities with integrity and fairness to all. Metrics used to measure customer satisfaction include quality, regulatory compliance, and customer feedback. Both DMs / GMs and employees can improve customer satisfaction by identifying issues or risks for resolution. The following list suggests possible areas that may be addressed in the annual operational review:




| **Customer Satisfaction Component** | **Review Description** |
| --- | --- |
| 1204 | Section 1204 of the Restructuring and Reform Act of 1998 prohibits the IRS from using any ROTER to evaluate employees or to impose or suggest production quotas or goals. It requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard and requires each appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner.<br> <br>   - Confirm the DM / GM timely completed quarterly 1204 certifications.<br>     <br>   - Confirm employees’ annual performance evaluations are free from ROTERs. |
| Quality | Quality should be analyzed using available EQRS reports. These resources can be used to identify trends that may need further attention. Department / Group managers may participate in at least one consistency review. |
| Sensitive Case Report | - Sensitive case reports (SCRs) are used to notify leadership of investigations of high-profile taxpayers, or in instances where the filing of the bankruptcy is likely to attract media attention, involve large dollars, the issue is novel/unique and may affect many taxpayers.<br>     <br>   - Review the SCRs prepared by the DM / GM during the rating period. Confirm updated reports where prepared when necessary and final reports were issued when appropriate. |
| Additional Considerations | - Accompany the caseworker when attending the FMC (in-person or via ZOOM).<br>     <br>   - Annual time utilization reviews conducted. |


**1.4.51.17.3.3** **(02-04-2025)**

##### Program Management-Business Results

1. The IRS assesses operational level business results through output, quantity and quality measures. The IRS uses organizational measures as an analytical reference to determine whether the actions taken achieved the desired performance result. The focus of the evaluation of the business results responsibility is based on the actions taken and related accomplishments toward meeting the organizational goals of SCI. There are several performance measures available to management to evaluate the Department’s / Group’s efficacy. Territory Manager / Operations Manager should communicate the areas of emphasis with their department / group managers at the beginning of the fiscal year and monitor the department’s / group’s performance at reasonable intervals throughout the rating period.

2. The operational review should speak to the DMs / GMs effectiveness in managing the performance components. The narrative should address whether performance components have been met or not met. In instances where a performance component is not met the review narrative must recommend actions to the DM / GM to improve the performance in that component. Action items assigned to the DM / GM should be aligned to the DM / GM needs to improve the group’s performance in a specific component rather than action items in specific cases.




| **Business Results Components** | **Review Description** |
| --- | --- |
| Timely Protection of Statutes<br> <br>   - Bar Date (BD)<br>     <br>   - Assessment Statutory Expiration date (ASED)<br>     <br>   - Collection Statutory Expiration date (CSED) | Territory / Operation / Department Managers can review a sample of cases to determine if the caseworkers are protecting, when appropriate BD, CSED and ASED. Territory / Operation / Department Managers will ensure that DMs / GMs have in place appropriate controls to monitor statutes. |
| Group Productivity and Efficiency | Conduct an analysis of the group’s efficiency in case resolution using productivity and cycle time reports. Productivity measures are a result of case work efficiencies, including simultaneous case actions, closing cases in a timely manner, and working cases with resolution in mind. |
| Group Time Reporting and Analysis | On a monthly basis or as directed by the Program Director review time reports to evaluate a group’s use of Direct Time, Administrative Time, etc. These items may be addressed during periodic briefings as well.<br> <br>### Note:<br>Field Insolvency employees report their specific program time in the Integrated Collection System (ICS) and use the Single-Entry Time Reporting (SETR) system to report their time and attendance. CIO employees report all their time in SETR, ensuring specific program times are separately out by the Organization Function Program (OFP). |
| Inventory and Case Assignment | - Ensure GMs balance their CAG regularly to ensure confirm receipts are within an acceptable level for the grade and chapter assigned to each employee. Verify that employees are not spending more than 25% of their time each month on work above their grade level.<br>     <br>   - For DMs ensure employees are processing payments and taking case actions timely.<br>     <br>   - TM / GM / OPS Manager will ensure that there is appropriate span of control maintained for their respective areas. |
| BOE report analysis | - Conduct analysis of mandatory BOE reports in areas such as inventory management, timely lien releases in discharged cases, timely case actions and other performance indicators.<br>     <br>   - Identify possible case trends and provide guidance designed to achieve department or territory targets/objectives.<br>     <br> Observation and results of the analysis may be addressed during periodic briefings with the group / department manager and then summarized in the operational review narrative. |


**1.4.51.17.4** **(02-04-2025)**

#### Administrative / Compliance Reviews

1. Administrative / Compliance Reviews are used to monitor and document oversight of operational items not included in operational reviews. Territory / Operation / Department Managers are required to provide oversight for Administrative / Compliance review areas. These reviews may be conducted at any time during the fiscal year.

2. Document results of mandatory Administrative / Compliance review items in a clearly identified subsection of the annual comprehensive operational review or prepare a separate narrative review (at least annually) to summarize results.

3. Documentation is required for those items noted as mandatory as well as items for which findings indicate non-compliance and/or a need for improvement.

4. Common components that may become part of the administrative portion of the operational review include but are not limited to:




| **Component** | **Description** |
| --- | --- |
| Timekeeping / SETR | Review the DM / GM control timekeeping process to ensure that established timekeeping guidance is being followed IRM 6.630.1, IRS Absence and Leave. |
| Security | Responsibilities include, but are not limited to:<br> <br>   - Verification of DM / GM after hours security checks and subsequent remedies.<br>     <br>   - Verification that DM / GM has reviewed BEARS accesses and need for access to all computer systems for their employees. (See IRM 10.8.1.4.1.1, AC-02 Account Management.)<br>     <br>   - Ensuring that taxpayer returns and other SBU data is protected. (See IRM 10.5.1.4.1, Employees/Personnel.) |
| Correspondence / File Retention | Identify the DMs / GMs correspondence and file retention procedures to ensure they comply with Document 12990, Records and Information Management Record Control Schedules. |
| Travel Vouchers / Authorizations | Ensure that the DM or GM is approving authorizations and vouchers timely and monitoring for correct coding, receipts, and expenses that are appropriate. (See IRM 1.32.1, IRS Local Travel Guide.) To request a ConcurGov report, send an email to: \*cfo.fms.electronic.travel.systems. When requesting a report remember to include:<br> <br>   - The name of the report needed<br>     <br>   - The organization code(s) to include in the report.<br>     <br>### Note:<br>For a list of frequently requested report descriptions, please visit: ConcurGov Reports |
| Purchase Cards / Supplies Order | Review the department’s / group’s purchase card procedures to verify they are following established guidance. (See IRM 1.35.3.3.2, Receipt Documentation.) |


**1.4.51.18** **(02-04-2025)**

### Director Performance Reviews and Employee Engagement.

1. During the fiscal year, SCI Director should perform a comprehensive review of all Insolvency operations. The Director performance review is used to identify and effect positive change in performance as well as to evaluate the managers impact on employee satisfaction, employee engagement, customer satisfaction and business results.

2. The Technical Analyst assigned to the Director can assist by monitoring performance metrics and identifying trends which may require managerial involvement to achieve the goals and objectives of SCI.

3. Perform follow-ups as necessary based upon action items assigned to Field Territory Managers and CIO Operations Manager.


**1.4.51.18.1** **(02-04-2025)**

#### Planning and Documentation

1. Provide the Territory / Operations Manager a copy of your planned review schedule.

2. Document the performance review in a memorandum to the Territory / Operations Manager within 60 days of completion of the review. If the review contains action items for completion by the Territory / Operations Manager, provide a response time frame for the required action item. The operational review should also include a candid discussion regarding the Territory / Operation Manager’s performance.

3. The performance review should address the responsibilities of the Territory / Operations Manager as they relate to the achievement of the program goals for SCI and proactive contributing to the Director’s Collection Business Plan. The table below provides an optional outline for the components of the area performance review:




| **Component** | **Elements** |
| --- | --- |
| Leadership | 1. Review operational reviews conducted by Territory / Operations Manager.<br>      <br>2. Address personnel actions to ensure proper processing and Labor Relations involvement where necessary. |
| Employee Satisfaction | 1. Assess whether Territory / Operations Manager addressed issues raised in the Employee View Point Survey.<br>      <br>2. Evaluate the LSR status report for the territory / operations and assess developmental opportunities provided to LSR participants. |
| Employee Engagement | 1. Confirm town hall meetings were held by the Territory / Operations Manager with each group in their territory / operations.<br>      <br>2. Address the Territory / Operations efforts to support the Frontline Manager Readiness Program (FLRP), Department Manager Readiness Program (DMRP) and Senior Manager Readiness Program (SMRP). |
| Customer Satisfaction | 1. Assess Territory / Operation Manager’s involvement in addressing customer service issues. This should be evident in operational reviews and discussions with Territory / Operation Managers.<br>      <br>2. Ensure Territory / Operation Managers are conducting EQRS Consistency Reviews annually with their respective department / groups and actions are taken to promote consistent application of the EQ attributes. Utilize cumulative data acquired during the fiscal year, identifying areas of achievement and those that require improvement.. |
| Business Results | 1. Determine if the Territory / Operation Manager is proactively contributing to the Director’s Collection Business Plan<br>      <br>2. Identify trends in accordance with Director’s goals and other pertinent indicators such as time utilization (direct, and administrative time), timely closure of discharged/dismissed cases, follow up reports, open cases where a lien has not been released, etc. |

4. Address additional programs and initiatives established by the Program Director that support the goals and objectives of SCI. Some examples include:



1. Training: discuss with Territory / Operation Manager what training has been made available to department / group managers.

2. Communication: review minutes of territory / operation meetings. Ensure Territory / Operation Managers are discussing special interest cases within their groups. Consider conducting focus group interviews with department / group managers and/or bankruptcy specialists.



      ### Note:



      The review areas listed above are not all inclusive. The Program Director may request review of additional items. (e.g., due to identifications of new or existing risks, changes in program goals and objectives, new legislation or emerging issues)


**Exhibit 1.4.51-1**

### Suggested Action Steps for Unacceptable Performance

| **If...** | **And...** | **Then...** |
| --- | --- | --- |
| During a workload review it is noted a performance deficiency or deficiencies based on employee's Critical Job Elements (CJE) (e.g. Protection of Public Interest, issue: filing of notice of lien and/or extension of NFTL determination) | N/A | The manager should…<br> <br>1. Take informal steps to correct performance deficiencies. The manager should determine if there are other factors that may have caused the identified deficiencies.<br>   <br>2. Counsel employee as to what is considered appropriate action on cases reviewed. Indicate which CJE or CJE's are identified as not being met at this time.<br>   <br>3. Schedule additional dates to review employee casework.<br>   <br>4. Require employee to obtain managerial approval to extend NFTL determination date (if applicable).<br>   <br>5. Continue to use AIS to identify lien indicator cases and perform a query of the cases on AIS. Indicators to check are:<br>   <br>   <br>   <br>   - When case received<br>     <br>   - When case assigned to an employee<br>     <br>   - When NFTL filed<br>     <br>6. All discussion(s) with employee must be fully documented and a copy of the documentation is provided to employee with a copy placed their EPF.<br>   <br>7. Continue to closely observe/monitor employee performance using managerial tools. |
| The manager continues to closely observe, monitor, review and correct (if necessary) the performance deficiency or deficiencies | the employee's performance improves | • No additional action needed |
| The manager continues to closely observe, monitor, review, and correct the performance deficiency or deficiencies | the employee's performance does not improve | 1. Begin formal counseling.<br>   <br>2. Consult with Labor Relations regarding the issuance of an opportunity letter to establish a formal period to show improvement to acceptable level of performance. The opportunity letter must include:<br>   <br>   <br>   <br>   - Critical elements/performance standards that are not acceptable.<br>     <br>   - Exact nature of deficiencies.<br>     <br>   - Improvement expected.<br>     <br>   - Fact that failure to improve could result in proposal to remove employee from current grade or even from the IRS.<br>     <br>   - A specific period of time to demonstrate acceptable level of performance (usually 90 days).<br>     <br>   - A stated commitment to work with employee.<br>     <br>   - If on Telework, suspension of Telework until performance improves.<br>     <br>3. With the continued assistance of Labor Relations, follow procedures outlined in Article 40, Unacceptable Performance, of the National Agreement - IRS/NTEU for BU employees.<br>   <br>4. Plan a review schedule. At this planning session discuss:<br>   <br>   <br>   <br>   - Number of reviews planned;<br>     <br>   - Types of reviews;<br>     <br>   - Types of cases to be reviewed;<br>     <br>   - Number of cases at each review;<br>     <br>   - Time frames for review schedule (one a week, twice a month etc.)<br>     <br>   - In summary, tailor the planned reviews to the needs of both the manager and the employee.<br>     <br>5. May continue to use AIS to identify lien indicator cases and perform a query review of the cases on AIS. Indicators to continue to check are:<br>   <br>   <br>   <br>   - When case received.<br>     <br>   - When case assigned to an employee.<br>     <br>   - When NFTL is filed.<br>     <br>6. Review, approve or disapprove (with comments) NFTL extension determination(s) made by employee (if applicable).<br>   <br>7. Document all reviews, provide copy of documentation to employee and place in their EPF. |
| The manager continues to closely observe, monitor, and review employee performance based on the provisions of the opportunity letter. | the employee's performance becomes minimally successful or fully successful | - Consult with Labor Relations personnel and issue a letter informing employee of this fact.<br>  <br>- If employee's Telework was suspended during this period, consider resuming the schedule. |
| The manager continues to closely observe, monitor, and review employee performance based on provisions of the opportunity letter. | the employee's performance does not improve | - Consult with Labor Relations regarding the issuance a 30 day advance notice of reduction in grade or removal.<br>  <br>- Make sure all documentation is in order and copies provided to employee with copies filed in their EPF.<br>  <br>- Follow procedures outlined in Article 40 of the National Agreement - IRS/NTEU for BU employees with the continued assistance of Labor Relations.<br>  <br>- Provide a written decision to the employee within 30 days after the date the advance notice period expires. — If no written decision is made within this 30 day period, then the advance notice period may be extended for one additional 30 day period only.<br>  <br>- Provide a written decision to employee within extended 30 day advance notice period.<br>  <br>- Initiate action to reduce in grade and/or removal based on unacceptable performance once the written decision is issued. |
| However, when a 30 day advance notice is being considered | reassignment, voluntary reduction in grade, retirement, or disability retirement is also being considered in lieu of notice | - Consult with Labor Relations personnel.<br>  <br>- Exercise options under consideration. – All but disability retirement option may preclude or delay processing of an action to reduce in grade or remove employee. – An application for disability retirement will not preclude or delay processing of an action to reduce in grade or remove the employee. |
| If written decision is issued to reduce in grade and/or removal based on unacceptable performance | the personnel action is effected | - The employee has appeal rights to Merit Systems Protection Board.<br>  <br>- BU employee may alternatively choose to appeal through the negotiated grievance procedure. |

**Exhibit 1.4.51-2**

### Pattern Letter for Incomplete Claim for Damages and/or Attorney's Fees

Below is suggested text for a letter to a claimant asking for payment of damages from the IRS because the IRS has violated the automatic stay or the discharge injunction. This letter is to be used when the claimant fails to provide complete information with the claim application. Local Counsel may suggest changes in wording or content.

| Begin the letter with: | Dear, name of claimant |
| --- | --- |
| Paragraph 1 | We have received your claim dated \[enter date of claim\] for damages and/or attorney's fees under Internal Revenue Code 7433(e), civil damages for alleged violation(s) of the Bankruptcy Code. However, we are unable to process your claim because: |
| Paragraph 2 | \[Enter the reason(s) why the claim cannot be processed at this time. Describe any missing or incomplete information and/or additional information the claimant must provide to justify the claim. Be specific.\] |
| Paragraph 3 | We are not rejecting your claim at this time. But we do require the information requested above to process it. If we receive the information, we will evaluate your claim and send our decision on this matter to you within 60 days. |
| End of letter | Sincerely, add your name and title |

**Exhibit 1.4.51-3**

### Pattern Letter for Approval of a Claim for Damages and/or Attorney's Fees

Below is suggested text for a letter to a claimant asking for payment of damages from the IRS because the IRS has violated the automatic stay or the discharge injunction. This letter is to be used when the IRS agrees to pay all or a portion of the claimant's application. Local Counsel may suggest changes in wording or content.

| Begin the letter with | Dear, name of claimant |
| --- | --- |
| Paragraph 1 | This letter is to advise you of our decision concerning the claim you filed. See the explanation below following the checked box. |
| Paragraph 2 | **We have approved your claim in full** for damages and/or attorney's fees under Internal Revenue Code 7433(e), civil damages for violation(s) of the Bankruptcy Code. |
| Paragraph 3 | **We have approved a portion,** $ \[enter portion amount\], **of your claim**for damages and/or attorney's fees under Internal Revenue Code 7433(e) civil damages for willful violation(s) of the Bankruptcy Code. However, we are denying the remaining portion of your claim for the following reason(s): |
| Paragraph 4. Describe the reason (s) for which the claim was partially allowed. | Insert the specific reason(s) |
| Paragraph 5 | Please sign and date the enclosed voucher and return it to us in the enclosed envelope. We will send you a signed copy for your records. Your check will be sent to you within six to eight weeks after we receive your signed voucher. |
| Paragraph 6 | Please sign and date the enclosed voucher and return it to us in the enclosed envelope. We will send you a signed copy for your records. Your check will be sent to you within six to eight weeks after we receive your signed voucher. |
| Paragraph 7 | You are not entitled to make an administrative appeal of this decision. However, if you wish to take further action, you may file a civil action in the bankruptcy court for damages under Internal Revenue Code 7433(e) for the difference not agreed upon. The law allows you two years from the date of a violation to take your case to court. |
| End of letter | Signature and title of Delegated Authority |

**Exhibit 1.4.51-4**

### Pattern Letter for Denial of a Claim for Damages and/or Attorney's Fees

Below is suggested text for a letter to a claimant applying for payment of damages because the IRS has violated the automatic stay or the discharge injunction. This letter is to be used when the IRS denies payment of all portions of the claimant's application. Local Counsel may suggest changes in wording or content.

| Begin letter with | Dear, Name of Claimant |
| --- | --- |
| Paragraph 1 | We have received your claim dated \[enter date of claim\] for damages and/or attorney's fees under Internal Revenue Code 7433(e), civil damages for alleged violation(s) of the Bankruptcy Code. |
| Paragraph 2 | We are denying your claim for the following reason(s). Enter the reason(s) why the claim has been denied. Be Specific |
| Paragraph 3 | You are not entitled to make an administrative appeal of this decision. However, if you wish to take further action, you may file a civil action in the bankruptcy court for damages under Internal Revenue Code 7433(e). The law allows you two years from the date of a violation to take your case to court. |
| Paragraph 4 | If you have any questions, please contact: insert the name and telephone number of the contact person |
| End of letter | Signature and title of Delegated Authority |

**Exhibit 1.4.51-5**

### Sample Annual/Mid-year Review Schedule

Group Review Schedule

**Group Review Schedule**

| **Month** | **SSN** | **Form 6850-BU Employee** | **Due** | **Mid-year** |
| --- | --- | --- | --- | --- |
| September | 0 | AA, BB | Oct 31 | EE, FF |
| October | 1 | N/A | Jan 31 | GG, HH, II |
| November | 2 | CC | Jan 31 | N/A |
| December | 3 | DD | Jan 31 | JJ, KK |
| January | 4 | N/A | Apr 30 | LL, MM |
| February | 5 | EE, FF | Apr 30 | N/A |
| March | 6 | GG, HH, II | Apr 30 | N/A |
| April | 7 | N/A | Jul 31 | AA, BB |
| May | 8 | JJ, KK | Jul 31 | N/A |
| June | 9 | LL, MM | Jul 31 | CC |
| July | N/A | N/A | N/A | DD |
| August | N/A | N/A | N/A | N/A |

### Note:

The letters in this chart, for example AA, BB, represent individual employees.

**Exhibit 1.4.51-6**

### Insolvency Group Manager's EQRS Review Documents, Form 6850-BU, and Narrative, General Guide

EQRS, Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request, and narratives are important in all actions regarding caseworker performance. The review documents should justify the numerical ratings and average indicated on the Form 6850-BU.

These documents will assist the manager in substantiating a decision to take any action regarding the performance of a caseworker. These actions can include awards, reduction of a rating of record, or removal from Telework. These documents should be clear and concise. They should provide the caseworker with a clear understanding of their level of performance.

EQRS review documents, narratives and other evaluative documents should provide positive feedback and specific strategies for improvement as applicable. The narrative should be specifically written to enhance performance, identify weaknesses, and explain potential consequences when warranted.

Ensure that the reviews are written and encompass a wide spectrum of cases from the caseworker's inventory.

**When performing case reviews utilizing the Embedded Quality Review System**:

1. Review any hard copy case file(s). This is to ensure documents that will expedite case resolution are included, (e.g., financial statements, bank records, etc.) and that an appropriate evaluation of case direction has been made.

2. Ensure clear comments are included for each case reviewed. If the employee is performing well, document it in the comments.

3. If case direction is needed, ensure directions are specific. If warranted, reference specific documents reviewed in the case file.


**When preparing the review documentation the manager should**:

1. Ensure the employee's actions were appropriately documented on each case.

2. Base comments on actions pertaining to the applicable CJE and sub-element.

3. Ensure conformity with the employees’ CJE’s by utilizing the employee’s Performance Plan.

4. When appropriate, reference relevant IRM sections, subsections, and case file documents.

5. Document strategies for improvement.

6. Be realistic in expectations.

7. Prepare a narrative of the overall findings.


Meet with the employee and engage in an open dialogue. Be sure to discuss the positive as well as the negative aspects of the employee’s performance. Discuss the comments on the EQRS Feedback Report given on each case and ensure the employee understands.

1. Ask for their input regarding the interpretation of their actions.

2. If warranted, discuss the documents included in the case file, and address any that are missing.

3. If appropriate, add their proposed actions to the comments as additional action items.

4. Ensure that time lines are realistic.

5. Ensure that case direction is clear.


Discuss the EQRS Feedback Report narrative with the employee to ensure they understand the document and its possible impact on their annual appraisal/evaluation (positive or negative).

Managers should have the employee sign for receipt of both the Individual Feedback Report and any accompanying documents. Document and date the Individual Feedback Report and narrative if the employee refuses to sign.

**Annual Appraisal Document Form 6850-BU**:

Form 6850-BU is the numerical representation of the employee's performance during the course of the evaluation period. It must be consistent with the employee's casework and evaluative documents prepared during the course of the evaluative period. Managers should ensure that the preparation of Form 6850-BU is in accordance with Article 12, Performance Appraisal System, of the National Agreement - IRS/NTEU. Base the appraisal of the employee on documented materials:

1. Evaluative documents retained in the caseworker's EPF, such as EQRS Individual Feedback and/or Cumulative Feedback Reports. Also _IRM 1.4.51.5_, Performance Management, and _IRM 1.4.51.5.2_, Reviews (Overview), for other considerations.

2. Taxpayer correspondence.

3. Internal customer correspondence.

4. All awards received during the period.


**Performance and Evaluative Narratives**:

Narratives are an effective tool in documenting and informing a employee of their performance. They should be used to emphasize the positive as well as the negative aspects of the employee's performance. They can be used as either stand alone documentation (EQRS Individual and/or Cumulative Feedback Reports) and/or with the Form 6850-BU (when appropriate). See Article 12, Section 4.N, of the National Agreement - IRS/NTEU, regarding Form 6850-BU narratives. Effective narratives:

01. Are clear and concise.

02. Address each Critical Element and its accompanying sub-element (for Form 6850-BU).

03. Reference prior reviews and other evaluative documents completed during the course of the evaluation period and the dates completed or received.

04. Are of sufficient length for the employee to have a clear understanding of their current level of performance and what is expected from them in the future.

05. Summarize the findings during the course of a review or the overall performance during an evaluative period. may choose to use specific examples or sanitized case references.

06. Refer to specific Critical Job Elements and sub-elements.

07. Describe strengths and weaknesses found within specific element(s).

08. Describe strategies for improvement (if necessary).

09. Identify the level of performance (overall and within a specific CJE).

10. Describe potential consequences if performance is at an unacceptable level or regressing.

11. Note that the manager is available for assistance.


In conjunction with the steps to address employee performance ensure that:

- Prescribed actions are specifically documented and appropriately worded. Consult with the Territory / Operation Manager or Labor Relations Specialist as appropriate.

- Documentation includes a description of any problems and documentation of the discussion with the employee involved. Inform the employee of possible consequences if the issue is not resolved. Managers may inform the employee verbally, but confirm the discussion via memorandum. The proposed resolution of the issue should include a specific time period for completion. The resolution may include actions the employee must take and meetings between managers and the employee to resolve the problem.



### Note:



The employee is entitled to request representation by the Union when the employee and the supervisor or other management official meet to discuss action or potential action, based on unacceptable performance.


### Note:

**When taking any performance action, managers should contact their servicing Labor Relations Representative and their direct supervisor.**

**Exhibit 1.4.51-7**

### Action Steps for Acceptable Level of Competence Determination if an Employee Within Grade Increase (WGI) is due.

| **Within** | **and the employee's last rating is...** | **and the employee's performance is projected as...** | **Managers must.....** |
| --- | --- | --- | --- |
| 90 days | Fully successful or above | Fully successful or above | Do nothing. WGI will be automatically generated. |
| 90 days | Fully successful or above | Below Fully successful | 1. Refer to WGI denial procedures in Article 17, Acceptance Level of Competence Determinations, for BU employees.<br>   <br>2. Consult with Labor Relations personnel and issue letter of intent to deny WGI 60 days prior to WGI due date.<br>   <br>3. If a fully successful rating is achieved after issuing intent letter, consult with LR regarding written notification to employee that WGI will become effective on original due date.<br>   <br>4. If a fully successful rating is not achieved after 60 days following issuance of intent letter:<br>   <br>   <br>   <br>   - Consult with LR regarding written notification to employee denying WGI.<br>     <br>   - Prepare Form 6850-BU as normally would happen at the end of the rating period except: – indicate period covered from last annual rating to date WGI was due and – annotate that “WGI Denied” – submit signed form to the Transactional Processing Branch (TPB) at least 15 days prior to WGI due date to ensure that the WGI is not processed. |
| 59 days or less | Fully successful or above | Below Fully Successful | 1. Refer to WGI denial procedures in Article 17 for BU employees.<br>   <br>2. Consult with LR and issue letter of intent to deny WGI. Letter will provide for required 60 day notice period.<br>   <br>3. As soon as possible, prepare Form 6850-BU. Complete appropriate blocks and annotate “Postpone WGI”.<br>   <br>4. Submit signed form to the TPB at least 15 days prior to WGI due date to ensure the WGI does not process.<br>   <br>5. If a fully successful rating is achieved at the end of 60 day notice period:<br>   <br>   <br>   <br>   - Consult with LR regarding written notification to employee that WGI will become effective retroactive to original due date.<br>     <br>   - Prepare Form 6850-BU. Complete appropriate blocks and annotate “Release WGI.” Submit signed form to the TPB within 3 days of advising employee.<br>     <br>6. If a fully successful rating is not achieved at the end of the 60 day notice period:<br>   <br>   <br>   <br>   - Consult with LR regarding written notification to employee that WGI is being denied.<br>     <br>   - Prepare Form 6850-BU as if annual rating except: – indicate period covered from last annual rating to date of WGI due – annotate “WGI Denied” – submit completed form to the TPB within 3 days after denial letter is issued to employee; and – immediately have SF-52 the TPB within 3 days after denial letter is issued to employee; and – immediately have SF-52 prepared for denial of WGI. |
| 59 days or less | Below Fully successful and the WGI was previously denied | Fully Successful or above | 1. Prepare Form 6850-BU as if annual rating except:<br>   <br>   <br>   <br>   - Indicate period covered from date WGI was last due to the date of this form being prepared, and<br>     <br>   - Annotate “WGI Released”<br>     <br>2. Advise employee that the WGI will become effective the following pay period.<br>   <br>3. Submit completed form to the TPB within 3 days of completing form. |
| 59 days or less | Below Fully Successful and WGI was not previously denied | Fully Successful or above | No action necessary |

**Exhibit 1.4.51-8**

### Guide for Litigation Transcript System (LTS) Reports (CIO)

**Purpose of Reports**. The Litigation Transcript System (LTS) matches master file data with TIN records of the AIS database. The transcripts provide new assessment data, potential manual refunds, unreversed TC 520s, delinquent federal tax deposits, and issues that may result in violations of the Bankruptcy Code automatic stay provisions.

**Frequency of Use by Caseworker** The CIO will work required LTS reports for cases in its inventory. The reports must be worked in accordance with the instructions and time frames established in IRM 5.9.16.2, Litigation Transcript System.

**Frequency of Use by Manager**. Managers should review the reports at least monthly to ensure potential stay violations are being addressed and resolved on a timely basis.

**Range of Uses**. The scope of the LTS reports touches all chapters.

**Retention**. The retention period for this report is one cycle.

**Referrals**. Appropriate receiving offices should be notified of events identified through LTS reports affecting previously issued referrals.

### Example:

Counsel should be advised of receipt of delinquent returns if a referral was made requesting a motion to compel filing.

**AIS History**. Caseworkers should document the AIS history in accordance with IRM 5.9.5.4(2), History Documentation, noting all actions taken to resolve the LTS issue.

**Transaction Codes Identified**. Examples of the types of transaction codes the LTS process identifies are:

- Posting of TC 277

- Posting of TC 430 and no TC 150 posted

- Posting of TC 520 with xx code

- Posting of TC 280 bad check penalty

- Posting of TC 670 cc05/99

- Posting of TC 820/700 (if that is the only issue)

- Posting of TC 846

- Posting of TC 971 ac031/033

- Posting of a TC 582 Notice of Federal Tax Lien

- Post-petition refunds and credits

- Zero balance due/even returns (wholly post-petition)


**Transcript Categories**. LTS transcripts fall into one of six categories:

- After Petition

- Credit Balance

- Other Credit Balance

- Case Closed on AIS

- New Assessments

- All Other (optional for CIO)


**Exhibit 1.4.51-9**

### Guide for Court Closure Follow-Up Report (CIO)

**Introduction**. The Court Closure Follow-Up report is mandatory for use by both Field and Centralized Insolvency. This report provides a list of open AIS cases where the court has notified the IRS of closure. It identifies cases where closing actions should be initiated immediately. The AIS generated report denotes discharges as (DC) and dismissals as (DM).

### Note:

FI caseworkers and managers must refer to the Field Insolvency Report Job Aid posted in Knowledge Management.

**Accessing the Report**. Use AIS Business Objects to access, run, and print the Court Closure Follow-Up report.

**Days Threshold Parameter**. When generating this report, the user must enter a days threshold parameter. Since employees are required to initiate closure actions within 30 days of notification, generally this report should be run using no more than 30 days.

**Frequency of Use by Caseworker**. This report must be generated and worked weekly so closure actions are initiated within 30 days of the IRS being notified of the discharge or dismissal.

**Frequency of Use by Manager**. Managers should review the Court Closure Follow-Up report "Monthly" to determine if cases are being closed in compliance with BCCP standards.

**Range of Uses**. This report identifies closures for Chapters 7N, 12, and 13 as well as individual Chapter 11 cases filed on or after October 17, 2005.

**Chapters 7A and 11**. This report is of limited value in listing Chapter 11 discharges because the courts issue Chapter 11 discharges upon plan confirmation with one exception. (See "note" below.) "Discharge" does not always mean the same thing for Chapter 11 cases as it does for other chapters. The Court Closure Report is of little value in listing Chapter 7A discharges because the courts usually issue Chapter 7A discharges immediately.

### Note:

For individual Chapter 11 cases filed on or after October 17, 2005, confirmation of the plan does not result in a discharge. Instead, the court will grant a discharge when all plan payments are completed.

**Use of Aged Case Report**. The Aged Case Report is more useful than the Court Closure Report for identifying overage Chapter 7A cases.

**History Documentation**. Managers should be conservative in requiring documentation from caseworkers on an ongoing basis. The use of accepted acronyms should be encouraged. (See Exhibit in IRM 5.9.1-2, Acronyms and Abbreviations.)

**Exhibit 1.4.51-10**

### Guide for Tech Review Follow-Up Report (CIO)

**Overview**. The Tech Review Follow-Up report may be used by both Field Insolvency and the Centralized Insolvency Operation. This report provides a listing of open cases selected by an Insolvency caseworker to be reviewed for a particular purpose within a specified range of dates. The user can create a list of follow-up priority items with action dates. A required action statement appears on the AIS Follow-up screen. This statement identifies the action needing attention by the caseworker.

**Accessing the Report**. Use AIS Business Objects to access, run, and print the Tech Review Follow-Up report.

- When entering the beginning date, an old date, such as 01/01/2000, should be input to capture cases previously overlooked or cases entered with an incorrect date.


**Frequency of Use by Caseworker**. This list must be generated and checked by caseworkers at least **"Monthly"** to ensure cases continue towards closure.

**Frequency of Use by Manager**. The Tech Review Follow-Up report is reviewed by managers **"Quarterly"** to ensure cases continue towards closure.

**Range of Uses**. All chapters benefit through the use of the Tech Review Follow-Up Report.

**Avoiding Redundancy**. The Tech Review Follow-Up report contributes to workgroup efficiencies if used in conjunction with the other AIS Business Objects reports. Scheduling a future review of the master file for receipt of delinquent returns demonstrates an effective use of this report. Actions loaded by the user to this report should not duplicate actions listed on other reports.

### Example:

A follow-up action item to prepare a POC should not be loaded because the Bar Date Follow-Up report will identify those cases.

**Report Uses**. The purpose of the Tech Review Follow-Up report is to focus on a particular range of cases ( large dollar Chapter 13 plans). Assigning follow-ups on every case may be counterproductive. A report listing non-critical action items debases its value for prioritizing case work.

**Report Misuse**. The caseworker who has not completed a scheduled action timely has the ability to change the action item with a future date giving the manager or reviewer a false impression the inventory is being effectively managed.

**Critical Follow-Up Categories**. Case actions that may be identified for follow-up include:

1. Refiling of a Notice of Federal Tax Lien at least six months before the refile period expires because Automated Lien System (ALS) does not generate refile reports on accounts in bankruptcy;

2. Issuing courtesy investigations to protect ASEDs or make ASED determinations.


**Updating Action Items**. An action item can be added to a Tech Review Follow-Up report a number of ways by any user with update permissions. The AIS Follow-Up screen displays the follow-up fields directly.

**Exhibit 1.4.51-11**

### Guide for LAMS Closed Case Listing Report (CIO)

**Unreversed TC 520s**. This report identifies cases closed on AIS but with at least one IDRS module showing an unreversed TC 520. IRM 5.9.16.4.1, LAMS Closed Case Listing, provides step instructions for printing and working this report.

**Exhibit 1.4.51-12**

### Guide for Pending Refunds Report (CIO)

**Purpose of Report**. The Pending Refunds report lists all cases with pending refunds on the Manual Refund screen of AIS.

**Accessing the Report**. Use AIS Business Objects to access, run, and print the Pending Refunds report.

**Frequency of Use by Caseworker**. Caseworkers must work the report at least weekly to ensure credits are processed timely.

**Frequency of Use by Manager**. Managers should review the report quarterly to identify trends or as part of employee reviews.

**Range of Uses**. All chapters are subject to this report.

**Exhibit 1.4.51-13**

### Guide for LAMS Not Found on AIS Case Listing Report (CIO)

**Purpose of Report**. Cases are listed on this report because their TINs do not match any TINs in the presumed AIS database, and the Bankruptcy/Litigation Location Code (BLLC) is for a district other than the presumed district. Under normal conditions these cases belong to taxpayers with a Primary Location Code in the home district and a bankruptcy in a foreign district. IRM 5.9.16.4.2, LAMS Not Found on AIS Case Listing Report, provides step instructions for generating and working this report.

**AIS Notification**. LAMS reports are updated quarterly somewhere between one week before the end of the calendar quarter and up to five weeks after the end of the calendar quarter. A message appears on AIS when LAMS is updated. In some instances a case on this list may indicate a situation involving joint returns where only one spouse has filed bankruptcy.

**Exhibit 1.4.51-14**

### Guide for Non-Master File Listing Report (CIO)

**Purpose of the Report**. The Non-Master File (NMF) Listing report must be worked by both Field Insolvency and the Centralized Insolvency Operation. It provides a roster of status 72 NMF assessments to be matched against the AIS open database to ensure the cases should be in litigation status and the CSED is not tolling.

### Reminder:

When a bankruptcy closure applies to a module in NMF, the module was subject to the automatic stay, and a balance remains on the module, the CSED must be extended manually using TC 550.

**Accessing the Report**. Reports are generated at the SB/SE Campus in Kansas City.

**Contents of the Report**. The TC 520 NMF listing includes litigation cases primarily involving bankruptcies and non-debtor spouses or other MFTs that still require NMF processing.

### Note:

No asterisk = 90 to 179 days from 520 transaction date, \* = 180 - 364 days from the TC 520 transaction date, and \*\* = one year or older.

**Frequency of Use by Caseworker**. The TC 520 listing should be generated quarterly for reconciliation. Insolvency should respond to the NMF unit within 60 days of receiving the report.

**Frequency of Use by Manager**. Managers should review the report annually for performance feedback purposes and to determine if CSED issues or other inventory management issues are addressed appropriately.

**Retention**. The NMF list should be retained for use in the following quarter to verify if accounts for which closing requests were previously submitted are truly closed.

**Range of Uses**. This report is used for all chapters of bankruptcy.

**Case Matching**. Cases should be matched against AIS and electronic court records if necessary due to age (greater than one year for Chapter 7 cases and greater than three years for all others) or lack of documentation in the AIS history.

**IDRS Review**. Caseworkers should check the IDRS status of cross referenced TINs to ensure their current collection status is appropriate in light of the pending bankruptcy.

### Note:

Reorganizations have affected the district code listing. Any NMF listing that contains TC 520 bankruptcy accounts controlled by another Insolvency group should be faxed to the appropriate office and a history item entered on AIS to document.

**Exhibit 1.4.51-15**

### Guide for Lien Research Report (CIO)

_Purpose of the Report_. This mandatory Lien Research report identifies cases that have been discharged and for which a Notice of Federal Tax Lien has not been systemically released. Insolvency must review the cases to identify those that require a manual release of the NFTL (excepting cases where pursuit of exempt, abandoned and excluded property is being considered). Failure to work this report may result in lien releases not being initiated within 30 days of notification of discharge when the liability is fully satisfied as defined in IRC 6325, Release of Lien or Discharge of Property.

**Accessing the Report** Use AIS Business Objects to access, run, and print the Lien Research report.

**Report Date Parameter**. When the user is generating this report, they must enter a date parameter. Managers generating the report for review should use the start date of the prior quarter and an end date of the prior quarter.

### Example:

If the manager is running the report on 04/01/2019, they will use 10/01/2018 as the beginning date and 12/31/2018 as the end date.

Caseworkers generating the report for case processing should use the start date of the week two weeks prior and an end date of the week two weeks prior to the date they run the report.

### Example:

If the caseworker is generating the report on 01/10/2019 they will use 12/23/2018 as the beginning date and 12/29/2018 as the end date.

Using these time frames should assist in identifying liens that have not been released so corrective actions can be taken. The date format is MM/DD/YYYY.

**Range of Uses**. This report is used for Chapter 7 Asset, 7 No Asset, and Chapter 13 cases that have been discharged.

**Procedures for Working the Report**. The employee must review each case on the report and determine any lien requiring release within the 30 day requirement (IRC 6325, Release of lien or discharge of property) will be timely released through systemic actions. If it appears the release will be delayed due to a Discharge Determination Report (DDR), mirroring, etc., and all statutory liens for periods on the NFTL are satisfied as required under IRC 6325, a manual lien release should be requested. The lien release can be input directly into ALS.

**History Documentation**. The employee must document the history to reflect the lien research report was reviewed and whether or not a manual lien release requested, any periods deemed non-dischargeable, etc.

### Note:

Managerial approval/denial of the lien release must also be documented in the AIS history.

**Frequency of Use by Caseworker**. This report must be generated and worked weekly.

**Frequency of Use by Manager**. Managers should review the report quarterly.

**Retention**. The Lien Research report should be retained for one quarter.

**Exhibit 1.4.51-16**

### Guide for Aged Cases Report (CIO)

**Purpose of Report**. This Aged Cases report identifies cases that are older than a certain number of days (270 for 7N and 7A cases, and 2190 for Chapter 13 cases) and do not yet have a dismissal/discharge date on AIS. IRM 5.9.16.6, Aged Case Reports, gives more information on this report.

**Accessing the Report**. Use AIS Business Objects to access, run, and print the Aged Cases report.

**Frequency of Use by Caseworker**. Annual matching is required. The CIO must work Chapter 7 No Asset and Chapter 13 cases assigned to its inventory.

**Frequency of Use by Manager**. The manager should review this report annually to determine if trends are evident in cases' not being closed timely.

**Range of Uses**. This report is available for Chapters 7N, 7A, and 13.

**AIS Documentation**. Managers should be conservative in requiring documentation from caseworkers on an ongoing basis. A short history in the case to be closed may state "DS or DC per aged."

**Exhibit 1.4.51-17**

### Guide for Case Assignment Reports (CIO)

**Purpose of Reports**. There are three Case Assignment Reports:

- Assigned Profiles identifies how cases will be systemically assigned via the CAG program using information based on the CAG matrix.

- CAG Assignment lists cases successfully processed and assigned to a caseworker during a specific period of time.

- Ungraded Case Follow-Up lists cases that have not passed all systemic checks and remain unassigned. Generally, cases should not remain unassigned for more than five days.


**Accessing the Report**. Use AIS Business Objects to access, run, and print the Case Assignment reports.

**Frequency of Use by Caseworker**. The CIO Automated Process Control (APC) team is responsible for working the "Ungraded Case Follow-Up report" . This listing should be printed and reviewed weekly. The majority of the cases on the report are attributed to "Potentially Invalid TINs or Process D errors" . Prompt resolution of the error condition will allow assignment of the case the next time the IIP processes are run.

**Frequency of Use by Manager**. CIO Managers should review the Ungraded Case Follow-Up report monthly and Assigned Profiles report as needed.

**Range of Uses**. All chapters are subject to this report.

**Procedures for Working the Ungraded Case Follow-Up report**. The caseworker must review each case on the report and determine the action to be taken in accordance with local procedures to resolve the condition preventing assignment.

**Retention**:

- Assigned Profiles: when no longer needed.

- CAG Assignment: when no longer needed.

- Ungraded Case Follow-Up: electronic or hard copies should be retained six months from date of printing.


**Exhibit 1.4.51-18**

### Guide for Unpostable Reports (CIO)

**Purpose of the Report**. The Unpostable Report, also called the Generalized Unpostable Framework (GUF), lists cases Insolvency entered a transaction on that went unpostable. Insolvency (both FI and CIO) is responsible for resolution of the resulting unpostable condition. General guidance for identifying and resolving unpostable transactions can be found in IRM 21.5.5, Unpostables.

**Accessing the Report**.

- CIO usually pulls their overage reports via Control-D or Overage Report Compiler and Sorter (ORCAS) on a weekly basic.


**Report Types**. Two types of reports are produced.

1. Overage Report is discussed in detail in IRM 5.9.16.5.1, Overage Report.

2. Nullified Distribution List is discussed in detail in IRM 5.9.16.5.2, Nullified Distribution List (NULL DIST LST).


**Frequency of Use by Caseworker**. Time frame for completion of the unpostable reports:

- CIO reports are worked weekly when the listing becomes available.


This report is worked when a listing becomes available.

**Frequency of Use by Manager**. Managers should review reports when completed by the caseworker to ensure issues are properly addressed and potential stay violations have been addressed/corrected.

**Range of Uses**. This report is pertinent for all chapters.

**Statutes**. ASEDs and CSEDs are two reasons these cases should be worked as soon as they are received. Imminent statute information must be included in the history when requesting resolution of an unpostable.

**Retention**. Reports should be destroyed when no longer needed in current operations.

**Requisite Command Codes**. Those working this report must have command code ACTON in their IDRS profile.

**Exhibit 1.4.51-19**

### CAG Pre-Assignment Factors

| **Factor** | **Name** | **Description** |
| :-: | :-: | :-: |
| **1** | Chapter | 01. 7N<br>    <br>02. 7A<br>    <br>03. 09<br>    <br>04. 11<br>    <br>05. 12<br>    <br>06. 13<br>    <br>07. 15<br>    <br>08. AS (Assignments)<br>    <br>09. DC (Decedent/Probate)<br>    <br>10. RC (Receiverships) |
| **2** | Unpaid Liability | • Ranges vary by chapter (See _Exhibit 1.4.51-20_, CAG Pre-Assignment Difficulty Indicators.) |
| **3** | Entity | - IMF<br>  <br>- BMF |
| **4** | Business Operating Division (BOD) | 1. SB<br>   <br>2. LM<br>   <br>3. TE<br>   <br>4. Taxpayer Service |

**Exhibit 1.4.51-20**

### CAG Pre-Assignment Difficulty Indicators

GS-07 Technician

| **Chapter** | **Bal Due** | **File Source** | **BOD** |
| --- | --- | --- | --- |
| **7N** | All | IMF, BMF | All |

GS-09 Specialist

| ****Chapter**** | ****Bal Due**** | ****File Source**** | ****BOD**** |
| --- | --- | --- | --- |
| **7A** | $0-$19,999\` | IMF, BMF | WI, SB |
| **13** | $0-$49,999 | IMF, BMF | WI, SB |

GS-11 Specialist

| ****Chapter**** | ****Bal Due**** | ****File Source**** | ****BOD**** |
| --- | --- | --- | --- |
| **7A** | $20,000-$149,999 | IMF, BMF | WI, SB, LM, TE |
| **9** | $0 - $149,999 | BMF | TE |
| **11** | $0 - $149,999 | IMF, BMF | WI, SB, LM, TE |
| **12** | $0- $149,999 | IMF, BMF | WI, SB, LM |
| **13** | $50,000 - $149,999 | IMF, BMF | WI, SB |

GS-12 Specialist

| **Chapter** | **Bal Due** | **File Source** | **BOD** |
| --- | --- | --- | --- |
| **7A** | $150,000+ | IMF, BMF | WI, SB, LM |
| **9** | $150,000+ | BMF | TE |
| **11** | $150,000+ | IMF, BMF | All |
| **12** | $150,000+ | IMF, BMF | WI, SB, LM |
| **13** | $150,000+ | IMF, BMF | WI, SB |
| **15** | All | All | All |
| **AS/RC** | All | All | All |

**Exhibit 1.4.51-21**

### Post-Assignment Difficulty Indicators Factor 5: Case Action

Caseworker GS-9 Specialist

| Factor 5: Case Action, Caseworker GS-9 Specialist |
| --- |
| Performs routine analysis and investigations. |
| Performs routine recommendations and request for legal assistance. |
| Reviews and respond to court documents on routine issues. |

Caseworker GS-11 Specialist

| Factor 5: Case Action, Caseworker GS-11 Specialist |
| --- |
| Conducts in-depth analysis, which may involve asset transfers and lien priority. |
| Recommends and request legal assistance on more complex issues involving application of law, hidden and undisclosed assets, large examination assessments, corporations, TEFR and multiple entities. |
| Reviews and responds to moderately difficult cases to make an informed judgment about a proposed plan of reorganization. |
| Addresses and resolve the following APOC Flags:<br> <br>1. BMF Compliance (after confirming the existence of a BMF entity)<br>   <br>2. CID Freeze (after confirming that case is assigned to CI)<br>   <br>3. LLC<br>   <br>4. Section 965 Transition Tax<br>   <br>5. IRPTRL>$1M<br>   <br>6. Secured Flags with aggregate balance >$25K<br>   <br>7. Serial Filer Cases (upon confirmation that the automatic stay has not been reimposed)<br>   <br>   <br>   <br>### Note:<br>   <br>   <br>   <br>For additional information about flags and processing of serial filer cases see IRM 5.9.14.2.8, Case Flags, IRM 5.9.14.2.9, Period Flags, IRM 5.9.5-4, Common Processing Steps in Serial Filer Cases |

Caseworker GS-12 Specialist

| Factor 5: Case Action, Caseworker GS-12 Specialist |
| --- |
| In the most complex cases, uses extensive knowledge and analytical techniques to determine:<br> <br>1. Viability of business’ continued operation<br>   <br>2. Government’s position in adversarial complaint |
| Recommends and requests legal assistance on the most complex issues:<br> <br>1. lien priorities<br>   <br>2. fraud<br>   <br>3. property ownership<br>   <br>4. settlement options<br>   <br>5. nominee/alter ego/transferee |
| Advisory opinion: research complex case issues to determine and apply law to facts presented. Opinions may be oral or written. |
| Resolve potential BCCP claims. |

**Exhibit 1.4.51-22**

### Post-Assignment Difficulty Indicators Factor 6: Communication

Caseworker GS-9 Specialist

| Factor 6: Communication, Caseworker GS-9 Specialist |
| --- |
| Confers and interacts with:<br> <br>1. taxpayers and their representatives<br>   <br>2. creditors and third parties<br>   <br>3. other IRS employees<br>   <br>4. tax practitioners, attorneys<br>   <br>5. IRS officials in Area Counsel and<br>   <br>6. officials from the bankruptcy court (judges, trustees, and other federal officials including representatives from DOJ) |
| Contacts are made to:<br> <br>1. exchange information<br>   <br>2. provide advice or assistance<br>   <br>3. resolve issues and problems<br>   <br>4. arrive at agreements for the settlement of tax related issues and determine the next course of action |
| Attends meeting of creditors and testifies relative to the level of expertise. |
| Prepares technical written documents (e.g. referrals to Counsel) relative to routine cases or task assignments. |

Caseworker GS-11 Specialist

| Factor 6: Communication, Caseworker GS-11 Specialist |
| --- |
| Confers and interacts with:<br> <br>1. taxpayers and their representatives<br>   <br>2. creditors and third parties<br>   <br>3. other IRS employees<br>   <br>4. tax practitioners and attorneys<br>   <br>5. IRS officials in Area Counsel and<br>   <br>6. officials from the bankruptcy courts (judges, trustees, and other federal officials including representatives from DOJ |
| Contacts are made to:<br> <br>1. exchange information<br>   <br>2. obtain or give advice or assistance<br>   <br>3. resolve complex and difficult issues and problems<br>   <br>4. arrive at agreements for the settlement of complex tax related issues and determine the next course of action |
| Attends meeting of creditors and testifies at hearings relative to the level of expertise. |
| Prepares technical written documents (e.g. referrals to Counsel) relative to more complex case or task assignment. |
| Advises and consults with IRS personnel on complex aspects of bankruptcy. |

Caseworker GS-12 Specialist

| Factor 6: Communication, Caseworker GS-12 Specialist |
| --- |
| Confers and interacts with:<br> <br>1. taxpayers (who may be high income and prominent) and their representatives<br>   <br>2. creditors and third parties<br>   <br>3. other IRS employees<br>   <br>4. tax practitioners and attorneys<br>   <br>5. IRS officials in Area Counsel and<br>   <br>6. officials from the bankruptcy courts (judges, trustees, and other federal officials including representatives from DOJ) |
| Contacts are made to:<br> <br>1. exchange information<br>   <br>2. obtain or give advice or assistance<br>   <br>3. resolve complex and difficult issues and problems<br>   <br>4. negotiate agreements for the settlement of complex tax related issues including adequate protection and determine the next course of action. |
| Serves as expert witness. |
| Prepares technical written documents (e.g. referrals to Counsel) relative to the most complex case or task assignment. |
| Act as contact with internal and external customers relative to duties and responsibilities as a program coordinator. |
| Deals with high profile and sensitive cases. |
| Delivers agency’s perspective in outreach presentations. |

**Exhibit 1.4.51-23**

### Post- Assignment Difficulty Indicators Factor 7: Supervisory Controls

Caseworker GS-9 Specialist

| Factor 7: Supervisory Controls, Caseworker GS-9 Specialist |
| --- |
| Little or no supervisory control exercised on typical GS-09 cases. |
| Completed work is reviewed for technical soundness, appropriateness and conformance with established guidelines. |
| Incumbent exercises independent judgement and initiative in determining the course of action on routine bankruptcy cases. |
| Guidance is limited to controversial or unprecedented issues including case actions which require an interpretation of the Bankruptcy Code or IRM, involve matters of public interest or have potential to create adverse publicity. |

Caseworker GS-11 Specialist

| Factor 7: Supervisory Controls, Caseworker GS-11 Specialist |
| --- |
| Little or no supervisory control exercised on typical GS-11 cases. |
| Completed work is reviewed based on results accomplished and is normally accepted without significant change. |
| Guidance is limited to:<br> <br>1. cases in which unusual difficult problems arises<br>   <br>2. case actions involving matters or public interest with the potential to create adverse publicity<br>   <br>3. cases which may set a precedent |
| Incumbent exercises a high degree of judgment and initiative in determining the course of action on a bankruptcy case. |

Caseworker GS-12 Specialist

| Factor 7: Supervisory Controls, Caseworker GS-12 Specialist |
| --- |
| Little or no supervisory control exercised on typical GS-12 cases. |
| Samples of completed work are reviewed to ensure fulfillment of program guidelines, procedures and objectives. |
| Completed work is rarely changed, as incumbent is considered to be a technical expert. |
| Supervisory consultation is limited to cases which:<br> <br>1. involve significant or sensitive case decisions which deviate from established policy<br>   <br>2. impact other divisions or functions within the IRS<br>   <br>3. involve matter of public interest or deemed to create adverse publicity |

**Exhibit 1.4.51-24**

### Case Assignment Profile Matrix

| FLSO1 | GS-07 | GS-09 | GS-11 | GS-12 |
| --- | --- | --- | --- | --- |
| Chapter 7N | A-C SEID YUBA<br> D-M SEID SMITH<br> N-Z SEID BALL | N/A | N/A | N/A |
| Chapter 7A | N/A | A-F SEID BENT<br> G-Z SEID DREW | A-F SEID CLAY<br> G-R SEID THOMAS<br> S-Z SEID MACK | A-Z<br> SEID NESS |
| Chapter 9 | N/A | N/A | A-D SEID DANTE<br> E-Z SEID PETERS | A-Z SEID NESS |
| Chapter 11 | N/A | N/A | A-D SEID DANTE<br> E-Z SEID PETERS | A-Z SEID NESS |
| Chapter 12 | N/A | N/A | A-F SEID YORK<br> G-Z SEID POLK | A-Z SEID NESS |
| Chapter 13 | N/A | A-F SEID HILL<br> G-Z SEID EDDY | A-F SEID YORK<br> G-Z SEID POLK | A-F SEID NESS<br> G-Z SEID PIMA |

**Exhibit 1.4.51-25**

### CAG Post-Assignment

****Coverage****. This portion of the Insolvency Case Assignment Guide (CAG) is primarily used to provide information which assists managers in determining if a task should be referred or an entire case reassigned. The post-assignment factors identify tasks/issues that are encountered or develop during the process of working the case. Careful review of post assignment factors should be made, as the case evolves, to ensure the case is assigned to the proper grade level of employee.

| **Factor** | **Case Actions** | **Description** |
| :-: | :-: | :-: |
| 5 | Case Action | Covers tasks/issues anticipated at the corresponding grade levels. |
| 6 | Communication | Includes typical individual(s) contacted and the purpose of contacts. |
| 7 | Supervisory Controls | Outlines the functioning relationship between the manager and employee, the degree of independence the employee is expected to exhibit and the extent of supervisory review of work products or accomplishments. |

Most issues referred from a lower to a higher graded employee will not result in the overall reassignment of the case. If the case is permanently reassigned, the manager must measure the case against the three post-assignment factors. While it is not necessary to meet all three factors, a case will generally not be graded at the higher level unless it meets a majority of the factors at the higher level or contains a difficulty indicator that has significant impact.

### Note:

All Chapter 7N cases are initially assigned to CIO. Large Dollar Chapter 7N cases are screened by CIO and assigned to Field Insolvency when potential collection from assets is identified. Chapter 7N cases assigned to Field Insolvency should be re-graded by the Field Insolvency Manager according to guidelines provided by the Director, Specialty Collection - Insolvency.

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-051#addtoany "Show all")

A2A