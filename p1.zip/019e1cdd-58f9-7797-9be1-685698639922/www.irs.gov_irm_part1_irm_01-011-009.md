---
url: "https://www.irs.gov/irm/part1/irm_01-011-009"
title: "1.11.9 Clearing and Approving the Internal Revenue Manual (IRM) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-009#main-content)

- 1.11.9  [Clearing and Approving the Internal Revenue Manual (IRM)](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782824528)
  - 1.11.9.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782794576)
    - 1.11.9.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782818192)
    - 1.11.9.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782816336)
    - 1.11.9.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782813664)
    - 1.11.9.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782809168)
    - 1.11.9.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782426640)
    - 1.11.9.1.6  [Terms](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152782424320)
    - 1.11.9.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152783787376)
    - 1.11.9.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152783591184)
  - 1.11.9.2  [Clearance Process Overview](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152783167984)
    - 1.11.9.2.1  [Instances of Streamlined Clearance](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756032784)
      - 1.11.9.2.1.1  [Clearance of Editorial Updates](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152755092688)
      - 1.11.9.2.1.2  [Incorporating Interim Guidance into the IRM](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152755089504)
      - 1.11.9.2.1.3  [Incorporating Policy Statements and and Servicewide Delegation Orders into the IRM](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152783747168)
      - 1.11.9.2.1.4  [Incorporating Internal Controls into the IRM](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152783743152)
    - 1.11.9.2.2  [Business Unit Clearance Points of Contact](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152783739968)
  - 1.11.9.3  [Identifying Reviewers](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152783736848)
    - 1.11.9.3.1  [Requesting Employee Feedback](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756210672)
  - 1.11.9.4  [Specialized Reviewers](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756206800)
    - 1.11.9.4.1  [Chief Counsel](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756170288)
    - 1.11.9.4.2  [Privacy, Governmental Liaison and Disclosure](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152754710224)
      - 1.11.9.4.2.1  [Clearance of Official Use Only (OUO) Information](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152754702560)
      - 1.11.9.4.2.2  [Clearance of Information about Privacy and Information Protection](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152754692768)
    - 1.11.9.4.3  [Taxpayer Advocate Service](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756143584)
    - 1.11.9.4.4  [Labor/Employee Relations & Negotiations](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756137600)
    - 1.11.9.4.5  [Legislative Affairs](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756127856)
    - 1.11.9.4.6  [Taxpayer Correspondence Services](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756124352)
    - 1.11.9.4.7  [Identity Protection](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756121120)
    - 1.11.9.4.8  [Chief Data & Analytics Officer, Research, Applied Analytics & Statistics (RAAS)](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756118768)
  - 1.11.9.5  [Clearance Submission Guidelines](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756108608)
    - 1.11.9.5.1  [Forwarding the IRM For Clearance](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756105120)
    - 1.11.9.5.2  [Documents Sent for Clearance - Clearance Package](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756094896)
    - 1.11.9.5.3  [Form 2061 - Document Clearance Record](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756084368)
    - 1.11.9.5.4  [Standard Clearance Time Frame](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756080624)
      - 1.11.9.5.4.1  [Expedited Clearance](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756075792)
  - 1.11.9.6  [Comment Methods and Options](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152756071872)
  - 1.11.9.7  [Guidelines for Reviewers](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787450656)
    - 1.11.9.7.1  [Review Assessment and Reviewer's Signature](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787444496)
    - 1.11.9.7.2  [Personally Identifiable Information (PII) or Federal Tax Information (FTI) Breach Actions](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787429200)
  - 1.11.9.8  [Responding to Reviewers' Comments](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787422720)
    - 1.11.9.8.1  [No Response to a Clearance Request](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787411920)
  - 1.11.9.9  [Resolving Disagreements](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787399152)
    - 1.11.9.9.1  [Issuing IRM While Disagreements are Discussed](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787388432)
  - 1.11.9.10  [Final Stages of the Clearance Process](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787378000)
    - 1.11.9.10.1  [Create Final Clearance Package](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787373664)
    - 1.11.9.10.2  [Management’s Final Review](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787365472)
    - 1.11.9.10.3  [Approval by Program Director](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787358112)
    - 1.11.9.10.4  [Final Review by IMD/IRM Coordinator](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787349888)
    - 1.11.9.10.5  [Archiving Clearance Documents](https://www.irs.gov/irm/part1/irm_01-011-009#idm140152787338096)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 9. Clearing and Approving the Internal Revenue Manual (IRM)

* * *

## 1.11.9 Clearing and Approving the Internal Revenue Manual (IRM)

#### Manual Transmittal

February 26, 2025

#### Purpose

(1) This transmits revised IRM 1.11.9, Internal Management Documents, Clearing and Approving the Internal Revenue Manual (IRM).

#### Background

IRM 1.11.9 gives guidance and procedures used for IRM clearance. As of January 01, 2024, the IMD Electronic Clearance (e-Clearance) website is the mandatory method for clearing all IRMs.

#### Material Changes

(1) The following changes have been made throughout IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM):

| **IRM Subsection** | **Material Change(s)** |
| --- | --- |
| _IRM 1.11.9.1_, Program Scope and Objectives | Paragraph (1) - Clarified IRMs are a type of internal management document. |
| _IRM 1.11.9.1.3_, Roles and Responsibilities | Paragraph (3) - Added obsolesced IRMs under the responsibility of program directors. |
| _IRM 1.11.9.1.6_, Terms | - Paragraph (2) - Added definition of a "business unit senior executive" .<br>  <br>- Paragraph (11) - Clarified the definition of "internal reviewer" to include affected individuals.<br>  <br>- Paragraph (17) - Clarified substantive changes are non-editorial. |
| _IRM 1.11.9.1.8_, Related Resources | - Paragraph (2) - Clarified the description of the IRM Preview Tool.<br>  <br>- Paragraph (2) - Added the IRM Author Curriculum to the list of tools for the IRM authoring and clearance processes.<br>  <br>- Paragraph (2) - Added the IMD Electronic Clearance website to the list of tools for the IRM authoring and clearance processes. |
| _IRM 1.11.9.2_, Clearance Process Overview | Paragraph (10) step 9 - Updated the use of e-Clearance when archiving documents with the IRS Historical Research Library. |
| _IRM 1.11.9.2.1_, Instances of Streamlined Clearance | - Paragraph (1) - Incorporated adding and updating internal controls through streamlined clearance from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024.<br>  <br>- Paragraph (3) - Added how to create streamlined clearance request on e-Clearance. |
| _IRM 1.11.9.2.1.2_, Incorporating Interim Guidance into the IRM | Paragraph (2)(1)(c) -Provided reference when archiving documents with the IRS Historical Research Library. |
| _IRM 1.11.9.2.1.3_, Incorporating Policy Statements and Servicewide Delegation Orders into the IRM | - Updated title for consistency and to clarify that the guidance is for Servicewide procedures.<br>  <br>- Added paragraph (2) - Provided reference for business unit delegation orders. |
| _IRM 1.11.9.2.1.4_, Incorporating Internal Controls into the IRM | Added new subsection to incorporate internal controls guidance from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024. |
| _IRM 1.11.9.3_, Identifying Reviewers | Added paragraph (3) - Clarified that authors send e-Clearance automated emails to their list of reviewers. This content was previously in paragraph (1). |
| _IRM 1.11.9.4_, Specialized Reviewers | Updated various business unit email addresses. |
| _IRM 1.11.9.4.2.2_, Clearance of Information about Privacy and Information Protection | Added IRM reference for additional information on inadvertent/unauthorized disclosures or accesses. |
| _IRM 1.11.9.4.4_, Labor/Employee Relations & Negotiations | - Revised entire subsection and incorporated instructions when potential IRM changes do and do not impact bargaining unit employees’ conditions of employment from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024. In addition, clarified procedures when notice and bargaining with NTEU are and are not required.<br>  <br>- Paragraph (2) - Added Caution to advise that responses from LERN must be received before clearing the IRM. |
| _IRM 1.11.9.4.6_, Taxpayer Correspondence Services | Updated name of Office of Taxpayer Corresponcence (OTC) to Taxpayer Correspondence Services (TCS). |
| _IRM 1.11.9.4.8_, Chief Data & Analytics Officer, Research, Applied Analytics & Statistics (RAAS) | Paragraph (1) - Updated the Chief Data and Analytics Officer’s responsibilities regarding data governance. Included content from previous paragraph (3) for clarity. |
| _IRM 1.11.9.5.1_, Forwarding the IRM for Clearance | - Paragraph (3)(a) - Clarified the definition of "business unit senior executives" .<br>  <br>- Paragraph (3)(b) - Added SPDER’s sample clearance email is intended for the rare use of Form 2061.<br>  <br>- Paragraph (4) - Clarified to include assessments. |
| _IRM 1.11.9.5.2_, Documents Sent for Clearance - Clearance Package | Added zip file of incorporated IG to the list of documents sent for initial clearance. |
| _IRM 1.11.9.5.3_, Form 2061 - Document Clearance Record | Added paragraph (4) - Minimum requirements for a complete Form 2061. |
| _IRM 1.11.9.6_, Comment Methods and Options | Clarified the comment menu type and reviewer comment options. |
| _IRM 1.11.9.7_, Guidelines for Reviewers | - Paragraph (2) - Clarified reviewers may also provide editorial comments.<br>  <br>- Paragraph (2) - Added a Caution statement to remind reviewers to be mindful of potential differences between comparing the XML file and the PDF generated by the IRM Preview Tool. |
| _IRM 1.11.9.7.1_, Review Assessment and Reviewer’s Signature | Paragraph (2) and (3) - Reorganized content and added paragraph (4). |
| _IRM 1.11.9.7.2_, Personally Identifiable Information (PII) or Federal Tax Information (FTI) Breach Actions | Paragraph (2)(c) - Added email address to contact the PGLD Incident Management Office. |
| _IRM 1.11.9.8_, Responding to Reviewers’ Comments | Incorporated procedures for responding to reviewers from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024:<br> <br>- Paragraph (2) - Added general time frame to respond to substantive comments.<br>  <br>- Paragraph (3) - Added time frame to incorporate agreed upon changes and added clarifying Reminder. |
| _IRM 1.11.9.9_, Resolving Disagreements | Incorporated procedures for resolving disagreements from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024:<br> <br>- Paragraph (5) - Provided instruction for authors who make suggested updates and do not receive revised assessments upon request. Added Note to clarify these procedures do not apply to initial clearance request responses.<br>  <br>- Paragraph (6) ( _not included in RAAS-01-0824-0003_) \- Removed “overseeing Deputy Commissioner” per the new IRS top-level structure. Clarified the definition of "business unit senior executives" .<br>  <br>- Paragraph (7) - Added IRM reference to follow when an originating office receives a non-concurrence and does not receive a follow-up response from the reviewing office. |
| _IRM 1.11.9.9.1_, Issuing IRM While Disagreements are Discussed | Incorporated procedures for issuing the IRM during disagreements from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024:<br> <br>- Paragraph (2) - Added business unit IMD coordinator to notification requirements.<br>  <br>- Paragraph (4) - Added requirement to clearly document and retain document clearance records when issuing an IRM with outstanding unresolved concerns.<br>  <br>- Paragraphs (5) & (6) - Provided guidance for rare circumstances when an IRM is issued by an originating office, and a reviewing office’s non-concurrence was never addressed. |
| _IRM 1.11.9.10_, Final Stages of the Clearance Process | Paragraph (1) - Clarified author and coordinator responsibilities regarding the final clearance process. |
| _IRM 1.11.9.10.1_, Create Final Clearance Package | - Paragraph (2) - Reorganized and clarified the list of documents required for the final clearance package.<br>  <br>- Paragraph (2) - Added IGM e-Clearance archive emails to the list for instances when e-Clearance is used to clear and approve IGMs.<br>  <br>- Paragraph (3) - Incorporated zip file attachment requirements for IRMs issued with unresolved disagreements from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024. |
| _IRM 1.11.9.10.2_, Management’s Final Review | Incorporated guidance for managers conducting IRM final reviews from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024:<br> <br>- Paragraph (1) - Added ensuring appropriate business units being given review opportunity. After RAAS-01-0824-0003 was issued, added managers ensuring proper assessments, reviewing non-response recordings, and signing Form 1767, if authorized.<br>  <br>- Paragraph (2) - Included management’s review of non-concurrences and applicable actions. |
| _IRM 1.11.9.10.4_, Final Review by IMD/IRM Coordinator | - Paragraph (2) - Added Note that author should be contacted for any changes to the IRM after management has approved.<br>  <br>- Paragraph (3) - Clarified the steps listed are for the IMD/IRM coordinator to publish the IRM. |
| _IRM 1.11.9.10.5_, Archiving Clearance Documents | - Paragraph (1) - Clarified that documents should be either uploaded to e-Clearance or, if Form 2061 was used, forwarded to the IRS Historical Research Library.<br>  <br>- Paragraph (1) Note - Specified authors should contact their business unit IMD coordinator prior to forwarding IRM packages if Form 2061 was used for clearance.<br>  <br>- Paragraph (3) E-Clearance - Incorporated guidance that emails to the IRS Historical Research Library are no longer needed when e-Clearance is used from RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), dated 08-14-2024.<br>  <br>- Paragraph (3) Form 2061 - Added authors should contact their business unit IMD coordinator prior to forwarding IRM packages. |
| Throughout | Made various editorial changes including:<br> <br>- Updated organizational titles to reflect the current IRS structure.<br>  <br>- Incorporated plain writing techniques including active voice and present tense.<br>  <br>- Updated web addresses and references.<br>  <br>- Corrected capitalization, typos, grammar, etc. |

#### Effect on Other Documents

IRM 1.11.9, dated December 12, 2023 and effective January 01, 2024, is superseded. This IRM incorporates interim guidance memorandum RAAS-01-0824-0003, Updates to IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM), issued on August 14, 2024.

#### Audience

The IMD community: IRM authors, IMD/IRM coordinators, their managers, and those responsible for the clearance, review and approval of IRM material.

#### Effective Date

(02-26-2025)

Holly A. Donnelly

Director, Strategy and Business Solutions

Research, Applied Analytics and Statistics (RAAS)

**1.11.9.1** **(02-26-2025)**

### Program Scope and Objectives

1. **Purpose:** This IRM section contains guidance for clearing Internal Revenue Manuals (IRMs), a type of internal management document (IMD). Specifically, IRM 1.11.9:



1. Establishes Servicewide standards and procedures for reviewing and approving a new, revised or obsolete IRM section.

2. Provides guidance and information to program owners on approving the issuance of a new or revised IRM section.

3. Provides guidance on completing document clearance requests for IRMs.

4. Contains guidance on incorporating issued interim guidance, delegation orders and policy statements into the IRM and the clearance of these updated IRMs.


2. **Audience:** These procedures apply to IRS employees responsible for issuing, authoring, reviewing, approving and managing IRMs including:



   - IRM authors

   - IMD/IRM coordinators

   - IRM reviewers

   - Managers with IMD program responsibilities

   - Program directors


3. **Policy Owner:** Director, Strategy and Business Solutions (SBS) - Research, Applied Analytics and Statistics (RAAS).

4. **Program Owner:** The Office of Servicewide Policy, Directives and Electronic Resources (SPDER), within SBS - RAAS is the program office responsible for overseeing the IMD program and providing Servicewide IMD policy and guidance including the IRM clearance process. Each business unit is responsible for establishing an internal process for managing their IRMs based upon these Servicewide processes.

5. **Contact Information:** Contact SPDER via email at \*SPDER or visit the SPDER home page for more information.


**1.11.9.1.1** **(01-24-2017)**

#### Background

1. SPDER designs, implements, and sets the Servicewide standards for the clearance (review and approval) of IRMs. Refer to IRM 1.11.1.6, IMD Roles and Responsibilities, for information about executive, business unit and program office IRM requirements.


**1.11.9.1.2** **(01-24-2017)**

#### Authority

1. By law, federal agencies document, publish and maintain records of policies, authorities, procedures and organizational operations. The IRM is the source of IRS operational guidance and information. Refer to IRM 1.11.1.1.2, Authority, for the authorities and legal obligations of IMDs.

2. Clearance documents are official records and there is a requirement to maintain them in the IRS Historical Research Library. Clearance documents are subject to federal records management requirements and National Archives and Records Administration (NARA) as provided in Document 12990, IRS Records Control Schedules. Refer to the table in IRM 1.11.1.1.2(2) for legal references.


**1.11.9.1.3** **(02-26-2025)**

#### Roles and Responsibilities

1. The Director, Strategic Business Solutions (SBS), RAAS, is the program director responsible for IMD program administration. The Director, SBS, designates oversight responsibility for the IMD program including IRMs to the Director, SPDER.

2. The Director, SPDER, has oversight responsibility for the IMD program of the IRS including IRMs.

3. Program directors Servicewide oversee IMD administration under their program responsibility, including approval of new, revised and obsolesced IRMs.

4. Program owners are the program offices that manage and execute the IRM program.

5. Management and assigned authors are responsible for determining the effects of proposed IRM changes on other program offices and documents, and forwarding revisions to these offices for review and comment.

6. Each business unit assigns IMD and/or IRM coordinators to assist in managing the processing of their IRMs. IMD coordinators or designated IMD/IRM staff also coordinate incoming requests for clearance review as an IRM clearance point of contact (POC).


**1.11.9.1.4** **(04-17-2020)**

#### Program Management and Review

1. SPDER monitors changes to the IRS’s Servicewide IRM inventory including new, updated and obsolete content.



### Note:



The IRS Historical Research Library maintains data information on IRM clearance packages.


**1.11.9.1.5** **(04-17-2020)**

#### Program Controls

1. The originating business unit ensures their IRM clearances are complete and in accordance with IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM).

2. The IRS Historical Research Library ensures clearance packages are present for all published IRM sections.


**1.11.9.1.6** **(02-26-2025)**

#### Terms

01. **Authorized Delegate** \- The senior manager delegated responsibility for IMD program administration by the member of the Senior Executive Service with program oversight per Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD).

02. **Business Unit Senior Executive** \- A senior executive who reports directly to the Commissioner of Internal Revenue, Deputy Commissioner of Internal Revenue, Chief Tax Compliance Officer or Chief Operating Officer.

03. **Clearance** \- A formal review and approval of an IRM prior to issuance.

04. **Clearance Point of Contact (POC)** \- A designated IMD/IRM coordinator or contact within each business unit responsible for managing, coordinating and/or forwarding IRMs received for review and clearance for assignment to reviewers in affected offices. The business unit’s IRM program office may use a designated mailbox to manage the program.

05. **Clearance Process** \- An established, formal process that provides affected business units and program offices the opportunity to review and comment on changes to information in the IRM to ensure it is complete, correct, and does not conflict with another policy, procedure, or process. The clearance process also documents the approval of IRS procedural changes by the responsible program owner and program director.

06. **Document Clearance Record (DCR)** \- A document used to perform the review, assessment, and approval of an IMD that serves as a routing slip and the official historical record of the IMD clearance; either IMD Electronic Clearance (e-Clearance), or Form 2061, Document Clearance Record.

07. **Editorial Change** \- A non-substantive revision to correct minor errors and typographical changes. Refer to IRM 1.11.2.8.1, Editorial Update Process, for examples.

08. **External Reviewer**\- An affected business unit/program office outside of the originating business unit.

09. **IMD Electronic Clearance** \- A website that automates and centralizes the complete IRM review process, also known as “e-Clearance.” It documents the review, comment and approval of the IRM. **This is the required method of IRM clearance.**

10. **Internal Management Document (IMD)** \- An official communication which designates policies, authorities, and instructions to IRS officials and employees. IMDs include the IRM, interim guidance, policy statements and delegation orders.

11. **Internal Reviewer** \- Affected individuals, organizations, or program offices within the originating business unit. Can also be known as a subject matter expert (SME).

12. **Program Director** \- A member of the Senior Executive Service (SES) or their authorized delegate responsible for program administration including issuance and approval of IRMs. To identify a member of the SES, refer to _IRM 1.11.9.10.3 (1)_, Approval by Program Director. Refer to Delegation Order 1-69 (New), Authorization to Approve an Internal Management Document (IMD), for who can be an authorized delegate.

13. **Program Owner** \- The program office with primary responsibility for establishing the process and procedures necessary to implement and manage an IRS program. The program director over this office authorizes and approves new or revised IRMs.

14. **Originating Business Unit** \- The business unit that owns the respective IRM section.

15. **Reviewer** \- A subject matter expert responsible for reviewing an IRM on behalf of their program office, area or business unit.

16. **Specialized Reviewer** \- A specific and identified program office, identified in _IRM 1.11.9.4_, Specialized Reviewers, with oversight in a particular area affecting Servicewide operations.

17. **Substantive Change** \- A non-editorial revision or change to procedural or operational matter.


**1.11.9.1.7** **(12-12-2023)**

#### Acronyms

1. The table lists commonly used acronyms and their definitions:




| Acronym | Definition |
| :-: | :-: |
| DCR | Document Clearance Record |
| FOIA | Freedom of Information Act |
| FTI | Federal Tax Information |
| IG | Interim Guidance (either an interim guidance memorandum or SERP IRM Procedural Update) |
| IGM | Interim Guidance Memorandum |
| IMD | Internal Management Document |
| IPU | IRM Procedural Update |
| IRM | Internal Revenue Manual |
| LERN | Labor/Employee Relations & Negotiations |
| M&P | Media and Publications |
| MT | Manual Transmittal |
| OUO | Official Use Only |
| PII | Personally Identifiable Information |
| POC | Point of Contact |
| SBU | Sensitive but Unclassified |
| SERP | Servicewide Electronic Research Program |
| SME | Subject Matter Expert |
| SPDER | Servicewide Policy, Directives and Electronic Resources |
| XML | Extensible Markup Language |


**1.11.9.1.8** **(02-26-2025)**

#### Related Resources

1. The following IRM sections provide guidance on related IMDs.




| **Type of IMD** | **Additional Source of Clearance Guidance** |
| --- | --- |
| IRM | IRM 1.11.2, Internal Revenue Manual (IRM) Process |
| Servicewide Policy Statement | IRM 1.11.3, Servicewide Policy Statement Process |
| Servicewide Delegation Order | IRM 1.11.4, Servicewide Delegation Order Process |
| Interim Guidance | IRM 1.11.10, Interim Guidance Process |

2. The following tools can be used during the IRM authoring and clearance processes.




| Tool | Description |
| :-: | :-: |
| IMD Electronic Clearance Training | This website provides electronic clearance training for authors, reviewers, managers, approvers, and coordinators. It contains the most up to date IMD Electronic Clearance Process Guide and various training recordings. |
| IRM Clearance Decision Tool | This tool helps you determine what offices should review your IRM. |
| Chief Counsel Clearance Determination Tool | This determination tool helps decide if your IRM requires review by the Office of the Chief Counsel. |
| IRM Preview Tool | This tool allows authors to preview the display and hyperlinks of an IRM before publishing. |
| IRM Author Toolkit | This tool gives step-by-step assistance on the clearance process for authors. |
| IRM Author Curriculum | This website provides a comprehensive listing of IRM-related courses and tools/resources for each stage of the IRM process. |
| IMD Electronic Clearance | A website that automates and centralizes the complete IRM process, also known as “e-Clearance”. It documents the review, comment and approval of the IRM. **This is the required method of IRM clearance.** |


**1.11.9.2** **(02-26-2025)**

### Clearance Process Overview

01. Clearance takes place after authoring and before publishing.

02. Prior to clearance the author takes the following actions:




    | Actions | IRM Reference |
    | :-: | :-: |
    | Finalizes draft IRM, including an updated MT and material changes, for review and approval. | IRM 1.11.2, Internal Revenue Manual (IRM) Process |
    | Sends the draft IRM to their manager for verification of content. Author may also informally send to other affected offices, stakeholders and SMEs. | IRM 1.11.2.7, Conduct an Informal Review |

03. Authors conduct the review and approval processes using IMD Electronic Clearance (e-Clearance). This serves as a control and record of routing, reviewing, approving, and archiving.



    ### Exception:



    If e-Clearance is down for more than three business days or the author is unable to use the clearance website due to limited functionality, Form 2061, Document Clearance Record, can be used in its place. Limited functionality includes visually impaired users and users in departments that cannot use the e-Clearance website (i.e., Criminal Investigation).

04. The author sends the IRM to the affected offices and stakeholders for review and assessment using e-Clearance.

05. Affected offices and stakeholders review IRMs when new or revised IRM content contains instructions or guidelines that affect their program office. Reviewing offices are responsible for considering the effect of the revisions on their procedures, providing relevant feedback (if any), and recording their assessment.

06. The author considers all feedback and comments, resolves any disagreements per _IRM 1.11.9.9_, and revises the IRM file as necessary.

07. The responsible program director approves IRM changes to ensure the instructions are consistent with IRS operational processes and authorities.

08. The IRM must complete clearance and be submitted for publishing within one year of the date clearance was initiated or it must be cleared again.

09. The IMD/IRM coordinator is the last review point prior to uploading the IRM for publishing.

10. The following are the steps in the IRM clearance process. Detailed descriptions of these topics are in the referenced IRM subsections.




    | Step | Actions | IRM Reference |
    | :-: | :-: | :-: |
    | 1 | Author identifies reviewers. | _IRM 1.11.9.3_, Identifying Reviewers, and _IRM 1.11.9.4_, Specialized Reviewers |
    | 2 | Author sends generated e-Clearance email to reviewers. | _IRM 1.11.9.5_, Clearance Submission Guidelines |
    | 3 | Reviewers comment and provide an assessment on changes within 30 days, plus extension up to 15 days. | _IRM 1.11.9.7_, Guidelines for Reviewers |
    | 4 | Author considers reviewers’ comments and updates the draft IRM as applicable. | _IRM 1.11.9.8_, Responding to Reviewers’ Comments, and _IRM 1.11.9.9_, Resolving Disagreements |
    | 5 | Author creates the final clearance package. | _IRM 1.11.9.10.1_, Create Final Clearance Package |
    | 6 | Management reviews the final clearance package. | _IRM 1.11.9.10.2_, Management Final Review |
    | 7 | Program director reviews the final package and approves the new, changed or obsolesced content. | _IRM 1.11.9.10.3_, Approval by Program Director |
    | 8 | Author forwards the approved IRM to IMD/IRM coordinator for publishing who conducts the final review for submission to M&P for publication. | _IRM 1.11.9.10.4_, Final Review by IMD/IRM Coordinator |
    | 9 | IMD/IRM coordinator ensures IRM clearance documents are located on e-Clearance for archival with the IRS Historical Research Library. | _IRM 1.11.9.10.5_, Archiving Clearance Documents |

11. IRM revisions that only involve editorial changes or the incorporation of previously cleared guidance may follow a streamlined clearance. Refer to _IRM 1.11.9.2.1_, Instances of Streamlined Clearance.

12. The standard 30-day clearance time frame may be reduced to meet business or operating needs following _IRM 1.11.9.5.4.1_, Expedited Clearance.


**1.11.9.2.1** **(02-26-2025)**

#### Instances of Streamlined Clearance

1. Clearance is abbreviated or streamlined when IRM changes are editorial or incorporate documents previously approved and cleared. These types of IRM changes include:



   - Editorial updates.

   - Incorporating interim guidance (IG) into the IRM.

   - Incorporating delegation orders and policy statements into IRM 1.2, Servicewide Policies and Authorities.

   - Incorporating internal controls into the IRM or revising them.


2. The minimum required level of review and approval include:



   - The author’s manager.

   - The program director (or documented designee).

   - The business unit IMD/IRM coordinator.


3. When creating a new streamlined clearance request on e-Clearance, select “Yes” to confirm that the streamlined clearance conditions have been met.

4. If using Form 2061, Document Clearance Record, check block 3 when clearing the IRM using the streamlined clearance process.



### Note:



The IRM must meet the "Exception" category listed in _IRM 1.11.9.2_, Clearance Process Overview, to use Form 2061, Document Clearance Record.

5. Follow IRM 1.11.2.8.1, Editorial Update Process, for completing the IRM clearance package for publishing.


**1.11.9.2.1.1** **(01-24-2017)**

##### Clearance of Editorial Updates

1. The editorial update process allows for a modified clearance process when IRM updates are strictly to correct format, punctuation, grammatical or other typographical errors in the published IRM. Refer to IRM 1.11.2.8, Editorial Updates, for a detailed list of editorial changes and the rules for preparing the IRM XML file.

2. Editorial changes do not affect the meaning of the information, content or guidance of the IRM. Editorial updates require minimal review.

3. The author’s manager, the program director, and the IMD/IRM coordinator are the only reviewers. Management may require additional levels of review.


**1.11.9.2.1.2** **(02-26-2025)**

##### Incorporating Interim Guidance into the IRM

1. An IRM author may use the streamlined clearance process when updates to the IRM consists of only incorporating an interim guidance memorandum (IGM) or a Servicewide Electronic Research Program (SERP) IRM Procedural Update (IPU).



### Note:



Incorporate interim guidance (e.g., IGMs or SERP IPUs) into the applicable IRM(s) within two years from issuance, the stated memo expiration date, or sooner if required by the business unit. Refer to IRM 1.11.10.9.1, Incorporate Interim Guidance into the IRM.

2. Follow these guidelines when revising an IRM to incorporate interim guidance (IGMs or IPUs):




| **If:** | **Then:** |
| --- | --- |
| (1) The interim guidance (IG) was:<br> <br>1. Cleared and concurred through all affected offices and specialized reviewers within the past two years, and<br>      <br>2. Incorporated into the IRM unchanged (language is the same as what was cleared and approved). | (1) You can use the streamlined clearance.<br> <br>1. Add the information from the IG into the IRM.<br>      <br>2. Complete a document clearance record using e-Clearance for management, IMD/IRM coordinator and program director/executive approval and signature. Forward to any other reviewers as determined by management.<br>      <br>3. Include the clearance documents secured during clearance of the IG in the IRM clearance package. Follow the procedures in _IRM 1.11.9.10.5_, Archiving Clearance documents, to ensure the IRM is properly archived with the IRS Historical Research Library. |
| (2) If the IG language must be revised, reinterpreted for inclusion in the IRM, or if any of the conditions in (1) above are not met, | (2) You must follow the rules under _IRM 1.11.9.3_, Identifying Reviewers, as the guidance requires review through all affected program offices and specialized reviewers. |

3. Refer to IRM 1.11.10, Interim Guidance Process, for complete guidance on preparing and clearing IG.


**1.11.9.2.1.3** **(02-26-2025)**

##### Incorporating Policy Statements and and Servicewide Delegation Orders into the IRM

1. After approval, signature and issuance of a Servicewide policy statement or Servicewide delegation order (refer to IRM 1.11.3, Servicewide Policy Statement Process, and IRM 1.11.4, Servicewide Delegation Order Process), SPDER incorporates the word-for-word content of the policy statement or delegation order into IRM 1.2.1, Servicewide Policy Statements, and IRM 1.2.2, Servicewide Delegations of Authority, for record keeping purposes. The Office of SPDER:



1. Incorporates the approved policy statement and/or delegation order into the applicable IRM through the streamlined clearance process. Refer to IRM 1.11.2.8, Editorial Updates.

2. Publishes the IRM and archives the IRM clearance package.


2. For information regarding incorporating business unit delegation orders into an IRM, refer to IRM 1.11.4.6, Business Unit Delegation Orders Standards.


**1.11.9.2.1.4** **(08-14-2024)**

##### Incorporating Internal Controls into the IRM

1. An IRM author may use the streamlined clearance process when revising the IRM only to incorporate or revise IRM internal controls.

2. IRM internal controls are internal to the program office and based on current program oversight. Refer to IRM 1.11.2.2.4, Address Management and Internal Controls, for complete instructions on properly authoring internal controls.

3. The author’s manager, program director, and IMD/IRM coordinator are the only reviewers if incorporating or revising IRM internal controls only. Management may require additional levels of review.


**1.11.9.2.2** **(05-16-2022)**

#### Business Unit Clearance Points of Contact

1. Each business unit and specialized reviewer designates a clearance contact to receive IRM clearance requests from authors. These designated contacts assist in the coordination of IRM clearance for their business unit. Refer to Business Unit IMD Clearance Points of Contact for a list of external and specialized reviewers.

2. The clearance POC sends the IRM to affected program offices and/or SMEs identified by the author. They may also forward it to additional reviewers based on the material changes in the proposed revision.

3. The business unit clearance POC may consolidate the responses and respond back to the originator with comments and one assessment depending on their internal process.


**1.11.9.3** **(02-26-2025)**

### Identifying Reviewers

1. Identify potential reviewers of the IRM. Reviewers include:



   - Author’s manager,

   - IMD/IRM coordinator,

   - Subject matter experts,

   - Internal reviewers - Affected program offices within the originating business unit,

   - External reviewers - Affected business units/program offices outside of the originating business unit,

   - Specialized reviewers as identified in _IRM 1.11.9.4_, Specialized Reviewers, and

   - Employees who use the new or revised procedures. Refer to _IRM 1.11.9.3.1_, Requesting Employee Feedback, for more information.



     ### Example:



     Taxpayer Services (TS) owns IRM 3.11.6, therefore any program office outside of TS is an external reviewer.





     ### Example:



     IRM 3.11.6 contains official use only (OUO) content. If new OUO content is added, the IRM must be reviewed by a specialized reviewer in Privacy, Governmental Liaison and Disclosure (PGLD).


2. Identify affected program offices:



1. If the changes potentially affect another business unit’s or program office’s policies, work processes, procedures, official published products, or IMDs, then send to that business unit or office for review and concurrence.



      ### Note:



      A simple reference to a procedure in another IRM does not require clearance through the responsible program office. You must submit the IRM for clearance only if the revision involves a change to the other office's published products, procedures or processes.

2. If another program office owns the changes, or if another office implements or conducts the work, send to that business unit/program office for review and concurrence.


3. E-Clearance allows authors to initiate a list of reviewers to send access to the IRM for clearance. The author sends the IRM clearance package via an automated email created from e-Clearance.

4. When sending your IRM outside of your business unit, always send the clearance request to the business unit’s IMD clearance POC in addition to the known reviewer. Do not send duplicate emails to IMD coordinators and the business unit POC mailbox. To identify the IMD clearance contact in each business unit, check the Business Unit IMD Clearance Points of Contact listing on the SPDER website.

5. Contact the IMD/IRM coordinator for help in identifying a SME or contact in a particular program office.


**1.11.9.3.1** **(01-24-2017)**

#### Requesting Employee Feedback

1. Each business unit must make new or revised IRMs available for feedback to employees who use the IRM. Initiate the feedback process at the time of clearance. The time frame for obtaining feedback from employees who use the IRM is five business days.

2. Each business unit determines their own feedback process. Contact the IMD coordinator for your business unit’s process on IRM employee feedback.

3. While authors are not required to respond or address employee comments, they must include them in the historical IRM file.


**1.11.9.4** **(02-26-2025)**

### Specialized Reviewers

1. Identified program offices with oversight in a particular area affecting Servicewide operations are specialized reviewers. Request review from a specialized reviewer when the IRM contains content within that program office's oversight, as described below:




| **When material contains:** | **Then send the IRM to:** | **IRM Subsection** |
| --- | --- | --- |
| Legal matters as described in _IRM 1.11.9.4.1_, Chief Counsel | Chief Counsel via email to the Chief Counsel IRM Clearance mailbox. | _IRM 1.11.9.4.1_, Chief Counsel |
| Any of the following as described in _IRM 1.11.9.4.2_, Privacy, Governmental Liaison and Disclosure:<br> <br>   - Content newly designated as official use only (OUO).<br>     <br>   - Procedures, policies, or instructions relating to the disclosure or potential disclosure of official information.<br>     <br>   - Procedures, policies, or instructions relating to privacy or information protection. | Privacy, Governmental Liaison and Disclosure (PGLD) via email to \*PGLD IMD SPOC. | _IRM 1.11.9.4.2_, Privacy, Governmental Liaison and Disclosure |
| Changes to any sections in the following IRM parts:<br> <br>   - Part 1 – Organization, Finance, and Management<br>     <br>   - Part 3 – Submission Processing<br>     <br>   - Part 4 – Examining Process<br>     <br>   - Part 5 – Collecting Process<br>     <br>   - Part 7 – Rulings and Agreements<br>     <br>   - Part 8 – Appeals<br>     <br>   - Part 20 – Penalty and Interest<br>     <br>   - Part 21 – Customer Account Services<br>     <br>   - Part 22 – Taxpayer Education and Assistance<br>     <br>   - Part 25 – Special Topics<br>     <br>### Exception:<br>Only forward SERP IPUs to TAS for review if the change affects how a member of the public files, pays, complies with their tax requirements or interacts with the IRS. | Taxpayer Advocate Service (TAS) via email to \*TAS IMD SPOC. | _IRM 1.11.9.4.3_, Taxpayer Advocate Service |
| Changes to conditions of employment of bargaining unit (BU) employees and<br> after completing the steps in IRM 1.11.2.5.1.4, IRM Changes Affecting Conditions of Employment of Bargaining Unit Employees | Labor/Employee Relations & Negotiations via email to \*WRD-Mailbox. | _IRM 1.11.9.4.4_, Labor/Employee Relations & Negotiations |
| Any of the following information:<br> <br>   - Instructions on developing or revising taxpayer notices or letters.<br>     <br>   - Guidance on handling incorrect correspondence. | Taxpayer Correspondence Services (TCS) via email to \*TS TCS IMD POC. | _IRM 1.11.9.4.6_, Taxpayer Correspondence Services |
| Procedures relating to:<br> <br>   - Implementation of new legislation affecting tax administration, or<br>     <br>   - Interactions with Congress or a member of Congress (e.g., a U.S. Representative or a Senator). | The Legislative Affairs point of contact. | _IRM 1.11.9.4.5_, Legislative Affairs |
| Content relating to identity theft | Identity Protection - TS Office of Identity Protection via email to \*TS CAS:AM:IPSO-IDT-IRMs. | _IRM 1.11.9.4.7_, Identity Protection |
| References to data governance, data and metadata standards, data quality and integrity, machine learning, artificial intelligence, and data access issues | Chief Data & Analytics Officer, RAAS, via email to \*RAAS IMD POC. | _IRM 1.11.9.4.8_, Chief Data & Research Analytics Officer, Research, Applied Analytics & Statistics (RAAS) |


**1.11.9.4.1** **(12-12-2023)**

#### Chief Counsel

1. The Office of Chief Counsel reviews IRMs and interim guidance (IG) that reference one or more of the following authorities for legal accuracy:



   - Federal law

   - Treasury regulations

   - Revenue rulings

   - Revenue procedures

   - Notices

   - Announcements

   - Treasury orders

   - Treasury directives

   - Servicewide policy statement

   - Servicewide delegation order


### Note:

Not all IRMs and interim guidance referencing the above authorities require review by Chief Counsel.

2. Scope of review - Chief Counsel generally reviews the IRM section for legal matters focusing on the substantial changes identified in either the material changes portion of the draft IRM or in the track change file submitted. While Chief Counsel does rely on the listing of substantial changes and on the track change file submitted for review, Chief Counsel also considers whether the authority for legal matters not updated has changed or whether to address new legal matters when there is an updated IRM.

3. An author **must submit** an IRM to Chief Counsel if Chief Counsel requests to review the IRM, or if the IRM contains new or revised guidance interpreting an authority listed in paragraph (1) above. Additionally, IRMs in the following chapters must be submitted for Chief Counsel review:



   - IRM Chapter 3.11, Returns and Documents Analysis

   - IRM Chapter 3.12, Error Resolution

   - IRM Chapter 3.13, Campus Document Services (except IRM 3.13.6, Submission Processing Image Control Team (ICT) Correspondence Scanning, and IRM 3.13.62, Media Transport and Control)

   - IRM Chapter 3.21, International Returns and Document Analysis

   - IRM Chapter 3.22, International Error Resolution


4. An author **may submit** an IRM/IG to Chief Counsel when:



   - The author wants to verify whether a current interpretation in the IRM is valid, or

   - The author has a specific question relating to legal matters and the content relates to an authority in paragraph (1) above.


5. An author should **not submit** an IRM/IG to Chief Counsel if Chief Counsel previously indicated through email the IRM section does not require their review, if the IRM is revised solely for editorial issues, reorganization of content or renumbering, or if it is being obsolesced. Additionally, IRMs in the following chapters should not be submitted for Chief Counsel review:



   - IRM Chapter 1.4, Resource Guide for Managers (except IRM sections addressing legal matters, e.g., IRM 1.4.51, Insolvency)

   - IRM Part 2, Information Technology − all chapters

   - IRM Chapter 3.10, Campus Mail and Work Control

   - IRM Chapter 3.24, ISRP System


### Exception:

Authors may submit an IRM meeting the above criteria to Chief Counsel for review if there is a specific question relating to legal matters in the IRM section. The author must articulate the question in the clearance email to Chief Counsel.

6. E-Clearance auto-generates an email when Chief Counsel is identified as a Specialized Reviewer. Send clearance requests to the Chief Counsel IRM Clearance mailbox.



1. **Do not** “cc” any attorneys or Chief Counsel subject matter experts in the email requesting clearance. If an attorney provided assistance on the revision of a document, indicate the attorney’s name and any Chief Counsel case tracking number (interim guidance only) in the body of the email sent to the Chief Counsel IRM clearance contact. If you believe an attorney who didn’t provide assistance on the revision should have the document directed to them for review, please state why so the attorney’s manager may take it into account.


7. Chief Counsel generally does not review or verify the following unless specifically requested:



   - Cross-references to forms, notices, other IRMs or other documents.

   - Listing of transaction codes (TC Codes).

   - Basic disclosure and privacy rules when clearing an IRM through PGLD.

   - Indexed figures in IRMs contained in the Internal Revenue Bulletins (IRBs).

   - Due dates specified on tax forms.


**1.11.9.4.2** **(10-01-2021)**

#### Privacy, Governmental Liaison and Disclosure

1. Authors must submit IRMs to Privacy, Governmental Liaison and Disclosure (PGLD) for review and clearance if their instructions involve any of the following:



1. Disclosure or potential disclosure of official information or data.

2. Newly designated official use only (OUO) information. For additional information, refer to _IRM 1.11.9.4.2.1_, Clearance of Official Use Only Information.

3. Privacy or information protection. For additional information, refer to _IRM 1.11.9.4.2.2_, Clearance of Information about Privacy and Information Protection.


2. Laws and policies relating to disclosure issues may change over time and the sensitivity of content designated OUO may also change. For this reason, responsibility remains with IRM authors and program management to consider when IRM content no longer warrants an OUO designation. Do not send OUO content to PGLD if they reviewed the original designation or if removing the OUO designation.

3. For IRMs containing identity theft content, refer to _IRM 1.11.9.4.7_, Identity Protection. If an IRM contains both identity theft and OUO/disclosure content, send the IRM to both the PGLD and the Identity Protection Strategy & Oversight offices.

4. Include a completed Form 13709, Privacy, Governmental Liaison and Disclosure Checklist for IMD and Training Materials, with the clearance request. Within the Form 13709 identify the IRM subsection number(s) or page number(s) for the content you believe requires PGLD review.

5. Once PGLD is identified, the Form 13709 generates. Send clearance requests to \*PGLD IMD SPOC.


**1.11.9.4.2.1** **(12-12-2023)**

##### Clearance of Official Use Only (OUO) Information

1. Submit IRMs containing content newly designated as Official Use Only (OUO) to PGLD for review.

2. Designate IRM content as OUO following the criteria outlined in IRM 1.11.2.5.3, Designate IRM Content as Official Use Only (OUO).

3. The following examples of IRM content may require designation of OUO:



1. Instructions relating to enforcement strategies, tolerances and criteria where public release would lead to a reasonable expectation of harm to IRS actions or operations.

2. Material where public release would significantly impede or nullify IRS actions in carrying out a responsibility or function.

3. Data processing information that would result in taxpayers altering their filing practices or avoiding payment of taxes.


### Note:

Generally, do not classify employee contact names and phone numbers as OUO. Refer to IRM 1.11.2.5.5, Contact Information.

### Reminder:

You must follow other privacy and security guidance to protect sensitive information, whether electronic files or on paper. Encrypt documents containing sensitive information when sending out via email or saving to a hard drive. Refer to IRM 10.5.1.6.8, Email and Other Electronic Communications, and IRM 10.8.1, Policy and Guidance.

4. Authors coordinate with SMEs and management to make OUO determinations. The Office of Disclosure reviews any newly designated proposed OUO material for compliance with FOIA and notifies the author if the identified OUO content does not meet FOIA requirements.



### Note:



The clearance file submitted to the IRS Historical Research Library must contain documentation outlining deviations from recommendations made by the Office of Disclosure.

5. An official who has the delegated authority per IRM 1.2.2.12.1, Delegation Order 11-1 (formerly DO-89, Rev.10), Administrative Control of Documents and Material, must approve the designation of information as OUO. Select “Yes” when prompted by e-Clearance to indicate new, changed or de-designated OUO. If using Form 2061 under the exception guidance found in _IRM 1.11.9.2_, Clearance Process Overview, select “Yes” in block 8.


**1.11.9.4.2.2** **(02-26-2025)**

##### Clearance of Information about Privacy and Information Protection

1. PGLD is responsible for ensuring consistency in all processes and procedures affecting the way the IRS handles privacy information protected by statute, regulation, executive order, or internal policy.

2. Authors must submit all IRMs to PGLD involving privacy and data protection. Examples include:




| Criteria: | Description: |
| :-: | :-: |
| General privacy and data protection compliance | - Compliance with any privacy and data protection laws, regulations, and policies.<br>     <br>   - References to IRM 10.5, Privacy and Information Protection and subsections. |
| Definition, use, or management of personally identifiable information (PII) and other sensitive information, including sensitive but unclassified (SBU) data | - Appropriately protecting PII and other sensitive information in email or online, during shipping, while stored (hardcopy or electronic format), in flexiplace, telework, or home as POD situations, or on SharePoint.<br>     <br>   - Procedures related to privacy impact assessments (PIAs) or security assessments and accreditation.<br>     <br>   - Elimination or reduction in use of taxpayer identification numbers.<br>     <br>   - Use of live data in training or developing systems. |
| Adoption or development of new technology; new uses for existing technology | - Online services<br>     <br>   - Social media<br>     <br>   - Mobile devices |
| Privacy risk assessments and privacy reporting requirements | Refer to IRM 10.5.2, Privacy Compliance and Assurance (PCA) Program. |
| Pseudonym use by IRS employees | Refer to IRM 10.5.7, Use of Pseudonyms by IRS Employees. |
| Potentially dangerous taxpayers (PDT) or caution upon contact (CAU) taxpayers | Refer to IRM 25.4.1, Potentially Dangerous Taxpayer, and IRM 25.4.2, Caution Upon Contact Taxpayer. |
| Inadvertent/unauthorized disclosures or accesses | - Identifying, reporting and tracking of IRS data breaches.<br>     <br>   - Data loss or breach prevention tools or procedures.<br>     <br>   - Procedures related to preventing or addressing unauthorized access or inspection of taxpayer records (UNAX).<br>     <br> Refer to IRM 10.5.1, Incident Management Program. |


**1.11.9.4.3** **(01-24-2017)**

#### Taxpayer Advocate Service

1. Authors must submit IRMs to TAS for review and clearance if their IRM section is within the following IRM Parts: 1, 3, 4, 5, 7, 8, 20, 21, 22, 25.

2. Only forward IGMs/SERP IPUs to TAS for review if the changes affect how a member of the public files, pays, complies with their tax requirements, or interacts with the IRS. Refer to _IRM 1.11.9.4_, Specialized Reviewers.

3. TAS reviews IRMs to ensure they protect taxpayer rights as defined by the Taxpayer Bill of Rights and to identify and mitigate IRS practices which might infringe on taxpayer rights or create undue burden to taxpayers. The Taxpayer Bill of Rights is published in Publication 1, Your Rights as a Taxpayer, and is also available on IRS.gov at [About Publication 1, Your Rights As A Taxpayer](https://www.irs.gov/forms-pubs/about-publication-1).

4. Employees must protect taxpayer rights when creating instructions. This promotes effective tax administration within all business units, helps to build trust and consistency, and improves voluntary compliance.

5. In accordance with IRC 7803, Commissioner of Internal Revenue, the Office of the Taxpayer Advocate identifies and proposes changes in the practices of the IRS to mitigate taxpayer problems.

6. Send clearance requests to \*TAS IMD SPOC.


**1.11.9.4.4** **(02-26-2025)**

#### Labor/Employee Relations & Negotiations

1. **Before starting the clearance process**, authors and/or management must evaluate IRMs and interim guidance for potential changes to conditions of employment of bargaining unit employees. Conditions of employment refers to personnel policies, practices, and matters impacting a bargaining unit employee’s daily work life, such as work processes or assignments, schedules, overtime, equipment, office space/design, parking, type/placement of office furniture, relocation of an office, etc. Some changes require formal notice and negotiations with the National Treasury Employees Union (NTEU) before implementing the change for bargaining unit employees. Refer to IRM 1.11.2.5.1.4, IRM Changes Affecting Conditions of Employment of Bargaining Unit Employees, and IRM 6.711.1.6, Managing Change and Dealing with the Union.

2. If it is determined the change(s) **do not** impact the working conditions of bargaining unit employees, the author may begin clearance.

3. If it is determined the change(s) may affect bargaining unit employees’ conditions of employment, the author or their manager (determined by the business unit) must complete Form 14036, Notice to National NTEU, and send it to Labor/Employee Relations & Negotiations (LERN), at \*WRD-Mailbox. LERN will determine notice/bargaining requirements and obligations prior to starting clearance.



### Caution:



If no response is received from LERN within a reasonable time frame, hindering processing the IRM, the program office must follow up with LERN. Clearance cannot move forward unless a response is received from LERN.

4. If LERN determines that **notice and bargaining with NTEU is not required**, the author and/or their manager may proceed with the IRM or IG change(s), begin clearance, and identify LERN as a specialized reviewer. Send the e-Clearance auto-generated email or Form 2061 , the draft IRM or IG and previously prepared Form 14036 with required attachments (i.e., the briefing and crosswalk) to \*WRD-Mailbox for LERN’s review and concurrence.

5. If LERN determines that **notice and bargaining with NTEU is required**, the business unit must decide if they want to implement the change(s) for non-bargaining unit employees only. Once LERN advises the author and/or their manager that bargaining obligations are met, management may begin Servicewide clearance to implement the change(s) for bargaining unit employees.


**1.11.9.4.5** **(11-01-2011)**

#### Legislative Affairs

1. Legislative Affairs is responsible for managing the IRS's relationship with members of Congress and their staff; planning, developing, directing and evaluating the legislative activities of the IRS.

2. When enacted legislation becomes law, affected IRS business units must develop an implementation plan to make program changes required by new legislation requirements. Specific implementation actions typically include IRM updates.

3. When a new IRM or change to an existing IRM relates to implementing new legislation affecting tax administration, or to official interactions with members of Congress, the IRM author must send the IRM to Legislative Affairs.

4. Send clearance requests to the Legislative Affairs point of contact.


**1.11.9.4.6** **(02-26-2025)**

#### Taxpayer Correspondence Services

1. Taxpayer Correspondence Services (TCS) reviews an IRM/IG when it contains any of the following:



   - Instructions on developing or revising taxpayer notices or letters.

   - Guidance on handling incorrect correspondence.


2. Send clearance requests for Taxpayer Correspondence Services to \*TS TCS IMD POC.


**1.11.9.4.7** **(01-24-2017)**

#### Identity Protection

1. TS Identity Protection Strategy & Oversight (IPSO) reviews all IRMs/IGs with identity theft guidance.

2. Send clearance requests to the IPSO point of contact at \*TS CAS:AM:IPSO-IDT-IRMs.


**1.11.9.4.8** **(02-26-2025)**

#### Chief Data & Analytics Officer, Research, Applied Analytics & Statistics (RAAS)

1. The Chief Data and Analytics Officer (CDAO) ensures that all IRS procedures, guidance and actions comply with the established government standards for data governance. Data governance is the management of policies and procedures to ensure the availability, usability, integrity, and security of data. The CDAO:



   - Coordinates with IRS officials to ensure IRS data needs are met.

   - Ensures IRS data conforms with data management best practices

   - Advises on the impact of the IRS infrastructure on the data asset accessibility and coordinates improvement to reduce barriers that inhibit data asset accessibility.

   - Co-chairs the Data and Analytics Strategic Integration Board (DASIB). For more information on the DASIB, refer to IRM 1.7.1.2.1, Data and Analytics Strategic Integration Board Purpose and Scope.


2. Authors must submit IRMs/IG to the Chief Data & Analytics Officer, RAAS for review and clearance if they reference any of the following:



   - Data governance

   - Guidelines that support data and metadata standards

   - Data quality

   - Data integrity

   - Data analysis or analytics

   - Data modeling

   - Artificial intelligence

   - Machine learning

   - Data access


3. Send clearance requests to \*RAAS IMD POC.


**1.11.9.5** **(01-24-2017)**

### Clearance Submission Guidelines

1. This subsection describes the following rules and processes for sending an IRM through clearance:



   - How to send an IRM for clearance.

   - Time frames for clearing IRMs.

   - What documents to send for clearing IRMs, also known as the clearance package.


2. The following procedures within this subsection are actions taken by the IRM author or the originator of the IRM.

3. To clear other IRMs refer to IRM 1.11.3, Servicewide Policy Statement Process, IRM 1.11.4, Servicewide Delegation Order Process, and IRM 1.11.10, Interim Guidance Process.


**1.11.9.5.1** **(02-26-2025)**

#### Forwarding the IRM For Clearance

1. Before submitting an IRM for clearance, an IRM author’s manager must review the revised IRM content. This internal review and approval ensures revised guidance is accurate, workable and the author’s manager considered the effect on internal program offices, external program offices and employees’ duties.

2. All reviewers perform clearance reviews simultaneously, receiving e-Clearance requests at the same time. After considering their feedback, the clearance package is sent to your manager and Director for approval.

3. The author forwards the proposed new or revised IRM and clearance documents through email or forwards the generated e-Clearance email to the identified reviewers, affected program offices, specialized reviewers and SMEs. Refer to _IRM 1.11.9.3_, Identifying Reviewers, and _IRM 1.11.9.5.2_, Documents Sent for Clearance - Clearance Package.



1. For affected program offices and specialized reviewers outside of your business unit, use the IMD Clearance Points of Contact listing. E-Clearance provides the email addresses when you select the affected program offices and specialized reviewers outside of your business unit. Include the affected program office or known SME by name in the email to the point of contact. This information is essential to ensure the correct affected program office reviews your IRM. The business unit IMD clearance point of contact forwards the clearance request to the program office contact or identified SME.



      ### Note:



      Do not email your IRM directly to a business unit senior executive. Business unit senior executives report directly to the Commissioner of Internal Revenue, Deputy Commissioner of Internal Revenue, Chief Tax Compliance Officer or Chief Operating Officer.

2. Provide clear instructions in the email and set a deadline for reviewers to review and respond. E-Clearance auto-generates an email with instructions for the author to forward. In the rare instance Form 2061 is used to clear the IRM, a sample email is available to use on the SPDER IMD webpage, under **Clearance Email Templates**.


4. Allow reviewers 30 calendar days to review and provide any comments and assessments. Obtain program director approval when the clearance review time frame is less than 30 calendar days. Refer to _IRM 1.11.9.5.4_, Standard Clearance Time Frame, and _IRM 1.11.9.5.4.1_, Expedited Clearance.

5. Contact your IMD/IRM coordinator for specific guidance on forwarding IRM/IGs for clearance, as some business units have internal processes on clearing IRMs.


**1.11.9.5.2** **(02-26-2025)**

#### Documents Sent for Clearance - Clearance Package

1. Include the following documents (clearance package) in e-Clearance for reviewers:



   - A draft IRM in PDF format or HTML using the IRM Preview Tool, where changes appear as accepted.



     ### Note:



     Convert the IRM file from Arbortext to PDF using Adobe Acrobat with Arbortext tags turned off. Unless the reviewer also has Arbortext, they cannot view a file prepared using Arbortext.

   - New or revised graphics in PDF format. Refer to IRM 1.11.2.5.4.2.1, Convert a Graphic to PDF.

   - A “tracked change” **or** “compare” PDF file of the IRM changes. For information for creating a tracked changes or compare file, refer to How to Create Two PDF Files when Clearing Your IRM. An author may also attach a "tracked change" HTML version in lieu of a PDF using the IRM Preview Tool.

   - Zipped XML file of the draft IRM for IMD/IRM coordinators.

   - A zip file of the incorporated interim guidance material, e-Clearance IGM archived email(s) if applicable, all approvals, all signed Forms 2061, etc.

   - Form 13709, PGLD Checklist for IMDs and Training Materials, if the IRM requires PGLD review.


2. Include the following **optional** items based on preference or program office’s internal clearance guidelines:



1. Form or matrix to capture reviewers’ comments. Refer to _IRM 1.11.9.6_, Comment Methods and Options.

2. Form 13839, Note to Reviewer, a template used to provide details or information about the proposed changes for the reviewer.

3. Additional or background information that supports the changes.


**1.11.9.5.3** **(02-26-2025)**

#### Form 2061 - Document Clearance Record

1. Form 2061, Document Clearance Record, should only be used in instances of limited functionality. _IRM 1.11.9.2_, Clearance Process Overview, gives guidance on limited functionality.

2. The author/originator prepares a separate document clearance record for each IRM.

3. The author/originator fills in the originator and reviewer information on Form 2061, part 1 and part 2.

4. On Form 2061, part 3, reviewers must, at a minimum, provide an assessment, include comments (or separate feedback matrix) and add their signature.


**1.11.9.5.4** **(12-12-2023)**

#### Standard Clearance Time Frame

1. When sending an IRM for clearance, the standard time frame allowed for reviewers to review and comment on the proposed IRM changes is 30 calendar days. If this is a non-workday, the due date is the next business day.

2. If the reviewer needs additional time, the reviewer contacts the originator to request an extension. The originating office may extend their clearance review up to an additional 15 calendar days.

3. When granting an extension, the originator documents the discussion and revised time frame and retains it as part of the historical file sent to the IRS Historical Research Library. Refer to _IRM 1.11.9.10.5_, Archiving Clearance Documents.

4. A clearance review may not exceed 45 calendar days.

5. The originator must not forward their IRM clearance package for final review before the end of the stated clearance time frame they’ve set. If allowing less than 30 calendar days, the originator must obtain program director (or designee) approval.


**1.11.9.5.4.1** **(12-12-2023)**

##### Expedited Clearance

1. The program office may reduce the clearance time frame to meet business or operating needs. This requires the program director’s (or designee’s) approval for expediting the clearance of an IRM. Originators must obtain director level approval to shorten the clearance time frame for the IRM.

2. When creating a clearance request, the author indicates the request is expedited and selects a shortened time frame, which must be at least three business days. The program director receives an email approval request which directs them to e-Clearance, where they or their designee can record their approval of the expedited time frame.

3. The reviewer must contact the originator to discuss any concerns within the set time frame. For guidance on disagreements, refer to _IRM 1.11.9.9_, Resolving Disagreements.


**1.11.9.6** **(02-26-2025)**

### Comment Methods and Options

1. Reviewers may submit comments and feedback as described in the table below:




| **Type of Document** | **Description** |
| --- | --- |
| E-Clearance | E-Clearance allows the addition of comments and, if needed, documents attached. Refer to the training information on e-Clearance for additional details and guidance on e-Clearance and the comment options. |
| Comment Form or Matrix | A Word or Excel file in a table format with headings for:<br> <br>   - Reviewer name<br>     <br>   - IRM subsection or other identifying information<br>     <br>   - Comments on the changed procedures<br>     <br> Download a sample from the SPDER IMD webpage, under "Feedback." |
| PDF File | The comment feature within Adobe Acrobat. The menu selection _Tools_ → _Comment and Markup_ has tools to add sticky notes, make text edits, and highlight text. |
| XML File | The _Comment_ features in the XML editor. |
| Within Form 2061, Document Clearance Record<br> <br>### Note:<br>Not for use with IRM clearance unless the author fits the exception guidelines in _IRM 1.11.9.2_, Clearance Process Overview. | Part III, block 14b, contains a comment section for reviewers with a drop-down menu. Reviewers are given the following choices to choose from:<br> <br>   - Decline review; no impact<br>     <br>   - I concur; no comments<br>     <br>   - I concur with comments<br>     <br>   - I do not concur; comments required |





### Note:



If identified, reviewers must follow the comment method requested by the IRM author for that respective clearance.


**1.11.9.7** **(02-26-2025)**

### Guidelines for Reviewers

1. Reviewers conduct a review and provide comments on changes to an IRM to identify inconsistencies between the changed content and their program’s processes, procedures and guidelines.

2. For the IRM, reviewers are to focus on substantive (non-editorial) changes identified in the MT material changes. Reviewers are to consider the impact of the revisions to their program, processes and procedures. Reviewers may also provide editorial revisions that enhance the readability and clarity of the IRM.



### Caution:



When reviewing an IRM using a PDF from the IRM Preview Tool, be aware that updates such as paragraph numbers, subsection dates, and other changes may not match the XML file or PDFs with applied changes. Ensure you compare both documents to confirm accuracy.



    .



3. Reviewers must include suggested language if proposing additional or revised content or language.

4. If a reviewer does not concur with the changed content, the reviewer must identify the specific issue with which they do not concur, the rationale for their position, and the required issues to address for concurrence.

5. For any questions or concerns about the revised content, the reviewer must contact the author to resolve as soon as possible.

6. Handle comments on IRM content not revised by the author outside of the IRM clearance process. Forward these comments to the author following the guidance in IRM 1.11.6.5, Providing Feedback About an IRM Section - Outside of Clearance. Authors follow IRM 1.11.2.5.1.3, Consider Requested IRM Changes, for handling and addressing these comments.


**1.11.9.7.1** **(02-26-2025)**

#### Review Assessment and Reviewer's Signature

1. To document completion of an IRM review, a reviewer must choose one of four review assessments on e-Clearance or in block 13, if using Form 2061. Refer to the table below for the four assessments and explanations.

2. The reviewer completes the steps below if using e-Clearance:



1. Select the Add Assessment button.

2. Select the appropriate assessment (from the options in paragraph (3 below)) and Sign button.

3. Include or attach comments within e-Clearance.


3. A reviewer must select one of the four review assessments:




| **Review Assessment** | **Explanation** |
| --- | --- |
| I concur, no comment. | The reviewing office agrees with the changes in the draft IRM. They provided no comments. |
| I concur, with comments. | The reviewing office agrees with the changes in the draft IRM and provides comments that aren’t material to their approval. |
| I do not concur, comments required. | The reviewing office does not agree with the changes in the draft IRM and provides the points of disagreement and an analysis of the issue. A do not concur indicates the reviewer does not agree with the change, issuance and publication of the document as written.<br> <br>### Example:<br>Revised IRM contains guidance contradicting current tax law. |
| Decline review. No Impact. | The reviewing office provides no comments because the draft IRM does not affect their program. |

4. Authors/creators of clearance requests receive systemically generated emails notifying them of reviewer assessments and comments (if any).

5. Some reviewing offices require a manager’s approval documenting their agreement with the reviewer’s assessment. E-Clearance and Form 2061 do not capture this agreement. Business units document this agreement per their internal established procedures.


**1.11.9.7.2** **(02-26-2025)**

#### Personally Identifiable Information (PII) or Federal Tax Information (FTI) Breach Actions

1. If you discover PII or FTI when reviewing the IRM or after it is published, **immediately report** it in accordance with IRM 10.5.4.3.3(2)a, Inadvertent Unauthorized Disclosures and Losses or Thefts of IT Assets, BYOD Assets and Hardcopy Records/Documents. A prompt report decreases possible use of the information to perpetrate identity theft or other forms of harm.

2. Take the following actions **immediately**:



1. Report the breach to your manager, the IRM author, their manager, and their business unit IMD coordinator. They will work with SPDER to revise the IRM and remove content from the IRS electronic sources.

2. Send an email to \*SPDER.

3. Report the breach to the Office of Privacy, Governmental Liaison and Disclosure (PGLD) Incident Management Office (IM) using the PII Breach Reporting Form. Send an email to \*PII or contact IM at 267-466-0777 if you have any problems with the online form or any questions about completing it.


3. Refer to IRM 10.5.4.3, Reporting Losses, Thefts and Disclosures, for more information on reporting inadvertent unauthorized disclosures of PII or FTI.


**1.11.9.8** **(08-14-2024)**

### Responding to Reviewers' Comments

1. The author must consider and address reviewers’ comments or concerns on substantive content changes and revise the draft IRM as appropriate. As necessary, the author contacts the reviewer directly to address and rectify any comments or concerns that are unclear or questionable.



1. If the author agrees to the suggested changes, the author revises the IRM and forwards the revised wording or revised IRM to prevent any misunderstanding.

2. If the reviewer does not respond within the requested clearance response date, refer to _IRM 1.11.9.8.1_, No Response to a Clearance Request, for further instructions.

3. If the author disagrees with the suggested changes, refer to _IRM 1.11.9.9_, Resolving Disagreements, for further instructions.


2. Respond to substantive comments via e-Clearance, or in rare instances, Form 2061. Authors should generally respond within 45 calendar days after the clearance due date or comment date (whichever is later), but no later than the date the approved IRM is forwarded to the IMD/IRM coordinator for publishing.

3. Incorporate all agreed changes into the proposed IRM for final clearance package and management review within 120 calendar days of the latter of the following dates:



   - Clearance due date, or

   - Date all changes were agreed upon by both originators and reviewers.


### Note:

Use the subsequent clearance due date if the IRM is re-cleared per paragraph (4) below.

### Reminder:

The date all changes were agreed upon may vary depending on a program office’s procedures for addressing and agreeing to reviewer changes (e.g., management's requirement to approve content before incorporation, other internal processes).

4. If substantially revising the IRM during the clearance process, forward the revised IRM to the offices affected by the changes, identifying the changed content. The additional time frame for review must be at least five business days but not more than 20 business days.

5. In rare situations where the agreed upon changes require a prolonged time to revise, the program director may approve publishing the IRM immediately without the agreed upon changes. The author must notify the reviewer of the delay to incorporate the agreed upon changes. Once the author incorporates the agreed upon changes that do not require a prolonged time to revise the IRM, the author will clear and republish the IRM.


**1.11.9.8.1** **(12-12-2023)**

#### No Response to a Clearance Request

1. If an identified reviewer does not respond to a request for clearance within the required time frame, there is no requirement to follow-up. Treat the non-response as concurrence to move forward with the clearance process.

2. An author documents a non-response by taking the steps below based on the method of clearance:




| E-Clearance | Form 2061 |
| :-: | :-: |
| 1. Select the No Response button.<br>      <br>2. Identify the type of reviewer, their business unit, role, and name.<br>      <br>3. Select the Save button. | Annotate the following in Part III, block 14a:<br> <br>1. In the "Name" , write the name of the reviewer or reviewing office.<br>      <br>2. In the "Title" , write "No Response Received."<br>      <br>      <br>      <br>      ### Reminder:<br>      <br>      <br>      <br>      Form 2061, Document Clearance Record, should only be used in the event there is limited functionality. _IRM 1.11.9.2_, Clearance Process Overview, gives limited functionality guidance. |

3. The author considers comments received after the agreed-upon deadline following the procedures in IRM 1.11.2.5.1.3, Consider Requested IRM Changes.


**1.11.9.9** **(02-26-2025)**

### Resolving Disagreements

1. The author must consider all reviewer comments on substantive content changes.

2. In situations where the reviewer "does not concur" with the changes, the author must contact the reviewer to try and resolve the disagreement.

3. If a reviewer initially records a non-concurring assessment but their concerns are addressed and resolved, the reviewer or their office must record another assessment. They can use the link from the original e-Clearance email to record the second assessment, indicating they now concur with comments. In the comments field, they must explain the reason for the change from non-concurrence to concurrence.



### Note:



The first (non-concurring) assessment does not get deleted; it is superseded by the later, concurring assessment.

4. If the reviewer continues to disagree with the changes, the author initiates a conference call between the author, reviewer, management and other key personnel from both offices to discuss the differing views before moving forward on publication of the IRM. Inform the IRM program director of any continuing disagreement preventing the issuance of IRM guidance to employees to engage in a decision or resolution.

5. If an author adopts a reviewing office’s changes, and the reviewing office does not provide a new assessment within 15 calendar days after the changes are made, the author should submit a new comment on e-Clearance that includes the date(s) the changes were made. Attach a copy of the email(s) requesting a new assessment that went unanswered. The comment and attachment(s) will automatically become a part of the document clearance record for the historical archives.



### Exception:



In the rare instance that e-Clearance was not used to clear the IRM, the author should provide a new comment on Form 2061 with the information above.





### Note:



_IRM 1.11.9.8.1_, No Response to a Clearance Request, provides instruction when a reviewing office does not respond to an initial clearance request, and does not apply to paragraph (5) above.

6. If the disputing offices are still unable to resolve the disagreement, elevate the issue to the respective business unit senior executives for discussion and resolution.



### Reminder:



Business unit senior executives report directly to the Commissioner of Internal Revenue, Deputy Commissioner of Internal Revenue, Chief Tax Compliance Officer or Chief Operating Officer.

7. If a non-concurrence has been received and the reviewing office will not respond to requests to meet or resolve, originating offices should follow _IRM 1.11.9.9.1_, Issuing IRM While Disagreements are Discussed.

8. The author documents the historical clearance file to explain the rationale behind any non-agreement and if applicable, any resolution.


**1.11.9.9.1** **(08-14-2024)**

#### Issuing IRM While Disagreements are Discussed

1. If, after taking action to resolve the disagreement as described in _IRM 1.11.9.9_, Resolving Disagreements, the reviewing office continues to disagree with the substantive content changes, the originating business unit can proceed with publishing if the executive responsible for the IRM agrees they must publish the information to ensure operations continue in an efficient manner and to allow employees to perform their duties without unnecessary delays or incomplete/incorrect guidelines.

2. After approval from the executive responsible for the IRM, the originating office notifies the reviewer and the reviewing office’s business unit IMD coordinator via email that they are sending the IRM to publishing in 15 calendar days. The email contains information identifying the comments not accepted and the reasons for its decision. For a sample 15-day notification email, refer to the SPDER IMD webpage under **Clearance Email Templates**.

3. If the IRM requires a change after the respective heads of offices reach a resolution, the originating office incorporates all agreed-upon changes into the IRM and sends it through clearance within 120 calendar days after resolving the differences. Refer to _IRM 1.11.9.3_, Identifying Reviewers, and _IRM 1.11.9.4_, Specialized Reviewers, to determine the clearance requirements.

4. Originating offices must clearly document and retain records on e-Clearance or with Form 2061 when issuing an IRM with unresolved non-concurrence assessments.

5. In the rare instance a reviewing office provides a non-concurring assessment, and the originator publishes the IRM without responding to the non-concurring assessment(s), within 90 calendar days of the IRM’s publishing:



1. The reviewing business unit’s IMD coordinator should contact the IMD coordinator of the originating business unit/office and explain the non-concurrence concerns and impact of the recent IRM’s publishing.

2. The originating office should schedule discussion(s) to address a path to resolution. In these discussions, include, at minimum, the assigned SPDER customer liaisons, applicable coordinators, and managers (including program directors) for both business units.


6. If the publishing of an IRM, with an unaddressed non-concur, causes a drastic impact to a business unit's process, the originating office should issue immediate IG to revert to the applicable previous IRM version until discussions result in a solution. Refer to IRM 1.11.10, Interim Guidance Process, for more information.


**1.11.9.10** **(02-26-2025)**

### Final Stages of the Clearance Process

1. Authors and coordinators ensure all actions of the final clearance process are completed. The final stages of the clearance process involve:



1. Final clearance package creation

2. Management final review and assessment

3. Program director approval

4. Business unit IMD/IRM coordinator final review

5. Clearance records archival


**1.11.9.10.1** **(02-26-2025)**

#### Create Final Clearance Package

1. The IRM author creates the final clearance package and sends it for management review. E-Clearance auto-generates the final clearance package email to forward for management review.

2. Include the following documents in the final clearance package by uploading them to e-Clearance or compiling for email submission:



   - PDF (or HTML using the IRM Preview Tool) of the final XML file with no tags and changes accepted.

   - PDF (or HTML using the IRM Preview Tool) of the final XML file with no tags and changes tracked. A compare file can be attached in lieu of a tracked change copy.

   - Zip file containing the final XML file, signed Form 1767, Publishing Services Requisition, and any new and/or revised graphics. The XML file must have changes accepted, tracked changes turned off and comments removed.

   - Completed Form 15418, IRM Package Check Sheet, if required by your business unit.

   - A zip file of the incorporated interim guidance material, e-Clearance IGM archived email(s) if applicable, all approvals, all signed Forms 2061, etc. if not included during initial clearance.

   - A zip file of any additional feedback or documentation collected outside of clearance or not previously uploaded.


### Caution:

Do not upload files or graphics with PII, FTI or those that are not properly fictionalized to e-Clearance.

3. When an IRM is being published without resolving all non-concurrences (refer to _IRM 1.11.9.9.1_, Issuing IRM While Disagreements are Discussed), attach a separate zip file to e-Clearance that contains emails, documented approvals, etc., justifying IRM issuance.

4. The author or clearance originator proposes a final package approval due date in e-Clearance. The suggested timeframe is 15 calendar days, but this can vary depending upon the business unit and circumstances.


**1.11.9.10.2** **(02-26-2025)**

#### Management’s Final Review

1. Management reviews the final clearance package and ensures:



1. All appropriate business units were given the opportunity to review the clearance package.

2. Comments have been addressed and reviewers have provided assessments.

3. Non-responses have been properly recorded.

4. There are no unresolved non-concurring assessments.

5. Agreed upon suggested corrections have been completed.

6. Form 1767 is completed and signed. If not signed, managers/IMD coordinators should review and sign (if authorized) in boxes 10 - 12. This may vary per business unit.


2. Management must thoroughly review e-Clearance to ensure the author addressed all substantive non-concurring comments and assessments. Management must return the final clearance package to the author if:



   - Any non-concurrences have not been addressed; and/or

   - There is no evidence that disagreements are being discussed.


3. Each level of management within the program office overseeing the IRM content must document their review and concurrence in e-Clearance.


**1.11.9.10.3** **(10-01-2021)**

#### Approval by Program Director

1. IRMs require approval and signature at or above the program director level. The program director must be a member of the Senior Executive Service (SES) responsible for program administration including issuance and approval of IRMs. Generally, the Discovery Directory series and grade "ES" identifies a member of the SES. To confirm the program director is a member of the SES when Discovery Directory does not display the series and grade "ES" :



   - An author may elevate it to their management.

   - An IMD/IRM coordinator may elevate it to their management or the program director’s staff assistant.


### Note:

A Personnel Action Request (PAR) reflecting the SES classification is equal to an "ES" position in Discovery Directory for the purpose of signing an IRM.

2. The responsible program director (or above) reviews, signs and approves an IRM after internal, external, specialized reviewers and management final review. The responsible program director may designate in writing (email, form, etc.) a designee as the authorized approving official to review, sign and approve an IRM on their behalf. The designee must be a supervisory manager with program oversight per Delegation Order 1-69, Authorization to Approve an Internal Management Document (IMD), in IRM 1.2.2.2.53.

3. To document approval, the program director (or designee) completes and signs e-Clearance, as the approving official. Their signature indicates they approve and authorize issuance of the new, revised or obsolesced IRM.

4. Program directors may not issue instructions or guidelines that affect areas outside their functional responsibility without appropriate clearance.

5. Designated IRM approvers must record their name and official title. The approver must also select “Yes” they have authorization in e-Clearance to approve this document and attach a copy of their authorization.

6. The program director/executive with the authority over all the programs approves and signs in e-Clearance when an IRM affects several program areas.

7. The name on the signatory line on the IRM Manual Transmittal (MT) is the current or acting program director/executive who signed in e-Clearance. In the event the documented designee signed in e-Clearance, the name of the current director appears on the MT, not the designee.


**1.11.9.10.4** **(02-26-2025)**

#### Final Review by IMD/IRM Coordinator

1. After the program director (or authorized designee) approves the IRM, the author forwards the auto-generated email, **Approved for Publication**, to their business unit’s IMD mailbox or their IMD/IRM coordinator for a final review.

2. To complete the final review, the IMD/IRM coordinator:



1. Verifies the new, revised, or obsolesced IRM was sent to affected offices and specialized reviewers following IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM).

2. Verifies the responsible program director or documented designee provided a signature, approving and authorizing the changes and issuance.

3. Verifies the author addressed non-concurrences.

4. Reviews the IRM XML file to ensure the file is free of Arbortext context errors and the author followed procedures in IRM 1.11.2, Internal Revenue Manual (IRM) Process.

5. Reviews the Form 1767, Publishing Services Requisition, for accuracy. If not already signed by the management official, authorized IMD Coordinators sign in Box 10. Refer to IRM 1.11.5.3.1, Preparing Form 1767, Publishing Services Requisition, for instructions on completing the form.

6. Verifies the author completed all actions based on Form 15418, IRM Package Check Sheet.

7. Verifies all substantively changed subsections have a material changes entry and a new subsection date or (MM-DD-YYYY).

8. Verifies new or changed graphics do not contain PII or FTI.

9. Signs on the e-Clearance website.


### Note:

The purpose of the final IRM review is to ensure smooth file processing. In an effort to avoid errors, IRM content should not be changed without the express agreement of the IRM author once an IRM has been approved by management.

3. To publish the IRM, the IMD/IRM coordinator:



1. Submits the IRM package for publishing to M&P, following the IRM upload instructions in IRM 1.11.5.4, Submitting the IRM Publishing Package.

2. Forwards the IRM clearance documents to the IRS Historical Library for archiving, following instructions in _IRM 1.11.9.10.5_, Archiving Clearance Documents. In some business units, the author completes this step; please confirm with your IRM/IMD coordinator.


**1.11.9.10.5** **(02-26-2025)**

#### Archiving Clearance Documents

1. Within 30 calendar days after publication of the IRM, records documenting the review and approval of IRM changes, including new or obsolesced IRMs, must be properly archived. The IMD/IRM coordinator or author ensures the following documents are uploaded to e-Clearance or forwards them (if Form 2061 was used) for retention to the IRS Historical Research Library:



   - Substantive comments affecting the content of the document, including any comment matrices, emails or individual pages of other documents that reflect non-editorial comments

   - Documents supporting comment discussions or deviations from recommendations made by a reviewer

   - Background material that supports the reason for changes

   - Feedback from end user employees

   - Interim guidance incorporated into the IRM and its original clearance of the documentation

   - PDF format of the draft IRM

   - Any signed Forms 2061 from reviewers and from the approving official (program director or designee)


### Note:

Contact your business unit’s IMD coordinator to determine whether this action is the responsibility of the author or of the IMD/IRM coordinator when Form 2061 was used to clear the IRM.

2. If Form 2061 was used during the clearance process, check the following information on each form or clearance request before forwarding to the IRS Historical Research Library for archival:



   - Date originated

   - IRM number and title

   - Originator, IMD/IRM coordinator, reviewer’s name, title, program office, office symbols

   - Signature and date, or electronic signature in Part III, block 14c for each reviewer/reviewing office identified/listed in Part II

   - Signature and date, or electronic signature of program director (or authorized designee) in Part VI, block 20c



     ### Note:



     The library contacts the originating business unit or returns incomplete packages for correction if the signature is missing in block 20c, **Approving Official's Signature**, or if a signed Form 2061 is not present for each reviewer checked on the form.





     ### Reminder:



     Form 2061, Document Clearance Record, should only be used in the event there is limited functionality. _IRM 1.11.9.2_, Clearance Process Overview, gives limited functionality guidance.


3. The IMD/IRM coordinator takes the following action:




| E-Clearance | Form 2061 |
| :-: | :-: |
| Ensures the IMD/IRM coordinator’s final review is recorded on e-Clearance and that the IRM clearance records are located in the e-Clearance archives. When M&P publishes the IRM, SPDER receives notification and will take action to archive the IRM clearance records. | Sends the IMD clearance package to the IRS Historical Research Library at \*IRM Library. For additional assistance or the physical mailing address, contact \*IRM Library.<br> <br>### Reminder:<br>Contact your business unit’s IMD coordinator to determine whether this action is the responsibility of the author or of the coordinator. Form 2061, Document Clearance Record, should only be used in the event there is limited functionality. _IRM 1.11.9.2_, Clearance Process Overview, gives limited functionality guidance. |

4. The IRS Historical Research Library preserves the permanent record of changes made to the IRM through the e-Clearance package. An archives page stores e-Clearance records. The information serves to support IRM author inquiries, legal cases, investigations and responses to inquiries and audits from outside offices like the Treasury Inspector General for Tax Administration (TIGTA) or General Accountability Office (GAO) inquiries.

5. For more information, visit the IRS Historical Research Library.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-009#addtoany "Show all")

A2A