---
url: "https://www.irs.gov/irm/part1/irm_01-001-013"
title: "1.1.13 Taxpayer Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-013#main-content)

- 1.1.13  [Taxpayer Services](https://www.irs.gov/irm/part1/irm_01-001-013#id1)
  - 1.1.13.1  [Introduction to the Taxpayer Services (TS)](https://www.irs.gov/irm/part1/irm_01-001-013#id2)
    - 1.1.13.1.1  [Our Mission, Vision, Philosophy, Values and Goals](https://www.irs.gov/irm/part1/irm_01-001-013#id4)
    - 1.1.13.1.2  [Our Customer Base](https://www.irs.gov/irm/part1/irm_01-001-013#id5)
    - 1.1.13.1.3  [Management Services (MS)](https://www.irs.gov/irm/part1/irm_01-001-013#id6)
  - 1.1.13.2  [Taxpayer Services (TS) Communications and Liaison (C&L)](https://www.irs.gov/irm/part1/irm_01-001-013#id7)
  - 1.1.13.3  [Taxpayer Services Operations Support (TSOS)](https://www.irs.gov/irm/part1/irm_01-001-013#id8)
    - 1.1.13.3.1  [Capital Management and Oversight (CMO)](https://www.irs.gov/irm/part1/irm_01-001-013#id9)
      - 1.1.13.3.1.1  [Compliance and Accountability (CA)](https://www.irs.gov/irm/part1/irm_01-001-013#id10)
      - 1.1.13.3.1.2  [Finance](https://www.irs.gov/irm/part1/irm_01-001-013#id11)
      - 1.1.13.3.1.3  [Workforce Development (WD)](https://www.irs.gov/irm/part1/irm_01-001-013#id12)
        - 1.1.13.3.1.3.1  [Career & Leadership Development (CLD)](https://www.irs.gov/irm/part1/irm_01-001-013#id14)
        - 1.1.13.3.1.3.2  [Learning and Education (L&E)](https://www.irs.gov/irm/part1/irm_01-001-013#id15)
        - 1.1.13.3.1.3.3  [Training Delivery and Evaluation (TD&E)](https://www.irs.gov/irm/part1/irm_01-001-013#id16)
      - 1.1.13.3.1.4  [Workforce Strategic Management (WSM)](https://www.irs.gov/irm/part1/irm_01-001-013#id17)
        - 1.1.13.3.1.4.1  [Workforce Recruitment & Hiring Solutions (WRHS)](https://www.irs.gov/irm/part1/irm_01-001-013#id19)
        - 1.1.13.3.1.4.2  [Workforce Planning (WP)](https://www.irs.gov/irm/part1/irm_01-001-013#id20)
        - 1.1.13.3.1.4.3  [Workforce Relations and Performance Management (WRPM)](https://www.irs.gov/irm/part1/irm_01-001-013#id21)
      - 1.1.13.3.1.5  [Workforce Support (WS)](https://www.irs.gov/irm/part1/irm_01-001-013#id22)
    - 1.1.13.3.2  [Business Systems Modernization (BSM)](https://www.irs.gov/irm/part1/irm_01-001-013#id23)
      - 1.1.13.3.2.1  [Modernization Demand and Release Management (MDRM)](https://www.irs.gov/irm/part1/irm_01-001-013#id25)
      - 1.1.13.3.2.2  [Governance, Risk and Compliance (GRC)](https://www.irs.gov/irm/part1/irm_01-001-013#id26)
      - 1.1.13.3.2.3  [Modernization Organization Readiness Services (MORS)](https://www.irs.gov/irm/part1/irm_01-001-013#id27)
      - 1.1.13.3.2.4  [Modernization Sustaining Operations (MSO)](https://www.irs.gov/irm/part1/irm_01-001-013#id28)
      - 1.1.13.3.2.5  [Modernization Project Management Services (MPMS)](https://www.irs.gov/irm/part1/irm_01-001-013#id29)
      - 1.1.13.3.2.6  [Project Office (PO)](https://www.irs.gov/irm/part1/irm_01-001-013#id30)
      - 1.1.13.3.2.7  [Rules and Requirements (RR)](https://www.irs.gov/irm/part1/irm_01-001-013#id31)
    - 1.1.13.3.3  [Business Technology Operations (BTO)](https://www.irs.gov/irm/part1/irm_01-001-013#id32)
      - 1.1.13.3.3.1  [Integrated Automation Technologies (IAT)](https://www.irs.gov/irm/part1/irm_01-001-013#id34)
      - 1.1.13.3.3.2  [Technology Integration and Program Support (TIPS)](https://www.irs.gov/irm/part1/irm_01-001-013#id35)
      - 1.1.13.3.3.3  [Program Evaluation and Improvement (PEI)](https://www.irs.gov/irm/part1/irm_01-001-013#id36)
      - 1.1.13.3.3.4  [Business Operations Support (BOS)](https://www.irs.gov/irm/part1/irm_01-001-013#id37)
    - 1.1.13.3.4  [Strategies and Solutions](https://www.irs.gov/irm/part1/irm_01-001-013#id38)
      - 1.1.13.3.4.1  [Lean Six Sigma Organization (LSSO)](https://www.irs.gov/irm/part1/irm_01-001-013#id40)
      - 1.1.13.3.4.2  [Research and Analysis](https://www.irs.gov/irm/part1/irm_01-001-013#id41)
    - 1.1.13.3.5  [Program Management Office (PMO)](https://www.irs.gov/irm/part1/irm_01-001-013#id42)
  - 1.1.13.4  [Return Integrity and Compliance Services (RICS)](https://www.irs.gov/irm/part1/irm_01-001-013#id43)
    - 1.1.13.4.1  [Program Coordination and Support (PCS)](https://www.irs.gov/irm/part1/irm_01-001-013#id44)
    - 1.1.13.4.2  [Return Integrity Verification Program Management (RIVPM)](https://www.irs.gov/irm/part1/irm_01-001-013#id45)
      - 1.1.13.4.2.1  [Program Management (PM)](https://www.irs.gov/irm/part1/irm_01-001-013#id46)
        - 1.1.13.4.2.1.1  [Quality](https://www.irs.gov/irm/part1/irm_01-001-013#id48)
        - 1.1.13.4.2.1.2  [Data Management, Analysis and Support (DMAS)](https://www.irs.gov/irm/part1/irm_01-001-013#id49)
      - 1.1.13.4.2.2  [Policy and Analysis (P&A)](https://www.irs.gov/irm/part1/irm_01-001-013#id50)
      - 1.1.13.4.2.3  [Business Performance Lab (BPL)](https://www.irs.gov/irm/part1/irm_01-001-013#id51)
        - 1.1.13.4.2.3.1  [Project Analysis and Evaluation (PAE)](https://www.irs.gov/irm/part1/irm_01-001-013#id53)
        - 1.1.13.4.2.3.2  [Project Development and Execution (PDE)](https://www.irs.gov/irm/part1/irm_01-001-013#id54)
        - 1.1.13.4.2.3.3  [Project Analytics and Modeling (PAM)](https://www.irs.gov/irm/part1/irm_01-001-013#id55)
        - 1.1.13.4.2.3.4  [Program Assessment and Data (PAD)](https://www.irs.gov/irm/part1/irm_01-001-013#id56)
    - 1.1.13.4.3  [Return Integrity Verification Operations (RIVO)](https://www.irs.gov/irm/part1/irm_01-001-013#id57)
      - 1.1.13.4.3.1  [Planning and Analysis (P&A)](https://www.irs.gov/irm/part1/irm_01-001-013#id58)
      - 1.1.13.4.3.2  [Return Integrity Verification Operations (RIVO) 1](https://www.irs.gov/irm/part1/irm_01-001-013#id59)
        - 1.1.13.4.3.2.1  [Department 1 Fraud and Referral Evaluation](https://www.irs.gov/irm/part1/irm_01-001-013#id61)
        - 1.1.13.4.3.2.2  [Department 2 Accounts Resolution](https://www.irs.gov/irm/part1/irm_01-001-013#id62)
        - 1.1.13.4.3.2.3  [Department 3 Non-Identity Theft Account Resolution & External Leads Department](https://www.irs.gov/irm/part1/irm_01-001-013#id63)
      - 1.1.13.4.3.3  [Return Integrity Verification Operations (RIVO) 2](https://www.irs.gov/irm/part1/irm_01-001-013#id64)
        - 1.1.13.4.3.3.1  [Department 1 Business Masterfile Identity Theft & Frivolous Return Program](https://www.irs.gov/irm/part1/irm_01-001-013#id66)
        - 1.1.13.4.3.3.2  [Department 2 Accounts Resolution Automated Questionable Credits](https://www.irs.gov/irm/part1/irm_01-001-013#id67)
        - 1.1.13.4.3.3.3  [Department 3 Accounts Resolution Automated Questionable Credits & Withholding Only Work](https://www.irs.gov/irm/part1/irm_01-001-013#id68)
    - 1.1.13.4.4  [Refundable Credits Examination Operations (RCEO)](https://www.irs.gov/irm/part1/irm_01-001-013#id69)
      - 1.1.13.4.4.1  [Planning and Analysis (P&A)](https://www.irs.gov/irm/part1/irm_01-001-013#id71)
    - 1.1.13.4.5  [Refundable Credits Program Management (RCPM)](https://www.irs.gov/irm/part1/irm_01-001-013#id72)
      - 1.1.13.4.5.1  [Program Management (PM)](https://www.irs.gov/irm/part1/irm_01-001-013#id73)
      - 1.1.13.4.5.2  [Refundable Credits Administration (RCA)](https://www.irs.gov/irm/part1/irm_01-001-013#id74)
        - 1.1.13.4.5.2.1  [Stakeholder Engagement (SE)](https://www.irs.gov/irm/part1/irm_01-001-013#id76)
        - 1.1.13.4.5.2.2  [Policy and Coordination (PC)](https://www.irs.gov/irm/part1/irm_01-001-013#id77)
        - 1.1.13.4.5.2.3  [Return Preparer Support (RPS)](https://www.irs.gov/irm/part1/irm_01-001-013#id78)
      - 1.1.13.4.5.3  [Examination Policy and Coordination (EPC)](https://www.irs.gov/irm/part1/irm_01-001-013#id79)
        - 1.1.13.4.5.3.1  [Examination Earned Income Tax Credit (EE)](https://www.irs.gov/irm/part1/irm_01-001-013#id81)
        - 1.1.13.4.5.3.2  [Examination Non-Earned Income Tax Credit (EN)](https://www.irs.gov/irm/part1/irm_01-001-013#id82)
      - 1.1.13.4.5.4  [Credits and Deductions Administration (CDA)](https://www.irs.gov/irm/part1/irm_01-001-013#id83)
  - 1.1.13.5  [Customer Assistance, Relationships and Education (CARE)](https://www.irs.gov/irm/part1/irm_01-001-013#id84)
    - 1.1.13.5.1  [Media and Publications (M&P)](https://www.irs.gov/irm/part1/irm_01-001-013#id85)
      - 1.1.13.5.1.1  [Media and Publications (M&P) Planning and Analysis (P&A)](https://www.irs.gov/irm/part1/irm_01-001-013#id86)
      - 1.1.13.5.1.2  [Tax Forms and Publications (TF&P)](https://www.irs.gov/irm/part1/irm_01-001-013#id87)
        - 1.1.13.5.1.2.1  [Individual and Specialty Forms and Publications](https://www.irs.gov/irm/part1/irm_01-001-013#id89)
        - 1.1.13.5.1.2.2  [Business, Exempt Organizations and International (BE&I) Forms and Publications](https://www.irs.gov/irm/part1/irm_01-001-013#id90)
        - 1.1.13.5.1.2.3  [Multilingual and Agency Services](https://www.irs.gov/irm/part1/irm_01-001-013#id91)
      - 1.1.13.5.1.3  [Publishing](https://www.irs.gov/irm/part1/irm_01-001-013#id92)
        - 1.1.13.5.1.3.1  [Publishing Services Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id94)
        - 1.1.13.5.1.3.2  [e-Publishing](https://www.irs.gov/irm/part1/irm_01-001-013#id95)
        - 1.1.13.5.1.3.3  [Tax Publishing Content Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id96)
      - 1.1.13.5.1.4  [Distribution](https://www.irs.gov/irm/part1/irm_01-001-013#id97)
        - 1.1.13.5.1.4.1  [Technology and Program Support](https://www.irs.gov/irm/part1/irm_01-001-013#id99)
        - 1.1.13.5.1.4.2  [National Distribution Center (NDC)](https://www.irs.gov/irm/part1/irm_01-001-013#id100)
        - 1.1.13.5.1.4.3  [Correspondence Production Services (CPS)](https://www.irs.gov/irm/part1/irm_01-001-013#id101)
        - 1.1.13.5.1.4.4  [Taxpayer Correspondence Services (TCS)](https://www.irs.gov/irm/part1/irm_01-001-013#id102)
    - 1.1.13.5.2  [Stakeholder Partnerships, Education and Communication (SPEC)](https://www.irs.gov/irm/part1/irm_01-001-013#id103)
      - 1.1.13.5.2.1  [Stakeholder Partnerships, Education and Communication (SPEC) Area Directors](https://www.irs.gov/irm/part1/irm_01-001-013#id104)
        - 1.1.13.5.2.1.1  [Stakeholder Partnerships, Education and Communication (SPEC) Territory Managers](https://www.irs.gov/irm/part1/irm_01-001-013#id106)
      - 1.1.13.5.2.2  [Strategy and Program Management](https://www.irs.gov/irm/part1/irm_01-001-013#id107)
        - 1.1.13.5.2.2.1  [Field Support and Analysis](https://www.irs.gov/irm/part1/irm_01-001-013#id109)
      - 1.1.13.5.2.3  [Program Support](https://www.irs.gov/irm/part1/irm_01-001-013#id110)
        - 1.1.13.5.2.3.1  [Products, Systems and Analysis](https://www.irs.gov/irm/part1/irm_01-001-013#id112)
        - 1.1.13.5.2.3.2  [Quality Program Office](https://www.irs.gov/irm/part1/irm_01-001-013#id113)
      - 1.1.13.5.2.4  [National Partnerships](https://www.irs.gov/irm/part1/irm_01-001-013#id114)
      - 1.1.13.5.2.5  [Grant Program Office](https://www.irs.gov/irm/part1/irm_01-001-013#id115)
    - 1.1.13.5.3  [Field Assistance (FA)](https://www.irs.gov/irm/part1/irm_01-001-013#id116)
      - 1.1.13.5.3.1  [Field Assistance Area Director](https://www.irs.gov/irm/part1/irm_01-001-013#id117)
        - 1.1.13.5.3.1.1  [Field Assistance Territory Managers](https://www.irs.gov/irm/part1/irm_01-001-013#id118)
          - 1.1.13.5.3.1.1.1  [Field Assistance Group Managers](https://www.irs.gov/irm/part1/irm_01-001-013#id120)
    - 1.1.13.5.4  [Customer Assistance, Relationships and Education (CARE) Planning and Analysis (P&A)](https://www.irs.gov/irm/part1/irm_01-001-013#id121)
  - 1.1.13.6  [Customer Account Services (CAS)](https://www.irs.gov/irm/part1/irm_01-001-013#id122)
    - 1.1.13.6.1  [Program Coordination and Support (PCS)](https://www.irs.gov/irm/part1/irm_01-001-013#id123)
    - 1.1.13.6.2  [CAS Project Management Office (CAS PMO)](https://www.irs.gov/irm/part1/irm_01-001-013#id124)
    - 1.1.13.6.3  [Accounts Management (AM)](https://www.irs.gov/irm/part1/irm_01-001-013#id125)
      - 1.1.13.6.3.1  [Reports, Equipment, Phones (REP)](https://www.irs.gov/irm/part1/irm_01-001-013#id126)
        - 1.1.13.6.3.1.1  [Reports, Analysis and Data (RAD)](https://www.irs.gov/irm/part1/irm_01-001-013#id128)
        - 1.1.13.6.3.1.2  [Joint Operations Center Operating Division Representative (JOC REP)](https://www.irs.gov/irm/part1/irm_01-001-013#id129)
        - 1.1.13.6.3.1.3  [Equipment Requests and Telework Management (ERTM)](https://www.irs.gov/irm/part1/irm_01-001-013#id130)
      - 1.1.13.6.3.2  [Resource Management and Training (RMT)](https://www.irs.gov/irm/part1/irm_01-001-013#id131)
        - 1.1.13.6.3.2.1  [Resource Planning and Scheduling (RPS)](https://www.irs.gov/irm/part1/irm_01-001-013#id133)
        - 1.1.13.6.3.2.2  [Training](https://www.irs.gov/irm/part1/irm_01-001-013#id134)
      - 1.1.13.6.3.3  [Policy and Procedures IMF (PPI)](https://www.irs.gov/irm/part1/irm_01-001-013#id135)
        - 1.1.13.6.3.3.1  [Individual Adjustments](https://www.irs.gov/irm/part1/irm_01-001-013#id137)
        - 1.1.13.6.3.3.2  [Customer Technical Communications Program (CTCP)](https://www.irs.gov/irm/part1/irm_01-001-013#id138)
      - 1.1.13.6.3.4  [Policy and Procedures BMF (PPB)](https://www.irs.gov/irm/part1/irm_01-001-013#id139)
        - 1.1.13.6.3.4.1  [Specialty Accounts (SA)](https://www.irs.gov/irm/part1/irm_01-001-013#id141)
        - 1.1.13.6.3.4.2  [Business Adjustments (BA)](https://www.irs.gov/irm/part1/irm_01-001-013#id142)
      - 1.1.13.6.3.5  [Technology Assistance and Stakeholder Communication (TASC)](https://www.irs.gov/irm/part1/irm_01-001-013#id143)
        - 1.1.13.6.3.5.1  [Servicewide Electronic Research Program (SERP) Communication Program (SCP)](https://www.irs.gov/irm/part1/irm_01-001-013#id145)
        - 1.1.13.6.3.5.2  [Rules Based Program Office (RBPO)](https://www.irs.gov/irm/part1/irm_01-001-013#id146)
      - 1.1.13.6.3.6  [Identity Protection Strategy and Oversight (IPSO)](https://www.irs.gov/irm/part1/irm_01-001-013#id147)
        - 1.1.13.6.3.6.1  [Identity Theft Victim Assistance (ITVA)](https://www.irs.gov/irm/part1/irm_01-001-013#id149)
        - 1.1.13.6.3.6.2  [Identity Protection (IP)](https://www.irs.gov/irm/part1/irm_01-001-013#id150)
      - 1.1.13.6.3.7  [Field Directors, Accounts Management](https://www.irs.gov/irm/part1/irm_01-001-013#id151)
        - 1.1.13.6.3.7.1  [Campus Operations](https://www.irs.gov/irm/part1/irm_01-001-013#id152)
        - 1.1.13.6.3.7.2  [Remote Operations](https://www.irs.gov/irm/part1/irm_01-001-013#id153)
        - 1.1.13.6.3.7.3  [Planning and Analysis](https://www.irs.gov/irm/part1/irm_01-001-013#id154)
          - 1.1.13.6.3.7.3.1  [Telephone Systems Support](https://www.irs.gov/irm/part1/irm_01-001-013#id156)
        - 1.1.13.6.3.7.4  [Site Coordinator](https://www.irs.gov/irm/part1/irm_01-001-013#id157)
      - 1.1.13.6.3.8  [Account Management Operations Support (AMOS)](https://www.irs.gov/irm/part1/irm_01-001-013#id158)
        - 1.1.13.6.3.8.1  [Program Management and Coordination (PMC)](https://www.irs.gov/irm/part1/irm_01-001-013#id160)
        - 1.1.13.6.3.8.2  [Process Improvement/Customer Accuracy (PICA)](https://www.irs.gov/irm/part1/irm_01-001-013#id161)
    - 1.1.13.6.4  [Electronic Products and Services Support (EPSS)](https://www.irs.gov/irm/part1/irm_01-001-013#id162)
      - 1.1.13.6.4.1  [Electronic Products and Services Support (EPSS) Operations Support](https://www.irs.gov/irm/part1/irm_01-001-013#id163)
      - 1.1.13.6.4.2  [E-file Provider Program Management (EPPM)](https://www.irs.gov/irm/part1/irm_01-001-013#id164)
      - 1.1.13.6.4.3  [Program Management](https://www.irs.gov/irm/part1/irm_01-001-013#id165)
      - 1.1.13.6.4.4  [Workforce Planning, Training and Quality (WPTQ)](https://www.irs.gov/irm/part1/irm_01-001-013#id166)
      - 1.1.13.6.4.5  [e-help Operations](https://www.irs.gov/irm/part1/irm_01-001-013#id167)
      - 1.1.13.6.4.6  [Technical Services Operation (TSO)](https://www.irs.gov/irm/part1/irm_01-001-013#id168)
        - 1.1.13.6.4.6.1  [Customer Service Sections (CSS)](https://www.irs.gov/irm/part1/irm_01-001-013#id170)
        - 1.1.13.6.4.6.2  [Filing Information Returns Electronically (FIRE) Support](https://www.irs.gov/irm/part1/irm_01-001-013#id171)
        - 1.1.13.6.4.6.3  [Information Filing Support (IFS)](https://www.irs.gov/irm/part1/irm_01-001-013#id172)
        - 1.1.13.6.4.6.4  [Product and Services Support (PSS)](https://www.irs.gov/irm/part1/irm_01-001-013#id173)
    - 1.1.13.6.5  [Joint Operations Center (JOC)](https://www.irs.gov/irm/part1/irm_01-001-013#id174)
      - 1.1.13.6.5.1  [Operations](https://www.irs.gov/irm/part1/irm_01-001-013#id175)
        - 1.1.13.6.5.1.1  [Routing and Monitoring](https://www.irs.gov/irm/part1/irm_01-001-013#id177)
        - 1.1.13.6.5.1.2  [Performance Tracking](https://www.irs.gov/irm/part1/irm_01-001-013#id178)
      - 1.1.13.6.5.2  [Planning and Analysis](https://www.irs.gov/irm/part1/irm_01-001-013#id179)
        - 1.1.13.6.5.2.1  [Strategic Forecasting and Analysis](https://www.irs.gov/irm/part1/irm_01-001-013#id181)
        - 1.1.13.6.5.2.2  [Reports Development](https://www.irs.gov/irm/part1/irm_01-001-013#id182)
      - 1.1.13.6.5.3  [Contact Analytics and Business Requirements Integration](https://www.irs.gov/irm/part1/irm_01-001-013#id183)
        - 1.1.13.6.5.3.1  [Contact Analytics (CA)](https://www.irs.gov/irm/part1/irm_01-001-013#id185)
        - 1.1.13.6.5.3.2  [Business Requirements Integration](https://www.irs.gov/irm/part1/irm_01-001-013#id186)
      - 1.1.13.6.5.4  [Centralized Quality Review System](https://www.irs.gov/irm/part1/irm_01-001-013#id187)
        - 1.1.13.6.5.4.1  [Customer Accuracy Improvement Section](https://www.irs.gov/irm/part1/irm_01-001-013#id189)
      - 1.1.13.6.5.5  [Program Management Office](https://www.irs.gov/irm/part1/irm_01-001-013#id190)
        - 1.1.13.6.5.5.1  [Project Management Team](https://www.irs.gov/irm/part1/irm_01-001-013#id192)
        - 1.1.13.6.5.5.2  [Voice/Chatbot Team](https://www.irs.gov/irm/part1/irm_01-001-013#id193)
    - 1.1.13.6.6  [Submission Processing (SP)](https://www.irs.gov/irm/part1/irm_01-001-013#id194)
      - 1.1.13.6.6.1  [Return Processing Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id195)
        - 1.1.13.6.6.1.1  [IMF Code and Edit/Error Resolution Section](https://www.irs.gov/irm/part1/irm_01-001-013#id197)
        - 1.1.13.6.6.1.2  [BMF Code and Edit/Error Resolution Section](https://www.irs.gov/irm/part1/irm_01-001-013#id198)
        - 1.1.13.6.6.1.3  [Mail Management/Data Conversion Section](https://www.irs.gov/irm/part1/irm_01-001-013#id199)
      - 1.1.13.6.6.2  [Accounting and Tax Payment Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id200)
        - 1.1.13.6.6.2.1  [Electronic Payment Section](https://www.irs.gov/irm/part1/irm_01-001-013#id202)
        - 1.1.13.6.6.2.2  [Lockbox Policy and Oversight Section](https://www.irs.gov/irm/part1/irm_01-001-013#id203)
        - 1.1.13.6.6.2.3  [Accounting and Deposit Section](https://www.irs.gov/irm/part1/irm_01-001-013#id204)
      - 1.1.13.6.6.3  [Program Management/Process Assurance Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id205)
        - 1.1.13.6.6.3.1  [Monitoring Section](https://www.irs.gov/irm/part1/irm_01-001-013#id207)
        - 1.1.13.6.6.3.2  [Resource Section](https://www.irs.gov/irm/part1/irm_01-001-013#id208)
        - 1.1.13.6.6.3.3  [Coordination Support Section](https://www.irs.gov/irm/part1/irm_01-001-013#id209)
        - 1.1.13.6.6.3.4  [Quality Support Section](https://www.irs.gov/irm/part1/irm_01-001-013#id210)
      - 1.1.13.6.6.4  [Specialty Programs Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id211)
        - 1.1.13.6.6.4.1  [Individual Taxpayer Identification Number (ITIN) Policy Section](https://www.irs.gov/irm/part1/irm_01-001-013#id213)
        - 1.1.13.6.6.4.2  [Post Processing Section](https://www.irs.gov/irm/part1/irm_01-001-013#id214)
        - 1.1.13.6.6.4.3  [Technical Support Section](https://www.irs.gov/irm/part1/irm_01-001-013#id215)
      - 1.1.13.6.6.5  [e-File Services](https://www.irs.gov/irm/part1/irm_01-001-013#id216)
        - 1.1.13.6.6.5.1  [Development Services Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id217)
        - 1.1.13.6.6.5.2  [IMF Services Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id218)
          - 1.1.13.6.6.5.2.1  [Individual e-File Sections](https://www.irs.gov/irm/part1/irm_01-001-013#id220)
        - 1.1.13.6.6.5.3  [BMF Services Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id221)
          - 1.1.13.6.6.5.3.1  [BMF Sections 1, 2, and 3](https://www.irs.gov/irm/part1/irm_01-001-013#id223)
        - 1.1.13.6.6.5.4  [Electronic Support Services Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id224)
          - 1.1.13.6.6.5.4.1  [Electronic Support Services Section 1](https://www.irs.gov/irm/part1/irm_01-001-013#id226)
          - 1.1.13.6.6.5.4.2  [Electronic Support Services Section 2](https://www.irs.gov/irm/part1/irm_01-001-013#id227)
        - 1.1.13.6.6.5.5  [Industry Engagement and Strategy Branch](https://www.irs.gov/irm/part1/irm_01-001-013#id228)
      - 1.1.13.6.6.6  [Submission Processing (SP) Field Directors (Austin, Kansas City, and Ogden)](https://www.irs.gov/irm/part1/irm_01-001-013#id229)
        - 1.1.13.6.6.6.1  [Site Coordinator](https://www.irs.gov/irm/part1/irm_01-001-013#id231)
        - 1.1.13.6.6.6.2  [Receipt and Control Operation](https://www.irs.gov/irm/part1/irm_01-001-013#id232)
        - 1.1.13.6.6.6.3  [Data Conversion Operation](https://www.irs.gov/irm/part1/irm_01-001-013#id233)
        - 1.1.13.6.6.6.4  [Document Perfection Operation](https://www.irs.gov/irm/part1/irm_01-001-013#id234)
        - 1.1.13.6.6.6.5  [Input Correction Operation](https://www.irs.gov/irm/part1/irm_01-001-013#id235)
        - 1.1.13.6.6.6.6  [Planning and Analysis, Submission Processing](https://www.irs.gov/irm/part1/irm_01-001-013#id236)
        - 1.1.13.6.6.6.7  [Accounting Operation](https://www.irs.gov/irm/part1/irm_01-001-013#id237)
        - 1.1.13.6.6.6.8  [Statistics of Income (SOI) Operation](https://www.irs.gov/irm/part1/irm_01-001-013#id238)
        - 1.1.13.6.6.6.9  [Individual Taxpayer Identification Number (ITIN) Operation](https://www.irs.gov/irm/part1/irm_01-001-013#id239)
  - Exhibit  1.1.13-1  [Taxpayer Services (TS) Organization Chart and Structure](https://www.irs.gov/irm/part1/irm_01-001-013#id240)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 13. Taxpayer Services

* * *

## 1.1.13 Taxpayer Services

#### Manual Transmittal

August 29, 2025

#### Purpose

(1) This transmits revised IRM 1.1.13, Organization and Staffing, Taxpayer Services.

#### Material Changes

(1) IRM 1.1.13 Changed name from Wage & Investment (W&I) to Taxpayer Services (TS) throughout the entire IRM. Also, changed office symbols. IPU 25U0194 issued 02-07-2025. Changed W&I Commissioner to TS Chief and links to site pages throughout the entire IRM.

(2) IRM 1.1.13.1, Removed EDI as an organization in TS per the DEI-EO. IPU 25U0210 issued 02-14-2025. Updated statistics to reflect the annual number of returns processed, telephone inquiries answered, the total number of business unit employees, Service Center campuses and Taxpayer Assistance Centers.

(3) IRM 1.1.13.1.1, Added Delegation Order TS 1-1-1.

(4) IRM 1.1.13.1.3, New subsection added Management Services (MS). Created due to not having a presence in the IRM and added MS mission.

(5) IRM 1.1.13.2 Removed subsection in accordance with the DEI-EO update. IPU 25U0194 issued 02-07-2025

(6) IRM 1.1.13.3 Changed name from Wage and Investment Operations Support (WIOS) to Taxpayer Services Operations Support (TSOS). Due to the removal of subsection 1.1.13.2 EDI, this subsection has been renumbered from 1.1.13.4 to 1.1.13.3.

(7) IRM 1.1.13.3.1, Updated Capital Management Oversight (CMO) organizational structure and program area names due to the Organizational Change approved April 11, 2024. Revised mission and functional statements to align with the program area’s responsibilities. Changed names of sections who report to the Director of CMO. Due to the removal of subsection 1.1.13.2, this subsection has been renumbered from 1.1.13.4.1 to 1.1.13.3.1.

(8) IRM 1.1.13.3.1.1, Changed name from Compliance and Quality Assurance (CQA) to Compliance and Accountability (CA). Revised mission and functional statements to align with the program area’s responsibilities. Changed CQA to CA throughout the IRM. Due to the removal of subsection 1.1.13.2, this subsection has been renumbered from 1.1.13.4.1.1 to 1.1.13.3.1.1.

(9) IRM 1.1.13.3.1.2, Updated the mission of Finance. Added who reports to the Chief of Finance. Due to the removal of subsection 1.1.13.2, this subsection has been renumbered from 1.1.13.4.1.2 to 1.1.13.3.1.2.

(10) IRM 1.1.13.3.1.3, Changed Leadership Development and Succession Planning (LDSP) to new branch named Workforce Development (WD). Added the mission statement for WD along with the functional statement to align with the program area’s responsibilities. Updated organizational structure and program area names due to the CMO Organizational Change approved April 11, 2024.

(11) IRM 1.1.13.3.1.3.1, New subsection added for Career & Leadership Development (CLD) formerly named Leadership Development and Succession Planning (LDSP). Added the mission and functional statement of CLD to align with the program area’s responsibilities. Added who the Chief of CLD reports to.

(12) IRM 1.1.13.3.1.3.2, New subsection added for Learning and Education (L&E). Added who the Chief of L&E reports to. Added the sections who report to the Chief of L&E. Due to the removal of subsection 1.1.13.2, this subsection has been renumbered from 1.1.13.4.1.4 to 1.1.13.3.1.3.2.

(13) IRM 1.1.13.4.1.3.3, New subsection added for Training Delivery and Evaluation (TD&E). Added the mission and functional statement to align with the program’s responsibilities. Added who the Chief of TD&E reports to. Added the sections that report to the Chief of TD&E.

(14) IRM 1.1.13.3.1.4, New subsection added for new branch named Workforce Strategic Management (WSM). Updated organizational structure and program area names due to the CMO Organizational Change approved April 11, 2024. Added the mission and functional statement to align with the program’s responsibilities. Added who the Chief of WSM reports to. Added the functions that report to the Chief of WSM.

(15) IRM 1.1.13.3.1.4.1, New subsection added for Workforce Recruitment & Hiring Solutions (WRHS). Changed the mission and functional statement to align with the program’s responsibilities. Updated who the Chief of WRHS reports to. Added the sections that report to the Chief of WRHS. Formerly known as Talent Recruitment (TR) under subsection 1.1.13.4.1.6.

(16) IRM 1.1.13.3.1.4.2, New subsection added to WSM branch for Workforce Planning (WP). Previously found in IRM 1.1.13.4.1.7, Workforce Planning (WFP). Moved due to CMO organizational change. Changed the abbreviation from Workforce Planning (WFP) to Workforce Planning (WP). Updated the mission and functional statement to align with the program’s responsibilities. Updated who the Chief of WP will report to. Added the sections that will report to the Chief of WP.

(17) IRM 1.1.13.3.1.4.3, New subsection added to WSM branch for Workforce Relations & Performance Management (WRPM). WRPM was previously Workforce Relations, Planning and Performance (WRPP) found in IRM 1.1.13.4.1.8. Moved due to CMO organizational change. Updated the mission and functional statement to align with the program’s responsibilities. Updated who the Chief of WRPM reports to.

(18) IRM 1.1.13.3.1.5, Changed name from Organizational Support and Engagement (OSE) to Workforce Support (WS). Updated the mission and functional statement to align with the program’s responsibilities. Added the sections that will report to the Chief of WS. Previously found in IRM 1.1.13.4.1.5.

(19) IRM 1.1.13.3.2, Added two functions that report to the Director of Business Systems Modernization (BSM). Updated the office symbols for BSM. Previously found in IRM 1.1.13.4.2.

(20) IRM 1.1.13.3.2.1, Modernization Demand and Release Management (MDRM) was previously located in 1.1.13.4.2.1.

(21) IRM 1.1.13.3.2.2, Governance, Risk and Compliance (GRC) was previously located in 1.1.13.4.2.2.

(22) IRM 1.1.13.3.2.3, Modernization Organization Readiness Services (MORS) was previously located in 1.1.13.4.2.3.

(23) IRM 1.1.13.3.2.4, Modernization Sustaining Operations (MSO) was previously located in 1.1.13.4.2.4.

(24) IRM 1.1.13.3.2.5, Modernization Project Management Services (MPMS) was previously located in 1.1.13.4.2.5. Removed “The Chief” at the beginning of paragraph 3

(25) IRM 1.1.13.4.2.6, New Section added Project Office (PO). Previously found in IRM 1.1.13.4.3.3, Customer Account Data Engine (CADE) Project Office (CPO). Moved due to TS realignment. IPU 24U0081 issued 01-12-2024. Project Office is now renumbered to 1.1.13.3.2.6.

(26) IRM 1.1.13.4.2.7, New Section added Rules and Requirements (RR). Previously found in IRM 1.1.13.4.3.4, Customer Account Data Engine (CADE) Rules and Requirements (CRR). Moved due to TS realignment. IPU 24U0081 issued 01-12-2024. Rules and Requirements is now renumbered to 1.1.13.3.2.7.

(27) IRM 1.1.13.4.3, Removed references of Project Office and Rules and Requirements. IPU 24U0081 issued 01-12-2024. Business Technology Operations (BTO) is now renumbered to 1.1.13.3.3.

(28) IRM 1.1.13.3.3.1, Integrated Automation Technologies (IAT) was renumbered from 1.1.13.4.3.1 to 1.1.13.3.3.1.

(29) IRM 1.1.13.3.3.2, Added to the functional statement to align with the program’s responsibilities. TIPS subsection has been renumbered from 1.1.13.4.3.2 to 1.1.13.3.3.2.

(30) IRM 1.1.13.3.3.3, Program Evaluation and Improvement (PEI) was renumbered from 1.1.13.4.3.3 to 1.1.13.3.3.3.

(31) IRM 1.1.13.4.3.4, Removed Development, Modernization and Enhancement (DME) references from paragraph 2C. IPU 24U0081 issued 01-12-2024. Business Operations Support (BOS) has been renumbered from 1.1.13.4.3.4 to 1.1.13.3.3.4. Updated the mission and functional statements to align with the program’s responsibilities.

(32) IRM 1.1.13.3.4, All subsections within Strategies and Solutions have been renumbered from 1.1.13.4.4 to 1.1.13.3.4.

(33) IRM 1.1.3.3.5, Program Management Office (PMO) has been renumbered from 1.1.13.4.5 to 1.1.13.3.5.

(34) IRM 1.1.13.4, Return Integrity and Compliance Services (RICS) has been renumbered from 1.1.13.4.

(35) IRM 1.1.13.4.1, Added responsibilities to the functional statement for Program Coordination and Support (PCS). Subsection renumbered from 1.1.13.5.1 to 1.1.13.4.1 due to the removal of .

(36) IRM 1.1.13.4.2, Updated the mission of Return Integrity Verification Program Management (RIVPM) and added the functional statement to align with the program area’s responsibilities. Subsection renumbered from 1.1.13.5.2 to 1.1.13.4.2.

(37) IRM subsections 1.1.13.4.2.1 through 1.1.13.4.2.3.4. have been renumbered from 1.1.13.5.2.1 through 1.1.13.5.2.3.4.

(38) IRM 1.1.13.4.3, Changed the names of the functions that report to the Director of Return Integrity Verification Operations (RIVO) from IVO #1 to RIVO #1 and IVO #2 to RIVO #2. Subsection renumbered from 1.1.13.5.3 to 1.1.13.4.3.

(39) IRM 1.1.13.4.3.1, Deleted link to home page. Subsection renumbered from 1.1.13.5.3.1 due to the removal of 1.1.13.2 EDI.

(40) IRM 1.1.13.4.3.2, Changed name from Integrity and Verification Operations (IVO) 1 to Return Integrity Verification Operations (RIVO) 1. Subsection renumbered from 1.1.13.5.3.2 due to the removal of 1.1.13.2 EDI.

(41) IRM 1.1.13.4.3.2.1, Changed name from Fraud and Referral Evaluation (FRE) Department to Department 1 Fraud and Referral Evaluation. Subsection renumbered from 1.1.13.5.3.2.1 due to the removal of 1.1.13.2 EDI.

(42) IRM 1.1.13.4.3.2.2, Changed name from Accounts Resolution Department to Department 2 Accounts Resolution. Subsection renumbered from 1.1.13.5.3.2.2 due to the removal of 1.1.13.2 EDI.

(43) IRM 1.1.13.4.3.2.3, Changed name from External Leads Department to Department 3 Non-Identity Theft Account Resolution & External Leads. Subsection renumbered from 1.1.13.5.3.2.3 due to the removal of 1.1.13.2 EDI.

(44) IRM 1.1.13.4.3.3, Changed name from Integrity and Verification Operations (IVO) 2 to Return Integrity Verification Operations (RIVO) 2. Subsection renumbered from 1.1.13.5.3.3 due to the removal of 1.1.13.2 EDI. Removed link to site page.

(45) IRM 1.1.13.4.3.3.1, Changed name from Return Screening and Verification Department to Business Masterfile Identity Theft & Frivolous Return Program. Subsection renumbered from 1.1.13.5.3.3.1 due to the removal of 1.1.13.2 EDI.

(46) IRM 1.1.13.4.3.3.2, Changed name from Accounts Resolution Department 2 to Department 2 Accounts Resolution Automated Questionable Credits. Subsection renumbered from 1.1.13.5.3.3.2 due to the removal of 1.1.13.2 EDI.

(47) IRM 1.1.13.4.3.3.3, Changed name from Accounts Resolution Department 3 to Department 3 Accounts Resolution Automated Questionable Credits & Withholding Only Work. Subsection renumbered from 1.1.13.5.3.3.3 due to the removal of 1.1.13.2 EDI.

(48) IRM 1.1.13.4.4, Refundable Credits Examination Operations (RCEO) subsection renumbered from 1.1.13.5.4 due to removal of EDI previously in subsection 1.1.13.2.

(49) IRM 1.1.13.4.4.1, Added subsection for Planning and Analysis (P&A) which includes the mission and functional statement that align with the area’s programs and responsibilities. Added office symbols.

(50) IRS 1.1.13.4.5, Updated the mission statement for Refundable Credits Program Management (RCPM) and added a function that reports to the Director. Subsection renumbered from 1.1.13.5.5 due to the removal of EDI formerly in 1.1.13.2.

(51) IRM subsections 1.1.13.4.5.1 through 1.1.13.4.5.3.2 renumbered from 1.1.13.5.5.1 through 1.1.13.5.5.3.2 due to the removal of EDI previously in subsection 1.1.13.2.

(52) IRM 1.1.13.4.5.4, Added new subsection for Credits and Deductions (CDA). Included the mission and functional statements that align with the program area’s responsibilities and the functions who report to the Program Manager of CDA.

(53) IRM 1.1.13.5, Customer Assistance, Relationships and Education (CARE) subsection renumbered from 1.1.13.6 due to the removal of EDI previously in subsection 1.1.13.2.

(54) IRM 1.1.13.5.1, Updated the functional statement for Media and Publications (M&P). Subsection renumbered from 1.1.13.6.1 due to the removal of EDI previously in 1.1.13.2.

(55) IRM 1.1.13.5.1.1, Changed Media & Publication’s Planning & Analysis (P&A) team names. Subsection renumbered from 1.1.13.6.1.1 due to the removal of EDI previously in 1.1.13.2.

(56) IRM 1.1.13.5.1.2, Removed one of the functions who previously reported to the Director of Tax Forms and Publications (TF&P). Subsection renumbered from 1.1.13.6.1.2 due to the removal of EDI previously in 1.1.13.2.

(57) IRM 1.1.13.5.1.2.1, Individual and Specialty Forms and Publications subsection renumbered from 1.1.13.6.1.2.2 due to the removal of EDI previously in 1.1.13.2. Added a section that reports to the Chief.

(58) IRM 1.1.13.5.1.2.2, Business, Exempt Organizations and International (BE&I) Forms and Publications subsection renumbered from 1.1.13.6.1.2.3 due to the removal of EDI previously in 1.1.13.2. Updated section names that reports to the Chief of BE&I.

(59) IRM 1.1.13.5.1.2.3, Multilingual and Agency Services subsection renumbered from 1.1.13.6.1.2.4 due to the removal of EDI previously in 1.1.13.2. Added a third section named Translation Services which reports to the Chief.

(60) IRM 1.1.13.5.1.3, Updated functional statement, major programs, and branch names for Publishing. Removed the Publishing Strategic Planning and Analysis (SPA) section. Subsection renumbered from 1.1.13.6.1.3 due to the removal of EDI previously in 1.1.13.2.

(61) IRM 1.1.13.5.1.3.1, Publishing Services Branch subsection renumbered from 1.1.13.6.1.3.2 due to the removal of EDI previously in subsection 1.1.13.2. Renamed the Non-Tax Products Section to Taxpayer Services Products Section.

(62) IRM 1.1.13.5.1.3.2, e-Publishing subsection renumbered from 1.1.13.6.1.3.3 due to the removal of EDI previously in subsection 1.1.13.2. Updated the mission statement and renamed the Content Services Section to e-Forms Technology Section.

(63) IRM 1.1.13.5.1.3.3, Tax Publishing Content Branch subsection renumbered and renamed from IRM 1.1.13.6.1.3.4 Tax Products.

(64) IRM 1.1.13.5.1.4, Distribution subsection renumbered from 1.1.13.6.1.4 due to the removal of EDI previously in 1.1.13.2. Made updates to the mission statement. Reduced number of functions reporting to the Director of Distribution from six to four and renamed one from Distribution Requirements to Technology and Program Support.

(65) IRM 1.1.13.5.1.4.1, Renamed as Technology and Program Support formerly in subsection 1.1.13.6.1.4.2 as Distribution Requirements. Renumbered due to the removal of EDI previously in subsection 1.1.13.2. Updated the mission and functional statements. Added additional programs this function is responsible. Made changes to the sections within this branch.

(66) IRM 1.1.13.5.1.4.2, National Distribution Center (NDC) section renumbered from 1.1.13.6.1.4.4 due to the removal of EDI previously in subsection 1.1.13.2. Updated the mission and functional statements, the major program responsibilities, and the sections of NDC.

(67) IRM 1.1.13.5.1.4.3, Correspondence Production Services (CPS) subsection renumbered from 1.1.13.6.1.4.5 due to the removal of EDI previously in 1.1.13.2. Change in mission statement. Number of sections increased from three to four.

(68) IRM 1.1.13.5.1.4.4, Taxpayer Correspondence Services (TCS), formerly subsection 1.1.13.6.1.4.6 Office of Taxpayer Correspondence (OTC) was renumbered due to the removal of EDI previously in 1.1.13.2. Updated names of the sections in TCS.

(69) IRM subsections 1.1.13.5.2 through 1.1.13.5.2.5 have been renumbered from 1.1.13.6.2 through 1.1.13.6.2.5 due to the removal of EDI previously in subsection 1.1.13.2.

(70) IRM subsections 1.1.13.5.3 through 1.1.13.5.4 have been renumbered from 1.1.13.6.3 through 1.1.13.6.4 due to the removal of EDI previously in subsection 1.1.13.2.

(71) IRM subsections 1.1.13.6 through 1.1.13.6.1 have been renumbered from 1.1.13.7 through 1.1.13.7.1 due to the removal of EDI previously in subsection 1.1.13.2.

(72) IRM 1.1.13.6.2, CAS Project Management Office (CAS PMO) has been renumbered from 1.1.13.7.2 due to the removal of EDI previously in 1.1.13.2. Updated mission and functional statements.

(73) IRM 1.1.13.6.3, Accounts Management (AM) has been renumbered from 1.1.13.7.3 due to the removal of EDI previously in 1.1.13.2.

(74) IRM 1.1.13.7.3.1, Renamed section to Reports, Equipment, Phones (REP) from Quality and Joint Operations Center (JOC) Operating Division Representative (RQ&JR). Removed references of RQ&JR. Updated office symbols. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.1 to 1.1.13.’6.3.1 due to the removal of EDI previously in 1.1.13.2.

(75) IRM 1.1.13.7.3.1.1, Clarified Reports, Analysis and Data (RAD) reports to the Program Manager of REP. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.1.1 to 1.1.13.6.3.1.1 due to the removal of EDI previously in 1.1.13.2.

(76) IRM 1.1.13.7.3.1.2, Clarified JOC reports to the Program Manager of RAP. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.1.2 to 1.1.13.6.3.1.2 due to the removal of EDI previously in 1.1.13.2.

(77) IRM 1.1.13.7.3.1.3, New Section added Equipment Request and Telework Management (ERTM). Previously section title was Process Improvements Customer Accuracy (PICA). PICA moved to IRM 1.1.13.7.3.8.2 due to W&I realignment. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.1.3 to 1.1.13.6.3.1.3 due to the removal of EDI previously in 1.1.13.2.

(78) IRM subsections 1.1.13.6.3.2 through 1.1.13.6.3.3.2 have been renumbered from 1.1.13.7.3.2 through 1.1.13.7.3.3.2 due to the removal of EDI previously in 1.1.13.2.

(79) IRM 1.1.13.7.3.4, Added paragraph four that specifies Policy and Procedures BMF (PPB) is responsible for dual Master File. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.4 to 1.1.13.6.3.4 due to the removal of EDI previously in 1.1.13.2.

(80) IRM 1.1.13.7.3.4.1, Clarified Specialty Accounts (SA) purview. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.4.1 to 1.1.13.6.3.4.1 due to the removal of EDI previously in 1.1.13.2.

(81) IRM 1.1.13.7.3.4.2, Changed name from Business Master File (BMF) to Business Adjustments (BA), clarified BA purview. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.4.2 to 1.1.13.6.3.4.2 due to the removal of EDI previously in 1.1.13.2.

(82) IRM subsections 1.1.13.6.3.5 through 1.1.13.6.3.6 have been renumbered from 1.1.13.7.3.5 through 1.1.13.7.3.6 due to the removal of EDI previously in subsection 1.1.13.2.

(83) IRM 1.1.13.7.3.6.1, Added IRM 25.23.13, Identity Protection and Victim Assistance-Income Related Identity Theft to the list of IRM’s Identity Theft Victim Assistance (ITVA) monitors. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.6.1 to 1.1.13.6.3.6.1 due to the removal of EDI previously in 1.1.13.2.

(84) IRM subsections 1.1.13.6.3.2 through 1.1.13.6.3.7.4 have been renumbered from 1.1.13.7.3.2 through 1.1.13.7.3.7.4 due to the removal of EDI previously in 1.1.13.2.

(85) IRM 1.1.13.7.3.8, New Section added Account Management Operation Support (AMOS). Created due to W&I realignment. Added AMOS mission and who reports to AMOS. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.8 to 1.1.13.6.3.8 due to the removal of EDI previously in 1.1.13.2.

(86) IRM 1.1.13.7.3.8.1, New Section added Program Management and Coordination (PMC). Created due to W&I realignment. Added PMC mission and how PMC will accomplish mission. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.8.1 to 1.1.13.6.3.8.1 due to the removal of EDI previously in 1.1.13.2.

(87) IRM 1.1.13.7.3.8.2, New Section added Process Improvement/Customer Accuracy (PICA). Previously found in IRM 1.1.13.7.3.1.3, PICA, Moved due to W&I realignment. Added PICA Mission and how PICA will accomplish mission. IPU 24U0081 issued 01-12-2024. Subsection renumbered from 1.1.13.7.3.8.2 to 1.1.13.6.3.8.2 due to the removal of EDI previously in 1.1.13.2.

(88) IRM 1.1.13.6.4, Corrected full name of Electronic Products and Services Support (EPSS) throughout the IRM. Subsection renumbered from 1.1.13.7.4 to 1.1.13.6.4 due to the removal of EDI previously in 1.1.13.2.

(89) IRM 1.1.13.6.4.1, Electronic Products and Services Support (EPSS) Operations Support subsection renumbered from 1.1.13.7.4.1 due to the removal of EDI previously in 1.1.13.2.

(90) IRM 1.1.13.6.4.2, Updated areas of responsibility/oversight. Subsection renumbered from 1.1.13.7.4.2 due to the removal of EDI previously in 1.1.13.2.

(91) IRM 1.1.13.6.4.3, Updated Program Management’s areas and IRMs of responsibility. Subsection renumbered from 1.1.13.7.4.3 due to the removal of EDI previously in 1.1.13.2.

(92) IRM 1.1.13.6.4.4, Updated Workforce Planning, Training and Quality’s (WPTQ) areas and IRMs of responsibility. Subsection renumbered from 1.1.13.7.4.4 due to the removal of EDI previously in 1.1.13.2.

(93) IRM 1.1.13.6.4.5, Updated e-help Operations’ areas and IRMs of responsibility. Subsection renumbered from 1.1.13.7.4.5 due to the removal of EDI previously in 1.1.13.2.

(94) IRM 1.1.13.6.4.6, Updated the names of the five functions within TSO. Updated the functional statements in all of their functions. Subsection renumbered from 1.1.13.7.4.6 due to the removal of EDI previously in 1.1.13.2.

(95) IRM 1.1.13.6.4.6.1, Customer Services Sections (CSS) subsection renumbered from 1.1.13.7.4.6.1 due to the removal of EDI previously in 1.1.13.2.

(96) IRM 1.1.13.6.4.6.2, Filing Information Returns Electronically (FIRE) Support subsection renumbered from 1.1.13.7.4.6.2 due to the removal of EDI previously in 1.1.13.2. Updated functional statements to align with the area’s responsibilities.

(97) IRM 1.1.13.6.4.6.3, Information Filing Support (IFS) subsection renumbered from 1.1.13.7.4.6.3 due to the removal of EDI previously in 1.1.13.2. Updated functional statements to align with the area’s responsibilities.

(98) IRM 1.1.13.6.4.6.4, Products and Services Support (PSS) subsection renumbered from 1.1.13.7.4.6.4 due to the removal of EDI previously in 1.1.13.2. Updated the areas of responsibility.

(99) IRM 1.1.13.6.5, Joint Operations Center (JOC) subsection renumbered from 1.1.13.7.6.5 due to the removal of EDI previously in 1.1.13.2.

(100) IRM 1.1.13.6.5.1, Operations subsection renumbered from 1.1.13.7.5.1 due to the removal of EDI previously located in 1.1.13.2. Updated the mission statement.

(101) IRM subsections 1.1.13.6.5.1.1 through 1.1.13.6.5.2.1 have been renumbered from 1.1.13.7.5.1.1 through 1.1.13.7.5.2.1 due to the removal of EDI previously in 1.1.13.2.

(102) IRM 1.1.13.6.5.2.2, Reports Development (RD) subsection renumbered from 1.1.13.7.5.2.2 due to the removal of EDI previously in 1.1.13.2. Updated the functional statements to align with the area’s responsibilities.

(103) IRM 1.1.13.6.5.3, Contact Analytics and Business Requirements Integration (CABRI) subsection renumbered from 1.1.13.7.5.3 due to the removal of EDI previously in 1.1.13.2. Updated the mission of CABRI.

(104) IRM 1.1.13.6.5.3.1, Contact Analytics (CA) subsection renumbered from 1.1.13.7.5.3.1 due to the removal of EDI previously in 1.1.13.2.

(105) IRM 1.1.13.6.5.3.2, Business Requirements Integration (BRI) subsection renumbered from 1.1.13.7.5.3.2 due to the removal of EDI previously in 1.1.13.2. Updated the mission and functional statements.

(106) IRM 1.1.13.6.5.4, Centralized Quality Review System (CQRS) subsection renumbered from 1.1.13.7.5.4 due to the removal of EDI previously in 1.1.13.2. Updated the functional statements to align with the area’s responsibilities.

(107) IRM 1.1.13.6.5.4.1, Customer Accuracy Improvement Section subsection renumbered from 1.1.13.7.5.4.1 due to the removal of EDI previously in 1.1.13.2.

(108) IRM 1.1.13.6.5.5, Updated the title to reflect the new name as Program Management Office and updated the mission and functional statements. Added sections who report to Chief of PMO. Subsection renumbered from 1.1.13.7.5.5 due to the removal of EDI previously in 1.1.13.2.

(109) IRM 1.1.13.6.5.5.1, Project Management Team subsection renumbered from 1.1.13.7.5.5.1 due to the removal of EDI previously in 1.1.13.2. Updated the functional statements to align with the area’s responsibilities.

(110) IRM 1.1.13.6.5.5.2, Added subsection for the newly created Voicebot/Chatbot Team. Included the mission and functional statements that align with the area’s responsibilities.

(111) IRM 1.1.13.6.6, Submission Processing (SP) subsection renumbered from 1.1.13.7.6 due to the removal of EDI previously in 1.1.13.2. Updated Paper Processing Branch’s name to Return Processing Branch throughout the IRM. Removed Fresno from the areas that report to the Director, Submission Processing.

(112) IRM 1.1.13.6.6.1, Updated name to Return Processing Branch formerly named Paper Processing Branch. Subsection renumbered from 1.1.13.7.6.1 due to the removal of EDI previously located in 1.1.13.2.

(113) IRM subsections 1.1.13.6.6.1.1 through 1.1.13.6.6.2 renumbered from 1.1.13.7.6.1.1 through 1.1.13.7.6.2 due to the removal of EDI previously in 1.1.13.2.

(114) IRM 1.1.13.6.6.2.1, Electronic Payment Section subsection renumbered from 1.1.13.7.6.2.1 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statement to remove Bank of America.

(115) IRM 1.1.13.6.6.2.2, Lockbox Policy and Oversight Section subsection renumbered from 1.1.13.7.6.2.2 due to the removal of EDI previously located in 1.1.13.2.

(116) IRM 1.1.13.6.6.2.3, Accounting and Deposit Section subsection renumbered from 1.1.13.7.6.2.3 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statement to remove Health Coverage Tax Credit (HCTC).

(117) IRM 1.1.13.6.6.3, Program Management/Process Assurance Branch subsection renumbered from 1.1.13.7.6.3 due to the removal of EDI previously located in 1.1.13.2. Updated the sections that reports to the Chief.

(118) IRM 1.1.13.6.6.3.1, Monitoring Section subsection renumbered from 1.1.13.7.6.3.1 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statement to include the IRMs that are maintained.

(119) IRM 1.1.13.6.6.3.2, Resource Section subsection renumbered from 1.1.13.7.6.3.2 due to the removal of EDI previously located in 1.1.13.2.

(120) IRM 1.1.13.6.6.3.3, Changed the title of the section from ‘Coordination and Quality Support’ to Coordination and Support Section. Subsection renumbered from 1.1.13.7.6.3.3 due to the removal of EDI previously located in 1.1.13.2. Updated the mission, focus and functional statements. Removed IRMs no longer authored.

(121) IRM 1.1.13.6.6.3.4, Added newly created ‘Quality Support Section’. Included mission and functional statements and the IRMs authored by this section.

(122) IRM 1.1.13.6.6.4, Specialty Programs Branch subsection renumbered from 1.1.13.7.6.4 due to the removal of EDI previously located in 1.1.13.2. Changes made to mission and functional statements.

(123) IRM 1.1.13.6.6.4.1, Individual Taxpayer Identification Number (ITIN) Policy Section subsection renumbered from 1.1.13.7.6.4.1 due to the removal of EDI previously located in 1.1.13.2. Updated functional statements.

(124) IRM 1.1.13.6.6.4.2, Post Processing Section subsection renumbered from 1.1.13.7.6.4.2 due to the removal of EDI previously located in 1.1.13.2.

(125) IRM 1.1.13.6.6.4.3, Technical Support Section subsection renumbered from 1.1.13.7.6.4.3 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statement to remove Kansas City Center and add Austin SP and Memphis centers.

(126) IRM 1.1.13.6.6.5, e-File Services subsection renumbered from 1.1.13.7.6.5 due to the removal of EDI previously located in 1.1.13.2. Updated branch names.

(127) IRM 1.1.13.6.6.5.1, Development Services Branch subsection renumbered from 1.1.13.7.6.5.1 due to the removal of EDI previously located in 1.1.13.2. Updated functional statements and added section that reports to the branch.

(128) IRM 1.1.13.6.6.5.1.1, Development Services Section 1 subsection renumbered from 1.1.13.7.6.5.1.1 due to the removal of EDI previously located in 1.1.13.2. Removed Development Services Section 1 making it obsolete.

(129) IRM 1.1.13.6.6.5.1.2, Development Services Section 2 subsection renumbered from 1.1.13.7.6.5.1.2 due to the removal of EDI previously located in 1.1.13.2. Removed Development Services Section 2 making it obsolete.

(130) IRM 1.1.13.6.6.5.2, IMF Services Branch subsection renumbered from 1.1.13.7.6.5.2, previously titled IMF Operations and Maintenance Services Branch, due to the removal of EDI previously located in 1.1.13.2. Updated the functional statements. Added section that reports to the branch.

(131) IRM 1.1.13.6.6.5.2.1 Individual e-File Sections subsection renumbered from 1.1.13.7.6.5.2.1, previously titled Individual e-File Sections 1 and 2, due to the removal of EDI previously located in 1.1.13.2. Update the functional statements.

(132) IRM 1.1.13.6.6.5.3, BMF Services Branch subsection renumbered from 1.1.13.7.6.5.3, previously titled BMF Operations and Maintenance Services Branch, due to the removal of EDI previously located in 1.1.13.2. Updated functional statements. Removed sections reporting to the branch.

(133) IRM 1.1.13.6.6.5.3.1, BMF Sections 1, 2, and 3 subsection renumbered from 1.1.13.7.6.5.3.1, previously titled Corporate and Partnership Section, due to the removal of EDI previously located in 1.1.13.2. Removed the mission and updated the functional statements.

(134) IRM 1.1.13.6.6.5.3.2, Removed Estates and Trusts/Employment Tax/Excise Tax Section, previously located in 1.1.13.7.6.5.3.2, making it obsolete. Took functional statements and moved them to subsection 1.1.13.6.5.3.1 BMF Section 1, 2, and 3.

(135) IRM 1.1.13.6.6.5.4, Electronic Support Services Branch subsection renumbered from 1.1.13.7.6.5.4 due to the removal of EDI previously located in 1.1.13.2. Updated the mission statement and the names of the sections who report to the branch.

(136) IRM 1.1.13.6.6.5.4.1, Electronic Support Services Section 1 subsection renumbered from 1.1.13.7.6.5.4.1 due to the removal of EDI previously located in 1.1.13.2. Formerly named Customer Outreach and System Support Section. Updated the mission statement.

(137) IRM 1.1.13.6.6.5.4.2, Electronic Support Services Section 2 subsection renumbered from 1.1.13.7.6.5.4.2 due to the removal of EDI previously located in 1.1.13.2. Formerly named ACA Information Returns/Modernized Information Returns System Support Section. Updated tthe mission statement.

(138) IRM 1.1.13.6.6.5.5, Industry Engagement and Strategy Branch subsection renumbered from 1.1.13.7.6.5.5 due to the removal of EDI previously located in 1.1.13.2. Formerly named Industry Stakeholder Engagement and Strategy Branch. Updated the functional statements and stakeholders.

(139) IRM subsections 1.1.13.6.6.6 through 1.1.13.6.6.6.1 have been renumbered from 1.1.13.7.6.6 through 1.1.13.7.6.6.1 due to the removal of EDI previously located in 1.1.13.2.

(140) IRM 1.1.13.6.6.6.2, Receipt and Control Operation subsection renumbered from 1.1.13.7.6.6.2 due to the removal of EDI previously located in 1.1.13.2. Updated the departments who report to RCO.

(141) IRM 1.1.13.6.6.6.3, Data Conversion Operation subsection renumbered from 1.1.13.7.6.6.3 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statements.

(142) IRM 1.1.13.6.6.6.4, Document Perfection Operation subsection renumbered from 1.1.13.7.6.6.4 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statements.

(143) IRM 1.1.13.6.6.6.5, Input Correction Operation subsection renumbered from 1.1.13.7.6.6.5 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statements and added additional reporting department.

(144) IRM 1.1.13.6.6.6.6, Planning and Analysis, Submission Processing subsection renumbered from 1.1.13.7.6.6.5 due to the removal of EDI previously located in 1.1.13.2.

(145) IRM 1.1.13.6.6.6.7, Accounting Operation subsection renumbered from 1.1.13.7.6.6.7 due to the removal of EDI previously located in 1.1.13.2. Updated the functional statements and the department names.

(146) IRM 1.1.13.6.6.6.8, Statistics of Income (SOI) Operation subsection renumbered from 1.1.13.7.6.6.8 due to the removal of EDI previously located in 1.1.13.2. Added an exception statement to the reports.

(147) IRM 1.1.13.6.6.6.9, Individual Taxpayer Identification Number (ITIN) Operation subsection renumbered from 1.1.13.7.6.6.9 due to the removal of EDI previously located in 1.1.13.2.

(148) Exhibit 1.1.13-1, Deleted EDI organization from Organization Chart. IPU 25U0194 issued 02-07-2025. Also updated exhibit to reflect other changes made to Taxpayer Services Organizational Chart.

(149) Editorial changes made throughout the IRM including: IPU 24U0081 issued 01-12-2024

- Updated office symbols and links to functional web pages as available. IPU 24U0081 issued 01-12-2024


- Corrected capitalization, typos, grammar, etc. IPU 24U0081 issued 01-12-2024


#### Effect on Other Documents

IRM 1.1.13, Taxpayer Services, dated January 24, 2023, is superseded. IRM Procedural Updates (IPUs) 24U0081 issued on January 12, 2024, 25U0194 issued on February 7, 2025, and 25U0210 issued on February 14, 2025 has been incorporated into this IRM.

#### Audience

All Divisions and Functions

#### Effective Date

(08-29-2025)

LaFondra N. Barlow

Director, Capital Management and Oversight

Taxpayer Services

**1.1.13.1** **(08-29-2025)**

### Introduction to the Taxpayer Services (TS)

1. Taxpayer Services (TS) serves all individual taxpayers and annually processes 225 million individual and business tax returns, including more than 180 million electronically filed returns. TS issues over 125 million individual refunds issued totaling over $347 billion annually. TS also answers over 40 million taxpayer phone calls each year.

2. TS delivers customer service, toll-free telephone and face-to-face help, identity theft victim assistance, tax return processing for all of America’s taxpayers, and administers pre-refund and post-refund compliance activities for taxpayer accounts. In addition, TS support organizations oversee modernization and management of technology, strategic planning and direction, communications, and strategic human capital management, ensuring safety and security and critical infrastructure, formulation and execution of the budget, and advancing equal opportunities for employees. Nationwide, TS has approximately 40,000 employees located in 363 Taxpayer Assistance Centers, 11 Service Center Campuses, and 15 Remote Call Sites.

3. The Chief, TS, reports to the Deputy IRS Commissioner. The Chief and Deputy Chief of TS lead long-term strategies consistent with the mission of the IRS and the mission of TS. These strategies involve planning, managing, directing, and executing nationwide activities for TS.

4. TS consists of the following organizational functions:



   - Communications and Liaison (C&L)

   - TS Operations Support (TSOS)

   - Return Integrity and Compliance Services (RICS)

   - Customer Assistance, Relationships and Education (CARE)

   - Customer Account Services (CAS)

   - Management Services (MS)


5. _Exhibit 1.1.13-1_, Taxpayer Services Organization Chart and Structure, shows the TS organizational structure and functions described in this section.

6. The office symbol for TS is C:DC:TS.

7. Visit TS at Taxpayer Services - Home.


**1.1.13.1.1** **(08-29-2025)**

#### Our Mission, Vision, Philosophy, Values and Goals

1. **Our Mission:** The mission of Taxpayer Services (TS) is "To provide Taxpayer Services customers top-quality service by helping them understand and comply with applicable tax laws and to protect the public interest by applying the tax law with integrity and fairness to all."

2. To accomplish our mission,TS maintains a "**customer-first**" focus through routinely soliciting information concerning the needs and characteristics of its customers and implementing programs based on the feedback received. In addition, TS:



   - Provides professional and courteous service to customers to help them understand and meet their tax obligations.

   - Partners with other federal agencies, financial institutions, tax preparers, community groups, trade organizations, state and local authorities and others to provide one-stop multi-agency tax information and education services to TS customers.

   - Strives to make taxes easier through continuous innovations in taxpayer service and compliance programs.


3. **Our Vision:** To make taxes easier through continuous innovations in taxpayer service and compliance programs.

4. **Our Philosophy:** To create a culture that values discovering the right thing to do and then doing it right. To challenge the status quo and ask the questions:



   - Does it make sense?

   - Is it the right thing to do?


5. **Our Values:**



   - Honesty and Integrity

   - Openness, Collaboration, and Inclusion

   - Trust

   - Recognition and Appreciation

   - Respect

   - Accountability

   - Excellence

   - Service to Others


6. **Our Goals:** The goals of TS parallel IRS strategic goals and the IRS Integrated Modernization Business Plan to provide service to all taxpayers and increase productivity through a quality work environment.

7. This is accomplished by:



   - Simplifying the process of filing, correction and payment for all taxpayers and their representatives.

   - Helping taxpayers understand their rights and responsibilities through proactive education and tailored outreach.

   - Expanding secure digital options for taxpayers and professionals to interact efficiently with the IRS, while maintaining and improving traditional service options.

   - Continuing partnerships to tackle common challenges, generate cost savings and share leading practices.

   - Fostering a collaborative and inclusive culture.

   - Supporting employee development with training opportunities and clear career paths.

   - Enhancing succession planning and knowledge transfer processes.


8. TS will gauge progress in achieving these goals through measures and goals that have been established for all of the TS Operating Units. Our measures continue to be refined as programs and priorities evolve.

9. Taxpayer Services follows guidance provided in IRM 1.2.61.2.1, **TS Delegation Order TS 1-1-1** for order of succession.


**1.1.13.1.2** **(01-24-2023)**

#### Our Customer Base

1. Taxpayer Services (TS) serves all individual taxpayers and annually processes more than 225 million individual and business tax returns.

2. Almost all the income for this group is reported by third parties, and the vast majority of taxes are collected through third-party withholding. Most of these taxpayers deal with the IRS only when they file their returns, receive refunds, and are highly compliant.

3. TS serves its customers by:



1. Answering toll-free calls through customer service representatives and automation.

2. Answering paper customer account inquiries.

3. Servicing face-to-face customer contacts at the Taxpayer Assistance Centers.

4. Preparing tax returns through volunteers.

5. Providing Enterprise web services such as "Where’s My Refund" .

6. Protecting revenue by detecting potential first and third-party fraud, including identity theft-related refund claims.


**1.1.13.1.3** **(08-29-2025)**

#### Management Services (MS)

1. Management Services is responsible for providing support and coordination for the Chief and Deputy Chief, Taxpayer Services.

2. **The mission** of Management Services is to provide executive and administrative support, procedural and policy guidance, and program support on behalf of Taxpayer Services Chief and Deputy Chief.

3. Management Services reports directly to the Chief of Staff who reports to the Chief, Taxpayer Services.


**1.1.13.2** **(01-24-2023)**

### Taxpayer Services (TS) Communications and Liaison (C&L)

1. **About:** The Taxpayer Services (TS) Communications and Liaison (C&L) office is the communications support function for TS and coordinates communications planning and implementation for the business unit through the office of National Communications and Liaison. Its primary goal is to help TS organizations appropriately and effectively communicate with their employees, customers, and stakeholders.

2. **Mission:** To help TS achieve its long-term goals and day-to-day business objectives through results-driven, organizationally integrated internal and external communications.

3. To accomplish the mission, TS C&L:



01. Consults with TS clients to identify business needs and objectives and provide strategic and tactical communications planning and products that meet the client’s goals.

02. Provides communications expertise and advice to the TS Chief and direct reports.

03. Builds and maintains strong business relationships with division leaders who support the strategic communications planning process.

04. Creates synergy within the TS C&L organization, designing and managing internal work processes that ensure quality products and group cohesion.

05. Serves as the primary communications liaison with other business units and headquarters C&L functions, particularly at the executive level.

06. Connects TS functional client programs and strategies to TS’s strategic plan, goals and vision with consistent messaging and communication strategies.

07. Oversees internal and external product development, ensuring products conform to publication standards in IRM 11.55.2.7, TS Publication Standards.

08. Guides and monitors employee performance, assigning work to employees based on existing and future business priorities and requirements.

09. Researches, interviews, writes and edits communication products primarily targeting campus employees.

10. Provides graphic and photographic support for news products and to fulfills other campus-related business needs.

11. Builds and maintains relationships with campus executives, managers and employees to support campus-based communications, when needed.


4. The Director, TS C&L reports to the Taxpayer Services Chief.

5. The office symbols for C&L are C:DC:TS:C.

6. Visit TS C&L at: Our Products.


**1.1.13.3** **(04-29-2022)**

### Taxpayer Services Operations Support (TSOS)

1. **About:** The TS Operations Support (TSOS) organization serves as the central headquarters for TS financial management, operations, planning and analysis, quality assurance and process efficiencies efforts, human capital management, performance reporting, risk analysis, modernization efforts, internal controls and organizational needs.

2. **Mission:** To implement IRS strategic directives by collaborating with our partners to identify organizational needs and to strategically align resources to deliver value-added, cost-efficient business and technology solutions.

3. To accomplish the mission, TSOS:



1. Provides oversight of strategic planning and direction for Taxpayer Services (TS).

2. Manages and oversees human resource, workforce relations, and leadership development activities within TS.

3. Oversees implementation of operational fiscal resource planning, formulation and execution of the budget.

4. Implements business improvement strategies and solutions.

5. Ensures safety and security and critical infrastructure.

6. Collaborates with partners to plan, develop and deliver modernized business systems.

7. Modernizes and re-engineers tax processing.

8. Collaborates with partners to deliver automated tools and technologies.

9. Manages the program evaluation and risk analysis processes, evaluates proposed programs for their investment in achieving division goal and assesses risks with ongoing programs.


4. The following functions report to the Director, TSOS:



   - Capital Management and Oversight (CMO)

   - Business Systems Modernization (BSM)

   - Business Technology Operations (BTO)

   - Strategies and Solutions

   - Program Management Office (PMO)


5. The office symbols for TSOS are C:DC:TS:O.

6. Visit TSOS at: Operations Support.


**1.1.13.3.1** **(08-29-2025)**

#### Capital Management and Oversight (CMO)

1. **Mission:** To provide world-class customer service, strategic management, and oversight in the delivery of employee and leadership development, finance, and human capital programs in support of TS’ mission.

2. To accomplish the mission, Capital Management and Oversight (CMO):



1. Serves as advisor and consultant to TS leadership and employees on various human capital related programs and ensures compliance and accountability of programs.

2. Provides financial management and oversight including operational fiscal planning, budget formulation, and execution.

3. Provides human capital services including career development, employee engagement, hiring, leadership succession planning, learning product development, recruitment, and workforce organization design.

4. Develops strategies and programs that assist in development and implementation of business continuity, employee satisfaction survey, performance management, workforce relations, and training and instructor evaluation.

5. Oversees the development of short-and long-term workforce planning models.


3. The Director, CMO reports to the Director, Taxpayer Services Operations Support (TSOS).

4. The following functions report to the Director, CMO:



   - Compliance and Accountability (CA)

   - Finance

   - Workforce Development (WD)

   - Workforce Strategic Management (WSM)

   - Workforce Support (WS)


5. The office symbols for CMO are C:DC:TS:O:CMO.

6. Visit CMO at: Capital Management & Oversight.


**1.1.13.3.1.1** **(08-29-2025)**

##### Compliance and Accountability (CA)

1. _Mission:_ Our mission is to foster a culture of compliance and accountability by upholding ethical standards, promoting transparency, and ensuring adherence to regulations, thereby building trust, and sustaining integrity within the Taxpayer Services community.

2. To accomplish the mission, CA:



1. Serves as advisor and consultant to TS leadership in ensuring compliance and accountability of program delivery.

2. Partners with TS leadership and HCO to put processes in place to ensure compliance.

3. Conducts periodic reviews of human capital programs to evaluate consistency, effectiveness, and quality.

4. Supports audits, risk, and compliance activities for all CMO programs, including evaluation of policies and operational guidance, metrics, and internal controls.


3. The Chief, CA reports to the Director, Capital Management and Oversight (CMO).

4. The office symbols for CA are C:DC:TS:O:CMO:CA.

5. Visit CA at:Compliance & Accountability - Home.


**1.1.13.3.1.2** **(08-29-2025)**

##### Finance

1. **Mission:** To provide advice and oversight to Taxpayer Services division-wide by coordinating all issues related to operational fiscal planning, budget formulation, financial plan execution and management controls.

2. To accomplish the mission, Finance:



01. Develops and maintains the master financial data repository structures for TS.

02. Manages the process of formulating multiple year budgets consistent with the TS Business Plan.

03. Manages the resource distribution process, including the development of a financial plan that supports the program priorities of TS.

04. Manages the financial resources for TS, including tracking resource usage against targets, and provides the necessary financial information to TS management that reflects the status of budget execution.

05. Establishes financial policies, procedures, and controls for TS in conjunction with overall IRS guidelines and procedures.

06. Provides the necessary financial support to TS operating units to develop sub-contracts with other business units (BUs) for delivery of shared services and determines billing and funds transfer procedures.

07. Administers and monitors reimbursable programs and cash awards.

08. Conducts division-wide financial reviews and develops recommendations with operating units to achieve a balanced financial plan.

09. Provides advice and assistance to operating units in developing and executing sound business cases.

10. Provides financial documentation on costing of initiatives and tracking resulting efficiency saving and expenditures.


3. The Chief, Finance, reports to the Director, Capital Management and Oversight (CMO).

4. The following sections report to the Chief of Finance:



   - Budget Execution/ Enforcement/HQ/Reporting

   - Budget Execution/Taxpayer Services

   - Budget Execution/ Campus Support

   - Program Support


5. The office symbols for Finance are C:DC:TS:O:CMO:F.

6. Visit Finance at: Finance.


**1.1.13.3.1.3** **(08-29-2025)**

##### Workforce Development (WD)

1. **Mission:** To foster proactive outreach and provide division-wide expertise that will improve the overall learning experience, integrate leadership and succession planning, provide instructor and training evaluation oversight, and develop ways to improve the employee’s learning experience in TS.

2. To accomplish the mission, WD will:



1. Serve as a central focus for learning and provide oversight, guidance, consultation, and support to TS leadership.

2. Emphasize and focus on learning, training and education, leadership succession, evaluation, and instructional course development and course delivery.

3. Provide oversight and a long-term strategy and accountability for course criteria, curriculum development.

4. Promote leadership readiness programs (frontline, senior manager, executive, and candidate development) and collaborate with HCO to revise and enhance.

5. Coordinate, monitor, and oversee all aspects of various Training Development and Delivery.

6. Assists customers in identifying the performance improvement opportunities.

7. Supports performance improvement through the design, development and delivery of quality learning products.


3. The Chief, WD reports to the Director, CMO.

4. The office symbols for Workforce Development are C:DC:TS:O:CMO:WD.


**1.1.13.3.1.3.1** **(08-29-2025)**

###### Career & Leadership Development (CLD)

1. Career & Leadership Development (CLD) creates, promotes, and fosters individual and organizational effectiveness by developing and executing a wide array of innovative and diverse training programs in support of Taxpayer Services’ commitment to career development, leadership succession, and organizational enrichment.

2. To accomplish the mission, Career & Leadership Development (CLD):



1. Empower employees to find their niche in the organization and to develop and apply their knowledge and skills to achieve a fulfilling career.

2. Create tools and programs that support career development, enhance our culture, and promote an equitable and engaging workplace.

3. Inspire managers and employees to grow professionally by building communities, eradicate barriers and silos, and creating space and time for engagement and thoughtful discussion.

4. Identify and develop strategic partnership opportunities within the IRS and externally to support the development and implementation of training programs for employees and managers at all levels.

5. Design and execute development opportunities for readiness program members that sharpens their knowledge, strengthen their skills, and enriches the organization.

6. Assess and measure the development and skills of our leadership pipelines to identify key insights and opportunities to strengthen our training and education programs, offer more extensive coaching and mentoring, and ultimately prepare tomorrow’s leaders for today.


3. The Chief, CLD reports to the Chief, Workforce Development (WD).

4. The office symbols for CLD are C:DC:TS:O:CMO:WD:CLD.

5. Visit CLD at: Career & Leadership Development


**1.1.13.3.1.3.2** **(08-29-2025)**

###### Learning and Education (L&E)

1. **Mission:** To provide Taxpayer Services (TS) employees with learning opportunities that equip them to deliver top-quality service to their customers.

2. To accomplish the mission, Learning and Education (L&E):



1. Assists customers in identifying the performance improvement opportunities needed to meet their business goals.

2. Supports performance improvement through the design, development and delivery of quality learning products.

3. Partners with other learning stakeholders to implement industry best practices.


3. The Chief, L&E reports to the Chief, Workforce Development (WD). The following sections report to the Chief, L&E:



   - Project Management and Design Office 1

   - Project Management and Design Office 2

   - Project Management and Design Office 3

   - Technology Development Office 1

   - Technology Development Office 2


4. The office symbols for L&E are C:DC:TS:O:CMO:WD:LE

5. Visit L&E at: Learning & Education.


**1.1.13.3.1.3.3** **(08-29-2025)**

###### Training Delivery and Evaluation (TD&E)

1. **Mission:**To coordinate and facilitate training delivery and evaluation for TS employees.

2. To accomplish the mission, TD&E will:



1. Ensure the Annual Training Plan and Treasury Directive 12-70 is followed and the training delivered is valuable to the learner and delivered accurately.

2. Ensure instructors are accurately trained and deliver content based upon accurate course development and lesson plans.


3. The Chief, TD&E reports to the Chief, Workforce Development (WD). The following sections report to the Chief, TD&E:



   - Training Delivery

   - Instructor Evaluation


4. The office symbols for TD&E are C:DC:TS:O:CMO:WD:TDE.


**1.1.13.3.1.4** **(08-29-2025)**

##### Workforce Strategic Management (WSM)

1. **Mission:** Provide world-class customer service, strategic management, and oversight in the delivery of human capital programs in support of TS’s mission.

2. To accomplish the mission, Workforce Strategic Management (WSM):



1. Serves as advisor and consultant to TS leadership and employees on various human capital related programs.

2. Manages and oversees human resource and workforce relations activities within TS.

3. Manages the strategic planning and policy guidance activities of TS and establishes the strategic direction and overall goals for the division.

4. Provides staff support to the various TS governance structures for human capital program areas.

5. Prepares the TS organizational performance measures, develops systems to capture TS measures data, and devises mechanisms to track performance.

6. Provides guidance to management on quality improvement methods.

7. Oversees the development of short- and long-term workforce planning models.


3. The Chief, WSM reports to the Director, Capital Management and Oversight (CMO).

4. The following functions report to the Chief, WSM:



   - Workforce Recruitment & Hiring Solutions (WRHS)

   - Workforce Planning (WP)

   - Workforce Relations & Performance Management (WRPM)


5. The office symbols for WSM are C:DC:TS:O:CMO:WSM.


**1.1.13.3.1.4.1** **(08-29-2025)**

###### Workforce Recruitment & Hiring Solutions (WRHS)

1. **Mission:** To provide customer service for division-wide hiring and recruitment, strategic implementation of TS hiring and recruitment goals, and coordination with Human Capital Office (HCO) for an improved human capital experience.

2. To accomplish the mission, WRHS:



1. Serves as liaison and provides guidance, consultation, and support to the Taxpayer Services (TS) leadership team.

2. Communicates changes impacting customers and efficiencies in hiring and recruitment processes.

3. Collaborates with TS stakeholders on hiring flexibilities and authorities to optimize our hiring process for speed, efficiency, and candidate experience, and adapting to new opportunities and mitigating risks.

4. Enhance and promote employee engagement through leadership.

5. Coordinates, monitors, and oversees aspects of various human capital related programs such as filing season hiring readiness, workforce flexibilities, hiring, staffing, and incentive coordination. Engage with HCO on automation and efficiency opportunities for the incentives.

6. Supports HCO efforts to ease barriers to smooth onboarding through a standardized, improved experience for new employees and provide new employees with access and technology more quickly.

7. Provides oversight of the TS priority hiring process and the Servicewide Opportunities Listing.


3. The Chief, WRHS reports to Chief, Workforce Strategic Management (WSM).

4. The following sections report to the Chief of WRHS:



   - Recruitment

   - Staffing

   - Program support


5. The office symbols for WHRS are C:DC:TS:O:CMO:WRHS.

6. Visit WHRS at: Workforce Recruitment & Hiring Solutions (WRHS)


**1.1.13.3.1.4.2** **(08-29-2025)**

###### Workforce Planning (WP)

1. **Mission:** To provide Taxpayer Services wide expertise, by coordinating with functional representatives, which will integrate organizational design and workforce planning with human resources management.

2. To accomplish the mission, Workforce Planning (WP):



1. Serves as liaison and provides guidance, consultation, and support to TS leadership. Collaborating with internal/external stakeholders to align workforce planning strategies.

2. Emphasizes and focuses on training and education, communication, workforce planning overview, current workforce resources, retirement bubbles, workload changes, and attrition rates that impact TS.

3. Designs career management tools to ensure career broadening opportunities exist for employees to progress to jobs within TS and in other operating divisions.

4. Develops a long-term strategy for acquiring, developing, and retaining critical staff to have the right people with the right competencies in the right place at the right time to achieve the mission or goals.

5. Develops workforce plans and work design programs that integrate with position management requirements.

6. Coordinates, monitors, and oversees all aspects of various human capital-related programs such as filling season hiring readiness, workforce planning, organizational design/redesign, position management, and span of control.


3. The Chief, WP reports to the Chief, Workforce Strategic Management (WSM).

4. The following sections report to the Chief of WP:



   - Organizational Design

   - Organizational Management & Planning

   - Workforce Analytics


5. The office symbols for WFP are C:DC:TS:O:CMO:WP.

6. Visit WP at: Workforce Planning.


**1.1.13.3.1.4.3** **(08-29-2025)**

###### Workforce Relations and Performance Management (WRPM)

1. **Mission:** To develop strategies and programs which assist in development and implementation of performance management and workforce relations for Taxpayer Services (TS) leadership.

2. To accomplish the mission, WRPM:



1. The Workforce Relations section serves as liaison between TS leadership and HCO Labor and Employee Relations and Negotiations (LERN) and provides guidance, consultation and support in both workforce relations and collective bargaining. Their support extends to litigation, grievance, and arbitration.

2. The Performance Management section provides guidance in the development and operation of performance management, recognition, incentive, and compensation programs and systems, as well as other HCO strategies that motivate, evaluate, and reward employees that support the IRS’s objectives.


3. The Chief, WRPM reports to the Chief, Workforce Strategic Management (WSM).

4. The office symbols for WRPM are C:DC:TS:O:CMO:WRPM.

5. Visit WRPM at: Workforce Relations & Performance Management (WRPM).


**1.1.13.3.1.5** **(08-29-2025)**

##### Workforce Support (WS)

1. **Mission:** Workforce Support (WS) provides customer support for employee engagement, employee experience, and a variety of programs and benefits.

2. To accomplish the mission, WS:



1. Provides leadership, guidance, and support to effectively implement human capital programs including but not limited to Engagement Councils, Federal Employee Viewpoint Survey (FEVS), workplace flexibilities, and work-life.

2. Serves as TS FMSS liaison.

3. Serves as the TS liaison for Business Continuity by preparing TS leaders and employees to respond appropriately and timely to coordinated tests, exercises, and emergency situations.


3. The Chief, WS, reports to the Director, Capital Management and Oversight (CMO).

4. The following sections report to the Chief of Workforce Support:



   - Organizational Support

   - Engagement & Recognition


5. The office symbols for WS are C:DC:TS:O:CMO:WS.

6. Visit WS at: Workforce Support - Workforce Support Home.


**1.1.13.3.2** **(08-29-2025)**

#### Business Systems Modernization (BSM)

1. **About:** Business Systems Modernization (BSM), formerly Modernization Development and Delivery (MDD), improves IRS business performance by collaborating with internal and external stakeholders in the identification, development, delivery, and maintenance of modernized business systems.

2. **Mission:** To collaborate with IRS Stakeholders in the development, delivery, and maintenance of modernized business systems. Ensure alignment with IRS Integrated Business Modernization Plan and Measures.

3. To accomplish the mission, BSM provides continual Business and Information Technology (IT) stakeholder collaboration to strengthen business modernization values that align to the IRS’ Future State and Strategic Goals in the areas of:



1. IT Programs BSM.

2. Modernized, cross-functional, and integrated systems using Agile functionality with business partners.

3. Coordination across the service to ensure Taxpayer Services (TS) initiatives are successful. BSM evaluates and prioritizes systems for Integration consideration, performs gap analysis and efficiency assessments, transmits a repeatable, robust, and comprehensive process for capabilities assessment, while also engaging in organizational readiness activities.

4. Collaboration and support in the development and delivery of modernizing tools and technology that would improve business operations services. BSM provides support to the business units (BUs) in launching new business practices by ensuring readiness activities are completed and partners with IT on technological improvements for the business.

5. Lean Business Case documentation for leadership prioritization of digital capable services.


4. BSM reports to the Director, Taxpayer Services Operations Support (TSOS).

5. The following functions report to the Director, BSM:



   - Modernization Demand and Release Management (MDRM)

   - Governance Risk and Compliance (GRC)

   - Modernization Organization Readiness Services (MORS)

   - Modernization Sustaining Operations (MSO)

   - Modernization Project Management Services (MPMS)

   - Project Office (PO)

   - Rules and Requirements (RR)


6. The office symbols for BSM are C:DC:TS:O:BSM.


**1.1.13.3.2.1** **(04-29-2022)**

##### Modernization Demand and Release Management (MDRM)

1. **Mission:** To update, monitor, track and report, Taxpayer Services (TS) modernization activities and progress and to collaborate with Information Technology (IT), Online Services (OLS), and other business units (BUs) to enable timely delivery of TS modernization initiatives.

2. To accomplish the mission, Modernization Demand and Release Management (MDRM), formerly Intake, Architecture, and Release Planning:



1. Identifies TS Modernization Demand, evaluates modernization planning documents and legislative changes to identify potential TS new modernization demand and determines support type, timing/staffing needs, and impact to the TS Modernization Roadmap.

2. Identifies and allocates resources to provide support for TS Modernization initiatives.

3. Conducts continuous monitoring of TS Modernization Initiatives and periodic reporting of the TS Modernization Roadmap to TS Customers/Stakeholders.

4. Collaborates on high-level scope and schedule, assesses resource needs, and prioritizes capabilities/epics.


3. MDRM reports to the Director, Business Systems Modernization (BSM).

4. The office symbols for MDRM are C:DC:TS:O:BSM:MDRM.


**1.1.13.3.2.2** **(04-29-2022)**

##### Governance, Risk and Compliance (GRC)

1. **Mission:** To equip business members of governing boards with information to make informed decisions for transforming taxpayer services and business performance, establish effective governing processes and change management controls; and protect the confidentiality, integrity, and availability of Taxpayer Services Operations Support (TSOS) owned applications and their data.

2. To accomplish the mission, Governance, Risk and Compliance (GRC), formerly Governance Risk and Security:



1. Creates touch points to enhance executive engagement, explores opportunities to add more business value by monitoring and reporting program risk, collaborates with Business Systems Modernization (BSM) partners to improve the process for submitting change requests, and partners with Business Technology Operations (BTO) to improve exit readiness reviews for Integrated Automated Technologies (IAT) tools.

2. Equips business members of governing boards with information to make informed decisions for transforming taxpayer services and business performance and establish effective governing processes and change management controls.

3. Partners with Cybersecurity and Information Technology (IT) to adapt to the Agile Enterprise Life Cycle (ELC) Methodology, explores opportunities to add business value to the Digital Identity Risk Assessment process, and ensures BSM applications meet Federal Information Security Management Act (FISMA) and National Institute of Standards and Technology (NIST) requirements.


3. GRC reports to the Director, Business Systems Modernization (BSM).

4. The office symbols for GRC are C:DC:TS:O:BSM:GRC.


**1.1.13.3.2.3** **(04-29-2022)**

##### Modernization Organization Readiness Services (MORS)

1. **Mission:** To conduct organization readiness activities to assist Taxpayer Services (TS) functional areas, collaborate with Information Technology (IT), Online Services (OLS) and other business units (BUs) to prepare operational processes for implementation of modernized capabilities and processes.

2. To accomplish the mission, Modernization Organization Readiness Services (MORS), formerly Project Management - Major Projects, provides oversight and support for:



1. Product Increment Planning - Performs Program Increment planning for Agile projects to inform development activities and engages in organizational readiness activities.

2. Business Liaison - Interacts with business stakeholders and subject matter experts to understand, document, and convey business needs as requirements (i.e., user story creation and validation, business rule writing mentoring) for Information Technology (IT) development. Supports the business in preparing to receive a system deployed, including forecasting training costs and providing initial training to the business stakeholders.

3. Project execution and progress monitoring - Identifies and schedules business activities.

4. User Acceptance Testing (UAT) Planning - Develops or supports development of test cases, effectively tests the functionality from the end user perspective, and tracks resolution of defects.

5. Post Deployment Validation - Effectively tests and validates defects identified and reported via the Knowledge, Incident/Problem, Service Asset Management (KISAM) system during UAT were not deployed into the production environment.


3. MORS reports to the Director, Business Systems Modernization (BSM).

4. The office symbols for MORS are C:DC:TS:O:BSM:MORS.


**1.1.13.3.2.4** **(04-29-2022)**

##### Modernization Sustaining Operations (MSO)

1. **Mission:** To provide project management services for the future state of Account Management Service (AMS), Legacy components including Electronic Fraud Detection System (EFDS) and the Return Review Program (RRP) and perform pre-deployment and deployment coordination activities in collaboration with Taxpayer Services (TS) functional areas, Information Technology (IT), Online Services (OLS) and other business units (BUs).

2. To accomplish the mission, Modernization Sustaining Operations (MSO), formerly Project Management - Sustaining Operations:



1. Completes all Filing Season Readiness (FSR) activities, including Unified Work Requests (UWRs), to ensure system users of Legacy Components (EFDS) and the RRP are equipped with capabilities to protect revenue and prevent fraud.

2. Completes all FSR activities, including UWRs, to ensure system users of Accounts Management System (AMS) have access to inventory and multiple forms/tools to better assist taxpayers.

3. Monitors post deployment production incidents per IT and TS Incident Management processes.


3. MSO reports to the Director, Business Systems Modernization (BSM).

4. The office symbols for MSO are C:DC:TS:O:BSM:MSO.


**1.1.13.3.2.5** **(08-29-2025)**

##### Modernization Project Management Services (MPMS)

1. **Mission:** To provide strategic product (program) support in delivery of digital services for stakeholders and customers and support change, conduct project management activities to assist Taxpayer Services (TS) functional areas, and collaborate with Information Technology (IT), Online Services (OLS), and other business units (BUs) to timely deliver modernized TS capabilities and processes.

2. To accomplish the mission, Modernization Project Management Services (MPMS), formerly Project Management - External Services Delivery:



1. Assists in partnership with Taxpayer Services (TS) with the development of a Digital Service Strategy through the solicitation, facilitation, prioritization and documentation of digital capabilities and services.

2. Supports partners through facilitation and creation of artifacts and products to support digital services.

3. Provides customer representation and serves as advocate for TS during end to-end Agile product delivery activities.

4. Supports TS WebApps by identifying and defining capabilities, facilitating and authoring documentation/artifacts with stakeholder support to promote governance and development, collaborating with stakeholders (i.e., Online Services (OLS) and Customer Account Services (CAS) Project Management Office (PMO)) to complete lean business cases for leadership prioritization, harvesting user stories and key features for development and serving as liaison and advocate for TS.


3. MPMS reports to the Director, Business Systems Modernization (BSM).

4. The office symbols for MPMS are C:DC:TS:O:BSM:MPMS.


**1.1.13.3.2.6** **(08-29-2025)**

##### Project Office (PO)

1. **Mission:**To drive business strategy for modernization initiatives that deliver Servicewide tax processing improvements and provide enterprise data delivery services for taxpayers and business operations.

2. To accomplish the mission, the Project Office (PO) coordinates across IRS modernization initiatives and legacy programs to ensure integrated solutions meet the needs of business operations. PO:



1. Serves as the primary liaison between Information Technology and business operating divisions for modernization initiatives.

2. Approves the implementation of enhanced business capabilities and manages business supports for project development, testing, and deployment.

3. Completes business impact assessments and approves trade-off decisions for project scope changes and risk assessments.

4. Manages project development and integration issues, prepares data, recommends options for resolution, and escalates unresolved issues to the appropriate Governance Body.

5. Completes Enterprise Organizational Readiness and transition management activities to ensure successful modernization deployments.

6. Communicates consistent messages to internal and external audiences regarding business priorities, project status, business value, and modernization project results.

7. Supports development of business cases, cost models, and measures for Taxpayer Services projects.


3. PO reports to the Director, Business System Modernization (BSM).

4. The office symbols for PO are C:DC:TS:O:BSM:PO


**1.1.13.3.2.7** **(08-29-2025)**

##### Rules and Requirements (RR)

1. **Mission:**To develop and deliver business requirement standards and rules that support IMF modernization and the implementation of new functionality aimed at improving the internal and external effectiveness and efficiency of the Service.

2. To accomplish the mission, Rules and Requirements (RR):



1. Elicits and develops new business requirements.

2. Models business process flows.

3. Creates business requirements packages for delivery.

4. Creates and maintains a Business Design that reflects the business interpretation of individual tax processing.


3. RR reports to the Director, Business System Modernization (BSM).

4. The office symbols for RR are C:DC:TS:O:BSM:RR.


**1.1.13.3.3** **(01-12-2024)**

#### Business Technology Operations (BTO)

1. **Mission:**To support Taxpayer Services (TS) business and technology integration, by providing technology insight and support, including risk management. Through collaboration and promoting strong stakeholder partnerships, we deliver tools and technologies to support a well-equipped workforce and increased agility/efficiency for TS.

2. To accomplish the mission, Business Technology Operations (BTO), formerly Modernization Tools and Technologies (MTT):



1. Supports business technology strategy and provides enhanced data to support business re-engineering opportunities and Servicewide strategies that improve tax processing.

2. Provides rapid delivery of nimble, scalable employee automation solutions through Integrated Automation Tools (IAT).

3. Manages Technology Integration and Program Support (TIPS) for TS.

4. Leads the TS Risk Management Program, fostering an integrated approach to Risk for TS.

5. Provides business operational services (including TS Incident Management, Unified Work Request support, IT demand and technology modernization areas).

6. Supports, conducts planning, sets policy, and provides oversight and guidance for TS's internal management controls; GAO and TIGTA audit and post audit processes; the GAO financial audit; the A-123 review; Internal Management Documents; the National Taxpayer Advocate (NTA) Most Serious Problems (MSPs); and Electronic Research.


3. The Director, BTO reports to the Director, Taxpayer Services Operations Support (TSOS).

4. The following functions report to the Director, BTO:



   - Integrated Automation Technologies (IAT)

   - Technology, Integration and Program Support (TIPS)

   - Program Evaluation and Improvement (PEI)

   - Business Operations Support (BOS)


5. The office symbols for BTO are C:DC:TS:O:BTO.

6. Visit BTO at: Business Technology Operations.


**1.1.13.3.3.1** **(01-24-2023)**

##### Integrated Automation Technologies (IAT)

1. The mission of Integrated Automation Technologies (IAT) is to design, build, test and deploy desktop productivity-enhancing tools by partnering with our customers to meet evolving business commitments and simplify taxpayer account processing.

2. To accomplish the mission, IAT:



1. Creates and supports two types of tools, Generalized IDRS Interface (GII) and multi-functional tools, designed to automate research and taxpayer account management functions within the Integrated Data Retrieval System (IDRS). IAT tools save time and increase accuracy and employee satisfaction. Less time is spent on repetitive manual data input, allowing for redirection to other tasks.

2. Automates processes and common search and research functions in IDRS, reducing manual data entry required to complete taxpayer account actions. There are approximately 81 IAT tools used in all business units and functional operating divisions by more than 50,000 IRS employees, including customer service representatives, tax examiners, revenue agents and tax analysts.

3. Supports Generalized IDRS Interface (GII) which is an Information Technology (IT) owned batch application that completes simple research and actions within IDRS. GII is most effective when multiple accounts need the same action taken. IAT leverages GII to create runs for one-time project actions and ongoing processes.

4. Provides training, help-desk support, and continuously updates reference materials to ensure their tools are fully used by their customers.


3. IAT reports to the Director, Business Technology Operations (BTO).

4. The office symbols for IAT are C:DC:TS:O:BTO:IAT.

5. Visit IAT at: Integrated Automation Technologies.


**1.1.13.3.3.2** **(08-29-2025)**

##### Technology Integration and Program Support (TIPS)

1. **Mission:** To provide information technology support in meeting the business needs of the Taxpayer Services (TS) Organization. Technology Integration and Program Support (TIPS) provides support and works as a liaison for Information Technology (IT) initiatives in regard to initiative support, computer hardware and software projects/issues, and assists with data and security with programs that affect TS.

2. To accomplish the mission, TIPS:



1. Ensures IT initiatives are achieved in a timely manner.

2. Acts as advocate for TS for many initiatives and programs in the hardware/software department.

3. Partners with IT to ensure TS employees have the technology resources they need, removing roadblocks and elevating issues as needed.

4. Serves as liaison between IT, Cybersecurity and the Office of Privacy for matters such as Computer Security Response Center (CSIRC) Incidents, Data Loss Prevention, Form 11377-E, _Taxpayer Data Access,_ process oversight.

5. Supports M365 and SharePoint including support for Power Platform, Power Apps, Power Automate, Power Bi, Dedicated Environment, Workflows, Troubleshooting, Governance,Teams and SharePoint Online (SPO) Site Request, Creation, and Implementation, etc.


3. TIPS reports to the Director, Business Technology Operations (BTO).

4. The office symbols for TIPS are C:DC:TS:O:BTO:TIPS.

5. Visit TIPS at: TIPS One Stop Shop - Home.


**1.1.13.3.3.3** **(01-24-2023)**

##### Program Evaluation and Improvement (PEI)

1. _Mission:_ To support, conduct planning, set policy, and provide oversight and guidance for Taxpayer Services’ (TS) internal management controls.

2. To accomplish the mission, Program Evaluation and Improvement (PEI):



01. Serves as liaisons, consultants, advisors, coordinators and subject matter experts to TS executives, management officials, and other internal and external stakeholders.

02. Determines business unit/function ownership and identifies supporting stakeholders and points of contact for incoming oversight audits.

03. Participates in opening conferences for oversight audits where TS is the lead or support stakeholder.

04. Monitors audit progress and provides guidance/assistance to the functions as needed.

05. Provides coordination support to the Chief Financial Officer (CFO) for the annual Government Accountability Office (GAO) audit of IRS’s financial statements.

06. Serves as independent observers of the GAO financial audit testing conducted at Submission Processing campuses, lockbox operations, and Taxpayer Assistance Centers.

07. Participates in applicable briefings and closing conferences.

08. Provides timelines for response completion and executive review.

09. Reviews all written responses to Treasury Inspector General for Tax Administration (TIGTA)/GAO for content, tone, clarity, and format.

10. Coordinates the executive review process for approval of audit responses and forwards final response to the auditing authority.

11. Ensures audit findings, recommendations, and planned corrective action (PCA) due dates are accurately reported in the Department of Treasury’s Joint Audit Management Enterprise System (JAMES).

12. Serves as the point of contact on all Enterprise Audit Management (EAM) correspondence about PCAs owned by TS.

13. Monitors and reports to TS leadership, the progress of PCAs in reaching "Implemented" or "Closed" status.

14. Oversees the coordination of all TS Internal Management Documents (IMDs), ensuring accuracy and timely distribution.

15. Represents TS on the IMD Council.

16. Manages electronic research user accounts for TS (Accurint, Thomson Reuters Westlaw, and Bloomberg).

17. Assists the TS Commissioner’s staff by coordinating the TS responses and other activities associated with the National Taxpayer Advocate Service (TAS) Most Serious Problems (MSP) program.

18. Coordinates and oversees the TS Section 1204 certification process.


3. The Chief, PEI, reports to the Director, Business Technology Operations (BTO).

4. The office symbols for PEI are C:DC:TS:O:BTO:PEI.

5. Visit PEI at: Program Evaluation & Improvement (PEI).


**1.1.13.3.3.4** **(08-29-2025)**

##### Business Operations Support (BOS)

1. _Mission:_ Business Operations Support (BOS) provides organizational oversight and coordination for Taxpayer Services (TS) to navigate established Information Technology (IT) processes to maintain consistency, efficiency, and effectiveness.

2. To accomplish the mission, Business Operations Support (BOS):



1. Supports TS IT Incident Management communications and collaboration.

2. Provides administration and reporting on the TS Unified Work Request (UWR) Program and the IT Portfolio Investment Process (PIP).

3. Coordinates and manages Federal Information Security Management Act (FISMA) business-related activities for the CADE 2 and Individual Master File (IMF) applications.

4. Coordinates business activities for CADE 2 production maintenance.

5. Supports TS IT Incident Management communications and collaboration.


3. The Chief, BOS, reports to the Director, Business Technology Operations (BTO).

4. The office symbols for BOS are C:DC:TS:O:BTO:BOS.

5. Visit BOS at: TS Business Operations Support - Home.


**1.1.13.3.4** **(01-24-2023)**

#### Strategies and Solutions

1. **Mission:** To collaborate with its partners to identify, plan and deliver business improvement strategies and solutions that support fulfillment of IRS strategic goals.

2. To accomplish the mission, Strategies and Solutions collaborates with partners on business and information technology strategies, solutions, and initiatives such as:



1. Process Improvement Initiatives

2. Customer Satisfaction Surveys

3. Advanced Analytic and Taxpayer Behavioral Studies

4. Business Process Re-engineering

5. Thought Leadership/Alternative Analysis

6. Integration of new legislative policy and service requirements


3. The Director Strategies and Solutions reports to the Director, Taxpayer Services (TS) Operations Support (TSOS).

4. The following teams report to the Director, Strategies and Solutions:



   - Lean Six Sigma Organization (LSSO)

   - Research (RG)


5. The office symbols for Strategies and Solutions are C:DC:TS:O:S.

6. Visit Strategies and Solutions at: Strategies & Solutions


**1.1.13.3.4.1** **(02-26-2020)**

##### Lean Six Sigma Organization (LSSO)

1. **Mission:** To support the IRS Taxpayer Services (TS) strategy of improving service to the taxpayer by leading accelerated process improvement initiatives utilizing the Lean Six Sigma Methodology.

2. To accomplish the mission, the LSSO methodology combines Lean, which focuses on eliminating waste and non-value-added activities, with Six Sigma, which improves process effectiveness and efficiency by reducing variation and increasing quality. LSSO is guided by a structured problem-solving approach called Define-Measure-Analyze-Improve-Control (DMAIC), which does the following:



1. Defines the problem.

2. Targets the underlying causes of the problem.

3. Develops and implements solutions.

4. Establishes controls to ensure the solutions stay in place.


3. The main body of knowledge and resources for LSSO are located and managed within TS. LSSO employs experienced process improvement individuals who are specifically trained and certified in the Lean Six Sigma Methodology and use the Memorandum of Understanding (MOU) as the primarily vehicle for expanding the program to other areas within the IRS.

4. To accomplish its goals and objectives, the LSSO partners with business leadership and process owners through the following activities:



1. Consulting with executives to prioritize strategic initiatives to maximize organizational impact and value.

2. Guiding a cross-functional team of subject matter experts to map the existing process utilizing baseline data and identifying opportunities and risks.

3. Administering a structured approach that targets customer requirements and relies on data to determine solutions to achieve objectives.

4. Executing changes that streamline, enhance flow, reduce errors, and improve overall process performance.

5. Delivering strategies for process consistency and standardization across the enterprise.


5. The LSSO teams report to the Director, Strategies and Solutions.

6. The office symbols for LSS are C:DC:TS:O:S:LSS.

7. Visit LSSO at: Lean Six Sigma Organization.


**1.1.13.3.4.2** **(01-24-2023)**

##### Research and Analysis

1. **Mission:** To inform valued operational change.

2. To accomplish the mission, Research:



1. Obtains research needs from all Taxpayer Services (TS) functional components and provides analytical support to TS decision makers as they develop near- and long-term strategies, plans, and programs to perform functional responsibilities in tax administration.

2. Uses qualitative and quantitative research methodologies to conduct tax administration research that informs valued operational change.

3. Supports initiatives in the TS Operations Plan by providing research that helps inform TS strategic goals and customer business objectives.

4. Uses advanced analytics to identify emerging pre-filing, filing and compliance issues.

5. Conducts qualitative and quantitative behavioral research studies (e.g., focus groups, surveys, usability testing) national in scope.

6. Manages contract administration for non-IT contractor support and survey vehicles.


3. TS Strategies & Solutions (TSSS) projects fall into one of three basic types: Standard, Rapid, and Administration.



1. Standard projects (Planned and Unplanned) typically involve a specific, standalone, research initiative, which includes, but not limited to profiles, surveys, predictive models, and/or experiments. All standard planned research requests should be submitted via the business unit’s annual research plan.

2. Rapid projects (Planned and Unplanned) tend to be issue specific requiring a more concise answer and typically can be completed within 30 days. Includes running data queries and creating maps, spreadsheets, charts, and/or tables. Requests for Rapid Research are submitted through TS's Unplanned Research Request Tool on the TS website.

3. Administration projects are typically other project types where administration is needed for tracking and time keeping. Examples include:


       \-\- Consulting projects are undertaken when TSSS researchers serving as a contributing member to a project team outside of TSSS such as conducting data analysis, evaluating the appropriateness of chosen methods.


       \-\- Infrastructure projects are those created for the betterment of TSSS, such as development and maintenance of the Project Management (PM) system, preparation of in-house training.


4. Six Research groups report to the Director, Strategies and Solutions.

5. The office symbols for the six Research Groups are C:DC:TS:O:S:RG1, C:DC:TS:O:S:RG2, C:DC:TS:O:S:RG3, C:DC:TS:O:S:RG4, C:DC:TS:O:S:RG5 and C:DC:TS:O:S:RG6.

6. Visit Research and Analysis at: Research and Analysis.


**1.1.13.3.5** **(10-13-2021)**

#### Program Management Office (PMO)

1. Mission: To provide Taxpayer Services (TS) business functions with planning and operational documents, monitor performance measures/metrics, coordinate the submission of budget initiatives and develop the TS Operations Plan in support of the IRS strategic goals.

2. To accomplish the mission, Program Management Office (PMO):



1. Tracks plan accomplishments and develops reporting documents on the achievement of objectives based on reviews of organizational performance,

2. Develops and manages the TS operational planning process in support of the IRS strategic planning, budgeting and performance management process.

3. Maintains TS performance data for operational planning and analysis,

4. Supports TS as the liaison to various IRS advisory committees,

5. Serves as the TS liaison to CFO, ultimately serving the Commissioner and the senior management team in Servicewide planning.


3. The Chief, PMO, reports to the Director, Taxpayer Services Operations Support.

4. The office symbols are C:DC:TS:O:PMO.

5. Visit PMO at: Program Management Office.


**1.1.13.4** **(01-24-2023)**

### Return Integrity and Compliance Services (RICS)

1. _About:_ Return Integrity Compliance Services (RICS) is the only enforcement function in Taxpayer Services (TS) and is responsible for protecting public interest by improving the IRS's ability to detect and prevent improper refunds and helping taxpayers understand the refundable tax credits for which they are eligible. RICS continually identifies innovations to improve the taxpayer experience and enhance the effectiveness and efficiencies in compliance programs.

2. **Mission:** To strengthen the integrity of the tax system by:



   - Protecting public interest by improving IRS's ability to detect and prevent improper refunds

   - Serving public interest by taking enforcement actions fairly and appropriately to identify, evaluate and prevent the issuance of improper refunds

   - Helping taxpayers understand the refundable tax credits for which they are eligible


3. To accomplish the mission, RICS:



1. Provides program oversight in refundable credit tax administration and Earned Income Tax Credit (EITC) pre-refund compliance process.

2. Provides leadership and direction in the development, delivery, and deployment of programs in the detection and resolution processes for pre-refund revenue protection such as fraud, identity theft (IDT), and compliance.

3. Develops, tests and perfects innovative, forward-thinking solutions to pre-refund revenue protection challenges as well as operational challenges.

4. Reduces taxpayer burden and broadens the use of electronic interactions with a focus on successful taxpayer outcomes.

5. Partners with the executive staff of other business units to develop strategies, address cross-functional issues, coordinate activities, and ensure consistency of approach.

6. Provides leadership in motivating and developing subordinates and implementing quality, excellence, and affirmative employment, diversity, and ethics programs.

7. Formulates short and long-range program policies, strategies, and objectives for the organization to achieve goals that enhance compliance, customer service, and business results.

8. Provides centralized, executive-level processes in key areas (e.g., oversight reporting structure, data calls, performance metrics, budget functions) to provide a unified view to stakeholders of the organization and its performance.


4. The Director, RICS reports to the Chief, Taxpayer Services (TS).

5. The following functions report to the Director, RICS:



   - Program Coordination and Support (PCS)

   - Return Integrity Verification Program Management (RIVPM)

   - Return Integrity Verification Operations (RIVO)

   - Refundable Credits Examination Operations (RCEO)

   - Refundable Credits Program Management (RCPM)


6. The office symbols for RICS are C:DC:TS:RICS.

7. Visit RICS at: Return Integrity & Compliance Services.


**1.1.13.4.1** **(08-29-2025)**

#### Program Coordination and Support (PCS)

1. **Mission:** To provide administrative and program assistance across Return Integrity and Compliance Services (RICS) components.

2. To accomplish the mission, Program Coordination and Support (PCS):



01. Manages relationships with stakeholders by providing guidance for key administrative data calls that impact the RICS organization.

02. Coordinates RICS Operational Reviews and quarterly Business Performance Reviews.

03. Oversees critical employee engagement items in RICS such as the Lunch and Learn sessions. All Employee emails from the RICS Director and the Monthly Employee Spotlight.

04. Coordinates IT Demand requests.

05. Coordinates RICS budget initiatives.

06. Coordinates operating and training travel.

07. Coordinates Filing Season Readiness.

08. Coordinates the Leadership Succession Review Program.

09. Manages and coordinates training throughout RICS organization.

10. Manages the RICS contracts, budget and hiring activities.

11. Coordinates the RICS IRM updates and publishing.


3. The Program Manager, PCS reports to the Director, RICS.

4. The office symbols for PCS are C:DC:TS:RICS:PCS.


**1.1.13.4.2** **(08-29-2025)**

#### Return Integrity Verification Program Management (RIVPM)

1. **Mission:** Provide policy and program oversight of pre-refund risk associated with identity theft and civil refund fraud. We will do this by:



   - Utilizing data analytics and engaging both employees and stakeholders to consistently monitor for emerging risks.

   - Monitoring programs and detection methods for fairness and taxpayer burden.

   - Collaborating with stakeholders to inform on scams, schemes, and opportunities to protect the American taxpayer and tax community.

   - Developing policies and procedures that consider employee and cross organizational feedback.

   - Providing accurate and timely feedback to operational processes and products that assist employees and taxpayers in resolving outstanding accounts.


2. The Director, Return Integrity Verification Program Management (RIVPM) reports to the Director, Return Integrity and Compliance Services (RICS).

3. The following functions report to the Director, RIVPM:



   - Program Management (PM)

   - Policy and Analysis (P&A)

   - Business Performance Lab (BPL)


4. The office symbols for RIVPM are C:DC:TS:RICS:RIVPM.

5. Visit RIVPM at: Return Integrity Verification Program Management.


**1.1.13.4.2.1** **(02-26-2020)**

##### Program Management (PM)

1. **Mission:** To provide program assistance and engage stakeholders across the Return Integrity Verification Program Management (RIVPM) organization to better understand program needs and offer solutions to bolster mission success.

2. To accomplish the mission, the Program Management (PM) staff:



1. Serves as the single point of contact for customers obtaining reports, performance metrics, and oversight reporting (e.g., Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA) and ad hoc data calls).

2. Provides leadership and support to the Return Integrity Verification Operations (RIVO) in meeting or exceeding measures and goals within budget and work plan allocations.

3. Provides oversight for the Quality program and Data Management, Analysis and Support (DMAS).


3. The Program Manager, PM reports to the Director, RIVPM.

4. The following functions report to the Program Manager, PM:



   - Quality

   - Data Management, Analysis and Support (DMAS)


5. The office symbols for PM are C:DC:TS:RICS:RIVPM:PM.

6. Visit RIVPM Program Management at: RIVPM Program Management.


**1.1.13.4.2.1.1** **(02-26-2020)**

###### Quality

1. **Mission:** To oversee Embedded Quality programs in Return Integrity Verification Operations (RIVO).

2. To accomplish the mission, the Quality staff:



1. Conducts national case reviews on the RIVO programs providing a method to monitor, measure, and improve the quality of work.

2. Uses quality review data to provide quality statistics for RIVO’s Business Results part of the Balanced Measures, and/or to identify trends, problem areas, training needs, and opportunities for process improvement.

3. Collaborates with Policy and Analysis (P&A) to share quality data, address identified trends and discuss process improvement ideas for possible implementation.


3. The Manager, Quality reports to the Program Manager, Program Management.

4. The office symbols for Quality are C:DC:TS:RICS:RIVPM:PM:Q.


**1.1.13.4.2.1.2** **(01-24-2023)**

###### Data Management, Analysis and Support (DMAS)

1. **Mission:** To support all coordination and oversight for high level administration for Return Integrity Verification Program Management (RIVPM) and Return Integrity Verification Operations (RIVO) programs through data-driven analysis.

2. To accomplish the mission, the Data Management, Analysis and Support (DMAS) staff:



1. Provides guidance and coordination for key administrative data calls that impact the RIVPM organization.

2. Provides performance data and analyses on revenue protected/recovered through Business Performance Lab (BPL) and RIVO.

3. Manages financial resources for RIVPM.

4. Monitors the performance results for the programs at the RIVO sites.

5. Develops and monitors RIVO work-plans in conjunction with Policy and Analysis (P&A).


3. The Manager, DMAS reports to the Program Manager, Program Management.

4. The office symbols for DMAS are C:DC:TS:RICS:RIVPM:PM:DMAS.


**1.1.13.4.2.2** **(08-29-2025)**

##### Policy and Analysis (P&A)

1. **Mission:** To develop and communicate policy and procedural guidelines for the programs worked by Return Integrity Verification Operations (RIVO).

2. To accomplish the mission, the Policy and Analysis (P&A) staff:



1. Develops and maintains the IRM part 25.

2. Develops and reviews training material for the RIVO operations.

3. Supports cross-functional headquarters operations within Return Integrity and Compliance Services (RICS).

4. Works jointly with Data Management Analysis and Support (DMAS) to develop the annual RIVO work-plan.

5. Conducts campus site visits and reviews of RIVO’s operations.

6. Cultivates internal and external partnerships, such as with the Bureau of the Fiscal Services (BFS) to establish pilots and work processes that align with IRS objectives.


3. The Program Manager, P&A reports to the Director, Return Integrity, Verification and Program Management (RIVPM).

4. The office symbols for P&A are C:DC:TS:RICS:RIVPM:PA.

5. Visit P&A at: RIVPM Policy & Analysis.


**1.1.13.4.2.3** **(02-26-2020)**

##### Business Performance Lab (BPL)

1. **Mission:** To initiate, recommend, and manage systemic solutions for the detection and treatment of improper refunds, while ensuring effective treatment for payment of valid refund claims.

2. To accomplish the mission, Business Performance Lab (BPL):



1. Leads the development and implementation of innovative business processes and technology solutions.

2. Develops policy and guidance for civil revenue protection initiatives and represents Return Integrity and Compliance Services’ (RICS) interest in support of the Servicewide revenue protection strategy.

3. Provides oversight for Project Analysis and Evaluation (PAE), Project Development and Execution (PDE), Project Analytics and Modeling (PAM), and Program Assessment and Data (PAD) teams.


3. The Program Manager, BPL reports to the Director, Return Integrity, Verification and Program Management (RIVPM).

4. The following functions report to the BPL:



   - Project Analysis and Evaluation (PAE)

   - Project Development and Execution (PDE)

   - Project Analytics and Modeling (PAM)

   - Program Assessment and Data (PAD)


5. The office symbols for BPL are C:DC:TS:RICS:RIVPM:BPL.

6. Visit BPL at: RIVPM Business Performance Lab.


**1.1.13.4.2.3.1** **(10-13-2021)**

###### Project Analysis and Evaluation (PAE)

1. **Mission:** To manage, monitor and report Return Integrity and Compliance Services’ (RICS’) Unified Work Request (UWR) status and processes; Manage and monitor IRS operational use of the Information Sharing and Assistance Center (ISAC); Oversee the prisoner tax compliance strategy, including analyzing and validating prisoner data to ensure integrity of prisoner file data; and Conduct data analysis, evaluation, and validation of Business Performance Lab (BPL) project implementations, which include gap analysis studies, data breaches, and project research while ensuring effective implementation of new initiatives.

2. Major programs and areas of responsibilities include:



   - Annual Prisoner File

   - Annual Report to Congress on Prisoner Compliance

   - ISAC operational documents

   - Monthly and ad hoc UWR Status Reports

   - Prisoner Data Exchange under IRC 6103(k)(10)


3. The Manager, PAE reports to the Program Manager, BPL.

4. The office symbols for PAE are C:DC:TS:RICS:RIVPM:BPL:PAE.

5. Visit PAE at: Project Analysis & Evaluation (PAE).


**1.1.13.4.2.3.2** **(02-26-2020)**

###### Project Development and Execution (PDE)

1. **Mission:** To lead enterprise-wide development, testing and deployment of innovative business process solutions that enhance revenue protection and increase organizational effectiveness and efficiency.

2. To accomplish the mission, Project Development and Execution (PDE):



1. Monitors, analyzes and optimizes new business solutions.

2. Reviews new and proposed legislation for impact to Return Integrity and Compliance Services’ (RICS) business operational performance.

3. Proposes and implements new and innovative solutions for civil revenue protection activities.


3. Major programs and areas of responsibilities include:



   - Expanded revenue protection opportunities

   - New business solutions


4. The Manager, PDE reports to the Program Manager, Business Performance Lab.

5. The office symbols for PDE are C:DC:TS:RICS:RIVPM:BPL:PDE.

6. Visit PDE at: Project Development & Execution (PDE).


**1.1.13.4.2.3.3** **(02-26-2020)**

###### Project Analytics and Modeling (PAM)

1. **Mission:** To perform oversight and management of all Return Integrity and Compliance Services’ (RICS) models, filters, and business rule sets designed to detect refund fraud and non-compliance and to monitor their performance to ensure a cycle of continuous improvement.

2. To accomplish the mission, Project Analytics and Modeling (PAM):



1. Increases revenue protection by applying filters to existing business rules to detect identity theft (IDT) and non-compliant returns in a pre-refund environment while timely providing refunds to compliant taxpayers.

2. Analyzes trends and schemes to determine common characteristics of IDT or non-compliant returns and uses these characteristics to enhance detection filters.

3. Processes the identified cases pre-refund to protect taxpayer accounts from being impacted by IDT and loss of revenue.

4. Manages and develops RICS’ databases for the support of revenue protection and improper payment operation.


3. Major programs and areas of responsibilities include:



   - Annual IDT Filters Package

   - Out of Wallet Taxpayer Authentication website

   - Systemic protection of taxpayer’s accounts


4. The Manager, PAM reports to the Program Manager, Business Performance Lab.

5. The office symbols for PAM are C:DC:TS:RICS:RIVPM:BPL:PAM.

6. Visit PAM at: Project Analytics & Modeling (PAM).


**1.1.13.4.2.3.4** **(02-26-2020)**

###### Program Assessment and Data (PAD)

1. Mission: To conduct and utilize data analysis to support, change, or implement the expansions of identity theft (IDT) and fraud programs initiated as a result of the Security Summit and other IRS initiatives, assess expended lead development and information sharing, while evaluating the effectiveness of IDT programs and related data.

2. To accomplish the mission, Program Assessment and Data (PAD):



1. Supports Return Integrity and Compliance Services’ (RICS) technology presence in the development of requirements for technology solutions such as the Return Review Program (RRP) and other systems to aid revenue protection activities.

2. Provides support to the Security Summit Information Sharing, Financial Services and Authentication Workgroup teams.

3. Establishes and coordinates RICS’ rules or requirements for the return review program.

4. Processes and monitors necessary changes for RICS’ database activities.


3. Major programs and areas of responsibilities include:



   - Database Change Requests and Sprints

   - RRP Rules and Requirements

   - Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO) responses


4. The Manager, PAD reports to the Program Manager, Business Performance Lab.

5. The office symbols for PAD are C:DC:TS:RICS:RIVPM:BPL:PAD.

6. Visit PAD at: Program Assessment & Data (PAD).


**1.1.13.4.3** **(08-29-2025)**

#### Return Integrity Verification Operations (RIVO)

1. **Mission:** To support IRS’ civil fraud detection and prevention efforts in a pre-refund environment.

2. To accomplish the mission, Return Integrity Verification Operations (RIVO):



1. Provides key support to Return Integrity and Compliance Services (RICS) and our customers as a single point for obtaining reports, performance metrics, oversight reporting (e.g., Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA), data calls for training and budget reporting.

2. Develops, tests, and perfects innovative, forward-thinking solutions to pre-refund revenue protection challenges as well as RICS’ operational challenges.

3. Stops fraudulent refunds, detects, evaluates and prevents improper refunds while ensuring actions are correct and fair.


3. The Director, RIVO reports to the Director, RICS.

4. The following functions report to the Director, RIVO:



   - Planning and Analysis (P&A)

   - Return Integrity Verification Operations (RIVO) #1

   - Return Integrity Verification Operations (RIVO) #2


5. The office symbols for RIVO are C:DC:TS:RICS:RIVO.

6. Visit RIVO at: Return Integrity Verification Operations..


**1.1.13.4.3.1** **(08-29-2025)**

##### Planning and Analysis (P&A)

1. **Mission:** To provide optimal service to Return Integrity and Compliance Services’ (RICS) customers by best matching resources to meet customer demand.

2. To accomplish the mission, Planning and Analysis (P&A):



01. Oversees all non-labor contract agreements.

02. Directs budget management and initiatives.

03. Oversees performance measures.

04. Monitors the status of strategic and business planning.

05. Serves as single point of contact for customers obtaining reports and performance metrics.

06. Serves as primary contact for oversight reporting (e.g., Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA) and ad hoc data calls).

07. Monitors overall inventory at the major program level, including the distribution of workload.

08. Develops streamlined and time-saving improvements to processes for stakeholders that add value to the overall organization.

09. Formulates and coordinates space, furniture and Information Technology (IT) equipment initiatives.

10. Manages and coordinates training throughout the Return Integrity Verification Operations (RIVO) organization.

11. Coordinates RICS Operational Reviews and quarterly Business Performance Reviews (BPR).

12. Coordinates with key stakeholders to develop RICS IRWeb and SharePoint sites.

13. Coordinates the Employee Suggestion Program (ESP) throughout the RIVO organization.

14. Oversees critical employee engagement items in RIVO such as the Lunch & Learn sessions and Town Hall sessions.

15. Coordinates the Leadership Succession Review (LSR) Program for RIVO.

16. Oversees embedded quality for Return Integrity and Verification Operations (RIVO).

17. Reviews and coordinates all HR Connect and personnel action requests (PAR) actions for timeliness within RIVO, as well as other systems oversight such as Integrated Data Retrieval System (IDRS) coordination.

18. Performs filing season readiness activities related to staffing to meet workload needs.

19. Identifies issues through monitoring staffing delivery and alerts the proper organization for in-depth analysis and recommendations.

20. Monitors resources and develop recommendations on seasonal hiring and release/recall for the inventory programs.

21. Manages relationships with key stakeholders by providing guidance for key administrative data calls that impact the RICS organization.


3. The Program Manager, P&A reports to the Director, RIVO.

4. The office symbols for P&A are C:DC:TS:RICS:RIVO:PA.


**1.1.13.4.3.2** **(08-29-2025)**

##### Return Integrity Verification Operations (RIVO) 1

1. **Mission:** To protect revenue by identifying and dispositioning returns which display evidence of patterns of fraud including identity theft (IDT).

2. To accomplish the mission, the Return Integrity Verification Operations (RIVO) 1 staff:



1. Provides timely customer service by ensuring accounts are properly resolved and documented to reflect IRS findings on returns with identified issues.

2. Processes information from financial institutions to recover fraudulent and/or IDT returns and associated refunds.


3. The following functions report to the Program Manager, RIVO 1:



   - Department 1 Fraud and Referral Evaluation

   - Department 2 Accounts Resolution

   - Department 3 Non-Identity Theft Account Resolution & External Leads


4. The Program Manager, RIVO 1 reports to the Director, Return Integrity Verification Operations (RIVO).

5. The office symbols for RIVO 1 are C:DC:TS:RICS:RIVO:RIVO1.


**1.1.13.4.3.2.1** **(08-29-2025)**

###### Department 1 Fraud and Referral Evaluation

1. **Mission:** To protect revenue by identifying and dispositioning returns which display evidence of patterns of fraud including identity theft (IDT).

2. To accomplish the mission, the Fraud and Referral Evaluation (FRE) staff:



1. Identifies and take actions on return inventory that may be associated with patterns of fraud and IDT as required to protect revenue, taxpayers, and the integrity of the tax system.

2. Receives, researches and processes information leads submitted from a variety of sources, i.e., industry leads, internal referrals.

3. Supports the operation by providing analytical support for inventory processes and reporting.


3. The Department Manager, Department 1 Fraud and Referral Evaluation reports to the Program Manager, Return Integrity Verification Operations (RIVO) 1.

4. The office symbols for Department 1 Fraud and Referral Evaluation are C:DC:TS:RICS:RIVO:RIVO1:FRE.


**1.1.13.4.3.2.2** **(08-29-2025)**

###### Department 2 Accounts Resolution

1. **Mission:**To provide timely customer service by ensuring that accounts are properly resolved and documented to reflect IRS findings on returns with identified issues.

2. To accomplish the mission, the Accounts Resolution Department reviews and adjusts accounts when:



1. Other pre-refund treatment streams for identified false returns are not available.

2. Legitimate taxpayers may be victims of identity theft (IDT).

3. Taxpayers are unduly impacted by revenue protection processes and require assistance through Taxpayer Assistance Service (TAS).


3. The Department Manager, Department 2 Accounts Resolution reports to the Program Manager, Return Integrity Verification Operations (RIVO) 1.

4. The office symbols for the Accounts Resolution Department are C:DC:TS:RICS:RIVO:RIVO1:AR.


**1.1.13.4.3.2.3** **(08-29-2025)**

###### Department 3 Non-Identity Theft Account Resolution & External Leads Department

1. **Mission:** To process information from institutions to recover fraudulent and/or identity theft (IDT) returns and associated refunds.

2. To accomplish the mission, the Non-Identity Theft Account Resolution & External Leads Department:



1. Receives, researches, and processes information leads submitted from financial institutions, prisons, Office of Child Support and Enforcement, and other external stakeholders where funds are available for return to the IRS.

2. Reviews inventory associated with these leads to identify fraudulent and/or IDT characteristics.

3. Updates Electronic Fraud Detection System (EFDS) and Integrated Data Retrieval System (IDRS).


3. The Department Manager, Non-Identity Theft Account Resolution & External Leads reports to the Program Manager, Return Integrity Verification Operations (RIVO) 1.

4. The office symbols for the Non-Identity Theft Account Resolution & External Leads Department are C:DC:TS:RICS:RIVO:RIVO1:EL.


**1.1.13.4.3.3** **(08-29-2025)**

##### Return Integrity Verification Operations (RIVO) 2

1. **Mission:** To protect revenue by identifying potentially false returns and verifying as-reported wage and withholding accuracy.

2. To accomplish the mission, the Return Integrity Verification Operations (RIVO) 2 staff:



1. Screens individual refund tax returns identified as potentially false.

2. Provides timely customer service by ensuring accounts are properly resolved and documented to reflect IRS findings on returns with identified issues.


3. The following functions report to the Program Manager, RIVO 2:



   - Business Masterfile Identity Theft & Frivolous Return Program

   - Department 2 Accounts Resolution Automated Questionable Credits

   - Department 3 Accounts Resolution Automated Questionable Credits & Withholding Only Work


4. The Program Manager, RIVO 2 reports to the Deputy Director, Return Integrity Verification Operations (RIVO).

5. The office symbols for RIVO2 are C:DC:TS:RICS:RIVO:RIVO2.


**1.1.13.4.3.3.1** **(08-29-2025)**

###### Department 1 Business Masterfile Identity Theft & Frivolous Return Program

1. **Mission:** To protect revenue by identifying potentially false returns and verifying as-reported wage and withholding accuracy.

2. To accomplish the mission, the Business Masterfile Identity Theft & Frivolous Return Program:



1. Screens individual refund tax returns identified as potentially false.

2. Verifies suspicious wage and withholding information reported on individual returns through third party contacts via phone or fax, disc verification and Integrated Data Retrieval System (IDRS), to prevent the release of potentially false refunds.


3. The Department Manager, Business Masterfile Identity Theft & Frivolous Return Program reports to the Program Manager, Return Integrity Verification Operations (RIVO) 2.

4. The office symbols for the Business Masterfile Identity Theft & Frivolous Return Program are C:DC:TS:RICS:RIVO:RIVO2:RSV.


**1.1.13.4.3.3.2** **(08-29-2025)**

###### Department 2 Accounts Resolution Automated Questionable Credits

1. **Mission:** To provide timely customer service by ensuring that accounts are properly resolved and documented to reflect IRS findings on returns with identified issues.

2. To accomplish the mission, Accounts Resolution Automated Questionable Credits reviews and adjusts accounts when:



1. Other pre-refund treatment streams for identified false returns are not available.

2. Legitimate taxpayers may be victims of identity theft.

3. Taxpayers are unduly impacted by revenue protection processes and require assistance through the Taxpayer Advocate Service (TAS).


3. The Department Manager, Accounts Resolution Automated Questionable Credits reports to the Program Manager, Return Integrity Verification Operations (RIVO) 2.

4. The office symbols for the Accounts Resolution Automated Questionable Credits are C:DC:TS:RICS:RIVO:RIVO2:AR2.


**1.1.13.4.3.3.3** **(08-29-2025)**

###### Department 3 Accounts Resolution Automated Questionable Credits & Withholding Only Work

1. **Mission:** To provide timely customer service by ensuring that accounts are properly resolved and documented to reflect IRS findings on returns with identified issues.

2. To accomplish the mission, Accounts Resolution Department 3:



1. Reviews and adjusts accounts when other pre-refund treatment streams for identified false returns are not available, legitimate taxpayers may be victims of identity theft (IDT), and taxpayers are unduly impacted by revenue protection processes and require assistance through the Taxpayer Advocate Service (TAS).

2. Supports IRS strategy to protect revenue and stop fraud and abuse through frivolous return filing. The Frivolous Return Program (FRP) provides for assessment of penalties to encourage compliance.


3. The Department Manager, Accounts Resolution 3 reports to the Program Manager, Return Integrity Verification Operations (RIVO) 2.

4. The office symbols for the Accounts Resolution Department 3 are C:DC:TS:RICS:RIVO:RIVO2:AR3.


**1.1.13.4.4** **(01-24-2023)**

#### Refundable Credits Examination Operations (RCEO)

1. **About:** Refundable Credits Examination Operations (RCEO) oversees the daily pre-refund examination campus operations. Examination initiates correspondence audits with taxpayers to maintain a compliance presence and encourage correct reporting of income, deductions, and refundable tax credits on tax returns. The RCEO communicates with taxpayers and tax preparers to provide guidance on tax law and the audit process.

2. **Mission:** To fairly and effectively assist our customers by providing accurate and consistent information to help them understand the refundable tax credits for which they are eligible. We will strengthen the integrity of the tax system and protect the public interest by detecting and preventing improper refunds and educating our customers in accordance with the Taxpayer Bill of Rights.

3. To accomplish the mission, RCEO conducts pre-refund examination activities and all pre- and post-refund Earned Income Tax Credit (EITC) compliance activities of individual tax returns via correspondence. The majority of the examinations conducted by RCEO deal with the Earned Income Tax Credit and related issues. Other refundable credits are also examined, usually prior to the issuance of the refund.

4. The Director, RCEO reports to the Director, Return Integrity and Compliance Services (RICS).

5. The following functions report to the Director, RCEO:



   - Planning and Analysis (P&A)

   - Examination Operations - Andover

   - Examination Operations - Atlanta

   - Examination Operations - Austin

   - Examination Operations - Fresno

   - Examination Operations - Kansas City


6. The office symbols for RCEO are C:DC:TS:RICS:RCEO.

7. Visit RCEO at: Refundable Credits Examination Operations.


**1.1.13.4.4.1** **(08-29-2025)**

##### Planning and Analysis (P&A)

1. **Mission:**To provide optimal service to Return Integrity and Compliance Services’ (RICS) customers by best matching resources to meet customer demand.

2. To accomplish the mission, Planning and Analysis (P&A):



01. Oversees all non-labor contract agreements.

02. Directs budget management and initiatives.

03. Oversees performance measures.

04. Monitors the status of strategic and business planning.

05. Serves as single point of contact for customers obtaining reports and performance metrics.

06. Serves as primary contact for oversight reporting (e.g., Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA) and ad hoc data calls).

07. Monitors overall inventory at the major program level, including the distribution of workload.

08. Develops streamlined and time-saving improvements to processes for stakeholders that add value to the overall organization.

09. Formulates and coordinates space, furniture and Information Technology (IT) equipment initiatives.

10. Manages and coordinates training throughout the Refundable Credits Examinations Operation (RCEO).

11. Coordinates RICS Operational Reviews and quarterly Business Performance Reviews (BPR).

12. Coordinates with key stakeholders to develop RICS IRWeb and SharePoint sites.

13. Oversees critical employee engagement items in RCEO such as the Lunch & Learn sessions and Town Hall sessions.

14. Coordinates the Leadership Succession Review (LSR) Program for RCEO.

15. Oversees embedded quality for Refundable Credits Examinations Operation (RCEO).

16. Reviews and coordinates all HR Connect and personnel action requests (PAR) actions for timeliness within RCEO, as well as other systems oversight such as Integrated Data Retrieval System (IDRS) coordination.

17. Performs filing season readiness activities related to staffing to meet workload needs.

18. Identifies issues through monitoring staffing delivery and alerts the proper organization for in-depth analysis and recommendations.

19. Monitors resources and develop recommendations on seasonal hiring and release/recall for the inventory programs.

20. Manages relationships with key stakeholders by providing guidance for key administrative data calls that impact the RICS organization.


3. The Program Manager, P&A reports to the Director, RCEO.

4. The office symbols for P&A are C:DC:TS:RICS:RCEO:PA.


**1.1.13.4.5** **(08-29-2025)**

#### Refundable Credits Program Management (RCPM)

1. **Mission:** To communicate policy, procedures, and guidance on the Earned Income Tax Credit (EITC) and all individual pre-refund credits and programs worked by the Refundable Credits Examination Operations (RCEO) functions.

2. To accomplish the mission, Refundable Credits Program Management (RCPM):



1. Provides oversight and monitors the performance of examination operations.

2. Acts as the liaison between the RCEO campuses and other headquarters functions.

3. Manages the administration of refundable credits through a balanced approach that encourages eligible taxpayers to apply for the credits and reduces the number of claims paid in error.

4. Plays a central role in coordinating Servicewide policy, outreach and enforcement activities for refundable credits.

5. Develops the compliance strategy for refundable credits and ensures the proper execution of the strategy.


3. The Director, RCPM reports to the Director, Return Integrity and Compliance Services (RICS).

4. The following functions report to the Director, RCPM:



   - Program Management (PM)

   - Refundable Credits Administration (RCA)

   - Examination Policy and Coordination (EPC)

   - Credits and Deductions Administration (CDA)


5. The office symbols for RCPM are C:DC:TS:RICS:RCPM.

6. Visit RCPM at: Refundable Credits Program Management.


**1.1.13.4.5.1** **(01-24-2023)**

##### Program Management (PM)

1. **Mission:** To monitor the Examination program performance results for the Refundable Credits Examination Operations (RCEO) campuses; provide leadership and support to the RCEO campuses in meeting or exceeding Return Integrity and Compliance Services (RICS) measures and goals within budget and work plan allocations; play a central role in the development of all digitalization and modernization efforts through coordination and oversight while working with the RCEO functions to plan and stand-up initiatives; respond to data requests in a timely and accurate manner; analyze and coordinate National Quality Review System (NQRS) and Embedded Quality Review System (EQRS) data with the program groups; and manage financial resources for Refundable Credits Program Management (RCPM).

2. To accomplish the mission, the Program Management (PM) staff:



01. Leads and manages the development of goals and measures including Balanced Measures for the Examination programs and the integration into the Examination work plan.

02. Prepares reports and conducts comprehensive data analysis to ensure goals and measures are on target.

03. Provides oversight and direction for critical outcome measures included as Performance targets.

04. Prepares Examination closure projections for the Director, RICS.

05. Identifies issues based on reviews of organization performances and provides assistance to program areas to resolve issues.

06. Provides data for internal and external customers on Taxpayer Services (TS) performance.

07. Provides data and assistance for RCPM site reviews.

08. Coordinates with Examination Policy and Coordination (EPC) and Refundable Credits Administration (RCA) to develop budget initiatives, consolidates Taxpayer Advocate Service (TAS) Most Serious Problem responses, responds to Government Accountability Office (GAO) Treasury Inspector General for Tax Administration (TIGTA) audits and develops the operating plan.

09. Provides data on strategic plan results and strategy modification needs.

10. Coordinates large projects and efforts such as RCEO inventory Digitization Efforts, RCEO/RCPM Corporate Inventory Initiatives, and RCEO Enterprise Case Management (ECM) on behalf of RCPM and RCEO Directors.

11. Ensures operating units implement policy aligned with the Examination work plan.

12. Analyzes site progress against strategic plans and identifies opportunities for improvement.

13. Coordinates with program areas within RICS.

14. Tracks resources to ensure adherence to the work plan and schedule.

15. Provides oversight, coordination, and direction to develop the Examination work plan (resources, closures, and starts work plan).

16. Analyzes and monitors the campus progress against the closure and starts work plan to identify opportunities for improvement.

17. Coordinates, prepares and maintains EPC operating guidelines for the RCEO campuses.

18. Plans and executes the RCPM budget.


3. The Program Manager for PM reports to the Director, RCPM.

4. The office symbols for Program Management are C:DC:TS:RICS:RCPM:PM.

5. Visit PM at: RCPM Program Management (PM).


**1.1.13.4.5.2** **(02-26-2020)**

##### Refundable Credits Administration (RCA)

1. **Mission:** To manage the administration of refundable credits through a balanced approach that encourages eligible taxpayers to apply for the credits and reduces the number of claims paid in error.

2. To accomplish the mission, the Refundable Credits Administration (RCA) staff:



1. Plays a central role in coordinating Servicewide policy, outreach and enforcement activities.

2. Provides oversight for the Stakeholder Engagement, Policy and Coordination, and Return Preparer Support teams within Refundable Credit Program Management (RCPM).


3. The Program Manager, RCA reports to the Director, RCPM.

4. The following functions report to the Program Manager, RCA:



   - Stakeholder Engagement

   - Policy and Coordination

   - Return Preparer Support


5. The office symbols for RCA are C:DC:TS:RICS:RCPM:RCA.

6. Visit RCA at: Refundable Credits Administration (RCA).


**1.1.13.4.5.2.1** **(01-24-2023)**

###### Stakeholder Engagement (SE)

1. **Mission:** To provide a strategic approach to Earned Income Tax Credit (EITC) and refundable credits outreach and education and coordinate research for the Refundable Credit Program Management (RCPM) organization.

2. To accomplish the mission, the Stakeholder Engagement (SE) staff:



1. Develops and monitors national outreach and education strategies for EITC and other refundable credits to reach taxpayers, tax preparers, and partners.

2. Coordinates leveraged outreach for EITC and other refundable credits, working with internal IRS communication functions including Taxpayer Services (TS) Communications and Liaison (C&L), National C&L, Stakeholder Partnerships, Education and Communication (SPEC), Small Business/Self-Employed (SB/SE) C&L, and limited external partners.

3. Creates communication products and tools for use by internal and external stakeholders.

4. Coordinates RCPM research activities to enable data driven decisions in support of strategic goals.


3. The Manager, SE reports to the Program Manager, Refundable Credits Administration (RCA).

4. The office symbols for SE are C:DC:TS:RICS:RCPM:RCA:SE.


**1.1.13.4.5.2.2** **(02-26-2020)**

###### Policy and Coordination (PC)

1. **Mission:** To coordinate with other IRS functions who deliver Earned Income Tax Credit (EITC) and refundable credits programs, as well as, with outside stakeholders, to develop, execute, monitor, and enhance compliance and outreach programs in support of Refundable Credits Administration’s (RCA's) strategic goals of increasing participation and reducing erroneous claims.

2. To accomplish the mission, Policy and Coordination (PC):



1. Develops and coordinates delivery of the Refundable Credits Return Preparer Strategy designed to strengthen preparer adherence to return preparer due diligence requirements through compliance treatments and outreach and education activities.

2. Ensures all preparer activities support and are consistent with Servicewide preparer strategies.

3. Conducts periodic reviews of correspondence products and content modules to evaluate consistency, effectiveness and quality.

4. Supports IRS efforts to meet the requirements for documenting, testing, and reporting effective estimation and remediation of improper payments (IPs) in accordance with the Office of Management and Budget (OMB) Circular A-123, Appendix C, Requirements for Payment Integrity Improvement, dated March 5, 2021, and with the Do Not Pay (DNP) initiatives of the Improper Payments Information Act of 2002, Executive Order 13520, and the Improper Payments Elimination and Recovery Acts of 2010 and 2012.


3. The Manager, PC reports to the Program Manager, RCA.

4. The office symbols for PC are C:DC:TS:RICS:RCPM:RCA:PC.


**1.1.13.4.5.2.3** **(01-24-2023)**

###### Return Preparer Support (RPS)

1. **Mission:** To conduct education and compliance activities in support of the Refundable Credits Return Preparer Strategy including educational phone calls, correspondence due diligence audits, building injunction cases, and assessing and monitoring penalty cases.

2. The Manager, Return Preparer Support (RPS) reports to the Program Manager, Refundable Credits Administration (RCA).

3. The office symbols for RPS are C:DC:TS:RICS:RCPM:RCA:RPS.


**1.1.13.4.5.3** **(01-24-2023)**

##### Examination Policy and Coordination (EPC)

1. _Mission:_ To conduct analysis and research of taxpayer compliance in order to develop risk-based strategies for selection of examinations, develop treatments designed specifically for taxpayer segments within Taxpayer Services (TS), and provide oversight for Earned Income Tax Credit (EITC) and Non-EITC audit programs.

2. To accomplish the mission, the Examination Policy and Coordination (EPC) staff:



1. Plays a central role in coordinating Examination policy and procedures of enforcement activities for Refundable Credits Examination Operations (RCEO).

2. Conducts operational reviews of each RCEO campus site to identify opportunities to improve overall effectiveness of an operation. Reviews are conducted every two years on a rotational basis, unless fewer reviews are warranted, due to restrictive travel conditions.


3. The Program Manager, EPC reports to the Director, Refundable Credits Program Management (RCPM).

4. The following teams report to the Program Manager, EPC:



   - Examination Earned Income Tax Credit (EE)

   - Examination Non-EITC (EN)


5. The office symbols for EPC are C:DC:TS:RICS:RCPM:EPC.

6. Visit EPC at: Exam Policy & Coordination (EPC).


**1.1.13.4.5.3.1** **(01-24-2023)**

###### Examination Earned Income Tax Credit (EE)

1. **Mission:** To conduct analysis and research of taxpayer compliance in order to develop risk-based strategies for selection of Earned Income Tax Credit (EITC) examinations and treatments, develop treatments designed specifically for EITC taxpayer segments within Taxpayer Services (TS), and support the operations at the Refundable Credits Examination Operations (RCEO) campuses by preparing and updating the IRM and providing training and ongoing clarification to EITC policy and procedure.

2. To accomplish the mission, the Examination Earned Income Tax Credit (EE) staff performs the following activities for all EITC selected case work:



01. Oversees the development of short- and long-range program policies, strategies and objectives for overall compliance strategy for the RCEO campuses.

02. Identifies non-compliant taxpayer segments and develops and tests alternative treatments and measures.

03. Performs operational reviews on assigned programs to ensure consistency and accuracy within the RCEO campuses. An operational review is an in-depth review and analysis of a particular program or function or organizational component.

04. Coordinates the strategic planning and research for all examination activities and provides significant input to the TS Strategic Plan.

05. Designs and develops research projects and/or complete analyses to solve complex examination issues and identifies trends to understand and address taxpayer needs and behavior patterns related to the overall TS strategic policies and procedures.

06. Develops comprehensive policy guidance and procedures to implement risk-based treatments of specific EITC taxpayer groups within TS .

07. Prepares projections and forecasts for Director, Refundable Credits Program Management (RCPM).

08. Communicates policy, procedures and guidance to the RCEO campuses on the examination programs.

09. Oversees the integration and writing of policies and procedures in a single simplified IRM, with annual reviews and updates through the clearance process, as revisions are needed.

10. Evaluates the impact of legislative changes on examination programs and provides clarification to the RCEO campuses via IRM Procedural Updates.

11. Coordinates with the Learning and Education (L&E) organization and the RCEO campuses to identify training needs and coordinates/develops training packages.

12. Determines examination business requirements necessary for systems.

13. Works with the RCEO campuses to determine examination programming requirements and provides coordination by communicating the requirements to Information Technology (IT) and all changes to the RCEO campuses.

14. Coordinates with Operations outside Return Integrity and Compliance Services (RICS), such as Criminal Investigation (CI) and Small Business/Self-Employed (SB/SE) to obtain suitable work to provide improved coverage.

15. Reviews the work schedules for all TS EITC programs.


3. The Manager, EE reports to the Program Manager, Examination Policy and Coordination (EPC).

4. The office symbols for EE are C:DC:TS:RICS:RCPM:EPC:EE.


**1.1.13.4.5.3.2** **(01-24-2023)**

###### Examination Non-Earned Income Tax Credit (EN)

1. **Mission:**To conduct analysis and research of Taxpayer Services (TS) taxpayer compliance in order to develop strategies for selection of refundable credit examination cases and risk-based treatments other than Earned Income Tax Credit (EITC) selections; develop treatments designed to fit the needs of specific taxpayer segments within TS; and support the operations at the Refundable Credits Examination Operations (RCEO) campuses by preparing and updating the IRM and providing training and ongoing clarification to policy and procedure.

2. To accomplish the mission, the Examination Non-Earned Income Tax Credit (EN) staff performs the following activities for all individual refundable credits other than EITC case work:



01. Oversees the development of short- and long-range program policies, strategies and objectives for the overall RCEO compliance strategy.

02. Identifies non-compliant taxpayer segments and develops and tests alternative treatments and measures.

03. Performs operational reviews on assigned programs to ensure consistency and accuracy within the RCEO campuses. An operational review is an in-depth review and analysis of a particular program, function or organizational component.

04. Coordinates the strategic planning and research for all examination activities and provides significant input to the TS Strategic Plan.

05. Designs and develops research programs or complete analyses to solve complex examination issues; identifies trends to understand and address taxpayer needs and behavior patterns related to the overall TS strategic policies and procedures.

06. Develops comprehensive policy guidance and procedures to implement risk-based treatments of specific taxpayer groups within the TS Division.

07. Prepares projections and forecasts for the Director, Refundable Credits Program Management (RCPM).

08. Communicates policy, procedures and guidance on the examination programs to the RCEO campuses.

09. Oversees the integration and writing of policies and procedures in a single simplified IRM.

10. Prepares updates and revises procedures and requirements.

11. Evaluates the impact of legislative changes on examination programs and provides clarification to the RCEO campuses via IRM Procedural Updates (IPUs).

12. Communicates new or revised policies and their impact to the RCEO campuses.

13. Coordinates with Learning and Education (L&E) and the RCEO campuses to identify examination training needs and coordinates/develops training packages.

14. Determines examination business requirements necessary for systems.

15. Works with the RCEO campuses to determine examination programming and equipment requirements and provides coordination by communicating the requirements to Information Technology (IT) and all changes to the RCEO campuses.

16. Coordinates with operations outside of Return Integrity and Compliance Services (RICS), such as Criminal Investigation (CI) and Small Business/Self Employed (SB/SE), to obtain suitable work to provide improved coverage.


3. The Manager, EN reports to the Program Manager, Examination Policy and Coordination (EPC).

4. The office symbols for EN are C:DC:TS:RICS:RCPM:EPC:EN.


**1.1.13.4.5.4** **(08-29-2025)**

##### Credits and Deductions Administration (CDA)

1. **Mission:**To guide taxpayers to understand and correctly claim credits and deductions to which they are entitled.

2. To accomplish the mission, the Credits and Deductions Administration (CDA) staff:



1. Supports Servicewide outreach activities.

2. Provides oversight for the Policy and Administration, and Program Development teams within Refundable Credit Program Management (RCPM).


3. The Program Manager, CDA reports to the Director, RCPM.

4. The following functions report to the Program Manager, CDA:



   - Policy and Administration

   - Program Development


5. The office symbols for CDA are C:DC:TS:RICS:RCPM:CDA.


**1.1.13.5** **(01-24-2023)**

### Customer Assistance, Relationships and Education (CARE)

1. _About:_ Customer Assistance, Relationships and Education (CARE) enhances the taxpayer experience by providing tax forms and publications and by leveraging partnerships with stakeholders to assist with return preparation and outreach events to educate them about refundable credits. CARE also offers virtual and face-to-face services to support Compliance activities.

2. **Mission:** To support taxpayers in fulfilling their tax responsibilities CARE will build and maintain partnerships with key stakeholders to inform, educate and communicate with taxpayers; improve tax forms, instructions, publications and notices tailored to the taxpayer, provide face-to-face and virtual assistance to taxpayers; and support Compliance activities.

3. To accomplish the Mission, CARE:



01. Provides face-to-face and virtual assistance to taxpayers.

02. Supports Compliance examination and collection activities.

03. Develops programs by partnering with stakeholders.


        \- Ensures taxpayers have access to education on their rights and responsibilities.


        \- Ensures taxpayers have the most current tax information and tax forms to facilitate return preparation and compliance.

04. Plans, designs, develops, manages and evaluates policies, systems, procedures and standards for all publishing products and services for taxpayers and internal customers.

05. Plans and manages the execution of the CARE financial plan.

06. Plans and manages the requests for IT Funding for IT related projects, including software, hardware and annual maintenance.

07. Provides guidance to and support of all CARE function’s Program Management staff and employees.


        \- Coordinates the integration of standardized policy throughout CARE.


        \- Communicates business goals, strategies, and organizational policies.


        \- Provides guidance and support regarding human capital initiatives, span-of-control, and Requests for Organizational Change.


        \- Participates in equal employment and diversity program activities.

08. Provides support for employee training by establishing proper training plans and ensuring mandatory training is completed.

09. Ensures business requirements are completed to support CARE’s Filing Season Readiness.

10. Manages the legislative process, including developing implementation plans for tax legislation, monitoring action plans to completion, and responding to congressional inquiries.

11. Develops measures to manage and track customer satisfaction, employee satisfaction and business results.

12. Coordinates and monitor new and enhanced project activities for CARE by partnering with TS Operations Support (TSOS).


4. _Customer Experience:_ CARE uses the following customer satisfaction instruments to measure the level of overall satisfaction with the services provided by Field Assistance (FA), Media and Publications (M&P), and Stakeholders, Partnerships, Education & Communication (SPEC):



1. FA Customer Satisfaction (Comment Card): Measures overall taxpayer satisfaction with the services provided by FA’s personnel as determined by the customer satisfaction survey. Taxpayers rate the services provided in Taxpayer Assistance Centers (TACs) on a scale from 1 – 5. The Pacific Consulting Group (PCG), an outside vendor, compiles the survey data monthly, conducts analyses, and prepares quarterly reports.

2. Business Taxpayer Survey, Forms Distribution Survey, Individual Taxpayer Survey, and Tax Return Preparer Survey: Each independently measures the satisfaction of external customers with the products and services provided by M&P.

3. Annual Partner Satisfaction Survey: Provides overall satisfaction rating with SPEC products and services.


5. The CARE director reports to the Chief, Taxpayer Services.

6. The following directors and chief report to the CARE director:



   - Chief, Planning & Analysis

   - Director, Field Assistance

   - Director, Media and Publications

   - Director, Stakeholder Partnerships, Education and Communication


7. The office symbols are C:DC:TS:CAR.

8. Visit CARE at: Customer Assistance, Relationships and Education.


**1.1.13.5.1** **(08-29-2025)**

#### Media and Publications (M&P)

1. **Mission:** The mission of Media & Publications (M&P) is to meet customer needs by producing external and internal forms, publications and notices that facilitate federal and state tax administration and ease of compliance by taxpayers in the most commonly encountered languages, and to work with Servicewide partners and stakeholders to publish and distribute the highest quality products and services.

2. To accomplish the mission, M&P:



1. Integrates the activities of Publishing, Distribution and Tax Forms and Publications to ensure a cohesive approach to the design, publishing and delivery of notices, forms and publications.

2. Obtains customer research-based data from Taxpayer Services (TS) Strategies and Solutions as well as customer, employee and business results to improve products which assist taxpayers in pre-filing, filing and post-filing.


3. The Director, M&P reports to the Director, Customer Assistance, Relationships and Education.

4. M&P consists of the following functions:



   - M&P Planning and Analysis

   - Tax Forms and Publications

   - Publishing

   - Distribution


5. The office symbols for M&P are C:DC:TS:CAR:MP.

6. Visit M&P at: Media and Publications.


**1.1.13.5.1.1** **(08-29-2025)**

##### Media and Publications (M&P) Planning and Analysis (P&A)

1. **Mission:**The mission of Media and Publications (M&P) Planning and Analysis (P&A) is to provide analytical, oversight, and advocacy support to the Director, M&P by overseeing the implementation and integration of resources, policy and planning activities.

2. To accomplish the mission, M&P P&A:



1. Provides technical and administrative support to M&P’s executives, managers and employees as it pertains to strategic planning and budgeting.

2. Provides guidance and liaison activities with Customer Assistance, Relationships and Education (CARE) and subordinate M&P functional offices.


3. Major programs and areas of responsibilities include:



   - Human Resources (i.e., Hiring Exceptions, Requests for Organizational Changes (ROC))

   - External Customer Satisfaction

   - Budget - Printing, postage, labor, and stewardship contracts

   - Contract Office Representative (COR) Contract Reviews (High and Low Dollar)

   - Business Performance Reviews Strategic Planning/Operational Reviews

   - Balanced Measures

   - M&P IRM and Internal Management Document (IMD) Reviews

   - Government Accountability Office (GAO)/Treasury Inspector General for Tax Administration (TIGTA)

   - Taxpayer Advocate Service (TAS)/National Taxpayer Advocate (NTA) Most Serious Problems

   - Risk Coordination

   - Employee/Leadership Training

   - Work Planning and Control (WP&C)


4. The Chief, M&P Planning and Analysis reports to the Director, M&P.

5. M&P P&A consists of the following teams:



   - Planning and Resources

   - Program Analysis and Reporting


6. The office symbols for M&P P&A are C:DC:TS:CAR:MP:PA.


**1.1.13.5.1.2** **(08-29-2025)**

##### Tax Forms and Publications (TF&P)

1. **Mission:** The mission of Tax Forms and Publications (TF&P) is to help taxpayers comply with their tax obligations and secure their tax benefits by timely making available forms, instructions, publications, and other tax products that are responsive to their needs, technically accurate, understandable, easy to access and use, available in the most commonly encountered languages.

2. To accomplish the mission, TF&P:



1. Creates and improves tax forms, instructions, publications and other documents to help taxpayers understand and meet their tax responsibilities.

2. Ensures the IRS complies with the Paperwork Reduction Act, by clearing all IRS material that collects information from taxpayers or requires record keeping, including forms, surveys and regulations.

3. Serves as the focal point for the operations of the Tax Products Committee.

4. Supports IRS efforts to develop and administer service wide policies, strategies and initiatives to assist Limited English Proficiency (LEP) taxpayers in meeting their tax responsibilities.

5. Solicits comments from internal and external customers to improve tax product accuracy, ease of use, and customer satisfaction.

6. In conjunction with Media and Publications (M&P), conducts Customer Satisfaction Surveys to identify ways in which products and services can be improved.


3. The Director, TF&P reports to the Director Media and Publications.

4. The following functions report to the Director, TF&P.



   - Individual and Specialty Forms and Publications

   - Business, Exempt Organizations and International Forms and Publications

   - Multilingual and Agency Services


5. The office symbols for TF&P are C:DC:TS:CAR:MP:T.

6. Visit TF&P at: Tax Forms & Publications - Home.


**1.1.13.5.1.2.1** **(08-29-2025)**

###### Individual and Specialty Forms and Publications

1. **Mission:** The mission of Individual and Specialty Forms and Publications is to advance the Tax Forms and Publications (TF&P) mission by focusing on tax products generally used by individual taxpayers and developing key tax products in languages other than English.

2. To accomplish the mission, Individual and Specialty Forms and Publications:



1. Develops and revises tax products primarily used by individuals who file Form 1040 series tax returns and commonly attached schedules such as Schedules A and B to ensure they accurately reflect tax law and are understandable and easy to use.

2. Develops and revises tax products that focus on forms, schedules, instructions and publications primarily used by individuals who are not covered by the 1040 Family Section, to ensure they accurately reflect tax law, and are as understandable and as easy to use as possible.

3. Develops, revises and improves tax products that focus on other special areas such as information returns and pension related products, to ensure they accurately reflect tax law and are as understandable and easy to use as possible.


3. Major programs and areas of responsibilities include:



   - Author tax products

   - Analyze legislation


4. The Chief, Individual and Specialty Forms reports to the Director, Tax Forms and Publications.

5. The following sections report to the Chief, Individual and Specialty Forms and Publications:



   - 1040 Family Section

   - Individual Tax Law Section

   - Specialty Tax Law Section

   - Other Tax Law


6. The office symbols for Individual and Specialty Forms and Publications are C:DC:TS:CAR:MP:T:I.


**1.1.13.5.1.2.2** **(08-29-2025)**

###### Business, Exempt Organizations and International (BE&I) Forms and Publications

1. **Mission:** The mission of Business, Exempt Organizations and International (BE&I) Forms and Publications is to advance the Tax Forms and Publications (TF&P) mission by focusing on tax products generally used by business entities, exempt organizations, and international taxpayers.

2. To accomplish the mission, Business, Exempt Organizations and International (BE&I) Forms and Publications:



1. Develops and revises tax products primarily used by exempt organizations, employee benefits plans, estates, or persons making taxable gifts.

2. Develops, revises and improves tax products primarily of interest to corporations including employment tax products.

3. Develops, revises and improves tax products primarily of interest to taxpayers affected by international tax matters.

4. Develops, revises and improves tax products primarily of interest to partnerships and small businesses.


3. Major programs and areas of responsibilities include:



   - Authoring tax products

   - Analyzing legislation


4. The Chief, Business, Exempt Organizations and International Forms and Publications reports to the Director, Tax Forms and Publications.

5. The following teams report to the Chief, BE&I Forms and Publications:



   - Tax Exempt and Government Entity (TE/GE) Section

   - Corporate Tax Section

   - International Section

   - Pass-Through Section


6. The office symbols for BE&I Forms and Publications are C:DC:TS:CAR:MP:T:B.


**1.1.13.5.1.2.3** **(08-29-2025)**

###### Multilingual and Agency Services

1. **Mission:** The mission of Multilingual and Agency Services is to advance the Tax Forms and Publications (TF&P) mission by focusing on burden reduction and coordination with the Office of Management and Budget (OMB) and by ensuring meaningful access to taxpayers with Limited English Proficiency (LEP) to IRS products and services through translation, interpretation, and similar multilingual services.

2. To accomplish the mission, Multilingual and Agency Services:



01. Facilitates the IRS’ efforts to support the needs of non-English/ limited English proficient taxpayers.

02. Supports IRS efforts to develop and administer service wide policies, strategies and initiatives to assist taxpayers in meeting their tax responsibilities.

03. Translates and quality reviews strategic tax products and "non-vital documents."

04. Administers IRS' "Language Assistance Policy."

05. Monitors implementation of translation standards.

06. Facilitates resolution of cross-functional language-related issues.

07. Supports the Language Services Executive Advisory Council (LSEAC).

08. Participates in language-related improvement projects.

09. Provides Servicewide translation and quality-reviews of all case-related, outreach and education, official IRS letters and notices, etc.

10. Management of all IRS multilingual websites (Spanish, Chinese, Vietnamese, Korean and Russian).

11. Contract management of Servicewide translation contracts.

12. Ensures the IRS complies with the Paperwork Reduction Act.


3. Major programs and areas of responsibilities include:



   - Translation Services

   - Quality Review

   - Proofreading

   - Servicewide Management of Paperwork Reduction Act Process


4. The Chief, Multilingual & Agency Services reports to the Director, Tax Forms and Publications.

5. Multilingual and Agency Services consists of three sections:



   - Linguistic Policy, Tools and Services (LPTS) Section

   - Special Services Section

   - Translation Services Section


6. The office symbols for Multilingual & Agency Services are C:DC:TS:CAR:MP:T:M.

7. Visit Multilingual & Agency Services at: Multilingual & Agency Services.


**1.1.13.5.1.3** **(08-29-2025)**

##### Publishing

1. **Mission:** To plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations; and, used internally within IRS for tax administration. This encompasses the integrated design, specifications writing, production planning, acquisition, and delivery or distribution coordination required to provide the highest quality products and services, using all print and electronic media and technology available.

2. To accomplish the mission, Publishing:



1. Integrates design, specifications writing, production planning, acquisition, and delivery/distribution coordination required to provide the highest quality products and services, using all print and electronic media and technology available.

2. Provides publishing specialists within Publishing as the initial contact for all printing and publishing services for all media types. Supports product originators during the developmental stage of any project or program that requires published products.

3. Digitize and make IRS forms fully functional on mobile devices.


3. Major programs and areas of responsibilities include:



   - Business Card Program

   - Design Management Project

   - Customer Service Satisfaction Surveys

   - Envelope Program

   - Form Letter Program

   - Internal Forms Design

   - Internal Revenue Bulletin

   - IRM/Internal Management Document (IMD) Program

   - Letterhead Stationery Program

   - Tax Forms Program

   - Taxpayer Education, Assistance and Awareness

   - Taxpayer Information Publications Program

   - Training Products Program

   - Digital and Mobile Adaptive Forms (DMAF)


4. The Director, Publishing reports to the Director, Media and Publications.

5. Publishing consists of three sections:



   - Publishing Services Branch

   - E-Publishing Branch

   - Tax Publishing Content Branch


6. The office symbols for Publishing are C:DC:TS:CAR:MP:P.

7. Visit Publishing at: Publishing.


**1.1.13.5.1.3.1** **(08-29-2025)**

###### Publishing Services Branch

1. **Mission:** To provide publishing support, policies and procedures for all public and internal non-tax products required by any of the Service’s organizations. This includes coordinating the design, composition, acquisition or production and dissemination of all non-tax product lines, including electronic media, and hardcopy printing.

2. To accomplish the mission, Publishing Services:



1. Partners with product originators Servicewide to manage publication of their products.

2. Develops policies and procedures to support publication of non-tax products.


3. Major programs and areas of responsibilities include:



   - Business Card Program

   - Customer Service Satisfaction Surveys

   - Internal Forms Design

   - Letterhead Stationery Program

   - Taxpayer Education, Assistance and Awareness Program

   - Training Products Program

   - Envelope Program


4. The Chief, Publishing Services reports to the Director, Publishing.

5. The Publishing Services Branch consists of three sections:



   - Taxpayer Services Products Section

   - Non-Tax Products Business Section

   - Functional Publishing Section


6. The office symbols for Publishing Services are C:DC:TS:CAR:MP:P:PS.

7. Visit Publishing Services at: Publishing Services Branch.


**1.1.13.5.1.3.2** **(08-29-2025)**

###### e-Publishing

1. **Mission:** To provide oversight of specialized electronic publishing needs for the Service, including design support, product creation, staging and posting tax products to IRS.gov, and electronic composition of all tax products.

2. To accomplish the mission, e-Publishing:



01. Partners with product originators Servicewide to develop and prepare content and supporting visual information for publication.

02. Provides specialized graphics and design services directly to IRS internal customers, and to publishing specialists in other Publishing branches so they can provide all IRS product owners one-stop publishing services.

03. Oversees the design Management and graphic identity standards for corporate identity of IRS.

04. Provides electronic composition services for the IRS’s tax products that include all forms, instructions and publications.

05. Ensures all forms and publications are Section 508 compliant.

06. Provides administration and support for the Publishing Services Request (PSR), Publishing Services Data (PSD), and the Electronic Status Notice (ESN) systems.

07. Maintains the Core Repository of Published Products (CROPP).

08. Administers cross-IRS publishing programs, such as the IRM and Internal Management Documents (IMDs).

09. Provides specialized services including Forms and Analysis Design and XML-Enabled Portable Document Formats (PDFs).

10. Provides job tracking and budget management for all Publishing products.

11. Manages product attributes about published products, both internal and public.

12. Prepares and stages products to be posted to [IRS.gov.](https://www.irs.gov/)


3. The Chief, of e-Publishing reports to the Director, Publishing.

4. e-Publishing consists of three sections:



   - Design Section

   - Electronic Composition Section

   - e-Forms Technology Section


5. The office symbols for e-Publishing are C:DC:TS:CAR:MP:P:EP.

6. Visit e-Publishing at: e-Publishing Branch.


**1.1.13.5.1.3.3** **(08-29-2025)**

###### Tax Publishing Content Branch

1. **Mission:** To provide publishing support for all tax products required by the Service. This includes coordinating the design, composition, acquisition or production and dissemination of all tax product lines, including electronic media, as well as hardcopy printing.

2. To accomplish the mission, Tax Products:



1. Coordinates development and delivery of tax products for publication.

2. Partners with other Media and Publications (M&P) divisions to produce tax products.


3. Major programs and areas of responsibilities include:



   - IRS’ Tax Product Dissemination Programs

   - Tax Forms Program

   - Taxpayer Assistance Center (TAC) Program

   - IRS Tax Forms Outlet Program (TFOP)

   - Taxpayer Information Publications Service (TIPS)

   - Form Letter Program

   - Substitute Forms Program

   - Internal Revenue Bulletin


4. The Chief, Tax Products Branch reports to the Director, Publishing.

5. Tax Products consists of two sections:



   - Tax Products Section

   - Content Delivery Section


6. The office symbols for Tax Publishing Content are C:DC:TS:CAR:MP:P:TP.

7. Visit Tax Products at: Tax Publishing Content Branch.


**1.1.13.5.1.4** **(08-29-2025)**

##### Distribution

1. **Mission:** The mission of Distribution is to:



   - Ensure the timely distribution of printed and electronic correspondence, forms, and instructional materials used by the public to comply with their federal tax obligations and used internally for tax administration.

   - Oversee technology resources used for the production and distribution of all printed products.

   - Manage the IRS’s postal budget and serve as the primary point of contact for the US Postal Service.

   - Work closely with Service-wide partners and stakeholders to deliver products that are of the highest quality in language and accessibility format to meet the taxpayer’s need.


2. To accomplish the mission, Distribution:



1. Oversees the planning and distribution services for all IRS print and electronic communications products used by the public.

2. Provides knowledge services and systems management support for all publishing and distribution programs.

3. Ensures the highest quality products and services to be made available using all print, electronic, accessible media, and technology are available.

4. Provides tools and guidance to ensure the IRS is Section 508 compliant in all publishing mediums through the Alternative Media Center (AMC) (i.e., braille, large print, CD-ROM, electronic braille, tactile graphics, captioning service, etc.).


3. The Director of Distribution reports to the Director Media and Publications (M&P).

4. The following functions report to the Director, Distribution:



   - Technology and Program Support

   - National Distribution Center

   - Correspondence Production Services

   - Taxpayer Correspondence Services


5. The office symbols for Distribution are C:DC:TS:CAR:MP:D.

6. Visit Distribution at: Distribution.


**1.1.13.5.1.4.1** **(08-29-2025)**

###### Technology and Program Support

1. **Mission**: To enhance business through a combination of customer knowledge and inspired thinking to deliver innovative technology and services that drive support for M&P for:



   - Information Technology and Program management

   - Distribution Programs and Support

   - Planning and management for all uses of mail and transportation services

   - Alternative Media accessibility services


2. To accomplish the mission, Technology and Program Support:



1. Coordinates business requirements and provides systems management support and security compliance for Media and Publications (M&P) publishing and distribution programs to deliver the highest quality products using all print and electronic media and technology available.

2. Provides Servicewide program and budget management for all users of mail and transportation services.

3. Plans and provides mail and transportation services for all published products.

4. Ensures Section 508 compliance and provides IRS published products in accessible alternative media formats for IRS employees and taxpayers with disabilities.


3. Major programs and areas of responsibilities include:



   - Private Delivery Service and U.S. Postal Service

   - FedEx, Personally Identifiable Information (PII) and United Parcel Service (UPS)

   - Transportation Management

   - International Bulk Mail and Transportation Management

   - XML/SGML help desk website

   - Alternative Media


4. The Chief, Technology and Program Support reports to the Director, Distribution.

5. The Technology and Program Support Branch consists of four sections:



   - Technology and Governance Section

   - Distribution Programs and Support Section

   - Postal and Transportation Section

   - Alternative Media Center


6. The office symbols are C:DC:TS:CAR:MP:D:DR.


**1.1.13.5.1.4.2** **(08-29-2025)**

###### National Distribution Center (NDC)

1. **Mission:** To provide planning and order fulfillment for IRS products to assist taxpayers in meeting their tax obligations and to support internal IRS operations.

2. To accomplish the mission, National Distribution Center (NDC):



1. Receive, input, and process requests from the public and internal IRS customers for IRS materials. This includes determining quantity requirements, distribution methods, and shipments for all products, including deliveries to outlet programs (TAC, TFOP and VITA).

2. Provide services for in-line order printing, package assembly, and warehousing.

3. Manage IRS correspondence projects for targeted audiences, including data merge, print, and mail.

4. Receives and inputs telephone, fax, mail order and electronic requests for published material from distribution outlets and IRS employees and organizations.

5. Provides inventory and warehouse management for all for all IRS published products.


3. Major programs and areas of responsibilities include:



   - Employer Program

   - International Program (Embassies)

   - Internal Management Documents Distribution System (IMDDS)

   - Order and Subscription Management System

   - Package Assembly Program

   - Postal and Transport Policy Program

   - Print on Demand Program

   - Prior Year Program

   - Small Business Tax Forms Distribution Program (Service Corps of Retired Executives (SCORE))

   - Tax Forms Outlet Program (Congressional Offices, Libraries and Post Offices)

   - Taxpayer Assistance Center (TAC) Program

   - Taxpayer Education, Assistance and Awareness Program

   - Toll-Free Telephone Services Forms Orders (Formerly called: NTI/NISH or Alpine Access)

   - Volunteer Income Tax Assistance (VITA)/Tax Counseling for the Elderly (TCE)


4. The Chief, National Distribution Center reports to the Director, Distribution.

5. NDC consists of three sections:



   - Production and Support Section

   - Forecasting and Coordination Section

   - Fulfillment and Logistics Section


6. The office symbols for NDC are C:DC:TS:CAR:MP:D:NDC.

7. Visit NDC at: Distribution (irs.gov).


**1.1.13.5.1.4.3** **(08-29-2025)**

###### Correspondence Production Services (CPS)

1. **Mission:**To build and utilize the best available products for internal and external customers. This includes the full range of automated and high-volume outgoing mail to taxpayers such as:



   - First class correspondence distribution for domestic and foreign destinations.

   - Automated postal discounting through correspondence pre-sort and electronic data exchanges with USPS.

   - Implementation of standards for mail data and USPS presentation.


2. To accomplish the mission, CPS:



1. Provides technical support for equipment, contracts, software, budget, quality control, and customer service and outreach within the CPS.

2. Produces all required correspondence mailings on time, with lowest cost and in accord with customer quality standards.

3. Offers round-the-clock production support using three shifts and weekend production to handle all its workload.

4. Oversees scheduling, production control and materials handling/logistics, machine operations.

5. Directs mailing activities to complete its workload timely and according to procedures.

6. Conducts quality review and reporting activities as required.

7. Communicates to and cooperates with other print sites and technical support staff to balance workload and ensure successful mailing.

8. Provides operational backup to the other CPS site.


3. Major programs and areas of responsibilities include:



   - First class mailing

   - Postage pre-sort discounting and data exchange with USPS

   - Return Receipt mailing with bulk proof of delivery

   - Certified mailing with delivery confirmation

   - International mailing (including Registered Foreign)

   - Mail manifesting and metering

   - Postal permit obligation and mail cost tracking

   - Notice Delivery System application administration


4. The Chief, Correspondence Production Services reports to the Director, Distribution.

5. CPS consists of four sections:



   - Technical Support Section

   - Operations Section - Detroit (East)

   - Operations Section - Ogden (West)

   - Operations Section – Bloomington (Central)


6. The office symbols for CPS are C:DC:TS:CAR:MP:D:CPS.

7. Visit CPS at: Correspondence Production Services (irs.gov).


**1.1.13.5.1.4.4** **(08-29-2025)**

###### Taxpayer Correspondence Services (TCS)

1. **Mission:** The mission of Taxpayer Correspondence Services (TCS) is to manage the design, development, planning and delivery of all taxpayer correspondence issued by the IRS. TCS implements consistency, quality, plain language standards, procedures, website design and business policies for all correspondence, both electronic and paper, with the goal of helping taxpayers understand their responsibilities and take the appropriate action to resolve their tax issues.

2. To accomplish the mission, TCS:



01. Coordinates, creates and implements correspondence using approved requirements as outlined in the correspondence toolkit.

02. Engages other organizations within Distribution and across Media and Publications (M&P) such as Correspondence Production Services (CPS), Alternative Media Center (AMC), and National Distribution Center (NDC) and Publishing Services to assess impact and ensure end to end coordination on delivery, printing, publishing and shipment of all correspondence.

03. Collaborates with stakeholders depending on correspondence needs (i.e., Office of Servicewide Penalties (OSP), Online Services (OLS), Communications & Liaison (C&L), etc.).

04. Coordinates correspondence language translations.

05. Develops and coordinates future multilingual notice strategy with stakeholders.

06. Ensures timely submission of feedback to correspondence updates.

07. Oversees timely coordination of Chief Counsel approval and Taxpayer Advocate Service input.

08. Completes, submits, and monitors correspondence related Unified Work Requests (UWRs).

09. Completes annual review of correspondence.

10. Coordinates Servicewide responses to Erroneous Taxpayer Correspondence (ETC) and documents risk-based decision processes, including erroneous correspondence reporting and correspondence development.


3. TCS is the required, authoritative source for all correspondence developers, product owners and stakeholders for the development or revision of all digital and paper correspondence and correspondence-related initiatives. TCS:



   - Oversees the development of new or revised taxpayer correspondence.

   - Acts as the liaison between the product owner and stakeholders.


4. The following table includes TCS key stakeholders and support provided:




| **Stakeholder** | **Support** |
| :-: | :-: |
| Accounts Management Services | Prepares an impact assessment of toll-free telephone numbers on new products. |
| Correspondence Production Services | Coordinates the production of new products. |
| Linguistic Policy, Tools and Services | Coordinates the translation of English products into requested languages for people not proficient in English. |
| Information Technology (IT) | Prepares programming requirements and submits Unified Work Requests for correspondence products. |
| Tax Advocate Services (TAS) | Shares a copy of new or revised correspondence products with TAS for feedback on taxpayer rights and taxpayer burden issues. |
| Chief Counsel | Sends a copy of new or revised correspondence to Counsel to determine if legally sufficient language is incorporated. |

5. The Chief, TCS reports to the Director, Distribution.

6. TCS consists of three sections:



   - Customer Accounts Management Section (CAMS)

   - Requirements and Technology Section

   - Data Metrics and Initiatives Section


7. The office symbols for TCS are C:DC:TS:CAR:MP:D:TCS.

8. Visit TCS at: Taxpayer Correspondence Services (irs.gov)


**1.1.13.5.2** **(01-24-2023)**

#### Stakeholder Partnerships, Education and Communication (SPEC)

1. **About**: Stakeholder Partnerships, Education and Communication (SPEC) develops and supports partnerships with client-based organizations that have a commitment to increase the economic well-being of shared customers. The SPEC organization integrates tax education, outreach, and free tax preparation with other strategies that are promoted by partners to increase income, build savings, and gain and sustain assets for taxpayers.

2. **Mission:** The mission of SPEC is to assist customers taxpayers in satisfying their tax responsibilities by building and maintaining partnerships with key stakeholders, seeking to create and share value by informing, educating and communicating with its shared customers.

3. To accomplish the mission, SPEC:



1. Uses a leverage approach to taxpayer service by placing primary emphasis on partner involvement and relationship management.

2. Delivers taxpayer help through its three-pronged business model of income tax return preparation, educational outreach and financial education, and asset building information.

3. Assists customers who prepare their own returns and who exhibit good faith attempts to voluntarily comply.

4. Maintains a customer focus by soliciting information concerning the needs and characteristics of its customers and by coordinating with Research to develop programs and products based on the information received.

5. Educates customers on their rights and responsibilities to clarify obligations for first-time customers, customers who have not invested time in understanding tax issues, and customers impacted by changes in either their filing status or in tax laws.

6. Gauges partner feedback and overall satisfaction each filing season by administering an online survey through a survey contractor, who compiles the survey results for review and follow-up actions by SPEC.


4. The Director, SPEC, reports to the Director, Customer Assistance, Relationships and Education (CARE).

5. The following report to the Director, SPEC:



   - SPEC Area Directors

   - Strategy and Program Management

   - Program Support

   - National Partnerships

   - Grant Program Office


6. The office symbols for SPEC are C:DC:TS:CAR:SPEC.

7. Visit SPEC at: Stakeholder Partnerships, Education & Communication.


**1.1.13.5.2.1** **(02-26-2020)**

##### Stakeholder Partnerships, Education and Communication (SPEC) Area Directors

1. **Mission:** To plan, manage and direct activities of field SPEC personnel and to provide oversight for SPEC’s leveraged partnerships.

2. To accomplish the mission, the staff:



1. Coordinates product and program customization at the territory level.

2. Supports territory office administrative requests.

3. Coordinates identification and sharing of proposed services.

4. Collects and processes customer feedback from territory offices prior to forwarding to SPEC headquarters office.

5. Ensures a consistent level of service across territory offices.


3. There are three SPEC Area Directors, located in Atlanta, GA, Cincinnati, OH, and Fresno, CA.

4. SPEC Area Directors report to the Director, SPEC.

5. SPEC Territory Managers report to the SPEC Area Directors.

6. The office symbols for SPEC Area Directors are:



   - Area 1: C:DC:TS:CAR:SPEC:A1

   - Area 2: C:DC:TS:CAR:SPEC:A2

   - Area 3: C:DC:TS:CAR:SPEC:A3


**1.1.13.5.2.1.1** **(02-26-2020)**

###### Stakeholder Partnerships, Education and Communication (SPEC) Territory Managers

1. **Mission:** To plan, manage and direct activities of field SPEC personnel.

2. To accomplish the mission, the staff:



1. Customizes products and programs according to local needs and preferences.

2. Collects feedback from partners and customers and forwards the feedback to the proper operations area office.

3. Identifies customer segments that require help, education and access.

4. Collects data to quantify the reach and impact of SPEC services on local customers.

5. Delivers tax information messages to Taxpayer Services (TS) customers.

6. Identifies and contacts local partners to provide the best leveraged opportunities.

7. Establishes and maintains local partnerships.

8. Delivers localized programs that promote electronic interactions (filing, paying and communicating) between IRS and TS.


3. The SPEC Territory Managers report to the SPEC Area Directors.


**1.1.13.5.2.2** **(02-26-2020)**

##### Strategy and Program Management

1. **Mission:**To plan, manage, and direct the budget and infrastructure activities of Stakeholder Partnerships, Education and Communication (SPEC).

2. To accomplish the mission, Strategy and Program Management:



01. Oversees the SPEC budget.

02. Oversees employee training and mandatory briefings.

03. Determines the infrastructure requirements (i.e., security, space, facilities).

04. Oversees staffing and hiring.

05. Oversees Treasury Inspector General for Tax Administration (TIGTA)/Government Accountability Office (GAO) Audits.

06. Coordinates SPEC program and administrative initiatives (Taxpayer Services (TS) Operation Review, BPR, Commissioners Update, etc.).

07. Develops Measures/Goals and Measures reports (Scorecard, Weekly Measures and Program Activity Code \[PAC1c\]).

08. Manages and developing the SPEC Program Guide.

09. Oversees the awards processes.

10. Oversees the travel processes.

11. Oversees the Annual Assurance Process.


3. The Chief, Strategy and Program Management, reports to the Director, SPEC.

4. The following report to the Chief, Strategy and Program Management:



   - Field Support and Analysis


5. The office symbols for Strategy and Program Management are C:DC:TS:CAR:SPEC:SPM.


**1.1.13.5.2.2.1** **(01-24-2023)**

###### Field Support and Analysis

1. **Mission:** To provide support to the Stakeholder Partnerships, Education and Communication (SPEC) area directors and territory offices, uniformly and efficiently applying service policies, programs and procedures.

2. To accomplish the mission, Field Support and Analysis:



01. Conducts Territory Operational Reviews.

02. Prepares reports and validates Territory performance.

03. Coordinates specific projects or programs for the Areas.

04. Oversees the Area Filing Season activities, Stakeholder Partnerships, Education and Communication Total Relationship Management (SPECTRM) Business Measures, and the Quality Program.

05. Analyzes Area technical, operational and administrative programs related to Volunteer Income Tax Assistance (VITA)/Tax Counseling for the Elderly (TCE) Program initiatives, tax preparation software, IRS computer loaned equipment, and Treasury Inspector General for Tax Administration (TIGTA)/Government Accountability Office (GAO) audits.

06. Monitors the Area’s budget allocations and expenditures.

07. Oversees the Areas travel processes.

08. Manages equipment and equipment certification.

09. Oversees the Area employee training and mandatory briefings.

10. Oversees and leads the Area Operational Reviews.


3. The Chief, Field Support and Analysis, reports to the Chief, Strategy and Program Management.

4. The office symbols for Field Support and Analysis are C:DC:TS:CAR:SPEC:SPM:FSA.


**1.1.13.5.2.3** **(01-24-2023)**

##### Program Support

1. The mission of Program Support is to plan, manage, evaluate and direct activities of the Volunteer Income Tax Assistance (VITA) and Tax Counseling for the Elderly (TCE) Programs.

2. To accomplish the mission, Program Support:



1. Oversees the loaned equipment program.

2. Outlines policy and guidance for the Areas for all filing season readiness activities.

3. Oversees the Volunteer Milestone Recognition program.

4. Outlines policy and guidance for the Certifying Acceptance Agent program.

5. Outlines policy and guidance for Continuing Education Credits.

6. Outlines policy and guidance for Civil Rights.

7. Outlines policy and guidance for Volunteer Misconduct/Volunteer Registry.

8. Outlines guidance for VolTax referrals.

9. Performs financial reviews of VITA and TCE grantees.


3. The Chief, Program Support, reports to the Director, Stakeholder Partnerships, Education and Communication (SPEC).

4. The following report to the Chief, Program Support:



   - Product, Systems and Analysis

   - Quality Program Office


5. The office symbols for Program Support are C:DC:TS:CAR:SPEC:PS.


**1.1.13.5.2.3.1** **(01-24-2023)**

###### Products, Systems and Analysis

1. The mission of Products, Systems and Analysis is to:



1. Equip Stakeholder Partnerships, Education and Communication (SPEC) employees, partners, and volunteers with the training and tools necessary for successful delivery of the filing season.

2. Inform and educate individual taxpayers to ensure voluntary compliance with IRS tax law and requirements.

3. Manage SPEC’s management information system (SPECTRM) as it provides key information on partners, sites, and equipment.


2. To accomplish the mission, the staff:



1. Develops Volunteer Income Tax Assistance (VITA)/Tax Counseling for the Elderly (TCE) products and materials for tax law training or operational programs.

2. Determines and manages the clearance process for all SPEC products through Media and Publications (M&P), Counsel, Earned Income Tax Credit (EITC) Program Office, Information Technology (IT), and other impacted offices.

3. Develops strategies to maximize the electronic interactions between IRS and Taxpayer Services (TS) customers, including e-learning and e-training.

4. Designs, operates, and maintains the SPEC Total Relationship Management (SPECTRM) system to support the SPEC business model and data reporting needs.


3. The Chief, Products, Systems and Analysis, reports to the Chief, Program Support.

4. The office symbols for Products, Systems and Analysis are C:DC:TS:CAR:SPEC:PS:PSA.


**1.1.13.5.2.3.2** **(01-24-2023)**

###### Quality Program Office

1. **Mission:** To establish a quality program to identify improving volunteer training; efficiently utilize resources; identify gaps in quality processes and potential inconsistencies; and promote better marketing and oversight.

2. To accomplish the mission, the staff:



1. Performs quality statistical sample (QSS) reviews determining the accuracy rate for Volunteer Income Tax Assistance (VITA)/Tax Counseling for the Elderly (TCE) program.

2. Develops Stakeholder Partnerships, Education and Communication (SPEC) Filing Season Readiness (FSR) employee training.

3. Develops fiscal year quality training for partners and employees.

4. Revises and develops forms and job aids needed for FSR/RSR and QSS processes.

5. Revises the handbooks for site coordinator, partners, and other partner products.

6. Issues Quality Site Requirement Alerts (QSRA) as needed.


3. The Chief, Quality Program Office reports to the Chief, Program Support.

4. The office symbols for Quality Program Office are C:DC:TS:CAR:SPEC:PS:QPO.


**1.1.13.5.2.4** **(01-24-2023)**

##### National Partnerships

1. **Mission:** To identify national organizations that have a shared mission of serving low-income, elderly, rural and limited English proficiency clients, and maintain relationships with those organizations to leverage and engage their resources to inform, educate, and communicate with our customers by implementing strategies through a community-based partnership model.

2. To accomplish the mission, the staff:



1. Partners with national organizations to deliver Taxpayer Services (TS) products and services.

2. Develops national or strategic partnerships that support Stakeholder Partnerships, Education and Communication's (SPEC’s) leveraged business model through the delivery of SPEC products and services.

3. Develops best practices, involving the SPEC community-based partner coalition model.

4. Promotes electronic interactions (filing, paying and communicating).

5. Oversees military training.

6. Coordinates the Partner Satisfaction Survey.

7. Manages the tax preparation software contract for the VITA/TCE program.


3. The Chief, National Partnerships reports to the Director, SPEC.

4. The office symbols for National Partnerships are C:DC:TS:CAR:SPEC:NP.


**1.1.13.5.2.5** **(01-24-2023)**

##### Grant Program Office

1. **Mission:**To oversee policy and procedures for administering the Volunteer Income Tax Assistance (VITA) and Tax Counseling for the Elderly (TCE) grant programs.

2. To accomplish the mission, the Grant Program Office (GPO) staff:



1. Oversees the grant application process according to the Office of Management and Budget (OMB) guidance and IRS grant program policies and procedures.

2. Makes recommendations for awards based on amount of funding from Congress, grant program eligibility requirements, and past performance.

3. Assembles and conducts training for grant ranking panels to ensure compliance with ranking guidelines.

4. Annually plans and conducts orientation for all grant recipients.

5. Annually conducts volunteer administrative reviews to assist grant recipients in complying with grant program guidelines.

6. Maintains and updates the Enterprise Case Management (ECM) system with applicant and grant recipient information and data.

7. Serves as the point of contact for information, assistance and guidance to all internal and external customers relative to IRS grants.


3. The Chief, Grant Program Office, reports to the Director, Stakeholder Partnerships, Education and Communication (SPEC).

4. The office symbols for the Grant Program Office are C:DC:TS:CAR:SPEC:GPO.

5. Visit GPO at Grant Program Office.


**1.1.13.5.3** **(01-24-2023)**

#### Field Assistance (FA)

1. _About:_ The Field Assistance (FA) organization manages the Taxpayer Assistance Centers (TACs) located throughout the country. Field Assistance serves as the “face” of the IRS by providing comprehensive face-to-face help, solutions to tax problems, and virtual assistance to taxpayers every business day.

2. **Mission:** To provide quality service to taxpayers requiring face-to-face assistance and to educate taxpayers on services available to them through all channels, including self-service.

3. To accomplish the mission, FA:



1. Locates offices in geographic areas accessible to the greatest number of taxpayers.

2. Provides state-of-the-art office designs for TACs.

3. Maintains a staff fully trained to provide the full range of services available at TACs.

4. Ensures processes and systems are maximized providing timely and quality service.


4. _Customer Satisfaction:_ Field Assistance uses the FA Customer Satisfaction Survey to measure overall taxpayer satisfaction with the services provided in TACs. TAC employees offer a survey card to every taxpayer served on designated days of the month. Taxpayers rate the services provided in the TAC on a scale from 1 to 5. The cards are collected in the TAC and mailed to an outside vendor who compiles the data monthly, conducts analyses, and prepares quarterly reports. See IRM 21.3.4.3.3, Communicating with and Surveying Taxpayers, for more information.

5. The Director, Field Assistance reports to the Director, Customer Assistance, Relationships and Education (CARE).

6. The following report to the Director, Field Assistance:



   - Chief, Operations and Training

   - Chief, Policy, Technology and Measures

   - Chief, Financial Planning and Resources

   - Field Assistance Area Directors


7. The office symbols for FA are C:DC:TS:CAR:FA.

8. Visit FA at: Field Assistance.


**1.1.13.5.3.1** **(02-26-2020)**

##### Field Assistance Area Director

1. **Mission:** To oversee all field activities within specified geographic areas with the primary objective of ensuring consistency and quality of program execution, including self-service.

2. To accomplish the mission, the staff:



1. Performs program reviews.

2. Monitors and analyzes quality data.

3. Monitors and analyzes balanced measures.

4. Coordinates training activities.


3. FA Area Directors report to the Director, FA.

4. FA Territory Managers report to FA Area Directors.

5. The office symbols for FA Area Directors are:



   - Area 1: C:DC:TS:CAR:FA:A1

   - Area 2: C:DC:TS:CAR:FA:A2

   - Area 3: C:DC:TS:CAR:FA:A3

   - Area 4: C:DC:TS:CAR:FA:A4


**1.1.13.5.3.1.1** **(12-21-2018)**

###### Field Assistance Territory Managers

1. **Mission:**To oversee activities of FA groups in a specified geographic territory and ensure consistency of training, program execution, services and facilities.

2. To accomplish the mission, the staff:



1. Manages and monitors the quality and quantity of work.

2. Maintains working relations with other business units (BU).

3. Ensures correct and timely training for front-line employees.

4. Allocates and efficiently uses non-financial resources among groups.

5. Interacts with other operating units for shared service needs (e.g., recruiting, facilities, etc.).

6. Coordinates with personnel and other BUs.


3. FA Territory Managers report to FA Area Directors.

4. FA Territory Managers oversee the FA Group Managers.


**1.1.13.5.3.1.1.1** **(02-26-2020)**

###### Field Assistance Group Managers

1. **Mission:** To oversee provision of face-to-face assistance, education and compliance services to customers that require face-to-face interaction with the IRS.

2. To accomplish the mission, the staff:



1. Responds to account inquiries.

2. Accepts payments.

3. Provides tax law assistance.


3. FA Group Managers report to FA Territory Managers.


**1.1.13.5.4** **(01-24-2023)**

#### Customer Assistance, Relationships and Education (CARE) Planning and Analysis (P&A)

1. **Mission:** To provide guidance and support to the Director, CARE by overseeing the integration of policy and planning, evaluating business process strategies for improvement, as well as to act as a consultant for the functional units, Field Assistance (FA), Media and Publications (M&P), and Stakeholder Partnerships, Education and Communication (SPEC).

2. To accomplish the mission, CARE Planning & Analysis (P&A):



01. Oversees the integration of standardized policy throughout CARE.

02. Provides guidance to CARE program management staffs and participate in liaison activities with FA, M&P, and SPEC functions.

03. Provides support, guidance and resolution to the CARE functions for space management and physical safety and security programs.

04. Serves as the management information systems focal point for CARE activities.

05. Coordinates and monitors the improvement project activities for CARE and serves as liaison to Business Systems Modernization (BSM).

06. Coordinates the review of overage conduct cases in conjunction with Labor Relations and Embedded Human Capital Office.

07. Manages content of the CARE home page and oversees [IRS.gov](https://www.irs.gov/) web links for CARE, ensuring accuracy of information.

08. Serves as a liaison to Capital Management and Oversight (CMO) in coordinating management of CARE’s fiscal resources.

09. Serves as liaison to Return Integrity and Compliance Services (RICS) on the development and implementation of the Earned Income Tax Credit (EITC) Service Level Agreement.

10. Provides guidance and support to CARE functions on human capital initiatives, span-of-control, and Requests for Organizational Change.

11. Supports and/or leads CARE special projects.

12. Manages internal controls, including Treasury Inspector General for Tax Administration (TIGTA), Government Accountability Office (GAO) audits and findings, and Chief Financial Officer (CFO) reviews, including the Annual Assurance process.

13. Manages the legislative process, including developing implementation plans for tax legislation, monitoring action plans to completion, and responding to congressional inquiries.

14. Coordinates and manages the external advisory groups program for CARE, which includes working with the Taxpayer Advocacy Panel (TAP), the IRS Advisory Council (IRSAC) and Electronic Tax Administration Advisory Committee (ETAAC).

15. Coordinates the CARE Internal Management Document (IMD) Program, which includes the update, review, clearance, and publishing of IRMs, delegation orders, policy statements, and interim guidance.

16. Manages the Taxpayer Advocate Service’s (TAS) Most Serious Problems.

17. Ensures actions are accomplished to support CARE’s readiness for a successful filing season.

18. Monitors the status of strategic and business planning and the balanced measures.

19. Provides support for employee training across the CARE organization to ensure all mandatory training is conducted and sub-offices establish proper training plans.

20. Verifies operational effectiveness of implementation and maintenance of technical procedures based on legislation and executive orders.

21. Manages the Office of Government Ethics (OGE) Program OGE Form 450, _Confidential Financial Disclosure Report_.


3. The Chief, P&A reports to the Director, CARE.

4. The office symbols for CARE P&A are C:DC:TS:CAR:PA.


**1.1.13.6** **(01-24-2023)**

### Customer Account Services (CAS)

1. **About:** The Customer Account Services (CAS) function is the largest single entity within the IRS with approximately 32,000 employees during peak season and a team of 23 executives. It is the cornerstone of the IRS filing season operation with three Submission Processing centers, processing over 160 million individual paper and electronic returns, and over 50 million paper and electronic business returns. Additionally, CAS answers over 68 million telephone calls through a combination of enterprise automation and assistors at 25 Accounts Management contact centers.

2. **Mission:** To "Inspire confidence in the American tax system by delivering top-quality service through a trouble-free filing experience and efficient resolution of issues."

3. The focus of CAS is to:



1. Actively pursue satisfaction of CAS customers through lawful resolution of customer issues.

2. Timely process tax returns and related submissions, payments and refunds while providing information and assistance on customer account and tax law inquiries.

3. Provide prompt notification of problems and errors related to taxpayer accounts in a manner that provides quality service, meets all IRS customers’ needs, and promotes voluntary compliance and customer confidence in the organization.


4. To accomplish the mission, CAS:



01. Develops operating unit strategy for processing returns and assisting taxpayers with specific account inquiries and adjustments.

02. Develops and implements measures for the CAS function that balance customer satisfaction, employee satisfaction and business results.

03. Processes the tax returns of all IRS customers.

04. Manages tax law, accounts, e-help, and compliance phone calls for Taxpayer Services (TS), Small Business/Self-Employed (SB/SE), and Tax Exempt and Government Entities (TE/GE) through the Joint Operations Center (JOC) Operations.

05. Ensures accurate maintenance of the TS Master File and prompt resolution of account errors.

06. Operates centralized toll-free customer service call sites and correspondence units.

07. Develops strategy for technology implementation issues in concert with Business Systems and Information Systems.

08. Monitors workload and effectiveness of submission processing and customer service patterns and develops strategies to focus CAS activities.

09. Monitors workload and effectiveness of CAS and allocates resources among processing and accounts management.

10. Prepares budget requests.

11. Ensures unit goals, strategy, and organizational policies are clearly communicated to all employees.

12. Participates in equal employment and diversity program activities.


5. The Director, CAS, reports to the Chief, Taxpayer Services.

6. The following business functions report to the Director, CAS:



   - Accounts Management (AM)

   - Electronic Products and Services Support(EPSS)

   - Joint Operations Center (JOC)

   - Submission Processing (SP)

   - CAS Program Coordination and Support

   - CAS Project Management Office


7. The office symbols for CAS are C:DC:TS:CAS.

8. Visit CAS at: Customer Account Services.


**1.1.13.6.1** **(01-24-2023)**

#### Program Coordination and Support (PCS)

1. **Mission:** “With integrity and commitment to excellence, Program Coordination and Support (PCS) supports the Customer Account Services (CAS) organization by collaborating with stakeholders in support of the IRS Strategic Plan.”

2. To accomplish the mission, PCS:



01. Analyzes the impact of legislation on overall CAS operation and ensures functions implement legislation and regulations by taking actions to carry out congressional intent.

02. Oversees the integration of policy throughout CAS.

03. Ensures policies are reflective of taxpayer behaviors, needs and characteristics to improve overall compliance and customer service.

04. Ensures policies incorporate compliance and taxpayer education concerns and needs.

05. Evaluates audit findings from Treasury Inspector General for Tax Administration (TIGTA), and Government Accountability Office (GAO), reports and identifies resources necessary to address recommendations.

06. Serves as the management information systems focal point for CAS activities.

07. Maintains the IRM for CAS.

08. Coordinates CAS budget activities with Taxpayer Services (TS) Finance and Taxpayer Services Operation Support.

09. Monitors the status of strategic and business planning, including balanced measures.

10. Provides guidance and liaison activities with subordinate program management staffs within Submission Processing (SP), Accounts Management (AM), Electronic Products and Services Support (EPSS), and Joint Operations Center (JOC).

11. Ensures the CAS organization complies with position management guidelines and policies.


3. The Chief, PCS reports to the Director, CAS.

4. The office symbols for PCS are C:DC:TS:CAS:PCS.


**1.1.13.6.2** **(08-29-2025)**

#### CAS Project Management Office (CAS PMO)

1. **About:**CAS Project Management Office (CAS PMO) leads and/or provides support for CAS projects that improve customer experiences and drive organizational efficiencies. This includes those impacting CAS’ four key operations: Accounts Management (AM), Electronic Products and Services Support (EPSS), Joint Operations Center (JOC) and Submission Processing (SP). CAS PMO also provides project management expertise in guiding the organization through project milestones, identifying impacts and developing innovative solutions with partners and stakeholders. In support of strategic goals, CAS PMO team members work to enhance the customer experience, maximize resources, simplify processes, modernize services, and improve efficiencies across operating divisions.

2. **Mission:** To support modernization initiatives that improve the efficiencies and processes within CAS, while considering the impact to our internal and external stakeholders. We leverage our project management expertise to maximize resources, integrate processes, systems and organizations to bring us to the future state through innovative solutions developed with our partners and stakeholders..

3. To accomplish the mission, the CAS PMO:



1. Establishes and/or assists with defining overall goals and objectives for major projects.

2. Works with Taxpayer Services (TS) internal and external stakeholders to develop modernization initiatives, evaluate options through data-driven analysis, and provide recommendations.

3. Validates the operational benefits/capabilities outlined in the initiatives.

4. Coordinates resolution of implementation issues.

5. Identifies and monitors implementation risks and coordinates risk mitigation approaches for the initiatives.

6. Identifies and prioritizes initiatives and develops business case for funding.

7. Assists with defining short-term and long-term infrastructure requirements and identifies an approval mechanism.

8. Develops and implements communications strategies to inform stakeholders of impacts of the initiatives in their business unit.


4. The Chief, Project Management Office reports to the Director, Customer Account Services (CAS).

5. The office symbols for the Project Management Office are C:DC:TS:CAS:PMO.


**1.1.13.6.3** **(08-29-2025)**

#### Accounts Management (AM)

1. **About:**Accounts Management (AM) provides assistance to individual taxpayers with tax law and account-related inquiries, including identity theft victim assistance, via telephone, correspondence, and web applications. This is accomplished through employees located in eleven campuses and 14 remote call sites throughout the country. The AM organization balances the delivery of telephone and paper adjustment programs to ensure that all taxpayers receive a correct and complete response in a timely manner. The AM organization continually strives to improve processes to enhance the taxpayer experience and improve efficiency and quality of service.

2. **Mission:** To provide customers with easy and timely access to accurate and user-friendly tax law and account services delivered through operational efficient, multi-channel contact centers; ensure functional implementation of legislation and regulations in a manner consistent with congressional intent; provide executive leadership and direction in the design, development, delivery and consistency of application of policies and procedures across multiple AM campuses and remote call sites; and, improve business practices and technology, and monitor adherence to work plans, program assignments, and guidance at the AM campuses and remote call sites.

3. To accomplish the mission, the AM staff:



01. Plans, directs, manages, administers and executes activities specific to management of customer accounts at the campuses (Andover, Atlanta, Austin, Brookhaven, Cincinnati, Fresno, Kansas City, Memphis, Ogden, Philadelphia and Puerto Rico) and their respective remote call sites, as well as Identity Theft Victim Assistance (IDTVA) directorate.

02. Provides oversight for all paper, electronic and telephone inquiry programs.

03. Directs design, development, and delivery of policies and procedures for multiple customer AM sites.

04. Designs and develops programs to solve routine and complex customer account and tax-related issues.

05. Enables taxpayers to understand and timely follow their tax obligations through telephone and written assistance.

06. Develops format and procedures to exchange data with Submission Processing and other business units.

07. Monitors the customer accounts sites' workloads and adjust workloads among sites as needed.

08. Collaborates extensively with the Joint Operations Center (JOC) to ensure resources are planned, scheduled and used efficiently.

09. Provides executive leadership and direction through subordinate executives and managers geographically located nationwide.

10. Delegates sufficient authority to subordinates to effectively manage their resources and to provide a supportive environment for creativity and innovation.

11. Coordinates program activities with other top-level IRS executives to prepare Servicewide policies, address cross-functional issues, develop strategies, and ensure consistency of approach.

12. Manages all human, physical and financial resources assigned to AM and allocate these resources following overall strategies to further the accomplishment of specific goals.


4. The Director, AM, reports to the Director, Customer Account Services (CAS).

5. Direct reports to the Director, AM, and Deputy Director, AM, include:



   - Reports, Quality and Joint Operations Center Operating Division Representative (RQ&JR)

   - Resource Management and Training (RMT)

   - Policy and Procedures IMF (PPI)

   - Policy and Procedures BMF (PPB)

   - Technology Assistance and Stakeholder Communication (TASC)

   - Identity Protection Strategy and Oversight (IPSO)

   - Field Directors, AM


6. The symbols for AM are C:DC:TS:CAS:AM.

7. Visit AM at: Accounts Management.


**1.1.13.6.3.1** **(01-12-2024)**

##### Reports, Equipment, Phones (REP)

1. **Mission:** To provide program support through data, analysis and process improvements to Accounts Management (AM) headquarters and field directorates.

2. To accomplish the mission, Reports, Equipment, Phones (REP):



1. Provides input related to Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA), and National Taxpayer Advocate (NTA) audits/reports (as needed).

2. Represents AM on councils and steering committees specific to gathering data of areas impacting the Enterprise telephone or inventory environment.

3. Consolidates AM issues and status updates for weekly distribution to the Director, AM and Deputy Director, AM.


3. The Program Manager of REP reports to the Director, AM and Deputy Director, AM.

4. The following teams report to the Program Manager of REP:



1. Reports, Analysis and Data team (RAD)

2. Joint Operations Center Operating Division Rep (JOC Rep)

3. Equipment Request Telework Management (ERTM)


5. The office symbols for REP are C:DC:TS:CAS:AM:REP.


**1.1.13.6.3.1.1** **(01-12-2024)**

###### Reports, Analysis and Data (RAD)

1. **Mission:** To extract/compile data, prepare reports and provide feedback to headquarters personnel on the achievement of strategic operational measures.

2. To accomplish the mission, the RAD team:



01. Coordinates and controls the directorate mid-year and end-of-year assessments.

02. Develops reports to monitor the implementation of new procedures to assist headquarters (HQ) personnel in assessing the impact on program delivery.

03. Tracks achievement of Site Level Indicators and Measures (SLIM).

04. Monitors, tracks and reports inventory and telephone programs.

05. Monitors, tracks and reconciles all Accounts Management (AM) data (Work Planning and Control (WP&C), Correspondence Imaging System (CIS), Electronic Transmitted Documents (ETD), Accounts Management Inventory Report (AMIR), etc.).

06. Develops and distributes the Fiscal Year Program Letter.

07. Develops filing season readiness templates and coordinates filing season readiness certifications.

08. Prepares reimbursable reports.

09. Develops and provides assumptions for the inclusion in work plans and/or work schedules.

10. Updates and publishes annual revisions to IRM 1.4.16, Accounts Management Guide for Managers.

11. Develops and disseminates reports that track productivity, inventory and aged case levels.

12. Participates in site assistance visits, providing reports and necessary follow-up.


3. RAD reports to the Program Manager of REP.

4. The office symbols for RAD are C:DC:TS:CAS:AM:REP:RAD.


**1.1.13.6.3.1.2** **(01-12-2024)**

###### Joint Operations Center Operating Division Representative (JOC REP)

1. **Mission:** To Enhance the Accounts Management (AM) customer experience through collaboration with Joint Operations Center (JOC) to identify and resolve issues pertaining to telephone call routing and scripting, as well as, electronic media contacts; and, serve as liaison between a variety of internal and external stakeholders to ensure telephone and web-based automated systems, projects, and initiatives support the needs of the directorates and AM customers.

2. To accomplish the mission, the JOC Rep:



1. Identifies and resolves issues with the JOC pertaining to telephone call routing and scripting, as well as electronic media contacts as they impact AM customers.

2. Ensures AM interests are met regarding Integrated Customer Contact Environment (ICCE) and other automated interactive applications.

3. Provides support and business requirements relative to call routing to AM resources including the call centers.

4. Serves as the business liaison with Information Technology (IT) relative to the roll-out or development of new call center environment technology.

5. Identifies system or call processing deficiencies that negatively impact the customer experience and/or business results; works with the JOC to evaluate and implement solutions.

6. Identifies business requirements related to new initiatives or programs and works with internal and external stakeholders to ensure successful implementation of call routing strategies.

7. Provides program support to AM field offices.

8. Acts as the administrative support to the Contracting Officer’s Representative (COR) for AM contracts (i.e., National Telecommuting Institute (NTI), Over the Phone Interpreter (OPI), Bureau of the Fiscal Service (BFS)).


3. JOC Rep reports to the Program Manager of REP (Reports, Equipment and Phones).

4. The office symbols for JOC Rep are C:DC:TS:CAS:AM:REP:JOCREP.


**1.1.13.6.3.1.3** **(01-12-2024)**

###### **Equipment Requests and Telework Management (ERTM)**

1. **Mission:**To provide support and resolution through collaboration relative to the technology and telework environment. We serve as a liaison between a variety of internal stakeholders, including AM Directorates and Information Technology (IT), to ensure that they have the equipment and resources needed to achieve operational goals.

2. To accomplish the mission, ERTM:



1. Serves as the business liaison with Information Technology (IT) relative to EEFax technology.

2. Monitors and coordinates with headquarters (HQ) Facilities Management and Security Services (FMSS) and IT on equipment needs including developing plans and responding to requests from stakeholders.

3. Provides oversight and coordination as the HQ Point of Contact (POC) for Business Continuity for the AM campuses.

4. Acts as AM HQ liaison for the campus site coordinators to ensure consistency between AM and Submission Processing (SP).

5. Acts as the AM POC for the start-up of the Volunteer Income Tax Assistance (VITA) program at all campuses for campus employees to ensure consistency between AM and SP.

6. Provides support to the AM directorates for new hire equipment. Track New Hire headsets, laptops, and other peripheral equipment. Certify the correct above baseline software is loaded for each laptop for their specific job title (i.e., CSRs, TEs, and Clerks). Monitor, facilitate, and help perfect the UWR’s processed for each directorate, ensuring stakeholders are prepared for Fiscal Year hiring goals.

7. Provides oversight of laptop validations and compliance for all AM directorates to certify users are assigned only to the laptop issued.

8. Administer reports to all AM directorates to alert of any impact to the quality of calls between the IRS and customers, and safeguard the confidentiality, and integrity of IRS communications for those teleworking.


3. ERTM reports to the Program Manager of Reports, Equipment, and Phones (REP).

4. The office symbols for ERTM are C:DC:TS:CAS:AM:REP:ERTM.


**1.1.13.6.3.2** **(01-24-2023)**

##### Resource Management and Training (RMT)

1. The mission of Resource Management and Training (RMT) is to:



1. Provide optimal service to Accounts Management (AM) customers by best matching resources to meet customer demand.

2. Improve AM administrative business processes and organizational staffing by providing guidance and direction on modernization initiatives through a variety of major analytical studies, special projects, and assignments. More specifically, ensures campus and remote sites’ adherence to the organizational blueprint and monitors Authorized Staffing Patterns and their impact and progress towards achieving and maintaining the modernized end-state goals.

3. Manage the budget for AM and monitor resource usage across the enterprise.

4. Oversee the hiring and training of all AM employees.


2. To accomplish the mission, RMT:



1. Monitors and suggests actions to address AM’s achievement and adherence to the end state organizational blueprint.

2. Provides program support to AM field offices and participates in site visits to discuss and assist sites with any organizational structure issues.

3. Coordinates with Taxpayer Services (TS) Operation Support, Capital Management and Oversight (CMO) and the IRS Human Capital Office (HCO) to ensure any enterprise-wide AM issues are addressed and resolved.

4. Serves as the AM representative on teams and projects relative to campus ramp downs and business unit realignments.

5. Submits and reports on final outcomes of Requests for Organizational Change (ROC) for site realignments and organizational changes.

6. Coordinates, directs and/or reviews any item that relates to the organizational structures under the authority of the Director, AM.

7. Where delegated authority, makes decisions on organizational and position management issues under the authority of the Director, AM and commits AM to a particular course of action.

8. Represents AM on councils and steering committees, such as the Filing Season Readiness Executive Steering Committee (FSR ESC).


3. The Program Manager of RMT reports to Director, AM, and Deputy Director, AM.

4. RMT is comprised of the following teams:



   - Resource Planning and Scheduling (RPS)

   - Training


5. The office symbols for RMT are C:DC:TS:CAS:AM:RMT.


**1.1.13.6.3.2.1** **(01-24-2023)**

###### Resource Planning and Scheduling (RPS)

1. **Mission:**To develop, issue and monitor enterprise telephone schedules and adherence to meet agency goals; allocate and monitor inventory enterprise-wide while directing workflow based on agency needs and provide site level performance feedback; and, monitor budget expenditures, assess staffing resources and develop strategic hiring plans to ensure Fiscal Year goals are met.

2. To accomplish the mission, Resource Planning and Scheduling (RPS):



01. Provides telephone and inventory plans, schedules, and staffing requirements to all Accounts Management (AM) sites.

02. Monitors delivery of the staffing requirements via daily half-hourly tracking, e-Workforce Management (eWFM); and monitors financial/resource usage.

03. Performs filing season readiness activities related to staffing to meet workload needs.

04. Develops eWFM procedures for headquarters (HQ) and the AM field.

05. Identifies issues through monitoring staffing delivery and alerts the proper AM HQ organization for in-depth analysis and recommendations.

06. Collaborates with the Joint Operations Center (JOC) to optimize service delivery including site go to/go from decisions, tactical plans, developing level of service scenarios, ad-hoc data requests, work plan/schedule development, and ensuring site compliance with schedules.

07. Monitors resources and develops recommendations on seasonal hiring and release/recall for the telephone and inventory programs.

08. Monitors and approves overtime expenditures.

09. Adjusts resource spending/tracking plans based on program decisions from other AM HQ organizations.

10. Monitors overall inventory at the major program level, including the distribution of workload.

11. Implements recommendations developed by AM HQ program owners on detailed distribution of inventory workload and specialized programs.

12. Schedules site training and/or inventory days based on feedback from the field and AM HQ program owners.

13. Develops contingency plans for special events such as the weather closures, lapse of appropriations, or other events that impact staffing and workload.

14. Develops and implements the conversions of seasonal employees to permanent work schedules.

15. Partners with AM Training to develop and implement the annual Enterprise Skill-Up Plan.


3. RPS reports to the Program Manager of RMT.

4. The office symbols are C:DC:TS:CAS:AM:RMT:RPS.


**1.1.13.6.3.2.2** **(01-24-2023)**

###### Training

1. **Mission** of Training is to:



1. Identify Accounts Management (AM) training needs and work with the Learning and Education (L&E) AM Design Center to develop and deliver just-in-time training material. Develop supplemental training material during the year and post on Servicewide Electronic Research Program (SERP) Learning Tab.

2. Provide subject matter experts (SMEs) to L&E to revise and develop new training material (including updating e-learning products).

3. Collaborate with field offices in development and execution of planning period training plans to ensure training delivery and proper training hour expenditures.

4. Maintain and update online tools essential to effective and efficient training delivery.


2. To accomplish the mission, Training:



01. Identifies, develops, and updates training material, curricula, skill-paths, and daily training agendas by site and employee work type.

02. Coordinates with L&E on the development and review of all training materials.

03. Ensures all AM training material is written or revised to correspond with changes in tax law, policy, and IRM procedures.

04. Updates the AM Training Requirement Document, Annual Training Assumptions Document, Critical Filing Season Readiness Training (CFSRT) Guide and the AM Program Letter to ensure consistency and just-in-time training.

05. Ensures training materials match IRM procedures to provide "how-to" instructions for employees.

06. Collaborates with other headquarters (HQ) teams, the field and outside stakeholders to identify training needs.

07. Partners with Resource Management and Training (RMT) and Resource Planning and Scheduling (RPS) to develop and implement the annual Enterprise Skill-Up Plan.

08. In conjunction with field Planning and Analysis, develops training plans to monitor all training for all AM programs.

09. Provides program support to AM field offices.

10. Supports and monitors program effectiveness and training delivery in AM sites by on-site monitoring and review as needed.

11. Develops and updates training curricula by work type, identifies training course development and update needs, and coordinates with L&E on the development and review of the training material.

12. Coordinates AM training material delivery with Communications and Liaison (C&L), Return Integrity and Compliance Services (RICS), Field Assistance, Taxpayer Advocate Service (TAS), Criminal Investigation, Stakeholder Partnerships, Education and Communication (SPEC), external companies, and field sites to learn of new alternative delivery methods.

13. Coordinates the development of training materials by working with L&E to obtain SMEs from field sites, incorporating the drivers of quality performance into new course materials, course updates, refresher, and CFSRT materials.

14. Coordinates training efforts within the operating division.

15. Coordinates training development with L&E to ensure correct training is developed timely.

16. Provides guidance and SMEs for the preparation of training material.

17. Coordinates and conducts Continuing Professional Education (CPE) training for analysts, managers, systems administrators, and functional training coordinators.

18. Coordinates and monitors the Leadership Development Program (LDP) to ensure future leaders have access to, are scheduled for and attend various developmental training sessions during the program.

19. Maintains and updates online training tools such as Training database, On-line Certification Tool, LDP tools, T-mode simulations prior to the delivery of new hire and other skill-up training.


3. Training reports to the Program Manager of RMT.

4. The office symbols for Training are C:DC:TS:CAS:AM:RMT:T.


**1.1.13.6.3.3** **(01-24-2023)**

##### Policy and Procedures IMF (PPI)

1. **Mission:** To develop policy and procedural guidelines for all IMF Accounts Management (AM) programs and assess/implement program efficiencies to improve all balanced measures.

2. To accomplish the mission, Policy and Procedures IMF (PPI):



01. Writes IRM procedures related to specific program areas for both phone and paper inventories. This includes updates related to legislative changes, system/process changes, continuous improvement initiatives, and input from the field or other stakeholders such as Return Integrity Compliance Services, Taxpayer Advocate Service, etc. Following the procedural change, PPI monitors the implementation to determine potential impacts on program delivery.

02. Monitors, tracks, and completes AM-related action items associated with PPI programs resulting from executive level meetings/briefings.

03. Provides administrative support for the Director and Deputy Director, AM and program oversight to the AM campuses to ensure consistency, efficiency, and effectiveness of program delivery for those assigned to PPI. This includes preparing responses to internal and external stakeholders, providing information, preparing presentations, preparing for meetings, etc. on PPI programs and issues.

04. Collaborates with the AM field directorates to ensure PPI-related programs are efficient and best practices are identified and leveraged for sustained improvement.

05. Analyzes technical, operational, and administrative problems relating to PPI programs through RQ&JR and Resource Management and Training (RMT) assessments and reports. PPI works with the field through telephone conferences and site visits on issues such as IRM consistency/clarification, productivity, inventory levels, and aged case controls to ensure programs are efficient and taxpayers receive top-quality service.

06. Identifies issues related to quality and/or consistency through a variety of sources including work with the field, quality information from Process Improvement/Customer Accuracy (PICA), Contact Analytics, or stakeholders. PPI issues alerts through Servicewide Electronic Research Program (SERP) or other communication methods with the field to improve PPI work products or work streams.

07. Reviews and analyzes recommendations provided through the Taxpayer Advocacy Panel (TAP), SERP Feedback, Business Process Improvement (BPI) initiatives, or other initiatives or task forces on programs associated with PPI. Provides required feedback on adopt/non-adopt and updates and communicates the IRMs with the field.

08. Works with RMT Training on guidance for the preparation of training materials.

09. Coordinates the procedures for the Customer Satisfaction Survey used to capture information about the service AM provides to taxpayers. As a part of our goal to provide the best service possible to our taxpayers, feedback is solicited on all product lines. The survey allows the service to systematically collect and review satisfaction data directly from the taxpayers.

10. Partners with RMT Resource Planning and Scheduling (RPS) on work plan assumptions based on regular annual adjustments and legislative changes specific to PPI programs.

11. Serves as a point of contact for Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) for audits led by AM or when AM feedback/response is necessary. Activities include coordinating meetings/briefings with GAO/TIGTA for AM, as well as receiving, reviewing, and tracking GAO/TIGTA report findings/recommendations for AM.

12. Prepares responses to audit findings from TIGTA and GAO reports related to all PPI related issues and provides guidance on audit follow-up procedures; ensures necessary changes are implemented because of reports and findings.


3. The Program Manager of PPI reports to the Director, AM and Deputy Director, AM.

4. PPI is comprised of the following teams:



   - Individual Adjustments

   - Customer Technical Communications Program


5. The office symbols for PPI are C:DC:TS:CAS:AM:PPI.


**1.1.13.6.3.3.1** **(10-13-2021)**

###### Individual Adjustments

1. **Mission:** To support the mission of Accounts Management (AM) by developing policy, procedures, and guidelines for processing Individual Master File (IMF) related programs regardless of communication channel of the customer (paper or phone).

2. To accomplish the mission, Individual Adjustments:



1. Supports all activities identified by Policy and Procedures IMF (PPI) within specific scope of programs associated with IMF accounts.

2. Evaluates legislative changes, current policy decisions, process improvement suggestions, technical advice, and other sources to write or revise IRM procedures; develops IRMs for adjustments, math errors, refunds and other telephone assister related IRMs.

3. Coordinates program area activities related to IRM publishing and distribution; interacts with the Taxpayer Services (TS) AM IRM Coordinator and internal publishing services to ensure requirements are met and proper layout of paper and electronic version IRM pages; tracks field feedback on the IRM.

4. Works with the Chief Financial Officer (CFO) on TOP reimbursables.

5. Reviews, evaluates, coordinates and responds to employee suggestions on assigned program responsibilities.

6. Performs operational reviews on assigned programs to ensure consistency and accuracy within the sites.

7. Performs pre-coordination meetings with Information Technology (IT) counterparts and submits Unified Work Requests (UWRs) when necessary to update the assigned programs.

8. Prepares responses to audit findings from Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO) reports related to all programs assigned to the IMF team and provides guidance on audit follow-up responses; ensures necessary changes are implemented because of reports and findings.


3. Individual Adjustments monitors and improves paper inventory programs. Areas of responsibility include:



   - Adjustment Guidelines

   - General Math Errors

   - Referrals

   - Refund Research

   - Manual Refunds

   - Erroneous Refunds

   - Unpostables

   - Freeze Codes

   - Credit Transfers

   - Credits

   - Campus Support

   - IRMs including:


| **IRM Number** | **IRM Title** |
| :-: | :-: |
| IRM 21.1.1 | Accounts Management and Compliance Services Overview |
| IRM 21.1.2 | Reference Materials Overview |
| IRM 21.1.7 | Campus Support |
| IRM 21.3.1 | Taxpayer Contacts Resulting from Notice Issuance |
| IRM 21.3.5 | Taxpayer Inquiry Referrals Form 4442 |
| IRM 21.3.6 | Forms and Information Requests |
| IRM 21.4.1 | Refund Research |
| IRM 21.4.2 | Refund Trace and Limited Payability |
| IRM 21.4.3 | Returned Refunds/Releases |
| IRM 21.4.4 | Manual Refunds |
| IRM 21.4.5 | Erroneous Refunds |
| IRM 21.5.1 | General Adjustments |
| IRM 21.5.2 | Adjustment Guidelines |
| IRM 21.5.3 | General Claims Procedures |
| IRM 21.5.4 | General Math Error Procedures |
| IRM 21.5.5 | Unpostables |
| IRM 21.5.6 | Freeze Codes |
| IRM 21.5.7 | Payment Tracers |
| IRM 21.5.8 | Credit Transfers |
| IRM 21.5.10 | Examination Issues |
| IRM 21.6.1 | Filing Status and Exemption/Dependent Adjustments |
| IRM 21.6.2 | Adjusting TIN-Related Problems |
| IRM 21.6.3 | Credits |
| IRM 21.6.4 | Tax Computation / Accounting Period Changes |
| IRM 21.6.5 | Individual Retirement Arrangements (IRA), Coverdell Education Savings Accounts (ESA), Archer Medical Savings Accounts (MSA) and Health Savings Accounts (HSA) |
| IRM 21.6.6 | Specific Claims and Other Issues |
| IRM 21.6.7 | Adjusting Individual Tax Accounts |
| IRM 21.6.8 | Split Spousal Assessments |

4. Individual Adjustments reports to the Program Manager of PPI.

5. The office symbols for Individual Adjustments are C:DC:TS:CAS:AM:PPI:IA.


**1.1.13.6.3.3.2** **(10-13-2021)**

###### Customer Technical Communications Program (CTCP)

1. **Mission:** To create easy-to-use, plain language documents from IRMs and other sources of technical information. These documents are referred to as Technical Communication Documents (TCD) and are used in conjunction with the IRM, with the goal of reducing research time and improving quality. Requests for TCDs from individuals, focus groups, program managers, and IRM authors are considered when determining what TCDs will be produced.

2. To accomplish the mission, Customer Technical Communications Program (CTCP):



1. Monitors and analyzes quality reports for error trends.

2. Maintains a website to ensure easy access to TCDs and ensures the documents are publicized.

3. Requests input from IRM tax analysts, managers, customer service representatives, functional training coordinators, and instructors for new TCDs via Servicewide Electronic Research Program (SERP) Feedback, focus interviews, and site visits.

4. Distributes Correspondence Imaging System (CIS) Enterprise Management Inventory (EMI) to ensure work is distributed in first in first out, specialized order, and reviews the age of Unassigned Inventory (UA).


3. CTCP reports to the Program Manager of Policy and Procedures IMF.

4. The office symbols for CTCP are C:DC:TS:CAS:AM:PPI:CTCP.


**1.1.13.6.3.4** **(01-12-2024)**

##### Policy and Procedures BMF (PPB)

1. **Mission:** To develop policy and procedural guidelines for Policy and Procedures BMF (PPB) Accounts Management (AM) programs and assess/implement program efficiencies to improve balanced measures.

2. The Program Manager of PPB reports to the Director, AM and Deputy Director, AM.

3. Policy and Procedures BMF (PPB) is comprised of the following teams:



   - Specialty Accounts

   - Business Adjustments


4. PPB is responsible for dual Master File (i.e., IMF and BMF) of all applicable programs under PPB purview.

5. The office symbols for PPB are C:DC:TS:CAS:AM:PPB.


**1.1.13.6.3.4.1** **(01-12-2024)**

###### Specialty Accounts (SA)

1. **Mission:** To support the mission of Accounts Management (AM) by developing policy, procedures and guidelines for processing specialty account (SA) related issues including refund offsets, injured spouse allocations, Practitioner Priority Service (PPS), Taxpayer Advocate Service (TAS), AM Authentication, operational guidelines, systems and research, Centralized Authorization File (CAF), Accounts Maintenance Research Hold (AMRH), and Statutes.

2. To accomplish the mission, SA:



1. Supports all activities identified by Policy and Procedures BMF (PPB) related to specialty programs.

2. Evaluates legislative changes, current policy decisions, process improvement suggestions, technical advice, and other sources to write or revise IRM procedures.

3. Develops IRMs for all applicable programs under PPB:SA purview.

4. Coordinates activities related to IRM publishing and distribution; interacts with the Taxpayer Services (TS) AM IRM Coordinator and internal publishing services to ensure proper layout of paper and electronic version IRM pages, and tracks field feedback on the IRM.

5. Assists with training development efforts with Training and the Learning and Education (L&E) organization to ensure training is delivered using current materials.

6. Serves as subject matter expert (SME) for program assignments on cross-functional issues.

7. Serves as liaison to Bureau of the Fiscal Service (BFS) and other agencies to resolve Treasury Offset Program (TOP) problem cases.

8. Perform program reviews on assigned programs to ensure consistency and accuracy within the sites.

9. Prepares responses to audit findings from Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO) reports related to all programs assigned to SA and provides guidance on audit follow-up responses; ensures necessary changes are implemented because of reports and findings.


3. Specialty Accounts monitors and makes suggestion for improvement, including coordination with other responsible AM headquarters stakeholders, to improve programs under areas of responsibility, which include:



   - Third Party Authorizations

   - Centralized Authorization File (CAF)

   - Practitioner Priority Services (PPS)

   - Refund offsets including tax and non-tax offsets

   - Form 8379, Injured Spouse Allocation

   - Statutes

   - Operational Guidelines

   - Disclosure

   - Integrated Automation Technology (IAT) Tools

   - Taxpayer Advocate Service (TAS)

   - Accounts Maintenance Research Transcripts (AMRH)

   - IRMs include:


| **IRM Number** | **IRM Title** |
| :-: | :-: |
| IRM 21.1.3 | Operational Guidelines Overview |
| IRM 21.2.1 | Systems |
| IRM 21.2.2 | Research |
| IRM 21.2.3 | Transcripts |
| IRM 21.2.4 | Master File Accounts Maintenance |
| IRM 21.3.7 | Processing Third-Party Authorizations onto the Centralized Authorization File (CAF) |
| IRM 21.3.10 | Practitioner Priority Service (PPS) |
| IRM 21.4.6 | Refund Offset |
| IRM 25.6.1 | Statute of Limitations Processes and Procedures |

4. Specialty Accounts reports to the Program Manager of PPB.

5. The office symbols for Specialty Accounts are C:DC:TS:CAS:AM:PPB:SA.


**1.1.13.6.3.4.2** **(01-12-2024)**

###### Business Adjustments (BA)

1. **Mission:** To support the mission of Accounts Management (AM) by developing policy, procedures, and guidelines for resolving and processing Business Adjustments (BA) related issues.

2. To accomplish the mission, BA:



01. Evaluates legislative changes, current policy decisions, process improvement suggestions, technical advances, and other sources to write or revise IRM procedures.

02. Partners with applicable AM headquarters stakeholders on issues or suggestions impacting BA related programs.

03. Coordinates activities related to IRM publishing and distribution; interacts with the Taxpayer Services (TS) AM IRM Coordinator and Media & Publications (M&P) to ensure requirements are met and proper layout of paper and electronic IRM pages; tracks field feedback on the IRM.

04. Assists with training development efforts with RMT, Training and the Learning and Education (L&E) organization to ensure training is delivered using current materials.

05. Develops IRM procedures for Employer Identification Number (EIN) assignment, business tax returns, BMF duplicate filing conditions, adjustments, Individual Master File (IMF)/BMF International, carrybacks, (IMF/BMF-International/Domestic), US Certifications, Tax Exempt and Government Entities (TE/GE) phone operations, as well as other AM telephone and paper programs related to business and certain individual adjustments.

06. Reviews, evaluates, coordinates and responds to process improvement suggestions on assigned program responsibilities.

07. Performs program reviews on assigned programs to ensure consistency and accuracy within the sites.

08. Performs pre-coordination meetings with Information Technology (IT) counterparts, submits Unified Work Requests (UWRs) when necessary to update assigned programs. Also performs production testing and acts as TS representation on IT coordinated pre and post release calls.

09. Prepares responses to audit findings from Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO) reports related to all programs assigned to BA and provides guidance on audit follow-up responses; ensures necessary changes are implemented because of reports and findings.

10. Partners with Large Business and International (LB&I), Small Business/Self-Employed (SB/SE), TE/GE and Competent Authority on a regular basis to ensure seamless program delivery where policy is created by an operating division other than TS for AM employees in the field.

11. Acts as SMEs for assigned programs in external stakeholder meetings with Information Reporting Program Advisory Committee (IRPAC), Internal Revenue Service Advisory Council (IRSAC), Social Security Administration (SSA), Census Bureau, and Quarterly Reporting Agent File (RAF) Conferences.

12. Performs technical review for accuracy as it relates to assigned programs including Technical Communications Documents (TCDs), Servicewide Electronic Research Program (SERP) stand-alone pages (Telephone Transfer Guide (TTG), Carryback 45-Day Interest Free charts, Sequestration, etc.,) and new or revised Integrated Automated Technologies (IAT) tools.

13. Provides guidance and coordinates cross functionally, if needed, to elevated cases from campuses on complex problems.


3. Business Adjustments area of responsibility include:



01. Processing Reporting Agent File (RAF) Authorizations

02. Business filing 94X

03. Assigning Employer Identification Numbers (EINs), including Mod-IEIN

04. Carrybacks (IMF/BMF-International/Domestic)

05. Business duplicate filing conditions

06. Business income taxes

07. TE/GE telephone operations

08. General Correspondence guidance (IMF/BMF)

09. International (IMF and BMF)

10. US Certifications

11. Non-Master File (NMF) operations (IMF and BMF)

12. IRC 965 AM casework (IMF/BMF)

13. IRMs including:


| **IRM Number** | **IRM Title** |
| :-: | :-: |
| IRM 21.3.3 | Incoming and Outgoing Correspondence/Letters |
| IRM 21.3.8 | Tax Exempt/Government Entities (TE/GE) Customer Account Services (CAS) Telephone Operations |
| IRM 21.3.9 | Processing Reporting Agents File Authorizations |
| IRM 21.5.9 | Carrybacks |
| IRM 21.5.13 | 965 Transition Tax Procedures-Accounts Management |
| IRM 21.7.1 | BMF/NMF Miscellaneous Information |
| IRM 21.7.2 | Employment and Railroad Tax Returns |
| IRM 21.7.3 | Unemployment Taxes |
| IRM 21.7.4 | Income Taxes/Information Returns |
| IRM 21.7.9 | BMF Duplicate Filing Conditions |
| IRM 21.7.10 | No-Merge Cases |
| IRM 21.7.11 | Additional Computer Paragraph Notices and Transcripts |
| IRM 21.7.12 | Non-Master File (NMF) Adjustments |
| IRM 21.7.13 | Assigning Employer Identification Numbers (EINs) |
| IRM 21.8.1 | IMF International Adjustments |
| IRM 21.8.2 | BMF International Adjustments |
| IRM 21.8.4 | United States Certification for Reduced Tax Rates in Tax Treaty Countries |
| IRM 21.8.5 | Miscellaneous Foreign Investment in Real Property Tax Act (FIRPTA) Related Issues |
| IRM 21.8.6 | Exemptions from US Withholding (Form 8233) |

4. Business Adjustments reports to the Program Manager of PPB.

5. The office symbols for Business Adjustments are C:DC:TS:CAS:AM:PPB:BA.


**1.1.13.6.3.5** **(01-24-2023)**

##### Technology Assistance and Stakeholder Communication (TASC)

1. **Mission:**To provide direct support to all employees by developing and deploying innovative electronic tools that enable employees to accurately and efficiently help taxpayers understand and comply with applicable procedures and tax laws; provide Correspondence Imaging System (CIS) technical guidance and process support to Accounts Management (AM) headquarters (HQ), the field, and other functional areas; and, provide direct support to employees by publishing documents and developing tools that reduce research time and improve quality.

2. To accomplish the mission, Technology Assistance and Stakeholder Communication (TASC):



1. Develops, implements, and maintains the business requirements for the Servicewide Electronic Research Program (SERP).

2. Develops, delivers and maintains a variety of internal and external tax law assistance tools.

3. Provides a variety of tools and procedural guidelines to assist managers and technicians to provide efficient taxpayer service.

4. Provides administrative support to the Director, AM, including preparing responses to internal and external stakeholders, providing information, preparing presentations, preparing for meetings, etc.

5. Assists with the Enterprise Management of Inventory (EMI) by balancing inventories in support of site specialization through mass reassignment of cases across campuses.

6. Gathers requirements and then prepares and submits Maintenance Update Requests (MURs) and Unified Work Requests (UWRs) to Information Technology (IT) for modifications to CIS.

7. Identifies, analyzes, and collaborates with IT to resolve CIS technical issues.

8. Provides custom inventory information to wide variety of customers.

9. Evaluates employee suggestions related to CIS.


3. The Program Manager of TASC reports to Director, AM, and Deputy Director, AM.

4. The following report to the Chief, TASC:



   - SERP Communication Program (SCP)

   - Rules Based Program Office (RBPO)


5. The office symbols for TASC are TASC.


**1.1.13.6.3.5.1** **(10-13-2021)**

###### Servicewide Electronic Research Program (SERP) Communication Program (SCP)

1. **Mission:** To provide employees from all IRS functions intranet access to IRMs and other reference materials, and the ability to easily retrieve frequently referenced documents required to perform their jobs. These materials are provided via SERP. The SCP staff works closely with Media and Publications, the Alternative Media Center, authors of technical information such as IRMs, local Site Coordinators, and other areas throughout the Service to ensure the most current information is always available.

2. To accomplish the mission, Servicewide Electronic Research Program (SERP) Communication Program (SCP):



1. Works with the operating divisions to ensure they are familiar with SERP submission procedures.

2. Participates in the operating divisions’ process for issuing IRMs, other published documents, alerts and update releases.

3. Works with the product owners for timely release of information.

4. Works with the end users through a feedback process to ensure their needs are being met.

5. Acts as liaison between authors of technical documents and the end users to ensure information available is accurate.

6. Provides employees the most expedient access possible to information required to perform their job.

7. Facilitates an annual certification process with all IRM authors and SERP content owners to certify their IRM and/or content are current.

8. Acts as liaison between authors and Content Management Application (CMA) Coordinators for [IRS.gov](https://www.irs.gov/) to ensure interim guidance issued through SERP, which meets electronic Freedom of Information Act criteria, is posted to [IRS.gov.](https://www.irs.gov/)

9. Reviews, evaluates and coordinates employee suggestions pertaining to the SERP website and its contents.


3. The SERP website provides a research service to all operating divisions. The content on the site includes:



   - IRMs and IRM procedural updates

   - Correspondex (Integrated Data Retrieval System) Letters

   - Links to forms and publications

   - Information Alerts

   - Job Aids

   - Supplemental information/documents developed by authorized submitters

   - Contact listings

   - Links to frequently used sites

   - Content specific portals


4. SERP also maintains the Telephone Transfer Guide (TTG) and ensures it is updated with the latest call transfer topics and numbers.

5. SERP reports to the Program Manager of Technology Assistance and Stakeholder Communication (TASC).

6. The office symbols for SCP are C:DC:TS:CAS:AM:TASC:SCP.

7. Visit SERP at: http://serp.enterprise.irs.gov/content/who-is-serp.html.


**1.1.13.6.3.5.2** **(10-13-2021)**

###### Rules Based Program Office (RBPO)

1. **Mission:** To develop and maintain Interactive Tax Law Assistant (ITLA) on the IRS intranet; Interactive Tax Assistant (ITA) on IRS.gov, Tax Law FAQs, Tax Topics and Tax Trails; and, Accounts Management (AM) content management on IRS.gov.

2. To accomplish the mission, Rules Based Program Office (RBPO):



01. Collects and tracks tax law changes to ensure updates are made to all tools.

02. Reviews, evaluates and coordinates employee suggestions.

03. Reviews and analyzes trend data.

04. Analyzes reports such as Google Analytics and Contact Analytics.

05. Determines workload prioritization on Tax Law Categories (TLC) development and maintenance.

06. Coordinates communication of ITLA/ITA processes between AM and other areas such as Field Assistance, ETA, Legislative Affairs, Communications and Liaison (C&L), Counsel, and Media and Publications (M&P).

07. Facilitates the ITLA/ITA deployment process through Information Technology (IT).

08. Customizes and deploys internal and external TLCs.

09. Manages and controls rule based functionality.

10. Monitors application performance and system enhancements.

11. Collaborates with and responds to audits from Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO), providing guidance on audit follow-ups and ensuring necessary changes are implemented because of agreed-to findings.


3. RBPO reports to the Program Manager of Technology Assistance and Stakeholder Communication (TASC).

4. The office symbols for RBPO are C:DC:TS:CAS:AM:TASC:RBPO.


**1.1.13.6.3.6** **(04-19-2018)**

##### Identity Protection Strategy and Oversight (IPSO)

1. **Mission:** To maintain enterprise-wide identity protection program oversight. This includes internal outreach to all business units (BUs) to ensure the established policies are implemented and supported Servicewide; develop policy, procedures, and guidelines for resolving individual taxpayer accounts upon contact from a victim of identity theft (IDT) or Return Preparer Misconduct (RPM); develop Servicewide policy and procedural guidance related to the protection of taxpayer identities to maintain the integrity of individual and business tax accounts and of the tax system; Identify Servicewide risks and reduce vulnerabilities for IDT in tax administration to reduce taxpayer burden.

2. To accomplish the mission, Identity Protection Strategy and Oversight (IPSO):



01. Works with Return Integrity and Compliance Services (RICS), Criminal Investigation, Compliance, and/or Privacy, Governmental Liaison and Disclosure (PGLD) on identifying new work streams and processes to deal with refund fraud, questionable refunds, and/or IDT.

02. Builds programs to reduce incidents of IDT such as the Identity Protection Personal Identification Number (IP PIN) and the IDT unpostable process.

03. Raises taxpayer awareness of IDT techniques through outreach.

04. Reduces taxpayer burden and improving service options while addressing and resolving IDT cases.

05. Protects Treasury revenue by identifying suspicious filings before the refunds are generated.

06. Increases operational efficiency of the IRS by detecting and processing reported IDT incidents as early and consistently as possible.

07. Identifies emerging trends and develops proper strategies and responses.

08. Develops, defines, monitors, and executes IDT policies and procedures.

09. Communicates and coordinates with both internal and external stakeholders (such as the Federal Trade Commission) to ensure consistency with IDT issues.

10. Determines IDT performance measures to assess the effectiveness of the program and IDT initiatives throughout the IRS and makes recommendations for improvement.

11. Oversees the maintenance, publication, and conveyance of the Servicewide IDT guidance via the Identity Protection and Victim Assistance IRM ensuring the information remains current.

12. Conducts IDT program reviews, which include, but are not limited to: IRM reviews to verify procedural consistency and closed case reviews to ensure adherence to Servicewide policies and procedures.

13. Evaluates new technologies and assesses benefits for use in IDT initiatives.

14. Defines, communicates and assigns responsibility for the IRS’ substantiated identity theft incident tracking program,

15. Participates in risk assessments on IRS business processes, where appropriate.


3. The Program Manager of IPSO reports to Director, Accounts Management (AM) and Deputy Director, AM.

4. IPSO is comprised of the following teams:



   - Identity Theft Victim Assistance (ITVA)

   - Identity Protection (IP) teams


5. The office symbols for IPSO are C:DC:TS:CAS:AM:IPSO.

6. Visit IPSO at: Identity Protection Strategy & Oversight (IPSO).


**1.1.13.6.3.6.1** **(01-12-2024)**

###### Identity Theft Victim Assistance (ITVA)

1. **Mission:** To develop policy, procedures, and guidelines for resolving individual taxpayer accounts upon contact from a victim of identity theft (IDT) or Return Preparer Misconduct (RPM). Identity Theft Victim Assistance (ITVA) issues guidance for researching accounts based on a return or claim from an apparent victim, correcting accounts when IDT or RPM is substantiated, and communicates with victims.

2. ITVA supports the IDTVA campus operations, BMF IDT Teams, IDT, and the Taxpayer Protection Program (TPP) toll-free product line through:



   - Oversight of IDTVA campus procedures and activities.

   - Oversight of the toll-free IDT product line procedures.

   - Collaboration with Return Integrity and Compliance Services (RICS) for the TPP toll-free line.

   - Support Identity Protection Strategy and Oversight (IPSO)/Identity Protection (IP) activities within the scope of programs associated with victim assistance.

   - Evaluation of legislative changes in current policy decisions, process improvement suggestions, technical advice, and other sources to write or revise IRM procedures.

   - Support of the development and implementation of Business Master File (BMF) IDT and RPM procedures.


3. To accomplish the mission, ITVA:



1. Writes and updates IRM 25.23 and IRM 25.24 as needed to enhance program efficiency and effectiveness. This includes updates related to legislative changes, system/process changes, continuous improvement initiatives, and input from the field or other stakeholders such as Compliance, Taxpayer Advocate Service, etc. Following the procedural change, ITVA monitors the implementation to determine potential impacts on program delivery.

2. Supports all activities identified by IPSO for programs associated with victim assistance.

3. Collaborates with and responds to audits from Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO), providing guidance on audit follow-ups and ensuring necessary changes are implemented because of agreed-to findings.

4. Completes site reviews to gain employee feedback on program procedures and provides the site input on case reviews.

5. Works with IDTVA to reduce burden of the IDT/RPM victim and the employees in IDTVA.

6. Works with BMF AM to reduce burden of the BMF IDT victim and the employees in the BMF IDT teams.

7. Monitors and improves programs involving the following IRMs:




      | **IRM Number** | **IRM Title** |
      | :-: | :-: |
      | IRM 25.23.3 | IMF Non-Tax-Related IDT and Specialized Programs |
      | IRM 25.23.4 | IDTVA Paper Process |
      | IRM 25.23.10 | Compliance Identity Theft Case Processing |
      | IRM 25.23.11 | Business Master File (BMF) Identity Theft Procedures for Accounts Management |
      | IRM 25.23.12 | IMF Identity Theft Toll-Free Guidance |
      | IRM 25.24.1 | Return Preparer Misconduct Victim Assistance - General Overview |
      | IRM 25.24.2 | Return Preparer Misconduct Victim Assistance Specialized Accounts Management Processing |
      | IRM 25.23.13 | Identity Protection and Victim Assistance- Income Related Identity Theft |


4. ITVA reports to the Program Manager of Identity Protection Strategy and Oversight.

5. The office symbols for ITVA are C:DC:TS:CAS:AM:IPSO:ITVA.

6. Visit ITVA at: IDTVA Home.


**1.1.13.6.3.6.2** **(10-13-2021)**

###### Identity Protection (IP)

1. **Mission:** To provide policy guidance related to the protection of taxpayer identities to maintain the integrity of individual tax accounts and of the tax system; and, formulate short and long-range program policy guidance, procedures, strategies and objectives to protect taxpayer identities and to ensure the ability of taxpayers to meet their tax obligations is not restricted.

2. To accomplish the mission, Identity Protection (IP):



01. Provides guidance and assistance and coordinates program activities with the Director and Deputy Director, Accounts Management (AM) to prepare Servicewide policy guidance and address changes in procedural instruction.

02. Designs and develops programs to solve routine and complex customer account and tax-related issues dealing with identity protection.

03. Collaborates extensively Servicewide and with other agencies to ensure resources and information are shared effectively and efficiently.

04. Constantly monitors and analyzes incidents involving potential or real identity threats for trends and gaps in programs.

05. Builds programs to reduce incidents of identity theft (IDT) such as the Identity Protection Personal Identification Number (IP PIN) and the IDT unpostable process.

06. Raises taxpayer awareness of IDT techniques through outreach.

07. Increases operational efficiency of the IRS by detecting and processing reported IDT incidents as early and consistently as possible.

08. Develops, defines, monitors, and executes IDT policies and procedures.

09. Communicates and coordinates with both internal and external stakeholders (such as the Federal Trade Commission) to ensure consistency with IDT issues.

10. Determines IDT performance measures to assess the effectiveness of the program and IDT initiatives throughout the IRS and makes recommendations for improvement.

11. Evaluates new technologies and assesses benefits for use in IDT initiatives.

12. Collaborates with and responds to audits from Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO), providing guidance on audit follow-ups and ensuring necessary changes are implemented because of agreed-to findings.

13. Monitors and improves programs involving the following IRMs:


| **IRM Number** | **Title** |
| :-: | :-: |
| IRM 25.23.1 | Identity Protection and Victim Assistance - Policy Guidance |
| IRM 25.23.2 | Identity Protection and Victim Assistance - General Case Processing |
| IRM 25.23.9 | BMF Identity Theft Processing |

3. IP reports to the Program Manager of Identity Protection Strategy and Oversight.

4. The office symbols for IP are C:DC:TS:CAS:AM:IPSO:IP.


**1.1.13.6.3.7** **(04-19-2018)**

##### Field Directors, Accounts Management

1. **Mission:** To provide top-quality customer service by timely and efficiently responding to taxpayer questions, helping them understand and meet their tax responsibilities and enforcing the law with integrity and fairness to all.

2. To accomplish the mission, the Field Directors, Accounts Management:



01. Provide executive leadership and direction for paper, electronic and telephone inquiry programs through subordinate managers in call sites located within their directorate.

02. Assist AM headquarters (HQ) with the formulation of short and long-range program policy guidance, procedures, strategies and objectives.

03. Provide guidance, assistance and direction to call centers within their directorate to ensure timely, accurate and efficient program delivery.

04. Provide guidance, assistance and coordinate program activities with the Director and Deputy Director, AM, to prepare Servicewide policy guidance, address cross-functional issues, develop strategies, and ensure consistency of approach.

05. Ensure subordinate managers operate as an effective management team and all management functions are handled in an equitable and responsive manner to meet the needs of the customers.

06. Coordinate with AM HQ on the development of resource planning schedules.

07. Take a lead role in the development of their subordinate managers, promoting a sound succession planning process for AM.

08. Assist their subordinate manager in the resolution of complex issues.

09. Interact with other functions and operating divisions for shared service needs (recruiting, facilities, etc.).

10. Coordinate with personnel and other business units (BUs) represented at their respective campuses.

11. Assume the duties of a Senior Commissioner Rep (SCR) in consolidated sites.

12. Foster an inclusive environment where everyone is valued, has a voice in the workplace and serves employees and the public with the highest level of ethics, integrity and excellence.


3. The Field Directors, AM report to Director, AM and Deputy Director, AM.

4. The following report to the Field Directors, AM:



   - Campus Operations

   - Remote Operations

   - Planning and Analysis

   - Site Coordinator (in consolidated sites)


5. The office symbols for Field Directors, AM are as follows:



   - Andover - C:DC:TS:CAS:AM:AN

   - Atlanta - C:DC:TS:CAS:AM:AT

   - Austin - C:DC:TS:CAS:AM:AU

   - Brookhaven - C:DC:TS:CAS:AM:B

   - Cincinnati - C:DC:TS:CAS:AM:C

   - Fresno - C:DC:TS:CAS:AM:F

   - Kansas City - C:DC:TS:CAS:AM:KC

   - Memphis - C:DC:TS:CAS:AM:M

   - Ogden - C:DC:TS:CAS:AM:O

   - Philadelphia - C:DC:TS:CAS:AM:P

   - IDTVA - C:DC:TS:CAS:AM:IDTVA(AN)


**1.1.13.6.3.7.1** **(04-19-2018)**

###### Campus Operations

1. **Mission:** To provide taxpayers with top-quality customer service by responding to taxpayer questions, helping them understand and meet their tax responsibilities and enforcing the law with integrity and fairness to all. Program responsibilities include:



   - Toll-free Telephones

   - Adjustments and Correspondence

   - Practitioner Priority Services (PPS)

   - Taxpayer Relations

   - Employer Identification Numbers (EIN), Internet EIN (IEIN), Practitioner Taxpayer Identification Number (PTIN)

   - Centralized Authorization File (CAF) and Power of Attorney (POA)

   - Reporting Agent File (RAF)

   - International Programs (Ogden, Cincinnati and Philadelphia only)

   - Correspondence Imaging System (CIS) Clerical Support and other related activities

   - Campus Mail Support (in consolidated sites)


2. To accomplish the mission, Campus Operations:



1. Provides leadership and direction for paper, electronic and telephone inquiry programs through subordinate managers.

2. Participates in the formulation of short and long-range program policy guidance, procedures, strategies and objectives.

3. Provides guidance, assistance and direction to the call center to ensure timely, accurate and efficient program delivery.

4. Ensures subordinate managers operate as an effective management team and all management functions are handled in an equitable and responsive manner to meet the needs of the customers.

5. Supports the development of subordinate managers and assists them in the resolution of complex issues.

6. Interacts with other functions and operating divisions for shared service needs (recruiting, facilities, etc.) represented at their respective campuses.


3. The managers of Campus Operations report to Field Directors, Accounts Management (AM).


**1.1.13.6.3.7.2** **(01-24-2023)**

###### Remote Operations

1. **Mission:** To provide taxpayers with top-quality customer service by responding to taxpayer questions, helping them understand and meet their tax responsibilities and enforcing the law with integrity and fairness to all. Program responsibilities include:



   - Toll-Free Telephones

   - Special telephone programs on an as needed basis (e.g., disaster assistance, Practitioner Priority Service (PPS), National Taxpayer Advocate (NTA), identity theft (IDT), International Tax Law, Taxpayer Assistance Center (TAC) appointments, etc.)

   - Referring taxpayers to online tools at [IRS.gov](https://www.irs.gov/) for tax law assistance including Interactive Tax Assistant (ITA) Tool, Frequently Asked Questions and Answers (FAQs), and Tax Topics


2. To accomplish the mission, Remote Operations:



1. Provides leadership and direction for telephone inquiry programs through subordinate managers.

2. Participates in the formulation of short and long-range program policy guidance, procedures, strategies and objectives.

3. Provides guidance, assistance and direction to the call center to ensure timely, accurate and efficient program delivery.

4. Ensures subordinate managers operate as an effective management team and handle all management functions in an equitable and responsive manner to meet the needs of the customers.

5. Supports the development of subordinate managers and assist them in the resolution of complex issues.

6. Interacts with other functions and operating divisions for shared service needs (recruiting, facilities, etc.) represented at their respective remote location.


3. The managers of Remote Operations report to Field Directors, Accounts Management (AM).


**1.1.13.6.3.7.3** **(12-21-2018)**

###### Planning and Analysis

1. **Mission:** To provide support to the Field Directors, Accounts Management (AM), ensuring service policies, programs and procedures are applied uniformly and efficiently.

2. To accomplish the mission, Planning and Analysis:



01. Analyzes processes to identify and resolve systemic and procedural problems.

02. Conducts conformance reviews and site assistance visits, prepares reports, and validates site performance.

03. Reports on progress toward delivering the assigned program goals, as well as objectives and measures.

04. Monitors and reports on program delivery to ensure quality, consistency and goals are met.

05. Provides oversight that facilitates the timely accomplishment of all program goals and objectives.

06. Coordinates specific projects or programs for the Field Director, AM.

07. Disseminates and consolidates responses to Field Director’s controls received from the Director or Deputy Director, AM, or other areas.

08. Organizes and monitors implementation of new programs.

09. Manages site inventory.

10. Serves as the central point of contact for work plan and budgetary matters.

11. Assists with business unit site assistance visits.

12. Coordinates and supports AM Resource Management and Training (RMT) on issues related to the directorate’s organizational structures.

13. Monitors business results and makes recommendations to assist in the formulation of short and long-range program policy guidance, strategies and objectives.

14. Assists with the coordination of program activities to address cross-functional issues, develop strategies, and ensure consistency of approach.

15. Ensures functional programs follow all existing quality policies and procedures and strives to improve the accuracy and timeliness of responses.

16. Conducts statistical analysis and evaluation of the elements comprising AM balanced measures.

17. Works with Customer Account Services (CAS) Finance to monitor resources and project needs.

18. Interacts with other functions and operating divisions for shared service needs (recruiting, facilities, etc.).

19. Coordinates with local support functions (e.g., Facilities Management and Security Services (FMSS), Personnel Services) and other business units (BUs) represented at their respective campuses.

20. Maintains the process for evaluative individual quality reviews, Centralized Evaluative Review (CER).


3. The program managers of Planning and Analysis report to Field Directors, AM.


**1.1.13.6.3.7.3.1** **(04-19-2018)**

###### Telephone Systems Support

1. **Mission:** To provide support to the Field Directors, Accounts Management (AM), ensuring adherence to schedules by monitoring and managing the Automated Call Distributor.

2. To accomplish the mission, Telephone Systems Support:



1. Reviews planning period requirements and provides staffing projections to the business unit/Joint Operations Center (JOC).

2. Coordinates telephone staffing reductions/adjustments with the business unit/JOC.

3. Plans adherence to half-hourly staffing schedules for all applications to meet phone demand and ensure adherence to the schedules.

4. Monitors application performance and manages the workforce to meet fluctuations of actual demand.

5. Monitors the system and reports systems problems to JOC.

6. Provides reports to improve efficiency.


3. The managers of Telephone Systems Support report to Planning and Analysis.


**1.1.13.6.3.7.4** **(12-21-2018)**

###### Site Coordinator

1. **Mission:** To provide the primary support for cross-unit coordination and collaboration involving major activities across multi-organizational functional and operations reporting structures in a campus environment and provide administrative support where a central point of contact on campus adds value. The Site Coordinator provides direct support to the Senior Commissioner’s Representative (SCR), the Accounts Management (AM) Field Director, especially concerning but not limited to, dealing with rapid response/emergency situations on campus including the coordination of all incident management planning and implementation.

2. To accomplish the mission, the Site Coordinators:



1. Provide primary support for cross-unit coordination by overseeing major activities that affect multiple functions with different reporting structures, ensuring cross-functional cooperation, coordination and consistency.

2. Serve as a primary liaison to ensure administrative and logistical support is provided to all campus entities by working with Information Technology (IT), Facilities Management and Security Services (FMSS) and other supporting organizations.

3. Serve as the liaison between all campus organizations in the development of administrative policies and practices and communicate and disseminate campus-wide decisions, policies and procedures.

4. Ensure the needs of the Deaf and Hard of Hearing (DHOH) community are addressed through scheduling requested interpreter services for meetings, training, or any function at which the DHOH employee is present on campus.


3. The Site Coordinators report to Field Directors, AM.


**1.1.13.6.3.8** **(01-12-2024)**

##### Account Management Operations Support (AMOS)

1. **Mission:**To provide program support through data, analysis and quality process improvements to Accounts Management (AM) headquarters, field directorates and other business units.

2. To accomplish the mission, the Account Management Operations Support (AMOS) staff:



1. Consolidates and provides input related to Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA), and National Taxpayer Advocate (NTA) audits/reports (as needed).

2. Monitors, tracks, and completes AM related action items resulting from executive level meetings/briefings.

3. Provides administrative support for the Director and Deputy Director, AM including preparing responses to internal and external stakeholders, providing information, preparing presentations, preparing for meetings, etc.

4. Foster an inclusive environment where everyone is valued, has a voice in the workplace and serves employees and the public with the highest level of ethics, integrity and excellence.

5. Support Accounts Management (AM) programs by identifying collaborative organizational partners, coordinating resources strategically, and tracking improvement processes to help deliver results for America’s Taxpayers.

6. Provide program support and coordination to the other AMHQ teams.

7. Coordinate and track Congressional Inquiries, Industry reach-ins, and internal inquiries.

8. Coordinate and track Hear Me/ Customer Early Warning System (CEWS), New Legislation, National Telecommuting Institute (NTI) and Taxpayer Relations (TPR) action items. The Program Manager of AMOS serves as the Project Manager for the NTI contract.

9. Consolidate information provided for Operational Reviews, Taxpayer Advocacy Panel Project Referral Program (TAP), Most Serious Problems (MSP), and Business Performance Review (BPR).


3. The Program Manager of AMOS reports to the Director, AM and Deputy Director, AM.

4. AMOS is comprised of the following teams:



   - Program Management and Coordination (PMC)

   - Process Improvement/Customer Accuracy (PICA)


5. The office Symbols for AMOS are C:DC:TS:CAS:AM:AMOS.


**1.1.13.6.3.8.1** **(01-12-2024)**

###### Program Management and Coordination (PMC)

1. **Mission:**To support Accounts Management (AM) programs by identifying collaborative organizational partners, coordinating resources strategically, and tracking improvement processes to help deliver results for America’s Taxpayers.

2. To accomplish the mission, Program Management and Coordination (PMC):



1. Provides program support and coordination to the other Accounts Management headquarter (AMHQ) teams

2. Coordinate and track the following:


       • Congressional Inquiries


       • Industry Reach ins


       • Internal (Exec Staff) Inquiries


       • Hear Me/Customer Early Warning System (CEWS) (AM)


       • New Legislation


       • Taxpayer Relations (TPR) action items


       • AM Inventory process improvements

3. Consolidate information provided for data class for the following:


       • Op Reviews


       • Commissioner Updates


       • Taxpayer Advocacy Panel Project Referral Program (TAP)


       • Most Serious Problems (MSP)


       • Business Performance Review (BPR) request


       • Electronic Tax Administration Advisory Committee (ETAAC)


       • Internal Revenue service Advisory Council (IRSAC)


       • Questions For the Record (QFR)

4. Coordinating volunteers from AM sites to the local offices for Taxpayer Experience Days.

5. Coordinating the approval of AM topics, staff, and travel for National Taxpayer Forums (NTF) between AMHQ, CAS and C&L


3. PMC reports to the Program Manager of AMOS.

4. The office symbols for PMC are C:DC:TS:CAS:AM:AMOS:PMC.


**1.1.13.6.3.8.2** **(01-12-2024)**

###### Process Improvement/Customer Accuracy (PICA)

1. **Mission:**To provide quality and process improvement support to all Accounts Management (AM). Process Improvement/Customer Accuracy (PICA) analysts utilize and maintain the National Quality Review System (NQRS) and Evaluative Quality Review System (EQRS) Data Collection Instruments (DCIs) to achieve a set level (goal) of phone and paper quality; providing statistical data, program support and trend analysis to improve customer accuracy and ensure the AM enterprise quality measures are met.

2. To accomplish the mission, PICA:



01. Provides clarification and guidance to the field directorates on procedural issues that improve work processes, quality and level of service for the taxpayer.

02. Develops AM business unit and site level program quality targets.

03. Measures and reports progress toward delivering program targets.

04. Champions quality initiatives by providing guidance, oversight and training to the Process Improvement Specialists in the field.

05. Monitors the implementation of new procedures to assess impact to program delivery.

06. Monitors quality of AM telephone and paper inventory programs, identifies trends, and if necessary, advises site of changes required to deliver higher quality.

07. Identifies and disseminates best practices to assist in meeting quality goals and improving performance.

08. Serves as a liaison with Centralized Quality Review System (CQRS) and local Program Analysis System (PAS) quality reviewers to identify emerging issues and improvement opportunities.

09. Serves as a liaison with the Centralized Evaluative Review (CER) team to identify emerging issues, improvement opportunities and to ensure consistency throughout the program.

10. Participates in site assistance visits, providing reports, conducting focus interviews to identify improvement suggestions and initiating follow-up actions.

11. Reviews and approves a valid sample of work for each AM program throughout the year with Statistics of Income (SOI).

12. Serves as a liaison with Process Improvement managers and specialists at each AM site to conduct national product (program) quality reviews.

13. Provides topics for training, skill-up, and improvement methods including the Define, Measure, Analyze, Improve Control (DMAIC) process.

14. Conducts and/or assists with DCI Coding Consistency Training sessions for headquarters (HQ) and field tax and quality analysts.

15. Shares sound recommendations with solid facts and figures to justify changes (procedural, systemic and program) to proper stakeholders such as Policy and Procedures IMF, Identity Theft (IDT), Return Integrity and Compliance Services (RICS), Field Assistance (FA), and Automated Collection System (ACS) to improve work practices, policies and guidelines.

16. Recommends any changes that provide/improve consistency and/or enhance productivity and efficiency.

17. Support delivery of EQRS Coding Consistency Training for AM sites to ensure CQRS, PAS, and CER coding is consistent. Conducts EQ Summits every two years to ensure EQRS DCI Coding eliminate low used coding attributes.

18. Oversees the AM Customer Satisfaction (CSAT) Surveys (CSS), coordinating with Taxpayer Services (TS) Strategies and Solutions (TSSS) and the vendor to ensure each AM Senior Manager and Field Director receives CSS Reports with improvements recommendations.


3. PICA reports to the Program Manager of AMOS.

4. The office Symbols for PICA are C:DC:TS:CAS:AM:AMOS:PICA.


**1.1.13.6.4** **(01-24-2023)**

#### Electronic Products and Services Support (EPSS)

1. **About:** Electronic Products and Services Support (EPSS) provides centralized operations and support to tax professionals and related partners, as well as other staffers and government entities using electronic products, e-Help services, and help desk operations. The organization manages and supports initiatives, projects, and other efforts aimed at developing, introducing, and improving electronic products and services. The EPSS organization provides program management of e-Services and a suite of web-based products which allow tax professionals and third parties to conduct business with the IRS via the Internet.

2. **Mission:** To support customer-valued e-solutions for Servicewide electronic products and services.

3. To accomplish the mission, EPSS:



01. Plans, directs, manages, administers, and executes activities specific to management of electronic products and services.

02. Provides oversight for paper, electronic and telephone inquiry programs.

03. Monitors the e-help Operation and Technical Services Operation workloads and adjusts workloads as necessary.

04. Collaborates with the Joint Operations Center (JOC) to ensure resources are planned, scheduled and used efficiently.

05. Provides executive leadership and direction through subordinate managers geographically located nationwide.

06. Delegates sufficient authority to subordinates to effectively manage their resources and to provide a supportive environment for creativity and innovation.

07. Coordinates program activities with other top-level IRS executives to prepare Servicewide policies, address cross-functional issues, develop strategies, and ensure consistency of approach.

08. Engages with internal stakeholders to develop a full-service support network skilled in providing help to external customers who encounter problems using IRS electronic products.

09. Manages all human, physical, information technology, and financial resources assigned to EPSS and allocates these resources following overall strategies to further the accomplishment of specific goals.

10. Minimizes impact on operations by researching, analyzing and evaluating contacts for downstream impact and providing guidance to affected business units (BUs).

11. Coordinates and manages Federal Information Security Management Act (FISMA) business-related activities related to the EPSS systems and applications.

12. Ensures protection of sensitive data by initiating and executing contracts to complete and renew certification and accreditation (C&A) of EPSS system applications including continued annual testing managed by IRS or contractors.


4. The Director, EPSS reports to the Director, Customer Accounts Services.

5. Direct reports to the Director, EPSS include:



   - Operations Support

   - e-help Operation

   - Technical Services Operation


6. The office symbols for EPSS are C:DC:TS:CAS:EPSS.

7. Visit EPSS at Electronic Products & Services Support (EPSS)..


**1.1.13.6.4.1** **(02-26-2020)**

##### Electronic Products and Services Support (EPSS) Operations Support

1. **Mission:** To provide program, operational and administrative support for Electronic Products and Services Support (EPSS) functions to ensure the achievement of all program and strategic goals and objectives.

2. To accomplish the mission, EPSS Operations Support:



1. Provides program management oversight to ensure the effectiveness of all programs under the jurisdiction of the EPSS director.

2. Provides budgetary and financial guidance for the EPSS functions.

3. Provides active participation to help implement innovative and customer-valued solutions that meet the demand of new projects and initiatives of internal operations and business partners.

4. Provides maintenance of Filing Season Readiness (FSR) program.


3. The Chief, Operations Support reports to the Director, EPSS.

4. The following EPSS functions report to the Chief, Operations Support:



   - E-file Provider Program Management (EPPM)

   - Program Management (PM)

   - Workforce Planning, Training and Quality (WPTQ)


5. The office symbols for EPSS Operations Support are C:DC:TS:CAS:EPSS:OS.

6. Visit EPSS Operations Support at: EPSS Operations Support.


**1.1.13.6.4.2** **(08-29-2025)**

##### E-file Provider Program Management (EPPM)

1. **Mission:** To oversee policies for application, suitability and program participation for authorized IRS e-file providers.

2. To accomplish the mission, E-file Provider Program Management (EPPM)



1. Provides enrollment and credential management for firms and government entities to e-file.

2. Maintains e-file participation policy and standards.

3. Maintains integrity of IRS e-file through background checks and tax compliance of e-file providers.


3. EPPM’s areas of responsibility/oversight include:



01. IRM 3.42.10, Authorized IRS e-file Providers, and IRM 3.42.20, Preparer e-file Hardship Waiver Requests

02. Pub 1345, Handbook for Authorized IRS e-file Providers of Individual Income Tax Returns and Pub 3112, IRS E-File Application and Participation

03. Small Business/Self-Employed (SB/SE) Liaison for e-file monitoring/Electronic Filing Identification Number (EFIN) modeling

04. Automated Suitability Analysis Program (ASAP) and Master File transcript programs

05. External Services Authorization Management (ESAM) e-file application

06. Criminal history records check and Adjudication

07. Oversight of Automated Fingerprinting process

08. Suitability and Appeals

09. Reconsideration policy

10. Assumptions for work plans

11. Authorized IRS e-file provider locator service for tax professionals/individuals

12. Freedom of Information Act (FOIA) extracts

13. Letter maintenance

14. [IRS.gov](https://www.irs.gov/) content for tax professionals

15. Maintaining safeguards, EFIN referral, Uniform Resource Locator (URL), new e-file requirements mailbox

16. Identity theft and compromised EFIN policies

17. Work Request (WR) management

18. Suspect EFIN Tool (SET)


4. The Supervisory Management Analyst of EPPM reports to the Chief, Operations Support.

5. The office symbols for EPPM are C:DC:TS:CAS:EPSS:EPPM.


**1.1.13.6.4.3** **(08-29-2025)**

##### Program Management

1. **Mission:** To provide critical oversight to a wide range of internal and external stakeholders, to support business operations, policy, Electronic Products and Services Support (EPSS) program delivery, program monitoring and coordination.

2. To accomplish the mission, Program Management:



01. Provides planning and oversight of products and services, and coordinates with a wide-range of internal stakeholders, program areas and policy owners.

02. Provides input and feedback for policy developed by external stakeholders’ programs.

03. Creates and maintain technical documents.

04. Communicates with external customers by creating and maintaining websites and delivering presentations.

05. Writes publications related to specific program areas.

06. Interprets legislation and other documents, makes changes to IRM procedures and provides changes to EPSS functions.

07. Maintains Knowledge Database through development of e-help support system knowledge articles (Solutions).

08. Reviews and analyzes trend data to recommend areas of focus for the directors of Customer Account Services (CAS) and EPSS.

09. Provides administrative support for the Director, EPSS, including preparing responses to internal and external stakeholders, providing information, preparing presentations, preparing for meetings, etc.

10. Provides oversight for the EPSS Director, on program delivery, efficiency and effectiveness.

11. Prepares assumptions for work plans.

12. Monitors work and program performance for the EPSS Director to ensure consistency over EPSS functions and to track information and prepare reports.

13. Provides support for conformance review and site assistance visits, prepares trip reports and validates site performance.


3. Program Management’s areas of responsibilities include:



1. Policy, procedures and guidance

2. e-help Support System (EHSS) Solutions

3. EPSS communications

4. Work Request (WR) coordination

5. Technical Services Operation (TSO)/e-help Operation program coordination


4. Program Management is responsible for the following IRMs and Publications:




| **IRMs** | **Title** |
| --- | --- |
| IRM 3.42.7 | EPSS Help Desk Support |
| IRM 3.42.8 | E-Services Procedures for Electronic Products and Services Support (EPSS) |
| IRM 3.42.9 | IRS e-file of Information Returns |
| IRM 21.3.11 | Information Returns Reporting Procedures |






| **Publication** | **Title** |
| --- | --- |
| Pub 1187 | Specifications for Electronic Filing of Form 1042-S, Foreign Person’s U.S. Source Income Subject to Withholding |
| Pub 1220 | Specifications for Electronic Filing of Forms 1097, 1098, 1099, 3921, 3922, 5498, and W-2G |
| Pub 1239 | Specifications for Electronic Filing of Form 8027, Employer’s Annual Information Return of Tip Income and Allocated Tips |
| Pub 1516 | Specifications for Electronic Filing of Form 8596, Information Return for Federal Contracts |
| Pub 4810 | Specifications for Electronic Filing of Form 8955-SSA, Annual Registration Statement of Identifying Separated Participants With Deferred Vested Benefits |
| Pub 5717 | Information Returns Intake System (IRIS) Taxpayer Portal User Guide |

5. The Supervisory Management Analyst of Program Management reports to the Chief, EPSS Operations Support.

6. The office symbols for Program Management are C:DC:TS:CAS:EPSS:OS:PM.


**1.1.13.6.4.4** **(08-29-2025)**

##### Workforce Planning, Training and Quality (WPTQ)

1. **Mission:** To provide oversight to key organizational business goals and labor management activities through planning, scheduling, monitoring business results, performance measures, training and quality programs by developing training for all Electronic Products and Services Support (EPSS) programs and ensuring quality objectives for the EPSS functions are effectively met.

2. To accomplish the mission, Workforce Planning, Training and Quality (WPTQ):



01. Ensures balanced measures are implemented in all EPSS operations.

02. Reviews and analyzes trend data and recommends areas of focus for the Customer Account Services (CAS) and EPSS directors.

03. Coordinates administrative duties, including operational space issues, physical moves, equipment needs, and numerous other issues.

04. Provides administrative support to the Director, EPSS, including preparing responses to internal and external stakeholders, providing information, preparing presentations for meetings, etc.

05. Ensures conformance with standardized practices from Joint Operations Center (JOC) about telephone operations and conformance with Work Planning and Control reports and other Management Information Systems (MIS).

06. Oversees site schedules and recommends changes based on inventory and call volume.

07. Supports site monitoring and review of phone and paper programs and prepares reports accessing process performance for all assigned programs, including telephones, paper and email.

08. Tracks resource usage (non-financial) hours and volumes ensuring accuracy of reporting data and delivery of programs as determined by CAS.

09. Provides oversight for the EPSS Director, on program delivery, efficiency and effectiveness.

10. Monitors work and program performance for the EPSS Director to ensure consistency over EPSS functions and to track information and prepare reports.

11. Creates and revises training materials for EPSS functions.

12. Creates Program Work Plans and Work Schedules.


3. WPTQ’s areas of responsibility include:



   - IRM 1.4.18, Electronic Products and Services Support (EPSS) Managers Guide

   - Work Plan/Work Schedules

   - Scheduling and forecasting contacts

   - Business/performance measures and goals

   - Work Request (WR) Coordination

   - Business Resumption

   - Training plan development

   - Course development

   - Quality Program

   - Contract Office Representative (COR) for Automatic Electronic Fingerprinting (AEF),and, Certified Professional Employer Organization (CPEO) contracts

   - EPSS website maintenance

   - e-help desk’s Customer Satisfaction Survey process

   - Budget and finance reporting

   - Resource allocation reporting

   - WP&C review and data anomaly analysis

   - Organization chart coordination and hiring

   - Overtime coordination and reporting

   - E-gains Chat box maintenance

   - PAC2E Business measures

   - Security reporting (SAAS)

   - Awards coordination for bargaining unit awards

   - Section 1204 coordination

   - Verint contact recording coordination


4. The Supervisory Management Analyst of WPTQ reports to the Chief, Operations Support.

5. The office symbols for WPTQ are C:DC:TS:CAS:EPSS:OS:WPTQ.


**1.1.13.6.4.5** **(08-29-2025)**

##### e-help Operations

1. **Mission:**To provide excellent quality assistance and effective technical solutions to users of IRS electronic products and services.

2. To accomplish the mission, the e-help Operations:



1. Provides leadership and direction for telephone, electronic and paper inquiries through subordinate managers.

2. Participates in the formulation of short- and long-range program policy guidance, procedures, strategies and objectives.

3. Ensures subordinate managers operate as an effective management team and all management functions are handled in an equitable and responsive manner to meet the needs of all customers.

4. Supports the development of subordinate managers and assists them in the resolution of complex issues.

5. Interacts with other functions and operating divisions for shared services.


3. The e-help Operations areas of responsibility include:



   - Electronic Filing (e-file)

   - e-Services including Secure Access Digital Identity (SADI), e-file Application, Transcript Delivery System (TDS), Taxpayer Identification Number (TIN) Matching, and Affordable Care Act (ACA) Application for Transmitter Control Code (TCC)

   - Free File Fillable Forms (FFFF)

   - Electronic Federal Tax Payment System (EFTPS) registration only

   - System for Award Management (SAM) registration only

   - Foreign Account Taxpayer Compliance Act (FATCA) online registration

   - Affordable Care Act Forms Acceptance (AFA)

   - Secure Access Digital Identity (SADI) enable/disable requests

   - 94X PIN Registration

   - Software Testing (IMF\\BMF\\Excise)

   - Preparer e-file Waiver Hardship Requests


4. The Chief, e-help Operations reports to the Director, Electronic Products and Services Support (EPSS).

5. The following departments report to the Chief, e-help Operations:



   - e-help West (located in Austin, Atlanta, and Ogden)

   - e-help East (located in Andover and Cincinnati)


6. The office symbols for e-help Operations are C:DC:TS:CAS:EPSS:E-HELP.

7. Visit e-help Operations at e-help Operations.


**1.1.13.6.4.6** **(08-29-2025)**

##### Technical Services Operation (TSO)

1. **Mission:** To provide excellent assistance and effective technical solutions to filers of electronic Information Returns.

2. To accomplish the mission, Technical Services Operation (TSO):



1. Supports external customers who need help with the filing requirements associated with accurately preparing information returns.

2. Provides technical customer assistance and troubleshoots errors for the Filing Information Returns Electronically (FIRE) System.

3. Supports various programs associated with processing electronic information returns.

4. Provides technical support to internal and external customers for systems, programs, and products supported by Electronic Products and Services Support (EPSS).

5. Provides leadership and direction for telephone, electronic and paper inquiries through subordinate managers.

6. Participates in the formulation of short and long-range program policy guidance, procedures, strategies and objectives.

7. Ensures subordinate managers operate as an effective management team and all management functions are handled in an equitable and responsive manner to meet the needs of all customers.

8. Supports the development of subordinate managers and assists them in the resolution of complex issues.

9. Interacts with other functions and operating divisions for shared services.


3. The Chief, Technical Services Operation reports to the Director, EPSS.

4. TSO consists of five functions:



   - Customer Service Section (CSS) 1 & CSS 2 (Martinsburg)

   - CSS 3 (Austin)

   - Filing Information Returns Electronically (FIRE) Support (Martinsburg)

   - Information Filing Support (IFS) (Martinsburg)

   - Products and Services Support (PSS)


5. The office symbols for TSO are C:DC:TS:CAS:EPSS:TSO.

6. Visit TSO at Technical Services Operation.


**1.1.13.6.4.6.1** **(08-29-2025)**

###### Customer Service Sections (CSS)

1. **Mission:** To provide assistance to Information Return filers to help them meet filing requirements and compliance obligations.

2. To accomplish the mission, Customer Service Sections (CSS) handles phone calls and emails pertaining to the following:



1. Paper and electronic filing questions for information returns.

2. Filing Information Returns Electronically (FIRE) to file information returns.

3. Information Returns (IR) Application for Transmitter Control Code (TCC).

4. Affordable Care Act (ACA) Application for TCC

5. ACA Information Returns (AIR) System to file information returns.

6. ACA Assurance Testing System (ATS)

7. Information Returns Intake System (IRIS) to file information returns.

8. Support of International Compliance Management Module (ICMM) errors on Foreign Account Tax Compliance Act (FATCA) information returns.


3. Customer Service Section supervisors report to the Chief, Technical Services Operation.

4. The office symbols for CSS are C:DC:TS:CAS:EPSS:TSO:CSS1, C:DC:TS:CAS:EPSS:TSO:CSS2, and C:DC:TS:CAS:EPSS:TSO:CSS3.


**1.1.13.6.4.6.2** **(08-29-2025)**

###### Filing Information Returns Electronically (FIRE) Support

1. **Mission:** To provide comprehensive technical support to the FIRE System to assist filers of information returns.

2. To accomplish the mission, Filing Information Returns Electronically (FIRE) Support:



1. Provides technical customer assistance and troubleshoots errors for the FIRE System.

2. Processes requests for electronic extensions of time to file and handles IR Application for TCC needing additional reviews.

3. Monitors incoming files to identify excessive withholding and other indicators of potential fraud and provides data to other Business Operating Divisions (BOD) for review and to be flagged.

4. Assists the issuer/transmitter community with the transmission of information returns through the FIRE system.


3. The FIRE Support supervisor reports to the Chief, Technical Services Operation.

4. The office symbol for FIRE Support are C:DC:TS:CAS:EPSS:TSO:FS.


**1.1.13.6.4.6.3** **(08-29-2025)**

###### Information Filing Support (IFS)

1. **Mission:** To provide information filing support to the Filing Information Returns Electronically (FIRE) System and related programs to ensure customers can meet their tax filing and compliance responsibilities.

2. To accomplish the mission, Information Filing Support (IFS):



1. Provides technical customer service and support related to post processing issues of information returns filed electronically.

2. Oversees the processing of electronic extensions and waivers that includes paper and electronic unpostable processing.

3. Assists the filer/transmitter community with technical issues relative to under-reporter inquiries, notice recreation expedites, and problem resolution that Customer Service Sections (CSS) cannot address.


3. The IFS supervisor reports to the Chief, Technical Services Operation.

4. The office symbols for IFS are C:DC:TS:CAS:EPSS:TSO:IFS.


**1.1.13.6.4.6.4** **(08-29-2025)**

###### Product and Services Support (PSS)

1. **Mission**: To provide technical support to internal and external customer for systems, programs and products owned by Electronic Products and Services Support (EPSS).

2. To accomplish the mission, PSS:



1. Provides support in resolving complex e-Services issues for external customers.

2. Provides information about Federal Information Security Management Act (FISMA) system security issues for the systems maintained by EPSS.

3. Ensures protection of sensitive data by providing certification and accreditation (C&A) information for EPSS systems.

4. Supports the creation of comprehensive contingency planning documents and systems applications and tests viability following disaster recovery guidelines.


3. PSS areas of responsibility include:



   - Application Program Interface (API) Client ID Application.

   - E-Help Support System (EHSS) application, development and system support

   - e-Services

   - EPSS website and [IRS.gov](https://www.irs.gov/) content management

   - Security certification of all applicable systems

   - Applicants Database (ADB)

   - Disaster recovery

   - FISMA assessments

   - Level II technical call resolution


4. The PSS supervisor reports to the Chief, Technical Services Operation.

5. The office symbols for PSS are C:DC:TS:CAS:EPSS:TSO:PSS.


**1.1.13.6.5** **(11-02-2018)**

#### Joint Operations Center (JOC)

1. **Mission:** To improve the customer experience by maximizing resources and infrastructure capabilities, and incorporating innovative and emerging technologies in a multi-channel environment.

2. To accomplish the mission, the Joint Operations Center (JOC):



1. Provides planning, analysis, technical and operations support for IRS customer contacts in a multi-channel environment including strategy and tactical solutions implementation, centralized quality review, change management and requirements, forecasting, real-time monitoring and reporting, and contact analytics.

2. Provides real-time channel and resources management.

3. Supports forecasting and data management across the enterprise.

4. Helps Taxpayer Services (TS) achieve desired service levels across multiple channels including written correspondence.

5. Works closely with Information Technology (IT) partners and business units (BUs) to ensure a smooth transition of enhancements from conceptualization to production.


3. The Director, JOC reports to the Director, Customer Account Services (CAS).

4. The following areas report to the Director, JOC:



   - Operations

   - Planning and Analysis

   - Contact Analytics and Business Requirements Integration

   - Centralized Quality Review System

   - Program Management Office


5. The office symbols for JOC are C:DC:TS:CAS:JOC.

6. Visit JOC at: Joint Operations Center.


**1.1.13.6.5.1** **(08-29-2025)**

##### Operations

1. **Mission:** Executing and evaluating contract center performance.

2. To accomplish the mission, Operations (OP):



1. Provides oversight of all real-time telephone operations, including routing and real-time scheduling activities.

2. Analyzes and responds to the impacts of overseeing real-time operations.

3. Conducts analysis of telephone operations and paper and electronic inventories.


3. The Chief, OP reports to the Director, JOC.

4. The following sections report to Chief, OP:



   - Routing and Monitoring

   - Performance Tracking


5. The office symbols for OP are C:DC:TS:CAS:JOC:OP.

6. Visit Operations at: JOC \| Operations.


**1.1.13.6.5.1.1** **(08-29-2025)**

###### Routing and Monitoring

1. **Mission:** To provide evaluation and responses to system demands by routing telephone calls dynamically and implementing routing strategies to continually improve telephone service delivery to Customer Account Services (CAS), Compliance and e-help customers.

2. To accomplish the mission, Routing and Monitoring (RM):



1. Monitors real-time call distribution.

2. Monitors real-time customer service delivery.

3. Monitors real-time adherence to staffing schedules.

4. Balances service delivery to telephone and correspondence customers (within the constraints of the Operating Division Work Plan).


3. RM reports to the Chief, OP.

4. The office symbols for R&M are C:DC:TS:CAS:JOC:OP:RM.


**1.1.13.6.5.1.2** **(08-29-2025)**

###### Performance Tracking

1. **Mission:** To provide oversight and guidance to the Chief, Operations, the Director, Joint Operations Center (JOC), and Taxpayer Services (TS) Customer Account Services (CAS) sites regarding strategies for responding to fluctuations in paper and electronic inventories and telephone demand.

2. To accomplish the mission, Performance Tracking (PT):



1. Monitors, analyzes and poses tactical solutions to variances from business units (BUs) objectives in real-time.

2. Identifies and makes recommendations to opportunities for improved service, which may require adjustments to operating division work plans.

3. Facilitates daily communications to TS CAS Headquarters (HQ) on workload issues.

4. Provides analysis for operating division JOC representatives on daily information about service delivery and performance.


3. PT reports to the Chief, OP.

4. The office symbols for Performance Tracking are C:DC:TS:CAS:JOC:OP:PT.


**1.1.13.6.5.2** **(11-02-2018)**

##### Planning and Analysis

1. **Mission:**To provide complete, timely and accurate performance trend analysis, toll-free telephone work planning, and Management Information Systems (MIS) data to internal and external stakeholders.

2. To accomplish the mission, Planning and Analysis (P&A):



1. Provides analysis for telephone product lines.

2. Prepares reports for the business units (BUs) and outside stakeholders.

3. Maintains all MIS reporting systems including the validation and verification of data to ensure accuracy and integrity.

4. Conducts work planning of telephone and all paper media for the Enterprise.


3. The Chief, Planning and Analysis reports to the Director, JOC.

4. The following sections report to the Planning and Analysis Branch:



   - Strategic Forecasting and Analysis

   - Reports Development


5. The office symbols for P&A are C:DC:TS:CAS:JOC:P&A.

6. Visit Planning and Analysis at: P&A.


**1.1.13.6.5.2.1** **(10-13-2021)**

###### Strategic Forecasting and Analysis

1. **Mission:** To analyze Enterprise performance data to identify staffing, routing and systemic problems and to provide toll-free forecasts to enable business units to meet strategic goals.

2. To accomplish the mission, Strategic Forecasting and Analysis (SFA):



01. Develops the telephone forecast by gathering historical data, identifying variances, and normalizing data incorporating expected trends.

02. Prepares work plans for telephone product lines that balance available resources with program goals.

03. Provides complete forecast to the Accounts Management (AM) scheduling staff after collaboration with the business units (BUs) and incorporating assumptions.

04. Tracks resource usage Enterprise-wide by monitoring and assessing adherence to plan.

05. Develops and publishes final forecast and work plans.

06. Identifies trends in usage, traffic patterns, operational statistics, etc., and issues reports documenting findings.

07. Coordinates internal and external ad hoc requests for information (measures and indicators, legislature).

08. Provides guidance for determining Management Information Systems (MIS) requirements.

09. Maintains official historic data reporting.

10. Maintains and develops reports for the Customer Account Services (CAS) organization.

11. Provides operational review talking points.

12. Develops Strategic Plan goals and Strategic Plan end of year projections.

13. Validates data for Government Accountability Office (GAO)/Treasury Inspector General for Tax Administration (TIGTA) filing season audits.


3. The Chief, SFA reports to the Chief, P&A.

4. The office symbols for SFA are C:DC:TS:CAS:JOC:P&A:SFA.


**1.1.13.6.5.2.2** **(08-29-2025)**

###### Reports Development

1. **Mission:** To provide centralized reporting of contact center environment data to various Joint Operations Center (JOC) components and business units (BUs).

2. To accomplish the mission, Reports Development (RD):



01. Manages, monitors, maintains and provides user guidance and training for the Report Request Central (RRC) Intake (the JOC Central repository for information requests) website.

02. Provides the following weekly reports:


        • Resource Allocation Reports (RAR) summary reports


        • Forms Order Vendor Comparison Report


        • Electronic Products and Services Support (EPSS) Online Services Contact/Call Report


        • Accounts Management (AM) Enterprise Customer Contact Report (ECCR)


        • Enterprise Self-Assistance Participation Rate (ESAPR) Report


        • Customer Callback Enterprise Solution Report (CCES)

03. Maintains and develops various reports for the Customer Account Services (CAS) organization.

04. Validates data for the Government Accountability Office (GAO)/Treasury Inspector General for Tax Administration (TIGTA) filing season audits.

05. Ensures data extraction, transformation and loading (ETL) processes are in place to receive data from source systems into Enterprise Telephone Data (ETD). These sources include:


        • Infrastructure Upgrade Project (IUP)


        • Cisco Intelligent Call Manager


        • Verizon


        • Integrated Customer Communications Environment (ICCE)


        • Customer Communications Management Information System


        • eGain


        • Microsoft (Nuance)


        • e-Workforce Management (eWFM)


        • Manually developed staffing schedules

06. Develops and maintains reports for the CAS and Compliance organizations, including the following:


        • Daily Executive Level Summary


        • Compliance Site Level Measures


        • Daily and Weekly Snapshots


        • Variable Call Routing


        • Agent Transfers


        • Agent Group


        • Survey Call


        • Half Hourly Adherence


        • AT&T Telephone Reports


        • Verizon Telephone Reports


        • Infrastructure Upgrade Project (IUP) Historical Reports

07. Designs, develops and tests new reports based on requirements provided by Business Operating Divisions (BODs).

08. Develops and maintains ad hoc and routine Structured Query Language (SQL) queries for business customers to retrieve from a restricted file share location.

09. Ensures compliance with the IRS policy related to systems security.

10. Coordinates system support and maintenance of the Enterprise Telephone Data (ETD) hardware and operating systems with impacted Modernization and Information Technology (IT) support organizations.


3. The Chief, RD reports to the Chief, P&A.

4. The office symbols for RD are C:DC:TS:CAS:JOC:P&A:RD.


**1.1.13.6.5.3** **(08-29-2025)**

##### Contact Analytics and Business Requirements Integration

1. **Mission:** To support IRS operational goals by facilitating routing changes to the Contact Center Environment and provide speech analytics services and data to improve the taxpayer experience, IRS processes and procedures.

2. The Chief, Contact Analytics and Business Requirements Integration (CABRI) reports to the Director, Joint Operations Center (JOC).

3. The following sections report to the Chief, CABRI:



   - Contact Analytics

   - Business Requirements Integration


4. The Chief, CABRI reports to the Director, JOC.

5. The office symbols for CABRI are C:DC:TS:CAS:JOC:CABRI.


**1.1.13.6.5.3.1** **(08-29-2025)**

###### Contact Analytics (CA)

1. **Mission:** To use Contact Analytics speech technology to analyze enterprise telephone contact data, provide the IRS with the ability to incorporate the productive use of resources and improve the taxpayer experience.

2. To accomplish the mission, Contact Analytics (CA):



1. Manages the CA application from end user perspective and serves as a liaison with Information Technology (IT).

2. Controls access and distribution of speech analytics reports.

3. Conducts analyses of call data from enterprise perspective and identifies potential areas for process improvement.

4. Gathers data via search functionality on recorded calls.

5. Provides standard and ad hoc reports to designated business unit representatives.

6. Provides knowledge transfer for use of reports.

7. Assists business unit liaisons with identifying corrective actions.

8. Establishes enterprise processes for current and future potential uses of CA software.

9. Conducts outreach on CA technology and program implementation.


3. CA reports to the Chief, CABRI.

4. The office symbols for CA are C:DC:TS:CAS:JOC:CABRI:CA.

5. Visit CA at: Contact Analytics (CA).


**1.1.13.6.5.3.2** **(08-29-2025)**

###### Business Requirements Integration

1. **Mission**: CABRI’s Business Requirements Integration (BRI) team delivers the customer experience, provides essential services to its customers and partners with multiple business units across the IRS to deliver requested changes to the Toll-free and Automated Self-Service Application (ASSA) systems.

2. To accomplish the mission, Business Requirements Integration (BRI) performs the following:



1. Requirements Management for in-production and concept toll-free and interactive telephony and web-based, taxpayer-account related applications.

2. Provide governance over the Change Request (CR) process and requests impacting the Contact Center Environment (CCE), with primary suppliers: Information Technology (IT)/Contact Center Services (CCS) and IT/Applications Development (AD).

3. Facilitate the development and integration of new call routing processes.

4. Coordinate release management by leveraging IT resources capacity with competing business priorities.

5. Overseeing the development and deployment of changes into the CCE and ASSAs.

6. Ensuring Business requirements and IT solutions effectively integrate with existing Call Center operations.

7. Providing Text-to-Speech (TTS) audio output.


3. BRI reports to the Chief, CABRI.

4. The office symbols for BRI are C:DC:TS:CAS:JOC:CABRI:BRI.

5. Visit BRI at: BRI.


**1.1.13.6.5.4** **(08-29-2025)**

##### Centralized Quality Review System

1. **Mission:** To provide a nationwide independent quality review service for various Specialized Product Review Groups (SPRGs) where taxpayers contact the IRS with an inquiry.

2. To accomplish the mission, Centralized Quality Review System (CQRS):



1. Monitors various SPRGs under Customer Account Services (CAS), Customer Assistance, Relationships and Education (CARE), and Compliance.

2. Conducts quality review monitoring via Contact Recording and Correspondence Imaging Inventory (CII) System and inputs the findings on a data collection instrument (DCI) in the National Quality Review System (NQRS) database.

3. Identify quality trends and provides quality statistics.

4. Elevates issues identified during coding.

5. Tracks items for funding purposes.


3. The vision of CQRS is to provide quality data and analysis to our customers while pointing the way on emerging issues that impact how taxpayers are treated in a professional, timely and accurate manner.

4. CQRS gathers and analyzes data to assess the accuracy of the contact and identify defects which are rolled up to provide the business results for the Balanced Measures (Customer Accuracy, Regulatory Accuracy, Procedural Accuracy, Timeliness, and Professionalism) in the Embedded Quality Review System (EQRS). CQRS finds opportunities for improvement and recommends corrective actions to help management with improving the quality of service to the taxpayer.

5. The Chief, CQRS reports to the Director, JOC.

6. The CQRS Branch includes nine sections with eight teams of Quality Review Specialists and a Customer Accuracy Improvement Section.

7. The office symbols for CQRS are C:DC:TS:CAS:JOC:CQRS.

8. Visit CQRS at: CQRS.


**1.1.13.6.5.4.1** **(08-29-2025)**

###### Customer Accuracy Improvement Section

1. The purpose of Customer Accuracy Improvement Section is to conduct monitoring and on-line review of the Customer Account Services (CAS) and Automated Collection System (ACS) toll-free telephone programs, as well as Customer Assistance, Relationships and Education (CARE) Field Assistance programs, to gauge the accuracy and timeliness of responses provided to customers. Quality review activities encompass tax law and account work on the ACS, Accounts Management (AM), and the Spanish toll-free lines, Electronic Products and Services Support (EPSS) lines, the Accounts Paper Adjustment Specialized Product Review Groups (SPRG), and the Identity Theft (IDT) Paper SPRGs.

2. To accomplish its goals, Customer Accuracy Improvement Section (CAIS):



1. Conducts quality reviews of CAS, CARE and ACS program activities.


3. CAIS reports to the Chief, CQRS.

4. The office symbols for CAIS are C:DC:TS:CAS:JOC:CQRS:CAIS.


**1.1.13.6.5.5** **(08-29-2025)**

##### Program Management Office

1. **Mission:** To provide strategic and tactical program solutions, deliver successful projects for new and legacy platforms with project management disciplines, serve as JOC audit liaison for TIGTA/GAO inquiries and support JOC responses to internal and external data inquiries.

2. To accomplish the mission, Program Management Office (PMO):



1. Collaborates with Taxpayer Services (TS) functions (including Operation Support, Business Systems Modernization), other business units, campus and field operations, Information Technology (IT), contractors, vendors, and external stakeholders to achieve its mission. PMO supports the following improvement areas: workforce management, routing features, and controls, customer service, contact channels integration, and enhanced/integrated data services.

2. Works together with the Joint Operations Center (JOC) Senior Operations Advisor to properly coordinate all JOC-wide controls and ensure that all coordination control program objectives and deliverables are realized.


3. The vision of PMO is to introduce innovative technology solutions and customer focused support in all its interactions.

4. The Chief, PMO reports to the Director, JOC.

5. The following sections report to the Chief, PMO:



   - Project Management Team

   - Voicebot/Chatbot Team


6. The office symbols for the PMO are C:DC:TS:CAS:JOC:PMO.

7. Visit PMO at: PMO.


**1.1.13.6.5.5.1** **(08-29-2025)**

###### Project Management Team

1. **Mission:** To provide project management leadership in support of the development of contact center technology to ensure business requirements are achieved. This includes applying project management disciplines to guide initiatives through the IRS life cycle phases.

2. To accomplish the mission, the Project Management (PM) Team:



1. Provides tactical application support of legacy Contact Center Environment (CCE) applications such as Contact Recording, Finesse, and Workforce Management.

2. Provides support, oversight, coordination, and leadership to implement new omni-channel technology in the CCE such as Customer Callback, voicebots and chatbots.

3. Supports the development of CCE initiatives for investment proposals and out-of-cycle budget requests.

4. Uses a repeatable process to evaluate Joint Operations Center (JOC) program effectiveness and risk assessments.

5. Provides information and status updates related to JOC initiatives for executive briefings and responses.


3. The PM Team reports to the Chief, PMO.

4. The office symbols for the PM Team are C:DC:TS:CAS:JOC:PMO:PM.


**1.1.13.6.5.5.2** **(08-29-2025)**

###### Voice/Chatbot Team

1. **Mission:** To provide project management leadership in support of the development of contact center omni-channel technologies that focus on customer service experience and ensure business requirements are achieved. This includes applying project management disciplines to guide initiatives through the IRS life cycle phases.

2. To accomplish the mission, the Voicebot/Chatbot (VB/CB)Team:



1. Provides oversight, coordination, and leads activities to support implementation of natural language voicebot and chatbot technologies.

2. Provides project management support on development and enhancements for interactive voicebots, powered by artificial intelligence (AI), that allows callers to navigate an interactive voice response (IVR) system using natural language.

3. Provides project management support on development and enhancements for self-guided and interactive chatbots, along with live assistance technology such as interactive text chat with contact center agents.

4. Provides information and status updates related to voicebot and chatbot initiatives for executive briefings and responses.


3. The VB/CB Team reports to the Chief, PMO.

4. The office symbols for the VB/CB Team are C:CD:TS:CAS:JOC:PMO:VBCB.


**1.1.13.6.6** **(01-24-2023)**

#### Submission Processing (SP)

1. **About:** Submission Processing (SP) develops requirements, policies, and procedures for the submission of all paper and electronic tax returns and processes all individual and business returns nationwide.

2. **Mission:**



1. Process tax returns, related documents, and payments at the Taxpayer Services (TS) SP Centers (Austin, Kansas City, and Ogden).

2. Ensure functional implementation of legislation and regulations in a manner that carries out congressional intent.

3. Provide executive leadership, oversight and direction in the design, development, delivery and consistency of application of paper and electronic filing policies and procedures between centers.

4. Improve business practices and technology and monitor adherence to work plans and filing season assignments at the SP centers.


3. To accomplish its mission, SP implements short and long-range program policies, strategies and objectives specific to SP including:



1. Overseeing the processing of paper and electronic individual returns and related payments and refunds.

2. Directing processing operations in dedicated SP centers and in the Service Center Recognition Image Processing System (SCRIPS) and Information Returns Processing (IRP).

3. Designing and developing programs to solve complex issues relating to the standards for taxpayer submissions, receipt of those submissions, and financial transfers.

4. Providing executive leadership and direction through subordinate executives and managers geographically located nationwide.

5. Delegating sufficient authority to subordinates to effectively manage their resources and to provide a supportive environment for creativity and innovation.

6. Coordinating program activities with other top-level IRS executives or other federal agencies to prepare Servicewide policies, address cross-functional issues, develop strategies, and ensure consistency of approach.

7. Implementing the development of activities to build leveraged partnerships and collaborate with stakeholders to increase taxpayer education and clarify tax code issues.

8. Managing all human, physical, information technology, and financial resources assigned to SP and allocating these resources following overall strategies to further the accomplishment of specific goals.


4. The Director, SP reports to the Director, Customer Account Services (CAS) and plans, manages, directs and executes activities at three (3) TS SP centers.

5. The following areas report to the Director, Submission Processing:



   - Return Processing Branch

   - Accounting and Tax Payment Branch

   - Program Management /Process Assurance Branch

   - Specialty Programs Branch

   - e-File Services

   - SP Field Directors (Austin, Kansas City, and Ogden)


6. The office symbols for SP are C:DC:TS:CAS:SP.

7. Visit Submission Processing at: Submission Processing.


**1.1.13.6.6.1** **(08-29-2025)**

##### Return Processing Branch

1. **Mission:** To provide guidance and establish policy and procedures on Individual Master File (IMF) and Business Master File (BMF) to enable the effective and efficient processing of all business and individual tax returns in three Submission Processing (SP) centers.

2. To accomplish its mission, the Return Processing Branch:



1. Provides IMF/BMF policy, procedures, and guidance to the Director, SP.

2. Determines business requirements and writes the Unified Work Requests (UWRs) for submission to Information Technology (IT) to incorporate into the SP systems. Provides program direction for IMF/BMF and International tax returns and related documents processed within the SP centers.

3. Provides operational oversight for the Service Center Recognition Image Processing System (SCRIPS); the Service Center Automated Mail Processing System (SCAMPS); the Multifunctional Document Handling System (MDHS)-MUFFY; and the Integrated Submission and Remittance Processing System (ISRP).


3. The Chief, Return Processing Branch reports to the Director, SP.

4. The following sections report to the Return Processing Branch:



   - IMF Code and Edit/Error Resolution Section

   - BMF Code and Edit/Error Resolution Section

   - Mail Management/Data Conversion Section


5. The office symbols for the Return Processing Branch are C:DC:TS:CAS:SP:RPB.


**1.1.13.6.6.1.1** **(02-26-2020)**

###### IMF Code and Edit/Error Resolution Section

1. **Mission:**To provide business requirements and program direction in all aspects of processing Individual Master File (IMF) tax returns and related documents including code and editing, error resolution, and taxpayer contact for additional information.

2. To accomplish its mission, IMF Code and Edit/Error Resolution Section:



1. Develops policy, procedures, and guidance for processing of IMF tax returns and related documents in the areas of C&E, Error Resolution (ERS), direct deposit, math error authority, rejects, extensions, and Adoption Tax Identifying Number (ATIN).

2. Evaluates new legislation and determines the necessary business requirements to update our automated systems through the Unified Work Request (UWR) process and the Information Technology (IT) organization.

3. Develops business requirements and writes work requests for all IMF domestic and international programming changes to IDOC specific, ERS screen layouts, and taxpayer notice codes (TPNCs).

4. Provides guidance for the preparation of Submission Processing (SP) training material and ensures material is kept current.

5. Ensures consistency between all pipeline processing IRMs and system requirements.

6. Provides instructions for the processing of International individual returns at the Austin SP Center.


3. The Chief, IMF C&E/Error Resolution Section reports to the Chief, Return Processing Branch.

4. The office symbols for IMF C&E/Error Resolution Section are C:DC:TS:CAS:SP:RPB:IMF.


**1.1.13.6.6.1.2** **(02-26-2020)**

###### BMF Code and Edit/Error Resolution Section

1. **Mission:** To provide support and guidance for the integration and coordination of BMF policies, programs, and procedures for Submission Processing; ensuring policies and procedures are reflective of BMF and International taxpayer behaviors, needs, and characteristics to improve overall compliance and customer service.

2. To accomplish its mission, BMF Code and Edit/Error Resolution Section:



1. Identifies business requirements and writes the BMF work requests needed to ensure the accurate processing of all BMF returns and related documents.

2. Provides program and policy direction for all aspects of processing BMF, international, and Non-Master File (NMF) returns and related documents.

3. Works with Learning and Education to deliver specific functional training and coordinates training efforts with field when specific specialized expertise is needed to develop training.

4. Provides updates to computer paragraph (CP) notices and Integrated Data Retrieval System (IDRS) Correspondex letters with the latest form information, line numbers, and tax law information.


3. The Chief, BMF C&E/Error Resolution Section reports to the Chief, Return Processing Branch.

4. The office symbols for BMF C&E/Error Resolution Section are C:DC:TS:CAS:SP:RPB:BMF.


**1.1.13.6.6.1.3** **(01-24-2023)**

###### Mail Management/Data Conversion Section

1. **Mission:** To provide guidance and support to the Submission Processing Receipt and Control and Data Conversion functional areas in the centers and to develop and administer policies and strategies that improve their overall operations.

2. To accomplish its mission, Mail Management/Data Conversion Section:



1. Develops policy, procedures, and guidance for the paper submission of tax information, including Individual Master File (IMF) and Business Master File (BMF) using the Integrated Submission and Remittance Processing System (ISRP) and Service Center Recognition Image Processing System (SCRIPS).

2. Evaluates new legislation and determines the business requirements needed to update Submission Processing (SP) systems (ISRP, Returns Processing, and SCRIPS) and writes the work requests for submission to Information Technology (IT) for implementation.

3. Prepares the required IRMs and procedures to ensure accurate and consistent guidance to three SP centers.


3. The Chief, Mail Management/Data Conversion Section reports to the Chief, Return Processing Branch.

4. The office symbols for Mail Management/Data Conversion Section are C:DCTS:CAS:SP:RPB:MM/DC.


**1.1.13.6.6.2** **(02-26-2020)**

##### Accounting and Tax Payment Branch

1. **Mission:** To provide business requirements and program direction for receiving, processing, and controlling all methods of revenue receipt payments. In addition, this branch provides guidance on all service center accounting and manual deposit programs.

2. To accomplish its mission, Accounting and Tax Payment Branch:



1. Formulates short- and long-range program strategies and objectives for service center accounting and revenue receipt processing.

2. Establishes business requirements and provides program direction for all aspects of payment processing.

3. Coordinates program activities with other senior program managers and analysts to integrate Servicewide policies, address cross-functional issues, develop strategies, and ensure consistency of approach.

4. Works with the Learning and Education organization to deliver specific functional training and coordinates training efforts with field when specific specialized expertise is needed to develop training.

5. Coordinates all activities related to IRM updates, publishing, and distribution.

6. Responds to Government Accounting Office ( [GAO](https://www.gao.gov/)) and Treasury Inspector General for Tax Administration ( [TIGTA](https://www.treasury.gov/tigta/)) on program related issues.

7. Responds to Employee Suggestions and various Congressional inquiries.


3. The Chief, Accounting and Tax Payment Branch reports to the Director, SP.

4. The following sections report to the Accounting and Tax Payment Branch:



   - Electronic Payment Section

   - Lockbox Policy and Oversight Section

   - Accounting and Deposit Section


5. The office symbols for the Accounting and Tax Payment Branch are C:DC:TS:CAS:SP:ATP.


**1.1.13.6.6.2.1** **(02-26-2020)**

###### Electronic Payment Section

1. **Mission:** To create policies and procedures for the development and deployment of electronic methods of collecting tax payments, to continue improving and supporting existing electronic methods, and to promote and encourage electronic methods as the preferred form of payment.

2. To accomplish the mission, Electronic Payment Section:



01. Coordinates the development of initiatives related to electronic payments with the Fiscal Service (FS), Federal Reserve Bank (FRB), Information Technology (IT), a Treasury Financial Agent (TFA) and other impacted operations.

02. Continuously monitors and manages multiple types of electronic payments, which are processed through Electronic Federal Tax Payment System (EFTPS)/Electronic Federal Payment Posting System (EFPPS) Automated Clearing House (ACH) credit/debit, bulk provider, batch provider, EFTPS web and phone, EFTPS for Federal Agencies, electronic payments from compliance programs including: FS, Social Security Administration (SSA) and state levy programs, Electronic Funds Withdrawal (EFW), Remittance Strategy-Paper Check Conversion (RS-PCC), same-day wires, single-debit, credit cards, etc.

03. Develops roles and responsibilities for the TFA, as well as creates and provides the TFA with program requirements for electronic payment programs and initiatives.

04. Collaborates with stakeholders, such as other customers, and with business partners (FS and IT), to develop strategies for meeting operational goals.

05. Works closely with IRS Cybersecurity to ensure programs, applications, and their users, adhere to strict security and disclosure policies.

06. Works in conjunction with three credit card processors (Link2Gov Corporation, Official Payments Corporation and WorldPay US, Inc.) in offering this option for paying taxes.

07. Monitors transactions related to electronic payments including, processed, scheduled and cancelled payments.

08. Requests, reviews, creates and tracks a host of reports related to electronic payments.

09. Monitors and ensures all electronic payment programs are fully operational.

10. Works closely with the TFA to resolve problems such as rejected files, equipment malfunctions, review and respond to incident reports etc.

11. Provides voice response scripts and standard response language used by IRS and TFA customer service representatives.

12. Requests, provides input for, and participates in various types of marketing surveys related to electronic payments and conducts periodic script reviews.

13. Supports Marketing and Media and Publications by reviewing and updating material related to electronic payments; also works closely with a marketing contractor, to produce various materials made available to taxpayers such as payment request letters, cover letters, guides, etc.

14. Provides content for various websites, such as irs.gov/payments and ETA Reports, EFTPS, and credit cards.

15. Coordinates with IT, FS and TFA to ensure various testing is performed such as, Independent Validation and Verification (IV&V), Participants Acceptance Test (PAT), Systems Acceptability Test (SAT), and conducts periodic script and review.

16. Conducts training and provides guidance to Submission Processing functional areas including the Ogden Accounting Unit where EFTPS perfection occurs.

17. Responds to Treasury Inspector General for Tax Administration (TIGTA) and Government Accountability Office (GAO) about questions and recommendations for policies, programs and procedures related to electronic payments.

18. Maintains the following IRMs:




       | **IRM Number** | **IRM Title** |
       | :-: | :-: |
       | IRM 3.17.277 | Electronic Payments |
       | IRM 3.17.278 | Paper Check Conversion (PCC) and Remittance Strategy Paper Check Conversion (RS-PCC) Systems |

19. Reviews and provides input to other IRMs, such as IRM 21 (Electronic Funds Withdrawal (EFW) and Credit Card sections), IRM 5.19.9, Automated Levy Program, and others.


3. The Chief, Electronic Payment Section reports to the Chief, Accounting and Tax Payment Branch.

4. The office symbols of the Electronic Payment Section are C:DC:TS:CAS:SP:ATP:EP.


**1.1.13.6.6.2.2** **(02-26-2020)**

###### Lockbox Policy and Oversight Section

1. **Mission:** To provide lockbox program policy, procedures and guidance related to remittance processing, system software, security and internal control management and to provide oversight to ensure all requirements are effectively adhered to by the lockbox network.

2. To accomplish the mission, Lockbox Policy and Oversight Section:



01. Develops and maintains the Lockbox Processing Guidelines (LPG), which contains processing and administrative guidelines and the Lockbox Security Guidelines (LSG) which contains the physical, personnel, courier, remittance and Information Technology (IT) guidelines.

02. Manages the Lockbox network Functional Specification Package (FSP), software requirements and the Lockbox Electronic Network (LEN) file transmission requirements.

03. Collaborates with IRS Research Division to develop performance measure data collection instruments (DCI) for daily and on-site review of incoming Lockbox receipts at the Submission Processing (SP) campuses.

04. Coordinates the development of new work for the Lockbox program and required process changes with SP campuses, other impacted operations, Bureau of the Fiscal Service (BFS) and the Lockbox network.

05. Determines annually if there are any Lockbox computer program changes required and provides recommendations and modifications to the annual program update.

06. Coordinates with IT, BFS, Lockbox financial agents, and SP campuses to perform annual Systems Acceptability Testing (SAT).

07. Provides Media and Publications (M&P) address information for each Lockbox site and SP center for timely printing.

08. Maintains Lockbox and SP campus tax form and payment address information on the official [IRS.gov](https://www.irs.gov/) website.

09. Coordinates testing of pre-printed vouchers between Lockbox and vendor in conjunction with M&P.

10. Supports BFS in the financial agent selection process, if necessary.

11. Supports BFS in the Lockbox Continuity of Operations Plan (COOP).

12. Participates in the annual Lockbox Filing Season Readiness (FSR) process.

13. Determines, in conjunction with BFS, if actions are needed resulting from performance measures.

14. Monitors all theft cases to ensure timely and proper resolution according to the LPG and IRM 3.0.230, Lockbox Processing Procedures.

15. Conducts the annual Lockbox Conference and participates in quarterly Lockbox Conferences with BFS.

16. Conducts on-site reviews of each Lockbox site to ensure quality of services, compliance with Lockbox requirements, and internal control effectiveness and identify areas of emerging risks.


3. The Chief, Lockbox Policy and Oversight Section reports to the Chief, Accounting and Tax Payment Branch.

4. The office symbols for the Lockbox Policy and Oversight Section are C:DC:TS:CAS:SP:ATP:LP.


**1.1.13.6.6.2.3** **(08-29-2025)**

###### Accounting and Deposit Section

1. **Mission:** To provide support and guidance for planning, directing, managing, and executing activities specific to service center accounting programs.

2. To accomplish its mission, Accounting and Deposit Section:



1. Participates in the formalization of short- and long-range program strategies and objectives for Accounting Services.

2. Analyzes technical, operational, and administrative problems relating to the manual deposit, credit and account transfer, losses and shortages, manual refund, erroneous refund, refund intercept, hardcore payment tracer, Service Center Control File (SCCF), Unidentified Remittance File (URF), Dishonored Check File (DCF), Excess Collection File (XSF) and Automated Non-Master File (ANMF) programs.

3. Performs independently and provides leadership to ad hoc groups who conduct special studies, investigations, or projects.

4. Responds to Treasury Inspector General for Tax Administration (TIGTA)/Government Accountability Office (GAO) issues related to Accounting and Deposit Section issues.

5. Works closely with Chief Financial Officer (CFO) on accounting and general ledger issues.

6. Updates/maintains “Courier Service” statement of work documents for each Submission Processing (SP) site.

7. Acts as the liaison to Taxpayer Assistance Center (TAC) offices processing payments.

8. Collaborates with stakeholders, customers, and business partners such as Bureau of the Fiscal Service and IRS Information Technology (IT) to develop strategies for meeting operational goals.


3. The Chief, Accounting and Deposit Section reports to the Chief, Accounting and Tax Payment Branch.

4. The office symbols for the Accounting and Deposit Section are C:DC:TS:CAS:SP:ATP:AD.


**1.1.13.6.6.3** **(08-29-2025)**

##### Program Management/Process Assurance Branch

1. **Mission:** To act as the Submission Processing (SP) central coordination point for both internal and external reviews and reports, to react to reports and findings by ensuring recommendations are implemented, to act as the key focal point for communications with other operating units and divisions as they relate to SP programs and activities, support and monitor program effectiveness and resource usage in the SP centers, determine resource allocations through the Work Plan/Work Schedule process, and establish policies and program guidance for the quality assurance, Measured Employee Performance System (MEPS), and Program Analysis System (PAS) programs.

2. To accomplish its mission, Program Management and Process Assurance:



1. Provides support and oversight to the SP centers on Filing Season Readiness (FSR), business measures, and the Quality Assurance Program.

2. Provides assistance and technical advice to SP centers, and monitors center operations to ensure timely, accurate, and efficient program delivery.

3. Prepares work plans and work schedules for SP programs and activities, including forecasting resource needs and tracking resource utilization.

4. Provides assistance, data and advice for quality review activities.

5. Prepares IRM procedures for SP business measures.

6. Prepares Unified Work Requests (UWRs) for support of business measures.


3. The Chief, Program Management/Process Assurance Branch reports to the Director, SP.

4. The following sections report to the Chief, Program Management and Process Assurance Branch:



   - Monitoring Section

   - Resource Section

   - Coordination Support Section

   - Quality Section


5. The office symbols for Program Management/Process Assurance Branch are C:DC:TS:CAS:SP:PM.


**1.1.13.6.6.3.1** **(08-29-2025)**

###### Monitoring Section

1. **Mission:** To provide assistance and technical advice to Submission Processing (SP) centers and to ensure timely, accurate and efficient program delivery.

2. To accomplish the mission, the Monitoring Section:



01. Provides oversight to centers about program delivery, efficiency and effectiveness.

02. Monitors processing in the SP centers to ensure consistency, track performance, and prepare reports.

03. Conducts conformance reviews and site assistance visits, prepares reports, and validates site performance.

04. Provides direction and oversight to ensure consistency on business measures data gathering and reporting by the centers.

05. Recommends goals for, and tracks business measures results, analyzes data, prepares reports, initiates quality initiatives, and identifies best practices.

06. Prepares IRM procedures for SP business measures and Service Center (SC) monitoring reports.

07. Prepares Request for Information Services (RIS) for support of business measures in coordination with Information Technology (IT).

08. Prepares reports, and Management Information Systems (MIS) requests for SP activities.

09. Coordinates Filing Season Readiness reviews at the site level and reviews site readiness plans.

10. Develops measures for the SP organization.

11. Reviews and analyzes trend data to recommend areas of focus for the SP and Customer Account Services (CAS) Directors.

12. Monitors the implementation of legislation affecting SP operations.

13. Maintains the business measures webpage on the SP website on the IRS intranet that defines business measures methodologies and goals, displays SP measure results, and provides relevant tools, information, and communications to SP functions and all SP centers.

14. Provides oversight and coordination of the Work Planning & Control (WP&C) reports and processes to ensure timely balancing of work, accurate Performance and Cost reports, employee performance reports, and employee time reporting.

15. Provides oversight and coordinates with business units (BUs) that report to the WP&C to ensure proper usage and accuracy of data included in reports.

16. Sets policy, procedure and provides oversight of the error correction and maintenance processes performed by the Reports Teams.

17. Coordinates and communicates Project PCX mainframe processing schedules and report maintenance to the BODs and Tier II processing.

18. Communicates quarterly, end of year, and split week processing needs to field managers (e.g., Single Entry Time Reporting (SETR) cutoffs). This includes physical inventory cut-over procedures.

19. Maintains the following IRMs:




       | **IRM Number** | **IRM Title** |
       | --- | --- |
       | IRM 3.0.275 | Business Results Measures for Submission Processing Functions |
       | IRM 3.30.18 | Reports Teams Instructions for Work Planning and Control |
       | IRM 3.30.19 | Production Control and Performance Reporting |
       | IRM 3.30.50 | Project PCA Production Control Accounting |
       | IRM 3.30.123 | Processing Timeliness: Cycles, Criteria and Critical Dates |
       | IRM 3.30.124 | Campus Monitoring Reports |
       | IRM 3.30.126 | Control Data Analysis |


3. The Chief, Monitoring Section reports to the Chief, Program Management/Process Assurance.

4. The office symbols for the Monitoring Section are C:DC:TS:CAS:SP:PM:M.


**1.1.13.6.6.3.2** **(01-24-2023)**

###### Resource Section

1. **Mission** To develop and review work plans (WP) and work schedules (WS) for all Submission Processing (SP) programs and activities; to coordinate preliminary strategic planning and budget formulation proposals for SP centers; to generate the cost estimate reference IRM and the workload scheduling IRM, and to provide staff support in the preparation and review of cost benefit analysis.

2. To accomplish the mission, the Resource Section:



01. Coordinates cross functional issues with Statistics of Income (SOI), Large Business and International Division (LBI), Tax Exempt and Government Entities (TE/GE), Small Business/Self-Employed (SB/SE), Facilities Management and Security Services (FMSS), Information Technology (IT), and Criminal Investigation (CI) for inclusion in WP and WS.

02. Forecasts workload based on projections from research to anticipate and plan for growth.

03. Solicits assumptions from customers, researches and validates, as necessary, and determines impact on resources.

04. Conducts annual WP review conferences.

05. Conducts annual WS review conferences to refine WP estimates.

06. Supports and monitors program effectiveness and resource usage in the SP centers.

07. Prepares SP input for the strategic planning processes which determine the SP centers’ long-range budgets; ensures budget allocations are adjusted to reflect increased/decreased paper or e-file volumes or changed systemic, procedural or legislative assumptions.

08. Authors IRM 3.30.10, Cost Estimate Reference, IRM 3.30.20 , Organization, Function, and Program (OFP) Codes, and IRM 3.30.127, Workload Scheduling.

09. Provides staff support for the review and development of cost benefit analyses.

10. Provides training on WP, WS and costing techniques, as requested.

11. Owns the Suite of Tools for the Review and Creation of Automated Work Plans and Schedules (STRAWS) and maintains the Organization Function Program (OFP) Code website.

12. Recommends goals for and tracks SP efficiency measure results, analyzes data, and prepares reports for input into the Business Performance Review System (BPRS) and PAC 2B Report and critical measures.

13. Supports and monitors program effectiveness and resource usage in the SP centers and coordinates all financial reviews at the program level and provides input to Customer Account Services (CAS) Finance.


3. The Chief, Resource Section reports to the Chief, Program Management/Process Assurance.

4. The office symbols for Resource Section are C:DC:TS:CAS:SP:PM:R.


**1.1.13.6.6.3.3** **(08-29-2025)**

###### Coordination Support Section

1. **Mission:** To provide support, coordination, and oversight to the Submission Processing (SP) centers and headquarters SP staffs in the areas of business resumption/continuity, National Treasury Employees Union (NTEU) notifications, Annual Assurance Review (AAR), program and training travel, space and property, physical and remittance security, Internal Revenue Manual (IRM), recruitment, training, shutdown contingency planning, Volunteer Income Tax Assistance (VITA), and Request for Organizational Change (ROC).

2. The focus of Coordination Support Section is to:



1. To provide program support through data, analysis and quality improvements to SP headquarters, field directorates, and other business units.


3. To accomplish this mission, Coordination Support Section:



01. Coordinates cross unit issues for SP sites and acts as liaison with Site Coordinators and Planning and Analysis (P&A) Chiefs in the centers and coordinates with BODs and organizations (outside of Submission Processing) that report to the WP&C.

02. Coordinates administrative duties including operational space issues, physical moves, and equipment needs for the SP headquarters staff in Covington, Kentucky.

03. Serves as contacts for space and property issues in the SP centers; acts as liaison when other business units are affected.

04. Acts as liaison and provides communications to other operating units and divisions as related to SP programs and activities.

05. Provides guidance to the centers and headquarters staff for the AAR.

06. Provides program support to the center campuses for the Business Resumption/Business Continuity and Physical and Remittance Security Programs.

07. Provides advice and assistance to center management on recruitment and other personnel-related issues, acts as liaison with HCO, monitors centers’ progress in meeting recruitment needs, and coordinates the Office of Government Ethics (OGE), OGE Form 450, Confidential Financial Disclosure Report, reporting requirements.

08. Researches and coordinates training policies and procedures, coordinates training requests that require input from SP headquarters and campuses, coordinates annual training needs assessment and coordinates training for SP headquarters personnel.

09. Coordinates with headquarters and Media and Publications to ensure the timely update and issuance of SP IRMs.

10. Coordinates and serves as the key point of contact for the VITA, program and training travel, NTEU notifications, and ROC programs.

11. Authors the following IRM:




       | **IRM Number** | **IRM Title** |
       | :-: | :-: |
       | IRM 3.0.276 | General, Scorecard Performance Measure Process - Security and Internal Control Review |


4. The Chief, Coordination Support Section reports to the Chief, Program Management/Process Assurance.

5. The office symbols for the Coordination Support Section are C:DC:TS:CAS:SP:PM:CS.


**1.1.13.6.6.3.4** **(08-29-2025)**

###### Quality Support Section

1. Mission: To provide support, coordination, and oversight to the Submission Processing (SP) centers and headquarters SP staffs in the areas of the Embedded Quality Submission Processing (EQSP) program (including the Measured Employee Performance System (MEPS)).

2. The focus of Quality Support Section is to:



1. Monitor the quality of all SP products and identify systemic as well as site specific opportunities for improvement.


3. To accomplish this mission, Quality Support Section:



01. Acts as liaison and provides communications to other operating units and divisions as related to SP programs and activities.

02. Develops and implements data collection instruments (DCI) for functions and programs within SP. Coordinates with IRM authors to ensure DCIs are current. Provides oversight to SP centers about use of the EQSP system.

03. Monitors the implementation of new procedures and processes to assess impact to EQSP and MEPS.

04. Coordinates with SP centers to improve the accuracy and the effectiveness of the EQSP system.

05. Monitors quality data from EQSP and prepares quality statistic summary reports for SP headquarters and Field Directors and elevates defect trends.

06. Performs EQSP coding consistency reviews by analyzing the defects input by Quality Reviewers.

07. Maintains the EQSP website which provides guidance to reviewers, information for improvement specialists, and quality charts and graphs showing weekly and Quarterly data.

08. Coordinates quality initiatives by providing guidance, oversight and support to the SP Improvement Specialists in the field.

09. Coordinates targeted EQSP sampling to meet High Quality Function minimum quarterly samples and MEPS recommended annual sample requirements per employee.

10. Provides direction and oversight for the Measured Employee Performance System (MEPS).

11. Performs defect trend analysis to identify areas for improvement.

12. Provides oversight and coordination for the release and recall activities.

13. Responds to Treasury Inspector General for Tax Administration (TIGTA)/Government Accountability Office (GAO) issues related to Program Management/Process Assurance Branch issues.

14. Authors the following IRMs:




       | IRM | Title |
       | --- | --- |
       | IRM 3.30.30 | Embedded Quality for Submission Processing (EQSP) System |
       | IRM 3.43.405 | Measured Employees Performance System (MEPS) for Managers |


1. Authors the following training materials: Measured Employees Performance System (MEPS) Managers and Employee Guides, Embedded Quality Submission Processing (EQSP) Managers and Reviewers Guides.


4. The Chief, Quality Support Section reports to the Chief, Program Management/Process Assurance.

5. The office symbols for the Quality Support Section are C:DC:TS:CAS:SP:PM:QS.

6. The office symbols for TIGTA/GAO is C:DC:TS:CAS:SP:PM:T.


**1.1.13.6.6.4** **(08-29-2025)**

##### Specialty Programs Branch

1. **Mission:** To provide guidance, establish policy, technical support and procedures for On-Line Notice Review, Files, Identity Theft (IDT), Individual Master File (IMF)/Business Master File (BMF) unpostables, IMF/BMF Entity, Individual Taxpayer Identification Number (ITIN), and Acceptance Agent (AA) programs, and the Return and Income Verification Services (RAIVS)/Income Verification Express Service (IVES) programs in the Submission Processing (SP) centers.

2. The Specialty Programs Branch (SPB) tracks and coordinates all legislative changes including Affordable Care Act (ACA), Information Return Document Matching (IRDM), Foreign Account Tax Compliance Act (FATCA) within SP to ensure all business requirements and Unified Work Requests (UWRs) for Information Technology (IT) systems are submitted timely and accurately.

3. To accomplish its mission, the Specialty Programs Branch:



1. Provides policy, procedures, operational oversight and support to the field and the Director, SP for programs listed in (1) above.

2. Determines business requirements and coordinates the UWRs for submission to IT to incorporate into the SP systems.

3. Coordinates all issues related to administering the ITIN and AA programs, such as policy interpretation for the processing centers, oversight and monitoring of ITIN application processing and approval of Acceptance Agent applications.

4. Manages the Files function, the associated National Archives and Records Administration (NARA) contract, and the Information Exchange Agreements (IEA) between the Social Security Administration and IRS on Numident and Death Master File.

5. Provides oversight and guidance for the United States Department of Agriculture (USDA) program in the Austin SP and Memphis center.


4. The Chief, Specialty Programs Branch, reports to the Director, SP.

5. The following sections report to the Specialty Programs Branch:



   - ITIN Policy Section

   - Post Processing Section

   - Technical Support Section


6. The office symbols for the Specialty Programs Branch are C:CS:TS:CAS:SP:SPB.


**1.1.13.6.6.4.1** **(08-29-2025)**

###### Individual Taxpayer Identification Number (ITIN) Policy Section

1. **Mission:** To ensure ITINs are issued timely to qualifying individuals and used only for tax administration purposes. This is accomplished through enhancing safeguards, increasing public outreach and education, developing improved methods and procedures to apply for and process ITIN applications, and improving technical training and work processes for IRS employees. These tasks are done to advance the overall Service goal of customer satisfaction, educational outreach and compliance within applicable tax laws.

2. To accomplish its mission, the Individual Taxpayer Identification Number (ITIN) Policy Section:



1. Develops and implements an annual strategic program plan that details or references the ITIN related activities of each functional area including Customer Assistance, Relationships and Education (CARE), Accounts Management (AM) Field Assistance and Compliance.

2. Develops, tests, and implements new procedures to facilitate improved ITIN processing and the proper use of ITINs.

3. Works independently and with other functions or independently to develop and maintain relationships with external stakeholders (community-based organizations, acceptance agents, and practitioners) to promote and facilitate the proper use of ITINs.


3. The Chief, IPS reports to the Chief, Specialty Programs Branch.

4. The office symbols for the IPS are C:DC:TS:CAS:SP:SPB:ITIN.


**1.1.13.6.6.4.2** **(01-24-2023)**

###### Post Processing Section

1. **Mission:** To develop policy, procedures, and guidance for various programs outside of the pipeline functions including:



   - On-Line Notice Review

   - Individual Master File (IMF)/Business Master File (BMF) unpostables

   - IMF/BMF Entity

   - Amended Returns (1040X)

   - Files and the associated National Archives and Records Administration (NARA) contract

   - Submission Processing (SP) Identity Theft (IDT) unpostables

   - Foreign Account Tax Compliance Act (FATCA)

   - Generalized Unpostable Framework (GUF)

   - Technical review for Form 3949-A


2. To accomplish its mission, the Post Processing Section:



01. Develops policy, procedures, and guidance for Correspondence Problem Resolution and Notice Review functions for the three SP centers.

02. Performs notice problem identification, resolution, and reporting.

03. Plans, coordinates, and participates in notice start-up activities.

04. Develops and maintains the Notice Review Processing System (NRPS) and On-Line Notice Review (OLNR).

05. Provides for the storage and retention of tax returns and related documents at the three SP centers and at the Federal Records Centers (FRCs).

06. Provides procedures for establishing, maintaining and updating entities on the Master File for IMF/BMF.

07. Provides business requirements and writes Unified Work Requests (UWRs) for all aspects of processing entity unpostables, unpostables, and On-Line Notice Review.

08. Establishes guidance and processes for the new FATCA registration process in Austin SP.

09. Provides guidance and procedures for SP IDT unpostables.

10. Provides guidance, procedures, and monitoring of the SP centers 1040X functions.


3. The Chief, Post Processing Section reports to the Chief, Specialty Programs Branch.

4. The office symbols for the Post Processing Section are C:DC:TS:CAS:SP:SPB:PP.


**1.1.13.6.6.4.3** **(08-29-2025)**

###### Technical Support Section

1. **Mission:** To develop policy, procedures, and guidance for various programs outside of the pipeline functions including: legislative changes, Return and Income Verification Services (RAIVS)/Income Verification Express Service (IVES), and Unified Work Request (UWR) coordination for Submission Processing (SP).

2. To accomplish its mission, the Technical Support Section:



1. Provides support and oversight to the three SP centers for RAIVS/IVES and United States Department of Agriculture (USDA) in the Austin SP and Memphis centers.

2. Tracks the status of tax law legislative changes and communicates SP impact to SP headquarters branches.

3. Establishes guidance and processes for SP work stemming from tax law legislative changes and initiatives as part of UWR coordination.

4. Coordination of all SP UWRs.


3. The Chief, Technical Support Section reports to the Chief, Specialty Programs Branch.

4. The office symbols for the Technical Support Section are C:DC:TS:CAS:SP:SPB:T.


**1.1.13.6.6.5** **(08-29-2025)**

##### e-File Services

1. **Mission:** To manage all strategic and day-to-day business activities for the IRS electronic filing program. This includes the development and support of information technology solutions and the re-engineering of business processes to improve the internal and external effectiveness and efficiency of electronic filing (e-file) services.

2. To accomplish the mission, e-File Services:



1. Develops the e-File Services business strategy.

2. Determines the sequence of the content master plan release.

3. Supports E-300 initiative planning and budget activities, business rule harvesting, business requirements management, updates and maintenance of e-file computer systems, and second level customer support.

4. Addresses security and privacy requirements.

5. Develops testing procedures for external partners, transition management, engagement and communications with internal and external stakeholders.

6. Administers the electronic filing federal/state program.

7. Responds to congressional inquiries.

8. Evaluates input from government oversight organizations e.g., Government Accountability Office (GAO)/Treasury Inspector General for Tax Administration (TIGTA), Electronic Tax Administration Advisory Committee (ETAAC), IRS Oversight Board as it pertains to electronic filing.


3. The Director, e-File Services reports to the Director, Submission Processing (SP).

4. The following branches report to e-File Services:



   - Development Services Branch

   - IMF Services Branch

   - BMF Services Branch

   - Electronic Support Services Branch

   - Industry Engagement and Strategy Branch


5. The office symbols for e-File Services are C:DC:TS:CAS:SPEF.


**1.1.13.6.6.5.1** **(08-29-2025)**

###### Development Services Branch

1. **Mission:** To ensure the successful simultaneous development of new electronic filing capabilities in support of IRS strategic business initiatives and the deployment of new functionality in support of the filing season.

2. To accomplish its mission, the Development Services Branch:



01. Perform strategic planning to ensure alignment with Taxpayer Services (TS) Future State Initiatives and IRS Modernization Plans.

02. Collaborates with Business Units, Tax Forms and Publications, and IT to determine requirements needed to develop new legislatively driven or existing paper forms for the Modernized e-File (MEF), Affordable Care Act Information Returns (AIR), or Information Return Intake System (IRIS) electronic filing platforms.

03. Develops business requirements for new electronic filing capabilities, including record layouts, schema, stylesheets, business rules, Generalized Mainline Framework (GMF), National Accounts Profile (NAP) for MEF related products.

04. Develops business requirements for new electronic filing capabilities including record layouts, schema, business rules for software companies, and business rules specific to application to application A2A intake of information returns. Assists with the development of the Taxpayer Portal wireframes and taxpayer education.

05. Conducts internal stakeholder training in support of new releases and the filing season.

06. Communicates and engages external software developers, transmitters, state and local revenue agencies, government agencies, and information return filers regarding tax and information returns in preparation for and supporting of filing season readiness.

07. Develops Assurance Testing System (ATS) scenarios, makes available for external testing, coordinates internal support for AIR, MEF, and IRIS filing systems.

08. Supports and monitors internal testing.

09. Monitors and supports the filing communities by analyzing and resolving defects.

10. Develops supporting documentation, including IRM updates, external communications such as IRS.gov web pages, and internal training material and manuals. This includes updating critical publications for MEF, AIR, and IRIS. DSB also is the owner of Publication 5164 Test Package for Electronic Filers of Affordable Care Act (ACA) Information Returns (AIR) Processing Year 2023 and Publication 5719, Information Returns Intake System (IRIS) Test Package for Information Returns.

11. Manages the transition of forms that Development Services has deployed once the forms are deemed stable to either the IMF Services Branch or the BMF Services Branch.


3. The Chief, Development Services Branch reports to the Director, e-File Services.

4. The following sections report to the Development Services Branch:



   - Development Services Section 1

   - Development Services Section 2

   - Development Services Section 3


5. The organization symbols for Development Services Branch are C:DC:TS:CAS:SP:DS.


**1.1.13.6.6.5.2** **(08-29-2025)**

###### IMF Services Branch

1. **Mission:** To ensure ongoing operations and maintenance of electronic filing capabilities previously deployed for Individual Master File (IMF) return processing, including requirements analysis and development pertaining to legislative changes and expiring provisions.

2. To accomplish its mission, the IMF Services Branch:



01. Coordinates annual product maintenance.

02. Oversees product preparation for the filing season.

03. Monitors and supports the filing season by conducting Controlled Launch/Submission Review activities to ensure the accuracy of the Business Rules, Code and Edit Rules, Stylesheet displays, Schema contents, Software ID usage, Master File postings, and payment processing.

04. Conducts post filing season assessment.

05. Participates in external forums and other professional conferences as required.

06. Supports e-file marketing and communication efforts.

07. Oversees the operation of the Modernized e-File (MeF) IMF Services Branch SharePoint site collection.

08. Participates in Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) audits, improving operations as recommended.

09. Reviews IRMs and publications to ensure accuracy and consistency in all electronic and paper tax return filing.

10. Reviews MeF documentation to ensure accurate implementation of requirements.

11. Maintains IRM 3.42.5, IRS e-File for Individual Tax Returns.

12. Assists external customers with understanding the filing requirements by addressing questions received through the MeF mailbox and the e-help desk.

13. Maintains [IRS.gov](http://www.irs.gov/) content related to the electronic filing of individual returns.

14. Manages the implementation of the individual e-File Assurance Testing System (ATS) by ensuring the testing specifications are updated annually and published timely. Prepares QuickAlerts to inform external stakeholders of individual e-file related requirement changes.

15. Prepares internal Revenue Workflow Optimization, Request, and Knowledge System (IRWorks) to resolve programming issues.


3. The Chief, IMF Services Branch reports to the Director, e-File Services.

4. The following sections report to IMF Services Branch:



   - Individual e-File Section 1

   - Individual e-File Section 2

   - Individual e-File Section 3


5. The office symbols for IMF Services Branch are C:DC:TS:CAS:SP:IMF.


**1.1.13.6.6.5.2.1** **(08-29-2025)**

###### Individual e-File Sections

1. **Mission:** To ensure timely, accurate, and efficient program delivery of Individual Master File (IMF) e-file requirements for a successful filing season.

2. To accomplish its mission, Individual e-File Sections:



01. Researches and maintains forms and schedules in the Form 1040 family that are part of the 1040 e-file program.

02. Maintains and supports the yearly changes to Generalized Mainline Framework (GMF) in support of Core Record Layout (CRL) changes for Paper Processing Branch.

03. Maintains the MeF IMF Enterprise Application Integration Broker (EAIB) for checking National Account profile (NAP) and Duplicate TINs.

04. Manages the annual implementation of the Assurance Testing System (ATS) program for Individual e-file returns/documents.

05. Supports the annual implementation of the Electronic Federal Tax Payment System (EFTPS).

06. Ensures ATS specifications and electronic filing specifications (Pub 1436, Assurance Testing System (ATS) Guidelines for Modernized e-File (MeF) Individual Tax Returns) are updated annually and published/posted to the web timely.

07. Evaluates new legislation and determine its impact on e-filing requirements.

08. Originates and coordinates Unified Work Requests (UWRs) with the branch and other internal stakeholders.

09. Supports digitalization and scanning initiatives to increase electronic filing participation.

10. Provides support for filing season start-up at designated hub sites.

11. Coordinates timely posting of updated Individual e-File Business Rules and Schema to the Secure Object Repository (SOR) for external stakeholders.

12. Coordinates timely posting of updated Individual e-File Business Rules and Schema to the Servicewide Electronic Research Program (SERP) for internal stakeholders.

13. Supports and serves as a program consultant on current Taxpayer Services (TS) and other business units (BUs) marketing of e-file programs.

14. Ensures annual maintenance activity for federal/state e-file products.

15. Provides support to the states for the federal/state program.

16. Supports Integrated Data Retrieval System (IDRS) Philadelphia Unit as Unit Security Representative (USR) and Alternate USR.

17. Participates in quality review (QR) and on-site testing.

18. Oversees the submission and processing of Form 8453, U.S. Individual Income Tax Transmittal for an IRS e-file Return and required paper forms or supporting documentation.

19. Manages the requirements for the Practitioner Personal Identification Number (PIN) Program.

20. Manages the requirements for the Self-Select PIN Program.

21. Researches and prepares responses to Congressional Inquiries, Treasury Inspector General for Tax Administration (TIGTA) Audits, and Employee Suggestions.

22. Maintains web ( [IRS.gov](https://www.irs.gov/)) content related to program assignments.

23. Responds to ad hoc requests related to programs within the section’s responsibility and requests not falling into a specific program responsibility in the branch.


3. The Chiefs, Individual e-File Sections 1, 2 and 3 report to the Chief, IMF Services Branch.

4. The office symbols for e-File Sections 1, 2 and 3 are C:DC:TS:CAS:SP:IMF:I1, C:DC:TS:CAS:SP:IMF:I2, and C:DC:TS:CAS:SP:IMF:I3.


**1.1.13.6.6.5.3** **(08-29-2025)**

###### BMF Services Branch

1. **Mission:** To support customer-valued e-solutions for Servicewide electronic products and services by advancing IRS electronic business opportunities to meet the changing demands of the future while delivering a positive customer experience.

2. To accomplish its mission, the BMF Services Branch:



01. Coordinates annual product maintenance and prepares and tracks Unified Work Requests (UWRs), ensuring requirements are implemented timely and accurately.

02. Oversees product preparation for the filing season.

03. Prepares Secure Object Repository (SOR) and Servicewide Electronic Research Program (SERP) distributions (BMF Schema/Business Rule Packages).

04. Oversees the filing season; conducts Controlled Launch/Submission Review activities to ensure the accuracy of the Business Rules, Code and Edit Rules, Stylesheet displays, Schema contents, Software ID usage, Master File postings, and payment processing.

05. Conducts post filing season assessment.

06. Reviews and analyzes trend data to recommend areas of focus for paper processing and electronic filing processing.

07. Conducts process improvements to enhance quality and operational efficiency.

08. Serves as a Subject Matter Expert on sub-teams in support of the Growing Business e-file Strategy.

09. Participates in external forums and other professional conferences as required.

10. Supports e-file marketing and communication efforts.

11. Oversees the operation of the Modernized e-File (MeF) SharePoint site collection.

12. Participates in Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) Audits, improving operations as recommended.

13. Reviews IRMs and publications to ensure accuracy and consistency in all electronic and paper tax return filing.

14. Reviews MeF documentation to ensure accurate implementation of requirements.

15. Maintains [IRS.gov](https://www.irs.gov/) content related to the electronic filing of business returns.

16. Ensures annual maintenance activity for federal and state e-file products.

17. Develops Federal/State Memorandums of Understanding (MOUs).

18. Provides support to the states for the federal/state program and supports the annual Federation of Tax Administrators (FTA) symposium.

19. Prepares QuickAlerts to inform external stakeholders of business e-file related requirement changes.

20. Approves Knowledge Incident/Problem, Internal Revenue Workflow Optimization Request, and Knowledge System (IRWorks) to resolve programming issues.


3. The Chief, BMF Services Branch reports to the Director, e-File Services.

4. The office symbols for BMF Services Branch are C:DC:TS:CAS:SP:EFS:BMF:B1, C:DC:TS:CAS:SP:EFS:BMF:B2 and C:DC:TS:CAS:SP:EFS:BMF:B3.


**1.1.13.6.6.5.3.1** **(08-29-2025)**

###### BMF Sections 1, 2, and 3

1. To accomplish the BMF mission, the Section(s) are responsible for the following:



01. Evaluates new legislation and determines its impact on U.S. Corporation Income Tax Partnership Income, and shared forms for MeF requirements; ensuring the accuracy of Business Rules, Code and Edit Rules, Dependencies, Generalized Mainline Framework (GMF), Schemas, and Stylesheets.

02. Evaluates new legislation and determines its impact on for Estates and Trusts, Employment Tax and Excise tax returns, and shared forms for MeF requirements; ensuring the accuracy of Business Rules, Code and Edit Rules, Dependencies, Generalized Mainline Framework (GMF), Schemas, and Stylesheets.

03. Analyzes technical, operational, and administrative problems which exist or may arise in programs relating to BMF Form Tax Types (94x Family, 720, 1065, Form 1120, and shared forms MeF processing.

04. Coordinates program activities with other e-file program managers and analysts to address cross-functional issues, develop strategies, and ensure consistency of approach.

05. Serves as a program consultant on current Taxpayer Services (TS) and Small Business/Self-Employed (SB/SE) marketing of e-file programs.

06. Participates (gathers data and acts as consultant) on various research projects.

07. Prepares, develops, and tracks section Unified Work Requests (UWRs); ensuring timely and accurate implementation of requirements.

08. Responds to ad hoc requests not applicable to a specific branch, section, or analyst.

09. Manages the implementation of the business e-file Assurance Testing System (ATS) and ensures testing specifications of electronic filing are updated annually and timely published to [IRS.gov](https://www.irs.gov/) for Form 720, Quarterly Federal Excise Tax Return, Form 94x Employment Tax Series, Form 1041, U.S. Income Tax Return for Estates and Trusts, Form 2290, Heavy Highway Vehicle Use Tax Return, Form 8849, Claim for Refund of Excise Taxes, Form 1120, U.S. Corporation Income Tax, Return, Form 1065, U.S. Return of Partnership Income, and shared forms.

10. Maintains IRM 3.42.4, IRS e-File for Business Tax Returns.

11. Maintains Publication 4164, Modernized e-File (MeF) Guide for Software Developers and Transmitters.

12. Maintains Publication 5078, Assurance Testing System (ATS) Guidelines for Modernized e-File (MeF) Business Submissions, which contains general and program specific testing information for all business form types for use in completing the ATS process.

13. Prepares Knowledge Incident/Problem, Service and Asset Management (KISAMs) to resolve programming issues.

14. Assists external customers with understanding the filing requirements by addressing questions received through the MeF mailbox and the e-Help desk.


**1.1.13.6.6.5.4** **(08-29-2025)**

###### Electronic Support Services Branch

1. **Mission:** ESS is dedicated to delivering a top-quality electronic filing experience by fostering close relationships with our internal and external stakeholders through open lines of communication and technical support, while maintaining continuity of internal security policies to protect Submission Processing systems.

2. To accomplish its mission, the Electronic Support Services Branch:



1. Prepares filing season statistical recaps, system performance information, and briefing material in support of E-300 initiative planning and budget process, and congressional and government oversight inquiries.

2. Manages filing season shutdown, cut-over, and start-up activities and communications.

3. Prepares and shares highly complex statistical data with employees across Taxpayer Services (TS). Works closely with Business Objects Enterprise (BOE) administrators to improve the end user experience.

4. Supports the IRS’s collaborative effort with the tax industry and the states to help combat stolen identity refund fraud.

5. Researches and briefs senior leadership if a proposed requirement change will cause any negative impacts on electronic tax or information returns.

6. Provides formal responses to Treasury Inspector General for Tax Administration (TIGTA) inquiries, Congressional requests, and other information document requests.


3. The Chief, Electronic Support Services Branch reports to the Director, e-File Services.

4. The following sections report the Electronic Support Services Branch:



   - Section 1

   - Section 2


5. The office symbols for the Electronic Support Services Branch are C:DC:TS:CAS:SP:ESS.


**1.1.13.6.6.5.4.1** **(08-29-2025)**

###### Electronic Support Services Section 1

1. **Mission:** Section 1 enriches Taxpayer service by delivering continuous exceptional technical support through a variety of channels to our internal and external business partners; while ensuring consistent application of security standards, policies, and procedures across Submission Processing Systems.

2. To accomplish its mission, Section 1:



01. Provides technical support to software developers, transmitters, and states as they move from testing to production status.

02. Maintains the application-to-application toolkit used by software developers and states to develop their electronic filing applications that interface with the IRS.

03. Opens, tracks, and works with Information Technology (IT) to resolve Knowledge, Incident/Problem, Service Asset Management (KISAM) programming issues.

04. Responds to elevated inquiries made through the Modernized e-File (MeF) and ACA Information Returns (AIR) mailboxes.

05. Manages and resolves Level 2 cases reported through the e-help desk, Accounts Management, and National Account Managers.

06. Works with SP, Affordable Care Act, and IT branches, Development Services, IMF Operations and Maintenance Services Branch and BMF Operation and Maintenance Services Branch on enhancement requirements to address performance and functionality gaps.

07. Participates in internal and external stakeholder testing and production calls.

08. Serves as content managers for the SP content published for software developers and transmitters on [IRS.gov.](https://www.irs.gov/)

09. Maintains MeF operational status on [IRS.gov.](https://www.irs.gov/)

10. Ensures the systems owned by SP follow the guidance specified in the FISMA.

11. Maintains the SP website on the IRS intranet, which supports the SP mission and provides relevant tools, information and communications to functions across all business units (BUs).

12. Maintains the Electronic Tax Administration Research and Analysis System and ERWS databases and e-file reports webpage.

13. Provides statistical reports on electronically filed returns.

14. Reviews and approves all Unified Work Requests for the division.


3. The Chief, Section 1 reports to the Chief, Electronic Support Services Branch.

4. The office symbols for the Customer Outreach and System Support Section are C:DC:TS:CAS:SP:ESS:ES1.


**1.1.13.6.6.5.4.2** **(08-29-2025)**

###### Electronic Support Services Section 2

1. **Mission:** Section 2 team is committed to fulfilling our external and internal customer’s electronic filing needs by providing accurate and timely responses to customer inquiries while continually improving the taxpayer experience.

2. To accomplish its mission, Section 2:



01. Supports technical support to software developers and transmitters as they move from testing to production status.

02. Manages and resolves Level 2 cases reported through the e-help desk, Accounts Management, and CMS.

03. Manages and responds to inquiries made through the IRS Modernized e-File (MeF) and AIR email accounts.

04. Works with Submission Processing, Affordable Care Act (ACA), Information Technology (IT), Development Services, IMF Operations and Maintenance Services Branch, and BMF Operation and Maintenance Services Branch on enhancement requirements to address performance and functionality gaps.

05. Issues technical quick alerts and acts as gatekeeper of all external technical communications.

06. Hosts and manages internal and external stakeholder testing and production calls.

07. Presents information at external and internal conferences.

08. Manages filing season shutdown, cut-over, and start up activities and communications.

09. Serves as content managers for the AIR and MeF content published for software developers and transmitters on [IRS.gov.](https://www.irs.gov/)

10. Maintains MeF and AIR operational status on [IRS.gov.](https://www.irs.gov/)


3. The Chief Section 2 reports to the Chief, Electronic Support Services Branch.

4. The office symbols for Section 2 are C:DC:TS:CAS:SP:ESS:ES2.


**1.1.13.6.6.5.5** **(08-29-2025)**

###### Industry Engagement and Strategy Branch

1. **Mission:** To provide expertise and guidance to internal and external customers to enable the development or refinement of e-filing strategies and policies, and to coordinate resolution of large-scale issues affecting the tax ecosystem, in order to achieve viable electronic tax administration solutions.

2. To accomplish its mission, the Industry Engagement and Strategy Branch:



1. Administers the Free Filing Program.

2. Supports the needs of internal business organizations to interact with the largest external partners successfully.

3. Supports the broad tax ecosystem by enabling external partners to interact successfully with the IRS.

4. Supports the Affordable Care Act.


3. To further accomplish the mission, the Industry Engagement and Strategy Branch provides guidance to internal and external stakeholders via channels and groups including:



   - Council for Electronic Revenue Communication Advancement (CERCA)

   - National Association of Computerized Tax Processors (NACTP)

   - Industry leaders within tax-ecosystem via the National Account Management (NAM) program.

   - IRS Pre-Filing Season Meeting

   - Reporting Agents Forum (RAF)

   - Software Developers Conference

   - Payroll Industry Calls

   - Largest Transmitters Conference Calls

   - Free File Alliance

   - Contact Center Forum (CCF)

   - Affordable Care Act (ACA) agencies, including the Centers for Medicaid and Medicare Services (CMS) and Federal and State-Based Exchanges


4. The Chief, Industry Engagement and Strategy Branch reports to the Director, e-File Services.

5. The office symbols for the Industry Engagement and Strategy Branch are C:DC:TS:CAS:SP:IES:.


**1.1.13.6.6.6** **(01-24-2023)**

##### Submission Processing (SP) Field Directors (Austin, Kansas City, and Ogden)

1. **Mission:** To provide America's taxpayers with top-quality customer service by timely and efficiently processing all Individual Master File (IMF) and Business Master File (BMF) tax returns, documents, payments and refunds, including processing of international returns.

2. To accomplish the mission, the SP centers:



1. Oversee day-to-day operations for SP.

2. Formulate short and long-range program policy guidance, strategies and objectives.

3. Coordinate program activities with the Director, Customer Account Services (CAS), and Director, SP, to prepare Servicewide policy guidance, address cross-functional issues, develop strategies and ensure consistency of approach.

4. Direct statistical analysis and evaluation of the elements comprising SP's business measures.

5. Ensure subordinate managers operate as an effective management team and handle all management functions in an equitable and responsive manner to meet the needs of customers.

6. Coach subordinate managers and assist in the resolution of complex issues.


3. The three SP Field Directors for Austin, Kansas City, and Ogden report to the Director, SP.

4. The following Operations report to the Field Directors, SP centers:



   - Site Coordinator

   - Receipt and Control Operation

   - Data Conversion Operation

   - Document Perfection Operation

   - Input Correction Operation

   - Planning and Analysis

   - Accounting Operation

   - Statistics of Income (SOI) Operation (Ogden only)

   - Individual Taxpayer Identification Number (ITIN)


5. The office symbols for the Field Directors, SP centers are:



   - Austin - C:DC:TS:CAS:SP:AU

   - Kansas City - C:DC:TS:CAS:SP:KC

   - Ogden - C:DC:TS:CAS:SP:O


**1.1.13.6.6.6.1** **(09-01-2005)**

###### Site Coordinator

1. **Mission:** To coordinate issues impacting the campuses by representing Submission Processing (SP), Accounts Management (AM), and Return Integrity and Compliance Services (RICS) Directors in addressing cross-functional issues and emerging areas of concern.

2. To accomplish the mission, the Site Coordinators:



1. Provide the primary support for the cross-unit coordination council by overseeing major activities that affect multiple functions with different reporting structures.

2. Serve as primary liaison to ensure administrative and logistical support is provided to all campus entities by working with Information Technology (IT), Facilities Management and Security Services (FMSS) and other shared services.

3. Oversees and provides administrative supervision to one or more Interpreters who provide sign language interpretation for employees and visitors in all campus functions.


3. The Site Coordinators report to the SP Field Directors.

4. The Analytical Support staff reports to the Site Coordinator.


**1.1.13.6.6.6.2** **(08-29-2025)**

###### Receipt and Control Operation

1. **Mission:** To efficiently and accurately receive, batch and distribute tax returns, taxpayer correspondence, and other documents, and process payments.

2. To accomplish this mission, the Receipt and Control Operation (RCO):



1. Opens all incoming mail and sorts it to the correct function.

2. Establishes the control systems that monitor returns processing activities.

3. Processes all remittances to maximize cash management practices and availability of funds to the United States Treasury.


3. The RCO Managers report to the Submission Processing (SP) Field Directors.

4. The following Department Managers report to the RCO Managers.



   - Extraction/Batching Department

   - Deposit Department

   - Image Control Team (ICT) Department


**1.1.13.6.6.6.3** **(08-29-2025)**

###### Data Conversion Operation

1. **Mission:** To convert tax return information and other documents to electronic data.

2. To accomplish this mission, the Data Conversion Operation (DCO):



1. Ensures the accurate and complete processing of documents received.

2. Inputs all fact of filing, entity, payment, and tax return information to the IRS computer system for posting to the Master File.

3. Provides photocopies and transcripts of returns to taxpayers and their representatives upon request.


3. The DCO Managers report to the Submission Processing Field Directors.

4. The Data Conversion Department Managers report to the Data Conversion Operation Managers.


**1.1.13.6.6.6.4** **(08-29-2025)**

###### Document Perfection Operation

1. **Mission:** To prepare tax returns and other documents for conversion to electronic data and ensure taxpayer name, address and identification numbers are updated as necessary in the IRS computer system.

2. To accomplish this mission, the Document Perfection Operation:



1. Verifies processing ability of submitted returns.

2. Secures all missing return information from the taxpayer.

3. Prepares returns for input by Data Conversion and inputs address and other entity changes.

4. Provides support to Electronic Return Originators (EROs) and transmitters in the Individual Master File (IMF) sites that support electronic filing.

5. Processes superseding returns, amended returns, and responses to computer paragraph (CP) notices.


3. The Document Perfection Operation Managers report to the Submission Processing Field Directors.

4. The Code and Edit, 1040X, and Entity Department Managers report to the Document Perfection Operation Managers.

5. The e-help Department Managers report to the Document Perfection Operation Managers (Andover and Austin).


**1.1.13.6.6.6.5** **(08-29-2025)**

###### Input Correction Operation

1. **Mission:** To provide support to Submission Processing (SP) Operations by perfecting unprocessable documents and transactions.

2. To accomplish this mission, the Input Correction Operation:



1. Perfects and resolves conditions that prevent transactions from posting to the Master Files.

2. Perfects documents to correct non-processable conditions.

3. Contacts taxpayers to resolve issues relating to name, address and identification number, and missing documentation.

4. Reviews outgoing notices on a sample basis ensuring product accuracy and identifying error trends.

5. Provides support to Electronic Return Originators (EROs) and transmitters in the Business Master File (BMF) sites supporting Electronic Filing.

6. Maintains paper records for receipt, retrieval, retention, retirement, and destruction of tax returns and related documents at the Submission Processing Campuses (SPCs) and the Federal Records Centers (FRCs).


3. The Input Correction Operation Managers report to the SP Field Directors.

4. The following Department Managers report to the Input Correction Operation Managers:



   - Error Resolution Department

   - Unpostables/Rejects Department

   - Notice Review Department

   - Files Department


**1.1.13.6.6.6.6** **(10-07-2013)**

###### Planning and Analysis, Submission Processing

1. **Mission:** To the Field Directors, Submission Processing (SP), ensuring that service policies, programs and procedures are applied uniformly and efficiently.

2. To accomplish this mission, Planning and Analysis:



1. Analyzes processes to identify and resolve systemic and procedural problems.

2. Coordinates specific projects or programs for the Field Director; disseminates and consolidates responses to director's controls received from headquarters, the Director, SP, or other areas.

3. Organizes and monitors implementation of new programs; serves as central contact point for work plan and budgetary matters.

4. Provides filing season oversight that facilitates the timely accomplishment of all program completion dates (PCD).


3. The Planning and Analysis Chief reports to the SP Field Director.

4. The following report to the Planning and Analysis Chief:



   - Planning and Analysis Staff

   - Improvement Team

   - Course Development Staff (Kansas City and Austin only)


**1.1.13.6.6.6.7** **(08-29-2025)**

###### Accounting Operation

1. **Mission:**To timely and accurately establish a record of all transactions for returns and documents processed through the IRS and provide special services for unique functions.

2. To accomplish this mission, the Accounting Operation:



1. Creates, receives and verifies accounting documents.

2. Maintains and reconciles accounting records.

3. Certifies tax assessments.

4. Provides requirements for receiving, processing, controlling and releasing refund litigation and/or potential refund litigation case requests from Area or Chief Counsel or their representatives upon request.

5. Maintains and reconciles Single Entry Time Reporting (SETR) and Work Planning and Control (WP&C) accounting records.


3. The Accounting Operation Managers report to the Submission Processing Field Directors.

4. The following Department Managers report to the Accounting Operation Managers:



   - Accounting Control/Services Department


**1.1.13.6.6.6.8** **(08-29-2025)**

###### Statistics of Income (SOI) Operation

1. **Mission:** To collect and process data from tax returns and other official documents so that it becomes useful information to be provided to customers in the form of tabulations, electronic data, scanned images, and publications.

2. To accomplish this mission, Statistics of Income (SOI) Operation:



1. Compiles information from tax returns sampled from all SP centers.

2. Conducts IRS studies on the operations of the tax laws for individuals, corporations, partnerships, sole proprietorships, estates, exempt organizations, trusts, and the international area.

3. Provides information used by various federal and state agencies, corporate America, educational and research organizations, foreign governments and international organizations in decision making activities.

4. Makes data available to the general public in the form of publications and electronic databases.

5. Scans a variety of documents to support Large Business and International (LB&I) and Small Business/Self-Employed (SB/SE) Compliance initiatives including, but not limited to, preparation of documents for court cases.


3. The SOI Operation Managers report to the Submission Processing (SP) Field Directors. Exception: Kansas City’s SOI managers report to the Document Perfection (DPO) Operations Manager.


**1.1.13.6.6.6.9** **(03-01-2007)**

###### Individual Taxpayer Identification Number (ITIN) Operation

1. **Mission:** To assign Individual Taxpayer Identification Numbers (ITINs) to taxpayers who submit Form W-7, Application for IRS Individual Taxpayer Identification Number; submit associated tax returns into the pipeline for processing after assignment of ITINs; and ensure taxpayer name, address and identification numbers are updated as necessary in the IRS computer system.

2. To accomplish this mission, the **Individual** Taxpayer Identification Number (ITIN) Operation:



1. Reviews each Form W-7 and supporting documentation for completeness and correctness.

2. Secures all missing supporting documentation from the taxpayer.

3. Rejects those applications which lack the required supporting documentation.

4. Returns original supporting documents to the taxpayer.

5. Inputs all required data to the ITIN Real-time System.

6. Prepares associated tax returns for input by Pipeline functions by editing the ITIN(s) on the return.

7. Inputs address and other entity changes as required.


3. The ITIN Operation Manager reports to the Submission Processing Field Director.

4. The ITIN Department Managers report to the ITIN Operations Manager.


**Exhibit 1.1.13-1**

### Taxpayer Services (TS) Organization Chart and Structure

![This is an Image: 30387001.gif](https://www.irs.gov/pub/xml_bc/30387001.gif)

> Taxpayer Services Organizational ChartThe following describes the many organizations listed on the Taxpayer Services (TS) Organizational Chart. TS consists of seven organizations that report to the Chief, TS. The organizations include: Management ServicesCommunication and Liaison (C&L)Customer Assistance, Relationships and Education (CARE)Customer Account Services (CAS)Return Integrity and Compliance Services (RICS)TS Operations Support (TSOS)The following organization, although not a component of TS, is also included on the TS organizational chart: TS Division Counsel, part of the Chief Counsel organizationDirect reporting organizations under CARE include: Media and Publication (M&P)Stakeholder Partnerships, Education and Communication (SPEC)Field Assistance (FA)Within these three CARE directorates, there are more direct reporting organizations.Direct reporting organizations under M&P include:Tax Forms and PublicationsPublishingDistributionDirect reporting organizations under SPEC include: Area Director, SPEC Area 1 (Atlanta)Area Director, SPEC Area 2 (Cincinnati)Area Director, SPEC Area 3 (Fresno)Direct reporting organizations under Field Assistance include: Field Assistance Area 1 (Cincinnati)Field Assistance Area 2 (Atlanta)Field Assistance Area 3 (Austin)Field Assistance Area 4 (Fresno)Direct reporting organizations under CAS include: Accounts Management (AM)Submission Processing (SP)Joint Operations Center (JOC)Electronic Products and Services Support (EPSS)Within the AM, EPSS, and SP CAS directorates, there are more direct reporting organizations. Direct reporting organizations under AM include: Accounts Management Center, AndoverAccounts Management Center, AtlantaAccounts Management Center, AustinAccounts Management Center, BrookhavenAccounts Management Center, CincinnatiAccounts Management Center, FresnoAccounts Management Center, Kansas CityAccounts Management Center, MemphisAccounts Management Center, OgdenAccounts Management Center, PhiladelphiaAccounts Management Center, Puerto RicoIdentity Theft (IDT) Victims AssistanceDirect reporting organizations under SP include:e-File ServicesSubmission Processing Center, AustinSubmission Processing Center, Kansas CitySubmission Processing Center, OgdenDirect reporting organizations under RICS include: Return Integrity Verification Program Management (RIVPM)Return Integrity Verification Operations (RIVO)Refundable Credits Program Management (RCPM)Refundable Credits Examination Operations (RCEO)Direct reporting organizations under TSOS include: Capital Management and Oversight (CMO)Business Systems Modernization (BSM)Business Technology Operations (BTO) Strategies and SolutionsProgram Management Office

[Please click here for the text description of the image.](https://www.irs.gov/media/129226 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-013#addtoany "Show all")

A2A