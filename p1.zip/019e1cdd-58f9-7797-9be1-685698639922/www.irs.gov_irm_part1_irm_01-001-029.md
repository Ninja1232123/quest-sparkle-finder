---
url: "https://www.irs.gov/irm/part1/irm_01-001-029"
title: "1.1.29 Office of Online Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-029#main-content)

- 1.1.29  [Office of Online Services](https://www.irs.gov/irm/part1/irm_01-001-029#id1)
  - 1.1.29.1  [Office of Online Services](https://www.irs.gov/irm/part1/irm_01-001-029#id2)
  - 1.1.29.2  [Shared Services Division](https://www.irs.gov/irm/part1/irm_01-001-029#id3)
    - 1.1.29.2.1  [Front Office Operation Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id5)
    - 1.1.29.2.2  [Project Management Office Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id6)
    - 1.1.29.2.3  [Strategy & Outreach Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id7)
  - 1.1.29.3  [Digital Products Division](https://www.irs.gov/irm/part1/irm_01-001-029#id8)
    - 1.1.29.3.1  [Individual Taxpayer Products Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id9)
      - 1.1.29.3.1.1  [ITP Team 1 Section](https://www.irs.gov/irm/part1/irm_01-001-029#id11)
      - 1.1.29.3.1.2  [ITP Team 2 Section](https://www.irs.gov/irm/part1/irm_01-001-029#id12)
    - 1.1.29.3.2  [Business & Tax Professional Products Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id13)
      - 1.1.29.3.2.1  [Business Solutions Section](https://www.irs.gov/irm/part1/irm_01-001-029#id15)
    - 1.1.29.3.3  [Taxpayer Digital Communication Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id16)
      - 1.1.29.3.3.1  [Technical Solutions Section](https://www.irs.gov/irm/part1/irm_01-001-029#id18)
      - 1.1.29.3.3.2  [Content and Engagement Section](https://www.irs.gov/irm/part1/irm_01-001-029#id19)
  - 1.1.29.4  [Product Services Division](https://www.irs.gov/irm/part1/irm_01-001-029#id20)
    - 1.1.29.4.1  [Evaluation & Experimentation Branches](https://www.irs.gov/irm/part1/irm_01-001-029#id21)
      - 1.1.29.4.1.1  [Front End Services Section](https://www.irs.gov/irm/part1/irm_01-001-029#id23)
      - 1.1.29.4.1.2  [Product Experimentation Section](https://www.irs.gov/irm/part1/irm_01-001-029#id24)
    - 1.1.29.4.2  [User Acceptance Testing Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id25)
    - 1.1.29.4.3  [Web Services Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id26)
      - 1.1.29.4.3.1  [IRS.gov Operations Section](https://www.irs.gov/irm/part1/irm_01-001-029#id28)
  - 1.1.29.5  [User Experience Services Division](https://www.irs.gov/irm/part1/irm_01-001-029#id29)
    - 1.1.29.5.1  [Analytics Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id31)
    - 1.1.29.5.2  [Enterprise Content Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id32)
    - 1.1.29.5.3  [User Experience Design Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id33)
    - 1.1.29.5.4  [User Experience Research Branch](https://www.irs.gov/irm/part1/irm_01-001-029#id34)
  - Exhibit  1.1.29-1  [Online Services Organizational Chart](https://www.irs.gov/irm/part1/irm_01-001-029#id35)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 29. Office of Online Services

* * *

## 1.1.29 Office of Online Services

#### Manual Transmittal

July 29, 2025

#### Purpose

(1) This transmits new IRM 1.1.29, Organization and Staffing, Office of Online Services.

#### Material Changes

(1)

|     |     |
| --- | --- |
| IRM 1.1.29 | various editorial changes throughout IRM |
| IRM 1.1.29.2 | IRM section rewritten and renamed for new Shared Services division based on operational reorganization. |
| IRM 1.1.29.2.1 | IRM section rewritten and renamed based on operational reorganization |
| IRM 1.1.29.2.2 | IRM section added due to an operational reorganization. |
| IRM 1.1.29.2.2.1 | IRM section added due to an operational reorganization. |
| IRM 1.1.29.2.3 | IRM section added due to an operational reorganization. |
| IRM 1.1.29.3 | IRM section rewritten for Digital Products division based on operational reorganization. |
| IRM 1.1.29.3.1 | IRM section rewritten and renamed based on operational reorganization. |
| IRM 1.1.29.3.1.1 | IRM section rewritten and renamed based on operational reorganization. |
| IRM 1.1.29.3.1.2 | IRM section rewritten and renamed based on operational reorganization. |
| IRM 1.1.29.3.2 | IRM section rewritten and renamed based on operational reorganization. |
| IRM 1.1.29.3.2.1 | IRM section added due to an operational reorganization. |
| IRM 1.1.29.3.3 | IRM section renumbered from IRM 1.1.29.3.4 then rewritten based on operational reorganization. |
| IRM 1.1.29.3.3.1 | IRM section renumbered from IRM 1.1.29.3.4.1 then rewritten based on operational reorganization. |
| IRM 1.1.29.3.3.2 | IRM section renumbered from IRM 1.1.29.3.4.2 then rewritten based on operational reorganization. |
| IRM 1.1.29.3.4 | IRM section removed due to an operational reorganization. |
| IRM 1.1.29.4 | IRM section was rewritten and renamed to reflect Product Services Division based on operational reorganization. |
| IRM 1.1.29.4.1 | IRM section rewritten and renamed based on operational reorganization |
| IRM 1.1.29.4.1.1 | IRM section rewritten and renamed based on operational reorganization |
| IRM 1.1.29.4.1.2 | IRM section added due to an operational reorganization |
| IRM 1.1.29.4.2 | IRM section rewritten and renamed based on operational reorganization |
| IRM 1.1.29.4.3 | IRM section rewritten and renamed based on operational reorganization |
| IRM 1.1.29.4.3.1 | IRM section rewritten and renamed based on operational reorganization |
| IRM 1.1.29.4.3.2 | IRM section removed due to an operational reorganization |
| IRM 1.1.29.5 | IRM was rewritten based on operational reorganization. |
| IRM 1.1.29.5.1 | IRM was rewritten based on operational reorganization. |
| IRM 1.1.29.5.2 | IRM was rewritten based on operational reorganization. |
| IRM 1.1.29.5.3 | IRM was renamed and rewritten based on operational reorganization. |
| IRM 1.1.29.5.4 | IRM was added due to an operational reorganization. |
| Exhibit 1.1.29-1 | Exhibit was updated to reflect new Organization Chart based on operational reorganization |

#### Effect on Other Documents

IRM 1.1.29 dated February 15, 2024 is superseded.

#### Audience

All employees in all business units

#### Effective Date

(07-29-2025)

/s/ Karen Howard

Director, Office of Online Services

**1.1.29.1** **(07-29-2025)**

### Office of Online Services

1. The Office of Online Services (OLS) was established to lead business transformation efforts focused on digital tax administration, improvements to the tax experience, and consistent enterprise-wide digital service options.

2. OLS is composed of four units that work together, along with partners, to create and improve the taxpayer experience. These **divisions** are:



   - Shared Services

   - Digital Products

   - Product Services

   - User Experience Services


3. OLS coordinates enterprise wide with Business Units (BU) and Information Technology (IT) leadership to lead and facilitate change by:



   - Creating transformational services

   - Encouraging adoption and integration of digital tools

   - Incorporating digital business processes into IRS operation


.



4. **Vision:** Continuously partner to innovate and transform the taxpayer experience side of interaction experiences.

5. **Mission:**Advocate for customers and lead digital transformation by aligning people and processes.

6. **Goals:**



   - Driving efficient operations by empowering taxpayers to digitally self-serve

   - Advancing data and analytics in the areas of online behavior tracking, qualitative and quantitative research, and sentiment analysis to deepen awareness of the customer


.



7. **Cross-organizational responsibilities:**



   - Enhance content management and search capabilities

   - Enhance personas, journey maps, and customer research

   - Develop cross-channel customer feedback and analytics

   - Advance consistent experiences per the 21st Century Integrated Digital Experience Act (IDEA)

   - Ensure consistent application of Service wide standards and industry best practices for digital content creation

   - Advance internal operations (e.g., moving forward AGILE/SAFe release cycles, championing use of collaboration tools, etc.)

   - Recruit and retaining core skills

   - Expand OLS outreach programs (e.g., Digital Days, etc.)


8. The Director of Online Services reports to the Deputy Commissioner).


**1.1.29.2** **(07-29-2025)**

### Shared Services Division

1. The Shared Services Division plays a vital role in empowering the functions and mission of the Office of Online Services (OLS). The organization strives to build trust with its customers by proactively understanding their needs and providing a range of high-quality services, such as business administration and operations, program and project management, communication and outreach, and strategic planning.

2. **Branches:**



   - Front Office Operations

   - Project Management Office

   - Strategy & Outreach


3. **Vision:** OLS Shared Services Division strives to be recognized as experts who contribute knowledge, solutions, and resources to support ongoing success by:



   - Leading with Knowledge

   - Being Proactive

   - Delivering Exceptional Results


4. **Mission:** OLS Shared Services Division’s mission is to provide centralized, value-added services that empower all OLS Divisions to focus on core competencies and achieve operational excellence by:



   - Empowering the Team

   - Enabling Goals

   - Driving Success


5. **Goals:** The OLS Shared Services Division has four Pillars for Success:



   - Reducing time lines for processing support requests will increase efficiencies and enhance Shared Services Reputation within OLS

   - Increasing the number of Shared Services tools, such as dashboards and automated flows to drive high responsiveness for requests

   - Defining customer service expectations for value and service and consistently meeting those standards Operational Excellence

   - Improving processes and operations allowing the organization to thrive and scale effectively


6. **Responsibilities:**



   - Digital Products Strategic Planning

   - Budget and Finance

   - Business Systems Planning

   - Project Management

   - Contracting Officer’s Representatives

   - Digital Products Marketing

   - Workforce Management


7. The Director of Shared Services reports to the Director of Online Services


**1.1.29.2.1** **(07-29-2025)**

#### Front Office Operation Branch

1. The Front Office Operations delivers business administrative services in support of the Director of Online Services and the Business Divisions with efficient and consistent operations and management of resources. This team of professionals seamlessly connects to the Business Division through expertise in IRS administrative and support business process that have been retooled and molded to serve the unique demands of the IRS’ sole producer of taxpayer digital service design and product deliverables

2. **Vision:** Lead with Knowledge. Be Proactive. Deliver Exceptional Results.

3. **Mission:** Empower the Team. Enable Goals. Drive Success.

4. **Goal:** The Front Office Team provides oversight and support for OLS activities such as audit management and controls, budget, workforce management, training, procurement, space planning, reporting, and knowledge management. The Front Office supports all aspects of OLS operations, ensuring processes are in place and efficient.

5. **Responsibilities:** The Front Office Team delivers customer focused support to the Online Services’ Business Divisions in the following areas:



   - OLS Strategy Development: Monitors and measures progress of auditing activities to facilitate and track responses related to OLS programs

   - Financial Management and Budget: Plans, manages, and executes the OLS annual budget, supporting development of investment requests

   - Business System Planning: Support OLS employees with their technical solutions, software, and hardware requirements

   - Workforce Management: Leads and manages the full employee life cycle to include recruitment, hiring, onboarding, training/development, performance management, retention, off-boarding, and space planning


6. The Front Office Functional Chief reports to the Director of Shared Services.


**1.1.29.2.2** **(07-29-2025)**

#### Project Management Office Branch

1. The Project Management Office (PMO) provides proactive project management, contract management, and risk management support to enable OLS and its divisions to achieve their missions and strategic goals. The Office establishes OLS-wide standards and guidance to drive excellence across the organization

2. **Section:**



   - PMO Team 1


3. **Vision:** Lead with Knowledge. Be Proactive. Deliver Exceptional Results.

4. **Mission:** Empower the Team. Enable Goals. Drive Success. The purpose of the PMO is to provide centralized project management, contract management, and risk management support.

5. **Goal:** Improve PMO processes to improve quality and reduce delivery times. Provide expert Project Manager (PM) support in the following areas:



   - Project Management

   - Contract Management

   - Risk Management


6. **Responsibilities:** PMO Support Team delivers customer-focused project management, contract management, and risk management support to OLS Divisions, by:



   - Maintaining a delivery mindset, ensuring projects are completed efficiently and effectively

   - Providing contract project updates to Director/ Product Owners, enabling them to make informed choices

   - Senior Manager / Product Owner provides direction and briefs OLS Director on project status, roadblocks etc.

   - Contract Officer’s Representative (COR) support for the acquisition strategy, vendor contracts, and vendor onboarding logistics

   - Risk Management support that assists OLS Divisions in reporting, mitigation, escalation, and closure of risks

   - Surge Project Management support for high-priority projects

   - Record Management


7. The Project Management Office Functional Chief report to the Director of Shared Services.


**1.1.29.2.3** **(07-29-2025)**

#### Strategy & Outreach Branch

1. The Strategy and Outreach Office markets Online Services’ products to IRS and external stakeholders, emphasizing how the organization supports improved taxpayer experiences via enhanced digital capabilities. The Strategy and Outreach Office also drives the development of the digital strategy by bringing OLS Divisions together to identify what matters to taxpayers and develop appropriate goals and implementation plans. The office also drives engagement across OLS employees to support connection and collaboration.

2. The Strategy and Outreach branch serves Digital Products and Online Services organizations by fostering adoption of a unified Digital Strategy across all products and by engaging in targeted, cross-product internal and external outreach.

3. **Objectives:**



   - Create programs that promote internal and external outreach and exchange of information about Digital Products’ services

   - Identify and develop new business opportunities for Digital Products among IRS customer-facing programs

   - Define new opportunities for business research and analysis

   - Enhance Digital Products’ and Online Services’ strategic planning


4. The Strategy & Outreach Functional Chief reports to the Director of Shared Services.


**1.1.29.3** **(07-29-2025)**

### Digital Products Division

1. Digital Products (DP) combines a pursuit of the IRS mission with a drive for innovation and a motivation to improve the customer experience so that taxpayers may connect with the IRS in a streamlined and integrated online environment.

2. **Branches:**



   - Individual Taxpayer Products Branch

   - Business & Tax Professional Products Branch

   - Taxpayer Communication and Engagement


3. **Vision:** Defines features, strategies, and roadmaps for online tools and their supporting business processes, driving the IRS’s strategic plan and customer service experience forward.

4. **Mission:** Engage internal and external partners and apply modern design practices, proven product management techniques, and agency-wide user research to new and existing initiatives.

5. **Responsibilities:**



   - Identify the heart of the customer need or business challenge

   - Bring innovative solutions to fruition

   - Collaborate with end users and business stakeholders to validate concepts and ensure customers’ needs are met

   - Analyze results and continuously improve digital services to empower and enable taxpayers to understand and meet tax responsibilities online

   - Product managers work with technology teams to ensure the application, tool, or service is being implemented according to the requirements and user stories


6. The Director of Digital Products reports to the Director of Online Services


**1.1.29.3.1** **(07-29-2025)**

#### Individual Taxpayer Products Branch

1. The Individual Taxpayer Products Team oversees the development, maintenance, and enhancement of digital services for individual taxpayers

2. **Sections:**



   - ITP Team 1

   - ITP Team 2


3. **Vision:** Empower individual taxpayers with accessible, efficient, and intuitive digital services that simplify tax-related processes and improve voluntary compliance.

4. **Mission:** Develop and sustain a comprehensive suite of authenticated and unauthenticated applications that enhance the taxpayer experience by offering reliable and self-service digital tools.

5. **Goals:**



   - Ensure Individual Online Account (IOLA) and Public User Portal (PUP) applications are continuously updated to align with current tax laws and regulations

   - Improve taxpayer engagement and satisfaction through iterative enhancements and data-driven insights

   - Expand the reach of digital services by improving awareness and usability

   - Strengthen collaboration with internal stakeholders to streamline product development

   - Monitor and enhance application performance through regular assessment and feedback implementation

   - Adopt modern design practices and user research to drive innovation in IRS digital products


6. **Responsibilities:**



   - Supporting IRS strategic goals by enhancing taxpayer self-service capabilities

   - Ensuring seamless integration between IOLA and PUP applications where applicable

   - Collaborating with internal IRS stakeholders, including the Business & Tax Professional Products Branch

   - Managing product life cycle activities, including



     > - **Metrics & analytics** (with User Experience Services Division)
     >
     >      - **Roadmap planning and execution**
     >
     >      - **Product backlog maintenance**
     >
     >      - **Application content management**
     >
     >      - **Outreach and taxpayer engagement**
     >
     >      - **Research and usability testing**
     >
     >      - **Performance monitoring and reporting**


7. The Individual Taxpayer Products Branch Functional Chief reports to the Director of Digital Products.


**1.1.29.3.1.1** **(07-29-2025)**

##### ITP Team 1 Section

1. ITP Team 1, supports the product manager with feature development, analytics, research, and outreach for Individual Online Account (IOLA),

2. **Vision:** Develop Strategy, Roadmap, and feature definition for IOLA, and related business processes, in support of the IRS’s strategic plan and customer service experience

3. **Mission:** Engage internal and external partners, and apply modern design practices, proven product management techniques, and agency-wide user research and data analytics to deliver new and enhance existing product initiatives.

4. **Goal:** Promote ITP branch goals with an operational focus on IOLA.

5. **Responsibilities:**



   - Support Product Management activities related to IOLA. This includes but is not limited to supporting the Product Manager for IOLA with the following:



     > - Metrics and analytics (in partnership with User Experience Services Division)
     >
     >      - Roadmap updates
     >
     >      - Product backlog maintenance and grooming
     >
     >      - Application content support
     >
     >      - Outreach support (in partnership with the Strategy & Outreach branch of the Shared Services Division)
     >
     >      - Research and analysis
     >
     >      - Product performance monitoring


   - Crosses over with work supported by the Business & Tax Professional Products branch where both branches may support the development of a feature that cross applications


6. The ITP Team 1 Section supervisor reports to the Functional Chief of Individual Tax Products Branch


**1.1.29.3.1.2** **(07-29-2025)**

##### ITP Team 2 Section

1. Manages Public User Portal (PUP) Applications, which do not require authentication and provide self-service tools for taxpayers

2. **Vision:** Empower taxpayers with intuitive, accessible, and reliable public user applications that simplify tax-related processes and enhance voluntary compliance.

3. **Mission:** Develop, maintain, and continuously improve a suite of user-friendly, unauthenticated applications that assist taxpayers in understanding and fulfilling their tax obligations efficiently

4. **Goals:**



   - Promote ITP branch goals with an operational focus on PUP apps.

   - Ensure user satisfaction by implementing user feedback and conducting regular usability testing

   - Increase public awareness and usage of PUP apps through targeted outreach initiatives

   - Foster strong partnerships with internal stakeholders and external vendors to streamline application development and maintenance processes

   - Monitor and analyze application performance metrics to inform data-driven improvements

   - Stay up to date with technological advancements to incorporate innovative features that enhance the taxpayer experience.


5. **Responsibilities:**



   - Manage and coordinate the development and maintenance of PUP applications that do not require user authentication

   - Research and Coordinate the viability of proposed additional applications from other internal customers

   - Collaborate with stakeholders across the IRS and work with contracted vendors to ensure timely updates and enhancements to these applications

   - Drive product strategy, development, and execution by managing the full product life cycle activities, including:



     > - **Metrics & analytics** (with User Experience Services Division)
     >
     >      - **Roadmap planning and execution**
     >
     >      - **Product backlog maintenance**
     >
     >      - **Application content management**
     >
     >      - **Outreach support** (in partnership with the Strategy & Outreach branch of the Shared Services Division)
     >
     >      - **Research and usability testing**
     >
     >      - **Performance monitoring and reporting**


6. The ITP Team 2 Section supervisor reports to the Functional Chief of Individual Taxpayer Products Branch


**1.1.29.3.2** **(07-29-2025)**

#### Business & Tax Professional Products Branch

1. The Business and Tax Professional Products Branch works with internal business and IT stakeholders to develop and prioritize features, craft requirements, highlight business process changes and develop and deploy solutions aimed at improving digital services. Serves as product manager responsible for the overall success of the products, with a focus on building tools, processes and services based on customer needs, insights, and user experiences

2. **Section:**



   - Business Solutions


3. **Vision:** Develop Strategy, Roadmap, and feature definition for Tax Pro Account and Business Tax Account, and their supporting business processes, in support of the IRS’s strategic plan and customer service experience.

4. **Mission:** Engage internal and external partners, and apply modern design practices, proven product management techniques, and agency-wide user research and data analytics to deliver new and enhance existing product initiatives.

5. **Goal:** Driving efficient operations by empowering businesses and tax professionals to digitally self-serve.

6. **Responsibilities:**



   - Defining strategy, roadmap, and feature development for BTA and Tax Pro Account

   - Engaging with internal business and IT stakeholders to develop and prioritize new features

   - Managing product lifecycle activities, including:



     > - Requirements gathering and validation
     >
     >      - Business process analysis and enhancement
     >
     >      - Feature implementation and deployment

   - Leveraging modern design practices, user research, and data analytics to optimize product performance

   - Collaborating with agency-wide partners to ensure seamless digital service delivery

   - Enhancing self-service capabilities for tax professionals and business users to streamline IRS interactions


7. The Business & Tax Professional Products Branch Functional Chief reports to the Director of Digital Products.


**1.1.29.3.2.1** **(07-29-2025)**

##### Business Solutions Section

1. The Business Solutions Team is responsible for the strategy, development, and maintenance of digital solutions tailored for businesses and tax professionals. This includes the Business Tax Account (BTA) and Tax Pro Account, which support the IRS’s strategic plan and customer service experience.

2. **Vision:** Empower businesses and tax professionals with modern, intuitive, and secure digital solutions that simplify tax administration and enhance operational efficiency.

3. **Mission:** To provide businesses and tax professionals with self-service digital tools that improve efficiency, compliance, and user experience by applying innovative product management approaches, advanced analytics, and customer-driven enhancements.

4. **Goals:**



   - **Increase digital adoption**: Promote and enhance the Business Tax Account and Tax Pro Account to drive greater usage among businesses and tax professionals

   - **Enhance customer experience**: Implement user feedback through iterative improvements and regular usability testing

   - **Drive operational efficiency**: Develop tools that enable businesses and tax professionals to self-serve, reducing reliance on traditional IRS service channels

   - **Strengthen stakeholder collaboration**: Work closely with internal IRS divisions and external partners to align digital solutions with taxpayer needs

   - **Ensure compliance and security**: Maintain rigorous standards for data security, authentication, and regulatory compliance across all solutions

   - **Monitor performance metrics**: Analyze user engagement and service effectiveness to drive continuous product improvements


5. **Responsibilities:**



   - Promote BTP branch goals


6. The Business Solutions Section supervisor reports to the Functional Chief of Business & Tax Professional Products Branch


**1.1.29.3.3** **(07-29-2025)**

#### Taxpayer Digital Communication Branch

1. The Taxpayer Digital Communications (TDC) Branch is the program office for product managers and thought leaders for customer facing digital communication services such as secure messaging and chatbot functionality.

2. **Sections:**



   - Technical Solutions

   - Content and Engagement


3. **Vision:** TDC strives for a future where every interaction with the IRS is intuitive, efficient, supportive, and taxpayers feel empowered whenever they need to communicate with the IRS. By leveraging innovation, data-driven insights, taxpayer feedback, and collaboration, we strive to set standards in digital communication within tax administration, fostering a system that is responsive, and trusted by all.

4. **Mission:** To pioneer a new era of tax communication, leveraging the latest digital technologies and methods to streamline processes, empower taxpayers and the IRS to effectively communicate with one another, and enhance overall compliance and trust.

5. **Goals:**



   - Implement user-friendly digital platforms for streamlined taxpayer interactions

   - Forge partnerships across the IRS to integrate proven digital solutions into tax communication processes

   - Help the IRS maximize its ability to assist taxpayers effectively with digital communications tools


6. **Responsibilities:**



   - Provide strategy and management for the continued expansion of Secure Messaging for taxpayers and within the service

   - Configures Secure Messaging for new installations and for the expansion of existing installations

   - Provides technical support to Contact Center Support Division and Operations and Maintenance

   - Delivers post installation support to IRS business units


7. The TDC Branch Functional Chief reports to the Director of Digital Products.


**1.1.29.3.3.1** **(07-29-2025)**

##### Technical Solutions Section

1. The Technical Solutions Section supports the Taxpayer Digital Communication (TDC) program activities including Secure Messaging use case analysis, prioritization and installation efforts, as well as the program’s strategic and operational efforts.

2. **Vision:** Create a future state where taxpayers can complete all of their direct interactions with IRS personnel in a secure, online environment.

3. **Mission:** Build timely, effective Secure Messaging installations for IRS business customers to maximize the number of taxpayers who can benefit from this service.

4. **Goal:** Drive more efficient and streamlined communication through the use of Secure Messaging.

5. **Responsibility:**



   - Promote TDC branch goals


6. The Technical Solutions Section supervisory reports to the Functional Chief of Taxpayer Digital Communication Branch.


**1.1.29.3.3.2** **(07-29-2025)**

##### Content and Engagement Section

1. The Content and Engagement Section supports the Taxpayer Digital Communication (TDC) program activities including Secure Messaging use case analysis, prioritization and installation efforts, as well as the program’s strategic and operational efforts.

2. **Vision:** Create a future state where taxpayers can complete all of their direct interactions with IRS personnel in a secure, online environment.

3. **Mission:** Build timely, effective Secure Messaging installations for IRS business customers to maximize the number of taxpayers who can benefit from this service.

4. **Goal:** Drive more efficient and streamlined communication through the use of Secure Messaging.

5. **Responsibilities:**



   - Promote TDC branch goals


6. The Content and Engagement Section supervisor reports to the Functional Chief of TDC Branch


**1.1.29.4** **(07-29-2025)**

### Product Services Division

1. Product Services plays a critical role in managing and supporting products throughout their life-cycle, specifically with regard to experimental pilots, content management and publishing, and user acceptance testing.

2. **Branches:**



   - Evaluation & Experimentation (E&E)

   - User Acceptance Testing (UAT)

   - Web Services


3. **Vision:** Our vision is to provide critical knowledge and expertise as the IRS embraces a full digital modernization, delivering cutting edge solutions that prioritize user-centered design and accessibility.

4. **Mission:** Our mission is to act on the user experience and human-centered design input received from other divisions at OLS, and lead OLS coordination efforts with IRS IT for the development of products and services.

5. **Goals:**



   - Establish accurate and repeatable models for working across divisions, based on industry best-practices

   - Invigorate E&E branch to provide actionable recommendations for incorporating emerging tech such as artificial intelligence and machine learning; Internet of Things; virtual and augmented reality, into digital enhancements that will provide a more efficient and effective online experience for the taxpayer

   - Establish the UAT branch as a stand-alone branch focused on cyclical and repetitive testing of online activities, using environments and data that mimic the production site, to ensure that the taxpayer’s experience is accurate and seamless

   - Transition Ops and Publishing teams to function in support of the new IRS.gov website, maintaining critical content publishing speed and accuracy as well as supported uptime for new website and infrastructure


6. The Product Services division Director reports to the Director of Online Services.


**1.1.29.4.1** **(07-29-2025)**

#### Evaluation & Experimentation Branches

1. The Evaluation & Experimentation (E&E) Branch was established within the Office of Online Services (OLS) to improve digital tax administration, enhance the online taxpayer experience, and accelerate enterprise-wide digital service options. E&E is comprised of two sections that work together to explore, incubate, and test new and emerging technologies.

2. **Sections:**



   - Front End Services

   - Product Experimentation


3. **Vision:** Reimagine the digital taxpayer experience through identification and testing of new and emerging technologies that increase taxpayer engagement by making the experience more simple, accessible, and secure

4. **Mission:** Build an innovation capability that can intake and incubate new and emerging solutions to pressing digital taxpayer needs.

5. **Goals:**



   - Establish OLS’ brand as an innovation leader within the IRS across Civilian Agencies

   - Support the development of the vision for the future state digital taxpayer experience

   - Establish an Experimentation Hub within OLS

   - Create a culture of innovation by empowering OLS personnel to explore and test new digital technologies

   - Collaborate with digital innovation leaders across the government, academia, and industry


6. The Evaluation & Experimentation Branch Functional Chief reports to the Director of Product Services.


**1.1.29.4.1.1** **(07-29-2025)**

##### Front End Services Section

1. **Vision:** Serve as technology specialists and support to incubate and pilot projects within E&E and act as a coordinator between IT, BODs, and other stakeholders to support incubation, piloting, transition, and scaling of projects

2. **Mission:** Provide technical expertise and guidance to E&E branch projects, as needed, to enable the experimentation of different solutions/concepts.

3. **Goals:**



   - Define requirements and develop solutions for proof-of-concepts

   - Coordinates with IT, BODs, and other stakeholders to confirm technical feasibility of a solution/concept, determine need for and method of procurement, participate on security reviews, and other project requirements that lead to either a proof-of-concept (POC) or a most viable product/process (MVP)

   - Support the drafting and review of any vendor solicitations, as appropriate

   - Coordinate a review and evaluation of vendor proposals, prior to a procurement

   - Oversee the analysis of pilot results and communicate results to stakeholders

   - Coordinate the transition of pilots, including but not limited to, knowledge transfer, technology transfer, and other activities for the successful scaling of a product/process


4. The Front End Services Section supervisor reports to the Functional Chief of Evaluation & Experimentation Branch.


**1.1.29.4.1.2** **(07-29-2025)**

##### Product Experimentation Section

1. **Vision:** Research and experiment with solutions/concepts to critical taxpayer experience challenges

2. **Mission:** Support the intake, identification, ideation, and incubation of solutions/concepts within the innovation lifecycle

3. **Goals:**



   - Capture and intake ideas for future evaluation and prioritization

   - Conduct initial concept research by gathering data from various platforms, and coordinate with UES and Digital Products divisions, as necessary

   - Research and identify solutions/concepts through various methods, such as horizon scanning, tech scouting, and other innovative approaches to identify uses for new digital technology to enhance the mission of OLS

   - Support different innovation engagement events to collect challenges or concepts, such as hackathons, industry exhibitions, or interest group outreach

   - Develop project documentation for decision-making, such as use cases, proposed solutions, funding needs, stakeholder engagement plans, and identification of business units that will own the technical solution

   - Support the project management of the incubation and/or pilot of a solution/concept


4. The Product Experimentation Section supervisor reports to the Functional Chief of Evaluation & Experimentation Branch.


**1.1.29.4.2** **(07-29-2025)**

#### User Acceptance Testing Branch

1. The User Acceptance Testing (UAT) Branch serves as a uniquely separate and final testing stage for OLS products. It supports the highest level of quality assurance from a business user’s perspective and customer experience.

2. **Sections:**



   - Test Team 1

   - Test Team 2


3. **Vision:** A separate environment to perform optimal user acceptance testing to achieve the highest quality in product delivery to business customers.

4. **Mission:** Collaborate with stakeholders to identify a product’s intended purpose and maximize user acceptance testing.

5. **Goals:**



   - Develop UAT Framework

   - Develop UAT Communications Plan

   - Staff UAT Branch to support key operations

   - Collaborate with product and business owners

   - Evaluate requirements to develop UAT environment

   - Present UAT strategy to stakeholders

   - Participate in training


6. The User Acceptance Testing Branch Functional Chief to the Director of Product Services.


**1.1.29.4.3** **(07-29-2025)**

#### Web Services Branch

1. Web Services is responsible for posting digital content on IRS.gov at the request of IRS business stakeholders through our content management request system (CMRS) and our web content management system (WCMS).

2. **Sections:**



   - Web Publishing

   - IRS.gov Operations


3. **Vision:** To provide excellent customer service for publishing content on IRS.gov to ensure it aligns with stakeholder CMRS requests, publishing governance and web standards.

4. **Mission:** To provide an excellent user experience for taxpayers by publishing content on IRS.gov accurately, timely and reliably.

5. **Goals:**



   - **Stakeholder Collaboration:** Working closely with internal and external customers across IRS to publish their content accurately and in alignment with our web, editorial and design guidelines

   - **Maintain Accuracy and Compliance:** Ensuring all content goes through a quality assurance review to maintain the accuracy, consistency, timeliness and credibility of IRS.gov to meet taxpayer needs

   - **User Acceptance Testing:** Providing support of WCMS development and functional deployments to ensure thorough testing coverage and successful system changes

   - **Multilingual Publishing:** Maintaining that translations for multilingual children content are in synch with their English parent

   - **Annual Content Recertification:** Proactively provide reports to businesses every 30, 60 and 90 days, to review their content to ensure it is still relevant, accurate, timely and compliant

   - **WCMS and CMRS Training:**Creating training materials and teaching new users how to submit CMRS tickets and produce content, including images, static files, webforms and landing pages in the WCMS

   - **Special Publishing Activities:** Maintaining the IRS.gov homepage, the secondary navigation, megamenus, and footer, and the EITC microsite; creating webforms, publishing PPSF and Chatbot files, and investigating and fixing 404s webpage errors


6. The Web Services Branch Functional Chief reports to the Director of Product Services.


**1.1.29.4.3.1** **(07-29-2025)**

##### IRS.gov Operations Section

1. IRS.gov Operations serves as the product owner for the IRS.gov Website Content Management System (WCMS), and technical team for the OLS Web Services Division.

2. **Vision:** To be the trusted leader in providing technical expertise, and seamless collaboration to ensure the effective and efficient operations of the IRS.gov WCMS, delivering innovative solutions that meet business needs and enhance taxpayer experience

3. **Mission:** Transform business needs into technical solutions by collaborating with stakeholders, ensuring the successful delivery and testing of IRS.gov WCMS, all while supporting strategic initiatives and optimizing system performance

4. **Goals:**



   - **Stakeholder Collaboration:** Strengthen partnerships with internal and external stakeholders to ensure a clear understanding of business needs and technical requirements

   - **Agile Process Optimization:** Implement and refine Agile methodologies to synchronize stakeholders, streamline project delivery, and ensure consistent, high-quality outputs that meet business and taxpayer needs.

   - **User Acceptance Testing (UAT) Excellence:** Collaborate with the UAT team to maintain comprehensive standards, collaborating with Subject Matter Experts (SMEs), AD, and the Publishing and Content teams to ensure thorough testing coverage and successful system changes.

   - **Technical Innovation and Research:** Lead efforts in researching and proposing innovative solutions that align with Web Services long term strategic goals, ensuring that new functionalities meet the needs of both business stakeholders and taxpayers.

   - **Issue Resolution and System Optimization:** Pro actively address production issues through detailed technical analysis and collaboration with AD to ensure minimal disruptions and continuous improvements to IRS.gov WCMS.

   - **Effective Communication and Technical Support:** Facilitate clear communication between technical and business teams to ensure that system constraints and functionality are well understood and aligned with strategic goals.


5. The IRS.gov Operations Section supervisor reports to the Functional Chief of Web Services Branch.


**1.1.29.5** **(07-29-2025)**

### User Experience Services Division

1. User Experience Services (UES) unit is responsible for defining and measuring integrated, human-centered customer experience strategies and solutions that merge data analytics, modern design principles, content strategy, and user-focused research, testing, and analysis.

2. **Branches:**



   - Analytics

   - Enterprise Content

   - User Experience Design

   - User Experience Research


3. **Goals**



   - Establish design intent

   - Ensures brand consistency

   - Deliver improved usability for IRS products and services

   - Work with product managers, business owners, and delivery partners to empower the IRS to evolve with changing customer needs

   - Make interacting with the IRS easier, clearer, and better for its customers

   - Share tools, processes, and knowledge that drive a consistent customer experience across channels

   - Accelerate the ideation process, providing conceptualization and prototyping tools

   - Ensure data-driven decision making that is informed by user research


4. The User Experience Services Director reports to the Director of Online Services.


**1.1.29.5.1** **(07-29-2025)**

#### Analytics Branch

1. User Experience Services (UES) Analytics Branch works with stakeholders to digital products and services are instrumented for user data collection so that outcomes can be measured and assessed.

2. **Sections:**



   - Analytics Team 1

   - Analytics Team 2


3. **Vision:** Engineer data, reporting and data science to inform outcome-based performance metrics that improves taxpayer digital interaction and improve the efficiency of digital services provided by the IRS

4. **Mission:** Engineer performance measurement and data visualization with Web applications.

5. **Goal:** Achieve 100% digital data collection for key metrics and drive successful data science that informs decision makers for application development roadmaping an optimized path to at or above key results and target for objective attainment of the American taxpayer’s jobs to be done

6. The Analytics branch Functional Chief reports to the Director of User Experience Services


**1.1.29.5.2** **(07-29-2025)**

#### Enterprise Content Branch

1. Enterprise Content branch works with these stakeholders to ensure the public can find, understand, and use the information they need to fulfill their tax obligations.

2. **Sections:**



   - Content Strategy Team 1

   - Content Strategy Team 2


3. **Vision:** A simple, powerful IRS digital experience where the public we serve can.

4. **Mission:** To produce usable digital products and Omni channel content for taxpayers.

5. **Goal:** Provide expertise in the following areas:



   - Information architecture

   - Content creation

   - Content validation and revision

   - Search optimization

   - Analysis

   - Continuous improvement

   - Content governance

   - Content strategy training and advancing the practice of content strategy


6. The Enterprise Content branch Functional Chief reports to the Director of User Experience.


**1.1.29.5.3** **(07-29-2025)**

#### User Experience Design Branch

1. The User Experience Design branch is responsible for delivering mission critical user-centered design solutions across the IRS digital services portfolio. These solutions emphasize the simplification and streamlining of all digital solutions at the IRS, including the tax returns, payments, and refund processes

2. **Sections:**



   - Design Team 1

   - Design Team 2

   - Design Team 3


3. **Vision:** To deliver easy, simple, and intuitive digital experiences for taxpayers based on real user needs and data.

4. **Mission:** To define and design the north-star vision for the taxpayer experience using data-driven design methodologies. By deeply understanding user needs through quantitative and qualitative data, the User Experience Design branch designs useful new experiences while simplifying existing complex, redundant systems to increase efficiencies across the agency

5. **Goals:**



   - Produce design solutions for IRS websites and digital services and products informed by user research and analytics

   - Develop north star visions for the taxpayer experience to drive product development roadmaps

   - Follow best practices for product design to ensure IRS digital services meet the needs for all taxpayers in their digital interactions with the IRS

   - Manage IRS Online Design Guide (ODG) standards to ensure usable, consistent interface and interaction design across IRS websites and digital products

   - Design with broader IRS brand guidelines


6. The User Experience Design branch Functional Chief reports to the Director of User Experience.


**1.1.29.5.4** **(07-29-2025)**

#### User Experience Research Branch

1. The User Experience Research branch is responsible for understanding and analyzing taxpayer needs, behaviors and expectations that inform mission critical user-centered design solutions across the IRS digital services portfolio. These solutions emphasize the simplification and streamlining of all digital solutions at the IRS, including tax filing, payments, and refund processes.

2. **Sections:**



   - Employee Experiences

   - UX Research Team 1

   - UX Research Team 2

   - UX Research Team 3


3. **Vision:** To research, analyze, and communicate an understanding of taxpayer needs that drive easy, simple, and intuitive digital experiences for taxpayers based on data.

4. **Mission:** To provide a data-driven, human-centered understanding of the taxpayer experience, using a range of research methods, that improve the quality, efficiency and effectiveness of IRS’s digital services. By researching and understanding user needs, identifying pain points and opportunities for improvement, and validating the effectiveness of our products and services, the User Experience Research branch ensures that taxpayers are receiving the quality services they require, and that IRS remains compliant with the statutory requirements of the 21st Century Integrated Digital Experiences Act for delivering a digital-first public experience.

5. **Goals:**



   - Conduct generative research to ensure an understanding of user needs and pain points, using a variety of qualitative and quantitative research methods

   - Analyze data and communicate research insights to ensure IRS products and services are effectively meeting user needs

   - Conduct evaluative research, including frequent, iterative user testing of digital products, services and content to inform continuous improvement

   - Manage the digital survey program to collect and analyze structured and unstructured data about customer experience within IRS’s digital services to inform improvement of IRS products, and meet IRS statutory reporting requirements as a High-Impact Service Provider (HISP)

   - Research and analyze IRS employees’ experiences with digital tools and legacy processes to better understand employee needs, and identify and resolve pain points related to taxpayer-facing services


6. The User Experience Research Branch Functional Chief reports to the Director of User Experience Services


**Exhibit 1.1.29-1**

### Online Services Organizational Chart

![This is an Image: 61156001.gif](https://www.irs.gov/pub/xml_bc/61156001.gif)

> This exhibit shows the Online Services (OLS) organization.

[Please click here for the text description of the image.](https://www.irs.gov/media/203581 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-029#addtoany "Show all")

A2A