---
url: "https://www.irs.gov/irm/part1/irm_01-015-005"
title: "1.15.5 Relocating/Removing Records | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-015-005#main-content)

- 1.15.5  [Relocating/Removing Records](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112996236224)
  - 1.15.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112996165200)
    - 1.15.5.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112968674544)
    - 1.15.5.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112968669456)
    - 1.15.5.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112996150384)
    - 1.15.5.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112996148112)
    - 1.15.5.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112969252944)
    - 1.15.5.1.6  [Acronyms and Terms](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112969157568)
    - 1.15.5.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112969234176)
  - 1.15.5.2  [Migrating Records Between IRS Offices](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112996176896)
  - 1.15.5.3  [Transferring to a New Business Unit / Organization](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112996172928)
  - 1.15.5.4  [Releasing Records Custody Between Government Agencies](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112996169536)
  - 1.15.5.5  [Definition of Permanent Records](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112969247936)
  - 1.15.5.6  [Archival Standards for Permanent Retention of Records](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112969242464)
  - 1.15.5.7  [Records that Require Direct Transfer to NARA](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112969239664)
  - 1.15.5.8  [Standard Form 258](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963702624)
  - 1.15.5.9  [Shipping Permanent Records to NARA](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963695392)
  - 1.15.5.10  [Separating Employee Clearance (SEC)](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963689952)
    - 1.15.5.10.1  [Employee/Manager Roles and Responsibilities (Outside HR Connect)](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963687472)
    - 1.15.5.10.2  [Employee Responsibilities Regarding Personal Documents](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963425648)
    - 1.15.5.10.3  [Documents Which Can Be Removed](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963420480)
    - 1.15.5.10.4  [Documents Which CANNOT Be Removed](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963406336)
    - 1.15.5.10.5  [Separating Employees Checklist (Form 14757)](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963393344)
      - 1.15.5.10.5.1  [Exceptions to Use of Form 14757 for Separating Employee Clearance](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963387744)
    - 1.15.5.10.6  [Retention of Separating Employee Clearance (SEC) Records](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963379696)
    - 1.15.5.10.7  [Notifications to IT](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963377056)
  - 1.15.5.11  [Penalties for Unlawful Removal, Alienation, or Destruction of Government Records](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963374448)
  - Exhibit  1.15.5-1  [Caution Permanent Record Tape and Instructions](https://www.irs.gov/irm/part1/irm_01-015-005#idm140112963371312)

# Part 1. Organization, Finance, and Management

# Chapter 15. Records and Information Management

# Section 5. Relocating/Removing Records

* * *

## 1.15.5 Relocating/Removing Records

#### Manual Transmittal

January 15, 2025

#### Purpose

(1) This transmits revised IRM 1.15.5, Records and Information Management, Relocating/Removing Records.

#### Material Changes

(1) IRM references, website links, and editorial updates were made throughout this IRM section.

#### Effect on Other Documents

IRM 1.15.5, dated October 17, 2023, is superseded.

#### Audience

All IRS divisions and functions

#### Effective Date

(01-15-2025)

Michael J. Oser

Acting Director, Identity and Records Protection (IRP)

Privacy, Governmental Liaison and Disclosure (PGLD)

**1.15.5.1** **(01-15-2025)**

### Program Scope and Objectives

1. **Purpose:** This IRM explains how to relocate records between offices and organizations, and release custody to another government agency, including the National Archives and Records Administration (NARA).

2. This IRM also includes policy on IRS employees’ and managers’ responsibilities for ensuring federal records are appropriately secured in advance of employee separation from the IRS, including completion and submission of an electronic case (eCase) Form 14757, Records Management Checklist for Separating Employees, using the Enterprise Case Management (ECM) Platform, to document that all federal records with ongoing retention requirements have been properly secured, including safeguarding records subject to litigation holds. The completion and submission of an eCase (Form 14757) is also required on separating Interns, Volunteers, and Student Trainees (paid or unpaid).



### Note:



Business Units (BUs) are entitled to an exception from completing and submitting an eCase (Form 14757), for their employees who work on 30, 60, 90-day temporary appointments.

3. **Audience:** These procedures apply to **all** IRS employees and contractors.

4. **Policy Owner:** Director, Identity and Records Protection - Records and Information Management (RIM).

5. **Program Owner:** The Records and Information Management (RIM) Program office, under Privacy, Governmental Liaison and Disclosure (PGLD) is the program office responsible for oversight of the Servicewide records management policy.

6. **Primary Stakeholders:** The Records and Information Management (RIM) Program office, under PGLD, promotes responsible recordkeeping practices for IRS employees and contractors to follow in accordance with federal laws, regulations, and procedures.


**1.15.5.1.1** **(02-12-2021)**

#### Background

1. Proper management of IRS documents (hard copy and electronic) improves business efficiency and timely responses to litigation and Freedom of Information Act (FOIA) requests.

2. This IRM provides guidance on removing personal documents, as well as preventing the unauthorized removal of government records by IRS employees, including political appointees.

3. Guidance on the Separating Employee Clearance (SEC) process is included in this IRM and integrates records management-related requirements into the HR Connect SEC maintenance record, under the Legal Category. The guidance outlines the records management responsibilities when separating from the Service, in compliance with NARA policies and helps ensure the IRS retains files in a recordkeeping system that supports ongoing records management and litigation requirements.

4. This IRM provides guidance on how to relocate records between offices and organizations, and how to release custody to another government agency, including NARA.

5. The Is It a Record? flowchart provides the process in determining whether the information you have (hard copy or electronic) is a record and actions you must take. Once you determine you have a record, review the information on What to do with a Record. Contact your Records Specialists or Headquarters Business Unit Information Resource Coordinators (BU/IRCs) with questions and for assistance.


**1.15.5.1.2** **(08-08-2017)**

#### Authority

1. The [36 Code of Federal Regulations (CFR) Chapter XII, Subchapter B - 1230](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Unlawful or Accidental Removal, Defacing, Alteration, or Destruction of Records, is supported by the SEC process that helps ensure documents containing IRS information belonging to separated employees will be retained in a recordkeeping system that supports records management and litigation requirements. This includes the capability to identify, retrieve, and retain the documents for as long as they are needed.

2. 44 USC 3301, Definition of Federal Records.

3. 36 CFR Chapter XII, Subchapter B - 1220.18, General Definitions, for the regulatory definition of "permanent records" .

4. 36 CFR Chapter XII, Subchapter B - 1231, Transfer of Records from the Custody of One Executive Agency to Another.


**1.15.5.1.3** **(08-08-2017)**

#### Responsibilities

1. This IRM is used by **all** IRS employees and contractors to ensure compliance with paper and electronic records management requirements.


**1.15.5.1.4** **(10-17-2023)**

#### Program Management and Review

1. The RIM Program is evaluated using the following reviews and reports:



   - **Records Management Self-Assessment (RMSA)**: The annual RMSA asks questions that assess compliance with records management statutes and regulations, as well as NARA policies and guidance.

   - **Federal Electronic Records and Email Management Reporting**: This report not only evaluates federal agency email management, it also seeks to assess the current state of all electronic records management at federal agencies (including email and permanent electronic records).

   - **Senior Agency Official for Records Management (SAORM) Annual Report**: This report gathers data on agency progress towards the goals of the OMB/NARA Update to Transition to Electronic Records memo (M-23-07) and other important records management initiatives as identified by NARA.

   - **Form 14377, Records and Information Management Virtual Program Review Self Assessment Checklist**: This checklist is utilized as a self-assessment tool to assist the field site offices with records management policies and procedures. In addition, it measures RIM goals to stimulate better fiscal management.

   - **Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist**: PGLD requires all business unit information resource coordinator (IRC) contacts to complete this form on a quarterly basis. The purpose of the form is to ensure and document IRS recordkeeping compliance as defined by NARA. Completing the Form 14377-A identifies to PGLD:IRP:RIM potential gaps for training opportunities to assist the business unit with their recordkeeping responsibilities.


**1.15.5.1.5** **(10-17-2023)**

#### Program Controls

1. **Records Management Mandatory Briefing**: Every IRS employee and contractor must protect the information they handle daily to carry out their job responsibilities. They must annually take the Records Management Mandatory Briefing Integrated Talent Management (ITM) course #62965, Records Management Awareness, to ensure IRS records management is efficient, effective, and compliant with all applicable records management laws and regulations.


**1.15.5.1.6** **(10-17-2023)**

#### Acronyms and Terms

1. This table lists commonly used acronyms and terms:




| **Acronym** | **Term** |
| --- | --- |
| BU | Business Unit |
| BOD | Business Operating Division |
| CFR | Code of Federal Regulations |
| ECM | Enterprise Case Management |
| EO | Executive Order |
| FOIA | Freedom of Information Act |
| FRC | Federal Records Center |
| GRS | General Records Schedules, Document 12829 |
| IRC | Information Resource Coordinator |
| NARA | National Archives and Records Administration |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| RCS | Records Control Schedules, Document 12990 |
| RIM | Records and Information Management |
| SEC | Separating Employee Clearance |
| SET | Senior Executive Team |
| USC | United States Code |


**1.15.5.1.7** **(10-17-2023)**

#### Related Resources

1. Employees will find the following resources helpful on records and information management:



   - Records and Information Management (RIM) SharePoint

   - Document 12829, General Records Schedules

   - Document 12990, IRS Records Control Schedules

   - Title [36 CFR Chapter XII, Subchapter B](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Records Management codes,

   - eCase (Form 14757), Records Management Checklist for Separating Employees on the Enterprise Case Management (ECM) Platform

   - Form 14604, Contractor Separation Checklist

   - IRM 1.15.2, Types of Records and Their Life Cycles

   - IRM 1.15.3, Disposing of Records

   - IRM 1.15.6, Managing Electronic Records

   - PGLD Records Separating Employee Clearance (SEC) SharePoint

   - Integrated Talent Management (ITM) course Item #80788, BOD Manager and Proxy BOD Manager Training for PGLD Records Separating Employee Clearance (SEC) eCase Form 14757, Records Management Checklist for Separating Employees on the ECM Platform


**1.15.5.2** **(08-08-2017)**

### Migrating Records Between IRS Offices

1. Following an organizational realignment, employees must:



1. Relocate or migrate current records supporting the function to the new office or organization.

2. Identify records not required by the new office or organization. Notify the Records Specialists for possible retirement of these records to Federal Records Center (FRC).

3. Notify the Records Specialists about the reorganization, which may require revision of Document 12990, Records Control Schedules (RCS).

4. Update the gaining or new office files plan to reflect the new function(s) and records.


**1.15.5.3** **(02-12-2021)**

### Transferring to a New Business Unit / Organization

1. Upon receiving a new position and/or before transferring to a new BU or organization, employees must:



1. Return records to an appropriate office location or give to the manager or staff assuming recordkeeping responsibility. The transferring employee must ensure that the BU can account for all records (paper and electronic) the employee maintained and possibly retired to FRC.

2. Identify records no longer required by the current office or organization, and notify the Records Specialists for possible records retirement to FRC or process the Form 11671, Certificate of Records Disposal, for internal disposal of the records, if eligible.


**1.15.5.4** **(08-08-2017)**

### Releasing Records Custody Between Government Agencies

1. NARA regulations, [36 CFR 1231](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Transfer of Records from the Custody of One Executive Agency to Another, prohibit the release of records from one government agency to another without the approval of the Archivist of the United States, unless any or all of the following conditions exist:



1. Release or change in custody is required by statute, Executive Order (EO) or Presidential reorganization.

2. Records are permanent and are eligible for transfer to NARA.

3. Records are on temporary loan for official use.


### Reminder:

Records subject to restriction upon their use, which is imposed by EO or by the agency, are still under restriction, even after they have been released to the gaining agency. However, the restriction can be removed later with a written agreement between the agencies.

**1.15.5.5** **(08-08-2017)**

### Definition of Permanent Records

1. NARA has established definitions for the retention and transfer of permanent records. Permanent records:



1. include documents related to policy, procedures, organization, or executive direction of Internal Revenue Service's (IRS) activities;

2. contain evidence of the organization and functions of the IRS;

3. contain information useful for researching the administrative history of the IRS and the Department of the Treasury; or

4. are of value to the IRS because they contain information needed for organizational, procedural, and policy decisions.


### Note:

See [36 CFR 1220.18](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), General Definitions, for the regulatory definition of "permanent" records.

**1.15.5.6** **(09-23-2016)**

### Archival Standards for Permanent Retention of Records

1. Only original or official copies of records which meet the definition of permanent are required for archival or permanent retention.



### Note:



Refer to the Permanent Records Directory/Index located in IRS Document 12990, Records Control Schedules, for the identification of permanent records created by the IRS.


**1.15.5.7** **(09-23-2016)**

### Records that Require Direct Transfer to NARA

1. The following classes of IRS permanent records will transfer directly to NARA. These types of records must not be retired to FRC. They are:



1. audio-visual records (movies, photographs, tapes, etc.)

2. maps, charts, etc.

3. electronic records referred to in IRM 1.15.6, Managing Electronic Records. IRM 1.15.6 provides specific instructions on transferring permanent records directly to NARA.


### Note:

Unscheduled records that are at least 30 years old, and no longer have continuing value for the IRS, require NARA appraisal to determine if they are considered permanent in nature.

### Note:

If a permanent record has been retired to FRC for temporary storage, the FRC will transfer the records to a facility within the National Archives at the appropriate time.

**1.15.5.8** **(02-12-2021)**

### Standard Form 258

1. Records Specialists work with records custodians to provide the following permanent records information, which is required by Standard Form (SF) 258, Agreement to Transfer Records to the National Archives of the United States, including a box inventory or list and samples, if requested:



1. record series or title

2. date span of records—beginning and ending

3. major and minor subdivisions, i.e., Information Technology, Office of the Chief Information Officer

4. contact person—include telephone number

5. RCS authority

6. volume and format (paper, PDF, photograph)

7. any restrictions, e.g., Privacy Act, IRC 6103, Classified

8. finding aids or documents

9. records' current location


2. Submit the above information, background materials and samples, if requested, to the IRS Records Officer for processing at \*Records Management. The IRS Records Officer will prepare and forward the SF 258 to NARA for approval. After approval, NARA will provide an approved copy to the IRS Records Officer, who will retain an approved copy and send a copy back to the Records Specialist or BU representative who originated the request.


**1.15.5.9** **(02-12-2021)**

### Shipping Permanent Records to NARA

1. When boxing and transferring permanent records to NARA, standard storage boxes are required. Each box must include a detailed index listing the contents. This list must be provided to the IRS Records Officer for submission with the SF 258; shipping directions will be provided to the Records Specialists (if transferring directly from the agency and not from the FRC) along with the copy of the approved request.

2. Secure every box with the _Caution Permanent Record Tape_ specifically designed by PGLD Records and Information Management team. This tape ensures the containers are not disposed of before eventual transferring to NARA and provides easy identification of permanent records containers if stored in business units or on site.

3. When shipping the container(s) directly to NARA, the standard storage box fits inside a sleeve box to eliminate double wrapping each box in opaque paper, so that the tape or box is not visible. Ensure the to/from address is printed on each sleeve and inside box, so that if the sleeve is damaged in transit, the box can be identified and delivered. To order record sleeve boxes, orders may go directly to Columbia Container Corp., 1798 Union Avenue, Baltimore, MD 21211. Telephone number: 410-467-1400, Fax number: 410-467-1793. RECORD STORAGE BOX SLEEVE - bundles of 25, plus shipping costs. Use of a different vendor is acceptable, but note that sleeve boxes must be one quarter inch in diameter larger on all six sides of a standard FRC box.


**1.15.5.10** **(02-12-2021)**

### Separating Employee Clearance (SEC)

1. The separating employee clearance process requires certification that hard copy records have been returned to an appropriate office location, given to the supervisor or staff assuming recordkeeping responsibility, and/or electronic federal records stored on IT-issued equipment (laptop, flash drive/thumb drive, external hard drive, or other removable media) have been secured prior to turning in equipment. This certification includes a signed statement by the separating employee’s manager remitted to the IRS Records and Information Management Office.

2. Managing documents in appropriate recordkeeping systems ensures IRS is compliant with NARA records management regulations and policies.


**1.15.5.10.1** **(10-17-2023)**

#### Employee/Manager Roles and Responsibilities (Outside HR Connect)

1. IRS employees and managers must ensure federal records and other hard copy and electronic documents in their possession with ongoing records retention or litigation hold requirements are appropriately secured in advance of separation from the IRS and electronic media turn-in.



1. IRS employees must maintain and dispose of federal records in accordance with the IRS comprehensive Records Control Schedules (RCS), which comes from two sources: Document 12990 for IRS program/mission-critical functions and Document 12829 for General Records Schedule administrative-related functions (see IRM 1.15.2 and IRM 1.15.3).

2. To help determine record status, refer to IRM 1.15.2, Types of Records and Their Life Cycles, and the Is It a Record? flowchart.

3. Separating employee documents may also be subject to a litigation hold. Regardless of the form in which they are kept, documents that are subject to a litigation hold must be preserved while the litigation hold is in place. For additional information on whether an employee is subject to a litigation hold, contact Chief Counsel by telephone at (202) 317-5206, or send an email to the Litigation Hold mailbox.

4. Documents may also need to be preserved for other reasons, such as holds issued in connection with pending Congressional inquiries or Freedom of Information Act (FOIA) requests.

5. All separating employees (including senior officials) must timely:



      > - Collect hard copy records and return them to their appropriate office locations (i.e., centralized file cabinet) or to FRC, for example, if "checked-out" from FRC storage.
      >
      >       - Review all electronic files, including emails, word processing documents, spreadsheets, folders, etc. saved to a personal hard drive for federal records or other material that must be preserved or maintained, and move them to an accessible network storage location. Email messages identified as federal records must be handled in accordance with guidance provided in IRM 1.15.6, Managing Electronic Records, and NARA-approved records retention schedules. When business needs require email records to be retained with other records (such as part of an investigation, contract, project, or other case file), forward or copy these email records to the appropriate recordkeeping system (i.e., electronic recordkeeping system or paper file) and maintain according to the Document 12990, IRS Records Control Schedules or Document 12829, General Records Schedules.
      >
      >       - Email records saved to the network will be auto-archived.
      >
      >       - Remove passwords from password-protected files and folders that you manage.
      >
      >
      >
      >         ### Note:
      >
      >
      >
      >         Employees must not provide passwords or PIN numbers for any IRS systems (such as IDRS, RGS, etc.).
      >
      >       - Review, with their manager, eCase (Form 14757), Records Management Checklist for Separating Employees, for manager’s certification that all records (hard copy and electronic) have been returned/secured/saved to an appropriate recordkeeping system (such as a Business Unit SharePoint site) for ongoing preservation and/or maintenance, or transferred to staff assuming responsibility for a matter (for example, a case file or project file). The eCase (Form 14757) also includes accounting for the records of separating employees under a litigation hold and separating senior executive team (SET) members. While Form 14757 was previously a PDF version, the manager and/or proxy completes the eCase (Form 14757) electronically using the Enterprise Case Management (ECM) Platform, which provides an automated, streamlined completion and submission.
      >
      >
      >
      >         ### Note:
      >
      >
      >
      >         If the manager and/or proxy **DO NOT** already have an account for accessing the ECM Platform, email the PGLD Records SEC Advisory Group at \*PGLD Records SEC ECM HELP.
      >
      >
      >
      >
      >
      >         ### Note:
      >
      >
      >
      >         To learn how to input and submit an eCase (Form 14757), refer to ITM course Item #80788, BOD Manager and Proxy BOD Manager Training for PGLD Records Separating Employee Clearance (SEC) eCase Form 14757, Records Management Checklist for Separating Employees on the ECM Platform.


2. Coordinate any ongoing records preservation or maintenance needs with IT, as necessary. This could mean extra records storage needs in a recordkeeping environment backed-up by a server or via network, and/or the transfer of proxy rights to that data. Employees must allow time to complete records-related responsibilities, beginning the process as early as possible prior to separation.

3. Managers are ultimately responsible for ensuring their employees comply with records management requirements. This guidance applies to managers of IRS separating employees. The requirement for managers to complete and submit an eCase (Form 14757), includes separating Interns, Volunteers, or Student Trainees, regardless of paid or unpaid position. This guidance does not apply to outside IRS contractors separating from an IRS contract and already following exit procedures outlined in Form 14604, Contractor Separation Checklist.

4. Under current procedures, separating employees subject to litigation holds must notify the attorney of the separation so the attorney can take steps to have IT "collect" the data before the separation. If IT does not "collect" the data before the separation, the computer equipment must be stored by the manager until IT conducts the "collection" . After the "collection" is completed, the manager will submit an IRS Service Central (formerly OS GetServices) ticket to notify IT that equipment of separating employee is ready for pick up and transfer to IT.


**1.15.5.10.2** **(02-12-2021)**

#### Employee Responsibilities Regarding Personal Documents

1. Personal documents are of a private and unofficial nature, that pertain to employee’s personal affairs. See IRM 1.15.2.3.2, Types of Records and Their Life Cycles, Personal Documents, for additional information on personal documents.

2. Employee responsibilities regarding personal documents are:



1. Clearly identify and maintain those documents of a private or unofficial nature separately from the records of the office; and

2. Remove personal information from documents containing both personal and business information; photocopy document and file the record copy without the personal information.


3. Personal documents may be removed at an employee’s discretion except when under a litigation hold. Senior Executive Team (SET) members, however, must consult with the IRS Records Officer at \*Separating Employee Clearance (SEC) prior to removing personal documents to confirm that such documents do not have an independent historical preservation interest.


**1.15.5.10.3** **(02-12-2021)**

#### Documents Which Can Be Removed

1. An employee, leaving employment with the IRS, can remove certain non-record material:



1. work aids, such as office diaries, logs, and memoranda of conferences and telephone calls that are memorialized elsewhere by other, or more detailed or complete records, provided the material does not contain national security, taxpayer privacy, or other confidential information; and

2. extra copies of records (e.g., photocopies, etc.), unless prohibited or limited by, disclosure statutes, regulations, or agreements.


2. The conditions under which an employee **can** remove non-record material are listed below:




| **If removal does not** | **Then** |
| --- | --- |
| Impose an administrative or financial burden | Obtain the IRS Records Officer’s approval to remove the material |
| Violate the confidentiality required by national security, privacy, and other interests protected by law | Obtain the IRS Records Officer’s approval to remove the material |
| Create a gap in the files and affect integrity of the file, the documentation, or the body of information | Obtain the IRS Records Officer’s approval to remove the material |





> ### Note:
>
> If separating employees want to remove copies of official records that may be classified or otherwise restricted, they must first consult the \*Disclosure staff, Chief Counsel and the IRS Records Officer at \*Separating Employee Clearance (SEC).
>
>  The IRS, not the individual, is responsible for determining whether the release of potentially classified or restricted records is appropriate and under what conditions.


**1.15.5.10.4** **(09-23-2016)**

#### Documents Which CANNOT Be Removed

1. The conditions for which an employee CANNOT remove documents (record or non-record, personal documents) are listed below:




| **If they are** | **Then** |
| --- | --- |
| Covered by a litigation or other hold because they are potentially relevant to a pending or contemplated civil, criminal, or administrative proceeding, or a pending Congressional inquiry<br> <br>### Note:<br>Releasing the information would impair or prejudice the outcome of the proceeding or otherwise adversely affect government policy, decisions, determinations, or other actions. | Do not remove |
| National security information and officially limited information<br> <br>### Note:<br>Such information remains classified, controlled, or restricted, as long as required for national security or IRS’ interests. | Do not remove |

2. **Executive Order 12958, Classified National Security Information** and Treasury regulations provide for possible downgrading, declassification, and review of national security and officially limited information.



### Note:



Contact your Security or Disclosure Officer for questions concerning the disclosure and declassification of national security and officially limited information.


**1.15.5.10.5** **(10-17-2023)**

#### Separating Employees Checklist (Form 14757)

1. Before an employee separates from IRS employment, the manager, per review with employees, must complete an eCase (Form 14757), Records Management Checklist for Separating Employees, to certify the protection of federal records, including the preservation of all documents (record or non-record) subject to litigation hold needs.

2. After creating the Personnel Action Request (PAR) and processing the HR Connect SEC Record under the Legal Category SEC Items, the manager and/or proxy must use the ECM Platform, while meeting with the employee answering the questions, to complete, sign, and submit the eCase (Form 14757).

3. The manager and/or proxy must request access to the ECM Platform (Clearance Management application) by completing and submitting a Business Entitlement Access Request System (BEARS) access request. Refer to the Records SEC/ECM BOD Managers, Proxy BOD Managers and IT-CC Guide on the PGLD Records Separating Employee Clearance (SEC) SharePoint, for step-by-step instructions on requesting access and completing all required records separating actions on the ECM Platform. Another way to learn how to input and submit an eCase (Form 14757), is to take the ITM course #80788, BOD Manager and Proxy BOD Manager Training for PGLD Records Separating Employee Clearance (SEC) eCase Form 14757, Records Management Checklist for Separating Employees on the ECM Platform.

4. The manager (not the proxy user) will sign and electronically submit the eCase (Form 14757) on the ECM Platform. Contact \*PGLD Records SEC ECM HELP for assistance gaining access to the ECM Platform. Additional information can be found on the PGLD Records Separating Employee Clearance (SEC) SharePoint.

5. If the employee is not available due to death, adverse action, etc. the manager, to the extent possible, must complete an eCase (Form 14757) and notate in Block 8 of the form that the employee is not available.

6. An eCase (Form 14757) must be completed on separating Interns, Volunteers, Student Trainees, regardless of paid or unpaid position, even if a PAR action is not required in HR Connect.


**1.15.5.10.5.1** **(10-17-2023)**

##### Exceptions to Use of Form 14757 for Separating Employee Clearance

1. Business units are entitled to an exception from completing and submitting an eCase (Form 14757), Records Management Checklist for Separating Employees, for their employees who work on 30, 60, 90-day temporary appointments. These temporary appointment employees do not utilize computers, but work in pipeline areas to open, sort, batch, and number mail/documents in a processing environment. They do not create, receive, or transmit federal records (in hard copy or electronic format).



### Note:



This exception does not apply to employees in a non-work status (furlough) as they are not permanently separated from the Service. When a permanent separation occurs, an eCase (Form 14757) will be required for these employees.

2. To qualify for this exception, the employee must be on a 30, 60, 90-day temporary appointment and must not create, receive, or transmit records (in hard copy or electronic format). If both criteria are met, the manager and employee are exempt from submitting an eCase (Form 14757).



### Note:



If the employee’s 30, 60, 90-day temporary appointment is amended, changed, updated, or altered to include the assignment of a computer or otherwise create, receive, or transmit records, the exception is no longer applicable to the manager and employee. The records management guidance outlined in _IRM 1.15.5.10.1_, Employee/Manager Roles and Responsibilities (Outside HR Connect) is applicable and becomes effective.

3. Business units utilizing this exception authority will provide notification to the Records and Information Management, PGLD Records SEC Advisory group via email by the 25th of each month to the \*Separating Employee Clearance (SEC) mailbox with the Subject line: 30, 60, 90-day Temporary Appointment Employee Terminations, and include a list of the names and Standard Employee Identifier (SEID) numbers of the 30, 60, 90-day terminations.

4. Business unit managers of the temporary appointment employee terminations are required to access the Legal Category in HR Connect and select "Not Applicable" for the "Estimated Return Method" for both SEC Items (Form 14757 CHKLST and Senior Executive Team (SET) Exit Briefing). Managers must also include a note in the "Comments" box: "Temporary Appointment Employee Termination" . Any selection other than "Not Applicable" will require the manager to submit an eCase (Form 14757) to the Records and Information Management office.

5. The Records and Information Management PGLD Records SEC Advisory group will, no later than the 10th of each month following receipt of email notification of termination of the 30, 60, 90-day temporary appointment employee, process the SEC maintenance record in the HR Connect system to close out the transaction.


**1.15.5.10.6** **(10-17-2023)**

#### Retention of Separating Employee Clearance (SEC) Records

1. The Records and Information Management Program office has primary recordkeeping responsibility for eCase (Form 14757) and maintains it on the ECM Platform for three (3) years after close-out of an eCase (Form 14757).

2. Managers have the option to download a PDF of the completed and signed eCase (Form 14757) from the ECM Platform. A copy can be retained by the manager in the employee’s drop file.


**1.15.5.10.7** **(09-23-2016)**

#### Notifications to IT

1. Managers will submit an IRS Service Central ticket to notify IT that equipment of separating employee is ready for pick up and transfer to IT. If a litigation hold or other hold is in place and Counsel has determined that data must be collected, managers must take custody of and secure separating employees’ IT equipment until IT takes the equipment and collects the data. Subsequent to the collection of the data by IT, managers may release the equipment to IT for appropriate handling and processing.


**1.15.5.11** **(09-23-2016)**

### Penalties for Unlawful Removal, Alienation, or Destruction of Government Records

1. Penalties for unlawful removal, alienation, or destruction of government records may include a fine, imprisonment, or both.

2. This offense, and related offenses, are stated in



   - 18 United States Code (USC) 2071; and

   - 18 USC 641, 793, 794, 798, and 952.


**Exhibit 1.15.5-1**

### Caution Permanent Record Tape and Instructions

![This is an Image: 31427002.gif](https://www.irs.gov/pub/xml_bc/31427002.gif)

> Title: Caution Permanent Record Tape Summary: This tape has the IRS official seal and instructs the user where to enter a record control schedule and how to identify and transfer permanent records.

[Please click here for the text description of the image.](https://www.irs.gov/media/129741 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-015-005#addtoany "Show all")

A2A