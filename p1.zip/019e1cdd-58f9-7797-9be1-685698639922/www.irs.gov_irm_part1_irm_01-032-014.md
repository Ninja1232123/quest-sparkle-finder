---
url: "https://www.irs.gov/irm/part1/irm_01-032-014"
title: "1.32.14 Gainsharing Travel Savings Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-014#main-content)

- 1.32.14  [Gainsharing Travel Savings Program](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952940128528)
  - 1.32.14.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911639696)
    - 1.32.14.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911635936)
    - 1.32.14.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952940116128)
    - 1.32.14.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952940111712)
      - 1.32.14.1.3.1  [Employees](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952940104640)
      - 1.32.14.1.3.2  [First-Level Managers](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952940098960)
      - 1.32.14.1.3.3  [Second-Level Managers](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952940094880)
      - 1.32.14.1.3.4  [Business Units](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911597728)
      - 1.32.14.1.3.5  [HCO](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911591904)
      - 1.32.14.1.3.6  [Commissioner](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911588000)
      - 1.32.14.1.3.7  [Chief Operating Officer](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911586000)
      - 1.32.14.1.3.8  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911583584)
      - 1.32.14.1.3.9  [Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911581840)
      - 1.32.14.1.3.10  [Travel Management](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911579920)
      - 1.32.14.1.3.11  [Travel Review](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911576528)
      - 1.32.14.1.3.12  [Travel Services](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911571200)
    - 1.32.14.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911569504)
    - 1.32.14.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911563936)
    - 1.32.14.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952911551936)
    - 1.32.14.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910380656)
  - 1.32.14.2  [General Rules](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910376144)
    - 1.32.14.2.1  [Common Carrier Savings](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910359936)
    - 1.32.14.2.2  [Lodging Savings](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910353648)
  - 1.32.14.3  [Excess Transportation and Miscellaneous Costs](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910345264)
  - 1.32.14.4  [Travel Ineligible for Gainsharing](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910335200)
  - 1.32.14.5  [Gainsharing Award Process](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910322656)
  - 1.32.14.6  [Taxes](https://www.irs.gov/irm/part1/irm_01-032-014#idm139952910302912)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 14. Gainsharing Travel Savings Program

* * *

## 1.32.14 Gainsharing Travel Savings Program

#### Manual Transmittal

June 18, 2024

#### Purpose

(1) This transmits revised IRM 1.32.14, Servicewide Travel Policies and Procedures, Gainsharing Travel Savings Program.

#### Material Changes

(1) IRM 1.32.14.1(4), Program Scope and Objectives, added Corporate Accounting office per CFO reorganization.

(2) IRM 1.32.14.1.1(5), Background, updated section to clarify that lodging savings also includes staying with family and/or friends.

(3) IRM 1.32.14.1.3(1)(f), Responsibilities, added responsibility for the Commissioner.

(4) IRM 1.32.14.1.3(1)(g), Responsibilities, updated title from Deputy Commissioners to Chief Operating Officer per IRS leadership organizational structure change.

(5) IRM 1.32.14.1.3(1)(i), Responsibilities, updated title from Associate CFO for Financial Management to Associate CFO for Corporate Accounting per CFO reorganization.

(6) IRM 1.32.14.1.3(1)(k), Responsibilities, updated title from Travel Policy and Review to Travel Review per CFO reorganization.

(7) IRM 1.32.14.1.3.4(1)(a), Business Units, removed that the employee’s business unit retains the award records for 2 years old because this is already covered in IRM 1.32.14.1.2, Authority, and IRM 1.32.14.2, General Rules.

(8) IRM 1.32.14.1.3.4(1)(b), Business Units, removed the retention period of six years for manual authorizations and vouchers because this is already covered in IRM 1.32.14.1.2, Authority, and IRM 1.32.14.2, General Rules.

(9) IRM 1.32.14.1.3.4(1)(f), Business Units, for clarification, added that if an award is processed during the same fiscal year in which the savings was accrued, the business unit will code the award to the current fiscal year. If an award is processed after the end of the fiscal year in which the savings was accrued, the business unit will code it to the fiscal year in which the award is processed.

(10) IRM 1.32.14.1.3.6, Commissioner, added responsibility for the Commissioner.

(11) IRM 1.32.14.1.3.6(1), Commissioner, added the Commissioner’s Chief of Staff is responsible for serving as the approving official for the Deputy Commissioner and Commissioner’s direct reports’ gainsharing awards.

(12) IRM 1.32.14.1.3.7, Chief Operating Officer, updated title from Deputy Commissioners to Chief Operating Officer per IRS leadership organizational structure change.

(13) IRM 1.32.14.1.3.7(1), Chief Operating Officer, updated title from Deputy Commissioners to Chief Operating Officer per IRS leadership organizational structure change.

(14) IRM 1.32.14.1.3.7(2), Chief Operating Officer, updated title from Deputy Commissioners to Chief Operating Officer per IRS leadership organizational structure change.

(15) IRM 1.32.14.1.3.9, Associate CFO for Corporate Accounting, updated title from Associate CFO for Financial Management to Associate CFO for Corporate Accounting per CFO reorganization.

(16) IRM 1.32.14.1.3.9(1), Associate CFO for Corporate Accounting, updated title from Associate CFO for Financial Management to Associate CFO for Corporate Accounting per CFO reorganization.

(17) IRM 1.32.14.1.3.11, Travel Review, updated title from Travel Policy and Review to Travel Review per CFO reorganization.

(18) IRM 1.32.14.1.3.11(1)(e), Travel Review, added responsibility to obtain the FedRooms Data File from FedRooms and provide to business unit contact.

(19) IRM 1.32.14.1.3.11(1)(g), Travel Review, updated title from Travel Policy and Review to Travel Review per CFO reorganization and updated that gainsharing awards report will be reviewed bi-weekly instead of monthly.

(20) IRM 1.32.14.1.4(2), Program Management and Review, updated title from Travel Policy and Review to Travel Review per CFO reorganization.

(21) IRM 1.32.14.1.4(4), Program Management and Review, updated title from Travel Policy and Review to Travel Review per CFO reorganization.

(22) IRM 1.32.14.1.4(5), Program Management and Review, updated title from Travel Policy and Review to Travel Review per CFO reorganization.

(23) IRM 1.32.14.1.5(1), Program Controls, updated title from Travel Policy and Review to Travel Review per CFO reorganization.

(24) IRM 1.32.14.1.6(1), Terms and Acronyms, updated definition for commuting area to clarify that for per diem purposes only, it’s defined as the area within a 50-mile radius of the employee’s residence and official station.

(25) IRM 1.32.14.1.6(1), Terms and Acronyms, updated definition for government travel card to add travel expenses such as transportation, lodging, meals, baggage fees, rental cars and rental car fuel/oils, for which the contractor bills the employee, for clarification.

(26) IRM 1.32.14.1.6(1), Terms and Acronyms, updated definition for non-conventional lodging to add private home or recreational vehicle (RV) for clarification.

(27) IRM 1.32.14.1.6(2), Terms and Acronyms, added the Code of Federal Regulations (CFR), Government Employees’ Incentive Awards Act (GEIAA), Recreation Vehicle (RV), Transportation Network Company (TNC) and U.S. Code (USC).

(28) IRM 1.32.14.1.7(5), Related Resources, removed that the employee’s business unit retains the award records for 2 years old because this is already covered in IRM 1.32.14.1.2, Authority, and IRM 1.32.14.2, General Rules.

(29) IRM 1.32.14.1.7(6), Related Resources, removed the retention period of six years for manual authorizations and vouchers because this is already covered in IRM 1.32.14.1.2, Authority, and IRM 1.32.14.2, General Rules.

(30) IRM 1.32.14.2(1), General Rules, updated section to clarify that lodging savings also includes staying with family and/or friends.

(31) IRM 1.32.14.2(4), General Rules, updated title from Deputy Commissioner for Operations Support to Chief Operating Officer per IRS leadership organizational structure change.

(32) IRM 1.32.14.2(11), General Rules, updated title from Associate CFO for Financial Management to Associate CFO for Corporate Accounting per CFO reorganization.

(33) IRM 1.32.14.2(13), General Rules, updated section to clarify that documents may be destroyed when 2 years old or 2 years after award is approved or disapproved, whichever is later, but longer retention is authorized if needed for business use such as a litigation hold, agency freezes and potential/impending audits.

(34) IRM 1.32.14.2(14), General Rules, updated section to clarify that copies of approved travel authorizations and supporting documentation for manual vouchers must be maintained for six years in compliance with GRS 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, for records retention authorized disposition, but longer retention is authorized if needed for business use such as a litigation hold, agency freezes and potential/impending audits.

(35) IRM 1.32.14.2.1(1), Common Carrier Savings, added an example of common carrier savings for clarification.

(36) IRM 1.32.14.3(2)(c), Excess Transportation and Miscellaneous Costs, added TNC such as Uber/Lyft for clarification.

(37) IRM 1.32.14.4(1)(j), Travel Ineligible for Gainsharing, updated section to remove “though the IRS or hotel”, as other agencies or private vendors may prepay, contract or prearrange lodging (e.g., block of rooms).

(38) IRM 1.32.14.4(1)(o), Travel Ineligible for Gainsharing, updated title from Associate CFO for Financial Management to Associate CFO for Corporate Accounting per CFO reorganization.

(39) IRM 1.32.14.4(1)(s), Travel Ineligible for Gainsharing, added that conventional lodging not booked in the Electronic Travel System (ETS) or with the Travel Management Center (TMC) is not eligible for gainsharing.

(40) IRM 1.32.14.5(1)(a), Gainsharing Award Process, removed that only one request may be submitted each fiscal year because this is already covered in IRM 1.32.14.1.1(8), Background.

(41) IRM 1.32.14.5(4)(a), Gainsharing Award Process, added responsibility for the business unit contact to review the FedRooms Data File, if applicable.

(42) IRM 1.32.14.5(4)(b), Gainsharing Award Process, updated title from Travel Policy and Review to Travel Review per CFO reorganization and updated mailbox to [CFO.FM.Travel.Gainsharing@irs.gov](https://www.irs.gov/irm/part1/CFO.FM.Travel.Gainsharing@irs.gov).

(43) IRM 1.32.14.5(5), Gainsharing Award Process, updated title from Travel Policy and Review to Travel Review per CFO reorganization.

(44) IRM 1.32.14.5(5)(a), Gainsharing Award Process, added responsibility for Travel Review to review the FedRooms Data File, if applicable.

(45) IRM 1.32.14.5(8), Gainsharing Award Process, removed that the employee’s business unit retains the award records for 2 years old because this is already covered in IRM 1.32.14.1.2, Authority, and IRM 1.32.14.2, General Rules.

(46) IRM 1.32.14.5(8)(f), Gainsharing Award Process, added manual authorizations and vouchers, if applicable.

(47) IRM 1.32.14.5(9). Gainsharing Award Process, moved section of the business unit retains copies of the approval manual travel authorizations and manual vouchers to IRM 1.32.14.5(8)(f). Removed the retention period of six years for manual authorizations and vouchers because this is already covered in IRM 1.32.14.1.2, Authority, and IRM 1.32.14.2, General Rules.

(48) This revision includes changes throughout the document for the following:

1. Added minor editorial changes

2. Updated links throughout the IRM


#### Effect on Other Documents

IRM 1.32.14, dated July 1, 2021, is superseded.

#### Audience

All business units

#### Effective Date

(06-18-2024)

Teresa R. Hunter

Chief Financial Officer

**1.32.14.1** **(06-18-2024)**

### Program Scope and Objectives

1. Purpose: This IRM provides policies and procedures for IRS employees who save the government money each fiscal year on common carrier transportation and lodging while on official city-to-city travel and who apply for a gainsharing award.

2. Audience: All business units

3. Policy Owner: CFO, Financial Management

4. Program Owner: CFO, Financial Management, Corporate Accounting, Travel Management office, develops and maintains this IRM.

5. Primary Stakeholders: The primary stakeholders are IRS employees who perform city-to-city travel, including domestic and foreign travel, in the interest of the government. Additional stakeholders include the business units, first-level managers, second-level managers, HCO and CFO.

6. Program Goals: To ensure that IRS employees exercise integrity while participating in the gainsharing program and comply with the Federal Travel Regulation (FTR) and IRS policy when applying for a gainsharing award.


**1.32.14.1.1** **(06-18-2024)**

#### Background

1. The Government Employees’ Incentive Awards Act (GEIAA), 5 U.S. Code (USC) 4501-07, authorizes an agency to pay a cash award for efficiency or economy.

2. In 1995, the General Services Administration (GSA) provided guidance on a program known as “Gainsharing” where agencies could give cash awards to employees who participate in programs to save travel dollars.

3. Initiated and negotiated with NTEU by the IRS on November 1, 1999, the Gainsharing Travel Savings Program is a voluntary program that rewards employees who save the IRS money on common carrier transportation and lodging while on official city-to-city travel.

4. At the core of the program are the principles that an employee must take affirmative, purposeful action to:



1. Save public funds.

2. Keep an accurate record of public funds saved.

3. Provide documentation for review.


5. Based on these principles, the IRS has determined that the only savings it recognizes are those arising from an employee paying less than the maximum lodging rate for a Temporary Duty (TDY) location, to include staying with family and/or friends resulting in zero lodging cost, and/or using frequent traveler benefits to purchase common carrier tickets for official travel.

6. The employee's award amount will be 50% of the savings on lodging expenses and/or contract carrier airfare when they qualify to receive an award of at least $100 before taxes for Bargaining Unit (BU) employees and at least $200 before taxes for Non-Bargaining Unit (NBU) employees.

7. Federal, state, and local income taxes, and Federal Insurance Contributions Act (FICA) taxes will be withheld on any award amount paid.

8. An employee can only submit one Form 13631-A, IRS Travel Savings, that covers the entire fiscal year award period.


**1.32.14.1.2** **(07-01-2021)**

#### Authority

1. 5 USC 4501-07, [Government Employees’ Incentive Awards Act](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partIII-subpartC-chap45)

2. 5 Code of Federal Regulations (CFR) Part 451, [Awards](http://www.law.cornell.edu/cfr/text/5/part-451)

3. National Defense Authorization Act of 2002, [Pub. L. 107-107, section 1116](https://www.govinfo.gov/content/pkg/PLAW-107publ107/html/PLAW-107publ107.htm)


**1.32.14.1.3** **(06-18-2024)**

#### Responsibilities

1. This section provides responsibilities for:



01. Employees

02. First-level managers

03. Second-level managers

04. Business units

05. HCO

06. Commissioner

07. Chief Operating Officer

08. CFO and Deputy CFO

09. Associate CFO for Corporate Accounting

10. Travel Management

11. Travel Review

12. Travel Services


**1.32.14.1.3.1** **(07-01-2021)**

##### Employees

1. Employees are responsible for:



1. Tracking their gainsharing savings during the fiscal year.

2. Preparing and submitting one completed Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, with supporting documentation, including reporting instructions, if applicable, travel vouchers and receipts, to their manager by December 31 for the immediately preceding fiscal year.

3. Providing proof that the government travel card was used for payment.

4. Providing proof of savings claimed for exchanging frequent traveler benefits for a free common carrier ticket or lodging, such as the common carrier or lodging invoice.

5. Providing proof of savings for lodging, such as the lodging invoice that displays the method of payment used.

6. Adhering to all travel guidelines in IRM 1.32.11, Official IRS City-to-City Travel Guide, to qualify for a gainsharing award.

7. Paying any fees charged to participate in frequent travel programs with personal funds.


**1.32.14.1.3.2** **(07-01-2021)**

##### First-Level Managers

1. First-level managers are responsible for:



1. Serving as the recommending officials.

2. Reviewing Form 13631-A, IRS Travel Savings, Form 15245, IRS Gainsharing Travel Savings Program Checklist, reporting instructions, if applicable, travel vouchers and receipts.

3. Ensuring the gainsharing award is processed in accordance with applicable award processing requirements contained in this IRM and with business unit award processing requirements.

4. Recommending a gainsharing award by signing and dating Form 13631-A, IRS Travel Savings.


**1.32.14.1.3.3** **(07-01-2021)**

##### Second-Level Managers

1. Second-level managers are responsible for:



1. Serving as the approving officials.

2. Reviewing Form 13631-A, IRS Travel Savings, Form 15245, IRS Gainsharing Travel Savings Program Checklist, reporting instructions, if applicable, travel vouchers and receipts.

3. Ensuring the gainsharing award is processed in accordance with applicable award processing requirements contained in this IRM and with business unit award processing requirements.

4. Approving a gainsharing award by signing and dating Form 13631-A, IRS Travel Savings.


**1.32.14.1.3.4** **(06-18-2024)**

##### Business Units

1. Business units are responsible for:



1. Establishing and maintaining a centralized repository for all gainsharing records to include Form 13631-A, IRS Travel Savings, Form 15245, IRS Gainsharing Travel Savings Program Checklist, reporting instructions, if applicable, travel vouchers and receipts.

2. Maintaining copies of approved travel authorizations and supporting documentation for manual vouchers.

3. Ensuring gainsharing awards are processed correctly in HR Connect.

4. Ensuring funds are available to pay for gainsharing awards.

5. Entering an estimate of gainsharing expenditures at year-end into the financial system.

6. Ensuring an award is coded to the correct fiscal year and accounting codes. If an award is processed during the same fiscal year in which the savings was accrued, the business unit will code the award to the current fiscal year. If an award is processed after the end of the fiscal year in which the savings was accrued, the business unit will code it to the fiscal year in which the award is processed.

7. Establishing internal procedures for authorization and approval processes, and the signed original Form 13631-A, IRS Travel Savings.


**1.32.14.1.3.5** **(07-01-2021)**

##### HCO

1. HCO is responsible for:



1. Conducting misconduct and tax compliance screenings.

2. Processing gainsharing awards submitted in HR Connect.

3. Correcting any gainsharing awards that fail to process in HR Connect.

4. Generating the Standard Form 50, Notification of Personnel Action, indicating the award amount.


**1.32.14.1.3.6** **(06-18-2024)**

##### Commissioner

1. The Commissioner’s Chief of Staff is responsible for serving as the approving official for the Deputy Commissioner and Commissioner’s direct reports’ gainsharing awards.


**1.32.14.1.3.7** **(06-18-2024)**

##### Chief Operating Officer

1. The Chief Operating Officer is responsible for serving as the approving official for all Senior Executive Service (SES) gainsharing awards. The Chief Operating Officer approves the gainsharing awards by signing and dating Form 13631-A, IRS Travel Savings.

2. The Chief Operating Officer is responsible for approving gainsharing awards in the amount of $10,001 to $25,000.


**1.32.14.1.3.8** **(07-01-2021)**

##### CFO and Deputy CFO

1. The CFO and the Deputy CFO are responsible for managing the Gainsharing Travel Savings Program.


**1.32.14.1.3.9** **(06-18-2024)**

##### Associate CFO for Corporate Accounting

1. The Associate CFO for Corporate Accounting is responsible for establishing, maintaining and ensuring compliance with travel policy and procedures for internal accounting operations and financial reporting related to the IRS Gainsharing Travel Savings Program.


**1.32.14.1.3.10** **(07-01-2021)**

##### Travel Management

1. The Travel Management office is responsible for:



1. Developing and issuing policy for the IRS Gainsharing Travel Savings Program.

2. Reviewing financial policies and procedures for compliance with financial laws and regulations.

3. Overseeing the gainsharing process and validating the program.


**1.32.14.1.3.11** **(06-18-2024)**

##### Travel Review

1. Travel Review is responsible for:



1. Providing guidance on the IRS Gainsharing Travel Savings Program.

2. Educating customers on travel policy, FTR, travel procedures and the gainsharing program.

3. Authoring IRM 1.32.14, IRS Gainsharing Travel Savings Program, and travel guidance.

4. Developing travel communications to educate travelers on the Gainsharing Travel Savings Program.

5. Obtaining the FedRooms Data File from FedRooms and providing to the business unit contact.

6. Reviewing gainsharing requests for accuracy prior to final approval.

7. Reviewing the bi-weekly gainsharing awards report and ensuring Travel Review reviewed all paid awards.


**1.32.14.1.3.12** **(07-01-2021)**

##### Travel Services

1. Travel Services is responsible for providing help desk services for users and authorizing officials.


**1.32.14.1.4** **(06-18-2024)**

#### Program Management and Review

1. Internal controls are established to ensure the use of the IRS Gainsharing Travel Savings Program is managed effectively.

2. Program reports: Travel Review uses reports obtained from HR Connect to verify gainsharing award payments. Reports are generated bi-weekly. Paid awards are reviewed to verify program requirements were met.

3. Program effectiveness: Throughout the year, program effectiveness is measured through several reviews. These reviews include, but are not limited to, the following:



1. 100% review of all vouchers and receipts related to the gainsharing award, Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, for accuracy and compliance with this IRM and the FTR.

2. 100% verification of all gainsharing awards paid to ensure accuracy and compliance with this IRM and the FTR.


4. If the business units and/or Travel Review determine the gainsharing requests are not accurate and compliant, the requests will be returned for corrections and/or may be denied.

5. If Travel Review determines the gainsharing awards paid are not accurate and compliant, a billing document may be established for repayment.


**1.32.14.1.5** **(06-18-2024)**

#### Program Controls

1. Several program controls are in place to ensure compliance with this IRM. They include, but are not limited to, the controls listed below:




| **Control** | **Control Method** |
| --- | --- |
| Delegation of Authority | Authority to approve gainsharing awards is delegated to the appropriate level in the business units and is documented. |
| Separation of Duties | Separate roles are established for travelers, reviewers and approvers. |
| Compliance Reviews | Travel Review conducts reviews of all awards and supporting documentation. HCO completes a misconduct and federal tax compliance screening prior to initiating a travel gainsharing award. |
| Documentation Reviews | Travel Review conducts reviews of all supporting documentation before award is paid. |
| Funding Approvals | Based on delegation of authority, the appropriate business unit contact will review and approve the award and ensure funds are available before a gainsharing award is processed. |
| Quality Reviews | Travel Review conducts post payment audits bi-weekly. |


**1.32.14.1.6** **(06-18-2024)**

#### Terms and Acronyms

1. The following table defines terms that appear throughout this IRM section:



|     |     |
| --- | --- |
| City-to-city | A form of travel to a place, away from an employee's official station, to which the employee is authorized to travel, which may involve an overnight stay or lodging expense. |
| Common carrier | Airline, bus or rail transportation. |
| Commuting area | For per diem purposes only, is defined as the area within a 50-mile radius of the employee’s residence **and** official station. |
| Contract city-pair fare | An airline transportation fare negotiated under contract by GSA. The fare is fully refundable and exchangeable and reserved for government travel. |
| Extended Temporary Duty (TDY) location | Employee is in TDY status for 30 consecutive days or longer at a single location, and the TDY location is farther than 50 miles from both the employee’s Post of Duty (POD) and residence. |
| Frequent traveler benefits | Miles or points accumulated using common carrier/hotel rewards programs that result in free common carrier tickets or hotel stays. |
| FedRooms | A GSA program that provides hotels and motels that have agreed to provide lodging at rates equal to or less than the per diem rate for a given locality. |
| Government travel card | A government contractor-issued card used by employees to pay for official travel expenses such as transportation, lodging, meals, baggage fees, rental cars and rental car fuel/oils, for which the contractor bills the employee. |
| Non-conventional lodging | Any lodging that is not a traditional hotel/motel type facility which includes but is not limited to home-sharing rentals, Vacation Rental By Owner (VRBO), Airbnb, long term apartment, condominium, private home or recreational vehicle (RV). |
| Temporary Duty (TDY) location | A place, away from an employee's official station, to which the employee is authorized to travel. |
| Travel Management Center (TMC) | The travel agency operating under a GSA contract that provides transportation, lodging and rental car services to the IRS. |

2. The following table provides acronyms that are used throughout this IRM section:




| **Acronyms** | **Descriptions** |
| --- | --- |
| Airbnb | Air Bed and Breakfast |
| BU | Bargaining Unit |
| CFR | Code of Federal Regulations |
| ETS | Electronic Travel System |
| FICA | Federal Insurance Contribution Act |
| FTR | Federal Travel Regulation |
| GEIAA | Government Employees’ Incentive Awards Act |
| GRS | General Records Schedule |
| GSA | General Services Administration |
| NBU | Non-Bargaining Unit |
| PAR | Personnel Action Request |
| POD | Post of Duty |
| RV | Recreation Vehicle |
| TDY | Temporary Duty Location |
| TMC | Travel Management Center |
| TNC | Transportation Network Company |
| USC | U.S. Code |
| VRBO | Vacation Rental By Owner |


**1.32.14.1.7** **(06-18-2024)**

#### Related Resources

1. IRM 1.32.11, IRS City-to-City Travel Guide

2. IRM 1.33.4, Financial Operating Guidelines

3. IRM 6.451.1, Policies, Authorities, Categories, and Approvals

4. 41 CFR Chapters 300-304, Federal Travel Regulation

5. GRS 2.2, item 030 Employee Incentive Award Records, for information on retaining receipts and documentation in compliance with records retention authorized disposition. [http://www.archives.gov/records-mgmt/grs/](http://www.archives.gov/records-mgmt/grs/).

6. GRS 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, for information on retaining copies of approved travel authorizations and supporting documentation.


**1.32.14.2** **(06-18-2024)**

### General Rules

01. An employee may claim savings that are realized from staying in less expensive lodging, to include staying with family and/or friends resulting in zero lodging cost, and/or using frequent traveler benefits to purchase common carrier tickets or lodging for official travel. All city-to-city travel outside of the commuting area with lodging expenses, foreign and domestic, are covered under this program. Relocation travel expenses are not eligible for this program.

02. IRS BU employees are eligible to participate in the gainsharing program when they qualify to receive an award of at least $100, before taxes. For example, a BU employee who saves a combined total of $200 in lodging and airline tickets during the fiscal year is eligible to share 50% of the savings with the IRS. Total Savings = $200 x 50% = $100. The minimum cumulative award that can be paid for a fiscal year is $100 for a BU employee.

03. IRS NBU employees are eligible to participate in the gainsharing program when they qualify to receive an award of at least $200 before taxes. For example, an NBU employee who saves a combined total of $400 in lodging and airline tickets during the fiscal year is eligible to share 50% of the savings with the IRS. Total Savings = $400 x 50% = $200. The minimum cumulative award that can be paid for a fiscal year is $200 for a NBU employee.

04. The maximum cumulative award that can be paid without higher level approval for a fiscal year is $10,000. A gainsharing award in the amount of $10,001 to $25,000 must be approved by the IRS Chief Operating Officer.

05. Federal, state and local income taxes, and FICA tax will be withheld from the award. The award amount will be included in the employee’s Form W-2, Wage and Tax Statement.

06. An employee accumulates travel savings over a fiscal year period and documents the savings by utilizing Form 13631-A, IRS Travel Savings.

07. An employee must submit Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, with supporting documentation, to the individual’s manager no later than December 31 for the immediately preceding fiscal year. No submissions for a gainsharing award will be accepted from employees after the deadline.



    1. The first-level manager reviews Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, with supporting documentation, submitted by the employee and approves or denies the request.

    2. If approved, the second-level manager reviews Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, and forwards this, with the supporting documentation, to the business unit contact no later than January 31 for the immediately preceding fiscal year.

    3. The business unit contact reviews Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, and submits the required forms and documentation to Travel Review no later than March 31 for the immediately preceding fiscal year.

    4. Travel Review reviews Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, submitted by the business unit contact and approves or denies the request, and forwards to the business unit contact within 60 days of receipt of all required forms and documentation.


08. Claims for fiscal year gainsharing awards must be paid by September 30 of the subsequent year.

09. An employee can only submit one request for a gainsharing award for a fiscal year.

10. A gainsharing award may be withheld if deemed necessary to protect IRS’s integrity.

11. Federal employees should always stay in a fire-safe facility. Some non-conventional lodging facilities may not meet the fire-safe requirements and should not be used. For an employee to use non-conventional lodging, an exception must be approved in advance by the Associate CFO for Corporate Accounting and the approval must be uploaded into the Electronic Travel System (ETS). Non-conventional lodging such as leased or rented houses, apartments, condominiums or home-sharing rentals (i.e., Air Bed and Breakfast (Airbnb), Vacation Rental By Owner (VRBO) and HomeAway) not approved by the Associate CFO for Corporate Accounting prior to travel is not eligible for gainsharing.

12. For NBU employees, only the first 30 calendar days of extended TDY travel will count as eligible for savings in the program. For NBU employees, extended TDY of more than 30 calendar days where a reduced per diem amount is required is not eligible for gainsharing. For NBU employees, staying with family, friends or associates is not eligible after 30 days when an employee is on extended TDY travel.

13. A centralized repository for all gainsharing records to include Forms 13631-A, IRS Travel Savings, Form 15245, IRS Gainsharing Travel Savings Program Checklist, and other supporting documentation must be established and maintained. Following the GRS, gainsharing award records may be destroyed when 2 years old or 2 years after award is approved or disapproved, whichever is later, but longer retention is authorized if needed for business use such as a litigation hold, agency freezes and potential/impending audits. The GRS 2.2 schedule can be found at: [http://www.archives.gov/records-mgmt/grs/](http://www.archives.gov/records-mgmt/grs/).

14. Copies of approved travel authorizations and supporting documentation for manual vouchers must be maintained for six years in compliance with General Records Schedule (GRS) 1.1, item 010 Financial Transaction Records Related to Procuring Goods and Services, Paying Bills, Collecting Debts, and Accounting, for records retention authorized disposition, but longer retention is authorized if needed for business use such as a litigation hold, agency freezes and potential/impending audits. The GRS 1.1 schedule can be found at: [http://www.archives.gov/records-mgmt/grs/](http://www.archives.gov/records-mgmt/grs/).


**1.32.14.2.1** **(06-18-2024)**

#### Common Carrier Savings

1. An employee who obtains a free airline ticket using frequent traveler benefits earned on either official or personal travel is eligible for a gainsharing travel savings award. An example of this is when an employee flies on a common carrier and accrues frequent traveler benefits earned on official travel purchased with the government credit card or centrally billed account and/or personal travel purchased with their personal credit card. When the employee is required to travel for official business, the employee can use all accrued frequent traveler benefits incurred through personal and/or official travel to redeem for a common carrier ticket directly from the airline for the official travel. The employee can then submit a request for a gainsharing award for 50% of this common carrier savings.

2. Savings on airfare costs are measured by the contract city-pair fare in effect at the time of the flight, plus the applicable Travel Management Center (TMC) fee. If there is no contract city-pair fare, the employee must use the lowest available non-restricted fully refundable coach class fare, plus applicable TMC fee, as the basis for determining travel savings.

3. To determine savings, the employee must compare the city-pair fare with the cost of the actual airfare paid.

4. Acceptable documentation to support savings realized includes any of the following:



1. TMC itinerary showing what the travel would have cost on a common carrier.

2. A screen print from ETS showing the selected flight information for the scheduled flight.

3. The ticketed invoice showing the frequent traveler benefits redeemed and trade-in value of the government airfare.

4. A screen print of the city-pair fare for the contract carrier for both the origin and destination cities of the travel period.


**1.32.14.2.2** **(06-18-2024)**

#### Lodging Savings

1. An employee who incurs lodging expenses at a daily rate that is less than the maximum lodging locality rate may be eligible to receive a gainsharing award for lodging savings. Maximum lodging rates can be found at: [www.gsa.gov/portal/category/21287](http://www.gsa.gov/portal/category/21287).

2. An employee may claim savings that are realized from using frequent traveler benefits to purchase lodging for official travel. All city-to-city travel with lodging expenses, foreign and domestic, are covered under this program. Relocation travel expenses are not eligible for this program.

3. Eligible lodging savings must be the result of:



1. Securing conventional or non-conventional lodging, resulting in zero or a lower than GSA per diem rate for the TDY location.

2. Sharing a room with another IRS traveler, where each traveler saves one half of the single lodging rate every day. Each employee should request a separate lodging receipt. However, if the employees are unable to obtain separate receipts, the employees need to determine the daily rate and divide the total lodging costs by the number of employees and the number of nights to arrive at a daily rate for each employee.

3. Staying with family, friends or associates and incurring no lodging costs. Lodging costs must not be claimed on the travel voucher.


4. For NBU employees, only the first 30 calendar days of extended TDY travel will count as eligible for savings in the program. For NBU employees, extended TDY of more than 30 calendar days where a reduced per diem amount is required is not eligible for gainsharing. For NBU employees, staying with family, friends or associates is not eligible after 30 days when an employee is on extended TDY travel.

5. The employee must charge lodging expenses to a government travel card to be eligible for gainsharing, unless the vendor does not accept the credit card for payment.

6. If the lodging vendor does not accept a government travel card in payment for lodging expenses, the employee may use personal funds. In order to be eligible for a gainsharing award when personal funds are used, an employee must provide a letter from the lodging vendor on company letterhead that clearly indicates the vendor does not accept the government travel card as payment for lodging expenses.

7. Employees should use tax-exempt certificates for lodging taxes, when applicable. Taxes on lodging are not considered in determining lodging savings.


**1.32.14.3** **(06-18-2024)**

### Excess Transportation and Miscellaneous Costs

1. An employee must take into consideration whether any additional transportation or miscellaneous costs will be incurred when seeking lodging savings for gainsharing eligibility.

2. An employee who incurs additional transportation expenses must deduct those expenses from the lodging savings. Examples of excess transportation costs include, but are not limited to:



1. Renting a vehicle for personal convenience at a TDY site to travel to and from a place of free or reduced lodging.

2. Driving a privately-owned vehicle more miles than would normally be traveled to or from the TDY site to obtain free or reduced lodging.

3. Incurring excess taxi, Transportation Network Company (TNC) such as Uber/Lyft, or mileage expenses or other public transportation fares that would not normally be incurred to obtain free or reduced lodging.


3. Examples include:



1. An employee could stay at a hotel near the TDY location and incur no transportation expenses between the hotel and the TDY location. Instead, the employee chooses to stay farther away, at a less expensive hotel and, as a result, incurs extra transportation costs each way. The extra costs may include, but are not limited to, rental car fees, mileage, parking or the cost of public transportation that would not have been incurred if the employee stayed at a hotel near the TDY location. The excess costs of the transportation must be deducted from the amount of the lodging savings.

2. An employee’s TDY location is New Carrollton, Maryland, for four nights. The lodging per diem rate per night is $256, totaling $1,024 for four nights. If the employee stays at a hotel in New Carrollton, the employee will incur no transportation expenses between the hotel and the New Carrollton office building. Instead, the employee chooses to stay farther away in Greenbelt, Maryland, with relatives, and, as a result, incurs daily extra transportation costs of $24 for Uber rides, totaling $72 for the week. The total lodging savings for the trip is $952. The excess $72 of transportation costs must be deducted from the amount of the lodging savings. The employee would be entitled to $476. Total Savings equals $1,024 - $72 = $952 x 50% = $476.

3. An employee’s TDY location is Dallas, Texas, for four nights. The lodging per diem rate per night is $154, totaling $616 for four nights. If the employee stays at a hotel in Dallas, the employee would incur minimal transportation expenses between the hotel and the Dallas office building of $4 daily, totaling $12 for the week. Instead, the employee chooses to fly into DFW instead of DAL, the airport closest to the TDY, to stay with friends, and, as a result, incurs extra transportation costs of $50 daily for Uber rides, totaling $150 for the week. The total lodging savings for the trip is $478. The excess transportation $150 - $12 allowance for 3 days to/from hotel/TDY = $138, and must be deducted from the amount of the lodging savings. The employee would be entitled to $239. Total Savings equals $616 - $138 = $478 x 50% = $239.


**1.32.14.4** **(06-18-2024)**

### Travel Ineligible for Gainsharing

1. The following activities are examples of travel ineligible for the Gainsharing Travel Savings Program:



01. Relocation travel.

02. Travel to an alternate location for personal reasons instead of staying at the TDY location.

03. Lodging savings incurred due to an authorized or voluntary return to the employee’s residence or Post of Duty (POD).

04. Travel paid by another government agency.

05. Travel paid with personal credit card or funds, even if the employee has an approved exemption from the use of the travel card, except as provided in IRM 1.32.14.2.2(5), Lodging Savings.

06. Choosing an airport that has a lower city-pair contract rate or government rate does not qualify for travel savings. The only air travel savings that qualify are from using frequent traveler benefits to purchase a coach class ticket.

07. Departing a TDY early, arriving at a TDY late and/or choosing to forego an authorized rest period in order to save a night of lodging does not constitute lodging savings.

08. Airport parking savings are not eligible for gainsharing.

09. Using an alternate mode of transportation instead of the authorized mode of transportation to the TDY.

10. Lodging that was prepaid, contracted or prearranged (e.g., block of rooms), except if the savings resulted from shared accommodations with another IRS employee.

11. Government FedRooms lodging, unless the accommodations are shared with another IRS employee on travel.

12. Military base housing or military lodging, which are federally funded.

13. Lodging costs incurred on annual leave or personal time used in conjunction with official travel.

14. Domestic lodging that does not meet the requirements of the Hotel and Motel Fire Safety Act of 1990. A list of lodging facilities that meet the requirements can be found at: [Hotel and Motel Fire Safety](https://apps.usfa.fema.gov/hotel/).

15. Non-conventional lodging such as leased or rented houses, apartments, condominiums or home-sharing rentals (i.e., Airbnb, VRBO and HomeAway) not approved by the Associate CFO for Corporate Accounting prior to travel is not eligible for gainsharing.

16. Lodging expenses for staying at your personally owned or co-owned property (e.g., vacation home, secondary home, rental units, timeshare, etc.), recreational vehicle or campers at the TDY location.

17. While performing mission critical travel in the best interest of the government, if it becomes necessary to incur lodging at multiple locations for the same travel dates, travel savings incurred at either TDY location is not eligible for gainsharing.

18. When traveling on an overnight or late-night flight, lodging savings incurred during the flight is ineligible for gainsharing.

19. Conventional lodging reservations not booked in ETS or with the TMC.


**1.32.14.5** **(06-18-2024)**

### Gainsharing Award Process

1. The employee:



1. Accumulates eligible travel savings incurred during a fiscal year and records the savings on one Form 13631-A, IRS Travel Savings.

2. Completes Form 15245, IRS Gainsharing Travel Savings Program Checklist.

3. Signs and dates the forms supporting the qualifying savings.

4. Submits the completed forms with reporting instructions, if applicable, travel vouchers and receipts to the first-level manager.


2. The first-level manager:



1. Reviews the reporting instructions, if applicable, vouchers, receipts, recorded savings on Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist.

2. Signs and dates the Form 13631-A, IRS Travel Savings, as the recommending official.

3. Submits the completed forms with reporting instructions, if applicable, travel vouchers and receipts to the second-level manager.


3. The second-level manager:



1. Reviews the reporting instructions, if applicable, vouchers, receipts, recorded savings on Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist.

2. Approves by signing and dating Form 13631-A, IRS Travel Savings, as the approving official.

3. Forwards the completed forms with reporting instructions, if applicable, travel vouchers and receipts to the business unit contact.


4. Business unit contact:



1. Reviews the reporting instructions and the FedRooms Data File, if applicable, vouchers and receipts, recorded savings on Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist.

2. Forwards Form 13631-A, IRS Travel Savings, and Form 15245, IRS Gainsharing Travel Savings Program Checklist, to Travel Review at [CFO.FM.Travel.Gainsharing@irs.gov](https://www.irs.gov/irm/part1/CFO.FM.Travel.Gainsharing@irs.gov).


5. Travel Review:



1. Reviews and audits the vouchers, receipts, reporting instructions and the FedRooms Data File, if applicable, recorded savings on Form 13631-A, IRS Travel Savings and Form 15245, IRS Gainsharing Travel Savings Program Checklist.

2. If approved, signs and dates the Form 13631-A, IRS Travel Savings, as the Travel Management reviewing official. If disapproved, return the package and provide the reason to the business unit contact and employee.

3. Forwards the documentation to the business unit contact.


6. Business unit contact:



1. Requests misconduct and tax compliance screening from HCO for approved claims.


7. HCO:



1. Completes misconduct and tax compliance screening.

2. Forwards result to the business unit point of contact.


8. The business unit inputs the Personnel Action Request (PAR) into HR Connect. The employee's business unit retains the following original or copies:



1. Form 13631-A, IRS Travel Savings

2. Form 15245, IRS Gainsharing Travel Savings Program Checklist

3. Reporting instructions, if applicable, travel vouchers and supporting documentation

4. Form 9127, Recommendation for Recognition

5. HR Connect PAR action

6. Manual authorizations and vouchers, if applicable


**1.32.14.6** **(07-01-2021)**

### Taxes

1. The IRS withholds appropriate federal, state, and local income taxes, FICA tax and other applicable deductions from the award amount.

2. The employee receives a Standard Form 50, Notification of Personnel Action, indicating the award amount.

3. The award amount will be included in the employee’s Form W-2, Wage and Tax Statement.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-014#addtoany "Show all")

A2A