---
url: "https://www.irs.gov/irm/part1/irm_01-001-024"
title: "1.1.24 Large Business and International Division | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-024#main-content)

- 1.1.24  [Large Business and International Division](https://www.irs.gov/irm/part1/irm_01-001-024#id1)
  - 1.1.24.1  [Large Business and International Division](https://www.irs.gov/irm/part1/irm_01-001-024#id2)
    - 1.1.24.1.1  [Guiding Principles](https://www.irs.gov/irm/part1/irm_01-001-024#id4)
    - 1.1.24.1.2  [LB&I Division Commissioner](https://www.irs.gov/irm/part1/irm_01-001-024#id5)
    - 1.1.24.1.3  [LB&I Deputy Division Commissioner](https://www.irs.gov/irm/part1/irm_01-001-024#id6)
  - 1.1.24.2  [LB&I Headquarters](https://www.irs.gov/irm/part1/irm_01-001-024#id7)
    - 1.1.24.2.1  [Assistant Deputy Commissioner Compliance Integration](https://www.irs.gov/irm/part1/irm_01-001-024#id8)
      - 1.1.24.2.1.1  [Strategy, Policy and Governance](https://www.irs.gov/irm/part1/irm_01-001-024#id9)
        - 1.1.24.2.1.1.1  [SPG Support of the Compliance Strategy Council](https://www.irs.gov/irm/part1/irm_01-001-024#id11)
        - 1.1.24.2.1.1.2  [LB&I Fraud Program](https://www.irs.gov/irm/part1/irm_01-001-024#id12)
        - 1.1.24.2.1.1.3  [IMD Program Coordination](https://www.irs.gov/irm/part1/irm_01-001-024#id13)
        - 1.1.24.2.1.1.4  [Compliance Assurance Process (CAP)](https://www.irs.gov/irm/part1/irm_01-001-024#id14)
        - 1.1.24.2.1.1.5  [Issue Resolution Tools](https://www.irs.gov/irm/part1/irm_01-001-024#id15)
      - 1.1.24.2.1.2  [Data Solutions](https://www.irs.gov/irm/part1/irm_01-001-024#id16)
        - 1.1.24.2.1.2.1  [Product Management](https://www.irs.gov/irm/part1/irm_01-001-024#id18)
        - 1.1.24.2.1.2.2  [Data Science](https://www.irs.gov/irm/part1/irm_01-001-024#id19)
        - 1.1.24.2.1.2.3  [Data Management and Services](https://www.irs.gov/irm/part1/irm_01-001-024#id20)
      - 1.1.24.2.1.3  [Compliance Planning and Analytics](https://www.irs.gov/irm/part1/irm_01-001-024#id21)
        - 1.1.24.2.1.3.1  [Planning, Reporting and Monitoring](https://www.irs.gov/irm/part1/irm_01-001-024#id23)
        - 1.1.24.2.1.3.2  [Workload Development and Delivery](https://www.irs.gov/irm/part1/irm_01-001-024#id24)
        - 1.1.24.2.1.3.3  [Data and Systems Management](https://www.irs.gov/irm/part1/irm_01-001-024#id25)
    - 1.1.24.2.2  [Program and Business Solutions](https://www.irs.gov/irm/part1/irm_01-001-024#id26)
      - 1.1.24.2.2.1  [Resource Solutions](https://www.irs.gov/irm/part1/irm_01-001-024#id27)
        - 1.1.24.2.2.1.1  [Communications](https://www.irs.gov/irm/part1/irm_01-001-024#id29)
        - 1.1.24.2.2.1.2  [Human Capital Management](https://www.irs.gov/irm/part1/irm_01-001-024#id30)
        - 1.1.24.2.2.1.3  [Finance](https://www.irs.gov/irm/part1/irm_01-001-024#id31)
        - 1.1.24.2.2.1.4  [Learning and Education](https://www.irs.gov/irm/part1/irm_01-001-024#id32)
      - 1.1.24.2.2.2  [Technology and Program Solutions](https://www.irs.gov/irm/part1/irm_01-001-024#id33)
        - 1.1.24.2.2.2.1  [Business Systems Planning](https://www.irs.gov/irm/part1/irm_01-001-024#id35)
        - 1.1.24.2.2.2.2  [Case Management System Solutions](https://www.irs.gov/irm/part1/irm_01-001-024#id36)
        - 1.1.24.2.2.2.3  [Collaborative Technology Support](https://www.irs.gov/irm/part1/irm_01-001-024#id37)
        - 1.1.24.2.2.2.4  [Program Planning, Coordination and Analysis](https://www.irs.gov/irm/part1/irm_01-001-024#id38)
        - 1.1.24.2.2.2.5  [Quality Review and Analysis (QRA)](https://www.irs.gov/irm/part1/irm_01-001-024#id39)
      - 1.1.24.2.2.3  [Equal Employment](https://www.irs.gov/irm/part1/irm_01-001-024#id40)
  - 1.1.24.3  [Practice Areas](https://www.irs.gov/irm/part1/irm_01-001-024#id41)
    - 1.1.24.3.1  [Pass-Through Entities](https://www.irs.gov/irm/part1/irm_01-001-024#id42)
      - 1.1.24.3.1.1  [Global High Wealth](https://www.irs.gov/irm/part1/irm_01-001-024#id44)
      - 1.1.24.3.1.2  [Pass-Through Examinations](https://www.irs.gov/irm/part1/irm_01-001-024#id45)
    - 1.1.24.3.2  [Enterprise Activities](https://www.irs.gov/irm/part1/irm_01-001-024#id46)
      - 1.1.24.3.2.1  [Practice Networks](https://www.irs.gov/irm/part1/irm_01-001-024#id48)
      - 1.1.24.3.2.2  [Financial Products](https://www.irs.gov/irm/part1/irm_01-001-024#id49)
      - 1.1.24.3.2.3  [Affordable Care Act](https://www.irs.gov/irm/part1/irm_01-001-024#id50)
    - 1.1.24.3.3  [Cross-Border Activities](https://www.irs.gov/irm/part1/irm_01-001-024#id51)
      - 1.1.24.3.3.1  [Field Operations](https://www.irs.gov/irm/part1/irm_01-001-024#id53)
      - 1.1.24.3.3.2  [Practice Networks](https://www.irs.gov/irm/part1/irm_01-001-024#id54)
      - 1.1.24.3.3.3  [CBA Headquarters](https://www.irs.gov/irm/part1/irm_01-001-024#id55)
    - 1.1.24.3.4  [Withholding, Exchange and International Individual Compliance](https://www.irs.gov/irm/part1/irm_01-001-024#id56)
      - 1.1.24.3.4.1  [Foreign Payments Practice and Automatic Exchange of Information](https://www.irs.gov/irm/part1/irm_01-001-024#id57)
        - 1.1.24.3.4.1.1  [Pre-Filing](https://www.irs.gov/irm/part1/irm_01-001-024#id59)
        - 1.1.24.3.4.1.2  [Post-Filing/Pre-Acceptance](https://www.irs.gov/irm/part1/irm_01-001-024#id60)
        - 1.1.24.3.4.1.3  [Post-Filing](https://www.irs.gov/irm/part1/irm_01-001-024#id61)
        - 1.1.24.3.4.1.4  [Automatic Exchange of Information (AEOI)](https://www.irs.gov/irm/part1/irm_01-001-024#id62)
      - 1.1.24.3.4.2  [International Individual Compliance](https://www.irs.gov/irm/part1/irm_01-001-024#id63)
      - 1.1.24.3.4.3  [Exchange and Offshore Strategy](https://www.irs.gov/irm/part1/irm_01-001-024#id64)
        - 1.1.24.3.4.3.1  [Exchange of Information](https://www.irs.gov/irm/part1/irm_01-001-024#id66)
        - 1.1.24.3.4.3.2  [Offshore Compliance Initiatives](https://www.irs.gov/irm/part1/irm_01-001-024#id67)
        - 1.1.24.3.4.3.3  [WEIIC Practice Networks (Inbound and Outbound)](https://www.irs.gov/irm/part1/irm_01-001-024#id68)
        - 1.1.24.3.4.3.4  [WEIIC Planning and Special Programs](https://www.irs.gov/irm/part1/irm_01-001-024#id69)
    - 1.1.24.3.5  [Treaty and Transfer Pricing Operations](https://www.irs.gov/irm/part1/irm_01-001-024#id70)
      - 1.1.24.3.5.1  [Advance Pricing and Mutual Agreement Program](https://www.irs.gov/irm/part1/irm_01-001-024#id71)
        - 1.1.24.3.5.1.1  [Treaty Assistance and Interpretation Team](https://www.irs.gov/irm/part1/irm_01-001-024#id72)
          - 1.1.24.3.5.1.1.1  [Treaties Practice Network](https://www.irs.gov/irm/part1/irm_01-001-024#id74)
          - 1.1.24.3.5.1.1.2  [U.S. Territories Program](https://www.irs.gov/irm/part1/irm_01-001-024#id75)
      - 1.1.24.3.5.2  [Transfer Pricing Practice](https://www.irs.gov/irm/part1/irm_01-001-024#id76)
        - 1.1.24.3.5.2.1  [Transfer Pricing Practice Networks](https://www.irs.gov/irm/part1/irm_01-001-024#id77)
          - 1.1.24.3.5.2.1.1  [Transfer Pricing Practice Network (TPPN)](https://www.irs.gov/irm/part1/irm_01-001-024#id79)
          - 1.1.24.3.5.2.1.2  [Transfer Pricing Risk Assessment Team](https://www.irs.gov/irm/part1/irm_01-001-024#id80)
    - 1.1.24.3.6  [Western Compliance](https://www.irs.gov/irm/part1/irm_01-001-024#id81)
      - 1.1.24.3.6.1  [Computer Audit Specialists](https://www.irs.gov/irm/part1/irm_01-001-024#id83)
    - 1.1.24.3.7  [Eastern Compliance](https://www.irs.gov/irm/part1/irm_01-001-024#id84)
      - 1.1.24.3.7.1  [Engineering](https://www.irs.gov/irm/part1/irm_01-001-024#id86)
    - 1.1.24.3.8  [Northeastern Compliance](https://www.irs.gov/irm/part1/irm_01-001-024#id87)
      - 1.1.24.3.8.1  [Tax Computation Specialists](https://www.irs.gov/irm/part1/irm_01-001-024#id89)
      - 1.1.24.3.8.2  [Joint Committee Review](https://www.irs.gov/irm/part1/irm_01-001-024#id90)
    - 1.1.24.3.9  [Practice Area PSPs (Planning and Special Programs)](https://www.irs.gov/irm/part1/irm_01-001-024#id91)
  - 1.1.24.4  [References for LB&I Programs](https://www.irs.gov/irm/part1/irm_01-001-024#id92)
  - Exhibit  1.1.24-1  [Quick Reference Guide for Acronyms](https://www.irs.gov/irm/part1/irm_01-001-024#id93)
  - Exhibit  1.1.24-2  [LB&I Organization Chart](https://www.irs.gov/irm/part1/irm_01-001-024#id94)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 24. Large Business and International Division

* * *

## 1.1.24 Large Business and International Division

#### Manual Transmittal

July 22, 2025

#### Purpose

(1) This transmits revised IRM 1.1.24, Organization and Staffing, Large Business and International Division. This section contains the functional statements and responsibilities of the offices within the Large Business and International Division.

#### Material Changes

(1) IRM 1.1.24.1: added reference to Document 14551, LB&I Organization Chart.

(2) IRM 1.1.24.1.3.3: removed reference to W&I, replaced with Taxpayer Services.

(3) IRM 1.1.24.2.1.1.2: removed subsection describing the Compliance Integration Steering Committee because it was decommissioned as of 7/30/2024.

(4) IRM 1.1.24.3.1: updated description of the Pass-Through Entities Practice Area.

(5) IRM 1.1.24.3.2.3: removed reference to ACA provision 9010, because it has expired.

(6) Exhibit 1.1.24-1: added acronyms BBA, BSP, DMS, LEP.

(7) Exhibit 1.1.24-2: updated organization chart.

(8) This IRM has been updated to comply with January 2025 Executive Orders and OPM guidance.

(9) Editorial changes made throughout the IRM for spelling, grammar, punctuation, links, formatting, titles, and citations.

#### Effect on Other Documents

IRM 1.1.24 dated March 12, 2024 is superseded.

#### Audience

All divisions and functions.

#### Effective Date

(07-22-2025)

#### Related Resources

IRM Exhibit 4.46.1-1, LB&I Examination Process, General Information and Definitions, contains a glossary of commonly used terms in LB&I.

The LB&I intranet site is: LB&I Source

See Document 14551 for a detailed LB&I organization chart.

Ronald H. Hodge II

Assistant Deputy Commissioner Compliance Integration

Large Business and International Division

**1.1.24.1** **(07-22-2025)**

### Large Business and International Division

1. The mission of the Large Business and International (LB&I) division is to provide large business and international taxpayers top quality service by helping them understand and meet their tax responsibilities and by applying the tax law with integrity and fairness to all.

2. LB&I serves C corporations, S corporations and partnerships with assets greater than $10 million. These businesses typically employ large numbers of employees, deal with complicated issues involving tax law and accounting principles, and conduct business in an expanding global environment. LB&I also serves U.S. citizens and residents with offshore activities and non-resident aliens with U.S. activities.

3. LB&I is organized into headquarters support functions and practice areas. Support functions use data analysis, portfolio and program management techniques to support LB&I’s activities. The practice areas provide pre-filing, filing, and post-filing programs and activities for the LB&I taxpayer population. The practice areas also study compliance issues within their areas of expertise and suggest campaigns to be included in the compliance plan.

4. See _Exhibit 1.1.24-1_ for a table of commonly used acronyms.

5. See _Exhibit 1.1.24-2_ for a basic LB&I organization chart. A detailed LB&I organization chart is published as Document 14551, LB&I Organization Chart.


**1.1.24.1.1** **(07-22-2025)**

#### Guiding Principles

1. LB&I is a world-class organization responsive to the needs of our customers in a global environment. We apply the tax laws with integrity and fairness using innovative approaches to customer service and compliance. Our highly skilled and engaged employees work in an environment where each employee can make a maximum contribution to the mission of the team.

2. A core set of guiding principles provides the foundation for LB&I:



1. **Flexible well-trained workforce**– LB&I cultivates an environment of continuous learning to support the workforce with focused training, foundational skillsets, specialized knowledge and dynamic tools.

2. **Optimal selection of work**– LB&I uses data analytics and examiner feedback to select the best work with intended compliance outcomes.

3. **Tailored treatments**– LB&I employs an integrated set of tailored treatment streams to maintain flexibility to address current and emerging issues and to achieve desired compliance outcomes.

4. **Integrated feedback loop**– LB&I continually collects and analyzes data and feedback to focus, plan and execute work, promote innovation, and implement feedback-based improvement.


**1.1.24.1.2** **(03-12-2024)**

#### LB&I Division Commissioner

1. The LB&I division commissioner is responsible for the full range of planning, managing, directing and executing the global activities of LB&I, which are generally described in this section.

2. The LB&I division commissioner:



1. Serves as the chief executive and advisor to the IRS Commissioner and all IRS functions on matters within his/her jurisdiction

2. Has supervisory responsibility for all LB&I personnel and offices located throughout the United States

3. Assigns work, reviews work products and appraises the performance of the executive leadership team

4. Coordinates the work of LB&I with the other functions of the IRS (including other business operating divisions, counsel, and IRS headquarters) on all administrative, policy, and technical matters pertaining to areas within LB&I’s responsibility

5. Serves as LB&I’s principal liaison officer for congressional committees, the Department of the Treasury, the IRS commissioner's office and other departments and agencies of the government

6. Delegates authority as appropriate and permitted


**1.1.24.1.3** **(09-24-2020)**

#### LB&I Deputy Division Commissioner

1. The role of the LB&I deputy division commissioner is to support the LB&I division commissioner in the accomplishment of the LB&I mission in the administration of corporate tax laws, regulations, and procedures in compliance activities.

2. The deputy division commissioner oversees LB&I operations, including those of practice areas and headquarters support functions. The directors of practice area and support functions report directly to the deputy division commissioner.


**1.1.24.2** **(09-30-2021)**

### LB&I Headquarters

1. LB&I headquarters support functions include:



1. Assistant Deputy Commissioner Compliance Integration

2. Program and Business Solutions


**1.1.24.2.1** **(09-24-2020)**

#### Assistant Deputy Commissioner Compliance Integration

1. The assistant deputy commissioner for compliance integration (ADCCI) reports directly to the LB&I deputy commissioner and is responsible for all ADCCI operations. ADCCI operations include Strategy, Policy and Governance; Data Solutions and Compliance Planning and Analytics.


**1.1.24.2.1.1** **(03-12-2024)**

##### Strategy, Policy and Governance

1. The director of Strategy, Policy and Governance (SPG) reports directly to the ADCCI.

2. The mission of SPG is to provide centralized support for the administration and coordination of LB&I’s compliance programs; and ensure the alignment of operations to LB&I’s strategic policies, goals, and objectives to deliver value-driven results.

3. SPG policy teams are responsible for:



   - Applying a consistent approach to policy decisions for LB&I operations to ensure they align with LB&I strategic goals and objectives

   - Defining and documenting LB&I policies and monitoring LB&I operations to assess adherence to LB&I policies and quality standards

   - Ensuring all policy decisions are coordinated/vetted with internal and external stakeholders as appropriate

   - Supporting the LB&I fraud program and issue resolution tools


4. SPG strategy and governance teams are responsible for:



   - Overseeing the Compliance Assurance Process, Large Corporate Compliance, campaign program support, and process improvement initiatives

   - Supporting LB&I governance bodies and practice areas to ensure alignment of resources against the strategy


**1.1.24.2.1.1.1** **(03-12-2024)**

###### SPG Support of the Compliance Strategy Council

1. The Compliance Strategy Council (CSC) serves as the governing body over the identification, selection, assignment and allocation of resources for all compliance and enforcement activities for LB&I taxpayers. They focus on the planning, development and implementation of strategies for LB&I compliance programs. To fulfill its roles and responsibilities in assisting the Council, SPG:



1. Coordinates all CSC meetings

2. Provides the CSC with the necessary tools to manage its inventory of campaigns and submissions

3. Assists the CSC in monitoring the practice area’s execution and post-campaign activities

4. Maintains the CSC website and SharePoint site


**1.1.24.2.1.1.2** **(09-30-2021)**

###### LB&I Fraud Program

1. SPG is responsible for the LB&I Fraud Program, collaborating with Office of Fraud Enforcement (OFE) and Criminal Investigation (CI) to inform and educate LB&I employees about the indicators of fraudulent tax practices by individuals, partnerships, and corporations and about the proper procedures to follow once fraud is identified. The SPG fraud analyst reports on LB&I fraud results and collaborates with LB&I practice area fraud coordinators on fraud initiatives. See the LB&I Fraud Program website at LB&I Fraud Resources and Contacts. and IRM 25.1 for more information.

2. SPG is responsible for the LB&I Corporate Executive Compliance Program, informing and educating LB&I employees about their responsibilities for verifying that key officers and executives have filed their income tax returns simultaneously with the examinations of LB&I corporate tax returns. In addition, LB&I employees are required to inspect and examine key officers and executive returns when warranted. See the LB&I Corporate Executive Compliance website for guidance and IRM Exhibit 4.46.3-6 for more information.


**1.1.24.2.1.1.3** **(09-24-2020)**

###### IMD Program Coordination

1. Any instructions to staff, such as delegation orders, interim guidance, and guidelines directing a course of action will be cleared for publication through an internal management document (IMD) coordinator in ADCCI under processes set forth by the Policy Office. The Policy Office will ensure that all LB&I stakeholders have an opportunity to comment on the guidance and that subject matter experts (SMEs) and appropriate management approve the technical aspects of the guidance.


**1.1.24.2.1.1.4** **(03-12-2024)**

###### Compliance Assurance Process (CAP)

1. SPG oversees the Compliance Assurance Process (CAP). The program improves timeliness and efficiencies for both taxpayers and the IRS through a real-time review process to ensure taxpayer compliance. See IRM 4.51.8, Compliance Assurance Process (CAP), for more information.


**1.1.24.2.1.1.5** **(03-12-2024)**

###### Issue Resolution Tools

1. SPG is responsible for program administration and coordination of several LB&I issue resolution tools. The program coordinators report on program activity, coordinate with LB&I practice areas to ensure sound tax administration, and communicate program guidelines.

2. Issue resolution tools can be used in either the pre-filing or post-filing stages.

3. Pre-filing resolution tools under the responsibility of SPG include:



1. The pre-filing agreement (PFA) program, see IRM 4.30.1.

2. The industry issue resolution(IIR) program, see IRM 7.40.1.

3. Determination letters, see the first revenue procedure of each calendar year (e.g., Rev. Proc. 2023-1)


4. Post-filing resolution tools under the responsibility of SPG include various programs co-administered with Appeals. These are:



1. Early Referral to Appeals, see IRM 4.46.5.4.2.5.

2. Fast Track Settlement, see IRM 4.51.4.

3. Rapid Appeals Process, see IRM 4.46.5.4.2.7.


**1.1.24.2.1.2** **(03-12-2024)**

##### Data Solutions

1. The director of Data Solutions (DS) reports directly to the ADCCI. DS supports LB&I’s strategic goals by improving the accessibility, reliability, usability, and measurability of data to facilitate data-informed business decisions in all of the division’s compliance and strategic support programs.

2. To accomplish its mission, DS:



1. Develops and uses technological products and tools

2. Applies advanced analytical techniques

3. Manages projects

4. Provides data visualizations

5. Develops statistical models

6. Promotes data security

7. Uses other skills to support LB&I’s existing and future compliance and strategic support programs


3. Data Solutions includes:



   - Product Management

   - Data Science

   - Data Management and Services


**1.1.24.2.1.2.1** **(03-12-2024)**

###### Product Management

1. The Product Management Program Area supports LB&I compliance programs and the IRS Strategic Operating Plan through the delivery of tools and data products that improve operational outcomes, drive process automation, and enhance the reporting of business results. Product Management provides project management services, promotes data accessibility, and ensures adherence to security standards.

2. Product Management has three teams:



1. Compliance Data Solutions, focused on support of International compliance systems and related technologies.

2. Operations and Release Management, focused on operational analytics, data product development, operations, and security support.

3. Project and Portal Management, focused on business process automation, project management services, and development of online portals and tools.


**1.1.24.2.1.2.2** **(03-12-2024)**

###### Data Science

1. Data Science provides support for LB&I compliance programs through implementation of a data science framework that encompasses identifying, defining problems; discovering, ingesting, wrangling data; applying statistical modeling and analysis to develop data products and tools. Supporting development of filters and models for workload selection based upon the needs of LB&I's compliance programs.

2. Four teams operate in Data Science focusing on:



1. Portfolio management implementation and support for the IRS's digitalization initiative.

2. Modeling, workload delivery and other program support for WEIIC.

3. Methods such as machine learning, artificial intelligence, and knowledge of statistical and mathematical operations to create program applications to extract, compile, manipulate, and analyze data for efficient use by IRS stakeholders.

4. LB&I model development and segmentation at the request of practice areas and management.


**1.1.24.2.1.2.3** **(03-12-2024)**

###### Data Management and Services

1. Data Management and Services (DMS) Program Area works closely with LB&I practice areas providing data analytics and visualizations, innovative tools, and project assistance to its customers. The DMS team draws upon its vast skillset of previous revenue agents, data scientists, and IT professionals to provide practice area specific data solutions and tools to aid in the compliance and exam function. DMS deliverables vary from answering questions related to taxpayer attributes across a defined population, to providing data support and analytics to practice areas, to creating visualization setting related to databases in compliance and exam functions, to supporting and maintaining existing tools (e.g., Auditor’s Workbench), to developing new tools (e.g., Corporate Graph Tool, a tool that provides examiners an interactive organizational chart for their assigned taxpayer under exam).

2. Three teams operate collaboratively within DMS:



1. Informative Analytics

2. Data Analytics and Services

3. Innovative Analysis and Automation


**1.1.24.2.1.3** **(09-24-2020)**

##### Compliance Planning and Analytics

1. The director for Compliance Planning and Analytics (CP&A) reports directly to the ADCCI. CP&A is responsible for:



1. Conducting all workload planning and selection for LB&I’s examination functions

2. Collaborating with DS, SPG and the practice areas to continually ensure the highest compliance risk areas are identified and assigned to the field for compliance consideration

3. Performing relevant research and leveraging technology and data analytics to quickly identify and assign returns with the highest risk of non-compliance

4. Managing the systems and tools that deliver workload and provide related field support throughout the case life cycle

5. Delivering returns, data and related information to the field in a timely and efficient manner

6. Providing support to the field to enhance planning, risk assessment and inventory management


2. CP&A includes:



   - Planning, Reporting and Monitoring

   - Workload Development and Delivery

   - Data and Systems Management


**1.1.24.2.1.3.1** **(09-24-2020)**

###### Planning, Reporting and Monitoring

1. Planning, Reporting and Monitoring develops and uses data, tools, techniques, research, studies and models to support LB&I field and headquarters functions in understanding the unique and evolving make-up of the LB&I taxpayer population. This office also prepares and monitors business compliance plans used by LB&I and its practice areas.

2. Planning, Reporting and Monitoring supports campaign development, prioritization, monitoring and feedback. These teams are responsible for:



   - Creating research studies

   - Reporting results of LB&I operations

   - Preparing and monitoring business compliance plans used by LB&I and its practice areas


**1.1.24.2.1.3.2** **(03-12-2024)**

###### Workload Development and Delivery

1. The Workload Development and Delivery (WD&D) program teams assist the practice areas in analyzing and scoping the identified compliance risks associated with a campaign proposal. These program teams are comprised of tax technical employees, data scientists, and specialists who work closely with the practice areas to develop campaigns. WD&D is also responsible for developing filters and models used for workload selection, campaign monitoring and Content Management Collaboration support. There are five teams comprising WD&D, namely:



1. Workload Administration

2. Workload Development Team 1

3. Workload Development Team 2

4. Office of Tax Shelter Analysis

5. Whistleblower Team


2. The Workload Administration Team is responsible for workload selection through the utilization of data analytics, including but not limited to filters, models, etc. The team is heavily involved in all phases of campaign development and works with LB&I Practice Areas as well as other Business Units to ensure that all filters and models comply with applicable laws, the Internal Revenue Manual and other published guidance. The team also provides data for research requests. Additionally, the team is also responsible for building and maintaining AIMS files for all LB&I returns.

3. Workload Development Team 1 is responsible for testing filters. The team provides recommendations and feedback to the Practice Areas for improving the filter formula in order to obtain more accurate results. The team is also responsible for classifying returns for compliance programs.

4. Workload Development Team 2 is responsible for classification of LB&I claims and correspondence in the Correspondence Imaging Inventory (CII). The team is also responsible for reviewing all LB&I Information Referrals except for Whistleblower Claims. Moreover, the team is responsible for resolving technical requests including Operation Assistance Requests (OAR) from the Taxpayer Assistance Services (TAS). Additionally, the team acts as liaison between Campus Operations and LB&I Field Exam to assist in ensuring LB&I taxpayer accounts are worked properly. Examples of issues worked: missing amended return, missing refunds, erroneous 105C disallowance letters or 916C no consider letters, amended return with balances due, statute issues, superseded returns not processed, posting errors, freeze code analysis, IDRS transcript analysis and CIS Analysis to evaluate various transaction and letters sent to taxpayers to determine correct course of action.

5. The Office of Tax Shelter Analysis (OTSA) Team is responsible for data collection and analysis of various disclosure forms such as Forms 8918, 8886, 3115, 8023, 8275 and 8275R and Schedule UTP, among others. The team also coordinates with Chief Counsel, LB&I Practice Areas and other Business Units with respect to emerging issue identification.

6. The Whistleblower Team serves as the liaison between the IRS Whistleblower Office and LB&I field exam teams working whistleblower cases. The team facilitates review of claims, coordinates field assignments, assists the field with claim processing and closures, and provides training on whistleblower claim procedures.


**1.1.24.2.1.3.3** **(07-22-2025)**

###### Data and Systems Management

1. The mission of the Data and System Management (D&SM) group is to transform data into useful information and develop tools to support planning, risk analysis, decision- making and performance improvement for LB&I. D&SM delivers workload and provides related field support throughout the case lifecycle. This includes:



   - Obtaining, managing and providing quality data for LB&I

   - Timely and efficiently delivering returns and related information to the field

   - Providing field support to enhance planning

   - Providing risk assessment and inventory management

   - Identifying ways to better leverage and more effectively use technology in the delivery of programs and services

   - Obtaining and using feedback from customers to improve processes and systems


2. D&SM services a wide variety of customers including the IRS research community, LB&I field employees, LB&I executives, SB/SE division, Research-Applied Analytics and Statistics (RAAS) and Taxpayer Services division.

3. To accomplish the mission and serve these customers, this group acquires, validates and maintains tax data from LB&I returns and schedules LB&I uses for planning, risk analysis, return selection and issue identification processes. D&SM provides database and systems management for multiple LB&I inventory management systems.


**1.1.24.2.2** **(07-22-2025)**

#### Program and Business Solutions

1. The director of Program and Business Solutions (PBS) reports directly to the LB&I deputy commissioner and is responsible for all PBS operations. PBS is a support function and consists of:



   - Resource Solutions

   - Technology and Program Solutions

   - Equal Employment


2. The mission of PBS is to support LB&I in the delivery and accomplishment of its mission, goals and priorities by providing quality, timely and effective services. PBS oversees the finance, human resource, communication, learning and education, information technology needs, compliance program support, case management systems, SharePoint and collaboration technology, examination quality review and enterprise-wide initiatives and programs for LB&I. PBS is responsible for the development, implementation and evaluation of policies, programs and services that meet LB&I's unique strategic needs. Its functions include budget formulation and execution, workforce forecasting, recruitment planning and identification, resolution of division-wide labor management issues, planning of organizational change efforts, training development and delivery, succession planning, as well as internal and external communications. PBS is also responsible for LB&I’s collaboration with IT to develop strategies, integrate technology and enhance business processes to improve LB&I's ability to promote and enforce compliance with federal tax laws. PBS partners with other business operating divisions to deliver excellent customer service and products.


**1.1.24.2.2.1** **(09-30-2021)**

##### Resource Solutions

1. Resource Solutions (RS) partners with the Practice Areas to deliver quality communications, human resource, training, finance, and real estate programs, products, and services to support effective tax administration.

2. The RS organization is comprised of the director’s office and four subordinate organizations:



   - Communications

   - Human Capital Management

   - Finance

   - Learning and Education


**1.1.24.2.2.1.1** **(09-30-2021)**

###### Communications

1. Communications collaborates with each practice area to plan and produce written communications, presentations, multimedia, and more. They track external speaking engagements, facilitate virtual events, manage the Getting It Right Together (GIRT) employee feedback tool, and coordinate visits from and provide official responses to foreign tax administrations.

2. Within Communications, the Web User Experience (UX) team manages content on the LB&I intranet and maintains LB&I-owned content on IRS.gov, while adhering to agency web standards. They also provide guidance on digital communications and web-centered technologies to improve upon the user experience.


**1.1.24.2.2.1.2** **(09-30-2021)**

###### Human Capital Management

1. Human Capital Management (HCM) has three offices which oversee the development, implementation, and evaluation of human capital policies and programs. The offices plan and implement all hiring and staffing needs such as initiating personnel actions. HCM oversees position management/classification, performance management, awards, and staffing programs (i.e. telework, etc.). They also manage workforce planning and HR analytics to create solutions developed in partnership with stakeholders to resolve workforce concerns. HCM represents LB&I’s interests and serves as the liaison with the Human Capital Office.


**1.1.24.2.2.1.3** **(09-30-2021)**

###### Finance

1. Finance has two sections which provide budget formulation, plan development, overall management and execution of the LB&I Financial Plan including tracking resource usage. Finance acts as the liaison between the division and IRS CFO and represents LB&I’s interests in the Division Finance Officers and Planning, Budgeting and Advisory Committee meetings. Finance also oversees the international travel process for the IRS.


**1.1.24.2.2.1.4** **(09-30-2021)**

###### Learning and Education

1. Learning and Education (L&E) supports Resource Solutions and LB&I by:



   - Analyzing and assessing LB&I training needs and develop and manage the training plan and budget.

   - Designing and developing training products.

   - Developing and managing the annual training plan and budget.

   - Implementing training solutions by working with HCO, Centralized Delivery Service and by managing the Treasury Directive 12-70 process.

   - Working with LB&I Practice Areas and other internal and external stakeholders, to successfully develop and deliver training curriculum.

   - Evaluating training effectiveness in terms of contributions to mission accomplishment.


2. The L&E organization is comprised of the director’s office and five subordinate functions:



   - Customer Support Training (CST)

   - Leadership, Workforce Development and Technology (LWDT)

   - Outservice Training & Support (OTS)

   - Specialty Training, Projects & Analysis (STPA)

   - Technical Training & CPA/CPE (TTCC)


**1.1.24.2.2.2** **(09-30-2021)**

##### Technology and Program Solutions

1. TPS provides leadership and support for LB&I initiatives and programs, collaborates with partners across the enterprise and is committed to delivering customer service and products with excellence.

2. TPS consists of the following program areas:



   - Business Systems Planning

   - Case Management System Solutions

   - Collaborative Technology Support

   - Program Planning, Coordination and Analysis

   - Quality Review and Analysis


**1.1.24.2.2.2.1** **(09-30-2021)**

###### Business Systems Planning

1. Business Systems Planning (BSP) provides customer-focused solutions and support to meet the technology and compliance information management needs of LB&I. BSP organization consists of three teams: Technology Integration, Strategic & Project Planning and Compliance Operations Support. These teams are collectively responsible for:



   - Supporting LB&I by being the LB&I liaison with Information Technology (IT) for LB&I technology needs and improvements

   - Identifying, planning and delivering business improvement opportunities and technology initiatives

   - Providing technical, administrative and analytical services for various technology components managed by LB&I, IT and other business operating divisions

   - Providing project management assistance to LB&I's practice areas with existing and new projects, such as the Bipartisan Budget Act of 2015, Enterprise Case Management, LB&I Workload Identification System, Content Management and Collaboration, Case Built Files, and Selection and Workload Classification

   - Providing workload coordination between field exam and campus to enhance taxpayer compliance and providing case closure support to Centralized Case Processing

   - Serving as LB&I's operations liaison team by supporting a wide range of projects that further LB&I's primary goal of tax administration, including: Modernized E-file, AIMS/ERCS, LB&I Image Network Help Desk, Integrated Data Retrieval System security, Summary Examination Time Transmission System


**1.1.24.2.2.2.2** **(09-24-2020)**

###### Case Management System Solutions

1. Case Management System Solutions (CMSS) supports LB&I’s responsibility to provide its customers operating in a global environment with innovative approaches to customer service and compliance. CMSS supports LB&I compliance operations by managing the Issue Management System (IMS) and Issue-Based Management Information System (IBMIS) which are used to meet LB&I’s overall need for comprehensive compliance management and reporting by promoting more effective customer service. IMS and IBMIS provide inclusive data on compliance features including case, entity, employee and issue development.


**1.1.24.2.2.2.3** **(09-24-2020)**

###### Collaborative Technology Support

1. Collaborative Technology Support (CTS) provides support for SharePoint, which is the primary platform across the LB&I organization for collaboration, knowledge management, business performance reporting and work process management. CTS is responsible for oversight of SharePoint governance and procedures for LB&I. It develops standards, streamlines processes and provides training and resources to SharePoint users.

2. CTS engages with LB&I and other federal agencies to continuously contribute to the development of standards on SharePoint governance. CTS provides a forum to share and exchange information on best practices for developing and managing SharePoint sites.


**1.1.24.2.2.2.4** **(09-24-2020)**

###### Program Planning, Coordination and Analysis

1. Program Planning, Coordination and Analysis (PPCA) provides business reporting, audit/compliance management, project management and support services to a broad range of LB&I customers and stakeholders. The PPCA organization consists of three teams: Program Planning and Reporting, Audit & Legislative Liaison and Knowledge Management. These teams are collectively responsible for:



   - Coordinating programs that either provide information directly from the LB&I commissioner to higher levels of the IRS or provide LB&I-level information to be included with other division-level information in consolidated Servicewide reports

   - Supporting facets of LB&I technical operations, including IT budgeting and security, business continuity, internal and external surveys, and employee engagement

   - Administering programs and activities that address LB&I’s obligations to oversight agencies, congressional bodies, the IRS and the taxpaying public which include serving as the LB&I liaison or coordinator for TIGTA and General Accounting Office (GAO) audits and resulting planned corrected actions; implementation of new legislation utilizing the Legislative Analysis, Tracking and Implementation Service; requests under the Freedom of Information Act; congressional inquiries; Questions For the Record; Taxpayer Advocate Service’s operational assistance requests; litigation holds/electronic document requests; discretionary changes to tax forms and publications; and the IRS annual assurance process

   - Serving as LB&I’s primary liaison for IRS Knowledge Management activities, including coordinating and assisting practice areas with the build-out of knowledge bases in the IRS Virtual Library, promoting consistency in updating and maintaining site content and facilitating cross-BOD collaborations


**1.1.24.2.2.2.5** **(09-24-2020)**

###### Quality Review and Analysis (QRA)

1. Quality Review and Analysis (QRA) provides LB&I customers with an evaluation of case quality, identifies best practices and makes recommendations for quality improvements. QRA provides quality data and promotes consistency in applying quality standards throughout LB&I examinations by evaluating a statistical sample of large business return and International Individual Compliance (IIC) cases for compliance with the audit and documentation requirements defined in the IRM.

2. QRA is responsible for reporting overall quality score results from its case reviews using a Document Collection Instrument to reflect the adherence to the auditing standards. The parameters of these reviews change as the workload demands of LB&I become more diversified.


**1.1.24.2.2.3** **(07-22-2025)**

##### Equal Employment

1. Equal Employment is a neutral office/program designed to enforce discrimination laws and promote equal opportunities for all employees.


**1.1.24.3** **(03-12-2024)**

### Practice Areas

1. LB&I is organized into eight practice areas. Five of the practice areas are issue-based:



   - Pass-Through Entities

   - Enterprise Activities

   - Cross-Border Activities

   - Withholding, Exchange and International Individual Compliance

   - Treaty and Transfer Pricing Operations


The other three practice areas are geographically-based:



   - Western Compliance

   - Eastern Compliance

   - Northeastern Compliance


2. The practice areas share a primary focus of studying compliance issues and supporting various compliance programs (See IRM 4.1.21.3.1) under the Portfolio Management strategy.

3. The geographic practice areas and Enterprise Activities share responsibility for industry practice networks. See IRM 4.30.4, LB&I Industry Program, for more information.


**1.1.24.3.1** **(07-22-2025)**

#### Pass-Through Entities

1. The director of Pass-Through Entities Practice Area (PTE PA) reports directly to the LB&I deputy commissioner and is responsible for all PTE operations. PTE PA has responsibility for pass-through primary return examination starts, regardless of entity size, and is responsible for related Servicewide strategy for partnerships, including large partnership compliance (LPC), S corporations, trusts, Global High Wealth (GHW), and the High-Income High-Wealth (HIHW) initiative. The PTE PA also provides campus support for post-field examination case processing for the centralized partnership audit regime under the Bipartisan Budget Act of 2015 (BBA), investor level statute control and TEFRA.


**1.1.24.3.1.1** **(09-24-2020)**

##### Global High Wealth

1. Global High Wealth (GHW) focuses compliance expertise on high wealth individuals and the enterprises they control. High wealth individuals frequently operate complex enterprises consisting of multiple, interrelated businesses and flow-through entities and often have international components. The job of GHW is to take a unified look at the entire web of business entities controlled by a high wealth individual to assess the risk such arrangements pose to tax compliance and the integrity of our tax system.


**1.1.24.3.1.2** **(03-12-2024)**

##### Pass-Through Examinations

1. Pass-Through Examinations focuses compliance expertise on large, complex pass-through entities such as S corporations, partnerships and trusts. The job of a pass-through examiner is to identify issues and arrangements that pose a risk to tax compliance. Examiners will address issues on these flow-through entities by looking at the full enterprise through multi-tiered structures related to the entity under examination.


**1.1.24.3.2** **(09-24-2020)**

#### Enterprise Activities

1. The director of the Enterprise Activities Practice Area reports directly to the LB&I deputy commissioner and is responsible for all Enterprise Activities operations. The Enterprise Activities Practice Area includes three distinct program areas:



1. **Practice Networks (PN)** (formerly Issue Practice Groups) are designed to increase collaboration, expand technical expertise and transfer skills within LB&I and build content to assist LB&I personnel in developing the best and most current technical positions for the U.S. government. Each of the PNs covers various code sections.

2. **Financial Products (FP)** has nationwide responsibility for personnel who specialize in the taxation of financial instruments and financial transactions, including actuaries who have a nationwide responsibility for actuarial issues.

3. **Affordable Care Act (ACA)** has responsibility for implementing some of the ACA legislative provisions and collaborating with IRS-wide functions to develop and implement processes and procedures to administer ACA provisions.


**1.1.24.3.2.1** **(09-24-2020)**

##### Practice Networks

1. The thirteen PNs include:



   - Life Insurance

   - Non-Life Insurance

   - Regulated Investment Companies (RICs), Real Estate Investment Trusts (REITs), Real Estate Mortgage Investment Conduits (REMICs), and Banking

   - Financial Instruments

   - Deductible and Capital Expenditures (DCE)

   - Methods of Accounting and Timing (MAT) (previously called Change in Accounting Method (CAM))

   - Inventory and 263A

   - Compensation and Benefits

   - Corporate Distributions and Adjustments

   - Corporate Income and Losses

   - General Business Credits

   - Energy and Investment Tax Credits

   - Penalties


**1.1.24.3.2.2** **(09-24-2020)**

##### Financial Products

1. Financial Products (FP) specialize in the taxation of financial instruments and financial transactions. FP agents participate as a team member in the examination process, by examining the financial product transactions that a taxpayer may have undertaken. FP agents provide specialized financial product expertise to all business operating divisions within the IRS. FP agents provide services on a consultation or formal referral basis.

2. FP agents examine FP issues that may be domestic or foreign in scope and may relate to any type of entity. Examples of FP issues include the following:



   - Stock

   - Debt, including bonds, notes, mortgages and other debt

   - Asset backed securities

   - Securitization

   - REMICs and REITs

   - Hybrid debt

   - Financial products and transactions in foreign currency

   - Commodities

   - Forward and futures contracts

   - Options

   - Notional principal contracts/swaps

   - Short sales, wash sales and constructive sales

   - IRC 475 Mark to Market

   - Hedging, speculating, trading transactions

   - Structured financial transactions

   - The amount, timing, character and/or source of debt and equity transactions


**1.1.24.3.2.3** **(07-22-2025)**

##### Affordable Care Act

1. The Affordable Care Act (ACA) team in the Enterprise Activities Practice Area is responsible for analyzing specific provisions of the ACA and collaborating with other IRS functions to develop and implement processes and procedures to administer these provisions. LB&I is responsible for implementation of the following provisions:



1. ACA Provision 9008 - Annual Fee on Branded Prescription Pharmaceutical Manufacturers and Importers (Branded Prescription Drug Fee or BPD Fee), imposes an annual fee on manufacturers and importers of BPDs with gross sales to specified government programs exceeding $5 million.

2. ACA Provision 9014 (IRC 162) - Limitation on Excessive Remuneration paid by Certain Health Insurance Providers, disallows deductions for executive remunerations over $500,000 paid by certain health insurance providers.

3. ACA Provision 9016 - (IRC 833) Modification of IRC 833 - Treatment of Certain Health Organizations, provides that IRC 833 applies only when the percentage of total premiums expended on reimbursement for clinical services and for activities that improve health care quality provided to enrollees under its policies during such taxable year (as reported under section 2718 of the Public Health Services Act, 42 USCS §300gg-18) is not less than 85%.

4. ACA Provision 9012 - Retiree Drug Subsidy - Modification of IRC 139A to eliminate the deduction for expenses allocable to the Medicare Part D subsidy. It applies to taxable years beginning after December 31, 2012.


Additional information regarding the ACA tax provisions can be found at: [Affordable Care Act Tax Provisions.](https://www.irs.gov/affordable-care-act/affordable-care-act-tax-provisions).



**1.1.24.3.3** **(09-24-2020)**

#### Cross-Border Activities

1. The director of the Cross-Border Activities (CBA) Practice Area reports directly to the LB&I deputy commissioner and is responsible for all CBA operations. CBA is responsible for administering many of the international tax provisions of the Internal Revenue Code which address cross border business transactions, including helping taxpayers understand their obligations and ensuring compliance with the law through enforcement. CBA is responsible for developing and implementing the technical, policy and procedural guidance (in collaboration with relevant LB&I stakeholders) on international issues impacting business taxpayers. Responsibilities include:



1. Conducting examinations of international transactions and issues impacting business taxpayers

2. Providing technical, policy and procedural guidance (in collaboration with relevant LB&I stakeholders) related to international business transactions

3. Collaborating, networking and sharing knowledge related to Business Inbound and Business Outbound issues

4. Administering the cross border international tax provisions of the Tax Cuts & Jobs Act of 2017


2. This office consists of field operations, practice networks, and headquarters.


**1.1.24.3.3.1** **(09-24-2020)**

##### Field Operations

1. The CBA field operations is comprised of groups of revenue agents aligned by territories to work international issues. Field operations responsibilities include:



1. Applying international issue-specific expertise in administering tax compliance for multinational entities

2. Identifying and elevating emerging issues that may require development of new guidance for the field

3. Collaborating with other PAs to foster the transfer of international knowledge across LB&I


**1.1.24.3.3.2** **(03-12-2024)**

##### Practice Networks

1. CBA field members are encouraged to participate in one or more PNs. The PNs are communities of employees seeking to network and share knowledge about international compliance. The PNs also develop training and curate information and resources for CBA international tax technical issues.

2. The CBA PNs provide technical assistance, training and information on various international tax issues in the following areas:



01. Foreign Derived Intangible Income

02. CFC Income

03. Foreign Tax Credit (Business)

04. Repatriation (Outbound)

05. Jurisdiction to Tax (includes Base Erosion Anti-Abuse Tax)

06. Inbound Financing

07. Information Gathering

08. Foreign Currency

09. Organization and Restructuring

10. Non-recognition provisions of IRC 367

11. Dual consolidated losses

12. Gain deferral method and IRC 721(c)


**1.1.24.3.3.3** **(09-24-2020)**

##### CBA Headquarters

1. CBA Headquarters includes senior advisors, an executive assistant and senior program analysts/specialists who carry out various responsibilities to support CBA field operations and practice networks and collaborate across LB&I to support broader LB&I initiatives.


**1.1.24.3.4** **(09-30-2021)**

#### Withholding, Exchange and International Individual Compliance

1. The director of Withholding, Exchange and International Individual Compliance (WEIIC) Practice Area reports directly to the LB&I deputy commissioner and is responsible for all WEIIC operations. WEIIC is responsible for the delivery of complete tax administration services to the following taxpayers:



   - U.S. citizens living and/or working abroad or in a U.S. Possession

   - U.S. citizens or resident aliens who hold income producing assets in a foreign country or claim the foreign earned income exclusion or foreign tax credit

   - Foreign persons who have a U.S. filing requirement

   - Withholding agents who have responsibility to report and withhold under chapters 3 and 4

   - Non-resident aliens or foreign corporations with claims for refunds or credits under chapters 3 or 4


2. The WEIIC director oversees the following compliance areas:



1. Foreign Payments Practice and Automatic Exchange of Information

2. International Individual Compliance Field Operations

3. Exchange and Offshore Strategy Field Operations


### Note:

Additional information on WEIIC may be found in IRM 4.63.1, Overview of the WEIIC Practice Area and IRM 4.63.2, LB&I WEIIC Practice Network Knowledge Management.

**1.1.24.3.4.1** **(09-24-2020)**

##### Foreign Payments Practice and Automatic Exchange of Information

1. The Foreign Payments Practice (FPP) and Automatic Exchange of Information (AEOI) provides oversight of chapter 3 and chapter 4 withholding tax matters with an emphasis on Servicewide coordination of technical issues, compliance, processing, and other information relating to nonresident aliens and foreign corporations. The FPP focuses resources through coordinated development of informational and educational material, improved forms and publications, processing capabilities and compliance strategies.


**1.1.24.3.4.1.1** **(09-24-2020)**

###### Pre-Filing

1. Pre-Filing is responsible for FATCA compliance, financial intermediary implementation and centralized withholding agreements.

2. FATCA compliance includes:



1. Review of FATCA Registration data to ensure that Global Intermediary Identification Numbers are assigned properly based on the information provided

2. Periodic assessment of registration

3. Tracking and analysis of trends which may prompt FAQs and updates to instructions

4. Development of FAQs based on common and recurring inquiries presented by industry

5. Providing support for the implementation of FATCA compliance strategies

6. Monthly updates of the IRS FFI list


3. Financial intermediaries (FI) ensures that the withholding, reporting and depositing of tax for those foreign entities that have entered into withholding agreements with the IRS is conducted according to contractual requirements. These entities include qualified intermediaries, withholding foreign partnerships, withholding foreign trusts and qualified derivative dealers. FI provides support for the implementation of FATCA compliance strategies.

4. A Centralized Withholding Agreement (CWA) is a formalized agreement or contract entered into by the IRS, a designated third-party withholding agent and a nonresident alien (NRA) athlete or entertainer, who has requested the agreement. The CWA program is a pre-filing compliance program that works to ensure proper withholding compliance. Rev. Proc. 89-47 establishes the guidelines for the CWA program.


**1.1.24.3.4.1.2** **(09-24-2020)**

###### Post-Filing/Pre-Acceptance

1. Post-Filing/Pre-Acceptance (PF/PA) is responsible for the verification of foreign withholding with respect to credits/claims for refunds on Form 1120F or Form 1040NR. PF/PA also:



1. Performs compliance activities focused on the data accuracy of withholding agent reporting

2. Coordinates and reviews changes and updates to regulations, forms, publications, and IRMs

3. Coordinates with Submission Processing and Accounts Management to resolve chapter 3 and 4 issues affecting taxpayers

4. Coordinates outreach to other business operating divisions and external stakeholders on chapter 3 and 4 issues

5. Provides support for the implementation of chapters 3 and 4 compliance strategies


**1.1.24.3.4.1.3** **(09-24-2020)**

###### Post-Filing

1. Post-Filing audit is aligned by geographic teams. Post-Filing audit uses issue-specific expertise to administer international tax compliance for multinational entities. Field Compliance:



1. Identifies and elevates emerging issues that may require development of new guidance for the field

2. Conducts examinations of and has jurisdiction over the withholding tax returns Forms 1042, 8804 and 8288

3. Audits Forms 1120-F claims filed by foreign corporations

4. Receives referrals for assistance from other business operating divisions with their chapter 3 and 4 withholding tax related issues


**1.1.24.3.4.1.4** **(09-24-2020)**

###### Automatic Exchange of Information (AEOI)

1. The AEOI program administers and coordinates all automatic exchanges of information between the U.S. and foreign national tax authorities (i.e., exchanges occurring on a regular and systematic basis, without the need for specific requests for information).

2. Automatic exchanges include exchanges of FATCA financial account data, certain information related to the OECD’s Base Erosion and Profit Shifting project (Country-by-Country Reporting), and information on U.S.-sourced fixed determinable annual periodic (FDAP) payments to foreign persons and foreign-sourced FDAP payments to U.S. persons (traditional automatic). AEOI also coordinates activities with internal business units and foreign tax authorities with respect to FATCA intergovernmental agreements, confidentiality and data safeguards and competent authority arrangements relating to AEOI.


**1.1.24.3.4.2** **(09-24-2020)**

##### International Individual Compliance

1. IIC field operations is comprised of groups of revenue agents, tax compliance officers and tax examiners that are responsible for administering tax compliance for U.S. citizens residing abroad or in U.S. territories and non-resident aliens who have a U.S. filing requirement. IIC’s primary areas of responsibility include:



1. Administration: IIC administers the tax law that affects any individual with international activity. These efforts include understanding our taxpayer population, proposing legislative changes, ensuring consistent treatment of similar taxpayers and promoting taxpayer education.

2. Strategy Priority: IIC is responsible for developing strategies to address the highest priority issues within specific taxpayer segments. IIC coordinates with the other IRS business operating divisions to determine who is best suited to address the issues found in specific taxpayer segments.

3. Program Delivery: IIC’s day-to-day responsibilities include identifying high risk returns and issues, case building, examining high risk returns, developing training, educating the IRS workforce, and working with specific groups in a pre-filing environment.


**1.1.24.3.4.3** **(09-30-2021)**

##### Exchange and Offshore Strategy

1. Exchange and Offshore Strategy Compliance field operations has four components:



1. Exchange of Information

2. Offshore Compliance Initiatives

3. WEIIC Practice Networks

4. Planning and Special Programs


**1.1.24.3.4.3.1** **(09-24-2020)**

###### Exchange of Information

1. The EOI program administers and coordinates all exchanges of information between the U.S. and foreign national tax authorities under tax treaties and Tax Information Exchange Agreements (TIEAs), except for exchanges relating to transfer pricing and mutual agreement proceedings administered by the APMA program, automatic exchanges of information administered by AEOI and certain exchanges relating to cross-border tax avoidance schemes administered by JITSIC.

2. Other responsibilities of EOI include:



1. Facilitating exchanges conducted in the course of simultaneous examinations and simultaneous criminal investigations involving two or more national tax authorities (the Simultaneous Examination Program and Simultaneous Criminal Investigation Program)

2. Coordinating requests for the collection of taxes due to a requesting authority under the Mutual Collection Assistance Request program

3. Providing tax returns and return information to Criminal Investigation in order to fulfill requests made by foreign national authorities under Mutual Legal Assistance Treaties


3. For more information regarding EOI, see IRM 4.60.1, Exchange of Information.


**1.1.24.3.4.3.2** **(09-24-2020)**

###### Offshore Compliance Initiatives

1. Offshore Compliance Initiatives (OCI) promote voluntary compliance with U.S. tax and foreign information reporting laws through strategic enforcement actions directed at identifying U.S. taxpayers involved in abusive offshore tax schemes. In addition, they focus on the banks, other financial institutions and third parties that provide, facilitate or enable their offshore financial arrangements and structures. OCI also:



1. Conducts information gathering and data analysis activities to identify promoters or facilitators of abusive offshore schemes for compliance activities

2. Participates in international forums for improving voluntary compliance, sharing best practices and leveraging resources

3. Focuses on taxpayers who did not report offshore activity through application of tax treaties

4. Provides technical and procedural guidance on international issues associated with offshore arrangements


**1.1.24.3.4.3.3** **(09-24-2020)**

###### WEIIC Practice Networks (Inbound and Outbound)

1. International field members are encouraged to participate in one or more issue PNs. The PNs are communities of employees sharing information in broad areas of international compliance providing international employees the opportunity to both learn from and teach their colleagues.

2. The WEIIC PN office focuses on compliance issues related to international individual outbound transactions and international individual inbound transactions.



1. The Individual Outbound PN focuses on individuals (U.S. citizens or resident aliens) whose activities generate income that is earned outside the United States. The Individual Outbound PNs include the Jurisdiction to Tax-Outbound PN, the Foreign Entities PN, the Offshore Arrangements PN and the Foreign Tax Credit PN.

2. The Individual Inbound PN focuses on U.S. source income of nonresident aliens taxed either at a flat rate for investment income, or at graduated rates on income effectively connected with a U.S. business. The Individual Inbound PNs include the U.S. Business Activities PN and the Withholding PN. The Withholding PN addresses withholding issues related to both individuals and entities.


**1.1.24.3.4.3.4** **(09-30-2021)**

###### WEIIC Planning and Special Programs

1. Planning and Special Programs (PSP) is responsible for the identification, classification, risk assessment and return delivery of the IIC filing population. It supports the field teams with inventory and workflow by monitoring actual performance against the compliance plan and providing updates and status reports necessary to allocate time and resources properly. PSP responsibilities include:



   - Claims processing

   - Compliance Functional Automation Support

   - Exchange of Information Screening and Examination

   - FinCEN Information Requests

   - Operation Assistance Requests (OARs)

   - Competent Authority Determination/Disposition Memorandum

   - Collaboration with the issue practice networks on issues developed

   - Consultations on development of new work streams


**1.1.24.3.5** **(03-12-2024)**

#### Treaty and Transfer Pricing Operations

1. The director of the Treaty and Transfer Pricing Operations (TTPO) Practice Area reports directly to the LB&I deputy commissioner and is responsible for all TTPO operations. TTPO identifies emerging tax treaty and transfer pricing issues and coordinates closely with LB&I leadership and Division and Associate Chief Counsel (International) to ensure consistently strong administration of treaty and transfer pricing issues throughout the IRS. TTPO also identifies, leads and participates in LB&I campaign initiatives.

2. TTPO is responsible for transfer pricing tax compliance activities and has a treaty oversight role with regards to:



   - U.S. multinational enterprises

   - Foreign entities with U.S. operations and activities

   - U.S. citizens and residents residing outside of the United States

   - Offshore activities and non-resident aliens with U.S. business or investment activities


3. The TTPO director is delegated authority under IRS Delegation Order 4-12 to sign on behalf of the Commissioner, LB&I, agreements between the competent authority of the United States and the competent authority of another country or a U.S. territory entered into under the tax treaties, tax information exchange agreements, and FATCA intergovernmental agreements of the United States and under tax coordination agreements and tax implementation agreements with the territories of the United States.

4. TTPO is comprised of the following programs:



1. Advance Pricing and Mutual Agreement (APMA)

2. Transfer Pricing Practice (TPP)


**1.1.24.3.5.1** **(09-30-2021)**

##### Advance Pricing and Mutual Agreement Program

1. The Advance Pricing and Mutual Agreement (APMA) program resolves actual or potential transfer pricing disputes in cooperation with the taxpayer. APMA administers the Advance Pricing Agreement (APA) program, which provides a voluntary process whereby the IRS and taxpayers may resolve transfer pricing issues and issues for which transfer pricing principles may be relevant on a prospective basis. APMA also administers the portion of the office of the U.S. Competent Authority with responsibility for cases arising under the business profits and associated enterprises articles of U.S. tax treaties. An example of a competent authority issue handled by APMA is the double tax that could be incurred as a result of an allocation made by the IRS under IRC 482 or by a foreign tax authority under an equivalent provision in its domestic law.

2. In addition, APMA administers, through its Treaty Assistance and Interpretation Team (TAIT) function, the portion of the office of the U.S. competent authority with responsibility for issues arising under other articles of U.S. tax treaties, including instances of double taxation or taxation otherwise inconsistent with a tax treaty and requests for certain discretionary determinations.


**1.1.24.3.5.1.1** **(03-12-2024)**

###### Treaty Assistance and Interpretation Team

1. TAIT is responsible for addressing all issues and cases related to the operation of tax treaties, excluding exchanges of information administered by AEOI or JITSIC, or issues pertaining to transfer pricing or other allocation cases administered by APMA. TAIT’s responsibilities include:



1. Negotiating agreements with treaty partners under mutual agreement procedures to resolve taxpayer-specific cases and negotiating generally applicable arrangements with treaty partners to clarify the application or interpretation of tax treaty provisions

2. Developing and managing the practice network responsible for treaty issues commonly encountered in examinations

3. Providing field personnel with a central point of contact for addressing all matters pertaining to tax treaties (other than issues arising under the associated enterprises article or the business profits article), including implementation of mutual agreements that affect taxpayers’ U.S. filing requirements

4. Developing training materials and delivering training programs for field personnel

5. Supporting the Treasury Department in negotiations of treaties/protocols

6. Supporting Treasury and IRS initiatives relating to the OECD

7. Overseeing the U.S. Territories program


**1.1.24.3.5.1.1.1** **(03-12-2024)**

###### Treaties Practice Network

1. The Treaties PN falls within TAIT and as such, reports to the Director, APMA.

2. The Treaties PN provides resources on how tax treaties may affect the taxing jurisdiction of each treaty partner by modifying the results that might otherwise be obtained under domestic law. The Treaties PN addresses and develops training on a wide range of treaty matters, including the following issues:



1. Qualification for treaty benefits under the residency and limitation on benefits articles

2. Determination of treaty withholding rates on FDAP income, including the effect of beneficial ownership and anti-conduit rules

3. Treatment of income derived by or through fiscally transparent entities

4. Determination of permanent establishment status

5. Taxation of U.S. resident and nonresident individuals under tax treaties

6. Taxation of income related to pensions and employee plans

7. Application of relief from double taxation articles under tax treaties

8. Availability of mutual agreement procedures, including with respect to taxpayers’ exhaustion of remedies to contest foreign tax adjustments

9. Compliance requirements relating to treaty benefits, such as Form 8833


**1.1.24.3.5.1.1.2** **(03-12-2024)**

###### U.S. Territories Program

1. The U.S. Territories Program falls within the Treaties PN in TAIT and as such, reports to the director, APMA. It is responsible for:



1. Addressing technical issues resulting from certain IRC sections unique to the U.S. territories, which include the U.S. Virgin Islands, Puerto Rico, American Samoa, the Commonwealth of the Northern Mariana Islands, and Guam

2. Administering the Tax Coordination and Tax Implementation Agreements between the IRS and each U.S. territory tax department

3. Coordinating and addressing technical issues that cross IRS operating divisions, including cover over payments to the territory tax departments

4. Collaborating with other federal agencies to administer IRC sections impacting the US territories.


**1.1.24.3.5.2** **(09-24-2020)**

##### Transfer Pricing Practice

1. TPP is comprised of a team of specialized transfer pricing professionals with a field examination focus. TPP may take primary responsibility for the examination of transfer pricing issues on an income tax return or may provide guidance to a team of other agents performing the examination. As such, TPP duties include:



1. Identifying appropriate transfer pricing issues and cases for audit

2. Performing the appropriate analysis of issues or advising examination teams in this activity and determining the best transfer pricing method to apply

3. Developing the Service’s positions on transfer pricing issues and communicating examination findings clearly and persuasively, both orally and in writing

4. Ensuring consistent and coordinated support of transfer pricing issues before Appeals, LB&I competent authority functions and, if necessary, in litigation

5. Assisting in identifying emerging transfer pricing issues

6. Coordinating with LB&I leadership, Division and Associate Chief Counsel, APMA, and PNs to ensure consistently strong administration of transfer pricing throughout the IRS


**1.1.24.3.5.2.1** **(09-24-2020)**

###### Transfer Pricing Practice Networks

1. TPP also consists of the TPP PNs, which are groups of specialized professionals that assist examiners by addressing and collaborating on compliance issues associated with income shifting, transfer pricing and valuation. The TPP PNs also share knowledge, assess risks and work on special projects.

2. The TPP PNs consist of the following groups:



1. Transfer Pricing Practice Network (TPPN)

2. Transfer Pricing Risk Assessment (TPRA) team


**1.1.24.3.5.2.1.1** **(03-12-2024)**

###### Transfer Pricing Practice Network (TPPN)

1. The TPPN provides a forum where issues, audit techniques and best practices can be shared and evaluated, fostering coordination and collaboration among all those interested. The TPPN serves as an engine for income shifting strategy, training and knowledge management.

2. The TPPN is comprised of revenue agents, tax law specialists and economists who provide guidance on various inbound and outbound transfer pricing issues. The TPPN focuses on a wide range of controlled transactions that may facilitate income shifting between U.S. and foreign-related entities (i.e., controlled foreign corporations, controlled foreign partnerships and/or foreign parents) to lower-tax environments.

3. The TPPN addresses and develops training on a wide range of issues, including:



   - Tangible goods transactions

   - Intangibles and intangible property (IP) valuation

   - Services and cost allocations

   - Cost sharing agreements

   - Pricing financial instruments


**1.1.24.3.5.2.1.2** **(03-12-2024)**

###### Transfer Pricing Risk Assessment Team

1. The TPRA team is TTPO’s centralized risk assessment function, performing high-level risk assessment using data analytic techniques to identify and evaluate transfer pricing risks. The TPRA team supports TTPO through project-focused risk assessment activities, including but not limited to the International Compliance Assurance Program (ICAP).


**1.1.24.3.6** **(03-12-2024)**

#### Western Compliance

1. The director of Western Compliance Practice Area (WCPA) reports directly to the LB&I deputy commissioner and is responsible for all WCPA operations. The WCPA provides the full range of pre-filing, filing and post-filing programs and activities for large businesses in Alaska, Arizona, California, Colorado, Hawaii, Idaho, Kansas, Louisiana, Montana, Nebraska, Nevada, New Mexico, Oklahoma, Oregon, Texas, Utah, Washington and Wyoming. The WCPA also has nationwide responsibility for the computer audit specialists.


**1.1.24.3.6.1** **(03-12-2024)**

##### Computer Audit Specialists

1. The Computer Audit Specialist (CAS) program is a component of the WCPA (DFO-South Central) within LB&I. The CAS program consists of computer audit specialists and statistical sampling coordinators. The computer audit specialists support examinations with analysis of electronic records. The statistical sampling coordinators support examinations with statistical samples as an effective audit technique. All business units within IRS are supported by the CAS program.


**1.1.24.3.7** **(03-12-2024)**

#### Eastern Compliance

1. The director of the Eastern Compliance Practice Area (ECPA) reports directly to the LB&I deputy commissioner and is responsible for all ECPA operations. The ECPA provides the full range of pre-filing and post-filing programs and activities for large businesses in Alabama, Arkansas, Florida, Georgia, Illinois, Indiana, Iowa, Kentucky, Michigan, Minnesota, Mississippi, Missouri, North Carolina, North Dakota, Ohio, South Carolina, South Dakota, Tennessee and Wisconsin. The ECPA also has Servicewide responsibility for the Engineering Program.


**1.1.24.3.7.1** **(03-12-2024)**

##### Engineering

1. The Engineering Program provides expertise on numerous technical issues including research credit, depreciation, depletion and valuation of real estate; business interests (stocks, options), intellectual property (including patents, trademarks and technology), tangible property (industrial equipment, collections of rare cars or yachts) and can compute market premiums and discounts, considering various factors.. The technical experts have backgrounds in various engineering disciplines (e.g., petroleum, computer science and mining) and include individuals certified/licensed in business and real estate appraisal. Engineering and valuation teams can provide services on a consult or formal referral basis.

2. The primary function of the Engineering Program is to provide specialized services to field personnel across multiple operating divisions as well as Appeals and Counsel.


**1.1.24.3.8** **(03-12-2024)**

#### Northeastern Compliance

1. The director of the Northeastern Compliance Practice Area (NECPA) reports directly to the LB&I deputy commissioner and is responsible for all NECPA operations. The NECPA provides the full range of pre-filing, filing, and post-filing programs and activities for large businesses in Connecticut, Delaware, Maine, Maryland, Massachusetts, New Hampshire, New Jersey, New York, Pennsylvania, Rhode Island, Vermont, Virginia, West Virginia and Washington D.C. The NECPA has nationwide responsibility for the Tax Computation Specialists Program and the Joint Committee Review program.


**1.1.24.3.8.1** **(09-24-2020)**

##### Tax Computation Specialists

1. The Tax Computation Specialists (TCS) Program is a component of the NECPA and has technical expertise in determining tax liability of all LB&I taxpayers. TCS provide services including:



1. Return Input - Tax reconciliation to the filed return.

2. Tentative Computation - Mid-cycle risk analysis or tax computation needed to determine if the team will continue the review of an audit issue.

3. Revenue Agent Report (RAR) Computation - RAR generated at the end of the examination.

4. Joint Committee Spreadsheets - TCS prepares spreadsheets and completes Section 1 of Form 2285 (Restricted Interest).


**1.1.24.3.8.2** **(03-12-2024)**

##### Joint Committee Review

1. The Joint Committee Review (JCR) program oversees the preparation of specific reports (JC reports) subject to review by the Joint Committee on Taxation (JCT) for refunds or credits under IRC 6405. A JC report must be prepared for examined and surveyed-after-assignment cases for refunds or credits of income, estate and gift taxes, and certain excise taxes in excess of the current jurisdictional threshold of $2 million ($5 million for C corporations). The JCR program has responsibility for Joint Committee (JC) cases that are fully agreed, certain partially agreed, and surveyed after assignment from LB&I, SB/SE and TE/GE.

2. Joint Committee specialists (JCS) review JC cases for procedural, computational and technical accuracy before preparing and submitting the JC reports that are submitted to the JCT for its review. The JCT is a nonpartisan committee of the United States Congress.

3. See IRM 4.36, Joint Committee Procedures, for more information.


**1.1.24.3.9** **(03-12-2024)**

#### Practice Area PSPs (Planning and Special Programs)

1. A PSP analyst is embedded in each of the practice area offices and reports to the executive assistant of the practice area director.

2. The primary responsibilities of the PSP analyst include, but are not limited to, the following:



   - Large Corporate Compliance

   - Ordering and delivering returns for examination

   - Monitoring results and inventory levels


3. Other programs or systems that the PSP Analyst may support/utilize:



   - AIMS/ERCS (SETTS)

   - LWIS, LIN, CBF, TIG, IBMIS

   - Campaigns and other compliance programs

   - Other Source Workload Delivery (Bankruptcy, Information Referrals, Statutes)


**1.1.24.4** **(09-24-2020)**

### References for LB&I Programs

1. **LB&I Examination Process (LEP)**: see IRM 4.46 and Pub 5125.

2. **Compliance Assurance Process (CAP)**: see IRM 4.51.8.

3. **Fast Track Settlement (FTS) program**: see IRM 4.51.4.

4. **Pre-filing Agreement (PFA) program**: see Rev. Proc. 2016-30 and IRM 4.30.1.

5. **Industry Issue Resolution (IIR) program**: see Rev. Proc. 2016-19 and IRM 7.40.1.

6. **FATCA**: see [Foreign Account Tax Compliance Act (FATCA) webpage on IRS.gov](https://www.irs.gov/businesses/corporations/foreign-account-tax-compliance-act-fatca).


**Exhibit 1.1.24-1**

### Quick Reference Guide for Acronyms

| **Acronym** | **Definition** |
| --- | --- |
| ACA | Affordable Care Act |
| ADCCI | Assistant Deputy Commissioner Compliance Integration |
| AEOI | Automatic Exchange of Information |
| APA | Advance Pricing Agreement |
| APMA | Advance Pricing and Mutual Agreement |
| BBA | Bipartisan Budget Act of 2015 |
| BSP | Business Systems Planning |
| C&L | Communication and Liaison |
| CAP | Compliance Assurance Process |
| CAS | Computer Audit Specialist |
| CBA | Cross-Border Activities |
| CD&A | Campaign Development and Administration |
| CMSS | Case Management System Solutions |
| CP&A | Compliance Planning and Analytics |
| CII | Correspondence Imaging Inventory |
|  |  |
| CSC | Compliance Strategy Council |
| CST | Customer Support Training |
| CTS | Collaborative Technology Support |
| D&SM | Data and System Management |
| DMS | Data Management and Services |
| DFO | Director of Field Operations |
| DS | Data Solutions |
| ECPA | Eastern Compliance Practice Area |
|  |  |
| EOI | Exchange of Information |
| EOS | Exchange and Offshore Strategy |
| FATCA | Foreign Account Tax Compliance Act |
| FPP | Foreign Payments Practice |
| FP | Financial Products |
| FTS | Fast Track Settlement |
| GAO | General Accounting Office |
| GHW | Global High Wealth |
| HCM | Human Capital Management |
| HCO | Human Capital Office |
| IBMIS | Issue-Based Management Information System |
| IIC | International Individual Compliance |
| IIR | Industry Issue Resolution |
| IMS | Issue Management System |
| IT | Information Technology |
| JC | Joint Committee |
| JITSIC | Joint International Taskforce on Shared Intelligence and Collaboration |
| L&E | Learning and Education |
| LEP | LB&I Examination Process |
| LIN | LB&I Image Network |
| LWDT | Leadership, Workforce Development and Technology |
| NECPA | Northeastern Compliance Practice Area |
| OCI | Offshore Compliance Initiatives |
| OECD | Organisation for Economic Cooperation and Development |
| OTS | Outservice Training and Support |
| PA | Practice Area |
| PBS | Program and Business Solutions |
| PFA | Pre-Filing Agreement |
| PF/PA | Post-Filing/Pre-Acceptance |
| PN | Practice Network |
| PPCA | Program Planning, Coordination and Analysis |
| PSP | Planning and Special Programs |
| PTE | Pass-Through Entities |
| QRA | Quality Review and Analysis |
| RAR | Revenue Agent Report |
| RS | Resource Solutions |
| SPG | Strategy, Policy and Governance |
| STPA | Specialty Training, Projects and Analysis |
| TAIT | Treaty Assistance and Interpretation Team |
| TCS | Tax Computation Specialist |
| TIEA | Tax Information Exchange Agreement |
| TIGTA | Treasury Inspector General for Tax Administration |
| TPP | Transfer Pricing Practice |
| TPPN | Transfer Pricing Practice Network |
| TPRA | Transfer Pricing Risk Assessment |
| TPS | Technology and Program Solutions |
| TTCC | Technical Training and CPA/CPE |
| TTPO | Treaty and Transfer Pricing Operations |
| WCPA | Western Compliance Practice Area |
| WD&D | Workload Development and Delivery |
| WEIIC | Withholding, Exchange and International Individual Compliance |
| WIIC | Withholding and International Individual Compliance (legacy term) |

**Exhibit 1.1.24-2**

### LB&I Organization Chart

![This is an Image: 14055001.gif](https://www.irs.gov/pub/xml_bc/14055001.gif)

> Large Business and International Organization ChartThis is the LB&I organization chart as described within this IRM. The LB&I commissioner is represented by a box at the top of the chart. Immediately beneath the LB&I commissioner box is a box for the LB&I deputy commissioner. The two HQ officials who directly report to the LB&I deputy commissioner are represented by a box to the left and a box to the right of the LB&I deputy commissioner box. These officials are:Director, Program and Business SolutionsAssistant Deputy Commissioner Compliance IntegrationBoxes representing the eight practice area directors who also directly report to the LB&I deputy commissioner are listed horizontally beneath the LB&I deputy commissioner box. They are:Director, Western Compliance Director, Pass-Through Entities Director, Enterprise ActivitiesDirector, Cross-Border ActivitiesDirector, Eastern Compliance Director, Withholding, Exchange and International Individual ComplianceDirector, Treaty and Transfer Pricing OperationsDirector, Northeastern Compliance Boxes representing the functions that report to the Director, Program and Business Solutions (PBS) are listed horizontally beneath the Director, PBS box. They are:Equal Employment ManagerDirector, Technology and Program SolutionsDirector, Resource SolutionsBoxes representing the functions that report to the Assistant Deputy Commissioner Compliance Integration (ADCCI) are listed horizontally beneath the ADCCI box. They are:Strategy, Policy and Governance DirectorDirector, Data SolutionsDirector, Compliance Planning and AnalyticsBoxes representing the functions that report to the Director, Western Compliance PA are listed vertically underneath the Director, Western Compliance PA box. They are:Director of Field Operations WestDirector of Field Operations NorthwestDirector of Field Operations CASDirector of Field Operations South CentralBoxes representing the functions that report to the Director, Pass-Through Entities PA are listed vertically underneath the Director, Pass-Through Entities PA box. They are:Deputy Director, Pass-Through Exam Strategy Promoters ProgramDirector of Field Operations, Global High WealthDirector of Field Operations, Pass-ThroughsBoxes representing the functions that report to the Director, Enterprise Activities PA are listed vertically underneath the Director, Enterprise Activities PA box. They are:Director, Financial Institutions and ProductsDirector of Field Operations, Financial Institutions and Products WestDirector, Corporate Issues/CreditsBoxes representing the functions that report to the Director, Cross-Border Activities PA are listed vertically underneath the Director, Cross-Border Activities PA box. They are:Director of Field Operations, EastDirector of Field Operations, WestDirector of Field Operations, CentralBoxes representing the functions that report to the Director, Eastern Compliance PA are listed vertically underneath the Director, Eastern Compliance PA box. They are:Director of Field Operations, North CentralDirector of Field Operations, SoutheastDirector of Field Operations, CentralDirector of Field Operations, Engineering EastDirector of Field Operations, Engineering WestBoxes representing the functions that report to the Director, Withholding, Exchange and International Individual Compliance PA are listed vertically underneath the Director, Withholding and International Individual Compliance PA box. They are:Director of Field Operations, Foreign Payments Practice (FPP) and AEOIDirector of Field Operations, International Individual ComplianceDirector of Field Operations, Exchange and Offshore StrategyBoxes representing the functions that report to the Director, Treaty and Transfer Pricing Operations PA are listed vertically underneath the Director, Treaty and Transfer Pricing Operations PA box. They are:Director of Field Operations, Transfer Pricing PracticeDirector of Field Operations, Treaty and Transfer Pricing WestDirector, Advance Pricing and Mutual AgreementBoxes representing the functions that report to the Director, Northeastern Compliance PA are listed vertically underneath the Director, Northeastern Compliance PA box. They are:Director of Field Operations, North AtlanticDirector of Field Operations, Mid-AtlanticDirector of Field Operations, Tax Computation Specialist/Joint Committee Review

[Please click here for the text description of the image.](https://www.irs.gov/media/129236 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-024#addtoany "Show all")

A2A