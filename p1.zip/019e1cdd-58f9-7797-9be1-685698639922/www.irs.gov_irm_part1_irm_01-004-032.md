---
url: "https://www.irs.gov/irm/part1/irm_01-004-032"
title: "1.4.32 Internal Control Review Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-032#main-content)

- 1.4.32  [Internal Control Review Program](https://www.irs.gov/irm/part1/irm_01-004-032#id1)
  - 1.4.32.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-032#id2)
    - 1.4.32.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-032#id3)
    - 1.4.32.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-004-032#id4)
    - 1.4.32.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-032#id5)
      - 1.4.32.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-004-032#id7)
      - 1.4.32.1.3.2  [Associate CFO for Internal Controls](https://www.irs.gov/irm/part1/irm_01-004-032#id8)
      - 1.4.32.1.3.3  [Internal Reviews](https://www.irs.gov/irm/part1/irm_01-004-032#id9)
      - 1.4.32.1.3.4  [Operating Divisions](https://www.irs.gov/irm/part1/irm_01-004-032#id10)
    - 1.4.32.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-032#id11)
    - 1.4.32.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-032#id12)
    - 1.4.32.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-004-032#id13)
    - 1.4.32.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-032#id14)
    - 1.4.32.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-032#id15)
  - 1.4.32.2  [Analytical Support](https://www.irs.gov/irm/part1/irm_01-004-032#id16)
  - 1.4.32.3  [Selection of Program Reviews](https://www.irs.gov/irm/part1/irm_01-004-032#id17)
  - 1.4.32.4  [Review Selection Notification](https://www.irs.gov/irm/part1/irm_01-004-032#id18)
  - 1.4.32.5  [Review Procedures and Services](https://www.irs.gov/irm/part1/irm_01-004-032#id19)
  - 1.4.32.6  [Reporting Process](https://www.irs.gov/irm/part1/irm_01-004-032#id20)
  - 1.4.32.7  [Report Approval Process](https://www.irs.gov/irm/part1/irm_01-004-032#id21)
  - 1.4.32.8  [Operating Division Post Review](https://www.irs.gov/irm/part1/irm_01-004-032#id22)
  - 1.4.32.9  [Records Retention/Accessibility of Reports](https://www.irs.gov/irm/part1/irm_01-004-032#id23)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 32. Internal Control Review Program

* * *

## 1.4.32 Internal Control Review Program

#### Manual Transmittal

February 17, 2026

#### Purpose

(1) This transmits revised IRM 1.4.32, Resource Guide for Managers, Internal Control Review Program.

#### Material Changes

(1) IRM 1.4.32.1.7, Acronyms, section updated.

(2) IRM 1.4.32.5, Review Procedures and Services, section name changed and section updated.

(3) IRM 1.4.32.7, Report Approval Process, added information on Strategic Advisory Reviews (SAR’s).

(4) IRM 1.4.32.8, Operating Division Post Review, removed Integrated Data Retrieval System (IDRS) reference.

(5) Throughout the IRM, changed “business unit” to “operating divisions.”

(6) Minor editorial changes made throughout the IRM.

#### Effect on Other Documents

IRM 1.4.32, dated January 19, 2024, is superseded.

#### Audience

All operating divisions

#### Effective Date

(02-17-2026)

Anthony S. Chavez

Chief Financial Officer

**1.4.32.1** **(01-31-2022)**

### Program Scope and Objectives

1. This IRM provides general guidance on the Internal Control Review (ICR) program and the established procedures designed to support the CFO’s efforts to improve the quality of IRS internal controls throughout the IRS. The ICR program provides operating divisions with insight into the effectiveness of their implemented corrective actions for audit recommendations issued by the Government Accountability Office (GAO) and TIGTA, which evaluates critical controls over IRS programs that may be high-risk, high-priority or high-visibility. This independent examination assists the operating divisions when they review and evaluate their internal control processes.

2. Purpose: Internal controls include activities used to monitor processes, procedures and programs to ensure they are operating as intended. Effective internal controls are also the first line of defense for safeguarding assets, preventing and detecting errors and mitigating risk. Internal controls are a vital tool allowing each manager to evaluate and monitor programs proactively and eliminate deficiencies timely. Operating division program managers have the primary responsibility for ensuring effective controls over their specific programs. The ICR analyst performs reviews to determine whether there are any internal control deficiencies and provides recommendations to improve or strengthen internal controls. The ICR program assists IRS senior leadership with oversight by providing independent insight into the status of program controls.

3. Audience: IRS managers and employees.

4. Policy Owner: The CFO, Office of Internal Controls (IC), is responsible for this IRM.

5. Program Owner: Internal Reviews, Internal Control Review program, promotes knowledge management and sharing of internal controls throughout the IRS by reviewing, testing, measuring and reporting on various controls.

6. Primary Stakeholder: This IRM and its related procedures apply to the entire IRS workforce. It is incumbent upon the program owners to evaluate the effectiveness of their programs. The term “program” in this IRM includes processes, projects, operations and any supporting activities.

7. Program Goals: The Servicewide ICR program supports ongoing program improvements by conducting a thorough analysis of internal controls and identifying potential deficiencies. The process is intended to allow ICR to evaluate the way a program works and make recommendations for improvements to controls and risk mitigation strategies. This, in turn, allows the program owners to develop and implement process improvements and strengthen controls, thereby eliminating deficiencies and mitigating risks before a program failure occurs or external stakeholders are adversely affected.




    All managers have a responsibility to perform periodic monitoring to review the accuracy and effectiveness of the internal controls. As required by IRM 1.4.2, Monitoring and Improving Internal Control, all program managers are responsible for ensuring their programs have effective controls in place and for monitoring those controls for continued effectiveness over time.


**1.4.32.1.1** **(01-31-2022)**

#### Background

1. This section clarifies ICR’s role throughout the IRS:



1. The ICR program partners with the operating divisions to identify gaps, deficiencies, weaknesses or program concerns and to provide the operating divisions with recommendations to improve or strengthen internal controls.

2. The ICR analyst applies a variety of methods (for example, administrative, analytical or technical) when evaluating and examining a program, procedure or process.

3. Once the ICR analyst concludes the review, the Office of Internal Controls issues the relevant operating division’s report to the point of contact (POC). The relevant business report includes results, conclusions, recommendation and findings, if applicable.


**1.4.32.1.2** **(01-19-2024)**

#### Authorities

1. [Federal Managers’ Financial Integrity Act](https://obamawhitehouse.archives.gov/sites/default/files/omb/assets/omb/financial/fmfia1982.html) (FMFIA) of 1982. Under 31 USC Section 3512(c) and (d) of the FMFIA, federal agencies are required to establish internal control over their accounting and administrative (operational) activities and review internal control systems periodically. The FMFIA also requires GAO to prescribe internal control standards to serve as criteria for those reviews.

2. [Standards for Internal Control in the Federal Government](https://www.gao.gov/greenbook) (also known as the “Green Book”) GAO-25-107721. The GAO issued the Green Book to provide standards for Internal Control in the Federal Government (Green Book). The Green Book provides the overall framework for agencies to establish, maintain and assess internal control over agency operations. As part of the monitoring component, the Green Book directs agency personnel to monitor their respective internal control systems, evaluate the results and remediate identified internal control deficiencies timely.

3. [Treasury Directive 40-04](https://home.treasury.gov/about/general-information/orders-and-directives/td40-04), Treasury Internal Control Program. Treasury Directive 40-04, Treasury Internal Control Program (TICP) (dated 7/1/2024), requires bureau heads and other officials to take all necessary steps to create an environment within their respective organizations that ensures adherence to all applicable statutory and regulatory standards related to operational, financial, program and administrative internal controls. This includes providing assurances to Treasury that the internal controls within their respective organizations adhere to applicable statutory and regulatory standards and ensure timely completion of corrective actions for identified control deficiencies.


**1.4.32.1.3** **(01-31-2022)**

#### Responsibilities

1. This section provides responsibilities for:



1. CFO and Deputy CFO

2. Associate CFO for Internal Controls

3. Internal Reviews

4. Operating Divisions


**1.4.32.1.3.1** **(09-26-2019)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO manage a portfolio of enterprise-wide activities including budget formulation, budget execution, accounting, financial management, and internal controls.


**1.4.32.1.3.2** **(09-26-2019)**

##### Associate CFO for Internal Controls

1. The Associate CFO for Internal Controls administers the IRS internal controls program and is responsible for coordinating and executing processes that assess the completeness and effectiveness of internal controls and support annual assurance and financial statement audit activities by:



1. Evaluating the effectiveness of internal controls.

2. Partnering with operating divisions to implement and evaluate Office of Management and Budget (OMB) Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control requirements.

3. Developing detailed procedures, documentation, training for managers and employees and reporting requirements necessary to review, establish, maintain, test, improve and report on the IRS’s control systems.

4. Providing advice and assistance to managers and their internal control coordinators.


**1.4.32.1.3.3** **(01-31-2022)**

##### Internal Reviews

1. Internal Reviews’ (IR) staff responsibilities include:



1. Establishing and documenting the ICR program processes, policies and procedures.

2. Collecting and analyzing data relevant to the program under review.

3. Developing a test plan or a preliminary research memorandum as appropriate for any review, which states the objective, focus areas, related IRM references or external audits, issues identified and any additional comments important to the review.

4. Providing a report outlining the purpose, scope, background analysis, findings, and conclusions, in addition to any recommendations from the ICR team or analyst.


**1.4.32.1.3.4** **(09-26-2019)**

##### Operating Divisions

1. Managers are responsible for improving and strengthening internal controls. Program management responsibility with respect to the ICR program is to:



1. Monitor controls with higher risk and greater vulnerabilities.

2. Identify subject matter experts (SME’s) for each program, process, or procedure.

3. Foster communication and develop a strategy to engage staff by encouraging the importance of internal controls.

4. Track and address open GAO, TIGTA, and Financial Assurance Control Testing (FACT) audit findings and recommendations.


2. Managers and SMEs are responsible for:



1. Providing documentation to ICR program staff upon request.

2. Providing comments on potential findings within the report.


3. SMEs are responsible for:



1. Coordinating timely responses to ICR inquiries via the designated ICR POC.

2. Coordinating logistics for ICR team field visits.


**1.4.32.1.4** **(09-26-2019)**

#### Program Management and Review

1. Program reporting includes the following:



1. The ICR team or analyst develops a post-review report detailing methodology, testing, findings and recommendations, as appropriate. Internal Controls leadership delivers the report to the owner of the program being reviewed. The report may be provided to external stakeholders under certain circumstances. For example, reports and related materials will be provided upon request to TIGTA or GAO; reports may be provided automatically where the review is being conducted in conjunction with requirements of a larger audit process, such as the annual Campus Physical Security review performed in support of the GAO Financial Statement Audit.

2. Findings may be reported to the Management Controls Executive Steering Committee (MC ESC) if the program is of sufficient scope and the control deficiencies discovered during the review are of sufficient seriousness to warrant a broad leadership discussion.

3. General, aggregated results of reviews performed during the year will be used to support IRS’s annual assurance statement.

4. Results of reviews may be used to support the development of remediation plans where control deficiencies are significant enough to warrant this approach.


2. Qualitative evaluation of this program’s effectiveness is determined by:



1. Whether operating divisions report successful completion of corrective actions related to the ICR team’s or analyst's recommendations within 180 days of report issuance.

2. Whether operating divisions implement new controls or measures based on ICR’s reviews.

3. When applicable, how external stakeholders such as TIGTA and GAO use or interpret the findings and recommendations of the ICR team or analyst and whether they find the analysis and recommendations thoughtful, insightful and comprehensive.

4. Whether TIGTA or GAO identifies other findings not identified by the ICR team or analyst during its reviews.


**1.4.32.1.5** **(09-26-2019)**

#### Program Controls

1. An employee’s access to the ICR SharePoint site is removed when an employee is no longer assigned to ICR. The site is protected by limiting access to those individuals who perform the reviews and manage the program.

2. Final reports are provided to the program owner upon completion of the review. Additional distribution by the program owner is based on specific requests from stakeholders.


**1.4.32.1.6** **(01-31-2022)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



1. **Internal control** \- Internal control (IC), which is synonymous with management control, is a major part of managing an organization. IC comprises the plans, methods and procedures used to meet missions, goals, and objectives and in doing so, supports performance-based management. IC also serves as the first line of defense in safeguarding assets and preventing and detecting errors and fraud and helps government program managers to achieve desired results through effective stewardship of public resources. Internal control systems provide reasonable assurance to achieve effectiveness and efficiency of operations, reliability of financial reporting and compliance with applicable laws and regulations. Reference GAO’s Green Book, page 5, for a more comprehensive definition of internal control.

2. **Internal control review** \- An internal control review assesses internal controls by analyzing programs, policies and procedures and their efficiency and effectiveness.

3. **Internal control weakness** \- A finding labeled as an Internal Control Weakness occurs when testing reveals the overall system of internal controls is ineffective.

4. **Management information only** \- A finding labeled as Management Information Only is designed to make management aware of a potential future issue that may arise if there are no improvements to controls.

5. **Opportunity for improvement** \- A finding labeled as an Opportunity for Improvement indicates that one or more individual controls are ineffective, but the overall system of controls is effective. Risk is no longer low but medium and consequently lessens the effectiveness of internal controls in daily operations.

6. **Risk** \- A risk is an event or potential event that may negatively affect the achievement of a business objective.

7. **Risk assessment** \- A risk assessment is an evaluation of the potential hazards, threats, or opportunities which could affect an organization’s ability to conduct business. The reviews help to identify inherent business risks and provide measures, processes, and controls to reduce or mitigate risks to business operations.


**1.4.32.1.7** **(02-17-2026)**

#### Acronyms

1. The following acronyms apply to this program.



|     |     |
| --- | --- |
| **Acronym** | **Meaning** |
| CAP | Corrective Action Plan |
| cICR | Comprehensive Internal Control Review |
| eICR | Exploratory Internal Control Review |
| FACT | Financial Assurance Control Testing |
| FMFIA | Federal Managers’ Financial Integrity Act |
| GAO | Government Accountability Office |
| IC | Internal Controls |
| ICR | Internal Control Review |
| ICW | Internal Control Weakness |
| IPU | IRM Procedural Updates |
| IR | Internal Reviews |
| MC ESC | Management Controls Executive Steering Committee |
| MIO | Management Information Only |
| OFI | Opportunity for Improvement |
| OMB | Office of Management and Budget |
| POC | Point-of-Contact |
| QAR | Quality Assurance Review |
| SA | Strategic Advisor |
| SAR | Strategic Advisory Review |
| SERP | Servicewide Electronic Research Program |
| SME | Subject Matter Expert |
| SOP | Standard Operating Procedure |
| TICP | Treasury Directive 40-04, Treasury Internal Control Program |


**1.4.32.1.8** **(09-26-2019)**

#### Related Resources

1. IRM 1.4.2, Monitoring and Improving Internal Control.


**1.4.32.2** **(09-26-2019)**

### Analytical Support

1. The ICR analysts consult with SMEs as needed for support and/or comments on testing methodology.


**1.4.32.3** **(01-31-2022)**

### Selection of Program Reviews

1. Each fiscal year, ICR updates the inventory of program reviews and selects a sample at its discretion.

2. The ICR list is an inventory from:



1. The Exploratory Internal Control Review (eICR) process, which requests preliminary information from the operating divisions pertaining to program internal controls in a focus area predetermined by the ICR program.

2. Topics created by ICR analysts and CFO leadership that are based on the risk profile, managerial interests, public interests and congressional priorities.

3. Program deficiencies identified in prior cICR’s, eICR’s or Strategic Advisory Reviews (SAR).

4. New IRS initiatives that the MC ESC or the Senior Executive Team has identified.

5. GAO and TIGTA audits identified as closed by Enterprise Audit Management.


3. Each fiscal year, ICR obtains a list of reviews that the IC QAR and FACT teams plan to perform to eliminate any duplication of efforts by ICR.


**1.4.32.4** **(09-26-2019)**

### Review Selection Notification

1. The ICR program notifies by email each operating division executive whose program ICR has selected for review.

2. The review notification:



1. Identifies the operating division selected for review;

2. Designates the review period;

3. Requests the names of SMEs and/or audit liaisons who will provide the necessary documentation and overview of the program; and

4. Provides a list of the documents that ICR will need for the review.


**1.4.32.5** **(02-17-2026)**

### Review Procedures and Services

1. There are three types of reviews: cICRs, eICRs and SARs. cICRs are more thorough and more in-depth, often take longer to complete and involve multiple testing methodologies for assessing internal controls. Management typically designates a two-person team to conduct a cICR. eICR’s are simpler or narrower in their objectives and scopes, tend to take less time to complete, and typically require less testing, relying near-exclusively upon interviews and document inspection to assess internal controls. Management typically designates a single ICR analyst to conduct an eICR. An SAR review is a streamlined review that specifically targets for analysis a potential area of risk with a limited scope while still providing applicable findings, observations and recommendations. Management typically designates a single ICR analyst to conduct an SAR, which is one of three different strategic advisory (SA) services that ICR offers.

2. The ICR process consists of four phases:



1. Planning:


       • 1-2 weeks for cICRs


       • 0-1 week(s) for eICRs


       • 0-1 week(s) for SARs

2. Fieldwork:


       • 1-4 weeks for cICRs


       • 1-2 weeks for eICRs


       • 0-1 week(s) for SARs

3. Reporting:


       • 1-3 weeks for cICRs


       • 1-2 weeks for eICRs


       • 0-1 week(s) for SARs

4. Close-out:


       • 1-2 weeks for cICRs


       • 0-1 week(s) for eICRs


       • 0-1 week(s) for SARs


A cICR typically takes no more than 12 weeks to complete, whereas an eICR typically takes no more than 6 weeks to complete and an SAR typically takes no more than 4 weeks to complete.

Should reporting delays occur, ICR managers and the respective operating division managers will be notified by their subordinate staff. If a review is put on hold (either by ICR or the operating division), all participants will be notified of the hold, why the hold occurred, and whether or when the review will resume.


3. Prior to initiating a program review, the ICR team or analyst will spend time getting to know and understand the program and the key program controls. The ICR team or analyst will use the following sources:



1. A description of key processes, which includes examples of the processing documents (for example, flowcharts, cycle memos and desk guides).

2. Policies and procedures governing transactions such as laws, regulations, IRMs, interim guidance memoranda, Servicewide Electronic Research Program (SERP) IRM procedural updates (IPU), and standard operating procedures (SOP).

3. External and internal reporting reviews (for example, reports issued by GAO or TIGTA).

4. Congressional hearings or testimonies.


4. The ICR team or analyst uses the information obtained to construct a framework and general review plan. This framework will outline the objectives and scope of the review and identifies areas that the review team or analyst will evaluate. Additionally, the framework provides the review team the flexibility to identify and pursue new leads or areas of significant concern identified during the review. The framework and review plan guides the overall review but should not constrain it.

5. To conduct the review, the ICR team or analyst will, as appropriate:



01. Issue an Engagement Memorandum;

02. Conduct an opening conference with the POC or designated liaison;

03. Request that the POC provide contact information for the SME along with an overview of the controls currently in place and how often management reviews the controls;

04. Conduct a detailed interview;

05. Obtain procedural manuals from the POC and/or SME (for example, IRMs, SOPs and desktop/technical manuals) and back up documentation from external audit sources (for example, internal examination reports and TIGTA or GAO audit reports);

06. Request source documents such as raw data, transcripts, tax forms, logs, and case files;

07. Observe demonstrations of the program activity utilizing various media (for example, face-to-face and video technology) and transaction reporting;

08. Conduct walkthrough procedures including a combination of inquiry, observation, inspection of relevant documentation, and re-performance of controls. In performing a walkthrough, the ICR analyst will question personnel about their understanding of the prescribed procedures and controls involved in performing the daily work;

09. Re-perform activities using source documents to check the procedural steps (for example, re-adding the total of a line of numbers to determine consistency);

10. Evaluate the operating effectiveness of key internal controls by completing the ICR Assessment Tool; and

11. Conduct a closing conference at the end of the review with management to discuss draft review findings and recommendations.


6. The three Strategic Advisory service options that ICR offers assess the effectiveness and efficiency of internal controls. An operating division may request SA services or an ICR team or analyst may recommend them.



1. The Internal Controls (IC) Toolkit helps the operating divisions to enhance their business processes and reinforce internal controls. It, among other things, allows the user to assess processes independently and to evaluate the effectiveness of existing and new internal controls. Upon using the toolkit, the management of an operating division may determine a need for further assistance and may request of ICR either further SA services or a cICR.

2. A Strategic Advisory Review (SAR) report is a service where a Strategic Advisor takes a consultative approach to examine a specific program area, function, or process and identifies or attempts to ameliorate an internal control deficiency or addresses a potential area of risk with a limited scope. An SAR makes for a swift and streamlined review with applicable findings, observations, and recommendations. An operating division official can submit a request for an SAR (or a cICR) by filling out the appropriate request form. (The operating division can also request an Internal Controls presentation if desired.) Once the operating division official submits the request form, the SA team will contact the requesting operating division official to schedule an initial consultative meeting to determine, discuss, and explain next steps.

3. A Corrective Action Plan (CAP) is a document that provides support to operating divisions’ stakeholders by assisting them in implementing recommendations meant to remediate internal control deficiencies identified during or by a cICR, SAR, use of the IC Toolkit, or other method. If an operating division wishes, its management can coordinate with the SA team or analyst to determine how best to implement new or strengthened internal controls and then fill out the appropriate SA CAP form.


**1.4.32.6** **(01-31-2022)**

### Reporting Process

1. After the ICR team or a team of analysts analyzes the data gathered, they will draft a report. The report will provide findings and/or recommendations identified during the review. Once ICR leadership sends a report draft to an approval authority and the approval authority provides edits and feedback (within five business days), the report author has a maximum of three business days to make any necessary changes. Once the report author makes the changes, the report is returned to the appropriate approval authority. This step is conducted as many times as needed until a report is released to the operating division.

2. The ICR analyst shares the report with the appropriate officials. If the ICR analyst noted findings during the review, the report addresses the findings as one of the following:



1. Management Information Only (MIO) - Designed to make management aware of a potential future issue that may arise if there are no improvements to controls.

2. Opportunity for Improvement (OFI) - Indicates that one or more individual controls are ineffective, but overall system of controls is effective. Risk is no longer low but medium and consequently lessens the effectiveness of internal controls in daily operations.

3. Internal Control Weakness (ICW) - Occurs when testing reveals the overall system of internal controls to be ineffective.


3. Recommendations will follow the conclusions and opinions that are supported by the analysis.


**1.4.32.7** **(02-17-2026)**

### Report Approval Process

1. The ICR analyst will submit all draft review reports for review, edits, and/or final approval by submitting them to each official in the chain of review in the following order, as appropriate:



1. SAR - Respective ICR Section Chief and then the Director of Internal Reviews.

2. eICR - Respective ICR Section Chief and then the Director of Internal Reviews.

3. cICR - Respective ICR Section Chief, Director of Internal Reviews, and then the Associate CFO for Internal Controls.

4. Reviews with Deputy Commissioner or Commissioner-level information - Reports will be approved by CFO. Anything requiring CFO approval will be transmitted via e-Trak.


2. Each approving official has five business days to review, edit, and/or approve any given draft report. If edits are necessary, the approving official will return the draft report to the author for corrections. If no edits are warranted, the approving official will approve and/or sign the draft report and send it to the next approving official in the chain of review.


**1.4.32.8** **(02-17-2026)**

### Operating Division Post Review

1. Operating division program owners and executives receive a report from the ICR team describing the team’s or analyst’s findings and recommendations once the review is complete. ICR provides recommendations to help operating divisions to identify areas where they should address control deficiencies and to provide a general framework that operating divisions may use for strengthening internal controls. Operating divisions generally have one week to review the report and provide comments for ICR to consider before issuing the final report.

2. Operating divisions should take the following steps once they receive the ICR team’s report:



1. Develop and implement corrective actions to address the findings and recommendations provided in the final report.

2. Assess and document the degree to which a control deficiency represents a risk if the operating division(s) will not take corrective actions.

3. Include any risks identified in the operating division’s risk register.

4. Retain any documentation created as part of post-review corrective actions or risk documentation/mitigation activities.


3. The ICR team may conduct a follow-up engagement with the operating division to ascertain the outcome of the steps described above. This follow-up engagement may include review of the corrective actions and accompanying documentation by the operating division, or other steps up to and including an additional subsequent comprehensive ICR. The timing and nature of any follow-up will depend on several factors, including the severity of control deficiencies, the nature of the program that ICR reviewed and the likelihood external that stakeholders will subject the program to significant scrutiny.

4. Operating divisions should also consider these internal control improvement tips:



1. Reevaluate controls periodically, especially when there are changes to personnel, work processes, business operations, and regulations that may affect the operating division.

2. Streamline monitoring processes to reduce burden and improve accountability.

3. Monitor and mitigate risk using data-driven approaches.

4. Involve employees in identifying and mitigating risk.


5. Examples of control monitoring:



1. Considering Disclosure/Privacy Act implications in all activities, including reviews of files and personnel folders.

2. Performing risk reviews.

3. Conducting quality assurance reviews.

4. Initiating timely background and security investigations and taking appropriate action based on the outcome of the investigations.

5. Monitoring telephone traffic volumes to ensure timely customer service.

6. Reviewing assignment of portable electronic devices such as laptop computers, cellular/personal communications’ system devices, audio/video/data recording or playback devices, scanning devices, and messaging devices to ensure safeguarding of these devices and the data that they contain and/or to ensure that the employees who possess them still have a business need for them.


**1.4.32.9** **(09-26-2019)**

### Records Retention/Accessibility of Reports

1. ICR maintains its reports on the ICR SharePoint site.

2. ICR maintains its electronic records in accordance with the following IRS electronic records retention policies:



1. IRM 1.15.1, The Records and Information Management Program.

2. IRM 2.25.2, IRS Integrated Enterprise Portal Usage Standard

3. IRM 10.5.1, Privacy Policy

4. IRM 10.5.2.3.1, FISMA Reporting

5. IRM 11.1.4, Content Policies and Standards for Intranet Sites


3. Records retention should be in accordance with the National Archives and Records Administration (NARA), General Records Schedule 5.7: Administrative Management and Oversight Records (https://www.archives.gov/records-mgmt/grs.html).


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-032#addtoany "Show all")

A2A