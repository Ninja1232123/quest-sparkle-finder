---
url: "https://www.irs.gov/irm/part1/irm_01-001-033"
title: "1.1.33 Taxpayer Experience Office | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-033#main-content)

- 1.1.33  [Taxpayer Experience Office](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263534544)
  - 1.1.33.1  [Introduction to the Taxpayer Experience Office (TXO)](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263453296)
  - 1.1.33.2  [Chief of Staff Office (CoS)](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263582704)
  - 1.1.33.3  [Operations Liaison Office (OLO)](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263579968)
  - 1.1.33.4  [Portfolio Management Office (PMO)](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263577344)
  - 1.1.33.5  [Community Engagement Office (CEO)](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263574384)
  - 1.1.33.6  [Insight and Analytics Office (IAO)](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263571728)
  - 1.1.33.7  [Multi-Channel Experience Office (MCXO)](https://www.irs.gov/irm/part1/irm_01-001-033#idm139932263568624)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 33. Taxpayer Experience Office

* * *

## 1.1.33 Taxpayer Experience Office

#### Manual Transmittal

September 18, 2024

#### Purpose

(1) This transmits revised IRM 1.1.33, Organization and Staffing, Taxpayer Experience Office.

#### Material Changes

(1) IRM 1.1.33.1, Introduction to the Taxpayer Experience Office - Updated the title from Chief, Taxpayer Experience Office (TXO) to Introduction to the Taxpayer Experience Office (TXO).

(2) IRM 1.1.33(3), Introduction to the Taxpayer Experience Office - Updated section to state the Chief and Deputy Chief TXO have equal delegated authority to authorize and approve matters related to TXO programs and operations.

(3) IRM 1.1.33.4(1), Portfolio Management Office (PMO) - Updated section to align with the organization’s mission and vision.

#### Effect on Other Documents

IRM 1.1.33 dated 08-23-2023 is superseded.

#### Audience

All IRS organizations

#### Effective Date

(09-18-2024)

Fumino Tamaki

Chief, Taxpayer Experience Officer

Taxpayer Experience Office

**1.1.33.1** **(09-18-2024)**

### **Introduction to the Taxpayer Experience Office (TXO)**

1. The mission of the Taxpayer Experience Office (TXO) is to enrich all IRS interactions through an IRS wide customer-centric approach.

2. The vision of the TXO is to ensure all IRS customers are empowered and supported when engaging with the IRS.

3. The Chief Taxpayer Experience Officer (CTXO) reports directly to the Commissioner of the IRS and the Deputy Chief Taxpayer Experience Officer (DCTXO) reports directly to the CTXO. The Chief and Deputy TXO have equal delegated authority to authorize and approve matters related to TXO programs and operations.

4. The CTXO and DCTXO oversee the execution of a full range of activities to support the TXO mission. The TXO develops customer-centric guidelines and expectations to improve IRS interactions across all segments to ensure a consistent voice and experience. The TXO is organized into six functions:



1. Chief of Staff Office (CoS)

2. Operations Liaison Office (OLO)

3. Portfolio Management Office (PMO)

4. Community Engagement Office (CEO)

5. Insight and Analytics Office (IAO)

6. Multi-Channel Experience Office (MCXO)


5. To carry out the mission, the CTXO and DCTXO:



1. Support the strategic operating plan initiatives to ensure efforts incorporate a customer experience perspective.

2. Serve as the Customer Experience (CX) Center of Excellence to ensure interactions are designed and enriched through a customer-centric approach, with a focus toward continuous improvement.

3. Promote human-centered design by developing IRS wide CX standards.

4. Work closely with partners from across the IRS to drive continuous improvement of the IRS CX.

5. Facilitate the CX training delivery.

6. Host the CX Community of Practice.

7. Provide organizational units with guidance on the latest CX frameworks.

8. Support CX projects for the full scope of IRS interactions.


6. For more information, view the TXO At-a-Glance at [https:www.irs.gov/experienceoffice](https://www.irs.gov/about-irs/taxpayer-experience-office-at-a-glance).


**1.1.33.2** **(09-18-2024)**

### **Chief of Staff Office (CoS)**

1. The mission of the Chief of Staff Office (CoS) is to provide administrative and executive support, maintain oversight controls, evaluate legislative implementation and perform special assignments to support the CTXO, DCTXO and the TXO.

2. The TXO CoS reports to the DCTXO.


**1.1.33.3** **(09-18-2024)**

### **Operations Liaison Office (OLO)**

1. The mission of the Operation Liaison Office (OLO) is to provide the TXO efficient and effective planning, coordination, and execution of operations services and support.

2. The TXO OLO reports to the DCTXO.


**1.1.33.4** **(09-18-2024)**

### **Portfolio Management Office (PMO)**

1. The mission of the Portfolio Management Office (PMO) is to lead the oversight for the CX project portfolio. The PMO manages delivery schedules, scope and resources related to CX projects to support the TXO’s mission and vision.

2. The TXO PMO reports to the DCTXO.


**1.1.33.5** **(09-18-2024)**

### **Community Engagement Office (CEO)**

1. The mission of the Community Engagement Office (CEO) is to partner with IRS stakeholders to gather insights to improve CX through outreach and education.

2. The TXO CEO reports to the DCTXO.


**1.1.33.6** **(09-18-2024)**

### **Insight and Analytics Office (IAO)**

1. The mission of the Insight and Analytics Office (IAO) is to support data driven decision making by coordinating with data functions and business operating divisions to identify and evaluate issues and trends, critical datasets, and measures and metrics to support TXO’s mission and vision statements.

2. The TXO IAO reports to the DCTXO.


**1.1.33.7** **(09-18-2024)**

### **Multi-Channel Experience Office (MCXO)**

1. The mission of the Multi-Channel Experience Office (MCXO) is to facilitate the improvement of the CX by understanding the customer’s needs, expectations, and feedback. MCXO will help identify insights and recommendations to enrich the CX through collaboration with internal and external stakeholders.

2. The TXO MCXO reports to the DCTXO.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-033#addtoany "Show all")

A2A