---
url: "https://www.irs.gov/irm/part1/irm_01-013-001"
title: "1.13.1 Statistical Reporting | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-013-001#main-content)

- 1.13.1 [Statistical Reporting](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960175456)
  - 1.13.1.1 [Statistical Reporting Overview](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960937520)
    - 1.13.1.1.1 [Legislative Authority for SOI Programs](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960932656)
    - 1.13.1.1.2 [SOI Studies and Reports](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960922864)
  - 1.13.1.2 [Statistical Processing Instructions](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960106656)
  - 1.13.1.3 [Coverage](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960085808)
  - 1.13.1.4 [Sampling](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960078016)
  - 1.13.1.5 [Requests for Tax Returns from Other Functions](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960069632)
    - 1.13.1.5.1 [Submission Processing Center Action](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960062352)
    - 1.13.1.5.2 [Photocopying](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960058720)
  - 1.13.1.6 [In-Services Requests for Statistical Services](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960055424)
    - 1.13.1.6.1 [Written SpecificationsIn Service Requests](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960051584)
    - 1.13.1.6.2 [Signature Authority for In-Service Requests](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960047872)
  - 1.13.1.7 [Statistical ServicesOut-Service Requests](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960044672)
    - 1.13.1.7.1 [Request ProcessOut-Service Requests](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960039680)
  - 1.13.1.8 [Requests for Previously Disseminated Statistical Data](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960028800)
  - 1.13.1.9 [Delegations of Authority for Reimbursable Services](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960025152)
  - 1.13.1.10 [SOI Requests for Out-Service Statistical Services](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960020672)
  - 1.13.1.11 [SOI Records Management](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960017600)
  - Exhibit 1.13.1-1 [Statistics of Income Performance Measures](https://www.irs.gov/irm/part1/irm_01-013-001#idm139947960011360)

# Part 1. Organization, Finance, and Management

# Chapter 13. Statistics of Income

# Section 1. Statistical Reporting

* * *

## 1.13.1 Statistical Reporting

#### Manual Transmittal

August 30, 2018

#### Purpose

(1) This transmits revised IRM 1.13.1, Statistics of Income, Statistical Reporting.

#### Material Changes

(1) This IRM section was revised to provide the current instructions and procedures for producing information for the SOI program. It also includes processes for other offices to request returns and for in-service and out-service customers to request and receive program products.

1. Section 1.13.11 was updated to remove the reference to IRM 1.15.25, which is now obsolete. A reference to the new Records Schedule, Document 12990, was added.


(2) Added Exhibit 1.13.1-1, which details SOI’s performance measures reporting.

#### Effect on Other Documents

IRM 1.13.1, dated December 3, 2015, is superseded.

#### Audience

Submission Processing Centers

#### Effective Date

(08-30-2018)

Barry W. Johnson

Director

Statistics of Income

**1.13.1.1** **(12-03-2015)**

### **Statistical Reporting Overview**

1. 1) This IRM section provides procedures and information to National Headquarters and Submission Processing Center employees about the services and programs provided by the Statistics of Income (SOI) office. It describes the IRS statistical programs, procedures for providing information to the Submission Processing centers, and the processes for in-service and out-service requests. It also covers delegations of authority for reimbursable services.

2. SOI is an office in Research, Applied Analytics, and Statistics (RAAS) and conducts the IRS statistical programs. As part of its responsibilities, SOI programs and services include:



   - Selecting data for the SOI samples

   - Collecting and disseminating SOI statistical data

   - Making SOI returns available to other IRS functions

   - Statistical processing of returns selected for the SOI samples


**1.13.1.1.1** **(12-03-2015)**

#### Legislative Authority for SOI Programs

1. Since 1916, SOI has been authorized to prepare a series of reports and publications in accordance with IRC 6108, Statistical Publications and Studies.

2. SOI programs fulfill a statutory requirement for producing statistics on the operation of the tax law under IRC 6108, Statistical publications and studies. Under IRC 6108(a), "the Secretary shall prepare and publish not less than annually statistics reasonably available with respect to the operations of the internal revenue laws, including classifications of taxpayers and of income, the amounts claimed or allowed as deductions, exemptions, and credits, and any other facts deemed pertinent and valuable."

3. SOI performs related research and other statistical functions needed to meet this requirement. SOI also assists in the quality measurement programs of the Service.

4. SOI programs include studies of:



   - Individual tax return statistics

   - Corporate tax return statistics

   - Special studies, including exempt organization, estate and gift, and international tax return statistics


5. Implementation of programs occurs in the



   - SOI office in the National Headquarters

   - Submission Processing Centers

   - Martinsburg Computing Center


6. SOI also furnishes technical guidance and direction to the submission processing centers and Martinsburg Computing Center to implement the SOI programs. Such guidance may be related to any phase of the statistical work, including the identification of problems and the development of solutions, and often requires written procedures, including those necessary for the selection of samples.

7. To assure that program implementation is correct, SOI evaluates the SOI work performed by the submission processing centers through:



   - Quality assurance programs

   - Internal audit reports, and

   - On-site reviews of the SOI field processing operation.


**1.13.1.1.2** **(12-03-2015)**

#### SOI Studies and Reports

1. SOI conducts special statistical studies based on tax returns or performs certain functions related to statistical studies, often on a reimbursable basis. In the latter capacity, it provides data to agencies and individuals authorized by the Internal Revenue Code to receive tax return information for statistical use.

2. Major SOI products include the annual SOI reports compiled from individual and corporation income tax returns, which feature income statement, balance sheet and tax data by industry and form type. Customers most frequently use:



1. Individual Tax Return data - Number of returns; sources of income; statutory adjustments to income and itemized deductions by type; personal exemptions; tax liability and tax credits classified by taxable and nontaxable returns or by size of adjusted gross income or tax rate.

2. Corporate Tax Return data - Number of returns; receipts and deductions by type; net income; tax liability and tax credits; and assets and liabilities classified by industry groups, returns with net income, and size of total assets or business receipts.


3. SOI also compiles a "Source Book" of corporation statistics, by asset size for more detailed industries than those included in the published annual report.

4. SOI also compiles historical data tables for corporations, sole proprietorships, and partnerships. Most SOI studies are summarized for public use in the _SOI Bulletin_. The _Bulletin_ includes



   - Data formerly published in separate reports,

   - Summary analyses of previously published tabulations, and

   - Results of special studies and analyses


5. Copies of SOI reports for official use are distributed



   - Throughout the IRS

   - Within the Treasury Department, and

   - To certain other Federal Government users, including the Congressional Joint Committee on Taxation (JCT).


6. SOI makes its reports available to the general public on [http://www.irs.gov/uac/Tax-Stats-2](http://www.irs.gov/uac/Tax-Stats-2). These Web pages include annual reports, Source Books, historical data, SOI Bulletins, tabulations, and microdata files for tax-exempt organizations.

7. SOI produces public-use files as a by-product of some of its programs. In most cases, because of the need to preserve taxpayer confidentiality, the files consist of tabulated data on the Tax Stats Web pages. However, the Web pages include individual records for tax-exempt organizations, which are required to make their returns available to the public. Additionally, SOI produces a public-use file of individual income tax returns, which contains separate tax return records, stripped of identifying information and edited to prevent disclosure.


**1.13.1.2** **(12-03-2015)**

### **Statistical Processing Instructions**

1. (1) The following IRM sections provide statistical processing instructions issued by the Statistics of Income office.



|     |     |     |     |
| --- | --- | --- | --- |
| Program Area | IRM Section | Summary | Audience |
| Individual Tax Returns | 3.49.5 | Individual Returns Statistical Processing | Submission Processing Centers |
| NAICS Coding | 3.49.6 | North American Industry Classification System (NAICS) coding for Statistical Processing | Submission Processing Centers |
| Corporate Tax Returns | 3.49.7 | Corporate Returns Statistical Processing | Submission Processing Centers |

2. IRM 3.49.5, Statistical Editing of Individual Tax Returns provides instructions for statistical processing and editing from individual income tax returns for use by submission processing centers, computing centers, and the National Headquarters. The instructions include statistical processing procedures for math error correction, reporting discrepancy correction, and statistical coding.

3. IRM 3.49.6 and IRM 3.49.7 provide instructions for statistical processing from corporation income tax returns and related forms and schedules for use by submission processing centers, Computing Centers, and the National Headquarters office. Also included are instructions for performing other functions, including quality review, necessary for the complete statistical processing of the returns.



1. IRM 3.49.6, _Industry Coding_, includes instructions for statistical coding of corporate returns using the North American Industry Classification System.

2. IRM 3.49.7, _Form 1120 Statistical Editing_, includes procedures for statistical processing and editing of corporate tax income tax returns. The instructions include statistical processing procedures for math error correction, reporting discrepancy correction, and statistical coding.


**1.13.1.3** **(12-03-2015)**

### **Coverage**

1. SOI compiles comprehensive data from individual income tax returns annually in both "preliminary" and final form.

2. The Treasury Department Office of Tax Analysis (OTA) and Joint Committee on Taxation (JCT) receive Advance Data tabulations based on an early cutoff of the sample receipts. The cutoff is Individual Master File posting cycle 39. (This same cutoff is then used for the "preliminary" ' data released to the public).

3. SOI also compiles data from:



1. Corporations, non-farm sole proprietorships and partnerships annually and development of these data is funded, in part, by the Department of Commerce. The data include business receipts, net income, and other selected financial items, by industry groups.

2. Estate tax and gift tax returns and tax-exempt organization and bond returns annually.

3. Other types of returns, such as certain international returns, are compiled occasionally.


4. SOI regularly produces estimates of personal wealth based on estate tax returns. This information is classified by age, sex, marital status and type of wealth for that segment of the population for which an estate tax return would be required in the event of death.

5. SOI also undertakes special studies to link together data from certain returns, e.g., estate tax returns with individual income tax returns.

6. SOI provides results of all of these studies to OTA and the JCT, and most are summarized for release in the [SOI Bulletin](http://www.irs.gov/uac/SOI-Tax-Stats-SOI-Bulletins).


**1.13.1.4** **(12-03-2015)**

### **Sampling**

1. SOI programs are generally based on samples of returns obtained from the Master File system. In order to obtain the required data, a plan for sampling is devised each year for the various types of returns included in the programs.

2. SOI issues editing instructions that describe data collection procedures, and provide specifications for computing weighting factors and sampling variability.

3. SOI issues computer specifications packages that include instructions for electronic selection of SOI sampled returns at the Martinsburg Computing Center and at the Ogden Submission Processing Center. IRM 1.13.3, _Document Management_, includes instructions to submission processing centers for selecting sample returns or for processing electronically selected samples.

4. IRM 1.13.3 includes further instructions to all submission processing centers for securing, maintaining, and controlling sample returns and issues sampling specifications or provides sampling information to specific submission processing centers. The IRM also includes controlling and shipping instructions. Also, sampling guidelines for some manual samples are included as part of revenue processing instructions.

5. Weekly sample selection summary reports are transmitted from the Martinsburg Computing Center to SOI as a control on the completeness of the sample during statistical processing.



1. Expected sample totals are compared with actual sample totals to determine where sampling shortages exist and whether follow-up action is required.

2. These reports also contain data on the number of returns filed for use in developing the weighting factors used to produce preliminary or "final" SOI estimates.


6. Information which has been transcribed from the major types of returns for tax administration purposes is then combined with additional data needed for SOI. The data are then tested by SOI computer programs for completeness and accuracy and subsequent corrections are applied.

7. To complete its file of returns for a given year, SOI researches the status of return filings through electronic resources and field service center contacts, as necessary.


**1.13.1.5** **(12-03-2015)**

### **Requests for Tax Returns from Other Functions**

1. The RAAS Data Management Division creates computer images for SOI of most returns after receipt.

2. IRS offices, such as Examination, Collection, and Criminal Investigation, may urgently need a return in the SOI samples before statistical processing on the return has been completed.

3. Offices must submit an expedited request, in writing, to the submission processing center where the return was sampled (filed) by also completing:



   - Form 4251, _Return Charge-out_,

   - Form 2275, _Records Request, Charge and Recharge_,

   - Form 5546, _Examination Return Charge-out Sheet_, or

   - Some other written request.


**1.13.1.5.1** **(12-03-2015)**

#### **Submission Processing Center Action**

1. The submission processing center where the return was filed will take one of the following actions:



1. If the return is in the submission processing center being processed for statistics, the submission processing center will act on the request.

2. If the return has been forwarded to another submission processing center or SOI for statistical processing, the request will be forwarded to the appropriate organization for action.


**1.13.1.5.2** **(12-03-2015)**

#### **Photocopying**

1. Returns requested by other IRS offices may be photocopied or imaged and the photocopy or image may be statistically processed in lieu of the original. In this case, the original is sent immediately to the requester. Also, all pages of the return, plus any supporting schedules that may be attached to it, are photocopied or imaged for statistical processing.

2. As stated in IRM 1.13.3.1.3.3, such photocopying is not charged to SOI.

3. After statistical processing has been completed, the photocopy is destroyed.


**1.13.1.6** **(12-03-2015)**

### **In-Services Requests for Statistical Services**

1. The SOI Division provides assistance for "in-service requests" from other IRS offices.

2. Depending on the resources required and the timeframe involved, reimbursement for special tabulations from SOI databases by the originating IRS office may be necessary.

3. The SOI samples are used, in some cases, as the IRS quality measurement samples from which evaluations and analyses are made of the accuracy of tax return data transcribed for the Master File system.

4. SOI, when called upon, provides expert testimony in court cases in which data it compiles are an issue.


**1.13.1.6.1** **(12-03-2015)**

#### **Written Specifications—In Service Requests**

1. IRS requests for services from SOI for special studies or tabulations involving new projects or changes in recurring projects must be submitted in writing, with specifications as complete and defined as possible. Provide clear specifications that are mutually understandable to both the requester and the SOI project manager. Be sure to cover both the source and availability of the basic data, content, presentation, and timing of the results.

2. If assistance is needed. Division project managers will work out the specifications with the requester. Consulting with SOI at an early stage before plans are set will facilitate the undertaking of a study.

3. Specifications should clear and mutually understandable and should cover both the source and availability of the basic data and the content, presentation, and timing of the results.


**1.13.1.6.2** **(12-03-2015)**

#### **Signature Authority for In-Service Requests**

1. Submit in-service requests to the Director, SOI.

2. Requests from National Headquarters Divisions should be addressed to the Director, SOI Division, and signed by the Director), National Director, or Business Operating Division Commissioner.

3. Requests from other IRS offices should be signed by the appropriate Director or Business Operating Division Commissioner.


**1.13.1.7** **(12-03-2015)**

### **Statistical Services—Out-Service Requests**

1. IRC 6108 authorizes:



1. Statistics, in anonymous form, reasonably available with respect to the operation of the internal revenue laws (IRC 6108(a) and IRC 6108(c)); and

2. Special statistical studies and compilations at the request of any party or parties, provided taxpayer return information is presented in unidentifiable form. A reasonable fee may be prescribed for the cost of the work or services performed for such party or parties (IRC 6108(b) and IRC 6108(c)).


2. SOI reserves the right to publish tabulations from the special studies which it conducts under IRC 6108(b).

3. SOI assists in negotiating and coordinating reimbursable agreements under IRC 6108(b) involving release of identifiable taxpayer information to Federal agencies authorized under IRC 6103(j) to receive such information for statistical use, subject to the conditions set forth in that Code section.


**1.13.1.7.1** **(12-03-2015)**

#### **Request Process—Out-Service Requests**

01. All requests for special statistical studies that do not require release of identifiable taxpayer information must be in writing to the Director, SOI unless otherwise specified below.

02. Requests for taxpayer data in unidentifiable form by Federal agencies that are also authorized access to specific identifiable taxpayer information for statistical purposes under IRC 6103 must be in writing to the Commissioner and be coordinated by SOI with the Office of Governmental Liaison and Disclosure (GLD).

03. Requests for identifiable taxpayer data (or for special statistical studies requiring taxpayer data in identifiable form) by either the Department of Commerce (i.e., Bureau of Economic Analysis or Bureau of the Census) which is authorized access to certain identifiable taxpayer data for specified statistical purposes (IRC 6103(j)) or the Social Security Administration which is authorized similar access for purposes of administering the social security laws (IRC 6103(l)), must be in writing and must be coordinated by SOI with the Office of GLD.

04. By agreement, annual requests from the Census Bureau from the Secretary are directed to the Commissioner Internal Revenue. Address requests outside the scope of annual requests to the Treasury Secretary.

05. In the case of the Bureau of Economic Analysis or the Social Security Administration, the written requests may be to the Commissioner of Internal Revenue (as the Secretary's delegate) from the Secretary of Commerce or from the Commissioner, Social Security Administration, respectively.

06. Requests by Treasury for taxpayer data in identifiable form for tax administration purposes (defined in IRC 6103(b)) do not have to be in writing (IRC 6103(h)). IRC 6103(j)(3) sets forth conditions under which certain requests must be in writing if they require access to taxpayer data in identifiable form for statistical use.

07. Requests for identifiable taxpayer data (or for statistical studies requiring taxpayer data in identifiable form) by the JCT (IRC 6103(f)) must be in writing to the Commissioner from the Chairman of the Committee or from its Chief of Staff.



    1. By agreement, written requests for data on taxpayers whose returns are included in the SOI samples are required in order to establish the names of JCT staff members who will have access to such data. Thereafter, written requests are required only to revise this list of names.

    2. For identifiable data on taxpayers other than those whose returns are included in the SOI samples, written requests are required on each occasion.

    3. SOI must coordinate written requests or agreements with the Office of Disclosure, Disclosure Litigation Division, or Legislative Affairs Division, as necessary.


08. Requests by other committees of Congress (IRC 6103(f)) for identifiable data (or for statistical studies requiring taxpayer data in identifiable form) must be in writing to the Commissioner and can be signed only by the Committee Chairman. SOI must coordinate such requests with the Office of Disclosure, Disclosure Litigation Division, or Legislative Affairs Division, as necessary.

09. Requests for data in either identifiable or unidentifiable form by State tax administrators must be coordinated by the SOI with the Office of Privacy, Governmental Liaison, and Disclosure.

10. Besides the coordination for purposes of avoiding possible unauthorized disclosure of identifiable taxpayer information, the SOI must make the appropriate arrangements for coordinating the statistical requests it receives that require use of data processing facilities or other resources in the field offices, submission processing centers, or Martinsburg Computer Center.


**1.13.1.8** **(12-03-2015)**

### **Requests for Previously Disseminated Statistical Data**

1. Requests for statistical data will not be considered to be requests for special statistical studies or compilations if:



1. They are contained in reports or releases already disseminated outside the Service, or

2. The request can be readily compiled from available source data with so small an expenditure of time as to be considered normal to the preparation of replies to the request.


**1.13.1.9** **(12-03-2015)**

### **Delegations of Authority for Reimbursable Services**

1. Delegation Order No. DO-1-13, as revised, Furnishing Special Statistical Studies, Compilations, Return and Return Information, Training, and Training Aids, delegates to the Director, SOI:



1. To commit resources for statistical work (of the type described in Commissioner's Delegation Order No. DO 1-13) by SOI from Activity 62 funds and to approve reimbursable agreements upon the written request of any person or organization desiring releasable information available from the SOI program or from databases maintained by SOI for statistical purposes and willing to pay for the cost of work to be performed.

2. Such approval will be subject to the availability of resources. The work performed must not in any way interfere with higher-priority assignments of the Division.

3. This authority may not be redelegated.


**1.13.1.10** **(12-03-2015)**

### **SOI Requests for Out-Service Statistical Services**

1. Under IRC 6103(n), SOI may contract out the special statistical services mentioned in that section in connection with statistical studies relating to the operation of the internal revenue law (IRC 6108(a)) that are considered necessary for tax administration (IRC 6103(b)). Identifiable taxpayer information may be disclosed to a contractor for such studies, subject to prescribed rules and regulations.

2. SOI may not contract out the statistical services mentioned in IRC 6103(n) if they are in connection with non-tax administration related special studies and compilations allowed under IRC 6108(b), even if the results are in unidentifiable form.


**1.13.1.11** **(08-30-2018)**

### **SOI Records Management**

1. Since SOI is responsible for much of the historical records and historical information generated by the Service, it must maintain an accurate and current records retention schedule. [Document 12990](http://publish.no.irs.gov/cat12.cgi?request=CAT2&itemtyp=D&itemb=12990&items=*) describes the SOI records control schedule.

2. This schedule must provide for identifying permanent records to be preserved and for identifying and scheduling temporary records to be destroyed. Identification and scheduling must be coordinated with the appropriate Headquarters Operations staff and, as appropriate, with the appraisal staff of the National Archives and Records Administration.

3. Records for this purpose include statistical reports and releases and tabulations or tax return records used for statistical purposes in whatever mode: hard copy, microfilm, microfiche, or digital files.

4. Records also include corresponding instructional materials or documentation, such as procedures used for statistical sampling, coding, editing, and validating, and information to facilitate use of computer tape/disk files.

5. In addition, records include program and subject files, e.g., correspondence and reports and related papers concerning the administration of the SOI and its programs.

6. Records retention schedules applicable to the SOI and its programs are contained in the Records Control Schedule.


**Exhibit 1.13.1-1**

### Statistics of Income Performance Measures

Quality and timeliness performance measures for SOI are captured in IRM .13.2. The Division reports on additional measures annually in its Performance Measures document. Details on the manner in which these measures are tracked are listed in Exhibit 1.13.1-1.

|     |     |
| --- | --- |
| **Performance Measure** | **Location** |
| Program Completion Dates | IRM 1.13.2 |
| Number of Missing Returns | IRM 1.13.2 |
| Quality Measures for Statistical Processing | IRM 1.13.2 |
| Relevance | Annual Performance Measures Report |
| File Delivery and Public Release Dates | Annual Performance Measures Report |
| Dissemination -- Number of Deliverables | Annual Performance Measures Report |
| Dissemination -- Number of Site Visits and Downloads | Annual Performance Measures Report |
| Mission Achievement -- Timeliness of File Deliveries and Data Releases | Annual Performance Measures Report |
| Mission Achievement -- Customer Satisfaction | Annual Performance Measures Report |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-013-001#addtoany "Show all")

A2A