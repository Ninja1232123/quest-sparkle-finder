---
url: "https://www.irs.gov/irm/part1/irm_01-017-010"
title: "1.17.10 IRS Published Product Identification | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-017-010#main-content)

- 1.17.10  [IRS Published Product Identification](https://www.irs.gov/irm/part1/irm_01-017-010#id1)
  - 1.17.10.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-017-010#id2)
    - 1.17.10.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-017-010#id4)
    - 1.17.10.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-017-010#id5)
    - 1.17.10.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-010#id6)
    - 1.17.10.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-017-010#id7)
    - 1.17.10.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-017-010#id8)
    - 1.17.10.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-017-010#id9)
    - 1.17.10.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-017-010#id10)
  - 1.17.10.2  [Product Identification Components](https://www.irs.gov/irm/part1/irm_01-017-010#id11)
  - 1.17.10.3  [Item IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id12)
    - 1.17.10.3.1  [Assigning Item IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id13)
    - 1.17.10.3.2  [Item ID Status](https://www.irs.gov/irm/part1/irm_01-017-010#id14)
    - 1.17.10.3.3  [Type of Use Categories](https://www.irs.gov/irm/part1/irm_01-017-010#id15)
    - 1.17.10.3.4  [Item Types](https://www.irs.gov/irm/part1/irm_01-017-010#id16)
      - 1.17.10.3.4.1  [Item Type and Type of Use](https://www.irs.gov/irm/part1/irm_01-017-010#id17)
        - 1.17.10.3.4.1.1  [Tax Products](https://www.irs.gov/irm/part1/irm_01-017-010#id19)
        - 1.17.10.3.4.1.2  [Non-Tax Products](https://www.irs.gov/irm/part1/irm_01-017-010#id20)
        - 1.17.10.3.4.1.3  [Item Types and Type of Use Table](https://www.irs.gov/irm/part1/irm_01-017-010#id21)
      - 1.17.10.3.4.2  [Forms](https://www.irs.gov/irm/part1/irm_01-017-010#id22)
        - 1.17.10.3.4.2.1  [Form Types](https://www.irs.gov/irm/part1/irm_01-017-010#id23)
          - 1.17.10.3.4.2.1.1  [Public-Use Forms](https://www.irs.gov/irm/part1/irm_01-017-010#id25)
          - 1.17.10.3.4.2.1.2  [Internal-Use Forms](https://www.irs.gov/irm/part1/irm_01-017-010#id26)
          - 1.17.10.3.4.2.1.3  [Standard and Optional Forms](https://www.irs.gov/irm/part1/irm_01-017-010#id27)
      - 1.17.10.3.4.3  [Repository Form Letters](https://www.irs.gov/irm/part1/irm_01-017-010#id28)
      - 1.17.10.3.4.4  [Repository Notices](https://www.irs.gov/irm/part1/irm_01-017-010#id29)
      - 1.17.10.3.4.5  [Instructions](https://www.irs.gov/irm/part1/irm_01-017-010#id30)
      - 1.17.10.3.4.6  [Documents](https://www.irs.gov/irm/part1/irm_01-017-010#id31)
      - 1.17.10.3.4.7  [Publications](https://www.irs.gov/irm/part1/irm_01-017-010#id32)
        - 1.17.10.3.4.7.1  [Publication Types](https://www.irs.gov/irm/part1/irm_01-017-010#id34)
      - 1.17.10.3.4.8  [Envelopes](https://www.irs.gov/irm/part1/irm_01-017-010#id35)
      - 1.17.10.3.4.9  [Internal Revenue Manual (IRM)](https://www.irs.gov/irm/part1/irm_01-017-010#id36)
      - 1.17.10.3.4.10  [Training Publications](https://www.irs.gov/irm/part1/irm_01-017-010#id37)
      - 1.17.10.3.4.11  [Other Government Agency (OGA) Products](https://www.irs.gov/irm/part1/irm_01-017-010#id38)
      - 1.17.10.3.4.12  [Templates](https://www.irs.gov/irm/part1/irm_01-017-010#id39)
      - 1.17.10.3.4.13  [Miscellaneous Products](https://www.irs.gov/irm/part1/irm_01-017-010#id40)
    - 1.17.10.3.5  [Item Base ID](https://www.irs.gov/irm/part1/irm_01-017-010#id41)
      - 1.17.10.3.5.1  [Numeric Base IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id43)
      - 1.17.10.3.5.2  [Alphabetic Base IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id44)
      - 1.17.10.3.5.3  [Freeform Base IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id45)
      - 1.17.10.3.5.4  [Training Base IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id46)
      - 1.17.10.3.5.5  [IRM Base IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id47)
    - 1.17.10.3.6  [Item Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id48)
      - 1.17.10.3.6.1  [Item Suffix and Item Type](https://www.irs.gov/irm/part1/irm_01-017-010#id49)
      - 1.17.10.3.6.2  [Serial Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id50)
        - 1.17.10.3.6.2.1  [Serial Version Types](https://www.irs.gov/irm/part1/irm_01-017-010#id52)
        - 1.17.10.3.6.2.2  [Dual Serial Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id53)
      - 1.17.10.3.6.3  [Associated Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id54)
        - 1.17.10.3.6.3.1  [Associated Suffix Series](https://www.irs.gov/irm/part1/irm_01-017-010#id55)
        - 1.17.10.3.6.3.2  [Schedules](https://www.irs.gov/irm/part1/irm_01-017-010#id56)
          - 1.17.10.3.6.3.2.1  [Schedule Item ID Format](https://www.irs.gov/irm/part1/irm_01-017-010#id58)
      - 1.17.10.3.6.4  [Language Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id59)
        - 1.17.10.3.6.4.1  [Language Suffix Format](https://www.irs.gov/irm/part1/irm_01-017-010#id61)
        - 1.17.10.3.6.4.2  [Multiple Language Suffix Format](https://www.irs.gov/irm/part1/irm_01-017-010#id62)
        - 1.17.10.3.6.4.3  [Language Suffix Table](https://www.irs.gov/irm/part1/irm_01-017-010#id63)
        - 1.17.10.3.6.4.4  [Language Suffixes for Tax Forms and Schedules](https://www.irs.gov/irm/part1/irm_01-017-010#id64)
        - 1.17.10.3.6.4.5  [Language Suffix Decision Matrix](https://www.irs.gov/irm/part1/irm_01-017-010#id65)
      - 1.17.10.3.6.5  [Locality Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id66)
        - 1.17.10.3.6.5.1  [Locality Suffix Table](https://www.irs.gov/irm/part1/irm_01-017-010#id68)
        - 1.17.10.3.6.5.2  [Use of Locality Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id69)
      - 1.17.10.3.6.6  [Alternate Use Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id70)
      - 1.17.10.3.6.7  [Envelope Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id71)
      - 1.17.10.3.6.8  [Multiple Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id72)
        - 1.17.10.3.6.8.1  [Multiple Suffix Table](https://www.irs.gov/irm/part1/irm_01-017-010#id74)
      - 1.17.10.3.6.9  [Suffix Formats](https://www.irs.gov/irm/part1/irm_01-017-010#id75)
        - 1.17.10.3.6.9.1  [Use of Special Characters](https://www.irs.gov/irm/part1/irm_01-017-010#id77)
        - 1.17.10.3.6.9.2  [Syntax](https://www.irs.gov/irm/part1/irm_01-017-010#id78)
        - 1.17.10.3.6.9.3  [Display of Product IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id79)
        - 1.17.10.3.6.9.4  [Examples of Product IDs with Suffixes](https://www.irs.gov/irm/part1/irm_01-017-010#id80)
        - 1.17.10.3.6.9.5  [ESN Special Rules](https://www.irs.gov/irm/part1/irm_01-017-010#id81)
    - 1.17.10.3.7  [Item Type Specific Rules](https://www.irs.gov/irm/part1/irm_01-017-010#id82)
  - 1.17.10.4  [Revision Dates](https://www.irs.gov/irm/part1/irm_01-017-010#id83)
    - 1.17.10.4.1  [Tax Products](https://www.irs.gov/irm/part1/irm_01-017-010#id84)
      - 1.17.10.4.1.1  [Calendar-Year Tax Item Classification](https://www.irs.gov/irm/part1/irm_01-017-010#id86)
      - 1.17.10.4.1.2  [Year-Ahead Tax Item Classification](https://www.irs.gov/irm/part1/irm_01-017-010#id87)
      - 1.17.10.4.1.3  [Quarterly Tax Item Classification](https://www.irs.gov/irm/part1/irm_01-017-010#id88)
      - 1.17.10.4.1.4  [Revision Date Tax Item Classification](https://www.irs.gov/irm/part1/irm_01-017-010#id89)
      - 1.17.10.4.1.5  [Annual Revision Tax Item Classification](https://www.irs.gov/irm/part1/irm_01-017-010#id90)
      - 1.17.10.4.1.6  [Information Return Tax Item Classification](https://www.irs.gov/irm/part1/irm_01-017-010#id91)
    - 1.17.10.4.2  [Non-Tax Products](https://www.irs.gov/irm/part1/irm_01-017-010#id92)
    - 1.17.10.4.3  [Revision Status](https://www.irs.gov/irm/part1/irm_01-017-010#id93)
    - 1.17.10.4.4  [Revision Dates on Translated Products](https://www.irs.gov/irm/part1/irm_01-017-010#id94)
  - 1.17.10.5  [IRS Identification (Dept, Agency, URL, and Wayfinder)](https://www.irs.gov/irm/part1/irm_01-017-010#id95)
  - 1.17.10.6  [Product Title](https://www.irs.gov/irm/part1/irm_01-017-010#id96)
    - 1.17.10.6.1  [Product Title Guidelines](https://www.irs.gov/irm/part1/irm_01-017-010#id97)
    - 1.17.10.6.2  [Non-English Product Titles](https://www.irs.gov/irm/part1/irm_01-017-010#id98)
    - 1.17.10.6.3  [Locality Item Product Titles](https://www.irs.gov/irm/part1/irm_01-017-010#id99)
      - 1.17.10.6.3.1  [Product Title Locality Table](https://www.irs.gov/irm/part1/irm_01-017-010#id101)
    - 1.17.10.6.4  [Envelope Product Titles](https://www.irs.gov/irm/part1/irm_01-017-010#id102)
    - 1.17.10.6.5  [Template Product Titles](https://www.irs.gov/irm/part1/irm_01-017-010#id103)
  - 1.17.10.7  [Non-English and Locality Products](https://www.irs.gov/irm/part1/irm_01-017-010#id104)
    - 1.17.10.7.1  [Translated Products](https://www.irs.gov/irm/part1/irm_01-017-010#id106)
    - 1.17.10.7.2  [Locality Products](https://www.irs.gov/irm/part1/irm_01-017-010#id107)
  - 1.17.10.8  [Product ID Placement on Product](https://www.irs.gov/irm/part1/irm_01-017-010#id108)
    - 1.17.10.8.1  [Tax Forms Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id110)
    - 1.17.10.8.2  [Tax Forms in Non-English Languages Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id111)
    - 1.17.10.8.3  [Non-Tax Form Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id112)
    - 1.17.10.8.4  [Tax Publication Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id113)
    - 1.17.10.8.5  [Tax Publications in Non-English Languages Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id114)
    - 1.17.10.8.6  [Non-Tax Publication Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id115)
    - 1.17.10.8.7  [Non-Tax Publications in Non-English Languages Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id116)
    - 1.17.10.8.8  [Repository Notice Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id117)
    - 1.17.10.8.9  [Repository Notices in Non-English Languages Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id118)
    - 1.17.10.8.10  [Document Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id119)
    - 1.17.10.8.11  [Locality Product ID Placement](https://www.irs.gov/irm/part1/irm_01-017-010#id120)
    - 1.17.10.8.12  [Product Identifiers Prior to 2009](https://www.irs.gov/irm/part1/irm_01-017-010#id121)
  - 1.17.10.9  [Changing Product IDs](https://www.irs.gov/irm/part1/irm_01-017-010#id122)
  - 1.17.10.10  [File Naming](https://www.irs.gov/irm/part1/irm_01-017-010#id123)
  - 1.17.10.11  [Frequent Periodicals](https://www.irs.gov/irm/part1/irm_01-017-010#id124)

# Part 1. Organization, Finance, and Management

# Chapter 17. Publishing

# Section 10. IRS Published Product Identification

* * *

## 1.17.10 IRS Published Product Identification

#### Manual Transmittal

December 08, 2025

#### Purpose

(1) This transmits revised IRM 1.17.10, _Publishing, IRS Published Product Identification_.

#### Material Changes

(1) Updated Signature to reflect current Publishing director.

(2) 1.17.10.1, _Program Scope and Objectives_ \- Updated Internal Controls to adhere to IRM 1.11.2.2.4(4).

(3) 1.17.10.3.5.4(3), _Training Base IDs_ \- Updated to remove reference to the five-digit limitation on course number. Our new catalog system allows Training product IDs to contain an alpha character following the five-digit number to match the number assigned through Learning and Education.

(4) 1.17.10.3.6.8.1(1), _Multiple Suffix Table_ \- Added content to direct the reader to the table at the linked site.

(5) Made editorial changes throughout to conform to Plain Writing requirements.

#### Effect on Other Documents

This supersedes IRM 1.17.10, _Publishing, IRS Published Product Identification_, dated December 17, 2024.

#### Audience

All IRS employees, contractors, and vendors who design, publish, or distribute electronic products for internal or external audiences.

#### Effective Date

(12-08-2025)

Tracey Quamie

Director, Publishing

Media & Publications Division

**1.17.10.1** **(12-08-2025)**

### Program Scope and Objectives

1. **Purpose:** Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within IRS for tax administration. The Publishing function (also known as "Publishing" ) under Media & Publications (M&P) within the Customer Assistance Relationships and Education (CARE) organization in the Taxpayer Services (TS) division develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use. This section sets forth the standards for published product IDs, including the numbering series, guidelines for assigning IDs within each series, revision dates, and how the product identification appears on each type of product. Product originators must request and obtain approval for exceptions to these standards through the Publishing function.

2. **Audience.**The audience for this IRM is IRS employees Servicewide.

3. **Policy Owner.** The Director of Publishing owns the policies contained herein.

4. **Program Owner.** TS, CARE, M&P, Publishing is responsible for the administration, procedures, and updates related to the program.

5. **Primary Stakeholders.** Tax Forms & Publications (TF&P) in M&P, CARE, TS; Chief Financial Officer of the IRS; Distribution in M&P, CARE, TS; IRS organizations servicewide.

6. **Contact Information.** The Director of Publishing in M&P in CARE, TS.


**1.17.10.1.1** **(12-17-2024)**

#### Background

1. Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within the IRS for tax administration. The Publishing function (also known as "Publishing" ) under M&P within CARE, TS develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use.


**1.17.10.1.2** **(12-17-2024)**

#### Authority

1. Publishing’s authority as the official IRS publisher is listed in IRM 1.17.9.6, _Roles and Responsibilities When Publishing a Product_. M&P controls published product identification. See IRM 1.17.9.6.1.1, _Officially Published Products_, for more information and to determine what products need an official product number.

2. Strict adherence to Product ID standards is crucial to systematic management of published products across IRS. The business rules for Product IDs allow IRS systems to be programmed consistently to manage products, search and sort on websites, and exchange data accurately. The standards also provide consistency for software vendors, tax preparers, and other public users for their identification of IRS products and software development.


**1.17.10.1.3** **(12-08-2025)**

#### Roles and Responsibilities

1. This section explains the responsibilities associated with being a published product originator and the roles and responsibilities of all involved in the published product processes.


**1.17.10.1.4** **(12-08-2025)**

#### Program Management and Review

1. **Program Reports.** Balanced measures for tax and non-tax products.

2. **Program Effectiveness.** The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.10.1.5** **(12-08-2025)**

#### Program Controls

1. The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.10.1.6** **(12-08-2025)**

#### Terms and Acronyms

1. This IRM section uses the following terms and acronyms to describe the involved processes and resources.




| Term/Acronym | Definition |
| --- | --- |
| AMC | Alternative Media Center |
| ADP | Automated Data Processing |
| ATG | Audit Technique Guide |
| BOD | Business Operating Division |
| C&L | Communications & Liaison |
| CAPS | Computer Assisted Publishing System |
| CARE | Customer Assistance Relationships and Education |
| CMS | Content Management System |
| CPM | Composition Process Management |
| CP | Computer Paragraph Notices |
| CROPP | Core Repository of Published Products |
| CRX | Correspondex Letters |
| C-SP | Spanish Correspondex letters dual suffix |
| ESN | Electronic Status Notice |
| GAO | Government Accountability Office |
| GII | Generalized IDRS Interface |
| GPO | Government Publishing Office |
| GSA | General Services Administration |
| HTML | Hyper-text mark-up language |
| IAT | Integrated Automation Technology |
| ID | Identification |
| IDRS | Integrated Data Retrieval System |
| IDEA | Integrated Digital Experience Act |
| IRB | Internal Revenue Bulletin |
| IRM | Internal Revenue Manual |
| ISO | International Standards Organization |
| LPTS | Linguistic Policy, Tools and Services |
| M&P | Media & Publications |
| NDC | National Distribution Center |
| NR | Non-Resident |
| OMB | Office of Management and Budget |
| OGA | Other Government Agency |
| OLS | Online Services |
| PDF | Portable Document File |
| PPMC | Published Product Media Catalog |
| PRA | Paperwork Reduction Act |
| PSD | Publishing Services Data |
| PSR | Publishing Services Request |
| PTVI | Product Title Version Identifier |
| SERP | Servicewide Electronic Research Program |
| SNIP | Servicewide Notice Information Program |
| SP | Spanish |
| TAC | Taxpayer Assistance Center |
| TCS | Taxpayer Correspondence Services |
| TF&P | Tax Forms & Publications |
| TIC | Tax Item Classification |
| TIN | Taxpayer Identification Number |
| TPDS | Training Products Distribution System |
| TS | Taxpayer Services |
| USPS | United States Postal Service |
| VIS | Visual Information Specialist |
| WCMS | Web Content Management System |
| XML | Extensible Markup Language |


**1.17.10.1.7** **(12-08-2025)**

#### Related Resources

1. Document 12687, _Getting Your Information Published at the IRS_

2. Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_

3. IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_

4. IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_

5. IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_


**1.17.10.2** **(11-10-2022)**

### Product Identification Components

1. The product identifier consists of several elements typically displayed on products in a single text line. The elements are:



   - Product type

   - Product number

   - Revision date

   - Catalog number

   - The words “Department of the Treasury”

   - The words “Internal Revenue Service”

   - The Intranet website address “publish.no.irs.gov” or the external website address “irs.gov”

   - Miscellaneous products may carry the requisition number in place of some of the information mentioned above


2. A visual information specialist authorized by the IRS Design Services office places product identifiers on products in a consistent manner using graphic design techniques and in accordance with Document 12749, _IRS Design Standards & Guidelines_.

3. The optional IRS Wayfinder is considered part of the official product identification. The Wayfinder displays the high-level business unit and may include the lower-level office responsible for the product. _Figure 1.17.10-1_



**Figure 1.17.10-1**

![This is an Image: 75322001.gif](https://www.irs.gov/pub/xml_bc/75322001.gif)





> Figure 1 IRS WayfinderFigure 1 shows the wayfinder for Taxpayer Services, which consists of the IRS logo and the text “Taxpayer Services.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342021 "")


**1.17.10.3** **(11-10-2022)**

### Item IDs

1. Every official published product has an item ID that consists of an item type (form, publication, instruction, document, etc.), an Item Base ID (1040, 1099, etc.) and, when needed, a Suffix. Examples of Item IDs Include Form 1040, Form 1099-A (BR), Document 13220, and Envelope 25-CR-10.

2. The term Product ID is the Item ID with the Revision Date added. See _IRM 1.17.10.4_, _Revision Dates_, for more information on revisions.


**1.17.10.3.1** **(11-10-2022)**

#### Assigning Item IDs

1. We assign an Item ID based on a Publishing Services Request (PSR) received either through the PSR application or in limited situations on Form 1767, _Publishing Services Requisition_. The PSR number or PSD requisition number is the audit trail for the business need authorization and funding for the new product.

2. A Product Gatekeeper in the Publishing function who has the experience and authority to properly assign Item IDs assigns Item IDs. Publishing specialists may request that the Gatekeeper assign an Item ID, or the Gatekeeper may assign an ID based on the PSR.

3. The Gatekeeper must forward to the PPMC (Published Product Media Catalog)/ESN (Electronic Status Notice) Administrator for action any requests for Item IDs that do not follow these standards. If, after follow-up with the requester and management, the Administrator assigns a non-standard Item ID, then the PPMC system or ESN Administrator notes document the reason for the Item ID for future reference.

4. Item IDs that do not meet these standards require correction when revised or if reinstated. If feasible, we suggest correcting Item IDs on reprints of stock.


**1.17.10.3.2** **(12-17-2024)**

#### Item ID Status

1. We provide full details of Item Status in Publishing Procedure 166 for M&P employees. The Publishing IRM 1.17.9.5, _Importance of Standards and Submitting a Publishing Services Request_, and IRM 1.17.9.6.2.3, _Obsoleting Published Products_, contain the procedures for customers to submit requests to create a new product or make it obsolete or historical.

2. A request for a new Item ID is in Draft status until the Gatekeeper or Administrator assigns an Item ID. Once assigned, the Item ID is in New status. It remains New until we publish and release the item for use. While New:



1. The requestor can cancel the Item ID if they decide not to publish the product.

2. If the Item ID is canceled, the requestor can submit a PSR to reinstate it to a New status if they decide to re-start product development.

3. The PPMC /ESN Administrator may change the New Item IDs with a documented reason.


3. When the product originator signs off on the product as OK to Publish, and we publish the item (released for print, print and electronic, or electronic-only), then the status becomes Active. Once Active:



1. Occasionally, Publishing may recall for correction an item published with an error. The Item returns to New status until a corrected product is published and it becomes Active again. See IRM 1.17.10.5.3, Revision Status.

2. The PPMC/ESN Administrator may change the Item ID only on non-tax products with a critical justification to do so. The Administrator must clearly document the reason for change and superseding/superseded by information in the PPMC or ESN application for use in the Product Catalog so that users easily understand the change.

3. We rarely change tax product Item IDs once published, because it is too confusing for public users. The best practice is for product originators/owners to make the incorrect item obsolete or historical and create a new item. In rare cases, we can change a non-standard Item ID to meet product ID standards when we revise the product.

4. Product originators/owners may submit a PSR to make an item obsolete or historical.

5. Originators/owners may submit a PSR to reinstate an obsolete or historical item to Active.


**1.17.10.3.3** **(11-10-2022)**

#### Type of Use Categories

1. We also categorize every product by Type of Use:



1. The TF&P function usually develops tax products, which are the products the public needs to file their taxes as required by law.

2. Tax-Related Public Use Products are those that the IRS uses to interact with the public about tax administration or education matters such as collection notices, tax payment agreements, or informational publications.

3. General Administrative Public Use Products are those that the public uses to interact with the IRS on other subjects, such as employment or facility management.

4. We intend Internal Use Products for use by IRS employees.


2. We group together the Tax-Related Public Use, General Administrative Public Use, and Internal Use types of use as non-tax products because the work processes that involve the TF&P function and those that do not are quite different. Major tax products used for filing taxes also have a much more structured set of requirements, development processes, approvals, public release schedules, and design standards. Therefore, dividing products into tax products and non-tax products is a useful distinction.


**1.17.10.3.4** **(11-10-2022)**

#### Item Types

1. Item Type groups products with similar key characteristics for high-level management and numbering. The Item Types are:



01. Document

02. Form

03. Instruction

04. Internal Revenue Bulletin (IRB)

05. Internal Revenue Manual (IRM)

06. Repository Form Letter

07. Repository Notice

08. Other Government Agency Product

09. Publication

10. Tax Package

11. Template

12. Training Product

13. Envelope


2. We do not officially number Miscellaneous Items. They instead carry a product Signature that may include the requisition number Publishing assigned for production and/or procurement purposes.


**1.17.10.3.4.1** **(11-10-2022)**

##### Item Type and Type of Use

1. Item Types have a relationship to their type of use.


**1.17.10.3.4.1.1** **(11-10-2022)**

###### Tax Products

1. Tax Products consist of these Item Types:



1. Form

2. Publication

3. Repository Notice

4. Instruction

5. Tax Package


**1.17.10.3.4.1.2** **(11-10-2022)**

###### Non-Tax Products

1. Non-tax products consist of these Item Types:



01. Form

02. Repository Form Letter

03. Repository Notice

04. Document

05. Publication

06. Envelope

07. Internal Revenue Bulletin (IRB)

08. Internal Revenue Manual (IRM)

09. Training Product

10. Other Government Agency Product

11. Template


**1.17.10.3.4.1.3** **(11-10-2022)**

###### Item Types and Type of Use Table

1. This table shows which Item Types are available within each Type of Use.




| **Item Type** | **Internal Use** | **Tax-Related Public Use** | **General Administration Public Use** | **Tax Product** |
| --- | --- | --- | --- | --- |
| Document | X |  |  |  |
| Form | X | X | X | X |
| Instruction |  |  |  | X |
| IRB |  | X |  |  |
| IRM | X |  |  |  |
| Repository Form Letter |  | X | X |  |
| Repository Notice |  | X |  | X |
| Other Government Agency Product |  | X | X |  |
| Publication |  | X | X | X |
| Tax Package |  |  |  | X |
| Template | X |  |  |  |
| Training Product | X |  |  |  |


**1.17.10.3.4.2** **(08-14-2023)**

##### Forms

1. A form is a data collection or dissemination instrument printed or electronically reproduced with space for filling in information, descriptive material, or addresses. All forms should include instructions for use. Public use forms may only contain variable taxpayer information data when attached to other taxpayer correspondence. Forms are the principal contact between the IRS and taxpayers and are the published products IRS employees use most frequently.

2. A data collection instrument, whether referred to as a form, a template, or any other term with similar meaning, collects data from multiple users through a standard process on an ongoing basis. IRS forms management controls data collection instruments created in and/or available only through online applications such as SharePoint, and the instruments are subject to IRS standards for numbering, approvals, and management. The data collection instrument/form owner must obtain an official form number and must display the official form number on the online form. The owner must also submit PSRs to keep the Published Product Catalog up to date with the link to the site where users can complete and submit the form.

3. All public-facing forms posted on IRS.gov must be in a fillable or digitized format to comply with the Integrated Digital Experience Act (IDEA) legislation. Publishing applies this capability to every form as a standard practice. Exceptions are those forms approved to be available in paper only, which Publishing then posts with an overlay stating that the form is not a fillable item.


**1.17.10.3.4.2.1** **(11-10-2022)**

###### Form Types

1. The Publishing organization produces three types of forms:



1. Public-Use Forms

2. Internal-Use Forms

3. Standard and Optional Forms


**1.17.10.3.4.2.1.1** **(11-10-2022)**

###### Public-Use Forms

1. A public-use form is any form the IRS prescribes to enable the general public and other government agencies to comply with internal revenue laws and regulations or to otherwise communicate with the public. The three categories of public-use forms the IRS prescribes are:



   - Tax Forms

   - Tax-Related Forms

   - General Administrative Forms


2. M&P’s OMB Clearance Office must review public-use forms. Procedures for Office of Management and Budget (OMB) approval are posted online.

3. A tax form is any form the IRS prescribes to enable the general public to comply with the requirements of IRS laws and regulations.

4. A tax-related form is any form the IRS prescribes (except tax forms) to communicate with the general public about tax matters relating to taxpayers, tax practitioners, or general tax information.

5. A general administrative form is any form the IRS prescribes to communicate with the general public about administrative matters relating to personnel, facilities, or finance.

6. The Taxpayer Correspondence Services (TCS) reviews public-use forms to determine if they need to go through the TCS for plain language, privacy act, and paperwork reduction statement review.


**1.17.10.3.4.2.1.2** **(11-10-2022)**

###### Internal-Use Forms

1. An internal-use form is any form prescribed for use solely within the IRS. These are forms completed by and used to collect information from IRS employees. Some examples of existing internal-use forms include employment, personnel, employee performance, training, and property security.

2. IRS employees are not required to complete and submit unnumbered (commonly referred to as “bootleg”) forms, which are unauthorized and prohibited.


**1.17.10.3.4.2.1.3** **(11-10-2022)**

###### Standard and Optional Forms

1. A standard form is one an executive agency prescribes for the use of two or more agencies under the approval of the National Archives and Records Services, General Services Administration (GSA). All federal agencies must use a standard form. Exceptions to standard forms involving departure from text or format require written approval by GSA prior to printing. Forward requests for exceptions to the GSA through Publishing.

2. Optional forms are for use at the discretion of each agency; they are not mandatory.

3. The agency with government-wide responsibility for the function the form accomplishes establishes, approves or revises standard accounting forms. Refer to the Government Accountability Office (GAO) Policies and Procedures Manual to determine the responsible agency for each standard accounting form. Exceptions to standard accounting forms involving departure from text or format require GAO written approval. Forward requests for exceptions to the originating agency through Publishing.

4. The Standard and Optional Forms Facsimile Handbook, published by GSA’s Federal Supply Service, gives detailed data concerning the use of each standard and optional form. GSA stocks most standard and optional forms.


**1.17.10.3.4.3** **(08-14-2023)**

##### Repository Form Letters

1. Letters are correspondence sent to taxpayers because the IRS owes the taxpayer, the taxpayer owes the IRS, the IRS needs information from the taxpayer, or the IRS provides information to the taxpayer.

2. Repository form letters are the templates with fill-in fields used to create personalized letters sent directly to taxpayers about specific tax account activities. These letters are either generated by the IRS user or systemically as part of a business process. Repository form letters must contain a point of contact and IRS contact phone number. Letters can request specific information, but should NOT collect routine, uniform, or structured information. If all recipients must send the same data, then the requesting office must include an official IRS form with the letter. The Publishing organization creates and maintains repository form letter templates, and they are available from the Publishing Product Catalog.

3. Surveys and/or survey letters are correspondence created and designed to collect taxpayer input, feedback, or data. We use the information collected to enhance the taxpayer’s experience with the IRS. These letters are typically not account-related but may result from any type of taxpayer account activity or condition.

4. See IRM 25.13.1.3.1, _Request for Services Process_, for additional information on taxpayer correspondence.


**1.17.10.3.4.4** **(08-14-2023)**

##### Repository Notices

1. The IRS can send a repository notice if it believes a taxpayer owes additional tax or is due a larger refund, or if there is a question about a tax return or a need for additional information.

2. Repository notices are numbered, preprinted messages to the public that are usually inserted or stuffed into envelopes with other printed matter. All information on repository notices is pre-printed; users cannot add or fill in information manually or electronically after reproduction. If we must print a language version of the same repository notice, then we will use one of the standard language suffixes. Repository notices are available in the Published Product Catalog on the Publishing + Distribution intranet site.

3. Computer Paragraph (CP) notices are tax account-related correspondence that systemically results from an account-related activity or condition and are not repository notices.


**1.17.10.3.4.5** **(11-10-2022)**

##### Instructions

1. Instructions commonly appear on forms at the bottom or back of the page. Lengthy instruction booklets provide more in-depth information for completing the form it accompanies.

2. Instruction booklets are prefixed with the words "Instructions for" and identified by the form number they accompany. An example is “Instructions for Form 1099-B,” Instructions for Form 1099-B, Proceeds from Broker and Barter Exchange Transactions.

3. Instructions do not contain fill-in fields.

4. Instruction booklets may contain worksheets, charts, or other descriptive information.


**1.17.10.3.4.6** **(11-10-2022)**

##### Documents

1. We intend IRS Documents for use by IRS employees and identify them numerically starting with Document number 5001. The content in Documents is generally for informational or administrative purposes. We do not generally distribute Documents to the public. Types of information published as documents are:



   - Personnel guidelines

   - Job aids

   - Employee development guides

   - Safety and health handbooks

   - Newsletters

   - Rules of conduct


**1.17.10.3.4.7** **(11-10-2022)**

##### Publications

1. A publication is an information product created for and distributed to a particular segment of the public in either electronic or printed format. Publications also include products for both IRS employees and public use. Some examples of publications are:



   - Recruitment packages

   - Reports to Congress

   - Promotional items approved for various IRS initiatives


**1.17.10.3.4.7.1** **(11-10-2022)**

###### Publication Types

1. The Publishing organization produces three types of publications:



1. Tax publications



      > - Related to federal taxation; and
      >
      >       - Aimed specifically at informing or educating all or certain groups of taxpayers.

2. General-use publications



      > - Non-tax publications
      >
      >       - Issued to the public for various informational and promotional purposes

3. Joint publications


> - Issued in conjunction with another government agency
>
>    - Published at either one or both agencies
>
>    - Issued to the public through either one or both agencies’ distribution channels
>
>    - Published with the publication identification numbers assigned by both agencies

**1.17.10.3.4.8** **(11-10-2022)**

##### Envelopes

1. Envelopes are vehicles used to mail printed products to IRS employees and the general public.


**1.17.10.3.4.9** **(11-10-2022)**

##### Internal Revenue Manual (IRM)

1. The IRM is the official source of IRS policies and procedures (instructions to staff). The IRM contains directions employees need to carry out their job duties in administering tax laws or other agency obligations.

2. We provide the redacted IRM for public reference on the IRS.gov website.


**1.17.10.3.4.10** **(11-10-2022)**

##### Training Publications

1. The IRS uses Training Publications to support employee development. This includes Training Products Distribution System (TPDS) products and Automated Data Processing (ADP) products used at IRS campuses.


**1.17.10.3.4.11** **(11-10-2022)**

##### Other Government Agency (OGA) Products

1. Most OGA products are now available electronically from the agency’s website. The IRS assigns an IRS item ID and prints OGA products only when the product needs specific IRS information pre-filled for IRS employee use.

2. When the IRS prints OGA products, they must include the IRS catalog number along with the other agency’s item number. The catalog number should appear on the printed document in the following format: IRS Catalog Number 99999X.


**1.17.10.3.4.12** **(11-10-2022)**

##### Templates

1. Templates are a new Item Type to identify electronic templates IRS employees use to create one-time products, such as reports or flyers, or to produce recurring internal information documents.


**1.17.10.3.4.13** **(11-10-2022)**

##### Miscellaneous Products

1. Miscellaneous products are any products that are not official forms, publications, documents, repository notices, letters, etc. Examples of Miscellaneous products include these and other products:



   - Memos

   - Door posters

   - Notepads

   - Promotional items


2. The IRS does not stock Miscellaneous products at the NDC or post them on a customer’s website or to Publishing’s catalog page.

3. A product signature should appear on all Miscellaneous published products, including all newly created, revised, or reprinted Miscellaneous products. The Miscellaneous signature will contain the product’s requisition number so users may research and reference the product in the future.

4. A product signature must appear on all Miscellaneous published products unless production constraints or other reasons make it unreasonable to do so. Publishing has designed three variations of the Miscellaneous signature. The product’s design and physical characteristics should determine the choice of signature variations. The publishing specialist and/or visual information specialist, following IRS design standards, may determine appropriate placement of the signature on the product.

5. For additional information on IRS design standards, see IRM 1.17.7, _Publishing, Use of the Official IRS Seal, IRS Logo, Program Logos, and Internal Logos_, and Document 12749, _IRS Design Standards & Guidelines_.


**1.17.10.3.5** **(11-10-2022)**

#### Item Base ID

1. The Base ID in the Published Product Media Catalog (PPMC) replaces the Base Number in the Electronic Status Notice (ESN) system. There are five types of Base IDs: Numeric, Alphabetic, Freeform, Training, and IRM.


**1.17.10.3.5.1** **(11-10-2022)**

##### Numeric Base IDs

1. Used for the following Item Types: Publications, Repository Notices, Forms, Repository Form Letters, Documents, and Envelopes.

2. A 1- to 5-digit number for the item. We assign numbers sequentially within the Item Type (Form, Repository Notice, Publication, etc.).

3. Publishing can set aside designated series of numbers for specific uses. Because of the difficulties in managing special series, we only do this when there is a highly significant business need to do so.

4. In rare cases when there is a significant business need, the ESN/PPMC administrator may assign a Numeric Base ID out of sequence.


**1.17.10.3.5.2** **(11-10-2022)**

##### Alphabetic Base IDs

1. Used for the following Item Types: Form and Instruction

2. We use a designated Alphabetic Base ID series for tax products. The ESN/PPMC administrator must well define and coordinate any New Alphabetic series. The Alphabetic series include:



   - W (Wages)

   - CT (Railroad)

   - I (Immigration)

   - SS (Social Security)

   - T (Timber)


3. Within each Alphabetic Base ID series, Publishing assigns the next available sequential number to a new product. The number follows the Alpha character with a hyphen to link it together in a chain or series, such as W-2.

4. In rare cases when there is a significant business need, the ESN/PPMC administrator may assign an Alphabetic Base ID out of sequence.

5. Limitations in the ESN system force these products to be managed as five zeros (00000) in the base number, and the entire product number and suffix is manually entered in the Suffix field. (e.g., Form 00000 W-2. This is formatted for display in applications and on reports as Form W-2.)


**1.17.10.3.5.3** **(11-10-2022)**

##### Freeform Base IDs

1. We only use the Freeform Base ID on rare occasions, and it requires approval and assignment by the ESN/PPMC administrator.

2. OGA items use the Freeform Base Type.



   - The Base ID is a text field for the number the issuing agency assigned.

   - The IRS is moving to keep only those items customized for IRS use in our product database, since OGA items are generally available publicly on the issuing agency’s website.


3. Limitations in the ESN system force us to manage these products as 5 zeros (00000) in the base number and manually enter the entire product number and suffix in the Suffix field.


**1.17.10.3.5.4** **(12-08-2025)**

##### Training Base IDs

1. Used for Item Type: Training Publication.

2. The Base ID is the Training Course and Training Item numbers linked together with a hyphen.

3. PPMC now allows the inclusion of an alpha character following the five digit Base Training Course Number (i.e., 12345A-101).


**1.17.10.3.5.5** **(11-10-2022)**

##### IRM Base IDs

1. Used for Item Type: IRM.

2. The Base ID is the IRM Part, Chapter, and Section linked with a period between each.

3. Limitations in the ESN system force us to manage these products as 5 zeros (00000) in the base number and manually enter the entire product number and suffix in the Suffix field.


**1.17.10.3.6** **(11-10-2022)**

#### Item Suffixes

1. Publishing uses suffixes when a created item is related to a ‘parent’ product in one of the following defined ways: Serial, Associated, Language, Locality, or Alternate Use.



### Example:



For instance, Form 433, _Statement of Financial Condition and Other Information_, is the parent product and Form 433-A, Collection Information Statement for Wage Earners and Self-Employed Individuals, is its ‘child.’ Form 433-A (SP), _Collection Information Statement for Wage Earners and Self-Employed Individuals (Spanish Version)_, is a child of Form 433-A and a ‘grandchild’ of Form 433.


**1.17.10.3.6.1** **(11-10-2022)**

##### Item Suffix and Item Type

1. Item Suffixes have a relationship with Item Type. The following table lists the Item types and their relationship(s) to a parent product through Serial, Associated, Language, Locality or Alternate Use.




| **Item Type** | **Serial** | **Associated** | **Language** | **Locality** | **Alternate Use** |
| :-: | :-: | :-: | :-: | :-: | :-: |
| Document | Allowed | Not Allowed | Not Allowed | Not Allowed | Allowed |
| Form | Allowed | Allowed | Allowed | Allowed | Allowed |
| Instruction | Allowed | Not Allowed | Allowed | Allowed | Allowed |
| IRB | Not Allowed | Not Allowed | Not Allowed | Not Allowed | Allowed |
| IRM | Not Allowed | Not Allowed | Not Allowed | Not Allowed | Allowed |
| Repository Form Letter | Allowed | Allowed | Allowed | Allowed | Allowed |
| Repository Notice | Allowed | Allowed | Allowed | Allowed | Allowed |
| OGA Item | Not Allowed | Not Allowed | Not Allowed | Not Allowed | Not Allowed |
| Publication | Allowed | Allowed | Allowed | Allowed | Allowed |
| Tax Package | Allowed | Allowed | Allowed | Allowed | Allowed |
| Template | Allowed | Not Allowed | Not Allowed | Not Allowed | Allowed |
| Training Product | Not Allowed | Not Allowed | Not Allowed | Not Allowed | Allowed |


**1.17.10.3.6.2** **(11-10-2022)**

##### Serial Suffixes

1. Publishing creates a Product Version using a parent product as a base identifier and appending a suffix to create a unique Product ID.

2. Publishing uses Serial Versions for series of related Products that involve the same subject or issue and require identification with the same Base ID.


**1.17.10.3.6.2.1** **(11-10-2022)**

###### Serial Version Types

1. We create Serial versions in two types: Alphabetic or Numeric.

2. If Serial Version Type is alphabetic, then the Suffix will be the next available serial letter A-Z.

3. If Serial Version Type is numeric, then the Suffix will be the next available number starting with 1.

4. We select the Serial Version Type for the first serial version made from a parent product. All subsequent serial versions must follow the format of the first. For example, if Publishing has created Form 1234-A, then the next serial version must also be an alphabetic version, Form 1234-B.

5. Serial versions for Envelopes or Templates must be numeric. All other item types must be alphabetic.

6. The ESN/PPMC administrator can assign a numeric serial version for items that are not Envelopes or Templates.

7. When the product owner/originator expects to create more than 26 versions of a parent product, Publishing should select the numeric serial version type so the product owner/originator can add more than 26 versions. If the serial version type is alphabetic and the series goes beyond 26 versions, then the publishing specialist must contact the PPMC/ESN administrator.

8. The ESN/PPMC administrator can assign an out-of-order alphabetic serial version with an approved justification. This has happened in the past when a single alpha digit stands for a particular use of the product. Unfortunately, the use of these suffixes has been inconsistent. Publishing should instead have created multi-digit Associated suffixes. We strictly limit these single alphabetic serial designations for new products to approved exceptions.


**1.17.10.3.6.2.2** **(11-10-2022)**

###### Dual Serial Suffixes

1. If the parent product’s Serial Version Type is alphabetic, then the second serial suffix will be the next available number starting with 1.

2. If the parent product’s Serial Version Type is numeric, then the second serial suffix will be the next available serial letter A-Z.


**1.17.10.3.6.3** **(11-10-2022)**

##### Associated Suffixes

1. Associated versions associate a product’s content to a parent product for a target audience or subject area. The associated suffix is related directly to the contents of the product version created.


**1.17.10.3.6.3.1** **(11-10-2022)**

###### Associated Suffix Series

1. Publishing creates Associated products in specific series that identify forms for a specific audience or subject. Each of these has a short abbreviation used in the product ID suffix as follows. The PPMC/ESN administrator must create new series. Below is a partial list of Associated suffixes.



   - Black Lung - BL

   - Bond Tax Credits – BTC

   - Capital – CAP

   - Certificate - CE

   - Credit Payments - CP

   - Credit - CR

   - Carrier Summary - CS

   - Digital Assets – DA

   - Dividends - DIV

   - Employers - EMP

   - Exempt organizations - EO

   - Estimated Tax - ES

   - Education Savings Accounts - ESA

   - Excise Tax - EX

   - Easy - EZ

   - Foreign efile - FE

   - Foreign Sales Corporation - FSC

   - General instructions - GENERAL

   - Generation Skipping - GS

   - Interest Charge - IC

   - Interest - INT

   - Long-term Care - LTC

   - Mortgage Assistance - MA

   - Miscellaneous - MISC

   - Nuclear Decommissioning - ND

   - Non-employee Compensation - NEC

   - Non-resident Aliens - NR

   - Original Issue Discount - OID

   - Patrons of a Patronage - PATR

   - Property & Casualty Insurance Companies - PC

   - Partnership efile - PE

   - Private Foundation - PF

   - Political Organizations - POL

   - Qualified Domestic Trusts - QDT

   - Qualified Funereal Trusts - QFT

   - Real Estate Investment Trusts - REIT

   - Regulated Investment Companies - RIC

   - Savings Account - SA

   - Settlement Fund - SF

   - Seniors - SR

   - Supplemental - SUP

   - Tax Credit - TC

   - TEGE efile - TE

   - Timber - TIMBER

   - Terminal Operators - TO

   - Corporations - CORP


**1.17.10.3.6.3.2** **(12-17-2024)**

###### Schedules

1. Schedules are extensions of tax forms and are associated to one primary tax form. Schedules must be filed with their associated primary tax form or other permitted tax form; schedules cannot be filed by themselves.

2. The primary form the schedule is filed with is part of the schedule’s Item ID. The heading area of the schedule and the form instructions list the other forms the schedule can be filed with.

3. Only the primary form is in the product ID so that the product ID does not change if the schedule’s associated forms change.


**1.17.10.3.6.3.2.1** **(11-10-2022)**

###### Schedule Item ID Format

1. The Item ID for a Schedule is an exception to the usual Form number ID syntax.



1. Replace the Item type Form with the word “Schedule”

2. Replace the Base ID with the Schedule Name



      |     |
      | --- |
      | 1\. Schedule Name is an open input that the business can determine; however, the preferred method is to use letters in alphabetic order (A, B, C, etc.). (e.g., Schedule A) |
      | 2\. If Publishing uses multiple designations to create versions of an alpha schedule, then we add a hyphen followed by a sequential number to create A-1, A-2, etc. (e.g., Schedule A-1) |

3. Add the primary form filed with the schedule in parenthesis (e.g., (Form 1234 M-5)), resulting in the format “Schedule” Schedule Name (Primary Form). e.g., Schedule 3 (Form 1040).


2. The Item ID appears on the product as Schedule AAA (Form NNNNN). When split into two lines for the upper left corner of the form, Schedule AAA is on the top line, and (Form NNNNN) is on the second line in a smaller font size.



   - NNNNN = The form number of the primary form filed with the schedule.

   - AAA = the Schedule Number(s) or Letter(s).


3. In PPMC, the format of the Item ID for Schedules is: Form Schedule AAA (Form NNNNN).



   - NNNNN = The form number of the primary form filed with the schedule.

   - AAA = the Schedule Number(s) or Letter(s).


4. The format of the ESN Item ID for schedules is F NNNNN SCH AAA.



   - F = Form

   - NNNNN = The form number of the primary form filed with the schedule.

   - SCH = The standard suffix identifier for a schedule.

   - AAA = the Schedule Number(s) or Letter(s).


5. The format for schedules in the Published Product Catalog is Form NNNNN Schedule AAA.



   - NNNNN = The form number of the primary form filed with the schedule.

   - AAA = the Schedule Number(s) or Letter(s).


**1.17.10.3.6.4** **(11-10-2022)**

##### Language Suffixes

1. The default language for IRS published products is English. Do not use a language suffix in the Item ID for products in English.


**1.17.10.3.6.4.1** **(11-10-2022)**

###### Language Suffix Format

1. Use a language suffix on products published in a non-English language.

2. Create a language “child” product from the English parent (source) product by adding the correct language suffix to the end of the parent Item ID.

3. The language suffix is usually a two-digit code from the international ISO standard for languages enclosed in parentheses. Some languages use the three-digit ISO standard when required to avoid conflicts with other suffixes.

4. The IRS uses a non-ISO suffix, (SP), for Spanish products. Because of the large number of existing Spanish products and multiple IRS systems programmed around the existing suffix, Publishing will not change the (SP) suffix other than to be consistent in using lower case for language suffixes.



1. Examples for Spanish, Russian, Simplified Chinese, and Traditional Chinese are respectively (sp), (ru), (zh-hans), and (zh-hant). Note that we shortened the Chinese designations to (zh-s) and (zh-t) because of ESN character limitations.


5. The product titles of the English parent and the language child must also be unique. See _IRM 1.17.10.6.2_, _Non-English Product Titles_, for details.

6. See _IRM 1.17.10.3.6.4.5_, _Language Suffix Decision Matrix_, for guidance on products that contain non-English languages that are less than the full product content or in other combinations.


**1.17.10.3.6.4.2** **(08-14-2023)**

###### Multiple Language Suffix Format

1. Use a dual language suffix when a product includes the same content in two languages. Use both language codes separated by a hyphen (E.g., (en-ur)).

2. Use the suffix (mul) when there are three or more non-English languages or (en-mul) when the product is in English and two or more additional languages. The PPMC system will contain the data on all languages in a product, and the Product Description will indicate all languages.


**1.17.10.3.6.4.3** **(12-17-2024)**

###### Language Suffix Table

1. The Language Table contains the valid languages suffixes.



1. **Language**: There are 20 required languages. Publishing has existing codes for German, Chinese, and Somalian, and we also include those in the language table.

2. **M&P System Abbreviation**: This column identifies the language code previously used in M&P systems.

3. **PPMC Language Suffix**: This is the language suffix in the PPMC system and on all new products.

4. **Drupal Abbreviation**: This is the language code of the Web Content Management System Online Services uses to support the IRS.gov website.

5. **ISO Standard**: This is the International Standards Organization language code used across industries and countries to identify a language. There are 2- and 3-digit codes in the ISO standard. Using the ISO standard makes the product identification compatible with any other systems or uses that identify the product language.

6. The table below lists language codes that have specific issues:




      | Language Code Issues |
      | :-: |
      | English: We use the English suffix in conjunction with other language suffixes, e.g. (en-ar) or (en-pl). |
      | Spanish: The ISO standard, es, conflicts with the associated Estimated Tax product suffix. Because there are many existing products with (SP), (sp) will remain in use. |
      | Vietnamese: The ISO standard, vi, is the same as the ISO standard country code for the U.S. Virgin Islands, which the IRS uses as a locality suffix. Therefore, Publishing uses the 3-digit ISO standard, vie. |
      | Persian/Farsi: Farsi is not on the ISO-2 standards list. It is a common name for Persian. We therefore use the Persian Language code. |
      | Gujarati: The ISO standard, gu, is the same as the ISO standard country code for Guam, which the IRS uses as a locality suffix. We therefore use the 3-digit ISO standard, guj. |
      | Khmer: There are two languages on the ISO 2- or 3-language code list: Central and Mon-Khmer. We use the Central language as the majority language of Cambodia. |
      | Puerto Rico: IRS has used the (PR) suffix to indicate that the product is in Spanish, but (PR) is a locality suffix and will no longer indicate language. |


| **Language (\*\*\*See table notes.)** | **M&P System Abbreviation (\*\*Existing products will change on revision.)** | **PPMC Language Suffix (\*Change to existing suffix.)** | **Drupal Abbrev.** | **ISO Standard (2 or 3 digit)** |
| --- | --- | --- | --- | --- |
| English\*\*\* | (EN) | (en) | en | en |
| Chinese Traditional | (CN-T)\*\* | (zh-t)\* | zh-hant |  |
| Chinese Simplified | (CN-S) | (zh-s)\* | zh-hans |  |
| Haitian Creole | (HT) | (ht) | ht | ht |
| Korean | (KR)\*\* | (ko)\* | ko | ko |
| Russian | (RU) | (ru) | ru | ru |
| Spanish\*\*\* | (SP) | (sp) | es | es or spa |
| Vietnamese\*\*\* | (VN)\*\* | (vie)\* | vi | vi or vie |
| Arabic | (AR) | (ar) | ar | ar |
| Tagalog | (TL) | (tl) |  | tl |
| French | (FR) | (fr) | fr | fr |
| Japanese | (JA) | (ja) | ja | ja |
| Polish | (PL) | (pl) | pl | pl |
| Portuguese | (PT) | (pt) | pt | pt |
| Bengali |  | (bn) | bn | bn |
| Persian/Farsi\*\*\* |  | (fa) | fa | fa |
| Gujurati\*\*\* |  | (guj) | gu | gu or guj |
| Italian |  | (it) | it | it |
| Khmer\*\*\* |  | (km) | km | km |
| Punjabi |  | (pa) | pa | pa |
| Urdu |  | (ur) | ur | ur |
| German\*\*\* | (DE) | (de) | de | de |
| Chinese | (CN) | (zh)\* | zh | zh |
| Somalian\*\*\* | (SO) | (so) | so | so |
| Hebrew | (HE) | (he) | he | he |
| Multiple Languages |  | (mul) |  | mul |

**1.17.10.3.6.4.4** **(11-10-2022)**

###### Language Suffixes for Tax Forms and Schedules

1. A language version of a tax form is a translation of the form into a non-English language and carries a language suffix as described above. See IRM 1.17.10.4.6.3.2, _Schedules_, in the Associated Suffixes section for how schedules relate to tax forms.

2. Likewise, a translation of a schedule into a different language means that the non-English target language schedule has the same content as the English schedule.

3. In almost all cases, taxpayers use a schedule with a form in the same language as the schedule. However, the taxpayer may use a form and schedule of different languages if needed. For example, a taxpayer can use the Spanish translation of Schedule 3 with the English Form 1040. The English Schedule 3 for Form 1040 and Spanish Schedule 3 for Form 1040 are the same product written in different languages, and the language of the form or schedule should not affect the data on the form or its entry into IRS systems.

4. The schedule must exist in English before we can create the Item ID for the schedule translated into a different language. The English schedule is the parent of the target language child version schedule.

5. The business rule to create the Item ID for the language version follows the general rule that we add the language code to the end of the parent product’s Item ID.



1. The parent product schedule Item ID is in the format “Schedule” Schedule Name (Primary Form). For example, Schedule 3 (Form 1040) or Schedule K-1 (Form 1041).

2. For the target language child version, we add the language code (based on the ISO standard code list in IRM 1.17.10.4.6.4.3) to the end. This creates the Item ID in the format: “Schedule” Schedule Name (Primary Form) (Language Code). For example, Schedule K-1 (Form 1041) (so).


6. On tax forms and schedules, the form identification in the upper left corner is designated as user identification. We translate it into the language of the product, and the form number does not include the language code. The product identification in the bottom margin of the form is the official product identification, is always in English, and includes the language suffix.


**1.17.10.3.6.4.5** **(11-10-2022)**

###### Language Suffix Decision Matrix

1. How to use language suffixes on products depends on how much of the content we translate, how many languages we include, and how we construct the product. Because of the complexity, we created a decision matrix to clarify the decision criteria and result.

2. Basic principles for this decision matrix:



1. If a product is primarily in English or is a product with English and other languages, it is the “parent” or “base” product.

2. We consider products that are in English and include text in other languages that is not the full product text as English products, and they do not carry a language suffix or Product Title Version Identifier.

3. We use language suffixes on child products to indicate the languages in the product when we translate the full text. We use the ISO standard suffix "mul" for products with three or more languages. See _IRM 1.17.10.3.6.4.3_, _Language Suffix Table_, for details.

4. Product Title Version Identifiers (PTVI) use the one or two non-English languages or "Multiple languages." See _IRM 1.17.10.6.2_, _Non-English Product Titles_, for details.

5. The product description for translated child products uses standard language to refer the user to the English base parent for a full description for consistency across all language translations. While PPMC will carry the data on all languages to help with selecting the correct product, that data may not be available in all situations. Therefore, the product description must include the languages in the product.

6. Revision dates for base products follow normal revision date rules. Revision dates for child products match revision dates of English base products. See _IRM 1.17.10.4.4_, _Revision Dates on Translated Products_ for details.


This decision matrix table clarifies the decision criteria and result.



| **Type of Multilingual Product** | **Description** | **Example** | **Product ID** | **Product Title Version Identifier (PTVI)** |
| --- | --- | --- | --- | --- |
| English product with minor multi-language use | A product primarily in English but has some words, phrases, or sentences in one or more different language(s), such as names, locations, references, quotes, or translations of small amounts of text | A publication or form with references to Spanish names or a few sentences about where to find a Spanish translation of the product; a glossary of terms that translates words or phrases into other languages | No language suffixes | No PTVI |
| English product with translated content portions | A product primarily in English and has an English title, but some paragraphs or sections may be repeated in one or more additional languages | A repository notice that has an English title and text but repeats some paragraphs in other languages | No language suffixes | No PTVI |
| Complete product translation as a separate product | A product that is a complete translation of an English parent into one other language | The Vietnamese language translation version of a tax form | Language version that uses a language suffix | PTVI for the language of product |
| Complete product translation as a combined product; No separate English-only product | A product that has the same content (including the title) in both English and one other language | A repository notice that has the same content in English and Spanish, often with one on the front and the other on the back, where the Spanish translation is a full translation, including title and product ID and could stand on its own as a product | Language suffix with English and other language (e.g., en-sp) | PTVI for English and the second language (e.g., English & Spanish Version) |
| Complete product translation as a combined product; An English-only or previous English and other language(s) combined base product exists | A product that has the same content (including the title) in both English and one other language | A repository notice that has the same content in English and Spanish, often with one on the front and the other on the back, where the Spanish translation is a full translation, including title and product ID and could stand on its own as a product. | Language suffix with English and other language (e.g., en-sp) | PTVI for English and the second language (e.g., English & Spanish Version) |
| Complete product multiple translations as a combined product with English; No separate English-only product | A product that has the same content (including the title) in both English and multiple other languages | A repository notice that has the same content in English and multiple other languages, where the other languages are full translations, including title and Product ID and could each stand on their own as a product | Language suffix with English and the multiple language code "mul" (e.g. en-mul) | PTVI for English and multiple languages (e.g. English & Multiple Language Version) |
| Complete product multiple translations as a combined product with English. An English-only or previous English and other language(s) combined base product exists. | A product that has the same content (including the title) in both English and multiple other languages. | A repository notice that has the same content in English and multiple other languages, where the other languages are full translations, including title and Product ID and could each stand on their own as a product. | Language suffix with English and "mul" (e.g., en-mul) | PTVI for English and multiple languages (e.g. English & Multiple Language Version) |
| Complete product with multiple translations as a combined product without English | A product that is a translation of an English product or English and other languages product and contains multiple non-English languages; The product has some or all content repeated in two or more additional languages. English may appear as names, locations, references, quotes, and/or product identification. | A repository notice that has the text in Vietnamese, Urdu, Gujarati, and Punjabi, but does not include English text, and is a translation of the English notice | Language suffix "mul" (e.g., mul) | PTVI for multiple languages (e.g., Multiple Language Version) |

**1.17.10.3.6.5** **(11-10-2022)**

##### Locality Suffixes

1. Because tax laws can be different for territories of the United States, we create some versions of tax products specifically for one or more of those locations. We call these locality products.

2. We limit the use of the PR locality suffix in products. When possible, the English version of the product will include information a resident of Puerto Rico needs, and the Spanish or other language translation of that product will also contain the same information. This helps residents of Puerto Rico who need a translation in a language other than Spanish.


**1.17.10.3.6.5.1** **(08-14-2023)**

###### Locality Suffix Table

1. When we publish a product for a locality, we may create a child product from a general use parent product by adding the appropriate locality suffix to the end of the parent product’s Item ID.

2. The locality suffix is a two-digit code from the International Standards Organization (ISO) standard for countries enclosed in parenthesis. The United States Postal Service (USPS) also uses the ISO 3166 country code standard for international mail. Therefore, this usage aligns with the IRS use of the USPS country codes. The locality suffix codes are the same as the USPS state codes that are used consistently across the IRS. Examples for Puerto Rico, Guam, and American Samoa are respectively (PR), (GU), and (AS).

3. Notes on the Locality Suffix Table are:



1. The ISO 3166 Country Codes standard is available online at [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html).

2. Localities are territories of the United States or other situations where location of the taxpayer creates a difference in the applicable tax laws.

3. M&P System Abbreviation: This column identifies the locality code previously used in M&P systems.

4. PPMC Locality Suffix: This is the locality suffix used in the PPMC system and on all new products.

5. ISO Standard: This is the International Standards Organization country code used across industries and countries to identify a country or part of a country. Using the ISO standard means the product identification will be compatible with any other systems or uses that need to identify the country.

6. The existing Locality codes match the ISO standard, except for The Commonwealth of Northern Mariana Islands. Any new products created for this territory will use the ISO standard country code MP.


This table lists the Locality, M&P System Abbreviation, PPMC Locality Suffix and ISO Standard codes.



| **Locality** | **M&P System Abbreviation** | **PPMC Locality Suffix** | **ISO Standard** |
| :-: | :-: | :-: | :-: |
| Puerto Rico | (PR) | (PR) | PR |
| Guam | (GU) | (GU) | GU |
| Virgin Islands (US) | (VI) | (VI) | VI |
| American Samoa | (AS) | (AS) | AS |
| The Commonwealth of Northern Mariana Islands | (CM), (NMI) | (MP)\* | MP |

**1.17.10.3.6.5.2** **(11-10-2022)**

###### Use of Locality Suffixes

1. In some cases, the PPMC (or ESN) administrator may create a locality product when no general use parent product exists.

2. Locality and Language suffixes are independent of each other. A Spanish product for Puerto Rico has both the (PR) and (sp) suffixes.

3. For Schedules, the official item ID may have two references to the locality where appropriate (e.g., Schedule A-1 (PR) (Form 1234 (PR))). In this example, we write both the schedule and form specifically for Puerto Rican tax laws. There may not be a general use Schedule A-1 or a general use Form 1234.

4. The text product title must also be different between the parent and locality child products. Publishing adds a Product Title Version Identifier (PTVI) to the product title of the child product. The PTVI comes from the Locality Product Title table. Examples are (Puerto Rico) and (American Samoa).


**1.17.10.3.6.6** **(08-14-2023)**

##### Alternate Use Suffixes

1. Alternate Use suffixes are designations of products produced in an alternative format such as Braille, Large Print, or Accessible HTML. These formats are “media types” of the parent product but may be assigned their own catalog number for ordering purposes. The following table lists Alternate Use suffixes and their descriptions.




| **Suffix** | **Description** |
| --- | --- |
| BR | Braille |
| LP | Large Print |
| HTM | Accessible HTML |
| AU | Audio |
| TXT | Text |


**1.17.10.3.6.7** **(11-10-2022)**

##### Envelope Suffixes

1. For envelopes, Publishing may assign a suffix that designates the Mail Type.



   - If the envelope is a Courtesy Reply envelope, then “CR” is the assigned suffix and is displayed with a hyphen after the base number, according to the standard item ID format.

   - If the envelope is a Business Reply envelope, then “BR” is the assigned suffix and is displayed with a hyphen after the base number, according to the standard item ID format.


**1.17.10.3.6.8** **(11-10-2022)**

##### Multiple Suffixes

1. For items requiring multiple suffixes, the serial or associated suffix will appear first, followed by the language or locality version suffix.

2. Order alphabetically multiple suffixes within each of the categories.

3. A word space separates the serial or associated suffix and language or locality suffix.

4. The alternate use suffix, such as (LP) or (BR), appears as the last of multiple suffixes and is also separated by a word space.

5. Spanish Correspondex letters use a dual suffix of (C-SP).


**1.17.10.3.6.8.1** **(12-08-2025)**

###### Multiple Suffix Table

1. See the Product Number section of the Catalog Help webpage for a listing and examples of allowed multiple suffixes. At the linked site, click on Product Number and then scroll down to find the table.


**1.17.10.3.6.9** **(11-10-2022)**

##### Suffix Formats

1. Use of Special Characters, Syntax, Display, Examples, and ESN Special Rules can all apply to suffix formats.


**1.17.10.3.6.9.1** **(11-10-2022)**

###### Use of Special Characters

1. To facilitate electronic delivery of IRS products, do not use the following characters in suffixes: <, >, ’ ’, " ", or &


**1.17.10.3.6.9.2** **(12-17-2024)**

###### Syntax

1. In general, we use a hyphen “-” to join the base ID to the suffix, and to join multiple suffixes together, except when the suffix begins with a parenthesis, “(“, or the specific words identified in 1.17.10.4.6.9.3, Display of Product IDs.

2. Products that use an alpha base ID do not have either a word space or hyphen between the Base ID and a serial or associated suffix (E.g., W-4P, W-8IMY).

3. When we use multiple alternate use suffixes, we separate them by a word space.

4. We join dual-language suffixes by a hyphen within the parenthesis. See examples in _IRM 1.17.10.3.6.9.4_, _Examples of Product IDs with Suffixes_.


**1.17.10.3.6.9.3** **(11-10-2022)**

###### Display of Product IDs

1. We display Product IDs in the Catalog by putting a hyphen between the base ID and the suffix, unless:



   - the suffix starts with "("

   - the suffix starts with "Schedule"

   - the suffix starts with "and"

   - the suffix starts with "or"

   - the suffix starts with "&"


2. In the Catalog, we replace an ampersand used because of system character limits with “and.”


**1.17.10.3.6.9.4** **(08-14-2023)**

###### Examples of Product IDs with Suffixes

1. See IRM 1.17.10.4.6.8.1, _Multiple Suffix Table_, for allowable suffix combinations.

2. Examples of Product IDs with Suffixes are in the Product Number section of the Catalog Help webpage.


**1.17.10.3.6.9.5** **(11-10-2022)**

###### ESN Special Rules

1. The ESN system has limitations that require special rules when translating the system data for display.

2. ESN currently has 21 characters available in the suffix field; however, 5 characters are reserved for creating AMC versions of any new public-use item. Therefore, ESN suffixes have special input rules and may not identically match the suffix on the item itself.

3. Following suffix standards is vital to proper file naming by the CROPP Uploader program used to name files posted to the CROPP.

4. ESN Rules Table




| ESN Rule | Issue |
| --- | --- |
| Form 1040 Schedule A | No hyphen used when suffix begins with “Schedule” |
| Instructions 990 & 990 EZ | No hyphen used when suffix begins with “&” |
| Instructions 1040 or 1040-SR | No hyphen used when suffix begins with “or” |
| Instructions 8804, 8805 & 8813 | No hyphen when the base number is 00000 (five zeroes) |
| Form W-2 | Zero base number item |
| Form W-2 (GU) | Zero base number item with locality suffix |
| Form W2-G | Zero alpha base number item with serial suffix |


**1.17.10.3.7** **(11-10-2022)**

#### Item Type Specific Rules

1. Instructions accompany a corresponding tax form. The tax form serves as the parent product for the instructions and shares the same base ID.

2. A Tax Product Gatekeeper must create new tax instructions.

3. A parent form can only have one set of instructions to avoid duplication of item IDs.

4. Only the PPMC/ESN administrator can assign a non-standard ID.

5. The PPMC/ESN administrator can assign a general instruction that applies to multiple versions of a form with the same base ID.



1. Example: General instructions and specific instructions for Form 1099 MISC are “Instruction 1099 MISC” and “Instruction 1099 General,” where the general instruction applies to multiple versions of Form 1099 supplemented by the specific instruction for Form 1099 MISC.


6. In some cases, Instructions will be for multiple forms.



1. We place a conjunction between two parent products. For example,



      |     |
      | --- |
      | - Instructions for Form 1040 and Form 1041<br>        <br>      - Instructions for Form 1040 or Form 1041 |

2. If there are more than two parent products, then we place a conjunction before the last product and commas between all others. For example,



      |     |
      | --- |
      | - Instructions for Form 1040, Form 1041, and Form 1042<br>        <br>      - Instructions for Form 1040, Form 1041, or Form 1042 |


**1.17.10.4** **(11-10-2022)**

### Revision Dates

1. The first issue of an item is an “issue date,” all subsequent revisions are “revision dates.”

2. A revision date assigned to published products consists of the month and year (MM-YYYY) or the month, day, and year (MM-DD-YYYY) we make an item or revision available to its intended audience. Currently, only IRMs use day revision dates.

3. Tax, IRM, translated, and alternative media products have special rules as described in this section.

4. See IRM 1.17.9.6.2.2, _Revising Existing Published Products_, for responsibilities in revising published products. Full details of revision status are in Publishing Procedure 166, Changing Published Products to Obsolete or Historical/Published Product Status Changes, for M&P employees.


**1.17.10.4.1** **(11-10-2022)**

#### Tax Products

1. The Tax Item Classification (TIC), as Calendar Year, Year-Ahead, Quarterly, or Revision Date, controls the revision date format for Tax Products. All tax products must have a Tax Item Classification.


**1.17.10.4.1.1** **(11-10-2022)**

##### Calendar-Year Tax Item Classification

1. Calendar-year items are for a specific tax filing year and carry a revision date in the format YYYY.

2. When we revise a calendar-year item after it’s published, a small tax form revision date or tax publication/instruction composed date identifies the different revisions to help ensure that users receive the most recent product.


**1.17.10.4.1.2** **(11-10-2022)**

##### Year-Ahead Tax Item Classification

1. Year-ahead items are for a specific tax filing year and carry a revision date in the format YYYY.

2. These items generally have two active revisions for different tax filing years at the same time.


**1.17.10.4.1.3** **(11-10-2022)**

##### Quarterly Tax Item Classification

1. Quarterly items may have 1, 2, 3, or 4 revisions for a tax filing year.

2. The revision date is provided on the Publishing Services Request and TF&P can update it through the Composition Process Management (CPM) system.


**1.17.10.4.1.4** **(11-10-2022)**

##### Revision Date Tax Item Classification

1. We only revise revision date items when tax law requires and at any time during the year that is appropriate. We use the month and year we release the revisions for use as their revision date, just like most non-tax products.

2. We usually revise revision date items less often than once a year.


**1.17.10.4.1.5** **(08-14-2023)**

##### Annual Revision Tax Item Classification

1. The Annual Tax Item Classification category is no longer in use.


**1.17.10.4.1.6** **(11-10-2022)**

##### Information Return Tax Item Classification

1. We will eliminate this TIC and reclassify its items. We record Information Return information as a product attribute instead of a TIC.


**1.17.10.4.2** **(11-10-2022)**

#### Non-Tax Products

1. The revision date on non-tax products, except the IRM, is the month and year we release them for use in the format (M-YYYY) for the first issue of a product and (Rev. M-YYYY) for subsequent revisions.

2. The month of a revision date is 1 – 12, without a leading zero.

3. The IRM uses the format (MM-DD-YYYY), including leading zeros for month and day as appropriate.


**1.17.10.4.3** **(08-14-2023)**

#### Revision Status

1. The item status and revision status are different, referring to the whole item and the individual revision, respectively.

2. A publishing specialist creates a new revision for non-tax products.

3. For tax and some non-tax products, the Composition Process Management (CPM) system creates the revision in PPMC. When the CPM system does not update the ESN or PPMC system, the publishing specialist will create and maintain the revision based on a PSR and subsequent communication from the TF&P point of contact.

4. Once created, the revision is in “New” status. It remains new until we publish the revision and release it for use. While new:



   - The tax law specialist may change the revision date in CPM for items developed through CPM.

   - A decision not to publish can cancel the revision.

   - If canceled, we can reinstated the revision to a new status if the requester decides to restart developing the revision.


5. When the product originator signs off on the revision as OK to Publish, and the revision is published (released for use either electronically or in hard copy), the revision status becomes “Active.” Once active:



1. Occasionally, we may recall for correction a revision published with an error.



      |     |
      | --- |
      | •In PPMC, to retain a record of the recalled revision, the status changes to “Recalled” and give a new copy a revision status of new. The revision with recalled status becomes locked for historical reference. The revision with new status gets updated and published when the corrected revision is ready. The updated revision then becomes active. |
      | •In ESN, the revision status remains active while we make the revision correction. |

2. A tax product revision on the Prior Revision Distribution Program becomes “Prior Revision” when:



      |     |
      | --- |
      | •A newer revision becomes active. |
      | •The item is retired and made “Historical.” |

3. We make “Obsolete” a revision not on the Prior Revision Distribution Program:



      |     |
      | --- |
      | •For printed products, when we no longer need the previous revision to fill orders. |
      | •For electronic only products, when we make a newer revision active. |
      | •When the Item is retired and made obsolete. |

4. We may reinstate to active an obsolete or prior revision status revision based on a PSR request.


**1.17.10.4.4** **(11-10-2022)**

#### Revision Dates on Translated Products

1. When we translate a product into a non-English language, the revision date matches the revision date of the English parent. This ensures clarity that the content of the translation is from the English parent of the same date.

2. The translated revision date may be in Arabic numerals (1, 2, 3, etc.), or in numerals of the translated language as appropriate. However, the official product identification will always have the English (Arabic numeral) revision date.


**1.17.10.5** **(11-10-2022)**

### IRS Identification (Dept, Agency, URL, and Wayfinder)

1. The Department, Agency, URL, and Wayfinder are part of the product identification.

2. Guidance in Document 12749, _IRS Design Standards & Guidelines_, controls the placement, font, and style of these identification elements.


**1.17.10.6** **(08-14-2023)**

### Product Title

1. The Product Title is the text title that appears on the product.

2. The product title must be unique so that when users are looking for a product on a list of text titles, they will be able to tell what each product is.

3. The product title in the PPMC/ESN system should exactly match the title that appears on the product.

4. We consider any title used in the concept stages or other pre-publishing activities a working title until we assign the product ID and Publishing reviews the title during product development and design processes.


**1.17.10.6.1** **(08-14-2023)**

#### Product Title Guidelines

1. When deciding on a product title:



1. Spell out acronyms

2. Be specific enough to uniquely identify the product and provide search terms that narrow results; product titles must provide context and convey a minimal summary of its content, and should contain keyword(s) that are specific and recognizable to its users when searching the product catalog


2. Do not include in the product title:



1. Product ID or Item Type (E.g., “Form”)

2. “Flyer,” “Poster,” or other descriptors unless needed to make the product title unique in a series of products

3. Special characters like the Internal Revenue Code symbol

4. Revision dates, tax year, or fiscal year


**1.17.10.6.2** **(08-14-2023)**

#### Non-English Product Titles

1. Product titles are always in English in IRS systems, because IRS employees and the general public may not read all the foreign languages used on IRS products.

2. For products in a Non-English language, a Product Title Version Identifier (PTVI) is added to the end of the product title.

3. Guidance on the PTVI added comes from the Product Title Language Table below.

4. As an example, a form created in Spanish as a translation of the English form with the product title “Tax Form” would use the product title “Tax Form (Spanish Version)” in IRS systems.

5. Whenever possible, IRS systems should display an additional title field that contains the translated title to assist public Limited English Proficiency users.

6. The translated title appears on the product itself without the PTVI.

7. When a product uses two languages, the PTVI is the two languages joined by “and” (E.g. (Russian and Spanish Version).

8. When a product uses more than two languages, the PTVI is either "English & Multiple Language Version" or "Multiple Language Version". Include the specific languages in the Product Description.




| **Language** | **M&P System Suffix** | **PPMC Language Suffix (\*Change to existing suffix)** | **Product Title Version Identifier** |
| --- | --- | --- | --- |
| English | (EN) | (en) | (English Version) |
| Chinese Traditional | (CN-T) | (\*zh-t)\* | (Chinese-Traditional Version) |
| Chinese Simplified | (CN-S) | (zh-s)\* | (Chinese-Simplified Version) |
| Haitian Creole | (HT) | (ht) | (Haitian Creole Version) |
| Korean | (KR) | (ko)\* | (Korean Version) |
| Russian | (RU) | (ru) | (Russian Version) |
| Spanish | (SP) | (sp)\* | (Spanish Version) |
| Vietnamese | (VN) | (vie)\* | (Vietnamese Version) |
| Arabic | (AR) | (ar) | (Arabic Version) |
| Tagalog | (TL) | (tl) | (Tagalog Versions) |
| French | (FR) | (fr) | (French Version) |
| Japanese | (JA) | (ja) | (Japanese Version) |
| Polish | (PL) | (pl) | (Polish Version) |
| Portuguese | (PT) | (pt) | (Portuguese Version) |
| Bengali |  | (bn) | (Bengali Version) |
| Farsi |  | (fa) | (Persian/Farsi Version) |
| Gujarati |  | (guj) | (Gujarati Version) |
| Italian |  | (it) | (Italian Version) |
| Khmer |  | (km) | (Khmer-Central (Cambodia) Version) |
| Punjabi |  | (pa) | (Punjabi Version) |
| Urdu |  | (ur) | (Urdu Version) |
| German | (DE) | (de) | (German Version) |
| Chinese | (CN) | (zh)\* | (Chinese Version) |
| Somalian | (SO) | (so) | (Somalian Version) |


**1.17.10.6.3** **(11-10-2022)**

#### Locality Item Product Titles

1. For locality products, we assign the Product Title Version Identifier (or Product Title Identifier) according to the Product Title Locality Table.


**1.17.10.6.3.1** **(11-10-2022)**

##### Product Title Locality Table

1. | **Locality** | **M&P System Suffix** | **PPMC Locality Suffix** | **Product Title Version Identifier / Product Title Identifier** |
| --- | --- | --- | --- |
| Puerto Rico | (PR) | (PR) | (Puerto Rico Version) / (Puerto Rico) |
| Guam | (GU) | (GU) | (Guam Version) / (Guam) |
| Virgin Islands (U.S.) | (VI) | (VI) | (U.S. Virgin Islands Version) / (U.S. Virgin Islands) |
| American Samoa | (AS) | (AS) | (American Samoa Version) / (American Samoa) |
| The Commonwealth of Northern Mariana Islands | (CM) | (MP)\* | (The Commonwealth of Northern Mariana Islands Version) / (The Commonwealth of Northern Mariana Islands) |


**1.17.10.6.4** **(11-10-2022)**

#### Envelope Product Titles

1. Envelopes do not have a text title printed on the envelope. Therefore, we build a product title from various data about the envelope to create a unique product title that describes the envelope.

2. The product title for envelopes is in the format: Envelope – Mail Type, Customer Use, Content Format, Window Type. An example is, “Envelope – Courtesy Reply, General Purpose, Flats, Left Window-extended.”



1. Mail Type options: Mailer, Courtesy Reply, Business Reply, or Internal Use

2. Customer Use options: Campus Use, General Purpose, NDC Order Fulfillment, or MCC Tax Data

3. Content Format options: Tri-fold, Tri-fold – oversize, Bi-fold, Flats, or Flats – oversize

4. Window Type options: Double Window, Left Window, Left Window-extended, Right Window, Mail/Ship Window, or No Window


**1.17.10.6.5** **(11-10-2022)**

#### Template Product Titles

1. Templates do not have a printed text title on them. The visual information specialist (VIS) in Publishing creates the title based on the following information. This results in a unique product title that describes the template.

2. The product title for templates is in the format: Template – Service Type, Template Type, Template Style, Wayfinder, Mail Merge, Signature. An example is: “Template – Self-Service, Certificate, Classic, BOD, With Mail Merge, Signature x 2”



1. The two options for the Service Type are Self-Service and VIS-Assisted. Self-Service templates are available on the Publishing webpage for IRS employees to download and use. Publishing VISs use VIS-Assisted templates to create a product revision.

2. The Template Type categorizes the use of the template. There are different categories for Self-Service templates and VIS-Assisted Templates. Template Type options include:



      |     |
      | --- |
      | - If Self-Service: Agenda, Bi-fold, Certificate, Flyer, Generic Multi-Page, Generic One-Page, Information Sheet, Multi-Page Job Aid, Name Tag, One-Page Job Aid, Presentation, Presentation (PowerPoint), Report, Retirement Flyer, Table Tent |
      | - If VIS-Assisted: Audit Technique Guide (ATG), Critical Job Elements (CJE), Newsletter |

3. Template Style indicates the template's design style. Template Style options: Classic, Grid, Grid Angle, Grid Angle Blue, Grid Angle Color, Iconic, One Voice, One Voice Dots, Wave

4. The Wayfinder is an indicator on the product that identifies the IRS organization that created the product. Wayfinder options (not applicable for ATG template type): BOD, BOD and Office

5. Some templates are useful in a mail merge to create individualized communications. Mail Merge options: With Mail Merge, Without Mail Merge

6. Certificate templates may or may not require one or two signature(s). Signature options (only for Certificate template type): Signature x 1, Signature x 2


**1.17.10.7** **(11-10-2022)**

### Non-English and Locality Products

1. This section describes how Publishing handles particular issues with products translated into Non-English language(s) and Locality products.


**1.17.10.7.1** **(11-10-2022)**

#### Translated Products

1. Product identification on a translated product serves two distinct purposes. The identification must be readable and usable to the taxpayer or other user in the non-English language. It also must properly reflect the official identification as it appears in IRS systems for product management in the development, publishing, and distribution processes.

2. Publishing has design standards for various types of products, including tax forms, non-tax forms, tax publications and instructions, non-tax publications, documents, repository notices, repository form letters, the IRM and other specialty products. Language and locality products primarily affect tax products and taxpayer communication products like repository form letters and repository notices, and some other non-tax public use products. Language and locality products do not affect Internal Use products, because they are only created in English.

3. Each published product has a "user content product ID" and an "official product ID". The design standards identify the user content product ID, which focuses on helping the public end-user with limited English proficiency identify the published product correctly. We translate the user content product ID into the non-English target language so the user can read it easily.

4. The design standards also identify the placement of the English official product ID designed for use by IRS employees, tax preparers and other English-speaking users. These users need a standard placement to easily find the product ID and cannot be expected to read the translated product ID.

5. The general rules for translated products are: (See _IRM 1.17.10.8.2_, _Tax Forms in Non-English Languages Product ID Placement_; _IRM 1.17.10.8.3_, _Non-Tax Form Product ID Placement_; _IRM 1.17.10.8.5_, _Tax Publications in Non-English Languages Product ID Placement_; _IRM 1.17.10.8.7_, _Non-Tax Publications in Non-English languages Product ID Placement_; and _IRM 1.17.10.8.9_, _Repository Notices in Non-English Languages Product ID Placement_, for examples.)



1. We translate the prominently placed product ID in the header, but the language suffix is not included. Form 1234 (sp) (Rev. 10-2020) and Publication 123 (sp) (2020) in the system become Formulario 1234 (Revisión 10-2020) and Publicación 123 (2020) on the product in the header area.



      |     |
      | --- |
      | - When the language of the product reads right to left, we translate the header, and the order changes to right to left. |
      | - For products where elements of the official product ID appear above the footer area, such as “Department of the Treasury Internal Revenue Service” on public-use non-tax forms, we do not translate this text into the user’s language. |

2. We translate the product title, not including the product title version identifier. “Tax Form (Spanish Version)” in the system becomes “Formulario de Impuestos” in the product header.

3. There is a designated area on each product, usually at the bottom of the page (footer), where the official product ID displays in English. This includes the Department, Agency, URL, Wayfinder, Catalog Number, Item ID including language or locality suffix, and revision date.



      |     |
      | --- |
      | When the language of the product reads right to left, we do not translate the footer, and the order remains left to right as in English. |


6. The Product Description for the Product Catalog should state that the product is a translation of the parent product ID. It is not necessary to include the parent‘s product description.

7. We list the parent product as the Related Product in the Catalog to allow easy reference.

8. We include the revision date of the parent product being translated in the Revision Remarks so that the Catalog displays which revision of the parent’s content has been translated.


**1.17.10.7.2** **(12-17-2024)**

#### Locality Products

1. Locality products include the locality suffix ((GU), (VI), (AS), (MP), or (PR)) in both the product identification for the user and in the official identification.

2. If we translate a Locality product into a non-English language for that locality, then it will include the locality suffix, but not the language suffix, in the product identification for the user. The English official product identification includes both the locality and language suffixes.

3. See _IRM 1.17.10.8.11_, _Locality Product ID Placement_, for more details.


**1.17.10.8** **(08-14-2023)**

### Product ID Placement on Product

01. The IRS Design Standards dictate the placement of the product ID on the physical product.

02. The Publishing function design groups (the IRS Design, Internal Forms Design, and Composition groups) retain the standards for font face, size, etc., as well as other placement standards defined in Document 12749, _IRS Design Standards & Guidelines_, Document 13463, _Design Guidelines for Tax Forms_, and Document 12616, _Design Guidelines for IRS Internal and Tax-Related Public Use Forms_.

03. Deviations or alterations necessary due to space limitations on the product are also at the discretion of the design groups if the official Product ID components of item type, item number, suffix and issue/revision date are consistently applied.

04. The product identifier consists of several elements typically displayed on products. The elements are:



    - Item type

    - Base ID

    - Optional Suffix

    - Issue/Revision Dates

    - Catalog Number

    - The words “Department of the Treasury”

    - The words “Internal Revenue Service”

    - The Intranet website address “publish.no.irs.gov/ephome.html” for internal use items or the external IRS website address “irs.gov” for public use items.

    - Wayfinder

    - Miscellaneous products carry a “signature” that has the requisition number in place of some of the information mentioned above


05. Only visual information specialists from the IRS Design Office, Publishing’s Electronic Composition section staff, members of the Internal Forms Design group, or publishing specialists may place or edit product identifiers on products.

06. Any other designated official who wishes to place or edit identifiers on products must seek approval from the IRS Design Office or the director of the Publishing function.

07. Online forms, templates, or other information-gathering tools used to gather data from multiple people in a standard process on an ongoing basis must carry an official IRS Form number. That allows IRS employees who want to participate in the business process and submit data can find the online form through the Published Product Catalog. This also applies when a custom-built online application replaces a traditional PDF form, and when we create a new online data collection tool. The Identification elements required in data-collection and information-gathering tools include:



    - Product ID (Item Type, Base ID, Optional Suffix, Issue/Revision Date)

    - Catalog Number

    - Department and Agency identification (The words "Department of the Treasury" and "Internal Revenue Service")


Place these elements in the header or footer as appropriate for the situation. The IRS Design Office or the director of the Publishing function must review and approve the placement.



08. If Publishing approves an exception, then the designated official must provide the IRS Design Office with a new file to ensure proper file management.

09. The IRS Product Identifier must appear on products made from substrates other than paper, such as computer disks and packaging. Product content owners/originators may contact the IRS Design Office for answers to any questions regarding which non-print products require the use of this identification.

10. For published products created prior to 2009, Publishing must apply a current Product Identifier to any reprints or revisions for that product as time and budgetary constraints allow.

11. See IRM 1.17.7.2.5, _Product Identification_, and Document 12749, _IRS Design Standards & Guidelines_, for details.


**1.17.10.8.1** **(11-10-2022)**

#### Tax Forms Product ID Placement

1. We consider the tax form item ID in the upper left corner as content for the form user.

2. The tax form identification in the bottom right margin is the official product ID that includes the revision date.

3. The tax form official product ID must match the business rules for Product Identification and will match the Published Product Media Catalog (PPMC) identification. Restrictions in ESN mean that the ESN display will not always exactly match the official product ID.



**Figure 1.17.10-2**

![This is an Image: 75322002.gif](https://www.irs.gov/pub/xml_bc/75322002.gif)





> Figure 2 Tax Forms Product ID Placement Figure 2 shows the header and footer area of a tax form with the product ID elements marked. In the header area in the upper left, “Form 1120” is user content identification. Below it, “Department of the Treasury Internal Revenue Service” Department and Agency are part of the official product ID. In the upper right, “OMB No. 1545-0,” the OMB number, is part of the official ID. Below it, “2020” revision is user content identification. In the bottom margin, “Cat. No. 14450Q Form 1120 (2020)” is the official product ID.







[Please click here for the text description of the image.](https://www.irs.gov/media/342026 "")


**1.17.10.8.2** **(08-14-2023)**

#### Tax Forms in Non-English Languages Product ID Placement

1. We consider the ID on tax forms in the upper left corner as content for the form user. It does not need the language code because it is in the translated language. A translated user content ID may also appear in the upper portion of subsequent pages.

2. The identification in the bottom right margin on all pages of tax forms is the official product ID that includes the revision date. This product ID must match the business rules in _IRM 1.17.10.3_, _Item IDs_, and _IRM 1.17.10.4_, _Revision Dates_.

3. The tax form official identification will match the Published Product Media Catalog (PPMC) identification.

4. Restrictions in ESN mean that the ESN display will not always exactly match the official identification.

5. The tax form official product ID is in English and contains the language code. The catalog number in the bottom margin is also in English.



**Figure 1.17.10-3**

![This is an Image: 75322003.gif](https://www.irs.gov/pub/xml_bc/75322003.gif)





> Figure 3 Tax Forms in Non-English Languages Product ID PlacementFigure 3 shows the header and footer area of a tax form in Spanish with the product ID elements marked. In the header area in the upper left, “Anexo 3 (Formulario 1040)” is user content identification and is translated. Below it, “Department of the Treasury Internal Revenue Service” Department and Agency is part of the official product ID and is in English. In the upper right, “OMB No. 1545-0,” the OMB number, is part of the official ID in English. Below it, “2020” revision is user content identification and would be translated. In the bottom margin, “Cat. No. 14450Q Schedule 3 (Form 1040) (sp) (2020)” is the official product ID in English, including the language code (sp).







[Please click here for the text description of the image.](https://www.irs.gov/media/342031 "")


**1.17.10.8.3** **(11-10-2022)**

#### Non-Tax Form Product ID Placement

1. We design non-tax forms according to either public-use or internal-use design standards.

2. The same principles described for English and translated tax forms apply to public -use forms, although specific locations of the identification elements on non-tax forms vary from those on tax forms.



1. Public-use form header and footer examples shows the user identification in the upper left corner. The official identification of Product ID, Catalog Number, and Web address is in the form footer. The Department and Agency is in the center top, and the OMB Number is in the upper right corner.



      **Figure 1.17.10-4**

      ![This is an Image: 75322004.gif](https://www.irs.gov/pub/xml_bc/75322004.gif)





      > Figure 4 Public Form Header and FooterFigure 4 displays the header and footer area of a non-tax public use form. In the header area from left to right are: “Form 13614-C” with “(October 2020)” below it, “Department of the Treasury - Internal Revenue Service” centered with the title “Intake/Interview & Quality Review Sheet” below it, and “OMB No. 1545-1984” in the upper right. In the bottom margin footer, “Catalog Number 52121E” is left justified, “www.irs.gov” is centered and “Form 13614-C (Rev. 10-2020)” is right justified.







      [Please click here for the text description of the image.](https://www.irs.gov/media/342036 "")

2. Translated public-use forms in one and two languages that read left to right show the user identification in the upper left translated, while the official identification of Product ID, Catalog Number and website, OMB Number, and Department and Agency in the lower margin, upper right, remain in English. The user identification does not include the language suffix. We translated the title into the target language.



      **Figure 1.17.10-5**

      ![This is an Image: 75322005.gif](https://www.irs.gov/pub/xml_bc/75322005.gif)





      > Figure 5 Public Form Left to RightFigure 5 shows the header and footer area of a non-tax public use form in Spanish. In the header area from left to right are: “Formulario 13614-C” with “(octubre de 2020)” below it, “Department of the Treasury - Internal Revenue Service” centered with the title “Hoja de Admision/Entrevista y Verificacion de Calidad” below it, and “OMB No. 1545-1984” in the upper right. In the bottom margin footer, “Catalog Number 52285Z” is left justified, “www.irs.gov” is centered and “Form 13614-C (sp) (Rev. 10-2020)” is right justified.







      [Please click here for the text description of the image.](https://www.irs.gov/media/342041 "")





      **Figure 1.17.10-6**

      ![This is an Image: 75322006.gif](https://www.irs.gov/pub/xml_bc/75322006.gif)





      > Figure 6 Public Form Two LanguagesFigure 6 displays the header and footer areas of a non-tax public use form with one header/footer combination in English and a translated header/footer pair in Spanish. In the English header area from left to right are: “Form 15080” with “(July 2020)” below it, “Department of the Treasury - Internal Revenue Service” centered with the title “Consent to Disclose Tax Return Information to VITA/TCE Tax Preparation Sites” below it. In the bottom margin footer, “Catalog Number 71414A” is left justified, “www.irs.gov” is centered and “Form 15080 (en-sp) (Rev. 7-2020)” is right justified. In the Spanish header area from left to right are: “Formulario 15080” with “(Julio de 2020)” below it, “Department of the Treasury - Internal Revenue Service” centered with the title “Consentimiento para Divulgar la Informacion de la Declaracion de Impuestos a los Sitios de Preparacion de Impuestos de VITA/TCE” below it. In the bottom margin footer, “Catalog Number 71414A” is left justified, “www.irs.gov” is centered and “Form 15080 (en-sp) (Rev. 7-2020)” is right justified. The Spanish translation has the same footer containing the official identification as the English.







      [Please click here for the text description of the image.](https://www.irs.gov/media/342046 "")

3. Translated public-use forms in languages that read right to left show the user identification moved to the upper right and translated, while the official identification of Product ID, Catalog Number and website in the lower margin, and the Department and Agency in the upper center, remain in English reading left to right. The user identification does not include the language suffix. We translated the title into the target language.


**Figure 1.17.10-7**

![This is an Image: 75322007.gif](https://www.irs.gov/pub/xml_bc/75322007.gif)

> Figure 7 Public Form Right to LeftFigure 7 shows the header and footer area of a non-tax public use form in Arabic. In the header area the user identification reads in the direction of the target language. From left to right are: “Department of the Treasury - Internal Revenue Service” centered with the Arabic title below it, and in the upper right the Arabic form number with the Arabic revision date in parenthesis below it. In the bottom margin footer, which is in English and reads left to right are “Catalog Number 71516X” left justified, “www.irs.gov” centered and “Form 15080 (ar) (Rev. 7-2020)” is right justified.

[Please click here for the text description of the image.](https://www.irs.gov/media/342051 "")

3. We do not translate Internal-use forms into other languages, so there is no need to designate separate user content and official product IDs for internal forms. The official identification is in the lower margin on internal-use forms.



**Figure 1.17.10-8**

![This is an Image: 75322008.gif](https://www.irs.gov/pub/xml_bc/75322008.gif)





> Figure 8 Internal Form IDFigure 8 shows the footer area of an internal use form. From left to right are “Form 9589-A (Rev. 6-2016)” left justified, “Catalog Number 66714F” and “publish.no.irs.gov” centered and “Department of the Treasury - Internal Revenue Service” right justified.







[Please click here for the text description of the image.](https://www.irs.gov/media/342056 "")


**1.17.10.8.4** **(08-14-2023)**

#### Tax Publication Product ID Placement

1. Tax publications authors use an XML authoring tool to compose the products through an automated composition process. This produces a standard layout for tax publications.

2. The top left corner tax publication product ID is content for the user. The Revision date is spelled out as (2018), (February 2018), or (Rev. February 2018).

3. The tax publication Department and Agency are located with the IRS logo.

4. The tax publication official product ID is in the bottom margin in English and includes the date composed, the catalog number, and the product ID.

5. The tax publication product ID includes the revision date in the format (YYYY), (Rev. YYYY), (M-YYYY), (MM-YYYY), (Rev. M-YYYY), or (Rev. MM-YYYY). We include “Rev.” when there is a previous revision. Leading zeroes do not appear in one-digit months.

6. On inside pages of tax publications, we place the page number at the outside margin of the page and the Product ID or other text footer entered by the Tax Law Specialist is justified to the inside margin, giving the most space for longer Product IDs or other text footer.



**Figure 1.17.10-9**

![This is an Image: 75322009.gif](https://www.irs.gov/pub/xml_bc/75322009.gif)





> Figure 9 Sample User Content ID and Official Product IDFigure 9 shows the header and footer area of a tax publication. In the upper left of the header area is the IRS logo with the user content identification “Publication 947” and “Practice Before the IRS and Power of Attorney” below it. In the footer official product identification from left to right are “Publication 947 (Rev. 2-2018),” “Catalog Number 13392P,” “Department of the Treasury - Internal Revenue Service” and “www.irs.gov” left justified.







[Please click here for the text description of the image.](https://www.irs.gov/media/342061 "")


**1.17.10.8.5** **(11-10-2022)**

#### Tax Publications in Non-English Languages Product ID Placement

01. Tax Publications in non-English languages are a translation of the English parent. The primary difference is that we do not translate official product identification; that remains in English.

02. For Tax Publications, we translate the top left corner ID as content for the user. We do not include the language suffix in the translated ID, and we spell out the revision date as (2018), (February 2018), or (Rev. February 2018).

03. We do not translate the Department and Agency on tax publications that are located with the IRS logo.

04. The official product ID on tax publications is in the bottom margin in English and includes the date composed, the catalog number, and the product ID.

05. The tax publication product ID includes the revision date in the format (YYYY), (Rev. YYYY), (M-YYYY), (MM-YYYY), (Rev. M-YYYY), or (Rev. MM-YYYY). We include “Rev.” when there is a previous revision. Leading zeroes do not appear in one-digit months.



    **Figure 1.17.10-10**

    ![This is an Image: 75322010.gif](https://www.irs.gov/pub/xml_bc/75322010.gif)





    > Figure 10 Sample User Content ID Translated and Official Product ID in EnglishFigure 10 shows the header and footer area of a tax publication in Spanish. In the upper left of the header area is the IRS logo with the user content identification “Publicacion 947” and “Como Ejercer ante el Servicio de Impuestos Internos (IRS) y el Poder Legal” below it. The language code is not included in the publication number. In the footer official product identification from left to right are “Publication 947 (sp) (Rev. 2-2018),” “Catalog Number 13392P,” “Department of the Treasury - Internal Revenue Service” and “www.irs.gov” left justified. The language code (sp) is included in the Publication number.







    [Please click here for the text description of the image.](https://www.irs.gov/media/342066 "")

06. The bottom margin of the cover of the tax publication is the official product identification. It remains in English and includes any language suffix.

07. The tax publication issue/revision date is in the format (YYYY), (MM-YYYY), or (Rev. MM-YYYY), where the MM is the one or two-digit number of the month.

08. The Catalog Number is in the bottom margin of the tax publication and is in English. In the example “Cat. No. NNNNNA,” NNNNN is the 5-digit numeric catalog number and A is the alphabetic check digit.

09. The composition date of the tax publication XML file (this helps identify the version of a calendar-year item) is in the lower left margin in English.



    **Figure 1.17.10-11**

    ![This is an Image: 75322011.gif](https://www.irs.gov/pub/xml_bc/75322011.gif)





    > Figure 11 Tax Publication in Non-English Language Internal Page Product ID PlacementFigure 11 shows the footer area of internal pages of a tax publication in Spanish. The footer of the pages inside the publication is user content and is translated. "Publicacion 947 (Febrero 2018)," is right justified on page 2. The language code (sp) is not included in the Publication number.







    [Please click here for the text description of the image.](https://www.irs.gov/media/342071 "")

10. The bottom margin of the subsequent pages in a tax publication is product identification for the user. The translated Product ID includes the revision date but not the language suffix.


**1.17.10.8.6** **(11-10-2022)**

#### Non-Tax Publication Product ID Placement

1. Non-tax publications are not as standard as tax publications and have a larger variety of layouts than tax publications. The general concepts are the same, however.

2. Non-tax publications should prominently place user content identification that includes at least the product ID and title.

3. The official product ID, which matches the Published Product Media Catalog, is in the bottom margin or other standard placement on the non-tax publication. The identification line includes the Item ID, Revision Date, Catalog Number, and Department and Agency identification.



**Figure 1.17.10-12**

![This is an Image: 75322012.gif](https://www.irs.gov/pub/xml_bc/75322012.gif)





> Figure 12 PublicationFigure 12 displays the footer area of a non-tax publication. From left to right the footer contains “Publication 4806 (Rev. 10-2016),” “Catalog Number 53787K,” “Department of the Treasury Internal Revenue Service” and “www.irs.gov.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342076 "")


**1.17.10.8.7** **(11-10-2022)**

#### Non-Tax Publications in Non-English Languages Product ID Placement

1. As with tax publications, we translate into the non-English target language the user content identification on the cover or front page of the non-tax publication.

2. The official product ID on a non-tax publication is in the bottom margin of the cover/first page or in another standard location as determined by the design standards. We do not translate the official identification elements.

3. We translate the product ID on interior pages of a non-tax publication, if any, and considered it as user content.



**Figure 1.17.10-13**

![This is an Image: 75322013.gif](https://www.irs.gov/pub/xml_bc/75322013.gif)





> Figure 13 Publication - One LanguageFigure 13 displays the footer area of a non-tax publication in Spanish. From left to right the footer contains “Publication 4806 (sp) (Rev. 10-2016),” “Catalog Number 53787K,” “Department of the Treasury Internal Revenue Service” and “www.irs.gov.” The official ID is in English and the publication number includes the (sp) language code.







[Please click here for the text description of the image.](https://www.irs.gov/media/342081 "")





**Figure 1.17.10-14**

![This is an Image: 75322014.gif](https://www.irs.gov/pub/xml_bc/75322014.gif)





> Figure 14 Publication - Two LanguagesFigure 14 displays the footer area of a non-tax publication in English and Spanish. From left to right the footer contains “Publication 4806 (en-sp) (Rev. 10-2016),” “Catalog Number 53787K,” “Department of the Treasury Internal Revenue Service” and “www.irs.gov.” The official ID is in English and the publication number includes the (en-sp) dual language code.







[Please click here for the text description of the image.](https://www.irs.gov/media/342086 "")


**1.17.10.8.8** **(08-14-2023)**

#### Repository Notice Product ID Placement

1. We produce pre-printed repository notices in the Notice numbering series, often referred to “stuffers” or “inserts,” in two layouts. “Insert” repository notices are a single 3-1/3” x 8-1/2” sheet that fits into a standard business envelope without folding. We print other repository notices on a standard 8-1/2” x 11” paper and fold them to fit in a standard business envelope.

2. Like other products translated into other languages, repository notices have a user content identification in a prominently placed position that is translated for the user and does not include a language code.

3. The bottom of the repository notice carries an English identification for use by English readers and includes the official product number, revision date, language code, and catalog number.



**Figure 1.17.10-15**

![This is an Image: 75322015.gif](https://www.irs.gov/pub/xml_bc/75322015.gif)





> Figure 15 Repository Notice Product ID PlacementFigure 15 displays the header and footer area of a repository notice. In the header area, the IRS logo is at the top, with “Notice 1447 (May 2020)” and “Important! Your balance due may include payments that you deferred” below it as user content identification. The footer has three lines of identification. The first is “Notice 1447 (5-2020) Catalog Number 74528T,” the second line is “Department of the Treasury Internal Revenue Service” and the third line is “www.irs.gov.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342091 "")


**1.17.10.8.9** **(11-10-2022)**

#### Repository Notices in Non-English Languages Product ID Placement

1. Repository notices translated into non-English languages also have the prominent translated user content in a prominently placed position. The translated product ID does not include the language suffix.

2. The repository notice official product ID in the lower margin is always in English and includes the Product ID, including the language suffix and revision date, the Catalog Number, Department and Agency identification, and website.



**Figure 1.17.10-16**

![This is an Image: 75322016.gif](https://www.irs.gov/pub/xml_bc/75322016.gif)





> Figure 16 Non-English Repository Notice Product ID PlacementFigure 16 displays the header and footer area of a repository notice in Spanish. In the header area, the IRS logo is at the top, with “El Aviso 1447 (Mayo de 2020)” and “Importante! Su saldo adeudado puede incluir los pagos que usted difirio” below it as user content identification that is translated. The language code (sp) is not included in the repository notice number. The footer has three lines of official identification in English and the repository notice number includes the (sp) language code. The first line is “Notice 1447 (5-2020) Catalog Number 74528T,” the second line is “Department of the Treasury Internal Revenue Service” and the third line is “www.irs.gov.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342096 "")


**1.17.10.8.10** **(11-10-2022)**

#### Document Product ID Placement

1. A document is, by definition, an internal use product. It can be almost any type of product that does not fall into one of the other special groups of internal products such as IRM, Forms, or Training Publications. Because it is internal use, a document does not need a separate user content identification and carries only an official product ID.

2. The standard identification for documents contains the product ID-- including the revision date as (M-YYYY), (MM-YYYY), (Rev. M-YYYY), or (Rev. MM-YYYY)--catalog number, department and agency, and the intranet site address where the product is available.

3. Some documents have unique designs, and the Visual Information Specialist will determine the correct placement for the product identification in those circumstances.



**Figure 1.17.10-17**

![This is an Image: 75322017.gif](https://www.irs.gov/pub/xml_bc/75322017.gif)





> Figure 17 Document Product ID PlacementFigure 17 displays the footer area of a document. The footer is one line and is always in English. The identification is “Document 12880 (Rev. 1-2020) Catalog Number 55843D Department of the Treasury Internal Revenue Service publish.no.irs.gov.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342101 "")


**1.17.10.8.11** **(11-10-2022)**

#### Locality Product ID Placement

1. We handle locality products the same as other products for identification.

2. Because locality products are also in English by default, a locality product may carry both a locality suffix and a language suffix, if translated. For instance, a product for use in Puerto Rico because of tax law differences for Puerto Rico residents that is translated into Spanish can have the suffixes “(PR) (sp).”

3. A locality product published in two languages has a combination language suffix, such as (en-sp).



**Figure 1.17.10-18**

![This is an Image: 75322018.gif](https://www.irs.gov/pub/xml_bc/75322018.gif)





> Figure 18 Locality Product ID PlacementFigure 18 displays the footer area of a Publication for use in Puerto Rico in English and Spanish. The footer has the official identification in English and the Publication number includes the (PR) locality suffix and the dual (en-sp) language code. The identification line is “Publication 4806 (PR) (en-sp) (Rev. 10-2016) Catalog Number 53787K Department of the Treasury Internal Revenue Service www.irs.gov.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342106 "")


**1.17.10.8.12** **(08-14-2023)**

#### Product Identifiers Prior to 2009

1. Figure 19 shows how publications M&P produced may have used the old IRS Product Identifier or the old IRS Signature. Publishing must update products produced with Product Identifiers prior to 2009 to meet current standards if owners or product originators submit them for reprint or revision.



**Figure 1.17.10-19**

![This is an Image: 75322019.gif](https://www.irs.gov/pub/xml_bc/75322019.gif)





> Figure 19 IRS Historical Product IdentificationFigure 19 shows two images. The image on the left is the old IRS product identifier. The image on the right is the old IRS signature. The old IRS product identifier consists of a one-column, four-row table with line separators at the top and bottom of each row and no side borders. The first row contains the IRS symbol (eagle) followed by the acronym "IRS." The second row contains the words "Department of the Treasury" stacked with the words "Internal Revenue Service" (in bold font). The third row contains the Publishing website https://publishing.no.irs.gov. The fourth row contains the word "Document" and the ID number (1234) followed by the revision date (01-2009) stacked with words "Catalog Number" and the product catalog number (12345X). The old IRS signature consists of a one-column, three-row table with line separators at the top and bottom of each row and no side borders. The first row contains the IRS symbol (eagle) followed by the acronym "IRS." The second row contains the words "Department of the Treasury" stacked with the words "Internal Revenue Service" (in bold font). The third row contains the IRS.gov website “www.irs.gov.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342111 "")


**1.17.10.9** **(11-10-2022)**

### Changing Product IDs

1. In some cases when we revise products, we change product IDs to align those products with these standards.

2. When possible and appropriate, the text “Previously Identified As” followed by the previous product ID should appear in the official ID in the bottom margin of the product to help users understand the transition of the product ID.

3. The previous identification generally appears below the official product ID. The design standards will designate the specifics of how to place this on the product.



**Figure 1.17.10-20**

![This is an Image: 75322020.gif](https://www.irs.gov/pub/xml_bc/75322020.gif)





> Figure 20 Use of Previously Identified AsFigure 20 displays the footer area of a publication in English and Spanish where the product ID has been changed by adding the language code. The footer has the official identification in English and the publication number includes the dual (en-sp) language code. The identification lines are “Publication 4857 (en-sp) (Rev. 12-2020) Catalog Number 55009Z.” The second line is “Department of the Treasury Internal Revenue Service www.irs.gov.” Below this is “Previously Identified As Publication 4857.”







[Please click here for the text description of the image.](https://www.irs.gov/media/342116 "")


**1.17.10.10** **(11-10-2022)**

### File Naming

1. Consider naming product files for the Core Repository of Published Products (CROPP) and IRS.gov when creating product IDs, especially in non-standard product IDs.

2. M&P employees should see Publishing Procedure 185, Core Repository of Published Product File Naming Standards, for details on the standards for naming files.

3. Each product and revision must have a unique file name.

4. When product IDs on active products change to match these standards, we must change the file names of all revisions in the CROPP in coordination with publishing the product revision.

5. We restrict IRS.gov file names to eight characters and assign them manually to be unique. Once assigned, the file name does not change, and only contains revision information in the file name for prior revision products.


**1.17.10.11** **(08-14-2023)**

### Frequent Periodicals

1. Any product planned for distribution more than once to a group of people that is larger than 10 outside the person’s workgroup/section/branch/division should have a product number. This is especially the case if the product is giving out information that someone may later have to reference, especially for information on how they did their job, managed their employees, recorded their time, and related activities, or conveys policy or procedures. See the section on “How to determine what needs an official product number” in this document and in IRM 1.17.9.6.1.1, _Officially Published Products_.

2. Frequent periodicals are a special case, because periodical issues come out too frequently (E.g., daily or weekly) for the normal PSR and PPMC/ESN revision process to be efficient. In some limited cases, products of a similar nature are issued less frequently or less regularly.

3. Publishing assigns a document or publication number to the product, the Design office helps with the proper design and product ID placement on a template for the product, and the originating office fills in the issue’s variable information, including a unique identifier that can be the date of the issue and/or volume and issue numbers, and distributes the product electronically.

4. The product template can have an assigned template number. We can revise it independently to change template graphics, themes, layout, etc.

5. The originating office must maintain an archive of the periodical’s issues for future reference. The product description in PPMC/ESN and the Catalog contains the URL for that archive so employees can find the issues.

6. Almost all frequent periodicals will now be electronic only, and thus require an identifier whether the product is print, print and electronic, or electronic-only.

7. Update ESN/PPMC only when the originator/originator office changes, we revise the template/banner, or we obsolete the product. Template/banner revisions require a PSR.

8. A graphic used for an executive’s email messages is different from the banner for a newsletter. We do not consider email banners for ad-hoc use as periodicals.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-017-010#addtoany "Show all")

A2A