---
url: "https://www.irs.gov/irm/part1/irm_01-004-031"
title: "1.4.31 Quality Assurance Review Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-031#main-content)

- 1.4.31  [Quality Assurance Review Program](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434763824)
  - 1.4.31.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434901904)
    - 1.4.31.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434889856)
    - 1.4.31.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434880736)
    - 1.4.31.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434874736)
      - 1.4.31.1.3.1  [CFO](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434871456)
      - 1.4.31.1.3.2  [Statistics of Income](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434863280)
      - 1.4.31.1.3.3  [Business Units](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434859056)
    - 1.4.31.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434852608)
    - 1.4.31.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434561984)
    - 1.4.31.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434559968)
    - 1.4.31.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434513408)
    - 1.4.31.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434493584)
  - 1.4.31.2  [Quality Assurance Review Program Framework](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434491184)
    - 1.4.31.2.1  [Executive Oversight](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434484656)
    - 1.4.31.2.2  [Managerial Assertions](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434482176)
    - 1.4.31.2.3  [Quality Assurance Review Program](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434479120)
    - 1.4.31.2.4  [Policy and Guidance](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434451056)
    - 1.4.31.2.5  [Assurance Statement](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434440896)
  - 1.4.31.3  [Quality Assurance Review (QAR) Call Notification](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434432240)
  - 1.4.31.4  [e-Form 14750 Submission Call Notification](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434429424)
  - 1.4.31.5  [Business Unit News and Leaders’ Alerts](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434420944)
  - 1.4.31.6  [Quality Assurance Review Listing](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434418544)
    - 1.4.31.6.1  [Risk Determination](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434414144)
    - 1.4.31.6.2  [Identification of Quality Assurance Reviews](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434407648)
    - 1.4.31.6.3  [Internal Control Managerial Assessment Sampling](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434401408)
    - 1.4.31.6.4  [New Initiatives](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434395616)
  - 1.4.31.7  [Quality Assurance Review Program Forms](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434391728)
  - 1.4.31.8  [Quality Assurance Review Program Process and Procedures](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434380576)
    - 1.4.31.8.1  [Timing of Reviews](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434375056)
    - 1.4.31.8.2  [Review Selection Criteria](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434372624)
    - 1.4.31.8.3  [Review Selection Notification](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434367616)
    - 1.4.31.8.4  [Review Methodology](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434361872)
    - 1.4.31.8.5  [Review Documentation](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434351664)
    - 1.4.31.8.6  [Records Retention](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434341712)
  - 1.4.31.9  [Identifying and Developing Quality Assurance Reviews](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434337056)
    - 1.4.31.9.1  [Quality Assurance Review Program Structure](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434313136)
    - 1.4.31.9.2  [Quality Assurance Review Knowledge and Skills](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434302336)
  - Exhibit  1.4.31-1  [FMFIA Internal Control Framework](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434296768)
  - Exhibit  1.4.31-2  [GAO’s standards for internal control in the federal government](https://www.irs.gov/irm/part1/irm_01-004-031#idm139659434294752)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 31. Quality Assurance Review Program

* * *

## 1.4.31 Quality Assurance Review Program

#### Manual Transmittal

October 17, 2024

#### Purpose

(1) This transmits revised IRM 1.4.31, Resource Guide for Managers, Quality Assurance Review Program.

#### Material Changes

(1) IRM section title, updated to Quality Assurance Review Program.

(2) IRM 1.4.31.1 (2), Program Scope and Objectives, updated Purpose.

(3) IRM 1.4.31.1 (4), Program Scope and Objectives, removed to streamline Policy Owner.

(4) IRM 1.4.31.1 (5), Program Scope and Objectives, Primary Stakeholders moved to IRM 1.4.31.1 (6).

(5) IRM 1.4.31.1 (5), Program Scope and Objectives, added Program Owner.

(6) IRM 1.4.31.1 (6), Program Scope and Objectives, Program Goals moved to IRM 1.4.31.1 (7).

(7) IRM 1.4.31.1 (7), Program Scope and Objectives, updated Program Goals.

(8) IRM 1.4.31.1.2 (1), Authorities, updated hyperlink for the Federal Managers’ Financial Integrity Act of 1982.

(9) IRM 1.4.31.1.2 (5), Authorities, updated hyperlink Office of Management and Budget (OMB) Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control, Appendix A: Management of Reporting and Data Integrity Risk.

(10) IRM 1.4.31.1.3.1 (1), CFO, updated QAR Program Responsibilities.

(11) IRM 1.4.31.1.3.3 (1), Business Unit, updated business units responsibilities.

(12) IRM 1.4.31.1.5 (2), Program Controls, updated to include QAR SharePoint site.

(13) IRM 1.4.31.1.6 (1), Terms/Definitions, updated.

(14) IRM 1.4.31.1.7 (1), Acronyms, updated.

(15) IRM 1.4.31.2.1 (2), Executive Oversight, updated to reflect new leadership structure.

(16) IRM 1.4.31.2.3 (3), Quality Assurance Review Program, updated review examples for managerial review.

(17) IRM 1.4.31.2.4 (1), Policy and Guidance, removed ITM training courses and added additional SHOTs Videos.

(18) IRM 1.4.31.2.5 (2)(c), Assurance Statement, updated to reflect new guidance regarding the ICMA process.

(19) IRM 1.4.31.3, Internal Reviews (IR) Call Notification, updated to reflect Quality Assurance Review (QAR) Call Notification.

(20) IRM 1.4.31.4, Quality Assurance Review e-Form 14750 Submission Notification, updated to reflect e-Form 14750 Submission Call Notification.

(21) IRM 1.4.31.5, Business Unit News, updated to reflect Business Unit News and Leaders’ Alerts.

(22) IRM 1.4.31.5 (1), Business Unit News and Leaders’ Alerts, updated.

(23) IRM 1.4.31.6.2 (1), Identification of Quality Assurance Reviews, updated to include hyperlink to e-Form 14750 Submission SharePoint site.

(24) IRM 1.4.31.6.2 (2), Identification of Quality Assurance Reviews, updated to include acting manager in the Note.

(25) IRM 1.4.31.6.3, Internal Control Managerial Assessment Sampling, updated to reflect new ICMA guidance.

(26) IRM 1.4.31.7 (1), Quality Assurance Review Program Forms, updated to include a link to QAR Forms.

(27) IRM 1.4.31.7 (1), Quality Assurance Review Program Forms, removed individual links for each form listed.

(28) IRM 1.4.31.8.2 (4), Review Selection Criteria, remove section regarding Tactical Review Assessment Plan.

(29) IRM 1.4.31.8.4 (5), Review Methodology, moved to IRM 1.4.31.8.4 (6).

(30) IRM 1.4.31.8.4 (5), Review Methodology, added to include guidance for issuing preliminary Form 14750-A, IRS Quality Assurance Review Report, to SME and POC.

(31) IRM 1.4.31.8.4 (7), Review Methodology, added to include guidance regarding elevating disagreed recommendations.

(32) IRM 1.4.31.8.5 (3), Review Documentation, updated.

(33) IRM 1.4.31.9 (1), Identifying and Developing Quality Assurance Reviews, updated management to managerial.

(34) IRM 1.4.31.9 (7), Identifying and Developing Quality Assurance Reviews, updated hyperlink to the e-Form 14750 Submission site.

(35) IRM 1.4.31.9.2, Quality Assurance Review Knowledge and Skills, updated.

(36) This revision includes changes throughout the document for the following:

1. Updated all references of Internal Reviews Call Notification to Quality Assurance Reviews Call Notification email.

2. Updated all references of QAR e-Form 14750 Submission Notification to e-Form 14750 Submission Call Notification email.

3. Updated all references of Form 14750-A, IRS Quality Assurance Review Checklist, to Form 14750-A, IRS Quality Assurance Review Report.

4. Updated all references of business units conducting the review to business unit performing the review.

5. Updated all references of QAR performing the review to QAR conducting the review.

6. Updated all references of CFO QAR to QAR.

7. Updated all references of IRS QAR to QAR.

8. Added minor editorial changes.


#### Effect on Other Documents

IRM 1.4.31, dated August 23, 2022, is superseded. This IRM supports IRM 1.4.2, Resource Guide for Managers, Monitoring and Improving Internal Control.

#### Audience

All IRS managers

#### Effective Date

(10-17-2024)

Teresa R. Hunter

Chief Financial Officer

**1.4.31.1** **(10-17-2024)**

### Program Scope and Objectives

1. This IRM provides guidance on the processes and procedures for the Quality Assurance Review (QAR) program designed to support the Commissioner’s Assurance Statement required by the Federal Managers' Financial Integrity Act (FMFIA) and activities defined by the Office of Management and Budget (OMB) Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control, Appendix A: Management of Reporting and Data Integrity Risk.

2. Purpose: The QAR program identifies and analyzes a sample of program evaluations, managerial, operational, quality assurance and security reviews completed by the business units to conduct compliance reviews to verify the IRS is adhering to internal controls and following management guidance, standards, regulations and legislation.

3. Audience: All IRS managers.

4. Policy Owner: The CFO, Office of Internal Controls, is responsible for this IRM.

5. Program Owner: Internal Reviews, QAR program, analyzes and strengthen internal controls within the IRS.

6. Primary Stakeholders: This IRM and its procedures apply to managers responsible for creating and monitoring the results of program evaluations, managerial, operational, quality assurance and security reviews.

7. Program Goals:



> 1. Modernize the QAR processes to increase efficiency and effectiveness to better serve our internal and external stakeholders.
>
> 2. Be strategic advisors by using technology, analytics and insight to determine best-in-class processes to uphold the highest internal control standards.
>
> 3. Continue to improve the efficiency of the QAR program through emerging technologies that enhance the employee experience.


**1.4.31.1.1** **(08-23-2022)**

#### Background

1. Quality assurance is a planned, systematic approach designed to provide confidence that programs, products, policies and procedures will conform to established requirements throughout their life cycle. The term “product” is used in this IRM to describe processes and systems developed, produced and acquired by the IRS to carry out mission-critical functions.

2. Quality assurance identifies unsatisfactory trends and conditions, defects, non-compliance and corrects factors contributing to improved processes and outcomes.

3. Quality assurance uses a variety of administrative, analytical and practical methods and techniques to enhance the reliability of products and services. The IRS approaches quality assurance by addressing a range of activities described for each functional program and various systematic activities designed to identify effective and ineffective processes.

4. Several factors have contributed to a significant impact on the federal government’s quality assurance programs, such as:



1. Internal control requirements

2. Advances in technology

3. More sophisticated and complex products and services

4. More stringent requirements for quality control, reliability and security

5. More emphasis on cost of quality and timely delivery


5. QAR ensures compliance with OMB and the Department of the Treasury policy through a formal objective assessment process. QAR evaluates and documents internal control activities over financial reporting in:



1. Annual financial statements

2. Other significant internal or external financial reports

3. Compliance with laws and regulations related to those financial reports


**1.4.31.1.2** **(10-17-2024)**

#### Authorities

1. [Federal Managers' Financial Integrity Act (FMFIA) of 1982](http://obamawhitehouse.archives.gov/omb/financial_fmfia1982%20) _Exhibit 1.4.31-1_

2. [Standards for Internal Control in the Federal Government (Green Book) GAO-14-704G](http://www.gao.gov/products/GAO-14-704G) _Exhibit 1.4.31-2_

3. [Department of the Treasury Internal Control Program Requirements](https://home.treasury.gov/about/general-information/orders-and-directives/td40-04)

4. [Government Auditing Standards (Yellow Book) GAO-17-313SP](https://www.gao.gov/yellowbook)

5. Office of Management and Budget (OMB) Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control, Appendix A: Management of Reporting and Data Integrity Risk


**1.4.31.1.3** **(10-17-2024)**

#### Responsibilities

1. This section provides responsibilities for:



1. CFO

2. Statistics of Income (SOI)

3. Business units


**1.4.31.1.3.1** **(10-17-2024)**

##### CFO

1. The QAR program responsibilities include:



01. Establishing and documenting the QAR framework.

02. Developing the annual QAR program cycle and plan that identifies tasks, new projects, due dates and points of contact to enable QAR to conduct the selected reviews.

03. Issuing the Quality Assurance Reviews Call Notification email and e-Form 14750 Submission Call Notification email.

04. Conducting QARs throughout the IRS.

05. Developing the annual QAR communications plan.

06. Updating and maintaining the Quality Assurance Review Listing on the QAR SharePoint site.

07. Collaborating with business units to identify best practices and program improvements.

08. Developing and maintaining training courses for the QAR program.

09. Maintaining a QAR SharePoint site and QAR Source page with references for training, new program policies, frequently asked questions and program updates.

10. Updating IRM 1.4.31, Quality Assurance Review Program.

11. Ensuring retention of records and work papers for the annual QARs.

12. Tracking the status of open recommendations.

13. Providing QAR program updates to the Management Controls Executive Steering Committee (MC ESC).


**1.4.31.1.3.2** **(08-23-2022)**

##### Statistics of Income

1. SOI assists the QAR program by conducting an independent sampling of data for QAR selection, after CFO provides specific criteria.

2. Specific criteria per CFO:



1. The number of reviews to be completed in the fiscal year are based on staffing levels.

2. Number of reviews with high risk (70%), medium risk (15%) and low risk (15%).

3. An allocation of reviews per business unit.

4. Several reviews for substitution (a minimum of 20).


**1.4.31.1.3.3** **(10-17-2024)**

##### Business Units

1. The business units are responsible for internal controls and implementing quality assurance policies and procedures. The goal is to create independent quality assurance processes complimentary to, but separate from, the QAR program, including:



1. Interpreting internal controls, quality assurance policies and providing technical guidance and direction to executives and managers.

2. Completing the annual GAO Internal Control Evaluation Tool, if invited.

3. Identifying and developing QARs to meet internal control objectives based on strategic and performance goals.

4. Submitting e-Form 14750, IRS Quality Assurance Review Questionnaire, for all identified reviews performed during the past fiscal year.

5. Identifying the executives responsible for internal controls in their business unit.

6. Advising all executives and managers of internal controls and QAR requirements.

7. Providing input to the CFO on best practices, policies and procedural updates for the QAR program.

8. Assigning appropriate QAR training for identified employees. For example, SHOTs videos and requesting training from QAR analysts.

9. Tracking and addressing open GAO, TIGTA and QAR/ICR/FACT audit/review recommendations.


**1.4.31.1.4** **(10-17-2024)**

#### Program Management and Review

1. Program Reports: The QAR program reports include:



1. MC ESC briefs

2. Deputy Commissioner Business Performance Reviews (BPRs)

3. Review result notifications to the business units on Forms 14750-A, IRS Quality Assurance Review Report, and 14750-B, IRS Quality Assurance Review Notification

4. Quality Assurance Review Program Summary


2. Program Effectiveness: The QAR program effectiveness is determined by the:



1. Ability to support the Assurance Statement signed by the Commissioner and submitted to the Department of the Treasury on the status of internal controls.

2. Ability to survey potential reviews, if necessary.

3. Continuous program improvements based on best practice discussions with business units, such as obtaining lessons learned via surveys and QAR program enhancements. Program enhancements include Internal Control Managerial Assessment (ICMA) sampling, and developing, updating and automating processes and official QAR forms.

4. QAR program training and increased IRS managerial awareness of internal controls.


**1.4.31.1.5** **(10-17-2024)**

#### Program Controls

1. All QAR program documentation and reports are stored on the QAR SharePoint site.

2. Access to the QAR SharePoint site is restricted to QAR analysts and CFO Management.


**1.4.31.1.6** **(10-17-2024)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Concurring Official** – The approving official that has the authority to respond to proposed recommendations on behalf of the business unit.

02. **Continuous monitoring** – A process and technology used to identify compliance and risk issues associated with an agency’s financial, enforcement and operational activities.

03. **Corrective action plan** – A plan to correct or remediate an identified control deficiency or weakness. Contains a detailed description of how management will implement a corrective action plan that includes completion dates and responsible/concurring official name(s).

04. **Effective controls** – An effective internal control system provides reasonable assurance that policies, processes, tasks, behaviors and other aspects of an organization, facilitate effective and efficient operations. This includes ensuring the quality of internal and external reporting and compliance with applicable laws, procedures and regulations.

05. **Executive Listing** – An annual listing of senior executives and business unit points of contact responsible for internal controls.

06. **Financial Assurance Control Testing (FACT)** – The FACT team is responsible for implementing OMB Circular A-123, Appendix A, Management of Reporting and Data Integrity Risk (for more information, see IRM 1.4.3 Resource Guide for Managers, Financial Assurance Control Testing).

07. **Finding** – A statement of fact resulting from a review or audit. It can describe a deficiency or an opportunity for improvement in the review report or corrective action plan.

08. **Government Accountability Office (GAO)** – An independent, nonpartisan agency that works for Congress. GAO investigates how the federal government spends taxpayer dollars.

09. **Government Accountability Office (GAO) Internal Control Evaluation Tool** – This tool assesses the organizational status of internal control and is based on GAO's Standards for Internal Control in the Federal Government.

10. **Government Auditing Standards (Yellow Book) GAO-17-313SP** – Auditors of government entities and entities that receive government awards use GAO Government Auditing Standards, commonly referred to as generally accepted government auditing standards (GAGAS) or the Yellow Book, to perform their audits and produce their reports. The Yellow Book contains standards for financial audits, attestation engagements, and performance audits as well as specific requirements for individual auditors and audit organizations.

11. **Indeterminable controls** – The QAR analyst cannot determine whether there are sufficient controls in place and unable to identify whether the review is effective or ineffective.

12. **Ineffective controls** – An ineffective internal control system does not provide reasonable assurance that policies, processes, tasks, behaviors or other aspects of an organization, facilitate effective and efficient operations.

13. **Internal Control** – The first line of defense in safeguarding assets and preventing and detecting deficiencies, errors and fraud. Internal control systems provide reasonable assurance to achieve effectiveness and efficiency of operations, reliability of financial reporting and compliance with applicable laws and regulations.

14. **Internal Control Managerial Assessment (ICMA)** – An integral part of the IRS’s annual assurance review process and a valuable tool, completed by all business unit heads of office, for determining the effectiveness and efficiency of, and adherence to, IRS internal controls.

15. **Internal Control Review (ICR) program** – The ICR program provides business units with insight into the effectiveness of their implemented corrective actions for audit recommendations issued by GAO and TIGTA, as well as evaluate critical controls over IRS programs that may be high risk, high priority or high visibility. This independent examination assists the business units when they review and evaluate their internal control processes. (For more information, see IRM 1.4.32 Resource Guide for Managers, Internal Control Review Program)

16. **Management Controls Executive Steering Committee (MC ESC)** – An internal oversight committee established to oversee management's design, implementation and operation of internal controls, and to ensure that all business units identify, address and correct internal control deficiencies.

17. **Material weakness** – Specific instance of a failure in a process/system of a control identified during a review and is critical enough to be reported to managers, senior management or executives. A weakness of this type could be one that would significantly impair fulfillment of the program’s mission, goals and objectives; deprive the public of needed services; violate statutory or regulatory requirements; significantly weaken safeguards against waste, fraud, loss, unauthorized use or misappropriation of funds, property or other assets; result in a conflict of interest; and so on. A material weakness is also reported to GAO and could lead to a modified audit opinion if not adequately addressed.

18. **Matter for Consideration****(MFC)** – An observation or finding that does not rise to the level of a formal recommendation.

19. **Quality Assurance Review (QAR) program** – The program is based on CFO reviews of ongoing program evaluations, managerial, operational, quality assurance and security reviews performed by the business units. The QAR program leverages existing internal control questionnaires and certification instruments to reduce managerial burden, support internal control objectives and continuously improve programs.

20. **Random sampling** – A sampling method in which each sample has an equal probability of being chosen.

21. **Recommendation** – A proposal of controls or improvements that addresses the audit/review finding(s), and when implemented, should correct identified issues.

22. **Repetitive review** – A review conducted in two preceding fiscal year periods.

23. **Responsible Analyst/Subject Matter Expert** – The person(s) responsible for the review and the overall procedures of the review.

24. **Responsible Official** – The executive or director of the Responsible Analyst/Subject Matter Expert responsible for the review and who receives the review report(s) and documentation.

25. **Risk** – An event that may occur and affect the achievement of a business objective.

26. **Risk Assessment** – An evaluation of potential hazards, threats or opportunities which could affect an organization’s ability to conduct business.

27. **Separation of Duties** – An administrative control designed to ensure those who initially completed the review are separate and distinct from those who can adjust live data or correct errors.

28. **Significant deficiency** – A deficiency or combination of deficiencies in internal controls that is less severe than a material weakness, yet important enough to merit attention by managers or senior executives.

29. **Standards for Internal Control in the Federal Government (Green Book) GAO-14-704G** – Sets internal control standards for federal agencies. An agency uses the Green Book to design, implement, and operate internal controls to achieve its objectives related to operations, reporting, and compliance as required by the FMFIA.

30. **Testing (Sampling)** – Procedures to determine whether internal control systems are working in accordance with internal control objectives.

31. **Treasury Inspector General for Tax Administration (TIGTA)** – The organization established under the IRS Restructuring and Reform Act of 1998 to provide independent oversight of IRS activities. TIGTA promotes economy, efficiency, and effectiveness in administering the internal revenue laws. It is also committed to the prevention and detection of fraud, waste, and abuse within the IRS and related entities.

32. **Work papers** – The records and documentation created while performing the program evaluations, managerial, operational, quality assurance and security reviews.


**1.4.31.1.7** **(10-17-2024)**

#### Acronyms

1. The following acronyms apply to this program:




| **Acronym** | **Meaning** |
| :-: | :-: |
| ACFO | Associate Chief Financial Officer |
| BUN | Business Unit News |
| CFO | Chief Financial Officer |
| FACT | Financial Assurance Control Testing |
| FMFIA | Federal Managers’ Financial Integrity Act |
| ICMA | Internal Control Managerial Assessment |
| ICR | Internal Control Review |
| IR | Internal Reviews |
| MC ESC | Management Controls Executive Steering Committee |
| OMB | Office of Management and Budget |
| POC | Point of Contact |
| QAR | Quality Assurance Review |
| SAT | Senior Assessment Team |
| SHOTs | Self-Help Online Tutorials |
| SOI | Statistics of Income |
| SOPs | Standard Operating Procedures |
| SME | Subject Matter Expert |


**1.4.31.1.8** **(08-23-2022)**

#### Related Resources

1. IRM 1.4.2, Resource Guide for Managers, Monitoring and Improving Internal Control

2. IRM 1.4.3, Resource Guide for Managers, Financial Assurance Control Testing

3. IRM 1.4.32, Resource Guide for Managers, Internal Control Review Program


**1.4.31.2** **(08-23-2022)**

### Quality Assurance Review Program Framework

1. The QAR program objective is to support the Assurance Statement signed by the Commissioner and submitted to the Department of the Treasury and GAO, as required by the FMFIA.

2. The QAR program catalogs the body of work in program evaluations, managerial, operational, quality assurance and security reviews performed by the business units. It is designed to support internal control objectives and continuously improve programs. The Quality Assurance Review Listing documents those reviews. The QAR program consists of the following components:



1. Executive oversight

2. Managerial assertions

3. Quality assurance reviews

4. Policy and guidance

5. Assurance Statement


**Figure 1.4.31-1**

![This is an Image: 66821001.gif](https://www.irs.gov/pub/xml_bc/66821001.gif)

> Quality Assurance Review Framework

[Please click here for the text description of the image.](https://www.irs.gov/media/129466 "")

**1.4.31.2.1** **(10-17-2024)**

#### Executive Oversight

1. The MC ESC serves as the Senior Assessment Team (SAT), which governs the internal control program. The SAT includes individuals from all parts of the organization who may affect internal control over financial reporting, including strategic, operational, financial and programmatic aspects.

2. The MC ESC meets periodically throughout the year, provides a top leadership perspective addressing important cross-functional issues and advises the Commissioner and Deputy Commissioner.


**1.4.31.2.2** **(08-23-2022)**

#### Managerial Assertions

1. The QAR program managerial assertions component leverages existing internal control questionnaires, surveys and certification instruments to reduce managerial burden. These instruments include:



1. GAO Internal Control Evaluation Tool

2. Internal Control Managerial Assessment


**1.4.31.2.3** **(10-17-2024)**

#### Quality Assurance Review Program

1. The review component of the QAR program validates the business units’ assessments of the effectiveness of internal controls by sampling a select number of program evaluations, managerial, operational, quality assurance and security reviews which are analyzed annually by the QAR team.

2. The QAR process is usually completed between January and July of each fiscal year using Form 14750-A, IRS Quality Assurance Review Report, and is based on documentation from:



1. Business unit reviews performed throughout the IRS

2. IRMs, SOPs, desk guides and other authoritative documents

3. Business unit review reports and results

4. Identified enterprise and audit risks

5. GAO, TIGTA, FACT or ICR audit findings and recommendations


3. The QAR program’s findings and recommendations are documented and presented to:



1. Designated business unit points of contact over internal controls

2. Executive responsible for the reviewed program area

3. MC ESC

4. Selected review concurring official or responsible official

5. Selected review SME/responsible analyst


**Type and Definition of Reviews**

| The following table provides a description of the types of reviews and definitions that QAR conducts. |  |
| :-: | :-: |
| **Program Evaluation** | **Managerial Review** |
| :-: | :-: |
| A process that evaluates the status, effectiveness and progress of programs, and helps identify the future direction, needs and priorities of those programs. It’s an evaluation of how effectively a program is working as part of the ongoing pursuit of higher levels of achievement and quality. Examples: Embedded Application Quality Review Process, Improper Payment Program Review and CFO Program Review – Trace ID. | A routine assessment of management programs/systems to ensure they are performing as intended and producing the desired results as efficiently as possible. This process represents ongoing due diligence by way of reviews performed by management that fill the gap between day-to-day (informal) work activities and periodic formal reviews. Examples: Single Entry Time Reporting (SETR) Review, Telework, Outside Employment, Travel and Performance Reviews. |
| **Operational Review** | **Quality Assurance Review** |
| An in-depth and objective review of an entire organization or a specific business unit of that organization. It can be used to identify and address existing concerns within your organization. Examples: communication issues between departments, problems with customer relations, operating procedures, lack of profitability issues and other factors that affect the stability of the business unit including but not limited to Operational Reviews and Annual Operational Reviews. | A planned and methodical evaluation for assuring management that the defined standards, practices, policies, procedures and methods of the processes are applied. Examples: Budget and Project Reviews, Accounts Payable Miscellaneous Interest Desktop Procedure Review and Cash Receipts Write-Off Desktop Procedure Review. |

|     |     |
| --- | --- |
| **Security Review** |  |
| An assessment or review of IRS minimum security standards and requirements for the protection of employees, facilities, equipment and infrastructure. Examples: Access Reviews, Information System Reviews and Physical Security Reviews. |  |

**1.4.31.2.4** **(10-17-2024)**

#### Policy and Guidance

1. The policy and guidance component of the QAR program addresses the CFO duties for developing:



01. IRM 1.4.31, Resource Guide for Managers, Quality Assurance Review Program

02. Standard operating procedures (SOPs), Quality Assurance Review Program

03. Desk guides and other authoritative directives

04. Sample selection, risk assessment and rotation schedule

05. Quality Assurance Review Listing

06. QAR training courses

07. Self-Help Online Tutorials (SHOTs) videos:



       > 1. QAR - Who We Are
       >
       >        2. QAR - Selected Review Process Overview
       >
       >        3. QAR - Interview Questions and IDRs
       >
       >        4. QAR - Completing e-Form 14750
       >
       >        5. QAR - Completing Form 14750-E

08. Business unit specialized trainings

09. Program forms (electronic and paper forms in the 14750 series)

10. Documentation including memoranda, findings and recommendations

11. Reference materials and maintenance of SharePoint sites

12. Retention and storage


**1.4.31.2.5** **(10-17-2024)**

#### Assurance Statement

1. The Assurance Statement is a certification that represents the IRS Commissioner's informed judgment as to the overall adequacy and effectiveness of internal controls. The Commissioner will provide one of the following:



1. Unmodified Statement of Assurance: an indication that there are no significant weaknesses or lack of substantial compliance reported. All evidence indicates that the IRS internal controls are effective and operating as intended.

2. Modified Statement of Assurance: an indication that the IRS’s internal controls are generally effective and operating as intended except for one or more material weaknesses or lack of substantial compliance reported.

3. Statement of No Assurance: an indication that there are no processes in place or there are widespread material weaknesses.


2. The CFO takes the following steps in the annual assurance process:



1. Request that the business units complete and return the GAO Internal Control Evaluation Tool during the months of January and February to evaluate the status of internal controls within the business unit.

2. Conduct A-123 internal control testing of key financial transactions as required by the Department of the Treasury guidance.

3. Request all business units heads of office to complete the ICMA by the deadline, usually July 31.

4. Update the Quality Assurance Review Listing based on business unit submissions of e-Form 14750, IRS Quality Assurance Review Questionnaire, and supplemental spreadsheets with additional review data.

5. Conduct QARs of program evaluations, managerial, operational, quality assurance and security reviews between January and July of each fiscal year.

6. Conduct Internal Control Review (ICR) program assessments of IRS activities, with the primary mission of providing management accurate analysis and objective recommendations.


**1.4.31.3** **(10-17-2024)**

### Quality Assurance Review (QAR) Call Notification

1. The QAR Call Notification is generally issued between November and December by the CFO.

2. This notification announces the QAR period for the fiscal year. The CFO requests cooperation and support from business units to assist the QAR analysts in conducting QARs during the review period from January through July.

3. The QAR Call Notification is available on the QAR Source page.


**1.4.31.4** **(10-17-2024)**

### e-Form 14750 Submission Call Notification

1. The e-Form 14750 Submission Call Notification process identifies key program evaluations, managerial, operational, quality assurance and security reviews performed by the business units to assess the effectiveness of IRS internal controls.

2. The e-Form 14750 Submission Call Notification contains guidance issued to the business units' executives over internal controls as well as their designated points of contact to identify QARs between April and August of each fiscal year.

3. Attachment - Identification of QARs - requests that business units submit new program evaluations, managerial, operational, quality assurance and security reviews that were not previously submitted. This includes identifying all internal control reviews that test or review work quality, measure quality of data and identify trends, problem areas and improvements to program effectiveness taking into consideration applicable directives, standards and procedures. Examples of these reviews include work processes, security reviews, site visits, desk procedure reviews and operational reviews.

4. The CFO will assess the Quality Assurance Review Listing consisting of program evaluations, managerial, operational, quality assurance and security reviews to recommend new reviews for business units where gaps are identified.

5. The CFO will examine submitted e-Form 14750, IRS Quality Assurance Review Questionnaires, to:



1. Verify the name and type of review, the business unit and the related organizational symbol, the source of the review and the subject matter expert (SME).

2. Determine whether multiple reviews exist on one e-Form 14750, IRS Quality Assurance Review Questionnaire, that may need to be documented separately.

3. Identify information gaps where business units may need to provide additional information and request clarification as necessary.

4. Update the Quality Assurance Review Listing.

5. Categorize the reviews by risk level.


### Note:

The e-Form 14750 Submission Call Notification and Quality Assurance Review Listing are available on the

QAR Source page.



**1.4.31.5** **(10-17-2024)**

### Business Unit News and Leaders’ Alerts

1. IRS Source Business Unit News (BUN) articles also provide general IRS awareness about the start of the review period (BUN #1), the end of the review period (BUN #2) and e-Form 14750, IRS QAR Questionnaire submission deadlines (BUN #3). Leaders’ Alert are electronic newsletters for IRS executives, managers and management officials and are emailed every Tuesday.


**1.4.31.6** **(08-23-2022)**

### Quality Assurance Review Listing

1. The Quality Assurance Review Listing is an inventory of IRS internal control reviews. It is updated based on e-Form 14750, IRS Quality Assurance Review Questionnaire, submitted by the business units.

2. The CFO may annotate the names on the Quality Assurance Review Listing to indicate the source or critical information concerning the review, as follows:



1. New – Indicates a new review for the fiscal year.

2. ICMA – Indicates that the review originated from the ICMA sampling.

3. Annual Assurance – Indicates that the review originated from the QAR e-Form 14750 Submissions.


**1.4.31.6.1** **(08-23-2022)**

#### Risk Determination

1. Risks can occur at any level of the organization. A risk assessment considers, at a minimum, the likelihood and impact of potential events that may occur. Risks are assessed using a combination of qualitative (for example, written descriptions) and quantitative (for example, number scores) methods.

2. The CFO assigns risk levels as follows:



1. A review will be designated as “Low Risk” if total points are 6 or less.

2. A review will be designated as “Medium Risk” if total points are between 7 and 12.

3. A review will be designated as “High Risk” if total points are 13 or more.



      ### Note:



      Questions 2b, 5 - 11 and 13 - 14 from e-Form 14750, IRS Quality Assurance Review Questionnaire, are risk determinative questions. Each “Yes” or “No” response to these questions is assigned a point value.


3. Once all questions are answered and explanations provided, the points are totaled (automatically) and the risk level for the review is determined using the point scale above. Each question’s point value varies depending on its effect on the overall risk exposure for the review.


**1.4.31.6.2** **(10-17-2024)**

#### Identification of Quality Assurance Reviews

1. The e-form 14750 Submission Call Notification attachment requests that business units review their submissions on the e-Form 14750 Submission SharePoint site and:



1. Identify and submit new internal control reviews.

2. Update existing internal control reviews.

3. Identify which reviews should be deleted and submit Form 14750-E, IRS Quality Assurance Review Questionnaire Deletion Request, for each identified review.



      ### Note:



      CFO requests the business unit submit a separate e-Form 14750, IRS Quality Assurance Review Questionnaire, for each program evaluation, managerial, operational, quality assurance and security review performed.


2. To aid in planning for future QAR program reviews, business units are encouraged to provide senior leaders with suggestions on QAR that merit consideration for additional reviews. Input by business units is important and will help in designing a QAR plan to best address issues that are important to the IRS.



### Note:



Every business unit head of office must complete the ICMA. Business units that respond positively to the ICMA questions about establishing and monitoring QARs should identify those reviews and document them on the e-Form 14750, IRS Quality Assurance Review Questionnaire, especially if selected for review.


**1.4.31.6.3** **(10-17-2024)**

#### Internal Control Managerial Assessment Sampling

1. The ICMA is one of the components of the Assurance Statement signed by the IRS Commissioner and submitted to the Department of the Treasury.

2. There is a direct correlation between the ICMA and the QAR process. The ICMA addresses questions regarding Internal Controls.

3. All business units of the IRS are required to review the adequacy of internal controls, identify risks, report fraud and certify that the control environment for their business unit is working as designed through the annual ICMA.

4. The CFO obtains a listing of IRS business units’ head of office responses to the ICMA from the Assurance review program manager.

5. A review of the ICMA internal control responses is based on a judgmental sample, which is a non-random sample that is selected based on the opinion of an expert.

6. Business Units who identify that they perform a review as part of their internal control operations and do not have an e-Form 14750, IRS Quality Assurance Review Questionnaire, on the Quality Assurance Review Listing are notified by email and asked to complete an e-Form 14750 for the identified review.

7. The ICMA sample is usually selected in the first quarter of the fiscal year.

8. The Quality Assurance Review Listing is updated when the e-Form 14750, IRS Quality Assurance Review Questionnaire, is received from the selected managers.


**1.4.31.6.4** **(10-17-2024)**

#### New Initiatives

1. Periodically, new IRS initiatives are identified by the MC ESC or the SET (Senior Executive Team) and require new program evaluations, managerial, operational, quality assurance or security reviews.

2. Identification of these new reviews would be in addition to the e-Form 14750 Submission Call Notification request and the ICMA sampling that resulted in new reviews being submitted. These new reviews may be the result of GAO, TIGTA, ICR or FACT recommendations. These new reviews may also be the result of an increased awareness of a particular program or new initiative.

3. The CFO will request that the business units’ points of contact for internal controls or the manager responsible for newly identified processes to complete e-Form 14750, IRS Quality Assurance Review Questionnaire.

4. The CFO will update and post the Quality Assurance Review Listing on the QAR SharePoint site.


**1.4.31.7** **(10-17-2024)**

### Quality Assurance Review Program Forms

1. The QAR program requires use of specific forms. These forms are available on the IRS Intranet (IRS Source) under Employee Resources, click on Forms, Pubs and Correspondence under Job Resources, locate the Forms, Pubs, Products Repository section and select Commonly Used Forms. There is a designated section called the IRS Quality Assurance Review Program that contains:



1. e-Form 14750, IRS Quality Assurance Review Questionnaire (Required). The e-Form 14750 allows business units to provide information that describes their program evaluations, managerial, operational, quality assurance or security reviews. Instructions can be accessed on the QAR e-Form 14750 Submission SharePoint site.

2. Form 14750-A, IRS Quality Assurance Review Report. This form is used by the QAR analyst to assess the selected QAR. The contents of the form represent an analysis of the business unit’s review processes.

3. Form 14750-B, IRS Quality Assurance Review Notification. This form is completed by the QAR analyst and is submitted by the ACFO for Internal Controls to the respective business units’ executive over internal controls with a summary of the overall results for each selected review.

4. Form 14750-C, IRS Quality Assurance Review Information Document Request. This form is used by the QAR analyst to request and track documents and other information necessary to perform the selected QAR. The requested documentation must be provided via a secure, encrypted method to protect Sensitive but Unclassified (SBU), Personally Identifiable Information (PII) and Federal Tax Information (FTI).

5. Form 14750-D, IRS Quality Assurance Review Recommendation Closure Request. This form is completed by the QAR analyst to request the closure of satisfied recommendations. It also ensures that verification of the closure is documented in a formal process.



      ### Note:



      For a recommendation to be considered closed, CFO approval is required.

6. Form 14750-E, IRS Quality Assurance Review Deletion Request. This form is completed and submitted by the business unit if a review is obsolete, duplicated or for another specified reason. This form will also assist in complying with the Code of Federal Regulation Title 36 Part 1236.26 "What actions must agencies take to maintain electronic information systems." This section states agencies should ensure the timely, authorized disposition of the records.


### Note:

_The static version of Form 14750_ _, IRS Quality Assurance Review Questionnaire, should only be used as a worksheet. All reviews should be captured on e-Form 14750 using the QAR e-Form 14750 Submission SharePoint site._

2. The QAR forms are reviewed and updated as needed.

3. New QAR static and electronic forms may be added as the program expands and the need for new information arises.


**1.4.31.8** **(08-23-2022)**

### Quality Assurance Review Program Process and Procedures

1. The QAR program assesses select business unit’s program evaluations, managerial, operational, quality assurance and security reviews to determine the effectiveness of the internal controls.

2. There are four types of tests used to assess internal controls:



1. Inspection – examining the evidence of a given control, for example, analyzing data to interpret and validate control procedures.

2. Observation – observing actual controls in operation, for example, watching an employee ‘walk-thru’ a process to assess internal controls.

3. Re-performance – repeating a given control, for example, sampling a process that was performed by the business unit.

4. Inquiry – obtaining an explanation of a given control, for example, conducting an interview to gain insight on the review.


**1.4.31.8.1** **(08-23-2022)**

#### Timing of Reviews

1. The QAR period begins in January and ends in July. The reviews are timed to support the Commissioner’s Assurance Statement submission to the Department of the Treasury.

2. QARs continuously monitor business unit activities such as processes, procedures and related reports.


**1.4.31.8.2** **(08-23-2022)**

#### Review Selection Criteria

1. The number of program evaluations, managerial, operational, quality assurance and security reviews selected for each fiscal year is based on a combination of the following:



1. SOI uses random sampling to determine the selected reviews per the criteria provided by the CFO.

2. QAR, ICR and FACT reviews that have been completed within the last two years are exempt from SOI sampling.



      ### Note:



      Reviews that have open recommendations will require follow-up in the subsequent fiscal year.


2. Significant Deficiency: Identify areas for improvement and include open items from remediation and action plans.

3. Independent Audit Findings: Identify open GAO financial reporting audit recommendations and TIGTA reports.


**1.4.31.8.3** **(10-17-2024)**

#### Review Selection Notification

1. Each business unit executive responsible for internal controls and the business unit POC is notified by email that their business unit is selected for review. The SME/Responsible Official/Responsible Analyst may also be included on the email correspondence.

2. The review notification:



1. Identifies the business unit’s selected review(s).

2. Designates the review period for the fiscal year.

3. Indicates the point of contact training date(s).



      ### Note:



      QAR will attempt to alleviate repetitive reviews, however, strengthening controls and minimizing risks remain the mission of the Office of Internal Controls.

4. Provides references and attachments such as the e-Form 14750, IRS Quality Assurance Review Questionnaire, associated with each selected review and the current QAR Call Notification email.


**1.4.31.8.4** **(10-17-2024)**

#### Review Methodology

1. To complete Form 14750-A, IRS Quality Assurance Review Report, the QAR analyst validates the following:



1. Supporting documentation of the business unit’s program evaluations, managerial, operational, quality assurance and security reviews.

2. Information contained on the e-Form 14750, IRS Quality Assurance Review Questionnaire.


### Note:

The CFO may expand the QAR for individual controls at a more detailed level to isolate risks and undertake a corrective action plan, if necessary.

2. The QAR analyst will conduct one or more interviews with the SME for the selected review by phone and electronic communication to gain a better understanding of the review.

3. The QAR analyst will request supporting documents using Form 14750-C, IRS Quality Assurance Review Information Document Request. Documentation from the business unit should be:



1. Sufficient: Provide complete documentation with their review findings, recommendations and results.

2. Accurate: Permit a reader with no knowledge of the review to reach the same conclusion(s).

3. Restricted to documentation that is applicable to the purpose, goals and outcome of the review.

4. Complete: All evidence needs to demonstrate how the reviewer arrived at the conclusion(s) and should provide a basis for determining whether the conclusions are reasonable and accurate.


4. The QAR analyst uses information provided on the e-Form 14750, IRS Quality Assurance Review Questionnaire, responses from the interview questions and documents received from Form 14750-C, IRS Quality Assurance Review Information Document Request, to determine whether the review controls are effective, ineffective or indeterminable.

5. The QAR analyst will provide the SME and POC a preliminary Form 14750-A, IRS Quality Assurance Review Report, for review.

6. The QAR analyst will share findings and any recommendations at a scheduled concurrence meeting conducted by telephone, Teams or email with the business unit point(s) of contact, concurring official and the executive that has the authority to commit resources to implement agreed recommendations.

7. In the event there are unagreed recommendations, they will be elevated to the QAR Section Chief, IR Director and ACFO for Internal Controls for evaluation and further discussion with elevated levels of the business unit, if necessary.


**1.4.31.8.5** **(10-17-2024)**

#### Review Documentation

1. The CFO stores QAR work papers and related documents on the QAR SharePoint site or other designated storage; for example, shared drives, if applicable.



### Note:



Any recommendations that are accepted by the business unit will remain open until implemented satisfactorily.

2. Review work papers represent all quality assurance materials, including, but not limited to:



1. Business Units’ training material

2. Completed Form 14750 series QAR forms

3. IRM extracts, Standard Operating Procedures (SOPs), desk guides and other authoritative directives

4. Review reports and requested samples provided by the selected business unit

5. Analyst notes

6. Interview question responses

7. Copy of relevant GAO, TIGTA and CFO audit/review reports



      ### Note:



      Joint Audit Management Enterprise System (JAMES) is the Department of the Treasury repository for GAO and TIGTA audit reports.


3. Written materials from the business unit related to the performed review:



1. System documentation: Includes policies and procedures, organization charts, manuals, memorandums, flowcharts and related written materials necessary to describe organizational structure, operating procedures and administrative practices.

2. Review documentation: Shows the type and scope of review, the responsible official, the pertinent dates and facts, what was tested and how, the key findings and the recommended corrective actions. Documentation should be complete, accurate, clear, legible, relevant and neat.


4. A status summary of the selected QARs is provided to the MC ESC and included in the Assurance Statement.


**1.4.31.8.6** **(08-23-2022)**

#### Records Retention

1. QAR documentation is considered a temporary federal record. Review records must be closed out at the end of the fiscal year and deleted five years after closure. Examples of records include:



1. Email communications including review notifications

2. Review documentation, checklists and work papers

3. Review findings and recommendations


### Note:

The retention requirement for QAR work papers and summary review results applies only to CFO. Business units should refer to IRM 1.15.2, Records and Information Management, Types of Records and Their Life Cycles, for retention guidance. Also refer to Document 12990, Records Control Schedules for the National Archives and Record Administration (NARA) approved records retention and disposition to prevent unauthorized/unlawful destruction of records.

**1.4.31.9** **(10-17-2024)**

### Identifying and Developing Quality Assurance Reviews

1. To assist in identifying program evaluations, managerial, operational, quality assurance and security review activities, the following are some questions that should be considered:



1. Does the review impact the outcome of the program, project or process?

2. Is there a set of criteria used to evaluate the program, project or process?

3. Who performs the review?

4. Is there a specific level and/or type of authority necessary to perform the review?

5. Is the review assessing whether a desired impact was achieved?

6. Is the review assessing compliance with existing rules, regulations, policies, procedures and/or legislation?

7. Is the review assessing a single performance of a process or a representative sample of multiple instances of the process’ performance?



      ### Note:



      For Types of Reviews, see 1.4.31.2.3(3), Quality Assurance Review Program.


2. Sources for new reviews may be identified by the business unit by examining:



1. Existing IRM guidance and confirming that processes and procedures have associated reviews.

2. Executive, managerial and management officials’ commitments and program goals.

3. Managerial reviews that assess internal controls as a derivative of the review.

4. TIGTA, GAO and FACT transactional testing recommendations.

5. Newly enacted legislation.

6. Threats and trends (for example, cyber terrorism and identity theft).

7. Enterprise risks and fraud risks.

8. Organizational survey results.


3. In developing new reviews, business units should make certain that they follow guidance from:



1. IRM 1.4.31, Resource Guide for Managers, Quality Assurance Review Program, Type of Definition of Reviews. _IRM 1.4.31.2.3_

2. GAO Standards for Internal Control in the Federal Government (Green Book)

3. OMB Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Control


4. Verify that internal controls are defined in terms of specific requirements to be met within their programs/processes and ensure they are communicated and understood by the individuals responsible for them.

5. Verify separation of duties exist and controls are tested by individuals other than those routinely executing them. See definition for separation of duties.

6. Business unit reviews may use the following techniques:



1. Inspection - requires a review examining the evidence of a given control.



      ### Example:



      Looking for signatures of a reviewing official or reviewing past reconciliations.

2. Observation - requires watching actual controls in operation.



      ### Example:



      Observing a physical inventory or watching a reconciliation occur.

3. Re-performance - requires repeating a given control.



      ### Example:



      Re-calculating an estimate or re-performing a reconciliation.

4. Inquiry – requires obtaining an explanation of a given control.



      ### Example:



      Inquiring about specific steps in a process.


7. Business units are encouraged to:



1. Develop program evaluations, managerial, operational, quality assurance and security reviews that address a single activity. Identifying one review process that occurs over multiple locations is considered one review. Reviews with multiple activities (for example, data security, case reviews and employee performance) should be separated, as practical.

2. Test the performance of the new review, adjust the review procedures (if necessary) and document all updates.

3. Complete an e-Form 14750, IRS Quality Assurance Review Questionnaire, on the e-Form 14750 Submission Site for the new review as part of the QAR e-Form 14750 Submission process. The new review will be incorporated into the Quality Assurance Review Listing.


### Note:

The IRS internal control environment continues to improve through the corrective actions implemented by business unit management. The commitment to excellence, accountability and compliance with applicable laws and regulations is demonstrated in actions to establish effective controls, make sound determinations on corrective actions and verify the results.

**1.4.31.9.1** **(08-23-2022)**

#### Quality Assurance Review Program Structure

1. The QAR organization structure is comprised of a section chief and program analysts.

2. **QAR Section Chief is responsible for:**



1. Providing guidance and management support for planning, analyzing and reporting on the effectiveness of internal controls and mitigating risks.

2. Coordinating with internal stakeholders and business units to conduct QARs to support the Assurance Statement signed by the Commissioner and submitted to the Department of the Treasury.

3. Managing the QAR process.

4. Reporting the results of the QARs.

5. Providing program summary to the ACFO for Internal Controls and CFO.


3. **QAR analysts are responsible for:**



1. Conducting reviews of business units program evaluations, managerial, operational, quality assurance and security reviews selected via random sampling.

2. Obtaining and analyzing applicable IRMs, Interim Guidance Memoranda, SOPs, Desk Guides, Job Aids, GAO/TIGTA audit reports and other guidance related to selected reviews.

3. Analyzing supporting documents submitted by the business units.

4. Reporting on the effectiveness of internal controls for assigned reviews.

5. Documenting the findings of the review.

6. Proposing recommendations to strengthen controls.

7. Conducting specialized training for business units, for example, annual training for Points of Contact.

8. Obtaining corrective action plans for open recommendations.

9. Tracking the status of open recommendations.


**1.4.31.9.2** **(10-17-2024)**

#### Quality Assurance Review Knowledge and Skills

1. QAR analyst must have, at minimum, the following knowledge, skills and abilities:



1. Working with functional programs, operations and processes.

2. Demonstrating analytical and evaluative methods, assessing program development or execution and improving organizational efficiency and effectiveness.

3. Preparing comprehensive program analyses and evaluations pertaining to the effectiveness of program operations.

4. Planning, coordinating and establishing operating methods and procedures for accomplishment of project mission.

5. Providing guidance for various analytical studies to resolve substantive problems or improve efficiency and effectiveness of operating line or administrative support programs.

6. Preparing effective written and oral communications.

7. Establishing effective interpersonal relationships with internal and external stakeholders.


**Exhibit 1.4.31-1**

### FMFIA Internal Control Framework

![This is an Image: 66821002.gif](https://www.irs.gov/pub/xml_bc/66821002.gif)

> IRS Internal Control Program

[Please click here for the text description of the image.](https://www.irs.gov/media/129471 "")

**Exhibit 1.4.31-2**

### GAO’s standards for internal control in the federal government

| **GAO’s Standards for Internal Control in the Federal Government** |
| :-: |
| **No.** | **Standard** | **Standard Description** |
| --- | :-: | :-: |
| 1. | **Control Environment** | The control environment is the foundation for an internal control system. It provides the discipline and structure, which affect the overall quality of internal control. It influences how objectives are defined and how control activities are structured. The oversight body and management establish and maintain an environment throughout the agency that sets a positive attitude toward internal control. |
| 2. | **Risk Assessment** | Having established an effective control environment, management assesses the risks facing the agency as it seeks to achieve its objectives. This assessment provides the basis for developing appropriate risk responses. Management assesses the risks the agency faces from both external and internal sources. |
| 3. | **Control Activities** | Control activities are the actions management establishes through policies and procedures to achieve objectives and respond to risks in the internal control system, which includes the agency’s information system. |
| 4. | **Information and Communications** | Management uses quality information to support the internal control system. Effective information and communication are vital for an agency to achieve its objectives. Agency management needs access to relevant and reliable communication related to internal as well as external events. |
| 5. | **Monitoring** | Internal control monitoring assesses the quality of performance over time and promptly resolves the findings of audits and other reviews. Corrective actions are a necessary complement to control activities to achieve objectives. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-031#addtoany "Show all")

A2A