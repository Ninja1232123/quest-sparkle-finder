---
url: "https://www.irs.gov/irm/part1/irm_01-011-003"
title: "1.11.3 Servicewide Policy Statement Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-003#main-content)

- 1.11.3  [Servicewide Policy Statement Process](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733899543056)
  - 1.11.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733926692912)
    - 1.11.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733926707920)
    - 1.11.3.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733899524960)
    - 1.11.3.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733899521792)
    - 1.11.3.1.4  [Program Management Review](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733899514880)
    - 1.11.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898704240)
    - 1.11.3.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898698976)
  - 1.11.3.2  [Purpose of Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733926598304)
    - 1.11.3.2.1  [Effect of Personnel and Organizational Changes on Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733926592656)
  - 1.11.3.3  [Policy Statements Standards](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733899642544)
    - 1.11.3.3.1  [Creating, Revising and Rescinding Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898812704)
    - 1.11.3.3.2  [Servicewide Policy Statement Content](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898800112)
  - 1.11.3.4  [Procedures for Clearing Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733926643120)
    - 1.11.3.4.1  [Clearance Package for Internal, External, and Specialized Reviewers for Servicewide Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898723024)
    - 1.11.3.4.2  [No Response to Clearance Request](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898708688)
    - 1.11.3.4.3  [Final Clearance Package for SPDER Review](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733899588752)
  - 1.11.3.5  [Issuance and Publishing of Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898591168)
  - 1.11.3.6  [Editorial Changes for Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898584704)
  - Exhibit  1.11.3-1  [Sample New Policy Statement](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898575456)
  - Exhibit  1.11.3-2  [Sample Revised Policy Statement](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898570064)
  - Exhibit  1.11.3-3  [Sample Rescinded Policy Statement](https://www.irs.gov/irm/part1/irm_01-011-003#idm139733898563680)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 3. Servicewide Policy Statement Process

* * *

## 1.11.3 Servicewide Policy Statement Process

#### Manual Transmittal

May 02, 2025

#### Purpose

(1) This transmits revised IRM 1.11.3, Internal Management Document (IMD) System, Servicewide Policy Statement Process.

#### Material Changes

(1) This revision includes the following changes:

| IRM Subsection and Title | Material Change(s) |
| :-: | :-: |
| 1.11.3.1 - Program Scope and Objectives | - Paragraph 1: Updated purpose of this IRM section.<br>  <br>- Paragraph 2: Updated to include management, IMD coordinators, policy statement coordinators, authors and reviewers.<br>  <br>- Paragraph 3: Updated to include Director, Strategy and Business Solutions (SBS).<br>  <br>- Paragraph 4: Added business unit responsibilities.<br>  <br>- Paragraph 5: Added primary stakeholders section.<br>  <br>- Paragraph 6: Added \*SPDER email information. |
| 1.11.3.1.3 - Roles and Responsibilities | - Paragraph 1: Added responsibilities for business unit IMD and policy statement coordinator.<br>  <br>- Paragraph 2: Added responsibilities for business unit executives. Also, added a note to define a business unit senior executive.<br>  <br>- Paragraph 3: Added responsibilities for Chiefs and Directors reporting directly to the Deputy Commissioner of Internal of Revenue.<br>  <br>- Paragraph 4: Updated the role of the Director, Strategy and Business Solutions (SBS), RAAS.<br>  <br>- Paragraph 5: Added the role and responsibilities for the Chief Operating Officer (COO).<br>  <br>- Paragraph 6: Updated the roles of the Commissioner and Deputy Commissioner. |
| 1.11.3.1.4 - Program Management Review | - Paragraph 2: Updated to provide additional details regarding the annual IMD Certification process. |
| 1.11.3.1.5 - Program Controls | - Added new subsection. |
| 1.11.3.1.6 - Terms and Acronyms | - Paragraph 1: Added new terms and acronyms.<br>  <br>- Added Business Unit Senior Executive role.<br>  <br>- Added acronym for Chief Information Officer.<br>  <br>- Added acronym for Chief, Tax Compliance Officer.<br>  <br>- Updated policy statement term. |
| 1.11.3.2 - Purpose of Policy Statements | - Removed the word “Content” from title and moved language describing policy statement content to IRM 1.11.3.3, Policy Statement Standards.<br>  <br>- Paragraph 1: Updated purpose of policy statements.<br>  <br>- Paragraph 3: Reworded paragraph and exception removed for clarity. |
| 1.11.3.2.1 - Effect of Personnel and Organizational Changes on Policy Statements | - Added new subsection. |
| 1.11.3.3 - Policy Statements Standards | - Changed title from Preparing and Coordinating Policy Statements to Policy Statement Standards.<br>  <br>- Paragraph 3: Added the standards for the effective date of policy statements.<br>  <br>- Paragraph 5: Added business unit senior executives instead of senior business unit executives. Also updated the policy statement order for reviewing and clearing policy statements.<br>  <br>- Paragraph 6: Added the standards for the business unit’s senior executives to review policy statements annually.<br>  <br>- Paragraph 7: Added procedural resources for revising, issuing, and formatting policy statements.<br>  <br>- Paragraph 8: Updated to explain policy statements are numbered by the business processes to which they belong.<br>  <br>- Paragraph 9: Updated to include policy statements are listed in IRM 1.2.1, Servicewide Policies.<br>  <br>- Paragraph 10: Added the standards for rescinding policy statements.<br>  <br>- Paragraph 11: Added the originating office’s responsibilities when policy statements are added, revised or rescinded.<br>  <br>- Paragraph 12: Added standards for transferring policy statements between business units.<br>  <br>- Paragraph 13: Added the standard for posting approved policy statements to the Servicewide Policy Statement Listing web page and the FOIA Library’s Recently Approved Policy Statements until published in IRM 1.2.1, Servicewide Policy Statements.<br>  <br>- Paragraph 14: Added a link to find all active policy statements. |
| 1.11.3.3.1 - Creating, Revising and Rescinding Policy Statements | - Changed title from Revising and Issuing Policy Statements to Creating, Revising and Rescinding Policy Statements.<br>  <br>- Revised IRM subsection to consolidate the list of policy statement actions. |
| 1.11.3.3.2 - Servicewide Policy Statement Content | - Added new subsection titled, Servicewide Policy Statement Content. |
| 1.11.3.4 - Procedures for Clearing Policy Statements | - Changed title from Revising and Issuing Policy Statements to Procedures for Clearing Policy Statements.<br>  <br>- Moved content for Revising and Issuing Policy Statements to IRM 1.11.3.3.1, Creating, Revising and Rescinding Policy Statements.<br>  <br>- Paragraph 1: Added requirement to send draft policy statement to SPDER for review before formal clearance.<br>  <br>- Paragraph 2: Added the list of reviewers that are required to view policy statements during clearance.<br>  <br>- Paragraph 3: Added resource for identifying affected offices.<br>  <br>- Paragraph 4: Added link to a SPDER listing of business unit points of contact.<br>  <br>- Paragraph 5: Added the timeframe allotted for policy statement review.<br>  <br>- Paragraph 6: Added requirement for expedited reviews.<br>  <br>- Paragraph 7: Added requirement and order of Chief Counsel review. Added Chief Counsel contact information.<br>  <br>- Paragraph 8: Added link to IRM 1.11.9.9, Resolving Disagreements.<br>  <br>- Paragraph 9: Updated the order for sending clearance package to author’s manager, the business unit senior executive, and the Chief or Director reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue (if applicable) for review. Added timeframes for responses to review requests.<br>  <br>- Paragraph 10: Updated requirement for forwarding completed clearance packages to SPDER.<br>  <br>- Paragraph 11: Added requirement to submit package to SPDER within one year of initiating clearance. |
| 1.11.3.4.1 - Clearance Package for Internal, External, and Specialized Reviewers for Servicewide Policy Statements | - Changed title from Procedures for Clearing Policy Statements to Clearance Package for Internal, External and Specialized Reviewers.<br>  <br>- Added new subsection with updated guidance for the clearance packages sent to reviewers.<br>  <br>- Removed requirement to include Form 14074, Action Routing Sheet. This document is no longer required for SPDER purposes.<br>  <br>- Table (a): Added the requirement for the Chief or Director reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue (if applicable) to review and complete Form 2061, Document Clearance Record.<br>  <br>- Table (b): Revised language to improve clarity and removed requirement for draft memo to be on Commissioner or Deputy Commissioner’s letterhead.<br>  <br>- Table (c): Removed requirement for track changes memo to be on Commissioner’s or Deputy Commissioner's letterhead. Added requirement to provide a complete track changes document.<br>  <br>- Table (e): Added guidance to include electronic links to each referenced Internal Revenue Code (IRC), IRM source of authority, statute, Treasury Regulation, and Treasury Decision when needed for a policy statement. |
| 1.11.3.4.2 - No Response to Clearance Request | - Changed title from Policy Statement Review Package to No Response to Clearance Package.<br>  <br>- Added new subsection to provide procedures to follow when no response is received for a clearance review request. |
| 1.11.3.4.3 - Final Clearance Package for SPDER Review | - Added new subsection to include updated guidance for the clearance packages sent to SPDER for review. Removed requirement to mail a completed paper package to the IRS Historical Research Library.<br>  <br>- Moved content from Policy Statement Review Package to this subsection.<br>  <br>- Paragraph (2(c)): Added requirement to include a track changes Word file with new policy statement.<br>  <br>- Paragraph(3(f)): Added reference to the Chief or Director reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue.<br>  <br>- Paragraph (4(a)): Added Chief, Servicewide Policy, Directives and Electronic Resources (SPDER) IMD Policy and Support.<br>  <br>- Paragraph (4(c)):Added Chief Data and Analytics Officer.<br>  <br>- Paragraph 5: Added the routing process for the final clearance package. |
| 1.11.3.5 - Issuance and Publishing of Policy Statements | - Changed title from Editorial Changes to Issuance and Publishing of Policy Statements.<br>  <br>- Moved content from Editorial Changes to IRM 1.11.3.6.<br>  <br>- Added new IRM subsection that describes the SPDER process for issuing and publishing new, revised or rescinded policy statements. |
| 1.11.3.6 - Editorial Changes for Policy Statements | - Added new subsection Editorial Changes for Policy Statements. |
| Exhibit 1.11.3-1 - Sample New Policy Statement | - Added a New Policy Statement and fictionalized approving official’s name.<br>  <br>- Replaced previous example with a new example. |
| Exhibit 1.11.3-2 - Sample Revised Policy Statement | - Added a Revised Policy Statement and fictionalized approving official’s name. |
| Exhibit 1.11.3-3 - Sample Rescinded Policy Statement | - Added a Rescinded Policy Statement and fictionalized approving official’s name.<br>  <br>- Replaced previous rescinded example with a new rescinded example. |
| Changes Throughout | - Made editorial changes to language throughout to improve clarity.<br>  <br>- Reorganized IRM 1.11.3 subsections to improve clarity and readability.<br>  <br>- Updated IRM 1.11.3 subsection titles to improve clarity.<br>  <br>- Replaced terms “division” and/or “function,” as used to describe organizations with the term “business units.”<br>  <br>- Converted lists to tables to improve readability.<br>  <br>- Updated and/or revised links throughout the IRM. |

#### Effect on Other Documents

This supersedes IRM 1.11.3, dated March 31, 2020.

#### Audience

IRS executives, managers, IMD coordinators, policy statement coordinators, authors and reviewers who create, revise and rescind policy statements.

#### Effective Date

(05-02-2025)

Holly A. Donnelly

Director, Strategy & Business Solutions

Research, Applied Analytics and Statistics

**1.11.3.1** **(05-02-2025)**

### Program Scope and Objectives

1. **Purpose:** This IRM section defines and explains policy statements. This IRM section also provides instructions for preparing, reviewing, approving and issuing policy statements.

2. **Audience:**The audience for this IRM section includes those who are responsible for creating, revising and rescinding IRS policy statements:



   - IRS executives and managers

   - IRS management officials

   - IMD coordinators

   - Policy statement coordinators

   - Authors

   - Reviewers


3. **Policy Owner:** Director, Strategy and Business Solutions (SBS), Research Applied Analytics and Statistics (RAAS).

4. **Program Owner:**The Office of Servicewide Policy, Directives and Electronic Resources (SPDER) within SBS - RAAS is the program office responsible for overseeing the internal management document (IMD) process and providing guidance. Each business unit is responsible for establishing an internal process for managing their procedures based on these Servicewide processes. This includes designating an IMD coordinator and team to oversee the process within their respective business units.

5. **Primary Stakeholders:** All organizations and business units that use, manage, own, or issue policy statements approved by the Commissioner or Deputy Commissioner of Internal Revenue.

6. **Contact Information:** Email \*SPDER to recommend changes or make any other suggestions for this IRM section.


**1.11.3.1.1** **(03-31-2020)**

#### Background

1. This IRM section enables the IRS to meet certain federal requirements to document, publish and maintain records of policies, authorities, procedures and organizational operations described in IRM 1.11.1.1.2, Authority.

2. The IRS Restructuring and Reform Act of 1998 resulted in a complete restructuring and reformatting of the IRM to align with IRS business processes. One of the primary goals of IRS modernization was to restore and maintain the IRM as the single, official compilation of IRS policies, procedures and guidelines.

3. In 1999, IRS formed the Office of Servicewide Policy, Directives and Electronic Resources (formerly Servicewide Policy, Directives and Electronic Research). SPDER is responsible for designing, implementing and monitoring a strategic approach to managing and setting Servicewide policy for internal management directives. Refer to IRM 1.11.1, Internal Management Document (IMD) Program and Responsibilities, for information about the effect of these changes.


**1.11.3.1.2** **(03-31-2020)**

#### Authority

1. By law, federal agencies are expected to document, publish and maintain records of policies, authorities, procedures and organizational operations. The IRM is the source for the IRS. Refer to IRM 1.11.1.1.2, Authority, for the authorities and legal obligations of IMDs.

2. The Freedom of Information Act (FOIA), [5 USC 552(a)(2)(c)](https://www.justice.gov/archives/oip/blog/foia-update-freedom-information-act-5-usc-sect-552-amended-public-law-no-104-231-110-stat), requires each agency to maintain and make available for public inspection and copying a current index providing identifying information for the public. The publication of the Policy Statement on IRS.gov and in IRM 1.2.1, Servicewide Policy Statement, fulfills this legal responsibility.


**1.11.3.1.3** **(05-02-2025)**

#### Roles and Responsibilities

1. The business unit IMD and policy statement coordinators are responsible for managing and providing guidance for their business unit's policy statements program.

2. The business unit senior executives are responsible for all policy statements assigned to their business unit. These responsibilities include serving as the final reviewer and approver of their business unit’s policy statements to ensure they are accurate, valid and up-to-date.



### Note:



Business unit senior executives report directly to the Commissioner of Internal Revenue or Deputy Commissioner of Internal Revenue, Chief Tax Compliance Officer or Chief Operating Officer.

3. The chiefs or directors who report directly to the Deputy Commissioner of Internal Revenue oversee a single business unit or multiple business units. These executives include Chief, Taxpayer Services, Chief, Tax Compliance Officer, Chief, Information Officer, Chief, Operating Officer and Director, Online Services. The Deputy Commissioner’s direct reports serve as the final reviewer for policy statements owned by the business units under their purview. For more information refer to the Department of Treasury IRS Organization and Top Officials Organizational Chart.

4. The Director, Strategic Business Solutions, is the program director responsible for IMD program administration. The Director, SBS, designates oversight responsibility for the IMD program, including policy statements to the Director, SPDER.

5. The Chief Operating Officer (COO) is responsible for providing direction and oversight to the major operational and administrative functions for the IRS in support of its business units that provide taxpayer service and enforcement.

6. The Commissioner of Internal Revenue or Deputy Commissioner of Internal Revenue reviews, approves and signs Servicewide policy statements.


**1.11.3.1.4** **(05-02-2025)**

#### Program Management Review

1. The business unit senior executives of each IRS organization are responsible for reviewing, maintaining and archiving policy statements for their respective programs.

2. SPDER performs an annual review of each business unit’s policy statements through the annual IMD certification process. Data is collected and compiled into a report for each business unit’s senior executives, managers, IMD coordinators and staff. The Annual IMD Certification Report highlights each business unit’s accomplishments and areas of opportunity. The business units use the results from the review to improve their IMD program management.


**1.11.3.1.5** **(05-02-2025)**

#### Program Controls

1. **Annual Report on the Internal Management Documents (IMD) Program**: An annual report issued that details IMD program accomplishments and activities and includes a summary of annual certification results and recommended actions. This report provides business unit senior executives with the information and resources necessary to efficiently manage their respective IMD programs.

2. **Annual IMD Program Risk Analysis Report**: This analysis report provides the status of Servicewide policy statements and the actions taken by each business unit to resolve these issues and mitigate risk. SPDER shares a report with each business unit’s senior executive, IMD coordinator, and staff.

3. **IMD Tracking System**: This tool allows SPDER to manage the receipt and posting of new, revised, and rescinded policy statement memos. Policy statements are updated in the IRM biannually, so this tool is designed to house and immediately make available the policy statement memos pending updates to IRM 1.2.1, Servicewide Policy Statements. The IMD Tracking System is also used to archive policy statements as they are published to IRM 1.2.1, Servicewide Policy Statements. It allows for the efficient management and retrieval of approved policy statements.


**1.11.3.1.6** **(05-02-2025)**

#### Terms and Acronyms

1. Common terms, acronyms and definitions.




| **Term or Acronym** | **Definition** |
| :-: | --- |
| Business Unit Senior Executive | Senior executives who report directly to one of the following:<br> <br>   - Commissioner of Internal Revenue<br>     <br>   - Deputy Commissioner of Internal Revenue<br>     <br>   - Chief Tax Compliance Officer<br>     <br>   - Chief Operating Officer |
| CIO | Chief Information Officer |
| COO | Chief Operations Officer |
| CTCO | Chief, Tax Compliance Officer |
| CTS | Chief, Taxpayer Services |
| Freedom of Information Act (FOIA) | A federal law ( [5 USC 552](https://www.foia.gov/foia-statute.html)) that requires federal agencies to make available to the public certain documents or information including administrative procedural manuals and instructions to staff unless the documents are exempt from disclosure. |
| Internal Management Documents (IMDs) | Official communications that designate policies, authorities and instructions to IRS officials and employees. |
| Policy Statements (PS) | Policy statements advise IRS employees and the public of the IRS commitment to an ideal or value. They are authorized by the Commissioner or Deputy Commissioner. These statements can form the basis for procedures and instructions in the IRM. |


**1.11.3.2** **(05-02-2025)**

### Purpose of Policy Statements

1. Policy statements serve to communicate the IRS’s perspectives on significant values and principles. These "IRS policies" govern and guide IRS personnel in the administration of the IRS.

2. The words **Servicewide policy** should not be used to designate an IRS position unless a policy statement has been signed by the Commissioner or Deputy Commissioner of Internal Revenue on the matter. Procedures established in conformance with approved Servicewide policies should be designated as procedures, instructions, guidelines, positions, etc

3. Policies established by the Department of the Treasury or other executive branch offices, as well as those from the legislative and judicial branches,**_are not_** designated as “IRS Policy Statements.”

4. Additionally, policy statements do not cover areas where basic decisions are proclaimed by another government agency or are settled by law. An exception could be made, for purposes of clarity and understanding, to combine IRS policy with other agency policies if they are so interrelated that omitting those policies originating outside of the IRS might cause an erroneous or misleading impression.


**1.11.3.2.1** **(05-02-2025)**

#### Effect of Personnel and Organizational Changes on Policy Statements

1. Policy statements issued by a previous official remain valid until they are rescinded or modified.

2. If an organizational or personnel change occurs that alters a title but does not substantially change the functions or duties, the existing policy statement will remain in effect.


**1.11.3.3** **(05-02-2025)**

### Policy Statements Standards

01. Policy statements publicize views concerning an important value of the IRS. The designation of any item as an ″IRS Policy″ concerns an issue of sufficient importance to warrant consideration, approval and signature by the Commissioner or Deputy Commissioner of Internal Revenue.

02. Policy statements can form the basis for procedures or instructions in the IRM. Policy statements are not, however, the appropriate vehicle to convey:



    - Instructions to staff

    - IRS interpretations of substantive tax provisions, or

    - Directions to the public


03. The Commissioner or Deputy Commissioner of Internal Revenue reviews, approves and signs all new, revised, and rescinded Servicewide policy statements. Once signed and approved, the policy statement is immediately effective and supersedes any preceding policy statements.

04. The only policies which can be issued as policy statements are those initiated by the Commissioner or Deputy Commissioner of Internal Revenue, or those initiated and submitted for their approval by:



    - Business unit senior executives, directly reporting to the Commissioner or Deputy Commissioner of Internal Revenue

    - Chief Tax Compliance Officer

    - Chief Operating Officer


05. Business unit senior executives are responsible for Servicewide policy statements within their organization and clearing them through impacted offices, the Office of Chief Counsel, the originating office’s senior executives, and then the Office of SPDER, prior to submitting to the Commissioner or Deputy Commissioner for approval and signature.



    ### Caution:



    SPDER will not process any policy statement packages without Chief Counsel’s review and concurrence.





    ### Note:



    **All policy statements must be cleared through the Office of SPDER before forwarding to the Commissioner’s or Deputy Commissioner's office for signature.**

06. Responsible business unit senior executives must review their policy statements annually to ensure the content in the policy statement is current, applicable and valid. This annual review includes consulting among other impacted executives concerning proposals for new, revised or rescinded policy statements when necessary.

07. Policy statements contain specific content and follow a specified format. Refer to IRM 1.11.3.3.1 , Creating, Revising and Rescinding Policy Statements, and IRM 11.3.3.2 , Servicewide Policy Statement Content.

08. Policy statements are numbered sequentially, according to the IRS business process (conforming to the IRM).



    ### Example:



    IRM 1.2.1.2, Policy Statements for Organization, Finance and Management Activities, contains all of the policy statements that relate to IRS administrative activities. IRM 1.2.1.5, Policy Statements for the Examining Process, contains all of the policy statements that relate to the examining process.

09. Policy statements are documented in IRM 1.2.1, Servicewide Policy Statements. The approval, revision and rescinded date will be printed with each policy statement

10. If a policy statement is to be removed permanently, the policy statement must be rescinded through review, approval and signature following the procedures outlined in IRM 1.11.3.3.1, Creating, Revising and Rescinding Policy Statements.

11. The originating office must determine how the changes impact other documents, processes, programs, and inform the organization owners. These changes could require updates to all related IRM sections to maintain overall consistency.

12. If there is an agreement to transfer a policy statement to a different business unit, contact \*SPDER to provide confirmation of the transfer of policy statement ownership to another business unit. This email must include the reason(s) for the transfer and the name(s) of the business unit senior executives(s) agreeing to the transfer.

13. Recently approved policy statements are posted to the Servicewide Policy Statement Listing web page and the FOIA Library’s [Recently Approved Policy Statements](https://www.irs.gov/uac/Recently-Approved-Policy-Statements-1) until published in IRM 1.2.1, Servicewide Policy Statements. IRM 1.2.1 is updated on a semi-annual schedule: January and July by SPDER.

14. A list of all active policy statements organized by business owner and number can be found on the Servicewide Policy Statement Listing web page.


**1.11.3.3.1** **(05-02-2025)**

#### Creating, Revising and Rescinding Policy Statements

1. **Assistance:**Authors must contact the business unit IMD/Policy Statement Coordinator for help with creating, revising, or rescinding policy statements.

2. **Creating New Policy Statements:**



1. IMD coordinators must contact \*SPDER to obtain a new policy statement number.

2. Follow IRM 1.11.3.3.2, Servicewide Policy Statement Content, and refer to _Exhibit 1.11.3-1_, Sample New Policy Statement for format.

3. Follow IRM 1.11.3.4, Procedures for Clearing Servicewide Policy Statements, for mandatory review and approval procedures.


3. **Revising Policy Statements:**



1. Authors must use the existing policy statement as the source document located in IRM 1.2.1, Servicewide Policy Statements.

2. Add the revision number in the title (e.g., Rev.1).

3. Obtain approval from SPDER for any renumbering.

4. Follow IRM 1.11.3.3.2, Servicewide Policy Statement Content, and refer to _Exhibit 1.11.3-2_, Sample Revised Policy Statement for format.

5. Follow IRM 1.11.3.4, Procedures for Clearing Servicewide Policy Statements, for mandatory review and approval procedures.



      ### Note:



      The first time a policy statement is approved and signed by the Commissioner of Internal Revenue or Deputy Commissioner of Internal Revenue, there is not a revision number. The next substantive revision submitted for a policy statement will be Rev.1.


4. **Rescinding Policy Statements:**



1. Authors must follow IRM 1.11.3.3.2, Servicewide Policy Statement Content, and refer to _Exhibit 1.11.3-3_, Sample Rescinded Policy Statement for format.

2. Follow IRM 1.11.3.4, Procedures for Clearing Servicewide Policy Statements, for mandatory review and approval procedures.


**1.11.3.3.2** **(05-02-2025)**

#### Servicewide Policy Statement Content

1. Policy statements must be complete and include the following required elements in the policy statement memorandum:




| **Policy Statement Memo Required Element** | **Comments** |
| --- | --- |
| Policy Statement Number, Revision, and Title | - Include the policy statement number.<br>     <br>   - After the policy statement number include one of the following:<br>     <br>     <br>     <br>     1. If the policy statement is new, include “New” after policy statement number. If a policy statement number is needed, contact \*SPDER to obtain a new policy statement number.<br>        <br>     2. If policy statement is revised include (Rev. #) after the policy statement number.<br>        <br>     3. If policy statement is rescinded, include “Rescinded” after policy statement number.<br>        <br>   - Include the policy statement title. Provide a brief descriptive title to reflect the subject. |
| Opening paragraph | Always list as (1) and include the title of the policy statement without the policy statement number and revision number. Paragraph (1) is always bold and must be in case format. For an example, refer to _Exhibit 1.11.3-1_, Sample New Policy Statement. |
| Policy | The second paragraph must convey the important IRS value that governs and guides IRS personnel in the administration of the IRS. The policy statement should **never** include instructions to the staff, IRS interpretations of substantive tax provisions, or directions to the public. When a separate but related “sub-topic” is included, indicate by using another bold lead in paragraph. |
| Approver Signature Line | The final paragraph of the policy statement must include a signature line labeled “Signed,” followed by a space for the electronic signature. Below this line, type the approving official’s name, title and the word “Date.” The Commissioner of Internal Revenue or Deputy Commissioner of Internal Revenue are the only officials authorized to sign and approve Servicewide policy statements. The approving official title is determined by the reporting office of the respective business unit. |

2. When possible, include electronic links to each referenced Internal Revenue Code (IRC), IRM source of authority, statute, Treasury Regulation, and Treasury Decision when needed for a policy statement.

3. Refer to _Exhibit 1.11.3-1_ through _Exhibit 1.11.3-3_ or the IMD Community site for sample policy statements and templates.

4. Policy statements **must not** contain any official use only (OUO), sensitive but classified (SBU) or controlled unclassified Information (CUI) content.


**1.11.3.4** **(05-02-2025)**

### Procedures for Clearing Policy Statements

01. Before starting the formal clearance process, the author must send the draft policy statement to \*SPDER with a courtesy copy to their Internal Management Documents (IMD) Coordinator for an informal review.

02. The author must use Form 2061, Document Clearance Record, to document the review and assessment(s) of:



    1. Affected offices

    2. Taxpayer Advocate Service (TAS)

    3. Chief Counsel

    4. Originator’s management official (Form 2061, Part V, 17a. - 17c)

    5. Business unit senior executive (Form 2061, Part V, 18a. - 18d.)

    6. Chief or director reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue (if applicable) (Form 2061, Part V, 19a. - 19c.)

    7. Business unit IMD coordinator


03. The author must identify affected offices in accordance with IRM 1.11.9.3 , Identifying Reviewers.

04. To locate program offices outside of the business unit, authors must use the Internal Management Documents (IMD) Contacts List.

05. Authors must allow 30 calendar days for reviewers to complete their review and assessment. Internal and external reviewers will perform reviews **simultaneously** during the 30-day timeframe.

06. In rare instances where an expedited clearance review is needed, authors must consider the following:



    1. Approval from the business unit senior executive is **_required._**

    2. Expedited clearance must last at least three business days.

    3. Authors must indicate: “EXPEDITED CLEARANCE” on Form 2061, Part 1, Line 7 and include “EXPEDITED CLEARANCE” in the subject line of the clearance email request.

    4. Prepare a complete clearance package per IRM 1.11.3.4.1, Clearance Package for Internal, External, and Specialized Reviewers for Servicewide Policy Statements.


07. Chief Counsel will complete their review **_sequentially._** After all affected offices and specialized reviewers have completed their review, the author must consolidate the responses and revise the policy statement before submitting the updated version for Chief Counsel’s review.



    1. Allow 30 calendar days for Chief Counsel to complete their review and assessment.

    2. Submit the clearance package for review and concurrence to \*CC IRM Clearance - Counsel Review, ensuring to copy the Chief Counsel policy statement point of contact as listed in the Internal Management Documents (IMD) Contacts List.

    3. Non-editorial content changes received from Chief Counsel, must be resubmitted back to Chief Counsel for subsequent review and approval.

    4. Chief Counsel must “concur” with revisions before the clearance package is sent forward for further review and approval.



       ### Caution:



       **If more than 60 calendar days pass between Chief Counsel’s review and delivery to SPDER, the policy statement package will be rejected back to the business unit. The business unit will then be required to clear the package through Chief Counsel again.**


08. In situations where a reviewer does not concur with the new or revised policy statement, refer to IRM 1.11.9.9, Resolving Disagreements.

09. After addressing and incorporating comments and feedback from all reviewers including Chief Counsel, the author will send the new, revised, or rescinded policy statement to management and the business unit senior executive for review and approval.



    ### Reminder:



    The suggested review timeframes are **_15 calendar days_** for each of the following roles: manager, business unit senior executive, chiefs or directors reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue (if applicable). Business units must obtain signatures and submit the clearance package to SPDER within 60 days of receiving Chief Counsel’s concurrence.

10. After the policy statement clearance package has been reviewed by the business unit senior executive and the chief or director reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue (if applicable), the author will send the complete policy statement package to the IMD coordinator. The IMD coordinator will perform a final review and forward the package to \*SPDER. Refer to IRM 1.11.3.4.3, Final Clearance Package for SPDER Review.

11. Servicewide policy statements must be cleared through all required reviewers and submitted to SPDER within one year of the date the official clearance package was initiated. Clearance packages received in SPDER after one year will be returned to the business unit with a request to clear the policy statement again.


**1.11.3.4.1** **(05-02-2025)**

#### Clearance Package for Internal, External, and Specialized Reviewers for Servicewide Policy Statements

1. The author forwards the policy statement clearance documents identified below to internal/external and specialized reviewers (if applicable), management, IMD coordinator and Chief Counsel for review and concurrence.




| Document (s) | Purpose |
| :-: | :-: |
| Form 2061, Document Clearance Record | Documents reviewer feedback and identifies affected offices, special reviewers, business unit IMD coordinator, business unit senior executive and the chief or director reporting directly to the Commissioner or Deputy Commissioner Internal Revenue (if applicable). |
| Draft memo (Microsoft Word file) for the new, revised, or rescinded policy statement with **no track** changes. | Draft memo (Microsoft Word file) for the new, revised, or rescinded policy statement with **no track** changes. |
| Track changes memo (Microsoft Word file) for revised, or rescinded policy statements.<br> <br>### Note:<br>The track changes document must reflect all changes made from the original policy statement to the final draft memo. | Reflects the changes being submitted for review and approval. |
| Form 13839, Note to Reviewer | Explains why a policy statement is being issued (new), revised, or rescinded. Explanation must be clear, concise, and identify all major issues and the significance of the change(s). |
| Source(s) of Authority (Microsoft Word or Adobe Acrobat file) | If applicable, document the source(s) of authority being cited in the policy statement. When possible, source(s) of authority must be linked to a related SharePoint, website, web page, etc. Refer to IRM 1.11.3.3.2, Servicewide Policy Statement Content, for format and content requirements. |
| Necessary background information | Assists in explaining the new, revised or rescinded policy statement. |


**1.11.3.4.2** **(05-02-2025)**

#### No Response to Clearance Request

1. If an affected office (other than Chief Counsel) does not respond to a clearance request within the specified time frame, a follow up is not necessary. The non-response will be treated as a concurrence with all new, revised, or rescinded policy statements.

2. The author must annotate Form 2061, Part III, block 14a as follows:



1. Enter the name of the reviewer or reviewing office in the “Name” field.

2. Write “No Response Received” in the Title field.


**1.11.3.4.3** **(05-02-2025)**

#### Final Clearance Package for SPDER Review

1. After the policy statement has been cleared through all of the of the required and affected offices, the specialized reviewers (including Chief Counsel) and reviewed by the business unit senior executives and chiefs or directors reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue (if applicable), the originating business unit submits the cleared policy statement package to SPDER. SPDER will review and submit the package to the Commissioner or Deputy Commissioner of Internal Revenue for approval and signature.

2. Email the following documents to \*SPDER for their review.




| Document(s) | Purpose |
| :-: | :-: |
| **Signed**Form 2061, Document Clearance Record(s) | Documents the comments and concurrence of all reviewers, including Chief Counsel and the originating business unit’s senior executive and the chief or director reporting directly to the Commissioner or Deputy Commissioner of Internal Revenue (if applicable).<br> <br>### Note:<br>SPDER must receive the package within 60 days of Chief Counsel’s approval date. |
| **Final** memo (Microsoft Word file) for the new, revised, or rescinded policy statement. Review for the following:<br> <br>   - Track changes turned off<br>     <br>   - All changes accepted<br>     <br>   - The official letterhead of the Commissioner or Deputy Commissioner.<br>     <br>### Note:<br>Include a signature line for the Commissioner or Deputy Commissioner of Internal Revenue that includes their name, title and “Date.” | Reflects the new or revised version being submitted for approval. Letterhead stationery is available at: Letterhead Stationery Program |
| **Final** track changes memo (Microsoft Word file) for the new, revised, or rescinded policy statements with track changes turned on.<br> <br>### Note:<br>The track changes document must reflect all made changes made from the original policy statement to the final draft memo. | Reflects the changes being submitted for approval. |
| Form 13839, Note to Reviewer | Explains why a policy statement is being issued (new), revised, or rescinded. Explanation must be clear, concise, and identify all major issues and the significance of the change(s).<br> <br>### Note:<br>Any package submitted for approval/signature without Form 13839, Note to Reviewer, will be returned to the initiator, as this is a requirement of the Commissioner's Office and SPDER. |
| Source(s) of Authority (Microsoft Word or Adobe Acrobat file) | If applicable, documents the source(s) of authority being cited in the policy statement. When possible, source(s) of authority must be linked to a related SharePoint, website, web page, etc. Refer to IRM 1.11.3.3.2, Servicewide Policy Statement Content, for format and content requirements. |
| All necessary background information | Assists in explaining the new, revised or rescinded policy statement. |

3. A SPDER analyst reviews the policy statement for the following items:



1. Correct grammar, punctuations, and spelling.

2. Correct policy statement numbering (Refer to IRM 1.11.3.3, Policy Statement Standards).

3. Form 13839, Note to Reviewer, accurately reflects the reason for and summary of the changes.

4. Formatting that complies with Servicewide policy statement standards.

5. Chief Counsel review and concurrence.

6. Business unit senior executive and chief or director reporting directly to the Commissioner or Deputy Commissioner Internal Revenue (if applicable) concurrence.



      ### Note:



      Incomplete clearance packages will be returned to the originator for corrections.


4. After completing a preliminary review, the SPDER office prepares a Form 14074, Action Routing Sheet, for the Commissioner or Deputy Commissioner’s approval. The Form 14074 will be routed through the following offices, as appropriate:



1. The Chief, SPDER IMD Policy and Support

2. The Director, Servicewide Policy, Directives and Electronic Resources

3. The Director, Strategy & Business Solutions, RAAS

4. The Chief Data and Analytics Officer

5. The Assistant Deputy Commissioner (as appropriate)

6. The Deputy Commissioner of Internal Revenue (as appropriate)

7. The Staff Assistant to the Commissioner (as appropriate)

8. The Commissioner of Internal Revenue (as appropriate)


5. After review and approval by the Chief Data and Analytics Officer, SPDER will convert the final Word file to a PDF and forward the final package (with completed Form 14074) via e-Trak to the Commissioner or Deputy Commissioner of Internal Revenue. Upon review and approval, the package will be sent to the Commissioner or Deputy Commissioner of Internal Revenue for final approval and signature.



### Reminder:



The Chief Tax Compliance Officer and Chief Operating Officer provides their final review of the clearance package prior to it being sent to SPDER.



    \`




**1.11.3.5** **(05-02-2025)**

### Issuance and Publishing of Policy Statements

1. After the Commissioner or Deputy Commissioner has approved and signed the policy statement, SPDER will post a PDF of the signed document to the Search Interim Guidance page, the Servicewide Policy Statement Listing, and request for Online Services to post the policy statement to the [IRS FOIA Library Recently Approved Policy Statements](https://www.irs.gov/uac/Recently-Approved-Policy-Statements-1).

2. SPDER will:



1. Review the final memo to confirm the Commissioner’s or Deputy Commissioner’s signature and date.

2. Prepare the final memo for posting by making the PDF 508 compliant.

3. Save the signed policy statement to the SPDER shared site.

4. Notify the originator and IMD coordinator of the signature and approval.

5. Forward the final package to the IRS Historical Research Library.

6. Incorporate the new/revised policy statement into IRM 1.2.1, Servicewide Policy Statements, on a semi-annual schedule (January/July).


**1.11.3.6** **(05-02-2025)**

### Editorial Changes for Policy Statements

1. In very limited situations, authors may request modifications to a published policy statement for editorial changes that do not change the meaning of the content. The streamlined clearance process will be used to make updates to policy statements.

2. Editorial changes are limited to:



   - Updating organizational terms and titles to current terms or titles

   - Correcting typographical errors, e.g., spelling or grammatical errors

   - Updating legal citation links to ensure they are accurate.



     ### Exception:



     Updates to legal citation/website references that changes policy statements are considered substantive changes.


3. For editorial changes, forward the following documents to \*SPDER for consideration:



1. Word file with tracked changes of the policy statement.

2. Final word file without tracked changes.

3. Form 13839, Note to Reviewer explaining the reason for the change.

4. Form 2061 signed by the business unit senior executive approving the change.


4. After review and agreement, SPDER will update the policy statement in IRM 1.2.1, Servicewide Policy Statements, according to the semi-annual schedule (January/July) and will note the editorial correction in the IRM’s manual transmittal.

5. The effective date and the revision number of the published policy statement will remain unchanged.

6. SPDER will retain the files and send them to the IRS Historical Research Library for record retention and documentation.


**Exhibit 1.11.3-1**

### Sample New Policy Statement

**Policy Statement 25-3 (New), Standard Tax Compliance Checks for Suitability and Monitoring for Federal Applicants, Employees, and Contractors**

**Effective Date:** ( _leave blank; date will be inserted once approved_)

(1) **Standard Tax Compliance Checks for Suitability and Monitoring for Federal Applicants, Employees, and Contractors**

(2) The IRS will consistently administer and uniformly process tax compliance checks for suitability determinations and monitoring tax compliance. Tax compliance is defined as the accurate and timely filing of all required tax returns and timely payment of all tax liabilities.

(3) Signed: Douglas W. O’Donnell, Deputy Commissioner of Internal Revenue

**Exhibit 1.11.3-2**

### Sample Revised Policy Statement

**Policy Statement 1-232 (Rev. 1), Solicitation for External Collaboration in the Development of Tax Forms**

**Effective Date:** ( _leave blank; date will be inserted once approved_)

(1) **Solicitation for External Collaboration in the Development of Tax Forms**

(2) Collaboration for the development of tax forms will be solicited, when appropriate from government agencies, industry, trade, and other external tax professionals. Feedback received from external sources will be evaluated and used based on its merits.

(3) **Coordination Maintained with Other Government Agencies**

(4) Coordination will be maintained with the Social Security Administration and other federal and state government agencies in matters of mutual interest that involve the technical content of tax forms and instructions.

(3) Signed: Daniel I. Werfel, Commissioner of Internal Revenue

**Exhibit 1.11.3-3**

### Sample Rescinded Policy Statement

**Policy Statement 1-48 (Rescinded), Reimbursement of Travel Expenses is Authorized for a Guest Attending an Awards Ceremony**

**Effective Date**: _leave blank; date will be inserted once approved_)

(1) **Reimbursement of Travel Expenses is Authorized for a Guest Attending an Awards Ceremony**

(2) Policy Statement 1-48 is rescinded as the information is covered by IRM 1.32.11.5.6 (07-02-2019), Invitational Travel. The IRM provides that the guest of an award recipient attending a major award ceremony (a Presidential Award or an annual ceremony of the IRS or major organizational component) is considered to be an invitational traveler and travel authorizations and reimbursement expenses are the same as those normally authorized for IRS employees in conjunction with a temporary duty assignment. Employees who receive a major award could be accompanied to the ceremony by one guest as an invitational traveler.

(3) Signed: Daniel I. Werfel, Commissioner of Internal Revenue

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-003#addtoany "Show all")

A2A