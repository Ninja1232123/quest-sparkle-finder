---
url: "https://www.irs.gov/irm/part1/irm_01-011-005"
title: "1.11.5 Publishing the Internal Revenue Manual (IRM) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-005#main-content)

- 1.11.5  [Publishing the Internal Revenue Manual (IRM)](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781480736)
  - 1.11.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782459760)
    - 1.11.5.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781963680)
    - 1.11.5.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781961392)
    - 1.11.5.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781575568)
    - 1.11.5.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782114176)
    - 1.11.5.1.5  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781795424)
    - 1.11.5.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782004976)
  - 1.11.5.2  [IRM Publishing Process](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782262240)
    - 1.11.5.2.1  [Steps to Produce the IRM](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782373696)
  - 1.11.5.3  [Preparing the IRM Package for Publishing](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782310320)
    - 1.11.5.3.1  [Preparing Form 1767, Publishing Services Requisition](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781850224)
    - 1.11.5.3.2  [Carefully Review the IRM Publishing Package](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782284528)
  - 1.11.5.4  [Submitting the IRM Publishing Package](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781563184)
    - 1.11.5.4.1  [Publishing Production Time Frames for the IRM](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782145776)
    - 1.11.5.4.2  [Filing Season Production Schedule](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782138432)
  - 1.11.5.5  [Distributing the IRM Through IMDDS](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781636880)
    - 1.11.5.5.1  [IRM Delivery](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781633344)
    - 1.11.5.5.2  [Electronic Availability of IRM Sections](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782063408)
    - 1.11.5.5.3  [Paper Distribution Exception](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782055440)
    - 1.11.5.5.4  [Distribution Pattern](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782343664)
      - 1.11.5.5.4.1  [Creating a Distribution Pattern](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782333184)
      - 1.11.5.5.4.2  [Requesting a Distribution Pattern](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782093264)
  - 1.11.5.6  [Tracking IRM Publication and Distribution](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782076816)
    - 1.11.5.6.1  [IRM Production Information Page](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781897008)
  - 1.11.5.7  [Fiscal Year-End IRM Planning](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781885024)
    - 1.11.5.7.1  [Steps for Submitting Form 1767 at the Fiscal Year End](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781515184)
  - Exhibit  1.11.5-1  [Completing Form 1767, Publishing Services Requisition](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050782227600)
  - Exhibit  1.11.5-2  [Contacts and Resources for Publishing Your IRM](https://www.irs.gov/irm/part1/irm_01-011-005#idm140050781660160)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 5. Publishing the Internal Revenue Manual (IRM)

* * *

## 1.11.5 Publishing the Internal Revenue Manual (IRM)

#### Manual Transmittal

February 10, 2025

#### Purpose

(1) This transmits revised IRM 1.11.5, Internal Management Documents System, Publishing the Internal Revenue Manual (IRM).

#### Material Changes

(1) _IRM 1.11.5.1_, Program Scope and Objectives: Updated internal controls- removed program goal as it is covered by purpose; added IMD policy owner.

(2) _IRM 1.11.5.1.1_, Background: Updated background information. Moved content on SPDER and M&P roles to IRM 1.11.5.1.3, Roles and Responsibilities.

(3) _IRM 1.11.5.1.3_, Roles and Responsibilities: Updated title to better reflect content. Incorporated content previously found in 1.11.5.1.3.1, Responsibilities. Reorganized content for clarity and deleted duplicate content.

(4) _IRM 1.11.5.1.5_, Terms and Acronyms. Moved terms into table and added column for acronyms. Added Media & Publications and SPDER.

(5) _IRM 1.11.5.3.2_: Form 15418, IRM Package Check Sheet replaces Document 13000.

(6) _IRM 1.11.5.5_, Distribution Pattern. New instructions for viewing and setting distribution patterns in the Media and Publications (M&P) portal..

(7) Removed IRM 1.11.5.6.2, Electronic Notice of a Published IRM Section. Process is suspended until further notice.

(8) Removed unresolved links from _Exhibit 1.11.5-2_, Contacts and Resources for Publishing Your IRM.

- Product Distribution Report

- What’s Hot In IMDDS


(9) Format of all hyper links updated to meet guidance on Section 508 Accessibility. Throughout, editorial changes clarify, reorganize and remove duplicate content. Plain language changes update grammar, titles, website addresses and references.

#### Effect on Other Documents

IRM 1.11.5 dated March 04, 2020, is superseded.

#### Audience

IRM authors, coordinators or other management officials responsible for preparing or packaging the IRM for publishing. Managers of IRM authors and Executives responsible for IRM content.

#### Effective Date

(02-10-2025)

Holly A. Donnelly

Director, Strategy and Business Solutions

Research, Applied Analytics and Statistics (RAAS)

**1.11.5.1** **(02-10-2025)**

### Program Scope and Objectives

1. **Purpose:** This IRM section provides IRS procedures for publishing and distributing the Internal Revenue Manual.

2. **Audience:** This information is for IRS employees in the IMD community responsible for submitting Internal Revenue Manual (IRM) sections for publishing. Employees involved in publishing and distributing the IRM include:



   - IRM authors

   - Business unit Internal management document (IMD) and IRM coordinators

   - IRM publishing specialists

   - Internal Management Documents Distribution System (IMDDS) coordinators

   - Servicewide Policy, Directives and Electronic Resources (SPDER) IMD staff

   - Approving officials


3. **IMD Policy Owner:** Director, Strategy and Business Solutions (SBS)- Research, Applied Analytics and Statistics (RAAS).

4. **IMD Policy Owner:** The Office of Servicewide Policy, Directives and Electronic Resources (SPDER) within SBS. RAAS is the program office responsible for overseeing the IMD process and providing guidance. Each business unit is responsible for establishing an internal process for managing their procedures based upon these Servicewide processes.

5. **Publishing Process Owner:** Media and Publications (M&P) in the Customer Assistance, Relationships and Education (CARE) office of Taxpayer Services (TS), is responsible for publishing and distributing the IRM and all other IRS published products.

6. **Contact Information:** Email SPDER email to recommend changes or make suggestions for this IRM section.

7. For a list of publishing and distribution contacts and resources, see _Exhibit 1.11.5-2_.


**1.11.5.1.1** **(02-10-2025)**

#### Background

1. M&P is authorized to produce and procure printing and publishing services for the IRS. SPDER partners with M&P to ensure that IRS procedures and staff instructions are published officially and in accordance with legal requirements.


**1.11.5.1.2** **(02-10-2025)**

#### Authority

1. By law, federal agencies must document, publish and maintain records of policy, authorities, procedures and organizational operations. The IRM is the vehicle through which the IRS complies with those legal requirements. See IRM 1.11.1.2, Authority, for IMD authorities and legal obligations.

2. United States Code Title 44 states that the U.S. Government Publishing Office is to perform all printing, binding, and blank-book work for the federal government. In addition, USC 44 grants the Congressional Joint Committee on Printing (JCP) the authority to regulate printing, duplicating, and distribution of products by federal government agencies, including the IRS. See IRM 1.17.1.1.1, Authorities of Government Publishing, Printing, and Duplicating, for authorities on publishing government products.

3. The Freedom of Information Act (FOIA), at 5 USC 552(a)(2)(c), requires each agency to maintain and make available for public inspection and copying a current index providing identifying information for the public. The redacted IRM and the Document 10988, IRM Index, both posted on the [Internal Revenue Service](https://www.irs.gov/) web site, fulfill this requirement.


**1.11.5.1.3** **(02-10-2025)**

#### Roles and Responsibilities

1. Within M&P, there are various roles and responsibilities:




| **Office, team or individual role** | **Responsibilities** |
| :-: | :-: |
| Office of Publishing | 1. Prepares and issues official products, including the IRM, to employees, vendors and other users.<br>      <br>2. Maintains the Core Repository of Published Products (CROPP), which contains all number-controlled, official published products issued by the IRS, including the IRM. |
| Office of Publishing - IRM Team | 1. Manages the IRS printing and publishing requirements.<br>      <br>2. Manages the IRM printing contract.<br>      <br>3. Maintains the IRS contract for the IRM authoring software.<br>      <br>4. Funds IRM publishing costs. |
| IRM Team publishing specialists | - Assigns catalog numbers for new IRM sections. A catalog number is a unique 5 digit number ending with a letter. See IRM 1.11.2, Internal Revenue Manual (IRM) Process, for information on how to request a catalog number.<br>     <br>     <br>     <br>     ### Example:<br>     <br>     <br>     <br>     The catalog number for IRM 1.11.5 is "30626A." |
| The Office of Distribution | - Provides planning and distribution services for all IRS print and electronic products within the IRS for tax administration and for the public.<br>     <br>   - The Internal Management Documents Distribution System (IMDDS) distributes printed products (where they are still in use), including the IRM, to IRS offices based on established subscriptions or distribution patterns. |
| National IMDDS coordinators | - Advise authors on distribution issues.<br>     <br>   - Creates distribution patterns for paper IRM sections. |
| XML Help Desk | - Provides help desk support for XML authors servicewide who use Arbortext Editor software. See IRM 1.18.4.2.5, eXtensible Markup Language (XML) Support. |

2. The printing contractor composes the official version of the IRM and packages it for internal and external (public) distribution. The contractor also distributes IRM files to commercial vendors of research products. See IRM 1.4.5, Corporate Tax Administration Tools, for information on the products IRS purchases for employee use.

3. The SPDER IMD team:



1. Establishes and communicates the rules for producing the IRM in accordance with the statutory authorities which govern M&P’s responsibilities

2. Coordinates special publishing processes such as those associated with filing season IRM sections and end of year publishing.

3. Assists M&P with implementation of new IRM authoring software versions.

4. Fields publishing-related questions from the IMD community and serves as a liaison between the IMD community and M&P.


For more of the SPDER IMD team’s roles and responsibilities, see IRM 1.11.1, Internal Management Documents (IMD) Program and Responsibilities.



**1.11.5.1.4** **(02-10-2025)**

#### Program Management and Review

1. M&P is responsible for the budget and contract maintenance for the printing contract and XML editor.


**1.11.5.1.5** **(02-10-2025)**

#### Terms and Acronyms

1. The following table defines terms and acronyms that appear throughout this IRM section:




| Term | Acronym | Definition |
| --- | --- | --- |
| Core Repository of Published Products | CROPP | The site that houses the IRM and all other IRS official published products; also referred to as the IRS Catalog. |
| Distribution pattern | n/a | A list of the offices (order points) to which a paper product is distributed. |
| Filing season IRM | FS IRM | An IRM section that contains tax year-specific information and must be published by a certain date, so employees can be trained to perform their jobs in time for the upcoming tax filing season. Most filing season IRM sections are found in Part 2, Information Technology, Part 3, Submission Processing, Part 21, Customer Accounts Services, and Part 25, Special Topics. |
| Filing season production schedule | n/a | A listing of filing season IRM sections that’s revised or created each year to monitor receipt and processing of each filing season IRM. |
| Internal Management Documents Distribution System | IMDDS | Subscription service that distributes IRM sections and other miscellaneous products when they’re revised, to subscribers. |
| Internal management documents | IMDs | Official communications that designate authorities and deliver instructions to IRS officials and employees. |
| IRM publishing specialists | n/a | M&P IRM Team employees who process IRM sections for publication. |
| Media and Publications | M&P | The function within the TS business unit that publishes and distributes internal forms, publications and notices. |
| Servicewide Policies, Directives and Electronic Resources | SPDER | the program office responsible for overseeing the Servicewide IMD process and providing guidance for it. |


**1.11.5.1.6** **(02-10-2025)**

#### Related Resources

1. IRM sections that are associated with the publishing and distribution process:



1. IRM 1.17.1, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure

2. IRM 1.17.2, Publishing Systems and Programs

3. IRM 1.11.2, Internal Revenue Manual (IRM) Process

4. IRM 1.11.9, Clearing and Approving the Internal Revenue Manual (IRM)


2. Official forms and documents frequently used when publishing the IRM (and other printed products):



   - Form 1767, Publishing Services Requisition

   - Fillable Form 1767: Custom Form 1767 Template for IRM Sections.

   - Form 13200, Authorization to Designate Business Approvers for Publishing Services Requests

   - Document 12591, M&P Quick Reference Guide for IRM Publishing

   - Form 15418, IRM Package Check Sheet

   - Document 10988, IRM Index


3. For references and links to IRM publishing contacts and resources, see _Exhibit 1.11.5-2._


**1.11.5.2** **(02-10-2025)**

### IRM Publishing Process

1. The assigned author or authors take(s) the following actions when preparing to publish an IRM section:




| Step | Action | Additional Instructions |
| --- | --- | --- |
| 1. | Prepare the IRM section | 1. Download the XML file of the section from the Media and Publications IRM Numerical Index, which houses the official IRM.<br>      <br>2. Create/revise the IRM file using the IRM authoring software.<br>      <br>### Note:<br>The PDF file created with the IRM authoring software is the official source file that is posted to the website. See IRM 1.11.2, for guidance on authoring the IRM. |
| 2. | Prepare graphics (if new)<br> Review and update any existing graphics | For instructions on preparing graphics, see IRM 1.11.2.5.4.2, Graphics. |
| 3. | Clear the IRM section through all affected stakeholders | For instructions on the clearance process, see IRM 1.11.9, Clearing and Approving the Internal Revenue Manual. |
| 4. | Prepare the Form 1767, Publishing Services Requisition | For instructions on preparing the Form 1767. See _IRM 1.11.5.3.1_. |
| 5. | Review IRM XML file | Follow Form 15418, IRM Package Check Sheet, to ensure the IRM section is properly prepared for publishing. |
| 6. | Submit the IRM publishing package | For instructions on submitting the IRM XML package using the IRM Upload tool, see _IRM 1.11.5.4_. |

2. M&P takes the following actions when processing an IRM section for publishing:




| Responsible Party | Actions |
| :-: | :-: |
| IRM publishing specialist | 1. Coordinates with the distribution analyst and generates the distribution list for a printed IRM.<br>      <br>2. Sends file to the printing/publishing contractor.<br>      <br>3. Uploads PDF on internal and external websites.<br>      <br>4. Emails the originator listed on Form 1767 when the IRM is processed.<br>      <br>5. Emails electronic notice to subscribers when they post the file. |
| IMDDS specialist | 1. Coordinates with the publishing specialist to address the IRM author's need for electronic or print distribution.<br>      <br>2. Prepares distribution pattern for printed IRM sections. |


**1.11.5.2.1** **(02-10-2025)**

#### Steps to Produce the IRM

1. The table below describes the responsibilities and actions of all parties who participate in the publication of the IRM.




| Step | Responsible Party | Action |
| :-: | :-: | :-: |
| 1. | IRM author | 1. Clear new revision of IRM section through Electronic Clearance Process. See IRM 1.11.9 , Clearing and Approving the Internal Revenue Manual (IRM)<br>      <br>2. Prepares the IRM publishing package. See _IRM 1.11.5.3_<br>      <br>3. Prepares Form 1767 and requests approval for publishing from their office’s authorized approver. See _IRM 1.11.5.3.1_.<br>      <br>4. Follows Form 15418, IRM Package Check Sheet, to ensure the IRM file is properly prepared.<br>      <br>5. Contacts the National IMDDS Coordinator to address distribution issues, if the IRM will be printed on paper. |
| 2. | IMD/IRM coordinator | 1. Verify that IRM section has been cleared according to IRM 1.11.9 , Clearing and Approving the Internal Revenue Manual (IRM)<br>      <br>2. Conducts the final IRM review using Form 15418 and Document 12591 to ensure the IRM is properly prepared.<br>      <br>3. Ensures graphics are properly prepared and associated with the XML file. See IRM 1.11.2.8.7<br>      <br>4. Validates that the Form 1767 is signed by an authorized approver. See _IRM 1.11.5.3_.<br>      <br>5. Ensures the IRM publishing package is complete.<br>      <br>6. Submits the IRM publishing package to M&P using the IRM Upload page. See _IRM 1.11.5.4_ |
| 3. | IRM publishing specialist | 1. Inputs information into the publishing database (posted on the production page).<br>      <br>2. Conducts IRM XML file review.<br>      <br>3. Notifies author of receipt via email.<br>      <br>4. Consults IMDDS specialist regarding IRM distribution.<br>      <br>5. Sends file to printing contractor. |
| 4. | Printing contractor | 1. Prepares file for printing.<br>      <br>2. Prepares redacted file.<br>      <br>3. Transmits files to IRS (and vendors) in the appropriate file format. |
| 5. | IRM publishing specialist | 1. Posts PDF file to the CROPP.<br>      <br>2. Updates the IRM Numerical Index.<br>      <br>3. Submits the file for posting to IRS.gov, SERP, and IRM Online. |


**1.11.5.3** **(02-10-2025)**

### Preparing the IRM Package for Publishing

1. Include the following documents in the IRM section publishing package:



   - IRM XML file created in the IRM authoring software named with the catalog number. The catalog number is a 5-digit number ending with a letter.

   - Graphic files, _new_ or _revised_, in PDF format.

   - Form 1767, Publishing Services Requisition, completed and signed by an authorized business approver.


### Note:

Although Form 15418 is not submitted with the IRM publishing package, employees should use it to quality check the completeness of their IRM package.

2. Prepare the IRM file for publishing by taking the following actions:



1. Finalize the IRM file (after completing clearance according to IRM 1.11.9 , Clearing and Approving the Internal Revenue Manual (IRM).) Obtain all necessary approvals.

2. Prepare the graphics in accordance with the publishing requirements. For detailed instructions on preparing graphics, see IRM 1.11.2.5.7 , Graphics.

3. Avoid the common errors discussed in Document 12591, M&P Quick Reference Guide for IRM Publishing.

4. Complete the Form 1767 and obtain the signature of an authorized official in your office. See IRM 1.11.5.3.1, Preparing Form 1767, Publishing Services Requisition.

5. Place the IRM, Form 1767, and any graphics in a zip file. See _IRM 1.11.5.4_, Submitting the IRM Publishing Package.


3. You must contact your business unit IMD/IRM coordinator for your business unit’s specific procedures for submitting an IRM package for publishing. Each business unit is responsible for establishing an internal process for managing their IRMs based upon the Servicewide processes set forth in IRM 1.11.9 , Clearing and Approving the Internal Revenue Manual (IRM). Find your IMD coordinator at Internal Management Documents (IMD) Contacts List. The coordinator proceeds with review and upload of the IRM Section According to IRM 1.11.9.10.4, Final Review by IMD/IRM Coordinator.

4. Do _not_ include the Form 2061, Document Clearance Record, background material, or any substantive comments in the publishing package. The originating office submits this material to the IRS Historical Research Library for permanent retention. See IRM 1.11.9.10.5, Archiving Clearance Documents.

5. If your IRM contains graphics, you may store them on a website that M&P created to house currently published IRM graphics for future authors. This tool shares the same site as the IRM Upload tool. See IRM 1.11.2.5.4.2.2, Store IRM Graphic Files.


**1.11.5.3.1** **(02-10-2025)**

#### Preparing Form 1767, Publishing Services Requisition

1. Form 1767, Publishing Service Requisition, authorizes the publishing of the IRM. It must be signed (digitally or in writing) by an authorized business approver.

2. The approving official **cannot** be the originator; another authorized official must sign the Form 1767.

3. A list of authorized business approvers is located in the Computer Assisted Publishing System Active Authorized Signatures list by Office. To add a name to the authorized business approver list, complete Form 13200, Authorization to Designate Business Approvers for Publishing Services Requests, have it signed by a division director or higher, and email it to PSR Help Desk.

4. Your BU IMD Coordinator should have authorized approval to sign Form 1767. Approval by your BU IMD Coordinator expedites the process, as they are typically the employee who uploads the finalized revised, new or obsolete IRM file to M&P for publishing via the IRM Upload tool.

5. To ensure you properly prepare Form 1767, we encourage you to use a template developed for this purpose. When you input the requested information, the appropriate line item on the Form 1767 (PDF) is automatically completed. At the push of a button, the template overlay is removed. When preparing Form 1767 for the IRM, take the following steps:



1. Download the fillable PDF overlay from Custom Form 1767 Template for IRM Sections.

2. Request approval from an authorized business approver.


6. The official version of Form 1767 is also available at the Form 1767 Catalog Page. See also _Exhibit 1.11.5-1_ for instructions on completing Form 1767 specifically for the IRM.



### Note:



When inserting the originator's name on the Form 1767 (block 22), insert their official name on the IRS badge or email address. By taking this action it will ensure employees can easily locate the appropriate contact for questions or suggestions.


**1.11.5.3.2** **(02-10-2025)**

#### Carefully Review the IRM Publishing Package

1. Errors are commonly found in these portions of the IRM publishing package:



   - IRM XML file

   - Form 1767, Publishing Services Requisition

   - Graphic files


2. The IRM author and the IMD/IRM coordinator are responsible for reviewing the IRM section for completeness to facilitate processing by the IRM publishing specialist. Mistakes in the package may delay publication of the IRM. See Document 12591, M&P Quick Reference Guide for IRM Publishing. This document lists 15 common problems that frequently occur in the IRM XML file submitted to M&P.

3. Use Form 15418, IRM Package Check Sheet, to review your IRM package to ensure the file and the associated material is properly prepared.

4. For help with correcting errors in the IRM XML file, contact your business unit IMD staff or the XML Help Desk staff. See _Exhibit 1.11.5-2_ for contact information.


**1.11.5.4** **(02-10-2025)**

### Submitting the IRM Publishing Package

1. M&P requires the use of the IRM Upload tool to submit the IRM publishing package. IRM Upload page. IMD/IRM Coordinators will complete this action.

2. The IMD coordinator follows the final submission process set forth in IRM 1.11.9.10.4 , Final Review by IMD/IRM Coordinator.

3. Follow these instructions for using the IRM Upload tool:




| Step | Action | Additional Instructions (where applicable) |
| --- | :-: | :-: |
| 1. | Use zip to create a zip file containing the:<br> <br>   - IRM file<br>     <br>   - New or revised graphic files<br>     <br>   - Completed Form 1767 | Do not password your zip file. |
| 2. | Select the IRM Package Submission on the IRM Upload page. | Access the tool from IRM Upload. |
| 3. | Enter the complete catalog number in the space provided.<br> <br>### Reminder:<br>A catalog number is required to use the IRM Upload tool. | The IRM number should appear next to the catalog number.<br> If it does not, email M&P IRM Team. |
| 4. | Click on the "Browse" button to find the ".zip" file on your computer and open it. | n/a |
| 5. | Click on the "Submit" button once all the information is correct and complete. | You will receive an email acknowledging you have successfully submitted the IRM. |

4. The IRM publishing specialist checks the package for completeness and submits the file to the contractor for publishing and distribution. If necessary, they will contact the IRM author and/or IRM/IMD coordinator to discuss any further action required before publication can proceed. For questions or problems uploading the IRM file, contact the IRM publishing specialist at M&P IRM Team.


**1.11.5.4.1** **(08-01-2017)**

#### Publishing Production Time Frames for the IRM

1. The publishing process may take from one to four weeks. Production time is based on the:



   - File size

   - Published format (electronic only or both electronic and print formats)

   - Filing season production schedule


2. Each year a high volume of IRM sections with tax-related filing season procedures are published between August through December. During this peak period, "filing season" IRM sections take priority over the "non-filing season" IRMs, increasing the publishing time frame for non-filing season IRMs due to the volume and priority given to filing season IRMs. See _IRM 1.11.5.4.2_ for information about the filing season production schedule.

3. When planning IRM updates, program owners submitting non-filing season IRM sections between August through December should consider the seasonal demands of the filing season products. The publishing production time line is shorter for non-filing season IRMs from January through mid-August.



### Note:



_A tip to improve IMD management is to schedule IRM processing between January through July._

4. Employees may track their IRM through the publishing process from receipt to posting (PDF) from the IRM Production Information (irs.gov), IRM Production Information Page. See _IRM 1.11.5.6.1_ for information about IRM production.


**1.11.5.4.2** **(04-07-2014)**

#### Filing Season Production Schedule

1. Each year, M&P solicits input from IMD coordinators during the second quarter of the fiscal year to prepare the "Filing Season Production Schedule" worksheet. The Filing Season Production Schedule is displayed on the Publishing website. From the IRM Program page at Internal Revenue Manual (IRM) Program, scroll down to the "Filing Season IRM Production Schedule" link for the most current information.

2. If you can't meet the filing season production season time line or need to change the schedule, contact the IRM publishing specialist at M&P IRM Team as soon as possible.

3. Authors may contact their business unit IMD/IRM coordinator or the IRM publishing specialist at M&P IRM Team to address questions or concerns about publishing the IRM during this time. If planning to publish a non-filing season IRM during the IRM filing season peak time due to special circumstances, (such as for training or other valid business reason), contact your IMD/IRM coordinator _prior to_ submitting the IRM for clearance.


**1.11.5.5** **(08-01-2017)**

### Distributing the IRM Through IMDDS

1. IMDDS distributes the IRM (and all other published products) to ensure employees receive it in the most cost-efficient manner. The printed IRM is distributed to employees who require the paper IRM to perform their jobs. See IMDDS Introduction & Index to access the IMDDS page.

2. With increased employee access to the web, employees are encouraged to use online sources to access the IRM. Accordingly, the IMDDS established criteria to limit the IRM sections eligible for paper distribution. See _IRM 1.11.5.5.3_, for a discussion about the paper distribution exception. See IRM 1.11.6, Using and Researching the Internal Revenue Manual (IRM).

3. The printed IRM is mailed to users through IMDDS according to an established distribution pattern. The distribution pattern is developed by the product creator (the IRM author), and modified through requests from individual offices.

4. The initial printing and mailing of the IRM is handled by the printing contractor.


**1.11.5.5.1** **(02-10-2025)**

#### IRM Delivery

1. The IRM author is responsible for determining the appropriate delivery options for their end users. One consideration is to determine whether end users have web access. See IRM 1.11.6.4, IRM Formats, for information on these options.

2. See _IRM 1.11.5.5.3_ regarding exceptions to paper distribution.

3. Prior to submitting the IRM for publishing, discuss your distribution needs with the IMDDS coordinator. See National IMDDS Coordinators.

4. Follow these guidelines when determining how to deliver the IRM.

5. Form 1767, Publishing Services Requisition, is used by IRS Offices for requisitioning and authorizing printing and publishing services. This table is a brief guide to use of the form.



### Note:



To all authors who are new the process, begin with your organization’s IMD/IRM Coordinator(s). Internal Management Documents (IMD) Contacts List








| To Do This | Take These Steps |
| :-: | :-: |
| a. Publish a new IRM section | Consult the IRM publishing specialist and the IMDDS coordinator. |
| b. Revise an existing IRM section (substantive changes) | On Form 1767, Block 18, select appropriate form of distribution. "Electronic Media" or "Print and Distribution." |
| c. Revise an IRM section (editorial changes) | On Form 1767, Block 18, select "Electronic Media." |
| d. Obsolete an existing IRM section | On Form 1767, Block 18, select "Electronic Media." |
| e. Request a reprint of the IRM section. | On Form 1767, Block 18, select:<br> <br>   - "Electronic Media" or<br>     <br>   - "Printing and Distribution," if end users meet requirements for a paper copy. See _IRM 1.11.5.5_<br>     <br>### Note:<br>Rare instances still exist where conditions require print copies of IRM sections. Most IRM are print-only. Exceptions may include off-line processes such as paper handling. |
| f. Obtain printed copies of an IRM section for conducting training or planning a conference | - Follow instructions for requesting a reprint. See _IRM 1.11.5.5.1 (6)_ for instruction on reprinting the IRM.<br>     <br>   - Consult the IMDDS coordinator. |

6. To order additional copies of a printed IRM section, submit a Form 1767 to request a "reprint" . The IRM publishing specialist will process the order through the printing contractor or the National Distribution Center (NDC), depending on the quantity requested. You must take this action at least _four weeks_ prior to the date the material is needed. The electronic **PSR** system (used to request most publishing services) is not available for the IRM.

7. To order a reprint:



1. Discuss your needs - number of copies, location and in-field date - with the IRM publishing specialist and the IMDDS coordinator.

2. Prepare Form 1767, _Publishing Services Requisition_, and select "Reprint" in Block 16.

3. Email the completed and signed Form 1767 to M&P at M&P IRM Team


### Note:

IRMs published **electronic only** are not accessible to employees through the National Distribution Center.

8. You may order printing or photocopying services through the PSR system at Services & Programs. For instructions, refer to IRM 1.17.2.2.1, The Digital Copy Center.


**1.11.5.5.2** **(02-10-2025)**

#### Electronic Availability of IRM Sections

1. Online versions of the IRM section are available to employees within days of processing.

2. The complete IRM is available to employees on the IRS intranet from these sources:



1. IRM Online IRM Online is a searchable version of the IRM.

2. The Media and Publications IRM Numerical Index links to the current IRM in portable document file (PDF) format.

3. The Product Catalog Information Page houses all published versions of the IRM in PDF and XML format.


### Note:

A regular inventory of currently active IRM sections appears as Document 10988, Internal Revenue Manual Index.

3. As described in IRM 1.11.6.4, IRM Formats, the IRM is also available to employees and the public on the following sources:



1. Servicewide Electronic Research Program (SERP) houses a portion of the IRM and other references on a searchable platform: SERP IRMs

2. IRS.gov posts a redacted version of the IRM, with the Official Use Only (OUO) information removed: [Internal Revenue Service](https://www.irs.gov/irm)

3. ReferenceNet is an IRS portal that provides access to public portions (OUO redacted) of the IRM through IRS corporate research services”


**1.11.5.5.3** **(02-10-2025)**

#### Paper Distribution Exception

1. Paper distribution of the IRM is limited. However, you may request printing and distribution of an IRM section under the following circumstances:



1. Employees who require access to the IRM but their workstation lacks a computer.

2. The printed IRM section (PDF) contains more than 100 pages.


2. Employees may obtain copies of the IRM for training or other purposes from the following sources:



1. Order through IMDDS distribution (the most cost efficient method for obtaining a printed IRM).

2. Order from the National Distribution Center.

3. Print copies locally.


3. To request an exception, take the following steps:



1. Identify your audience by reviewing the Product Distribution Report. See _IRM 1.11.5.5.4 (3)_, Product Distribution Report.

2. Prepare a written request explaining the reasons for requesting a paper copy (email or other form).

3. Obtain approval of your program manager.

4. Submit the documentation along with the Form 1767 when uploading the IRM package.


**1.11.5.5.4** **(02-10-2025)**

#### Distribution Pattern

1. A distribution pattern is assigned to each IRM section for customers who require a paper copy. The distribution pattern identifies the:



1. Offices receiving the printed IRM.

2. Number of printed copies distributed to each office.

3. Total number of printed copies distributed.


2. Common distribution patterns are established based on a job classification(s) or an organizational component. Some examples are :



   - All W&I employees

   - All managers

   - All Tax Exempt/Government Entities managers

   - Campus Employees

   - Customer Service Representatives

   - EEO Groups

   - Personnel Groups


3. The Product Distribution Report provides the current distribution pattern information such as OSMS Order Point Numbers, print quantity, contacts, and other information. Click on the link for the Order & Subscription Management System and complete as follows:



1. Click on R3, **IRM Distribution Report Options**.

2. Enter up to 8 catalog numbers you wish to view the previous and current total print quantities.

3. Generate the Excel Report to show the breakdown by IMDDS Order Points and by the Catalog Number(s) for the subscriptions you are viewing.


**1.11.5.5.4.1** **(02-10-2025)**

##### Creating a Distribution Pattern

1. Typically, the IRM publishing specialist coordinates with IMDDS Distribution IRM Program Analyst to determine if a product will be printed or electronic. If a distribution pattern is needed, it's discussed as part of this process. They take this action based on the information provided on Form 1767, block 17 (quantity requested) and block 18 (type of service).

2. A new distribution pattern can take three to four weeks to develop, depending on the complexity. Failure to establish a distribution pattern prior to submitting the IRM for publishing will delay the printing and distribution of the final IRM section. See _IRM 1.11.5.5.4(3)_ for information on how to obtain the Product Distribution Report.



### Note:



For a new IRM, there must be a record of the product before a distribution pattern is created.

3. An existing distribution pattern can be the starting point for creating a distribution pattern for a new IRM section. Follow the steps outlined under _IRM 1.11.5.5.4 (3)_ to obtain and review an existing IRM distribution pattern.


**1.11.5.5.4.2** **(09-01-2009)**

##### Requesting a Distribution Pattern

1. When requesting a distribution pattern, the author must provide the IMDDS coordinator the following information:



   - Title of IRM/IMD

   - Item number/name

   - Catalog number

   - Revision date


2. Be prepared to answer the following questions when asking IMDDS to establish a distribution pattern:



1. What is your organization or function?

2. Who is your intended audience?

3. How many copies should be sent to each office?



      ### Example:



      One copy to each intended office.

4. Where is your intended audience located?



      ### Example:



      All IRS Campuses, all call sites, all Small Business/Self-Employed (SB/SE) examiners, etc.

5. Is your IRM/IMD product only for managers or for all employees in a particular function?


3. Additional information to help identify a distribution pattern:




| If the IRM | Then provide the National IMDDS Coordinator with |
| --- | --- |
| Replaces another IMD or published product, | - The catalog number for the replacement product.<br>     <br>### Note:<br>An existing distribution pattern can be used as a baseline for the new distribution pattern. |
| Is required for a training class, | - The name, date and location of the class.<br>     <br>   - Discuss whether additional stock will be needed for future training classes. |


**1.11.5.6** **(09-01-2009)**

### Tracking IRM Publication and Distribution

1. The following tools are available to inform employees about the status of a new or revised product:



   - IRM Production Information page

   - Electronic notice of IRM issuances


2. The IRM Production Information page allows authors to track the progress of their published IRM section through the posting to the Electronic Publishing website. See _IRM 1.11.5.6.1._


**1.11.5.6.1** **(09-01-2009)**

#### IRM Production Information Page

1. Information on the IRM Production page is posted and updated regularly. The date for each of the following actions is available for each IRM section:




| Column | Description |
| :-: | :-: |
| a. Date received | The date the IRM section was checked in. It displays on the web page the following day. |
| b. Ship Complete | The estimated ship date. |
| c. Ship Complete\* (with asterisk) | The actual ship date. |
| d. Files Posted | Date files posted to the CROPP ( PDF and XML versions). |

2. To access information on the IRM Production page for a specific product:



1. Click on the website IRM Production Information (irs.gov).

2. Click on either "all IRMs" or the specific IRM part.

3. Verify fiscal year information. Select "Prior" if checking for prior year information.

4. Scroll through the list or sort by "Office" , to find the specific IRM section.


**1.11.5.7** **(04-07-2014)**

### Fiscal Year-End IRM Planning

1. While M&P funds the publishing costs of the IRM, it depends upon each organization to accurately plan and report their publishing needs for the fiscal year ending September 30. During the fiscal year, M&P monitors the IRM budget. After the close of the second quarter, M&P evaluates the April through September IRM publishing budget projections. This estimate includes publishing costs for the scheduled filing season IRMs due by September 30 and an estimate for publishing costs of non-filing season IRMs.

2. There are two cut-off dates for fiscal-year end publishing:



1. Form 1767 cut-off date, and

2. Publishing package cut-off date.


3. To close-out the fiscal year spending and improve the estimate for the publishing budget, M&P establishes a cut-off date for submitting a signed and completed Form 1767, _Publishing Services Requisition_. M&P notifies the IMD community at least 30 days in advance to allow for proper planning. The communication is sent by email and posted on IRWeb. To sign up to receive IMD communications, (referred to as "IMD Alerts" ), use the IMD News page.

4. The "Publishing package cut-off date" is the last date that M&P will accept a publishing package for processing.



1. For filing season IRMs, this date is on the filing season schedule.

2. For all other IRMs, this date is typically seven days prior to the end of the fiscal year.


5. By the Form 1767 cutoff date, a signed and completed Form 1767, _Publishing Services Requisition_, must be submitted for each IRM section the organization needs published by the fiscal year end, September 30. M&P will obligate funds based upon the requisitions received and identify potential shortfalls or redirect any surpluses, as appropriate.



### Note:



The cut-off date for submitting Form 1767, _Publishing Services Requisition_ for an IRM may differ from the cut-off date for other M&P products. The Form 1767 must be submitted timely for the IRM to be published.

6. When deciding whether to submit a Form 1767, authors must consider carefully whether the IRM will be ready for publishing _before_ the Publishing package cut-off date. You must allow sufficient time for clearing and preparing your IRM for publishing. Typically, if an IRM is not in clearance by mid-August, your IRM may not be ready for publishing before September 30. As soon as the new fiscal year begins, M&P will process the IRM (subject to the demands of the filing season schedule). See _IRM 1.11.5.4.2_ for information on the filing season production schedule and how it may affect the end of the fiscal year requirements.


**1.11.5.7.1** **(06-19-2012)**

#### Steps for Submitting Form 1767 at the Fiscal Year End

1. The following instructions apply when submitting an IRM section for publishing before the publishing package cut-off date that falls under the current budget.




| IF | AND | THEN |
| :-: | :-: | :-: |
| You plan to publish your IRM before October 1 | Submit Form 1767 signed by an authorized official, to M&P IRM Team through your IMD coordinator; | 1. Submit the IRM package through the IRM Upload process.<br>      <br>2. Include the XML file and any graphics in the IRM package.<br>      <br>3. M&P will process the IRM on a first-in, first out basis. |
| You submit a Form 1767 before the cutoff date, | You don't submit your IRM _before_ the cut-off date; | 1. Notify M&P by email M&P IRM Team as soon as possible.<br>      <br>2. Submit the IRM package through the IRM Upload process _after_ September 30.<br>      <br>3. Don’t include the Form 1767 when submitting the publishing package. |
| You do _not_ submit Form 1767 prior to the cut-off date, | The IRM section must be published before the next fiscal year processing; | 1. The Director/Executive must submit a written justification (email is acceptable), with a signed Form 1767.<br>      <br>2. The Publishing Director must grant the waiver, indicated by his/her signature.<br>      <br>### Note:<br>A request for a waiver may be denied. |
| You do _not_ submit Form 1767 prior to the cut-off date, | The IRM section does not need to be published by the end of the fiscal year | M&P will process the IRM section in the following fiscal year (on a first-in-first-out basis), after filing season IRMs are processed. |

2. After the Form 1767 cutoff date, the author submits the IRM publishing package without the Form 1767. The IRM publishing package will only include the IRM XML file and graphic files. Do not re-send the Form 1767 unless a change occurred in the interim.


**Exhibit 1.11.5-1**

### Completing Form 1767, _Publishing Services Requisition_

Complete these fields on the Form 1767 when submitting an IRM for publishing.

| Block Number | Title | Required Information |
| :-: | :-: | :-: |
| 3 | Title | Enter the chapter and section titles, separated by a hyphen. Ensure the titles match the titles used in the IRM XML file. |
| 4 | Item | Enter the IRM number (part, chapter, and section). |
| 5 | Catalog Number | Enter the IRM catalog number (five digit number ending with a letter).<br> Follow guidelines in IRM 1.11.2 to request a catalog number for a new IRM section. |
| 6 | Item Date | Enter the IRM effective date or MM-DD-YYYY. |
| 7 | Security/Special Handling | If your IRM/IMD contains OUO information or requires any other special handling, check "Yes" otherwise, check "No. " |
| 8 | Date Needed at Destination | Leave blank unless the IRM is needed on a specific date.<br> <br>### Note:<br>The date the IRM is distributed and will reach its destination is based on the print schedule. |
| 9 | Number of Originals or Material Description | Describe the materials. For example, IRM XML file and if applicable, the number of graphic pages. |
| 10-12 | Approving Official Signature, Name, Date | Obtain the signature of an authorized official. Insert name, title and date. |
| 13-15 | Funds Approval | LEAVE BLANK. The cost to print and distribute the IRM is funded by M&P. |
| 16 | Request Action | Indicate action:<br> R - Reprint<br> N - New for a new product<br> V - Revised for a revision to an existing product<br> O - Obsolete (if the IRM is no longer in effect) |
| 17 | Quantity Requested | If printing the IRM, enter on line (c) _IMDDS file pattern number_, the catalog number or IRM number.<br> For a new IRM section, contact IMDDS to establish a distribution pattern. |
| 18 | Type of Service | Check the appropriate box:<br> <br>- "Electronic Media"<br>  <br>- "Printing and Distribution"<br>  <br>### Reminder:<br>Printing and distribution are limited to the circumstances described in _IRM 1.11.5.5_. |
| 19 | Functional Description | Briefly describe the purpose of the IRM, the intended audience and other important information. This description displays on the _Product Catalog information page_ for each published product. |
| 21 | Additional Instructions | Enter any additional instructions involved in printing or distributing the IRM.<br> <br>### Example:<br>Indicate when an IRM section contains a 2-color graphic, even if no change was made. |
| 22 | Product Originator | Enter the author’s (content owner) official name. This information displays on the _Product Catalog information page_ for the IRM. |
| 23 | Office Symbols | Enter the author’s office symbols. |
| 24 | Phone | Enter the author’s telephone number. |
| 25 | Originator Email Address | Enter the author’s email address. |
| 26 | Name and Contact for other Contact Person | Enter the name and phone number of a back-up, such as, another analyst, manager or IMD/IRM coordinator. |

**Exhibit 1.11.5-2**

### Contacts and Resources for Publishing Your IRM

The tables below contain a consolidated list of sources when publishing the IRM.

| Publishing Process | Resource |
| :-: | :-: |
| Electronic Publishing catalog | Product Catalog Information Page |
| Form 1767 PDF template | Custom Form 1767 Template for IRM Sections |
| Form 1767 Authorized Approvers | Computer Assisted Publishing System Active Authorized Signatures list by Office |
| Form 13200, Authorization to Designate Business Approvers for Publishing Services Requests | Form 13200<br> Email PSRhelpdesk@irs.gov |
| IRM Numerical Index | Media and Publications IRM Numerical Index |
| IRM Production Information page | IRM Production Information (irs.gov) |
| IRM Program page | Internal Revenue Manual (IRM) Program |
| IRM publishing specialists | Internal Revenue Manual (IRM) Program Team |
| IRM Upload Tool | IRM Upload |
| M&P IRM mailbox | M&P IRM Team mailbox |
| M&P Services and Programs page | Services & Programs |
| XML Help desk website and email | XML Help Desk website.<br> XML Help Desk email address. |

| Distribution Process | Website |
| :-: | :-: |
| National IMDDS Coordinators | National IMDDS Coordinators |
| IMDDS Index | IMDDS Introduction & Index |

| IMD Process | Website |
| :-: | :-: |
| IMD Alerts sign-up | IMD News |
| IMD Coordinators | Internal Management Documents (IMD) Contacts List |
| IMD website | IMD Community Home |
| IRM Authoring Software FAQs | Arbortext Editor FAQs |
| SPDER mailbox | SPDER Mailbox |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-005#addtoany "Show all")

A2A