---
url: "https://www.irs.gov/irm/part1/irm_01-032-012"
title: "1.32.12 IRS Relocation Travel Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-012#main-content)

- 1.32.12  [IRS Relocation Travel Guide](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539364192)
  - 1.32.12.1  [Program Scope and Objective](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539374064)
    - 1.32.12.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539370416)
    - 1.32.12.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539366736)
    - 1.32.12.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539346640)
      - 1.32.12.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539341152)
      - 1.32.12.1.3.2  [Senior Associate CFO for Financial Management](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539338672)
      - 1.32.12.1.3.3  [Travel Management](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539333968)
      - 1.32.12.1.3.4  [Travel Operations](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539330512)
      - 1.32.12.1.3.5  [Relocating Employee](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539327440)
      - 1.32.12.1.3.6  [Business Units](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254539317392)
      - 1.32.12.1.3.7  [CFO Relocation Coordinators](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538771648)
      - 1.32.12.1.3.8  [CFO Relocation Technicians](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538764272)
    - 1.32.12.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538758752)
    - 1.32.12.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538751776)
    - 1.32.12.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538737472)
    - 1.32.12.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538703504)
    - 1.32.12.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538676752)
  - 1.32.12.2  [General Rules and Applicability](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538667392)
    - 1.32.12.2.1  [Travel to the New Official Station Prior to the Report Date](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538627136)
    - 1.32.12.2.2  [Short Distance Moves](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538623456)
  - 1.32.12.3  [Employee Eligibility Requirements](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538620704)
    - 1.32.12.3.1  [Service Agreements](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538615744)
    - 1.32.12.3.2  [Time Limits](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538603824)
    - 1.32.12.3.3  [Advance of Funds](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538598144)
  - 1.32.12.4  [Relocation Allowances by Specific Type](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538566128)
    - 1.32.12.4.1  [New Appointee](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538560800)
    - 1.32.12.4.2  [Transferred Employees](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538532848)
    - 1.32.12.4.3  [Overseas Tour Renewal Travel](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538446656)
    - 1.32.12.4.4  [Senior Executive Service (SES) Separation for Retirement Last Move Home](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538441200)
    - 1.32.12.4.5  [Temporary Change of Station (TCS)](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538423376)
    - 1.32.12.4.6  [Return Separation](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538408144)
  - 1.32.12.5  [Allowances for Subsistence and Transportation Expenses](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538405088)
    - 1.32.12.5.1  [Travel Expenses](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538400864)
    - 1.32.12.5.2  [Per Diem at New Official Station](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538396896)
    - 1.32.12.5.3  [Use of More Than One Privately-Owned Vehicle (POV) for En Route Travel](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538392784)
  - 1.32.12.6  [Allowance for House-Hunting Trip Expenses](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538385888)
  - 1.32.12.7  [Allowance for Temporary Quarters (TQ) Subsistence Expenses](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538371616)
  - 1.32.12.8  [Transportation and Temporary Storage of Household Goods, and Professional Books, Papers, and Equipment, and Baggage Allowances](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538318032)
    - 1.32.12.8.1  [Actual Expense Method](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538302400)
    - 1.32.12.8.2  [Unaccompanied Air Baggage (UAB) Allowance](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538287488)
    - 1.32.12.8.3  [Temporary Storage of Household Goods](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538285024)
    - 1.32.12.8.4  [Household Goods Traffic Management Program](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538280496)
  - 1.32.12.9  [Allowances for Extended Storage of Household Goods](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538277568)
    - 1.32.12.9.1  [Extended Storage During Assignment to Isolated Locations Within the Continental United States (CONUS)](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538273664)
    - 1.32.12.9.2  [Extended Storage During Assignment Outside the Continental United States (OCONUS)](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538271152)
  - 1.32.12.10  [Allowances for Transportation and Emergency Storage of a Privately-Owned Vehicle (POV)](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538264112)
    - 1.32.12.10.1  [Transportation of Privately-Owned Vehicle (POV) to an Outside the Continental United States (OCONUS) Post of Duty](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538257072)
    - 1.32.12.10.2  [Return Transportation of a Privately-Owned Vehicle (POV) From an Outside the Continental United States (OCONUS) Post of Duty](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538251680)
    - 1.32.12.10.3  [Transportation of a Privately-Owned Vehicle (POV) Within the Continental United States (CONUS)](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538249680)
    - 1.32.12.10.4  [Emergency Storage of a Privately-Owned Vehicle (POV)](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538243648)
  - 1.32.12.11  [Allowances for Transportation of Mobile Homes and Boats Used as a Primary Residence](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538237632)
  - 1.32.12.12  [Allowances for Expenses Incurred in Connection with Residence Transactions](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538233664)
    - 1.32.12.12.1  [Title Requirements](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538218096)
    - 1.32.12.12.2  [Request for Reimbursement for Residence Sale and Purchase](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538215824)
  - 1.32.12.13  [Unexpired Lease](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538206368)
  - 1.32.12.14  [Allowance for Miscellaneous Expenses](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538198368)
  - 1.32.12.15  [Voucher Submission](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538184528)
  - 1.32.12.16  [Relocation Income Tax Allowance (RITA)](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538103376)
  - 1.32.12.17  [Relocation Debts](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538087792)
  - 1.32.12.18  [Forms](https://www.irs.gov/irm/part1/irm_01-032-012#idm140254538077152)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 12. IRS Relocation Travel Guide

* * *

## 1.32.12 IRS Relocation Travel Guide

#### Manual Transmittal

March 24, 2025

#### Purpose

(1) This transmits revised IRM 1.32.12, Servicewide Travel Policies and Procedures, IRS Relocation Travel Guide.

#### Material Changes

(1) IRM 1.32.12.1.3(1)(b), Responsibilities, updated title to Senior Associate CFO for Financial Management due to CFO reorganization and updated throughout the document.

(2) IRM 1.32.12.1.3(1)(d), Responsibilities, updated responsibilities from Travel Policy and Review to Travel Operations due to CFO reorganization and updated throughout the document.

(3) IRM 1.32.12.1.3.6(2)(k), Business Units, replaced \*CFO Relocation Basic Plus Requests@irs.gov mailbox with the CFO relocation coordinator and updated throughout the document.

(4) IRM 1.32.12.1.6, Terms/Definitions, updated definitions.

(5) IRM 1.32.12.1.7, Acronyms, updated acronyms.

(6) IRM 1.32.12.1.8, Related Resources, removed reference to obsolete Publication 521 Moving Expenses.

(7) IRM 1.32.12.2(14), General Rules and Applicability, updated process for request for basic relocation allowances.

(8) IRM 1.32.12.2(16), General Rules and Applicability, updated to add temporary quarters. Added use of government travel card required for temporary quarters lodging.

(9) IRM 1.32.12.2(22), General Rules and Applicability, updated to add background of new General Services Administration (GSA) ruling amending the Federal Travel Regulations to implement a third Temporary Quarters Subsistence Expenses methodology called Temporary Quarters Subsistence Expenses (TQSE) Lodging Plus, June 2024.

(10) IRM 1.32.12.2(23), General Rules and Applicability, updated to add Inbound Shipments to Puerto Rico shipping requirements due to new General Services Administration (GSA) recent update.

(11) IRM 1.32.12.3.1, Service Agreements, added new GSA FTR (Federal Travel Regulations) updates for service agreement terms for both CONUS (Continental United States and OCONUS (Outside Continental United States).

(12) IRM 1.32.12.4.2, Transferred Employees, updated tables per recent GSA updates regarding reimbursement for divorced spouses & terminated domestic partner relationships OCONUS return to United States.

(13) IRM 1.32.12.6(3), Allowance for house-hunting Trip Expenses, updated to add the type of leave granted for house-hunting trips.

(14) IRM 1.32.12.7(1), Allowance for Temporary Quarters Subsistence Expenses, updated to add IRS will use new TQSE Lodging Plus methodology to calculate TQSE.

(15) IRM 1.32.12.7(11), Allowance for Temporary Quarters Subsistence Expenses, updated to add IRS does not offer reimbursement under the Actual Expense method.

(16) IRM 1.32.12.7(13), Allowance for Temporary Quarters Subsistence Expenses, updated to new GSA implementation of “TQSE Lodging Plus” methodology and updated charts for both lodging and Meals and Incidentals (M&IE) allowances.

(17) IRM 1.32.12.7(14), Allowance for Temporary Quarters Subsistence Expenses, updated to address lodging taxes. Actual expenses removed.

(18) IRM 1.32.12.7(15), Allowance for Temporary Quarters Subsistence Expenses, updated to show laundry & dry cleaning expenses are included in M&IE and not reimbursed separately.

(19) IRM 1.32.12.7(16), Allowance for Temporary Quarters Subsistence Expenses, updated to Employees will claim the flat rate applicable to the locality for M&IE expenses under new Lodging Plus expense method.

(20) IRM 1.32.12.7(17), Allowance for Temporary Quarters Subsistence Expenses, updated to remove expense list due to new Lodging Plus expense method.

(21) IRM 1.32.12.7(18), Allowance for Temporary Quarters Subsistence Expenses, updated to add use of the government travel card is mandatory.

(22) IRM 1.32.12.7(19), Allowance for Temporary Quarters Subsistence Expenses, updated to show authorized a house-hunting trips.

(23) IRM 1.32.12.7(20), Allowance for Temporary Quarters Subsistence Expenses, updated to address Presidentially Declared Disaster area TQSE and CFO, Director of Travel Management can authorize.

(24) IRM 1.32.12.7(21), Allowance for Temporary Quarters Subsistence Expenses, updated to address how house-hunting days are calculated.

(25) IRM 1.32.12.7(24)(25), Allowance for Temporary Quarters Subsistence Expenses, deleted to remove Lump Sum TQSE payment method calculation since it will no longer be used since TQSE Lodging Plus is now the new method used.

(26) IRM 1.32.12.10.3(2), Transportation of a Privately Owned Vehicle (POV) Within the Continental United States (CONUS), updated title to Senior Associate CFO for Financial Management due to CFO reorganization.

(27) This IRM revision includes changes throughout the document for minor editorial changes to include grammar, spelling, minor changes for clarification purposes, updated links and corrected references throughout the IRM.

#### Effect on Other Documents

IRM 1.32.12, dated June 7, 2022, is superseded.

#### Audience

All business units

#### Effective Date

(03-24-2025)

Teresa R. Hunter

Chief Financial Officer

**1.32.12.1** **(04-14-2020)**

### Program Scope and Objective

1. Purpose - This IRM provides the policies and procedures for IRS employees who perform official relocation travel in the interest of the government. It also provides guidance to supervisory and administrative personnel who authorize, direct, review or certify payments for reimbursement of relocation expenses.

2. Audience - All business units

3. Policy Owner - CFO, Financial Management

4. Program Owner - CFO, Financial Management, Travel Management office develops and maintains this IRM.

5. Primary Stakeholders - The primary stakeholders are employees relocating, domestically or internationally, who have been authorized relocation allowances in the interest of the government.

6. Program Goals - The goals of this IRM are to ensure that IRS employees receive clear guidance and comply with the IRS relocation policies.


**1.32.12.1.1** **(04-14-2020)**

#### Background

1. The General Services Administration (GSA) is responsible for establishing government-wide relocation policies and procedures.

2. This guide is intended to supplement the Federal Travel Regulations (FTR) contained in 41 Code of Federal Regulations (CFR), Chapters 300 through 304, which implements statutory requirements and executive branch policies for travel by federal civilian employees and others authorized to travel at government expense.

3. The FTR represents the governing document for relocation policy for all IRS employees. This IRM supplements the FTR by providing IRS-specific policies and procedures where needed. If the FTR differs from this IRM, the FTR is the controlling legal authority.

4. This guide applies to all employees authorized by the IRS to relocate to a new official station in the interest of the government. It covers foreign and domestic relocations.


**1.32.12.1.2** **(04-14-2020)**

#### Authorities

01. 5 U.S. Code (USC) Section 5707, [Regulations and Reports](https://uscode.house.gov/browse/prelim@title5/part3/subpartD/chapter57/subchapter1&edition=prelim)

02. 5 USC Section 5724, [Travel and transportation expenses of employees transferred; advance of funds; reimbursement on commuted basis](https://uscode.house.gov/browse/prelim@title5/part3/subpartD/chapter57/subchapter2&edition=prelim)

03. 5 USC Section 5726, [Storage expenses; household goods and personal effects](https://uscode.house.gov/browse/prelim@title5/part3/subpartD/chapter57/subchapter2&edition=prelim)

04. 5 USC Section 5737, [Relocation expenses of an employee who is performing an extended assignment](https://uscode.house.gov/browse/prelim@title5/part3/subpartD/chapter57/subchapter2&edition=prelim)

05. 5 USC Section 5738, [Regulations](https://uscode.house.gov/browse/prelim@title5/part3/subpartD/chapter57/subchapter2&edition=prelim)

06. 31 USC Section 901, [Establishment of agency Chief Financial Officers](https://uscode.house.gov/browse/prelim@title31/subtitle1/chapter9&edition=prelim)

07. 31 USC Section 902, [Authorities and functions of agency Chief Financial Officers](https://uscode.house.gov/browse/prelim@title31/subtitle1/chapter9&edition=prelim)

08. 31 USC Section 3726, [Payment for Transportation](https://uscode.house.gov/browse/prelim@title31/subtitle3/chapter37/subchapter3&edition=prelim)

09. [Department of Treasury Directives](https://home.treasury.gov/about/general-information/orders-and-directives/numerical-index-of-treasury-directives)

10. [Tax Cuts and Jobs Act of 2017](https://www.congress.gov/bill/115th-congress/house-bill/1/text/eh)

11. Federal Travel Regulation, Chapters 300-304


**1.32.12.1.3** **(03-24-2025)**

#### Responsibilities

1. This section provides responsibilities for:



1. CFO and Deputy CFO

2. Senior Associate CFO for Financial Management

3. Travel Management

4. Travel Operations

5. Relocating employee

6. Business units

7. CFO relocation coordinators

8. CFO relocation technicians


**1.32.12.1.3.1** **(03-24-2025)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for the oversight of the IRS relocation program and also for:



1. Overseeing policies and procedures and employee compliance with relocation allowances.


**1.32.12.1.3.2** **(03-24-2025)**

##### Senior Associate CFO for Financial Management

1. The Senior Associate CFO for Financial Management is responsible for:



1. Establishing and maintaining policies and controls to ensure compliance on the relocation program for internal accounting operations and financial reporting.

2. Administering the relocation services contract. Refer to IRM 1.32.13Relocation Services Program, for additional information.

3. Approving requests for basic plus allowances for shipment of privately-owned vehicles (POV) within the Continental United States (CONUS) and use of the Relocation Services Program, which also includes IRS buyout of an employee’s house when they are unable to sell the home on their own.

4. Ensuring criteria is met for basic plus allowances and forwarding the requests to the Senior Associate CFO for Financial Management for a decision.


**1.32.12.1.3.3** **(04-14-2020)**

##### Travel Management

1. Travel Management is responsible for



1. Developing and issuing IRS relocation program policy.

2. Updating and maintaining this IRM.

3. Reviewing and approving an extension for an expired one-year time limitation for employees to claim relocation expenses for an additional one year, not to exceed a combined total of two years.


**1.32.12.1.3.4** **(03-24-2025)**

##### Travel Operations

1. Travel Operations is responsible for:



1. Reviewing requests for basic plus allowances and coordinating the requests to Travel Management for further elevation to the Senior Associate CFO for Financial Management for a decision.

2. Educating customers on FTR and relocation policies.


**1.32.12.1.3.5** **(04-14-2020)**

##### Relocating Employee

1. The relocating employee is responsible for:



01. Signing a Form 4282, Twelve-Month Service Agreement, for a domestic location within CONUS or Form 10902, Overseas Transportation - Service Agreement, for a foreign location Outside the Continental United States (OCONUS) or Form 9803, Transportation Agreement, for posts of duty in a non-foreign OCONUS location.

02. Receiving an approved relocation authorization prior to incurring any relocation expenses.

03. Contacting the IRS gaining office and the designated CFO relocation coordinator to determine what relocation expenses are authorized and to ensure that the relocation authorization for basic moving expenses is signed before incurring any expenses. The IRS will not reimburse employees for any expenses incurred before the relocation authorization is approved.

04. Meeting all prerequisites for use of the basic plus relocation program such as marketing the residence for the specified time period before requesting the service.

05. Retaining copies of all relocation documents associated with the relocation.

06. Notifying the CFO relocation coordinator of any requirements to perform temporary duty at another location or locations en route to the new official station or while occupying temporary quarters. Employees must file a separate travel voucher in Concur for any temporary duty expenses.

07. Reading all furnished materials carefully to understand responsibilities; if employees are misinformed by a government official; the IRS has no legal basis to pay an unauthorized claim. Incorrect information provided by an IRS representative does not bind the government to pay a claim that is in violation of regulations.

08. Submitting signed and approved Form 8741, Relocation Voucher, to the technician, with receipts and supporting documentation within 15 calendar days after completion of the relocation activity and ensuring claimed relocation expenses are correct.

09. Using the government travel card for official travel including purchases of common carrier transportation, baggage fees, meals, vehicle rentals and other relocation related expenses.

10. Paying all charges and fees associated with the government travel card by the due date on the invoice. Employees are liable for all charges.

11. Liquidating a relocation advance on a voucher or submitting a check to the debt collection unit for any amount due.

12. Paying all billing documents for overweight household goods shipments and non-allowed charges.

13. Paying all billing documents for withholding taxes associated with the relocation activities.

14. Ensuring that administrative leave is only used for official relocation activities.


**1.32.12.1.3.6** **(03-24-2025)**

##### Business Units

1. The losing office approving official is responsible for:



1. Reviewing and approving requests for administrative leave for relocation and ensuring the administrative leave is recorded properly for relocation activities prior to the employee’s en route travel.

2. Coordinating a report date with the gaining office approving official.

3. Reviewing and approving Form 8741, Relocation Voucher as necessary prior to the employee’s report date to the new official station.


2. The gaining office approving official is responsible for:



01. Informing the employee of their transfer within a time frame that provides the employee with sufficient time for preparation for the move.

02. Signing and verifying information in the service agreement.

03. Forwarding a copy of the service agreement to the servicing personnel office to be filed in the employee’s official personnel folder.

04. Signing and verifying information on the relocation authorization for basic moving expenses prior to the employee incurring any relocation expenses.

05. Signing the amendments, if necessary, to the relocation authorization for basic moving expenses.

06. Approving shipment of a POV to an OCONUS and/or non-foreign area for the new post of duty (POD) per guidelines of each OCONUS location.

07. Reviewing Form 8518, Request for the Use of the Relocation Services Contract.

08. Reviewing Form 14564, Request for Approval for the Basic Plus Allowance Shipment of Privately-Owned Vehicle.

09. Verifying that Form 8741Relocation Voucher, are correct and filed within 15 calendar days after completion of each segment of the relocation activity.

10. Reviewing the requests for the use of the basic plus relocation allowances.

11. Submitting the requests for the use of the basic plus relocation allowances program to the CFO relocation coordinator for review and submission to the Senior Associate CFO for Financial Management.

12. Ensuring employees do not use excessive administrative leave for relocation travel and review any hours greater than 200.

13. Approving Form 4253-C, Relocation Travel Advance Requests Form 4253-C.


3. The gaining budget office is responsible for:



1. Contacting the designated CFO relocation coordinator to initiate the preparation of the relocation authorization for basic moving expenses immediately to ensure the authorization will be signed by an approving official prior to incurring any expenses.

2. Providing the correct accounting data for the corresponding accounting string to ensure adequate funding is established to cover the employee’s relocation allowances and ensure funds are obligated for authorized relocation entitlements on the relocation authorization and amendments for basic moving expenses, and relocation authorization amendments for basic plus moving expenses.

3. Providing employees with a signed relocation authorization for basic moving expenses and relocation authorization amendment for basic plus moving expenses if necessary.

4. Forwarding signed copies of service agreements, relocation authorizations, amendments and extensions to the CFO relocation coordinator.

5. Routing any request for basic plus relocation allowances through the head of office or their designee to the Travel Management office for submission to the Senior Associate CFO for Financial Management for decision.


4. The business unit head of office is responsible for:



1. Authorizing and approving basic relocation allowances program requests on relocation authorizations for basic moving expenses. This authority may be redelegated, in writing, by the business unit head of office to the director, Strategy and Finance or their equivalent.

2. Signing requests for use of the basic plus relocation allowances program for shipment of POV and use of the relocation services contract and forwarding to the CFO relocation coordinator for coordination in obtaining the signature of the Senior Associate CFO for Financial Management.


**1.32.12.1.3.7** **(04-14-2020)**

##### CFO Relocation Coordinators

1. The CFO relocation coordinators are responsible for:



01. Counseling and assisting relocating employees with relocation entitlements and allowances.

02. Preparing relocation authorizations for basic moving expenses and relocation authorization amendments for basic plus moving expenses for approval, if applicable.

03. Reviewing approved relocation authorizations for basic moving expenses, and relocation authorization amendments for basic plus moving expenses and obligating funding where necessary.

04. Amending relocation authorizations for basic moving expenses, and amending relocation authorizations for basic plus moving expenses, to revise obligations when an entitlement (or expense) was not previously approved.

05. Arranging for a professional carrier to pack, load, ship and store the employee’s household goods, unaccompanied air baggage (UAB), and POV, if applicable, and preparing the Internal Revenue Bills of Lading (IRBL) for authorized services.

06. Assisting employees with completing cost comparisons for shipping a POV.

07. Assisting employees with preparation of forms to request basic plus relocation allowances.

08. Assisting employees with requesting use of the relocation services contract. Refer to IRM 1.32.13, Relocation Services Program, for additional information.

09. Establishing billing documents for overweight charges and non-allowed charges.

10. Establishing billing documents for withholding taxes associated with payments made to a third-party company on behalf of the employee.


**1.32.12.1.3.8** **(04-14-2020)**

##### CFO Relocation Technicians

1. CFO relocation technicians are responsible for:



1. Reviewing and paying relocation vouchers and invoices submitted for reimbursement.

2. Validating and entering information in the relocation system.

3. Processing Relocation Income Tax Allowance (RITA) reimbursement or billing document after reconciliation.

4. Processing third-party payments to moving companies for household goods services including shipment, storage and delivery.

5. Processing third-party payments to moving companies for shipment of POVs, if approved.

6. Processing third-party payments for use of the relocation services contract for home sale and property management services.

7. Establishing billing documents for overweight charges and non-allowed charges.

8. Establishing billing documents for withholding taxes associated with payments made to a third-party company on behalf of the employee.


**1.32.12.1.4** **(04-14-2020)**

#### Program Management and Review

1. Internal controls are established to ensure the relocation program is managed effectively. Reviews are conducted to ensure vouchers and invoices are processed according to regulatory requirements and to ensure the expenses are included in gross income for tax compliance.

2. Program reports: The IRS completes the following reports:



1. Aging Unliquidated Relocation Obligations

2. Open Relocation Voucher Report

3. GSA Relocation Data Call Report


3. In accordance with 5 USC 5707 (c), [Regulations and Reports](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partIII-subpartD-chap57-subchapI-sec5707), all agencies that spend more than $5 million on travel and relocation must provide an annual report to GSA by November 30. GSA provides the required data elements and report format for the annual report.

4. Program effectiveness: The CFO Travel Operations office completes the following to ensure the program is managed effectively:



1. Monthly performance matrix that measures whether or not corrective actions are necessary.

2. Surveys customers quarterly soliciting feedback from relocating employees on relocation voucher processing.


**1.32.12.1.5** **(04-14-2020)**

#### Program Controls

1. Travel Operations reviews for effectiveness by:



1. Conducting a weekly review of all relocation vouchers and invoices to ensure compliance with prompt payment processing guidelines.

2. Performing a review of open relocation obligations quarterly to ensure timely processing of relocation allowances and deobligation of excess amounts.

3. Reviewing relocation reimbursements and reconciling payments annually to ensure tax withholding and taxable income are recorded properly.


2. The following chart below describes the internal controls in place for using the relocation travel program:




| **Control** | **Control Description** |
| --- | --- |
| Delegation of authority | Authority to approve relocation travel allowances is delegated to the appropriate level in the business units in accordance with Delegation 1-3, Authorization of Employee Relocation Allowances and Approval of Relocation Reimbursements. |
| Funding requirements | Relocation authorizations must be approved and obligated before expenses are incurred to cover anticipated relocation expenses. |
| Liquidation of travel advances | Advances are liquidated with each applicable relocation voucher. If the advance is not liquidated, a billing document is established. |
| Manual quality reviews | 100% of all vouchers and third-party invoices are reviewed prior to processing. Invoices for third-party payments to a moving company are individually audited by a pre-audit company. |
| moveLINQ access | User profiles for moveLINQ access are appropriate for the job duties. |
| Separation of duties | Approving officials are responsible for following the delegation orders when authorizing and approving relocation allowances for the relocating employee. Separate roles are established for analysts, junior analysts and technicians for processing relocation documents. Analysts counsel relocating employees and establish authorizations in moveLINQ. Junior analysts review and approve relocation documents in moveLINQ and IFS. Technicians review vouchers and invoices for accuracy, input data in moveLINQ and provide reports of tax withholdings to employees. |


**1.32.12.1.6** **(03-24-2025)**

#### Terms/Definitions

1. This section provides IRS terms to supplement the FTR Chapter 300, Part 300-3, [Glossary of Terms](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-300/subchapter-A/part-300-3).

2. The following terms and definitions apply to this program:



01. **Actual Report Date** \- The date when an employee or new appointee physically reports to the new or first official station and performs any integral work related to the transfer or appointment.

02. _Approving Official_ \- The manager authorized to approve relocation vouchers in accordance with Servicewide Delegation Orders pertaining to relocation travel.

03. **Authorizing Official** \- The head of office authorized to approve relocation authorizations in accordance with Servicewide Delegation Orders pertaining to relocation travel.

04. **CFO Relocation Coordinator** \- The primary employee that provides relocation benefit counseling to relocating employees.

05. **Centrally Billed Account (CBA)** \- A corporate credit card account used by authorized IRS employees who do not have an individually billed government travel card for official IRS common carrier transportation (airline and train) travel expenses. CBA is used only for common carrier transportation.

06. **City-to-City** \- A form of travel to a place, away from an employee's official station, to which the employee is authorized to travel, which may involve an overnight stay or lodging expense.

07. **Federal Insurance Contributions Act (FICA) Tax** \- A payroll tax or employment tax imposed by the federal government on both employees and employers to fund Social Security and Medicare.

08. **Foreign Area** (also refer to non-foreign area) - An area that includes the Trust Territories of the Pacific Islands situated both outside the continental United States (OCONUS) and the non-foreign areas.

09. **Gaining Office** \- The office where the employee will report, and which will issue the relocation travel authorization and fund the travel.

10. **Government Travel Card** \- A credit card used to pay for authorized official travel and allowable travel-related expenses. Each travel card reflects an individual account established in the travel cardholder's name. This term is synonymous with travel card, credit card, government issued travel card and individual billed account (IBA). The travel card is a credit card issued by a financial institution under contract with Treasury which can only be used to pay for authorized official IRS travel and allowable travel-related expenses.

11. **Head of Office** \- Any of the following IRS officials: Commissioner of Internal Revenue, Deputy Commissioners, Division Commissioners, IRS Chief Human Capital Officer, Chiefs, Chief Counsel, Chief of Staff, Directors reporting directly to the Commissioner or Deputy Commissioners and National Taxpayer Advocate.

12. **House-Hunting**\- The activity of searching for a house to buy or rent.

13. **Losing Office** \- The office where the employee is departing.

14. **Non-Foreign Area** -The states of Alaska and Hawaii, an area that includes, the Commonwealths of Puerto Rico and the Northern Mariana Islands, Guam, the United States (U.S.) Virgin Islands and the territories and possessions of the United States (excludes the former Trust Territories of the Pacific Islands, which are considered foreign areas for the purposes of the FTR).

15. **Internal Revenue Bill of Lading (IRBL)** \- A contract using the actual expense method for transportation services between the United States (U.S.) Government and the carrier transporting the household goods, professional books, papers, and equipment (PBP&E), privately-owned vehicles (POV), and unaccompanied air baggage (UAB).

16. **Official Station** \- The location where the employee regularly performs their duties. The geographic limits of the official station are the corporate limits of the city or town where the employee is located, or, if not in an incorporated city or town, the reservation, station or other established area that has definite boundaries where the employee is located, not to exceed 50 miles from the employee's location. If the employee’s work involves recurring travel or varies on a recurring basis, the location where the work activities of the employee’s position of record are based is considered the regular place of work.

17. **Permanent Change of Station (PCS)** \- An assignment of a new appointee to an official station or the transfer of an employee from one official station to another on a permanent basis.

18. **Relocation Advance** \- The prepayment of estimated relocation expenses to an employee. It is the expectation that the employee will account for amounts received by filing a relocation voucher.

19. **Relocation Authorizations** \- The documents that authorize allowances on a relocation authorization for basic moving expenses and relocation authorization amendment for basic plus expenses, and other amendments for temporary quarters or any allowance not authorized on the original basic moving expense authorization that provide approval to relocate in the government's interest and are used to obligate relocation funds.

20. **Relocation Income Tax Allowance (RITA)** \- The payment to the employee to cover the difference between the withholding tax allowance (WTA), if any, and the actual tax liability incurred by the employee as a result of their taxable relocation benefits; Relocation Income Tax Allowance (RITA) is paid whenever the actual tax liability exceeds the WTA.

21. **Relocation Voucher** \- Form 8741, Relocation Voucher, a written request for reimbursement of expenses supported by documentation and receipts incurred in the performance of a permanent change of station or temporary change of station, and for the liquidation of advances, if applicable.

22. **Residence** \- The one home from which an employee regularly commutes to and from work on a daily basis and which was their residence at the time an employee is officially notified by competent authority to transfer to a new official station.

23. **Temporary Change of Station (TCS)** -The relocation of an employee to a new official station for a temporary period while performing a long-term assignment, and subsequent return to the previous official station upon completion of that assignment.

24. **Temporary Quarters Subsistence Allowance (TQSA)** \- The Temporary Quarters Subsistence Allowance (TQSA) is an allowance provided to assist with temporary lodging, meals, laundry and dry cleaning while occupying temporary quarters at a new post and permanent residence is not yet available, or when an employee is getting ready to depart a post of duty permanently and must vacate residence.

25. **Temporary Quarters Subsistence Expenses (TQSE)** \- The Temporary Quarters Subsistence Expenses (TQSE) is an allowance provided to reimburse actual subsistence expenses incurred by an employee and/or their immediate family while occupying temporary quarters. TQSE does not include transportation expenses incurred during occupancy of temporary quarters.

26. **Transport** \- A system or means of conveying people or goods from place to place by means of a vehicle, aircraft, or ship.

27. **Withholding Tax Allowance (WTA)** \- The amount provided by the agency to gross-up taxable relocation allowances, reimbursements or direct payments to a vendor to offset the federal tax withholding.


**1.32.12.1.7** **(03-24-2025)**

#### Acronyms

1. The following acronyms apply to this program:




| **Acronyms** |
| :-: |
| CBA | Centrally Billed Account |
| CHAMP | Centralized Household Goods Traffic Management Program |
| CFR | Code of Federal Regulations |
| CONUS | Continental United States |
| DSSR | Department of State Standard Regulations |
| FICA | Federal Insurance Contributions Act |
| FTA | Foreign Transfer Allowance |
| FTR | Federal Travel Regulation |
| GSA | General Services Administration |
| IBA | Individual Billed Account |
| IRBL | Internal Revenue Bill of Lading |
| M&IE | Meals and Incidental Expenses |
| MEA | Miscellaneous Expense Allowance |
| mLINQs | Government Relocation Accounting Software |
| OCONUS | Outside the Continental United States |
| PCS | Permanent Change of Station |
| POD | Post of Duty |
| PBP&E | Professional Books, Papers and Equipment |
| POV | Privately-Owned Vehicle |
| RITA | Relocation Income Tax Allowance |
| SES | Senior Executive Service |
| SURI | Sistema Unificado de Rentas Internas |
| TCS | Temporary Change of Station |
| TDY | Temporary Duty |
| TQ | Temporary Quarters |
| TQSA | Temporary Quarters Subsistence Allowance |
| TQSE | Temporary Quarters Subsistence Expenses |
| UAB | Unaccompanied Air Baggage |
| USC | U.S. Code |
| WTA | Withholding Tax Allowance |


**1.32.12.1.8** **(03-24-2025)**

#### Related Resources

01. Employees should review the following IRMs:

02. IRM 1.32.4, Government Travel Card Program, for information on the Travel Card Program and the Centrally Billed Government Travel Card Program.

03. IRM 1.32.11, IRS City-to-City Travel Guide, for information on city-to-city travel, including domestic, foreign, invitational and emergency travel.

04. IRM 1.32.13, Relocation Services Program, for information regarding the use of the relocation services contract.

05. IRM 1.32.5, International Travel Office Procedures, for guidance on completing the necessary travel documents for international travel including the Form 1321, Authorization for Official Travel as well as visa and passport applications.

06. IRM 6.610.1, IRS Hours of Duty, for information on the use of administrative leave in connection with a government authorized relocation travel.

07. [Federal Travel Regulations](https://www.defensetravel.dod.mil/Docs/perdiem/JTR.pdf), for additional information on foreign and non-foreign OCONUS relocation.

08. [Department of State Standardized Regulations](https://aoprals.state.gov/content.asp?content_id=282&menu_id=101) (DSSR) for additional information on foreign and non-foreign OCONUS relocation.

09. [Foreign Affairs Manual: United States (U.S.) Department of State](https://fam.state.gov/), for additional information on foreign and non-foreign OCONUS relocation.

10. [Foreign Affairs Handbook - U.S. Department of State](https://fam.state.gov/), for additional information on foreign and non-foreign OCONUS relocation.

11. Delegation Order 1-3, Authorization of Employee Relocation Allowances and Approval of Relocation Reimbursements, for information on approval of relocation activities.


**1.32.12.2** **(03-24-2025)**

### General Rules and Applicability

01. This section provides IRS guidance to supplement FTR Chapter 302, Subpart A, Part 302-1, [General Rules](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-A/part-302-1).

02. The IRS may authorize the payment of relocation expenses to:



    1. Attract qualified candidates willing to relocate.

    2. Attract a specific individual with a unique set of skills not easily found in the area.

    3. Accommodate a mandatory or directed reassignment.


03. The rules governing the IRS’s ability to pay for relocation expenses for new and current employees are as follows:



    1. The employee is transferring from one duty station to another for permanent duty and the new duty station is at least 50 miles from the old duty station. The distance test is met when the new official station is at least 50 miles further from the employee’s current residence than the old official station is from the same residence. For example, if the old official station is three miles from the current residence, then the new official station must be at least 53 miles from that same residence to receive relocation expenses for residence transactions. The distance between the official station and residence is the shortest of the commonly traveled routes between them. The distance test does not take into consideration the location of a new residence. This follows the distance guidelines found in Internal Revenue Service Publication 521, Moving Expenses. The business unit’s Deputy Commissioner (or the Chief of Staff for Commissioner direct-report organizations) may authorize an exception to the 50-mile threshold on a case-by-case basis.

    2. The employee must sign a Form 4282, Twelve-Month-Service Agreement, for a domestic relocation (CONUS), a Form 10902, Overseas Transportation Service Agreement for a foreign (OCONUS) relocation or a Form 9803, Transportation Agreement for a non-foreign relocation (OCONUS).

    3. Employees cannot incur any travel expenses prior to approval. The employee must begin their travel including transportation for the family and household goods after receiving an approved relocation authorization. All aspects of the relocation must be completed within one year from the report date of the transfer or appointment, including settlement of real estate transactions. The one-year limit can be extended for an additional year by the employee through their approving official. There is no authority to extend the relocation beyond the two years.


04. Relocation allowances are determined by the type of assignment as a new appointee, student trainee, transferee, overseas tour renewal employee, separating employee or an employee performing a temporary change of station.

05. The purpose of the relocation authorization is to:



    1. Provide written approval authorizing the employee to incur relocation expenses.

    2. Inform the employee of approved entitlements and allowances by listing the estimated amount for each allowance.

    3. Obligate funds for relocation expenses.


06. Public Law 115-97 known as the "Tax Cuts and Jobs Act of 2017" was signed into law on December 22, 2017. The law suspended qualified moving expense deductions along with the exclusion for employer reimbursements and payments of moving expenses effective January 1, 2018, for tax years 2018 through 2025. Relocations that occurred prior to January 1, 2018, are still deductible.

07. The IRS has determined payment for extended storage of household goods for employees assigned to OCONUS locations will remain excluded from gross income and exempt from taxation. Additionally, transportation of an employee’s POV to, from and between the CONUS and a post of duty outside the continental United States, or between posts of duty OCONUS will remain excluded from gross income and exempt from taxation. Transportation of an employee’s POV within CONUS, however, will be included in the employee’s gross income and subject to tax liability for those payments.

08. Employees cannot relocate to the new official station before they have received an approved relocation authorization for basic moving expenses, before incurring permanent change of station (PCS) or temporary change of station (TCS). Employees must contact their assigned CFO relocation coordinator for assistance with entitlements and allowances for basic relocation allowances and basic plus relocation allowances.

09. The IRS has two relocation programs:



    1. The basic relocation allowances program must be authorized on relocation authorization for basic moving expenses and approved by the business unit head of office or their designee as defined in Delegation Order 1-3, Authorization of Employee Relocation Allowances and Approval of Relocation Reimbursements. This authority may be redelegated, in writing, by the business unit head of office to the director, Strategy and Finance, or their equivalent.

    2. The basic plus relocation allowances program must be authorized on the relocation authorization amendment and approved by the business unit head of office or their designee. The request is then forwarded to the Senior Associate CFO for Financial Management for final approval. Refer to IRM 1.32.13, Relocation Services Program, for additional information on requesting this program.


10. Relocating employees are entitled to all mandatory payments allowable under the basic relocation allowances program. The basic relocation allowances program includes mandatory allowances by move type as prescribed by the FTR:



    1. En route travel to new POD for employees and immediate family

    2. Miscellaneous expenses

    3. Real estate transactions

    4. Transportation of a mobile home or boat used as a primary residence in lieu of transportation of household goods

    5. Transportation of household goods up to 18,000 pounds, with a 2,000-pound packing additive, and storage up to 60 days in a CONUS location or 90 days in an OCONUS location

    6. Temporary storage for household goods may not exceed a total authorization of 150 days for CONUS locations or 180 days for OCONUS locations

    7. Extended storage of household goods (for isolated official stations)

    8. RITA


11. The Basic Relocation Allowances Program also includes discretionary allowances as prescribed by the FTR:



    1. House-hunting trip

    2. Temporary Quarters Subsistence Expenses (TQSE) for up to 60 days

    3. Extension of temporary quarters for an additional 60 days not to exceed a total of 120 days

    4. Shipment of a POV to a foreign or non-foreign OCONUS location

    5. Extension of temporary storage of household goods within CONUS – up to an additional 90 days not to exceed a maximum of 150 days and whenever there is an OCONUS origin or destination up to an additional 90 days not to exceed a maximum of 180 days


12. Under the Basic Plus Relocation Allowances Program, the IRS may pay the following additional relocation allowances:



    1. Use of the relocation services contract

    2. Shipment of a POV within CONUS


13. Employees must receive authorization for basic relocation allowances on, Relocation Authorization for Basic Moving Expenses, before requesting the basic plus relocation allowances on Relocation Authorization Amendment for Basic Plus Moving Expenses.

14. The business units must submit the request for basic plus relocation allowances to all CFO relocation coordinators at mailbox \*CFO Relocation Basic Plus Requests@irs.gov. Travel Operations will forward the request to the Director, Travel Management, who will review and forward to the Senior Associate CFO for Financial Management for approval or disapproval. The Senior Associate CFO for Financial Management will return the package to Travel Operations.

15. Relocation allowances are determined by the type of assignment as a new appointee, student trainee, transferee, overseas tour renewal employee, separating employee or employee performing a TCS.

16. Employees are required to use their government travel card for themselves and authorized family members, for house-hunting trips, en route travel and temporary quarters in accordance with the rules governing the mandatory use of the government travel card. Use of the government travel card for temporary quarters is required for lodging.

17. Employees must contact the Travel Management Center (TMC) to obtain transportation tickets for themselves and family members. Tickets may not be obtained from any other source.

18. Employees may contact one of the relocation coordinators for pre-transfer counseling. A list of the coordinators can be found on the relocation guidance website.

19. Information regarding a hardship relocation program can be found on the relocation guidance website, or by contacting the designated points of contact in the business unit.

20. In accordance with IRM 6.610.1.3.9(1), IRS Hours of Duty, employees who are authorized moving expenses are required to obtain management approval to be excused from duty for the purpose of completing certain relocation transactions. If activities associated with the relocation cannot be conducted outside the employee’s regular working hours, an employee may be granted an excused absence to make arrangements and to transact personal business directly related to a permanent change in duty station. Such activities may relate to locating living quarters at the new POD (if a house-hunting trip was not authorized); sale of property; transportation and delivery of household goods; and securing utilities, driver's license and automobile tags. Excused absence may only be approved if the cost of relocation (travel and transportation of household goods) is paid by the IRS.

21. If a house-hunting trip is authorized, employees may be given a reasonable period of excused absences, up to 10 consecutive calendar days, that includes travel time.

22. GSA issued a final rule amending the FTR with respect to temporary quarters subsistence expenses (TQSE) allowances. Changes include implementing a third TQSE methodology called TQSE Lodging Plus, redefining the current TQSE methods, lowering the percentage multipliers for calculating TQSE maximum daily amounts, and prohibiting adjustments to TQSE percentage multipliers for house-hunting days. The final rule also exempts temporary quarters (TQ) located in Presidentially Declared Disaster areas under the Stafford Act from the “reasonable proximity” requirement and allows agencies to authorize TQSE at the locality per diem allowance or authorize actual expenses on an individual basis. These changes are applicable for relocation authorized before June 30, 2024, and beyond. Travelers with a relocation authorized before June 30, 2024, must maintain their selection of TQSE Actual Expense and TQSE Lump Sum and must follow the former TQSE methodologies. All locations in the United States and non-foreign overseas locations where employees are occupying temporary lodging during a permanent change of station are affected.

23. Shipments to Puerto Rico requires all relocating employees/shippers to register in the Puerto Rico Treasury Department Sistema Unificado de Rentas Internas (SURI) system prior to bringing goods into Puerto Rico. This is a mandatory requirement. Registration must be done timely or the shipment will be delayed, at no fault of the transportation service provider.



    1. All relocating employees/shippers must transmit the required information in the system before the shipment arrives to Puerto Rico

    2. All vehicle transports must include: Title, Registration, License, Bill of Sale. Here is a link to the registration and the tax document forms: [SURI Puerto Rico Government](https://suri.hacienda.pr.gov/%20/)

    3. Relocating employees must log into SURI and create an account.

    4. This process should be completed before their shipment leaves for Puerto Rico to avoid problems and delays. The transportation service provider and the relocating employee/shipper must coordinate together.


**1.32.12.2.1** **(04-14-2020)**

#### Travel to the New Official Station Prior to the Report Date

1. The IRS requires the reporting date to be the date on which the employee physically reports for duty at their new official station. This date may be specified in the employee's service agreement. The reporting date will be the first day of the one-year time limit allowed to complete all applicable relocation activities. The effective transfer or appointment date will not always coincide with the reporting date. Per diem for en route travel ends whether arrival is prior or subsequent to the date on the approved relocation authorization.

2. Travel to the new official station prior to the report date may only occur if the travel assignment is determined to be distinct from the new assignment and can be legitimately classified as temporary duty travel, in which case the payment of per diem may be authorized. If the travel to the new official station is an integral part of the new assignment, payment of per diem is not allowed and the beginning date of the travel is considered the employee’s report date. The nature of the assignment may not be related to the new position.


**1.32.12.2.2** **(03-24-2025)**

#### Short Distance Moves

1. Relocation allowances for a short distance move, which is less than 50 miles from the old POD or residence, may only be authorized when it is determined by the IRS Deputy Commissioner to be in the best interest of the government with a written memorandum providing the exception. All reimbursable expenses for short distance moves are taxable income and cannot be waived.

2. Business units must submit a request to Travel Operations when the travel and transportation expenses and applicable allowances in connection with the employee's transfer from their residence involves a distance of less than 50 miles within the same general local or metropolitan area. Travel Operations will forward the request to the IRS Deputy Commissioner for approval or disapproval.


**1.32.12.3** **(04-14-2020)**

### Employee Eligibility Requirements

1. This section provides IRS guidance to supplement FTR Chapter 302, Relocation Allowances, Subpart A, Part 302-1, [General Rules](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-A/part-302-1), and 302-2, [Employee Eligibility Requirements](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-A/part-302-1), including:



1. Service agreements

2. Time limits

3. Advance of funds


**1.32.12.3.1** **(03-24-2025)**

#### Service Agreements

1. A service agreement is a written agreement between the employee and the IRS, signed by the employee and an approving official, stating that the employee will remain in the service of the government for a period of time as specified in after the employee has relocated. Employees must sign a service agreement if the employee is receiving reimbursement for relocation travel expenses, except as provided in § 302-2.17 and §§ 302-3.300 (see the note to table F in § 302-3.101 of this chapter; no service agreement is required for separation or relocation where the gaining agency does not authorize relocation expenses) and 302-3.410 of this chapter.

2. There are three types of service agreements:



1. Form 4282, Twelve-Month Service Agreement, (for domestic travel) - A written agreement between IRS and the employee that they will remain within the service of the government for a period of twelve months, after they have relocated; and includes a duplicate reimbursement statement that the employee nor an immediate family member has not received any other relocation benefits from another source. An employee is required to agree to the terms within CONUS for a period of service of not less than 12 months following the effective date of appointment or transfer.

2. Form 10902, Overseas Transportation Agreement, (for foreign OCONUS travel) - The employee is required to agree to the terms of the agreement for OCONUS for an agreed upon period of service of not more than 36 months or less than 12 months following the effective date of appointment or transfer. This allows the employee to remain at that POD for a period of 36 months from the date the employee arrives, unless the employee's tour is interrupted for a reason beyond the employee's control and acceptable to the IRS. If the employee extends their 36 month period, they must sign the tour renewal portion of the form in order to continue to receive allowances until they return to their U.S. post of assignment.

3. Form 9803, Transportation Agreement, (for non-foreign OCONUS travel) - Requires the employee to remain at that POD for a period of two years from the date the employee arrives, unless the employee's tour is interrupted for a reason beyond the employee's control, and acceptable to the IRS. If the employee extends their two-year period, they must also sign the tour renewal portion of the form in order to continue to receive allowances until they return to their U.S. post of assignment.


3. The applicable service agreement must be signed by the employee, prior to the approving official signing the Relocation Authorization for Basic Expenses. Employees and their immediate family members may incur expenses after the signed document has been forwarded to the employee.

4. Employees will be penalized if they separate from the government before completing the service agreement, unless the IRS Commissioner determines that the reasons for the separation were beyond the employee's control and are acceptable to the IRS.

5. If an employee is separated from the government before completing one year of an agreed tour of duty, under circumstances that appear to be beyond their control, the facts should be presented to the Commissioner. If the Commissioner determines that the separation was beyond the employee’s control and acceptable to the IRS, the employee will be relieved of all indebtedness normally arising from the early separation. A copy of such memorandum of acceptance, stating that the expense of return travel and transportation will be allowed and the reasons, therefore, must be submitted to the CFO relocation coordinator for review. The IRS Commissioner will return the request back to the CFO relocation coordinator electronically via email.

6. If employees receive reimbursement for any claimed expense from another source in error, they will be required to repay the duplicate reimbursement to the IRS by submitting the payment to:


    Beckley Finance Center


    ATTN: Debt Collection Unit


    P.O. Box 9002


    Beckley, WV 25802-9002


**1.32.12.3.2** **(04-14-2020)**

#### Time Limits

1. The employee is authorized to begin their travel, including transportation for the family and household goods, after receiving an approved relocation authorization. At no time may an employee incur any travel expenses prior to approval. All aspects of the relocation must be completed within one year from the report date of the transfer, including settlement of real estate transactions. The one-year limit may be extended for an additional year by the employee through their appropriate business unit approving official. Additional extensions beyond the two years may not be approved.

2. The IRS may authorize a one-year extension, if extenuating circumstances exist including, but not limited to:



1. Inability to obtain financing

2. Absence from official station for extended periods of time

3. Inadequate housing to meet family needs


3. Employees must submit a written request to the business unit head of office or director, Strategy and Finance, no later than 60 days before the one-year expiration date if they require additional time to complete their relocation activities.

4. The business unit must approve the employee’s extension and contact the CFO relocation coordinator 60 days before the expiration of the one-year limitation.


**1.32.12.3.3** **(04-14-2020)**

#### Advance of Funds

01. To receive a relocation advance employees must have:



    1. A signed service agreement

    2. An approved Relocation Authorization for Basic Moving Expenses

    3. An approved Form 4253-C, Relocation Travel Advance Request.


02. Advances should be kept to the minimum amount needed to cover the employee’s needs, but no more than 75% of the estimated reimbursable expenses expected to be incurred.

03. As a transferee, employees may receive advances for the following:




    | **Advance of Funds Allowances for a Transferee** |
    | :-: |
    | **Funds may be advanced for:** | **Funds may not be advanced for:** |
    | 1\. House-hunting and per diem for employee and spouse only | 1\. Miscellaneous moving expenses |
    | 2\. TQSE | 2\. Residence transaction expenses (sell, buy, or lease termination expense) |
    | 3\. Per diem en route to new official station | 3\. Federal, state or local income taxes |
    | 4\. Transportation of a mobile home in lieu of household goods except if a government bill of lading is used | 4\. Extended storage of household goods |
    | 5\. Shipment and/or storage of a POV when authorized within CONUS except if a government bill of lading is used | 5\. Non-temporary storage of household goods |
    | 6\. Transportation and temporary storage of household goods except if a government bill of lading is used |  |

04. When travel and transportation to an official station are authorized for a new appointee or student trainee, the IRS may advance funds to cover cash expenditures expected for reimbursable travel expenses, as follows:




    | **Advance of Funds Allowances for a New Appointee or Student Trainee** |
    | :-: |
    | **Funds may be advanced for:** | **Funds may not be advanced for:** |
    | 1\. Per diem en route to new official station for new employee only | 1\. Extended storage of household goods |
    | 2\. Transportation of a mobile home except if a government bill of lading is used |  |
    | 3\. Shipment and/or storage of a POV if authorized for an overseas assignment or CONUS except if a government bill of lading is used |  |
    | 4\. Transportation and temporary storage of household goods except if a government bill of lading is used |  |

05. Relocating employees may use their government travel card, if applicable, to obtain advances using an automated teller machine. If an employee does not have a government travel card, the employee should complete Form 4253-C, Relocation Travel Advance Request, to request a relocation advance. Use of the travel card for temporary quarters is mandatory.

06. Employees must apply for separate advances to cover allowed expenses for house-hunting, en route travel, temporary quarters, and shipping and storage of household goods. Requests for advances should be submitted two weeks before an employee anticipates incurring a relocation expense.

07. Employees must complete an advance request Form 4253-C, Relocation Travel Advance Request, and submit by email or postal mail to:


     Beckley Finance Center


     ATTN: Relocation Unit


     P.O. Box 9002


     Beckley, WV 25802-9002








     Email - \*CFO.BFC.Relocation@irs.gov


     Employees cannot use the IRS electronic travel system to request relocation advances or to enter relocation expenses.

08. If the transfer is cancelled, postponed or the service agreement is violated, the advanced amount must be returned immediately.

09. Advances for regular travel cannot be mixed with relocation advances.

10. Employees must submit a relocation voucher within 15 calendar days of completing or cancelling any of the relocation activities and liquidate the outstanding advance.


**1.32.12.4** **(04-14-2020)**

### Relocation Allowances by Specific Type

1. This section provides IRS guidance to supplement FTR Chapter 302, Relocation Allowances, Part 302-3, [Relocation Allowance by Specific Type](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-B/part-302-3), including:



1. New appointee

2. Transferred employees

3. Overseas tour renewal

4. Senior Executive Service (SES) separations for retirement (Last Move Home)

5. TCS

6. Return separation


**1.32.12.4.1** **(03-24-2025)**

#### New Appointee

1. The relocation allowances available to new appointees are as follows:




| **Table A: Assigned to First Official Station in CONUS** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. Transportation for employee and immediate family member(s) | 1\. Shipment of POV within CONUS when the distance is 600 miles or more after approval by the Senior Associate CFO for Financial Management |
| 2\. Per diem only for the employee en route travel |  |
| 3\. Transportation and temporary storage of household goods |  |
| 4\. Extended storage of household goods when assigned to a designated isolated official station in CONUS |  |
| 5\. Transportation of a mobile home or boat used as a primary residence instead of the transportation of household goods |  |
| 6\. RITA |  |






| **Table B: Assigned to First Official Station in Foreign or Non-Foreign OCONUS** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. Transportation for employee and immediate family member(s) | 1\. Shipment of a POV to a foreign or non-foreign OCONUS location after approval by the approving official |
| 2\. Per diem only for the employee en route travel | 2\. TQSE are not authorized in a foreign area. Employees may be entitled to the following under the DSSR (Department of State Standardized Regulations) (Government Civilians-Foreign Areas), which is available from the Superintendent of Documents, Washington, DC 20402:<br> a) Foreign Transfer Allowance (FTA) (Subsistence Expense) for quarters occupied temporarily before departure from the 50 states or the District of Columbia for an official station in a foreign area incident to a permanent change of station and travel to first official station overseas<br> b) Temporary quarters subsistence allowance (TQSA) when a transfer is authorized to a foreign area<br> c) Miscellaneous expense portion of the FTA is authorized incident to first official station travel to a foreign area |
| 3\. Transportation and temporary storage of household goods | 3\. Use of the relocation services contract for property management services after approval by the Senior Associate CFO for Financial Management |
| 4\. Extended storage of household goods |  |
| 5\. RITA |  |


**1.32.12.4.2** **(03-24-2025)**

#### Transferred Employees

1. When authorized, the IRS will pay or reimburse the following allowances for transferred employees:



1. Table A: Transfer Between Official Stations in CONUS

2. Table B: Transfer from CONUS to Foreign or Non-Foreign OCONUS Official Station

3. Table C: Transfer from Foreign or Non-Foreign OCONUS Official Station to an Official Station in CONUS

4. Table D: Transfer Between Foreign or Non-Foreign OCONUS Official Stations

5. Table E: Return from Foreign or Non-Foreign OCONUS Official Station to Place of Actual Residence for Separation

6. Table F: Tour Renewal Agreement Travel


| **Table A: Transfer Between Official Stations in CONUS** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation and per diem for employee and immediate family members | 1\. House-hunting per diem and transportation and for only the employee and spouse after approval by the approving official |
| 2\. Miscellaneous moving expenses | 2\. TQSE up to 60 days and an extension up to an additional 60 days after approval by the approving official |
| 3\. Residence transaction expenses (sell, buy, or lease termination expenses) | 3\. Shipment of a POV within CONUS when the distance is 600 miles or more after approval by the Senior Associate CFO for Financial Management |
| 4\. Transportation and temporary storage of household goods | 4\. Use of the relocation services contract to sell residence after approval by the Senior Associate CFO for Financial Management |
| 5\. Extended storage of household goods when assigned to a designated isolated official station in CONUS | 5\. House-hunting per diem & transportation, employee & spouse only when transfer is from an OCONUS non-foreign area (part 302-5 of this chapter). |
| 6\. Transportation of a mobile home or boat used as a primary residence instead of the transportation of household goods |  |
| 7\. RITA | 6\. Property Management Services (part 302-15 of this chapter). |

| **Table B: Transfer from CONUS to Foreign or Non-Foreign OCONUS Official Station** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation and per diem for employee and immediate family members | 1\. TQSE are not authorized in a foreign area. Employees may be entitled to the following under the Department of State Standard Regulations, DSSR (Government Civilians-Foreign Areas), which is available from the Superintendent of Documents, Washington, DC 20402:<br> a) FTA for quarters occupied temporarily before departure from the 50 states or the District of Columbia for an official station in a foreign area incident to a permanent change of station and travel to first official station overseas<br> b) TQSA |
| 2\. Miscellaneous moving expenses | 2\. Use of the relocation services contract for property management services after approval by the Senior Associate CFO for Financial Management |
| 3\. Transportation and temporary storage of household goods | 3\. Shipment of a POV to a foreign or non-foreign OCONUS location after approval by the approving official |
| 4\. Extended storage of household goods |  |
| 5\. Residence expenses only for lease termination expenses foreign |  |
| 6\. Residence expenses for home sale and purchase for non-foreign |  |
| 7\. RITA |  |

### Note:

Residence transaction expenses (lease termination expenses) apply when an employee is transferred in the interest of the government to a different non-foreign area official station instead of being returned to the former non-foreign area official station.

### Note:

**Column 2, item 1a**: Allowed for transfers to a non-foreign OCONUS location.

| **Table C: Transfer from Foreign or Non-Foreign OCONUS Official Station to an Official Station in CONUS** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation and per diem for employee and immediate family members | 1\. Shipment of a POV from OCONUS requires approval if the POV was not previously shipped to that OCONUS location |
| 2\. TQSE |  |
| 3\. Miscellaneous moving expenses |  |
| 4\. Residence transaction expenses (sell, buy, or lease termination expenses) |  |
| 5\. Transportation and temporary storage of household goods |  |
| 6\. Shipment of POV from OCONUS if employee was previously authorized a shipment of POV to that OCONUS location |  |
| 7\. Extended storage of household goods only when assigned to a designated isolated official station in CONUS |  |
| 8\. RITA |  |

### Note:

**Column 1, item 2:** A TQSA under the Department of State Standard Regulations (DSSR) may be authorized preceding final departure subsequent to the necessary vacating of residence quarters.

**Column 1, item 4:** Allowed when the old and new official station are located in the United States. Also allowed when instead of being returned to the former non-foreign OCONUS area official station, an employee is transferred in the interest of the government to a different non-foreign OCONUS area official station from which transferred when assigned to the non-foreign official station.

**Column 1, item 4:** Also allowed when instead of being returned to the former CONUS area official station, an employee is transferred in the interest of the government to a different CONUS official station.

| **Table D: Transfer Between Foreign or Non-Foreign OCONUS Official Stations** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation and per diem for employee and immediate family members | 1\. Shipment of a POV to a foreign or non-foreign OCONUS location requires approval by the approving official |
| 2\. TQSE | 2\. Use of the relocation services contract for property management services after approval by the Senior Associate CFO for Financial Management |
| 3\. Transportation and temporary storage of household goods | 3\. TQSA may be authorized under DSSR |
| 4\. Miscellaneous moving expenses |  |
| 5\. Extended storage of household goods |  |
| 6\. RITA |  |
|  |  |

| **Table E: Return from Foreign or Non-Foreign OCONUS Official Station to Place of Actual Residence for Separation** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation for employee and immediate family members | 1\. Shipment of a POV from OCONUS requires approval by the approving official if the POV was not previously shipped to that OCONUS location |
| 2\. Per diem for employee only |  |
| 3\. Transportation and temporary storage of household goods |  |
| 4\. RITA |  |
| 5\. Divorced spouse & terminated committed relationship with domestic partner | 2\. Employees who divorce their spouse or terminate a committed relationship with a domestic partner while OCONUS, will receive reimbursement of transportation expenses to return their former spouse or domestic partner and other immediate family members to the place of actual residence within or outside CONUS. Early return expenses for the immediate family are limited to transportation and shipment of household goods and personal effects. Early return expenses do not include other relocation expenses such as TQSE and miscellaneous expense allowance. |

| **Table F: Tour Renewal Agreement Travel** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation for employee |  |
| 2\. En route transportation for immediate family |  |

**1.32.12.4.3** **(04-14-2020)**

#### Overseas Tour Renewal Travel

1. Overseas tour renewal travel is reimbursement for the employee and their immediate family of round-trip travel and transportation expenses between the overseas post of duty and the employee’s actual place of residence in the U.S.

2. Employees and their immediate family members are entitled to overseas tour renewal travel expenses that may include rest and recuperation travel or home leave travel. The reimbursement will be limited to transportation cost only.

3. The approving official must sign Section A of Form 10902, Overseas Transportation Service Agreement, for a foreign transfer or Form 9803, Transportation Agreement, if the employee is moving to a non-foreign POD and the employee must sign Section B of the form after completion of each tour renewal, either continuing with the current tour or beginning a new tour. A copy of the form should be submitted to the CFO relocation coordinator and maintained by the employee for their personal records.

4. Employees must submit Form 13635, Manual Travel Authorization, prior to travel to receive reimbursement for overseas tour renewal travel and submit Form 15342, Manual Travel Voucher, within five business days after completion of the trip.

5. Employees must immediately provide the CFO relocation coordinator with their actual place of residence within CONUS for future tour renewal travel.

6. Employees who are on an overseas assignment and have signed a new service agreement or tour renewal to remain at the overseas post or to transfer to another overseas post will be authorized to continue extended storage and property management services at no expense to them.


**1.32.12.4.4** **(03-24-2025)**

#### Senior Executive Service (SES) Separation for Retirement Last Move Home

1. Senior Executive Service (SES) employees must contact their assigned CFO relocation coordinator to request authorization for their separation retirement relocation expenses on Relocation Authorization for Basic Moving Expenses. The request must include:



1. The tentative moving dates

2. The origin and destination of their planned move

3. A copy of their eligibility letter for SES separation retirement last move home benefits


2. As an eligible SES career appointee who meets the conditions for a separation retirement may be reimbursed for relocation expenses which include the following:




| **Table G: Last Move Home for SES Career Appointees Upon Separation Retirement** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation for employee and immediate family members | 1\. Shipment of a POV within CONUS when the distance is 600 miles or more after approval by the Senior Associate CFO for Financial Management |
| 2\. Per diem for employee only |  |
| 3\. Transportation and temporary storage of household goods |  |
| 4\. Transportation of a mobile home or boat used as a primary residence instead of the transportation of household goods |  |
| 5\. RITA |  |

3. Upon separation, if the employee elects to reside in a different geographical area which is less than 50 miles from the official station, they will not receive reimbursement.

4. Employees should request their Relocation Authorization for Basic Moving Expenses, within six months prior to the date of separation and begin their relocation activities no later than six months after their date of separation. All last move home activities must be completed within one year of the date of separation.

5. If an employee dies before the separation retirement travel is completed, the IRS pays moving expenses for the family even if the family chooses a different destination other than the one chosen by the employee.

6. Employees may not receive a travel advance for a last move home.


**1.32.12.4.5** **(03-24-2025)**

#### Temporary Change of Station (TCS)

1. A temporary change of station (TCS) is a relocation to a new official station for a temporary period while performing a long-term assignment, and subsequent return to the previous official station upon completion of that assignment.

2. Employees may be reimbursed the following allowances for temporary change of station:




| **Table H: Temporary Change of Station (TCS)** |
| :-: |
| **Mandatory: Relocation allowances the IRS _must_ pay or reimburse:** | **Discretionary: Relocation allowances the IRS _may_ pay or reimburse:** |
| 1\. En route transportation and per diem for employee and immediate family members | 1\. House-hunting trip expenses after approval by the approving official |
| 2\. Miscellaneous moving expenses | 2\. TQSE for 60 days and an extension up to an additional 60 days after approval by the approving official |
| 3\. Transportation and temporary storage of household goods | 3\. Shipment of a POV to a CONUS location when the distance is 600 miles or more after approval by the Senior Associate CFO for Financial Management |
| 4\. Transportation of a mobile home or boat used as a primary residence instead of the transportation of household goods | 4\. Property management services after approval by the Senior Associate CFO for Financial Management |
| 5\. RITA |  |

3. The IRS will not pay for residence transaction expenses for a TCS move. However, the IRS will pay for property management services if approved by the Senior Associate CFO for Financial Management.


**1.32.12.4.6** **(04-14-2020)**

#### Return Separation

1. Return separation occurs once the employee has completed the duty OCONUS as specified in the service agreement. The IRS must pay one-way transportation expenses for the employee, the family member(s) and the household goods.

2. An employee qualifies for a return separation at government expense when the employee successfully completes a tour of duty at an OCONUS post of duty as specified in the original service agreement which the employee signed when transferred.

3. When the employee has completed an OCONUS tour as specified in the service agreement, the IRS must pay one-way transportation expenses for the employee and family member(s), per diem for the employee only, transportation and temporary storage of household goods and shipment of POV when authorized.


**1.32.12.5** **(04-14-2020)**

### Allowances for Subsistence and Transportation Expenses

1. This section provides IRS guidance to supplement FTR Chapter 302, Part 302-4, [Allowances for Subsistence and Transportation](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-C/part-302-4) including:



1. Travel expenses

2. Per diem at new official station

3. Use of more than one POV for en route travel


**1.32.12.5.1** **(04-14-2020)**

#### Travel Expenses

1. The IRS will pay for an employee’s transportation expenses for the authorized mode of travel that is determined to be the most advantageous to the government. If the employee travels by any other mode, the IRS will pay the employee’s transportation expenses, not to exceed the cost of transportation expenses by the authorized mode. En route mileage for travel begins at the residence at the old post of duty and ends at the temporary quarters or permanent residence at the new post of duty.

2. The employee must use their government travel card or the centrally billed account (CBA) for transportation costs for themselves and their immediate family members.

3. Employee per diem for en route relocation travel between the old and new official stations is limited to the standard CONUS rate which can be found on the GSA website.

4. The travel regulations prohibit reimbursement of meals and incidental expenses (M&IE) unless travel is in excess of 12 hours and 300 miles for en route travel.


**1.32.12.5.2** **(03-24-2025)**

#### Per Diem at New Official Station

1. Per diem for en route travel ends on the report date, whether the arrival is prior to or subsequent to the report date on the approved relocation authorization. However, an employee may be entitled to receive reimbursement of actual expenses up to the maximum calculation of per diem allowances for temporary quarters when they arrive at the new official station, if authorized.

2. An employee detailed to duty at a temporary duty location (TDY) location is not entitled to per diem at such place on and after the date they received notice, formal or informal, that the temporary station was to become the permanent official station. The employee should immediately return to the old official station and begin their relocation.

3. Employees cannot receive per diem at a TDY location when it becomes their permanent official station.

4. Employees may receive per diem to return to the old official station, when they are detailed to a TDY location, after the IRS designated the TDY location as the permanent official station. Employees are allowed per diem for a round trip between the new and old stations to handle personal matters related to the transfer or to complete unfinished work. The trip home is temporary duty travel, and the voucher should be filed in the IRS electronic travel system.


**1.32.12.5.3** **(04-14-2020)**

#### Use of More Than One Privately-Owned Vehicle (POV) for En Route Travel

1. Employees can be authorized to use more than one POV to perform en route travel to the new official station under certain situations.

2. The maximum number of POVs that the approving official can authorize for en route travel is limited to the number of authorized licensed drivers, including the employee and immediate family members. The approving official may authorize the use of more than one POV if the employee meets one of the following circumstances:



1. One POV cannot reasonably transport the entire family together with luggage.

2. A family member's age or physical condition requires special accommodations.

3. The employee must report in advance of the family, who remains at the old official station to sell the residence, ship household goods, complete the school term or adequate housing is not available at the new official station.

4. A member of the family performs travel between points other than those of the employee's travel.

5. In advance of the employee's travel, the family must travel to the new official station for acceptable reasons, such as enrolling children in school at the beginning of the term.


3. The use of more than one POV for en route travel must be authorized in advance on Relocation Authorization for Basic Moving Expenses by the approving official.



### Note:



Check the GSA website for the most recent mileage rates when relocation travel is performed by POV.


**1.32.12.6** **(06-07-2022)**

### Allowance for House-Hunting Trip Expenses

1. This section provides IRS guidance to supplement FTR Chapter 302, Relocation Allowances, Part 302-5, [Allowance for house-hunting Trip Expenses](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-C/part-302-5), including:

2. The IRS may authorize only one round trip for the employee and/or spouse in connection with a particular transfer.

3. Administrative leave may not be granted for the house-hunting trip as it is considered duty status. If a house-hunting trip is authorized, employees will record the time as hours of work but may be granted a reasonable amount of time to conduct house-hunting activities (for hours within their TOD) to allow them up to a maximum of ten consecutive calendar days for house-hunting, including travel time.

4. The applicable per diem rate for a house-hunting trip is the standard CONUS rate if the lodging plus expense method is chosen.

5. The approving official can authorize the mode of transportation that provides the minimum time en route and maximum time at the new official station, as follows:



1. Expenses for reasonable local transportation costs including common carrier, local transit, rental car or a POV at the location of the new official station when house-hunting is allowed. When the new official station is less than 250 miles from the employee's old station, the approving official must authorize travel by POV, unless there are compelling reasons for not using a POV that are acceptable. (For example, employee is physically impaired, does not own or lease a POV and has only the POV that is used for family transportation or the POV is not road worthy for such a trip).

2. Expenses incurred by driving a POV will be limited to the constructive costs of common carrier for trips of 250 miles or more.

3. Expenses for the use of a taxi are limited to transportation to airports, or other carrier terminals, and places of lodging and may not be used to seek permanent residence.

4. Expenses for rental cars may be authorized; however, the rental car cannot be used for personal travel and the approving official may impose limitations on the total mileage reimbursed. Family members are not covered under the government rental car agreement; therefore, they are considered unauthorized drivers/passengers, and will not be insured by the government. The IRS will not reimburse the cost of additional insurance purchased by the employee to cover authorized family members.


6. A one-way house-hunting trip is a trip to seek permanent living quarters after arrival in the local commuting area of the new official station, but before reporting to the office to work at the new assignment. When performing a one-way house-hunting trip, the IRS considers all expenses for travel to the new official station as house-hunting expenses rather than en route travel.

7. Employees and their spouses may choose to complete a one-way house-hunting trip if time does not permit a round trip to seek permanent living quarters. The IRS will not reimburse employees for any house-hunting trip expenses incurred after the employee reports to their new official station and begins performing any work related to their new assignment. However, if the employee’s spouse continues to seek permanent living quarters after the employee reports, the employee may receive reimbursement for the spouse’s expenses in support of house-hunting not to exceed 10 consecutive days.

8. For a lump-sum house-hunting trip, the expenses are reimbursed as follows:



1. If an employee performs a house-hunting trip and their spouse does not, or if their spouse performs a house-hunting trip and the employee does not, multiply the applicable locality per diem rate by 5.00 (see https://www.gsa.gov/perdiem ) [GSA Per Diem Rates](https://www.gsa.gov/perdiem).

2. If an employee and their spouse perform a house-hunting trip, together or separately, multiply the applicable locality per diem rate by 6.25 (refer to [GSA Per Diem Rates](https://www.gsa.gov/perdiem)).


**1.32.12.7** **(03-24-2025)**

### Allowance for Temporary Quarters (TQ) Subsistence Expenses

01. The IRS will reimburse employees for TQSE using the preferred TQSE Lodging Plus reimbursement method. The employees will be paid their actual daily temporary lodging costs and daily Meals and Incidental Expenses (M&IE) allowance not to exceed the single maximum M&IE amount for the locality at the old or new official station wherever temporary lodging will be occupied. The TQSE expenses must be reasonable and if expenses exceed the maximum allowable amount, they will not be reimbursed for more than the maximum allowable amount. TQSE lodging costs must be supported by receipts, meals and incidental expense allowances are not required to be itemized. This section provides IRS guidance to supplement FTR Chapter 302, Relocation Allowances, Part 302-6, [Allowance for Temporary Quarters Subsistence Expenses](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-C/part-302-6).

02. TQ refer to lodging obtained from private or commercial sources to be occupied temporarily (with the intent of moving to permanent quarters at a later date) by the employee and/or members of their immediate family who vacated the residence in which they were residing at the time the transfer was authorized.

03. If authorized, an employee and their immediate family can occupy TQ for a period not to exceed 60 days. The approving official may approve extensions in 30 day increments, for an additional period of up to 60 days, for the occupancy of TQ where there is a compelling reason which is an event that is beyond the employee’s control and is acceptable by the IRS (for example, sudden illness, delayed delivery of household goods, inability to secure a permanent residence), or a demonstrated need for the additional time). The maximum period of time for TQ occupation is 120 days. The TQ may be utilized at the old official station and/or the new official station as long as it does not exceed the maximum period approved.

04. If the employee's immediate family members will be arriving at the new official station after the employee has entered TQ, the TQ period begins when the employee or any members of their immediate family initially enter TQ, and the time must run concurrently. For example, if the employee enters TQ on June 1, and their immediate family enters TQ at another location on July 1. The TQ period started June 1, for the employee and their immediate family. When the employee TQ period expires, it expires for their immediate family members as well. Employees have the option of beginning TQ alone or at the time their family vacates the old residence.

05. If the employee needs to occupy TQ more than 60 days, they must request an extension of TQ. They must contact their CFO relocation coordinator for assistance. All extension requests must be requested and approved by the employee’s business unit approving official.

06. Employees can obtain lodging from family and friends for TQ; however, the IRS will not reimburse employees the applicable per diem rate for lodging when obtaining TQ with family and friends. The IRS reimburses for the additional costs the host incurs in accommodating the employee, such as increased water or electric bills, if the employee is able to substantiate the costs. The IRS will not reimburse the employee for the cost of comparable conventional lodging in the area or a flat rate amount. The employee's host must provide proof of increased costs.

07. The IRS can reimburse an employee for meals when obtaining lodging from family and friends. The IRS will reimburse the employee the lower of the employee’s actual itemized daily meal costs or up to the maximum allowable amount for the employee and the authorized family members who are occupying TQ with the employee. The maximum calculation is based on the standard CONUS rate and is reduced after the first 30 days of the TQ period. Employee’s M&IE is not affected under TQSE-LP when staying with family and friends.

08. The IRS can reimburse an employee the cost of other types of lodging when there are no conventional lodging facilities in the area. For example, in remote areas or when conventional facilities are in short supply, because of an influx of attendees at a special event, such as the World’s Fair or international sporting event. Examples of such lodging include:



    1. Military housing

    2. College dormitories

    3. Similar facilities or rooms that are not offered commercially, but made available to the public by area residents


09. Expenses for permanent quarters or TQ which become permanent are not reimbursable. If the TQ become the employee’s permanent residence, the IRS will consider the following factors to determine if reimbursement of TQ may be allowed:



    1. Duration of lease

    2. Movement of household effects into TQ

    3. Expressions of intent

    4. Attempts to secure a permanent dwelling

    5. Length of time employee occupies TQ


10. Employees cannot claim expenses for a rental vehicle while in TQ. The IRS will not reimburse employees for expenses for local transportation expenses at the new post of duty as these are considered commuting costs and not reimbursable relocation expenses. This includes parking fees. If a vehicle is necessary to perform the duties required by the position, such as traveling from the job site to a temporary duty location on a daily basis, the approving official may authorize car rental expenses under local travel guidelines. Refer to IRM 1.32.1, Official IRS Local Travel Guide.

11. The IRS does not offer a lump sum reimbursement for TQSE. The IRS does not offer reimbursement under the Actual Expense method.

12. Employees cannot claim temporary quarter’s subsistence while they are on personal travel. Employees must include the day(s) they are away from the new official station for personal reasons on Form 4702, Temporary Quarters Subsistence Expenses for Thirty Days (30 Days). If employees sign a month's lease and they can provide a receipt for the applicable period, they are entitled to the full lodging expenses. M&IE for the day(s) away from the new station are not reimbursable.

13. The temporary quarters lodging plus allowance is reduced after both the first 30 days and second 30 days in accordance with the FTR. Employees calculate the maximum reimbursement allowed under the Lodging Plus TQSE method by multiplying the number of days in a period (normally 30) that they incur TQSE by the applicable per diem rate for the employee and each family member based on the following charts, which explain the allowance for both lodging and M&IE. With the TQ-Lodgings Plus method, the allowance is also reduced down on the third 30 days should a third 30 days be needed. If a fourth period is needed, those percentages remain the same as the third 30 days.




    | **Maximum Daily Amount in TQSE for Lodging - Under the Lodging Plus Expense Method** |
    | :-: |
    | For: | Employee and/or employee’s unaccompanied spouse or domestic partner\* may receive: | Employee’s accompanied spouse, domestic partner or a member of employee’s immediate family who is age 12 or older may receive: | A member of employee’s immediate family who is under age 12 may receive: |
    | The first 30 days of temporary quarters. | Up to 100% maximum allowance for the applicable per diem rate. | Up to 50% of the applicable per diem rate. | Up to 40% of the applicable per diem rate. |
    | The second 30 days of temporary quarters. | Up to 75% of the applicable per diem rate. | Up to 45% of the applicable per diem rate. | Up to 35% of the applicable per diem rate. |
    | The third and fourth 30 days of temporary quarters | Up to 55% of the applicable per diem rate. | Up to 40% of the applicable per diem rate. | Up to 30% of the applicable per diem rate. |






    | **Maximum Daily Amount in TQSE for M&IE - Under the Lodging Plus Expense Method** |
    | --- |
    | For: | Employee and/or employee’s unaccompanied spouse or domestic partner\* may receive: | Employee’s accompanied spouse, domestic partner or a member of employee’s immediate family who is age 12 or older may receive: | A member of employee’s immediate family who is under age 12 may receive: |
    | The first 30 days of temporary quarters. | Up to 100% maximum allowance for the applicable per diem rate. | Up to 50% of the applicable per diem rate. | Up to 40% of the applicable per diem rate. |
    | The second 30 days of temporary quarters. | Up to 75% of the applicable per diem rate. | Up to 45% of the applicable per diem rate. | Up to 35% of the applicable per diem rate. |
    | The third and fourth 30 days of temporary quarters | Up to 55% of the applicable per diem rate. | Up to 40% of the applicable per diem rate. | Up to 30% of the applicable per diem rate. |





    ### Note:



    \*Unaccompanied spouse or domestic partner occupies TQ in a location separate from the employee.

14. Temporary lodging taxes are not included in the daily temporary lodging rate and may be documented as a separate TQSE Lodging Plus miscellaneous expense.

15. Laundry or dry-cleaning expenses are included in the M&IE allowance and are not separately reimbursed.

16. Employees will claim the flat rate applicable to the locality for M&IE expenses.

17. Receipts are required for all lodging expenses, utilities and furniture rentals. A copy of the lease (if applicable) is required for reimbursement. Grocery or meal receipts are not needed with the TQ-Lodgings Plus.

18. It is mandatory that employees use the government travel card to pay for TQSE.

19. If the employee is authorized a house-hunting trip, the total number of days authorized for TQSE may be reduced by the number of house-hunting days. The percentage multiplier used for calculating TQSE may not be reduced based on the number of days for a house-hunting trip.

20. If an employee relocates to or occupies temporary lodging in a Presidential Declared Disaster area, TQSE may be authorized at the locality per diem rate, or actual expenses may be authorized on an individual basis. Actual expense authorization must be approved by the CFO, Director of Travel Management for official relocation travel performed on or after the date of the Presidentially Declared Disaster.

21. If employees are departing a POD in the U.S. for an OCONUS foreign post, they may be granted up to 10 days of pre-departure subsistence. The reimbursement will be based upon the U.S. locality rate. (Refer to DSSR, section 242.2). If employees are departing a post in the U.S. for an OCONUS non-foreign post, employee may be granted a TQSE allowance. The reimbursement will be based on the applicable per diem rate for a period of no more than 30 days.

22. Employees are entitled to 60 days temporary quarters upon arrival at the new overseas post of duty.


**1.32.12.8** **(04-14-2020)**

### Transportation and Temporary Storage of Household Goods, and Professional Books, Papers, and Equipment, and Baggage Allowances

1. This section provides IRS guidance to supplement FTR Chapter 302, Relocation Allowances, Part 302-7, [Transportation and Temporary Storage of Household Goods, Professional Books, Papers, and Equipment, and Baggage Allowance](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-D/part-302-7), including:



1. Actual expense method

2. UAB allowance

3. Temporary storage of household goods

4. Household goods traffic management program


2. The authorized methods for transportation, movement and temporary storage of household goods include the actual expense method and do-it-yourself moves. Contact the CFO relocation coordinator for assistance.

3. The maximum weight allowance of household goods that may be shipped and/or stored at government expense is 18,000 pounds net weight. A 2,000-pound allowance is added to the 18,000 pounds net weight allowance to cover packing materials for the shipment. Under no circumstances should a shipment weigh over 20,000 gross pounds (the 18,000 pounds net weight of the household goods plus the 2,000-pound allowance for packing materials). The relocating employee is responsible for reimbursing the government for all costs incurred if the shipment is overweight. Employees are responsible for any additional cost if they have their household goods transported and/or stored and the combined weight exceeds the 18,000 pounds net weight (20,000 pounds including packing materials) limitation.

4. Employees may ship their household goods and professional books, paper, and equipment (PBP&E) from more than one origin point and/or to more than one destination point. The amount that the IRS will reimburse is limited to the cost of transporting the household goods and PBP&E in one lot not to exceed 18,000 pounds net weight from the authorized origin to the authorized destination. Under the actual method, the IRS will pay the mover for the entire invoice. Employees are required to reimburse the IRS for charges that result from shipping more than one lot from any unauthorized origins to any unauthorized destinations. The household goods carrier prepares a cost comparison between the authorized route and the route requested by the employee.

5. Authorized employees may ship their PBP&E in a separate lot, as an administrative expense, if their weight for household goods exceeds 18,000 pounds net weight.

6. Employees must file a claim directly with the carrier that transported the household goods for any loss or damages. They must contact the carrier within 75 days from the date of delivery to notify them of any loss or damage and to request a claim form. The carrier is required to acknowledge all claims within 10 calendar days after receipt of a properly completed form. The negotiation and settlement of the employee's claim is between the employee and the carrier.

7. Federal, state and local laws or carrier regulations may prohibit common carrier shipment of certain articles. These articles frequently include:



1. Hazardous articles such as: explosives, flammable and corrosive materials, and poisons.

2. Items that cannot be taken from the premises without damage to the item or premises.

3. Perishables including frozen foods, items requiring refrigeration or perishable plants unless:




       1\. The item is shipped less than 150 miles.


       2\. The item requires no storage.


       3\. The item requires no preliminary or en route services by the carrier such as watering or other preservative method.


8. The IRBL provides full value protection service at no additional cost to the employee. The basis for the full value protection service is $6 per pound multiplied by the net weight of the shipment. Employees may obtain additional value protection at their own expense from the carrier.


**1.32.12.8.1** **(04-14-2020)**

#### Actual Expense Method

1. The IRS assumes responsibility for awarding the contract and paying the carrier transporting household goods, PBP&E and temporary storage using an IRBL. The CFO relocation coordinator is responsible for making all the necessary arrangements for transporting household goods, PBP&E and temporary storage including, but not limited to:



1. Packing/unpacking

2. Crating/uncrating

3. Pickup/delivery including debris pickup within 30 days of delivery

4. Weighing

5. Line-haul


The CFO relocation coordinator will also issue an IRBL or other shipping documents with all charges billed directly to the IRS.



2. Employees must pay the carrier directly if they sign a separate contract using the actual expense method in addition to the IRBL.

3. Employees are responsible for charges of excess weight for household goods under the actual expense method. The IRS pays the total charges and will bill employees for the cost of transportation and other charges applicable to any excess weight.

4. Employees must reimburse the IRS for charges assessed if and when:



1. The weight of the household goods exceeds the maximum pounds allowed.

2. There are disallowed household goods items and restricted articles transported by the carrier.

3. There are debris pick up charges, if requested, within 30 days of delivery.

4. There are days of storage in excess of the authorized number of days.

5. There are additional valuations of household goods.

6. There are additional charges incurred for shipments originating and/or terminating at locations other than the authorized points of origin and destination.

7. There are storage access fees.


Note: During the initial counseling, the CFO relocation coordinator will discuss potential for additional charges not listed above.



5. There are other charges that the employee may be responsible to pay the carrier when the IRS determines that the employee’s actions produced unnecessary expenses. Employees must discuss any unexpected or unusual circumstances as soon as possible with the carrier and the CFO relocation coordinator to prevent additional expenses. Examples of conditions include:



1. Expedited pickup or delivery services – The carrier must provide service between 8 AM and 5 PM, Monday through Friday, excluding U.S. holidays. However, if employees require service outside of these hours and the employee, the carrier, and the IRS do not agree in writing, the employee will be responsible for the charges.

2. Carrier waiting time caused by employee – The IRS does not reimburse for charges if the employee or their representative are not present at the agreed upon time for the packing, pickup and delivery of household goods. The employee must immediately contact the carrier if they cannot be present at the appointed time to avoid additional fees.


6. The IRS will pay for an extra stop for charges assessed for one origin pickup and one destination delivery.


**1.32.12.8.2** **(04-14-2020)**

#### Unaccompanied Air Baggage (UAB) Allowance

1. Employees and their authorized immediate family members are entitled to UAB allowance if the employee is transferred to an OCONUS location. The UAB allowance is up to 350 pounds each for the employee and authorized family members ages 12 and above. Authorized family members under age 12 receive up to 175 pounds each.

2. The employees should contact the CFO relocation coordinator for assistance when requesting a UAB allowance.


**1.32.12.8.3** **(04-14-2020)**

#### Temporary Storage of Household Goods

1. The employee's initial allowance for temporary storage of household goods within CONUS is 60 days and OCONUS is 90 days.

2. Upon written request, the initial temporary storage period may be extended within CONUS an additional 90 days for a total of 150 days under certain circumstances when approved by the authorizing official.

3. Upon written request, the initial temporary storage period may be extended OCONUS for up to an additional 90 days for a total of 180 days under certain circumstances when approved by the authorizing official.

4. Employees in training at the Federal Law Enforcement Training Center (FLETC) will receive initial temporary storage not to exceed 180 days due to the length of the training class.

5. Employees should contact the CFO relocation coordinator for assistance for requesting an extension to temporary storage under the Basic Relocation Allowances Program. All extensions for temporary storage must be requested and approved by the employee’s business’s unit approving official.


**1.32.12.8.4** **(04-14-2020)**

#### Household Goods Traffic Management Program

1. GSA’s Centralized Household Goods Traffic Management Program (CHAMP) assists relocating federal civilian government employees in transporting household goods from one official duty station to another, both domestically and internationally.

2. The CFO relocation coordinator will assign a mover within the GSA CHAMP program to perform a pre-move survey, pack, load, ship and store the household goods based upon the transferee’s individual needs.


**1.32.12.9** **(04-14-2020)**

### Allowances for Extended Storage of Household Goods

1. This section provides IRS guidance and instructions to supplement FTR Chapter 302, Part 302-8, [Allowances for Extended Storage of Household Goods](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-D/part-302-8) including:



1. Extended storage during assignment to isolated locations within CONUS

2. Extended storage during assignment OCONUS


**1.32.12.9.1** **(04-14-2020)**

#### Extended Storage During Assignment to Isolated Locations Within the Continental United States (CONUS)

1. An official station at an isolated location is a place of permanent duty assignment in CONUS at which the employee has no alternative except to live where the employee is unable to use their household goods.

2. The IRS Commissioner is responsible for designating an official station as isolated to allow extended storage of household goods at the IRS expense. Employees should contact their assigned CFO relocation coordinator for assistance.


**1.32.12.9.2** **(04-14-2020)**

#### Extended Storage During Assignment Outside the Continental United States (OCONUS)

1. The authorized time period for extended storage of household goods is the duration of the assignment.



1. Extended storage may begin 30 days before the tour begins and end 60 days after the tour is completed.

2. Extensions may be authorized by the approving official for subsequent service or tours of duty at the same or other overseas stations if:


       1\. The official station is one where the employee is not authorized to take or use the household goods.


       2\. The extended storage is in the public's interest.


       3\. The estimated cost of extended storage would be less than the cost of round-trip transportation and temporary storage of the household goods to the employee's new official station.

3. When eligibility ceases, storage at the IRS expense may continue until the beginning of the second month after the employee’s tour at the official station OCONUS terminates. To avoid inequity to the employee for additional expenses, the approving official may extend the period for storage at their discretion depending on the employee’s circumstances.


### Note:

Shipment is synonymous with transportation as used in the FTR 302, [Relocation Allowances](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302).

**1.32.12.10** **(04-14-2020)**

### Allowances for Transportation and Emergency Storage of a Privately-Owned Vehicle (POV)

1. This section provides IRS guidance and instructions to supplement FTR Chapter 302, Relocation Allowances, Part 302-9, [Allowances for Transportation and Emergency or Temporary Storage of a Privately Owned Vehicle](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-D/part-302-9), including:



1. Transportation of a POV to a OCONUS post of duty

2. Return transportation of a POV from a OCONUS post of duty

3. Transportation of a POV within CONUS

4. Emergency storage of a POV


2. The purpose of the POV shipment allowance is to:



1. Reduce the government's overall relocation costs by allowing transportation of a POV to the employee's official station, within CONUS or OCONUS, when it is advantageous and cost effective.

2. Improve the overall effectiveness of an employee who is transferred or otherwise reassigned to a post of duty when it is in the government's interest for the employee to have use of a POV at the new official station.


**1.32.12.10.1** **(04-14-2020)**

#### Transportation of Privately-Owned Vehicle (POV) to an Outside the Continental United States (OCONUS) Post of Duty

1. In deciding whether to authorize transportation of a POV to a foreign OCONUS or a non-foreign OCONUS post of duty, the IRS must consider if:



1. The conditions at the employee's new post of duty warrants use of a POV

2. The use of the POV involved is suitable to local conditions at the new post of duty

3. The use of the POV will contribute to the employee's effectiveness on the job

4. The cost of shipping the POV to and from the post of duty will be excessive considering the time the employee has agreed to serve


2. The approving official can authorize transportation of one POV to a foreign OCONUS or a non-foreign OCONUS post of duty in accordance with the rules for the OCONUS location.

3. The approving official cannot authorize the employee a rental car while they wait for the arrival of their POV at the new OCONUS duty location. There are no provisions for this type of expense under the IRS relocation policy.


**1.32.12.10.2** **(04-14-2020)**

#### Return Transportation of a Privately-Owned Vehicle (POV) From an Outside the Continental United States (OCONUS) Post of Duty

1. The IRS will pay transportation costs to return the POV from the OCONUS post of duty, if the employee was authorized to ship a POV to an OCONUS post of duty. If the employee did not ship a POV, then the employee should contact their assigned CFO relocation coordinator for assistance.


**1.32.12.10.3** **(03-24-2025)**

#### Transportation of a Privately-Owned Vehicle (POV) Within the Continental United States (CONUS)

1. Shipment of a POV is a discretionary allowance that requires prior approval. The IRS must consider the following to determine whether to ship a POV within CONUS:



1. The cost of traveling by POV

2. The cost of transporting the POV

3. The cost of travel if the POV is transported

4. The productivity benefit derived from the employee’s accelerated arrival at the new station

5. The POV is in operating order, legally titled and tagged for driving

6. The distance to drive is 600 miles or more


2. Employees may transport up to two POVs within CONUS to the new duty station provided each transportation is advantageous and cost effective to the IRS. Employees must complete Form 13378, IRS Relocation Cost Comparison, and Form 14564, Request for Approval of Basic Plus Relocation Allowance Shipment of POV. All requests for shipment of POV within CONUS must be approved by the Senior Associate CFO for Financial Management. The general rule is for the employee to fly to the new post of duty. If the employee must drive, then the spouse must fly to the new post of duty.


**1.32.12.10.4** **(04-14-2020)**

#### Emergency Storage of a Privately-Owned Vehicle (POV)

1. The IRS will only reimburse for storage when an employee receives a notice to evacuate their immediate family and/or household goods from their OCONUS post of duty. Employees may store their POV at a place determined to be reasonable by the IRS whether or not the POV is already located at, or being transported, to the post of duty.

2. The IRS will reimburse all necessary emergency storage expenses for a POV including, but not limited to:



1. Preparing the POV for storage and for use after storage.

2. Local transportation to and from point of storage.

3. The cost of insurance on the POV, while it is in storage, is the employee's financial responsibility.


3. Employees may ship and store, under emergency circumstances, a passenger automobile, station wagon, light truck or any other similar vehicle that will be used primarily for personal transportation.

4. Employees may not ship or store a trailer, airplane or any vehicle intended for commercial use.

5. Employees may receive an advance of funds for shipment and emergency storage of a POV not to exceed the estimated shipment and storage costs. However, they may not receive an advance if the POV is shipped by a government bill of lading.


**1.32.12.11** **(04-14-2020)**

### Allowances for Transportation of Mobile Homes and Boats Used as a Primary Residence

1. This section provides IRS guidance and instructions to supplement FTR Chapter 302, Relocation Allowances, Part 302-10, [Allowances for Transportation of Mobile Homes and Boats Used as a Primary Residence](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-D/part-302-10), including:

2. In lieu of transportation of household goods at government expense, employees may be entitled to an allowance for transportation of their mobile home or houseboat within CONUS, Alaska and through Canada en route between Alaska and CONUS. Employees must provide a written statement to their assigned CFO relocation coordinator that the mobile home or houseboat is their primary residence.

3. Employees must provide a detailed receipt from the mover after transporting their mobile home or houseboat.


**1.32.12.12** **(04-14-2020)**

### Allowances for Expenses Incurred in Connection with Residence Transactions

1. This section provides IRS guidance and instructions to supplement FTR Chapter 302, Relocation Allowances, Part 302-11, [Allowances for Expenses Incurred in Connection with Residence Transactions](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-E/part-302-11), including:



1. Title requirements

2. Request for reimbursement for residence sale and purchase


2. Employees must be occupying their residence at the time they are notified of the transfer to be reimbursed for expenses incurred for residence transactions.

3. Employees may place their property on the market any time after the Relocation Authorization for Basic Moving Expenses has been approved.

4. The IRS will reimburse employees for expenses related to direct sales not to exceed:



1. 10% of the actual sale price for the employee's residence at the old duty station.

2. 5% of the actual purchase price of the employee's residence at the new duty station.


5. Employees who are marketing their home independently must include the following clause in the listing agreement or as an attachment to the listing agreement. This is to protect employees in the event that they decide to use the Relocation Services Program. (Refer to IRM 1.32.13, Relocation Services Program for additional information on marketing requirements and use of the Relocation Services Program). Failure to include the exclusion clause in the listing agreement could make the employee liable for a non-reimbursable brokerage commission.




| **Exclusion Clause** |
| :-: |
| It is understood and agreed that regardless of whether or not an offer is presented by a ready, willing and able buyer:<br> a) No commission or compensation shall be earned by, or due and payable to broker(s) until sale of the property has been consummated between seller(s) and a buyer(s), the deed delivered to the buyer and the purchase price delivered to the seller (s), and<br> b) The seller(s) reserve the right to sell the property to \_\_\_\_\_\_\_\_\_\_\_or \_\_\_\_\_\_\_\_\_\_\_ \[name of any other party to be covered by this exclusion clause\] \[individually or collectively a "Named Prospective Purchaser" \] at any time. Upon execution of a Named Prospective Purchaser and me (us) of an Agreement of Sale with respect to the property, the listing agreement shall immediately terminate without obligation on my (our) part or on the part of any Named Prospective Purchaser to either pay a commission or to continue this listing.<br> It is understood and agreed that this Listing Addendum (Exclusion Clause) is incorporated by reference in and becomes a part of the Listing Agreement for all purposes. |

6. If the sale of land is in excess of that required for the employee's residence site, the employee will be limited to reimbursement for a pro rata share of expenses covering the acreage of what is reasonably related to the residence site.

7. Employees can only claim reimbursement for one real estate transaction at the old station for either the cost of settling a lease or the sale of a residence.


**1.32.12.12.1** **(04-14-2020)**

#### Title Requirements

1. The title or interest in the property must be in the employee's name and/or that of an immediate family member.

2. If the employee or a member of their immediate family does not hold full title to the property for which they are requesting reimbursement, the employee, will be reimbursed on a pro rata basis to the extent of the employee's equitable title interest in the residence.


**1.32.12.12.2** **(04-14-2020)**

#### Request for Reimbursement for Residence Sale and Purchase

1. To request reimbursement for a residence sale and purchase expenses the employee incurs for residence transaction, the employee sends the claim for reimbursement and documentation of expenses to the approving official for review and approval.

2. Employees must submit the following forms for reimbursement of any real estate transactions:



1. Form 8741, Relocation Voucher

2. Form 4527, Employee Application for Reimbursement of Expense Incurred Upon Sale and/or Purchase of Residence, along with any receipts and documents pertaining to the sale or purchase of real estate

3. Closing Disclosure

4. Receipts for allowable expenses paid outside of closing

5. Sale contract or purchase contract


### Note:

All items a. through e. must be submitted to the \*CFO.BFC.Relocation@irs.gov for processing.

3. Employees should submit their claim(s) within 15 calendar days after the completion of the sale of the former residence and for expenses incurred in the purchase of a new residence.

4. When there is a discrepancy between the employee's claimed amount for reimbursement and what the IRS considers reasonable and the amounts claimed are higher than the normal charge for similar services in the locality, the IRS will consider the costs to be excessive and will disallow them. If there is a discrepancy and a fee schedule is not available, employees will need to obtain information from the title company and at least three different realtors in the locality in which the expenses are incurred. Documentation requested may include, but will not be limited to:



1. The current schedule of closing costs which applies to the area in which the employee is buying or selling

2. Information concerning local custom and practices with respect to charging of closing costs which relate to either their sale or purchase and whether such costs are customarily paid by the seller or purchaser

3. Information on the local terminology used to describe the costs specified in paragraph (b) above


**1.32.12.13** **(04-14-2020)**

### Unexpired Lease

1. Settlement of an employee's unexpired lease is reimbursable, when the employee's unexpired lease (including month-to-month) is for residence quarters at the employee's old official station. The IRS may reimburse for settlement expenses for an unexpired lease, including but not limited to, broker’s fees for obtaining a sublease or charges for advertising if:



1. Applicable laws or the terms of the lease provide for payment of settlement expenses.

2. Such expenses cannot be avoided by sublease or other arrangement.

3. The Employee has not contributed to the expenses by failing to give appropriate lease termination notice promptly after the employee had definite knowledge of the transfer.

4. The broker’s fees or advertising charges are not in excess of those customarily charged for comparable services in that locality.


2. Employees must submit Form 8741, Relocation Voucher, requesting reimbursement for expenses of an unexpired lease settlement with an itemization of all expenses claimed including:



1. Documentary support showing that they paid all lease settlement fees.

2. A copy of either the lease agreement under which a charge for settling an unexpired lease was levied or the legal citation that provides for the lease settlement charge.

3. Documentation to show the date the employee was informed of the transfer and the date the employee informed the lease holder, if timeliness of notification to the lease holder is a factor in the settlement charge.

4. A statement of the transfer date if such date cannot be otherwise verified.


**1.32.12.14** **(04-14-2020)**

### Allowance for Miscellaneous Expenses

1. This section provides IRS guidance and instructions to supplement FTR Chapter 302, Relocation Allowances, Part 302–16, [Allowance for Miscellaneous Expenses](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-F/part-302-16), including:

2. If an employee elects the standard allowance rather than itemizing miscellaneous expenses, the IRS will reimburse the following amount without support or documentation:



1. $650 or the equivalent of one week’s basic gross pay, whichever is the lesser of the amount, for employees relocating without an immediate family.

2. $1,300 or the equivalent of two week’s basic gross pay, whichever is the lesser of the amount, for employees relocating with an immediate family member.


3. When an employee itemizes miscellaneous expenses, instead of requesting reimbursement of the standard allowance, all receipts are required justifying the employee expenses starting with the first dollar amount incurred. The maximum employees will be reimbursed, regardless of their actual miscellaneous expenses, is one week’s basic gross pay when moving without an immediate family member or two week’s basic gross pay when moving with an immediate family member. Employees should refer to FTR Chapter 302, Relocation Allowances, Part 16.202, [Are There Any Restrictions to the Types of Costs We May Cover?](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-F/part-302-16) and Part 16.203, [What Are Examples of Types of Costs Not Covered by the Miscellaneous Expense Allowance (MEA)?](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302/subchapter-F/part-302-16), for restrictions and examples of costs not covered by the miscellaneous expense allowance.



### Note:



The amount cannot exceed the maximum rate of a grade GS-13 biweekly pay for the locality area of the new official station.

4. Employees may claim reimbursement for the following miscellaneous expenses:



1. Fees for new driver’s licenses

2. Auto registration fees, if the POV is taken to the new duty station

3. Installation fees for cable and telephone

4. Refitting carpeting and draperies for new residence

5. Expenses associated with shipping a household pet (dog or cat), limited to transportation and handling costs required to meet the rules of air carriers.

6. Professional license fees required by the new official station state that are directly related to the employee's or a family member’s occupation, such as fees required to take the bar exam or teaching certification.

7. Third-party services related to the shipment of the employee household goods, such as washer/dryer disconnect and reconnect of gas appliances that are determined to be necessary and incident to the move.


**1.32.12.15** **(06-07-2022)**

### Voucher Submission

1. Employees must submit Form 8741, Relocation Voucher, within 15 calendar days after the completion of each relocation activity, such as a house-hunting trip, real estate closing, or en route travel. When filing the final voucher for a category of expense, employees must put an "F" in the box immediately preceding the expense being claimed in Block 15.

2. Employees must include supporting documentation with Form 8741, Relocation Voucher. Depending upon the type of expense employees are claiming, documentation includes, but is not limited to, the following:




| **Required Documentation** | **House- hunting Trip** | **Travel to New Official Station** | **Household goods Transportation** | **Household goods Storage** | **POV Transportation** | _Temporary Quarters_ |
| --- | --- | --- | --- | --- | --- | --- |
| Original lodging receipt | X | X |  |  |  | X |
| Itinerary invoice for common carrier transportation reflecting method of payment | X | X |  |  |  |  |
| Rental car receipt | X | X |  |  |  |  |
| Telephone call receipts | X | X |  |  |  |  |
| Receipts for expenses over $75 | X | X | X | X | X | X |
| Carrier’s contract, invoice and receipt |  |  | X |  | X |  |
| Rental truck/towing equipment contract and receipt |  |  | X |  | X |  |
| Weight tickets |  |  | X | X |  |  |
| Receipts for labor |  |  | X | X |  |  |
| Gasoline receipts regardless of amount |  |  | X |  | X |  |
| Rental contract and receipts |  |  |  | X |  |  |





### Note:



Vouchers submitted with missing receipts may be elevated to the Travel Policy and Review office for review and approval.

3. When employees undertake a TDY assignment en route to a new official location, their relocation travel to the new post of duty stops upon arrival at the TDY location. Employees must process their TDY expenses in the electronic travel system.



### Note:



Refer to IRM 1.32.11, IRS City-to-City Travel Guide, for information and entitlements while on temporary duty travel.

4. Employees must submit each relocation voucher to the approving official for approval. After approval, the employee or the gaining office forwards the voucher to the \*CFO BFC Relocation mailbox for processing.


**1.32.12.16** **(04-14-2020)**

### Relocation Income Tax Allowance (RITA)

01. This section provides IRS guidance and instructions to supplement FTR Chapter 302, Relocation Allowances, Part 302-17, Taxes on Relocation Expenses, including:

02. The relocation income tax allowance (RITA), reimburses an employee for federal, state and local income taxes incurred on taxable relocation travel reimbursements reportable on Form W-2, Wage and Tax Statement. The RITA does not reimburse employees for their Medicare or Social Security taxes on relocation travel expense reimbursements. The RITA is paid in two parts:



    1. Through the payment of a withholding tax allowance (WTA) at the time vouchers are paid.

    2. Through the payment of the final RITA in the following calendar year.


03. The CFO relocation technicians will calculate the withholding taxes on relocation vouchers to determine the amount that is subject to income tax after reviewing the voucher(s) and determining the amount of reimbursement due to the employee.

04. The tax withholdings and reimbursements of moving expenses have an effect on the employee’s final tax liability. The taxable reimbursements are considered income to the employee and the additional income may place the employee into a higher tax bracket. Withheld taxes may not be sufficient to cover the additional tax liability for the employee as a result of the higher tax bracket. The employee is responsible for the additional tax liability but may be reimbursed through the RITA process.

05. The RITA reimburses the employee for the federal and state tax withholdings on taxable relocation travel expenses. The WTA also reimburses the employee the federal tax withholdings on the WTA itself, since the WTA is also considered income to the employee. The technician calculates and applies the WTA automatically, requiring no change to the voucher filing procedures. When the technician processes a voucher and the reimbursement is subject to federal tax, the technician applies an estimated partial payment of the RITA as an offset to the federal tax withholdings. The technician calculates the withholding taxes on relocation vouchers to determine the amount that is subject to income tax after reviewing the voucher(s) and determining the amount of reimbursement due to the employee.

06. The technician sends the employee a statement of tax withholdings as each voucher is processed showing the voucher amount approved for payment, the WTA amount, and the federal, state and Federal Insurance Contributions Act (FICA) withholdings.

07. The technician is responsible for filing the appropriate withholding taxes for moving expenses for state, territorial, or District of Columbia returns and for transmitting the tax withholdings to the IRS.

08. The technician prepares a Form W-2, Wage and Tax Statement, for each employee to whom payments were made for moving expenses no later than January 31 of each year.

09. Employees must file the RITA claim no later than June 30 of the year following the year when the tax reimbursements were paid unless the employee has an extension of their tax return, then the RITA claim is due 30 days after the approved extension. When an employee does not file a claim, the IRS assumes that the RITA amount is zero. Consequently, employees would be required to reimburse the IRS for the amount of the WTA(s) previously paid to them for the related move.

10. The IRS forwards the relocation Form W-2, Wage and Tax Statement, to each eligible employee by January 31. The technician emails the RITA package which includes the instructions along with the necessary forms for filing a RITA claim. IRS sends the W-2 reports and authorization reports by U.S. mail generated through the relocation system. The employee must complete:



    1. Form 8741, Relocation Voucher. The amount claimed block on the Form 8741, Relocation Voucher, will be left blank as the RITA is calculated by the technician. The back of the form will be left blank except for the following statement in the Description column: "RITA claim for the Year 20XX. Form 8445, Statement of Income and Tax Filing Status, and supporting documents are attached."

    2. Form 8445, Statement of Income and Tax Filing Status, does not require the approving official’s signature.


The technician calculates the RITA amount based on the information and supporting documentation provided by the employee. Employees must submit the following documents to the relocation unit:


    1. Form 8445, Statement of Income and Tax Filing Status

    2. Form 8741, Relocation Voucher


11. A notice is sent to any employee who receives taxable reimbursements for more than one state prior to the mailing of their relocation Form W-2, Wage and Tax Statement. The income is reported to the payroll state as identified by the employee during the year that the expenses were reimbursed.

12. The WTA could exceed the RITA where the marginal tax rate is less than the supplemental wage withholding. The technician will establish a receivable for the excess WTA, as the IRS overpaid federal taxes on the employee's behalf. However, the result depends on the parameters of the established tax brackets. Employees must notify their technician if they have any change of their tax status such as an amended tax return or tax audit that would change the information provided for calculation of the RITA.


**1.32.12.17** **(06-07-2022)**

### Relocation Debts

1. A relocation debt may be established when:



1. The applicable relocation activity for which an advance was issued is completed and the remaining balance of the advance exceeds the expenses claimed on an approved relocation voucher, or

2. The relocation activity is cancelled, or

3. A relocation advance becomes 90 days old.

4. A taxable payment to a moving company or a relocation services company is made on the employee’s behalf and withholding taxes must be collected.

5. An overweight household goods shipment and overweight household goods storage payment has been paid to a moving company and must be collected.

6. An employee’s request for relief of the service agreement for failing to affect the transfer is denied and must be collected.

7. A RITA voucher reconciliation of the withholding tax allowance paid and the employee’s income tax bracket results in a negative payment to the employee.


2. If a debt is established in connection with an employee’s relocation, the debt is subject to the debt collection procedures in IRM 1.36.4, Administrative Accounting and Financial Reports, Administrative (Non-Tax) Debt Management.

3. If the employee needs to repay a debt related to their relocation, the employee must submit payment for the advance payable to the IRS to:


    Beckley Finance Center


    ATTN: Debt Collection Unit


    P.O. Box 9002


    Beckley, WV 25802-9002

4. The employee must include a Debt Collection Repayment memo with their payment. The form can be found at the CFO website, select Travel Guidance and then Travel Policy and Procedures.

5. The employee has the right to dispute a debt or request a waiver if they have documentation or additional information to support their request. See IRM 1.36.4, Administrative Accounting and Financial Reports, Administrative (Non-Tax) Debt Management for details surrounding the debt waiver process and the employee’s appeal rights.


**1.32.12.18** **(04-14-2020)**

### Forms

1. The following forms apply to this program:




| **NUMBER** | **TITLE** |
| --- | :-: |
| Form 9803 | Transportation Agreement (Posts of Duty in Non-Foreign OCONUS) |
| Form 1099-S | Proceeds From Real Estate Transactions |
| Form 10902 | Overseas Transportation-Service Agreement |
| Form 13378 | IRS Relocation Travel-Cost Comparison Worksheet Driving vs. Shipping a Privately-Owned Vehicle (POV) |
| Form 14564 | Request for Approval for Basic Plus Relocation Allowance Shipment of Privately-Owned Vehicle (POV) |
| Form 14565 | Property Management Reimbursement Request |
| moveLINQ | Relocation Authorization for Basic Moving Expenses |
| moveLINQ | Relocation Authorization Amendment for Basic Plus Moving Expenses |
| Form 4253-C | Relocation Travel Advance Request |
| Form 4282 | Twelve-Month-Service Agreement (50 United States and the District of Columbia) |
| Form 4527 | Employee Application for Reimbursement of Expense Incurred upon Sale and/or Purchase of Residence upon Change of Official Station |
| Form 4702 | Temporary Quarters Subsistence Expenses For Thirty (30) Days |
| Form 8445 | Statement of Income and Tax Filing Status |
| Form 8741 | Relocation Voucher |
| Form W-2 | Wage and Tax Statement |


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-012#addtoany "Show all")

A2A