---
url: "https://www.irs.gov/irm/part1/irm_01-032-004"
title: "1.32.4 Government Travel Card Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-004#main-content)

- 1.32.4  [Government Travel Card Program](https://www.irs.gov/irm/part1/irm_01-032-004#id1)
  - 1.32.4.1  [Program Scope and Objective](https://www.irs.gov/irm/part1/irm_01-032-004#id2)
    - 1.32.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-004#id3)
    - 1.32.4.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-032-004#id4)
    - 1.32.4.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-004#id5)
      - 1.32.4.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-032-004#id7)
      - 1.32.4.1.3.2  [Credit Card Services Office](https://www.irs.gov/irm/part1/irm_01-032-004#id8)
      - 1.32.4.1.3.3  [Managers](https://www.irs.gov/irm/part1/irm_01-032-004#id9)
      - 1.32.4.1.3.4  [Travel Cardholders](https://www.irs.gov/irm/part1/irm_01-032-004#id10)
      - 1.32.4.1.3.5  [Authorized Centrally Billed Account Users](https://www.irs.gov/irm/part1/irm_01-032-004#id11)
      - 1.32.4.1.3.6  [Travel Management Office](https://www.irs.gov/irm/part1/irm_01-032-004#id12)
    - 1.32.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-004#id13)
    - 1.32.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-004#id14)
    - 1.32.4.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-004#id15)
    - 1.32.4.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-004#id16)
    - 1.32.4.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-004#id17)
  - 1.32.4.2  [Individually Billed Account Travel Card Program](https://www.irs.gov/irm/part1/irm_01-032-004#id18)
    - 1.32.4.2.1  [Mandatory Use of Individually Billed Account](https://www.irs.gov/irm/part1/irm_01-032-004#id19)
      - 1.32.4.2.1.1  [Exemptions to Mandatory Use of Travel Card Policy](https://www.irs.gov/irm/part1/irm_01-032-004#id20)
        - 1.32.4.2.1.1.1  [Exemption for Mandatory Use for International Travel](https://www.irs.gov/irm/part1/irm_01-032-004#id22)
        - 1.32.4.2.1.1.2  [Payment Sources for Travelers with Exemptions](https://www.irs.gov/irm/part1/irm_01-032-004#id23)
    - 1.32.4.2.2  [Use of the Individually Billed Account](https://www.irs.gov/irm/part1/irm_01-032-004#id24)
      - 1.32.4.2.2.1  [Authorized/Unauthorized Uses](https://www.irs.gov/irm/part1/irm_01-032-004#id26)
      - 1.32.4.2.2.2  [National Treasury Employees Union Use of the Travel Card](https://www.irs.gov/irm/part1/irm_01-032-004#id27)
      - 1.32.4.2.2.3  [Inappropriate Use of the Travel Card](https://www.irs.gov/irm/part1/irm_01-032-004#id28)
    - 1.32.4.2.3  [Card Controls](https://www.irs.gov/irm/part1/irm_01-032-004#id29)
      - 1.32.4.2.3.1  [Card Limits](https://www.irs.gov/irm/part1/irm_01-032-004#id31)
      - 1.32.4.2.3.2  [Relocation Employees (Special Privileges)](https://www.irs.gov/irm/part1/irm_01-032-004#id32)
      - 1.32.4.2.3.3  [Merchant Category Codes and Templates](https://www.irs.gov/irm/part1/irm_01-032-004#id33)
    - 1.32.4.2.4  [Cash from Automated Teller Machines Access](https://www.irs.gov/irm/part1/irm_01-032-004#id34)
    - 1.32.4.2.5  [Record Retention Period for Travel Card Documentation](https://www.irs.gov/irm/part1/irm_01-032-004#id35)
    - 1.32.4.2.6  [Training and Application Process](https://www.irs.gov/irm/part1/irm_01-032-004#id36)
      - 1.32.4.2.6.1  [Electronic Credit Review](https://www.irs.gov/irm/part1/irm_01-032-004#id37)
      - 1.32.4.2.6.2  [Activating the Travel Card](https://www.irs.gov/irm/part1/irm_01-032-004#id38)
      - 1.32.4.2.6.3  [Ordering a Replacement Card](https://www.irs.gov/irm/part1/irm_01-032-004#id39)
      - 1.32.4.2.6.4  [Card Renewal Process](https://www.irs.gov/irm/part1/irm_01-032-004#id40)
        - 1.32.4.2.6.4.1  [Travel Card Refresher Training](https://www.irs.gov/irm/part1/irm_01-032-004#id42)
    - 1.32.4.2.7  [Monthly Statements](https://www.irs.gov/irm/part1/irm_01-032-004#id43)
      - 1.32.4.2.7.1  [Statement Explanation](https://www.irs.gov/irm/part1/irm_01-032-004#id44)
      - 1.32.4.2.7.2  [Dispute Process](https://www.irs.gov/irm/part1/irm_01-032-004#id45)
      - 1.32.4.2.7.3  [Trip Cancellation](https://www.irs.gov/irm/part1/irm_01-032-004#id46)
      - 1.32.4.2.7.4  [Payment Terms](https://www.irs.gov/irm/part1/irm_01-032-004#id47)
        - 1.32.4.2.7.4.1  [Payment Methods](https://www.irs.gov/irm/part1/irm_01-032-004#id49)
        - 1.32.4.2.7.4.2  [Making/Expediting Payment](https://www.irs.gov/irm/part1/irm_01-032-004#id50)
      - 1.32.4.2.7.5  [Travel Vouchers: Relationship to Travel Cards](https://www.irs.gov/irm/part1/irm_01-032-004#id51)
    - 1.32.4.2.8  [Delinquent Accounts](https://www.irs.gov/irm/part1/irm_01-032-004#id52)
      - 1.32.4.2.8.1  [Past Due Accounts](https://www.irs.gov/irm/part1/irm_01-032-004#id54)
      - 1.32.4.2.8.2  [Suspension and Reactivation](https://www.irs.gov/irm/part1/irm_01-032-004#id55)
      - 1.32.4.2.8.3  [Multiple Suspensions](https://www.irs.gov/irm/part1/irm_01-032-004#id56)
      - 1.32.4.2.8.4  [Payments Returned for Non-Sufficient Funds](https://www.irs.gov/irm/part1/irm_01-032-004#id57)
      - 1.32.4.2.8.5  [Cancellation](https://www.irs.gov/irm/part1/irm_01-032-004#id58)
      - 1.32.4.2.8.6  [Cancelled Card and Need to Travel](https://www.irs.gov/irm/part1/irm_01-032-004#id59)
      - 1.32.4.2.8.7  [Salary Offset for Undisputed Travel Card Debt](https://www.irs.gov/irm/part1/irm_01-032-004#id60)
      - 1.32.4.2.8.8  [Reinstatement Process](https://www.irs.gov/irm/part1/irm_01-032-004#id61)
    - 1.32.4.2.9  [Travel Card Account Changes](https://www.irs.gov/irm/part1/irm_01-032-004#id62)
    - 1.32.4.2.10  [Travel Card Problems](https://www.irs.gov/irm/part1/irm_01-032-004#id63)
  - 1.32.4.3  [Centrally Billed Account Program](https://www.irs.gov/irm/part1/irm_01-032-004#id64)
    - 1.32.4.3.1  [Centrally Billed Account Guidelines](https://www.irs.gov/irm/part1/irm_01-032-004#id65)
      - 1.32.4.3.1.1  [Authorized Uses of the Centrally Billed Account](https://www.irs.gov/irm/part1/irm_01-032-004#id67)
      - 1.32.4.3.1.2  [Unauthorized Uses of the Centrally Billed Account](https://www.irs.gov/irm/part1/irm_01-032-004#id68)
      - 1.32.4.3.1.3  [Centrally Billed Account Ticket Authorization Process](https://www.irs.gov/irm/part1/irm_01-032-004#id69)
      - 1.32.4.3.1.4  [Travel Voucher Considerations](https://www.irs.gov/irm/part1/irm_01-032-004#id70)
      - 1.32.4.3.1.5  [Unused Tickets](https://www.irs.gov/irm/part1/irm_01-032-004#id71)
      - 1.32.4.3.1.6  [Ticket Cancellation](https://www.irs.gov/irm/part1/irm_01-032-004#id72)
      - 1.32.4.3.1.7  [Special Travel Considerations](https://www.irs.gov/irm/part1/irm_01-032-004#id73)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 4. Government Travel Card Program

* * *

## 1.32.4 Government Travel Card Program

#### Manual Transmittal

February 13, 2026

#### Purpose

(1) This transmits revised IRM 1.32.4, Servicewide Travel Policies and Procedures, Government Travel Card Program.

#### Material Changes

(1) IRM 1.32.4.1.2(2), Authority, added new bullet, Title 41, CFR Chapters 300.

(2) IRM 1.32.4.1.2(3), Authority, added new bullet, Treasury Directive 74-12, Use of Government Contractor-Issued Travel Charge Cards.

(3) IRM 1.32.4.1.3.2(2)(n), Credit Card Services Office, added new bullet, “Developing and maintaining travel card training and refresher training.”

(4) IRM 1.32.4.1.3.2(2)(o), Credit Card Services Office, added new bullet, “Reviewing and approving travel card applications on the contract bank’s electronic access system.”

(5) IRM 1.32.4.1.6(1)(a), Terms/Definitions, changed term from Automatic teller machine to Automated teller machine.

(6) IRM 1.32.4.1.7(1), Acronyms, changed acronym description from Automatic Teller Machine to Automated Teller Machine.

(7) IRM 1.32.4.2.1.1(1), Exemptions to Mandatory Use of Travel Card Policy, updated sentence to include the director, Travel Management Office exemption authority.

(8) IRM 1.32.4.2.1.1(2), Exemptions to Mandatory Use of Travel Card Policy, revised sentence for clarity.

(9) IRM 1.32.4.2.1.1(3), Exemptions to Mandatory Use of Travel Card Policy, revised sentence, “If the manager determines the requirements are met, the manager will forward the approved request via email to Credit Card Services mailbox at \*IRS CCS.”

(10) IRM 1.32.4.2.1.1(4)(g), Exemptions to Mandatory Use of Travel Card Policy, deleted bullet, “Employees who have relocated and are staying in temporary quarters.”

(11) IRM 1.32.4.2.1.1.1(1), Exemption for Mandatory Use for International Travel, updated sentence to include the Travel Management Office exemption authority; added Criminal Investigation to employees who arrange travel through their respective travel office; updated International Travel link for Chief Counsel and Criminal Investigation employees.

(12) IRM 1.32.4.2.1.1.1(2), Exemption for Mandatory Use for International Travel, updated link from CFO Travel Resources to IRS Source website.

(13) IRM 1.32.4.2.1.1.2(1)(b), Payment Sources for Travelers with Exemptions, updated bullet to include link to procedures for requesting approval of use of personal funds for over $100 round-trip transportation fare.

(14) IRM 1.32.4.2.2.1(1), Authorized/Unauthorized Uses, revised text, “The travel card can only be used for allowable travel and travel-related expenses while in official IRS travel status.”

(15) IRM 1.32.4.2.2.1(1) Table, Authorized/Unauthorized Uses, expense type Auto Rental changed to Rental Car; Incidental expenses changed to Laundry or dry cleaning; Long distance calling removed; added Personal items expense type; and throughout the table minor edits were made for clarity.

(16) IRM 1.32.4.2.2.1(3), Authorized/Unauthorized Uses, revised text, “Travel cards may be used for Meals and Incidental Expenses (M&IE) and must be used for meals over $15.”

(17) IRM 1.32.4.2.3.1(1), Card Limits, updated text and added a sentence, “For most travel cardholders, the card limit is $1 until travel is approved. The card limit is increased to cover expected expenses for the travel period and then reduced back to $1.”

(18) IRM 1.32.4.2.3.2(1), Relocation Employees (Special Privileges), updated text, “Use of the travel card for temporary quarters and temporary subsistence is mandatory.”

(19) IRM 1.32.4.2.4(1), Cash from Automated Teller Machine Access, removed the last sentence and replaced with text, “The Federal Travel Regulation requires the travel card be used for all official travel related expenses, unless exempted as described in IRM 1.32.4.2.1.1.”

(20) IRM 1.32.4.2.6(1), Training and Application Process, updated last sentence with text, “All travel card applications must be in the applicant’s name as shown in IRS official personnel records or in approved pseudonym names and must be electronically submitted by the applicant through the government credit card contractor’s electronic access system.”

(21) IRM 1.32.4.2.7.3(2), Trip Cancellation, updated text, “Car and/or hotel only reservations booked in the ETS are valid, even if the authorization has not been signed or approved. The CGE reservation fee is incurred when the authorization is approved or on the first day of travel.”

(22) IRM 1.32.4.2.7.4.1(1), Payment Methods, updated text, “The travel cardholders may pay their accounts through ETS voucher split disbursement, through the government credit card contractor’s electronic access system, by mail, or by telephone.”

(23) IRM 1.32.4.2.8.2(3), Suspension and Reactivation, removed bullet, “At the time of suspension, any special privileges assigned to the account, such as an increased card limit, will be revoked. Special privileges will not be reinstated when the payment is made.”

(24) IRM 1.32.4.2.8.4(3), Payments Returned for Non-Sufficient Funds, deleted the last sentence, “The government credit card contractor will not reinstate and account that has a history of payments returned for non-sufficient funds.”

(25) IRM 1.32.4.2.8.5(2), Cancellation, deleted bullet, “If an account remains unpaid for 151 days from the closing date of the statement period on the statement of account, the government credit card contractor may report the delinquency to the credit bureaus and it will appear on the travel cardholder’s personal credit history. More information is available on the IRS Source website.”

(26) IRM 1.32.4.2.8.8(1), Reinstatement Process, deleted second sentence, “A travel card account that was cancelled due to non-sufficient funds or multiple suspensions will not be considered for reinstatement.”

(27) IRM 1.32.4.2.8.8(3), Reinstatement Process, revised the second sentence and added a third sentence, “If the account has been paid in full, Credit Card Services will notify the employee to submit a new on-line travel card application and must consent to the credit check. If the employee does not agree to consent to the credit check, the travel card cannot be reinstated.”

(28) IRM 1.32.4.3.1(2), Centrally Billed Account Guidelines, revised the sentence and bullets, “Travelers who have a travel card cannot use the CBA, unless they meet one of the following exceptions: a) Have a suspended account or an account closed for misuse; b) Have an account closed as being lost, stolen, or fraudulent and a new card hasn’t been received; c) Incur foreign travel transportation costs.”

(29) IRM 1.32.4.3.1.1(1)(c), Authorized Uses of the Centrally Billed Account, revised the bullet text, “Travel Management Center (TMC) fees associated with transportation, lodging, and rental car ticketing.”

(30) IRM 1.32.4.3.1.4(1)(b), Travel Voucher Considerations, changed Standard Form 1012, Travel Voucher for reimbursement, to Standard Form 15342, Travel Voucher.

(31) IRM 1.32.4.3.1.7(5), Special Travel Considerations, revised the second sentence text, “The designated IRS employee is responsible for making travel arrangement.”

(32) IRM 1.32.4.3.1.7(9), Special Travel Considerations, added new bullet, “Counsel employees whose invitational travel is paid for by a 501(c)(3), under the relevant statutory authority, are exempt from the mandatory travel card use requirements.”

(33) Minor editorial changes made throughout the IRM for clarity and link updates.

#### Effect on Other Documents

IRM 1.32.4, dated October 19, 2023, is superseded. This IRM incorporates the applicable information from Interim Guidance Memorandum CFO-01-1125-0002, Interim Guidance for Government Travel and Purchase Card Programs, dated November 24, 2025.

#### Audience

All business units

#### Effective Date

(02-13-2026)

Anthony S. Chavez

Chief Financial Officer

**1.32.4.1** **(10-19-2023)**

### Program Scope and Objective

1. **Purpose**: This IRM provides information regarding the Government Travel Card Program, including the Individually Billed Account (IBA) and Centrally Billed Account (CBA) programs.

2. **Audience**: All business units

3. **Policy Owner**: The CFO is responsible for travel card program policy, and related audits.

4. **Program Owner**: Credit Card Services is responsible for travel card-related administration, procedures and audits.

5. **Primary Stakeholders**: The CFO, Credit Card Services, travel cardholders, CBA users and managers.

6. **Program Goals**: Provide an effective travel card program that enables IRS employees to conduct official government travel to carry out their tax administration duties and ensure effective internal controls as outlined in OMB Circular A-123, Appendix B: Improving the Management of Government Charge Card Programs. The mandatory use of the travel card enables the IRS to obtain rebates offered by the credit card contractor.


**1.32.4.1.1** **(10-19-2023)**

#### Background

1. This IRM provides information for the Government Travel Card Program including the IBA and the CBA programs. It applies to IRS employees who perform official government travel and supervisory and administrative personnel who direct or review and approve, official travel or reimbursement of expenses.


**1.32.4.1.2** **(02-13-2026)**

#### Authority

1. The Travel and Transportation Reform Act of 1998 (Pub. L. No. 105–264)

2. Title 41, CFR Chapters 300-304, [Federal Travel Regulation](https://www.ecfr.gov/current/title-41/subtitle-F)

3. Treasury Directive 74-12, Use of Government Contractor-Issued Travel Charge Cards


**1.32.4.1.3** **(07-30-2021)**

#### Responsibilities

1. The CFO, Deputy CFO, and Credit Card Services share joint responsibility for the Government Travel Card Program.

2. This section provides responsibilities for the following:



1. CFO and Deputy CFO

2. Credit Card Services office

3. Managers and approving officials

4. Travel cardholders

5. Authorized CBA users

6. Travel Management office


**1.32.4.1.3.1** **(07-05-2019)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for Government Travel Card Program policy.


**1.32.4.1.3.2** **(02-13-2026)**

##### Credit Card Services Office

1. The Credit Card Services office is responsible for administration, procedures and oversight of the government travel card program.

2. Responsibilities for IBA and CBA accounts include:



01. Providing guidance and direction to travel cardholders and managers.

02. Assisting travel cardholders with travel card account maintenance changes.

03. Reviewing travel authorizations for appropriate information and approvals.

04. Performing reviews and monitoring travel card program activity.

05. Initiating appropriate action to notify Labor/Employee Relations and Negotiations of delinquent accounts and inappropriate use.

06. Safeguarding the CBA cardholder account numbers.

07. Authorizing the TMC to issue tickets that are charged to the CBA.

08. Reviewing, reconciling and certifying monthly CBA statements of account for payment and sending them to the CFO, Travel Management, Travel Operations office.

09. Ensuring payments to the government credit card contractor are properly and timely post to the CBA account(s).

10. Initiating and completing the dispute resolution process when unauthorized or erroneous/duplicate charges appear on the CBA statements of account.

11. Reviewing the activity on the CBA to ensure: 1) travelers are not seeking reimbursement for CBA charges; 2) erroneous/duplicate charges are identified and resolved; 3) all charges are for travelers authorized to use the CBA for official government travel.

12. Maintaining statistical and narrative information related to the travel card program.

13. Providing CBA expenditure information to the business units.

14. Developing and maintaining travel card training and refresher training.

15. Reviewing and approving travel card applications on the contract bank’s electronic access system.


**1.32.4.1.3.3** **(07-30-2021)**

##### Managers

1. Managers are responsible for:



1. Ensuring all employees obtain and use the government travel card for all official travel, except where specifically exempted.

2. Reviewing travel documents to ensure travel card expense claims are appropriate and business related.

3. Approving requests for travel card account maintenance changes such as card limits and cancellations.

4. Ensuring their employees are aware of the government travel card requirements.

5. Consulting with Labor/Employee Relations and Negotiations before meeting with a travel cardholder who is delinquent in paying their government travel card bill or who may have inappropriately used the travel card.

6. Concurring with or rejecting employee requests to use the CBA.

7. Ensuring that travel authorizations have the correct funding codes when the CBA is used to pay for the transportation.

8. Approving or disapproving employee travel authorization requests.

9. Ensuring that airfare/train and reservation fees charged to the CBA have the form of payment shown as CBA (not personal or Government Travel Card) on the employee’s travel voucher.


**1.32.4.1.3.4** **(07-30-2021)**

##### Travel Cardholders

1. Travel cardholders are responsible for:



1. Becoming familiar with the current IRS IRM 1.32.1, IRS Local Travel Guide and IRM 1.32.11, IRS City- to-City Travel Guide.

2. Using the government travel card only for travel-related expenses while performing official government travel.

3. Promptly filing travel vouchers.

4. Paying all charges and fees associated with the account timely.

5. Disputing any incorrect or unauthorized charges that may appear on the monthly statement of account timely.

6. Safeguarding the government travel card and account number from unauthorized use.

7. Complying with the terms and conditions of the Cardholder Account Agreement.


**1.32.4.1.3.5** **(07-05-2019)**

##### Authorized Centrally Billed Account Users

1. Authorized CBA users are responsible for:



1. Contacting the TMC to make a reservation.

2. Informing the TMC that the CBA will be used to purchase the common-carrier transportation tickets.

3. Obtaining the cost of the transportation ticket, the cost of the Concur Government Edition (CGE) fee and the reservation locator code from the TMC.

4. Notifying the TMC and Credit Card Services if an authorized trip is cancelled.

5. Identifying "CBA" as the method of payment for transportation costs charged to the CBA when filing travel vouchers.


**1.32.4.1.3.6** **(07-05-2019)**

##### Travel Management Office

1. The Travel Management office is responsible for IRS policies governing the travel card program.


**1.32.4.1.4** **(07-05-2019)**

#### Program Management and Review

1. **Program Reports**: Credit Card Services uses reports obtained from the credit card contractor’s electronic reporting system and from the Integrated Financial System (IFS) to monitor accounts and review transactions.

2. **Program Effectiveness**: Credit Card Services measures the effectiveness of travel card program oversight by performing continuous reviews of account data and monthly and quarterly reviews of travel card transactions to measure compliance and mitigate the risk of fraud and abuse.


**1.32.4.1.5** **(07-05-2019)**

#### Program Controls

1. The following chart describes the internal controls in place for using the government travel card:




| **Controls** | **Control Descriptions** |
| :-- | :-- |
| Travel Advances | Standard travel cardholders are not authorized travel advances from Electronic Travel System (ETS). They may use the ATM feature on their standard travel card for official IRS travel expenses that cannot be charged using the travel card. Restricted travel cardholders are authorized travel advances through ETS up to 40% of all reimbursable expenses, except transportation, since they do not have ATM privileges. |
| Mandatory Use of the Government Travel Card | All employees are required to obtain and use the travel card for required travel expenses unless they qualify for an exemption as outlined in IRM 1.32.4.2.1.1, Exemptions to Mandatory Use of Travel Card Policy. |
| Account Controls | Card use is restricted for any non-travel merchant category codes and high-risk merchant codes. Spending limits are restricted during periods of inactivity or misuse. Spending limits are reduced on travel cards during periods of non-travel status. Travel cards are canceled when a traveler retires or leaves the IRS. |
| Card Limits | Card limits are used to strengthen internal controls by establishing the appropriate amount that travel cardholders can spend in a billing cycle to accomplish their program responsibilities. |
| Training | Training is required to obtain a card and refresher training is required every two years. |
| Split Disbursement | Process of dividing a travel voucher reimbursement between the credit card contractor and the traveler. The balance owed to each is sent directly to the applicable party. |
| Salary Offset | The collection of an undisputed, delinquent travel card amount via direct deduction from a traveler’s payroll account. |


**1.32.4.1.6** **(02-13-2026)**

#### Terms/Definitions

1. The following terms and definitions apply to this program.



01. **Automated teller machine (ATM)** \- The contractor provides this service allowing cash withdrawals from participating ATMs. The cash withdrawal and associated fees are charged to the standard travel card account. Cash from ATMs is only authorized for expenses that cannot be charged to the travel card while in official IRS travel status.

02. **Billing cycle** \- The period of time commencing on the fourth day of the month and ending on the third day of the following month. All transactions that post to an account during a cycle are summarized on a statement of account issued by the government credit card contractor.

03. **Card limit** \- The maximum cumulative amount that can be charged to an individually billed government travel card in any one billing cycle.

04. **Concur Government Edition (CGE) reservation fee** \- A vendor fee that will auto-populate in a document when reservations are booked through Concur or by contacting the TMC directly. If a reservation is cancelled prior to ticketing, no transaction fee is incurred.

05. **Centrally billed account (CBA)** \- A corporate travel card account set up for travelers who do not have an individually billed account to use for official IRS travel expenses (airline and train tickets only).

06. **Delinquent account** \- Individually billed account with a balance due that remains unpaid for a period of 61 days or more from the closing date of the statement of account on which the charges first appeared.

07. **Disputed item** \- An erroneous, duplicate, or over charge that appears as a transaction on an individually billed travel cardholder's statement of account. Travel cardholders are responsible for disputing timely any incorrect or unauthorized charges that may appear on their statement of account.

08. **Electronic credit review** \- An electronic credit check performed by the government credit card contractor to research the applicants credit score, assessing creditworthiness based on credit history and current credit accounts.

09. **Electronic travel system (ETS)** \- A web-based, integrated travel booking and reimbursement system that includes authorizations, vouchers and travel reservations for both domestic and foreign travel. The system's split disbursement function allows travelers to allocate the payment of individual expenses directly to the government credit card contractor.

10. **Government credit card contractor** \- The bank that issues the travel card used by authorized IRS employees to pay for official travel expenses.

11. **Inappropriate use** \- Use of the IRS government credit card to make purchases not approved, funded and authorized by or in conformance with applicable IRS travel card and CBA guidelines.

12. **Individually billed account (IBA)** \- A government contractor-issued travel card used by authorized individuals to pay for official travel and transportation related expenses for which the contractor (bank) bills the employee and for which the employee is liable for paying.

13. **Merchant category code (MCC)** \- A standard code assigned to every merchant that accepts a credit card identifying the category of goods, services, or activity they are involved with. The accuracy of the assigned MCC is the function of the merchant and MasterCard.

14. **Merchant category code templates** \- A grouping of MCCs assigned to each individually billed travel cardholder's account based on the travel cardholder's anticipated purchasing activity. MCC templates are an element of the system of internal controls for the credit card program, designed to reduce the potential for inappropriate credit card use.

15. **Restricted travel cardholder** \- A travel cardholder who did not consent to an electronic credit check or had a credit score of less than 660. A restricted travel card does not include a MCC template for miscellaneous expenses. In addition, restricted travel cardholders also do not have ATM privileges.

16. **Split disbursement** \- An electronic travel system (ETS) functionally dividing a travel voucher reimbursement between the credit card contractor and the traveler. The balance owed to each is sent directly to the applicable party.

17. **Standard travel cardholder** \- A travel card applicant who agreed to an electronic credit review and had a credit score of 660 or more. A standard travel card includes the MCC template for miscellaneous expenses and ATM access.

18. **Statement of account** \- A summary of transactions (debits and credits) posted to the individually billed travel cardholder’s account during the billing cycle. The government credit card contractor will send a statement of account to the individually billed travel cardholder within five business days after the end of the billing cycle. Statements of account can be accessed through the government credit card contractor’s website.

19. **Travel advance** \- A prepayment of estimated travel expenses paid to an IRS employee in advance of authorized official IRS travel. Travel advances are not available to standard travel cardholders.

20. **Travel card -** A credit card used to pay for authorized official IRS travel and allowable travel-related expenses. Each travel card reflects an individual billed account established in the travel cardholder's name. The term "individually billed" account is synonymous with travel card, credit card, government issued travel card and IBA.

21. **Travel authorization** \- An electronic or written document submitted for approval to authorize official travel. The travel authorization obligates funds and must be submitted and approved before traveling, except in emergency situations.

22. **Travel cardholder** \- The IRS employee who has been trained and authorized to use the individually billed account. The travel cardholder is the _only authorized user_ of the travel card and is responsible for safeguarding the travel card and account number to minimize the opportunity for theft or unauthorized use.

23. **Travel management center (TMC)** \- A travel agency contracted by the IRS or the electronic travel system (ETS) to provide services to book and ticket transportation, lodging and rental car services to IRS employees on official travel.

24. **Travel voucher** \- A written request or electronic submission supported by documentation and receipts, where applicable, for reimbursement of expenses incurred in the performance of official IRS and relocation travel.


**1.32.4.1.7** **(02-13-2026)**

#### Acronyms

1. The following acronyms apply to this program.




| **Acronym** | **Description** |
| --- | --- |
| ABA | American Bankers Association |
| ATM | Automated Teller Machine |
| CBA | Centrally Billed Account |
| CGE | Concur Government Edition |
| ETS | Electronic Travel System |
| IBA | Individually Billed Account |
| IFS | Integrated Financial System |
| MCC | Merchant Category Codes |
| GPS | Global Positioning System |
| TMC | Travel Management Center |


**1.32.4.1.8** **(02-13-2026)**

#### Related Resources

1. IRM 1.32.1, IRS Local Travel Guide

2. IRM 1.32.11, IRS City-to-City Travel Guide

3. [Federal Travel Regulation](https://www.irs.gov/www.ecfr.gov/current/title-41/subtitle-F)

4. [5 U.S.C. 5514, Installment deduction for indebtedness to the United States](http://www.gpo.gov/fdsys/pkg/USCODE-2011-title5/pdf/USCODE-2011-title5-partIII-subpartD-chap55-subchapII-sec5514.pdf)

5. IRS Source

6. The Inappropriate Use Guide offers specific instances of misuse and their resolutions.

7. IRS Manager’s Guide to Penalty Determinations provides Labor/Employee Relations and Negotiations guidance for penalty determinations for the misuse of the travel card.


**1.32.4.2** **(07-30-2021)**

### Individually Billed Account Travel Card Program

1. The Individually billed account (IBA) travel card is a government contractor-issued travel card used by authorized individuals to pay for official travel and transportation related expenses for which the contractor (bank) bills the employee and for which the employee is liable for paying.

2. All employees are required to obtain and use the IBA travel card for all official travel unless:



1. A vendor does not accept the travel card;

2. The director, Credit Card Services, has granted an exemption (see IRM 1.32.4.2.1.1 (1), Exemptions to Mandatory Use of Travel Card Policy;

3. The manager, International Travel and Visitor’s Program/Official Passports, in LB&I has granted an exemption; or

4. The employee qualifies for an exemption under IRM 1.32.4.2.1.1 (4), Exemptions to Mandatory Use of the Travel Card Policy.


**1.32.4.2.1** **(07-05-2019)**

#### Mandatory Use of Individually Billed Account

1. The Federal Travel Regulation (FTR), 41 CFR Part 301-51.1 and 301-51.2, Paying Travel Expenses, requires use of the travel card for official travel unless the employee has an exemption.

2. All employees who are required to travel must obtain and use the travel card for all official travel and transportation-related expenses. The credit card contractor will bill the employee directly and the employee is required to pay the statement timely.


**1.32.4.2.1.1** **(02-13-2026)**

##### Exemptions to Mandatory Use of Travel Card Policy

1. Delegation Order 1-49, Exemption to Travel Card Mandatory Use Policy, grants authority to the director, Credit Card Services and Travel Management, to grant exemptions to the mandatory use policy to employees who believe they would incur a hardship if required to obtain and use the government issued travel card.

2. The Letter of Understanding between the director, Labor/Employee Relations and Negotiations, and NTEU defines hardship as (a) a history of personal or work-related financial hardship or (b) objection to the use of credit cards in general based on tenets of the employee’s religion.

3. Employees may request an exemption by sending an email with justification to their immediate manager. If the manager determines the requirements are met, the manager will forward the approved request via email to the Credit Card Services mailbox at \*IRS CCS. The subject line of the message should be adjusted to read "Exemption Request" before forwarding.

4. The IRS exempts the following groups of travelers from the mandatory use of the government travel card:



1. Employees who have a government travel card application pending.

2. Employees for whom the issuance of a government travel card would adversely affect the mission of IRS or put the employee at risk.

3. Employees who are not eligible to receive a government travel card.

4. New employees who are exempt until they obtain a government travel card. New employees who will travel are expected to obtain and use the government travel card within 45 days after they report to duty.

5. International travelers.

6. Employees with suspended or cancelled government travel cards.


**1.32.4.2.1.1.1** **(02-13-2026)**

###### Exemption for Mandatory Use for International Travel

1. The LB&I International Travel Office and Travel Management Office has been delegated the authority to grant exemptions to the mandatory use of the government issued travel card for IRS business outside the United States, except for Chief Counsel and Criminal Investigation employees. Additional information and guidance for Chief Counsel and Criminal Investigation employees can be found on the International Travel website.

2. Information for submitting requests for exemption from the mandatory use of the travel card requirement for international travel can be found on the IRS Source website.


**1.32.4.2.1.1.2** **(02-13-2026)**

###### Payment Sources for Travelers with Exemptions

1. The following payment sources for allowable travel expenses are authorized for travelers who receive an exemption from the mandatory use of the travel card:



1. CBA (for common carrier transportation expenses only).

2. Personal funds/personal charge card without approval (except for purchases of common carrier tickets over $100. See IRM 1.32.11.7.5, IRS City-to-City Travel Guide for procedure to request approval.).

3. Travel advances through ETS for IRS employees only.


**1.32.4.2.2** **(07-05-2019)**

#### Use of the Individually Billed Account

1. The travel card can only be used for official government travel and travel-related expenses while in official travel status.



1. The ATM feature must only be used to obtain cash for official IRS travel expenses that cannot be charged using the travel card. The ATM may be used three calendar days prior to the start of travel through the last travel day.

2. Some states provide a lodging tax exemption for federal employees on official business. GSA provides a list of participating states with their applicable forms. See [State Tax Information.](https://smartpay.gsa.gov/content/state-tax-information) Travelers must present the form to the hotel at check-in.

3. The travel card is non-transferable and may only be used by the employee whose name appears on the travel card.


2. Employees should use the travel card to the maximum extent possible. At a minimum, employees must use the government travel card to pay for transportation, lodging, rental cars and rental car gas.

3. The travel card can be used to purchase fuel for a privately-owned vehicle (POV) for travel between places of official business or other authorized points no more than one calendar day prior to the start of official travel through one calendar day after the official travel ends.


**1.32.4.2.2.1** **(02-13-2026)**

##### Authorized/Unauthorized Uses

1. The travel card can only be used for allowable travel and travel-related expenses while in official IRS travel status.




| **Expense Type** | **Authorized For City to City Travel** | **Authorized for Local Travel** | **When Expense is Authorized, Card Use is:** |
| :-: | :-: | :-: | :-: |
| Baggage fees | Yes | No | Mandatory |
| Common carrier transportation tickets | Yes | No | Mandatory |
| Companion/personal airline tickets and additional charges for premium seats (requires CFO Travel Policy approval\*) | No | No | Unauthorized |
| Emergency purchases (refer to emergency expenses in IRM 1.32.11.5.3) | Yes - Conditional | Yes - Conditional | Optional |
| Gasoline for a government vehicle | No | No | Unauthorized |
| Gasoline for a POV (excludes car washes) | Yes | Yes | Optional |
| Gasoline for a rental car (excludes car washes) | Yes | Yes | Mandatory |
| Laundry or dry cleaning (for domestic travel four or more nights only) | Yes | No | Optional |
| Lodging (hotel or motel) | Yes | No | Mandatory |
| Meals (including grocery stores) - Alcohol purchase without food is not authorized. | Yes (Unless Same-Day Travel completed within 12 hours and does not include Per Diem) | No (Unless in travel status for 12 hours or more with Per Diem) | Optional if less than $15 |
| Meeting space and conference fees or reserving rooms for other travelers | No | No | Unauthorized |
| Non-travel related expenses (lien fees, investigator expenses, administrative summons expenses, copies third party records or Right to Financial Privacy Act expenses) | Yes | Yes | Optional |
| Office supplies | No | No | Unauthorized |
| Parking (long term, daily, hotel) | Yes | Yes | Optional |
| Personal items (e.g., over-the counter medications, vitamins, clothing, toiletries, household items, reusable cups, or gifts) | No | No | Unauthorized |
| Photos for Passports/Visas (keep the receipt to claim the expense on the voucher) | Yes | Yes | Optional |
| Postage (stamps, certified mail, shipping-UPS, FedEx, etc.) | No | No | Unauthorized |
| Rental car | Yes | Yes | Mandatory |
| Taxi, Uber, Lyft and shuttle service (subscription services are NOT allowable for Uber, Lyft, Doordash, etc. | Yes | Yes | Optional |
| Vehicle repairs | No | No | Unauthorized |

2. Travel cards may **not** be used to purchase personal items, for example, over-the-counter medications, vitamins, clothing, toiletries, household items, reusable cups, or gifts.

3. Travel cards may be used for Meals and Incidental Expenses (M&IE) and must be used for meals over $15. Incidental expenses are defined by the Federal Travel Regulations Section 300-3.1 as fees and tips given to porters, baggage carriers, hotel staff, and staff on ships.

4. Employees may not use their government travel card for any alcohol and alcoholic beverage for which a separate charge is made.

5. Lodging expenses are not authorized for local travel within a 50-mile radius of the employee’s official duty station and residence without approval from Director, Travel Management. See Per Diem Expenses for Local Travel in IRM 1.32.1.8 for more information.


**1.32.4.2.2.2** **(07-05-2019)**

##### National Treasury Employees Union Use of the Travel Card

1. The travel card cannot be used to pay for travel expenses of employees performing NTEU business unless the IRS has approved it. For example, if NTEU officials travel using NTEU funds rather than government funds, a government travel card cannot be used.


**1.32.4.2.2.3** **(07-05-2019)**

##### Inappropriate Use of the Travel Card

1. Credit Card Services is responsible for reviewing travel card transaction reports to ensure charges are appropriate and business-related. Questionable charges on a travel cardholder's statement of account will be referred to management through the appropriate Labor/Employee Relations and Negotiations office for further investigation and resolution. Travel cardholders who use their government travel card for personal charges could be in violation of the Rules of Conduct. The task order with the government credit card contractor requires that travel cards be used only for official government travel and related expenses and that resulting statements be paid in full within the statement period. Examples of inappropriate use include:



1. Purchasing items for personal use;

2. Using the card without prior travel authorization;

3. Using the incorrect credit card;

4. Use of the travel card by a non-authorized user;

5. Purchasing meals within the official work location/commuting area (unless employee is in official travel status entitled to meals and incidental expenses (M&IE));

6. Renting automobile without prior authorization; and

7. Charging travel expenses of several travelers on one travel card.


The Inappropriate Use Guide offers specific instances of misuse and their resolutions. The Government Charge Card Abuse Prevention Act of 2012 requires agencies to impose appropriate adverse personnel actions in cases where employees fail to comply with applicable travel card terms. The IRS Manager’s Guide to Penalty Determinations provides Labor/Employee Relations and Negotiations penalty determinations guidance for travel card misuse.


**1.32.4.2.3** **(02-13-2026)**

#### Card Controls

1. The controls and restrictions on travel card accounts are discussed below. If a travel card is declined because of a restriction, refer to the IRS Source website.


**1.32.4.2.3.1** **(02-13-2026)**

##### Card Limits

1. The card limit is the maximum cumulative amount that can be charged to a travel card account in a billing cycle. For most travel cardholders, the card limit is $1 until travel is approved. The card limit is increased to cover expected expenses for the travel period and then reduced back to $1. The travel card limit considers unpaid charges from prior monthly billing cycles as part of the card limit. As a result, the actual available card limit fluctuates as charges and payments are posted.

2. Higher limits are provided for special circumstances such as extended travel. Requests for a higher limit must be made with the approval of the travel cardholder's manager. Requests must be specific as to the need for the increased limit and the duration. The duration may be permanent or for a specific time period and should reflect the traveler’s business needs. It is not appropriate to request an increase in the card limit if there is an outstanding balance. More information about requests to change card and ATM limits is available on the IRS Source website.


**1.32.4.2.3.2** **(02-13-2026)**

##### Relocation Employees (Special Privileges)

1. Employees with relocation expense authorizations are required to use the government travel card for house hunting and en-route travel expenses to the new official station. Use of the travel card for temporary quarters and temporary quarters subsistence is mandatory.

2. Special privileges for travel cardholders with relocation expense authorization include an increased card limit and enhanced merchant category code templates. Special privileges are removed from the travel cardholder's account at the end of the relocation travel period.


**1.32.4.2.3.3** **(02-13-2026)**

##### Merchant Category Codes and Templates

1. Merchant category codes (MCC) are four-digit numerical standard codes that identify the type of goods and/or services the merchant provides. The codes limit purchases to travel-related expenses. Travel card activity is restricted by the MCC assigned to the travel cardholder's account.

2. An MCC template is a grouping of MCCs assigned to a travel cardholder's account based on anticipated use. The travel card will then be accepted at merchants, such as airlines and hotels, whose MCC is included in the template for that travel card. Travel cards will be declined at merchants whose MCC is not included in the template.

3. Requests for MCC changes for miscellaneous expenses (non-travel related expenses for lien fees, investigator expenses, administrative summons expenses or Right to Financial Privacy Act expenses) on a restricted travel card account will not be considered.


**1.32.4.2.4** **(02-13-2026)**

#### Cash from Automated Teller Machines Access

1. The ATM feature (available only to standard travel cardholders) may be used to obtain cash for official IRS travel expenses. The travel card should be used to the maximum extent possible to charge travel expenses. The Federal Travel Regulation requires the travel card be used for all official travel related expenses, unless exempted as described in IRM 1.32.4.2.1.1..

2. The ATM withdrawals are limited to $100 per day with an overall withdrawal limit of $1,000 per billing cycle. The travel cardholders can withdraw cash from an ATM three days prior to the official travel date of departure through the last day of official travel.

3. The government credit card contractor charges a fee of 2.5% of the amount of the cash advance for the service. In addition, an ATM fee of varying amounts can be charged as an access fee. These fees are charged to the standard travel cardholder’s account. Both fees are reimbursable to the standard travel cardholder.

4. Restricted travel cardholders are not granted ATM privileges.

5. Standard travel cardholders cannot request a travel advance.

6. Standard travel cardholders can establish or change their card’s PIN at any time by calling the government credit card contractor. PINs are used to obtain cash for official IRS travel expenses that cannot be charged using the travel card. Changes are effective immediately after confirmation.

7. Information regarding ATM access is available on the IRS Source website.


**1.32.4.2.5** **(02-13-2026)**

#### Record Retention Period for Travel Card Documentation

1. Travel cardholders are responsible for ensuring that their travel documents have been correctly uploaded into ETS and are legible. The ETS retains copies of the receipts for six years after the fiscal year in which travel occurred. See IRM 1.32.11.7.7, Claiming Reimbursements. Managers are not required to retain original receipts and vouchers if the voucher is filed using ETS. Managers must retain copies of approved manual travel authorizations and vouchers, and all supporting documents for six years. Manual travel voucher records may then be destroyed according to the guidelines for records retention and disposition.

2. Record retention guidance is available in Electronic Travel Record Retention..


**1.32.4.2.6** **(02-13-2026)**

#### Training and Application Process

1. Training is a prerequisite for obtaining a travel card. All potential travel cardholders must first complete the travel card self-study training course. The instructions for completing the government credit card contractor's on-line travel card application form can be accessed at the end of the course. All travel card applications must be in the applicant's name as shown in IRS official personnel records or in approved pseudonym names and must be electronically submitted by the applicant through the government credit card contractor’s electronic access system.

2. A travel card will be mailed in a plain envelope to the applicant at the statement billing mailing address indicated on the application form. It should be received within five to seven business days from the date the properly completed application is entered in the government credit card contractor's electronic access system.

3. Travel cardholders will need to call the government credit card contractor at the number on the back of the travel card to establish a PIN. The PIN will be used at chip enabled merchant terminals and for standard travel cardholders to obtain cash from the ATM for official IRS travel expenses that cannot be charged using the travel card. Information regarding the training and application process for obtaining a travel card is available on the IRS Source website.


**1.32.4.2.6.1** **(02-13-2026)**

##### Electronic Credit Review

1. The Office of Management and Budget (OMB) Circular A-123, Appendix B, Chapter 6, Creditworthiness, requires all agencies to perform a credit check on new travel card applicants using a Fair Isaac Corporation (FICO) credit score. A new travel card applicant is an employee who has not had a government-issued travel card within the last 12 months. Creditworthiness reviews are an important internal control to ensure that travel cardholders are financially responsible.

2. The option of consenting to an electronic review by the government credit card contractor is on the on-line travel card application. A new travel card applicant with a FICO credit score of 660 or higher will receive a standard travel card. Applicants with a FICO credit score of less than 660, or who do not consent to an electronic credit review will receive a restricted travel card. Information regarding electronic credit checks is available on the IRS Source website.


**1.32.4.2.6.2** **(10-19-2023)**

##### Activating the Travel Card

1. Upon receipt of the travel card, travel cardholders must verify the accuracy of the information on the transmittal document and on the travel card.

2. If there is an error on the transmittal document or travel card, the cardholder should contact Credit Card Services via IRS Service Central (IR Works) to correct the problem.

3. If the information is correct, the travel cardholder should activate the travel card by calling the government credit card contractor at the telephone number on the activation sticker. When the call is completed, the card will be activated and ready for use.

4. Travel cardholders will need to call the government credit card contractor at the number on the back of the travel card to establish a PIN. The PIN will be used at chip enabled merchant terminals and for standard travel cardholders to obtain cash from the ATM for official IRS travel expenses that cannot be charged using the travel card.


**1.32.4.2.6.3** **(06-01-2006)**

##### Ordering a Replacement Card

1. If the travel card becomes worn, damaged, or defective in any way, the travel cardholder can order a replacement card by contacting the government credit card contractor at the telephone number listed on the back of the card.


**1.32.4.2.6.4** **(06-01-2006)**

##### Card Renewal Process

1. When the expiration date shown on the face of the travel card draws near, the government credit card contractor will send the travel cardholder a renewal card automatically. This generally, will occur two to four weeks prior to the expiration date. The renewal card will require activation. Activation instructions will be provided on a sticker affixed to the renewal card. Activating the renewal card automatically cancels the expiring card. The expired card should be properly disposed of by cutting it up.


**1.32.4.2.6.4.1** **(07-05-2019)**

###### Travel Card Refresher Training

1. Travel cardholders are required to complete refresher training every two years. The objectives of refresher training are to:



1. Ensure all travel cardholders are made aware of current program rules, regulations, guidelines and changes.

2. Strengthen the IRS travel card program internal controls.


2. Travel cardholders will be notified via email with detailed instructions when they are required to complete the refresher course. Travel cardholders will have approximately 45 calendar days to complete the training after being notified.


**1.32.4.2.7** **(02-13-2026)**

#### Monthly Statements

1. Travel cardholders receive a statement from the government credit card contractor if there is activity on the account or an outstanding balance, unless the travel cardholder has selected "Go Paperless" on the government credit card contractor’s electronic access system.

2. The billing cycle for travel card accounts closes on the third day of each month.

3. Travel cardholders are responsible for timely payment of all undisputed charges.


**1.32.4.2.7.1** **(02-13-2026)**

##### Statement Explanation

1. Travel cardholders will receive a statement of account from the government credit card contractor if there is activity on the account or an outstanding balance. The statement of account is available electronically if the travel cardholder selects "Go Paperless" on the government credit card contractor’s electronic access system or is mailed to the statement billing mailing address provided by the travel cardholder. This will usually be the travel cardholder’s home address, unless the travel cardholder has specified a different mailing address.

2. The monthly statement of account reflects activity on the account for the billing cycle. The billing cycle for travel cards closes on the third of each month. Each charge and credit transaction that posts to the travel cardholder's account during the billing cycle will be itemized on the statement of account. The statement of account will show the total amount due and the payment due date.

3. The travel cardholder must review the statement of account for erroneous or unauthorized charges. If any of these charges are identified, the travel cardholder must take prompt action to resolve the dispute.


**1.32.4.2.7.2** **(02-13-2026)**

##### Dispute Process

1. The travel cardholders are responsible for disputing any incorrect or unauthorized charges that appear on their monthly statements of account timely. Travel cardholders must contact the government credit card contractor representative within 90 days from the "transaction date" of the erroneous charge(s).

2. If the merchant's name and the charge(s) are not recognized by the travel cardholder, the cardholder should immediately contact the government credit card contractor to initiate a transaction dispute so the unrecognized charge(s) can be removed and a new travel card issued.

3. If the merchant's name is recognized by the travel cardholder, but the charge was not authorized, the cardholder should contact the merchant to request a credit. If the credit does not post in the next billing cycle, the cardholder should contact the government credit card contractor to initiate a transaction dispute. If the dispute is not initiated within the 90-day time-frame, the cardholder will be responsible for paying the charge(s).

4. After the travel cardholder notifies the government credit card contractor, disputed amounts may be deducted from "total payments due" . Travel cardholders must be proactive in securing credits resulting from a dispute from merchants timely. Travel cardholders must timely pay all charges on their statement of account that have not been disputed timely.

5. Information regarding the dispute process is available on the IRS Source website.


**1.32.4.2.7.3** **(02-13-2026)**

##### Trip Cancellation

1. When the travel card is used to purchase common carrier transportation tickets through ETS and the trip is cancelled, if the reservation has not been ticketed, the travel authorization and reservation in ETS must be cancelled by the travel cardholder. No transaction fee will be incurred, and the fare will not be charged to the travel card.

2. If the trip is cancelled after ticketing, the travel cardholder should contact the TMC to cancel and request a refund for the common carrier ticket. The travel authorization should not be cancelled in ETS and the Concur Government Edition (CGE) fee is non-refundable. The travel cardholder should prepare a travel voucher to claim reimbursement for the CGE fee. If a common carrier charge appears on the travel cardholder's statement of account, the travel cardholder must contact the government credit card contractor at the number shown on the back of the travel card to initiate the dispute process. The cardholder must contact the hotel to cancel reservations booked directly with the hotel when booked via a block of rooms. Car and/or hotel only reservations booked in the ETS are valid, even if the authorization has not been signed or approved. The CGE reservation fee is incurred when the authorization is approved or on the first day of travel. Information about the dispute process is available on the IRS Source website.


**1.32.4.2.7.4** **(07-05-2019)**

##### Payment Terms

1. The travel cardholder is responsible for payment of all undisputed charges upon receipt of the monthly statement of account.

2. The travel cardholder must pay all undisputed charges in full upon receipt of the statement of account. The government credit card contractor must receive the travel cardholder's payment by the due date. The due date is 25 calendar days from the closing date on the statement of account in which the charges first appear. The travel cardholder is responsible for paying undisputed charges timely regardless of whether reimbursement has been received.

3. Government postage must not be used when remitting payments to the government credit card contractor.


**1.32.4.2.7.4.1** **(02-13-2026)**

###### Payment Methods

1. The travel cardholders may pay their accounts through ETS voucher split disbursement, through the government credit card contractor's electronic access system, by mail, or by telephone. Information regarding each payment method is available on the IRS Source website.

2. The IRS has implemented split disbursement and salary offset procedures for the government travel cards.


**1.32.4.2.7.4.2** **(02-13-2026)**

###### Making/Expediting Payment

1. Employees are required to use split disbursement. Split disbursement is the ETS default payment method. All employees have the option to change the method and amount of payment (e.g., meals and incidental expenses not charged on the travel card). However, if the method and amount of payment is changed, employees will be required to explain why the default split disbursement payment method was not used, which will be evaluated as part of the ETS pre-audit process.

2. Payments allocated to the government credit card contractor in ETS can be verified in the on-line payment feature or when the monthly paper statement of account is received in the mail. Travelers must pay any remaining travel card balance that was not covered by split disbursement to the employees individual billed government travel card. The remaining charges should be paid by the statement of account due date. It is the travel cardholder's responsibility to ensure payments are posted as designated in ETS.

3. Payments may be expedited using the on-line payment feature on the government credit card contractor's website. Travel cardholders must provide their American Bankers Association (ABA) routing number, account number and dollar amount. The government credit card contractor does not charge a fee for using the on-line payment feature; however, there may be a fee charged by the travel cardholder's financial institution. .

4. Payments to the government credit card contractor may be made by mail prior to receipt of the monthly paper statement of account. Travel cardholders should include their 16-digit account number with the remittance. A copy of the electronic statement of account may be enclosed with the remittance.

5. The travel cardholders may use the government credit card contractor’s phone pay service to expedite payment by telephone using an electronic check service. Payments made by this method will post to the travel cardholder’s account immediately.


**1.32.4.2.7.5** **(07-30-2021)**

##### Travel Vouchers: Relationship to Travel Cards

1. The travel cardholders must file their travel vouchers within five working days after completing travel. All travel card charges must be paid within 25 calendar days from the closing date of the statement of account on which they appear. Travelers are responsible for payment of their IBA charge card bill in accordance with the cardholder agreement, even if the cardholder has not been reimbursed by IRS. Actual bank fees charged for non-payment will not be reimbursed by IRS. When properly submitted travel claims are not paid by IRS within 30 days, IRS will reimburse a late payment fee. This late payment fee is equivalent to interest calculated using the prevailing Prompt Payment Act Interest Rate plus a fee equivalent to any late payment charge the bank would have charged the traveler had they not paid the bill. All interest paid on late vouchers is considered income for payments of $600 or more during the calendar year and must be reported on an individual’s tax return.


**1.32.4.2.8** **(10-17-2012)**

#### Delinquent Accounts

1. Travel cards with a balance due that remains unpaid for a period of 61 days or more from the closing date of the statement of account on which the charges first appeared are considered delinquent. Failure to pay undisputed charges is a conduct issue that could result in disciplinary action.


**1.32.4.2.8.1** **(10-17-2012)**

##### Past Due Accounts

1. A travel card account with an unpaid, undisputed balance 31 days after the statement closing date on which the charge(s) first appeared is considered past due. If an account is unpaid 45 days from the statement closing date, the government credit card contractor will send the travel cardholder a "past due" letter. If the account remains unpaid at 55 days, the government credit card contractor will send the travel cardholder a pre-suspension notification. A travel card account with an unpaid, undisputed balance 61 days after the closing date is considered delinquent.


**1.32.4.2.8.2** **(02-13-2026)**

##### Suspension and Reactivation

1. If an account is unpaid 61 days from the statement closing date on which the charge(s) first appeared, the government credit card contractor will suspend the cardholder’s travel card account and the travel cardholder will not be able to use the travel card. The government credit card contractor will reactivate a suspended travel card after payment has been received.

2. Charges that have been disputed (and confirmed by the government credit card contractor by email) will not be considered delinquent until the government credit card contractor makes a determination.


**1.32.4.2.8.3** **(07-30-2021)**

##### Multiple Suspensions

1. If an account has been suspended two times during a rolling 12-month period for undisputed amounts and becomes past due again, the government credit card contractor can cancel the travel card account. A rolling 12-month period begins in one month and concludes 12 months later. For example, if a travel cardholder account is suspended in May 2020, the suspension will continue to be considered as the first suspension until May 2021 when it will drop-off of the 12-month calendar.

2. The government credit card contractor will issue a letter to notify the travel cardholder and offer the travel cardholder an opportunity to avoid cancellation if the past due balance is paid within ten days from the date of the letter. A second letter will be sent to the travel cardholder if the account has been cancelled due to failure to pay the outstanding amount within the ten-day period.


**1.32.4.2.8.4** **(02-13-2026)**

##### Payments Returned for Non-Sufficient Funds

1. Payments by check, telephone or on-line that are returned by the government credit card contractor because of non-sufficient funds (NSF) will affect the travel cardholder’s account.

2. Upon the first instance of an NSF payment, any special privileges assigned to the travel cardholder’s account, such as an increased card limit, will be revoked.

3. When a second instance of an NSF occurs in a rolling 12-month period, the government credit card contractor will automatically cancel the travel cardholder’s account.


**1.32.4.2.8.5** **(02-13-2026)**

##### Cancellation

1. If an account is unpaid 126 days from the closing date on the statement of account in which the delinquent charge(s) first appeared, the government credit card contractor will cancel the cardholder’s travel card account and revoke all charging privileges.


**1.32.4.2.8.6** **(10-17-2012)**

##### Cancelled Card and Need to Travel

1. If an employee's travel card account has been suspended or cancelled for non-payment and, then, the employee is required to travel, the following sources of payment for allowable travel expenses are authorized:



1. CBA for common carrier transportation expenses only

2. Personal funds/personal charge cards, except for purchases of common carrier tickets over $100

3. Travel advances.


**1.32.4.2.8.7** **(02-13-2026)**

##### Salary Offset for Undisputed Travel Card Debt

1. The authority for federal agencies to collect undisputed delinquent amounts incurred on an employee's travel card from the employee's disposable pay is contained in the Travel and Transportation Reform Act of 1998 (Pub. L. No.105-264).

2. IRM 1.36.4, Administrative (Non-Tax) Debt Management, implements the IRS policy for salary offset.

3. The government credit card contractor may consider salary offset for outstanding undisputed travel card charges on suspended accounts. Selection for salary offset is made at the government credit card contractor’s discretion using established collection criteria. Salary offset will be considered upon written request from the government credit card contractor and approval of IRS. See 1.32.4.2.8.2, Suspension and Reactivation, for additional information on suspended accounts.

4. No more than 15% of the employee's disposable pay per pay period will be collected under this procedure. The debt covered by this collection procedure is lower in priority to all other involuntary collection, garnishment, and offset actions, and will not be collected if higher priority debt would result in collecting more than 15% of the employee's disposable pay for any given pay period.

5. When the IRS receives a written request from the government credit card contractor for collection of travel card indebtedness, the employee will be afforded due process before any salary amounts are withheld. The IRS will notify the employee in writing of its intention to collect the debt. The employee will be provided 30 days to repay the delinquent balance or enter into a written payment agreement with the government credit card contractor.

6. Salary offset will continue until the full amount of the debt is collected or the employee makes full payment.

7. If the employee does not make full payment or enter into a payment agreement within the 30-day period, collection will begin the next pay period. The employee will receive a notification of the amount of the bi-weekly deduction.

8. The salary offset provision arises under the debt collection procedures in 41 CFR § 301-76.100, which provide due process rights to employees, including written notice and the right to request a review of the debt. If an employee is not disputing a travel card debt, the employee is waiving rights that arise under the Debt Collection Act.


**1.32.4.2.8.8** **(02-13-2026)**

##### Reinstatement Process

1. The government credit card contractor will rarely reinstate a travel card account that was cancelled due to non-payment. If an employee's travel card account was cancelled as a result of non-payment and the employee wants to pursue reinstatement, the outstanding balance on the account, including late fees, must be paid in full. The employee should then contact their manager.

2. If the manager determines the employee's reinstatement request should be pursued, the employee will be required to complete the on-line travel card self-study training course available on the IRS Source website. The manager will complete the Request for Consideration of Reinstatement Form and forward it to Credit Card Services.

3. Upon receipt of the required documentation, Credit Card Services will review the employee's travel card account history. If the account has been paid in full, Credit Card Services will notify the employee to submit a new on-line travel card application, and the employee must consent to the credit check. If the employee does not agree to consent to the credit check, the travel card cannot be reinstated.

4. The government credit card contractor makes the final determination on whether the account will be reinstated. The government credit card contractor may review and consider the employee’s complete credit history in deciding whether to reinstate the individual’s account. Credit Card Services will notify the manager of the government credit card contractor’s decision. Due to the government credit card contractor’s required review of the account, the request could take several weeks to process.

5. If the account is reinstated and becomes past due again, Credit Card Services will cancel the account. No future reinstatement requests will be considered.

6. Information on requesting reinstatement of a travel card account and the Request for Consideration of Reinstatement Form is available on the IRS Source website.


**1.32.4.2.9** **(02-13-2026)**

#### Travel Card Account Changes

1. Information and procedures regarding account maintenance changes are available on the IRS Source website. Account maintenance changes include:



1. Name change

2. Address and phone number changes

3. Canceling your travel card

4. Reactivating a closed travel card account

5. ATM Access, Usage and Limit Changes

6. Limit increase

7. Declined transaction


**1.32.4.2.10** **(02-13-2026)**

#### Travel Card Problems

1. Information and procedures regarding travel card problems are available on the IRS Source website. Travel Card problems include:



1. Lost, stolen or compromised travel card

2. Delinquent accounts

3. Canceled trip

4. Incorrect charges

5. Account credit


**1.32.4.3** **(10-17-2012)**

### Centrally Billed Account Program

1. A corporate travel card account set up for travelers who do not have an individually billed account to use for official IRS travel expenses (airline and train tickets). One CBA account is established for each IRS business unit.


**1.32.4.3.1** **(02-13-2026)**

#### Centrally Billed Account Guidelines

1. The CBA is a credit card account that travelers can use to charge common carrier transportation expenses and is available to:



1. Employees when issuance of the government contractor-issued travel card would adversely affect the IRS mission or put the employee at risk.

2. Employees who are not eligible to receive a government contractor-issued travel card.

3. New employees who have not yet obtained their own travel card.

4. Invitational travelers.

5. Employees who have received a written exemption from the mandatory use of the travel card from the director, Credit Card Services; and

6. Relocating employees and family members may use the CBA for house-hunting trips and en- route travel if the employee does not hold a government credit card.


2. Travelers who have a travel card cannot use the CBA, unless they meet one of the following exceptions:



1. Have a suspended account or an account closed for misuse.

2. Have an account closed as being lost, stolen, or fraudulent and a new card hasn’t been received.

3. Incur foreign travel transportation costs.


**1.32.4.3.1.1** **(02-13-2026)**

##### Authorized Uses of the Centrally Billed Account

1. The CBA can only be used for purchasing common carrier transportation tickets and related fees for official IRS travel while employees are in travel status away from their official station. Authorized uses are as follows:



1. Airline tickets

2. Railway tickets

3. Travel Management Center (TMC) fees associated with transportation, lodging, and rental car ticketing


**1.32.4.3.1.2** **(10-17-2012)**

##### Unauthorized Uses of the Centrally Billed Account

1. Unauthorized uses of the CBA include:



1. Personal travel (airline and train)

2. Rental cars and gasoline

3. Lodging and meals


**1.32.4.3.1.3** **(10-19-2023)**

##### Centrally Billed Account Ticket Authorization Process

1. The traveler’s manager must authorize the traveler to use the CBA. The traveler will use ETS to complete and sign a travel authorization. The signed travel authorization reflecting CBA as the method of reimbursement will route systemically to a credit card services conditional router for review and approval.

2. The Credit Card Services conditional router will review the reservation and will either approve (authorize) or disapprove (return) the request. The document is stamped in ETS and the traveler receives a general email message indicating the status.



1. Approved (authorized) requests will route to the traveler's manager for review and approval of the trip. The TMC will issue the transportation ticket three or four days prior to the scheduled departure date and will email or fax an invoice to the traveler, confirming the ticket has been purchased.

2. Disapproved (returned) requests will not include a justification in the email message from ETS. Travelers may review the justification and/or status of a pending request by selecting Digital Signature from the pull-down list located at the bottom of the ETS screen.


3. Additional information regarding the process for using the CBA is available on the IRS Source website.


**1.32.4.3.1.4** **(02-13-2026)**

##### Travel Voucher Considerations

1. The CBA charges are billed and paid monthly. Travelers who use the CBA cannot claim reimbursement for transportation and CGE fees on their travel voucher. Travelers should ensure that:



1. If using ETS, the method of reimbursement should reflect CBA on the transportation ticket and the CGE fee.

2. If using the manual travel authorization form, the travel voucher (Form 15342) should indicate use of the CBA as the method of payment for the transportation ticket and the CGE fee.


2. Managers or approving officials should review the TMC itinerary or invoice attached to the voucher to determine how the transportation ticket was purchased. Expenses charged to the CBA should not be approved for reimbursement to the traveler. Information is available on the IRS Source website.


**1.32.4.3.1.5** **(10-17-2012)**

##### Unused Tickets

1. If the CBA issued ticket is not used, the TMC will issue a refund automatically within 24 hours (no exchanges are permitted).


**1.32.4.3.1.6** **(07-30-2021)**

##### Ticket Cancellation

1. When the CBA is used to purchase common carrier transportation tickets and the trip is cancelled, the employee must promptly notify the TMC and Credit Card Services.



1. If an electronic ticket was issued using the CBA, the traveler must notify the TMC of the cancelled trip immediately and request issuance of a credit.

2. If the ticket has been invoiced, the ETS travel authorization must be left open.

3. If a paper ticket was issued, the traveler must notify the TMC of the cancelled trip immediately and return the paper ticket to the TMC. A credit will not be issued for the paper ticket until the ticket is returned to the TMC.


2. Travelers must notify Credit Card Services via an IRS Service Central ticket or by calling the ERC at 866–743–5748 (TTY: 866-924-3578) for assistance if a trip is cancelled. The traveler must provide the following information immediately after the trip is cancelled:



1. Original travel authorization number;

2. Date the TMC confirmed cancellation and/or date paper ticket was returned for refund; and

3. Travel dates.


**1.32.4.3.1.7** **(02-13-2026)**

##### Special Travel Considerations

1. **Last-minute travel** \- For last-minute travel, defined as Friday afternoon or weekend travel notification, the traveler may contact the TMC for transportation tickets. Travelers who do not have a travel card or have a travel card that is declining, may use the CBA. The TMC will issue the CBA ticket and notify Credit Card Services of the emergency issuance. The traveler must complete and the traveler’s manager or approving official must approve a travel authorization through ETS or on a manual travel authorization form.

2. **Travel expenses charged to another business unit** \- The traveler's manager or approving official is responsible for ensuring the traveler has provided the correct funding codes in ETS or on the manual travel authorization form. When travel is not being charged to the traveler's home organization, the correct funding codes must be obtained from the organization funding the travel.

3. **Disapproved (returned) CBA transportation requests** \- Current travel cardholders who selected CBA as the method of payment for transportation in ETS and were disapproved, must cancel the current transportation reservation and create a new reservation using their travel card.

4. **Airport travelers (reservation without ticket or no reservation)** \- Travelers who arrive at the airport during business hours without an airline ticket and who must use the CBA (due to having no travel card or their travel card was declined) may contact the TMC to secure a reservation. The traveler must then contact the Employee Resource Center (ERC) and request expedited assistance to obtain approval to use the CBA and acquire the transportation ticket.

5. **Invitational travel** \- The business unit will designate an IRS employee to serve as a representative for the invitational traveler. The designated IRS employee is responsible for making travel arrangements, completing the manual travel authorization form and notifying Credit Card Services (\*IRS CCS) of cancelled trips.

6. **Relocation travel** \- Tickets for common carrier transportation authorized for an IRS employee's spouse for travel associated with house hunting can be charged to the CBA. En-route common carrier transportation tickets authorized for the IRS employee's spouse or dependents can also be charged to the CBA. IRS employees should:



1. Ensure the relocation authorization provides for house hunting and en-route travel.

2. Contact the TMC to make reservations.

3. Complete the manual travel authorization form.


7. **Indirect Travel - Personal and Official Travel Combined**



1. Employees are not able to combine personal and official travel reservations in ETS. The ETS is for official government travel only.

2. Employees who combine personal travel with official travel must call Duluth at 866-442-9925. Duluth will book a one-way official travel fare for the portion of travel between the official station and temporary duty (TDY) station. This fare must be purchased with the employee’s individually billed government travel card account (IBA) or the centrally-billed account (CBA) if traveler hasn’t received their IBA. Duluth will also note the total cost of a round-trip official travel fare on the itinerary/invoice, to be used on Form 15278, Cost Comparison worksheet.

3. Duluth will then book the personal travel portion. The personal ticket must be a fully refundable fare open to the public; otherwise, if official travel is canceled the employee will be responsible for the non-refundable fare. Government contract fares may not be used for personal travel. The employee will be charged a non-reimbursable leisure fee. An additional fee applies for each ticket issued. Both the tickets and associated fees must be charged to a personal credit/debit card, the IBA or CBA may not be used for the personal portion of the trip.


8. **Official Travel Paid by Other Federal Agencies or Entity** \- Per IRM 1.32.11.10, Travel Payments from Other Federal Agencies, when an employee travels for another federal agency, the traveler has two options: Direct Reimbursement or Pay-In-Kind where the other agency/entity pays all expenses to the traveler.



1. Direct Reimbursement - The traveler completes an IRS ConcurGov authorization and voucher, no additional approval from Credit Card Services is needed.

2. Pay-In-Kind - The traveler must request and obtain approval prior to travel to use their IRS Government Travel Card from the director, Credit Card Services. An email request to \*IRS CCS mailbox with subject line: Request to Use IRS Government Travel Card - Travel for Another Agency/Entity must include the travelers:


       Name


       TDY location


       Travel period/dates of travel


       Agency or Entity traveling for


       Documentation of event


9. **Invitational Travel - Counsel employees** \- Counsel employees whose invitational travel is paid for by a 501(c)(3), under the relevant statutory, are exempt from the mandatory travel card requirements.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-004#addtoany "Show all")

A2A