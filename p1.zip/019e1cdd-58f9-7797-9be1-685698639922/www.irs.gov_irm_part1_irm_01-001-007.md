---
url: "https://www.irs.gov/irm/part1/irm_01-001-007"
title: "1.1.7 Independent Office of Appeals | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-007#main-content)

- 1.1.7  [Independent Office of Appeals](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201169344)
  - 1.1.7.1  [Chief of Appeals (AP)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201077728)
  - 1.1.7.2  [Appeals Headquarters](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201062208)
  - 1.1.7.3  [Communications](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201054944)
  - 1.1.7.4  [Collection Appeals (AP:CL)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201050272)
  - 1.1.7.5  [Examination Appeals (AP:EX)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201199808)
    - 1.1.7.5.1  [Area 9 - Appeals Team Case Leader (ATCL) Operations](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201190608)
  - 1.1.7.6  [Specialized Examination Programs and Referrals (AP:SEPR)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201187600)
    - 1.1.7.6.1  [Area 10 (E&G, TE/GE, INNSP, and AAS)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201182976)
    - 1.1.7.6.2  [Area 11 (International)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201178736)
    - 1.1.7.6.3  [Technical Guidance (TG)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201040864)
    - 1.1.7.6.4  [Technical Support](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201027920)
  - 1.1.7.7  [Operations Support (AP:OS)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201024784)
    - 1.1.7.7.1  [Business Systems Planning (BSP)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201021312)
      - 1.1.7.7.1.1  [Customer Programs and Operational Support (CPOS)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201017184)
      - 1.1.7.7.1.2  [Business Systems Planning Modernization Team](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201009984)
      - 1.1.7.7.1.3  [Business Systems Planning Case Management Team](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993201003312)
    - 1.1.7.7.2  [Education and Knowledge Management (E&KM)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200997088)
      - 1.1.7.7.2.1  [Learning and Education (L&E)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200993456)
      - 1.1.7.7.2.2  [Knowledge Management (KM)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200984592)
    - 1.1.7.7.3  [Human Capital and Finance (HC&F)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200977728)
    - 1.1.7.7.4  [Policy, Planning, Quality, and Analysis (PPQ&A)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200962672)
      - 1.1.7.7.4.1  [Policy, Planning and Analytics](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200957952)
      - 1.1.7.7.4.2  [Policy, Planning and Analytics – Collection (PPA-C)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200944112)
      - 1.1.7.7.4.3  [Policy, Planning and Analytics – Examination (PPA-E)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200937008)
      - 1.1.7.7.4.4  [Appeals Quality Measurement System (AQMS)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200929168)
  - 1.1.7.8  [Case Support (AP:CS)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200922304)
    - 1.1.7.8.1  [Account and Processing Support (APS)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200918864)
    - 1.1.7.8.2  [Shared Team of Administrative and Redaction Support (STARS)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200910800)
  - 1.1.7.9  [Alternative Dispute Resolution Program Management Office (ADR PMO)](https://www.irs.gov/irm/part1/irm_01-001-007#idm139993200903536)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 7. Independent Office of Appeals

* * *

## 1.1.7 Independent Office of Appeals

#### Manual Transmittal

June 03, 2025

#### Purpose

(1) This transmits revised IRM 1.1.7, _Organization and Staffing, Independent Office of Appeals_.

#### Material Changes

(1) Changed section title to Independent Office of Appeals.

(2) Revised IRM to reflect the new organizational titles, structure, roles and responsibilities resulting from the Independent Office of Appeals’ realignments and the Taxpayer First Act.

(3) Removed references to Case & Operations Support (COS) throughout this IRM and added Case Support (CS) and Operations Support (OS) due to organizational structure change.

(4) _IRM 1.1.7.1_, _Chief of Appeals_: Removed reference to simultaneous consideration of issues by Appeals and Competent Authority from dispute resolution methods.

(5) _IRM 1.1.7.2_, _Appeals Headquarters_: Added Executive Assistant, Management and Program Analysts, Case Support, and Alternative Dispute Resolution Program Management Office to list of individuals and functions reporting to the Chief of Appeals.

(6) _IRM 1.1.7.4_, _Collection Appeals_: Added Area 13 to this section to include new training area. Also added Tax Law Specialists under Director supervision.

(7) _IRM 1.1.7.6.1_, _Area 10_: Added Art Appraisal Services (AAS) and removed Penalty Appeals (PENAP) from this section.

(8) _IRM 1.1.7.6.2_, _Area 11 (International)_: Removed Art Appraisal Services (AAS) and renumbered from prior IRM 1.1.7.6.1.1. Provided examples of international tax issues in IRM 1.1.7.6.2(1) and updated responsibilities in IRM 1.1.7.6.2(2).

(9) _IRM 1.1.7.6.3_, _Technical Guidance (TG)_: Updated the role of the Director, Technical Guidance and removed abusive tax avoidance transactions from the list of specific programs. Removed duplicate information in (2) along with reference to compliance officers.

(10) _IRM 1.1.7.7_, **Operations Support**: Renamed Operations Support (OS) due to organizational change. Updated the role of OS to remove reference to Account and Processing Support (APS).

(11) _IRM 1.1.7.7.1_, _Business Systems Planning (BSP)_: Added additional information outlining BSP role and outlined the staffs reporting to the Director, BSP.

(12) Added new _IRM 1.1.7.7.1.2_ to outline the role of Business Systems Planning Modernization Team.

(13) Added new _IRM 1.1.7.7.1.3_ to outline the role of Business Systems Planning Case Management Team.

(14) _IRM 1.1.7.7.2.1_, _Learning and Education_: Removed reference to SABA and added Adobe Connect.

(15) _IRM 1.1.7.7.4_, _Policy, Planning, Quality & Analysis_: Removed reference to Alternative Dispute Resolution.

(16) _IRM 1.1.7.7.4.2_, _Policy, Planning and Analytics - Collection_: Removed reference to Alternative Dispute Resolution.

(17) _IRM 1.1.7.7.4.3_, _Policy, Planning and Analytics - Examination_: Removed reference to Alternative Dispute Resolution.

(18) Added new _IRM 1.1.7.8_ to outline the role of Case Support (CS), which includes Account and Processing Support (APS) and Shared Team of Administrative and Redaction Support (STARS).

(19) Added new _IRM 1.1.7.8.1_ to outline the role of Account and Processing Support (APS). Removed reference to uploading the Tax Court Calendar to the TAXCAL system.

(20) Added new _IRM 1.1.7.8.2_ to outline the role of the Shared Team of Administrative and Redaction Support (STARS).

(21) Added new _IRM 1.1.7.9_ to outline the role of the Alternative Dispute Resolution Program Management Office (ADR PMO).

(22) Removed references to Wage & Investment (W&I) and replaced with Taxpayer Services (TS) throughout this IRM.

(23) Replaced reference to Coordinated Industry Cases (CIC) with Large Corporate Compliance (LCC).

(24) _IRM 1.1.7.1_, _IRM 1.1.7.4_, _IRM 1.1.7.5_: Updated to comply with Executive Orders and Office of Personnel Management (OPM) memorandums regarding diversity, equity, inclusion (DEI) and gender.

(25) Updated links throughout this IRM.

(26) Made editorial changes throughout this IRM.

#### Effect on Other Documents

IRM 1.1.7, dated June 10, 2020, is superseded.

#### Audience

Independent Office of Appeals

#### Effective Date

(06-03-2025)

Steven M. Martin

Director, Operations Support

**1.1.7.1** **(06-03-2025)**

### Chief of Appeals (AP)

1. The mission of the Independent Office of Appeals (Appeals) is to resolve Federal tax controversies without litigation on a basis which is fair and impartial to both the Government and the taxpayer, promotes a consistent application and interpretation of, and voluntary compliance with, the Federal tax laws, and enhances public confidence in the integrity and efficiency of the Internal Revenue Service.

2. The Chief of Appeals reports to the Commissioner of Internal Revenue (IRS Commissioner) and is responsible for planning, managing, directing, and executing nationwide activities for Appeals.

3. To accomplish the mission, Appeals:



01. Works with the IRS Commissioner to ensure an independent Appeals process.

02. Develops and implements Appeals measures that balance customer satisfaction, employee satisfaction, and business results.

03. Manages Appeals human capital resources through a strategic Human Capital plan that articulates workforce needs and strategies to meet them.

04. Ensures that Appeals programs meet taxpayer requirements.

05. Assists Appeals customers in understanding the Appeals process and their rights by providing information through plain language publications, seminars, workshops, websites, and other products.

06. Provides taxpayers a variety of dispute resolution methods to resolve taxpayer disputes without litigation, including but not limited to conferences, correspondence, and alternative dispute resolution services including fast-track settlement, mediation, and early referral of issues to Appeals.

07. Provides taxpayers with an administrative appeal on disputes regarding requests made under the Freedom of Information Act.

08. Provides practitioners with an administrative appeals process regarding IRS determinations to withhold or remove electronic filing authorization.

09. Supports taxpayers’ needs for a high quality review of art object appraisals and evaluations along with providing expert witness testimony in litigated cases on art object appraisals and evaluations.

10. Conducts ongoing research to gather data regarding Appeals determination results and provides feedback to the IRS Operating Divisions as well as the functional divisions of Taxpayer Advocate Service (TAS) and Chief Counsel.


4. Cases handled for the IRS include:



01. Appeals of the decisions of business unit commissioners, generally involving income, profits, estate, gift, and excise tax (except those imposed on alcohol, tobacco, and firearms)

02. Docketed United States Tax Court cases under the jurisdiction of Appeals

03. Appeals of collection actions (liens, levies, seizures, and termination or rejection of installment agreements)

04. Offers-in-compromise

05. Trust fund recovery penalty appeals

06. Penalty appeals

07. Employment taxes

08. Refund claims

09. Over-assessments

10. Pension plans and exempt organizations


5. See [Appeals - Internal Revenue Service](https://www.irs.gov/appeals) for a link to the Appeals Organization Chart.


**1.1.7.2** **(06-03-2025)**

### Appeals Headquarters

1. The Chief of Appeals has functional responsibility for all headquarters operations in Appeals. The mission of headquarters is to provide strategic and operational support to field operations and technical services within Appeals to assist the Chief in accomplishing the Appeals mission. Headquarters will also interpret, modify as appropriate, and implement guidance issued by the IRS Commissioner.

2. The following individuals, functions, directors, and their staff report to the Chief of Appeals:



   - Deputy Chief of Appeals

   - Special Advisors

   - Executive Assistant

   - Management and Program Analysts

   - Staff Assistant

   - Collection Appeals

   - Examination Appeals

   - Specialized Examination Programs and Referrals

   - Operations Support

   - Case Support

   - Alternative Dispute Resolution Program Management Office


**1.1.7.3** **(06-10-2020)**

### Communications

1. Appeals’ communication efforts are overseen by the Chief’s staff and supported by representatives from the Communications and Liaison (C&L) function. The staff:



1. Facilitates effective communication with Appeals employees and other internal and external stakeholders.

2. Develops Appeals-wide internal communication strategies, plans, and messages.

3. Prepares speeches and briefing papers for the Chief/Deputy Chief of Appeals and serves as the Public Affairs contact.

4. Serves as a central point of contact for internal communications and media relations.

5. Manages Appeals’ internet and intranet websites including their content.


**1.1.7.4** **(06-03-2025)**

### Collection Appeals (AP:CL)

1. The mission of Collection Appeals is to provide operational support in meeting the Appeals Strategic Business Plan in a manner consistent with Appeals’ Mission and Vision Statements. Collection Appeals provides independent dispute resolution services to taxpayers.

2. Collection Appeals is geographically divided into four areas (Areas 1, 2, 3, and 4), with a fifth nationwide area (Area 13) that primarily serves as a training area for newly hired settlement officers. See the Collection Appeals Area Map posted on the Appeals website.

3. The Director is responsible for planning, managing, directing, and executing the nationwide Collection Appeals function in Appeals.

4. The Director supervises and is responsible for the activities of Area Directors, Senior Operations Advisors, Tax Law Specialists, and Technical Advisors. Collection Appeals is primarily staffed by Appeals settlement officers, also referred to as Appeals Technical Employees (ATE). ATEs consider a wide variety of collection cases from many sources, predominately IRS Collection-sourced cases. See _IRM 1.1.7.1 (4)_ for a list of some of the types of cases worked in Appeals.

5. To accomplish its mission, Collection Appeals:



1. Assists in the development of the overall Appeals strategy and goals to enhance compliance consistent with the Appeals Strategic Business Plan.

2. Manages human capital resources to ensure accomplishment of Appeals’ strategic goals.

3. Implements and provides feedback regarding Appeals policies and procedures.

4. Communicates and coordinates with all IRS Operating Divisions.

5. Maintains effective internal communications programs to keep employees informed of Appeals policies, procedures, IRS laws, and regulations.

6. Deploys resources where required to meet needs of taxpayers and internal customers.

7. Coordinates the advisory board meetings with Small Business / Self Employed (SB/SE) Collection.


**1.1.7.5** **(06-03-2025)**

### Examination Appeals (AP:EX)

1. The mission of Examination Appeals is to provide operational support in meeting the Appeals Strategic Business Plan in a manner consistent with Appeals’ Mission and Vision Statements. Examination Appeals provides independent dispute resolution services to taxpayers.

2. Examination Appeals is geographically divided into four areas (Areas 5, 6, 7, and 8), and one national area (Area 9) that handles team cases (discussed below, in _IRM 1.1.7.5.1_, _Area 9 - Appeals Team Case Leader (ATCL) Operations_). See the Examination Appeals Area Map posted on the Appeals website.

3. The Director is responsible for planning, managing, directing, and executing the nationwide Examination Appeals function in Appeals. Examination Appeals is primarily staffed by Appeals officers, also referred to as ATEs. ATEs consider a wide variety of examination cases from many sources, predominately IRS Examination-sourced cases. See _IRM 1.1.7.1 (4)_ for a list of some of the types of cases worked in Appeals.

4. To accomplish the mission, Examination Appeals:



1. Assists in the development of the overall Appeals strategy and goals to enhance compliance consistent with the Appeals Strategic Business Plan.

2. Manages human capital resources to ensure accomplishment of Appeals’ strategic goals.

3. Implements and provides feedback regarding Appeals policies and procedures.

4. Communicates and coordinates with all IRS Operating Divisions.

5. Maintains effective internal communications programs to keep employees informed of Appeals policies, procedures, IRS laws, and regulations.

6. Deploys resources where required to meet needs of taxpayers and internal customers.

7. Coordinates the advisory board meetings with Large Business & International (LB&I) and SB/SE (Exam).


**1.1.7.5.1** **(06-03-2025)**

#### Area 9 - Appeals Team Case Leader (ATCL) Operations

1. The Area Director, Area 9, reports to the Director, Examination Appeals, and coordinates a nationwide program with responsibility for the largest cases in Appeals, generally Large Corporate Compliance (LCC) and Industry Cases (IC) with multiple complex tax issues with over $10 million dollars in dispute.

2. See IRM 8.7.11, _Technical and Procedural Guidelines - Working Appeals Team Cases_, for more information on ATCL Operations and team cases.


**1.1.7.6** **(06-03-2025)**

### Specialized Examination Programs and Referrals (AP:SEPR)

1. The Director, Specialized Examination Programs and Referrals (SEPR), is responsible for planning, managing, directing, and executing an inventory of specialized examination program cases, providing art valuation services and oversight of the Commissioner's Art Advisory Panel (Art Appraisal Services (AAS)), providing technical and procedural guidance to the field on domestic and international issues, and providing computational support to Appeals, Counsel and, in certain cases, Department of Justice attorneys.

2. This mission is accomplished through the Director, SEPR, Area Directors, and staff of:



   - Area 10 (Estate & Gift (E&G), Tax Exempt & Government Entities (TE/GE), Innocent Spouse (INNSP), and AAS)

   - Area 11 (International)

   - Technical Guidance

   - Technical Support


**1.1.7.6.1** **(06-03-2025)**

#### Area 10 (E&G, TE/GE, INNSP, and AAS)

1. The Area Director, Area 10, is responsible for planning, managing, directing, and executing nationwide specialized examination programs for Appeals. The four specialized examination programs in Area 10 include:



   - E&G: Responsible for planning, managing, directing, and executing the nationwide E&G case resolution operations for Appeals.

   - TE/GE: Responsible for planning, managing, directing, and executing the nationwide TE/GE case resolution operations for Appeals.

   - INNSP: Responsible for planning, managing, directing, and executing the nationwide Innocent Spouse case resolution operations for Appeals.

   - AAS: Responsible for reviewing fair market value claims on works of art and cultural property in cases under examination and administering the Commissioner's Art Advisory Panel.


**1.1.7.6.2** **(06-03-2025)**

#### Area 11 (International)

1. The Area Director, Area 11, is responsible for coordinating the Appeals International Program. International issues arise from overseas and cross-border activities of U.S. businesses and individuals as well as U.S. activities of foreign businesses and individuals. Examples of international tax issues are:



1. IRC 482 Transfer Pricing adjustments

2. Foreign earnings subject to U.S. income tax (e.g., Passive Foreign Investment Company, Global Intangible Low-Taxed Income, and Subpart F income)

3. International Information Returns (e.g., foreign trust and controlled foreign corporation reporting)

4. Tax Treaty related adjustments

5. Withholding on income received by foreign persons


2. The Appeals International Program is responsible for planning, managing, directing, and executing the nationwide international case resolution operations for Appeals and supporting resolution of cases with international issues managed by other Appeals divisions, which includes:



01. Directly working an inventory of international cases.

02. Recommending to the Director, SEPR, the designation and coordination of international issues as an Appeals Coordinated Issue (ACI) and whether ACIs require review and concurrence (ACI-RC).

03. Recommending to the Director, SEPR, settlement positions on significant international issues, industries, schemes and shelters with nationwide impact that require coordination.

04. Developing Appeals settlement guidelines and positions to facilitate the timely and consistent settlement of coordinated international issues.

05. Providing ATEs with specialized information, research, and assistance on all coordinated international issues; providing issue specialists to serve as team members, consultants, or mediators for Appeals cases with international issues; providing review and concurrence for settlements proposed on ACI-RC international issues to ensure consistent resolution of similar cases.

06. Monitoring and reporting on the status of coordinated international issues.

07. Working with Compliance to oversee the use of Delegation Order 4-25 for international issues and reporting to the Director, SEPR, on its use and effectiveness for international issues.

08. Reviewing revenue procedures, revenue rulings, and other guidance drafted by Chief Counsel for publication.

09. Identifying international tax issues requiring legislative change or public clarification on IRS policies and procedures.

10. Maintaining oversight of IRM 8.7.3, _Technical and Procedural Guidelines, Domestic and International Operations Programs_.


**1.1.7.6.3** **(06-03-2025)**

#### Technical Guidance (TG)

1. The Director, Technical Guidance, is responsible for recommending to the Director, SEPR, the designation and coordination of issues. Certain issues that have Servicewide impact or importance are coordinated to ensure uniformity and consistency nationwide. Coordinated issues will generally include emerging issues, issues of first impression, or issues with evolving legal jurisprudence. Specific TG programs include:



   - Tax Equity and Fiscal Responsibility Act (TEFRA)

   - Bipartisan Budget Act of 2015 (BBA)

   - Engineering issues

   - Valuation assistance

   - Economists

   - Financial Products


2. TG:



01. Recommends to the Director, SEPR, settlement positions on significant Servicewide issues, industries, schemes, and shelters that require coordination..

02. Develops Appeals settlement guidelines and positions to facilitate the timely and consistent settlement of coordinated issues. Cases with the below designation are referred to technical specialists in SEPR.



       > - ACI
       >
       >        - ACI-RC

03. Provides ATEs with specialized information, research, and assistance on coordinated issues; provides issue specialists to serve as team members, consultants, or mediators for Appeals cases with coordinated and emerging issues; provides review and concurrence for settlements proposed by ATEs for coordinated issues to ensure consistent resolution of similar cases.

04. Monitors and reports on inventory and closures of coordinated issues and tax shelters.

05. Works with Compliance to oversee the use of Delegation Order 4-25 and reports to the Director, SEPR, on its use and effectiveness for domestic issues.

06. Participates in the Industry Issue Resolution (IIR) Program, which provides guidance to resolve frequently disputed or burdensome business tax issues that are common to a significant number of taxpayers.

07. Reviews revenue procedures, revenue rulings, and other guidance drafted by Chief Counsel for publication.

08. Identifies tax issues requiring legislative change or public clarification on IRS policies and procedures.

09. Maintains oversight of IRM 8.7.3, _Technical and Procedural Guidelines, Domestic and International Operations Programs._

10. Appeals TEFRA/BBA Team (ATT/BBA). ATT/BBA is responsible for coordinating and controlling certain TEFRA/BBA key case actions in Appeals.


**1.1.7.6.4** **(01-29-2018)**

#### Technical Support

1. The Director, Technical Support, is responsible for coordinating the Tax Computation Specialist function. Tax Computation Specialists (TCS) are responsible for completing tax computations and account summaries in accordance with the decisions and determinations of Appeals officers, ATCLs, Counsel and Department of Justice attorneys, and opinions of the Tax Court. TCS prepares settlement computations, Rule 155 computations, refund litigation computations, statements of account, notices of deficiency and other notices, and tentative computations. TCS also provides technical and accounting analyses of tax in some of the most difficult and complex cases in the tax arena, including certain protested and/or petitioned Joint Committee cases.


**1.1.7.7** **(06-03-2025)**

### Operations Support (AP:OS)

1. The Director, Operations Support, is responsible for designing, developing, and delivering short and long-range tax administration programs, policies, strategies, and objectives for the Appeals organization and monitoring their overall effectiveness.

2. The mission of Operations Support is accomplished through the combined staffs of:



   - Business Systems Planning (BSP)

   - Education and Knowledge Management (E&KM)

   - Human Capital and Finance (HC&F)

   - Policy, Planning, Quality and Analysis (PPQ&A)


**1.1.7.7.1** **(06-03-2025)**

#### Business Systems Planning (BSP)

1. The mission of the BSP organization is to represent Appeals’ interest in partnership with Information Technology (IT) to identify, plan, and manage delivery of business improvement opportunities and technology initiatives to support the fulfillment of Appeals’ strategic mission. BSP leads the Appeals IT investment portfolio planning process and ensures the delivery of Appeals’ needs through case and inventory management, software applications and systems support, technology implementation, IT security, and equipment management.

2. The mission is accomplished through the combined staffs of:



   - Customer Programs and Operations Support (CPOS)

   - Modernization

   - Case Management


**1.1.7.7.1.1** **(01-29-2018)**

##### Customer Programs and Operational Support (CPOS)

1. Customer Programs and Operational Support (CPOS) reports to the Director, BSP.

2. As a component of BSP, CPOS:



1. Provides business expertise to complement IT deployment of technology upgrades and changes.

2. Provides customer support for escalated and ongoing technology related issues.

3. Manages IT portfolio needs (hardware, software, support).

4. Liaises with IT on the best way to use existing and new technology.

5. Monitors and tracks the security, testing, and evaluation of Appeals’ major application, Appeals Centralized Database System (ACDS), in accordance with Federal Information Systems Management Act (FISMA) requirements.

6. Works in partnership with IT Applications Development and IT Enterprise Operations, which are the principal designers and maintainers of ACDS.

7. Supports security and privacy awareness in Appeals and assures that employees understand requirements to encrypt sensitive data, protect IT assets and data, and report any losses or security breaches to appropriate authorities.

8. Provides account administration for Appeals systems, such as ACDS, which includes managing permissions, creating role-based profiles, and addressing the account needs of employees.

9. Oversees the Appeals SharePoint environment including governance, administration, access management, design, and site development.


**1.1.7.7.1.2** **(06-03-2025)**

##### Business Systems Planning Modernization Team

1. BSP Modernization Team reports to the Director, BSP.

2. As a component of BSP, the Modernization Team:



1. Manages, analyzes, evaluates, coordinates, and recommends changes to complex business systems projects across multiple agencies.

2. Analyzes business systems and prepares action plans and schedules for various phases of project accomplishment, both short and long-range; ensures that plans are consistent with IRS goals, schedules, and policies.

3. Assesses the impact of new programs and legislative changes on existing business systems and resources. Presents findings through consolidated status reports, oral presentations, memoranda, and other documents as required. Makes recommendations to management on resources for user acceptance testing.

4. Manages and administers user accounts for specific modernization, digitalization, or transformational projects, including Secure Messaging, as identified by BSP Leadership.

5. Develops business cases and work requests for information services via the Unified Work Request (UWR) process.

6. Facilitates the Appeals Prioritization Council (APC), which engages in a continual, cross-functional process that results in effective prioritization and risk assessment of Appeals Work Requests (AWR) for Appeals systems.

7. Makes recommendations to and advises the Appeals Advisory Council (AAC), Appeals Governance Board (AGB), and Appeals Risk Ambassador Team on requests to modify ACDS, and other IT related issues.


**1.1.7.7.1.3** **(06-03-2025)**

##### Business Systems Planning Case Management Team

1. Case Management Team reports to the Director, BSP.

2. As a component of BSP, Case Management Team:



1. Manages the operations, maintenance, and administration of case management systems and/or its applications.

2. Provides support and assistance to Appeals employees, other IRS business units, functions, and stakeholders concerning issues related to case management systems.

3. Evaluates and prioritizes systems for integration consideration and provides support to the business functions in launching new business practices by ensuring readiness activities are completed. Partners with IT on technological improvements for the business functions.

4. Improves business performance by collaborating with internal and external stakeholders in the identification, development, delivery, and maintenance of modernized business systems.

5. Develops improvement opportunities to achieve optimal digital transformation for continued modernized workflows and efficiencies to accelerate the IRS’s response to taxpayer and employees.

6. Identifies, plans, and implements process and workflow projects to improve quality, reduce costs, increase productivity, and improve cycle time to address operational and/or system issues.


**1.1.7.7.2** **(01-29-2018)**

#### Education and Knowledge Management (E&KM)

1. E&KM assists in achieving the Appeals mission and strategic/organizational goals by providing mission-related training to employees to optimize their learning, development, and job performance, and fostering a collaborative and innovative environment that sustains a skilled workforce.

2. The mission is accomplished through the combined staffs of:



   - Learning and Education (L&E)

   - Knowledge Management (KM)


**1.1.7.7.2.1** **(06-03-2025)**

##### Learning and Education (L&E)

1. The Learning and Education team manager (L&ETM) reports to the Director, E&KM. The L&ETM has overall responsibility for:



01. Performing strategic plan development to meet customer needs.

02. Developing training plans based on training needs assessments.

03. Performing training plan delivery planning with IRS University (IRSU) Learner Event Support (LES).

04. Overseeing curriculum/content design, development, and revisions for all modes of design and development following Training Development Quality Assurance System (TDQAS) (e.g., classroom, Adobe Connect, Interactive Video Training/Teleconference (IVT), Digital Video Disk (DVD)).

05. Overseeing the maintenance of course content on Integrated Talent Management (ITM).

06. Overseeing functional leadership program content and coordinating with leadership and cross-functional departments in meeting readiness and basic leadership training needs.

07. Overseeing and facilitating subject matter expert (SME) selections on course/product development projects, including training and educating SMEs on designing and developing performance based curricula/courses.

08. Coordinating and collaborating with Human Capital Office (HCO) IRSU staff on a variety of matters (e.g., Learning Content Management System (LCMS), ITM, Training Policy Development, Measures).

09. Supporting the National Association of State Boards of Accountancy (NASBA) Continuing Professional Education (CPE) Certified Public Accountant (CPA) accreditation for all appropriate technical courses through Large Business and International (LB&I).

10. Competitively announcing and selecting classroom instructors as well as virtual instructors.

11. Coordinates Front-Line and Senior Manager Readiness and Development programs in conjunction with HCO.

12. Provides guidance on succession planning.


**1.1.7.7.2.2** **(01-29-2018)**

##### Knowledge Management (KM)

1. KM staff fosters a collaborative and innovative environment that sustains a skilled workforce and supports Appeals’ mission through coordination and oversight of the Appeals Exchange (ApEx) SharePoint site. KM has overall responsibility for:



01. Overseeing content submission and maintenance of the ApEx knowledge libraries.

02. Ensuring 508 Compliance requirements are met for ApEx content.

03. Overseeing and monitoring knowledge retention questionnaires and activities.

04. Monitoring the Ask an Expert dashboard and ensuring established process is adhered to, including maintaining the SME Submission List, and seeking experts within Appeals if no SME is identified.

05. ApEx maintenance.

06. Calendar Updates.

07. News Updates.

08. Monitoring/responding to Provide Feedback.

09. Maintaining acronyms.

10. Maintaining Knowledge Outline.


**1.1.7.7.3** **(06-10-2020)**

#### Human Capital and Finance (HC&F)

1. HC&F provides strategic and tactical consultation and guidance on human capital issues, enabling Appeals leaders to make informed decisions that support our organizational goals. HC&F is responsible for documenting the strategic directions of programs and effectively planning for distribution and execution of Appeals financial resources.

2. HC&F:



01. Serves as the Appeals representative on the Human Capital Advisory Council.

02. Develops and implements policies, guidelines, and procedures for Appeals within parameters set by the HCO.

03. Serves as a liaison between Appeals managers and HCO to obtain human resources (HR) services (e.g., classification, position management, and recruiting and hiring support).

04. Provides administrative analysis and support to Appeals Headquarters (HQ) as requested.

05. Provides support to organizational improvement efforts by providing change management analysis and support for Appeals Strategic Programs.

06. Manages the Employee Engagement Program, including analysis and interpretation of the Federal Employees Viewpoint Survey (FEVS) results.

07. Provides coordination, advice, and analysis concerning Appeals-wide labor and employee relations issues.

08. Provides guidance on strategic recruitment and retention to Appeals HQ and the Appeals Field Operations.

09. Provides guidance in hiring and staffing issues (e.g., managerial competencies, HRConnect, and ad hoc staffing issues). Serves as liaison to HCO to ensure support on hiring initiatives, hiring templates, Standard Position Descriptions, and various HR reports.

10. Monitors the Office of Government Ethics (OGE) reporting requirements for Appeals. Provides oversight of the Section 1204 and OGE Reporting.

11. Provides oversight and guidance for the Health and Safety programs.

12. Maintains and updates the Occupant Emergency Plan (OEP) for Appeals HQ office.

13. Coordinates Appeals HQ security issues with Facilities Management and Security Services (FMSS).

14. Provides oversight and guidance for Appeals telework.

15. Provides guidance related to Single Entry Time Reporting (SETR) issues.

16. Secures the resources needed for Appeals to fulfill its mission and ensures the efficient and effective use of those resources.

17. Develops an integrated budget submission for the Appeals organization.

18. Informs Appeals management of the status of funds and provides them with the analysis needed for sound decision making.

19. Identifies workforce investments in other business units that will have an impact on the Appeals budget for the out-years. Appeals Finance costs out these investments through the Plan Development, Budget Formulation, and Budget Execution cycles.

20. Responds to inquiries from external stakeholders (Department of the Treasury, Office of Management and Budget, and Congress) on the Appeals budget.

21. Manages the financial resource distribution process with the development of a financial plan that supports and tracks the program priorities of Appeals. This includes resources for all of Appeals.

22. Establishes financial policies, procedures, and controls for Appeals in compliance with overall IRS guidelines and procedures.

23. Regularly provides labor projections to ensure Appeals stays within its allocated resources.

24. Provides oversight and program management of the internal controls and purchase card usage in Appeals.


**1.1.7.7.4** **(06-03-2025)**

#### Policy, Planning, Quality, and Analysis (PPQ&A)

1. The Director, PPQ&A, is responsible for providing technical and procedural guidance to the Appeals organization. PPQ&A establishes and maintains policies and standard procedures for Appeals work streams, and provides information regarding case work flow and organizational performance, and identifies and resolves issues that impact Appeals stakeholders. The Director, PPQ&A, manages strategic planning activities of Appeals, monitors workload trends, and develops overall goals and performance measures for Appeals. PPQ&A plans, implements, and coordinates the Appeals Quality Measurement System (AQMS), which monitors and evaluates the quality and effectiveness of Appeals programs.

2. The PPQ&A mission is accomplished through the combined staffs of:



   - Policy, Planning and Analytics - Collection (PPA-C)

   - Policy, Planning and Analytics - Examination (PPA-E)

   - AQMS


**1.1.7.7.4.1** **(06-10-2020)**

##### Policy, Planning and Analytics

1. Policy, Planning and Analytics – _Collection_ and Policy, Planning and Analytics – _Examination_ both have parallel roles and responsibilities for their assigned program areas. Policy, Planning and Analytics:



01. Provides support to Appeals as a main point of contact for policy and procedural issues.

02. Drafts and coordinates updates to existing Appeals-owned Internal Revenue Manuals (IRM), Delegation Orders and Policy Statements.

03. Serves as chief liaison to the Office of Servicewide Policy, Directives and Electronic Research (SPDER).

04. Oversees the Appeals Internal Management Document (IMD) program.

05. Creates and updates forms, publications, and notices originated by Appeals.

06. Participates on advisory boards and provides feedback loop data to IRS Operating Divisions and functions.

07. Provides managerial oversight on sensitive and confidential matters.

08. Conducts reviews of assigned program areas.

09. Initiates and assists with AWRs to improve the automated systems used in Appeals.

10. Promotes customer outreach and satisfaction by working with taxpayer groups and practitioner organizations.

11. Develops and implements measures for the Appeals function that balance customer satisfaction, employee satisfaction, and business results.

12. Provides coordinated and complete Appeals responses to Government Accountability Officer (GAO) and Treasury Inspector General for Tax Administration (TIGTA) reports.

13. Looks across the Appeals organization to identify trends and emerging issues and concerns within the LB&I, SB/SE, Taxpayer Services (TS), and TE/GE taxpayer segments.

14. Develops workload projections and assists Appeals HQ and Appeals Operations in identifying and implementing business plans tailored to workload and emerging issues originating from LB&I, SB/SE, TS, and TE/GE taxpayer segments.

15. Assists Appeals HQ and Appeals Operations in evaluating and improving existing processes, as well as developing new processes.

16. Analyzes and interprets customer satisfaction survey results and advises Appeals HQ and Appeals Operations of trends and issues identified.

17. Coordinates and provides oversight of the Appeals Strategic Plan, annual Program Letter (Organizational Priorities), the quarterly Business Performance Review, responses to IRS Oversight Board Operations Committee information requests, and periodic Appeals reports – both public and internal-use-only.

18. Participates in advisory board meetings with TAS.

19. Provides guidance on workforce planning.


**1.1.7.7.4.2** **(06-03-2025)**

##### Policy, Planning and Analytics – Collection (PPA-C)

1. The Policy, Planning and Analytics - Collection manager reports to the Director, PPQ&A.

2. Programs specific to Policy, Planning and Analytics - Collection include:



1. Serves as chief liaison and manages programs generated from the SB/SE and TS, Collection Operating Divisions, including Campus Compliance and Accounts Management for campus program issues.

2. Provides oversight and policy guidance in the negotiation and settlement of SB/SE and TS collection disputes.

3. Provides technical review of IMDs (e.g., IRMs, forms, interim guidance) for consistency with Appeals procedures.

4. Provides assistance and support to APS employees and managers, and other IRS functions and stakeholders concerning issues related to the processing of various types of cases.

5. Manages the Controlled Correspondence Program for inquiries related to Collection policy issues.

6. Manages the Multilingual Initiative Strategy Program for Appeals.

7. Assists the Appeals chief liaison with the TAS on matters involving the Service Level Agreement and other collection related matters.

8. Serves as chief liaison for Appeals Policy Collection during TIGTA and GAO audits.

9. Participates in the advisory board meetings with Collection Operating Divisions.


**1.1.7.7.4.3** **(06-03-2025)**

##### Policy, Planning and Analytics – Examination (PPA-E)

1. The Policy, Planning and Analytics - Examination manager reports to the Director, PPQ&A.

2. Programs specific to Policy, Planning and Analytics - Examination include:



1. Serves as chief liaison and manages programs generated from LB&I, SB/SE (Exam), TS (Exam), and TE/GE Operating Divisions, including Campus Compliance and Accounts Management, for campus program issues.

2. Provides oversight and policy guidance in the negotiation and settlement of LB&I, SB/SE, TS, and TE/GE examination disputes.

3. Provides technical review of IMDs (e.g., IRMs, forms, interim guidance) for consistency with Appeals procedures.

4. Manages the Controlled Correspondence Program for inquiries related to Examination Appeals policy issues.

5. Manages the Controlled Correspondence Program for inquiries related to LB&I, SB/SE (Exam), TE/GE, and Alternative Dispute Resolution (ADR) policy issues.

6. Assists the Appeals chief liaison with the TAS on matters involving the Service Level Agreement and other examination related matters.

7. Serves as chief liaison for Appeals Policy Exam during TIGTA and GAO audits.

8. Serves as the Appeals liaison with the Office of Professional Responsibility (OPR).

9. Participates in the advisory board meetings with LB&I, SB/SE (Exam), TE/GE and Counsel.


**1.1.7.7.4.4** **(06-10-2020)**

##### Appeals Quality Measurement System (AQMS)

1. The AQMS Team Manager reports to the Director, PPQ&A. AQMS:



1. Coordinates a portion of the Feedback Loop Program for Appeals for qualitative balanced measures.

2. Performs closed reviews on a statistically valid random sample of all cases closed by Appeals using Appeals Quality Standards and Attributes.

3. Evaluates Appeals case work (e.g., sample reviews, special issue reviews, large case process reviews) to determine whether conclusions reached by Appeals are consistent with tax law, procedures and policy requirements and appropriate to the case resolution and settlement.

4. Analyzes and interprets supporting documents and distributes data to Area Directors and managers.

5. Identifies ways to improve the quality review process and AQMS report development, and implements new processes and improvements when appropriate.

6. Assists Area Directors and managers in accomplishing program goals and solving case related problems.

7. Assists in the review of TAS Report to Congress, and TIGTA and GAO Audit Reports.

8. Coordinates with Planning, Quality, and Analysis to address issues pertaining to the effectiveness of AQMS programs and practices.

9. Manages the AQMS website, providing information about the purpose of AQMS, its rating system, results of case reviews, and recommendations to improve the appeals process.


**1.1.7.8** **(06-03-2025)**

### Case Support (AP:CS)

1. The mission of Case Support is to provide operational support in meeting the Appeals Strategic Business Plan in a manner consistent with Appeals’ Mission and Vision Statements.

2. The mission is accomplished through the combined staffs of:



   - APS

   - Shared Team of Administrative and Redaction Support (STARS)


**1.1.7.8.1** **(06-03-2025)**

#### Account and Processing Support (APS)

1. APS is responsible for accurately controlling and timely processing cases in Appeals and Counsel’s jurisdiction. APS performs a full range of processing actions including adjustments, assessments, manual refunds, and abatements for all types of cases controlled by the Audit Information Management System (AIMS), ACDS, and Processing Employee Automated System (PEAS), which is a sub-system of ACDS. APS is comprised of three areas:



   - APS Collection

   - APS Examination

   - APS Specialty Programs


2. APS:



1. Cards cases on ACDS.

2. Identifies and tracks docketed U.S. Tax Court cases using the Docketed Inventory Management System (DIMS), a sub-system of ACDS.

3. Processes various types of interim updates necessary to ensure the Appeals inventory control system reflects accurate and current data.

4. Closes and processes Appeals cases.

5. Provides support and assistance to Appeals employees and other IRS functions, stakeholders, and taxpayers concerning issues related to the control and processing of various types of cases.

6. Handles inquiries for every type of case: open, unassigned, assigned, closed, and not yet in Appeals.

7. Resolves cases closed from Appeals that have account related problems.


**1.1.7.8.2** **(06-03-2025)**

#### Shared Team of Administrative and Redaction Support (STARS)

1. STARS provides timely and accurate administrative services to all of Appeals and performs redaction of case files requested under the Taxpayer First Act.

2. STARS:



1. Provides database review assistance, including ACDS, Integrated Collection System (ICS), Account Management Services (AMS), Automated Lien System (ALS), Automated Trust Fund Recovery (ATFR), Public Access to Court Electronic Records (PACER), and Report Generation Software (RGS).

2. Secures transcripts from the Transcript Delivery System (TDS), Integrated Data Retrieval System (IDRS), and Automated Offer in Compromise (AOIC).

3. Provides mail support for telework employees.

4. Provides research for Statutory Notice of Deficiency (SNOD) and Certified Mail List (CML) requests.

5. Conducts special search requests for Service Center files.

6. Transfers cases on ACDS.

7. Provides manager support, including preparation of various reports, assistance with new hires, ConcurGov reviews, Operational Review support, SETR assistance, Electronic Employee Performance File (EPF) support, supply requests, meeting notes, and shipping labels.

8. Provides redaction support for Taxpayer First Act requests.

9. Provides redaction support for Respond Directly requests.


**1.1.7.9** **(06-03-2025)**

### Alternative Dispute Resolution Program Management Office (ADR PMO)

1. The mission of the ADR Program Management Office (PMO) is to oversee, administer, and promote IRS ADR programs in a manner that creates greater awareness, increases use, and ensures quality delivery of these programs to facilitate customer satisfaction and taxpayer issue resolution at the earliest stage.

2. The Director, ADR PMO, is responsible for planning, managing, and directing the nationwide ADR programs for Appeals.

3. To accomplish its mission, the ADR PMO:



01. Serves as a central, neutral point of contact for internal and external ADR program inquiries.

02. Receives and reviews all ADR requests sent to Appeals and coordinates assignment of ADR requests within Appeals.

03. Provides procedural guidance and assistance for ADR programs to ATEs and Appeals Team Managers and monitors the progress of ADR requests in Appeals.

04. Gathers and analyzes data on the usage trends and effectiveness of ADR programs.

05. Conducts periodic evaluations of the ADR programs to identify actions needed to improve their performance in achieving objectives.

06. Compiles and interprets feedback to improve employee and customer satisfaction with ADR programs.

07. Works with other Appeals functional areas and other IRS functions to create strategic plans for increasing awareness, knowledge, and use of ADR programs.

08. Works with other Appeals functional areas and other IRS Operating Divisions as appropriate to consider and develop procedural changes to improve ADR programs, ensuring their quality and effectiveness in resolving tax issues.

09. Coordinates and drafts content of IRM sections in IRM 8.26, _Alternative Dispute Resolution (ADR) Program_.

10. Works with Policy in Appeals and other IRS Operating Divisions where appropriate to coordinate revision of ADR Forms.

11. Reviews and updates ADR job aids and online resources.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-007#addtoany "Show all")

A2A