---
url: "https://www.irs.gov/irm/part1/irm_01-004-005"
title: "1.4.5 Corporate Tax Administration Tools | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-005#main-content)

- 1.4.5  [Corporate Tax Administration Tools](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056994568416)
  - 1.4.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056994591232)
    - 1.4.5.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056994584560)
    - 1.4.5.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056994581664)
    - 1.4.5.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056994579376)
    - 1.4.5.1.4  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056994576640)
    - 1.4.5.1.5  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993540512)
    - 1.4.5.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993530560)
  - 1.4.5.2  [Enterprise Research Program](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993527888)
  - 1.4.5.3  [Electronic Research](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993509696)
    - 1.4.5.3.1  [Electronic Research Advantages](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993504240)
  - 1.4.5.4  [Electronic Research Program Management](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993498288)
    - 1.4.5.4.1  [Accessing Electronic Research Tools](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993496560)
    - 1.4.5.4.2  [Electronic Research Training and Reference Material](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993494544)
  - 1.4.5.5  [Tax and Legal Research Contracts](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993487120)
  - 1.4.5.6  [Asset/Locator and Public Records Contracts](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993484160)
    - 1.4.5.6.1  [Local Contracts](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993480960)
    - 1.4.5.6.2  [Credit Bureau Information](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993477888)
    - 1.4.5.6.3  [Court Records through PACER](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993474112)
  - 1.4.5.7  [Contract Management](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993469536)
    - 1.4.5.7.1  [Contract Restrictions](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993467200)
      - 1.4.5.7.1.1  [Permissible Uses of Extracts from Commercial Research Services](https://www.irs.gov/irm/part1/irm_01-004-005#idm140056993464800)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 5. Corporate Tax Administration Tools

* * *

## 1.4.5 Corporate Tax Administration Tools

#### Manual Transmittal

January 08, 2025

#### Purpose

(1) This transmits revised IRM 1.4.5, Resource Guide for Managers, Corporate Tax Administration Tools.

#### Background

IRM 1.4.5 provides IRS managers with the background relating to delivery of corporate tax administration tools, where and how to access them, and related training materials.

#### Material Changes

(1) Throughout: Replaced references to Business Operating Division (BOD) with Business Unit (BU).

(2) _IRM 1.4.5.1_, Program Scope and Objectives: Clarified the Policy Owner and Program Owner of this IRM is the SPDER office under Strategy and Business Solutions (SBS) in RAAS.

(3) _IRM 1.4.5.1.3_, Roles and Responsibilities: Clarified the business units are responsible for providing ID administrators for electronic research tools.

(4) _IRM 1.4.5.1.4_, Program Controls: Deleted paragraph 3 regarding SPDER's role in local contracts. Each business unit is responsible for reviews of local electronic research services to ensure they are not duplicating existing contracts.

(5) _IRM 1.4.5.1.5_, Terms and Acronyms: Retitled subsection to reflect content.

(6) _IRM 1.4.5.2_, Enterprise Research Program: Deleted reference to batch processing as it is not included under the current electronic legal and research contract.

(7) _IRM 1.4.5.3_, Electronic Research: Added court records to list of electronic research materials.

(8) _IRM 1.4.5.4.2_, Electronic Research Training and Reference Material: Deleted reference to telephonic training as it is obsolete.

(9) _IRM 1.4.5.6_, Asset/Locator and Public Records Contracts: Added a cross reference to IRM 5.1.18, Locating Taxpayers and their Assets for guidance on use of asset locator tools.

(10) _IRM 1.4.5.6_, Asset/Locator and Public Records Contracts: Deleted reference to batch processing as it is not included under the current contract.

(11) _IRM 1.4.5.6.1_, Local Contracts: Reorganized content and paragraphs for clarity.

(12) _IRM 1.4.5.6.3_, Court Records through PACER: Deleted alpha list and added paragraphs 2 and 3 clarifying contract ownership and BU responsibilities.

(13) _IRM 1.4.5.6.3_, Court Records through PACER: Changed Online 5081 to Business Entitlement Access Request System (BEARS) for requesting access to PACER.

(14) _IRM 1.4.5.7.1.1_, Permissible Uses of Extracts from Commercial Research Services: Entire subsection revised to clarify copyright laws and restrictions to align with IRM 1.17.8.5, Copyright and Copyrighted Material. Removed the word regionalized for redundancy as it is considered local.

(15) Throughout: Removed links to internal sites per guidance received from the Office of Online Services (OLS), Privacy, Governmental Liaison and Disclosure (PGLD) and Information Technology (IT) on August 28, 2024.

(16) Throughout: Made editorial changes to clarify, reorganize and remove duplicate content. Incorporated plain language and updated grammar, titles, website addresses and references.

#### Effect on Other Documents

IRM 1.4.5, Resource Guide for Managers, Corporate Tax Administration Tools, dated December 2, 2020 is superseded.

#### Audience

This IRM is intended for IRS managers Servicewide.

#### Effective Date

(01-08-2025)

Holly A. Donnelly,

Director, Strategy and Business Solutions (SBS)

Research, Applied Analytics and Statistics (RAAS)

**1.4.5.1** **(01-08-2025)**

### Program Scope and Objectives

1. **Purpose**: This IRM section provides an overview of the program to purchase commercial research products and services to support tax administration activities.

2. **Audience**: All IRS managers involved in research and analysis of data to support tax administration activities.

3. **Policy Owner**: The Office of Servicewide Policy, Directives and Electronic Resources (SPDER), within Strategy and Business Solutions (SBS) - Research, Applied Analytics and Statistics (RAAS).

4. **Program Owner**: SPDER within SBS - RAAS is the program office responsible for overseeing the purchase of servicewide research products and services, and for providing guidance on the use of these tools. Each IRS organization is responsible for establishing personnel to administer login access for the tools.

5. **Primary Stakeholders**: All IRS organizations


**1.4.5.1.1** **(04-11-2019)**

#### Background

1. Prior to the existence of SPDER, individual IRS organizations were each maintaining their own separate electronic research contracts (often with the same vendor).

2. In 1999, the Commissioner recognized a need to centralize electronic research contracts to create the capability for all IRS business units to conduct electronic tax law research, foster better collaboration of research efforts across the service and to significantly reduce research costs. On December 22, 1999, the Office of Servicewide Policy, Directives and Electronic Research (SPDER) officially stood up as an organization. The name was subsequently changed to Servicewide Policy, Directives and Electronic Resources. SPDER strategically designs, delivers, and manages a set of tax administration and knowledge tools to enable IRS employees to meet their responsibilities for enforcement compliance, and customer service.


**1.4.5.1.2** **(04-11-2019)**

#### Authority

1. IRS Restructuring and Reform Act of 1998 (RRA 98).

2. Policy Statement 1-3 governs IRS research activities. The guidance in this IRM section conforms with Policy Statement 1-3 establishing the foundation for research in the IRS to improve operations and decision-making through the service.


**1.4.5.1.3** **(01-08-2025)**

#### Roles and Responsibilities

1. The Director, Strategy and Business Solutions, is the program manager for SPDER.

2. SPDER, in a stewardship role, provides oversight of the enterprise strategy for delivering electronic research tools.

3. Each BU is responsible for authorization and password assistance for accessing electronic research tools including user login and password administration. ID administrators create and maintain IDs. They aid users when called upon.


**1.4.5.1.4** **(01-08-2025)**

#### Program Controls

1. Electronic Research Oversight Council (EROC) is comprised of representatives from each business unit, including Chief Counsel. The EROC is chartered to provide a strategic direction for the identification and delivery of tax administration tools. This group provides a forum for business unit collaboration on the delivery of research services to employees.



1. The EROC members list is posted on ReferenceNet.

2. The EROC serves as a decision-making body and makes recommendations on electronic research issues, including product content and features, training, and problem resolution.


2. SPDER requires quarterly reports from each electronic tax and legal research service provider documenting access, usage, training, and known issues.


**1.4.5.1.5** **(01-08-2025)**

#### Terms and Acronyms

1. The table lists commonly used acronyms and their definitions:



**Acronyms**






| **Acronym** | **Term** |
| --- | --- |
| BU | Business Unit |
| --- | --- |
| EROC | Electronic Research Oversight Council |
| RAAS | Research, Applied Analytics and Statistics |
| SPDER | Servicewide Policy, Directives and Electronic Resources |


**1.4.5.1.6** **(01-08-2025)**

#### Related Resources

1. The following are related resources:



   - Memorandum announcing the creation of the Office of Servicewide Policy, Directives and Electronic Research (SPDER), presently known as the Office of Servicewide Policy, Directives and Electronic Resources (SPDER), refer to SPDER Memo.

   - ReferenceNet website.


**1.4.5.2** **(01-08-2025)**

### Enterprise Research Program

1. The following table lists the types of research products and services available.




| **Category** | **Product** |
| :-: | :-: |
| Tax, Legal, Business, and News | - Internal Revenue Code<br>     <br>   - Income tax regulations<br>     <br>   - IRS administrative decisions<br>     <br>   - IRS forms<br>     <br>   - Internal Revenue Manual<br>     <br>   - Federal tax judicial decisions<br>     <br>   - Commercial tax services and tax related books<br>     <br>   - Treatises and periodicals and other non-tax legal, news, and business sources |
| Asset and Locator | - Credit bureau reports<br>     <br>   - Judgments<br>     <br>   - Verdicts<br>     <br>   - Liens<br>     <br>   - Bankruptcy data<br>     <br>   - Real property records<br>     <br>   - State incorporation and corporate officer/principal information<br>     <br>   - Corporate asset data<br>     <br>   - Department of Motor Vehicles (DMV) records where available |

2. All research products and services are available online.

3. SPDER is responsible for contract administration for all servicewide electronic research contracts except the credit bureau contracts owned by SB/SE.

4. Local Asset and Locator contracts which do not serve a servicewide audience are owned by the requesting business unit.


**1.4.5.3** **(01-08-2025)**

### Electronic Research

1. _Electronic Research_ is the use of computers to gather information needed to complete a full analysis of a tax return, whether as part of the audit process, collection process, or assistance process. Electronic research includes the following categories of material:



1. Asset and Locator

2. Business and News

3. Court records

4. IRS materials

5. Legal

6. Tax


Also see _IRM 1.4.5.2_.



**1.4.5.3.1** **(01-08-2025)**

#### Electronic Research Advantages

1. The quality of investigations has direct impact on fair and impartial administration of the tax laws, protection of taxpayer rights, and the collection of the proper revenue. IRS employees commonly use research to determine a defensibly _correct_ conclusion to a tax question.

2. Expanded access to electronic research improves the quality of cases, assists in the fair application of the laws, and helps front line employees resolve taxpayer questions.

3. Advantages to using electronic research are:



1. Immediate access to current procedures, forms, documents, agency decisions, regulations, related court cases as well as primary sources and secondary sources for tax-related research

2. Research time is reduced as well as resources spent traveling to libraries and courthouses

3. Accurate research results due to the ability to validate references

4. Consistent taxpayer treatment which improves business results

5. Improved casework


**1.4.5.4** **(04-11-2019)**

### Electronic Research Program Management

1. In a stewardship role, SPDER provides oversight of the enterprise strategy for delivering electronic research tools, much like FMSS or IT provides stewardship for other servicewide assets.


**1.4.5.4.1** **(01-08-2025)**

#### Accessing Electronic Research Tools

1. Access to Electronic Research tools often requires user IDs and passwords.

2. Instructions for requesting access, as well as links to these tools, are on ReferenceNet.


**1.4.5.4.2** **(01-08-2025)**

#### Electronic Research Training and Reference Material

1. Managers are responsible for ensuring employees have access to tax administration tools and receive training to use them.

2. Information on training is on ReferenceNet.

3. The following types of training are available:



1. _Classroom Training_ \- Provides training for either a general or specific audience

2. _Online Training_ \- Offers training at your computer with a live IRS or vendor instructor via web conference

3. _Computer Based Training_ \- Gives you the flexibility to review the modules you need when it's convenient for you

4. _Quick Reference Guides_ \- Help you get started with common tasks

5. _User Guides_ \- Provide detailed instructions on how to use various tools


**1.4.5.5** **(01-08-2025)**

### Tax and Legal Research Contracts

1. Current corporate tax and legal research services contracts provide IRS employees with access to primary and secondary federal tax, news, business, and legal sources.



### Note:



These products are linked to cited references, allowing access to all research material from one place.

2. SPDER's website, ReferenceNet, contains information on the research services contracts. See ReferenceNet.


**1.4.5.6** **(01-08-2025)**

### Asset/Locator and Public Records Contracts

1. Employees can research public records through the asset/locator tool. It provides easy access to public records such as real estate transactions, real property assessment information, vehicles, aircraft, as well as information on people and businesses.



### Caution:



Employees may not use asset/locator tools to search or browse for themselves, friends, relatives, celebrities, government officials, etc. Searching or browsing for these people is a violation of IRS policy as well as a misuse of government computer resources.

2. For guidance on use of asset locator tools see IRM 5.1.18, Locating Taxpayers and Their Assets.


**1.4.5.6.1** **(01-08-2025)**

#### Local Contracts

1. Local contracts may still be required for data that is unavailable from the servicewide contract vehicles. For example, in some states the Department of Motor Vehicles does not sell records to third-party vendors. Local contracts are largely funded by SB/SE; however, these funds are expected to cover all needs for local contracts, regardless of business unit or function.



### Note:



_IRM 1.4.5.7.1_, Contract Restrictions, provides the IRS policy for procuring electronic research services. It applies to the purchase of all local contracts. Business units must follow this policy when seeking to purchase services outside the servicewide contracts.


**1.4.5.6.2** **(07-08-2011)**

#### Credit Bureau Information

1. SB/SE owns the Servicewide contract for credit bureau data.

2. Under this contract full credit reports are only available to IRS employees working balance due cases. The Fair Credit Reporting Act requires this limitation. Credit reports can be a valuable source of information regarding an individual's addresses, assets, financial relationships, and judgment/lien information where available.

3. Additional details about the Credit Bureau Program and Fair Credit Reporting Act may be found in IRM 5.1.18, Locating Taxpayers and Their Assets and IRM 5.17.6, Legal Reference Guide for Revenue Officers, Summonses.



### Note:



IRS employees in Examination functions have to issue a summons to a credit bureau in order to obtain a taxpayer’s credit report.


**1.4.5.6.3** **(01-08-2025)**

#### Court Records through PACER

1. A servicewide interagency agreement provides IRS employees with Public Access to Court Electronic Records (PACER). Through PACER, users can access case and docket information from federal appellate, district and bankruptcy courts, and from the U.S. Party/Case Index.

2. PACER electronic research service is owned and funded by SB/SE.

3. Business units are responsible for monitoring usage to ensure IRS employees are using it for IRS work-related purposes and for ensuring costs are within the estimates provided.

4. If you do not have a PACER ID, you may request one using an online access request Business Entitlement Access Request System (BEARS).

5. More information on the agreement, funding, point of contact, as well as access to PACER is provided from the ReferenceNet website.


**1.4.5.7** **(01-08-2025)**

### Contract Management

1. SPDER manages the servicewide electronic research contracts which are set up at agency level with a single funding point for all delivery orders and requisitions.



### Exception:



SB/SE coordinates and manages the asset/locator contracts for local services and the national credit bureau contract.

2. Contracts are for multiple years, allowing IRS to purchase them at a consolidated bulk rate with a volume discount. This allows IRS to provide unlimited access to all employees who need to research, at a reduced cost per person.


**1.4.5.7.1** **(07-21-2016)**

#### Contract Restrictions

1. A key component of IRS' standardization of electronic research services is the intent to acquire, at the best value to the government, as much content for an ideal tax and legal reference library as possible through one source. Additional content will be obtained, as necessary, through existing avenues such as Fed link or GSA schedules.

2. Offices must obtain approval from SPDER before procuring commercial electronic research services, or training for these services


**1.4.5.7.1.1** **(01-08-2025)**

##### Permissible Uses of Extracts from Commercial Research Services

1. Copyright laws and restrictions apply to electronic research vendor data and its use.

2. Existing IRS electronic research contracts allow the IRS to:



1. Copy, download, and distribute materials for internal use

2. Copy and insert legal source materials in IRS training materials

3. Copy materials for their case file and share them with reviewers and taxpayers in performing their job


### Note:

Legal source materials include Court cases, statutory or regulatory documents, administrative guidance like Revenue Rulings, Procedures, Notices. For any questions on current IRS electronic research contracts contact SPDER.

3. Copying or downloading materials from other sources, require explicit permission from SPDER.

4. Employees may create links to copyrighted material.

5. When referencing content, link directly to the source. Do not download and post a stand-alone copy of legal source documents to internal web sites. By linking to the source document you will ensure it is current.

6. For more information on copyrighted material refer to IRM 1.17.8.5, Copyright and Copyrighted Material.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-005#addtoany "Show all")

A2A