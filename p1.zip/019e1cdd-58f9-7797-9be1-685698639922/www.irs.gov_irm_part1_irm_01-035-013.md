---
url: "https://www.irs.gov/irm/part1/irm_01-035-013"
title: "1.35.13 Administrative Waiver | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-035-013#main-content)

- 1.35.13  [Administrative Waiver](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883277504)
  - 1.35.13.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584888108944)
    - 1.35.13.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584888103504)
    - 1.35.13.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883305872)
    - 1.35.13.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883294384)
      - 1.35.13.1.3.1  [Debtors Seeking Relief](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883287552)
      - 1.35.13.1.3.2  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854963808)
      - 1.35.13.1.3.3  [Senior Associate CFO for Financial Management (FM) and Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854958016)
      - 1.35.13.1.3.4  [Travel Management](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854954624)
      - 1.35.13.1.3.5  [Worklife and Leave Sharing Office, HR Shared Services, HCO](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854950144)
      - 1.35.13.1.3.6  [Government Payables and Funds Management Office](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854946256)
      - 1.35.13.1.3.7  [Director, HR Shared Services, HCO and Deputy Director, HR Shared Services, HCO](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854941072)
      - 1.35.13.1.3.8  [Director, Policy and Audits, HCO](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883273888)
      - 1.35.13.1.3.9  [Austin Payroll Center](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883270624)
      - 1.35.13.1.3.10  [Associate Chief Counsel (Finance & Management)](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883265952)
      - 1.35.13.1.3.11  [Deputy Chief Counsel (Operations)](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883260816)
    - 1.35.13.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883258976)
    - 1.35.13.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584883252592)
    - 1.35.13.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854935328)
    - 1.35.13.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854916688)
    - 1.35.13.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854903984)
  - 1.35.13.2  [General Waiver Requirements](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854900000)
    - 1.35.13.2.1  [Evaluation Criteria](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854890096)
    - 1.35.13.2.2  [Waiver Approvals and Denials](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854883280)
  - 1.35.13.3  [Waiver Request for Pay and Allowances](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854870752)
    - 1.35.13.3.1  [Waiver Request Submission](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854867888)
  - 1.35.13.4  [Waiver Request for Travel, Transportation, Relocation Expenses and Allowances](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854839712)
    - 1.35.13.4.1  [Waiver Request Submission](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854836048)
  - 1.35.13.5  [Waiver Request for Government Funded Training and Student Loan Repayments](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854818528)
    - 1.35.13.5.1  [Waiver Request Submission](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854815488)
  - 1.35.13.6  [Appealing the Denial of Waiver Requests for Pay and Allowances, Travel, Transportation, Relocation Expenses and Allowances](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854800480)
  - 1.35.13.7  [Appealing the Denial of Waiver Requests for Government Funded Training and Student Loan Repayments](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854766608)
  - 1.35.13.8  [Department of the Treasury Role in Reviewing Waiver Requests and Appeals](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854764928)
  - 1.35.13.9  [Treasury Reporting Requirements](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854762784)
  - 1.35.13.10  [Debtor’s Right to Withdraw a Request without Prejudice](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854748624)
  - 1.35.13.11  [Right to a Judicial Review](https://www.irs.gov/irm/part1/irm_01-035-013#idm140584854746064)

# Part 1. Organization, Finance, and Management

# Chapter 35. Financial Accounting

# Section 13. Administrative Waiver

* * *

## 1.35.13 Administrative Waiver

#### Manual Transmittal

July 23, 2024

#### Purpose

(1) This transmits revised IRM 1.35.13, Financial Accounting, Administrative Waiver.

#### Material Changes

(1) IRM 1.35.13.1.3.2, CFO and Deputy CFO, changed reference from Deputy Commissioner of Operations Support (DCOS) to Chief Operating Officer (COO) due to IRS leadership structure change.

(2) IRM 1.35.13.1.3.7, Director, HR Shared Services, HCO and Deputy Director, HR Shared Services, HCO, changed reference from DCOS to COO due to IRS leadership structure change.

(3) IRM 1.35.13.1.3.8, Director, Policy and Audits, HCO, changed reference from DCOS to COO due to IRS leadership structure change.

(4) IRM 1.35.13.1.7, Acronyms, added the acronym for Chief Operating Officer (COO).

#### Effect on Other Documents

IRM 1.35.13, dated June 30, 2023, is superseded.

#### Audience

All business units

#### Effective Date

(07-23-2024)

Teresa R. Hunter

Chief Financial Officer

**1.35.13.1** **(06-30-2023)**

### Program Scope and Objectives

1. Purpose: To provide policy and guidance for requesting a waiver or the appeal of a denied waiver from the collection of delinquent non-tax debts including but not limited to:



   - Erroneous payments of pay and allowances, travel, transportation or relocation expenses and allowances.

   - An employee or former employee’s breach of an agreement for government funded training.

   - An employee or former employee’s breach of an agreement for Student Loan Repayments.


This IRM also provides policies and guidance for approving or denying a waiver request.



2. Audience: All IRS employees, former employees, personal administrators for estates of former IRS employees and IRS personnel that manage the administrative waiver program.

3. Policy Owner: The CFO owns the policies herein.

4. Program Owners: CFO Government Payables and Funds Management office and the Human Capital Office (HCO).

5. Primary Stakeholders: The CFO, Chief Counsel and the HCO.

6. Program Goals: To ensure that requests for waivers and the appeals of denied waivers of non-tax debts are resolved equitably and timely.


**1.35.13.1.1** **(06-30-2023)**

#### Background

1. Under 5 USC, Section 5584, an authorized official may waive recovery of overpayments resulting from erroneous payment to an employee of (1) pay or allowances or (2) travel, transportation, or relocation expenses and allowances. Use of the waiver authority is discretionary on the part of the authorized official. An employee's overpayment debt may be waived in whole or in part. A waiver decision must be based on a finding that collection would be against equity and good conscience and not in the best interests of the United States. An erroneous payment for which collection is waived is deemed to be a valid payment.

2. The heads of Executive agencies have full authority to waive the overpayment debts owed to their respective agency regardless of the amount of the debt. The head of each Executive agency is responsible for establishing waiver policies and standards and determining levels of approval. Agency policies must be consistent with statutory requirements. All waiver requests must be directed to the agency that made the erroneous payment resulting in an overpayment debt.


**1.35.13.1.2** **(07-02-2021)**

#### Authorities

1. The authorities for this IRM include:



01. [5 United States Code (USC), Section 4108, Employee agreements; service after training](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partIII-subpartC-chap41-sec4108)

02. [5 USC, Section 5584, Claims for overpayment of pay and allowances, and of travel, transportation and relocation expenses and allowances](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partIII-subpartD-chap55-subchapVIII-sec5584/context)

03. [26 USC, Section 6050P, Returns relating to the cancellation of indebtedness by certain entities](https://www.govinfo.gov/app/details/USCODE-2011-title26/USCODE-2011-title26-subtitleF-chap61-subchapA-partIII-subpartB-sec6050P)

04. [31 USC, Section 3711, Collections and compromise](https://www.govinfo.gov/app/details/USCODE-2010-title31/USCODE-2010-title31-subtitleIII-chap37-subchapII-sec3711)

05. [31 USC, Section 3717, Interest and penalty on claims](https://www.govinfo.gov/app/details/USCODE-2010-title31/USCODE-2010-title31-subtitleIII-chap37-subchapII-sec3717)

06. [31 Code of Federal Regulations, Section 901.9, Interest, penalties and administrative costs](https://www.govinfo.gov/app/details/CFR-2011-title31-vol3/CFR-2011-title31-vol3-sec901-9)

07. [Treasury Directive 34-01, Waiving Claims Against Treasury Employees for Erroneous Payments](https://home.treasury.gov/about/general-information/orders-and-directives/td34-01)

08. [Administrative Procedure Act of 1946, P. L. 79-404, 60 Stat. 237, 5 USC Section 500 et. seq.](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partI-chap5-subchapI-sec500)

09. [Delegation Order 1-61, Authority to Waive Training Debts](https://www.irs.gov/irm/part1/irm_01-002-002#idm140695290891456)

10. [Delegation Order 1-15, Waiving Claims Against Current or Former Employees for Erroneous Payments](https://www.irs.gov/irm/part1/irm_01-002-002#idm140695290909056)


**1.35.13.1.3** **(06-30-2023)**

#### Responsibilities

1. This section provides responsibilities for:



01. Debtors seeking relief from a non-tax debt owed to the IRS

02. CFO and Deputy CFO

03. Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

04. Travel Management

05. Worklife and Leave Sharing Office, HR Shared Services, HCO

06. Government Payables and Funds Management Office

07. Director, HR Shared Services, HCO and deputy director, HR Shared Services, HCO

08. Director, Policy and Audits, HCO

09. Austin Payroll Center

10. Associate Chief Counsel (Finance & Management)

11. Deputy Chief Counsel (Operations)


**1.35.13.1.3.1** **(07-02-2021)**

##### Debtors Seeking Relief

1. Debtors, if desiring relief, are responsible for:



1. Submitting a written request for a waiver stating a justification for granting relief.

2. Attaching supporting documentation to the request.

3. Responding to requests for additional or supplemental information.


**1.35.13.1.3.2** **(07-23-2024)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for:



1. Overseeing the administrative waiver program.

2. Approving or denying requests for waiver of claims less than $7,500 for travel, transportation and relocation expenses and allowances, and student loan repayments.

3. Preparing and submitting to the Chief Operating Officer (COO), all waiver request packages for travel, transportation and relocation expenses and allowances and student loan repayments for review by the Deputy Assistant Secretary for Human Resources/Chief Human Capital Officer (DASHR/CHCO), Department of the Treasury, where the amount of relief is equal to or more than $7,500.

4. Preparing and submitting to the COO, the appeals of denied waiver requests for review and final decision by the DASHR/CHCO, Department of the Treasury, for travel, transportation and relocation expenses or allowances.


2. The CFO is solely responsible for:



1. Approving or denying requests for relief of employee or former employee debts that arise out of a breach of a government funded training agreement.


**1.35.13.1.3.3** **(06-30-2023)**

##### Senior Associate CFO for Financial Management (FM) and Associate CFO for Corporate Accounting

1. The Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting are responsible for:



1. Submitting to the CFO/Deputy CFO requests for waiver of claims for overpayments of travel, transportation and relocation expenses and allowances, government funded training and student loan repayments.

2. Forwarding to the CFO/Deputy CFO, appeals of denied waiver requests for review by the DASHR/CHCO, Department of the Treasury, of travel, transportation or relocation expenses and allowances.


**1.35.13.1.3.4** **(06-30-2023)**

##### Travel Management

1. Travel Management is responsible for:



1. Obtaining and validating supporting documentation, drafts of recommended actions, reports, files and registers, including the case folder memorandum, necessary for the deciding official to evaluate the waiver request for travel, transportation and relocation expenses and allowances.

2. Preparing and submitting waiver request packages and appeals of denied waiver requests to the Senior Associate CFO for Financial Management or Associate CFO for Corporate Accounting.

3. Providing quarterly reports on the status of pending requests submitted by IRS employees, former employees and the estates of former employees seeking relief from debts to the Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting.

4. Submitting a copy of the subsidiary register to the Government Payables and Funds Management office annually.


**1.35.13.1.3.5** **(06-30-2023)**

##### Worklife and Leave Sharing Office, HR Shared Services, HCO

1. Worklife and Leave Sharing Office is responsible for:



1. Obtaining and validating supporting documentation, drafts of recommended actions, reports, files and registers, including the case folder memorandum, necessary for the deciding official to evaluate the waiver request for Student Loan Repayments.

2. Preparing and submitting waiver request packages for travel, transportation and relocation expenses to the Senior Associate CFO for Financial Management or Associate CFO for Corporate Accounting .

3. Submitting a copy of the subsidiary register to the Government Payables and Funds management office annually.


**1.35.13.1.3.6** **(06-30-2023)**

##### Government Payables and Funds Management Office

1. The Government Payables and Funds Management office is responsible for:



1. Notifying current and former employees of erroneous payments relating to travel, transportation and relocation expenses and allowances, government paid training and student loan repayments.

2. Managing procedures for processing waiver requests by current or former employees and their estates.

3. Forwarding request for waiver of claims and appeals for denied waiver claims for travel, transportation or relocation expenses and allowances to Travel Management.

4. Processing results of waiver request decisions.

5. Issuing Form 1099-C, Cancellation of Debt.

6. Consolidating and reporting the Treasury-mandated Servicewide register of waiver activity.


**1.35.13.1.3.7** **(07-23-2024)**

##### Director, HR Shared Services, HCO and Deputy Director, HR Shared Services, HCO

1. The director, HR Shared Services, HCO and deputy director, HR Shared Services, HCO, are responsible for (excluding Chief Counsel employees):



1. Approving or denying requests for waiver of claims less than $15,000 for erroneous payments of pay and allowances.

2. Preparing packages for waiver of claims greater than $15,000 for COO submission to the DASHR/CHCO, Department of the Treasury.

3. Preparing appeal request packages for the director, Policy and Audits, HCO, when a waiver request for a claim for erroneous payments of pay and allowances that is less than $15,000 is denied.

4. Preparing appeal request packages for COO submission to the DASHR/CHCO, Department of the Treasury, when a waiver request for a claim for erroneous payments of pay and allowances that is $15,000 and greater is denied.

5. Providing information to the National Finance Center for issuance of Form 1099-C, Cancellation of Debt, when applicable.


**1.35.13.1.3.8** **(07-23-2024)**

##### Director, Policy and Audits, HCO

1. The director, Policy and Audits, HCO is responsible for:



1. Approving or denying requests for an appeal when a waiver request is denied for an erroneous payment of pay and allowances claim that is less than $15,000.

2. Preparing and submitting to the COO, all waiver request packages for review by the DASHR/CHCO, Department of the Treasury, where the debt is equal to or more than $15,000.


**1.35.13.1.3.9** **(06-30-2023)**

##### Austin Payroll Center

1. The Austin Payroll Center is responsible for:



1. Notifying an employee upon discovery of an erroneous payment of pay and allowances and following established collection policies and procedures.

2. Preparing quarterly status reports of pending requests submitted by IRS employees, former employees and the estates of former employees seeking relief from debts for erroneous payments of pay and allowances.

3. Maintaining a subsidiary register of waiver activity involving IRS employees and pertaining to debts for erroneous payments of pay and allowances.

4. Submitting a copy of the subsidiary register to the Government Payables and Funds Management office annually.

5. Overseeing payroll offsets.


**1.35.13.1.3.10** **(07-02-2021)**

##### Associate Chief Counsel (Finance & Management)

1. The Associate Chief Counsel (Finance & Management) is responsible for (Chief Counsel employees only):



1. Approving requests for waivers for erroneous payments of pay and allowances when the claim is less than $15,000.

2. Preparing waiver request packages for the Deputy Chief Counsel (Operations) for submission to the DASHR/CHCO, Department of the Treasury, for waivers of claims $15,000 or greater and appeals when a waiver request is denied for a claim of $15,000 or greater.

3. Submitting requests for appeal to the Deputy Chief Counsel (Operations) when a waiver request is denied for a claim that is less than $15,000.

4. Preparing quarterly reports and maintaining subsidiary registers on the status of pending requests and waiver activity of Chief Counsel employees seeking relief from debts.

5. Submitting a copy of the subsidiary register to the Government Payables and Funds Management office annually.


**1.35.13.1.3.11** **(07-02-2021)**

##### Deputy Chief Counsel (Operations)

1. The Deputy Chief Counsel (Operations) is responsible for approving or denying Chief Counsel employee appeals of a denied waiver request for a claim that is less than $15,000 for erroneous payments of pay and allowances.


**1.35.13.1.4** **(07-02-2021)**

#### Program Management and Review

1. Program reports: Officials will use activity and status reports to evaluate the effectiveness of how the administrative waiver program is managed.



1. Waiver status reports reflect the status of waiver requests and includes the total number and dollar amount of pending, denied and approved waiver requests.

2. A Treasury-mandated register of waiver activity that includes the number of waiver requests received and resolved, the dollar amount of the requests granted and other information. See IRM 1.35.13.3, Waiver Request for Pay and Allowances, for additional detail.


2. Program Effectiveness: The IRS has implemented program controls and reports which ensures all statutory and regulatory requirements are met. The reports substantiate that waiver requests and decisions are executed within established time frames as outlined in the debt letter. See IRM 1.35.13.1.5, Program Controls and IRM 1.35.13.9, Treasury Reporting Requirements for additional information.



1. Waiver status reports are prepared quarterly and provided to the Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting for review.

2. The Treasury-mandated register of waiver activity is prepared annually by no later than October 15 for the preceding fiscal year.

3. The responsible office will provide written notice of final action to the requester within 60 days of the receipt of the request. A memorandum is issued and forwarded to Government Payables and Funds Management. Government Payables and Funds Management will follow up with the deciding official for any delays over 60 days.


**1.35.13.1.5** **(07-02-2021)**

#### Program Controls

1. The following table shows the control and the control methods:




| **Control** | **Control Methods** |
| :-: | :-: |
| Case Reviews/Validations | All cases are reviewed for signatures and supporting documentation to ensure completeness of the waiver request.<br> The time required to complete the evaluation and decision of all waiver requests are recorded and verified to ensure timeframes established in IRM 1.35.13.1.4, Program Management and Review, are satisfied.<br> Complex cases and waiver requests seeking relief for amounts of $7,500 or greater involve consultation with GLS to ensure compliance with statutory requirements. |
| Documentation/Record Retention | The IRS maintains files on all waiver actions for deciding officials to refer to prior decisions and a register of all waiver activity, along with the pertinent details of all waiver requests, for a period of 6 years and 3 months. This retention period can facilitate a petitioner’s request for a judicial review in a U.S. Federal Court and aids in maintaining consistent practices over extended time. |


**1.35.13.1.6** **(06-30-2023)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Administrative debt** \- A non-tax debt resulting from administrative actions.

02. **Appeal** \- An administrative proceeding in which the responsible party requests higher level of management review of the debt.

03. **Debt** \- An amount of money, funds or property that has been determined by an agency official to be due to the United States from any person, organization or entity, except another federal agency.

04. **Debt collection** \- The recovery of non-tax debts owed to the IRS.

05. **Debtor** \- A person, organization or entity, except another federal agency, that owes an amount of money, funds or property to the United States.

06. **Deciding official** \- An individual who has authority to determine whether a requested waiver may be granted or denied and generally renders a decision..

07. **Delinquent****Debt** \- A debt status signifying that the amount owed was not paid by the date of the IRS initial billing notice unless other satisfactory payment arrangements have been made. [31 CFR 900.2, Definitions and Construction.](https://www.ecfr.gov/current/title-31/subtitle-B/chapter-IX/part-900/section-900.2)

08. **Erroneous payment** \- A payment made for which there is no legal justification.

09. **Overpayment** \- Any payment to an employee that is more than the amount owed to the employee.

10. **Pay and Allowances** \- Basic salary and any additional monetary benefits offered to the employee.

11. **Penalty** \- A punitive charge assessed on a delinquent debt. The rate is not to exceed 6% per year and is assessed on the portion of the debt remaining delinquent more than 90 days (Title 31, USC, Section 3717(e)(2)), Interest and penalty on claims.

12. **Principal** \- An amount owed by the debtor to the IRS, excluding interest, administrative costs, penalty, fees and prepaid charges.

13. **Restitution** \- Payment by a party causing a loss, damage or injury to the injured party to restore the injured party to the status existing before suffering the loss, damage or injury.

14. **Salary offset** \- The process of collecting a percentage or a set dollar amount of a debtor's current salary to help satisfy a delinquent non-tax debt.

15. **Waiver** \- In accordance with an appropriate statute, the cancellation, remission, forgiveness or non-recovery of a non-tax debt owed by a debtor to an agency, generally at the debtor's request.

16. **Waiver request** \- A petition seeking relief from paying a debt.


**1.35.13.1.7** **(07-23-2024)**

#### Acronyms

1. The following acronyms apply to this program:




| **ACRONYM** | **DESCRIPTION** |
| --- | --- |
| CFR | Code of Federal Regulations |
| CHCO | Chief Human Capital Officer |
| COO | Chief Operating Officer |
| DASHR | Deputy Assistant Secretary for Human Resources |
| DCFO | Deputy Chief Financial Officer |
| FM | Financial Management |
| GLS | General Legal Services (Chief Counsel) |
| GP&FM | Government Payables and Funds Management |
| HCO | Human Capital Office |
| USC | United States Code |


**1.35.13.1.8** **(07-02-2021)**

#### Related Resources

1. Related resources include:



1. [IRM 6.410.1, Learning and Education Policy](https://www.irs.gov/irm/part6/irm_06-410-001)

2. [Memorandum to IRS Commissioner from Deputy Assistant Secretary for Human Resources (DASHR) and CFO, Department of the Treasury, Delegation of Limited Waiver and Appeal Authority for Employee Salary Overpayments, dated March 17, 2009](https://portal.ds.irsnet.gov/sites/IRSSourceSearch/pages/results.aspx?k=delegation%20of%20limited%20waiver%20and%20apppeal%20authority#k=delegation%20of%20limited%20waiver%20and%20appeal%20authority)


**1.35.13.2** **(06-30-2023)**

### General Waiver Requirements

1. A debt may only be waived for:



1. An erroneous payment of pay and allowances, travel, transportation or relocation expenses and allowances.

2. An employee's non-compliance with the terms of a relocation service agreement.

3. An employee’s non-compliance with the terms of a government funded training or student loan repayment program. See IRM 6.410.1, Learning and Education Policy.


2. A waiver will not be granted where there is any proof of fraud, misrepresentation, fault or lack of good faith on the part of the debtor. Fault may exist if the debtor knew or should have known an error or omission existed. For example, the reimbursement of airport parking expenses in excess of the amount allowed under the Federal Travel Regulation and the underwithholding of health insurance premiums are situations in which the debtor should have known an error existed.

3. To avoid enforced collection action, debtors must submit a waiver request no later than 15 days from the receipt of the debt letter sent to the debtor for an erroneous payment of pay and allowances, travel, transportation or relocation expenses and allowances, government funded training or student loan repayment.

4. The debtor must provide a written justification for a waiver request along with supporting documentation, if any.

5. The debtor must include the following information for both the initial waiver request and any appeal:



1. Debtor’s name

2. Debtor’s SEID

3. Amount of debt

4. Amount requested to be waived

5. Reason or justification for the waiver request or appeal

6. Receipts, vouchers and supporting documents redacted to omit any social security numbers or bank account numbers.

7. Any additional documentation that supports the waiver request.


6. The IRS suspends collection of a debt during the waiver review process. All interest, penalty and administrative costs may continue to accrue and are added to the amount of the debt if the waiver request is denied.


**1.35.13.2.1** **(06-30-2023)**

#### Evaluation Criteria

1. Factors considered for a waiver of debt relating to pay and allowances, travel, transportation and relocation pay and allowances include but are not limited to:



1. Whether the debtor knew of or should have known of the erroneous payment.

2. The time elapsed between the erroneous payment, the subsequent discovery of the error and notification to the debtor.

3. Whether the debtor received an unearned benefit or was unduly enriched.

4. Whether the debtor has relinquished a valuable right or changed positions for the worse due to the erroneous payment.


2. Factors the IRS considers when evaluating a debtor’s waiver request of a government funded training debt or a student loan repayment include but are not limited to:



1. Whether the situation presents extenuating circumstances.

2. Whether the debtor could have foreseen or anticipated the situation.

3. Whether the debtor acted to mitigate the loss to the IRS (such as a timely withdrawal from the course where the debtor obtained a tuition refund).


3. See Treasury Directive Publication 34-01, Waiving Claims Against Treasury Employees for Erroneous Payments, for additional evaluation criteria.


**1.35.13.2.2** **(06-30-2023)**

#### Waiver Approvals and Denials

1. If either the IRS or Treasury’s DASHR/CHCO approves a waiver request:



1. The waiver is effective on the original date the debt occurred. This has the effect of negating accumulated interest, administrative fees and penalties.

2. The IRS refunds amounts already paid by the debtor (up to the amount of debt waived). Should only a portion of the debt be waived, the amount of accumulated interest, administrative fees and penalties charged will be pro-rated based on the amount not waived.

3. The IRS reports the amount of debt discharged on Form 1099-C, Cancellation of Debt, if such amount is $600 or more.


2. If either the IRS or Treasury's DASHR/CHCO denies a waiver request for an erroneous payment of pay and allowances, travel, transportation or relocation expenses and allowances or student loan repayment:



1. The debtor has the right to appeal the decision. See IRM 1.35.13.6, Appealing the Denial of Waiver Requests for Pay and Allowances, Travel, Transportation and Relocation Expenses and Allowances.

2. Suspension of the debt collection effort continues during the appeal process. If the appeal is denied, the IRS will initiate or resume collection of the debt amount, including interest, administrative fees and penalties that accrued during the waiver review process.


3. Waiver requests after IRS employment separation:



|     |     |
| --- | --- |
| Waiver request**denied** after separation from the IRS | Collection action enforced by offsetting any payments due the debtor or referral to Bureau of Fiscal Services |
| Waiver request **granted** after separation from IRS | All amounts collected toward debt (up to the amount waived) will be refunded to the debtor |
| Partial waiver granted after separation from IRS | Debtor is responsible for remaining debt balance to include accumulated interest, administrative fees and penalties on that remaining balance |


**1.35.13.3** **(06-30-2023)**

### Waiver Request for Pay and Allowances

1. Debtors may submit a request to waive the collection of a debt, in whole or in part, arising out of erroneous payment of pay and allowances.

2. Generally, waiver of an overpayment will not be approved if the debtor received a significant unexplained increase in pay or otherwise knew or reasonably should have known that an erroneous payment occurred and did not inquire or bring the matter to the attention of management.

3. For additional information about the waiver process for pay and allowances, contact the Employee Resource Center (ERC).


**1.35.13.3.1** **(06-30-2023)**

#### Waiver Request Submission

1. A debtor, excluding a Chief Counsel employee, may submit a written request for waiver from repayment of erroneous payments as follows:




| **Pay and Allowances**<br>**Current Employees, Former Employees and Their Estates (Excluding Chief Counsel Employees and the Estates for Those Who Worked for the Chief Counsel)** |
| :-: |
| **Amount of Claim** | **Address Waiver Request to:** | **Mail Waiver Request to:** |
| **Less than $15,000** | Director, HR Shared Services, HCO | Austin Payroll Center<br> HCO.APC.AdminDebt.Section@irs.gov or<br> EEfax to: (855) 846-8631 |
| **$15,000 or More** | DASHR/CHCO, Department of the Treasury |

2. Current and former Chief Counsel employees may submit a written request for waiver from repayment of erroneous payments as follows:




| **Pay and Allowances**<br>**Current Chief Counsel Employees, Former Chief Counsel Employees and the Estates for Those Who Worked for the Chief Counsel** |
| :-: |
| **Amount of Claim** | **Address Waiver Request to:** | **Mail Waiver Request To:** |
| **Less than $15,000** | Associate Chief Counsel (Payroll & Processing Section) | Internal Revenue Service<br> Payroll & Processing Section<br> 1111 Constitution Avenue NW<br> CC: F&M:HR:PPO RM4033<br> Washington, DC 20224 or<br> Fax to: (202) 317-4587 |
| **$15,000 or More** | DASHR/CHCO, Department of the Treasury |

3. The dollar amount of a claim due to an erroneous overpayment of pay and allowances is the sum of both the pay and the allowances overpayment.


**1.35.13.4** **(06-30-2023)**

### Waiver Request for Travel, Transportation, Relocation Expenses and Allowances

1. A debtor may submit a request to waive the collection of a debt, in whole or in part, arising from an erroneous payment of travel, transportation or relocation expenses and allowances.

2. Travel Management reviews each waiver request to ensure the debtor provided all required documentation. If not, Travel Management contacts the debtor to request the additional information.

3. Final approval authority is for either the CFO/DCFO or the Department of the Treasury, depending upon the dollar amount of the overpayment. The decision is based on the merits of each individual case.

4. For additional information about the waiver process for travel, transportation or relocation expenses and allowances, contact Government Payables and Funds Management at: CFO.BFC.Debt.Collection.Helpdesk@irs.gov.


**1.35.13.4.1** **(06-30-2023)**

#### Waiver Request Submission

1. A debtor, including Chief Counsel employees, may submit a written request for waiver from repayment of erroneous payments (relating to travel, transportation or relocation expenses and allowances) as follows:




| **Travel, Transportation, Relocation Expenses and Allowances**<br>**Current Employees, Former Employees and Their Estates (Including the Estates of Those Who Worked for the Chief Counsel)** |
| :-: |
| **Amount of Claim** | **Address Waiver Request to:** | **Mail Waiver Request To:** |
| **Less than $7,500** | DCFO | Internal Revenue Service<br> Beckley Office<br> ATTN: Debt Collection Unit<br> P.O. Box 9002<br> Beckley, WV 25802 or<br> cfo.bfc.debt.collection.helpdesk@irs.gov or<br> EEfax (855) 780-9044 |
| **$7,500 or More** | DASHR/CHCO, Department of the Treasury |

2. The amount of a claim due to an erroneous overpayment of travel, transportation or relocation expenses and allowances is the sum of the claims for:



1. The overpayment of travel expenses and allowances

2. The overpayment of transportation expenses and allowances

3. The overpayment of relocation expenses and allowances


**1.35.13.5** **(06-30-2023)**

### Waiver Request for Government Funded Training and Student Loan Repayments

1. A debtor may submit a request to waive the collection of a debt, in whole or in part, arising from a government funded training or student loan repayment.

2. A debtor must detail any extenuating circumstances for consideration which prevented the employee from successfully fulfilling the terms of government funded training or student loan repayment programs.

3. For additional information about the waiver process for Government Funded Training and Student Loan Repayments, contact Government Payables and Funds Management at: CFO.BFC.Debt.Collection.Helpdesk@irs.gov.


**1.35.13.5.1** **(06-30-2023)**

#### Waiver Request Submission

1. A debtor, including Chief Counsel employees, may submit a written request for waiver from repayment of Government Funded Training and Student Loan Repayments as follows:




| **Government Funded Training and Student Loan Repayments**<br>**Current Employees, Former Employees and Their Estates (Including Those Who Worked for the Chief Counsel)** |
| :-: |
| **Amount of Claim** | **Address Waiver Request To:** | **Mail Waiver Request To:** |
| **Less than $7,500** | DCFO | Internal Revenue Service<br> Beckley Office<br> ATTN: Debt Collection Unit<br> P.O. Box 9002<br> Beckley, WV 25802 or<br> cfo.bfc.debt.collection.helpdesk@irs.gov or<br> EEfax (855) 780-9044 |
| **$7,500 or More** | DASHR/CHCO, Department of the Treasury |


**1.35.13.6** **(06-30-2023)**

### Appealing the Denial of Waiver Requests for Pay and Allowances, Travel, Transportation, Relocation Expenses and Allowances

1. A debtor has the right to appeal the decision of a disapproved waiver request.

2. If either the IRS or the Department of the Treasury denies a waiver request, the office denying the request will advise the debtor of their right to appeal the denial.

3. Suspension of debt collection action continues during the appeal process. All interest, penalty and administrative costs may continue to accrue. Should the official evaluating the appeal sustain the denial of the waiver, the IRS either initiates or resumes collection of the debt amount, including all accrued interest, administrative fees and penalties.

4. The debtor must submit the appeal, in writing, no later than 60 calendar days after notification of denial of the waiver.

5. The debtor must include the following in the written appeal:



1. The basis for the appeal.

2. A chronological order of the events surrounding the erroneous payments.

3. A statement regarding any mitigating factors.

4. The original request for a waiver.

5. The deciding official’s denial of the original waiver request.

6. The deciding official’s conclusion for the basis of the denial.

7. Copies of any personnel actions (e.g. promotions, demotions, step increases, etc.) that relate to the overpayment.


6. A debtor, excluding Chief Counsel employees, may submit a written request appealing a disapproved waiver request for repayment of erroneous payment of pay and allowances as follows:




| **Pay and Allowances**<br>**Current Employees, Former Employees and Their Estates (Excluding the Estates of Those Who Worked for the Chief Counsel)** |
| :-: |
| **Amount of Claim** | **Address Appeal Request to:** | **Mail Appeal Request To:** |
| **Less than $15,000** | Director, Policy and Audits, HCO | Austin Payroll Center<br> HCO.APC.AdminDebt.Section@irs.gov or<br> EEfax to: (855) 846-8631 |
| **$15,000 or More** | DASHR/CHCO, Department of the Treasury |

7. Current and former Chief Counsel employees may submit a written request appealing a disapproved waiver request for repayment of erroneous payment of pay and allowances as follows:

8. A debtor, including Chief Counsel employees, may submit a written request appealing a disapproved waiver request for repayment of erroneous payments of travel, transportation, relocation expenses and allowances as follows:




| **Travel, Transportation, Relocation Expenses and Allowances**<br>**Current Employees, Former Employees and Their Estates (Including the Estates for Those Who Worked for the Chief Counsel)** |
| :-: |
| **Amount of Claim** | **Address Appeal Request to:** | **Mail Appeal Request To:** |
| **Any Dollar Amount** | DASHR/CHCO, Department of the Treasury | Internal Revenue Service<br> Beckley Office<br> ATTN: Debt Collection Unit<br> P.O. Box 9002<br> Beckley, WV 25802 or<br> cfo.bfc.debt.collection.helpdesk@irs.gov or<br> EEfax (855) 780-9044 |


**1.35.13.7** **(06-30-2023)**

### Appealing the Denial of Waiver Requests for Government Funded Training and Student Loan Repayments

1. There are no appeal rights for denied waivers of government funded training and student loan repayments.


**1.35.13.8** **(06-30-2023)**

### Department of the Treasury Role in Reviewing Waiver Requests and Appeals

1. Waiver requests and appeals of denied waiver requests for which the claim is above a specific dollar amount are sent to the DASHR/CHCO, Department of the Treasury, for review and a decision to approve the waiver or the appeal. See tables in IRM 1.35.13.3, Waiver Request for Pay and Allowances; IRM 1.35.13.4, Waiver Request for Travel, Transportation, Relocation Expenses and Allowances and IRM 1.35.13.5, Waiver Request for Government Funded Training and Student Loan Repayments.


**1.35.13.9** **(07-02-2021)**

### Treasury Reporting Requirements

1. Treasury Directive Publication 34-01, Section (b), Waiving Claims Against Treasury Employees for Erroneous Payments, states, "The heads of bureaus and the DASHR/CHCO shall maintain a register of waiver actions subject to Departmental review. The register must cover each fiscal year and be prepared annually by October 15th of each year for the preceding fiscal year."

2. The IRS maintains three separate subsidiary registers as follows:



1. The chief, Austin Payroll Center, maintains a subsidiary register pertaining to waiver actions for pay and allowances that involve IRS employees referred to as Subsidiary Register 1.

2. The director, Travel Management, maintains a subsidiary register pertaining to waiver actions for travel, transportation or relocation expenses and allowances involving IRS employees referred to as Subsidiary Register 2.

3. The Associate Chief Counsel (Finance & Management) maintains a subsidiary register pertaining to waiver actions for pay and allowances, travel, transportation or relocation expenses and allowances involving Chief Counsel employees referred to as Subsidiary Register 3.


3. Each subsidiary register must contain:



1. The total amount waived by the IRS or Chief Counsel.

2. The number and dollar amount of waiver applications granted in full.

3. The number and dollar amount of waiver applications granted in part and denied in part and the dollar amount of each.

4. The number and dollar amount of waiver applications denied in their entirety.

5. The number and dollar amount of the waiver applications referred to the DASHR/CHCO for initial action or for appeal.

6. The dollar amount refunded from a waiver action by the IRS or Chief Counsel.

7. The dollar amount refunded from a waiver action by the DASHR/CHCO or the assistant secretary for management.


4. The chief, Austin Payroll Center; the director, Travel Management and the Associate Chief Counsel (Finance & Management) are responsible for forwarding their subsidiary register to the director, Government Payables and Funds Management, no later than October 15.

5. The associate director, Austin Payroll Center; the director, Travel Management and the Associate Chief Counsel (Finance & Management) are responsible for retaining a written record of each waiver action listed in the subsidiary register for six years and three months after the close of the fiscal year in which the action was taken on the waiver. At a minimum, the written record must contain:



1. A summary of the events surrounding the erroneous payment.

2. Any written comments submitted by the debtor from whom collection is sought.

3. An account of the waiver action taken and the reasons for such action.

4. Any other pertinent information such as any action to refund amounts repaid.


**1.35.13.10** **(07-02-2021)**

### Debtor’s Right to Withdraw a Request without Prejudice

1. A debtor has the right to withdraw a debt waiver request at any time prior to a decision. A withdrawal of a debt waiver request does not prohibit the debtor from resubmitting the request at a later time. To avoid commencement of enforced collection action, the waiver request must be resubmitted within the period of time specified in the debt letter

2. Should a debt waiver request be withdrawn, collection effort on the debt will either be initiated or resumed.


**1.35.13.11** **(07-02-2021)**

### Right to a Judicial Review

1. If a petitioner for a waiver request believes he or she suffered legal wrong because of action of the Department of the Treasury, that petitioner is entitled to a judicial review of that action. This right, resulting from the Administrative Procedure Act of 1946 (P. L. 79-404, 60 Stat. 237), is codified at 5 USC Section 702. All administrative remedies must be exhausted prior to filing a suit with the U.S. District Court.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-035-013#addtoany "Show all")

A2A