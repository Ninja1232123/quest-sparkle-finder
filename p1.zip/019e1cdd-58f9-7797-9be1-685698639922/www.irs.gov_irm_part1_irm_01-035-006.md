---
url: "https://www.irs.gov/irm/part1/irm_01-035-006"
title: "1.35.6 Property and Equipment Accounting | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-035-006#main-content)

- 1.35.6  [Property and Equipment Accounting](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677272768)
  - 1.35.6.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677421504)
    - 1.35.6.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677418128)
    - 1.35.6.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677415248)
    - 1.35.6.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677202832)
      - 1.35.6.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677195840)
      - 1.35.6.1.3.2  [Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677194176)
      - 1.35.6.1.3.3  [Director, Financial Reporting and Analysis Office](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677192224)
      - 1.35.6.1.3.4  [Chief, Facilities Management and Security Services (FMSS)](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677189312)
      - 1.35.6.1.3.5  [Deputy Chief, FMSS](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677185984)
      - 1.35.6.1.3.6  [Office of the Chief Procurement Officer](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677183664)
      - 1.35.6.1.3.7  [Chief Information Officer](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677180528)
      - 1.35.6.1.3.8  [Program Manager, Information Technology User and Network Services (UNS), Operations Service Support](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677176400)
      - 1.35.6.1.3.9  [Chief, CI](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677174528)
      - 1.35.6.1.3.10  [CI Director, Field Operations](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677169504)
      - 1.35.6.1.3.11  [CI Field Offices](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677166496)
      - 1.35.6.1.3.12  [Criminal Investigation Management Information System Equipment Coordinator](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677164864)
      - 1.35.6.1.3.13  [Business Units](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677161104)
    - 1.35.6.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677159424)
    - 1.35.6.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677157024)
    - 1.35.6.1.6  [Terms and Definitions](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677152896)
    - 1.35.6.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677121616)
    - 1.35.6.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677101840)
  - 1.35.6.2  [Acquisition of Goods and Services](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677088192)
    - 1.35.6.2.1  [Shopping Cart Process](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677086512)
    - 1.35.6.2.2  [Procurement Process](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677084016)
    - 1.35.6.2.3  [Receipt and Acceptance Process](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677080880)
  - 1.35.6.3  [Recording Property and Equipment Transactions](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677079184)
  - 1.35.6.4  [Property and Equipment Capitalization](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677074848)
    - 1.35.6.4.1  [Information Technology Equipment](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677040496)
    - 1.35.6.4.2  [Non-IT Equipment](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677034480)
    - 1.35.6.4.3  [Furniture and Fixtures](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677027504)
    - 1.35.6.4.4  [Internal Use Software](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677025776)
    - 1.35.6.4.5  [Investigative or Forensic Equipment](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677012304)
    - 1.35.6.4.6  [Leasehold Improvements](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677010000)
    - 1.35.6.4.7  [Leases](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191677002912)
      - 1.35.6.4.7.1  [Lease Categories](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676987824)
      - 1.35.6.4.7.2  [Lease Asset and Liability](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676979536)
    - 1.35.6.4.8  [Treasury Franchise Fund](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676975136)
    - 1.35.6.4.9  [Vehicles](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676973344)
  - 1.35.6.5  [Physical Security Protection](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676970720)
  - 1.35.6.6  [Verification of IFS to KISAM](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676967856)
  - 1.35.6.7  [Maintenance, Repair and Rehabilitation](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676966064)
  - 1.35.6.8  [Impairment](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676958656)
  - 1.35.6.9  [Disposals](https://www.irs.gov/irm/part1/irm_01-035-006#idm140191676951168)

# Part 1. Organization, Finance, and Management

# Chapter 35. Financial Accounting

# Section 6. Property and Equipment Accounting

* * *

## 1.35.6 Property and Equipment Accounting

#### Manual Transmittal

June 28, 2024

#### Purpose

(1) This transmits revised IRM 1.35.6, Financial Accounting, Property and Equipment Accounting.

#### Material Changes

(1) IRM 1.35.6.1.1, (2), Background, added FASAB standards related to recording property and equipment.

(2) IRM 1.35.6.1.3.2, Changed Associate CFO for Financial Management and Deputy Associate CFO for Administrative Financial Management to Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting.

(3) IRM 1.35.6.1.3.5, Deputy Chief, FMSS, added deputy chief, FMSS, also assists the chief, FMSS, in directing the Division that provides nationwide facilities and security services for all IRS employees and manages approximately 23 million square feet of office space in approximately 519 buildings throughout the country. These services include real estate and project management, physical security or security, logistics services, and environmental and safety services.

(4) IRM 1.35.6.1.3.8, Program Manager, Information Technology UNS, Operations Service Support renamed subsection title from Program Manager, IT Service Asset and Configuration Management to Information Technology, UNS, Operations Service Support.

(5) IRM 1.35.6.1.3.8, Program Manager, Information Technology, UNS, Operations Service Support, deleted the following responsibilities:

- Providing oversight, coordination and guidance on the asset management of IT equipment Servicewide within KISAM.

- Performing analyses of the KISAM database and identifying anomalies.

- Maintaining business rules for asset management processes.

- Developing and improving asset management and control processes.

- Providing direction to asset owners and IT staff for property and equipment activities to strengthen asset management processes and controls.

- Ensuring accurate record-keeping in KISAM.


(6) IRM 1.35.6.3.12, (d), Criminal Investigation Management Information System Equipment Coordinator, replaced National Criminal Investigation Training Academy (NCITA) with Asset and Knowledge Management (AKM).

(7) IRM 1.35.6.1.6, Terms and Definitions, made the following revisions:

- Added Assisted Acquisitions

- Updated Capital Asset

- Deleted Capital Lease

- Deleted Deferred maintenance and repairs (DM&R)

- Added Intragovernmental Lease

- Added Lease

- Deleted Lease-purchase

- Deleted Operating Lease

- Added Probable

- Added Right-to-use Lease


(8) IRM 1.35.6.1.7, Acronyms, added the following acronyms:

- MGC, Material Group Code

- PE, Property and Equipment

- PCC, Product Category Code

- PPS, Procurement for Public Sector

- RTU, Right-to-use


(9) IRM 1.35.6.2.1, Shopping Cart Process, added reference to material group code (MGC).

(10) IRM 1.35.6.3,(a), Recording Property and Equipment Transactions, deleted Budgeting section reference.

(11) IRM 1.35.6.3,(c), Recording Property and Equipment Transactions, replaced capital leases with right-to-use leases.

(12) IRM 1.35.6.4, Property and Equipment Capitalization, updated to reflect SFFAS 54 requirements.

(13) IRM 1.35.6.4, Property and Equipment Capitalization, deleted Assets for capital lease from table.

(14) IRM 1.35.6.4, Property and Equipment Capitalization, added Right-to-use to table.

(15) IRM 1.35.6.4.1,(5), Information Technology Equipment deleted software capitalization criteria example.

(16) IRM 1.35.6.4.2,(1), Non-IT Equipment, replaced $5,000 with $10,000.

(17) IRM 1.35.6.4.4,(7), Internal Use Software, deleted sentence - Any IT or non-IT equipment purchased in conjunction with a capitalized IUS that is not an integral part of the IUS is treated separately; and replaced with Equipment purchased in conjunction with capitalized internally developed software as an integral part of the IUS is treated and depreciated, accordingly.

(18) IRM 1.35.6.4.4,(10),(a), Internal Use Software, deleted reference to estimated cumulative project costs over $50 million over the five-year period of performance.

(19) IRM 1.35.6.4.6,(5), Leasehold Improvements, added subsections 5, 5(a), and 5(b).

(20) IRM 1.35.6.4.7, Leases renamed subsection from “Assets under capital Leases” to “Leases”, and changed content to reflect SFFAS 54 updates.

(21) IRM 1.35.6.4.7.1, Lease Categories, added new subsection.

(22) IRM 1.35.6.4.7.2, Lease Asset and Liability added new subsection.

(23) IRM 1.35.6.4.9,(3), Vehicles, changed assets under capital lease to lease.

(24) Prior IRM 1.35.6.5.1, Inventory System, section deleted.

(25) IRM 1.35.6.8, Impairment, deleted paragraph, The IRS does not impair other general property and equipment per SFFAS No. 44, Accounting for Impairment of General Property, Plant, and Equipment Remaining in Use, as these assets are repaired, replaced, or disposed of when damaged or obsolete.

(26) IRM 1.35.6.5, Physical Security Protection, deleted reference to IRM 10.2.15 because IRM is obsolete.

(27) Prior 1.35.6.5.3, Physical Inventory, deleted section.

(28) IRM 1.35.6.6, Verification of IFS to KISAM, subsection title changed from “Reconciliation of IFS to KISAM”.

(29) IRM 1.35.6.9, Disposals, added reference to IRM 10.8.1, Information Technology (IT) Security, Policy and Guidance.

(30) Minor editorial changes were made throughout this document.

#### Effect on Other Documents

This IRM supersedes IRM 1.35.6, dated April 23, 2021. This IRM incorporates Interim Guidance Memorandum CFO-01-0923-0005, Interim Guidance for recognition of leases defined by SSFAS 54, dated November 20, 2023.

#### Audience

All business units.

#### Effective Date

(06-28-2024)

Teresa R. Hunter

Chief Financial Officer

**1.35.6.1** **(09-27-2019)**

### Program Scope and Objectives

1. Purpose: To provide policy and guidance for recording property and equipment transactions, ensuring data integrity and accountability.

2. Audience: All business units

3. Policy Owner: CFO

4. Program Owner: Financial Reporting and Analysis office

5. Primary Stakeholders: CFO and the IRS business units

6. Program Goals: To maintain internal controls to ensure accurate and timely accounting treatment for property and equipment according to Federal Accounting Standards Advisory Board (FASAB) standards and Office of Management and Budget (OMB), Treasury, and IRS guidance.


**1.35.6.1.1** **(06-28-2024)**

#### Background

1. In October 1990, the Secretary of the Treasury, the Director, Office of Management and Budget, and the Comptroller General established the FASAB by a memorandum of understanding (MOU). The FASAB standards are recognized as generally accepted accounting principles (GAAP) for the federal government.

2. The IRS records property and equipment at full cost in accordance with FASAB, Statement of Federal Financial Accounting Standards (SFFAS) 5, 6, 10, 44, and 54 (see IRM 1.35.6.1.8, Related Resources).

3. The IRS checks the useful life categories periodically to verify reasonableness.


**1.35.6.1.2** **(09-27-2019)**

#### Authorities

1. The authorities for property and equipment policies are:



1. [Chief Financial Officers Act of 1990](http://govinfo.library.unt.edu/npr/library/misc/cfo.html), Pub. L. No. 101-576

2. 40 USC 524, [Duties of Executive Agencies](http://www.gpo.gov/fdsys/pkg/USCODE-2011-title40/pdf/USCODE-2011-title40-subtitleI-chap5-subchapII-sec524.pdf)

3. [Federal Managers' Financial Integrity Act of 1982 (FMFIA)](https://obamawhitehouse.archives.gov/omb/financial_fmfia1982) Pub. L. No. 97-255

4. [E-Government Act of 2002](http://www.gpo.gov/fdsys/pkg/PLAW-107publ347/pdf/PLAW-107publ347.pdf), Pub. L. No. 107-347

5. 31 USC 3512, [Executive Agency Accounting and Other Financial Management Reports and Plans](https://www.govinfo.gov/app/details/USCODE-2010-title31/USCODE-2010-title31-subtitleIII-chap35-subchapII-sec3512/summary)

6. 41 CFR, [Public Contracts and Property Management](https://www.ecfr.gov/cgi-bin/text-idx?tpl=/ecfrbrowse/Title41/41tab_02.tpl), Chapters 101 and 102

7. 41 CFR Part 102-36, [Disposition of Excess Personal Property](https://www.ecfr.gov/cgi-bin/text-idx?tpl=/ecfrbrowse/Title41/41tab_02.tpl)


**1.35.6.1.3** **(09-27-2019)**

#### Responsibilities

1. This section assigns responsibilities for:



01. CFO and Deputy CFO

02. Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

03. Director, Financial Reporting and Analysis Office

04. Chief, Facilities Management and Security Services (FMSS)

05. Deputy Chief, FMSS

06. Office of Chief Procurement Officer (OCPO)

07. Chief Information Officer (CIO)

08. Program manager, IT Service Asset and Configuration Management (SACM)

09. Chief, CI

10. CI director, Field Operations

11. CI field offices

12. CI Management Information System (CIMIS) equipment coordinator

13. Business units


**1.35.6.1.3.1** **(09-27-2019)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for overseeing compliance with accounting policies for Servicewide property and equipment.


**1.35.6.1.3.2** **(06-28-2024)**

##### Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

1. The Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting are responsible for providing Servicewide property and equipment guidance to the business units and offices, and ensuring the proper recording of property and equipment transactions on the financial statements.


**1.35.6.1.3.3** **(09-27-2019)**

##### Director, Financial Reporting and Analysis Office

1. The Financial Reporting and Analysis office is responsible for:



1. Overseeing accounting procedures and internal controls for administrative property and equipment accounting.

2. Ensuring property and equipment transactions are accurately posted to the Asset Accounting Module (AAM).


**1.35.6.1.3.4** **(09-27-2019)**

##### Chief, Facilities Management and Security Services (FMSS)

1. The chief, FMSS, is responsible for setting Servicewide policies, procedures, standards and guidelines for purchasing and using furniture and equipment by:



1. Providing central oversight and guidance for managing property and equipment.

2. Planning, negotiating, executing and managing property and equipment procurement activities.

3. Conducting internal control reviews of property and equipment.


**1.35.6.1.3.5** **(06-28-2024)**

##### Deputy Chief, FMSS

1. The Deputy Chief, FMSS, is responsible for receiving, evaluating and disposing of foreign gifts, decorations and unconditional (in-kind) gifts tendered to IRS employees consistent with the Foreign Gifts and Decorations Act of 1966, amended (5 USC 7342) and Delegation Order 1-24 (FMSS Property and Asset Management Desk Guide). The Deputy Chief, FMSS, also assists the Chief, FMSS, in directing the Division that provides nationwide facilities and security services for all IRS employees and manages office space within its buildings throughout the country. These services include real estate and project management, physical security or security, logistics services, and environmental and safety services.


**1.35.6.1.3.6** **(09-27-2019)**

##### Office of the Chief Procurement Officer

1. The OCPO is responsible for establishing, maintaining and ensuring purchases are in accordance with [Federal Acquisition Regulations](https://www.acquisition.gov/), [Department of the Treasury procurement policy and regulations](https://www.treasury.gov/about/organizational-structure/offices/Mgt/Pages/ProcurementPolicy-Regulations.aspx), Internal Revenue Service Acquisition Policy (IRSAP), and Procedures, Guidance, and Information (PGI) documents.


**1.35.6.1.3.7** **(09-27-2019)**

##### Chief Information Officer

1. The CIO is responsible for:



1. Managing all IRS IT resources.

2. Delivering and maintaining modernized information systems throughout the IRS, including information security policies, procedures and control techniques to address system security planning and all applicable needs.

3. Ensuring information systems maintain an approved security plan, are authorized to operate and have the ability for reporting of all security-related activities.

4. Coordinating all policy issues related to information systems security including: computer security, telecommunications security, operational security, certificate management, electronic authentication, disaster recovery (DR) and critical infrastructure protection related to cyber threats.


**1.35.6.1.3.8** **(06-28-2024)**

##### Program Manager, Information Technology User and Network Services (UNS), Operations Service Support

1. The program manager, IT UNS, Operations Service Support, is responsible for overseeing and managing IT assets enterprise-wide that meets the established criteria set forth in the annual established Inventory Certification Plan.


**1.35.6.1.3.9** **(09-27-2019)**

##### Chief, CI

1. The chief, CI, is responsible for:



1. Maintaining and coordinating the inventory, control and accountability of all CI investigative and non-investigative equipment.

2. Establishing uniform rules and guidelines for CI equipment assignment, use, application and loan to maintain proper security and to prolong service life.

3. Providing an electronic extract of Criminal Investigation Management Information System (CIMIS) data to requestors.

4. Allocating CI equipment to field offices.

5. Fulfilling all roles of a property manager including records accountability.

6. Coordinating CI procurement requirements with the Procurement office.

7. Ensuring accurate asset record-keeping in CIMIS.


**1.35.6.1.3.10** **(09-27-2019)**

##### CI Director, Field Operations

1. The CI director, Field Operations, is responsible for:



1. Maintaining an accurate record of all investigative equipment, investigative accessories and investigative supplies assigned to the director, Field Operations.

2. Designating an area CIMIS equipment coordinator responsible for training new operators and providing aide to the field office equipment coordinators within their area.


**1.35.6.1.3.11** **(09-27-2019)**

##### CI Field Offices

1. The CI Field Offices are responsible for maintaining an accurate record of all investigative equipment.


**1.35.6.1.3.12** **(06-28-2024)**

##### Criminal Investigation Management Information System Equipment Coordinator

1. The CIMIS equipment coordinator is responsible for:



1. Ensuring information for access to CIMIS is provided by new users to the CIMIS user administrator.

2. Ensuring all users are aware of security procedures.

3. Offering all excess equipment to all other field offices before disposal.

4. Ensuring physical inventory of investigative equipment is completed, documented and reported to the Asset Knowledge Management (AKM) within the prescribed time frame in the fourth quarter of each fiscal year.


**1.35.6.1.3.13** **(09-27-2019)**

##### Business Units

1. The business units are responsible for complying with policies and procedures to requisition, purchase and safeguard property and equipment.


**1.35.6.1.4** **(09-27-2019)**

#### Program Management and Review

1. Program Reports - The IRS uses the Integrated Financial System (IFS) as its official financial system of record and reports the historical cost, depreciation and net book value of property and equipment in its annual financial statements according to FASAB, OMB, and Department of Treasury guidance.

2. Program Effectiveness - The effectiveness is measured by ensuring that all asset classifications are valid and recorded timely at the appropriate thresholds.


**1.35.6.1.5** **(09-27-2019)**

#### Program Controls

1. The Financial Reporting and Analysis office implements controls to ensure reasonable assurance that the property and equipment balances are accurate by:



1. Analyzing all property and equipment and certain expense transactions $50,000 and greater to verify they are classified correctly.

2. Reconciling property and equipment databases between AAM, KISAM and CIMIS.

3. Reconciling AAM to the general ledger.

4. Reviewing disposals.

5. Segregating duties and IFS access control.


**1.35.6.1.6** **(06-28-2024)**

#### Terms and Definitions

1. The following terms and definitions apply to this program.



01. **Acquisition cost** \- The original cost of an asset to the government, which is the amount recorded in the financial and accounting records. This includes all costs incurred to bring the asset to a form and location suitable for its intended use.

02. **Asset** \- Tangible or intangible items owned by the federal government that have probable economic benefits that can be obtained or controlled by a federal government entity.

03. **Assisted acquisitions** \- The original cost of an asset to the government, which is the amount recorded in the financial and accounting records. This includes all costs incurred to bring the asset to a form and location suitable for its intended use.

04. **Book value** \- The net amount at which an asset or a liability is carried on the books (also referred to as carrying value or amount). It equals the gross or nominal amount of an asset or liability minus any allowance or valuation amount.

05. **Capital asset** \- Structures, equipment, vehicles and intellectual property, that are used by the federal government and that have an estimated useful life of two years or more.

06. **Capitalize** \- To record a cost as an asset rather than an expense.

07. **Commercial Off-The-Shelf (COTS) software** \- Software that is bought from a vendor and is ready to use with little or no changes.

08. **Criminal Investigation Management Information System (CIMIS)** \- A database system used by Criminal Investigation (CI) to track asset management activities for the full life cycle of non-IT and sensitive law enforcement equipment from acquisition to disposal.

09. **Depreciation** \- The systematic and rational allocation of the acquisition cost of an asset, less its estimated salvage or residual value, over its estimated useful life.

10. **Direct costs** \- Costs assigned to activities by direct tracing of units of resources consumed by individual activities. A cost that is specifically identified with a single cost object.

11. **Indirect costs** \- Costs that cannot be identified specifically or traced to a given cost object economically.

12. **Impairment** \- A significant and permanent decline in the service utility of general property and equipment or expected service utility for construction work in process.

13. **Internal use software (IUS)** \- Software that is bought from commercial vendors “off-the-shelf,” internally developed, or contractor-developed, solely to meet the entity's internal or operational needs.

14. **Internally developed software** \- Software that employees are actively developing, including new software and existing or purchased software that is being modified with or without contractor’s assistance.

15. **Intragovernmental lease** \- An intragovernmental lease is a contract or agreement occurring within a consolidation entity or between two or more consolidation entities whereby one entity (lessor) conveys the right to control the use of Property and Equipment (PE) (the underlying asset) to another entity (lessee) for a period of time as specified in the contract or agreement in exchange for consideration.

16. **Knowledge, Incident/Problem, Service and Asset Management (KISAM)** \- An inventory system for all accountable IRS property and equipment, except for leasehold improvement, software, investigative equipment, and vehicles. Investigative equipment and vehicles are recorded in CIMIS. The KISAM Asset Manager module is used to track asset management activities for full life cycle of IT and non-IT hardware from acquisition to disposal.

17. **Lease** \- A lease is defined as a contract or agreement whereby one entity (lessor) conveys the right to control the use of PE (the underlying asset) to another entity (lessee) for a period of time as specified in the contract or agreement in exchange for consideration.

18. **Net book value** \- The net amount an asset or group of assets is carried on the books. It is based on the historical cost (gross amount) of the asset less any depreciation, amortization, or impairment costs against the asset.

19. **Probable** \- The IRS follows the FASAB consideration of probable, to equate to more likely than not (>50% probability).

20. **Product category code (PCC) or****material group code (MGC)** \- A data element used to group materials and services according to their characteristics. The PCC/MGC can be associated with one commitment item and more than one Federal Supply Codes (FSC).

21. **Rehabilitation** \- The restoration or renovation of serviceable or operable articles to near-new condition or the repair of unserviceable or inoperable articles when the overall aim is to restore or renovate articles to a near-new condition.

22. **Right-to-use (RTU) Lease** \- A lease that is a non-intragovernmental that does not transfer ownership and the term is longer than 24 months.

23. **Shopping cart** \- The official Procurement Public Sector (PPS) requisition document submitted by an end user, a program office or a contracting officer's representative (COR), for acquiring property and equipment, supplies or services through an appointed procurement office via a warranted Contracting Officer.

24. **Short-term lease** \- A lease with a term of 24 months or less.

25. **Service utility** \- The expected usable capacity at acquisition.

26. **Useful life** \- The expected operating life of an asset.


**1.35.6.1.7** **(06-28-2024)**

#### Acronyms

1. The following acronyms apply to this program.




| **ACRONYM** | **DESCRIPTION** |
| --- | --- |
| AAM | Asset Accounting Module |
| CIMIS | Criminal Investigation Management Information System |
| COTS | Commercial Off-the-Shelf |
| GAAP | Generally Accepted Accounting Principles |
| IFS | Integrated Financial System |
| IUS | Internal Use Software |
| KISAM | Knowledge, Incident/Problem, Service and Asset Management |
| LHI | Leasehold Improvements |
| MGC | Material Group Code |
| NPV | Net Present Value |
| NRV | Net Realizable Value |
| OMB | Office of Management and Budget |
| PE | Property and Equipment |
| PCC | Product Category |
| PPS | Procurement for Public Sector |
| RTU | Right-to-use |
| SFFAS | Statement of Federal Financial Accounting Standards |
| UNS | User and Network Service |


**1.35.6.1.8** **(06-28-2024)**

#### Related Resources

01. OMB Circular No. A-11, [Preparation, Submission, and Execution of the Budget](https://www.whitehouse.gov/omb/information-for-agencies/circulars/)

02. OMB Circular No. A-94, [Guidelines and Discount Rates for Benefit-Cost Analysis of Federal Programs](https://www.whitehouse.gov/omb/information-for-agencies/circulars/), Appendix C: Discount Rates for Cost-Effectiveness, Lease-Purchase, and Related Analyses for OMB Circular No. A-94

03. OMB Circular No. A-136, [Financial Reporting Requirements](https://www.whitehouse.gov/omb/information-for-agencies/circulars/)

04. SFFAS No. 5, [Accounting for Liabilities of the Federal Government](https://files.fasab.gov/pdffiles/handbook_sffas_5.pdf)

05. SFFAS No. 6, [Accounting for Property, Plant, and Equipment](https://files.fasab.gov/pdffiles/handbook_sffas_6.pdf)

06. SFFAS No. 10, [Accounting for Internal Use Software](https://files.fasab.gov/pdffiles/handbook_sffas_10.pdf)

07. SFFAS No. 44, [Accounting for Impairment of General Property, Plant, and Equipment Remaining in Use](https://files.fasab.gov/pdffiles/handbook_sffas_44.pdf)

08. SFFAS No. 54, [Leases](https://files.fasab.gov/pdffules/handbook_sfas_54.pdf)

09. IRM 1.14.4, Personal Property Management

10. IRM 2.149.1, Asset Management Policy

11. IRM 2.149.2, Asset Management Process Description

12. IRM 2.149.3, Asset Management Hardware Procedures

13. IRM 2.149.4, Asset Management Software Procedures

14. IRM 9.10.1, Criminal Investigation Management Information System Equipment Inventory

15. IRM 9.11.3, Investigative Property

16. Procurement Policy Framework

17. Financial Management Codes Handbook


**1.35.6.2** **(09-27-2019)**

### Acquisition of Goods and Services

1. This section provides guidance on procuring goods and services.


**1.35.6.2.1** **(06-28-2024)**

#### Shopping Cart Process

1. Requester electronically prepares and tracks shopping carts (requisitions) in the PPS module. The shopping cart must be complete and contain the proper approvals, technical documentation and funding information to be acceptable for processing. The requester, approver, and financial plan manager validate the accounting string and ensure the product category code (PCC) and material group code (MGC) complies with the Financial Management Codes Handbook.

2. See Procurement Knowledge Base for more information.


**1.35.6.2.2** **(09-27-2019)**

#### Procurement Process

1. Procurement is responsible for the centralized purchase of goods and services for their assigned business units.



1. Procurement staff use the PPS module to generate shopping cart documents for executing new orders, modifying existing orders and obligating funds.

2. See Procurement Policy Framework andIFS-PPS Resource Center for more information.


**1.35.6.2.3** **(09-27-2019)**

#### Receipt and Acceptance Process

1. See IRM 1.35.3, Receipt and Acceptance Guidelines, for more information.


**1.35.6.3** **(06-28-2024)**

### Recording Property and Equipment Transactions

1. The Financial Reporting and Analysis office is responsible for ensuring property and equipment is recorded correctly and presented fairly in the financial statements and conforms to GAAP and OMB guidance. This includes:



1. Reclassifying and recording: The Financial Reporting and Analysis office extracts and compiles capitalized amounts for internal use software and leasehold improvements initially recorded as an operating expense, reclassifies assets and expenses, and records disposals.

2. Financial reporting: Net property and equipment and right-to-use leases are reported on the balance sheet, depreciation expense, gains, and losses are reported as a program cost or earned revenue on the Statement of Net Cost.


**1.35.6.4** **(06-28-2024)**

### Property and Equipment Capitalization

1. This section provides guidance for the capitalization and depreciation of property and equipment.

2. According to SFFAS No. 6, [Accounting for Property, Plant, and Equipment](https://files.fasab.gov/pdffiles/handbook_sffas_6.pdf), property and equipment must meet the following criteria to be capitalized:



1. Have an estimated useful life of two or more years.

2. Not be intended for sale in the ordinary course of operations.

3. Be acquired, constructed or developed with the intention of being used or available for use by the entity.


3. Property and equipment categories consist of:



1. IT equipment

2. Internally developed software/internal use software

3. Leasehold improvements

4. Vehicles

5. Non-IT equipment

6. Right-to-use lease

7. Laboratory or forensic equipment


4. The useful life of an asset is determined by factors such as physical wear and tear and technological changes that affect the asset’s economic usefulness.

5. Capitalized cost includes all costs necessary to bring the asset to the form and location for its intended use, such as amounts paid to vendors, transportation, handling and storage, labor, installation, integration, and other direct and indirect production costs.

6. In general, single item or bulk purchases of $50,000 or more are capitalized and depreciated over the asset’s useful life.

7. The following table summarizes the threshold value and useful life for each type of capitalized property and equipment:



|     |     |     |
| --- | --- | --- |
| **EQUIPMENT** | **THRESHOLD VALUE** | **USEFUL LIFE** |



|     |     |     |
| --- | --- | --- |
| Mainframe Computer Systems and Servers | $50,000 | 7 years |
| Telecommunications Equipment | $50,000 | 7 years |
| Non-IT Equipment | $50,000, or $5,000 if barcoded | 10 years |
| Internal Use Software | $10 million per year or $50 million over software life cycle | Assessed case by case |
| Mainframe, server, or telecommunications software licenses | $50,000 | 7 years |
| Laboratory or Forensic Equipment | $50,000 | 10 years |
| Vehicles | All | 5 years |
| Right-to-use | $930,000 | Shorter of lease term or the useful life of the underlying asset |
| Leasehold Improvements | $50,000 | 10 years or the remaining life of the lease, whichever is shorter |


**1.35.6.4.1** **(06-28-2024)**

#### Information Technology Equipment

1. IT equipment generally consists of mainframes, servers, laptops, desktops, and telecommunications equipment.

2. Cost of mainframe computer systems, servers, and telecommunications equipment is capitalized when the purchase is equal to or greater than $50,000 and depreciated over a useful life of 7 years.

3. Capitalized cost may include costs of related equipment and software if the equipment and software is integral in the functioning of the capitalized asset. For example, if the software is necessary to operate the mainframe computer system rather than to perform an application, the software is considered part of the mainframe computer and is capitalized and depreciated, accordingly.

4. Capitalized cost may also include other costs necessary to bring the asset to a form and location suitable for its intended use, such as shipping, barcoding and installation.

5. Equipment or software not integral to the functioning of the capitalized asset should be considered separately for capitalization criteria.

6. Costs not necessary to bring the capitalized asset to a form and location suitable for its intended use, such as maintenance, warranty, relocation, reinstallation, and removal of existing wiring, should be expensed in the period incurred.

7. Laptops, desktops, tablets, smartphones and IT peripherals such as monitors, keyboards, mice, hard drives, memory upgrades, printers, desktop scanners, and braille equipment are not capitalized.

8. The User and Network Service (UNS) staff maintains inventory records for IT equipment and is responsible for updating inventory records for final asset disposition.


**1.35.6.4.2** **(06-28-2024)**

#### Non-IT Equipment

1. In general, cost of non-IT equipment is capitalized when the purchase, including the costs to bring the asset to a form and location suitable for its intended use (i.e. components, shipping, installation, configuration, asset tagging), is equal to or greater than $50,000, or an individual item costs $10,000 or more and is bar-coded.

2. Capitalized non-IT equipment is depreciated over a useful life of 10 years.

3. Non-IT equipment includes, but is not limited to:



1. Automated file storage equipment

2. Equipment for producing, storing and viewing microforms

3. Document processing equipment for photocopies, mail and check handling, and shredders

4. Television studio, cameras and other photographic equipment

5. Printing and binding equipment

6. Office equipment, devices and machines other than IT equipment

7. Uninterruptible power supplies (UPS)


4. The FMSS territory staff maintains inventory records for non-IT equipment and is responsible for updating inventory records for final asset disposition.


**1.35.6.4.3** **(04-23-2021)**

#### Furniture and Fixtures

1. Purchases of furniture and fixtures, with the exception of those related to leasehold improvements, are not capitalized.


**1.35.6.4.4** **(06-28-2024)**

#### Internal Use Software

01. Internal use software (IUS) consists of Commercial Off-the-Shelf (COTS) software and internally developed software and is capitalized and amortized over the useful life according to SFFAS No. 10, [Accounting for Internal Use Software](https://files.fasab.gov/pdffiles/handbook_sffas_10.pdf) and FASAB Technical Release 16, [Implementation Guidance for Internal Use Software](https://files.fasab.gov/pdffiles/handbook_tr_16.pdf).

02. COTS cost equal to or greater than $50,000 is capitalized if the useful life is two or more years, except for software installed on laptops or desktops which is expensed.

03. For COTS software, capitalized cost includes amounts paid to vendor for the software, and the useful life is seven years, which matches the useful life of the machine on which the software runs.

04. For internally developed software, capitalized cost includes both direct and indirect cost (full cost) incurred during the software development stage, such as salaries of programmers, system analysts, project managers, and administrative personnel, associated employee benefits, outside consultant’s fees, rent, supplies, and documentation manual. The IRS capitalizes these costs incurred after:



    1. Management authorizes and commits to the computer software project and believes that the IRS will more likely complete the project and use the software to perform the intended function with an estimated service life of 2 years or more, and

    2. Conceptual formulation, design, and testing of possible software project alternatives (the preliminary design stage) are completed.


05. Cost incurred during the preliminary design stage (i.e., conceptual formulation, design, and testing of alternatives) and cost incurred after software deployment (i.e., data conversion, maintenance and support) are expensed.

06. COTS that is an integral part of the internally developed software should be capitalized as part of the internally developed software and depreciated, accordingly.

07. Equipment purchased in conjunction with capitalized internally developed software as an integral part of the IUS is treated and depreciated, accordingly.

08. For internally developed software, the useful life is determined for each project with input from the respective IT project office.

09. The IRS IT Governance and Executive Steering Committee monitors and certifies the internally development software project life cycle.

10. The following criteria is used to identify major internally developed software projects subject to capitalization:



    1. The project/program that the software is intended to support must have a total annual budget of $10 million or greater during any one year.

    2. The project/program must be identified as a “Major Project” according to the IT dashboard submitted by the Department of the Treasury for all bureaus.

    3. The project/program must be for new systems or major enhancements to existing systems.


11. Costs for internal use software are accrued in an in-development account. Upon completion of the final acceptance testing and the software is placed in service, costs in the in-development account are transferred to the deployed systems account and amortization begins. Costs incurred after deployment are expensed.


**1.35.6.4.5** **(09-27-2019)**

#### Investigative or Forensic Equipment

1. Investigative or forensic equipment is capitalized when the cost of the equipment and other cost to put the equipment into service is $50,000 or more.

2. Enforcement equipment, such as firearms, surveillance and night vision equipment, telescopes, optical equipment, and body armor, are expensed.


**1.35.6.4.6** **(06-28-2024)**

#### Leasehold Improvements

1. Leasehold improvements (LHI) are alterations to leased property that extend the useful life of leased space or increase the usefulness of the leased space including:



1. Building alterations.

2. Additions permanently attached to or part of a building, including plumbing, power-plant boilers, fire alarm systems, refrigerating systems, security systems, flooring, and carpeting.

3. Improvements to land, including landscaping, fences, sewers and parking lots.


2. LHI cost equal to or greater than $50,000 per award line is capitalized.

3. LHI costs are tracked in a construction-in-progress account until the project is complete.

4. LHI is depreciated over 10 years or the remaining lease term, whichever is shorter.

5. If LHI is part of a Reimbursable Work Agreement, LHI is recognized when it is determined:



1. The provider-lessor would not be expected to derive significant residual economic benefits or services from such reimbursable work under these types of agreements.

2. The provider-lessor should expense the costs incurred for the reimbursable work and recognize reimbursement as intragovernmental revenue.


**1.35.6.4.7** **(06-28-2024)**

#### Leases

1. Under SFFAS No. 54 Leases, a lease is a contract or agreement whereby one entity (lessor) conveys the right to control the use of property, plant, and equipment (the underlying asset) to another entity (lessee) for a period of time as specified in the contract or agreement in exchange for consideration. To qualify as a lease, the underlying asset should be identified by being explicitly specified in a contract or agreement. However, an asset also can be identified by being implicitly specified at the time that the asset is made available for use by the lessee.



1. Leases include contracts or agreements not explicitly identified as leases but that meet the definition of a lease.

2. To determine whether a contract or agreement conveys the right to control the use of the underlying asset, assess whether the contract or agreement gives the lessee both of the following:



      > - The right to obtain economic benefits or services from use of the underlying asset as specified in the contract or agreement; and
      >
      >       - The right to control access to the economic benefits or services of the underlying asset as specified in the contract or agreement.

3. Complex contracts or agreements may contain (1) both lease (for example, right to use a building) and non-lease (for example, maintenance services) components and/or (2) leases of multiple underlying assets. Such lease components are often referred to as “embedded leases” but this term was not used in SFFAS 54. SFFAS 54 paragraphs 72-77 provide guidance for identifying such leases and assigning costs to individual lease components for accounting purposes. The IRS elected not to recognize embedded leases until October 1, 2026.


2. Under SFFAS No. 54 the lease term is the non-cancelable period plus certain periods subject to options to extend or terminate the lease. The non-cancelable period is the shorter of:



1. The period identified in the lease contract or agreement that precedes any option to extend the lease, or

2. The period identified in the lease contract or agreement that precedes the first option to terminate the lease.


> The following periods should be included, if applicable:

1. Those periods specified in the lease contract or agreement that relate to a lessee’s option to extend the lease if it is probable **(see terms and definitions)**, based on all relevant factors, that the lessee will exercise that option.

2. Those periods specified in the lease contract or agreement that follow a lessee’s option to terminate the lease (up until the point in time when there is another option or, if none, the end of the lease) if it is probable **(see terms and definitions)**, based on all relevant factors, that the lessee will not exercise that option.

3. Those periods specified in the lease contract or agreement that relate to a lessor’s option to extend the lease if there is significant evidence, based on all relevant factors, that the lessor will exercise that option.

4. Those periods specified in the lease contract or agreement that follow a lessor’s option to terminate the lease (up until the point in time when there is another option or, if none, the end of the lease) if there is significant evidence, based on all relevant factors, that the lessor will not exercise that option.



      > The options should be considered in chronological order. If a determination is made that an additional period will not be added to the lease term for an option based on the likelihood criteria above, subsequent options would not be considered.


**1.35.6.4.7.1** **(06-28-2024)**

##### Lease Categories

1. The Financial Reporting and Analysis office recognizes leases in the following categories in accordance with SFFAS No. 54:



1. Short-term lease (24 months or less and recorded as expenses) payments are recognized as an expense based on the payment provisions of the contract or agreement and standards regarding recognition of accounts payable and other related amounts.

2. Intragovernmental (expense) lease payments including lease-related operating costs (for example, maintenance, utilities, taxes, etc.) are recognized as expenses based on the payment provisions of the contract or agreement.

3. The Right-to-use (RTU) asset lease (asset and liability) should be recognized at the present value of payments expected to be made during the lease term. Measurement of the lease liability should include the following, if required by a lease:


   - Fixed payments;

   - Variable payments that depend on an index or a rate (such as the Consumer Price Index or a market interest rate), initially measured using the index or rate as of the commencement of the lease term;

   - Variable payments that are fixed in-substance as described in paragraph 41, SFFAS 54;

   - Amounts that are probable of being required to be paid by the lessee under residual value guarantees;

   - The exercise price of a purchase option if it is probable that the lessee will exercise that option;

   - Payments for penalties for terminating the lease, if the lease term reflects the lessee exercising (1) an option to terminate the lease or (2) an availability of funds or cancellation clause;

   - Any lease incentives (par. 70–71, SFFAS 54) receivable from the lessor;

   - Any other payments to the lessor that are probable of being required based on an assessment of all relevant factors.


**1.35.6.4.7.2** **(06-28-2024)**

##### Lease Asset and Liability

1. A lessee should initially measure the lease asset as the sum of the following:



1. The amount of the initial measurement of the lease liability (par. 40, SFFAS 54);

2. Lease payments made to the lessor at or before the commencement of the lease term, less any lease incentives (par. 70–71, SFFAS 54);

3. Initial direct lease costs that are necessary to place the lease asset into service.


2. A lease asset should be amortized in a systematic and rational manner over the shorter of the lease term or the useful life of the underlying asset, except as provided in paragraph 51, SFFAS 54. The amortization of the lease asset should be reported as amortization expense.


**1.35.6.4.8** **(05-05-2014)**

#### Treasury Franchise Fund

1. The IRS does not capitalize property and equipment bought and held by the Treasury Franchise Fund (TFF). Depreciation of TFF allocated to the IRS by Treasury is based on pro rata share of usage.


**1.35.6.4.9** **(06-28-2024)**

#### Vehicles

1. Vehicles are purchased or leased.

2. Purchased vehicles are capitalized and depreciated over a five-year useful life.

3. Vehicle leases are analyzed to determine if the criteria for capitalization under IRM 1.35.6.4.7, Leases, are met.


**1.35.6.5** **(06-28-2024)**

### Physical Security Protection

1. To comply with Department of the Treasury, Interagency Security Committee (ISC), and IRS protection standards and policies, the IRS has established physical security protection methods.

2. Due to monetary value, importance, or vulnerability posed by its loss or compromise, specific IRS assets or equipment may require security measures in addition to being within secured IRS spaces.

3. See IRM 10.2.14, Methods of Providing Protection, for more information.


**1.35.6.6** **(06-28-2024)**

### Verification of IFS to KISAM

1. The Financial Reporting and Analysis office performs a reconciliation to ensure that capitalized property and equipment transactions in IFS AAM are properly recorded in KISAM.


**1.35.6.7** **(07-26-2016)**

### Maintenance, Repair and Rehabilitation

1. Federal agencies must fulfill property needs through redistribution, repair, or rehabilitation of already-owned furniture and office equipment.

2. The General Services Administration, Regional Federal Supply Schedule offices, assist federal agencies by providing maintenance, repair and rehabilitation services. The services are through contracts with commercial firms, agreements with the National Industries for the Blind, and with federal repair facilities such as those supplied by the Federal Prison Industries.

3. See IRM 1.14.4, _Personal Property Management_; IRM 2.149.1, _Asset Management Policy_; IRM 2.149.2, _Asset Management Process Description_; IRM 2.149.3, _Asset Management Hardware Procedures_; IRM 2.149.4, _Asset Management Software Procedures_; and IRM 9.11.3, _Investigative Property;_ for procedures and guidelines for the maintaining and repairing property and equipment.


**1.35.6.8** **(06-28-2024)**

### Impairment

1. The IRS recognizes impairment for IUS according to SFFAS No. 10, [Accounting for Internal Use Software.](https://files.fasab.gov/pdffiles/handbook_sffas_10.pdf)

2. For software in development, when it is determined that the software will not be completed and placed in service, the related book value accumulated in the in-development account is reduced to reflect the NRV, if any, and a loss is recognized.

3. For post-implementation or operational software, impairment is recognized when:



1. The software no longer provides substantive service potential and will be removed from service, or

2. A significant reduction occurs in the capabilities, functions, or uses of the software.


4. For projects that are impaired but remain in use, the loss is determined as the difference between the book value and either:



1. The cost to acquire software that would perform similar remaining functions (i.e., unimpaired functions), or

2. The portion of the book value attributable to the remaining functional elements of the software.


5. If the loss cannot be determined by either method, the book value of the software is amortized over the remaining useful life of the software. If the impaired software is removed from use, the loss is the difference between the book value and any NRV. The NRV of the impaired software is transferred to an appropriate asset account until such time the software is disposed of.


**1.35.6.9** **(06-28-2024)**

### Disposals

1. The disposal process removes property and equipment due to obsolescence, loss, theft, damage or erroneous records.

2. UNS and CI send disposal information from KISAM and CIMIS to the Financial Reporting and Analysis office. The Financial Reporting and Analysis office analyzes the information and compares it to what is recorded in AAM. Additional analysis is performed at year-end for assets older than 10 years. Adjustments are recorded in IFS for asset balances that are greater than those in KISAM or CIMIS.

3. See IRM 1.14.4, Personal Property Management; IRM 2.149.1, Asset Management Policy; IRM 2.149.2, Asset Management Process Description; IRM 2.149.3, Asset Management Hardware Procedures; IRM 2.149.4, Asset Management Software Procedures; IRM 9.10.1, Criminal Investigation Management Information System Equipment Inventory; IRM 9.11.3, Investigative Property; for disposals of IRS property and equipment; and IRM 10.8.1, Information Technology (IT) Security, Policy and Guidance; for disposals of IRS property and equipment.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-035-006#addtoany "Show all")

A2A