---
url: "https://www.irs.gov/irm/part1/irm_01-001-012"
title: "1.1.12 Information Technology | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-012#main-content)

- 1.1.12  [Information Technology](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261903157552)
  - 1.1.12.1  [Mission](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261900917104)
  - 1.1.12.2  [ACIO for Enterprise Program Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261900909456)
    - 1.1.12.2.1  [Enterprise Case Management](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261903174192)
    - 1.1.12.2.2  [Enterprise Program Controls](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261903171488)
    - 1.1.12.2.3  [Emerging Programs & Initiatives](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261903163840)
    - 1.1.12.2.4  [Web Applications](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931201408)
    - 1.1.12.2.5  [DevSecOps Practice](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931198240)
    - 1.1.12.2.6  [Information Returns Modernization](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931183968)
    - 1.1.12.2.7  [Digitalization, Research & Execution](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931304352)
  - 1.1.12.3  [ACIO for Cybersecurity](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931298592)
    - 1.1.12.3.1  [Architecture & Implementation](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931286016)
    - 1.1.12.3.2  [Cybersecurity Operations](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931283792)
    - 1.1.12.3.3  [Security Risk Management](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261931281568)
    - 1.1.12.3.4  [Cyber Threat Response & Remediation](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902988112)
  - 1.1.12.4  [ACIO for Applications Development](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902983616)
    - 1.1.12.4.1  [Delivery Management and Quality Assurance](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902975440)
    - 1.1.12.4.2  [Compliance Domain](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902971120)
    - 1.1.12.4.3  [Internal Management Domain](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902969040)
    - 1.1.12.4.4  [Corporate Data Domain](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902963136)
    - 1.1.12.4.5  [Submission Processing Domain](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902959824)
    - 1.1.12.4.6  [Data Delivery Services Domain](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902957888)
    - 1.1.12.4.7  [Customer Service Domain](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902951952)
    - 1.1.12.4.8  [Technical Integration Organization](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902945728)
    - 1.1.12.4.9  [Identity and Access Management Organization](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902939392)
  - 1.1.12.5  [ACIO for Enterprise Services](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902932368)
    - 1.1.12.5.1  [Enterprise Architecture](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902927456)
    - 1.1.12.5.2  [IT eDiscovery](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902925616)
    - 1.1.12.5.3  [Solution Engineering](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902921664)
    - 1.1.12.5.4  [Acquisition](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902919856)
    - 1.1.12.5.5  [Strategic Planning and Technology](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902918112)
    - 1.1.12.5.6  [Enterprise Systems Testing](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902574960)
  - 1.1.12.6  [ACIO for User and Network Services](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902573296)
    - 1.1.12.6.1  [Customer Service Support](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902565808)
    - 1.1.12.6.2  [Operations Service Support](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902560720)
    - 1.1.12.6.3  [Service Planning and Improvement](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902555696)
    - 1.1.12.6.4  [Contact Center Support Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902553792)
    - 1.1.12.6.5  [Enterprise Field Operations](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902549744)
    - 1.1.12.6.6  [Unified Communications](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902545440)
    - 1.1.12.6.7  [Engineering](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902543504)
  - 1.1.12.7  [ACIO for Enterprise Operations](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902540976)
    - 1.1.12.7.1  [Demand Management and Project Governance Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902528944)
      - 1.1.12.7.1.1  [Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902519200)
      - 1.1.12.7.1.2  [Audit Program Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902515392)
      - 1.1.12.7.1.3  [Project Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902513424)
    - 1.1.12.7.2  [Governance & Resource Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902509424)
      - 1.1.12.7.2.1  [Governance & Risk Management Section](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902500784)
      - 1.1.12.7.2.2  [Filing Season Readiness Section](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902497696)
    - 1.1.12.7.3  [Contract & Acquisition Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902494480)
      - 1.1.12.7.3.1  [Contract & Acquisition Infrastructure Support Section](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902488688)
    - 1.1.12.7.4  [Contract & Acquisition Services Support Section](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902485360)
    - 1.1.12.7.5  [Process & Document Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902481440)
      - 1.1.12.7.5.1  [IT Service Transition Program Section](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902474032)
      - 1.1.12.7.5.2  [Integrated Process Management Section](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902464272)
    - 1.1.12.7.6  [Service Delivery Management Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902459328)
      - 1.1.12.7.6.1  [Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902452912)
      - 1.1.12.7.6.2  [Large Program Support Office 1](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902155904)
      - 1.1.12.7.6.3  [Large Program Support Office 2](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902153424)
      - 1.1.12.7.6.4  [Large Program Support Office 3](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902151008)
    - 1.1.12.7.7  [Security Operations & Standards Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902148592)
      - 1.1.12.7.7.1  [Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902141296)
      - 1.1.12.7.7.2  [Authorizing Official Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902136016)
      - 1.1.12.7.7.3  [IT Continuity Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902131968)
      - 1.1.12.7.7.4  [Account Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902126016)
      - 1.1.12.7.7.5  [Security Operations Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902118448)
    - 1.1.12.7.8  [Enterprise Technology Implementation Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902111008)
      - 1.1.12.7.8.1  [Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902105584)
      - 1.1.12.7.8.2  [IRS Web Infrastructure Services Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902102288)
        - 1.1.12.7.8.2.1  [Internet Services Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902097952)
          - 1.1.12.7.8.2.1.1  [M365 Program Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902094704)
          - 1.1.12.7.8.2.1.2  [Internet Services Integration Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902091104)
      - 1.1.12.7.8.3  [Technology Implementation Services Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902088240)
        - 1.1.12.7.8.3.1  [TIS Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902082000)
        - 1.1.12.7.8.3.2  [Technology Deployment Support Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902076944)
          - 1.1.12.7.8.3.2.1  [IT E-Discovery Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902074960)
        - 1.1.12.7.8.3.3  [E-Records Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902070304)
          - 1.1.12.7.8.3.3.1  [Aged Infrastructure Initiative Support Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902065760)
    - 1.1.12.7.9  [Infrastructure Services Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902063600)
      - 1.1.12.7.9.1  [Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902056016)
      - 1.1.12.7.9.2  [Directory Services Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902053696)
      - 1.1.12.7.9.3  [Enterprise Messaging & Virtualization Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902051296)
      - 1.1.12.7.9.4  [Automation Support Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902047776)
      - 1.1.12.7.9.5  [Middleware Services Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902045920)
    - 1.1.12.7.10  [Server Support & Services Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902043088)
      - 1.1.12.7.10.1  [Server Build Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902036752)
      - 1.1.12.7.10.2  [Software Support Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902034896)
      - 1.1.12.7.10.3  [Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902032848)
      - 1.1.12.7.10.4  [Program and Project Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902447760)
        - 1.1.12.7.10.4.1  [Standards Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902445200)
    - 1.1.12.7.11  [Data Management Services & Support Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902438304)
      - 1.1.12.7.11.1  [Enterprise Database Services Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902433376)
      - 1.1.12.7.11.2  [Data Storage & Protection Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902431520)
      - 1.1.12.7.11.3  [Distributed Database Services Branches](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902428560)
    - 1.1.12.7.12  [Enterprise Server Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902426704)
      - 1.1.12.7.12.1  [z/VM & z/TPF Services Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902420960)
      - 1.1.12.7.12.2  [IBM z/OS Support Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902417104)
      - 1.1.12.7.12.3  [Unisys Support Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902413904)
    - 1.1.12.7.13  [Enterprise Computing Center](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902410304)
      - 1.1.12.7.13.1  [Mainframe Operations Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902400752)
      - 1.1.12.7.13.2  [Server Infrastructure Support Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902398768)
      - 1.1.12.7.13.3  [Server Product and Application Support Branch 1](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902396816)
      - 1.1.12.7.13.4  [Server Product and Application Support Branch 2](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902394432)
      - 1.1.12.7.13.5  [Server Product and Application Support Branch 3](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902392064)
      - 1.1.12.7.13.6  [Server Product and Application Support Branch 4](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902389696)
      - 1.1.12.7.13.7  [Operations Scheduling Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902387328)
      - 1.1.12.7.13.8  [Enterprise Automated Deployment Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902385424)
      - 1.1.12.7.13.9  [Project Response & Incident Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902380848)
      - 1.1.12.7.13.10  [Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902378528)
    - 1.1.12.7.14  [IT Operations Command Center Division](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902373328)
      - 1.1.12.7.14.1  [IT Operations Command Center Division Management Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902365024)
      - 1.1.12.7.14.2  [Mainframe Monitoring/Triage Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902362144)
      - 1.1.12.7.14.3  [Server & Network Monitoring/Triage Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902359888)
      - 1.1.12.7.14.4  [Incident & Problem Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902357360)
      - 1.1.12.7.14.5  [Monitoring Solutions Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902354160)
      - 1.1.12.7.14.6  [IT Services Management Branch](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902351584)
  - 1.1.12.8  [ACIO for Strategy and Planning](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902348400)
    - 1.1.12.8.1  [Financial Management Services](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902342912)
      - 1.1.12.8.1.1  [Budget Execution](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902338976)
      - 1.1.12.8.1.2  [Budget Planning](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902335088)
      - 1.1.12.8.1.3  [Support Services](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902329728)
    - 1.1.12.8.2  [Business Planning & Risk Management](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902324912)
      - 1.1.12.8.2.1  [Enterprise Intake](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902320752)
        - 1.1.12.8.2.1.1  [Business Planning and Analysis](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902316976)
        - 1.1.12.8.2.1.2  [Technical Support Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902315104)
        - 1.1.12.8.2.1.3  [Work Request Support Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902304352)
      - 1.1.12.8.2.2  [Enterprise Life Cycle](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902302208)
      - 1.1.12.8.2.3  [Information Resources Accessibility Program](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902300080)
        - 1.1.12.8.2.3.1  [508 Customer Support](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902298048)
        - 1.1.12.8.2.3.2  [508 Program Support](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902296128)
      - 1.1.12.8.2.4  [Program Oversight Coordination Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902294144)
      - 1.1.12.8.2.5  [Requirements Engineering Program Office](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902287824)
        - 1.1.12.8.2.5.1  [Requirements, Guidance & Outreach](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902285968)
        - 1.1.12.8.2.5.2  [Requirements Support](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902283872)
    - 1.1.12.8.3  [Investment & Portfolio Control & Oversight](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902281008)
      - 1.1.12.8.3.1  [Portfolio Management & Oversight](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902276592)
      - 1.1.12.8.3.2  [Investment & Portfolio Governance](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902271264)
      - 1.1.12.8.3.3  [Investment Management & Control](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902264736)
      - 1.1.12.8.3.4  [Investment & Portfolio Evaluation](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902256960)
        - 1.1.12.8.3.4.1  [Strategic Planning & Execution](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902251472)
    - 1.1.12.8.4  [Strategic Supplier Management](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902245184)
      - 1.1.12.8.4.1  [Strategic Management Support](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902238864)
      - 1.1.12.8.4.2  [Program Management](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902228224)
      - 1.1.12.8.4.3  [Space Continuity and Contingency Planning](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902220672)
        - 1.1.12.8.4.3.1  [Spend Analytics](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902216608)
  - 1.1.12.9  [ACIO for Individual Masterfile Modernization](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902209952)
    - 1.1.12.9.1  [Customer Account Data Engine 2](https://www.irs.gov/irm/part1/irm_01-001-012#idm140261902205568)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 12. Information Technology

* * *

## 1.1.12 Information Technology

#### Manual Transmittal

March 27, 2024

#### Purpose

(1) This transmits revised IRM 1.1.12, Organization and Staffing, Information Technology.

#### Material Changes

(1) This IRM has been updated to reflect the missions and responsibilities of the Information Technology organization. The Information Technology organization has undergone many reorganizations within all the areas in the IT organization. The IRM has been updated to reflect all the restructuring of the offices and any new offices that have been established. The Information Technology organization changes frequently due to the technology changes and with those changes comes restructuring of the entire content contained in the IRM with regards to the mission and function statements for each office.

(2) Specific changes and content updates to subsection, 1.1.12.2.5 DevSecOps Practice:

- Updated organization name change

- Reordered paragraphs in subsection

- Expanded program responsibilities and added paragraph 1.1.12.5.8.

- Minor wording corrections to align with IRS plain language guidance


#### Effect on Other Documents

IRM 1.1.12, dated July 22, 2022, is superseded.

#### Audience

All Operating Divisions and Functions.

#### Effective Date

(03-27-2024)

Rajiv Uppal

Chief Information Officer

**1.1.12.1** **(03-27-2024)**

### Mission

1. The mission of Information Technology (IT) is to deliver IT services and solutions that drive effective tax administration to ensure public confidence.

2. IT is led by the Chief Information Officer (CIO). The CIO reports to the Deputy Commissioner for Operations Support (DCOS) of the Internal Revenue Service (IRS).

3. IT has two Deputy Chief Information Officers:



   - Deputy CIO for Operations

   - Deputy CIO for Strategy/Modernization


4. IT has eight subordinate offices:



   - Associate Chief Information Officer (ACIO) for Enterprise Program Management Office

   - ACIO for Cybersecurity

   - ACIO for Applications Development

   - ACIO for Enterprise Services

   - ACIO for User and Network Services

   - ACIO for Enterprise Operations

   - ACIO for Strategy & Planning

   - ACIO for Individual Masterfile Modernization


**1.1.12.2** **(07-22-2022)**

### ACIO for Enterprise Program Management Office

1. The mission of the Enterprise Program Management Office (EPMO) is to:



   - Serve as the Prime Integrator, driving program delivery and integration efforts in a consistent yet flexible manner

   - Continue to deliver on high priority program and initiative capabilities

   - Mature program management processes, strengthening program management functions and driving consistency through shared standards and best practices

   - Foster a culture of collaboration and integration with Business and Delivery Partners, creating a high-performing workforce and working environment

   - Serve as evaluator and initiator for newly proposed programs and/or initiatives within IT


2. EPMO has seven subordinate offices:



   - Enterprise Case Management

   - Enterprise Program Control

   - Emerging Programs & Initiatives

   - Web Applications

   - DevSecOps Practice

   - Information Returns Modernization

   - Digitalization, Research & Execution


**1.1.12.2.1** **(02-24-2021)**

#### Enterprise Case Management

1. Enterprise Case Management (ECM) is a business-driven transformation program that will address the need to modernize and consolidate 60+ existing case management systems onto a single, cloud-based platform to improve service provided to taxpayers. The current case management ecosystem is massive, with redundant systems and a diverse set of enabling technology. Today there is limited visibility of case management practices between programs, as well as process redundancies and multiple handoffs that can lead to bottlenecks and increased risk. The ECM Future State consolidates case management systems onto a unified platform to streamline enterprise-wide case management processes throughout the case lifecycle. Implementation of the solution will provide a consistent approach to case management across business units. Through delivery of ECM, the IRS will improve interaction with taxpayers by enabling IRS staff to easily access comprehensive, digital case information and streamlining communication channels between case workers.


**1.1.12.2.2** **(02-24-2021)**

#### Enterprise Program Controls

1. Enterprise Program Controls (EPC) champions IT program management best practices providing shared services, controls and workforce management for successful delivery of IT capabilities and initiatives.



   - Program Operations provides financial management and coordination of the EPMO and the individual programs and projects that the EPMO provides sponsorship.

   - Enterprise Organizational Readiness (EOR) ensures the preparedness of organizations through a proven framework to identify and drive the resolution of gaps in the focus areas of People, Process, Technology and Financial readiness with a joint partnership between IT Delivery Partners and Business stakeholders.

   - The Investment & Risk Management (I&RM) organization ensures uniformity, consistency, accuracy and timeliness of internal and external program investment reporting and detailed documentation among EPMO’s major investments’ Information Technology Business Cases. Also provided guidance and support to the EPMO programs’s Risk Management processes to ensure compliance and alignment with the Enterprise Risk Management (ERM) framework.

   - The mission of Program Controls and Integration (PC&I) is to provide consulting, guidance and coordination support activities designed to add value and improve the efficiencies of EPMO operations. PC&I aims to help the EPMO accomplish its objectives by driving consistency, standardizing and bringing a systematic, disciplined approach to improve the effectiveness of program management capabilities across EPMO. PC&I accomplishes its mission through the management of the following functions: Audit Reporting, Configuration Management, Demand Management, Executive Reporting, Program Governance and Requirements Management.

   - Program Management Office Support Services (PMOSS) supports new and existing programs by providing program management guidance, processes and procedures through collaboration and leveraging of best practices across IT. With the establishment of modernization initiatives across IRS, IT, PMOSS assists with facilitation of the EPMO Modernization Reporting effort.

   - The mission of the Program Support Services (PSS) office is to provide enterprise wide guidance to customers with the necessary information to meet management and operational project control needs in a timely, effective manner. To accomplish this mission, PSS develops, maintains and provides Program Management process guidance, standards, templates and data management services. In addition, PSS provides human resource coordination, SharePoint solutions and workforce planning efforts for the EPMO.


**1.1.12.2.3** **(07-22-2022)**

#### Emerging Programs & Initiatives

1. Emerging Programs & Initiatives (EP&I) proactively plans for legislative and other newly proposed programs and/or initiatives to align implementation with IRS IT strategic priorities. EP&I analyzes legislative and public policy themes and emerging priorities to determine IT impacts and prepare IT to respond to mandates and other business priorities

2. EP&I applies a five-step framework to continuously assess emerging priorities, prepare for delivery and monitor execution:



   - Scan emerging priorities and initiatives for insights on potential IT impacts

   - Analyze draft legislation and mandates pre-enactment to determine possible IT impacts

   - Plan IT actions and coordinate with partners to prepare for delivery efforts based on the analysis and IRS IT priorities

   - Stand-Up deliver efforts for legislative and assigned non-legislative initiatives

   - Monitor execution efforts for legislative and assigned non-legislative initiatives


**1.1.12.2.4** **(08-01-2018)**

#### Web Applications

1. The mission of Web Applications (Web Apps) is to improve interactions and communications across taxpayers, employers, the IRS and third parties by providing a broad range of self-service options, establishing secure information exchange options and building internal capabilities. By enabling third parties and taxpayers to interact digitally with the IRS, the investment will provide a better user experience, achieve significant savings by moving services to lower cost channels and deliver consistent data and services through reusable Application Programming Interfaces (APIs). Web Apps will transform the way the IRS does business by delivering a digital service that is the taxpayers’ first-choice when interacting with the IRS to get the information they need when they need it.


**1.1.12.2.5** **(03-27-2024)**

#### DevSecOps Practice

1. DevSecOps Practice is the application of Lean principles to the software development lifecycle for faster delivery and better quality. With a strong focus on collaboration, it maintains collapsing roles, automating processes to simplify handoffs and eliminating error-prone, time-consuming manual work.

2. DevSecOps Practice represents the integration of IT products and capabilities (entire delivery pipeline, including day-to-day IT operations and IT service delivery) at many levels. DevSecOps is a culture change focusing on process workflows and infrastructure management, as well as solution creation, deployment, and delivery and encompasses seven functions. Fundamentally, DevSecOps represents an accelerated, secure, more agile approach to conceptualizing business innovation and driving those ideas or processes into customer and user capabilities.

3. DevSecOps Practice pipeline orchestrates the delivery of project software artifacts, computing infrastructure and patches, from source code check-in through production deployment in a fully automated manner with minimal user intervention. All applications should follow the DevSecOps Definition of Done documentation.

4. The DevSecOps Practice functions for each initiative are:



   - Continuous Integration (CI) - Code is delivered to a code repository. Builds and tests are automatically performed to find any issues. Alerts are sent if issues arise during the automated build process.

   - Automated Testing (AT) - Automated testing occurs continuously throughout the development lifecycle. It provides insight into the current health of the software so irregularities can be resolved early, providing the confidence required for deployment.

   - Continuous Delivery (CD) - Code continuously delivered to test environments and every software change is potentially deployable to production. Automated testing can drive the acceptance of software.

   - Software Define Infrastructure (SDI) - Technical computing infrastructure entirely under the control of software with no operator or human intervention. It operates independent of any hardware-specific dependencies and is programmatically extensible.

   - Platform as a Service (PaaS) - Establishes PaaS best practices and strategies as well as standards for operational use in production. Aligns with all IT areas and commitments to ensure success and enables IT to meet existing commitments and goals including: Solaris to Linux, Aging Hardware Refresh, and support of major upgrade activities and N/N-1 strategic commitments.

   - Infrastructure as Code (IaC) - Establishes IaC best practices and criteria for operational use, in addition to focusing on streamlining the provisioning of servers using automation, reducing the time needed to instantiate a server and configure the infrastructure.

   - Configuration Management - Tracks and control changes to the software code base and archival of all file versions into a central configuration management database. Provides organization for the software build process by accounting for multiple environments.


5. Continuous Monitoring - Continuously monitors the system and applications for issues and notifies responsible parties in case of irregularities. Provides analytics gathering capabilities to ensure application is performing at optimal levels and the system is secure.

6. Organizational Transformation (OT) - Fosters culture change to enable shifts in mind-sets and skills through organization change management and communications.

7. Security - Secures DevSecOps initiatives and lead activities that move security to the left in the One Solution Delivery Life Cycle (SDLC)

8. DevSecOps Pipeline Requirements Process (Diagram)



**Figure 1.1.12-1a**

![This is an Image: 30386001.gif](https://www.irs.gov/pub/xml_bc/30386001.gif)





> This figure shows the multi-stage pipeline process







[Please click here for the text description of the image.](https://www.irs.gov/media/399731 "")





**Figure 1.1.12-1b**

![This is an Image: 30386002.gif](https://www.irs.gov/pub/xml_bc/30386002.gif)





> Multi-Stage Pipeline Process Details







[Please click here for the text description of the image.](https://www.irs.gov/media/399736 "")


**1.1.12.2.6** **(07-22-2022)**

#### Information Returns Modernization

1. The mission of Information Returns Modernization (IR MOD) is to meet legislative requirements and modernize the end-to-end Information Returns (IR) pipeline to enhance the taxpayer experience. Future releases will continue to increase IR processing efficiency, improve IR data access and integration, and enhance compliance mechanisms through advanced analytics

2. The IR MOD program is a multi-release Program intended to satisfy the Taxpayer First Act (TFA) 1, 2 Sec. 2102



   - The first release allows the IRS to meet the requirement to develop an Internet portal by January 1, 2023 for small businesses to electronically file forms 1099

   - The second IR Mod release will address additional legislative mandates (e.g., Infrastructure Investment and Jobs Act (IIJA) 80603 Cryptocurrency Mandate)

   - The third release will continue to align IRS IT priorities (e.g., IT Mod Plan, Enterprise Data Strategy, Filing Season Integration Services), and contribute to the modernization of the IRS IT ecosystem


**1.1.12.2.7** **(07-22-2022)**

#### Digitalization, Research & Execution

1. Digitalization Research & Execution focuses on identifying and implementing priority digital capabilities that enable the enterprise to meet its strategic goals of reducing current and incoming paper volume and inventory, increasing access to digital data, preparing the IRS to manage digital data and driving the reduction of manual workloads to portable work

2. Digitalization has been developing a holistic strategy that drives alignment across people, process, technology and policy to realize the following benefits:



   - Enables the IRS mission to be digital-first

   - Reduces the agencies dependency on paper driven processes

   - Maximizes data accessibility and use in new and innovative ways

   - Scales new solutions to drive the retirement of legacy systems

   - Transitions repetitive, low-value work to mission-driven high-value activities

   - Prioritizes security through digital design and implementation


**1.1.12.3** **(07-22-2022)**

### ACIO for Cybersecurity

1. The mission of Cybersecurity is to protect Taxpayer information and the IRS’s electronic systems, services and data from internal and external cyber security related threats by implementing World Class security practices in planning, implementation, management and operations. The IRM 1.1.25 has been incorporated into parts of the Mission and functions of Cybersecurity.

2. Cybersecurity has four subordinate offices:



   - Architecture & Implementation

   - Cybersecurity Operations

   - Security Risk Management

   - Cyber Threat Response & Remediation


3. The Cybersecurity functions are:



   - Data protection and encryption

   - Computer Security Incident Response Center (CSIRC) management

   - Federal Information Security Management Act (FISMA) compliance

   - Security policy, process guidance

   - Disaster recovery coordination

   - Security stakeholder management

   - Systems security testing, certification on-premise, cloud and contractor

   - IT security engineering

   - Vulnerability scanning and analysis

   - Business Impact Analysis

   - Security performance metrics and monitoring

   - Investment management

   - Cloud services

   - Contractor security assessment

   - Filing season risk management

   - Audit and validation

   - Strategy & investments


**1.1.12.3.1** **(02-24-2021)**

#### Architecture & Implementation

1. Architecture & Implementation (A&I) is responsible for security architectures, innovative security solutions through expert analysis, implementation of best of breed security tools, trusted advisory services and disciplined project management. A&I provides security project management, security policy management and interpretation, investment management, pre-milestone security posture impact of new technology/architecture, external representation on technical industry and cross-government initiatives and security engineering for systems/applications.


**1.1.12.3.2** **(09-08-2023)**

#### Cybersecurity Operations

1. Cybersecurity Operations is responsible for ensuring the security and resilience of the IRS’s information and information systems in support of the federal tax administration processes through 24/7 cyber incident management, cyber/fraud analytics, user behavior analytics and situational awareness.


**1.1.12.3.3** **(02-24-2021)**

#### Security Risk Management

1. Security Risk Management (SRM) is responsible for ensuring IRS compliance with federal statutory, legislative and regulatory requirements governing measures to assure the confidentiality, integrity and availability of IRS electronic systems, services and data. In partnership with the business units, SRM monitors the implementation of the IT security program in accordance with FISMA, Treasury, OMB, FedRAMP and Federal Continuity Directives (FCDs) 1 & 2. Other responsibilities include performing assessments of risks to IRS, cloud and supporting contractor systems, tracking security compliance, monitoring risk remediation activities, performing comprehensive security controls testing, managing disaster recovery and contingency plan testing, performing penetration testing, vulnerability scanning and source code analysis. Managing the Security Assessment and Authorization (SA&A) process and coordinating the enterprise continuous monitoring program performance. SRM conducts application-based risk analysis against filing season and Financial Systems as well as High Value Assets.


**1.1.12.3.4** **(07-22-2022)**

#### Cyber Threat Response & Remediation

1. Cybersecurity Threat Response & Remediation is responsible for serving as the principal advisor and consultant with focus on programs in alignment to threat response and remediation, while providing a single point of coordination with a clear mission to ensure the Cybersecurity organization is well prepared, informed and knowledgeable regarding Cyber events and activities. The Cybersecurity Threat Response & Remediation also provides executive leadership in developing the Taxpayer First Act (TFA) and modernized products, as well as developing and aligning strategic and operational plans to deliver future-state capabilities, to include leadership functions such as setting intent with Cyber Strategy to drive mission priorities; Audit and Risk Management; Acquisition Management; and driving and leading across IT disciplines, including data management, data integration, business intelligence tools and IT security laws, regulations and policies.


**1.1.12.4** **(07-22-2022)**

### ACIO for Applications Development

1. The mission of Applications Development (AD) is to build, test, deliver and maintain integrated information applications systems that will support modernized systems and the production environment to achieve the vision and objectives of the IRS.

2. The Applications Development functions are:



   - System design, development, testing, deployment and maintenance

   - Test, assurance, documentation

   - Program management


3. Applications Development has nine subordinate offices:



   - Delivery Management and Quality Assurance

   - Compliance Domain

   - Internal Management Domain

   - Corporate Data Domain

   - Submission Processing Domain

   - Data Delivery Services Domain

   - Customer Service Domain

   - Technical Integration Organization

   - Identity and Access Management Domain


**1.1.12.4.1** **(02-24-2021)**

#### Delivery Management and Quality Assurance

1. The mission of Delivery Management and Quality Assurance (DMQA) is to drive strategic change through shared services, leadership and standards for the management of programs/projects, contracts, budgets, intake and audits, in alignment with IT strategic vision and guidance, in order to make AD strong.

2. DMQA is organized into seven services-focused subordinate branches/offices:



   - Acquisitions 1 & 2 Branches

   - Program & Project Management 1, 2 & 3 Branches

   - Intake & Audit Branch

   - Planning & Coordination Office


**1.1.12.4.2** **(07-22-2022)**

#### Compliance Domain

1. The mission of the Compliance Domain (CD) is to develop, design, build, test, deliver and maintain software applications to help achieve the vision and objectives of the IRS in the Compliance and Appeals arenas. Compliance IT Systems support include all systems related to Collection, Return Examination and Appeals components, which includes 93 Federal Courts, the State of California, Treasury Business Financial Systems, 3 territories and 50 state Unemployment Offices.


**1.1.12.4.3** **(08-01-2018)**

#### Internal Management Domain

1. The mission of the Internal Management (IM) Domain is to build, maintain, test and deliver internal systems critical to our business partners. Not limited to, but including financial, administrative and human resource integrated systems by conducting the following:



   - Manage the financial systems

   - Manage workforce time, payroll and productivity

   - Manage human capital functions (staffing, promotions, performance management)

   - Support the financial audit

   - Support Tax Courts and Litigation

   - Manage and support Independent Taxpayer Rights cases

   - Manage and support Organization Travel Systems and Reports

   - Protect IT assets and information

   - Make informed decisions


**1.1.12.4.4** **(08-01-2018)**

#### Corporate Data Domain

1. The mission of the Corporate Data Domain is to:



   - Ensure the integrity of individual and business accounts and tax law administration

   - Provide services for the business and individual return data, information return data, employee plan data, corporate data and provide customer research, notice composition and online notice review capabilities


2. The Corporate Data Domain areas of responsibility are authoritative databases, refund identification, notice generation and reporting Corporate data.


**1.1.12.4.5** **(08-01-2018)**

#### Submission Processing Domain

1. The mission of the Submission Processing Domain is to collaborate across IT and with our customers to develop and deliver secure and effective paper and electronic solutions to accept tax returns, information returns and payments, including input and perfection of data through transactional and daily processing.


**1.1.12.4.6** **(02-24-2021)**

#### Data Delivery Services Domain

1. The mission of the Data Delivery Services (DDS) Domain is to implement data-centric services for applications development through people, process and technologies. The goal is to enable agile and efficient delivery of functionality to our stakeholders. DDS accomplishes this by focusing on the collection, consolidation, certification and reporting of a broad array of data and providing secure, ready access methods and services to this data to enable stakeholder use.

2. DDS is organized into seven services-focused subordinate branches/offices:



   - Program & Coordination Office (PCO)

   - Return Review Program Fraud & Analytics Services (RFA) Branch

   - CADE2 Data Services (CDS) Branch

   - Enterprise Data Warehouse Services (EDW) Branch

   - Departmental Warehouse Services (DWS) Branch

   - ACA Analytics Data & Reporting (AADR) Branch

   - Executive Office (XO)


**1.1.12.4.7** **(07-22-2022)**

#### Customer Service Domain

1. The mission of the Customer Service Domain (CSD) is to improve voluntary federal tax compliance while reducing customer service call-center volumes through self-service features by providing access to systems and data that enables the IRS and its partners to deliver service and information to taxpayers

2. CSD is the development organization for internet and telephone automated self-service applications that provide tax law assistance, taxpayer education, taxpayer data and systems that generate and manage taxpayer correspondence.

3. CSD has seven subordinate offices:



   - Planning & Coordination Office

   - Customer Communications Branch

   - Tax Professional eServices Branch

   - International & Field Applications Branch

   - Online Accounts Branch

   - Online Experience Branch

   - Business Online Accounts Branch


**1.1.12.4.8** **(07-22-2022)**

#### Technical Integration Organization

1. The Technical Integration Organization (TIO) idrives achievement of the strategic goals of IT and Applications Development in three main areas:



   - As consultants and practitioners, practically applies expertise to AD in driving cost-effective application of new and emerging technologies and IT models

   - Provides leadership and AD advocacy for IT issues with cross-domain impacts, identifying opportunities or areas of concern and managing solutions and communications where appropriate

   - Implements and supports targeted applications as needed (e.g., ACA, cross-application shared services, etc.)


2. TIO is organized into five services-focused branches/offices:



   - Application Innovation (AI)

   - App Standards and Quality (ASQ)

   - Application Security (AS)

   - Technical Advisory Group (TAG)

   - Planning and Coordination (PC)


**1.1.12.4.9** **(02-24-2021)**

#### Identity and Access Management Organization

1. The mission of the Identity and Access Management Organization (IAM) is to:



   - Provide technical leadership and strategic guidance for Digital Identity efforts to drive innovation and enhance effectiveness of taxpayer services and systems

   - Drive decision making, lead integration and collaborate on IT topics

   - Conduct annual and strategic planning

   - Conduct personnel and administrative functions

   - Support internal and external partners to provide technical leadership and communication across AD and our Delivery Partners, breaking down barriers to drive efficiency and consistency of standards and practices across the AD portfolio


2. IAM is organized into five services-focused branches/offices:



   - Authorization

   - Authentication

   - Common Services

   - Planning and Coordination

   - Executive Office


**1.1.12.5** **(08-01-2018)**

### ACIO for Enterprise Services

1. The mission of Enterprise Services is to architect, design and test enterprise solutions, balancing efficiency and fit to connect the tax ecosystem in a seamless and leading-edge manner.

2. Enterprise Services has six subordinate offices:



   - Enterprise Architecture

   - IT eDiscovery

   - Solution Engineering

   - Acquisition

   - Strategic Planning and Technology

   - Enterprise Systems Testing


**1.1.12.5.1** **(08-01-2018)**

#### Enterprise Architecture

1. The mission of Enterprise Architecture (EA) is to set enterprise technology direction by translating business priorities into an effective enterprise technical framework, setting architecture guidance and establishing technology standards.


**1.1.12.5.2** **(08-01-2018)**

#### IT eDiscovery

1. The mission of IT eDiscovery is to:



   - Institutionalize and execute IRS’s repeatable process for Electronic Discovery (E-Discovery)

   - Assure IRS responsiveness to litigation requiring E-Discovery for civil cases, as well as Freedom of Information Act (FOIA) requests (administrative phase)

   - Raise awareness across IRS and partner with all business functions to educate the workforce about E-Discovery

   - Integrate the E-Discovery process and technology (new and existing) with applicable business and IT enterprise processes


**1.1.12.5.3** **(08-01-2018)**

#### Solution Engineering

1. The mission of Solution Engineering is to supply high quality design solutions by embracing simplicity, encouraging collaboration, viewing problems from different angles and early resolution of technical risks.


**1.1.12.5.4** **(08-01-2018)**

#### Acquisition

1. The mission of Acquisition is to enable business transformation by providing integrated and agile acquisition solutions, services and standards.


**1.1.12.5.5** **(08-01-2018)**

#### Strategic Planning and Technology

1. The mission of Strategic Planning and Technology is to set enterprise technology-related policies and goals, develop strategic plans, manage key aspects related to delivering world-class enterprise architecture/engineering and establish internal technical standards.


**1.1.12.5.6** **(08-01-2018)**

#### Enterprise Systems Testing

1. The mission of Enterprise Systems Testing is to work in partnership with its customers to improve the quality of IRS information systems, products and services.


**1.1.12.6** **(02-24-2021)**

### ACIO for User and Network Services

1. The mission of the User and Network Services (UNS) organization is to provide the IRS with reliable, secure, innovative and cost-effective technology and services that enable communication, collaboration and business capabilities.

2. Overview of UNS:



   - Manages the architecture, design, engineering, standards, implementation and operations for voice, video and internal/external data communications, contact center environment, converged networks and user infrastructure

   - Manages the enterprise service desk operations to business customers and end-users

   - Maintains the day-to-day operations environment while developing long-term network and process improvements in support of business requirements


3. UNS has seven subordinate offices:



   - Customer Service Support

   - Operations Service Support

   - Service Planning and Improvement

   - Contact Center Support Division

   - Enterprise Field Operations

   - Unified Communications

   - Network Engineering


**1.1.12.6.1** **(02-24-2021)**

#### Customer Service Support

1. Responsible for planning, coordinating, delivering and managing IT support activities for end-users in accordance with negotiated Service Level Agreements (SLAs). This is accomplished by:



   - Providing tiered analysis and troubleshooting assistance to resolve end-user incidents through the use of remote tools

   - Developing, designing and managing solutions/knowledge that facilitates rapid resolution of end-user incidents and problems

   - Establishing and communicating policies related to the end-user environment

   - Conducting Problem Management through root cause analysis and proactive data analysis, and monitoring for incident and problem resolution

   - Performing analysis and coordination across all workstreams (phones, web chat, web queue tickets) to maintain balanced workloads, top quality customer interactions and to ensure service accessibility for the operations support of the Enterprise Service Desk

   - Providing the best innovative technology solutions for the growing needs of the IRS end-users seeking products and services


**1.1.12.6.2** **(07-22-2022)**

#### Operations Service Support

1. Responsible for the integration, testing, provisioning, logistics, asset management and security configuration compliance of end-user computing hardware, software and peripherals. This is accomplished by:



   - Supporting workstation operations in the production and test environments to improve serviceability of workstations and business operations; project/initiative engagements and future technology evaluations to improve workstation operations, capabilities and user experience

   - Managing the end-to-end computer and peripherals supply chain: including depot warehousing, VITA program delivery, equipment sanitization and disposal operations

   - Managing the laptop/desktop computing environment to include coordinating and executing day to day operational support and new technology upgrades

   - Managing computer security configuration, compliance, patching and vulnerability remediation

   - Supporting end-user productivity by resolving incidents requiring replacement of equipment and satisfying requests for new equipment


**1.1.12.6.3** **(07-22-2022)**

#### Service Planning and Improvement

1. Responsible for delivering effective and cost efficient IT services in accordance with negotiated SLAs. Provides oversight of business operations to include Business Relationship management, Process Improvement, Acquisition Strategy, Portfolio Management and UNS security oversight


**1.1.12.6.4** **(02-24-2021)**

#### Contact Center Support Division

1. Serves as the IT single Point of Contact (POC) for Business Operating Divisions and internal service desks for IRS contact center operations and infrastructure maintenance. Ensures all contract center components and related network infrastructure are efficient, cost effective, secure and highly reliable. Provides real time monitoring, scripting and call control tables, and 2nd/3rd level operational support to ensure all contact center technology is functioning to meet customer requirements. Responsible for monitoring the IRS Unified Contact Center Environment (UCCE) systems, circuits and applications and providing event management and problem resolution. Develops, tests and deploys call routing changes to provide optimum taxpayer and internal IRS employee service. Documents and implements configuration changes, security patches and hardware/software updates and upgrades. Maintains and supports all CCE-specific applications.

2. Manages programmatic and planning activities that support the Contact Center Environment infrastructure including by serving as the primary interface with Contact Center customers; coordinating customer requirements, managing UCCE UWR responses; coordinating release management activities; budget oversight and guidance; deployment support for major UCCE initiatives; oversight and management of UCCE contracts; and serving as primary interface with Procurement ensuring product and service availability.

3. Research, select, architect, design and test enterprise contact center IT solutions that align with business needs. (Plan, Research, Analyze and Integrate UCCE Solutions)


**1.1.12.6.5** **(08-01-2018)**

#### Enterprise Field Operations

1. Delivers end-user effective and cost efficient IT services in accordance with negotiated Master Service Level Agreement (MSLA). This is accomplished by:



   - Managing/supporting the Local Area Network (LAN) environment (data network and voice systems)

   - Supporting deployment of key infrastructure initiatives

   - Establishing and communicating end-user policies and processes.

   - Managing/supporting end-user equipment (desktops, laptops and printers) to include proving oversight of assets throughout lifecycle

   - Resolving end-user incidents and satisfying requests for services


**1.1.12.6.6** **(08-01-2018)**

#### Unified Communications

1. Responsible for providing leading technology for voice, video and data communications such as presence, chat, fax and web conferencing on a common single infrastructure. The goal is to connect people, information and teams to enable comprehensive and effective collaboration while delivering greater user functionality and capabilities


**1.1.12.6.7** **(08-01-2018)**

#### Engineering

1. Responsible for architecture, technical direction, engineering design and standards, and the planning, execution and management of network services


**1.1.12.7** **(07-22-2022)**

### ACIO for Enterprise Operations

1. The mission of Enterprise Operations (EOps) is to provide efficient, cost effective, secure and highly reliable computing (server and mainframe) services for all IRS business entities and taxpayers. To accomplish the mission, EOps will:



   - Deploy and maintain a secure infrastructure capable of supporting the business and administrative needs of the Service for both the current environment and modernized operations

   - Provide mainframe tax processing for the successful delivery of each filing season with all the Service's consolidated customer sites

   - Provide effective planning, direction and coordination of the Service’s Master File operations

   - Standardize, consolidate and manage the server-computing infrastructure, mainframe computing infrastructure and ancillary systems/software

   - Provide technical and operational support for the Service’s Tier 2 tax processing and electronic commerce systems

   - Maintain and modify systems software products for the Service's mainframe computing environment

   - Develop policy and procedures and execute strategic plans and budgets for corporate computing services

   - Conduct capacity planning and performance measures for all systems and services managed by EOps

   - Provide services to business units/divisions within established SLAs

   - Provide planning and coordination for the successful implementation of all modernization initiatives into the corporate computing environment


2. EOps has 11 subordinate offices:



   - Demand Management and Project Governance (DPMG) Division

   - Service Delivery Management Division

   - Security Operations & Standards Division

   - Technology Implementation Services Division

   - IRS Web Infrastructure Services Division

   - Infrastructure Services Division

   - Server Support & Services Division

   - Data Management Services & Support Division

   - Enterprise Server Division

   - Enterprise Computing Center

   - IT Operations Command Center Division


**1.1.12.7.1** **(02-24-2021)**

#### Demand Management and Project Governance Division

1. The mission of the Demand Management and Project Governance Division is to provide high-quality IT operations services and solutions that align with and enable the strategic imperatives of IT and IRS. These solutions will be scalable, value driven, reliable and secure. In delivering our solutions, we will focus on leadership, best practices and continuous improvement to:



   - Serve as the central POC for EOps customers and manage customer outreach, including acting as administrator of the Unified Work Request (UWR) process for EOps and serve as the entry point for work requests for all EOps activities, including entry point for requests (“R tickets”, Security Requests, etc.) that do not route appropriately through the incident management process

   - Direct strategic planning for EOps, including Demand, Portfolio and Workforce management

   - Direct the governance and planning of programs and projects impacting the enterprise environment by providing a consistent approach to managing projects and provide implementation execution on pre-determined large projects

   - Serve as POC for the IT Level Governance Board(s)

   - Advance EOps to World Class IT, with a focus on process improvement best practices and standardization ITIL maturity advancement

   - Oversee infrastructure inventory, asset management and procurement

   - Serve as the Enterprise process owner for Configuration and Change Management


2. Demand Management & Project Governance has the following subordinate branches:



   - Division Management Office

   - Audit Program Office

   - Project Management Branch

   - Governance & Resource Management Branch

   - Contract & Acquisition Management Branch

   - Process & Document Management Branch


**1.1.12.7.1.1** **(02-24-2021)**

##### Division Management Office

1. The DMPG Division Management Office (DMO) supports leadership/management and provides oversight to DMPG staff/project managers and to the division’s branch chiefs to ensure the DMPG mission is met

2. DMPG DMO also:



   - Serves as the division’s single point of entry for incoming suspense items and as a liaison to stakeholders and customers

   - Formulates and prepares supporting justifications for budgetary and staffing resources for programs, projects and activities, including cost projections and analyses and business cases for new investments


**1.1.12.7.1.2** **(02-24-2021)**

##### Audit Program Office

1. The mission of the Audit Program Office (APO) is to provide coordination and management of audit activities being conducted by the Government Accountability Office (GAO) and the Treasury Inspector General for Tax Administration (TIGTA), which may impact EOps. Additionally, the Audit Program Office coordinates EOps responses for Internal Revenue Manual (IRM) updates.


**1.1.12.7.1.3** **(02-24-2021)**

##### Project Management Branch

1. The Project Management Branch (PMB) serves as the Demand Management and Project Governance Division (DMPGD) operational component. PMB supports the EOps Divisions with project planning, management and coordinating available resources. PMB also serves as the gateway for all work entering EOps, coordinating with supplier Divisions to accomplish work and change requests.

2. PMB has the following three subordinate offices:



   - Project Planning & Org Readiness Section

   - Customer & Technical Support Section

   - Demand Management Section


**1.1.12.7.2** **(02-24-2021)**

#### Governance & Resource Management Branch

1. The Governance & Resource Management Branch (GRMB) ensures developing, executing and preserving a consistent management framework, homogenizing the EOps ACIO’s governance, risk management and filing season readiness processes, procedures and standards, while facilitating information sharing, methodologies, tools and techniques to:



   - Govern selected investments and their systems, programs and projects as delegated

   - Identify the mission, goals and scope of risk management and the procedure to carry out the support of managing risks

   - Escalate risks and increase awareness on risks associated with EOps Major Investments

   - Provide oversight for coordinating and planning Filing Season Readiness (FSR) activities across the EOps organization

   - Facilitate and manage completing:


   - Filing Season (FS) activities

   - FS Improvements

   - FS Infrastructure Readiness

   - FS Integrated Master Schedule (IMS)

   - EOps Health Checks (HC)

   - FS Certification for the IT Expanded Scope certification areas


2. GRMB has the following two subordinate offices:



   - Governance & Risk Management Section

   - Filing Season Readiness Section


**1.1.12.7.2.1** **(02-24-2021)**

##### Governance & Risk Management Section

1. The Governance & Risk Management (GRM) mission it to:



   - provide a consistent approach for the management and governance of major products, initiatives, risks and issues for the EOps organization

   - facilitate the EOps Governance and Risks Review Boards, as well as project/initiative assessments by providing key data, recommendations and final disposition of the EOps Project and Risk Portfolios


**1.1.12.7.2.2** **(02-24-2021)**

##### Filing Season Readiness Section

1. The mission of the Filing Season Readiness Section (FSRS) is to lead and provide program oversight for the coordination and planning of Filing Season Readiness (FSR) activities across the Enterprise Operations (EOps) organization. The processes around the following FSR activities are used to facilitate the EOps ACIO in the process of certifying organizational readiness in support of Filing Season to the CIO:



   - Improvements

   - Infrastructure Readiness Assessment (IRA) Health Checks, Integrated Master Schedule (IMS) and Certification are used to facilitate the EOps ACIO in the process of certifying organizational readiness in support of Filing Season to the CIO.


**1.1.12.7.3** **(02-24-2021)**

#### Contract & Acquisition Management Branch

1. The Contracts & Acquisition Management Branch (CAMB) supports the EOps Divisions with contract management, acquisition processing and reporting metrics for IT-related products and services in support of tax and administrative processing. This includes a full range of professional acquisition and contract management services for EOps customers nationwide; including planning and preparing IT infrastructure and services requirements, as well as continuing administration and support throughout the contract lifecycle

2. CAMB also provides a full range of professional financial management services for EOps ACIO, including planning and preparing IT infrastructure and contractor services budget formulation, as well as continued fiscal administration and oversight support throughout the investment’s lifecycle.

3. CAMB has the following two subordinate offices:



   - Contract & Acquisition Infrastructure Support Section

   - Contract & Acquisition Services Support Section


**1.1.12.7.3.1** **(02-24-2021)**

##### Contract & Acquisition Infrastructure Support Section

1. The Contract & Acquisition Infrastructure Support Section manages EOps hardware and software acquisition and contract functions, including:



   - Processing shopping carts for new purchases or renewals

   - Receipt and acceptance

   - Collaboration on KISAM data validations


**1.1.12.7.4** **(02-24-2021)**

#### Contract & Acquisition Services Support Section

1. The Contract & Acquisition Services Support Section manages EOps contractor support demands for acquisition and contract functions, including:



   - Processing shopping carts for new requirements or renewals

   - Onboarding activities

   - Meeting with customers and vendors on a recurring basis

   - Acting as liaison support to mitigate issues


**1.1.12.7.5** **(02-24-2021)**

#### Process & Document Management Branch

1. The Process & Documentation Management (PDM) Branch uses industry best practices and de facto standards to provide the IT organization with the means to leverage efficiencies and economies of scale by eliminating redundancies, streamlining workflows and implementing process improvements. The IT organization gains consistent and proven systematic procedures aligned with the business objectives. PDM:



   - Aligns strategic initiatives to “best of breed” practices in meeting organizational goals and objectives

   - Facilitates improved processes, workflows and products to meet business needs

   - Facilitates research and design to improve organizational capabilities that foster consistent management support and services enterprise-wide

   - Uses and adopts IT Infrastructure Library (ITIL), Capability Maturity Model Integration -Dev (CMMI-Dev), Lean Six Sigma (LSS) and Project Management Body of Knowledge (PMBOK) methodologies to achieve transformational results for EOps divisions, branches and section

   - Conducts training to institutionalize process standardization, centralization and integration enterprise-wide using proven techniques

   - Promotes continuous improvement mechanisms and methodologies in support of knowledge management, change management and configuration management initiatives enterprise-wide


2. PRM has the following two subordinate offices:



   - IT Service Transition Program Section

   - Integrated Process Management Section


**1.1.12.7.5.1** **(02-24-2021)**

##### IT Service Transition Program Section

1. The IT Service Transition Program (ITSTP) Section ensures the value of new and changed services into supported environments by controlling risk and supporting organizational knowledge for effective decision support. ITSTP consists of:



   - Knowledge Management (KM) ensures the right information is provided to the right people at the right time to enable informed decision-making. KM:


   - Ensures the standardization of EOps documentation and maintains the official EOps KM/Configuration Management Library (CML) documentation repository

   - Administers the EOps Bundled Document Review (BDR) process and the Memorandum of Understanding/Memorandum of Agreement (MOU/MOA) and Customer Service Agreement processes


2. Change Management (ChM) creates deploys and maintains a standard ITIL change management process for all of IRS IT, supported by an integrated change management system. ChM:



   - Supports IRS IT to implement change management improvement initiatives

   - Provides input, guidance and assistance with the establishment of internal change management capacity

   - Provides overall strategic change management guidance to the senior leadership team

   - Supports change management initiatives through research, diagnostics, assessments and employment of surveys


3. Configuration Management (CM) ensures the institutionalization of configuration management and serves as the authoritative source for compliance and guidance at the enterprise level. CM:



   - Ensures CM documents are accurate and updated to reflect the needs of the portfolio

   - Ensures that practitioners are properly trained, informed and notified of changes that may impact their organization

   - Ensures all ACIO areas are assessed annually to determine their compliance with CM guidance

   - Administers and maintains the Configuration Management Library (CML) to ensure effective identification and control of configurable items

   - Defines and implements effective configuration management practices at the enterprise level to ensure program or project readiness for implementation at various points in the system development lifecycle


**1.1.12.7.5.2** **(02-24-2021)**

##### Integrated Process Management Section

1. Integrated Process Management (IPM) IT services to changing business needs by identifying and implementing continuous process improvement throughout the IT lifecycle, while establishing provisions for quality products, services and cost effectiveness enterprise wide. IPM:



   - Supports IT Service Management through measurable and repeatable processes enterprise wide

   - Ensures all delivered services are monitored and measured against agreed upon service in accordance to the customer's business needs

   - Evaluates process maturity using the ITIL and CMMI frameworks to identify key areas of process improvement essential to an organization’s service

   - Executes an integrated and holistic approach in the adoption of service management standards and principles thereby becoming more customer-focused and service-centric utilizing best practices/de facto standards

   - Serves as the IT trusted, quality service provider, and functioning as a single entity to meet customer needs in a timely and cost-effective manner by optimizing processes, systems, and communications


**1.1.12.7.6** **(02-24-2021)**

#### Service Delivery Management Division

1. The mission of the Service Delivery Management Division (SMSD) is to provide program management for the EOps’ portions of IT programs under the purviews of the EPMO or other programs/projects assigned by ACIO EOps. In delivering EOps responsibilities, SDMD will focus on leadership, best practices and continuous improvement to:



   - Direct the planning and implementation of the EOps portions of large programs and projects impacting the Enterprise environment, providing a consistent approach to managing current and future IT programs.

   - Manage the new EOps work associated with standing up these new programs and facilitate communication between the EPMO and the other EOps divisions

   - Provide standard EOps project governance for these programs and ensure EOps organizational readiness to support new projects at Milestone 4b


2. Service Delivery Management has four subordinate offices:



   - Division Management Office

   - Large Program Support Office 1

   - Large Program Support Office 2

   - Large Program Support Office 3


**1.1.12.7.6.1** **(08-01-2018)**

##### Division Management Office

1. The Division Management Office (DMO) provides leadership, management and oversight in the administration, planning and execution of IT Initiatives to ensure program goals and objectives are achieved.



   - Oversees and reports on projects and all aspects of investment-portfolio management, identifying risks/issues with obtaining IT objectives

   - Plans, prioritizes, and recommends mitigating strategies to address risks/issues

   - Contributes to the IRS’s IT strategic management in terms of formulating and executing policy, its long-range objectives and internal administration

   - Serves as the division’s single point of entry for incoming suspense items and as a liaison to stakeholders and customers

   - Formulates and prepares supporting justifications for budgetary and staffing resources for programs, projects and activities, including cost projections and analyses and business cases for new investments


In addition to the role of the DMO, the DMO Chief supports the division director and provides leadership, management, and oversight to DMO staff/project managers and to the division’s branch chiefs to ensure the mission of the division is met.



**1.1.12.7.6.2** **(02-24-2021)**

##### Large Program Support Office 1

1. The Large Program Support Office (LPSO) 1 is responsible for representing EOps as a delivery partner for the applicable programs. The LPSO acts as the liaisons between EOps and the “customer” projects. The LPSO assists projects in adhering to standard EOps processes to maintain the integrity and stability of the enterprise. The LPSO provides EOps tasks and timelines so that these can be appropriately included in schedules to ensure the timely delivery of new infrastructure and applicable products and configurations. The LPSO also ensures the appropriate technical insertion and organizational readiness activities are conducted, including staffing, training and documentation, and interfacing with managed service providers (MSP) to allow seamless handoff to Operations and Maintenance processes and organizations.


**1.1.12.7.6.3** **(02-24-2021)**

##### Large Program Support Office 2

1. The LPSO 2 is responsible for representing EOps as a delivery partner for the applicable programs. The LPSO acts as the liaisons between EOps and the “customer” projects. The LPSO assists projects in adhering to standard EOps processes to maintain the integrity and stability of the enterprise. The LPSO provides EOps tasks and timelines so that these can be appropriately included in schedules to ensure the timely delivery of new infrastructure and applicable products and configurations. The LPSO also ensures the appropriate technical insertion and organizational readiness activities are conducted, including staffing, training and documentation, and interfacing with MSP to allow seamless handoff to Operations and Maintenance processes and organizations.


**1.1.12.7.6.4** **(02-24-2021)**

##### Large Program Support Office 3

1. The LPSO 3 is responsible for representing EOps as a delivery partner for the applicable programs. The LPSO acts as the liaisons between EOps and the “customer projects. The LPSO assists projects in adhering to standard EOps processes to maintain the integrity and stability of the enterprise. The LPSO provides EOps tasks and timelines so that these can be appropriately included in schedules to ensure the timely delivery of new infrastructure and applicable products and configurations. The LPSO also ensures the appropriate technical insertion and organizational readiness activities are conducted, including staffing, training and documentation, and interfacing with MSP to allow seamless handoff to Operations and Maintenance processes and organizations.


**1.1.12.7.7** **(07-22-2022)**

#### Security Operations & Standards Division

1. The mission of the Security Operations & Standards Division is to:



   - Provide oversight and management of a comprehensive EOps IT Security program

   - Ensure that the Enterprise Operations organization’s policies, plans and processes are compliant with the guidance specified in the Federal Information Security Management Act (FISMA)

   - Integrate all security components within EOps

   - Lead all Enterprise Operations Disaster Recovery & Business Continuity activities

   - Lead Enterprise Operations Patch Management activities


2. The Security Operations & Standards Division has five subordinate branches/offices:



   - Division Management Office

   - Authorizing Official Management Branch

   - IT Continuity Management

   - Account Management Branch

   - Security Operations Management Branch


**1.1.12.7.7.1** **(02-24-2021)**

##### Division Management Office

1. The mission of the Division Management Office (DMO) is to support the Director by providing leadership, management and oversight in the administration, planning and execution of IT initiatives to ensure program goals and objectives are achieved.

2. To accomplish this mission, the DMO:



   - Oversees and reports on projects and all aspects of investment-portfolio management, identifying risk/issues with obtaining IT objectives

   - Plans, prioritizes and recommends mitigating strategies to address risk/issues

   - Contributes to the IRS’s IT strategic management in terms of formulating and executing policy, its long-range objectives and internal administration

   - Serves as the division’s single point of entry for incoming suspense items and as a liaison to stakeholders and customers

   - Formulates supporting justifications for budgetary and staffing resources for programs, projects and activities, including cost projections and analyses and business cases for new investments


**1.1.12.7.7.2** **(02-24-2021)**

##### Authorizing Official Management Branch

1. The mission of the Authorizing Official Management Branch (AOMB) is to provide:.



   - Oversight for the EOps Executive Authorizing Official activities related to General Support System (GSS)

   - Oversight/coordination of EOps Risk Acceptance activities for SOSD

   - Oversight and Initiation of EOps Plan of Action and Milestones (POAMS) and remediation tracking

   - Oversight tracking of EOps vulnerability and mitigation management

   - Oversight/coordination of EOps owned GSS inventory updates and validations


**1.1.12.7.7.3** **(07-22-2022)**

##### IT Continuity Management Branch

1. The mission of the IT Continuity Management Branch (ITCMB) is to:



   - Provide Business Resumption Strategy (BRS) for major outages

   - Lead all EOps Disaster Recovery and ASP activities

   - Provide oversight, coordination, and serve as liaison of EOps for all contingency planning, such as government shutdowns

   - Support EOps High Service Availability Initiative. Provide authoritative, internal repository for all Information System Contingency Plans (ISCP), Business Continuity Plans (BCP), Alternate Site Processing (ASP) plans, Disaster Recovery Plans (DRP) and keystroke-level response plans for recovering critical mainframe systems and applications

   - Provide command and control for the execution of response plans during recovery exercises, production ASP activities and actual outages impacting critical mainframe systems

   - Support threat response for the 4000+ annual physical security threats against the IRS that AWSS– Situational Awareness Management Center (SAMC) manages in coordination with TIGTA and other federal agencies

   - Provide management decision support based on impact assessments of the dependency relationships between organizational data, business processes, technology and response plans


**1.1.12.7.7.4** **(07-22-2022)**

##### Account Management Branch

1. The mission of the Account Management Branch is to provide account administration, management and oversight in accessing critical IRS Information systems such as:



   - Mainframe Systems

   - Integrated Data Retrieval Systems (IDRS)

   - Enterprise User Portal (EUP)

   - Integrated Enterprise Portal (IEP-RUP)

   - Integrated Submission and Remittance Processing (ISRP)


2. To accomplish this mission:



   - Security Administrators provide access to IBM and Unisys Mainframe, Integrated Enterprise Portal - Employee User Portal (EUP)/Registered User Portal (RUP) and eAuth applications and critical tax filing systems such as Integrated Submission Remittance Process (ISRP) and Integrated Data Retrieval System (IDRS)

   - Security Administrators control authorized user access nationwide to "critical" IRS information systems by managing the roles, entitlements and access privileges of individual users in which users are granted and/or denied that access

   - Security Administrators maintain, modify and monitor user access throughout the lifecycle of the user and only granting permission to the proper enterprise system ensuring compliance with IRS policies and regulations and enforcing least privilege

   - Security Administrators monitor and control IT user access to Federal Tax Information (FTI), elevated/privilege and enterprise global access to IRS systems.

   - Provide oversight and management of the Service Account Program and Non-Person Entity.


**1.1.12.7.7.5** **(07-22-2022)**

##### Security Operations Management Branch

1. The mission of the Security Operations Management Branch (SOMB) is to secure the Enterprise Operations IT systems.

2. To accomplish this mission, SOMB:



   - Performs Operating Systems continuous monitoring of systems compliance with required security configurations

   - Performs analysis of reported non-compliant configurations for IBM z/OS and z/VM, Windows Server and UNIX Server Operating Systems

   - Remediates and/or directs the remediation of stated non-compliant configurations of systems to bring them into compliance with Internal Revenue Manual (IRM) policies

   - Leads the Enterprise Operations Patch Management Program by providing patch management oversight, scheduling and execution support

   - Provides Enterprise Server Malware protection

   - Supports IBM Mainframe system certificates

   - Secures IBM Mainframe systems and COTS products

   - Manages and installs Vanguard COTS products on zOS IBM Mainframes

   - Provides FISMA and GAO Audit Support


**1.1.12.7.8** **(02-24-2021)**

#### Enterprise Technology Implementation Division

1. The mission of the Enterprise Technology Implementation Division (ETI) is to lead the implementation and operations of enterprise technology programs including third-party managed and EOps-operated services. A primary focus is managed service and enterprise-wide Commercial Off-the-Shelf (COTS) products. Specifically, the ETI will:



   - Lead the implementation of enterprise technology programs including third-party managed and EOps-operated services

   - Provide contract management ensuring operations, maintenance and enhancement support for the Integrated Enterprise Portal (IEP), Public User Portal (PUP), Registered User Portal (RUP), Employee User Portal (UEP), Affordable Care Act Transaction Portal Environment (ACA-TPE) and Web Content Management System (WCMS)

   - Provide project management support related to implementation of Enterprise Infrastructure Projects

   - Provide governance and perform Operations and Maintenance support of the Enterprise Office 365 SharePoint environment


2. ETI has three subordinate offices:



   - Division Management Office

   - IRS Web Infrastructure Services Office

   - Technology Implementation Services Office


**1.1.12.7.8.1** **(08-01-2018)**

##### Division Management Office

1. The mission of the DMO is to provide world class demand management service delivery processes in the form of centralized support for shared administrative functions; including but not limited to: finance, human resources, divisional data calls and communications and provides liaison services to offices outside ETI, EOps, IT and the IRS. The ETI DMO also guides the division in applying portfolio management practices to the myriad ETI projects.


**1.1.12.7.8.2** **(02-24-2021)**

##### IRS Web Infrastructure Services Office

1. The mission of the IRS Web Infrastructure Services Office (WISO) is to provide program leadership, guidance and strategic direction for the IRS Web Services Infrastructure investment which provides the infrastructure for one-stop, Web-based services, including IRS.gov website, with the long-term goal of providing a virtual tax assistance center for internal and external users. This investment enables landing page access to services for taxpayers, businesses, practitioners, electronic return originators and IRS employees. Services enabled by the IRS Web Services Infrastructure investment include easy access to forms and publications, electronic payment transactions, delivery of transcripts, tracking of refunds and amended returns, modernized e-filing, free-file for certain taxpayers and other electronic services. Planned enhancements for the IRS Web Services Infrastructure include more secure and reliable portals with a modernized portal design and increased systems capacity.

2. IRS WISO has three subordinate branches/offices:



   - Internet Services Branch

   - Intranet Services Branch

   - IEP Acquisition Office


**1.1.12.7.8.2.1** **(02-24-2021)**

###### Internet Services Branch

1. The mission of the Internet Services Branch (ISB) is to provide continual operations and enhancements of IEP. It provides portal planning, development, testing and operational services to projects utilizing the IEP services. The Internet Services Branch has two subordinate offices:



   - Intranet Services Delivery Office

   - Internet Services Integration Office


**1.1.12.7.8.2.1.1** **(07-22-2022)**

###### M365 Program Management Branch

1. The mission of the M365 Program Management (MPM) Branch is to define and support governance, development, expansion, operation and management of Microsoft 365 products for On-Premises, Hybrid and Cloud delivery to partners and stakeholders; manage and support, except for infrastructure, nearly all aspects of SharePoint, including platform support, monitoring, user support, change management and governance for the SharePoint and integrated Third Party products, IIS/SQL server, IRS Source, Service-wide Knowledge Management, PERM initiative and CI Organization; migrate on-premises solutions for Microsoft applications of Exchange, Skype, SharePoint, on-premises storage of user files (hard drives / i-drives / shared drives) and Project to cloud-based Microsoft 365 Software-as-a-Service (SaaS) in the M365 Cloud (Exchange Online, Teams, SharePoint Online, OneDrive, and Project Online). The M365 Program Management Branch has two subordinate sections:



   - SharePoint Program Management Services Section

   - M365 Program Management Services Section


**1.1.12.7.8.2.1.2** **(02-24-2021)**

###### Internet Services Integration Office

1. The mission of the IEP Acquisition Office is to focus on acquisition planning and implementation of Releases 1.5 and 2.0 (at least), including an integrated project prioritization approach and framework that will enable, support and integrate with high visibility interdependent Portal-related projects across the IRS IT organization (Portal Eco-System). As a key group in ETI, also participates in other acquisition and implementation efforts on going as needed.


**1.1.12.7.8.3** **(07-22-2022)**

##### Technology Implementation Services Office

1. The mission of the Technology Implementation Services (TIS) is to:



   - Establish and maintain a results-oriented enterprise infrastructure project portfolio that implements and expands technology services

   - Apply portfolio management practices to enterprise infrastructure upgrades and IT insertion investments and projects

   - Ensure cross-IT coordination of enterprise technology initiative projects

   - Ensure that processes, procedures and products used to produce and sustain the software conform to all relevant requirements and standards

   - Identify, monitor and resolve risks from the inception of a product to the implementation of the product and across product lines


2. TIS has five subordinate offices:



   - TIS Division Management Office

   - Technology Deployment Services Office

   - IT E-Discovery Office

   - E-Records Office

   - Aged Infrastructure Initiative Support Office


**1.1.12.7.8.3.1** **(07-22-2022)**

###### TIS Division Management Office

1. The mission of the TIS Division Management Office is to support the Director by providing leadership, management and oversight in the administration, planning and execution of IT initiatives to ensure program goals and objectives are achieved.



   - Oversees and reports on projects and all aspects of investment-portfolio management, identifying risks/issues with obtaining IT objectives

   - Plans, prioritizes and recommends mitigating strategies to address risk/issues

   - Serves as the division’s single point of entry for incoming suspense items and as liaison to stakeholders and customers

   - Formulates and prepares supporting justifications for budgetary and staffing resources for programs, projects and activities, including cost projections and analyses and business cases for new investments


2. In addition to the role of the DMO, the DMO Chief supports the division director and provides leadership, management, and oversight to DMO staff/ project managers and to the division’s branch chiefs to ensure the mission of the division is met.


**1.1.12.7.8.3.2** **(07-22-2022)**

###### Technology Deployment Support Office

1. The mission of the Technology Deployment Support Office (TDSO) is to provide program level leadership, guidance and tech insertion, and strategic and tactical direction for the deployment of large technology initiatives, enabling infrastructure currency and the delivery of IT services and solutions that drive effective tax administration to ensure public confidence.


**1.1.12.7.8.3.2.1** **(07-22-2022)**

###### IT E-Discovery Office

1. The mission of the IT E-Discovery Office is to leverage technology-enhanced electronic processing tools and workflows, to forensically search, collect, preserve and process targeted electronic stored information (ESI) in support of Chief Counsel Civil litigation (such as: Tax Case lawsuits, FOIA, Congressional Inquiry, other Government Investigations); with the goal of delivering documented defensible evidence that promotes E-Discovery case wins and favorable case settlements that achieve the best possible legal outcomes for the IRS.



   - Institutionalize and execute IRS’s repeatable process for IT Electronic Discovery (E-Discovery) that is both “Defensible and Reasonable” in accordance with the Federal Rules of Civil Procedures

   - Assure IRS responsiveness to litigation requiring E-Discovery for civil cases and Freedom of Information Act (FOIA) requests (administrative phase)

   - Raise awareness across IRS and partner with all business functions to educate the workforce about IT E-Discovery

   - Integrate the E-Discovery process and technology (new and existing) with applicable business and IT enterprise processes


**1.1.12.7.8.3.3** **(07-22-2022)**

###### E-Records Office

1. The mission of the E-Records Office is to provide IT program and project management support for the deployment of enterprise solutions to enable customers to meet their electronic records management and digitization goals to ensure alignment with the IT strategic vision.



   - Provides planning and coordination for the successful implementation of records-related technology solutions to meet the business need

   - Provides oversight and management for technology solution implementation for the entire project life cycle

   - Provides communication to all IT and various stakeholders across the IRS

   - Coordinates with Budget Team on the management of approved Development Modernization Enhancement (DME) & Investment Management Plan (IMP) to support the project

   - Drives projects towards closure and completeness to meet the OMB/NARA mandate M-19-21, EO 13556 and 32 CFR Part 2002


**1.1.12.7.8.3.3.1** **(07-22-2022)**

###### Aged Infrastructure Initiative Support Office

1. The mission of the Aged Infrastructure Initiative Support Office (AIISO) is to provide program oversight and structure for Enterprise Tier 1 and Tier 2 assets and infrastructure management. AIISO promotes hardware and software alignment by establishment of refresh and maintenance priorities for infrastructure, to reduce the vulnerabilities associated with non-compliant assets or software. AIISO drives capability selection, prioritization, and funding recommendations to improve IT infrastructure health and support its sustainment.


**1.1.12.7.9** **(07-22-2022)**

#### Infrastructure Services Division

1. The mission of the Infrastructure Services Division (ISD) is to provide the core enterprise IT functions which enable stability, protection, communication, and agility for the broader IT. These essential services include:



   - Computer Resources for enterprise applications through a virtualized server infrastructure

   - Secure Electronic Messaging Services, including email and tools for custom collaboration and messaging services applications including mobile devices

   - Directory Services, which include Active Directory, Certificate Management, Identity Management and enforcement of identity-related security rules

   - Software Automation supporting software deployment, patch management, asset inventory, software distribution, license management and security compliance

   - Middleware Infrastructure Services involving software components which act as a connector, moving data by message or file between disparate systems, handling data in a transient manner, translating data as needed to provide that interface between platforms/products, but not making substantive changes to content


2. ISD has one office and four subordinate branches:



   - Division Management Office

   - Directory Services Branch

   - Enterprise Messaging & Virtualization Branch

   - Automation Support Branch

   - Middleware Services Branch


**1.1.12.7.9.1** **(07-22-2022)**

##### Division Management Office

1. The mission of the Division Management Office (DMO) is to provide leadership, management and oversight in the administration, planning, and execution of Information Technology Initiatives to ensure program goals and objectives are achieved. The DMO Chief supports the ISD (Division) Director and provides leadership, management and guidance to DMO Staff & Project Managers and to the Division Branch Chiefs.


**1.1.12.7.9.2** **(08-01-2018)**

##### Directory Services Branch

1. The Directory Services Branch is responsible for overseeing the efforts of the Directory Management Sections and the Public Key Infrastructure (PKI) Section. The Mission of the Directory Services Branch is to provide program management for all EOps managed Active Directory forest(s), Certificate and PKI program management for the IRS, Directory Service management and support IRS Identity & Access Management solutions.


**1.1.12.7.9.3** **(07-22-2022)**

##### Enterprise Messaging & Virtualization Branch

1. The mission of the Enterprise Messaging & Virtualization Branch is to work in partnership with EOps and all consumers of messaging resources and virtual infrastructure resources. We shall provide a robust, highly redundant and reliable platform for needs in these areas. We shall provide excellent support services and infrastructure to enable our customers the ability to meet their business objectives in a timely manner.



   - The Enterprise Messaging Systems are the core infrastructure technologies that provide the IRS Main and Chief Counsel with secure electronic messaging services and collaborative communications.

   - The Virtualization Support Sections provide virtual and container cloud technology expertise and program guidance to support all virtual and container infrastructure resource needs within the IRS. These areas oversee the infrastructure automation tools and integrate infrastructure automation and hyperconverged infrastructure.


**1.1.12.7.9.4** **(08-01-2018)**

##### Automation Support Branch

1. The Automation Support Branch (ASB) provides tools and solutions which enable our IT partners to provide services that reduce manual burden. This ultimately results in improved timeliness and the best in customer service and delivery.


**1.1.12.7.9.5** **(08-01-2018)**

##### Middleware Services Branch

1. Middleware Services Branch (MSB) provides support for the subset of COTS, Government Off the Shelf (GOTS), Open Source and custom software that acts as a connector whose primary function is to move data between disparate applications or systems (differing platforms, software applications or domains), temporarily storing and/or transforming the data as needed in order to effectively pass the data between the source and target system.


**1.1.12.7.10** **(02-24-2021)**

#### Server Support & Services Division

1. The mission of the Server Support & Services Division (SSSD) is to:



   - Provide standards for Tier 2 infrastructure which includes servers, operating system, and COTS

   - Build all Tier 2 servers across all enterprise environments

   - Install and configure Commercial Software for Unix, Linux, and Wintel servers (with the exception of Middleware components)

   - Provide comprehensive support for the version of the IBM Rational tools currently deployed throughout the IRS and the processes/methodologies surrounding their use

   - Provide program management support to the Division to ensure we meet customer needs and Division goals


2. SSSD has five subordinate branches/offices:



   - Server Build Branch

   - Software Support Branch

   - Division Management Office

   - Program and Project Management Office

   - Standards Management Office


**1.1.12.7.10.1** **(08-01-2018)**

##### Server Build Branch

1. The mission of the Server Build Branch is to improve operational efficiency by leveraging technology, best practices and tools to provision Wintel, UNIX and Linux systems, software and services in a rapid, repeatable and agile manner for all IRS business units.


**1.1.12.7.10.2** **(02-24-2021)**

##### Software Support Branch

1. The mission of the Software Support Branch is to provide an Enterprise Rational Tool environment that supports the IRS project lifecycle from design to development; including curating requirements and testing. Provide software tool custodianship to install, configure, upgrade, and facilitate software delivery for Tier II COTS on Wintel and Unix/Linux platforms as it aligns to automation, infrastructure currency, and standard stack.


**1.1.12.7.10.3** **(08-01-2018)**

##### Division Management Office

1. The mission of the DMO is to provide leadership, management and oversight in the administration, planning and execution of IT initiatives to ensure program goals and objectives are achieved. To accomplish this mission, the DMO:



   - Oversees and reports on projects and all aspects of investment-portfolio management, identifying risks/issues with obtaining information technology objectives

   - Plans, prioritizes and recommends mitigating strategies to address risks/issues

   - Contributes to the Service’s IT strategic management in terms of formulating and executing policy, its long-range objectives and internal administration

   - Serves as the division’s single point of entry for incoming suspense items and as a liaison to stakeholders and customers

   - Formulates and prepares supporting justifications for budgetary and staffing resources for programs, projects and activities, including cost projections and analyses and business cases for new investments


In addition to the role of the DMO, the DMO Chief supports the division director and provides leadership, management and oversight to DMO staff/project managers and to the division’s branch chiefs to ensure the mission of the division is met.



**1.1.12.7.10.4** **(02-24-2021)**

##### Program and Project Management Office

1. The mission of the Program and Project Management Office (PPMO) is to provide leadership, management and oversight of the SSSD team of IT project managers to ensure the mission of SSSD is achieved. The PPMO will provide the planning, and project management methodology that ensures cost, schedule, risk management control, and successful delivery. The PPMO will also manage and oversee SSSD Division specific initiatives, EOps projects, and support AD major releases.


**1.1.12.7.10.4.1** **(02-24-2021)**

###### Standards Management Office

1. The mission of the Standards Management Office (SMO) is to develop and manage standards for server Operating Systems and COTS products in the Tier 1 and Tier 2 environments. SMO supports and collaborates with all IT organizations to ensure approved software on the IRS Enterprise Standards Profile (ESP) are developed and in alignment with established standards and policies.



   - Manages and develops standards for OS and COTS software on Tier 1 and Tier 2 platforms

   - Identifies new OS and COTS software standard requirements

   - Provides oversight and coordinates with Software Subject Matter Experts (SMEs) to identify requirements for standards

   - Monitors and reviews existing standard documents and provide updates on an ongoing basis

   - Coordinates with Knowledge Management Library (KML) to have standard documents approved by IMCCB and stored as appropriate


2. SMO supports the verification and validation of newly built servers and works on several initiatives to improve and standardize server delivery.



   - Manages the Standard Stack Initiative

   - Validates baseline images that SSSD builds against appropriate server standards

   - Verifies and validates Server Compliance information provided by server build team during the building of servers being placed in DSTest and DS Domains


**1.1.12.7.11** **(08-01-2018)**

#### Data Management Services & Support Division

1. The mission of the Data Management Services & Support Division is to:



   - Plan, build, operate and maintain the IRS’s data management technologies and processes

   - Perform database and storage administration and provide Level 2 and 3 support


2. The Data Management Services & Support Division has three subordinate branches:



   - Enterprise Database Services Branch

   - Data Storage & Protection Branch

   - Distributed Database Services Branches


**1.1.12.7.11.1** **(08-01-2018)**

##### Enterprise Database Services Branch

1. The Enterprise Database Services Branch designs, develops and deploys Database Products for the IRS Mainframe systems to meet evolving customer business needs in a manner consistent with established standards and IRS business objectives.


**1.1.12.7.11.2** **(08-01-2018)**

##### Data Storage & Protection Branch

1. The mission of the Data Storage & Protection Branch (DSPB) is to provide high availability of stored data for all Corporate IT assets. DSPB will provide continuous services to deliver enterprise level support and solutions for data requirements in regards to storage, protection, backup, replication and restoration. DSPB will provide these services to meet or exceed Business Requirements and SLAs. The DSPB staff is dedicated to providing high level day to day customer support including continued focus on being a collaborative partner to IT Service Continuity Management and Business Resumption Planning.


**1.1.12.7.11.3** **(08-01-2018)**

##### Distributed Database Services Branches

1. The Distributed Database Services Branches design, develop and deploy Database Products for the IRS server systems, to meet evolving customer business needs in a manner consistent with established standards and IRS business objectives.


**1.1.12.7.12** **(02-24-2021)**

#### Enterprise Server Division

1. The mission of the Enterprise Server Division is to:



   - Evaluate, plan, build, test and deploy mainframe technologies

   - Provide Level 3 support for mainframe incidents

   - Evaluate, design, develop, test and deploy the IBM and Unisys Mainframe systems, making changes to meet evolving customer business needs in a manner consistent with established standards and IRS business objectives

   - Evaluate, design, develop, test, install and modify mainframe system infrastructure required for various ongoing Tax Processing systems


2. The Enterprise Server Division has three subordinate branches:



   - z/VM & z/TPF Services Branch

   - IBM z/OS Support Branch

   - Unisys Support Branch


**1.1.12.7.12.1** **(02-24-2021)**

##### z/VM & z/TPF Services Branch

1. The mission of the z/VM & z/TPF Services Branch is to:



   - Evaluate, design, develop, test and deploy the IBM z Transaction Processing Facility (z/TPF) operating system, the z/VM operating system and COTS products supporting z/TPF and z/VM on the IBM mainframes

   - Perform Capacity and Performance Analysis for all z/VM Systems

   - Support IBM’s TPF Operations Server Support System (TOS), the Security Communications System Application (SACS), the Computer Assisted Publishing System (CAPS) and IBM’s Transactional Processing Facility Operating System


**1.1.12.7.12.2** **(08-01-2018)**

##### IBM z/OS Support Branch

1. The mission of the IBM z/OS Support Branch is to:



   - Evaluate, design, develop, test, deploy and maintain the IBM z/OS operating system, the z/OS operating system and COTS products supporting z/OS and z/OS on the IBM mainframes

   - Install, customize, test and maintain releases on transactional software

   - Perform Capacity and Performance Analysis for all z/OS Systems


**1.1.12.7.12.3** **(08-01-2018)**

##### Unisys Support Branch

1. The mission of the Unisys Support Branch is to:



   - Evaluate, design, develop, test, deploy and maintain Unisys operating systems, COTS and communications products for the Unisys mainframe

   - Install, customize, test and maintain releases on transactional software

   - Perform Capacity and Performance Analysis for all Unisys Systems


**1.1.12.7.13** **(02-24-2021)**

#### Enterprise Computing Center

1. The Enterprise Computing Center’s (ECC) agile and innovative workforce provides secure tax and administrative processing and highly available hosting solutions to fund Government services for America. The division employs a fully integrated solution that manages key functions that:



   - Manage operation services, scheduling and validation through planning, coordination and staff support related to computer workload management for Operations system schedules, processing and related balancing and controls

   - Provide 24x7 support to Unix/Linux and Windows Servers and Mainframe Operations

   - Resolve incidents and maintain stable processing environments for production and development systems and disaster recovery operations

   - Lead Release Management by serving as the IT Filing Season Release/Deployment Manager and developing and maintaining the enterprise-wide release management plan for deployment of quality IRS IT systems, services and support to the production environment. This includes coordinate, plan for and manage Filing Season, including the daily calls and reports


2. ECC has ten subordinate branches/offices:



   - Mainframe Operations Branch

   - Server Infrastructure Support Branch

   - Server Product and Application Support Branch 1

   - Server Product and Application Support Branch 2

   - Server Product and Application Support Branch 3

   - Server Product and Application Support Branch 4

   - Operating Scheduling Branch

   - Enterprise Automated Deployment Branch

   - Project Response & Incident Management Office

   - Division Management Office


**1.1.12.7.13.1** **(02-24-2021)**

##### Mainframe Operations Branch

1. The mission of the Mainframe Operations Branch (MOB) is to provide Computer Systems Analyst support on a 24x7 basis to ensure the mainframe systems deliver highly available, efficient and timely Real Time services and processing support to both internal and external customers. MOB also provides print and digital file delivery support to internal and external customers.


**1.1.12.7.13.2** **(08-01-2018)**

##### Server Infrastructure Support Branch

1. The mission of the Server Infrastructure Support Branch is to provide System and Product Administration to support a stable server environment for development, test, pre-production, production and Disaster Recovery/Alternate Site Production Environment (DR/ASPE) for developers, testers, project offices, internal IT customers and end users.


**1.1.12.7.13.3** **(08-01-2018)**

##### Server Product and Application Support Branch 1

1. The mission of the Server Product & Application Support Branch 1 is to provide Product and Business Application administration support for a portfolio of projects to deliver a stable server environment for development, test, pre-production, production and DR/ASPE for developers, testers, project offices, internal IT customers and end users.


**1.1.12.7.13.4** **(08-01-2018)**

##### Server Product and Application Support Branch 2

1. The mission of the Server Product & Application Support Branch 2 is to provide Product and Business Application administration support for a portfolio of projects to deliver a stable server environment for development, test, pre-production, and DR/ASPE for developers, testers, project offices, internal IT customers and end users.


**1.1.12.7.13.5** **(08-01-2018)**

##### Server Product and Application Support Branch 3

1. The mission of the Server Product & Application Support Branch 3 is to provide Product and Business Application administration support for a portfolio of projects to deliver a stable server environment for development, test, pre-production, and DR/ASPE for developers, testers, project offices, internal IT customers and end users.


**1.1.12.7.13.6** **(08-01-2018)**

##### Server Product and Application Support Branch 4

1. The mission of the Server Product & Application Support Branch 4 is to provide Product and Business Application administration support for a portfolio of projects to deliver a stable server environment for development, test, pre-production, and DR/ASPE for developers, testers, project offices, internal IT customers and end users.


**1.1.12.7.13.7** **(08-01-2018)**

##### Operations Scheduling Branch

1. The Operations Scheduling Branch (OSB) assures efficient and secure information processing by integrating and supporting automated schedules, completing secure file transfers and developing efficient operating procedures to support and fund government agencies for the American Taxpayer.


**1.1.12.7.13.8** **(07-22-2022)**

##### Enterprise Automated Deployment Branch

1. The mission of the Enterprise Automated Deployment (EAD) Branch is to provide deployment services which meet or exceed IRS requirements to release approved changes and maintain the integrity of controlled environments. Additionally, the EAD Branch supports the fiduciary processing of disbursements to the American public. To accomplish this mission, the EAD Branch will:



   - Balance, validate and certify accuracy of Master File and CADE 2 refunds and other disbursements

   - Coordinate, plan and manage filing season release plans, deployments and reports

   - Support configuration management by establishing and maintaining source code baselining and version control for IRS critical systems

   - Support change management by coordinating and facilitating approval of changes to controlled environments

   - Support modernization by implementing tools and improving processes to bring the Service into alignment with industry standards and best practices


**1.1.12.7.13.9** **(02-24-2021)**

##### Project Response & Incident Management Branch

1. The mission of the Project Response & Incident Management Branch is to provide leadership, management and oversight for the Enterprise Computer Centers Special Programs, Incident and Problem Management Data Center Strategy initiatives and Risk Management/Mitigations.


**1.1.12.7.13.10** **(02-24-2021)**

##### Division Management Office

1. The mission of the DMO is to provide leadership management and oversight in the administration, planning and execution of IT initiatives to ensure program goals and objectives are achieved. To accomplish this mission, the DMO:



   - Oversees and reports on projects and all aspects of investment-portfolio management

   - Contributes to the IRS’s IT strategic management in terms of formulating and executing policy, its long-range objectives and internal administration

   - Serves as the division’s single point of entry for incoming suspense items and as a liaison to stakeholders and customers

   - Formulates and prepares supporting justifications for budgetary and staffing resources for programs, projects and activities, including cost projections and analyses and business cases for new investments

   - In addition to the role of the DMO, the DMO Chief supports the division director and provides leadership, management and oversight to DMO staff/ project managers and to the division’s branch chiefs to ensure the mission of the division is met


**1.1.12.7.14** **(02-24-2021)**

#### IT Operations Command Center Division

1. The IT Operations Command Center (ITOCC) division serves as IT’s first line of defense; we execute Event Management, Incident Management and Problem Management activities on the IRS’s mainframes, servers and the enterprise network by:



   - Providing 24x7x365 Level 1 & 2 monitoring and triage for the IRS enterprise

   - Proactively monitoring infrastructure and applications to avoid and minimize outages

   - Managing the restoration of service to customers during outages by providing escalation paths for expediting incident resolution through functional and hierarchical escalation to IT managers and technical teams responsible for incident resolution

   - Performing root cause analysis of applicable incidents to identify systemic deficiencies, opportunities for automation and additional monitoring requirements


2. ITOCC also develops and delivers technologies that support cross-IT service management processes, i.e. IT Service Management (ITSM) and ITIL.

3. ITOCC has six subordinate branches/offices:



   - Division Management Office

   - Mainframe Monitoring/Triage Branch

   - Server & Network Monitoring/Triage Branch

   - Incident & Problem Management Branch

   - Monitoring Solutions Branch

   - IT Services Management Branch


**1.1.12.7.14.1** **(02-24-2021)**

##### IT Operations Command Center Division Management Office

1. The mission of the ITOCC DMO is to provide leadership management and oversight in the administration, planning and execution of IT Initiatives to ensure program goals and objectives are achieved.

2. In addition to the role of the DMO, the DMO Chief supports the division director and provides leadership, management and oversight to DMO staff and to the division’s branch chiefs to ensure the mission of the division is met.


**1.1.12.7.14.2** **(02-24-2021)**

##### Mainframe Monitoring/Triage Branch

1. The mission of the Mainframe Monitoring/Triage Branch is to ensure that normal IT service operations are maintained. It is responsible for providing 24x7x365 solutions for proactive monitoring and resolution of critical infrastructure issues. The Branch utilizes industry best practices and processes and employs Level 1 & 2 Event Management (EM) and Incident Management (IM) methodologies to support these services. This branch is responsible for providing support for the systems used to receive and process tax returns and payments.


**1.1.12.7.14.3** **(02-24-2021)**

##### Server & Network Monitoring/Triage Branch

1. The mission of the Server & Network Monitoring/Triage Branch is to ensure normal IT service operations are maintained to minimize service outages on servers and the enterprise network. It is responsible for providing 24x7x365 solutions for proactive monitoring and resolution of critical infrastructure issues. The branch utilizes industry best practices and processes and employs Level 1 & 2 EM and IM methodologies to support these services. This branch is also responsible for providing support for all infrastructure and application servers enterprise-wide that house the applications responsible for the receipt and processing of tax returns and payments.


**1.1.12.7.14.4** **(02-24-2021)**

##### Incident & Problem Management Branch

1. The mission of the Incident & Program Management Branch is to minimize the adverse impact of premium systems delays and outages on business operations by facilitating the quick restoration of normal service operations and to identify, mitigate and resolve issues before they place enterprise systems and operations performance at risk. The branch intercepts actionable events to help reduce the number and severity level of service interruptions and ensure high availability. The branch also analyzes incident records and uses data collected by other IT Service Management processes to identify trends or significant performance issues and initiates root cause analysis activities to investigate and resolve underlying issues.


**1.1.12.7.14.5** **(02-24-2021)**

##### Monitoring Solutions Branch

1. The mission of the Monitoring Solutions Branch is to enable automated monitoring of system events by providing capabilities that allow the IRS to proactively isolate infrastructure and COTS application issues through holistic dashboard views coupled with automated ticket and assignment generation, as well as proactively restore services and mitigate outages quickly with actionable, correlated system and performance metrics.

2. The branch provides operational oversight to the Monitoring Management Section and the Monitoring Implementation Section.


**1.1.12.7.14.6** **(02-24-2021)**

##### IT Services Management Branch

1. The mission of the IT Services Management Branch (ITSM) is to provide systems support and services based on ITIL processes – which include integration and solution development, application administration for incident management, problem management, configuration management, asset management, change management, and ITSM tool administration and Infrastructure and Service Metric reporting.


**1.1.12.8** **(02-24-2021)**

### ACIO for Strategy and Planning

1. The mission of the Strategy and Planning (S&P) organization is to provide strategic and financial leadership to achieve responsible planning, execution and stewardship of IT.

2. S&P collaborates with IT leadership to provide policy and direction on administration of essential programs. Managed functions in S&P are strategic and capital planning, governance, vendor and contracts control, demand and risk management, space management and incident/emergency planning.

3. The ACIO for S&P leads the organization and reports to the CIO.

4. S&P has four subordinate divisions :



   - Financial Management Services

   - Business Planning & Risk Management

   - Investment & Portfolio Control & Oversight

   - Strategic Supplier Management


**1.1.12.8.1** **(02-24-2021)**

#### Financial Management Services

1. Financial Management Services (FMS) supports IRS IT by planning and executing IT budgets, preparing clear financial policy and providing financial services to the ACIOs. Serving as IT’s link to the CFO, FMS represents IT’s funding needs to Corporate IRS.

2. FMS has three subordinate branches:



   - Budget Execution

   - Budget Planning

   - Support Services


**1.1.12.8.1.1** **(02-24-2021)**

##### Budget Execution

1. The Budget Execution branch manages the IT budget and all aspects of plan execution, including certification, funding, transfers, labor projections, analyses and supporting budgeting systems. This includes the development and distribution of financial guidance outlining rules governing the expenditure of IT resources, and defining roles, responsibilities and the timeline related to the development and execution of the IT budget.

2. The Budget Execution branch has three subordinate sections:



   - Financial Plan Management

   - Program and Policy

   - Labor Management


**1.1.12.8.1.2** **(02-24-2021)**

##### Budget Planning

1. The Budget Planning branch coordinates and develops the annual IT budget submissions in compliance with the IRS’s goals and objectives, including Business Systems Modernization programs. The major functions of this office include:



   - Submission of budget requests to IT leadership, Department of the Treasury, OMB and Congress

   - Development of an IT Spend Plan

   - Development of lifecycle estimates for IT projects and legislative proposals.


2. The Budget Planning branch has three subordinate sections:



   - Plan Development

   - Special Programs

   - Estimation Program Office


**1.1.12.8.1.3** **(02-24-2021)**

##### Support Services

1. The Support Services branch oversees finance operations for assigned IT Divisions and enhances their ability to meet the IRS's business requirements through the execution of innovative financial solutions consistent with organizational goals and priorities.

2. The Support Services branch has four teams that provide help and services:



   - Team A

   - Team B

   - Team C

   - Team D


**1.1.12.8.2** **(02-24-2021)**

#### Business Planning & Risk Management

1. Business Planning and Risk Management (BPRM) supports IRS IT through demand and risk management, managing Enterprise Intake and leveraging management reporting and other repeatable processes to support risk-based decisions. As IT investments are put into play with intended outcomes, these variables are shared with the Investment and Portfolio Control and Oversight Division. Additionally, BPRM provides Section 508 Compliance and Assistive Technology Support business requirements support, audit oversight and reporting, Enterprise Life Cycle support across a diverse range of IT initiatives and Enterprise Risk Management support for IT.

2. BPRM has five subordinate offices:



   - Enterprise Intake

   - Enterprise Life Cycle

   - Information Resources Accessibility

   - Program Oversight Coordination

   - Requirements Program Office


**1.1.12.8.2.1** **(02-24-2021)**

##### Enterprise Intake

1. The Enterprise Intake (EI) office unites efforts between IRS business units, IT and suppliers in all phases of the investment and work request cycles. Through detailed investment analysis, this group makes recommendations to our Governance bodies to help them make informed investment decisions that align with the IRS’ strategic direction. EI has three subordinate offices.



   - Business Planning & Analysis

   - Technical Support Office

   - Work Request Support Office


**1.1.12.8.2.1.1** **(02-24-2021)**

###### Business Planning and Analysis

1. The Business Planning and Analysis (BPA) office partners with IRS executives and external stakeholders to ensure Selection, Planning and Management of an IT investment portfolio that aligns with IRS strategic priorities and demonstrates business value.


**1.1.12.8.2.1.2** **(02-24-2021)**

###### Technical Support Office

1. The Technical Support Office (TSO) manages and supports Micro Focus-Project Portfolio Management (PPM) Modules including Work Request Management System (WRMS), Enterprise Demand Management (EDM), Resource Management (RM) and Investment Proposals, Agile Requests, EA Change Requests , as well as Business Object reporting. TSO provides Release Management, Change Management, Configuration Management, Requirements Management, Design, Development and Quality Assurance for WRMS.


**1.1.12.8.2.1.3** **(02-24-2021)**

###### Work Request Support Office

1. The Work Request Support Office (WRSO) allows the IRS, via the Unified Work Request (UWR) process, to register demand for IT products and services into the Work Request Management System (WRMS). Using WRMS, WRSO supports the coordination between requesting organizations and suppliers in all phases of the WRMS process.


**1.1.12.8.2.2** **(02-24-2021)**

##### Enterprise Life Cycle

1. The purpose of the Enterprise Life Cycle (ELC) office is to provide direction, processes, tools and assets based on best practices to accomplish change in a consistent and repeatable manner. The ELC is a framework used by IRS projects to ensure consistency and compliance with government and industry best practices. The ELC framework is the workflow that projects follow to move an IT solution from concept to production while making sure that they follow IRS guidelines and are compatible with the overall goals of the IRS.


**1.1.12.8.2.3** **(02-24-2021)**

##### Information Resources Accessibility Program

1. The Information Resources Accessibility Program (IRAP) office delivers technical guidance and support on Section 508 and accessibility principles, assists customers with assistive technology features & functions and provides technical assistance to local Desktop Support staff to resolve complex assistive technology hardware and software issues. IRAP has two branches.


**1.1.12.8.2.3.1** **(02-24-2021)**

###### 508 Customer Support

1. The 508 Customer Support branch evaluates the needs of qualified individuals with disabilities to determine the appropriate assistive technology to accommodate functional limitations, evaluate new assistive technologies for potential use within the IRS and purchase assistance technology, maintenance and training.


**1.1.12.8.2.3.2** **(02-24-2021)**

###### 508 Program Support

1. The 508 Program Support branch provides Section 508 conformance oversight for all IT requisitions, capital planning documents and ELC milestones. This office also represents and supports the IRS for all external 508 reporting to such entities as OMB and Department of the Treasury and represents the IRS in cross-agency think tank groups towards improving 508 across the Government.


**1.1.12.8.2.4** **(07-22-2022)**

##### Program Oversight Coordination Office

1. The Program Oversight Coordination Office (PO) provides effective oversight to meet GAO, TIGTA and other management control requirements impacting the IT organization. PO is responsible for implementing and maintaining an efficient audit oversight process within the IT organization to ensure that conclusions leading to published recommendations are likely to be beneficial in reducing future programmatic, technical, business or IT risk. This is accomplished by:



   - Developing and managing Pre-Audit Vulnerability reviews to ensure audit readiness

   - Collaborating and monitoring audit activities to ensure that audit reports and responses reflect appropriate conclusions and findings

   - Maintaining the PO SharePoint site, IT Audit List and tracking for all IT Planned Corrective Actions (PCAs)

   - Sharing best practices across IT to ensure the audit process runs smoothly and effectively

   - Delivering monthly and biannual training, educational sessions and reference guides on audit processes/procedures for IT executives and support staff

   - Producing Monthly Audit Status and Activities Executive Report for the CIO

   - Monitoring, reporting, and processing closure documentation for IT Planned Corrective Actions

   - Producing Monthly Open IT PCA Progress Executive Report and Statistics for the CIO

   - Managing the PCA Risk Management process for due date extension requests


**1.1.12.8.2.5** **(08-01-2018)**

##### Requirements Engineering Program Office

1. The Requirements Engineering Program Office (REPO) is the IRS authority that provides standards and guidance on requirements engineering activities, process modeling and requirements-related solutions. REPO has two subordinate offices.


**1.1.12.8.2.5.1** **(07-22-2022)**

###### Requirements, Guidance & Outreach

1. The Requirements, Guidance & Outreach (G&O) office provides requirements guidance, methods and techniques to requirements practitioners, IT projects and delivery partners, while promoting Agile/Lean practices. The G&O Office also provides coaching, mentoring and advising, as well as online requirements and Agile training and information sharing exchanges for the user community.


**1.1.12.8.2.5.2** **(07-22-2022)**

###### Requirements Support

1. The Requirements Support (RSO) office provides requirements and tools services to IT programs, projects, application developers and requirements practitioners. Using agile as a guiding principle, these services are designed to help IT practitioners plan, document and manage their requirements efforts to improve IT delivery outcomes. Additionally, the RSO manages all standard requirements tool(s) on behalf of the IRS enterprise, including product training and end-user support.


**1.1.12.8.3** **(02-24-2021)**

#### Investment & Portfolio Control & Oversight

1. Investment & Portfolio Control & Oversight (IPCO) leads and engages with enterprise stakeholders on a collection of support services to plan, select manage, govern and evaluate IT investments to effectively manage the business of technology management.

2. IPCO has five subordinate offices:



   - Portfolio Management & Oversight

   - Investment & Portfolio Governance

   - Investment Management & Control

   - Investment & Portfolio Evaluation

   - Strategic Planning & Execution


**1.1.12.8.3.1** **(02-24-2021)**

##### Portfolio Management & Oversight

1. The Portfolio Management & Oversight (PMO) office enables more efficient and effective portfolio and program management reporting and decision making across the IRS through the design, development, implementation and administration of a web-based (IRS intranet) standard portfolio management tool, providing cost savings as an internal service provider. Additionally, PMO provides expertise, methods, practices and processes for meeting internal and external performance reporting requirements for IT, which includes the development and submission of deliverables to the CIO, the Chief Financial Officer (CFO), the DCOS, Department of the Treasury, OMB, Congress and the IRS Oversight Board. Below are significant work products produced by the PMO:



   - Administer Oracle Portfolio Management tool (formerly ProSight) including the development and maintenance of custom portfolio applications and reports

   - Dashboards - IT Internal/External Metrics Dashboards, and S&P Dashboard

   - Consultation with ACIO performance teams on measures development and adjustment

   - Quarterly IT Business Performance Review (BPR) development and submission of IRS Oversight Board measures

   - Quarterly Omnibus IT Investment Reporting support

   - IT Annual Management Discussion and Analysis (IRS end-of-year reporting)


**1.1.12.8.3.2** **(02-24-2021)**

##### Investment & Portfolio Governance

1. Investment and Portfolio Governance Office (IPGO) designs, develops and maintains the governance framework, policy and preferred practices that supports the achievement of the IRS mission and strategic goals through the establishment of governance capabilities. This structure will be the basis for a working relationship between investments, programs and projects and their respective decision-making Executive boards and committees. This office provides direct support to key enterprise-level IT governance boards as well as coaching to other organizations with IT governance boards. IPGO serves as the process owner for the enterprise IT governance process and collaborates with the organizations owning related governance and other processes to ensure seamless oversight of IRS’s IT Portfolio. The services provided by the IPGO:



   - Maintains and enhances the Enterprise Information Technology Governance process, standards, guidance and training

   - Maintains a website and repository to house resources and documentation for the Domain-based Executive Steering Committees (ESCs)

   - Maintains the IT Governance Register (ESC demographic data)

   - Maintains governance board charters and membership lists

   - Provides direct technical support to the enterprise-level governance boards as directed by the ACIO S&P

   - Provides coaching to governance boards not under direct support


**1.1.12.8.3.3** **(02-24-2021)**

##### Investment Management & Control

1. The purpose of the Investment Management & Control (IMC) office is to provide continuous monitoring of IT projects, investments or useful components/modules through the development or acquisition lifecycle to ensure that projects and systems are performing as expected. The Control Phase is characterized by decisions to continue, change or terminate an investment or useful component/module or to make future funding releases conditional on corrective actions. This phase is supported and coordinated by the IPM Investment Management Control (IMC), which provides information and analysis to the ESCs and other governing bodies to assist in monitoring portfolio and investment performance. The information generated through tracking of project and portfolio performance also informs the Evaluate, Pre-Select and Select phases to help in the analysis and decisions on project re-selection. Using the results of these analyses, IRS executives decide whether to continue, change or terminate an investment or to make future funding releases conditional on corrective actions. IMC supports and coordinates with a variety of other stakeholders to implement the Control phase and monitor and track the progress and performance of the IT investments. Stakeholders include IRS project managers, PMO, Business Systems Planning (BSP) offices of the business and functional operating divisions, Security and Privacy and Infrastructure. IMC provides the following services:



   - Provides cost/schedule baseline and performance measures for IT investments

   - Monthly variance reporting and subsequent meetings to brief Department of the Treasury

   - IT investment team training on the SharePoint Investment Knowledge Exchange (SPIKE) tool

   - Analytical support to the IT FMS and CFO organizations ensuring sound IT budget data

   - Department of the Treasury data calls focusing on the IRS IT portfolio

   - Investment/portfolio analysis for IRS leadership

   - Audit support on topics involving Control activities


**1.1.12.8.3.4** **(02-24-2021)**

##### Investment & Portfolio Evaluation

1. The mission of the Investment & Portfolio Evaluation (IPE) office is to equip IRS decision makers with information products and capabilities (enterprise policy and standards, measures, process analysis, reviews and reporting) that enable them to achieve desired portfolio, program and project outcomes related to the evaluation process of capital planning. The IPE office also provides guidance, process and tool support for the capture and disposition of Lessons Learned to assist programs in following repeatable best practices:



   - Enhance the Capital Planning and Investment Control (CPIC) evaluation process through Lessons Learned and in compliance with the OMB guidance

   - Execute Post-Implementation Reviews (PIRs) on major IT projects semi-annually and report results to executive leadership and the Department of the Department of the Treasury

   - Execute Operational Analysis (OA) on major IT investments annually and report results to executive leadership and the Department of the Department of the Treasury

   - Maintain the IT Lessons Learned Library

   - Maintain the IPE Evaluation SharePoint site


**1.1.12.8.3.4.1** **(02-24-2021)**

###### Strategic Planning & Execution

1. The Strategic Planning & Execution (SP&E) office is designed to support the strategic planning process and ensure ongoing collaboration with forward-focused programs within S&P, ES and elsewhere within IT and across the IRS. The SP&E office facilitates the planning and execution of the IRS Integrated Modernization Business Plan by working directly with the programs to collect data that will be used to report out on all Modernization Plan activities. The SP&E office will work to populate monthly, quarterly and annual reports for internal and external stakeholders on the execution of the plan and progress achieved towards modernizing IRS.



   - Integrate existing strategic processes into a repeatable IT strategic planning process

   - Support development and execution against the IT Strategic Plan (ITSP) including the publishing of the Annual Key Insights Report (AKIR)

   - Support development of targets and monitor progress for measuring performance of IT Modernization

   - Lead integration with forward-driven “top-down” modernization planning across FMS and EA

   - Maintain the SP&E Evaluation SharePoint site


**1.1.12.8.4** **(07-22-2022)**

#### Strategic Supplier Management

1. Strategic Supplier Management (SSM) supports IRS Information Technology by:



   - Strategically managing acquisitions and vendors and maximizing the IRS' investment in key commodities

   - Providing guidance on acquiring IT, interpreting IT acquisition policies and determining best practices for collaboration between SSM stakeholders and SSM customers

   - Coordinating across IT to integrate acquisition improvement initiatives

   - Managing integrated spend analytics tools and reports to improve acquisition-related processes, supplier management and contract management/administration activities

   - Serving as IT liaison for LSS process improvements

   - Managing Rent Reduction, Shared Workstations, Unassigned Workspace/Hoteling, Critical Hiring and Workspace Standards projects/activities impacting IT employees


2. SSM has four subordinate branches:



   - Strategic Management Support Branch

   - Program Management Branch

   - Space Continuity and Contingency Planning Branch

   - Spend Analytics Branch


**1.1.12.8.4.1** **(07-22-2022)**

##### Strategic Management Support

1. The Strategic Management Support (SMS) branch provides leadership and subject matter expertise for high-impact acquisitions, vendor engagements and contract management initiatives across all IT functional areas/disciplines.

2. The SMS is responsible for maintaining and optimizing IT software assets across all phases of software ownership, support strategic sourcing and managing enterprise IT acquisition governance and process improvement initiatives.

3. SMS has two subordinate sections:



   - Strategic Sourcing Section

   - Software Asset Management Section


4. The Strategic Sourcing Section provides collaborative sourcing expertise and support for software, infrastructure, and infrastructure-related service acquisitions. The Strategic Sourcing Office will review software acquisitions over $500K, infrastructure and infrastructure-related service acquisitions over $1M. Responsibilities include:



   - Improving effectiveness by minimizing risk to IT service delivery; improving vendor performance; modernization; leveraging competition and synchronizing needs and vendor capabilities

   - Collaborating with the Office of Procurement and vendor/supplier community to develop high-value, enterprise-wide, IT business agreements that effectively execute statutory authority (e.g., improve service levels, reduce costs, and modernize relevant infrastructure)

   - Reviewing IT requisitions greater than $1M annual contract value to identify potential cost-containment, gain efficiencies or improvements in the execution of the requisition reviews/approvals


5. The Software Asset Management Section’s responsibilities include the following:



   - Overseeing and managing of the Software Assessment Management (SAM) activities for the IT organization

   - Improving effectiveness by serving as the IT lead for the design, implementation and enhancement of supplier/application management and contract management/administration activities

   - Establishing and implementing policy and direction of the IRS’s SAM

   - SAM environment across all Tiers and is the centralized point of oversight and governance

   - Integrating people, strategy technology and data required to effectively operate software asset lifecycle activities

   - Creating awareness of SAM goals and providing education to key stakeholders


**1.1.12.8.4.2** **(07-22-2022)**

##### Program Management

1. The Program Management (PM) branch serves as IT’s central POC for all matters related to acquisitions. It is the primary liaison across IT to integrate acquisition improvement initiatives into IT financial management processes; conducts targeted reviews of key commodities, contracts and supplier trends.

2. The PM branch provides Contract Execution Oversight in tracking and managing contract schedules, assisting Acquisition Program Managers in remaining compliant with Procurement policies and maximizing cost savings and providing contract management support to all SSM managed acquisitions. Responsibilities include:



   - Providing centralized management and contract administration support for high-impact, enterprise-wide software, hardware, and vendor labor support contracts/delivery orders for pre-award and post-award activities

   - Serving as liaison to the Office of Procurement to facilitate meeting Acquisition Planning dates and finding solutions for cross-functional challenges

   - Serving as liaison across IT to collaborate with Acquisition Program Managers (APMs) on all matters related to procurement (e.g., Receipt and Acceptance, Contractor Performance Assessment Reports System (CPARS), AUOs and providing quarterly updates to the Procurement Spend Plan (PSP)

   - Serving as liaison to IT FMS and ACIO program areas to execute acquisition-related financial management processes and management controls to: document, capture, realign and monitor current year contract savings and modify the IT Core Services Budget to realize identified out-year savings/initiative results


3. PM has one subordinate section:



   - Project Management Section


   - The Project Management Section provides Contracting Officer’s Representative (COR) Support in the administration and management of Federal government contracts for IT and/or enterprise-wide software acquisitions


**1.1.12.8.4.3** **(07-22-2022)**

##### Space Continuity and Contingency Planning

1. The Space Continuity and Contingency (SC&C) branch coordinates Critical Hiring (relating to space needs), Unassigned Workspace/Hoteling and Workspace Standards projects/activities impacting IT employees.



   - Continuity Planning prepares the IT organization for potential unforeseen events, such as, man-made attacks, natural disasters or technological emergencies.

   - Contingency Planning prepares the IT organization for a potential government shutdown due to a lapse of appropriations.

   - Federal Acquisition Certification for Program and Project Managers (FAC-P/PM) administers and executes the overall FAC-P/PM Core and IT Core Plus certification program to ensure the appropriate program governance, processes, procedures and certification standards are applied fairly and consistently throughout the impacted IT organizations.


**1.1.12.8.4.3.1** **(07-22-2022)**

###### Spend Analytics

1. The Spend Analytics (SA) branch supports SSM stakeholders by obtaining, analyzing, reporting and using data to inform and improve IT contract management processes and results. Responsibilities include:



   - Serving as the IT lead for the design, implementation and enhancement of spend analytics systems and tools

   - Developing and delivering contract-related data sets, reports and dashboards

   - Identifying acquisition business scenarios to develop Robotics Process Automation (RPA) to save manual effort and improving process efficiency

   - Developing prediction models using Machine Learning/Artificial Intelligence algorithms and statistical models to forecast milestone dates and events

   - Assessing benefits and value additions to processes and users as part of Technology Insertion

   - Conducting Proof of Concepts on new technologies and synergies and identifying risk thresholds

   - Developing customized analytics reports, visualizations and related tools for acquisition, contract management performance measure development and tracking

   - Developing specific metrics that indicate areas of concern, presentation of performance or status of important aspects of processes related to IT acquisitions, timely awards, contract and vendor management, contract oversight and acquisition planning

   - Providing SharePoint expertise to design and developing custom workflows and forms to support automation of tasks and processes


**1.1.12.9** **(07-22-2022)**

### ACIO for Individual Masterfile Modernization

1. The mission of the ACIO for Individual Masterfile (IMF) Modernization (Mod) is to:



   - lead an enterprise-wide planning and delivery approach to drive forward priorities for IRS modernization

   - lead Modernization program integration and delivery across IT Delivery Partners and Business Operating Divisions (BODs) and Functional Operating Divisions (FODs)

   - initiate and lead a transformational effort that will deliver incremental improvements & benefits ultimately resulting in the retirement of the entire IMF ecosystem.


2. IMF Mod has one subordinate office:



   - Customer Account Data Engine 2 (CADE 2)


**1.1.12.9.1** **(07-22-2022)**

#### Customer Account Data Engine 2

1. The mission of the Customer Account Data Engine 2 (CADE 2) program is to build a state-of-the-art individual taxpayer account processing system and leverage data-driven technologies to improve service to taxpayers, enhance IRS tax administration and ensure fiscal responsibility. To achieve this mission, CADE 2 will reengineer the Individual Master File (IMF) using modern programming languages, developing a relational database that aggregates individual taxpayer records and makes taxpayer data available to organizations across the IRS. CADE 2 will provide the technical improvements necessary to sustain ongoing administration of the nation’s tax laws while enabling future business process reengineering to improve taxpayer services. This program builds strong and mutually beneficial relationships with customers, delivery partners and stakeholders to ensure successful delivery and implementation of the CADE 2 solution.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-012#addtoany "Show all")

A2A