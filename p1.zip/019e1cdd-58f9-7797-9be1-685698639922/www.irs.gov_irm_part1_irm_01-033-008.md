---
url: "https://www.irs.gov/irm/part1/irm_01-033-008"
title: "1.33.8 Estimating Trust Fund Costs | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-033-008#main-content)

- 1.33.8  [Estimating Trust Fund Costs](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947015952)
  - 1.33.8.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405946919392)
    - 1.33.8.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405946915936)
    - 1.33.8.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947013152)
    - 1.33.8.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947006832)
      - 1.33.8.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947003040)
      - 1.33.8.1.3.2  [Associate CFO and Deputy Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947001456)
      - 1.33.8.1.3.3  [Cost and User Fees Office](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405946998400)
      - 1.33.8.1.3.4  [Business Unit Finance Offices](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920151888)
    - 1.33.8.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920146384)
    - 1.33.8.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920142688)
    - 1.33.8.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920139712)
    - 1.33.8.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920055584)
    - 1.33.8.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920044176)
  - 1.33.8.2  [General Methodology](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920041568)
  - 1.33.8.3  [Quarterly Reports](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920039136)
    - 1.33.8.3.1  [Report on Trust Fund Costs](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405920035232)
    - 1.33.8.3.2  [Cost Analysis Variance Report](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947117408)
    - 1.33.8.3.3  [Quarterly Estimate of Trust Fund Expenses](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947111904)
  - 1.33.8.4  [Annual and Ten-Year Trust Funds Forecast Report](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947107552)
  - 1.33.8.5  [Fiscal Year-End Trust Fund Report](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405947102576)
  - 1.33.8.6  [Periodic Reviews](https://www.irs.gov/irm/part1/irm_01-033-008#idm140405917731424)

# Part 1. Organization, Finance, and Management

# Chapter 33. Strategic Planning, Budgeting and Performance Management Process

# Section 8. Estimating Trust Fund Costs

* * *

## 1.33.8 Estimating Trust Fund Costs

#### Manual Transmittal

June 21, 2024

#### Purpose

(1) This transmits new IRM 1.33.8, Strategic Planning, Budgeting and Performance Management Process, Estimating Trust Fund Costs.

#### Material Changes

(1) Content has been incorporated from IRM 1.35.17 as follows:

|     |     |
| --- | --- |
| **Subsection Number** | **Content Description** |
| 1.33.8.1, Program Scope and Objectives | Contains content previously found in IRM 1.35.17.1 |
| 1.33.8.1.1, Background | Contains content previously found in IRM 1.35.17.1.1 |
| 1.33.8.1.2, Authorities | Contains content previously found in IRM 1.35.17.1.2 |
| 1.33.8.1.3, Responsibilities | Contains content previously found in IRM 1.35.17.1.3 |
| 1.33.8.1.3.1, CFO and Deputy CFO | Contains content previously found in IRM 1.35.17.1.3.1 |
| 1.33.8.1.3.2, Associate CFO and Deputy Associate CFO for Corporate Budget | Contains content previously found in IRM 1.35.17.1.3.2 |
| 1.33.8.1.3.3, Cost and User Fees Office | Contains content previously found in IRM 1.35.17.1.3.3 |
| 1.33.8.1.3.4, Business Unit Finance Offices | Contains content previously found in IRM 1.35.17.1.3.4 |
| 1.33.8.1.4, Program Management and Review | Contains content previously found in IRM 1.35.17.1.4 |
| 1.33.8.1.5, Program Controls | Contains content previously found in IRM 1.35.17.1.5 |
| 1.33.8.1.6, Terms/Definitions | Contains content previously found in IRM 1.35.17.1.6 |
| 1.33.8.1.7, Acronyms | Contains content previously found in IRM 1.35.17.1.7 |
| 1.33.8.1.8, Related Resources | Contains content previously found in IRM 1.35.17.1.8 |
| 1.33.8.2, General Methodology | Contains content previously found in IRM 1.35.17.2 |
| 1.33.8.3, Quarterly Reports | Contains content previously found in IRM 1.35.17.3 |
| 1.33.8.3.1, Report on Trust Fund Costs | Contains content previously found in IRM 1.35.17.3.1 |
| 1.33.8.3.2, Cost Analysis Variance Report | Contains content previously found in IRM 1.35.17.3.2 |
| 1.33.8.3.3, Quarterly Estimate of Trust Fund Expenses | Contains content previously found in IRM 1.35.17.3.3 |
| 1.33.8.4, Annual and Ten-Year Trust Funds Forecast Report | Contains content previously found in IRM 1.35.17.4 |
| 1.33.8.5, Fiscal Year-End Trust Fund Report | Contains content previously found in IRM 1.35.17.5 |
| 1.33.8.6, Periodic Reviews | Contains content previously found in IRM 1.35.17.6 |

(2) IRM 1.33.8.1.3, Responsibilities, updated responsibilities to match the revised CFO organization.

(3) IRM 1.33.8.3.1(5), W&I updated with Taxpayer Services.

(4) Throughout IRM - Made minor writing edits for clarity and precision and updated office names to correspond with organizational changes within CFO.

#### Effect on Other Documents

This IRM was originally published as IRM 1.35.17 on August 23, 2022. The chapter has moved. This IRM incorporates information from prior IRM 1.35.17, Estimating Trust Fund Costs.

#### Audience

Business unit finance offices and employees responsible for estimating Unemployment Compensation, Old-Age, Survivors, Disability and Hospital Insurance (OASDHI), and Black Lung Disability Trust Fund Costs.

#### Effective Date

(06-21-2024)

Teresa R. Hunter

Chief Financial Officer

**1.33.8.1** **(06-21-2024)**

### Program Scope and Objectives

1. Purpose: This IRM provides policies and procedures for estimating costs for providing services to the OASDHI; Unemployment Compensation; and Black Lung Disability Trust Funds.

2. Audience: The audience for this IRM is business unit finance offices responsible for estimating OASDHI, Unemployment Compensation, and Black Lung Disability Trust Fund Costs.

3. Policy Owner: CFO owns these policies.

4. Program Owner: The CFO Cost and User Fees office oversees this program.

5. Primary Stakeholders: Business units that estimate the trust fund costs are stakeholders for this IRM.

6. Program Goals: The program goals are to ensure internal controls for estimating trust fund costs are implemented and cost estimates are accurate and consistent.


**1.33.8.1.1** **(06-21-2024)**

#### Background

1. The IRS provides tax administration and support for the OASDHI, Unemployment Compensation, and Black Lung trust fund programs.

2. The OASDHI Programs include the Old-Age Survivors Insurance (OASI) program, the Disability Insurance (DI) program, and the Hospital Insurance (HI) Trust Fund. The Social Security Act (SSA) of 1935 (Pub. L. No. 74-271) established the Old-Age Survivors Insurance (OASI) program, and Title II of the SSA authorizes the OASI and Disability Insurance (DI) programs. The Hospital Insurance (HI) Trust Fund, also known as Medicare Part A, is a health insurance program authorized in 1965 under Title XVIII of the SSA.



1. The OASI and DI Trust Funds are distinct legal entities operated independently by the Social Security Administration, but to illustrate the actuarial status of the entire program, the fund operations are often combined on a hypothetical basis (OASDI). The OASI Trust Fund was established in 1940 as a separate account in the U.S. Treasury to pay monthly benefits to retired-worker (old-age) beneficiaries, their spouses and children, and survivors of deceased insured workers. The DI Trust Fund, established in 1956, pays monthly benefits to disabled-worker beneficiaries and to their spouses and children. It also provides rehabilitation services to the disabled.

2. The HI Trust Fund is administered by the U.S. Department of Health & Human Services. It covers specified inpatient hospital services, post-hospital skilled nursing care, home health services, and hospice care for aged and disabled individuals who meet the eligibility requirements.

3. To fund the OASDHI programs, the Federal Insurance Contributions Act (FICA) authorized payroll taxes to be paid by both employees and employers. Similarly, under the Self-Employment Contributions Act of 1954 (Pub. L. No. 83-761), self-employed persons must make payroll tax contributions on their covered net earnings from self-employment. The Social Security Administration and the Department of the Treasury (Treasury) share responsibility for administering the FICA tax system.


3. The Unemployment Compensation program, which received its framework under the SSA Titles III, IX, and XII and the Federal Unemployment Tax Act (FUTA) of 1939, is funded through FUTA taxes paid by employers to compensate people who are unemployed. The Department of Labor and Treasury share responsibility for administering the FUTA tax system.

4. The Black Lung Benefits Revenue Act of 1977 established the Black Lung Disability Trust Fund within Treasury. It imposed an excise tax on coal mine operators to fund monthly payments and medical benefits to miners disabled by black lung disease. The Department of Labor and Treasury share responsibility for administering the Black Lung Disability Trust Fund.

5. Treasury’s Bureau of the Fiscal Service (Fiscal Service) is responsible for administrating, maintaining and investing trust fund monies. The IRS performs the following activities for FICA, FUTA and Black Lung taxes:



1. Processing returns

2. Processing payments

3. Providing accounts management

4. Collecting unpaid assessments

5. Examining returns

6. Assessing penalties and interest

7. Performing document matching

8. Providing appeal services

9. Conducting criminal investigations


6. Treasury requires quarterly IRS reporting of the estimated costs incurred for services for the FICA, FUTA and Black Lung programs. Every year, the IRS also provides Treasury a ten-year forecast of its estimated annual costs to support each program.

7. The Secretary of the Treasury pays the Treasury General Fund quarterly for the estimated IRS costs of supporting:



1. the OASDHI and Unemployment Compensation programs and

2. the Black Lung program up to a limit of $356,000 per year.


**1.33.8.1.2** **(06-21-2024)**

#### Authorities

1. [Social Security Act,](http://www.ssa.gov/history/35actinx.html) Pub. L. No. 74-271

2. 42 USC 401, [Trust Funds](https://www.gpo.gov/fdsys/granule/USCODE-2011-title42/USCODE-2011-title42-chap7-subchapII-sec401/content-detail.html)

3. 42 USC 1104, [Unemployment Trust Fund](http://uscode.house.gov/view.xhtml?req=(title:42%20section:1104%20edition:prelim))

4. 26 USC 9501, [Black Lung Disability Trust Fund](http://uscode.house.gov/view.xhtml?req=(title:26%20section:9501%20edition:prelim))

5. Treasury Directive 32-06, [Administrative Expenses for Trust Funds](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td32-06.aspx) (Jan. 31, 2018)


**1.33.8.1.3** **(06-21-2024)**

#### Responsibilities

1. This section provides responsibilities for:



1. The CFO and Deputy CFO.

2. The Associate CFO and Deputy Associate CFO for Corporate Budget.

3. The Cost and User Fees office.

4. Business unit finance offices.


**1.33.8.1.3.1** **(06-21-2024)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO oversee the policy for estimating trust fund costs.


**1.33.8.1.3.2** **(06-21-2024)**

##### Associate CFO and Deputy Associate CFO for Corporate Budget

1. The Associate CFO and Deputy Associate CFO for Corporate Budget are responsible for:



1. Ensuring policies, procedures, standards and controls for estimating trust fund costs are in place.

2. Approving the Report on Quarterly Costs, the Annual and Ten-Year Trust Funds Forecast Report and the Fiscal Year-End Trust Fund Report.


**1.33.8.1.3.3** **(06-21-2024)**

##### Cost and User Fees Office

1. The Cost and User Fees office reports to the Deputy Associate CFO for Corporate Budget and is responsible for:



01. Developing and communicating policies, procedures, standards and controls for estimating trust fund costs.

02. Reviewing, validating and approving the business unit methodologies for estimating trust fund costs.

03. Calculating the corporate overhead rate to be applied to labor and benefit costs (as described in IRM 1.33.5.2.5.3, Calculating Cost Outside of the Cost Module) to determine the full cost of supporting the trust funds.

04. Reviewing Treasury Directive 32-06, Administrative Expenses for Trust Funds, annually for updates.

05. Developing quarterly costs templates for the business units.

06. Preparing the Report on Quarterly Trust Fund Costs and the Annual and Ten-Year Trust Funds Forecast Report based on business unit submissions.

07. Preparing the Cost Analysis Variance Report, obtaining and validating justifications for material variances and any judgmentally sampled items, and adjusting the quarterly trust fund report as appropriate.

08. Creating the Quarterly Estimate of Trust Fund Expenses billing document.

09. Briefing the Deputy Associate CFO for Corporate Budget on the Report on Quarterly Trust Fund Costs, the Annual and Ten-Year Trust Funds Forecast Report and the Fiscal Year-End Trust Fund Report.

10. Submitting the approved Quarterly Estimate of Trust Fund Expenses to the Fiscal Service.

11. Reviewing the business units’ supporting documents and calculations on a revolving schedule, briefing management on the review results and providing feedback to the business units.

12. Maintaining a detailed audit file with original source documents received from the business units, calculations used to compile reports and CFO executive approvals for a minimum of three years.


**1.33.8.1.3.4** **(06-21-2024)**

##### Business Unit Finance Offices

1. The business unit finance offices in organizations supporting the trust funds are responsible for:



1. Capturing the direct costs for trust fund activities.

2. Completing Quarterly Cost Templates within 25 days of the end of each quarter that include the labor and benefit costs, applied overhead costs, and any other direct costs (e.g., travel, training, supplies, etc.) expended for processing returns, enforcing taxpayer compliance and providing customer service for the trust funds.

3. Providing the Cost and User Fees office with explanations for variances based on the stated materiality criteria in the Cost Analysis Variance Report and any additional variance the office judgmentally selects during the review process.

4. Reviewing supporting documentation to ensure trust fund costs are accurately estimated.

5. Maintaining a detailed audit file with the original source documents and electronic files used to prepare the Quarterly Cost Templates for a minimum of three years.

6. Providing information to the Cost and User Fees office annually for preparing the Annual and Ten-Year Trust Funds Forecast Report for the next fiscal year and subsequent ten budget years.


**1.33.8.1.4** **(06-21-2024)**

#### Program Management and Review

1. The following program reports are used to review estimated trust fund costs quarterly.



1. Report on Trust Fund Costs

2. Cost Analysis Variance Report

3. Quarterly Estimate of Trust Fund Expenses


2. Program effectiveness is measured by providing accurate and consistent estimated costs.


**1.33.8.1.5** **(06-21-2024)**

#### Program Controls

1. The following controls are in place to ensure compliance.



1. Quarterly statement of difference

2. Annual reviews of costing methodology


**1.33.8.1.6** **(06-21-2024)**

#### Terms/Definitions

1. The following terms and definitions apply to this program.



01. **Benefit rate** \- The rate calculated by dividing the total benefit costs of the organization by the total salary costs (permanent and temporary salaries) of the organization. Each program applies this rate to estimated salary costs to determine the program’s benefit costs.

02. **Corporate overhead rate** \- The rate calculated annually by the Cost and User Fees office and applied to total labor and benefit costs to determine the full cost of providing services.

03. **Direct hours** \- Labor hours incurred by IRS employees that can be specifically identified with or assigned to a program, activity or output.

04. **Direct staff years** \- Direct hours converted to staff years using the fiscal year’s compensable hours.

05. **Federal Insurance Contributions Act (FICA)** \- A U.S. payroll or employment tax imposed on both employees and employers to fund Social Security and Medicare.

06. **Full cost** \- All costs used in generating outputs, including all direct and indirect costs.

07. **Full time equivalent** \- The total number of regular hours worked and approved leave taken by employees, divided by the fiscal year’s compensable hours.

08. **Federal Unemployment Tax Act (FUTA)** \- A U.S. payroll or employment tax imposed on employers to fund unemployment compensation.

09. **Indirect hours** \- Total available hours for an organization less the direct hours spent on programs.

10. **Trust fund** \- An account established to record receipts used to finance specific purposes or programs under a trust agreement or statute.


**1.33.8.1.7** **(06-21-2024)**

#### Acronyms

1. The following acronyms apply to this program.




| **Acronym** | **Description** |
| --- | --- |
| FICA | Federal Insurance Contributions Act |
| Fiscal Service | Bureau of the Fiscal Service |
| FUTA | Federal Unemployment Tax Act |
| IFS | Integrated Financial System |
| OASDHI | Old-Age, Survivors, Disability and Hospital Insurance |
| SSA | Social Security Act |


**1.33.8.1.8** **(06-21-2024)**

#### Related Resources

1. [Federal Accounting Standards Advisory Board Accounting Concepts and Standards, Standard No. 4, Managerial Cost Accounting](https://fasab.gov/accounting-standards/document-by-chapter/)

2. IRM 1.33.5, Managerial Costing


**1.33.8.2** **(06-21-2024)**

### General Methodology

1. The business units use their respective timekeeping systems, subject matter experts and the Integrated Finance System (IFS) to estimate labor and benefit costs supporting the trust funds. Costs include administrative and management support of trust fund activities.

2. The Cost and User Fees office applies the corporate overhead rate to the business units' costs to determine the full cost of supporting the trust funds.


**1.33.8.3** **(06-21-2024)**

### Quarterly Reports

1. Three trust fund reports are created quarterly by the Cost and User Fees office and briefed to Corporate Budget leadership:



1. Report on Trust Fund Costs

2. Cost Analysis Variance Report

3. Quarterly Estimate of Trust Fund Expenses


2. The Deputy Associate CFO for Corporate Budget approves the reports.


**1.33.8.3.1** **(06-21-2024)**

#### Report on Trust Fund Costs

01. The Report on Trust Fund Costs consolidates the business unit costs for executive review and approval.

02. The Cost and User Fees Office:



    1. Develops and distributes the Quarterly Cost Template to business units.

    2. Calculates the overhead rate and reviews the methodology for estimating trust fund costs annually.

    3. Compiles the business units' Quarterly Cost Templates into the Report on Trust Fund Costs.

    4. Analyzes the data for material or unexpected variances between the reporting quarter and the same quarter of the prior year.

    5. Corresponds with the business units for explanations of variances.

    6. Adjusts the Report on Trust Fund Costs.

    7. Prepares the Quarterly Estimate of Trust Fund Expenses.


03. Business unit finance offices:



    1. Maintain desk procedures for developing quarterly trust fund cost estimates based on all direct costs, to include labor and benefits and their related applied overhead as well as any other direct costs (e.g., travel, training, supplies, etc.), and coordinate changes with the Cost and User Fees office.

    2. Prepare, review and submit Quarterly Cost Template and justifications for significant variances in the Cost Analysis Variance Report to the Cost Accounting and User Fees office.

    3. Develop estimates to support the trust fund costs and complete the Quarterly Cost Template by:


    1. Determining direct hours used to perform trust fund work.

    2. Increasing direct hours to full time equivalent by including the appropriate rate of indirect hours.

    3. Applying salary and benefit rates to those hours to determine the total labor and benefit costs for supporting the trust funds.

    4. Applying the overhead rate to the total labor and benefit costs.

    5. Including any other identified direct costs (e.g., travel, training, supplies, etc.).


04. The SB/SE division develops the labor and benefit costs for its:



    1. Field collection for balance due FICA and FUTA returns.

    2. Automated call site collection of balance due FICA and FUTA returns.

    3. Field and campus examinations of FICA, FUTA and Black Lung Disability returns.

    4. Campus FUTA units that perform document matching activities.

    5. Combined Annual Wage Reporting unit in the SB/SE campuses for FICA document matching activities.

    6. Headquarters FICA and FUTA program oversight.

    7. Communications and Stakeholder Outreach costs for FICA activities.


05. The Taxpayer Services division develops the labor and benefit costs for its:



    1. Campus processing of paper and electronic forms for FICA and FUTA.

    2. FUTA customer account calls and correspondence.

    3. Campus FICA customer account calls and correspondence.

    4. Headquarters FICA and FUTA program oversight.


06. The Appeals division develops the labor and benefit costs for its technical employees working on cases with FICA and FUTA taxes.

07. The LB&I division develops the labor and benefit costs for examining FICA, FUTA and Black Lung Disability returns.

08. The TE/GE division:



    1. Develops the labor and benefit costs for examining FICA and FUTA returns, including supervision and support costs.

    2. Uses IFS to determine the labor and benefit cost of the Federal, State and Local Government Division, which is 100% devoted to employment tax issues.


09. Chief Counsel develops the labor and benefit costs for its case work that includes FICA and FUTA return issues worked by Counsel's SB/SE, TE/GE, and Procedure and Administration offices.

10. The CI division develops the labor and benefit costs for its work on FICA return issues in employment tax investigations.


**1.33.8.3.2** **(06-21-2024)**

#### Cost Analysis Variance Report

1. The Cost Analysis Variance Report compares the business unit quarterly costs (excluding corporate overhead) to the costs from the same quarter in the prior year and identifies material variances requiring explanation.

2. The Cost and User Fees office:



1. Prepares the Cost Analysis Variance Report quarterly, adding any unexpected or judgmentally sampled variances to those identified based on the workpaper’s stated materiality criteria.

2. Forwards the results to the business units for review and response.

3. Reviews, substantiates and consolidates business unit justifications and updates the Report of Trust Fund Costs as needed.

4. Briefs the results and business unit justifications to the Deputy Associate CFO for Corporate Budget.


3. The business units review and justify identified cost variances for each quarter. If errors are found during this review the business units submit revised quarterly costs.


**1.33.8.3.3** **(06-21-2024)**

#### Quarterly Estimate of Trust Fund Expenses

1. The Quarterly Estimate of Trust Fund Expenses is submitted to the Fiscal Service in a memo format, providing the amount to bill to the trust funds for the upcoming quarter.



1. The Cost and User Fees office prepares the Quarterly Estimate of Trust Fund Expenses, which details the cost estimates for the upcoming quarter and the adjustment for prior quarter costs.

2. The adjustment is the difference between the prior quarter’s estimated and the actual costs.

3. Any adjustments attributed to prior periods are also included in the current memo.

4. The Cost and User Fees office obtains approval for the memo from the Deputy Associate CFO for Corporate Budget and emails the memo to the Fiscal Service by the end of each quarter.


**1.33.8.4** **(06-21-2024)**

### Annual and Ten-Year Trust Funds Forecast Report

1. The Annual and Ten-Year Trust Funds Forecast Report details the anticipated trust fund expenses quarterly for the following year and annually for the following ten years.

2. The Cost and User Fees office prepares the report for the OASDHI, Unemployment Compensation and Black Lung Trust Funds by:



1. Determining the methodology to estimate future costs by considering current cost trends and establishing the appropriate labor inflation factor based on the latest OMB projections for federal pay increases.

2. Updating data to account for prior period adjustments and applying information from business units, such as expected workload changes and other factors, to the baseline costs for the following ten years.


3. The Deputy Associate CFO for Corporate Budget approves the Annual and Ten-Year Forecast Trust Fund Report.

4. The Cost and User Fees office submits the approved report to the Fiscal Service annually by December 1st.


**1.33.8.5** **(06-21-2024)**

### Fiscal Year-End Trust Fund Report

1. The Fiscal Year-End Trust Fund Report summarizes the costs from the Quarterly Trust Fund Cost Reports.



1. The Cost and User Fees office compiles the report.

2. The Deputy Associate CFO for Corporate Budget approves the report.

3. The Cost and User Fees office submits the approved report to the Fiscal Service by January 1st of the following fiscal year.


**1.33.8.6** **(06-21-2024)**

### Periodic Reviews

1. The Cost and User Fees office reviews the supporting documents and calculations for each business unit on a two-year revolving schedule to ensure the template is completed using the approved methodology.

2. Each business unit’s finance office maintains detailed audit files for a minimum of three years, which include:



1. Source documents used for trust fund cost information, and

2. IFS data supporting average salary rates, average benefit rates and other aspects of the methodology downloaded in Excel files.


3. The Cost and User Fees office calculates adjustments for any discrepancies, and business units submit any material corrections needed. The Cost and User Fees office includes the adjustments on the current Quarterly Estimate of Trust Fund Expenses.

4. The Cost and User Fees office prepares a report documenting the review, briefs CFO leadership and the business unit finance office on the results and recommendations, and maintains the review documentation in its audit files.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-033-008#addtoany "Show all")

A2A