---
url: "https://www.irs.gov/irm/part1/irm_01-004-020"
title: "1.4.20 Filing & Payment Compliance Managers Handbook | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-020#main-content)

- 1.4.20  [Filing & Payment Compliance Managers Handbook](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898481132960)
  - 1.4.20.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480272128)
    - 1.4.20.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480263584)
    - 1.4.20.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480261808)
    - 1.4.20.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480259952)
    - 1.4.20.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480245088)
    - 1.4.20.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480232736)
    - 1.4.20.1.6  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480228560)
    - 1.4.20.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480837104)
  - 1.4.20.2  [The Operations Manager](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480833648)
  - 1.4.20.3  [Management Information Systems](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480819216)
  - 1.4.20.4  [ACS Systems Extracts](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480816464)
  - 1.4.20.5  [Work Plans and Staffing](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480809296)
    - 1.4.20.5.1  [Work Planning & Control System (WP&C)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480796160)
    - 1.4.20.5.2  [Telephone Management](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480788192)
  - 1.4.20.6  [Financial Reviews](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480782112)
  - 1.4.20.7  [Communication](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480776624)
    - 1.4.20.7.1  [Meetings](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480757824)
  - 1.4.20.8  [Coordination With Other Functions](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480746560)
    - 1.4.20.8.1  [ACS Support Function](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480744080)
  - 1.4.20.9  [Controls](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480739312)
  - 1.4.20.10  [Operational Reviews and Employee Engagement](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480716944)
    - 1.4.20.10.1  [Frequency and Planning](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480713600)
    - 1.4.20.10.2  [Coverage](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480709520)
    - 1.4.20.10.3  [Review Scope](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480704400)
      - 1.4.20.10.3.1  [Department Manager’s Operational Review of Frontline Manager (FLM)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480689616)
      - 1.4.20.10.3.2  [Operations Manager’s Operational Review of Department Manager (DM)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480628640)
      - 1.4.20.10.3.3  [Director P & A Staff Operational Review of Operations Manager (OM)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898480578944)
    - 1.4.20.10.4  [Documentation and Follow-up](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479505504)
  - 1.4.20.11  [Program Reviews](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479499936)
  - 1.4.20.12  [Enforcement Statistics](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479494272)
  - 1.4.20.13  [Priorities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479490464)
    - 1.4.20.13.1  [Downtime Contingency Plan](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479486224)
  - 1.4.20.14  [Taxpayer Rights](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479476864)
    - 1.4.20.14.1  [Unauthorized Disclosure](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479469664)
    - 1.4.20.14.2  [Collections Appeals Program (CAP)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479465184)
    - 1.4.20.14.3  [Collection Due Process (CDP)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479458624)
  - 1.4.20.15  [The Performance Management System](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479454016)
  - 1.4.20.16  [Administrative Tasks](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479430944)
    - 1.4.20.16.1  [Employee Appraisals Mid-year Progress Reviews](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479429200)
    - 1.4.20.16.2  [Employee Performance Folders](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479425808)
    - 1.4.20.16.3  [Employee Performance Data](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479406656)
    - 1.4.20.16.4  [Security](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479382640)
  - 1.4.20.17  [Team Approach to Processing](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479375520)
  - 1.4.20.18  [Workload Management](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479370640)
    - 1.4.20.18.1  [Compliance Nature of Workload](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479356256)
      - 1.4.20.18.1.1  [Collection Managerial Reports](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479338144)
    - 1.4.20.18.2  [Use of Management Information Systems](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479323952)
    - 1.4.20.18.3  [Priorities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479316096)
    - 1.4.20.18.4  [Accounts Management Services (AMS)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479303840)
      - 1.4.20.18.4.1  [AMS Access](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479296928)
      - 1.4.20.18.4.2  [AMS Management Tools](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479275408)
      - 1.4.20.18.4.3  [AMS Reports](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479265936)
    - 1.4.20.18.5  [Scheduling](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479257008)
  - 1.4.20.19  [Paper Documents and Mail Processing](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479252736)
    - 1.4.20.19.1  [Mail Processing](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479244464)
  - 1.4.20.20  [Employee Work Reviews](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479238368)
    - 1.4.20.20.1  [ACS Activity Reviews (TEACH File)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479223824)
      - 1.4.20.20.1.1  [Evaluative TEACH Review](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479221280)
    - 1.4.20.20.2  [Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479214032)
      - 1.4.20.20.2.1  [Evaluative Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479197136)
      - 1.4.20.20.2.2  [Non Evaluative Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479190176)
      - 1.4.20.20.2.3  [ACS Contact Recording](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479186560)
    - 1.4.20.20.3  [ACS (TEACH) /ACS Support Paper Document Review](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479184544)
    - 1.4.20.20.4  [CSCO Paper Document Review](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479178960)
    - 1.4.20.20.5  [CSCO Evaluative Paper Document Review](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479174176)
    - 1.4.20.20.6  [Compliance Non-Evaluative Reviews (OJI)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479168512)
    - 1.4.20.20.7  [Compliance Clerical Reviews](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479164496)
    - 1.4.20.20.8  [Compliance Non-Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479160400)
    - 1.4.20.20.9  [IDRS Adjustment Review](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479157600)
  - 1.4.20.21  [Managerial Approval Process Overview](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479150272)
    - 1.4.20.21.1  [ACS Managerial Approval Process](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479144640)
    - 1.4.20.21.2  [ACS Managerial Approval Actions](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479140528)
    - 1.4.20.21.3  [ACS Managers' Responsibility](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479126192)
    - 1.4.20.21.4  [ACS Managerial Approval Contact Person's Responsibility](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479117360)
    - 1.4.20.21.5  [CSCO Managerial Approval Actions](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479114352)
  - 1.4.20.22  [Training and Employee Development](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479110720)
    - 1.4.20.22.1  [Core Training](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479106304)
    - 1.4.20.22.2  [ACS Interactive Training File (Procedures and Equipment)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479101488)
    - 1.4.20.22.3  [On-the-Job Training](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479098448)
    - 1.4.20.22.4  [Training for all Employees](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479094144)
  - 1.4.20.23  [Developing Employees and Managers](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479080432)
    - 1.4.20.23.1  [Managers Training](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479072320)
  - 1.4.20.24  [Training of Employees with Disabilities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479057904)
    - 1.4.20.24.1  [Adaptive Equipment and Other Accommodations - IRAP Services](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479055712)
    - 1.4.20.24.2  [Braille Materials](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479031792)
    - 1.4.20.24.3  [Interpreting Services Process](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479013936)
      - 1.4.20.24.3.1  [Obtaining Interpreting Services](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479012176)
      - 1.4.20.24.3.2  [Circumstances for Obtaining Interpreting Services](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898479009536)
  - 1.4.20.25  [Overview of Quality](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478999392)
    - 1.4.20.25.1  [Quality Measurement Process](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478996768)
    - 1.4.20.25.2  [Role of the Centralized Quality Review (CQRS) and the Program Analysis System Reviewer (PAS)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478988464)
    - 1.4.20.25.3  [EQRS/NQRS Standard Reports](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478984496)
    - 1.4.20.25.4  [Role of the Local Campus Quality Analyst](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478979360)
  - 1.4.20.26  [Role of the Campus Collection Manager](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478964928)
    - 1.4.20.26.1  [Acting Manager Assignments and Designations](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478960368)
  - 1.4.20.27  [Campus Systems Administrator – Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478956912)
    - 1.4.20.27.1  [Systems Security Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478944192)
    - 1.4.20.27.2  [Functional Coordinator (FUNCO) Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478932016)
    - 1.4.20.27.3  [Resource Allocation Control File (RACF)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478920736)
    - 1.4.20.27.4  [Profile Resume Procedures](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478916848)
    - 1.4.20.27.5  [Profile Revoke Procedures](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478912192)
  - 1.4.20.28  [Handling Telephone Threats Through the IUP System.](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478908176)
    - 1.4.20.28.1  [Handling Telephone Threats on IUP Telephone Systems](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478898304)
    - 1.4.20.28.2  [Employee and Building Security](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478891680)
    - 1.4.20.28.3  [Site Closings](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478882096)
  - 1.4.20.29  [ACS Telephone Program and System Reports](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478874096)
  - 1.4.20.30  [CSCO System Reports](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478869328)
  - 1.4.20.31  [Managers Responsibility to the Federal Employee Viewpoint Survey](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478859040)
  - 1.4.20.32  [Managers Responsibility to the Customer Satisfaction Survey (CSS)](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478854048)
  - 1.4.20.33  [Useful Websites for Managers](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478848960)
  - Exhibit  1.4.20-1  [Types of Performance Awards](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478843984)
  - Exhibit  1.4.20-2  [Other Types of Honorary Awards](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478825440)
  - Exhibit  1.4.20-3  [Links to Resources - Employees with Disabilities](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478811728)
  - Exhibit  1.4.20-4  [Actions To Display A User on ACS](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478806624)
  - Exhibit  1.4.20-5  [Actions To Resume A User on ACS](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478771296)
  - Exhibit  1.4.20-6  [Actions To Resume and Assign New Passwords](https://www.irs.gov/irm/part1/irm_01-004-020#idm139898478733568)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 20. Filing & Payment Compliance Managers Handbook

* * *

## 1.4.20 Filing & Payment Compliance Managers Handbook

#### Manual Transmittal

June 05, 2025

#### Purpose

(1) This transmits a revision for IRM 1.4.20, Organization, Finance and Management, Resource Guide for Managers, Filing and Payment Compliance (F&PC) Managers Handbook.

#### Material Changes

(1) Editorial changes made throughout to update references and terminology; to correct formatting issues; and to revise wording for clarity, eliminate unnecessary or duplicate verbiage, update website address, IRM references and comply with current writing standards. Updated to comply with January 2025 Executive Orders and OPM guidance.. Material changes are noted below.

| IRM | Change |
| --- | --- |
| 1.4.20.10 | Changed titles 10.1 frequency to frequency and planning & 10.3 depth to review scope, added sections 10.3.1 department manager review of frontline manager, 10.3.2 operations manger’s operation review of department manager & 10.3.3 director P&A staff operational review of operations manager, streamlined verbiage throughout section and subsections. |
| 1.4.20.20.5 | Corrected (7) discuss review results timeframe to adhere to National Agreement. |
| 1.4.20.20.7 | Corrected (4) discuss review results timeframe. |
| 1.4.20.19 | (5) Revised R2 to S7 TAS inventory function assignment. |

#### Effect on Other Documents

This Material supersedes IRM 1.4.20 May 2, 2023.

#### Audience

ACS, ACSS, and CSCO operations, department and team managers, and team leads at SBSE Compliance Service sites.

#### Effective Date

(06-05-2025)

Thomas Kramer

Director, Collection Policy

Small Business/Self-Employed Division

**1.4.20.1** **(06-05-2025)**

### Program Scope and Objectives

1. **Purpose:**This IRM provides managerial guidance for ACS, CSCO, ACS Support (ACSS) operations and all levels of management at the Self Employed (SBSE) Campus Compliance Services sites.



### Note:



References throughout this IRM may refer either to CSCO, ACS, or to ACSS, collectively or individually.

2. **Audience:**The primary users of this IRM are Collection Compliance Service Directors, operations, department and frontline managers.

3. **Policy Owner:** These polices are owned by the Director of Collection Policy, SB/SE.

4. **Program Owner:** Campus Policy, an office within Collection Policy.

5. **Primary Stakeholders:** The primary stakeholders are ACS, CSCO, ACS Support (ACSS) operations and team leaders at the Self Employed (SBSE) Compliance Service Sites.

6. _Program Goals:_ This guidance is provided to communicate managerial responsibilities to campus collection managers including performance management, assignment of work, approval of work, promoting quality casework and maintaining effective internal controls.


**1.4.20.1.1** **(06-05-2025)**

#### Background

1. This IRM provides managerial guidance and processes for ACS, CSCO, ACS Support (ACSS) operations and team leaders at Small Business and Self Employed (SBSE) Compliance Service Sites.


**1.4.20.1.2** **(07-10-2020)**

#### Authority

1. The authority relating to this section is SB/SE Functional Delegation Orders-Collection SBSE 1-23-2 (Rev. 2), see IRM 1.2.65, Small Business/Self-Employed Delegations of Authority, and Policy Statement 5-2 in IRM 1.2.1, Servicewide Policy Statements.


**1.4.20.1.3** **(06-05-2025)**

#### Roles and Responsibilities

1. The director, collection policy, is the executive responsible for the policies and procedures in this IRM.

2. The director, operations and department managers are responsible for ensuring the guidance and procedures described in this IRM are followed.

3. The operations manager is responsible for directing operation activities. They oversee department, team and employee responses to taxpayer inquiries and responses concerning balances. They oversee department, team and employee actions to resolve balance due and delinquent return accounts owed by taxpayers who did not fully pay their tax due and/or file timely returns.

4. The department manager is responsible for overseeing team and employee responses to taxpayer inquires and responses concerning balances due, following IRM procedures. They oversee team and employee actions to resolve balance due and delinquent return accounts owed by taxpayers who did not full pay their tax due and/or file timely returns.

5. The team manager is responsible for overseeing employee responses to taxpayer inquires and responses concerning taxpayer delinquent return accounts and investigations following IRM procedures. They oversee employee actions to resolve balance due accounts owed by taxpayers who did not full pay their tax due. Team managers are responsible for ensuring employees are duly delegated to take various actions, including levy and notice of federal tax lien. They are responsible to approve certain case actions and ensure that all actions taken are in accordance with established policy and procedures and ensuring the accuracy of the preparation of various documents. Team managers are responsible for ensuring their employees comply with records and files management lifecycle (hardcopy and electronic), including creation, maintenance, retrieval, preservation and disposition of all records to avoid unlawful destruction of records. See the series of IRM 1.15.6, Managing Electronic Records.


**1.4.20.1.4** **(06-05-2025)**

#### Program Management and Review

1. Program Reports: Section 1204 reports. Managers are required to submit quarterly certifications of compliance with section 1204 of the Internal Revenue Service Restructuring and Reform Act of 1998, prohibiting the use of tax enforcement results. Daily and weekly reports are performed by management. Headquarters gathers monthly data to communicate targets and objectives.

2. Managers are required to manage work programs and perform program and employee reviews to ensure Compliance work is completed according to procedural guidelines contained in applicable IRMs.

3. Program management and review guidelines are detailed in IRM 1.4.20.5.

4. The following reports assist with management controls:




| **Reports** |
| --- |
| Embedded Quality Review System (EQRS) Reports |
| --- |
| National Quality Review System (NQRS) Reports |
| Accounts Management Services (AMS) Reports |
| Overage Report Compiler and Sorter (ORCAS) |
| ACS Reports |
| Monthly Monitoring Report (MMR) |
| Work Planning and Control (WP&C) Reports |
| Case Control Activity System (CCA) Report |
| Collection Activity Report (CAR) |
| MISTLE Report |
| Business Object Enterprise (BOE) Reports |


**1.4.20.1.5** **(06-05-2025)**

#### Program Controls

1. Restructuring & Reform Act of 1998 (RRA 98), Section 1204, prohibits the use of records of tax enforcement results to evaluate employees, impose or suggest production quotas or goals with respect to such employees. This applies to all employees regardless of position held or location in which the work is performed. For purpose of implementing this section, IRM 1.5.1, The IRS Balanced Performance Measurement System, refers to employees exercising judgment in determining tax liability or ability to pay as" Section 1204 Employees" .

2. IRS has access control measures in place to provide protection from unauthorized alteration, loss, unavailability, or disclosure of information. These access controls are developed according to assigned user duties, i.e., telephone agents, managers, telephone system analyst, or headquarters analyst. Systems users are required to obtain Business Entitlement Access Request Systems (BEARS) permissions to access servers and programs, i.e., Contact Recording, Account, Management Service (AMS) and Automated Lien System (ALS).

3. Managers are required to follow program management procedures and controls addressed in this IRM.


**1.4.20.1.6** **(06-05-2025)**

#### Terms/Definitions/Acronyms

1. The table below lists common abbreviations definitions and acronyms used throughout this IRM.




| **ABBREVIATION** | **DEFINITION** |
| --- | --- |
| AAB | Aggregate Assessed Balance |
| ACD | Automated Call Distributor |
| ACS | Automated Collection System |
| ACSS | Automated Collection System Support |
| AHT | Average Handle Time |
| AMC | Alternative Media Center |
| AMS | Account Management Services |
| AO | Accessibility Office |
| AOIC | Automated Offer in Compromise |
| APM | Administrative Procedures for Managers |
| ASFR | Automated Substitute for Return |
| ATFR | Automated Trust Fund Recovery |
| ATTS | Automated Time Tracking System |
| AWOL | Absent without Leave |
| AWSS | Agency-Wide Shared Services |
| BEARS | Business Entitlement Access Request System |
| BD | Balance Due |
| BMF | Business Master File |
| BOD | Business Operating Division |
| BOE | Business Object Environment |
| BRP | Business Resumption Plan |
| CAC | Chief Accessibility Coordinator |
| CAP | Collection Appeal Program |
| CAWR | Combined Annual Wage Reporting |
| CDP | Collection Due Process |
| CDPTS | CDP Tracking System |
| CJE | Critical Job Element |
| COBR | Campus Operation Business Results |
| COIC | Centralized Offer in Compromise |
| CPE | Continuing Professional Education |
| CQRS | Centralized Quality Review System |
| CR | Collection Representative |
| CSCO | Compliance Service Collection Operation |
| CSS | Customer Satisfaction Survey |
| CTDWA | Control-D Web Access |
| DCI | Data Collection Instrument |
| DI | Desktop Integration |
| DOJ | Department of Justice |
| EH | Equivalent Hearing |
| ELITE | Enterprise Logistics Information Technology |
| EONS | Electronic On-line Network |
| EPF | Employee Performance Folder |
| EQ | Embedded Quality |
| EQRS | Embedded Quality Review System |
| ER/LR | Employee Relations/Labor Relations Skill for Managers |
| ESP | Employee Suggestion Program |
| ETA | Electronic Tax Law Assistance |
| EUP | Employee User Portal |
| FLRP | Front-line Leader Readiness Program |
| FMLA | Family and Medical Leave Act |
| FR | Financial Review |
| FTE | Full-Time Equivalent |
| FUNCO | Functional Coordinator |
| FUTA | Federal Unemployment Tax Act |
| IC | Incomplete Case |
| ICP | Integrated Case Processing |
| IDRS | Integrated Data Retrieval System |
| IRM | Internal Revenue Manual |
| ISD | Information System Division |
| ITM | Integrated Talent Management |
| IUP | Infrastructure Upgrade Project |
| JOC | Joint Operations Center |
| LAC | Local Accessibility Coordinator |
| LEM | Law Enforcement Manual |
| LWOP | Leave Without Pay |
| LWSB | Lions World Services for the Blind |
| MAAG | Month at a Glance |
| MC | Missing Case |
| MFT | Master File Tax |
| MIS | Management Information Statistics |
| MISTLE | Management Information System Top Level Executive |
| MITS | Modernization Information Technology & Security |
| NCD | Non-Competitive Detail |
| NMF | Non-Master File |
| NQRS | National Quality Review System |
| NTEU | National Treasury Employees Union |
| NW | New Work |
| OEP | Occupational Emergency |
| OFP | Organization Function Program |
| OIC | Offer in Compromise |
| OJI | On-The-Job Instructor |
| P&A | Planning and Analysis |
| PMS | Performance Management System |
| POA | Power of Attorney |
| QMF | Query Master File |
| RAC | Reasonable Accommodation Coordinator |
| RACF | Resource Allocation Control File |
| RCA | Reasonable Cause Assistant |
| RD | Return Delinquency |
| ROTERs | Records of Tax Enforcement Results |
| RRA 98 | Restructuring and Reform Act of 1998 (Law) |
| RTA | Real Time Adherence |
| RTC | Resource Training Coordinator |
| RTR | Remittance Transaction Research |
| S.A.F.E | Security Awareness for Employees |
| SERP | Servicewide Electronic Research Program |
| SSO | System Security Officer |
| TAO | Taxpayer Assistance Order |
| TBOR2 | Taxpayer Bill of Rights 2 |
| TE/GE | Tax Exempt/Government Entities |
| TEA | Tax Examining Assistant |
| TEACH | Temporary Employee Action Code History |
| TERs | Tax Enforcement Results |
| TIGTA | Treasury Inspector General for Tax Administration |
| TIN | Tax Identification Number |
| TMT | Tax Motivated Transactions or Temporary Manager Training |
| TQM | Total Quality Measurement |
| TRIS | Telephone Routing Interactive Systems |
| UNAX | Unauthorized Access |
| UTC | Unable to Contact |
| UTL | Unable to Locate |
| UWR | Unified work Request |
| VMS | Voice Messaging System |
| WP&C | Work Planning & Control |


**1.4.20.1.7** **(06-05-2025)**

#### Related Resources

1. IRM 1.5.1, The IRS Balanced Measurement System.

2. IRM 5.19, Liability Collection.

3. IRM 6.451.1, Policies, Authorities, Categories, and Approvals.

4. IRM 13, Taxpayer Advocate Service.

5. IRM 21, Customer Account Services.


**1.4.20.2** **(06-05-2025)**

### The Operations Manager

1. The operations manager is responsible for directing operation activities, coordinating efforts within the operation and accomplishing balanced measures and objectives identified in the headquarters office program and workload scheduling guidelines. Where operations are divided into departments, the department managers are responsible for coordinating efforts among their teams to ensure consistency.

2. To accomplish this mission, operations and/or department managers must:




| **Actions** |
| --- |
| Lead your staff using a balanced measurement approach focusing on what actions are important to achieve our strategic and operational goals; |
| --- |
| Generate a productive quantity of work in a quality manner and provide meaningful outreach to all customers. Use management information systems to track your operations/departments performance in accordance with IRM 1.5.1, The IRS Balanced Measurement System; |
| Establish and maintain effective communications strategies to ensure that you and your operation are providing accurate and professional services to internal and external customers in a courteous, timely fashion; |
| Create an enabling work environment for employees by providing quality leadership, adequate training and effective support services; |
| Establish practices and controls which emphasize quality of work and effective use of resources; |
| Ensure efficient use of staff year allocations provided by the Headquarters office, to adhere to a meaningful schedule and work plan and provide consistent high-level customer service; |
| Establish and conduct regular operational and program reviews to assess effectiveness and identify and correct problems; |
| Ensure that subordinate managers are aware of the provisions of RRA 98. See _IRM 1.4.20.1.4_ Program Management and Review. When conducting work reviews and telephone monitoring, managers should establish that the rights of the taxpayer are protected. Taxpayers requesting to speak to a team manager will be referred to the team manager for priority handling. When the manager is unavailable, the customer should be advised that a manager will call them back. A call back message for a team manager will be considered a priority work assignment and the call will be returned within 24 hours of the customer's call; |
| Assess workload priorities and use available resources to optimize efficiency and to prevent backlogs of work. A backlog of taxpayer correspondence or third-party responses exists if any items are not controlled (i.e. program specific systems; ACS, ASFR, OIC) or worked within five workdays of receipt; |
| Coordinate recruitment and training efforts and motivate employees and managers so that the workforce is highly skilled, productive and stable. It is imperative to have in place a structured developmental path for new employees. Managers require highly developed skills and managerial techniques which include time and mentoring. Developing these skills is an on-going learning process; |
| Recognize that the effectiveness of the operation depends on subordinate managers. Manage and develop them so that they reach their highest potential as managers and guide them in using their time effectively; |
| Use management information to identify opportunities for quality improvement and initiate quality improvement projects in those areas so identified; |
| Achieve an optimum balance of inventory processed and incoming calls answered. |


**1.4.20.3** **(06-05-2025)**

### Management Information Systems

1. Operations managers, department managers and team managers should use various Information System tools to ensure inventories are being processed properly, sufficient staffing is being provided and utilized, and programs are being worked based on established time-frame requirements. Reports can also be created to give important information on the effectiveness of a specific team or employee.

2. Operations managers, department managers and team managers should ensure that information at the campus team level is available on a regular or as needed basis. The information should be reviewed by the appropriate level of management to allow for immediate correction regarding any situations or problems (i.e. time-frames not being met).


**1.4.20.4** **(06-05-2025)**

### ACS Systems Extracts

1. Each site should have Query Master File (QMF) extracts to allow for a complete picture of the status of inventories in the site. Those extracts should be requested as needed or on a regular basis and be reviewed by the appropriate level of management to look for possible inventory issues or problems.

2. Systems Analysts have the ability to create, modify and run extracts.

3. Extracts should be reviewed for various reasons, including but not limited to:



   - Age of the inventory related to past follow-up dates in each inventory,

   - Inventory levels in conjunction with priority case definitions,

   - Closures and new inventory receipts on a weekly basis.


4. Operations management should identify inventories beyond the time-frames established in IRM 5.19, Liability Collection, as well as from headquarter operations, and take immediate steps to resolve the situation(s). Some possible solutions include:



1. Reassignment of work among other operation employees,

2. Consideration for overtime,

3. Consideration of details from other functions.


5. Next level management and headquarter operations should be notified when inventory is beyond the established guidelines.


**1.4.20.5** **(06-05-2025)**

### Work Plans and Staffing

1. Work plans play an important role in developing priorities for sites in the use of resources. A work plan is developed by Headquarters with review by the sites. The work plan establishes the resources to be devoted to each program worked in the site.

2. A work plan is developed for each fiscal year; however, constant review of the current years work schedule and activities play an important role in establishing an effective work plan for the following fiscal year. Employees charging their time under the wrong program can have a drastic impact on the work plan process. All levels of management must be involved with ensuring employees are properly charging their time.



### Note:



Managers are required to review Form 3081, (or employees direct input of time into SETR) thoroughly, to ensure employees are recording their time correctly.

3. Work plans are used to schedule expected volumes and hours to determine the amount of staffing needed by each site for each program. The process typically begins in early May, at the Headquarter Office, for the following fiscal year.

4. The initial work plan is developed by Headquarters based on the site history for each program and any expected changes to programs. Those changes, called assumptions, can be related to new programs, new procedures, and/or changes in rates or volumes on one or more programs.

5. The work plan is broken into three periods, October through December, January through June, and July through September.

6. Do not assume that the final work plan will be fully funded. Typically, assessments are made to cover funding shortages. If not fully funded, the Business Operating Division (BOD) staff should decide where to cut hours.

7. Operations management should be involved in every phase of the work plan process. Day-to-day involvement ensures all employees are charging time to the appropriate code. When the proposed work plan is received:



1. Review the assumptions and determine if they are valid for your site;

2. Verify that history was used correctly and assumptions were computed properly;

3. Verify that the rates are valid; consider changes to employee's experience levels;

4. Prepare narratives for any proposed changes.


8. When the work plan is finalized, compute staffing required to meet the work plan. Consider the impact of the number of hours your employees will not be available. Ensure that staffing needed will be available to meet work plan hours.



1. If current staffing is too low, announce positions.

2. If current staffing is too high, consider details or reassignments.


9. Reviews should be completed throughout the year. This includes ensuring that staffing is aligned with the needs of the programs, including evening telephone calls. Monitor employee movement in and out of the operation to ensure that the work plan will be delivered. Adjust hiring during the year based on realization of your projections of details, attrition, and LWOP/AWOL. These staffing projections should be developed to include the expected staff movement and be adjusted on a regular basis. Overtime can also be utilized, if approved, to realize the work plan. Establish work schedules for each appropriate work plan period.



1. Efforts to achieve work plan goals should be documented and communicated to the headquarters office(s) responsible for monitoring the work plan.

2. If a particular work plan goal is no longer relevant due to changing business needs or new information, this should also be documented and communicated.


**1.4.20.5.1** **(06-05-2025)**

#### Work Planning & Control System (WP&C)

1. WP&C reports are tools that you will use to ensure that your work schedule is being met. It is important that it be reviewed weekly to identify potential problems or issues. The reports can also be helpful in detecting:



   - Receipt/volumes being worked higher than projections

   - Rates not within projections

   - Hours not being charged to codes properly


2. Reports should be ran each week showing the cumulative figures for the period. The weekly data is added to the year to date cumulative data.

3. Weekly reports should be kept for a year. After a year, they can be destroyed but the period ending reports should be kept for three years.

4. Review the WP&C Report for accuracy on a weekly basis. When an error is identified it must be corrected as soon as possible.

5. The WP&C system provides other valuable reports that should be reviewed and will provide lower level information of possible concerns or issues that need attention. The Operations/Department and Organizational (unit) Report provides volumes, hours and rates at each level. These reports should be reviewed by all levels of management to identify problems. Issues of higher or lower team productivity may be identified, such as not reporting time properly or working more efficiently. Looking at that team may correct a problem or give you a best practice that should be shared with other teams doing like work.

6. Another report is the Employee Detail Summary. This report is generated weekly and lists hours detailed to and from your organization by operation and management activity code. The report indicates which of your employees are using other operation codes and if employees from other operations are using your codes. This is especially important when you have employees who are detailed to other functions that should be paid by the function to which they are detailed. Weekly review of this report allows corrections to be completed to ensure that all hours are charged to the appropriate operation.


**1.4.20.5.2** **(06-05-2025)**

#### Telephone Management

1. The Aspect system has been phased out and replaced with IUP (Infrastructure Upgrade Project). Management must IUP reports to ensure resources are being utilized effectively and that taxpayer needs are being met.

2. Aceyus Reports are also an effective reports to ensure resources are being effectively utilized. For more information on Aceyus Reports, see IRM 1.4.18.9.3.8 , Aceyus Reports.

3. Care should be taken when using the Telephone Reports with levels of management within the guidelines of IRM 1.5.1, The IRS Balanced Measurement System.

4. Telephone reports should be reviewed on a regular basis to cover at least the following items:



   - Peak times for calls received and calls abandoned

   - Average Handle Time (AHT)

   - Adherence to employee assignment schedule

   - Employee time utilization


5. Call Site telephones will be available to our taxpayers from 8:00 a.m. to 8:00 p.m. Monday thru Friday. Sites may be asked to handle calls outside of their normal time band to assist in handling calls received nationwide from sites in other time zones. Outgoing calls can be made only between the hours of 8:00 a.m. to 9:00 p.m. local time for the taxpayer.


**1.4.20.6** **(01-20-2012)**

### Financial Reviews

1. The Financial Review (FR) is the process used to assess programs, financial status and requirements for the various operations. It is used to identify problems and opportunities and resolve programmatic issues, where appropriate, through the reprogramming or reallocation of resources. If there is a need to realign resources between regular time, training hours and overtime, or if there is a need to move resources between planning periods, the FR process is the vehicle to ensure this is done timely and accurately.

2. Changes in workload and staffing can have a significant impact on the resource usage. These changes must be taken into consideration during the FR process and appropriate FTE (full-time equivalent) realignments should occur as necessary to address these changes. Throughout the year, financial reviews are conducted to monitor spending compared to the plan and/or schedule. The current spending to schedule is reviewed, projections for the remainder of the period are shown and the yearly total spending is compared to the budget. The goal is to effectively schedule the hours for each period. The spending schedule should be monitored weekly and is usually the responsibility of the operation’s technical advisor.

3. If it is estimated that the operation cannot live within the budget, help should be requested from the Headquarter's Finance operation to cover additional spending or decide which programs to cut. If the operation is not spending to plan and/or schedule, additional hiring, overtime, recalling employees or details to your operation might be considered. An operation’s final delivery should not significantly differ from their projected delivery. Every effort should be made to ensure accurate capturing and forecasting of the projected needs within an operation.


**1.4.20.7** **(06-05-2025)**

### Communication

01. In order to improve organizational performance and increase customer satisfaction, it is important to establish and maintain open and effective communication at all levels of management and with your employees. Establish and maintain effective lines of communication within and outside your function. Also ensure that all appropriate information is disseminated to impacted functions. All procedures, guidelines and new ideas must be shared with all team managers.

02. Total Quality Measurement (TQM) is defined as a strategic, integrated management system for achieving customer satisfaction. It involves all managers and employees and uses quantitative methods to continuously improve an organization's processes. (For additional information and resources on TQM please refer to Quality Tools Toolkit Online References.)

03. Depending upon the organizational structure and the number of managers, meetings could include all managers and management officials in the operation, or only those who report directly to the operations manager. If attendance is restricted, department managers must hold regular staff meetings for their subordinate managers. If team managers do not attend operation level meetings, the operations manager may need to enhance their sense of identification with the operations management team. This may be done by having each department manager bring one team manager on a rotating basis, to the staff meetings, or by including all managers in monthly operations staff meetings; or by sharing operational meeting minutes with all frontline managers.

04. Training coordinators may attend staff meetings. Any performance problems or technical changes may indicate a need for additional training for managers and/or employees. Training coordinators must be involved in identifying areas in which additional training may be needed. The training coordinator will schedule any training/workshops for the operation as needed.

05. Technical changes may need to be made in course material before training new employees. The full support of the teams are needed to promote training involvement as a way to help keep pace with day-to-day operations.

06. The Planning and Analysis (P&A) analysts may attend staff meetings. They may be of great assistance for the management team in identifying technical/procedural deficiencies within each operation, and in assisting in the development or delivery of workshops. The training coordinator and the P&A analyst will work closely together in the identification of needed training.

07. Tools to gather and disseminate information include the following:




    | **Tools for Information to be gathered and shared** |
    | --- |
    | IRS Home Page |
    | --- |
    | Servicewide Electronic Research Program (SERP) |
    | Compliance eGuides (ACS, ACS Support and CSCO) |
    | Voice Messaging System (VMS) |
    | News Releases, Bulletins, and E-mail |
    | IDRS MESSG File and Campus Bulletins |
    | Meetings for daily and weekly updates |
    | Program Help Screens |
    | Knowledge management |
    | Meeting Minutes |
    | SharePoint |
    | ITM (Integrated Talent Management) |
    | Microsoft Teams |

08. Oral communication should be expressed in a precise and meaningful way. Whenever possible, contact employees directly. It is also important that all employees are kept informed of their performance by receiving timely copies of written documents that contain guidance that will have an impact on their job expectations and performance. Include follow-up communications to help ensure clarity.

09. Ensure that all Collection Representatives (CR) receive the Quality Communication Training before they begin assisting taxpayers.

10. Managers must encourage recommendations from their employees for improving communications or new forms of information sharing.

11. In order to encourage your employees to express their concerns, report problems and make suggestions, you need to create a climate for open communication. It is essential that you ask for and listen to feedback from all levels of the organization. You should also ensure information received from upper levels of the organization is disseminated as needed.


**1.4.20.7.1** **(06-05-2025)**

#### Meetings

1. Another significant aspect of effective communications is scheduling meetings with your managers. These meetings should be held as needed and focus on:



1. Disseminating important procedural and management information (including safety in cases of certain threats initiated by customers)

2. Reporting progress on objectives;

3. Identifying areas needing improvement and developing strategies on how to accomplish them;

4. Identifying areas in which resources shifts may be needed to meet workload requirements;

5. Promoting communication and cooperation among managers and employees;

6. Reinforcing objectives.

7. Establishing follow-up timeframes for review of strategy development.


2. Operations managers should schedule at least one "All Employees" meeting annually, more if needed, to be visible to employees and discuss successes within the operation.

3. Frontline/team managers will hold meetings with their employees regularly to disseminate procedural changes, to provide guidance on problem trends found in work reviews, to report progress on objectives, to provide informal training and to solicit questions. SBSE Compliance Service managers should see the IRS-NTEU Customer Service Agreement for more information about meeting guidelines. Customer Service Agreement (CSA)

4. To enhance the effectiveness of your meetings:



1. Keep them brief;

2. Solicit agenda items in advance when possible;

3. Prepare and provide in advance the agenda items you want to cover; including responses to solicited topics when available.

4. Issue brief minutes promptly after the meeting to document the meeting. These minutes must be recorded, distributed and a copy filed for reference. Documentation should indicate date of the meeting, management/employees in attendance, and topics discussed.


5. Encourage the participation of National Treasury Employees Union (NTEU) at all appropriate meetings in order to demonstrate your commitment to open communications.



### Note:



NTEU must be invited to meetings where changes in working conditions or issues involving critical elements are discussed. These are considered "7114" meetings which require a union steward to be present. See the current National Agreement contract for all requirements.


**1.4.20.8** **(01-20-2012)**

### Coordination With Other Functions

1. Your employees are required to contact other functions in some situations and should be advised to notify you (or a designated person) when they have questions or problems in dealing with the other functions.

2. When you identify an issue that may have a significant impact or lead to increased difficulties with other functions, upper management needs to be informed immediately in order to assist in resolving the issue.


**1.4.20.8.1** **(06-05-2025)**

#### ACS Support Function

1. The relationship between a call site and the ACS Support (ACSS) function is very important to ensure that ACS work continues to flow smoothly without taxpayer impact. Most actions taken by a call site employee activate other actions at the support site. Each site can easily be overwhelmed with work if there is no close coordination, especially if there is a change in work priorities which impacts customers, (i.e. massive request for letters or realignment of resources). This type of coordination would assist all in ensuring the same level of support is continued. The Support site handles taxpayer and incoming third-party correspondence. The Support Site handles all mass mail outs generated from the call sites and in most instances, the majority of taxpayer and third-party correspondence. These inventories and correspondence must be worked in a timely manner to eliminate possible negative impact to the taxpayer (i.e. erroneous levy or lien) by the call site. Each item of mail received in any ACSS operation must be date-stamped upon receipt into the operation and the envelope should be maintained with the correspondence. In addition to call site initiated correspondence, they also process the undeliverable mail.

2. Each support site must have a tracking mechanism in place to ensure that all letters, levies and listings are received timely from the Information System Division (ISD). Immediate resolution of any problem is imperative to reduce potential negative impact to the customer or case timeliness. Resolution may include finding the missing output or having it reproduced. If a resolution cannot be taken timely, then the support site must take whatever action is necessary to ensure that the computer systems; IDRS, AMS, and ACS do not reflect inaccurate data.

3. The support staff should utilize telephone calls to maximize case resolution when working correspondence or support functions. When an employee works a support program, they should take the next appropriate action and route the account to the next function/team for case processing. If additional information is needed to resolve the case or an insufficient response is received, and a telephone number is available from IDRS or on the notice, ACSS and Compliance Services Collection Operations (CSCO) should make outgoing calls prior to sending a letter to the taxpayer.


**1.4.20.9** **(06-05-2025)**

### Controls

01. RRA 98, Section 1204, requires all appropriate supervisors to certify quarterly, by letter to the Commissioner, whether or not tax enforcement results are being used in a manner that is prohibited. Records of Tax Enforcement Results (ROTERs) or Tax Enforcement Results (TERs) should not be used to evaluate employees, or to impose or suggest production quotas and goals with respect to such employees. "Appropriate supervisors" are defined as the highest ranking executive in an operational or functional division that supervises, directly or indirectly, one or more section 1204 employees. The appropriate supervisor can delegate responsibility to lower level managers within their organization.

02. For more information on the Quarterly Certification Process, refer to IRM 1.5.3, Manager’s Self-Certification and the Independent Review Process, RRA 98 Section 1204 Self-certification and the Independent Review Process. Tools include:



    - IRM 21, Customer Account Services

    - IRM 13, Taxpayer Advocate Service

    - IRM 5.19 ACS Program Processing Procedures


03. Managing the Collection Due Process (CDP) or Equivalent Hearing (EH) workload requires the establishment of controls on time sensitive appeal requests.

04. To ensure timely processing of appeal requests, managers or management officials must ensure ACSS employees are taking initial actions on CDP requests following IRM 5.19.8.4.7.5, Initial Actions, and forwarding the request to Appeals in a timely manner. Periodic employee reviews, focusing on the four timeliness elements listed below.

05. Reviews should determine if:



    1. Accounts were moved to S8 inventory timely per IRM 5.19.8.4.7.5(1)a, Initial actions.

    2. Cases were input to CDP Tracking System (CDPTS) per IRM 5.19.8.4.7.5(1)b, Initial Actions

    3. Cases were controlled on IDRS per IRM 5.19.6.11.6(3), Accounts Management Services (AMS) Create Batch.

    4. Timely CDP or EH cases were forwarded to appeals per IRM 5.19.8.4.7.5, Initial Actions.


06. The following reports can be used to monitor the aging of CDP inventory:



    - AMS Ad-hoc Inventory

    - AMS Time Per Case

    - Business Objects CDP Aged

    - Business Objects ACSS Inventory Summary Daily

    - Business Objects ACSS Inventory Summary by OFP Weekly

    - MISTLE report

    - CCA4243 age list.



      ### Note:



      This list is not all inclusive.


07. Certain actions require managerial approval. Depending upon employee experience levels, operations and department managers may require approval of other actions (i.e. routing of lien filing cases to E9 to ensure that FM10s are requested by GS-6 or higher CRs; or GS-8 if the employee is not in the Compliance Collection function, transfer actions to the field, or the queue). Inappropriate actions can be detected by frequently reviewing employee Temporary Employee Action Code History (TEACH) listings, which contains all actions an employee performed during a given day.

08. Based on your sites operations and department managers requirements, the site should establish controls for travel advances and vouchers to ensure the prompt liquidation of advances and prompt filing of travel vouchers.

09. The following website can provide information regarding travel: Traveler’s Toolkit. . Organizational policy requires that all travel be paid with government credit cards. Imprest funds may be available for special circumstances.

10. An operational level control should be established to ensure that listings generated by the computer room are received and worked, and a follow-up initiated as necessary.

11. A control should be established within the operation or within each department to control property such as headsets and Documents 6209.

12. Operations/department managers should:



    1. Review, periodically, third party correspondence awaiting processing in function I7 and batch taxpayer correspondence awaiting processing, in function R1 for call site, and S4 for ACS Support, to determine its age and thus the timeliness of correspondence processing. Each item of mail in any ACS Operation must be date-stamped upon receipt and the envelope should be maintained with the correspondence. This is necessary to ensure timely filed Collection Due Process requests from our external customers or their authorized representative.

    2. Review for quality, transfers to E9–FM10 request, E4–Levy Issuance, revenue officers or the queue, releases of levy, and RD90, 91, and 93 dispositions, which do not require managerial approval. The employee's TEACH list can help in facilitating these types of reviews. TEACH reviews, as well as reviews of the aged case listing, should be completed within locally established timeframes.

    3. Engage periodically in telephone monitoring to detect trends and to advise team managers of issues needing their attention;

    4. Spot-check the technical adequacy of team manager's approvals. This can be accomplished by selecting cases from the team manager's TEACH list;

    5. Conduct operational reviews at least once a year;

    6. Ensure Security reviews are performed, at least, on a quarterly basis.

    7. Operations Managers can also review similar samples to ensure task completion.


**1.4.20.10** **(06-05-2025)**

### Operational Reviews and Employee Engagement

1. An operational review is an in-depth review and analysis of a particular program or function or a subordinate manager and their organizational component. Reviews are opportunities to improve overall effectiveness of managers, teams, departments, and the operation. Reviewing subordinate managers is imperative for their personal growth and the efficiency of the operation. .

2. These reviews may be of organizational as well as individual performance. The review should be evaluative and direct. Operational reviews are conducted in the following manner:



   - Department Managers (DM) review frontline teams

   - Operations Managers (OM) review DMs

   - Directors and Planning & Analysis (P&A) staff review Operations


**1.4.20.10.1** **(06-05-2025)**

#### Frequency and Planning

1. Each operations and department manager must complete an operational review of each subordinate component every year..

2. Operational and/or administrative/compliance reviews may be conducted during the fiscal year as a " single phase comprehensive review or may take the form of an on-going series of multi-phased reviews that focus on specific aspects of the team's/department's performance. Feedback about operational review findings is expected to occur continuously throughout the review cycle.

3. Conduct more frequent follow-up reviews when warranted by indicators such as statistical data out of the acceptable range, lack of experience on the part of the subordinate manager, or poor results from prior reviews. These reviews should also have established follow-up review dates scheduled for any areas showing minimal/no improvement.

4. Each operations and department manager will maintain an operational review schedule showing the date of the prior review and the scheduled and actual review dates for each component for which they are responsible. Prepare a schedule of planned reviews at the beginning of each fiscal year, schedule reviews to ensure that all teams are addressed. No later than November 1st, provide the schedule to the operations manager or director as appropriate.


**1.4.20.10.2** **(06-05-2025)**

#### Coverage

1. Operational reviews of a team are performed by a department or operations (when there is no department manager at the site) manager. To perform the operational review additional information may be provided by the operations analyst or technical advisor when available. As the process moves up through each component of management, the content of the review is streamlined to minimize duplication of effort and focus on the higher priorities at each level of management. .

2. A department manager’s review should cover a majority of the team’s and employees’ responsibilities. Review should include but is not limited to; employee leave and attendance, workload management and inventory controls, Employee Performance Files (EPF) maintenance per IRM 6.430.2.3.5 Employee Performance File (EPF), timekeeping records, status of prior Headquarters Collection review action items and identified training needs of employees, specific feedback, and action items as required.

3. The scope of operational reviews by an operations manager of a department should focus on the overall health of the department including efficiencies, program enhancements, risk management, succession planning, staffing, statute controls, special projects, best practices, status of prior Headquarters Collection review action items, operational goals, future planning, specific feedback, and action items as required.

4. Director/Planning & Analysis staff review should cover the operation’s internal controls, best practices, risk analysis and management, staffing, succession planning, employee development, the status of operational goals, status of prior feedback, and action items as required.


**1.4.20.10.3** **(06-05-2025)**

#### Review Scope

1. Each operations and department manager should review the manager’s position description and Performance Management System (PMS) expectations prior to starting the review. Responsibilities to cover include oversight for:



   - Program Delivery-provide appropriate guidance and direction.

   - Administrative/Compliance Conformance-adherence to servicewide managerial requirements and law, regulation policy and any other requirements established by the program director.


2. Request the information needed from the manager in advance, generally 30 days. This will ensure all information is available at the start of the review.

3. Each manager will set required reviews for each component. This may include the following items, but not limited to:




| **Reviews of:** |
| --- |
| EPF |
| Meeting Minutes |
| Inventory Reports |
| Telephone contact (where applicable) |
| Work in progress |
| Closed cases |
| Leave tracking |
| Review samples and schedules |
| Evaluation/Midyear samples |
| Quality/Productivity/Improvement Initiatives |
| Management Controls Tracking |

4. A current EPF check sheet/template should be included in all EPF folders .Creation and maintaining employee performance records per IRM 6.430.2.3.5 Employee Performance File (EPF), It is recommended when EPFs are reviewed:



   - Department managers should include a review of EPFs for each team in the frontline operational review.

   - Operations managers should review a sampling of EPFs from the various teams in each department. Include a variety of skills (Manager, work leader, secretary, clerk, tax examiner, collection representative) and employees with different levels of experiences.


5. The scope of the operational review should incorporate a majority of the key topics listed, which align with the Form 12450 responsibilities, along with a sampling of the subsections as a guide when performing the operations review. The forthcoming subsections are not all inclusive and additional topics/categories can be added based on operational focus.


**1.4.20.10.3.1** **(06-05-2025)**

##### Department Manager’s Operational Review of Frontline Manager (FLM)

1. **Leadership & Human Capital:** Evaluating Leadership involves review of actions taken toward FLM responsibilities:




| **Leadership Attribute** | **Activities** |
| --- | --- |
| Leadership development | - Developing Career Learning Plans (CLP), Leadership Succession Review (LSR).<br>     <br>   - Scheduling meetings with CLP/LSR participants.<br>     <br>   - Providing developmental opportunities. |
| Adaptability | Adapting to and promoting organizational change. |
| Networking | Networking with peers and stakeholders |
| Communication | - Sharing knowledge with employees, peers and beyond the work unit.<br>     <br>   - Maintaining meeting minutes.<br>     <br>   - Maintaining visibility to the team.<br>     <br>   - Listening.<br>     <br>   - Communicating through e-mail and/or through Teams as appropriate.<br>     <br>   - Encouraging a positive working environment.<br>     <br>   - Sharing team and operational Goals.<br>     <br>   - Sharing expectations. |
| Use of Time | - Effectiveness of time management method used for scheduling tasks or assignments.<br>     <br>   - Workload processing and handling of backlogs.<br>     <br>   - Identification of problems and implementation of solutions.<br>     <br>   - Timeliness of controlled responses. |
| Employee Personnel Folders (EPF) Maintenance | - Review a random sample of employee EPFs in each team.<br>     <br>   - Review current EPF checklist.<br>     <br>   - Ensure outdated material is purged.<br>     <br>   - Ensure compliance IRM 1.4.1.8.5, Employee Performance File (EPF) |
| Timekeeping Record/Controls | Review:<br> <br>   - WebSETR.<br>     <br>   - Leave Records.<br>     <br>   - FMLA tracking/documentation.<br>     <br>   - Credit requests and approvals.<br>     <br>   - Overtime (OT)/Credit sign-in sheets.<br>     <br>   - Telephone reports.<br>     <br>   - Employee time reporting. |

2. **Customer Service & Collaboration-Customer Satisfaction:**Evaluate quality aspects as follows:



   - Use of EQRS Reports.

   - EQRS quality results/goals shared with employees.

   - Number of EQ reviews conducted.

   - Quality and timeliness of work performed in team.

   - Error trends identified.

   - Quality improvement actions taken.

   - Workshops provided.

   - Employee input requested and utilized.


3. **Employee Engagement:** Evaluate aspects of employee engagement as follows:




| **Employee Engagement Components** | **Review Description** |
| --- | --- |
| Team Meeting Minutes | Review frequency of meetings, content, employee engagement.<br> <br>   - solicit agenda items from the team.<br>     <br>   - sharing an agenda.<br>     <br>   - ensuring meeting minutes are available for employees to review. |
| Performance Feedback | Evaluate:<br> <br>   - Methods of feedback used.<br>     <br>   - Schedule in place for Annual and Mid-Year reviews.<br>     <br>   - Timeliness of Annual and Mid-Year reviews presented.<br>     <br>   - Proper adherence to schedule of work reviews, such as EQ, paper and telephone monitoring.<br>     <br>   - Sample reviews for narratives including both negative and positive feedback.<br>     <br>   - Timeliness of Employee feedback and follow-up.<br>     <br>   - Actions taken to improve employees performing below the acceptable level.<br>     <br>   - Contract requirements are covered if the performance has decreased. |
| Employee Engagement | - Solicits employee perspectives in achieving team or operational goals.<br>     <br>   - Addresses issues raised by employees, follow-up, and feedback.<br>     <br>   - Uses management information reports to improve employee performance and overall team performance (inventory reports, Survey EQRS, phone reports, etc.).<br>     <br>   - Uses survey results to enhance Employee Satisfaction, Customer Satisfaction, and Business Results. |
| Staff Utilization | - Identifies and eliminates single points of failure, ensuring back-ups are in place for all responsibilities.<br>     <br>   - Provides Cross Training.<br>     <br>   - Utilizes clerical support effectively to ensure all work is logged in, batched, and assigned per the IRM requirements timely.<br>     <br>   - Work leader accessibility. |
| Best Practices & Program Enhancements | - Involvement in special projects.<br>     <br>   - Identifies and implements efficiencies.<br>     <br>   - Identifies best practices.<br>     <br>   - Engages the staff in leading improvement and leading others. |

4. **Program Management**-Business Results: Evaluate aspects of program management as follows:




| **Program Management Attribute** | **Activities** |
| --- | --- |
| Leave Usage | - Review leave usage report for leave balances/patterns.<br>     <br>   - Review leave counseling documentation. |
| Time Utilization | - Identifies/elevates/resolves scheduling issues.<br>     <br>   - Reviews status of inventory.<br>     <br>   - Initiatives/challenges.<br>     <br>   - Response to controls. |
| Strategic Plan | - Actions taken to achieve operational goals.<br>     <br>   - Maintains technical abilities by keeping abreast of procedural changes, reviews SERP Alerts, attends annual Continuing Professional Education (CPE) or technical training when available. |
| Risk Management | Risk awareness, analysis, and management within and outside of team. |
| Statute Protection | Takes actions to protect statutes. |


**1.4.20.10.3.2** **(06-05-2025)**

##### Operations Manager’s Operational Review of Department Manager (DM)

1. **Leadership & Human Capital**: Evaluating Leadership involves review of actions taken toward DM responsibilities:




| **Leadership attribute** | **Activities** |
| --- | --- |
| Leadership development | - Developing CLP, LSR.<br>     <br>   - Scheduling meetings with LSR participants.<br>     <br>   - Providing developmental opportunities. |
| Adaptability | Adapting to and promoting organizational change. |
| Networking | Networking with peers, stakeholders, internal and external contacts. |
| Communication | - Knowledge sharing with direct and indirect staff, peers, and beyond the department.<br>     <br>   - Visibility to staff.<br>     <br>   - E-mail communication.<br>     <br>   - Sharing operational goals. |
| Use of Time | - Effectiveness of time management method used for managing tasks or assignments.<br>     <br>   - Workload processing and handling of backlogs.<br>     <br>   - Organization effectiveness.<br>     <br>   - Identification of problems and implementation of solutions.<br>     <br>   - Timeliness of controlled responses. |
| Employee Personnel Folders (EPF) Maintenance | - Review a random sample of employee EPFs in each department and team. (Director discretion on sample volume requirements).<br>     <br>   - Current EPF checklist provided.<br>     <br>   - Outdated material purged. |

2. **Customer Service & Collaboration - Customer Satisfaction**: Evaluate quality aspects as follows:



   - Review and assess EQRS results.

   - Shared EQRS quality results/goals with departments.

   - Number of EQRS reviews conducted.

   - Error trends identified.

   - Quality improvement actions taken.


3. **Employee Engagement:** Evaluate aspects of employee engagement as follows:




| **Employee Engagement Component** | **Review Description** |
| --- | --- |
| Staff Meeting Minutes | Review frequency of meetings, content and appropriate agenda items are filtered from DM to teams. |
| Performance Feedback | - Methods of feedback used.<br>     <br>   - Review schedule in place for Annuals and Mid-Years.<br>     <br>   - Annual and Mid-Years are presented timely. |
| Employee Engagement | - Solicits employee perspectives in achieving team or operational goals.<br>     <br>   - Addresses issues raised by employees, follow-up and feedback.<br>     <br>   - Holds focus group meetings.<br>     <br>   - Use of survey results to enhance employee satisfaction customer satisfaction, and business results. |
| Staff Utilization | - Promotes succession planning.<br>     <br>   - Acts to minimize effects of projected attrition.<br>     <br>   - Addresses staffing concerns.<br>     <br>   - Ensuring Inventory management controls are in place. |
| Best Practices & Program Enhancements | - Involvement in special projects.<br>     <br>   - Identifies and implements efficiencies.<br>     <br>   - Identifies best practices.<br>     <br>   - Engages the staff in leading improvement and leading others. |

4. **Program Management- Business Results:** Evaluate aspects of program management as follows:




| **Program Management Attribute** | **Activities** |
| --- | --- |
| Leave Usage | - Oversees resources.<br>     <br>   - Review leave usage report for leave balances/patterns.<br>     <br>   - Review leave counseling documentation. |
| Time Utilization | - Response to dues/controls.<br>     <br>   - Addresses/resolves program challenges and/or scheduling issues. |
| Strategic Plan | - Actions taken to achieve operational goals.<br>     <br>   - Manager maintains technical abilities by keeping abreast of procedural changes reviews SERP alerts, attends annual CPE or technical training when available. |
| Risk Management | Risk awareness, analysis and management within and outside of team. |
| Statute Protection | Takes action to protect statutes. |


**1.4.20.10.3.3** **(06-05-2025)**

##### Director P & A Staff Operational Review of Operations Manager (OM)

1. **Leadership & Human Capital:** Evaluating leadership involves review of actions taken toward OM responsibilities:




| **Leadership Attribute** | **Activities** |
| --- | --- |
| Leadership Development | - Schedules meetings with LSR participants.<br>     <br>   - Provides developmental opportunities. |
| Adaptability | Adapting to and promoting organizational change. |
| Networking | Networking with internal and external contacts. |
| Communication | - Knowledge sharing with direct and indirect staff and beyond the operation.<br>     <br>   - Visibility to staff.<br>     <br>   - Shares status of operational goals. |
| Employee Personnel Folders (EPF) Maintenance | - Random sampling from various teams in each department: (2) DM, (2) FLM and (1) tax examiner or collection representative, clerk and team lead from each department.<br>     <br>   - Current EPF Checklist provided.<br>     <br>   - Outdated material purged. |

2. **Customer Service & Collaboration- Customer Satisfaction**: Evaluate quality aspects by review of NQRS/EQRS reports:



   - Compare NQRS to EQRS cumulative results to identify opportunities for improvement in each measurement.

   - Compare quality goals to quality achievements.

   - Evaluate quality improvement actions.


3. **Employee Engagement**: Evaluate aspects of employee engagement as follows:




| **Employee Engagement Component** | **Review Description** |
| --- | --- |
| Performance feedback | Review frequency of meetings, content and appropriate agenda items are filtered through operation. |
| Employee Engagement | Ensures annual CPE is provided to all employees. |
| Staff Utilization | - Promotes succession planning.<br>     <br>   - Acts to minimize effects of projected attrition.<br>     <br>   - Addresses staffing concerns.<br>     <br>   - Ensures Inventory management controls are in place. |
| Best Practices & Program Enhancements | - Involvement in special projects.<br>     <br>   - Identifies and implements efficiencies.<br>     <br>   - Identifies best practices.<br>     <br>   - Engages the staff in leading improvement and leading others. |

4. **Program Management- Business Results**: Evaluate aspects of program management as follows:




| **Program Management Attribute** | **Activities** |
| --- | --- |
| Time Utilization | - Responds to dues/controls.<br>     <br>   - Addresses/resolves program challenges and/or scheduling issues.<br>     <br>   - Monitors program targets.<br>     <br>   - Delivery of the business plan. |
| Strategic Plan | Actions taken to achieve operational goals. |
| Risk Management | Process to address risks identified within the operation. |
| Statute Protection | Takes actions to protect statutes. |


**1.4.20.10.4** **(07-10-2020)**

#### Documentation and Follow-up

1. Each operational review must be documented in a memorandum from the reviewer to the manager of the component reviewed. It is not intended that the review be completed all at once. Any item reviewed before the scheduled operational review should not be repeated. The results of such reviews must be included in the documented annual review. The memorandum must be issued promptly upon completion of the review. The review date will be the same as the review completion date for purposes of assessing the timeliness of the review.

2. The format of an operational review should begin with identifying the team/department/operation reviewed, the evaluative period, summarize the review process and communicate response requirements. The body of the review should address each of the Responsibilities in the Management Performance Agreement for the manager (Leadership and Human Capital Management-Employee Satisfaction, Customer Service and Collaboration-Customer Satisfaction, and Program Management-Business Results) as well as the administrative compliance requirements. In addition to the Responsibilities, the operational review must include a section on employee engagement. The review should also include engagement between the management chain as well as engagement between the manager and their employees. The closing section of the review should summarize the overall performance of the team/department/operation, articulate corrective actions to be taken and communicate any follow-up actions to be performed by the reviewer.

3. Action items communicated to the manager must include a description of the action to be performed and include a time line for completion.

4. Managers must follow up to ensure accomplishment of action items identified in their reviews. The follow-up must be performed timely and include actions taken on problems identified, updated progress actions taken towards completion and any further actions identified requiring additional follow-up documented with a second date for completion.

5. To provide continuity and a record of the problems and progress of each organizational component, maintain the review memorandums and all follow-up action items in file folders or binders by organizational component. A signed and dated copy of the initialed memorandum(s) and all follow-up documentation must be placed in the EPF of the appropriate manager for future use in the evaluation process. .


**1.4.20.11** **(07-10-2020)**

### Program Reviews

1. The best opportunity to improve the overall operation of a program or function is with employees' input. Employee input and suggestions should always be considered. New employees to the operation, function or program provide an excellent opportunity to question procedures that have been in place for a long period of time and offer suggestions for improvement. Rotation of assignments provide an opportunity for another point of view to be included in working the program.

2. A program review is designed to evaluate the effectiveness of a specific work process, procedure or any aspect thereof. The scope of the review is not limited to any organizational component. The primary purpose is to identify procedural and/or workflow problems and procedural or processing techniques to enhance productivity.

3. Program reviews should be conducted based on implementation of new programs, statistical indicators, backlogs, feedback from the employees or customers, or other problem indicators. They should also be conducted on a periodic basis in high-risk areas (areas in which procedural breakdown are either likely, such as correspondence processing, or unacceptable, such as remittance processing and security).

4. Any level of management may identify the need for a program review, but the review should be initiated by the level of management which has responsibility for the total program. The actual conducting of the review may be delegated to a lower level manager or to a technician. Conducting a program review could be a good developmental experience.

5. Program reviews should be documented in a memorandum for the record, which should identify the purpose, background, methodology and findings. Additionally, action items, recommendations, target dates and responsible parties should be identified. The initiator of the review should follow up timely on target dates.

6. To prevent duplication of effort and provide necessary documentation, the documentation describing program review results should be maintained at the operation level. If the results have national impact, they should be shared with the appropriate BOD Analyst.


**1.4.20.12** **(07-10-2020)**

### Enforcement Statistics

1. IRM 1.5.1, The IRS Balanced Performance Measurement System, prohibits the use of Records of Tax Enforcement Results (ROTERs) and Tax Enforcement Results (TERs) in evaluations or to impose or suggest goals or quotas for Collection employees and their immediate managers. This applies to any employee responsible for making enforcement determinations.

2. In addition to evaluations, ROTERs or TERs cannot be considered in selecting employees for promotions or in performance recognition.

3. Each manager (all levels) must certify that they have not used ROTERs or TERs each quarter. The certification must include a detailed description of all incidents and the corrective actions. Managers should become familiar with the IRM 1.5.2 , Uses of Section 1204 Statistics, which provides guidance on the proper use of statistics.

4. Managers should discuss methods for staying abreast of the operation's compliance with the proper use of enforcement statistics so that all understand what is expected. Sample reviews are required of items such as: evaluations, work reviews, team meeting notes.


**1.4.20.13** **(01-20-2012)**

### Priorities

1. A primary responsibility of the operations manager is to balance staff with workload. This may involve shifting personnel between departments or teams to prevent backlogs or unanticipated workload demands.

2. The operations manager should deploy the staff to prevent backlogs in the most critical areas (i.e., correspondence, incoming calls, TAO cases, Congressional cases). Workload and resources must be evaluated on an operational level rather than the departmental level in order to take maximum advantage of all available resources so that the most critical workloads receive first attention. In work scheduling, department and front-line managers are instructed to elevate resource surplus/shortfall conditions to the operations manager.

3. Beyond those critical areas in which no backlogs can be tolerated, the operations manager must ensure efficient application of staffing to the workload. The key consideration is the prioritizing of each functional workload. Staffing should be balanced to ensure its application to the highest priority cases in each workload before application to lower priority cases in any workload.

4. The shifting of resources between CSCO, ACS Call sites, and ACS Support sites will enable the operation to process all priorities of all functional workloads. When this is not possible and a shortfall occurs that requires high priorities to become backlogged for more than 45 days after the follow-up date has expired, the operations manager should advise their director of the condition.


**1.4.20.13.1** **(06-05-2025)**

#### Downtime Contingency Plan

1. Under an enterprise telephone system, calls are routed using Enterprise Queue (EQ) technology. The current Joint Operations Center (JOC) web page, Joint Operations Center , has the criteria to be used to request a site closure due to a system outage. A site should follow this criteria if needed applications such as ACS or IDRS are down. Every effort must be made to handle the calls within your directorship prior to Enterprise routing. Refer to IRM 5.19.5.4.12, Telephone Techniques and Communication Skills, for specific instructions on handling calls in the ACS Call sites when experiencing system problems. However, when calls are re-routed, there is a need to assign work for your employees to complete until the system is restored. If down time is scheduled, any of the items listed below could be utilized.

2. Each call site, ACS Support site, and CSCO operation should have a contingency plan of operation in place to be used when downtime occurs. The plan should include options that are available for short term or long term down time.

3. Suggested short-term actions include:



1. Conduct team meetings;

2. Adjust read time or provide additional read time;

3. Make directory assistance calls from lists (if available)

4. Conduct mini-training sessions.

5. Identify inventories that can be worked if only one of the two systems are down;

6. Consider clerical work, if co-located within a Support function.

7. Have employees take any required or elective Integrated Talent Management (ITM) courses online.


4. If significant downtime is expected, the above items could be used on a larger scale or some of the following can be considered:



1. Move up longer scheduled training sessions if possible (i.e., CPEs)

2. Possible details outside of ACS

3. Liberal leave


5. Generally, downtime contingency plans are developed and maintained at the operations and/or department level. However, first-line managers should be aware of the plan's contents and should be prepared to implement them upon notification. Some sites utilize a net send to instruct employees on the plan of action to take (i.e., work green screen if ACSWeb is not functional, etc.).


**1.4.20.14** **(06-05-2025)**

### Taxpayer Rights

1. Restructuring and Reform Act (RRA)'98, Section 1203 contains important sections that all IRS employees should thoroughly understand and take very seriously. RRA '98 provides for the mandatory termination of any IRS employee who willfully commits any of the 10 specific acts or omissions under various specific instances of misconduct. Consult the Human Capital Office web site HCO Section 1203 and Non-1203, for 1203 Statutory language and related guidance.

2. Managers must be sure that employees know and observe the rights of customers. Taxpayers have the right to prompt, courteous, and impartial treatment. In dealing with taxpayers, employees should:



1. Assume that each taxpayer wants to comply, unless circumstances of the case indicate otherwise;

2. Try to put him/herself in the taxpayer's position;

3. Seek to identify the taxpayer's problem;

4. Try to resolve the immediate problem and at the same time prevent future problems;

5. Try to resolve a taxpayer's problem without referring him/her elsewhere;

6. Allow the taxpayer to appeal to the supervisor if they feel the decision is unfair;

7. Maintain a business like and professional manner.


### Note:

The IRS formally adopted a Taxpayer Bill of Rights in June 2014, which provides the nation’s taxpayers with a better understanding of their rights and helps reinforce the fairness of the tax system. In 2015, Congress charged the Commissioner with ensuring IRS employees are familiar with and act in accord with the taxpayer rights as afforded by the Code. IRC 7803(a)(3). IRS employees must be informed about taxpayer rights and be conscientious in the performance of their duties to honor, respect and effectively communicate those rights which may aid in reducing taxpayer burden. See Pub 1, Your Rights As A Taxpayer, or IRM 5.19.1.3.2.3, Taxpayer Advocate Service (TAS), for more information. Also, see Taxpayer Bill of Rights FAQS.

**1.4.20.14.1** **(07-10-2020)**

#### Unauthorized Disclosure

1. As a Front-line manager, you should report any suspected unauthorized disclosures to your local TIGTA Office.

2. It is not within the scope of your authority to make a determination on whether sanctions should be imposed against an employee for a willful or inadvertent violation of the disclosure laws. This will be determined by the Treasury Inspector General For Tax Administration (TIGTA).



### Note:



A willful act is one where there is an intentional violation of a known legal duty.

3. If one of your employees receives a complaint or summons in a civil suit containing allegations of unauthorized disclosure, immediately contact your local Disclosure Manager and notify TIGTA.



### Note:



Please see IRM 11.3.38.5 , Reporting Suspected Willful Unauthorized Accesses or Disclosures, and IRM 11.3.38.5.1 , Reporting Non-willful Inadvertent Disclosures of Sensitive Information, for a contrast of willful versus inadvertent improper disclosures.


**1.4.20.14.2** **(05-18-2021)**

#### Collections Appeals Program (CAP)

1. ACS, ACSS and CSCO managers will be involved with Collection Appeal Program (CAP) issues, which are liens, levies, seizures, and Installment Agreement terminations.

2. If a taxpayer is told by an IRS employee that a lien, levy or seizure action has been or will be taken, or that an Installment Agreement is rejected or terminated or proposed to terminate, the taxpayer can appeal the action

3. Customers are informed about the existence of their appeal rights in Pub 594 , The IRS Collection Process, which is sent with the final notice (CP 504, LT11, or equivalent). CP 523 Installment Agreement Default Notice, informs the customer of his/her right to an independent appeal. (A provision of the Taxpayer Bill of Rights 2 (TBOR2) gives taxpayers appeal rights once they are notified that the IRS intends to terminate their installment agreement.) Publication 1660, Collection Appeal Rights , includes information on how to appeal.

4. When your employee has advised a customer that a lien or levy action will be taken, or if the action has been taken, the customer has the right to appeal this action. However, before the case is referred for Appeals consideration, the customer must first discuss the problem with the manager. IRM 5.19.8.4.16 contains procedures for the CAP.

5. As a front-line manager, you will take the call immediately, if possible, so a call back message will not be necessary. If you must call back, it should be made within 24 hours of the customer's call.



### Note:



These callbacks cannot be re-delegated.

6. If the customer does not agree with your decision, verbally advise the customer the case will be forwarded to Appeals through the CAP Coordinator. The coordinator or originating manager will then hand-carry or fax the complete file, within 2 days of your conference with the taxpayer, to the appropriate Appeals office for final resolution.

7. Ensure the collection activity is suspended while the case is in Appeals. Appeals have agreed to process these cases within 5 days and will notify management of their decision.


**1.4.20.14.3** **(05-18-2021)**

#### Collection Due Process (CDP)

1. ACSS employees are responsible for taking initial actions on Collection Due Process requests following the guidance in IRM 5.19.8, Collection Appeal Rights, and forwarding the request to Appeals. Timely filed CDP requests should be forward to Appeals as required per IRM 5.19.8.4.7.5, Initial Actions.

2. Managers must monitor the aging of CDP or EH cases remaining in ACSS inventory prior to the required referral date, see IRM 5.19.8.4.7.5, Initial Actions.

3. If resolution of the taxpayer’s issues seems likely but will take longer than time allowed in IRM 5.19.8.4.7.5, Initial Actions, manager concurrence is required to continue working with the taxpayer toward resolution.

4. This concurrence must be documented by a manager or managerial official in AMS history and the case file history. If AMS is unavailable, concurrence should be documented in ACS comments.



### Note:



See IRM 1.4.20.9, Controls, for a list of reports which can be used to monitor the aging of CDP inventory.


**1.4.20.15** **(06-05-2025)**

### The Performance Management System

1. The Performance Management System (PMS) is the appraisal system used to evaluate IRS employees. It consists of an ongoing process of planning expectations, monitoring, evaluating and recognizing performance. Leaders use the system to inform an employee of what is important and expected of an employee in performing his or her job. The IRS's performance management system is designed to strengthen the linkages between Performance Management and the IRS's mission, strategic business goals, business plans and the Balanced Measurement System. This agreement is intended to establish annual performance expectations in this regard. As described below, those critical expectations consist of three parts: Responsibilities that are common to all IRS managers, commitments that are specific to each, and a retention standard for fair and equitable treatment of taxpayers. These performance expectations (set at the beginning of each fiscal year) serve as the basis for a manager's annual performance evaluation.

2. The performance agreements for executives, Leaders and management officials (Forms 12450, A or B) consist of the following categories:



   - Responsibilities - represent the core values of the IRS, what is important to us as an organization and are common to all executives, leaders and management officials

   - Commitments - distinct actions/desired results to be achieved during the performance period

   - Summary Evaluation - balances the Retention Standard, Responsibilities and Commitments to determine the final rating


3. **Critical Job Element (CJE)** \- The performance plan for employees is composed of critical job elements and performance standards that serve as the basis for assessing performance. CJEs establish a link between organizational performance (balanced measures) and individual performance. They are specifically developed for each IRS occupation by teams composed of managers and employee subject-matter-experts. For more information please use the link provided to visit the CJE Resource Center: /Critical Job Elements (CJE) Resource Center. It consists of the following: Work assignments or responsibilities of such importance that unacceptable performance in one element determines the employee's overall performance to be unacceptable



1. Performance aspect - a portion of the CJE which describes the requirements of the position

2. Performance standard – found within each CJE and which describes how well an employee must do their job to accomplish the work objectives effectively


4. **Retention Standard**\- Both the performance agreements for executives, Leaders and management officials and the performance plans for employees contain the Retention Standard mandated by the Internal Revenue Service Restructuring and Reform Act of 1998. All employees are required to be evaluated on the fair and equitable treatment of taxpayers. If an employee does not meet the retention standard, they will be considered as having failed a CJE and will be ineligible for certain personnel actions, such as a performance award, a within-grade increase, a career ladder promotion and competition for a promotion. If the employee has not conducted duties with potential impact on taxpayer issues or outcomes during the performance period, you should check the "Not Applicable" block on the Retention Standard form.

5. **Types of Recognition/Awards granted at the IRS** \- Employee recognition is designed to reward and recognize employees, either individually or as a member of a team or group, for their performance, adopted suggestion ideas, or other exemplary contributions to the IRS's mission. .



1. Employee recognition may include monetary awards, time-off without charge to leave, honorary recognition (e.g. plaques, certificates, etc.), informal recognition items, or a combination thereof. See Exhibits 1.4.20-1 and 1.4.20-2 for a list of the various forms of recognition.

2. Processing: Form 9127, Recommendation for Recognition, (or other locally authorized award approval document) shall be used to recommend, approve, certify and authorize payment of an employee, team or group award.


6. **Leader's Responsibilities** \- Managers have a responsibility to ensure the timely completion of administrative actions. Below is a list of some of those actions:




| **Actions** |
| --- |
| Ensuring the leader’s or management official’s performance agreement or employee’s critical job elements accurately reflect the expectations you and the organization have of the employee. |
| --- |
| Issuance of the performance plan to the employee in a timely manner; at the beginning of the performance period. Within the first 30 days, employees sign the appropriate retention standard document (Form 6774 ,Receipt of Critical Job Elements and Retention Standard; TD F 35-07 - Executive Performance Agreement,; Form 12450-A,- Manager Performance Agreement, ,12450-B - Management Official Performance Agreement Form, and 12450-D - Management/Program Analyst Performance Agreement ) to acknowledge receipt of the standard. These forms can be found at Executive performance agreement. Employees must sign a new receipt even if their performance standards (CJEs or responsibilities/commitments) have not changed from the prior year. The manager files the signed receipt in the employee personnel file (EPF). |
| Thoroughly discussing the plan with the employee. |
| Ensuring the employee understands what is expected of them. |
| Obtaining the employee's signature on the appropriate forms and filing them in the employee's Employee Performance Folder (EPF). Both the receipt and acknowledgement of the retention standard and the ratings are filed in the EPF and retained for three years. |
| Providing meaningful feedback to the employee during the rating period including conducting the mandatory mid-year progress review. |
| Requesting the employee provide a self-assessment near the end of the rating period. |
| Completing the employee’s annual appraisal and discussing the results with the employee. At the end of the performance period, managers indicate whether the retention standard is "Met,"" Not Met," or "Not Applicable" and the appraisal form (Form 6850, 12450, or TD F35-07) is filed in the employee personnel file (EPF). |
| Recognizing the employee’s performance with performance awards when appropriate. For more information please access the following web site: Employee Recognition Program |


**1.4.20.16** **(01-20-2012)**

### Administrative Tasks

1. Managers have a variety of administrative responsibilities, some of which are not directly related to the daily management of employee work. The following text outlines some of these administrative areas.


**1.4.20.16.1** **(01-20-2012)**

#### Employee Appraisals Mid-year Progress Reviews

1. The progress review must be documented in writing to aid discussion and to verify that it has taken place. However, you are not required to write a comprehensive narrative as you would for an Annual appraisal. If the employee is performing at a fully successful or better level, the narrative need only address the employee's overall performance in general terms, without the specificity required for an annual appraisal.

2. If the employee's performance is less than fully successful, you need to give more specific information and include a plan of action to help the employee to improve. A warning at the mid-year progress review should be documented if the employee's performance may result in the evaluation being lowered at their next annual rating period.

3. Critical job elements must be noted in the progress review. The manager will advise the employee of the level of performance required and provide examples of both strong and weak areas of performance.


**1.4.20.16.2** **(06-05-2025)**

#### Employee Performance Folders

1. To ensure consistency and equitable treatment of all employees Servicewide, the Employee Performance Folder (EPF), including the official ratings of record, must be maintained and secured by the manager of record in his/her office. Managers must maintain an EPF for each employee. The folder provides for assembling significant data, which will assist in evaluating employees.

2. EPF items are intended to be representative work samples and should be prepared as frequently as possible. Managers should be alert to potential EPF items when reviewing work in process, completed cases submitted for approval, and telephone monitoring.

3. EPF items should be keyed to the critical job elements and standards of the position description. When completed regularly and discussed with the employee, EPF items will keep the employee fully apprised of his or her performance. The contents of the EPF should form the basis for performance appraisals.

4. The following is a list of mandatory items that are required to be included in an Employee Personnel Folder:




| **Mandatory EPF items** |
| --- |
| Form 6774: Receipt of Performance Plan |
| --- |
| Form 6850: Copy of most recent, and subsequent evaluation appraisals |
| A copy of the employee’s Position Description (PD) and Current Critical Job Elements (CJE's) - Performance Plan |
| Applicable standards if the employee is under a measured plan |
| Copies of mid-year and other performance related material (for example: Telephone monitoring /and or TEACH reviews; promotion appraisal data, probationary certification, removal or performance related awards) |
| Performance counseling (employees statements of disagreement with evaluations should be attached to appropriate evaluation) |
| Aged Case Listing (CSCO, ACSS) |
| Employee rebuttal statements |
| interim appraisals and or reports such as evaluations of details, task force participation or instructor assignments |
| Copies of letters of commendation, awards, or congratulatory letters regarding the employee's work |





### Note:



For more information about what is required to be included in an employee’s EPF you can search the Human Capital Office website at, Human Capital Office

5. The following material should not be included as documentation in the performance folders:



   - Documentation related to any non-performance matter or adverse action that is based purely on non-performance reasons,

   - Negative material, which has not been discussed or acknowledged by the employee within 15 days of its development or receipt. (See the Article 12, Section 9 on Evaluative Recordation in the current National Agreement).

   - Files, ratings, certifications and appraisals entered on Forms 6850, which exceed the 4 year retention period. Material older than 12 months may be used for historical reference purposes only. Please refer to Human Capital Office for additional guidance.



     ### Reminder:



     Under no circumstances will evaluation material older than 12 months be used in the preparation of a performance appraisal or its re-validation.


6. Review performance folder material periodically (at least yearly) and keep it current. No purpose is served by maintaining historical files after the problems observed have been corrected. Acting unit/team managers who are detailed for more than an occasional managerial absence should be alert for performance data to include in the EPF. Remind acting managers of the current National Agreement requirements regarding items of recordation.



### Note:



All documentation placed in an employee's EPF must be signed and dated by the employee or notated "**employee refused to sign**."


**1.4.20.16.3** **(06-05-2025)**

#### Employee Performance Data

1. Managers have numerous opportunities, both formal and informal, to observe and evaluate employee performance. The current National Agreement sets forth criteria under which these observations can or cannot be used in performance appraisals.

2. It is important to understand what types of data can be used in evaluating employees.



   - Performance Indicators

   - Embedded Quality Review System(EQRS)Data Collection Instrument (DCI)

   - Recordation


| **Types of Employee Information** |
| --- |
| **Performance Indicators** are anything positive or negative that directs a manager’s attention to some aspect of employee performance. | Statistical data contained in management reports must not be used in evaluating employee performance (this is prohibited by law)<br> <br>   - Managers can review and analyze individual statistics such as number of calls made, average talk and display times, number of cases accessed, etc. This may indicate some area of performance to investigate further<br>     <br>   - The actual performance evaluation of an employee shall continue to be made by traditional evaluative methods, for example, work reviews, monitoring, and personal observation.<br>     <br>   - Management Reports generated from various systems are prohibited from being used for evaluative purposes. Use reports to determine indicators of behavior, and the need for further monitoring and/or assistance. Reports can also be used to assist in determining when increased managerial involvement is warranted.<br>     <br>   - Performance indicators may help identify training needs. |
| **Embedded Quality Review System**EQRS Data Collection Instrument (DCI) | The EQ system summarizes five quality measures or buckets that are mapped to the employee CJEs.<br> <br>   - Customer Accuracy<br>     <br>   - Regulatory Accuracy<br>     <br>   - Procedural Accuracy<br>     <br>   - Professionalism<br>     <br>   - Timeliness |
| **Recordation** | Written documentation that has been shared with the employee.<br> <br>   - Can be positive or negative and in any written format (i.e. memorandum).<br>     <br>   - Praise good work, explain problems identified, give guidance, and determine training needs.<br>     <br>   - Documentation must be shared with the employee within 15 (work) days of its development if it is used in a performance appraisal. |

3. All Ratings of Record must be reviewed and approved by a higher level official than the Appraising official. In carrying out these responsibilities, approving officials shall pay particular attention to the difficulty of the standards and the strictness of the application of the ratings to ensure employees are rated fairly. Only those employees whose performance exceeds normal expectations are rated at levels above Fully Successful. Ratings of Record may not be communicated to employees until approved by a higher level of management.

4. **Employee Drop File**: Aside from maintaining an EPF, managers are responsible for also maintaining what is referred to as a "Drop File" or "Manager's File" . This file consists of information regarding the employee that is not performance related. Samples of items to be included in this file would be:



   - Attendance and leave counseling

   - Training requirement completions

   - Conduct issues and counseling

   - Medical information is no longer kept in the EPF folder. Per Labor Relation guidelines, this must be kept in a separate folder and stored in a locked cabinet.


5. **Leave Counseling**: Managers have a responsibility to maintain accurate leave records for their employee's. Managers should also cover leave issues with their employees on a regular basis in the form of leave counseling. Managers should follow the practices established within their local jurisdiction.


**1.4.20.16.4** **(06-05-2025)**

#### Security

1. Managers and ACS Systems Analysts are responsible for reviewing the Employee Listing by Name, requesting profile changes on applicable applications, such as ACS, IDRS, and AOIC, and enabling terminals for their employees. Managers should ensure their employees' IDRS profiles allow them to perform their assigned tasks. Tables at IRM 5.1.25-2 list the common command codes approved for use by all SB/SE Collection Operations employees, including Campus Collection.

2. When an employee is expected to be away from their terminal for more than two weeks or longer the employee should lock their profile to avoid being locked out by Data Security. The CC LOKME is used to lock IDRS. Please refer to IRM 10.8.34.5.2.2.4.2, Employee Self-Profile Locking (LOKME), for additional information.

3. Managers and employees have a legal obligation to protect the confidentiality of Sensitive But Unclassified (SBU) data including Personally Identifiable Information (PII) tax information and to prevent the unauthorized access to, or destruction of, IRS files accordance with IRM 10.5.1, Privacy Policy. To provide for the security of equipment, government documents, and return information, managers must ensure that:



1. Copies of tax returns, internal documents, etc., are properly shredded before disposal;

2. Visitors are channeled to a receptionist or other employee so that they do not have unauthorized access to the work area. Advise all employees to question strangers in the work area;

3. Employees should clear their desk of confidential material at the end of the workday, and sign-off all systems.

4. "Official Use Only" documents are protected per IRM 10.5.1, Privacy and Information Protection, and IRM 11.3.12 , Designation of Documents.

5. Fax machines and printers should be checked at the end of your tour of duty for government documents or return information;

6. Employees should always lock their terminals when leaving their workstation.


**1.4.20.17** **(07-10-2020)**

### Team Approach to Processing

1. Each site is responsible for all actions taken on cases that reside on their data base, including efforts to locate the taxpayer, contact with the taxpayers or third parties, correspondence processing etc. The case remains in the sites inventory until it is closed or transferred. Most management reports are available at the team level. In those sites using the team approach, managers approve work belonging to employees assigned to their team. Valid call site teams are designated by an alphabetical character from A through Z. The maintenance of this parameter table, which allows for creation of new teams when a need arises, is the responsibility of the campus management.

2. Each team has a Lead, CR or Tax Examining Assistant (TEA), who is responsible for relieving the manager of excess technical work. In addition to the above, the Lead is responsible for distributing and balancing the workload among employees and monitoring the status and progress of the work assigned to ensure timely completion. The Lead assures that all employees have enough work to utilize their work time efficiently. Day to day adjustments of work are made in accordance with established priorities. When absences occur, the lead assists the manager by informing employees of changes in assignment in order to balance the workload. The incumbent provides on-the-job training, instructs employees in specific tasks, and answers questions on procedures, policies and directives. Side-by-side monitoring/reviews can be conducted with trainees or to address performance issues, to provide constructive feedback (non-evaluative and/or evaluative) for the purpose of improving skills and/or documenting performance. The Lead keeps the manager informed of all patterns or trends observed which indicate potential problems in case processing and/or training needs. The Lead acts for the manager in his/her absence. When not performing lead duties, the incumbent performs the duties of a team CR and/or tax examiner as stated in their position description.


**1.4.20.18** **(01-20-2012)**

### Workload Management

01. Managing the workload requires the establishment of controls, adherence to work priorities, proper staff scheduling and assignment of work, and involvement in the daily operation of the team. Workload reviews are performed primarily for the following reasons:



    - Make an objective assessment of an employee's performance

    - Protect the rights of customers

    - Identify training needs


02. Work reviews should focus on effective case resolution according to IRM guidelines.

03. In addition, reviews should focus not only on your employee's ability to complete his/her assignments, but also on their ability to set priorities and complete assignments independently and expeditiously

04. Due to the variety and complexity of work categories, managers must ensure that:



    1. All work processes receive appropriate priority processing

    2. Adequate staffing is available

    3. Controls are established to monitor the paper workflow

    4. Employees are properly trained

    5. Imbalances in work inventory are corrected expeditiously


05. CSCO and ACS Support maintain their own workflow management protocols based on established Headquarter and local campus direction.

06. The CSCO and ACS Support schedules should identify clerical employee(s) responsible for processing the mail, reviewing letters, list processing etc. This schedule should also include assigning TEA employees responsibilities for processing support programs.

07. Managing call site programs requires establishing a work schedule assigning individual responsibility for receiving incoming calls, functional inventory, and lunch and break schedules. In preparing the schedule, consider the following factors:



    - Approved leave, training, etc.

    - JOC telephone schedule requirements

    - Inventory on hand at the end of the prior week in each team



      ### Note:



      Inventory reports can distort the true picture of a team’s performance or backlog situation.

    - Clerical duties such as updating locator services (directories) and the IRM, miscellaneous typing and filing, and other support services

    - Monthly, quarterly and/or annual activities your employees have with organizations outside of your operation (i.e. Special Emphasis Programs, NTEU Steward meetings, annual conventions or conferences and unique celebrations in your area of the country).


08. Managing the workload in the contact functions (Predictive Dialer Program) requires the establishment of priorities which will enable the team manager to conduct an outgoing call program while ensuring that customer service is provided to taxpayers as effectively as possible. Proper staff scheduling and assignment of work to handle incoming and outgoing telephone calls will require daily involvement in the teams. There will be peak and non-peak periods in the incoming call operations. Therefore, the systems analyst should keep department/team managers informed if staffing needs to be realigned

09. Managing the inventory in the Research and Investigation functions requires the establishment of workflow controls, assignment schedules, quality review checkpoints, monitoring and performance review schedules, and timeframes to complete certain work items such as mail processing, list processing, and other clerical assignments.

10. Rotate work assignments to ensure that all employees are fully trained in all areas and to provide sufficient evaluative information of their work performance.


**1.4.20.18.1** **(06-05-2025)**

#### Compliance Nature of Workload

1. Your employees may answer telephones, make outgoing telephone contacts, work written referrals of taxpayer inquiries or correspondence, or work other paper processes. This work is outside of the AUR, CAWR and FUTA current year program processes.

2. Collection managers in campuses and area offices are responsible for managing one, all, or any combination of the following:



   - Telephone operations

   - Correspondence operations

   - ACS inventories


3. Proper workload management is essential for timely responses to customers and prompt account transactions. Due to the variety and complexity of work in Compliance Service, managers must be familiar with the many aspects to managing workloads such as:



   - Establishing controls and priorities

   - Requesting adequate staffing and terminals

   - Conducting reviews

   - Processing work within established time frames

   - Correcting imbalances in work inventory

   - Providing adequate training

   - Being involved in the daily operation of the unit

   - Managing time effectively

   - Using available reports and management tools to monitor the operation


4. All workloads must be processed using the guidelines provided in the following IRMs:



   - IRM Part 4 - Examining Process

   - IRM Part 5 - Collecting Process

   - IRM Part 13 - Taxpayer Advocate Service

   - IRM Part 20 - Penalty and Interest

   - IRM Part 21 - Customer Account Services

   - IRM Part 25 - Special topics



     ### Note:



     Please note this list is not all inclusive.


5. There are peak and non-peak periods in each function to be aware of in planning for staffing and training. They can be anticipated by doing the following:



   - Looking at current work schedules and work plans

   - Checking historical data

   - Getting updated information from the operations and/or department manager


6. Once you have determined your peak and non-peak periods, prepare for workload peaks in the following manner:



1. Cross-train employees on all programs worked in the unit

2. Recall seasonal employees in time to give them refresher training

3. Hire additional staff if necessary

4. Survey other areas for staff available for details

5. Ensure you have an employee trained to access NMF information

6. Consider the use of overtime


**1.4.20.18.1.1** **(06-05-2025)**

##### Collection Managerial Reports

01. As a Compliance manager, you are also responsible for ensuring that the workload is being managed in a timely and efficient manner. In order to properly manage workload, you must be familiar with productivity, control, inventory, quality and customer satisfaction reports.

02. Inventory reports can be found on the Control-D Web Access (CTDWA), which replaced the Electronic On-line Network System (EONS). CTDWA is an inventory system that reduces print output and allows quicker access and greater report management for users to their respective report files. Complete BEARS to request access to the CTDWA.

03. The following information reports can be accessed through CTDWA:



    - CCA 42/42 - Collection Branch Team Inventory Report

    - CCA 42/43 - Collection Branch Day Overage Report

    - CCA 42/44 - IDRS Multiple Case Control Report.

    - PCC 6040 SC WP&C Performance and Cost Report


04. Inventory reports may also be generated through AMS. Complete BEARS to request access to AMS.

05. The CCA 42/43 report must be reviewed to determine unpostable IDRS transactions.

06. IDRS reports may be reviewed to determine the overall age of controlled inventory for groups. IDRS reports also provide individual controlled inventory reports and must be monitored to ensure that all cases are controlled and worked timely.

07. Additional information on these reports and others can be found in IRM 3.30, Work Planning and Control, IRM 5.2.4 , Collection Reports, and IRM 21.2, Systems and Research Programs.

08. It is your responsibility to ensure that all data reflected in the summary reports is accurate. In order to determine accuracy, verify the hours used under your organization with your employee’s time sheets. Also, verify the receipts and closures shown with your employee’s individual inventory reports.

09. You may generate quality reports using the Embedded Quality Review System (EQRS). EQRS reports are available in three categories:



    - **Employee Reports** \- Quality attributes are mapped to employee critical job elements (CJEs) and performance aspects. This ties the quality of a case directly to an employee's appraisal. There are two types of employee evaluative reports available Individual Review Feedback Report and Cumulative Review Feedback Report

    - **Organization Reports** \- Can be generated for any organizational segment down to a team level. The available reports include Organizational Cumulative Report, Top Ten Defects/Successes Report, Customer Accuracy Driver Report, Days to Closure Report (Unweighted), and Time in Inventory Report

    - **Ad Hoc Reports** \- Allows the user to specify report parameters, giving the user much more flexibility in retrieving data.


10. Complete BEARS to request access to EQRS. Additional information for EQRS can be found in IRM 21.10.1, Embedded Quality (EQ) Program for Accounts Management, Campus Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support .

11. For more information concerning the Customer Satisfaction Survey, see _IRM 1.4.20.32_, Manager's Responsibility to the Customer Satisfaction Survey (CSS).


**1.4.20.18.2** **(06-05-2025)**

#### Use of Management Information Systems

1. Team managers will utilize the following telephone management information reports:



   - IRS.STND.HI Agent Team- Aceyus Reports

   - IUP Historical Reports -ETD

   - Daily/Weekly Employee Time Summary - Ready Report

   - eWFM

   - Standard or locally developed Custom View Reports - Director

   - And any other pertinent reports - RTA


2. Team managers will utilize the following inventory management information reports:



   - Inventory Reports - QMF

   - Daily Workload - ACS MR00

   - Teach List - ACS ER00, Team, Empl,Num or QMF

   - Employee Summary Report - ES00,OPT,Emp,Num

   - Time Statistics Report - TS00


3. These reports provide useful employee performance data and assist in the management of a team's inventory and telephone operation. These reports will provide a total picture of an individual employee's or team's performance.


**1.4.20.18.3** **(06-05-2025)**

#### Priorities

1. Managers must set workload priorities for their team to address critical areas (i.e., incoming call operation, TAOs, correspondence, levy inventories, and over aged functional inventory). Workload and resource balancing are subject to operations approval.

2. ACS inventories are sequenced for next case processing within a two-tiered priority system. Generally, workload in a higher tier must be exhausted before the system moves to a lower tier per IRM 1.4.61.2.




| **ACS inventory factors** |
| --- |
| Time constraint | Sequencing is used to identify the best time to call the taxpayer. The time constraint should not apply to Research or Investigation functional inventory. |
| priority and scheduled follow-up date | Sequencing applies to all functions. Ensures first-in first-out processing within priority. Access order:<br> <br>   - Highest priority (i.e. 0,1, etc.)<br>     <br>   - Oldest follow-up date within priority<br>     <br>   - Oldest ACS establishment cycle within follow-up date; this allows all higher priority cases to be accessed before any lower priority cases. |

3. ACS Call Site workable inventories are determined based on inventory segments and “Consolidated Decision Analytics” (CDA) identify high priority inventory cases which is first priority.

4. CSCO and ACS Support maintain workflow management consistent with established Headquarter Campus Collection, and local protocols.

5. Ensure correspondence is screened according to established CSCO and/or ACS Support program protocols based on campus direction. Identify documents (for re-routing) belonging to other employees to associate with suspense files. Managers must ensure that correspondence is expeditiously routed to the proper function. Depending on the CSCO and/or ACS Support Department, work will be batched in volumes of 25 or less, assigned a locally determined batch control number and dispensed according to established campus direction.


**1.4.20.18.4** **(06-05-2025)**

#### Accounts Management Services (AMS)

1. Account Management Services (AMS) is the successor application to Integrated Case Processing (ICP) and Desktop Integration (DI). It pulls information from many different IDRS and CFOL command codes and presents it in an easy to understand case summary. AMS serves as an inventory control system for taxpayer correspondence, electronic 911 and 4442 referrals, and various transcripts. Tools such as forms, letters, Payoff Calculator, and Financial Statement pre-populate taxpayer data and assist with case analysis and calculations. AMS also connects to other applications such as Automated Collection Systems (via ACSWeb), Automated Underreporter (AUR), Automated Trust Fund Recovery (ATFR), Correspondence Imaging System (CIS), Enterprise Logistics Information Technology (ELITE), Employee User Portal (EUP), Reasonable Cause Assistant (RCA), and Remittance Transaction Research (RTR).

2. AMS emphasizes the sharing of key business data, increasing the availability of new tools, and integrating the access of these capabilities into a common interface. This allows any taxpayer contact, whether face-to-face, by phone, or by correspondence is documented and accessible by any IRS employee responding to taxpayer inquiries and working taxpayer compliance issues. Unique to AMS is the ability for any user to leave detailed case history narratives. This allows information to be shared across multiple functions working the taxpayer’s account. The enhanced efficiency of the “One Stop” concept of customer service reduces the length of time in which taxpayer inquiries are handled and reduces the time frame in which enforcement activities are conducted. Frontline employees have access to more complete information, enabling them to better respond to taxpayer inquiries, address all issues, and provide resolution. This reduces the need for subsequent taxpayer contact or correspondence on the same issue. In addition, the ability to enhance customer service ties directly to the satisfaction or dissatisfaction of taxpayers with the IRS, which in turn influences taxpayer compliance.

3. Training for all features in AMS is available through Integrated Talent Management (ITM). On the AMS Home Page, users can select the **Help** button in the upper right corner to find self-help user guides and job aids detailing how to use the different features. Users may access additional information about AMS updates, current issues, tips and hints, as well as job aids and facilitator guides on the AMS website. AMS also posts information to SERP in the Local/Sites/Other tab.

4. The MITS AMS help desk provides routine and emergency alerts through e-mail. Updates, new features, expected and unexpected outage information is sent out to all users with an active BEARS for AMS. Others may subscribe to these alerts by sending an e-mail to ams-announce-join@adc.irs.gov and typing "subscribe ams-announce" on the first line in the body of the e-mail.


**1.4.20.18.4.1** **(06-05-2025)**

##### AMS Access

01. Access to AMS is not universal and is determined by each Headquarters. Please contact your Headquarters analyst if you are not sure whether your function has access. If your function does not have access, your Headquarters will need to submit a Unified Work Request (UWR).

02. Functions with access to AMS are set up with profiles established by their Headquarters. This means each function will have different access to various forms, letters, and tools. Users may have access to only one functional profile at a time.

03. AMS does not require a unique user identification or password. AMS uses IDRS to validate a user’s identity. This means every user who wants access to AMS must first be an IDRS user. Department or operations managers who may not otherwise use IDRS still need IDRS to get AMS access. They should obtain IDRS access through BEARS and request the addition of command codes SUMRY and TXMOD be included in their profiles to meet the minimum requirement.

04. After IDRS access is obtained, the manager or employee needs to complete an BEARS request for AMS access. In BEARS, browse for AMS to see a list of the different AMS profiles available. They are based on BOD, campus, location, and function.

05. Certain features will not be available without the correct command codes. For example, the screen for Update Taxpayer Entity will not contain the ability to change addresses or phone numbers without the command codes ENREQ, INCHG/BNCHG, TELEA, TELEC, or TELED. managers or IDRS security representatives must add these command codes in IDRS before these features can be used in AMS. If these command codes are added while the user is signed on, they will need to sign off then sign back on to AMS and IDRS before the command codes will be recognized by these systems.

06. Managers or users should use the delete feature in BEARS when they no longer require AMS access.

07. If a user moves to a different function, even if they will need AMS in their new area, they or their manager will need to first delete their current AMS profile through BEARS. Deletion of the current profile is necessary BEFORE submitting a second BEARS to add the new profile.

08. Simultaneous with the BEARS process, every AMS user needs to register with the Employee User Portal (EUP). This is needed for AMS to check the Negative TIN table which contains TINs for family, friends, or others where account access would create an Unauthorized Access (UNAX) situation. To register locate the Employee User Portal (EUP) on the IRS home page under Research Tools then follow the steps in the table below:




    | **STEPS** | **ACTIONS** |
    | --- | --- |
    | 1 | Click on EUP (Employee User Portal). |
    | 2 | Click on the Register for EUP access link. |
    | 3 | Follow the instructions for User Registration |
    | 4 | Once you choose a password click on submit. |
    | 5 | You will be given the message **Registration Successful**. |
    | 6 | Read the instruction on the Acknowledgement Screen. |
    | 7 | Click on logout in the top right corner. |
    | 8 | Wait for an e-mail with your registration token. |
    | 9 | Once you have received the token, log back into the EUP system. |
    | 10 | Using your SEID and the password you created, click on submit. You will then be asked to enter the token you received. |

09. The registration process is the only thing needed by AMS. If other features within EUP are needed, separate BEARS requests will need to be completed for the other features. They are separate from AMS

10. The BEARS process will set up the basic profile for each user. Managers should review each of their employees’ profiles to add any other features, inventories, skills or thresholds needed.


**1.4.20.18.4.2** **(06-05-2025)**

##### AMS Management Tools

1. AMS offers a number of tools to assist managers in making various functionality or systems available to their employees. In the left-hand navigation panel, managers should select My Profile to review their own information. If any changes are needed, managers should request changes from their site’s System Security Officer (SSO). The SSO is usually the same person who has security responsibilities for IDRS or ACS but may be anyone designated by their operations.

2. Managers can review their employees’ profiles by selecting “Profile Management”, then “User Profile” in the left navigation panel on AMS. A list of employees assigned to them will be displayed. Select the name of the employee, then “View/Modify”. The profile screen will display information such as name, pseudonym, group, user role, title, telephone number, fax number, e-mail address, and IDRS campus. Managers and SSOs may modify this information. It also shows what profile was chosen from the BEARS process.

3. At the top of the profile page, there are several other tabs you may select to perform various updates. For example, select “Application Tools” to see a list of the various features available for you to choose to give your employee. If your employee is eligible for an available application, click on it and select “Add”. All applications your employee has access to are shown in the “Selected “ box as well as anything you may add. If you want to remove a “Selected” application, click on it and select “Remove”. You must select “Save All & Exit” to make these changes permanent. RCA and RTR are not considered a basic part of the user profile. If you choose either of these applications for your employee, remember to have them complete Reasonable Cause Penalty Abatement training on ITM before granting access to RCA and complete an BEARS for RTR before access is given.

4. Another tab on your employee’s profile page is “Inventories”. In Compliance, ACS Support and CSCO show taxpayer correspondence and some transcripts in AMS inventory. Choose the inventory type from the drop down menu. Under “Available Skills”, it shows the OFP types you can assign to your employee. Instructions on how to add or remove inventory/OFP can be found on the AMS web page under FAQ, at AMS End User Support site . The threshold and the gatekeeper skill can also be selected. Skills and thresholds must be set for each employee in order to receive work. You must select “Save All & Exit” to make these changes permanent.

5. Use the Web Links tab on your employee’s profile page to set up links to specific websites or online IRM references. Assign the link a name and copy the URL from the website or page. Up to five links can be set up. Your employee can also set these links themselves. You must select “Save All & Exit” to make the changes permanent.

6. Another important feature to set up is the second link under “Profile Management”. The “Group Profile” link opens the “Group Address” page. Input the address you want to appear on all of the group’s forms including the 10321, fax cover page, or any other form that requires this information. Select “Add/Modify” to make the change permanent.


**1.4.20.18.4.3** **(07-01-2021)**

##### AMS Reports

1. AMS provides managers with a variety of reports that have been pre-defined by Headquarters. In AMS, select the Reports link under the Tools section in the left- hand navigation panel. Different functions have different reports. Different levels of management such as frontline, operations, and headquarters will have access to different group, site, or BOD level reports.

2. All users have access to the TIN Summary report to view accounts they have accessed themselves. Frontline managers have access to all TIN Summary reports for each of their employees. Reports can be viewed for specific date ranges from today’s date going back thirty days.

3. ACS call site managers will continue to obtain their reports through ACS or ACSWeb Manager.

4. CSCO and ACS Support have access to various inventory reports such as daily or weekly starting and ending inventories for all OFPs or specific OFPs; by individual, group or operation. There are also reports to show skills assigned to each employee as well as their current thresholds.

5. ACS Support managers will ensure all written and electronic correspondence is sorted and the related ACS case moved to the appropriate ACS function within 2 business days of receipt in the ACSS operation.

6. CSCO managers will ensure all written and electronic correspondence is sorted and batched in AMS within 5 business days of receipt in the operation.

7. Written and electronic correspondence received in CSCO and ACS Support Operations must be batched in AMS and controlled within the latter of 14 days from the IRS received date or 5 business days from the operation received date. When a final response cannot be initiated within 30 days, an interim response will be initiated by the 30th calendar day from the IRS received date. If correspondence is received from a previous area after the 30 days expires and no interim letter was issued, you must send an interim letter within five business days of receipt in your area. Follow all other IDRS control procedures in IRM 21.5.1.4.2.2, Integrated Data Retrieval System (IDRS) - Control Procedures



### Note:



Sites using AMS for controlling and monitoring inventory follow AMS guidelines for case control and acknowledgment of taxpayer correspondence.





    .


8. Managers should routinely access reports to determine the timeliness and volume of work being completed. This assists in scheduling employees to remain current with priority work and conducting reviews.

9. In the Collection Paper Product line, the closing site’s applicable time frames are measured from the date received in the site’s Compliance Services Collection Operation.


**1.4.20.18.5** **(06-05-2025)**

#### Scheduling

1. The key to managing a successful team is utilizing proper scheduling techniques in order to ensure that objectives are met. This entails scheduling available resources against these objectives and executing the schedule to the extent of the resource capabilities.

2. Managers should be cognizant of rotating their employees in a manner which ensures that all critical element standards are observed.

3. Managers must review staffing levels and work plans to ensure sufficient staffing within the team is available at all times to process the workload.

4. Incoming calls are the highest priority and proper scheduling must be accomplished in order to maximize customer service and satisfaction. If an out call is necessary for case resolution, calls should only be made between the hours of 8:00 a.m. - 9:00 p.m. local time. If contacting a Power of Attorney (POA), contact should be made during routine business hours (8:00 a.m. - 6:00 p.m. local time.) Local time is determined by the time the call is received by the taxpayer, not when the call is placed by ACS.

5. To schedule off-terminal inventories, use anticipated receipts plus on-hand documents/lists identified from local controls and experience.


**1.4.20.19** **(07-10-2020)**

### Paper Documents and Mail Processing

1. Clerical staff sorts third party responses and tax return information. The kind of managerial controls used will be determined by the volume of work and the number of employees involved.

2. If volume is low, visual control should be adequate. Have the work sorted by type and receipt date and kept in bins, trays, or shelves where it is visible. Check periodically during the workday to ensure first-in, first-out processing and to ensure that backlogs do not develop.

3. If volume is high, have work batched (by type and receipt date) and maintain a control log showing the assignment of batches to individual employees. This will help to ensure first-in, first-out processing and to identify work needing follow-up.

4. Taxpayer correspondence will be processed within teams.



   - Team R1 processes taxpayer correspondence on ACS call site cases.

   - Teams R5 processes ACS Installment Agreement requests.

   - Team S4 processes correspondence received in ACS Support


5. Ensure all correspondence is screened against ACS to identify documents (for re-routing) belonging to other employees and to associate with other suspense file documents. Managers must ensure that correspondence meeting TAO criteria is expeditiously routed to S7 (or to the Taxpayer Advocate Office). During all screening, an indicator should be put in Comments to alert other call site/support employees that correspondence is being processed. Batches of 25 documents or less should be established and given a locally determined batch control number.

6. Mail received through electronic submissions must be moved daily to a local electronic storage location in ACSS received date order to ensure timely processing of the request. The electronic team mailboxes are required to be processed within 5 days of receipt and the walk-in mailbox must be processed within one hour. Team Leads will send count of the electronic receipts to the clerical unit to add to the weekly inventory report.

7. Maintain a control log showing the date and employee to whom each batch is assigned, the number of documents, and the completion date. Use this control to ensure batches are processed in the order received and to follow up on late completions.

8. Whenever possible maintain batch integrity throughout processing. This means the batch remains intact and individual documents are not removed until the batch is completed. This promotes timely processing, keeps employees from retaining cases, and allows the manager access to the entire batch when doing a review.


**1.4.20.19.1** **(01-20-2012)**

#### Mail Processing

1. Clerks distribute incoming and outgoing mail. Employees assigned this duty should be thoroughly familiar with:



   - routing procedures,

   - the difference between correspondence, Collection Due Processing (CDP) requests, correspondence for cases assigned to other employees and mis-directed mail,

   - form ordering procedures, and

   - routing and shipping procedures including frequency, method and addresses


2. Date stamp all incoming mail; this helps managers in other teams assess the timeliness of their work. Keep a log showing the volume of mail received by type each day (for example, third party responses, tax returns, taxpayer correspondence and other program criteria). This will assist management in long term planning.

3. Make periodic visual inspections. By reviewing the contents of the mail sorting bins, the manager can increase the timeliness and accuracy of the work.


**1.4.20.20** **(06-05-2025)**

### Employee Work Reviews

1. To assist employee performance, verify the rights of the taxpayer are protected, identify training needs, and assess the quality of the work product, a systemic process of reviewing the work of employees is required. All reviews with the exception of some clerical reviews, bin, security, IDRS and AMS reviews, must be completed on a Data Collection Instrument (DCI) via the Embedded Quality Review System (EQRS). Since the work in the team can be varied, review methods may include the following:




| **Types of Reviews** |
| --- |
| Telephone Monitoring |
| --- |
| Temporary Employee Action Code History (TEACH Reviews) |
| Paper Processing Reviews |
| Clerical Reviews |
| Bin Reviews |
| Security Reviews |
| Integrated Data Retrieval System (IDRS) adjustment reviews. See IRM 1.4.14.5.7, Review of IDRS Adjustment |
| AMS reviews |
| Workload reviews and on-line reviews |
| Non-evaluation reviews |
| Evaluative reviews |

2. Review results are linked, by attribute scoring, directly to the employee's Critical Job Elements (CJEs). It is the manager's responsibility to schedule employee reviews in a manner which will permit the employees to obtain documentation for as many aspects of their CJEs as possible.

3. Employees, other than Collection Representatives (CR) and Tax Examining Assistants (TEA) who do not make regular outgoing calls and are not scheduled to take incoming calls, but instead process correspondence, will receive a minimum of one review per month (e.g., paper document, TEACH review).

4. A review schedule should be maintained which lists all employees in the team and the completion date of evaluative reviews. When the required number of reviews are not timely completed, notate the reason on the schedule. Since these schedules will be reviewed by department and operations managers during their operational reviews, retain the schedules until completion of the operational reviews.

5. Evaluative reviews/telephone monitors are completed as formal documentation of employees' performance that feed into their annual performance evaluation. The manager must sign the reviews and share the feedback with the employees in a timely fashion. In accordance with the current National Agreement guidelines, Leads may provide supplemental evaluative reviews; however, the manager must sign and share the reviews with the employees.

6. All ACS Collection Representatives must receive a minimum of two telephone monitoring evaluative reviews per month, plus one TEACH Review per quarter. A TEACH review will consist of at least 5 cases or 10 paper documents for each review. Managers have the option to schedule a TEACH or paper document review depending on employee assignments. There should be a balance of these reviews throughout the year. Non-evaluative reviews/telephone monitors should be conducted to address training or performance issues. These reviews may be conducted by managers, lead CRs or On-the-Job Instructors (OJIs). This type of review can include working side by side with the employee, dual jack telephone monitoring, a review of calls recorded by Contact Recording and case reviews for the purpose of skill and job performance enhancement when deemed necessary.

7. The shared signed evaluative review (DCI) must be filed in the employee's EPF, and a copy provided to the employee.


**1.4.20.20.1** **(06-05-2025)**

#### ACS Activity Reviews (TEACH File)

1. In addition to the required call site monthly telephone monitoring review, managers/lead CRs are required to document reviews of at least five cases processed by each employee every quarter for evaluation purposes. ACS Support managers/lead TEA's should conduct five (5) Teach and/or Paper Document reviews.

2. If it is determined that additional documentation is needed on an employee's performance, increase the number of evaluative reviews as necessary. In this situation the employee should be notified of the change in advance.


**1.4.20.20.1.1** **(01-20-2012)**

##### Evaluative TEACH Review

1. Use the ACS system to request a display of all cases processed by an employee up to a given point in the processing day, or request a hard copy print for review the next day, of all cases processed the preceding day.

2. There are several methods you can use to select cases for review as described below:



   - Random Sample

   - Every XX case

   - Sample based on patterns; for this type of sample, analyze the number of cases processed and look for patterns. Examples of patterns to look for are:



     ### Example:



     frequent incidence of History Code OAXX, which may indicate incomplete processing





     ### Example:



     history codes which are inappropriate to the function (e.g. TFOJ, or LT28) or the History Code and definer seem incompatible (e.g. TOC1, LV01)





     ### Example:



     frequent appearance of TFRO or TFQU actions


3. A TEACH list review should consist of no less than five cases. A separate DCI must be prepared for each case. Select ACS Case Processing as the product line when inputting ACS TEACH reviews into EQRS.

4. All managers must ensure the proper paperwork is completed through the Embedded Quality process.


**1.4.20.20.2** **(06-05-2025)**

#### Telephone Monitoring

1. Monitoring employee telephone calls and providing feedback will be one of the most important aspects of an ACS manager's job. Managers will be spending a significant amount of time on this activity. When monitoring telephone calls, managers and quality reviewers can determine whether the employee:



1. Addressed disclosure issues.

2. Treated the customer with courtesy, fairness and respect.

3. Researched reference material accurately.

4. Used required Integrated Automation Technologies (IAT) tools.

5. Resolved the case per IRM guidelines.

6. Provided an accurate answer.

7. Applied appropriate communication skills.



      ### Note:



      Communication skills and use of hold guidelines are outlined in IRM 5.19.5.4.12, Telephone Techniques and Communication Skills.

8. Conducted a concise successful interview.


2. Rude remarks or disrespectful behavior cannot be tolerated when communicating with the taxpayer or in the workplace.

3. Each telephone monitor should review a complete call. Do not interrupt a live monitored conversation unless an error is being made that would adversely impact the accuracy or timely processing of the taxpayer's account. When this occurs, activate the barge-in feature to alert the employee to put the call on hold while the issue is discussed privately.

4. Telephone monitors should include efficiency techniques to aid the CR with their case processing. Some ways to improve call efficiency include:



1. _Stay with the call:_ Minimizing the number of holds and/or the length of hold; if the caller prefers not to hold the CR can explain their may be moments of silence while updating the account.

2. _Identify the Issue:_ Identifying the reason for the call can help the CR resolve the issue in a more efficient way.

3. _Controlling the Conversation:_ The CR can lead the call with probing questions to help move the account along and reach a resolution.

4. _Multi task during the call:_ Documenting the case actions during the call lends to more accurate notations of the actions taken and directions provided to the taxpayer.

5. _ACS AMS Checklists:_ Recommending the use of checklists or Word document to capture the notes during the call can help the CR navigate through other computer systems and continue to add to their case narratives


5. Monitoring results should reflect the performance observed. Do not assume that promised processing actions will take place after the contact. A manager should ensure that all actions evaluated actually took place.

6. Select **ACS Phones** as the Specialized Product Review (SPRG)when inputting monitoring information to EQRS.

7. If it is determined that additional reviews are needed, based on an employee's performance or training needs, the manager may increase the number of reviews as necessary. The employee should be notified during counseling of the additional monitoring in advance.


**1.4.20.20.2.1** **(06-05-2025)**

##### Evaluative Telephone Monitoring

1. For documentation and evaluative purposes managers are required to monitor each employee for a minimum of two (2) complete calls each month. This monitoring is in addition to the ACS TEACH review requirement.

2. There are specific standards to which ACS employees must adhere. The first is to be knowledgeable about the cases on which they are calling or receiving calls. They must scan the ACS screens to familiarize themselves with the account, determine the objectives of the call, and prepare to listen and control the course of the conversation. While protecting the rights of the taxpayer, they must not be intimidated but be firm, calm, polite, and persistent. Surnames must be used when identifying themselves and when addressing the taxpayer. To prevent misunderstandings, IRS jargon must be avoided when communicating with the public. Finally, the conversations must be clear, concise, and controlled.

3. Each monitored call must be documented and furnished to an employee within fifteen (15) workdays of the time the manager becomes aware, or should have been aware, of the event which it addresses. Follow current National Agreement, Article 12, Subsections 9A and 9B and 9C. Note that, whenever possible, taxpayer identifying information should be removed from EPF material. However, when assessing an employee's performance, it may be necessary to discuss taxpayers' cases or situations with some specificity. In these instances, EPF documentation that includes account information may be appropriate. See IRM 10.5.6.8.7.1 , Disclosure of Tax Records Permitted by IRC §6103(l)(4)(A), for further guidance in this area.

4. Upon completion of the review, follow current National Agreement when sharing the review results with the employee. Praise good work, explain problems identified, give guidance, and determine training needs. Obtain the employee's signed acknowledgment. A copy must be given to the employee and one copy will be retained in the employee's EPF.

5. Do not interrupt monitored conversations unless an error is being made by an employee that would adversely impact the accuracy or timely processing of the taxpayers account. When this occurs, activate the barge-in feature and alert the employee to put the call on hold while the issue is discussed privately.



### Note:



Silent monitoring operation is not supported for mobile agents.


**1.4.20.20.2.2** **(01-20-2012)**

##### Non Evaluative Telephone Monitoring

1. Managers can accomplish non-evaluative monitoring by reviewing the employee’s recorded calls on Contact Recording, and then inviting the employee to listen to their own call with you. You can stop the recording periodically to discuss better ways to handle a call. You can also conduct non-evaluative reviews by utilizing periodic side by side reviews when deemed appropriate or requested by an employee through the use of an optional telephone jack (double plugging) on the employee's teleset. Apply these techniques when circumstances merit an in-depth discussion for training purposes.

2. Managers may delegate listening to recorded calls or side by side non-evaluative reviews to a lead CR or an OJI. Periodically, delegate side by side non-evaluative reviews to experienced CR's to foster the team approach to improve the group's performance. This peer-to-peer monitoring approach will ultimately improve the IRS's work process.

3. Double plugging as an introduction to the job by new CRs with experienced employees is a good training tool.


**1.4.20.20.2.3** **(06-05-2025)**

##### ACS Contact Recording

1. "Contact Recording" is a telephone application/tool/system that records incoming "toll free" telephone contacts for the purpose of subsequent monitoring for evaluative and non-evaluative reviews. Managers and Quality reviewers use the tool to perform required random reviews (performance and product) of incoming telephone contacts. For more information on contact recording, refer to IRM 21.2.1.27, Contact Recording.


**1.4.20.20.3** **(07-10-2020)**

#### ACS (TEACH) /ACS Support Paper Document Review

1. If an employee is assigned paper document processing, ACS Activity (TEACH) reviews alone may be insufficient. This type of work is frequently found in ACS Support, and may include processing third party mail, taxpayer correspondence, and various listings. However, there may be occasions that warrant a paper document review in the call site.

2. For evaluation purposes the manager has the option to conduct either a TEACH and/or paper document review depending on employee assignments for that month. Five cases per employee should be reviewed monthly. Each program to which an employee is assigned should be reviewed to cover all aspects of the employee's performance.

3. ACS Support managers should select **ACS Support** as their product line when inputting into EQRS; call site managers should use **ACS Case Processing** when completing TEACH reviews.

4. Paper document reviews will enable the manager to determine whether the employee is following procedural guidelines, transcribing pertinent data, accurately performing locator research, and to assess the quality of the employee's work without limitation to cases routed for approval. They will also enable the manager to determine whether the employee is analyzing ACS data correctly; making correct decisions and recommendations; initiating effective follow-up actions; and unnecessarily encouraging taxpayer call-backs or correspondence.


**1.4.20.20.4** **(06-05-2025)**

#### CSCO Paper Document Review

1. For evaluative purposes, the manager is required to conduct paper reviews based on the employee's assignments. Each program to which an employee is assigned should be reviewed to cover all aspects of the employee's performance.

2. CSCO should use "CSCO Paper" , **CSCO Paper IAAL Transcripts**, or **CSCO Paper Misc”** SPRGs when inputting review data into EQRS. Please see IRM 21.10.1.5.3.2.15, Collection Paper Product, line for additional information about each SPRG.

3. Paper document reviews will enable the manager to determine whether the employee is following procedural guidelines and correctly transcribing pertinent data to assess the quality of the employee's work without limitation to cases routed for approval. Paper document reviews will also enable the manager to determine whether the employee is analyzing data correctly; making correct decisions and recommendations; initiating effective follow-up actions; and minimizing unnecessary taxpayer call-backs.


**1.4.20.20.5** **(11-06-2020)**

#### CSCO Evaluative Paper Document Review

1. For documentation and evaluation purposes, managers will complete a minimum of two (2) work reviews per employee per month.

2. Obtain the employee's batch intact at the end of the day from the closed case bin. Employees should not be notified in advance when their batch is to be selected; this is an unannounced review.

3. At some time during the work week, obtain from the employee all documents processed (these are normally destroyed) from which to draw a review sample. It will not be necessary to arrange to obtain the list pages from the employee since these are routinely returned to the manager after processing.

4. The review sample should be selected from the actual documents in the batch.

5. Review the information contained in the taxpayer's correspondence against the entries to determine whether the employee has exercised good collection judgment, followed procedural guidelines and whether pertinent data was entered. When reviewing locator processing, the manager should use applicable resources (i.e. computers, directories) to spot check the quality of the actual research.

6. Each review should be documented. No specific case data, such as the taxpayer's name and/or TIN may be recorded on this form nor may unsanitized case screen prints be retained. If further review is needed, refer to the employees Summary of Job Elements.

7. Upon completion of the review discuss the review results within 15 workdays (follow current National Agreement) with the employee. Praise good work, explain problems identified, give guidance, and determine training needs. Obtain the employee's signed acknowledgment and retain the review in the employee's EPF.


**1.4.20.20.6** **(01-20-2012)**

#### Compliance Non-Evaluative Reviews (OJI)

1. Employees are subject to non-evaluative reviews during the on-the-job instruction phase of training. In addition to the evaluative monitoring and case reviews, managers must spend some time each week (except for the weeks in which evaluative reviews are done) monitoring or reviewing cases. In ACS a side-by-side, dual-jack approach should be utilized. This provides an opportunity for immediate feedback in a non-evaluative atmosphere that will foster employee receptivity.

2. Each contact or case can be discussed immediately upon its conclusion (or even during the contact) so that the employee can be provided with the benefit of the manager, lead CR or OJI's own experience and perspective on effective telephone techniques and case handling.

3. Results of monitoring conducted in this manner must be documented as non-evaluative**and cannot**be used as part of the employee's performance appraisal.


**1.4.20.20.7** **(11-06-2020)**

#### Compliance Clerical Reviews

1. Clerical functions may include list distribution, processing of various listings, mail receipt and distribution, typing, log controls, maintenance of files, locator research, and other various administrative tasks. The manager responsible for the clerical employee will conduct a minimum of two reviews per month on required actions taken by the employee to determine the accuracy of this work based on established campus direction.

2. Review the mail sorting when the mail has been placed in bins for delivery to other areas. The frequency of theses reviews will depend on the experience of the assigned employee, the results of prior reviews, and the feedback from other functions/teams.

3. Focus not only on the employee's ability to complete his/her assignments, but also on his/her ability to set priorities and complete assignments independently and expeditiously. Conduct monthly reviews to determine the accuracy and timeliness of employees' work.

4. Upon completion of the review discuss the review results within 15 workdays (follow current National Agreement) with the employee. Praise good work, explain problems identified, give guidance, and determine training needs. Document review results in narrative format specifically addressing aspects of the employee's job elements.


**1.4.20.20.8** **(01-20-2012)**

#### Compliance Non-Evaluative Reviews

1. The primary purpose of a non-evaluate review is to help the employee develop and enhance their job skills. Effective non-evaluate reviews foster open lines of communication among the employee, the manager, and the lead technical employee. This enables the manager and/or the lead to receive employee feedback and transfer operational goals informally.

2. Non-evaluative reviews do not contain a written rating. Share the results orally. Some documentation is appropriate to establish that it actually occurred. (EQRS may be used to track employee development for this purpose by choosing "non-evaluative" on the drop-down menu option.) Have the employee initial and date any documentation. Provide one copy for the employee and retain the other copy in the employee's drop file.


**1.4.20.20.9** **(07-10-2020)**

#### IDRS Adjustment Review

1. IDRS adjustment reviews help prevent unpostables and ensure prompt correction of errors. Review a sample of IDRS adjustments with source documents, focusing on the following areas



   - Appropriate source documents

   - Accurate and complete input data

   - Proper hold codes

   - Correct priority codes

   - Accurate source codes

   - Appropriate blocking series

   - Appropriate reason codes

   - Complete remarks section


2. Unpostables are identified on the CCA4243 report as category "NLUN" . It is highly recommended that unpostable cases be resolved within seven business days. (NOTE: The unpostable received date will be the date the control base was re-established on IDRS. The IRS received date will be much earlier than what is reflected on the IDRS tax module; therefore, it is in the best interest of the taxpayer that the case is processed according to when the IRS received it.)

3. IDRS adjustment reviews may be delegated to a work leader or peer, but employees may not conduct a review of their own cases. If this review is delegated, the employee conducting the review will brief the manager and the employee involved.

4. IDRS/IORS (IDRS Online Reporting System) security reviews may not be delegated and must be performed by a manager.


**1.4.20.21** **(06-05-2025)**

### Managerial Approval Process Overview

1. Collection managers are required to approve certain types of dispositions such as:



   - manual refunds

   - installment agreements

   - currently not collectible

   - adjustments


2. Collection managers should **not** approve dispositions they initiated as a result contact with the taxpayer.



### Example:



An ACS manager is working overtime but is answering phone calls as a Customer Service Representative (CSR). They should not approve their own case work.


**1.4.20.21.1** **(07-10-2020)**

#### ACS Managerial Approval Process

1. **ACS Employee's Responsibility:** With nationwide call routing (Enterprise), we process accounts residing in other ACS Call Sites’ inventories, so case prints or other action is required to inform the manager that an approval is needed. ACS employees taking the following actions must inform their manager of the need to review and approve the case when it is moved to the managerial inventory (C0, N0, R0, I0, or S0, Q0).

2. There is a systemic check that prevents non-managers from inputting these approvals on ACS. Other actions that either initiate or cease collection activities may require managerial approval as well.

3. Procedures may be established locally to require managerial approval of other actions, but there will be no systemic checks to ensure this.


**1.4.20.21.2** **(06-05-2025)**

#### ACS Managerial Approval Actions

1. Any disposition requiring approval on _an account residing on a different Call Site's inventory._ See IRM 1.4.61.3.3, ACS Managerial Approval Contact Person’s Responsibility.

2. **Levy / Lien Action:**



   - Any manual levy IRM 5.19.4.3.11, Typing Manual Levies

   - Levies on Social Security income -IRM 5.19.4.3.12, Issuing Levies

   - Levies or liens issued while pending an appeal or "Equivalent Hearing" - IRM 5.19.8.4.6, Collection Action During the CDP Appeal Period

   - Lien filing meeting criteria in IRM 5.19.4.5.2, Do Not File Decisions

   - Decision not to file a lien meeting criteria in- IRM 5.19.4.5.3.4, When Filing an NFTL Requires Approval


3. **Installment Agreement Dispositions**



   - meeting approval criteria, see IRM 5.19.1.6.4.8 , IA Managerial Approval

   - PPIA and reinstatements of PPIA meeting approval requirements, see - IRM 5.19.1.6.5.3, Managerial Approval of PPIA


4. **Currently Not Collectible Dispositions**



   - Certain hardship cases warranting currently not collectible closings - IRM 5.19.17.2.1.2, Hardship Closure Authority Levels.

   - Decedent,defunct/insolvent corporations, UTL and UTC , –IRM 5.19.17.2.1.1, Non Hardship Closure Authority Levels.


5. **Return Delinquency Dispositions**



   - Little or no Tax due except 6+ year old mods (if the command code IRPTRJ is not used on IMF accounts) and all BMF accounts – IRM 5.19.2.6.4.6.3.2 and 5.19.5.8.3.5.

   - HINF Closures - IRM 5.19.2.8.1, High Income Nonfiler Processing (HINF).


6. **Request for Appeal** – IRM 5.19.8.4.16, Collection Appeals Program (CAP) Procedures.

7. **Referrals to Examination or Criminal Investigation** \- IRM 5.19.5.7.3.1, R3 Roles and Responsibilities - Collection Representative or Tax Examiners.


**1.4.20.21.3** **(07-10-2020)**

#### ACS Managers' Responsibility

1. **ACS Call Site and ACS Support Operations Managers:** Provide general oversight to ensure approvals are done promptly.

2. _ACS Call Site and ACS Support Department Managers:_ Provide oversight of the teams within the department to ensure approvals are done promptly.

3. **ACS Call Site and ACS Support Team Managers:** Manager approvals (zero functions) should be worked daily.



1. Address your own employee's cases requiring approval and ensure your employees are making case prints when approvals are required, or a query/listing process is used.

2. Address cases remaining in the zero functions by working through the managerial approval inventory assigned to your team using next case access.

3. If the work is correct, approve the case or if it can be resolved with a simple input, that action should be taken without referring the account.

4. Managers must consider what is known about the taxpayer's financial condition, including economic hardship, when approving a levy on benefit income, retirement income and social security incomes. If there is sufficient information to determine the levy would cause an economic hardship, the levy should not be issued. While information in the IRS’s records may be sufficient to corroborate the presence of economic hardship, in some cases the taxpayer may need to provide additional information in order to make that determination

5. If work done by another Call or Support Site's employee is not correct and/or cannot be resolved by you, provide your Call or Support Site's ACS managerial approval process contact person with the TIN, the employee ID, and the date moved to the managerial function (or Screen 1 print to pdf/or screen shot). The information will be forwarded daily to the Call or Support Site of the employee taking the case action for appropriate follow-up. Please DO NOT forward cases that you can correct easily.


**1.4.20.21.4** **(05-18-2021)**

#### ACS Managerial Approval Contact Person's Responsibility

1. Inform the other ACS Sites of cases in your site's managerial approval inventories that require additional attention prior to closure via fax promptly. Your site's team leaders will provide this information. Promptly resolve or direct cases identified by other Sites as needing additional work to the appropriate team manager for follow-up. To ensure that information is properly transmitted, verify that the fax was sent successfully. The contact person will enter AMS comments on cases (both the person sending the account and the person responding in the originating site) to clearly record actions taken.

2. If the referred account has not been resolved after two attempts, contact the managerial approval fax contact person in the receiving site by phone or secure e-mail (if the site accepts this type of transmission) to resolve the outstanding issue promptly. Local practice will be followed to elevate the issue if the account remains unresolved after that contact.


**1.4.20.21.5** **(07-10-2020)**

#### CSCO Managerial Approval Actions

1. The manager will review each case for compliance with the requirements of applicable IRM's for correct judgment in support of the employee's action. If the requested action is acceptable, take the action.

2. If the requested action on the case is not acceptable because additional actions are required prior to managerial approval, or if the request is technically incorrect, the manager should return the case to the responsible employee for correction.

3. If any requested action is not acceptable, return the request with an explanation to the originating employee. The manager should ensure that the responsible employee takes an appropriate action to resolve the taxpayer inquiry.

4. The manager must approve all Installment Agreements as required per IRM 5.19.1.6.4.8 , IA Managerial Approval. There are no exceptions to this rule.


**1.4.20.22** **(07-10-2020)**

### Training and Employee Development

1. Management is responsible for the training and development of employees and managers. The following text outlines some of your responsibilities relating to the training and development of your employees and subordinate managers.

2. CSCO employees training consists of structured formal classroom training in procedures and applicable computer applications. Training is also enhanced annually through Continuing Professional Education (CPE). New training may also include an on- the- job-training period.

3. Training for new Collection Representatives (CRs) is described in the ACS Core Skills, made up of many class number offerings contained on the ITM. Employee progress in the training is recorded in the ACS Development Guide. The development guide outlines the responsibilities of all participants in the technician's training program and is used for documenting the trainee's progress. ACS management is responsible for seeing that the training needs of their employees are identified and met.

4. Training for CSCO and ACS employees is achieved through "Continuing Professional Education (CPE)" and /or new hire training. This training is directed and controlled by the Training Coordinator. The Resource Training Coordinator (RTC) has the responsibility to ensure accreditation is given to course participants on the Integrated Talent Management (ITM). Managers should be aware of the training needs and accomplishments of each team employee. Managers have the final responsibility to identify and to ensure team employees are provided the training required to effectively perform their duties.


**1.4.20.22.1** **(07-10-2020)**

#### Core Training

1. ACS Collection Representative core training is currently being redesigned by the compliance collection balance due optimization team (CCBDO). The redesign format will consist of three phases, with between two and four weeks each of classroom training in each phase. Followed by On-the-Job (OJI) training. This training includes procedures, systems, equipment and hands-on training. The initial training consists of streamlined balance due and return delinquency instructions. The second phase consist of more complex balance due cases including collection information statements. The third phase is broken down into two components, ACS and BMF (for those sites that work BMF calls/inventory). All new employees are required to complete core training.

2. Previously core classroom training consisted of 27 Lessons and additional sub-lessons on the Enterprise Learning Management System (ELMS) currently know as ITM. The lessons were basically in an IMF or BMF format, with a further breakdown to return delinquency (RD) or balance due (BD). A lesson is a discussion of a specific subject, such as Lesson 2B, Automated Collection System Screen Displays. Each lesson provided a complete subject discussion and is a building block for subsequent lessons.

3. The core training was developed to give operations management more flexibility, based on the needs of the call site in determining the subject order and time frames. It allows more emphasis on the type of cases that are worked in the call site and the BOD. For instance, if the call site does not work cases involving Form 943 (MFT 11) accounts, the instructors would present the form briefly as an awareness, and emphasize the other BMF returns.

4. Additionally, the suggested schedule was designed to give the students the opportunity to easily reinforce what was just covered in the classroom, with the use of interspersed periods of on-the-job training (OJT). It was designed to have the option for students to complete an OJT session after each significant lesson.


**1.4.20.22.2** **(07-10-2020)**

#### ACS Interactive Training File (Procedures and Equipment)

1. The ACS Interactive Training File is designed to introduce employees to equipment operations and to permit them to make simulated case decisions. They will learn how to operate the ACS equipment through the use of simulated cases and role-plays. An updated version of the Training was released in FY 2011.

2. The ACS Core Training System consists of ‘free-form’ access mode only. The system allows the trainee to access the ACS Training cases and work them as live cases. Upon exiting the system, cases are not updated and are ready for use by next trainee. The system is designed to introduce employees to “ACS Green Screen” and ACSWeb screens. This allows them to make simulated case decisions. The training cases can be worked by and instructor/trainee in a classroom setting, or by the trainee at their desk.


**1.4.20.22.3** **(06-05-2025)**

#### On-the-Job Training

1. On-the-job training (OJT) is a very integral portion of the technician training. Effective OJT instructors (coaches) are vital to the success of the technicians training program. As operations and front-line managers, you must contribute to that success by carefully selecting the best OJT instructors and by periodically meeting with them to review progress and provide support.

2. All employees selected to participate as an OJT instructor should receive OJI training. A couple of suggested training documents are Course number 1779 On-the-Job Instructor Training and course 27016 Workshop for On-the-Job Instructors in ACS Call-Sites. It may also be useful to include training on the use of the Embedded Quality Review System.

3. It is suggested that coaches/instructors, at a minimum, review the core lessons and take the test themselves. Additionally, they will find it beneficial to complete the Interactive File lessons to anticipate any problems their students may encounter.

4. All students should be counseled at various points throughout their OJT period. At a minimum, formal counseling sessions should include an initial, midway and final progress discussion. Informal counseling can be used to keep the trainees informed of their progress. Frequent opportunities should be taken to give trainees feedback to minimize any issues concerning the technical information and the progress of the employee. It is vital that the coaches provide honest feedback, positive or negative, to the students.


**1.4.20.22.4** **(06-05-2025)**

#### Training for all Employees

1. Employees will receive annual training under the Continuing Professional Education (CPE) program, also referred to as "refresher" training. Subjects will be designed to keep employees abreast of technical and procedural developments that relate to their jobs. In the event that Headquarters CPE training materials are not available, topics identified as mandatory must be developed locally. In addition to the mandatory topics, local training needs should always be identified and included as part of the CPE. The timing for delivering CPE will be negotiated with the Joint Operations Center to minimize impact to telephone traffic schedules.

2. Topic(s) selection should be driven by the level of difficulty in new procedures and trend analysis as identified through telephone monitoring, NQRS/EQRS results or other feedback.

3. In-service and out-service training are additional options. Your local training coordinator can assist in identifying the proper course and obtaining approval for it, but it is your responsibility, as managers, to identify the training need and initiate the action.

4. Managers must be aware and proactive in ensuring that team employees timely complete Mandatory Briefings. A listing of briefing ID numbers and titles is offered below. These offerings are available on ITM.




| **Mandatory Briefings** |
| --- |
| 19358 Mandatory Ethics Briefing |
| --- |
| 16412 UNAX Awareness |
| No FEAR Act |
| Sexual Harassment Prevention for Federal Employees |
| 23131 7114 Certification of Ethics Meeting |
| 28970 Privacy, Information Protection and Disclosure Briefing |
| 28971 Information Systems Security |
| 31659 FMSS Physical Security and Emergency Training |
| 26043 RRA ‘98 Section 1204 (for 1204 employees only) |
| 62965 Records Management |
| 30337 USERRA (Uniformed Services Employment and Reemployment Rights Act) (Only for employees in designated components of HCO.) |
| 19356 Environmental Health & Safety Awareness |
| 39841 Plain Writing Act of 2010 |


**1.4.20.23** **(07-10-2020)**

### Developing Employees and Managers

1. In addition to identifying training needs, you are responsible for developing your employees that report directly to you. Developing employees will initially be directed towards improving skills in their present position and developing potential toward advancement.

2. Recognizing and developing potential is a responsibility of all levels of management. You must continually look for employees with potential for higher level and more responsible work.

3. You are responsible for ensuring employees reach their potential in their present position and prepare employees for achieving career advancement for which they display skills and abilities. This can be accomplished through the development of a Career Learning Plan (CLP). The CLP is designed to enhance your employee's skills so that he or she may increase his or her current job performance and/or become more competitive when applying for in IRS career enhancement positions. The CLP should specify the career goal or training needs, the developmental activities needed, and target completion dates. The CLP should be brief and realistic and assist the employee in identifying feasible and meaningful activities. Be careful not to recommend additional training that will serve little purpose in improving an employee's performance or advancement. Activities can include acting managerial or lead details, instructing, OJI coaching, developing and presenting technical workshops or details to other functions. Other developmental activities also include self-directed training toward skill enhancement for employees as outlined in the "current National Agreement" .

4. Periodically review the CLP's of your employees to ensure developmental activities are being completed and to identify areas in which the employee needs assistance. Completion, addition, deletion, and extension of developmental activities should be annotated during these reviews.

5. Every effort should be made to encourage all employees to develop a CLP, however, when an employee is unsure of his/her career goals or simply does not want an CLP, the employee should state so in writing and the manager should place this in the employee's EPF. This is done for two reasons:



1. To document that the manager made the effort to assist the employee in developing an CLP and the employee chose not to have an CLP; and

2. The document can be used as a follow-up item for the manager to encourage the employee at a later time.


6. Employees should be provided with training/guidance on the job qualification process, including how to complete a job application and conducting a mock interview.

7. Managers interested in further developing their professional education can research courses and their relationships to the IRS Leadership Competencies by researching in IRM 6.410.1, Learning and Education Policy, and or the Integrated Talent Management (ITM).


**1.4.20.23.1** **(06-05-2025)**

#### Managers Training

1. Entry level managers should receive Tax Motivated Transaction(TMT) (Course 9012) training either prior to their first managerial assignment or within a few quarters of their initial assignment. New managers should also receive Core Leadership Training, Course No. 9670. All managers should attend the course between the second and sixth month after their selection but no later than the end of their probationary period (within one year).

2. New managers should receive appropriate portions of technicians' core and module training. This material should be selected from Course No. 9670 series and be tailored locally depending upon the background and position of the newly selected manager.

3. The new ACS manager should receive the pertinent procedures and equipment hands-on training and the ACS telephone operations training.

4. Additional Self-Study Leadership training materials are available as useful tools in improving your managerial skills. These can be accessed through Skillsoft or Integrated Talent Management (ITM).

5. The following is a list of suggested Leadership classes. These courses will serve to enhance your ability as an IRS manager and team leader to communicate with peers and subordinates, and will assist you in making decision that are in the best interest of your employees, the customer and the organization:




| **Leadership classes** |
| --- |
| Administrative Procedures for Managers (APM), course number 15346 |
| --- |
| Front-Line Leader Readiness Program (FLRP) |
| Employee Relations/Labor Relations Skills for Managers (ER/LR), course number 15351 |
| Fundamental Management Skills (ITM) |
| New Manager Orientation Tutorial (ITM) |
| Improving Performance - A Guide for Managers (ITM), course number 25196 |
| Single Entry Time Reporting (SETR) (ITM), course number 15640 |
| Leading Teams (ITM) |
| 9670 Front-Line Managers Course (CORE Leadership) |
| Management Aspects of EEO (MAEEO), course number 13466 |
| 9016 Meeting Challenges |
| 6700 Facilitative Skills for Leaders |


**1.4.20.24** **(06-05-2025)**

### Training of Employees with Disabilities

1. Your Local Accessibility Coordinator (LAC) serves as your main point of contact to assist managers and employees with disabilities in the day to day accessibility issues. The Local Accessibility Coordinators report to the Chief Accessibility Coordinator. The Office of the Chief Accessibility Coordinator (CAC) was established to assist management with inquiries concerning accessibility, adaptive equipment/software compatibility and usability issues, reasonable accommodation concerns, and employees with disabilities performance issues to name a few.



### Note:



Please see Exhibit 1.4.20-3 for the links to various websites related to employees with disabilities.


**1.4.20.24.1** **(06-05-2025)**

#### Adaptive Equipment and Other Accommodations - IRAP Services

01. Employees with disabilities will be provided adaptive equipment and services on a case by case basis in accordance with the agency guidelines for reasonable accommodations.

02. All new requests for assistive technology and services should be initiated through your servicing IRS Disability Office Reasonable Accommodation Services office. Select the applicable link for products, devices and services guidance on 'Employee Resources-Assistive technology , links include: Information Resource Accessibility Program (IRAP), Ordering Assistive Technology, Assistive Technology Product Catalog, Assistive Technology Replacement and Assistive Technology Repairs. e.

03. Once approved for an assistive technology reasonable accommodation, the IRS Disability Office Reasonable Accommodation Services office will submit a request to IRAP.

04. IRAP will take the following actions:



    - make an initial contact with the customer within one business day

    - work with the employee and manager to perform a needs assessment

    - coordinate with the employee and local IT support personnel to ensure that non-IRAP hardware/software is compatible with the recommend IRAP solutions.

    - Work with the customer and local IT support to resolve any issues

    - order the equipment (once written concurrence form the employee and manager with the prosed solution is received)


05. Most adaptive technology equipment and services will be delivered to IRS within 15 days. After the equipment is delivered to IRS, local IT personnel will install and configure the equipment as needed.

06. The Primary IRAP services include:




    | **IRAP services** |
    | --- |
    | Communication of information on IRAP services and accessibility principles | - Blindness/Low Vision Products such as speech and braille output systems, braille translation software, portable note takers and screen magnification software.<br>      <br>    - Deafness/Hard of Hearing Products such as, teletypewriters (TTYs), telephone handset amplifiers and Visual signaling devices.<br>      <br>    - Mobility Impairment Products such as alternative keyboards, trackball mouse and voice recognition software.<br>      <br>    - Learning Disability Products such as scanner/reader systems. |
    | Assisting in the determination and acquisition of appropriate adaptive technology solutions, including installation, training, and maintenance of the equipment. | - Coordinate with the employee and local IT support personnel to ensure that non-IRAP hardware/software is compatible with the recommend IRAP solutions.<br>      <br>    - Order the equipment (once written concurrence form the employee and manager with the prosed solution is received)<br>      <br>    - Assisting IRS employees with adaptive equipment features and functions.<br>      <br>    - Work with the customer and local IT support to resolve any issues. |
    | Performing technical consultation and coordination for adaptive hardware and software. | - Providing guidance to local Modernization, Information Technology & Security (MITS) Services staff<br>      <br>    - Developing and providing online training to assist IRS employees in better understanding accessibility issues.<br>      <br>    - Providing technical guidance on the provisions of the Section 508 Accessibility Standards to IRS managers and employees.<br>      <br>    - Providing technical guidance on accessibility to owners of current or proposed information technology.<br>      <br>    - Evaluating new adaptive technologies for potential use within the IRS.<br>      <br>    - Coordination of any initial bulk purchases of a new type of equipment, after successful testing. |

07. The IRAP Office is only responsible for the maintenance repair costs (after the expiration of initial warranty coverage) on equipment they purchased. Any maintenance and repair costs for equipment not purchased by the IRAP Office is the responsibility of the purchasing organization.

08. Contact your local Modernization & Information Technology Services (MITS), Site Support Office to report equipment malfunctions. Known problems with adaptive equipment should be reported to the IRAP Office.

09. Readers must be provided as necessary for visually impaired employees needing access to the Internal Revenue Manual (IRM) and Training material or other publications not available in hard copy.

10. A centrally funded process for obtaining sign language interpreting service for hearing impaired employees was implemented Servicewide by memorandum in June 2000. Refer to IRM 1.4.20.24.3, Interpreting Services Process for details on Interpreter Services. Your EEO contact will be able to provide you with a copy of these procedures if needed.


**1.4.20.24.2** **(06-05-2025)**

#### Braille Materials

1. The Alternative Media Center (AMC) has been established to meet the needs of employees with disabilities for information in alternative media.

2. The primary services of AMC is to provide the following:




| **List of AMC services** |
| --- |
| Hard copy braille |
| Large print |
| Electronically Accessible tax products and training materials in HTML and text formats |
| Electronic Braille format |
| Speech-friendly PDF forms |
| Tactile graphics |
| Digital talking books |
| Help Desk services |
| Custom development and delivery strategies for unique products |
| Document accessibility consulting |
| XML Accessibility services |
| Training services and tutorials |
| Research and Development |

3. AMC Ordering Procedures must include the following information with all orders to the AMC Help Desk or through E-mail:



   - Name and phone number

   - Complete mailing address including room numbers/stop numbers

   - Type of Media (braille, electronic, large print,)

   - Product(s) requesting

   - Quantity required

   - Date materials are needed (certain material may take up to 4 weeks to receive)


4. To obtain AMC services managers/employees may obtain annual Tax Products and Training material by:



   - Call or fax your order to the area distribution centers

   - Download electronic media from the AMC website or Multimedia Catalog site at: amc enterprise and Order alternative media formats.

   - E-mail your request to the AMC at \*ALTMC.


5. Use the **Contact Us** feature on the IRS Alternative Media Center Web page at AMC contact us.


**1.4.20.24.3** **(01-20-2012)**

#### Interpreting Services Process

1. Various laws and regulations require each business division to provide interpreting services, as needed, as a form of reasonable accommodation.


**1.4.20.24.3.1** **(06-05-2025)**

##### Obtaining Interpreting Services

1. Once a determination has been made that a Sign Language Interpreter or Communications Real-Time Access (CART) Writer is the most effect accommodation, the process for procuring an interpreter varies depending on location.

2. Campuses-Site coordinators manage fulfillment of all Interpreting Services/CART requests whether by a staff or contract interpreter. Sign Language Interpreters and CART captioning services are request by submitting Form 14960. In campus locations, site coordinators fill requests for services using both staff and contract interpreters. Follow your respective Campus procedures for requesting interpreters.


**1.4.20.24.3.2** **(06-05-2025)**

##### Circumstances for Obtaining Interpreting Services

1. Interpreting services may be requested in at least the following circumstances:




| **Interpreting Service needs** |
| --- |
| Training |
| --- |
| Employee orientations |
| Formal/informal staff meetings |
| Formal/informal conferences and meetings |
| Job interviews |
| Video conferences |
| Special Emphasis programs |
| Interagency meetings |
| Orientations for new employees |
| Tax related meetings |
| Other business-related activities |


**1.4.20.25** **(07-10-2020)**

### Overview of Quality

1. The quality review process provides a method to monitor, measure and improve the quality of work within each operation. Quality review data is used to provide quality statistics for the IRS’s Business Results portion of the balanced measures, and to identify trends, problem areas, training needs and opportunities for improvement. The business results for reporting quality include Customer Accuracy, Timeliness, and Professionalism. Regulatory Accuracy and Procedural Accuracy are internally reported process measures.


**1.4.20.25.1** **(05-18-2021)**

#### Quality Measurement Process

1. Two systems are used in the quality review process. They utilize a common approach to quality and provide a clear link between quality measures and employee performance. They use the same standards and consequently bring accountability for quality throughout all levels of the organization. These systems are:



   - Embedded Quality Review System (EQRS)

   - National Quality Review System (NQRS)


2. Embedded Quality Review System (EQRS) - EQRS is an on-line database used by the managers/reviewers to review employee performance. All employees are evaluated on the same measures and are evaluated using a common evaluation tool and performance reports.

3. National Quality Review System (NQRS) is used by the Centralized Quality Review staff (CQRS), and Program Analysis System (PAS) Review staff .

4. For additional information on these two systems research IRM 21.10.1.8, Embedded Quality Review System (EQRS)/National Quality Review System (NQRS).

5. Review Data is compiled in EQRS and NQRS by completing a Data Collection Instrument (DCI).

6. A DCI is used in both the EQRS and NQRS systems to input review results. The reviewer has the option of using a "smart DCI" that targets suggested attributes for their particular product line or "Specialized Product Review Group (SPRG)." The Smart DCI will only display the most commonly used attributes applicable to the SPRG selected for review.

7. When reviewing a case, if additional rarely coded attributes that are not on the Smart DCI are needed, click on the “Total Attributes” button within each attribute screen. This will bring up the Total DCI for that SPRG.

8. CQRS and some PAS reviewers use the Verint telephone system when conducting telephone reviews. The sample plans identify the number of calls reviewed, per day, for the ACS call sites' and other Collection telephone programs. This provides a valid sampling on a quarterly basis with a precision margin of +/- 5%. For paper processing reviews, a random sample of closed cases are pulled daily providing a . This providing a valid sampling a. See IRM 21.10.1.3.3, Quality Review Campus Collection and Campus Examination Sampling Guidelines, for further information. Although there are no sampling plans for manager reviews, there are minimum review requirements.

9. EQRS users may also have access to the Contact Recording system to review monitored calls.


**1.4.20.25.2** **(07-10-2020)**

#### Role of the Centralized Quality Review (CQRS) and the Program Analysis System Reviewer (PAS)

1. The Centralized Quality Review System (CQRS) and the Program Analysis System Reviewer (PAS) are operated by Headquarters. The objective of the CQRS/PAS is to collect data that will provide independent quality review services for a number of different product lines and SPRGS. They provide the basis for measuring and improving program effectiveness by:



1. Identifying defects resulting from site, systemic and procedural issues, and

2. Determining root causes of defects and recommending corrective actions.


2. For more information, per IRM 21.10.1.2.6.2 Collection Quality and Technical Support (CQ&TS) and Examination Quality and Technical Support (EQ&TS).


**1.4.20.25.3** **(06-05-2025)**

#### EQRS/NQRS Standard Reports

1. The Embedded Quality Review System (EQRS) is an on-line database accessed through the IRS Intranet. Managers will use EQRS and the EQRS Data Collection Instrument (DCI) to input case analysis results. Managers will also use EQRS to generate employee feedback reports, standardized and ad hoc reports. For a list of Product Lines and Specialized Product Review Groups (SPRG) covered by EQRS. See IRM 21.10.1.2 The Quality Review Process.

2. Reports may be retrieved through both EQRS and NQRS

3. EQRS and NQRS provide standard reports on Customer Accuracy, Timeliness, and Professionalism on a period of time specified by the requestor. Weighted and un-weighted reports are available. Attributes accuracy reports are also available, as well as top defect reports.

4. EQRS provides standard employee level, organizational level and Ad Hoc reports. An Individual Review Feedback Report is shared and signed by the employee. An employee cumulative report is also available. Management has the ability to secure a cumulative organization report, and a standardized top ten defect or top ten successes report for their site/SPRG; or for any subgroup within their site/SPRG. See IRM 21.10.1.7.12.1, Standard EQRS Reports.

5. For more information on NQRS reports, see IRM 21.10.1.8.12.2 Standard NQRS Reports.

6. Ad hoc reports are an extremely helpful tool found in EQRS. They allow for drill down analysis of data. They can provide a list of records or a count of records that meet the query criteria. See IRM 21.10.1.8.13, EQRS/NQRS Ad Hoc Reports.


**1.4.20.25.4** **(06-05-2025)**

#### Role of the Local Campus Quality Analyst

1. The role of your site's Quality Analyst is to measure and monitor quality data and recommend solutions to improve the site's performance. This is done in the following manner:




| **Measure and monitor quality data** |
| --- |
| Analyze trend data from the EQRS and NQRS; |
| --- |
| Conduct local case reviews and telephone monitoring to supplement the NQRS and EQRS data |
| Calibrate and validate quality review results between EQRS and NQRS; |
| Perform focus reviews determined by prior quality results or to ensure new or revised procedures are properly implemented; |
| Provide managers with quality trend analysis on an ongoing basis |
| Alert management when errors have been identified that recent procedural changes are having an impact on quality results; |
| Identify the root cause of the defects. This can include problems with the IRM or systemic issues. as well as employee performance; |
| Attend operation meetings; |
| Attend operation and team meetings to discuss error trends identified and recommend solutions. Solicit feedback from employees to further assist in identifying root causes; |
| Recommend solutions to address root causes. Here are some examples. |





### Example:



Recommend changes to the IRM where procedures are missing or unclear. Surface systemic problems to the appropriate function.





### Example:



Recommend and coordinate training to site management and training coordinators.





### Example:



Suggest changes to the training material that will ensure consistency with IRM procedures.





### Example:



Coordinate the development of training material to supplement the existing material.





### Example:



Coordinate with other functions when their procedures are in conflict with your IRM procedures.


**1.4.20.26** **(07-10-2020)**

### Role of the Campus Collection Manager

1. You will work closely with your site's Quality staff to ensure your employees are providing customer service and processing cases in a quality manner as defined in your IRM. An analysis of on-line and case processing review results can be useful in determining areas that need to be addressed and or reinforced.

2. All managers will use the EQRS system to complete employee in-line reviews and case processing reviews. Results may be used to identify the need for increased monitoring or reviews to further evaluate performance. Quality results are linked, by attribute, directly to the employee's CJEs.

3. The standardized attributes mean every employee should receive consistent reviews from their managers. Managers should utilize team, department, and organizational level reports to ensure fair and consistent scoring of attributes among employees, and to ensure that review requirements are met.

4. Based upon review results, managers will ensure that appropriate training or coaching will be provided to employees.

5. As trends are identified and corrective action is taken, monitor your team’s performance to ensure that the actions taken have improved the defects.


**1.4.20.26.1** **(07-10-2020)**

#### Acting Manager Assignments and Designations

1. You should designate an acting manager during periods of absence. To maintain continuity, the acting manager should usually perform all managerial tasks (Refer to the current National Agreement for certain restrictions on performance evaluations (Section 4) and evaluative telephone monitoring (Section 12)). Managerial tasks to be performed and those to be deferred may depend on the duration of the assignment. Assignments should be agreed on between you and the acting manager in advance. Specific expectations should be given at the beginning of each assignment. This will form the basis for your feedback on performance of the acting assignment. Except for assignments of very short duration, you will provide the acting manager with documentation evaluating performance on the detail.

2. You may designate specific tasks even though you are not absent. This enables a manager to provide developmental assignments to employees aspiring to the next level to gain useful experience while freeing some of your time. In this situation, no "acting" assignment exists. The person to whom the task is designated does not exercise managerial authority; therefore, tasks reserved to managers, (i.e., telephone monitoring, manager approvals, callbacks requested by the taxpayer that involve a CAP appeal), cannot be delegated. You should document any designation of specific tasks on the employee's CLP as a developmental assignment


**1.4.20.27** **(07-10-2020)**

### Campus Systems Administrator – Roles and Responsibilities

1. The role and responsibilities of a system administrator (analyst) are as follows:




| **System administrator (SA) roles include:** |
| --- |
| Ensuring system is properly configured to meet organizational and operational objectives; |
| --- |
| Maintaining a trouble log to monitor response time problems, circuit problems, unusual staffing situations (snow days, building closures, etc.) or any other factor which could distort telephone data and affect circuitry or staffing plans; |
| Ensuring circuitry meets standardization requirements; |
| Adhering to schedule; |
| Checking the Automated Collection System/Integrated Collection System (ACS/ICS) Parameter File for the correct date and cycle; |
| Reviewing the reports that are generated from the system to determine if the operation is achieving its goal and identify system problems that may exist within the system; |
| Distributing ACS/ICS and QMF Reports to appropriate managerial levels, providing assistance to managers and employees, and creating user profiles and assigning passwords; |
| Checking voice disk space; |
| Retrieving and reviewing Telephone Routing Interactive Systems Management Information Statistics (TRIS MIS); |
| Monitoring agents for long wrap and idle times as needed; |
| Analyzing systems impact resulting from Headquarter office maintenance, TRIS Project Office Master Customer Service Script changes, etc. |
| Advising operations management and facilitate implementation with involved parties; |
| Instructing site employees on new features and procedures and troubleshoot system and equipment problems resulting from changes; |
| Creating tickets for needed Query Management Facility (QMF) reports as requested by operations manager |


**1.4.20.27.1** **(06-05-2025)**

#### Systems Security Responsibilities

1. System's management begins with the establishment of the Security database for IDRS, ACS and the Resource Allocation Control File (RACF). Information input to the Security database authorizes employees to use the system and keeps track of employee information for reporting purposes.



### Note:



For security purposes written procedures should be provided to all users and training conducted once a year.

2. For ACS Security refer to IRM 5.19.5.2, ACS Security.

3. For security purposes, perform the following tasks:




| **Systems security tasks include:** |
| --- |
| Prepare written instructions to users and conduct training to promote overall system security; |
| --- |
| Maintain a current and historical master record of all control numbers, ACS, and IDRS users within the call-site or CSCO; |
| Maintain a complete listing of all call site hardware; |
| Maintain system-wide records concerning security on the parameter file; |
| Perform periodic reviews of IDRS command code profiles with managers to ensure that employees have only those command codes that are required to complete the job; |
| Assure that profile change requests are appropriate and meet security criteria; |
| Monitor security reports; |
| Ensure that RACF and IDRS security violations are identified and appropriate remedial actions are taken |
| Inform the operation of continuing violations and provide appropriate documentation |
| Maintain appropriate records of security violations |


**1.4.20.27.2** **(06-05-2025)**

#### Functional Coordinator (FUNCO) Responsibilities

1. This person serves as the first point of contact for technical support to computer system end-users. They ensure security of the functional area computers and act as the coordinator in the implementation of automated applications. The role and responsibilities of a FUNCO are as follows:




| **FUNCO Role and responsibilities include:** |
| --- |
| Reporting system problems that cannot be resolved through normal troubleshooting procedures; |
| --- |
| Serving as the coordinator for computer maintenance and hardware problems; |
| Reports problems to the MITS help desk and ensures they are resolved; |
| Resolves common technical problems and serves as a technical resource to functional coordinators in other divisions |
| Reviews and submits requests to MITS for security access for functional area users. Reports user-identified security breaches to the appropriate team manager or to his/her supervisor if of a more sensitive nature; |
| Ensures permissions and passwords are requested and received |
| Evaluates existing computer equipment and makes recommendations for replacement or upgrades; Determines where new equipment will be installed with input from management; |
| Assists MITS with functional moves by updating floor plans and re-arranging work areas/computer set-ups as applicable; |
| Maintain a complete listing of all call site hardware; |
| Maintains and monitors user permissions including adding, deleting, and modifying user permissions on shared directories assigned to functional areas; |
| Creates, monitors, and secures folders on shared directories on the network; |


**1.4.20.27.3** **(06-05-2025)**

#### Resource Allocation Control File (RACF)

1. The ACS security system exists in the appropriate campus and is used to control access to the ACS host system. To add or remove users from the ACS system the following steps must take place:



1. The ACS employee must complete a BEARS request. These are routed through the appropriate channels for management approval and then routed to the Security Office at the campus. The Security Office issues a RACF user number for all new employees.

2. Following issuance of the RACF user number, the ACS Systems Analyst will create a temporary RACF password.

3. The RACF user member is entered on the ACS Security Maintenance Screen (SMOO) with the appropriate team, function and unit.


**1.4.20.27.4** **(07-10-2020)**

#### Profile Resume Procedures

1. This process is utilized to specify that a user is to be allowed access to the system again. The analyst would normally use RESUME to restore a user’s access to the system that has been revoked by:



   - Three consecutive unsuccessful password/log in attempts

   - A prior REVOKE command


2. You can assign a new entry password and RESUME the profile at any time. See Exhibit 1.4.20-5 for detailed instructions. Always remember to do the following:



   - DISPLAY the user before resuming that user. See Exhibit 1.4.20-4 for detailed instructions.

   - Verify the appropriate action is taken on the correct user.


**1.4.20.27.5** **(06-05-2025)**

#### Profile Revoke Procedures

1. When an employee’s profile is "REVOKED" , this specifies that RACF is to prevent a user from accessing the system. The user’s profile and DATA SETS are not deleted. The user cannot access the system, and the employee will be denied access at their next log in attempt.

2. A user should always be "REVOKED" if detailed to another position for 30 days or more.

3. If a user no longer needs ACS/ICS access DELETE the user by completing a BEARS.



### Note:



Remember to "DISPLAY" the user id before revoking or resuming and verify that the appropriate action is being taken on the correct user. See Exhibit 1.4.20-5 for detailed instructions.


**1.4.20.28** **(07-10-2020)**

### Handling Telephone Threats Through the IUP System.

1. In situations of threats received on the telephone (e.g. bomb threats, suicide, building security threats or other threats of bodily harm to employees or their families), the CR will push the EMERGENCY/Record Call button on the Infrastructure Upgrade Project-Endpoint Replacement, Computer Telephone Integration Object (UP EP CTIOS) desktop to allow the call to be recorded.

2. This procedure will begin the recording of the conversation and notify both the manager and the System Analyst (SA) an emergency exists at the CR's workstation.

3. In addition to reserving at least one voice port for emergencies of this nature, you will need to obtain the following information details for tracing the call:



   - Product line on which the call was received (7650 or 3903).

   - Time call received and length of call

   - Trunk number the call came in on and the Circuit ID Number


4. When notified of an emergency call, take the following actions:



   - Query the trunk record (via IUP) for the trunk number that the call came in on. This trunk record will provide you with the Circuit ID Number (the number of the T-1)

   - Provide this information to the Telecom representative and contact AT&T's Annoyance Call Bureau for 800 Services at 1-800-325-0261


5. In order for AT&T to trace the call, they will need the following:



   - The 800 number the taxpayer was calling

   - The office where the call was terminated

   - Length of call

   - Time the call was received


6. Provide this information to the local Treasury Inspector General for Tax Administration (TIGTA) office along with a copy of the recorded telephone call.

7. Maintain a copy of the Trunk record, Agent and Trunk Detail reports in a security file for possible future reference.


**1.4.20.28.1** **(06-05-2025)**

#### Handling Telephone Threats on IUP Telephone Systems

1. Telephone threats to the IRS may be directed at the agency or at an individual employee of the IRS. Telephone threats, as with any other type of threatening or intimidating behavior or action should be taken very seriously, regardless of whether or not the threat specifically mentions an explosive device. Managers can reference IRM 21.1.3.10 , Safety and Security Overview, as a guideline.

2. It is recommended that all employees under the manager's span of control are aware of such guidelines and understand what actions are required to be taken should this type of incident occur.

3. Some items you should be aware of in the event of a threatening call.



1. Take note of the wording the caller is using. If possible, try and write down as much specific language and/or direct references the caller makes.

2. Listen closely to the voice (male/female), voice quality (calm/excited), accents, and speech impediments.

3. Notate if the caller appears well spoken, incoherent, and irrational or if the caller uses foul language. As difficult as it may be, it is important that you take note as to the specific language the caller uses. Investigators will be interested in all aspects of the call.

4. Notate any background noises you might hear, such as street sounds, a PA system, animal noises, music, and any other noise which may give a clue to caller’s location.

5. Follow site direction to report threatening phone calls. Telephone numbers are available through your office’s security or TIGTA representatives.


**1.4.20.28.2** **(06-05-2025)**

#### Employee and Building Security

01. In the event of an emergency, ACS sites should contact JOC directly.

02. All managers must familiarize themselves, and their team, with the Occupational Emergency Plan (OEP) book. This plan describes procedures and responses relative to a variety of emergency situations and threats, both natural and man-made. Adherence to these specific procedures is imperative. A copy of this plan must be kept in the manager’s office and will be available for reference by all employees.

03. In the event of an emergency, CSCO operation's should follow established contact directives to ensure notification of applicable stakeholders.

04. Managers should be familiar with all evacuation procedures and Accountability Stations as they pertain to their team and department employees.



    1. All manages must maintain a current listing of active duty employees. This listing must be available in the event of a site evacuation. This listing should be taken to the Team Accountability Station to ensure that all active employees are accounted for in the event of an evacuation.

    2. Managers must familiarize their team members on proper evacuation procedures and Accountability locations. Secondary Accountability locations may be warranted. A map of this location and the evacuation routes should be posted


05. Managers should ensure that their employees are aware of locally established Business Resumption Plan (BRP) protocols and have access to all contact numbers in the event of a site closure or other similar event.

06. All managers should familiarize themselves with local emergency personnel, security and medical phone numbers, CSCO contact campus reporting instructions hot-line or other site BRP directives and protocols specific to site locations.

07. All managers should maintain a Business Resumption Plan (BRP) listing, complete with employee contact information. Managers must also communicate with team employee’s site closing contact information so employees can ascertain the re-opening of affected sites and plan accordingly.

08. Managers should be familiar with the various Organizational identification cards and badges to ensure access to prohibited areas is controlled.

09. Managers should be aware and alert to issues related to violence in the workplace and trigger signs that employees may display. Review campus direction and protocols with respects to handling individual employees who display such mannerism

10. Managers must complete relative incident reports to ensure accurate follow-up and actions.


**1.4.20.28.3** **(06-05-2025)**

#### Site Closings

1. In the event of an emergency, call sites should contact the Joint Operations Center (JOC) directly. JOC will ensure the information is posted on the JOC web page. Emergency situations include:



   - Weather

   - Disasters

   - Threats to the health and well being of the employees

   - Instances where the site is unable to access applicable applications, such as AMS, ACS, IDRS, and AOIC, but these systems are available elsewhere across the enterprise


### Note:

Each site must provide to their Headquarter office the name of three individuals, including the operations manager that will be authorized to contact JOC in the event of an emergency. This list of names will provide information to the staff at JOC as they become more familiar with the ACS/CSCO operation, as well as to the Headquarters office.

2. For office closure or emergency information employees will need to call the IRS help desk at 866-743-5748 option 3. For TTY 800-877-8339.

3. Scheduled Site Closings: Sites should work with their respective JOC and Headquarter Operations for any pre-approved request outlined below:



   - Site wide mandatory training that has a deadline and it is not possible to stagger the training

   - Unusual site events, and Headquarters Office agrees with the instance

   - Scheduled administrative closings, such as fire drills


4. Communications Plan: JOC web page: Joint Operations Center will provide information on emergency closings, site hours of operation and any exceptions that are communicated to JOC.


**1.4.20.29** **(05-30-2013)**

### ACS Telephone Program and System Reports

1. A primary responsibility is to assist in monitoring and managing the telephone system to maximize level of service. Available ACS reports include:



   - ACS Production Report (ACRM5001) - provides management with information to monitor new cases, processed cases and the remaining balance of cases. Monitoring this information permits management to make policy decisions on case load scheduling, utilization of resources, and prioritization of taxpayer accounts. The Production report shows beginning and ending inventory balances for major categories of activity, which account for balance changes. Access to this report is through the ACS Manager Menu using action code RP00, Report 1, Report ID ACRM5001.

   - Call Site Total Screen - used to identify a National Inventory of open ACS cases for all call sites. To display, enter the action code NI00 from the Manager Menu. Total case inventory will be shown for each call site. Placing an S by an individual call site will result in a breakdown of the call site's inventory by Team and TIN Range.

   - Standard QMF (Query Management Facility) reports can be accessed by Systems Analysts through QMF for Windows. AD Hoc reports may be created by the Systems Analyst using QMF based on the criteria provided by the operations manager. A strong knowledge of the ACS database is required.

   - IRM 1.4.21.1.6 provides information regarding other ACS Telephone Program Reports


**1.4.20.30** **(07-10-2020)**

### CSCO System Reports

1. Departments rely on a variety of inventory and age reports. These reports assist all levels of management within CSCO to identify the status of casework and the relationships those cases have on issues such as age and service. It is imperative that managers learn to interpret these reports in order to make informed decisions based on accurate data.

2. Some CSCO reports are available for viewing on the Headquarters' SharePoint drive. You will need to request permission to access this site. The following reports are examples of those that are available on this site.



   - ACS Reports

   - CSCO Inventory Report

   - MAAG

   - Workplans


3. Some CSCO reports are available for viewing on the Headquarters shared drive, formerly referred to as the “L” drive. Your department managers can support active permissions to access this drive:



1. Quality/Overage

2. IA Tracker

3. COM Report

4. Customer Satisfaction


4. There are reports that SB/SE and CSCO managers should review on a weekly basis, as applicable. Some examples are:



1. CCA 4243 (overage)

2. WP & C

3. ASFR 200 report (MIS)

4. Department specific inventory reports (i.e., program inventory reports)

5. AMS


**1.4.20.31** **(06-05-2025)**

### Managers Responsibility to the Federal Employee Viewpoint Survey

1. Every manager has a responsibility to encourage their team members to actively and honestly participate in the Survey process. The U.S. Office of Personnel Management (OPM) will send the survey link to IRS employees. OPM will continue to send weekly emails to remind employees to take the survey. Because the emails are system-generated, an employee can stop the weekly emails by completing the survey. The emails will discontinue when the survey administration period ends. Managers must conduct a Federal Employee Viewpoint (FEVS) workgroup meeting at a minimum annually. Managers have the option of inviting a trained facilitator from the IRS Facilitator Cadre. See IRS Facilitator Cadre for more information.



### Note:



Managers must provide their employees with a copy of the survey results prior to the FEVS workgroup meeting.

2. The National Human Capital Office determines the IRS Servicewide core focus questions. Managers must review their report to identify focus areas and develop action plans that align with the IRS corporate focus on engagement.

3. NTEU stewards are not required to attend the FEVS workgroup meetings, per the current National Agreement, Article 8A, Section 1.l, but management will not implement any changes identified during the meetings without providing notice to NTEU and bargaining to the extent required by law.

4. Upon completion of all meeting, submit the completed Employee Engagement Tracking document to the designated party.


**1.4.20.32** **(07-10-2020)**

### Managers Responsibility to the Customer Satisfaction Survey (CSS)

1. The Customer Satisfaction Survey is a telephone survey for ACS customers. Surveying taxpayers allows us to identify the things we are doing right, as well as areas for improvement in order to deliver top quality service to America’s taxpayers. Improving customer satisfaction requires the combined efforts of all IRS employees. Front line employees and managers are the primary providers of service to taxpayers, and can directly impact taxpayer perceptions of IRS courtesy, professionalism, accuracy, timeliness and fairness through the actions they taker (or fail to take).

2. To provide taxpayers with complete anonymity when providing their responses, private market research firms are used to survey taxpayers with whom we interact. These companies compile and analyze the survey results and issue reports. The reports highlight the overall customer satisfaction rating and include the areas to focus on to improve future results.

3. Each Operating Unit has at least one Customer Satisfaction Coordinator who is familiar with the results and reports for their function.

4. For each function, Customer Satisfaction survey results are reported annually at the National level.

5. See IRM 21.1.1.9, TS Accounts Management and Automated Collection Services (ACS) Telephone Customer Satisfaction Survey (CSS), for additional information.


**1.4.20.33** **(06-05-2025)**

### Useful Websites for Managers

1. Electronically accessing information is the most common way for managers to acquire the information they need by searching through the Intranet/Internet. Below are some useful web addresses that will assist you in gathering the information you need in the most efficient manner.



1. iManage -This is the link to the iManage website. iManage is a virtual community for IRS managers which contains targeted information, advice and interactive features to help you work more efficiently.

2. irssource - This site will provide you access to a variety of training issues related to both yourself and your team employees.

3. http://hco.web.irs.gov/perfmgmt - This link will provide information related to the Performance Management System.

4. Employee development resources This link will provide access to various websites that will assist you in acquiring information on a variety of topics.

5. Education and Training This site provides links to multiple training delivery systems.


**Exhibit 1.4.20-1**

### Types of Performance Awards

| **Awards** |
| --- |
| Performance Awards | Monetary awards granted to recognize and reward individual employee performance as reflected in their most recent performance appraisal. There are three general categories of performance awards:<br> <br>- bargaining unit employees<br>  <br>- non-bargaining unit employees<br>  <br>- non-bargaining unit employees compensated under the IRS pay banding system |
| --- | --- |
| Special Act or Service Award | Monetary awards granted to recognize and reward commendable employee, team or group achievements. Managers may recommend an award for employees’ personal achievements in connection with or related to official employment or otherwise in the public interest.<br> <br>### Note:<br>There is no limit to the number of special act awards that an employee may receive for accomplishments either as an individual or a member of a group or team |
| Managers' Awards | A type of special act award designed for timely recognition, and fast processing and payment. These awards may be used to recognize an achievement performed in an exemplary manner that is more limited in scope than a special act or service award. Managers' award amounts are limited to $50 to $250; an approval and processing procedures are more streamlined than for special act or service awards. |
| Time-Off Awards | Time-off from duty granted without charge to leave or loss of pay. At management's discretion, any monetary award may be granted as a monetary payment, as a time-off award, or a combination monetary and time-off award. Up to 40 hours of time-off may be granted to an employee for a single award, and up to a total of 80 hours of time-off may be granted to an employee during a leave year. A time-off award must be scheduled and used within one year from the effective date of the award. |
| Quality Step Increase (QSI) | An increase in a GS, GM or GL employee's rate of basic pay from one step of the grade to the next higher step of that grade. The purpose of a QSI is to provide appropriate incentives and recognition for excellence in individual employees' performance.<br> <br>### Note:<br>Effective for appraisal periods ending on and after September 30, 2008, IRS implemented an enhanced criteria based QSI policy as part of the Commissioner's "Workforce of Tomorrow" initiative to make the IRS the best place to work in government. |
| Bilingual Award | Special Act awards granted to employees who use their bilingual skills on a regular basis, are currently rated at least fully successful and are not otherwise compensated through a Performance Award or Superior Accomplishment Award based on their use of their bilingual skill. |
| External Awards | These honors are sponsored by agencies or organizations outside of IRS in recognition of notable achievements in the public sector. (The external awards program is administered by the Human Capital Office). |
| Honorary Awards | Symbolic non-monetary recognition items such as certificates, plaques, medals, or similar items which provide suitable commemoratives of employees' notable achievements. |
| Suggestion Awards | Based on the adoption of employee suggestions to improve the efficiency of effectiveness of Government operations through formally submitting their ideas in writing. |

**Exhibit 1.4.20-2**

### Other Types of Honorary Awards

| **Honorary Awards** |
| --- |
| Commissioner's Award | This award is the highest honor that the Commissioner can bestow. This award is an expression of the Commissioner's personal appreciation for outstanding and significant contributions in the public interest related to the activities of the Internal Revenue Service. This award may be presented to an individual, team, or group within the IRS. |
| --- | --- |
| Federal Career Service Award | Honor IRS employees upon attainment of 5 years of federal service and at each subsequent 5-year milestone. |
| Certificates of Recognition | These are used to recognize employees who have provided significant, non-routine contributions which do not meet the criteria for any other type of award. These certificates are also suitable for presentation to individuals or groups outside of IRS that have made significant contributions to the IRS. |
| Albert Gallatin Award | The Department of Treasury's highest career service award. Conferred by the Secretary upon the retirement or death of Federal employees who served twenty or more years in the Department and whose record reflects fidelity to duty. (The HCO Benefits and Services Team provides guidance and procedures regarding employee eligibility and the distribution of _Gallatin Awards_.) |
| Travel Gainsharing Awards | A program that allows employees, who save the government money while traveling, to receive a portion of that money as an award. (Additional information may be found at the _Employee Resource Center_. |
| Retiree Emblems | A retiree emblem and retirement certificate are issued to retiring employees who have completed ten years or more of service with the IRS. |

For more information, please see IRM 6.451.1, Policies, Authorities, Categories, and Approvals.

**Exhibit 1.4.20-3**

### Links to Resources - Employees with Disabilities

|     |
| --- |
| **Employees with Disabilities resources include:** |
| Accessibility Office |
| IRworks |
| Assistive Technology |

**Exhibit 1.4.20-4**

### Actions To Display A User on ACS

To **DISPLAY** an employee on ACS to see if they are **REVOKED** take the following actions:

**AT YOUR IAP SCREEN:**

| **STEP** | **ACTIONS** |
| --- | --- |
| 1 | **Type****LOGON** |
| 2 | **Hit****Space Bar** |
| 3 | _Type_ **_your_****RACF ID** |
| 4 | _Hit_ **Control** |
| 5 | _Type in_****your******Password** |
| 6 | _Hit_ **Control** |
| 7 | _When you see_**\\*\\*\\*** _hit_ **Control** _again_ |
| 8 | _Type in_ **TSO** |
| 9 | _Hit_ **Space Bar** |
| 10 | _Type_ **LU** |
| 11 | _Hit_ **Space Bar** |
| 12 | _Type in_ **Employee's RACF ID** |
| 13 | _Hit_ **Control** |

If your screen looks like this**(see the example below)** before you hit your final control, you are correct.

- **Example**: TSO LU J955555


**Exhibit 1.4.20-5**

### Actions To Resume A User on ACS

To **RESUME** an employee on ACS that has been **REVOKED** take the following actions:

**AT YOUR IAP SCREEN:**

| **STEP** | **ACTION** |
| --- | --- |
| 1 | _Type_**LOGON** |
| 2 | _Hit_**Space Bar** |
| 3 | _Type_ **_your_****RACF ID** |
| 4 | _Hit_ **Control** |
| 5 | _Type in_ ****your**Password** |
| 6 | _Hit_ **Control** |
| 7 | _When you see_ _\\*\\*\\*_ _hit_ **Control**_again_ |
| 8 | _Type in_ **TSO** |
| 9 | _Hit_ **Space Bar** |
| 10 | _Type_ **ALU** |
| 11 | _Hit_ **Space Bar** |
| 12 | _Type in_**Employee's RACF ID** |
| 13 | _Hit_ **Space Bar** |
| 14 | _Type_ **RESUME** |
| 15 | _Hit_ **Control** |

If your screen looks like this**(see the example below)** before you hit your final control, you are correct.

- **Example**: TSO ALU J955555 RESUME


**Exhibit 1.4.20-6**

### Actions To Resume and Assign New Passwords

To **RESUME** an employee on ACS that has been **REVOKED** and issue a new password, take the following actions:

**AT YOUR IAP SCREEN:**

| **STEPS** | **ACTIONS** |
| --- | --- |
| 1 | _Type_ **LOGON** |
| 2 | _Hit_ **Space Bar** |
| 3 | _Type your_**RACF ID** |
| 4 | _Hit_ **Control** |
| 5 | _Type in_ **_your_****Password** |
| 6 | _Hit_ **Control** |
| 7 | _When you see_**\\*\\*\\*** _hit_**Control** _again_ |
| 8 | _Type in_ **TSO** |
| 9 | _Hit_ **Space Bar** |
| 10 | _Type_ **ALU** |
| 11 | _Hit_ **Space Bar** |
| 12 | _Type in_ **Employee's RACF ID** |
| 13 | _Hit_**Space Bar** |
| 14 | _Type the word_ **PASSWORD** |
| 15 | _Hit_ **Space Bar** |
| 16 | _Type_**(** |
| 17 | _Type_ **the temporary password you want to assign to the employee** |
| 18 | _Type_**)** |
| 19 | _Hit_ **Control** |

If your screen looks like this**(see the example below)** before you hit your final control, you are correct.

- **Example**: TSO ALU J955555 PASSWORD (NEW99you)



### Note:



Passwords should be a combination of 8 letters/numbers. This format works the best.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-020#addtoany "Show all")

A2A