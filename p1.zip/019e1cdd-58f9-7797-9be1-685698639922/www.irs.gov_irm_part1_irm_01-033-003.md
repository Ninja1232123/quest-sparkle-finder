---
url: "https://www.irs.gov/irm/part1/irm_01-033-003"
title: "1.33.3 Reimbursable Operating Guidelines | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-033-003#main-content)

- 1.33.3  [Reimbursable Operating Guidelines](https://www.irs.gov/irm/part1/irm_01-033-003#id1)
  - 1.33.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-033-003#id2)
    - 1.33.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-033-003#id3)
    - 1.33.3.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-033-003#id4)
    - 1.33.3.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-033-003#id5)
      - 1.33.3.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-033-003#id6)
      - 1.33.3.1.3.2  [Financial Management Systems Office](https://www.irs.gov/irm/part1/irm_01-033-003#id7)
      - 1.33.3.1.3.3  [Associate CFO for Corporate Budget and Deputy Associate CFO for Corporate Budget](https://www.irs.gov/irm/part1/irm_01-033-003#id8)
        - 1.33.3.1.3.3.1  [Budget Execution Office](https://www.irs.gov/irm/part1/irm_01-033-003#id10)
        - 1.33.3.1.3.3.2  [Cost and User Fees Office](https://www.irs.gov/irm/part1/irm_01-033-003#id11)
      - 1.33.3.1.3.4  [Senior Associate CFO for Financial Management](https://www.irs.gov/irm/part1/irm_01-033-003#id12)
        - 1.33.3.1.3.4.1  [Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-033-003#id13)
          - 1.33.3.1.3.4.1.1  [Financial Reporting and Analysis Office](https://www.irs.gov/irm/part1/irm_01-033-003#id15)
          - 1.33.3.1.3.4.1.2  [Government Payables and Funds Management Office](https://www.irs.gov/irm/part1/irm_01-033-003#id16)
      - 1.33.3.1.3.5  [Business Units](https://www.irs.gov/irm/part1/irm_01-033-003#id17)
    - 1.33.3.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-033-003#id18)
    - 1.33.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-033-003#id19)
    - 1.33.3.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-033-003#id20)
    - 1.33.3.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-033-003#id21)
    - 1.33.3.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-033-003#id22)
  - 1.33.3.2  [Apportionments](https://www.irs.gov/irm/part1/irm_01-033-003#id23)
    - 1.33.3.2.1  [Reimbursable Plan Management](https://www.irs.gov/irm/part1/irm_01-033-003#id25)
    - 1.33.3.2.2  [Agreement Budget Authority Alignment](https://www.irs.gov/irm/part1/irm_01-033-003#id26)
  - 1.33.3.3  [Financial Policies](https://www.irs.gov/irm/part1/irm_01-033-003#id27)
    - 1.33.3.3.1  [Execution and Funds Control of Reimbursable Services](https://www.irs.gov/irm/part1/irm_01-033-003#id28)
    - 1.33.3.3.2  [Operational Policies and Procedures](https://www.irs.gov/irm/part1/irm_01-033-003#id29)
      - 1.33.3.3.2.1  [Cost Estimate Standards and Procedures](https://www.irs.gov/irm/part1/irm_01-033-003#id30)
        - 1.33.3.3.2.1.1  [Direct Costs](https://www.irs.gov/irm/part1/irm_01-033-003#id32)
        - 1.33.3.3.2.1.2  [Indirect and Overhead Costs](https://www.irs.gov/irm/part1/irm_01-033-003#id33)
        - 1.33.3.3.2.1.3  [Full Cost Estimating](https://www.irs.gov/irm/part1/irm_01-033-003#id34)
        - 1.33.3.3.2.1.4  [Approval of Direct, Indirect, and Overhead Costs](https://www.irs.gov/irm/part1/irm_01-033-003#id35)
      - 1.33.3.3.2.2  [Agreements](https://www.irs.gov/irm/part1/irm_01-033-003#id36)
      - 1.33.3.3.2.3  [Agreement Statutory Authority](https://www.irs.gov/irm/part1/irm_01-033-003#id37)
      - 1.33.3.3.2.4  [Federal G-Invoicing Program Mandate](https://www.irs.gov/irm/part1/irm_01-033-003#id38)
      - 1.33.3.3.2.5  [Federal Agreements](https://www.irs.gov/irm/part1/irm_01-033-003#id39)
      - 1.33.3.3.2.6  [Non-Federal Entity Agreements](https://www.irs.gov/irm/part1/irm_01-033-003#id40)
      - 1.33.3.3.2.7  [Agreement Approval Process](https://www.irs.gov/irm/part1/irm_01-033-003#id41)
        - 1.33.3.3.2.7.1  [Agreement Authorizing Officials and Delegation Orders](https://www.irs.gov/irm/part1/irm_01-033-003#id43)
      - 1.33.3.3.2.8  [Agreement Modifications](https://www.irs.gov/irm/part1/irm_01-033-003#id44)
    - 1.33.3.3.3  [IFS Budget and Accounting Procedures](https://www.irs.gov/irm/part1/irm_01-033-003#id45)
      - 1.33.3.3.3.1  [Financial Codes](https://www.irs.gov/irm/part1/irm_01-033-003#id46)
        - 1.33.3.3.3.1.1  [Customer Numbers](https://www.irs.gov/irm/part1/irm_01-033-003#id48)
        - 1.33.3.3.3.1.2  [Funded Program Codes](https://www.irs.gov/irm/part1/irm_01-033-003#id49)
      - 1.33.3.3.3.2  [IFS Transactions](https://www.irs.gov/irm/part1/irm_01-033-003#id50)
      - 1.33.3.3.3.3  [Forecast and Sales Order Processing](https://www.irs.gov/irm/part1/irm_01-033-003#id51)
      - 1.33.3.3.3.4  [Reimbursable Earnings (FV50)](https://www.irs.gov/irm/part1/irm_01-033-003#id52)
      - 1.33.3.3.3.5  [Billing and Payment Processing](https://www.irs.gov/irm/part1/irm_01-033-003#id53)
      - 1.33.3.3.3.6  [Reports and Compliance](https://www.irs.gov/irm/part1/irm_01-033-003#id54)
        - 1.33.3.3.3.6.1  [IFS Reimbursable Status Reports](https://www.irs.gov/irm/part1/irm_01-033-003#id56)
        - 1.33.3.3.3.6.2  [Monthly Reporting and Compliance](https://www.irs.gov/irm/part1/irm_01-033-003#id57)
  - 1.33.3.4  [Closeout of Reimbursable Agreements](https://www.irs.gov/irm/part1/irm_01-033-003#id58)
  - 1.33.3.5  [Prior-Year Settlements and Refunds](https://www.irs.gov/irm/part1/irm_01-033-003#id59)

# Part 1. Organization, Finance, and Management

# Chapter 33. Strategic Planning, Budgeting and Performance Management Process

# Section 3. Reimbursable Operating Guidelines

* * *

## 1.33.3 Reimbursable Operating Guidelines

#### Manual Transmittal

August 27, 2025

#### Purpose

(1) This transmits revised IRM 1.33.3, Strategic Planning, Budgeting and Performance Management Process, Reimbursable Operating Guidelines.

#### Material Changes

(1) _IRM 1.33.3.1.2_, Authorities, added OMB Circular A-11, Part 4, Section 150.

(2) _IRM 1.33.3.1.3.2_, Financial Management Systems Office, relocated to reflect organization structure and updated to reflect current duties.

(3) _IRM 1.33.3.1.3.3_, Associate CFO for Corporate Budget and Deputy Associate CFO for Corporate Budget, updated to reflect the creation of the deputy position.

(4) _IRM 1.33.3.1.3.3.1_, Budget Execution Office, updated to reflect existing processes.

(5) _IRM 1.33.3.1.3.3.2_, Cost and User Fees Office, updated to reflect existing processes.

(6) _IRM 1.33.3.1.3.5_, Business Units, updated to reflect existing processes.

(7) _IRM 1.33.3.1.6_, Terms/Definitions, removed unnecessary definitions.

(8) _IRM 1.33.3.1.8_, Related Resources, updated to include internal resources.

(9) _IRM 1.33.3.2.1_, Reimbursable Plan Management, updated to include business unit responsibility to ensure earnings are submitted in accordance with terms on the agreement.

(10) _IRM 1.33.3.2.2_, Agreement Budget Authority Alignment, updated to include statement that business units should contact GP&FM if earnings are delayed.

(11) _IRM 1.33.3.3.2.1.3_, Full Cost Estimating, updated to state business units must use the CB cost worksheet template.

(12) _IRM 1.33.3.3.2.1.4_, Approval of Direct, Indirect, and Overhead Costs, updated to state projects with only non-labor costs must be approved by the Director, Budget Execution.

(13) _IRM 1.33.3.3.2.2_, Agreements, updated to reflect the implementation of G-Invoicing. Relocated detailed language on federal agreements to _IRM 1.33.3.3.2.5_, Federal Agreements.

(14) _IRM 1.33.3.3.2.3_, Agreement Statutory Authority, consolidated redundant wording related to the Economy Act.

(15) _IRM 1.33.3.3.2.4_, Federal G-Invoicing Program Mandate, updated to reflect compliance with the G-Invoicing mandate.

(16) _IRM 1.33.3.3.2.5_, Federal Agreements, updated to emphasize the use of Fiscal Service (FS) 7600 forms for federal agreements. Included sections to distinguish between G-Invoicing active and G-Invoicing non active agreements.

(17) _IRM 1.33.3.3.2.6_, Non-Federal Entity Agreements, relocated information on methods of payment from previous IRM 1.33.3.3.3.6, Government Payables and Funds Management Office Mailing Addresses and Contact. Eliminated references to paper checks and money orders to comply with the Executive Order.

(18) _IRM 1.33.3.3.2.7_, Agreement Approval Process, revised to provide clarity on the process.

(19) _IRM 1.33.3.3.2.8_, Agreement Modifications, updated to emphasize importance of maintaining audit trail for modifications.

(20) _IRM 1.33.3.3.3_, IFS Budget and Accounting Procedures, rearranged subsections to more accurately reflect the order of procedures. Removed language referencing transition to G-Invoicing.

(21) _IRM 1.33.3.3.3.1.2_, Funded Program Codes, renumbered and incorporated content from previous IRM 1.33.3.3.3.5.2, Work Breakdown Structure.

(22) _IRM 1.33.3.3.3.2_, IFS Transactions, renumbered and updated for new transactions.

(23) _IRM 1.33.3.3.3.3_, Forecast and Sales Order Processing, renumbered and updated to reflect current processes.

(24) _IRM 1.33.3.3.3.5_, Billing and Payment Processing, renumbered and updated to reflect current process.

(25) _IRM 1.33.3.3.3.6_ , Reports and Compliance, new section created to group subsections related to reports.

(26) _IRM 1.33.3.3.3.6.2_, Monthly Reporting and Compliance, changed title and renumbered sections.

(27) _IRM 1.33.3.5_, Prior Year Settlements and Refunds, clarified process for settling earnings and added business unit responsibility for ensuring prior year fund availability.

(28) IRM 1.33.3 several subsections were renumbered to improve readability of the document.

(29) Updated links and corrected references throughout the IRM.

(30) Minor editorial changes made throughout the IRM.

#### Effect on Other Documents

IRM 1.33.3, dated July 13, 2023, is superseded.

#### Audience

The IRS business unit budget community involved in establishing and processing federal Intragovernmental and non-federal transactions.

#### Effective Date

(08-27-2025)

Anthony S. Chavez

Acting Chief Financial Officer

**1.33.3.1** **(07-13-2023)**

### Program Scope and Objectives

1. Purpose: The Reimbursable Operating Guidelines (ROG) is internal funds control guidance developed to assist division finance officers (DFOs), financial plan managers (FPMs), and related staffs with establishing, costing, and approving agreements. The ROG also assists with the accounting, billing, and collection of reimbursable funds owed to the IRS.

2. Audience: The IRS business units, particularly finance and program offices, which provide reimbursable services to federal and non-federal entities.

3. Policy Owner: The CFO, Corporate Budget (CB) office is responsible for policy decisions reflected in the ROG.

4. Program Owner: The ROG is published by CB. Comments and change requests may be submitted to the CB Director, Budget Execution Office. Future revisions, including interim guidance, will be posted to the CFO website.

5. Primary Stakeholders: All IRS management, CFO and business unit budget and finance staff participating in reimbursable agreements.

6. Program Goals: To ensure the IRS reimbursable agreements meet statutory and regulatory requirements, the costing methods employed are thorough, negotiations are sound, accounting procedures are properly applied, and trading partner differences are resolved timely.



### Note:



In the event of a Continuing Resolution (CR), related guidance specific to the CR and CR period will be posted on the CFO website and will supersede this IRM, where applicable.


**1.33.3.1.1** **(07-13-2023)**

#### Background

1. This IRM addresses seller reimbursable activity where the IRS functions as the provider of reimbursable goods and/or services. These guidelines do not apply to buyer agreements where the IRS procures services from other governmental and non-governmental entities.

2. The Office of Management and Budget (OMB) requires that agencies develop and implement funds control regulations and operational guidance for reimbursable agreements. This requirement is set out in OMB Circular A-11, Part 4 Section 150, Administrative Control of Funds.

3. Treasury requires standardized, Treasury-wide policies and procedures for preparing, processing, executing, administering, and closing-out of reimbursable agreements. These guidelines reinforce standard processes and consistent treatment in the Servicewide administration of the reimbursable agreement program.

4. The Antideficiency Act (ADA) also requires all government agencies to prescribe, by regulation, a funds control system. The funds control system is intended to:



1. Restrict obligations and expenditures from each appropriation or fund account to the lower of the amount apportioned by OMB or the amount available in the appropriation or fund account.

2. Enable the agency head to identify the person(s) responsible for exceeding appropriations, apportionments, allotments, statutory limitations or other administrative subdivisions of funds.


5. Reimbursable obligations and expenditures must be recorded timely and accurately to ensure the IRS is compliant with U.S. fiscal law, including the ADA.

6. This IRM includes high-level Treasury, Fiscal Service G-Invoicing guidance and procedures. The G-Invoicing Program Guide is located on the [Bureau of Fiscal Service’s website](https://www.fiscal.treasury.gov/ussgl/resources-g-invoicing-program-guide.html). Detailed instructions for processing IRS agreements through G-Invoicing are located on the Procurement SharePoint site.

7. This IRM includes accounting guidance for recording and transferring expenses between the IFS Direct Fund and Reimbursable Fund accounts.


**1.33.3.1.2** **(08-27-2025)**

#### Authorities

1. The authorities for this IRM include:



1. [The Antideficiency Act, Pub. L. 97-258, 96 Stat. 923,31 USC 1341-1342](https://uscode.house.gov/view.xhtml?req=(title%3A31%20section%3A1341%20edition%3Aprelim)%20)

2. [The Economy Act of 1933, (31 USC 1535-1536)](https://uscode.house.gov/view.xhtml?req=31+USC+1535&f=treesort&fq=true&num=159&hl=true&edition=prelim&granuleId=USC-prelim-title31-section1535)

3. [Stafford Disaster Relief and Emergency Assistance Act (Pub. L. 100-707, 42 USC 5147)](https://www.fema.gov/disaster/stafford-act)

4. [The Intergovernmental Cooperation Act of 1968, (31 USC 6505)](https://uscode.house.gov/view.xhtml?req=31+USC+6505&f=treesort&fq=true&num=8&hl=true&edition=prelim&granuleId=USC-prelim-title31-section6505)

5. [TFM Chapter 4700, Federal Entity Reporting Requirements](https://tfx.treasury.gov/tfm/volume1/part2/chapter-4700-federal-entity-reporting-requirements-financial-report-united-states)

6. OMB Circular A-11, Part 4, Section 150


**1.33.3.1.3** **(07-13-2023)**

#### Responsibilities

1. This section provides funds control responsibilities for:



01. CFO and Deputy CFO

02. Financial Management Systems Office

03. Associate CFO for Corporate Budget and Deputy Associate CFO for Corporate Budget

04. Budget Execution Office

05. Cost and User Fees Office

06. Senior Associate CFO for Financial Management

07. Associate CFO for Revenue Financial Accounting

08. Associate CFO for Corporate Accounting

09. Financial Reporting and Analysis Office

10. Government Payables and Funds Management

11. Business Units


**1.33.3.1.3.1** **(07-13-2023)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for:



1. Providing oversight and accountability for the IRS reimbursable program.

2. Establishing the guidelines, overseeing and approving the Reimbursable Operating Guidelines (ROG).

3. Approving and issuing the IRS financial management guidance governing the reimbursable program.


**1.33.3.1.3.2** **(08-27-2025)**

##### Financial Management Systems Office

1. The Financial Management Systems office is responsible for:



1. Serving as the owner of the IRS’s financial management systems and ensuring compliance with accounting standards and internal controls per the CFO Act; FASAB; Treasury; OMB; federal financial system requirements; and other financial requirements.

2. Overseeing the IRS's data integrity, user security controls for IFS Operations and maintenance, and the fiscal year-end close.

3. Establishing and maintaining the IRS internal financial management systems policies and procedures.

4. Serving as the IRS G-Invoicing owner on systems integration necessary to conform to the Fiscal Service G-Invoicing Platform requirements and other systems requirements.

5. Issuing ongoing G-Invoicing communications and status reporting to the business unit finance community.

6. Ensuring IFS G-Invoicing related system user guides and training materials are available to the reimbursable community.

7. Troubleshooting G-Invoicing issues.

8. Assisting business unit and CB staff in obtaining proper access to G-Invoicing and IFS.


**1.33.3.1.3.3** **(08-27-2025)**

##### Associate CFO for Corporate Budget and Deputy Associate CFO for Corporate Budget

1. The Associate CFO for Corporate Budget and Deputy Associate CFO for Corporate Budget are responsible for:



1. Ensuring effective internal controls are in place to maintain the integrity of the reimbursable program.

2. Ensuring the IRS does not violate the ADA at the agency level.


**1.33.3.1.3.3.1** **(08-27-2025)**

###### Budget Execution Office

1. The Budget Execution office is responsible for:



01. Developing and implementing the Service’s administrative policies and procedures governing the reimbursable program such as this IRM.

02. Providing oversight of the execution of the reimbursable program as a whole and of all reimbursable agreements.

03. Preparing the reimbursable program fiscal year overhead rate memo and cost templates.

04. Creating, requesting and maintaining financial codes to track reimbursable agreements.

05. Establishing the IFS apportionment levels.

06. Reviewing and approving business unit reimbursable agreements, and cost estimates.

07. Reviewing and posting the forecast of revenue and allocating budget/ Full-Time Equivalents (FTEs) in IFS for non G-Invoicing agreements.

08. Reviewing and approving sales orders and allocating budget/FTEs in IFS for G-Invoicing agreements.

09. Assessing whether particular reimbursable agreements should be reviewed by the Financial Reporting and Analysis office to ensure budget reporting and analysis requirements are in compliance.

10. Responding to Treasury, OMB, Congress, the Government Accountability Office (GAO), Treasury Inspector General of Tax Administration, the IRS Internal Controls Office, and other stakeholders on issues related to reimbursables.

11. Monitoring apportionment availability to ensure reimbursable earnings do not exceed apportionments and requesting appropriate apportionment increases if warranted.

12. Developing reimbursable budget projections for the next fiscal year to support the reimbursable budget formulation and apportionment processes.

13. Supporting reimbursable year-end close activities.


**1.33.3.1.3.3.2** **(08-27-2025)**

###### Cost and User Fees Office

1. The Cost and User Fees office is responsible for:



1. Developing the reimbursable overhead costing methodology and fiscal year overhead rate.

2. Establishing and maintaining appropriate IRS Cost and User Fees office policies and procedures.

3. Advising business units on standards for reimbursable agreement cost estimating and accounting methodologies and requirements.

4. Establishing and updating reimbursable agreement funded program codes in IFS.


**1.33.3.1.3.4** **(08-27-2025)**

##### Senior Associate CFO for Financial Management

1. The Senior Associate CFO for Financial Management provides executive direction for the Financial Management organization, including administering, monitoring and reporting on federal and non-federal reimbursable resources and collections.


**1.33.3.1.3.4.1** **(07-13-2023)**

###### Associate CFO for Corporate Accounting

1. The Associate CFO for Corporate Accounting is responsible for:



1. IRS financial reporting and ensuring compliance with federal financial reporting requirements.


**1.33.3.1.3.4.1.1** **(07-13-2023)**

###### Financial Reporting and Analysis Office

1. The Financial Reporting and Analysis office is responsible for:



1. Monitoring, reviewing, and analyzing reimbursable activity for the IRS financial statement reports and Standard General Ledger (SGL) accounts.

2. Providing guidance on reimbursable financial reporting matters, as appropriate, through its CB and Government Payables and Funds Management (GP&FM) office counterparts.

3. Reviewing and approving new agreements identified by CB that may require billing arrangements that are outside of the traditional monthly or quarterly billing arrangements. For example, some agreements may require more frequent, pre-determined cycle payments.


**1.33.3.1.3.4.1.2** **(07-13-2023)**

###### Government Payables and Funds Management Office

1. The GP&FM office is responsible for:



1. Verifying that an approved, fully signed agreement is received prior to processing any billing.

2. Monitoring individual project earnings statuses and following up with business units when earnings and billing frequency are noncompliant with agreement terms and conditions.

3. Reviewing, posting, billing and collecting project earnings parked in IFS by the business units.

4. Validating the accuracy of submitted earnings documents (Form FV50).

5. Informing the Servicewide reimbursables team (SRT) and the business unit reimbursable coordinator when advance payments are received by the GP&FM office.

6. Ensuring each agreement contains a valid customer number and obtaining new customer numbers when one has not been established.

7. Maintaining all submitted documents in respective project files.


**1.33.3.1.3.5** **(08-27-2025)**

##### Business Units

1. Business units are responsible for the financial oversight, management, and funds control of their respective reimbursable agreements. General responsibilities include:



01. Ensuring a binding agreement is authorized between the IRS, as the seller, and the customer, as the buyer, before reimbursable work begins.

02. Ensuring agreement terms and conditions comply with appropriations law principles and are negotiated, finalized and signed by the buyer and seller delegated signing officials and reviewed and approved by CB.

03. Providing timely notice to trading partners when cost adjustments are necessary.

04. Notifying CB when revisions to the agreement cost estimate become necessary and then following up with the agreement modification package and revised cost estimates for review and approval by the SRT.

05. Maintaining agreement related documentation on receipt of reimbursable apportionment, statutory authorities, legal opinions, among other types of justification.

06. Applying basic accounting principles and practices to establish the agreement budget cost estimates, which may include the direct, indirect, overhead, forecast of revenue or sales order cost estimates, and the FTEs personnel estimate.

07. Monitoring and maintaining IFS reimbursable cost estimates and FTEs.

08. Making prompt corrections to accounting errors and misalignments.

09. Promptly parking accurate earnings in IFS according to the agreement billing frequency and addressing errors and misalignments on a monthly basis.

10. Maintaining an official, audit-worthy, record-keeping version, and final copy of the signed reimbursable agreement as well as all modifications and attachments.

11. Maintaining documentation to support earnings calculations.

12. Ensuring all reimbursable earnings and collections are received in accordance with the billing and payment frequency set in the agreement and comply with the balances owed.

13. Assigning appropriate roles to staff in G-Invoicing and ensuring appropriate IFS roles are requested.

14. Coordinating with and providing support to CFO on the year-end closeout of reimbursable projects.


**1.33.3.1.4** **(07-13-2023)**

#### Program Management and Review

1. **Program reports:** CB monitors financial plans periodically and through more comprehensive reviews of reports using IFS reports and queries, such as the status of available funds report and the reimbursables reports provided by the Financial Reporting and Analysis office. FPM responsibilities include using IFS to identify surpluses or deficits early, so that the IRS can optimize resource use.

2. **Program effectiveness:**To monitor and manage the IRS reimbursable resources, business units participate in several CB financial reviews that take place after the close of the second quarter. These include the midyear review and the uncommitted balances reviews. CB provides specialized guidance and procedures to follow on these types of review processes. The purpose of these reviews is to:



1. Evaluate the timely obligation of reimbursable project services’ costs and report progress on reimbursable collection activities, whether on a monthly basis or other billing and payment frequency.

2. Assess increase/decrease modification plans based on budget to collections standings and trends.

3. Finalize reimbursable spend plans and agreement closing projections.


3. **Program planning:** In Q4, CB requests reimbursable estimates for the following fiscal year from the business unit finance offices to develop initial apportionment estimates.


**1.33.3.1.5** **(07-13-2023)**

#### Program Controls

1. Business unit DFOs and FPMs have funds control responsibility for their reimbursable program financial plans. During the execution phase of the budget cycle, DFOs and FPMs must maintain monthly financial oversight of agreement budget allocations compared to expenditures for services. Conducting monthly, quarterly, and pre-year-end close status reviews of plans is recommended to ensure expenditures do not exceed budget availability. See _IRM 1.33.3.2.1_, Reimbursable Plan Management.

2. IFS is the system of record for CB, DFOs and FPMs for managing budgetary resources effectively. Availability controls are integrated into system rules to prevent the IRS from exceeding its budget authority at the fund level.


**1.33.3.1.6** **(08-27-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to the ROG.



01. **Acceptance** \- The official signing of an agreement by a cognizant federal official with delegated authority to commit and/or their contractors to perform reimbursable work.

02. **Account Symbol (also known as the Treasury Account Symbol)** \- A Treasury Account Symbol (TAS) is an identification code assigned by the Department of the Treasury (Treasury), in collaboration with the OMB and the owner agency, to an individual appropriation, receipt, or other fund account. For more information on account symbols and titles, Fiscal Service issues a Treasury Financial Manual supplement known as the [Federal Account Symbols and Titles: The FAST Book.](https://www.fiscal.treasury.gov/reference-guidance/fast-book/)

03. **Agency Location Code (ALC)** \- The agreement ALC code and description identifies the accounting reports and documents prepared by or for agency accounting stations and the Treasury financial centers.

04. **Agreement** \- An agreement is a written arrangement between two or more federal agencies to document the parties’ understanding of their respective roles and responsibilities in connection with a federal program or project. The agreement may take the form of an Agency Participation Agreement, Interagency Agreement, Memorandum of Agreement, Memorandum of Understanding or other similar document.

05. **Agreement period (period of performance)** \- The total amount of time during which the federal buyer authorizes the seller to complete the approved work of the project described in the agreement.

06. **Apportionment** \- A funds allocation plan, approved by OMB, to spend resources provided by one of the annual appropriations acts, a supplemental appropriations act, a continuing resolution, or a permanent law (mandatory appropriations). Resources are apportioned by Treasury Appropriation Fund Symbol (TAFS), also known as TA). The apportionment identifies amounts available for obligation and expenditure. It specifies and limits the obligations that may be incurred and expenditures made (or makes other limitations, as appropriate) for specified time periods, programs, activities, projects, objects or any combination thereof. An apportionment may be further subdivided by an agency into allotments, sub-allotments and allocations.

07. **Appropriation** \- A provision of law (not necessarily in an appropriations act) authorizing the **obligation and** expenditure of funds for a given purpose. Usually, but not always, an appropriations act provides budget authority and funds to operate for the full fiscal year. The IRS funding might come in its regular annual appropriation act, an omnibus act, a supplemental appropriation, a continuing resolution, or pursuant to a permanent appropriation. In IFS, an appropriation is represented by the "Application of Funds" code and may be a single fund or a combination of many IFS funds (see sub-appropriation).

08. **Binding agreement** \- A binding agreement is defined as an agreement on both General Terms & Conditions and an Order, signed by all parties.

09. **Bona-fide needs rule** \- The principle that a fiscal year appropriation may be used only for a legitimate, or bona fide, need, arising in, or in some cases arising prior to but continuing to exist in, the fiscal year for which the appropriation was made. Title 31 U.S. Code Section 1502(a) (the bona fide needs statute) provides: "The balance of an appropriation or fund limited for obligation to a definite period is available only for payment of expenses properly incurred during the period of availability or to complete contracts properly made within that period of availability and obligated consistent with section 1501 of this title. However, the appropriation or fund is not available for expenditure for a period beyond the period otherwise authorized by law."

10. **Budget authority** \- The authority provided by law to incur financial obligations that will result in outlays. Specific forms of budget authority include appropriations, borrowing authority, contract authority and spending authority from offsetting receipts and collections.

11. **Budgetary resources** \- For federal customers, the reimbursable agreement provides the budgetary resource. For non-federal customers, the reimbursable agreement and the advance payment(s) received for unfilled orders provide the budgetary resource.

12. **Buyer** \- The general term used for the Federal Program Agency (FPA) trading partner or customer that is purchasing goods and/or services for all types of intragovernmental activity. The buyer is the requesting agency.

13. **Collection** \- Money collected by the Federal Government and recorded as a receipt, an offsetting collection or an offsetting receipt.

14. **Continuing resolution (CR)** \- An appropriation act that provides budget authority for federal agencies, specific activities, or both to continue operations, usually for a specific duration when Congress and the President have not completed action on the regular appropriation acts by the beginning of the fiscal year. A CR usually specifies a maximum rate at which the obligations may be incurred based on levels specified in the resolution. When the IRS is under a CR, CB publishes special CR operating procedures on the CFO Website.

15. **Division finance officer (DFO)** \- The person who has been delegated by their division commissioner or chief with full responsibility for its financial plan, including overseeing funds control and managing all phases of the budget cycle. See also financial plan manager.

16. **Expenditure** \- The actual spending of money; an outlay. The definition does not mention receipt of goods or services.

17. **Federal Program Agency (FPA)** \- A permanent or semi-permanent organization of government that is responsible for the oversight and administration of specific functions.

18. **Financial plan** \- A subdivision of funds in IFS, which may be further subdivided into fund centers. Typically, there is a one-to-one relationship of financial plan to business unit, but a few business units manage multiple financial plans. See the financial plans table in the Financial Management Codes Handbook found on the **CFO website**.

19. **Financial plan manager** \- The person responsible for day-to-day operations of monitoring and controlling a financial plan’s funds in the execution phase of the budget cycle.

20. **Fiscal Service (FS) Form 7600A** \- General Terms & Conditions (GT&C), Agreement Between Federal Program Agencies for Intragovernmental Reimbursable, Buy/Sell Activity. The GT&C defines statements of fact, intentions, responsibilities, support, services, procedures, matters of coordination, and estimates agreed to by the signatories. Fiscal Service developed the form and instructions for use governmentwide by Buy/Sell FPAs. This form is the first section and the FS 7600B, described below is the second. Standard data elements are required to be completed for the exchange between FPAs to result in a binding agreement.

21. **Fiscal Service (FS) Form 7600B** \- Order, Agreement Between Federal Program Agencies for Intragovernmental Reimbursable, Buy/Sell Activity. The Order contains more detailed accounting exchange data, allows the servicing agency to report on the total cost estimate in relation to orders completed and balances remaining to accomplish services and redress costs. See also: _IRM 1.33.3.1.8_, Related Resources.

22. **Fiscal year** \- The federal government’s accounting period, which begins on October 1 and ends on September 30, and is designated by the calendar year in which it ends.

23. **Forecast of revenue** \- The forecast of revenue is the business unit determination of the appropriation or line-by-line accounting breakout of the agreement direct, indirect, and overhead cost estimate. CB provides a standard template for use by business units. This definition applies to non-G-Invoicing agreements.

24. **Form 14417, Reimbursable Agreement – Non-Federal Entities** \- Non-federal entities include state, local, foreign governments, and, non-governmental entities. This form is the standard template and communication tool between the buyer and seller and enables the two to agree on data elements and terms of the reimbursable transaction before business begins. Form 14417, Reimbursable Agreement - Non-Federal Entities can be accessed on the IRS Publishing website.

25. **Full-time equivalent (FTE)** \- The basic measure of the employment levels used in the budget. It is the total number of regular, straight-time hours (that is, not including overtime or holiday hours) worked by employees divided by the number of compensable hours applicable to each fiscal year. Annual leave, sick leave, compensatory time off and other approved leave categories are considered hours worked for purposes of defining full-time equivalent employment.

26. **G-Invoicing** \- An online platform for all entity staff involved with IGT reimbursable activity (including funding officials, program officials, and payment approvers) to originate and settle Buy/Sell Interagency Agreements (IAAs) electronically. Entities use G-Invoicing to establish and maintain their agreement on the funding terms and the accounting treatment of their reimbursable activity, and to exchange that data with one another for consistent financial reporting.

27. **Integrated Financial System (IFS)** \- The administrative accounting system used by the IRS. IFS is composed of four modules: Budget Control System (BCS), Materials Management (MM), Financial Accounting (FIA) and Controlling (CO). Key features of IFS include integrated modules covering many business functions, real-time data entry, online information, drill-down capability, enhanced reporting capability and simplified research. All reimbursable transactions, such as forecast of revenue, sales orders, and reimbursable earnings must be recorded in IFS.

28. **Internal Controls** \- The steps the IRS takes to provide reasonable assurance that, among other things, obligations and costs are in compliance with applicable regulations and laws; funds and property, and other assets, are safeguarded against waste, loss, unauthorized use, or misappropriation; and revenues and expenditures applicable to agency operations are properly accounted for and recorded.

29. **Intragovernmental Payment and Collection (IPAC)** \- The Bureau of the Fiscal Service’s system that provides a standardized mechanism for Federal Program Agencies to transfer funds electronically from one agency to another.

30. **Non-Federal entity agreements** \- Non-federal entities are self-sustaining organizations, incorporated or unincorporated, that are not an agency or instrumentality of the federal government. These may include states, local governments, Indian tribal governments, institutions of higher education, foreign governments, and private organizations. Form 14417- Reimbursable Agreement - Non-Federal Entities is the standard form completed between the two parties.

31. **Obligation** \- A definite commitment that creates a legal liability of the government for the payment of goods and services ordered or received, or a legal duty on the part of the United States that could mature into a legal liability by virtue of actions on the part of the other party beyond the control of the United States. Budgetary resources must be available before obligations can legally be incurred.

32. **Reimbursable earnings** \- Reimbursable earnings are recorded in IFS after reimbursable work has been performed and are based on the actual cost of the work performed. The FV50-BZ/BG transaction is used to record these costs.

33. **Reimbursable obligation** \- An obligation financed by offsetting collections credited to an expenditure account in payment for goods and services provided by that account.

34. **Reimbursable work** \- Work or services performed for another federal or non-federal customer, with the cost of performing the work reimbursed by the buyer. The IRS, as the seller, is compensated by an offsetting collection known as a reimbursement, which may be credited as authorized by law to the appropriation or the IRS fund account. Reimbursable work performed by the IRS for buyers is considered to be part of the buyer’s direct mission responsibility and not the IRS’s.

35. **Sales Order (SO)** \- A document that is generated by the seller to authorize the sale of products or services on receipt of the buyer’s order. Business units use the SO to forecast or track sales and the specifics of the agreement such as period of performance, description and other details of the order. It is considered parallel to the Forecast of Revenue and aligns with the G-Invoicing Platform for uploads.

36. **Seller** \- The general term used for a trading partner that is providing goods and/or services. The seller is also the servicing agency. For all reimbursable agreements discussed in this guidance, the IRS is the seller.

37. **Servicewide Reimbursables Team (SRT)** \- The individual(s) designated by CB, Budget Execution to ensure at the staff level that the reimbursable responsibilities of the Associate CFO, CB, are carried out.

38. **Taxpayer Identification Number (TIN)** \- An identification number used by the IRS in the administration of tax laws. It is either a Social Security Number (SSN) or a unique nine-digit number issued by the IRS. The TIN number for the IRS is 52-1782822.

39. **Trading partner** \- A federal entity that is party to Intragovernmental Transactions (IGT) with another federal entity. Trading partners are two federal entities engaged in IGT activity and are known as the buyer and seller.

40. **Treasury Financial Manual (TFM)** \- The manual issued by Fiscal Service containing procedures to be observed by all agencies, Federal Reserve Banks, and ﬁnancial institutions with respect to payments, collections, central accounting, ﬁnancial reporting, and other governmentwide ﬁscal responsibilities of the Department of the Treasury.


**1.33.3.1.7** **(07-13-2023)**

#### Acronyms

1. A select list of acronyms and abbreviations are referenced for budget execution.




| Acronym | Explanation |
| :-: | :-: |
| ADA | Antideficiency Act |
| BETC | Business Event Type Code |
| CB | Corporate Budget |
| DFO | Division Finance Officer |
| FPM | Financial Plan Manager |
| FTE | Full-Time Equivalent |
| G-Invoicing | Government Invoicing |
| GP&FM | Government Payables and Funds Management |
| IAA | Interagency Agreement |
| IFS | Integrated Financial System |
| IGT | Intragovernmental Transaction |
| IPAC | Intragovernmental Payment and Collection System |
| IRM | Internal Revenue Manual |
| MOU | Memorandum of Understanding |
| OMB | Office of Management and Budget |
| ROG | Reimbursable Operating Guidelines |
| SRT | Servicewide Reimbursables Team |
| TAS | Treasury Account Symbol |
| USC | U.S. Code |
| WBS | Work Breakdown Structure |


**1.33.3.1.8** **(08-27-2025)**

#### Related Resources

1. Related resources for this IRM include:



01. [Federal Entity Reporting Requirements for the Financial Report of the U.S. Government](https://tfx.treasury.gov/tfm/volume1/part2/chapter-4700-federal-entity-reporting-requirements-financial-report-united-states)

02. [Bureau of the Fiscal Service-Forms](https://https//www.fiscal.treasury.gov/g-invoice/resources.html)

03. [Bureau of the Fiscal Service-TFM Bulletins](https://tfx.treasury.gov/tfm/bulletins)

04. [Bureau of the Fiscal Service-Federal Account System and Titles (FAST) Book I](https://fiscal.treasury.gov/reference-guidance/fast-book/)

05. [Bureau of the Fiscal Service-Financial Management and Budget Standardization](https://fiscal.treasury.gov/financial-management-budget-standardization/)

06. [Bureau of the Fiscal Service-G-Invoicing Program Guide](https://www.fiscal.treasury.gov/ussgl/resources-g-invoicing-program-guide.html)

07. [Treasury Financial Manual Chapter 4700, Appendix 8, Intragovernmental Transactions (IGT) Buy/Sell](https://tfm.https//tfx.treasury.gov/tfm/volume1/part2/chapter-4700-federal-entity-reporting-requirements-financial-report-united-states)

08. [FASAB, SFFAS No. 4, Managerial Cost Accounting Concepts and Standards for the Federal Government,](http://files.fasab.gov/pdffiles/handbook_sffas_4.pdf)

09. [IPAC, TAS, BETC, and TAS Components](https://sam.for.fiscal.treasury.gov/sampublic/info/tasbetc.htm)

10. [Federal Accounting Standards Advisory Board, Statement of Federal Financial Accounting Standards](http://files.fasab.gov/pdffiles/handbook_sffas_4.pdf)

11. Financial Management Code Handbook

12. Continuing Resolution operations and guidance

13. [GAO's Principles of Federal Appropriations Law (The Red Book)](https://www.gao.gov/legal/appropriations-law/red-book)

14. IRM 1.1.21, Chief Financial Officer

15. IRM 1.33.4, Financial Operating Guidelines

16. The CB IAA SharePoint Site

17. IRS CB Reimbursables Handbook for Interagency & Non Federal Agreements (IRS as Seller)

18. G-Invoicing Work Step Instructions


**1.33.3.2** **(07-13-2023)**

### Apportionments

1. To support the development of the initial apportionment request for the next fiscal year, CB requires business units to provide reimbursable plan estimates based on a defined costing methodology. The estimate factors in new starts, cancellations, and renewals. These estimates are due at the beginning of fourth quarter (Q4) of the current fiscal year.

2. CB submits the Apportionment and Reapportionment Schedule (SF-132) to OMB for an initial apportionment for the new year.

3. After OMB approval, CB completes a step-down allocation from the appropriation to apportionment levels. Once each agreement has been approved and final signed by both FPAs (buyer/seller), then the budget is sub-allocated to the authority level by accounting string and becomes ready for obligation activity.

4. Reapportionments may be requested for unexpected cost increases such as increases to FEMA agreements for disaster assistance. Significant increases that may result in the need for an increased apportionment should be identified as far in advance as possible. It may take several weeks to secure OMB approval for reapportionments.

5. Business unit plan managers should review reimbursable funding projections and identify potential shortfalls in projections and then report to the SRT analyst. The SRT will review available apportionment balances and determine whether funds are available to cover the shortfall.


**1.33.3.2.1** **(08-27-2025)**

#### Reimbursable Plan Management

1. Business units must ensure agreements are developed, negotiated properly, and cleared in accordance with guidelines. When approved, the business unit manages plan performance based on budget authority, services provided, billing frequency, and other requirements.

2. The business unit should submit earnings per the billing frequency outlined on the agreement and monitor the earnings on an ongoing basis to ensure the full cost of reimbursable work is collected.

3. When a business unit reimbursable plan manager serves as a lead project coordinator for several business units involved in the project and costing, there should be coordination with each participating business unit finance office. An advance plan should be considered to review monthly collections compared to the budget and forecasted line items as each month unfolds. Each finance office is responsible for maintaining their monthly, quarterly, and projected year-end close line-by-line accounting and reconciliation.

4. FPMs and reimbursable plan managers must maintain financial oversight of these areas:



1. **Reimbursables Knowledge Base and Training:** To manage the plan effectively, analysts should develop a knowledge base of applicable TFMs, Fiscal Service G-Invoicing resources and training opportunities, the IRS IRMs, CB guidance, handbooks, standard operating procedures, work-step instructions, among other supplemental materials.

2. **Effective Communications:** Facilitate frequent communications with federal and non-federal entities, business unit program and finance offices, CFO reimbursables subject matter experts, and the proper Buy/Sell signing officials on approving agreement packages.

3. **Pre-Year-end Closing Requirements:** Initiate pre-year-end closing requirements by contacting federal and non-federal entity buyers on monthly, quarterly, and projected year-end close results and trending. Coordinate final September reimbursable work and estimates. Plan requirements for accounting adjustments, increase modifications or notifications to decrease or de-obligate funds.


5. Each fiscal year, business units must report to CB on the following budget cycle components involving reimbursable budgets, collections status, agreement signing officials, reimbursable tracking and coding, and year-end closing estimates:



1. Reimbursable apportionment estimates by business unit.

2. Congressional Justification cost estimates for reimbursables by business unit.

3. Annual updates for business unit delegated signing officials.

4. New fiscal year updates on funded program codes.

5. Business unit midyear review of reimbursable projects.

6. Business unit uncommitted reviews of reimbursables.

7. Year-end review estimates and closing activities for reimbursables.


**1.33.3.2.2** **(08-27-2025)**

#### Agreement Budget Authority Alignment

1. Business units must maintain a monthly and quarterly status on the agreement budget authority and monitor earnings based on the billing frequency of the FS Form 7600B and payment status. The status confirms collections results and progress toward meeting 100% of earnings.

2. If monthly and or quarterly earnings fall short of projections or billing cycle estimates, the business unit finance office will coordinate on any actionable requirements to stay within the budget authority assigned.

3. Any administrative modification, such as accounting code changes or deobligations, should be addressed promptly to ensure accurate earnings are posted in IFS.

4. The GP&FM office anticipates earnings will be received according to the agreement billing frequency specified on the FS Form 7600B. If monthly schedules are missed and earnings are delayed, finance office subject matter expert(s) should contact the GP&FM office to advise of delay. The GP&FM office will periodically contact the finance office subject matter expert(s) to follow-up on an action plan to catch up the past due earnings.

5. Year-end earnings must reach 100% of the reimbursables budget by the date established in the year-end close guidelines. If year-end earnings will not reach 100%, the reimbursables budget and forecast of revenue/sales order must be adjusted to match the final earnings.


**1.33.3.3** **(07-13-2023)**

### Financial Policies

1. Business units must ensure reimbursable services are accomplished in accordance with established laws, regulations, and provisions of the respective reimbursable agreement(s). There are four main financial policy categories for reimbursables:



1. Execution and funds control of reimbursable services.

2. Operational policies and procedures.

3. IFS budget and accounting procedures.

4. Closeout of reimbursable agreements.


**1.33.3.3.1** **(07-13-2023)**

#### Execution and Funds Control of Reimbursable Services

1. The below funds control requirements must be met before an agreement is approved and accepted:



1. Receipt of budget resources from an OMB apportionment and availability of reimbursable authority.

2. Expenditures against reimbursable budget authority or availability are limited to the lesser of the approved apportionment or the budgetary resources made available. Expenditures cannot exceed the agreement limitations and are managed and accounted for according to the provisions of the agreement.

3. Federal agreements are subject to the provisions of 31 U.S.C. 1501, Documentary Evidence Requirements for Government Obligations and Procurement Guidance. Documents authorizing the performance of services must identify funding sources and comply with document retention standards.

4. Appropriation funding cited in the agreement is restricted to the purposes specified in the agreement. 31 U.S.C. 1301 states an appropriation may only be used for the purposes contained in the appropriation. Unless provided for by law, the IRS cannot finance reimbursable services from its own appropriations and it cannot finance reimbursable work from a buyer or another entity's fund. If funding and reimbursement requirements are prescribed by law but are inconsistent with the IRS guidance, then legal requirements take precedence.

5. The agreement must specify that the buyer or customer is responsible and accountable for any financial consequences associated with the termination of services.

6. The buyer is responsible for making a determination on whether the work agreement and the specific period of performance in the agreement meets the **_bona fide_**, needs of the period of availability of the buyer’s appropriation. This includes a determination by the ordering agency of whether the requested work is severable or non-severable as required.


2. Before obligational authority to start reimbursable services can be acted on, these organizational funds control planning requirements must be in place.



01. IFS is the system of record that CB, DFOs, and FPMs must use to manage budgetary resources effectively. IFS includes availability controls to help prevent the IRS from exceeding its budget authority. Servicewide availability controls keep the IRS from over-obligating at the fund level.

02. IFS user roles, systems access, and security measures applicable to business unit reimbursables are detailed in IRM 1.35.24, Financial Accounting, Establishing IRS Commitments and Obligations.

03. CB has certified and approved the agreement cost estimates, and allocated budget authority.

04. The authorizing officials (buyer, seller, or non-federal entity) have approved the GT&C and Order agreement forms or the Form 14417, Reimbursable Agreement - Non-Federal Entities.

05. The billing and frequency timetable agrees with the agreement terms and conditions.

06. There has been a validation that reimbursable work costs, obligations, and expenditures for each agreement will not exceed the amount and limitations specified in the signed reimbursable agreement.

07. No costs can be incurred for performance of reimbursable work beyond the period of performance specified in the agreement.

08. Contractors cannot begin reimbursable work for non-IRS customers until they have obtained authorization from the responsible IRS contracting officer.

09. Business units must review funds availability before posting reimbursable expenses to be sure obligated balances will not result in negative availability.

10. Business units must establish cutoff dates prior to the end of the fiscal year to provide ample time to review, accept, obligate, distribute, and record reimbursable account coordination and closing with buyers.

11. The lead business unit and sub-units must coordinate on monthly costing to ensure the approved terms and conditions and orders are administered effectively.

12. Business units and FPMs managing reimbursable work must maintain an appropriate management control environment to provide sufficient advance notification of potential funding shortfalls to obtain additional funds to continue or determine when to end project services.


**1.33.3.3.2** **(07-13-2023)**

#### Operational Policies and Procedures

1. This section provides guidance on building cost estimates, the Fiscal Service G-Invoicing mandate, federal and non-federal agreement developmental stages, and the agreement clearance process.


**1.33.3.3.2.1** **(07-13-2023)**

##### Cost Estimate Standards and Procedures

1. Cost assignment methods must be consistent with the Federal Accounting Standards Advisory Board (FASAB) accounting standards.

2. One of the five standards for federal managerial cost accounting, as stated in the Statement of Federal Financial Accounting Standards (SFFAS), No. 4, Managerial Cost Accounting Standards and Concepts, is accumulating and reporting costs of activities on a regular basis to derive the full costs of government goods and/or services. The full cost of an output is the total amount of resources used to produce the output. This includes direct and indirect costs that contribute to the output, regardless of funding sources. The full cost of an output produced by a business unit is the sum of:



1. The cost of resources consumed by the business unit that directly or indirectly contribute to the output.

2. The cost of identifiable support services provided by sustaining the IRS business units.


3. When reimbursable projects use the same types of goods and/or services as direct-funded projects, the reimbursable project costs will use the same rates and consumption basis as the direct-funded projects.

4. Recognition of Earned Reimbursements: In accordance with the SFFAS No. 7, Accounting for Revenue and Other Financing Sources and Concepts for Reconciling Budgetary and Financial Accounting, “earned“ or “exchanged” revenues are created once the seller provides goods and/or services to the buyer for the amount negotiated in the agreement - meaning that the payment or revenue should not be recognized until costs are incurred from providing the goods and services.


**1.33.3.3.2.1.1** **(07-13-2023)**

###### Direct Costs

1. Direct costs are expenses that can be directly traced to a program, activity, product or service. For detailed information, refer to IRM 1.33.5.2.3.1, Managerial Costing. These costs generally result from the business unit execution of their reimbursable budgets, and may include these types of costs:



01. Salaries, including overtime, holiday pay, premium pay and awards, and other benefits for employees that work directly on products, services, and activities being performed under the reimbursable agreement.

02. Accrued annual leave and compensatory time.

03. Materials and supplies used in outputs, including postage and printing.

04. Travel, relocation and training costs.

05. Consulting and contractual services.

06. Enforcement expenses.

07. Automated data processing (ADP) or IT expenses.

08. Equipment and facilities.

09. Imputed costs of goods and services received from other government agencies.

10. Rent is traceable to business units and office space and generally allocated as secondary costs.

11. Any other costs that are directly attributable to the work outlined in the reimbursable agreement.


2. The costs for specific products and services are considered direct costs when the costs can be readily identified through accounting details.

3. Direct costs must be recorded under appropriate SGL accounts and align with budget and commitment line items.


**1.33.3.3.2.1.2** **(07-13-2023)**

###### Indirect and Overhead Costs

1. Indirect costs are the costs of resources that are jointly or commonly consumed by two or more business units' activities but are not specifically identifiable to a single product or service. Indirect costs include sustaining business unit labor costs that support the IRS as a whole. For detailed information, refer to _IRM 1.33.5.2.3.2, Managerial Costing_.

2. Indirect costs can be incurred within a business unit as a result of its own activities or when the business unit receives products or services generated by other business units. The business unit’s indirect costs are assigned internally in accordance with the Cost and User Fees cost allocation methodologies.

3. Most indirect costs accumulate within identifiable business units. However, some costs such as depreciation and facilities costs cannot be linked to an identifiable business unit. In those instances, such costs are allocated based on cost allocation methodologies.

4. Indirect costs must be recorded to specific SGL accounts that align to budget and commitment line items.

5. The Cost and User Fees office calculates the corporate overhead rate annually. The rate calculation is based on cost accounting data from the latest audited financial statement data and is calculated by dividing indirect costs by direct costs.

6. The overhead rate is multiplied by direct labor and benefits to calculate the overhead cost for each agreement. Direct labor costs are defined as salary and benefit costs for the specific services provided through the reimbursable agreement.


**1.33.3.3.2.1.3** **(08-27-2025)**

###### Full Cost Estimating

1. Determining the cost estimate of a reimbursable agreement requires the identification of the projected full cost of the products and services that are to be provided to the buyer. Each reimbursable project is unique and determining the cost estimate can vary based on the requirements of the project. See _IRM 1.33.5,_ _Managerial Costing_, for further information on full cost recognition.

2. The [SFFAS 4: Managerial Cost Accounting Standards and Concepts](https://irm.web.irs.gov/common/scripts/ExitScript.asp?GOTO=https://fasab.gov/accounting-standards/document-by-chapter/) establishes internal costing standards to accurately measure and manage the cost of federal programs. It provides an order of preference framework for cost assignment. The cost assignment process links accumulated costs with cost objects in specific reporting periods. There are three methods of cost assignment:



1. Trace costs directly wherever feasible and economically practicable.

2. Assign costs on a cause-and-effect basis.

3. Allocate costs on a reasonable and consistent basis.


3. These methods should be used by business units to develop full-cost projections for the cost of the products and/or services provided by reimbursable project(s). This includes labor, non-labor, and indirect/overhead costs.

4. Business units must make buyers aware of the requirement to include overhead costs in their agreements and should work with them to develop initial cost estimates. In many cases, negotiation of overhead costs adds time to the process. Business units should begin this process months before the agreement starts.

5. The business unit must calculate direct labor and non-labor costs using a methodology that conforms to the guidance outlined above.



1. The business unit must complete CB’s reimbursable cost estimates template to document costs. The template is located on the CB, Budget Execution SharePoint Site in the fiscal year folder.

2. Direct costs should be documented and based on a sound methodology. Business units can submit supplemental worksheets with more detailed calculations along with the CB worksheet.

3. Rolling over cost estimates from the previous year is not an acceptable methodology. Cost estimates must be updated every time a new agreement is negotiated.


6. The overhead rate developed by the Cost and User Fees office is included on CB’s reimbursable cost estimates template.

7. All overhead earnings are posted to a specific accounting string determined by CB and disseminated by the SRT.

8. Cost increases that occur during the performance of the agreement must also be recovered, unless the SRT determines them to be immaterial, meaning that the administrative cost of collecting the increase is more than the amount of the increase.

9. Cost estimates for annually recurring reimbursable projects should be recalculated each year.


**1.33.3.3.2.1.4** **(08-27-2025)**

###### Approval of Direct, Indirect, and Overhead Costs

1. The business units must submit the reimbursable cost estimates template to the SRT for review and approval.

2. A business unit may request a full or partial exemption from overhead costs for an agreement. Such exceptions are granted rarely and will require strong justification. All full or partial exemptions from overhead costs, to include projects that only charge non labor, must be approved by the Director, Budget Execution.


**1.33.3.3.2.2** **(08-27-2025)**

##### Agreements

1. There are two types of agreements under the SGL Accounts: federal and non-federal. Both intragovernmental, inter/intradepartmental agreements are encompassed in federal to federal agreements.


**1.33.3.3.2.3** **(08-27-2025)**

##### Agreement Statutory Authority

1. The Economy Act provides general authority to federal agencies to enter into reimbursable agreements; however, if more specific authority exists, it supersedes the Economy Act.

2. The IRS has numerous specific legal authorities to perform reimbursable work for other federal entities. Consistent with past Comptroller General decisions (e.g., B-285451.3/B-285451.4), the most specific legal authority applies to an agreement even if the authority is not specified in the agreement itself or by the federal agencies that are party to the agreement.

3. The IRS statutory authorities used to authorize services for non-federal entities are also very specialized legal authorities in most cases.


**1.33.3.3.2.4** **(08-27-2025)**

##### Federal G-Invoicing Program Mandate

1. The use of G-Invoicing has been mandated across the federal government. In October 2023, the IRS became fully compliant with the G-Invoicing mandate and Fiscal Service requirements. G-Invoicing is the comprehensive governmentwide solution to enhance federal financial management and improve the quality of buy/sell reporting by:



1. Providing a common platform to broker IGT Buy/Sell activity.

2. Establishing a Federal IGT Buy/Sell Data Standard.

3. Giving users transparent access to a common data repository of brokered transactions.

4. Working to reduce the number of IPAC adjustments in the Central Accounting and Reporting System (CARS).

5. Building a system that drives the reconciliation and elimination of IGT Buy/Sell activity from the Financial Report of the U.S. Government.


2. Fiscal Service is responsible for centrally administering the governmentwide implementation of the G-Invoicing Program mandate. It maintains the G-Invoicing website to inform governmentwide trading partners of TFM and Fiscal Service guidance, operational procedures, standard agreement forms and instructions, and G-Invoicing training opportunities. Refer to [G-Invoicing: Resources (treasury.gov)](https://www.fiscal.treasury.gov/g-invoice/resources.html#admin).

3. Trading partners must have accounting systems that meet the interface specifications for integrating with G-Invoicing to process federal agreements.

4. The [Fiscal Service G-Invoicing Rules of Engagement](https://fiscal.treasury.gov/g-invoice/) provides detailed guidance to assist trading partners in initiating and completing each of the four stages of the agreement processing events listed below.



1. Stage 1: GT&Cs

2. Stage 2: Orders

3. Stage 3: Performance Transactions

4. Stage 4: Fund Settlement


5. The [Fiscal Service G-Invoicing Program Guide for Basic Accounting and Reporting](https://fiscal.treasury.gov/ussgl/resources-g-invoicing-program-guide.html) provides comprehensive operational guidance.

6. The trading partner directory is housed on [Connect.gov](https://community.connect.gov/display/CrossAgencyExternal/G-Invoicing+-+Agency+Implementation+Plans) and contains updates on trading partner’s status regarding their transition to G-Invoicing.

7. Trading partners unable, from a systems integration standpoint, to transition to G-Invoicing are using pre-existing agreement policy and procedures until fully integrated with G-Invoicing.

8. The IFS accounting system continues to be the IRS’s system of record for the IRS accounting, with G-Invoicing being the web-based platform for active intragovernmental exchanges.


**1.33.3.3.2.5** **(08-27-2025)**

##### Federal Agreements

1. The IRS relies on the TFM, Appendix 8 standard guidance and Fiscal Service guidance, forms, and instructions on initiating federal IAAs. See _IRM 1.33.3.1.8_, Related Resources.

2. The IRS requires the use of FS Form 7600A, GT&C and 7600B, Order for all federal agreements. These forms are generated either electronically through G-Invoicing or completed manually on paper forms. For instructions in completing these forms, see [FS Form 7600A and Form 7600B Instructions](https://fiscal.treasury.gov/g-invoice/resources.html), which applies to IAAs that are created manually or through G-Invoicing.

3. The trading partner’s G-Invoicing status will drive how the IRS processes agreements.



1. **Federal to Federal Interagency Reimbursable Agreements (G-Invoicing Active)** \- A reimbursable agreement to provide a service for another FPA in exchange for reimbursement where both FPAs are systemically capable of successfully uploading and exchanging transactions under all G-Invoicing Processing Stages. Costs are accumulated by the seller and included in the performance of services costs sent to the buyer. After all monthly funds transfers, settlements, and IPACs are complete for the year, final closeout of the G-Invoicing agreement can occur.

2. **Federal to Federal Interagency Reimbursable Agreements (G-Invoicing Inactive)** \- A reimbursable agreement to provide a service for another FPA but either one or both FPAs have accounting systems that are systemically incapable of interfacing and exchanging transactions under one or more of the G-Invoicing Processing Stages. The FPAs use pre-existing procedures to complete reimbursable clearance packages. Costs are accumulated by the seller and included in the performance of services costs sent to the buyer. After the monthly funds transfers occur, there could be modifications to the agreement negotiated between the seller and buyer prior to the period of performance expiration and closeout.


4. The IRS also has certain IGT agreements that are recognized as being exempt from the G-Invoicing mandate due to the IRS systems interface conversion cost outweighing benefit.

5. Federal buyers are usually billed monthly after the work has been completed, with some exceptions.


**1.33.3.3.2.6** **(08-27-2025)**

##### Non-Federal Entity Agreements

1. The IRS requires the use of Form 14417, Reimbursable Agreement - Non-Federal Entities, to establish agreements with non-federal entities. This form includes certain basic data elements in common with the federal forms but facilitates the pre-payment of the entire cost estimate for the services to be provided. See Form 14417 - Reimbursable Agreement - Non-Federal Entities

2. Advance payments for the full cost estimate are required for agreements with state, local, and foreign governments, commercial organizations, and private businesses because their accounting systems do not interface with the federal government’s accounting system. Estimated costs are for planning purposes and can vary depending upon level of services. The final bills submitted to the customer will include actual costs. Depending upon the amount, either a refund is sent to the entity or a payment is sent to the IRS.

3. To comply with Executive Order – Modernizing Payments To and From America’s Banking Account, the GP&FM office requires electronic submission of reimbursable business accounting transactions, justifications, and documentation. Advance payment via ACH or credit card can be submitted through [Pay.gov](https://www.pay.gov/public/home) or submission via wire transfer is also acceptable.



> **Electronic ACH or credit card payments:**
>
> www.Pay.gov/public - instructions can be found at: Debt collection





> **Federal Wire Transfers:**
>
> US Treasury Routing ABA Number: 021030004, ALC: 20090003
>
> For international wire transfers use Swift Code FRNYUS33
>
> _Bank address:_
>
> FRB NY
>
> 33 Liberty Street
>
> New York, NY 10045
>
> The Financial Reporting and Analysis office may approve exceptions to the advance payment requirement.


**1.33.3.3.2.7** **(08-27-2025)**

##### Agreement Approval Process

1. The agreement approval process guidance is included in the IRS Corporate Budget Reimbursables Handbook. This comprehensive guide contains standard reimbursable management guidance for administering reimbursables programs at the business unit level.

2. There should be a binding agreement between the IRS and the buyer before performance of reimbursable work.

3. Business units should send all reimbursable agreements and supporting documentation (including a direct and indirect cost estimates) to the SRT for approval prior to sending the agreement to the buyer for signature.

4. The method of exchanging agreement clearance and approval packages for federal agreements depends on if the FPA is using G-Invoicing to prepare the FS Form 7600,GT&C.



1. For agreements processed through G-Invoicing, the business unit or buyer develops the FS Form 7600A, GT&C in the G-Invoicing application. The form is routed electronically to CB and the IRS program officials for review and approval. Once the trading partner signs, the agreement is finalized. For detailed instructions, refer to Work-Step Instructions and Job Aids for Interagency Agreements located on the Procurement in the Public Sector Resource Page under Interagency Agreements.

2. For agreements completed manually on paper forms, which includes non-federal agreements, the business unit uses pre-existing approval procedures. The business unit completes FS Form 7600A, GT&C /FS Form 7600B, Order or Form 14417 and submits the forms to the SRT for review. Once approved by the team, the agreement package is forwarded to the next level of clearance within the business unit before forwarding to the buyer for approval.


.



**1.33.3.3.2.7.1** **(07-13-2023)**

###### Agreement Authorizing Officials and Delegation Orders

1. An agreement is considered to be accepted when both trading partners have signed and are cognizant federal officials with delegated authority to commit agency resources to perform reimbursable work.

2. All business units executing reimbursable agreements with federal agencies, states, and other external stakeholders must comply with 1.2.2, Servicewide Delegations of Authority, (Delegation Order 1-62), Signing Agreements with Federal Program Agencies Intragovernmental Buy/Sell Reimbursable Transactions and Non-Federal Reimbursable Agreements.

3. If the implementing agreement, Memoranda of Understanding (MOU), or other agreement allows for the exchange of a taxpayer return or taxpayer return information, the document must be coordinated with Privacy, Governmental Liaison and Disclosure before the delegated authority may execute the agreement.


**1.33.3.3.2.8** **(08-27-2025)**

##### Agreement Modifications

1. Business units should renegotiate any projects that are expected to exceed agreement projections. If earnings are significantly lower than originally projected, the buyer should be notified and the IFS projections must be reduced.

2. The G-Invoicing platform retains electronic copies of the agreements but does not track the reasoning for the adjustment or modification on the forms. Documentation substantiating the nature and reason for adjustments and changes must be retained by the business unit owner of the agreement to support future audit activity.

3. Any administrative modification, such as accounting code changes, should be addressed promptly to ensure accurate earnings are posted in IFS.


**1.33.3.3.3** **(08-27-2025)**

#### IFS Budget and Accounting Procedures

1. This section provides guidance on financial codes, key transaction codes, recording projections and earnings in IFS.

2. Reimbursable earnings may be collected under a federal agreement with a billing frequency agreed to or an advance payment non-federal agreement where the full cost is due before work begins.


**1.33.3.3.3.1** **(07-13-2023)**

##### Financial Codes

1. You can find a complete list of all financial codes in the Financial Management Codes Handbook. The handbook is revised quarterly and is available on the CFO website.

2. All reimbursable projects must have a customer number and funded program code established. IFS transaction ZFPLIST, Funded Program List Report, contains a real-time list of funded program codes.


**1.33.3.3.3.1.1** **(07-13-2023)**

###### Customer Numbers

1. New customer numbers can be requested from the GP&FM office. To obtain a new customer number, submit a copy of the new project agreement to the GP&FM office contact or provide the trading partner’s TIN/EIN, business address, ALC, and TAS.


**1.33.3.3.3.1.2** **(07-13-2023)**

###### Funded Program Codes

1. Funded program codes are IFS data elements that collect expenditure data for specific projects. Either an internal order code or work breakdown structure (WBS) element populates the funded program field in IFS for reimbursable projects. All funded program codes for reimbursables begin with RA and are also referred to as the project numbers.

2. Internal order codes are unique nine-to-twelve-character alphanumeric codes (ex RA2025742/RA2025879GSA) used for non-federal reimbursable agreements and federal agreements where the trading partners are not ready to participate in G-Invoicing for Orders.

3. Work Breakdown Structure (WBS) elements are unique fourteen-to-seventeen-digit codes (ex RA.2025.808.01/RA.2025.399OIG.01) used for federal agreements where both trading partners are G-Invoicing ready for GT&Cs, Orders, Performance Transactions, and Settlement within the platform.

4. CB, in conjunction with the business units, determine which funded program codes are reinstated under the new fiscal year and those created for new projects during the course of the fiscal year.

5. CB sends the Cost and User Fees office requests to establish new funded program codes as needed.


**1.33.3.3.3.2** **(08-27-2025)**

##### IFS Transactions

1. The below IFS transactions are used to process reimbursables in IFS:



1. Create, modify, and view Forecast of Revenue (FMV1, FMV2, & FMV3)

2. Create, modify, and view Sales Orders (VA01, VA02, & VA03)

3. Transfer and reprogram Budget/FTE (FMBB)

4. Recognize Reimbursable Earnings (FV50 and FBV0 – BZ/BG)

5. Record Unbilled Revenue (FV50-BW)

6. Advance Payment Receipts (FB50 or F-29-DZ)

7. Establish Billing Document and Clear Payments (FB05-AD or DR and F-28-DZ)

8. Record and Clear Credit Memo (FB75-DG and F110-IP)


**1.33.3.3.3.3** **(08-27-2025)**

##### Forecast and Sales Order Processing

1. For agreements with federal trading partners processed through G-Invoicing:



1. The business unit must complete a Sales Order workbook, which contains a breakout of the project cost estimates, for SRT review. Refer to the Work-Step Instructions and Job Aids for Interagency Agreements posted on Procurements SharePoint site for detailed instructions.

2. The business unit enters the sales order in IFS for review and approval by CB, the business unit funding official and the business unit program official.

3. Once the Order is approved by the IRS and the trading partner, a copy of the FS Form 7600B, Order is downloaded from G-Invoicing.

4. CB releases (posts) the sales order and adds the budget/FTE in IFS.


2. For agreements with federal trading partners that use paper forms and those with non-federal entities, legacy procedures will be followed:



### Note:



Certain federal trading partners with recognized exemptions would also use pre-existing procedures.





1. The business unit must complete a Forecast of Revenue workbook, which contains a breakout of the project cost estimates. Refer to the IRS Corporate Budget Reimbursables Handbook for detailed instructions.

2. The business unit enters the forecast of revenue in IFS for review by CB.

3. CB posts the forecast of revenue and adds the budget/FTE in IFS.


3. After the steps above are completed, the business unit can park earnings in IFS.


**1.33.3.3.3.4** **(07-13-2023)**

##### Reimbursable Earnings (FV50)

1. Most reimbursable earnings are considered offsetting collections that should be identified with the IRS apportioned reimbursable authority. Reimbursable expenses are initially recorded against the direct fund appropriation codes ending with a "D" These expenses must be transferred to the reimbursable fund accounting string ending with an "R" using FV50 document types BZ/BG. When the expenses are moved under this transaction, it indicates or triggers a billing to be issued to the buyer.

2. Detailed Instructions for completing an FV50 (document type BZ) for non-G-invoicing agreements are located at: [GP&FM - Debt Collection Contact(sharepoint.com)](https://irsgov.sharepoint.com/sites/CFO/SitePages/Debt-Collection.aspx). Detailed instructions for completing an FV50 (document type BG) for G-Invoicing agreements are located at: Park, Post BG Documents.

3. The business unit parks the FV50 in IFS and completes a pdf document for submission to GP&FM: [\*CFO BFC DCU Reimbursable Program](https://www.irs.gov/irm/part1/cfo.bfc.dcu.reimbursable.program@irs.gov).

4. The GP&FM office assigns specific staff to each business unit’s reimbursable projects. The Reimbursable Project Inventory and contacts list is available at: Reimbursable Project Inventory.

5. The GP&FM accounting technician checks the parked document against the pdf submitted and posts the FV50 in IFS. GP&FM will contact the business unit for any corrections needed to process parked documents. GP&FM will make contacts following an established elevation schedule. If corrections are not received within the nine-day elevation process, the parked documents will be deleted and will need to be re-entered by the business unit.


**1.33.3.3.3.5** **(08-27-2025)**

##### Billing and Payment Processing

1. From the initial budget cost estimates to the final earnings transaction and closeout of the reimbursable project, the budget and accounting transactions should conform to one of two collections methods: the IPAC billing and payment process or the non-federal agreement advance payment process.



1. Except for non-federal entity agreements, which are paid in advance based on a lump sum estimate, all other agreements are billed monthly unless otherwise specified in the agreement. The monthly bill normally represents the prior month’s actual costs for services and is billed at the beginning of the next month. Since the actual costs of the final month of the fiscal year are not known until after the year closes, a September estimated amount is accounted for prior to the fiscal year-end closing procedures. It is not appropriate to simply divide the annual cost into equal monthly payments unless the cost of the work performed is consistent from month-to-month.

2. Advance payment billings are adjusted upwards/downwards as necessary as the project nears completion.

3. Federal agreements, whether interfaced with G-Invoicing or not, are processed using the IPAC network. However, G-Invoicing processed agreements follow a different work stream before reaching the IPAC fund settlement.

4. Non-G-Invoicing integrated agreements and advance payment agreements continue to follow pre-existing billing and payment procedures. These were processed through the GP&FM office and will continue to be maintained outside of G-Invoicing until further notice on the IRS G-Invoicing final implementation and effective date on startup. A few agreements have received G-Invoicing exemptions and would not be subject to conversion to G-Invoicing operational procedures.


**1.33.3.3.3.6** **(08-27-2025)**

##### Reports and Compliance

1. CB will periodically send out status of funds reports, inquire about the status of earnings, possible reductions to agreements, missing forecasts/sales orders and the status of agreements that have not been finalized.


**1.33.3.3.3.6.1** **(07-13-2023)**

###### IFS Reimbursable Status Reports

1. The following status reports support reimbursables monitoring and analysis:



1. Treasury Account Symbol (TAS) Search Report: ZTASBETCREP to validate the requesting agency TAS referenced on the FS Form 7600B.

2. Status of funds report: ZSOF ECC2 to check reimbursable fund alignment with project accounting line details.

3. Reimbursable Earnings Error Report: ZOFR013 to view earnings errors real-time.

4. Earmarked funds journal: S\_P99\_41000147 displays reimbursable projects for posted earnings and open balances.

5. Reimbursable audit report: ZOFR011 provides a summary of projects by customer and SGL accounts.

6. BW2900 SOAF reports provide historical FTE and budget statuses by fiscal year periods and various sorting options.


**1.33.3.3.3.6.2** **(08-27-2025)**

###### Monthly Reporting and Compliance

1. The validity of reimbursable collections data reported in the central accounts and published in the Federal Government’s Monthly Treasury Statement depends upon the accuracy of the monthly statements of transactions submitted by all departments and agencies. The timeliness of reports depends on strict compliance with Fiscal Service assigned deadlines, and the IRS monthly billing and collection deadlines.

2. Business unit compliance with the monthly reporting cycle is a critical to maintaining the IRS internal accounting controls. The IRS processes transactions according to formal IFS posting models. The posting models require certain transactions related to the monthly processing cycle be completed within the same month.

3. Late entries or those posted outside of the monthly cycle cause accounting relationships to become out-of-balance. Correcting an account misalignment requires the Financial Reporting and Analysis office to reconcile and complete adjustments before the IRS financial statements can be forwarded to Fiscal Service.


**1.33.3.4** **(07-13-2023)**

### Closeout of Reimbursable Agreements

1. Business units closing out reimbursable agreements at the end of the fiscal year must comply with the Corporate Budget Year-end Guidance and Year-end Responsibilities and Cutoff Dates. This guidance is provided on a fiscal year basis to assists business units with facilitating and monitoring their year-end close activities.

2. The process of closing out a reimbursable agreement will commence upon completion of the work or when the period of performance specified in the reimbursable agreement ends, whichever comes first.

3. Prior to closeout and within the cutoff dates agreed to between the buyer and seller, the IRS must notify the buyer of the agreement actual year to date costs and any late August/September estimates.


**1.33.3.5** **(08-27-2025)**

### Prior-Year Settlements and Refunds

1. In the first quarter of the subsequent fiscal year, the business units submit corrected FV50 documents to GP&FM that reflect actual costs for late August/September.

2. When final costs are known, the IRS must coordinate with the buyer to return unused balances. There can be unforeseen instances where either the federal buyer or seller has significantly under/overestimated the final agreement orders costs or the non-federal entity has overpaid invoices and expects a refund. If an overbilling has occurred, the impacted business units must ensure there is funding availability in the direct fund receiving the charge.

3. The Financial Reporting and Analysis office, CB, and the GP&FM office will weigh the amount of the claim or refund against the cost estimate involved in reopening IFS during a downtime and rebuilding the accounting to resettle the claim. If the claim or refund amount is approved, then Financial Management and CB will assist the business unit and FPM with the process.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-033-003#addtoany "Show all")

A2A