---
url: "https://www.irs.gov/irm/part1/irm_01-004-007"
title: "1.4.7 TE/GE Knowledge Management (KM) Administration | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-007#main-content)

- 1.4.7  [TE/GE Knowledge Management (KM) Administration](https://www.irs.gov/irm/part1/irm_01-004-007#id1)
  - 1.4.7.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-007#id2)
    - 1.4.7.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-007#id3)
    - 1.4.7.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-007#id4)
    - 1.4.7.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-007#id5)
      - 1.4.7.1.3.1  [Senior Manager](https://www.irs.gov/irm/part1/irm_01-004-007#id7)
      - 1.4.7.1.3.2  [KM Manager](https://www.irs.gov/irm/part1/irm_01-004-007#id8)
      - 1.4.7.1.3.3  [KM Lead](https://www.irs.gov/irm/part1/irm_01-004-007#id9)
      - 1.4.7.1.3.4  [Core Team Member](https://www.irs.gov/irm/part1/irm_01-004-007#id10)
      - 1.4.7.1.3.5  [Extended Core Team Member](https://www.irs.gov/irm/part1/irm_01-004-007#id11)
      - 1.4.7.1.3.6  [Communications & Liaison (C&L)](https://www.irs.gov/irm/part1/irm_01-004-007#id12)
      - 1.4.7.1.3.7  [TEGE Division Counsel (TEGEDC)](https://www.irs.gov/irm/part1/irm_01-004-007#id13)
      - 1.4.7.1.3.8  [Compliance, Planning and Classification (CP&C)](https://www.irs.gov/irm/part1/irm_01-004-007#id14)
    - 1.4.7.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-007#id15)
    - 1.4.7.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-007#id16)
    - 1.4.7.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-007#id17)
    - 1.4.7.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-007#id18)
  - 1.4.7.2  [KM Operating Principles / Guidelines](https://www.irs.gov/irm/part1/irm_01-004-007#id19)
    - 1.4.7.2.1  [Collaboration](https://www.irs.gov/irm/part1/irm_01-004-007#id20)
    - 1.4.7.2.2  [Identifying Trends](https://www.irs.gov/irm/part1/irm_01-004-007#id21)
    - 1.4.7.2.3  [Knowledge Base (Content) Maintenance](https://www.irs.gov/irm/part1/irm_01-004-007#id22)
    - 1.4.7.2.4  [KM Communications](https://www.irs.gov/irm/part1/irm_01-004-007#id23)
      - 1.4.7.2.4.1  [Internal Communications](https://www.irs.gov/irm/part1/irm_01-004-007#id24)
        - 1.4.7.2.4.1.1  [Internal KM Team Meetings](https://www.irs.gov/irm/part1/irm_01-004-007#id26)
        - 1.4.7.2.4.1.2  [Communications on Continuous Improvements](https://www.irs.gov/irm/part1/irm_01-004-007#id27)
      - 1.4.7.2.4.2  [External Communications](https://www.irs.gov/irm/part1/irm_01-004-007#id28)
  - 1.4.7.3  [Host Knowledge Management Events](https://www.irs.gov/irm/part1/irm_01-004-007#id29)
  - 1.4.7.4  [Manage/Maintain Knowledge Base Content](https://www.irs.gov/irm/part1/irm_01-004-007#id30)
    - 1.4.7.4.1  [Existing Content](https://www.irs.gov/irm/part1/irm_01-004-007#id31)
    - 1.4.7.4.2  [New and Revised Content](https://www.irs.gov/irm/part1/irm_01-004-007#id32)
    - 1.4.7.4.3  [Content Posting](https://www.irs.gov/irm/part1/irm_01-004-007#id33)
      - 1.4.7.4.3.1  [Guidelines for Posting Content:](https://www.irs.gov/irm/part1/irm_01-004-007#id35)
    - 1.4.7.4.4  [Content Maintenance](https://www.irs.gov/irm/part1/irm_01-004-007#id36)
  - 1.4.7.5  [Update the KM Knowledge Base](https://www.irs.gov/irm/part1/irm_01-004-007#id37)
    - 1.4.7.5.1  [Managing Hot Topics](https://www.irs.gov/irm/part1/irm_01-004-007#id38)
    - 1.4.7.5.2  [Core Team and Extended Core Team Contact List](https://www.irs.gov/irm/part1/irm_01-004-007#id39)
    - 1.4.7.5.3  [Managing Hot Topics Discussion Forums](https://www.irs.gov/irm/part1/irm_01-004-007#id40)
    - 1.4.7.5.4  [Managing Feedback](https://www.irs.gov/irm/part1/irm_01-004-007#id41)
    - 1.4.7.5.5  [Contact an Expert](https://www.irs.gov/irm/part1/irm_01-004-007#id42)
      - 1.4.7.5.5.1  [Contact an Expert Process](https://www.irs.gov/irm/part1/irm_01-004-007#id44)
    - 1.4.7.5.6  [Issue Snapshots](https://www.irs.gov/irm/part1/irm_01-004-007#id45)
    - 1.4.7.5.7  [Records Management](https://www.irs.gov/irm/part1/irm_01-004-007#id46)
  - 1.4.7.6  [SharePoint Site Maintenance](https://www.irs.gov/irm/part1/irm_01-004-007#id47)
    - 1.4.7.6.1  [Permissions](https://www.irs.gov/irm/part1/irm_01-004-007#id49)
  - 1.4.7.7  [Records Management](https://www.irs.gov/irm/part1/irm_01-004-007#id50)
    - 1.4.7.7.1  [Categories of KM Records](https://www.irs.gov/irm/part1/irm_01-004-007#id51)
      - 1.4.7.7.1.1  [Hot Topics and Discussion Forum Records](https://www.irs.gov/irm/part1/irm_01-004-007#id52)
        - 1.4.7.7.1.1.1  [Creation of Hot Topics and Discussion Forum Records](https://www.irs.gov/irm/part1/irm_01-004-007#id54)
        - 1.4.7.7.1.1.2  [Deleting or Making Substantive Edits to Hot Topics and Discussion Forum Records](https://www.irs.gov/irm/part1/irm_01-004-007#id55)
        - 1.4.7.7.1.1.3  [Retention and Archiving Hot Topics and Discussion Forum Records](https://www.irs.gov/irm/part1/irm_01-004-007#id56)
      - 1.4.7.7.1.2  [Contact an Expert Tracker Records](https://www.irs.gov/irm/part1/irm_01-004-007#id57)
        - 1.4.7.7.1.2.1  [Creating Contact an Expert Records](https://www.irs.gov/irm/part1/irm_01-004-007#id59)
        - 1.4.7.7.1.2.2  [Deleting or Making Substantive Edits to Records](https://www.irs.gov/irm/part1/irm_01-004-007#id60)
        - 1.4.7.7.1.2.3  [Retention and Archiving](https://www.irs.gov/irm/part1/irm_01-004-007#id61)
      - 1.4.7.7.1.3  [Original KM Content in Content Development Library](https://www.irs.gov/irm/part1/irm_01-004-007#id62)
        - 1.4.7.7.1.3.1  [Creation of Content Development Library Records](https://www.irs.gov/irm/part1/irm_01-004-007#id64)
        - 1.4.7.7.1.3.2  [Deleting or Making Substantive Edits to Content Development Library Records](https://www.irs.gov/irm/part1/irm_01-004-007#id65)
        - 1.4.7.7.1.3.3  [Retention and Archiving](https://www.irs.gov/irm/part1/irm_01-004-007#id66)
      - 1.4.7.7.1.4  [Original KM Content in the KM Virtual Library](https://www.irs.gov/irm/part1/irm_01-004-007#id67)
        - 1.4.7.7.1.4.1  [Creation of KM Virtual Library Records](https://www.irs.gov/irm/part1/irm_01-004-007#id69)
        - 1.4.7.7.1.4.2  [Deleting or Making Substantive Edits to KM Virtual Library Records](https://www.irs.gov/irm/part1/irm_01-004-007#id70)
        - 1.4.7.7.1.4.3  [Retention and Archiving](https://www.irs.gov/irm/part1/irm_01-004-007#id71)
      - 1.4.7.7.1.5  [Original KM Content in Contact an Expert Library](https://www.irs.gov/irm/part1/irm_01-004-007#id72)
        - 1.4.7.7.1.5.1  [Creation of Contact an Expert Library Records](https://www.irs.gov/irm/part1/irm_01-004-007#id74)
        - 1.4.7.7.1.5.2  [Deleting or Making Substantive Edits to Contact an Expert Library Records](https://www.irs.gov/irm/part1/irm_01-004-007#id75)
        - 1.4.7.7.1.5.3  [Retention and Archiving](https://www.irs.gov/irm/part1/irm_01-004-007#id76)
      - 1.4.7.7.1.6  [Original KM Content in the Knowledge Library](https://www.irs.gov/irm/part1/irm_01-004-007#id77)
    - 1.4.7.7.2  [Unauthorized Disclosures in SharePoint](https://www.irs.gov/irm/part1/irm_01-004-007#id78)
      - 1.4.7.7.2.1  [Unauthorized Disclosures via Contact an Expert](https://www.irs.gov/irm/part1/irm_01-004-007#id80)
      - 1.4.7.7.2.2  [Unauthorized Disclosures via the Hot Topics Discussion](https://www.irs.gov/irm/part1/irm_01-004-007#id81)
  - Exhibit  1.4.7-1  [TE/GE KM Decision Matrix](https://www.irs.gov/irm/part1/irm_01-004-007#id82)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 7. TE/GE Knowledge Management (KM) Administration

* * *

## 1.4.7 TE/GE Knowledge Management (KM) Administration

#### Manual Transmittal

February 19, 2026

#### Purpose

(1) This transmits revised IRM 1.4.7, Resource Guide for Managers, TE/GE Knowledge Management (KM) Administration.

#### Material Changes

(1) Updated and reorganized internal controls as required by IRM 1.11.2.2.4 , Address Management and Internal Controls, including:

- IRM 1.4.7.1.3, Roles and Responsibilities

- IRM 1.4.7.1.4, Program Management and Review

- IRM 1.4.7.1.5, Program Controls

- IRM 1.4.7.1.6, Terms and Acronyms

- IRM 1.4.7.1.7, Related Resources


#### Effect on Other Documents

This document supersedes IRM 1.4.7, Resource Guide for Managers, TE/GE Knowledge Network (KM) Administration, dated July 29, 2025.

#### Audience

Tax Exempt and Government Entities

#### Effective Date

(02-19-2026)

Stephen A. Martin

Director, Exempt Organizations, Rulings and Agreements

Exempt Organizations and Government Entities

Tax Exempt and Government Entities

**1.4.7.1** **(02-19-2026)**

### Program Scope and Objectives

1. **Purpose:** This IRM is to provide Knowledge Management (KM) Managers, Core Teams, and Extended Core Teams a common set of guidelines for KM operations. This is a document that will change over time as TE/GE identifies opportunities for improvement. Submit your suggested changes through the Provide Feedback link on KM sites.

2. **Audience**: KM Managers, Core Teams and Extended Core Teams.

3. **Policy Owner**: Commissioner, TE/GE.

4. **Program Owner**: Office of the Commissioner, TE/GE.

5. **Primary Stakeholders**: KM managers, team members, administration.


**1.4.7.1.1** **(07-06-2022)**

#### Background

1. KM encompasses a combination of practices that enable TE/GE to capture, organize, and share the information needed to carry out the mission of the organization. Its implementation helps ensure that the wealth of knowledge and experience our employees possess is shared and is used to improve the organization. TE/GE Knowledge Management materials reside on the Service Wide Virtual Library.



   - Capture, compile and catalogue current technical knowledge relevant to TE/GE functions, and maintain in a form easily accessible to TE/GE employees.

   - Consolidate, preserve and share TE/GE’s technical knowledge base.

   - Establish knowledge networks that connect employees and improve communication and collaboration.

   - Make timely technical assistance available to all TE/GE employees.

   - Ensure quality and consistency of technical positions taken and services performed on behalf of TE/GE.


**1.4.7.1.2** **(07-06-2022)**

#### Authority

1. By Treasury Order 150, the Secretary of the Treasury delegates to the Commissioner of Internal Revenue the responsibility for the enforcement of the Internal Revenue Laws.

2. Policy Statement 1-21 (IRM 1.2.1.2.5) provides:



1. The Internal Revenue Service will be a progressive organization.

2. There will be a definite program to enhance the effectiveness of all elements of the Service. The program will be comprehensive in concept, imaginative, yet realistic in design and will be so administered so as to provide vigorous and dedicated attention to making the Internal Revenue Service a truly forward thinking organization, one that will be recognized by employees and the public alike as representing that which is best in modern and progressive management.


**1.4.7.1.3** **(02-19-2026)**

#### Roles and Responsibilities

1. Each KM team is composed of a group of people with various roles and responsibilities:



   - A Senior Manager

   - A KM Manager

   - Core Team members

   - At least one TE/GE Division Counsel (TEGEDC) Representative



     ### Note:



     A KM team may have Extended Core Team members and a KM Lead.


**1.4.7.1.3.1** **(02-19-2026)**

##### Senior Manager

1. A Senior Manager leads the KM Area to:



   - Plan

   - Identify approaches to proactively meet employees’ knowledge needs.

   - Work collaboratively to answer questions.



     ### Note:



     KM Areas are Exempt Organizations and Employment Tax, Employee Plans, Indian Tribal Governments and Tax-Exempt Bonds.


2. Major duties include, but aren’t limited to:



   - Lead employees.

   - Direct resources and plan KM operations.

   - Guide priorities for KM activities.

   - Promote coordination among KM teams and other functions including work plan development, case selection, and other compliance and outreach activities.

   - Develop strategies to improve and enhance coordination and cross-functional integration.

   - Coordinate meetings: agenda-setting and meetings with KM Managers.

   - Collaborate with other Senior Managers and KM teams to share best practices and maintain consistent operations across TE/GE.

   - Develop procedures and controls to ensure that KM content is of high quality, complete, and accurate.

   - Develop and update procedures and guidance materials on KM operations.

   - Identify, report, and escalate issues.

   - Ensure submitted suggestions are addressed.

   - Identify and set goals for the KM Area.

   - Coordinate ongoing KM staffing, solicitation, and hiring requirements.

   - Be the primary decision maker for KM postings, advice, and processes.

   - Update the KM Area's Action Plan with task status and secure Tier 1 Director approval, if applicable.

   - Coordinate refresher or current training on KM operations to Core Teams, Extended Core Teams, and users as needed.

   - Approve content posting and secure Tier 1 Director approval, if applicable.


**1.4.7.1.3.2** **(02-19-2026)**

##### KM Manager

1. A KM Manager:



1. Oversees the KM team’s day-to-day operations

2. Ensures the KM team meets its identified goals as established by the Senior Manager

3. Ensures the KM team exhibits collaboration and knowledge sharing in its activities.


2. Major duties include but aren’t limited to:



   - Promote a collaborative environment that allows employees to express and consider differing opinions and supports team building.

   - Ensure Core Team and Extended Core Team members adhere to KM roles and responsibilities.

   - Manage work assignments and monitor workload.

   - Create an Action Plan that guides KM activities and ensures KM content is regularly reviewed and updated for currency, relevance and quality and secures Senior Manager and Director approval, if applicable.

   - Help coordinate the Core and Extended Core Teams to develop content and training materials, answer questions and reach consensus.

   - Offer the Extended Core Team learning opportunities in coordination with the employees’ Manager of Record.

   - Check-in regularly with Extended Core Team’s Manager of Record to discuss progress, workload, time management, etc.

   - Analyze trends on the Contact an Expert data and discussion forum to identify new issues, areas requiring additional content development, and potential topics for KM Events.

   - Review regularly the Contact an Expert tracker to ensure data is complete and ensure technical quality of responses.

   - Ensure Core Teams and Extended Core Teams are sufficiently trained on KM operations and technology.

   - Coordinate with other KM teams to develop training materials with Learning and Education (L&E) to promote cross-functional collaboration and engagement.

   - Collaborate with other KM Managers to share best practices and ensure consistent operations.

   - Review submitted suggestions for KM, assign them, and ensure they are addressed.

   - Identify and follow up on questions outstanding more than 20 business days.

   - Get approval to post content.

   - Provide input on Extended Core Team members’ performance evaluations.

   - Coordinate KM events to avoid conflicts.

   - Review training recommendations.


**1.4.7.1.3.3** **(02-19-2026)**

##### KM Lead

1. The KM Manager may designate or be assigned a KM Lead for support in day-to-day operations. Depending on the KM team's size and complexity, this role may not be required. Typical lead duties may include:



1. Set up internal team meetings.

2. Monitor the Contact an Expert queue and assign them based on the KM Manager’s direction.

3. Act as a liaison between the team and the KM Manager.

4. Knowledge Base site administrator.



      ### Note:



      Duties are assigned based on the individual’s grade and experience level.


**1.4.7.1.3.4** **(02-19-2026)**

##### Core Team Member

1. KM Core Team members participate in the day-to-day operations of a KM team. They help:



1. Capture and develop content.

2. Share expertise.

3. Collaborate.


2. Major duties include but aren’t limited to:



   - Maintain content on KM SharePoint sites and ensure it’s current.

   - Identify the need to collaboratively create new content and get items approved such as job aids, examination tools, Issue Snapshots, and pro forma language to post to the KM sites.

   - Work with KM Manager and KM Senior Manager to brief Executives on emerging technical issues.

   - Communicate routinely with the field and other stakeholders to stay abreast of new developments and emerging issues.

   - Be responsible for their own technical development and growth of expertise.

   - Track significant developments such as new laws, industry practices, guidance, etc.

   - Recommend training with Training Coordinators and L&E.

   - Communicate new developments and topics of interest to relevant TE/GE employees via email, meetings, Frequently Asked Questions , Hot Topics, etc.

   - Plan, develop content and facilitating KM Events to share information and engage in dialogue with employees.

   - Respond to questions and work with the Core and Extended Core Teams to answer them, if applicable.

   - Develop and routinely update FAQs based on questions received.

   - Monitor the website for feedback and general maintenance.


**1.4.7.1.3.5** **(02-19-2026)**

##### Extended Core Team Member

1. An Extended Core Team member:



1. Devotes up to 25% of his/her time

2. Supports one or more KM teams in some or all of the Core Team member duties in _IRM 1.4.7.2.4 (2)_

3. May have varying levels of experience with KM technical issues.


2. The KM Manager assigns work to Extended Core Team members in consultation with the employee’s own manager based on the:



   - employee’s availability

   - employee’s expertise

   - KM team needs


3. The Extended Core Team employee’s Manager of Record does management functions including time and leave approval, routine performance evaluations, and disciplinary actions.


**1.4.7.1.3.6** **(02-19-2026)**

##### Communications & Liaison (C&L)

1. Communications & Liaison (C&L) supports KM objectives through communications support. C&L helps with SharePoint site support administration and provides technological expertise.

2. C&L supports technology for KM SharePoint sites by doing these tasks, including but not limited to:



   - Submit system defects/errors and technology enhancements/improvements from the feedback process to the Change Control Board.

   - Be the central point of contact for submitting technology change requests (including requested prioritization) per the Change Control Process.

   - Do structural updates to KM Portal approved via the Change Control Process.

   - Manage Permissions for KM Portal and troubleshoot any access problems.

   - Support KM Teams in using their Knowledge Bases and KM Portal sites effectively including configuring internal document libraries, setting up alerts, etc.

   - Offer basic user support and troubleshooting for using the KM Portal.


3. C&L also supports the KM teams using communication tools and processes by doing these tasks, including but not limited to:



   - Edit TE/GE-wide communications on KM updates, events and general presentations about KM activities and services.

   - Edit other communication materials as needed, such as newsletter articles or other KM communications.

   - Publish appropriate information on KM Portal, IRS.gov, and other TE/GE communications once approved.

   - Edit KM training and communication materials for plain language and make 508 compliant, as requested.


**1.4.7.1.3.7** **(02-19-2026)**

##### TEGE Division Counsel (TEGEDC)

1. Each KM team has at least one TEGEDC representative as a KM TEGEDC advisor. In general, follow two key principles when working with TEGEDC:



1. The KM teams serve as a clearinghouse for issues. They escalate and resolve issues with TEGEDC.

2. The assigned TEGEDC advisor is involved in each KM team and contributes to discussions on issue escalation.


2. The TEGEDC KM advisor’s primary responsibility:



1. Provide timely legal advice to the KM teams.

2. Identify issues to elevate to TE/GE and/or TEGEDC management or coordinate with other Chief Counsel functions.

3. Review new content (such as training, issue snapshots, FAQs and exam guidelines). See _IRM 1.4.7.6.2_.


3. TEGEDC attorneys may:



1. Participate in KM events.

2. Give presentations.

3. Attend KM meetings.

4. Collaborate with the KM teams on suggested guidance.



      ### Note:



      TEGEDC isn’t involved in the day-to-day KM operational or management and won’t post content to the KM sites.


**1.4.7.1.3.8** **(02-19-2026)**

##### Compliance, Planning and Classification (CP&C)

1. KM Areas and Issue ID will coordinate at least annually to discuss and review tax law or form changes and the impact on case classification.

2. Collaboration with Issue ID will be to discuss tax law changes, identify trends, and to develop new queries to identify issues related to such changes.

3. This coordination with Issue ID may include the sharing of training material being developed and suggestions for revised or new queries. Communication and collaboration between the KM Areas and Issue ID are key in this effort to assess tax law changes and the impact on CP&C’s work.


**1.4.7.1.4** **(02-19-2026)**

#### Program Management and Review

1. Actions Plans are used to manage the program.

2. Each KM area develops its own goals and focus. KM areas are encouraged to:



1. Be innovative in discussing and suggesting ways to achieve KM goals.

2. Create an Action Plan to establish its focus for the upcoming year.


3. The Action Plan considers these TE/GE employees’ broader strategic priorities and gathers their input:



   - TE/GE leadership

   - KM management

   - KM teams

   - Field managers

   - Key stakeholders (such as, other KM teams, TEGEDC site administrators)


4. The team uses the Action Plan to sequence and prioritize work. They revisit and revise it as issues arise throughout the year.

5. The Action Plan should clearly identify what the KM area expects to accomplish in an agreed upon time. It:



1. Identifies activities (for example, new, ongoing, proposed).

2. Describes the activity.

3. Identifies responsible person(s), proposes timing for planning and execution.

4. Describes actions to sustain or maintain the activity, as appropriate.


6. Once developed, the Action Plan is reviewed and approved by the Senior Manager (and the Tier 1 Director for any proposed new content development). KM Managers prioritize and assign the work when approved. The Action Plan may be the basis for the tasks evaluated in the annual Operational Review. The Action Plan should be reviewed and revised regularly.

7. Also, check with other organizations to identify areas of crossover and/or impact. The KM manager coordinates with any other organization points of contact responsible for planning, updating, and approving IRM updates, if applicable.


**1.4.7.1.5** **(02-19-2026)**

#### Program Controls

1. Senior Managers and Tier 1 Directors: approve the Action Plan for new content development before it’s executed.

2. KM teams:



1. Post drafts of new or revised content on the collaboration site for other team members to review.

2. Let users know about new or revised content by posting under Hot Topics and discussing during KM events.


3. KM Managers must review new content for quality, clarity, relevance, and accuracy and ensure:



1. TEGEDC reviews content.

2. New content posted on IRS.gov doesn’t contain Official Use Only or Law Enforcement Material in the content.

3. Proper procedures are followed with Official Use Only or Law Enforcement Material in the content, and consult with TEGEDC if the Use Only designation is warranted.

4. Content meets disclosure, plain language, and Section 508 Accessibility requirements.


4. See the KM Decision Matrix for approval requirements


**1.4.7.1.6** **(02-19-2026)**

#### Terms and Acronyms

1. This table lists acronyms used in this IRM and their definitions.



|     |     |
| --- | --- |
| C&L | Communications and Liaison |
| CP&C | Compliance, Planning and Classification |
| EEE | The Associate Chief Counsel (Employee Benefits, Exempt Organizations and Employment Taxes) |
| FAQ | Frequently Asked Questions |
| GPO | Government Publishing Office |
| IRC | Information Resource Coordinator |
| KM | Knowledge Management |
| PDF | Portable Document Format |
| TE/GE | Tax Exempt and Government Entities |
| TEGEDC | Tax Exempt and Government Entities Division Counsel |


**1.4.7.1.7** **(02-19-2026)**

#### Related Resources

1. Use the following IRMs in conjunction with this manual:



   - IRM 1.4.1, Management Roles and Responsibilities

   - IRM 1.4.2, Monitoring and Improving Internal Control


**1.4.7.2** **(07-06-2022)**

### KM Operating Principles / Guidelines

1. TE/GE KM operates in a collaborative environment. Key areas of operation include:



   - Identifying trends

   - Maintaining site content

   - Communicating to employees

   - Hosting network events

   - Managing and maintaining Knowledge Libraries

   - Managing Hot Topics

   - Monitoring discussion forums and feedback items

   - Responding to technical questions


**1.4.7.2.1** **(07-06-2022)**

#### Collaboration

1. Collaboration within and across KM is essential to building and retaining KM support by all employees. Seeking diverse opinions and encouraging discussions to arrive at consensus will ultimately:



1. Lead to better ideas.

2. Put the best position forward.

3. Get buy-in from employees who see that their opinions are valued.


2. The Core Team and Extended Core Team should raise any recommended change that has a broader impact to the KM Manager for further review and discussion. Decisions that impact content (such as, job aids, precedential law, etc.) and training should be worked within the teams to ensure the best information is included in the Knowledge Library and there’s no duplication of effort.


**1.4.7.2.2** **(07-06-2022)**

#### Identifying Trends

1. KM teams are at the forefront of identifying new or emerging issues based on trend analysis, change in tax law, change in financial statement reporting, etc. KM teams have two responsibilities with respect to identified issues or trends:



1. Create or updating existing content.

2. Brief executives.


2. When a new issue emerges, KM teams should do an impact analysis to determine how the KM Virtual Libraries are impacted. The team should update existing materials to reflect the latest developments. If the topic hasn’t been addressed, teams should consider creating Hot Topics, Issue Snapshots, or other appropriate materials. Teams should follow existing content approval procedures. (See _IRM 1.4.7.6_.)

3. Managers and KM teams should be proactive and brief Executives on emerging technical issues. Prepare topics in a one-page briefing. Describe the issue, how the team has been involved, and what the challenges are. Managers should note this as an opportunity to highlight not only new or emerging issues, but also issues for which guidance decisions or procedures have a significant impact to the field and we need increased awareness.


**1.4.7.2.3** **(07-06-2022)**

#### Knowledge Base (Content) Maintenance

1. The Core Team identifies and maintains the content on the KM Knowledge Bases to ensure it remains accessible to employees. The team:



1. Does basic editorial and administrative quality assurance reviews such as: checking for broken links, duplicate items, 508 compliance, etc.

2. Looks for inconsistencies in resource categorization and information linking, and suggest new categorizations and taxonomy as additional content is posted and reviewed.

3. Conducts regular content reviews of site content to ensure relevance of the materials.


2. See _IRM 1.4.7.6.5_ for additional information on Content Management.


**1.4.7.2.4** **(07-06-2022)**

#### KM Communications

1. Communication, both external and internal, is a key responsibility of KM teams.


**1.4.7.2.4.1** **(07-06-2022)**

##### Internal Communications

1. Internal KM communications include interactions with Core and Extended Core team members and KM management.


**1.4.7.2.4.1.1** **(07-06-2022)**

###### Internal KM Team Meetings

1. Internal KM team meetings are held at least monthly or more often as determined by the KM Manager. The KM team meets periodically to:



   - Discuss workload.

   - Collaborate on complex questions.

   - Discuss opportunities to develop new technical content.


2. The KM Manager holds the meetings or may designate someone else to lead the meeting and may designate a note taker. The note taker posts meeting minutes on the site designated meeting minute location before the next scheduled meeting.

3. Prepare agendas for Team Meetings in advance. The KM Manager approves it when appropriate. The meeting structure is flexible to ensure that all new ideas and pending items are adequately addressed.


**1.4.7.2.4.1.2** **(07-06-2022)**

###### Communications on Continuous Improvements

1. The KM Team collects, analyzes, reports and communicates feedback from users and stakeholders to evaluate the KM team's use and performance. The team:



1. Evaluates potential action items.

2. Works with the KM Managers to improve the KM site (including submitting any system related suggestions through the Feedback Process).


**1.4.7.2.4.2** **(07-29-2025)**

##### External Communications

1. The KM Team communicates by:



1. Emailing information.

2. Posting information as Hot Topics.

3. Posting events on the Events Calendar.


2. To announce an event in the Weekly News (TE/GE Connect), complete a Communication Request Form with C&L three weeks before the event. Post upcoming events in the KM Events sections of the KM site.

3. The KM teams also collaborate with C&L to ensure IRS.gov is kept up to date. The KM teams may complete the Communication Request Form and attach relevant information to:



1. Create new web pages on IRS.gov.

2. Supplement existing web pages on IRS.gov (for example, adding a new FAQ to an existing set of FAQs, updating cited law).

3. Clarify information already available (for example, adding examples, editing text for plain language).

4. Release an Issue Snapshot.

5. Hold a webinar for external taxpayers.

6. Create other outreach products.


4. Senior Managers and KM Managers must coordinate to minimize scheduling conflicts and work with C&L to ensure duplicate communications are not sent to the same audience.


**1.4.7.3** **(07-06-2022)**

### Host Knowledge Management Events

1. The KM Team hosts regular KM events. The KM Manager should designate a responsible individual(s) to:



1. Prepare the agenda.

2. Write an announcement (with link to Teams/Skype/Zoom/Saba and conference call number, if applicable).

3. Post information to the KM Related Events section after the Manager approves. Include the name of the event, a brief description, and any supporting materials.

4. For large or formal events, send a meeting invitation to \*TE/GE Exec Events to post to the Executive Calendar.


2. The purpose of KM events is to:



   - Share and receive technical expertise.

   - Discuss practical issue-based information for expanding technical knowledge.

   - Identify emerging issues and trends.


3. KM Event can include subject matter experts who are not KM team members.

4. Events should create an environment that:



   - Encourages sharing of ideas.

   - Helps enhance skills.

   - Allows employees to feel comfortable to speak up and share ideas.

   - Promotes two-way communications.


5. During the event, employees may:



   - Learn about an issue.

   - Ask questions about an issue they’re currently working on.

   - Interact with other examiners who have a similar issue.

   - Discuss the legal analysis of the issue.

   - Discuss the IRS position on the issue and how to apply it to a case.


**1.4.7.4** **(07-06-2022)**

### Manage/Maintain Knowledge Base Content

1. This section gives guidelines to make sure KM content is:



   - relevant

   - accurate

   - easy to use


2. It also describes responsibilities to review, approve, and continually maintain content. See _Exhibit 1.4.7-1_ for guidelines on content approval and maintenance.


**1.4.7.4.1** **(02-19-2026)**

#### Existing Content

1. **Existing Content**includes content that has been previously written and is in circulation.



### Example:



Guidance and reference materials on IRS.gov, case law, and code.

2. If you’re uncertain if material has been previously reviewed and approved, treat it as new content (see _IRM 1.4.7.6.2_, New and Revised Content).

3. The KM team reviews existing content for accuracy, relevance, and importance and recommends its posting to the Knowledge Base.



1. Fully **vet** documents before posting.

2. Consider the need and reason for the document before posting- quality matters most over quantity.

3. Post content that is current and gives employees a strong base from which to start their research. (Don’t post every available document - be discrete in what you consider the most relevant and useful information.)


4. Links to general training and other reference materials are on the KM Virtual Library.

5. Whenever possible, link code, regs etc. on IRS.gov, GPO site, or a third-party research site rather than posting a document with this information.

6. See _IRM 1.4.7.1.5_, Program Controls, for required review and approvals for existing content.


**1.4.7.4.2** **(07-06-2022)**

#### New and Revised Content

1. **New** content is **original** content the KM teams developed such as examination tools, training materials, or issue snapshots. **Revised** content is material that was previously existing content but has been revised. Revised content does not include formatting or grammatical changes. Any technical changes should be reviewed by TEGEDC. The KM teams must identify existing content that requires updating, or new content that needs to be developed by:



1. Looking for commonly submitted questions to KM teams or on the Discussion Forum.

2. Field reports or data illustrating which issues are being identified in examinations.

3. Suggestions and feedback from KM site users.

4. Discussions with other tax law specialists/technical advisors, examiners, actuaries, managers, reviewers, and others about emerging trends and issues.


2. Content development process:



1. Discuss content needs and document them in the KM Action Plan for approval (KM Team and Manager).

2. Designate a project lead(s) (either a Core or Extended Core member) and help assemble a team (KM Senior Manager or Manager). The project lead tracks the progress of the content development: updates and helps to complete it, and works with management when necessary.

3. Include members of the Core Team, Extended Core Team, and other employees with expertise in the area, and representatives from other BODs when appropriate.

4. Include TEGEDC representatives at the start to incorporate their feedback.

5. Use existing template(s) (if available) to ensure consistency.


**1.4.7.4.3** **(07-29-2025)**

#### Content Posting

1. The Content Management Training Session includes references for posting content such as:



   - Best practices

   - Information on using metadata

   - Legal obligations


2. KM Managers are responsible for ensuring that IRS procedures for posting content are followed.

3. Managers, Core Team members, and Extended Core Team members designated and trained as content contributors upload and maintain content on the site.


**1.4.7.4.3.1** **(07-06-2022)**

##### Guidelines for Posting Content:

1. Ensure that files are Section 508 compliant.

2. Link directly to approved/contracted third-party research sites, GPO and other sites and databases rather than copying or uploading content to avoid copyright concerns.


**1.4.7.4.4** **(07-06-2022)**

#### Content Maintenance

1. The Virtual Library requires a review schedule of content at a minimum of annually. However, the recommendation is to review the content at least every six months. The Virtual Library is evaluated for relevance, accuracy, completeness, and usefulness. It is recommended to:



   - Stagger reviews to distribute the workload over the course of the year.

   - Designate content as current, requiring update, or requiring archiving.

   - Add content requiring update to the KM Action Plan.

   - Archive content per record retention procedures. Coordinate with the designated Information Resource Coordinator (IRC) for proper archiving, and check the record control schedule for retention requirements.


2. Review content on the KM Knowledge Base (including event calendars, Hot Topics, etc.) at least monthly to verify it’s up to date.

3. Be proactive in seeking feedback from the KM users on their recommendations for additional content or changes.


**1.4.7.5** **(07-06-2022)**

### Update the KM Knowledge Base

1. KM teams are responsible for keeping the KM Knowledge Base up to date, including:



   - Hot Topics postings

   - Site Contact List

   - Hot Topics Discussion Forums

   - Feedback

   - Contact an Expert

   - Events

   - KM related links


**1.4.7.5.1** **(07-06-2022)**

#### Managing Hot Topics

1. The purpose of Hot Topics is to keep KM users up to date on current developments. Hot Topics are posted by KM teams and will remain as long as the topic is relevant. Hot Topics should be approved by the KM Manager before posting. To learn of new items posted:



1. Employees can set a specific alert for Hot Topics for a KM site.

2. KM teams may send an email to employees to alert them that a new Hot Topic was posted.

3. Participate in Hot Topics Discussion Forums. _IRM 1.4.7.7.3_


**1.4.7.5.2** **(07-06-2022)**

#### Core Team and Extended Core Team Contact List

1. The contact list contains contact information for KM Core Team and Extended Core Team members as Knowledge Base contributors, administrators or site owners. The contact list includes contact information for users to easily contact KM team members. Update the list when there is a change in membership so the latest contacts are available.

2. KM Managers are listed in the Site Contacts.


**1.4.7.5.3** **(07-06-2022)**

#### Managing Hot Topics Discussion Forums

1. Hot Topics Discussions Forums are open to all users. Anyone may post a comment; however, the KM Team must:



1. Monitor the discussion forum.

2. Review forums for relevancy and accuracy of the website content.



      ### Note:



      As with all other posted site content, make sure no personally identifiable information (PII) or sensitive but unclassified (SBU) information is added to the discussion forums.


2. Managers establish procedures for how their KM Team monitors the discussion forums and consider:



|     |     |
| --- | --- |
| • | Assignment - Assign team members to monitor the forum discussions in one of these ways:<br> <br>   - Rotating assignment - Team members take turns<br>     <br>   - KM Lead - If the KM team has a lead, he/she may be responsible<br>     <br>   - Forum Patrol - Two members of the team share the responsibility |
| • | Frequency - Reviewing the discussion forums will vary by KM team based on its level of activity. Managers or Core Team members can create an alert to ensure that the person(s) assigned to monitoring the KM is(are) immediately aware of any new posts. |
| • | Escalation - Escalate content that is questionable with respect to accuracy, professionalism, or sensitivity to KM management. KM managers can approve deleting or editing a post and direct teams on how to follow-up including notifying the individual whose post was removed or edited. The Core Team may immediately remove any blatantly incorrect or inappropriate content then promptly notify the KM Manager. Retain any material that is required to be kept for Records Retention (if not retained elsewhere) per IRM 1.15.24 and the current TE/GE Records Control Schedule |

3. If you can answer a question with a simple, documented response, then the team member(s) responsible for monitoring the discussion may post the answer directly in the Hot Topic Discussion. If not, the team may wish to direct the user to the Contact an Expert feature for an answer.

4. Incorporate commonly-discussed topics into FAQs and Hot Topics. This way, content from the forums may reduce the number of questions while offering technical input on specific issues.

5. Besides simply monitoring the forums, use the discussion boards to stimulate conversation and interact with users. Do this by posting questions and other discussion topics to start a conversation.


**1.4.7.5.4** **(07-06-2022)**

#### Managing Feedback

1. KM teams should continuously seek feedback in these ways to better serve KM users:



1. During KM events.

2. Via the Provide Feedback function on the KM Knowledge Bases.

3. In other ways.


2. To keep a record, document feedback using the Provide Feedback form on the KM site.

3. KM teams should review all feedback they receive through the Provide Feedback function at least weekly. KM Managers should assign each item to a KM team member and follow up to ensure it’s addressed. Discuss suggestions impacting overall KM operations or other KM teams during the KM Manager meetings.

4. Group suggestions on system errors or improvements that affect the site design, templates, or shared resources on a custom report for C&L.

5. KM teams may address feedback specific to their own site/topic, such as fixing a broken link or developing or updating content. The teams may also help users to navigate the site or provide one-on-one basic training through a KM Content Contributor.


**1.4.7.5.5** **(07-06-2022)**

#### Contact an Expert

1. The "Contact an Expert" process describes how a user may request information from the KM Team and how the team will respond to the inquiry. The process is:



1. Primarily intended to answer questions after an employee has researched the KM sites and resources, discussed questions with peers and managers, and is looking for additional help.

2. Limited to general questions on issues and procedures for case work. KM teams don’t review specific cases, develop IDRs, arguments, or other exam documentation, or become involved in casework such as TAMs


2. To ensure consistency and promote collaboration and information sharing, existing Review Functions and others offering technical assistance should coordinate with the KM teams on issues that fall under one of the specified TE/GE areas. Coordination includes:



   - Communicating FAQs to the KM team to develop or revise content

   - Involving the KM team in discussions about complex, novel, or emerging issues that arise through the technical assistance process

   - Directing requestors to KM sites to familiarize them with available resources


**1.4.7.5.5.1** **(07-29-2025)**

##### Contact an Expert Process

1. The Contact an Expert process from inquiry to initial contact should generally be completed within 5 business days:




| Step | Person/Actions |
| --- | --- |
| Submit Inquiry | Requestor:<br> <br>1. Selects the Contact an Expert feature on the KM site.<br>      <br>2. Complete the fields on the Contact an Expert form. |
| Pre-Screen and Referral | Manager or designated Assigner named as the point of contact:<br> <br>1. Read question.<br>      <br>2. If you receive a simple question via call or email that you can answer immediately, answer it right away. If the question is something that should be tracked for trending, add it in as a formal question to Contact an Expert to document and track it and let Requestor know that it has been added.<br>      <br>3. Assign to the proper KM team if mistakenly assigned to yours. Add notes and explain on the appropriate fields of the form. |
| Assign Inquiry | Assigner:<br> <br>1. Assign the inquiry to appropriate Core or Extended Core Team member(s) from the Active Directory linked to Outlook. Assign to a Secondary Responder so members can learn and collaborate.<br>      <br>2. Complete the following fields on the form: Date Assigned, Assigned To - Primary, Assigned To - Secondary (not mandatory), Status (change to Assigned). |
| Confirm Receipt and Provide Initial Response | Responder: Email Requestor to:<br> <br>   - Confirm receipt<br>     <br>   - Schedule an initial discussion to ensure the facts are accurate<br>     <br>   - Confirm if additional research is needed<br>     <br>### Note:<br>Your initial response can include existing guidance, self-help materials, forum discussions, etc. In some cases, this may be all that is required. The primary and secondary assignee should work inquiries together to knowledge share, collaborate, and ensure consistent positions. |
| Draft Response and Review | Responder: Draft a response depending on the complexity of the question:<br> <br>1. Simple questions that have a standard response or a published position don’t require team collaboration to determine the answer. Email your answer and cc the Requestor’s manager.<br>      <br>2. Complex or unique questions that don’t have an established answer or resource require a team approach.<br>      <br>      <br>      <br>      - To gain additional input or expertise, post the drafted response to the team collaboration site, where the KM Team can review and build consensus on an appropriate response.<br>        <br>      - In about 5 days, Responder(s) reviews feedback and incorporates into the response.<br>        <br>      - If the question is particularly complex or there are differing opinions, Responder may add the topic to an internal team meeting agenda.<br>        <br>### Note:<br>It’s important to communicate with Requestor during this time to clarify and collaborate possible answers. |
| Update form / Send response | Responder:<br> <br>1. Complete the Inquiry Response field.<br>      <br>2. Email the response to Requestor.<br>      <br>3. Post the final response on the collaboration site in the designated library/folder using the team’s agreed file naming convention.<br>      <br>4. Refer to the filename in the Inquiry Response field so the team can find the response for future, similar questions, trending analysis and management review.<br>      <br>5. CC Requestor’s manager for information and to consider for similar issues. |


**1.4.7.5.6** **(07-06-2022)**

#### Issue Snapshots

1. Issue Snapshots:



1. Give an overview of a tax issue.

2. Identify resources that may help clarifying the topic further.


2. An Issue Snapshot includes:



   - A brief description

   - Pertinent Internal Revenue Code sections, Treasury Regulations, other resources (including any job aids)

   - Analysis of the issue

   - Determinations review or exam tips

   - Industry information, if applicable


3. An Issue Snapshot is not intended to be:



   - A comprehensive analysis of an issue or multiple issues.

   - Used as a "pro forma" position/discussion on an issue.


4. An Issue Snapshot is a resource for technical knowledge that can be shared. It’s a tool that helps achieve the KM goal of collecting, organizing and cataloguing knowledge. Issue Snapshots are posted in the Knowledge library and on the IRS.gov reading room for external customers.

5. Issue Snapshots require Counsel approval of the topic prior to development. Upon drafting of an Issue Snapshot, TEGEDC and Associate Chief Counsel Employee Benefits, Exempt Organizations, and Employment Taxes (EEE) will review and provide guidance. This guidance may include revisions to the Issue Snapshot.


**1.4.7.5.7** **(07-06-2022)**

#### Records Management

1. KM teams should continue to follow existing records retention policy and the TE/GE records control schedule.


**1.4.7.6** **(02-07-2017)**

### SharePoint Site Maintenance

1. Maintaining the KM SharePoint site is a collaborative process and includes maintaining permissions and ensuring that records retention standards are followed.


**1.4.7.6.1** **(07-06-2022)**

#### Permissions

1. Permissions in SharePoint allow specific users certain abilities, such as reading and posting content. A permission level is a pre-defined set of permissions grouped together that grants users the ability to perform related tasks. SharePoint uses the following permission levels:



   - Full Control - Contains all available SharePoint permissions. By default, this permission level is assigned to the Owners group. It cannot be customized or deleted.

   - Edit - Add, edit, and delete books or lists; view, add, update, and delete pages, list items, and documents.

   - Contribute - View, add, update, and delete book pages, list items, and documents.

   - Read - View pages and items in existing books, lists, document libraries, and download documents.

   - Approve - Edit and approve pages, book pages or list items, and documents.


2. KM site owners and administrators assign and maintain permissions and permission groups. Permissions should be reviewed at least quarterly for any changes.

3. C&L maintains and assigns permissions for the SharePoint Collaboration site as approved by the KM Manager. Permissions should be reviewed at least quarterly for any changes.


**1.4.7.7** **(07-06-2022)**

### Records Management

1. KM operations are subject to Records Management requirements that apply to all TE/GE operations and programs. KM teams should continue to follow existing records retention policy and the TE/GE records control schedule (see IRM 1.15.24).

2. See _IRM 1.4.7.9.1_ below for specific procedures for generated and stored KM content.


**1.4.7.7.1** **(07-06-2022)**

#### Categories of KM Records

1. Below is an inventory of records generated and maintained by KM Teams.



### Note:



See the Core and Extended Core Team Resources site for a complete inventory of KM records.





### Note:



Don’t destroy records with "pending disposition" retention schedules before the pending schedule is finalized and approved.






| **Title** | **Description** | **RECORDS DESCRIPTION** | **RECORDS DESCRIPTION (additional)** | **RECORD RETENTION** |
| --- | --- | --- | --- | --- |
| Contact an Expert Tracker | Online database with technical questions (not case specific) includes requestor name, question, responder’s name, etc. | Technical and General Correspondence Files | Correspondence involving the furnishing of technical assistance or information on tax matters (not covered elsewhere in this Schedule, not made part of a specific case, and/or does not constitute an official ruling). | PENDING DISPOSITION<br> Cut off at end of fiscal year.<br> Destroy 6 months after cutoff. |
| Original KM Content (in Collaboration Sites and Knowledge Library) | Original KM Content (including Issue Snapshots, Examination Tools, Training Materials) | Program, Policy and Procedural Files | Desk guides, and standard operating procedures covering TE/GE program activities involving policy, procedures, rulings, decisions, etc., not made part of a specific case. | approved product is superseded, or 3 years after policy or program is terminated, whichever is earlier. |
| Original KM Content (In Contact an Expert Library) | Word documents with responses to technical questions received through Contact an Expert list | Technical and General Correspondence Files | Correspondence involving the furnishing of technical assistance or information on tax matters (not covered elsewhere in this Schedule, not made part of a specific case, and/or does not constitute an official ruling). | Cut off at end of fiscal year.<br> Destroy 6 months after cutoff. |
| Hot Topics With Discussion | Centralized list of announcements on current events, recent regulation changes, and new guidance and job aids posted to the Knowledge Library | General Administration and Management Files | Correspondence and other papers e.g. operating plans and programs, pertaining to the overall administration and management of TE/GE | Destroy when no longer needed in current operations but no later than 5 years after close of file. |


**1.4.7.7.1.1** **(07-06-2022)**

##### Hot Topics and Discussion Forum Records

1. Items posted to the KM discussion forums are considered records and all applicable records retention standards must be followed.


**1.4.7.7.1.1.1** **(07-06-2022)**

###### Creation of Hot Topics and Discussion Forum Records

1. KM Teams, Managers, and all system users can post to the Hot Topics discussion forums.


**1.4.7.7.1.1.2** **(07-06-2022)**

###### Deleting or Making Substantive Edits to Hot Topics and Discussion Forum Records

1. Users are unable to delete or edit their own forum postings. Only KM Managers and KM Teams may delete postings.

2. KM Teams and Managers should review the hot topic and discussion responses regularly to ensure that responses to answer the question(s) are accurate and no case-specific return information, PII or SBU is discussed. This type of sensitive information should not be available for view on the user site. Specific procedures for unauthorized disclosures of PII, SBU and return information are provided below.

3. Deletions and substantive edits require approval by the KM Manager.

4. Before you delete a posting, create a PDF of the posting and all replies in any of these ways:



   - Right click on the discussion thread and click "Print" – select Adobe PDF

   - Take a screen shot with Snagit, paste to a Word Document, and print to Adobe PDF

   - Create a PDF of the last alert if you have alerts set up on the discussion forum


### Note:

Keep the PDF per the instructions below in

5. Edits to the discussion forum are tracked with version history and require no manual tracking.

6. Add a line item to the KM team's deletion audit log to note the item deleted, rationale, and any other information.

7. Delete the item from the discussion forum.

8. The posting goes into the KM Knowledge Base recycle bin for 30 days, then to the central IRS recycle bin for another 30 days.


**1.4.7.7.1.1.3** **(07-06-2022)**

###### Retention and Archiving Hot Topics and Discussion Forum Records

1. Because Hot Topics and discussions are valuable to users browsing the sites to see prior questions and discussions, keep them on the KM site until either:



1. The question/answer is no longer accurate.

2. The number of postings becomes voluminous.


2. Follow procedures above for removing and archiving prior postings.

3. Until the disposition schedule for discussion forum posts is approved, don’t destroy these records. Assuming the proposed schedule is approved, keep the discussion forum archive for six months after the fiscal year end.


**1.4.7.7.1.2** **(07-06-2022)**

##### Contact an Expert Tracker Records

1. The KM Contact an Expert tracker is considered a record so follow all applicable record retention standards.


**1.4.7.7.1.2.1** **(07-29-2025)**

###### Creating Contact an Expert Records

1. KM Teams, Managers and system users can add questions to the Contact an Expert Tracker.


**1.4.7.7.1.2.2** **(07-06-2022)**

###### Deleting or Making Substantive Edits to Records

1. Only Site Owners and Administrators may edit or delete these records once they’re submitted

2. Don’t delete Contact an Expert records except for PII/SBU. In this case, see procedures for unauthorized disclosures in _IRM 1.4.7.9.2.1_ below.

3. Edits to Contact an Expert records are tracked as part of the version history and require no manual tracking.


**1.4.7.7.1.2.3** **(07-06-2022)**

###### Retention and Archiving

1. Once the list meets either 5,000 items, across all KM teams or every two years, export and archive the list. C&L must export from the master list in Excel format and give the relevant questions to each KM to store on the collaboration site.


**1.4.7.7.1.3** **(07-06-2022)**

##### Original KM Content in Content Development Library

1. KM Teams and Managers may create original content. This new material is housed in the content development library until approved/ disapproved per the decision rights matrix.


**1.4.7.7.1.3.1** **(07-06-2022)**

###### Creation of Content Development Library Records

1. KM Teams and Managers can create new records in the Content Development Library. There are two main types of records created in this library:



1. The Library item indicating the title, document name or link, tags, and audit trail for any content under consideration.

2. A document that represents original KM content or IRS original content that is not covered under an existing record control schedule or records management program.


**1.4.7.7.1.3.2** **(07-06-2022)**

###### Deleting or Making Substantive Edits to Content Development Library Records

1. The KM Manager decides which content gets deleted and archived from the Content Development Library, but it’s rare to delete postings except if they’re duplicates or errors.



### Example:



Delete items posted in duplicate or in error or that aren’t part of KM operations, procedures, or decisions.

2. Keep items in the Content Development Library and not posted to the Knowledge Library in status "Not Approved" or "Postponed" until moved to the KM team's archive library (see below).


**1.4.7.7.1.3.3** **(07-06-2022)**

###### Retention and Archiving

1. For Library list items:



   - KM teams may continue to use the Content Development Library as their audit log of approvals and prior content considered.

   - As the library becomes too voluminous, the Manager may regularly export items that are Approved or Not Approved for Posting from the collaboration site to an Excel spreadsheet and store the file within the KM team's archive library.

   - After archiving, delete the list items from the active library.


2. For Original KM Content:



   - Keep the edited final draft showing tracked changes/comments and the final clean one to show how they got to the final version of the snapshot or other original content.

   - Download final drafts showing tracked changes and comments to the archive before the list is purged.

   - Post the final "published" version in the appropriate KM Virtual Library until it’s no longer needed.

   - Download and archive the final in the team’s Archive folder or library.

   - Record the deletion in the deletion or edit archive log.

   - Keep responses as Program, Policy and Procedural Files per the retention policy as follows: Destroy the earlier of: three years after final approved product is superseded, or three years after policy or program is terminated.


**1.4.7.7.1.4** **(07-06-2022)**

##### Original KM Content in the KM Virtual Library

1. A Core or Extended Core Team member posts original content to the applicable KM Virtual Library site when approved via the decision rights matrix. This includes KM site book and page narratives.


**1.4.7.7.1.4.1** **(07-06-2022)**

###### Creation of KM Virtual Library Records

1. KM Teams and Managers can create these three types of new records in the KM Virtual Library:



1. KM site pages of narrative of an issue or topic.

2. Any document or link showing the title, document name or link, tags, and audit trail for any content.

3. A document that is original KM content or IRS original content not covered under an existing record control schedule or records management program.


**1.4.7.7.1.4.2** **(07-06-2022)**

###### Deleting or Making Substantive Edits to KM Virtual Library Records

1. The KM Manager decides which content gets deleted and archived, but it’s rare to delete posting from the KM Virtual Library.



### Example:



Delete items: posted in duplicate or in error, superseded, or no longer accurate or relevant.


**1.4.7.7.1.4.3** **(07-06-2022)**

###### Retention and Archiving

1. For Original KM Content:



   - Keep current documents in the Knowledge Library.

   - Store documents no longer needed in the Knowledge Library in the Archive Library.

   - Keep these files as Program, Policy and Procedural Files per the retention policy as follows: Destroy the earlier of: three years after final approved product is superseded, or three years after policy or program is terminated.


**1.4.7.7.1.5** **(07-06-2022)**

##### Original KM Content in Contact an Expert Library

1. The Contact an Expert library is a SharePoint Document library that includes:



1. The Contact an Expert Tracker listing draft responses to questions.

2. Metadata listing the question number, the assigned responders, and the status of the review.


**1.4.7.7.1.5.1** **(07-06-2022)**

###### Creation of Contact an Expert Library Records

1. KM Teams and Managers can create new records in the Contact an Expert Library. There are two main types of records created in this library:



1. The question showing its reference number, status and assignment.

2. A Word file with the draft and final response.


**1.4.7.7.1.5.2** **(07-06-2022)**

###### Deleting or Making Substantive Edits to Contact an Expert Library Records

1. The KM Manager decides which content gets deleted and archived, but it’s rare to delete posting from the Contact an Expert Library.



### Example:



Delete items: posted in duplicate or in error, superseded, or no longer accurate or relevant.


**1.4.7.7.1.5.3** **(07-06-2022)**

###### Retention and Archiving

1. For Library items:



   - KM teams: continue to use the Contact an Expert Library as an audit trail for your responses to questions.

   - KM Manager: Delete the item from the Contact an Expert Library when complete and regularly export completed items into an Excel file from the Collaboration site to the Archive library.


2. For the Response:



   - Keep the edited draft and final to show how you got to the final response.

   - Embed the draft in the Final version in the Contact an Expert Library.

   - Keep responses as Technical Correspondence for 18 months after they’re archived.


**1.4.7.7.1.6** **(07-06-2022)**

##### Original KM Content in the Knowledge Library

1. The Knowledge Library is:



1. A document library with metadata that describes a specific resource- either a document or a link

2. The storage vehicle for current KM content. When documents are deleted from the KM Virtual Library they’re stored in the Collaboration site archive.


2. Record the deletion in the archive log.


**1.4.7.7.2** **(07-06-2022)**

#### Unauthorized Disclosures in SharePoint

1. PII, SBU and return information are not permitted on any IRS SharePoint site. Follow these procedures for an inadvertent disclosure on a KM site:


**1.4.7.7.2.1** **(07-06-2022)**

##### Unauthorized Disclosures via Contact an Expert

1. Questions received via Contact an Expert are viewable on the collaboration site, access to which is restricted to the KM Manager and the KM team.

2. If an unauthorized disclosure of return information, SBU or PII is identified, the KM Manager immediately contacts the requestor’s Manager to begin the unauthorized disclosure reporting process (see IRM 10.5.4, IRM 10.5.5).



### Note:



Return information includes most case-specific facts and information and is not limited to the taxpayer’s name, address, SSN, date of birth, or other information on the taxpayer’s return.





### Note:



PII includes all information that, viewed separately or along with other available information, can be used to identify a unique taxpayer.





### Caution:



Therefore, if you see case-specific facts on the discussion forum, or any facts that could be used to identify a unique taxpayer, assume they are return information unless the user has clearly indicated he/she created hypothetical facts.

3. KM Manager:



1. Document an audit log stored on the KM team's Collaboration Site: the name of the requestor, the date submitted, the ID number in the tracking system, the general nature of the disclosure, and actions taken to address it.

2. Move the submitted question (including the return information, SBU or PII data) to the designed secured electronic folder on the shared server.

3. Remove the return information, SBU or PII from the KM website.

4. Notify the site collection administrator so the item can be deleted permanently from the recycle bin.


**1.4.7.7.2.2** **(07-06-2022)**

##### Unauthorized Disclosures via the Hot Topics Discussion

1. Hot Topics Discussion questions/comments are viewable to all IRS employees.

2. PII, SBU and return information should not be posted to the discussion forums. See the disclaimer on at the top of the forums.



### Note:



Return information includes most case-specific facts and information and is not limited to the taxpayer’s name, address, SSN, date of birth, or other information on the taxpayer’s return.





### Note:



PII includes all information that, viewed separately or along with other available information, can be used to identify a unique taxpayer.





### Caution:



Therefore, if you see case-specific facts on the discussion forum, or any facts that could be used to identify a unique taxpayer, assume they are return information unless the user has clearly indicated he or she created hypothetical facts for purposes of the forum.

3. If an unauthorized disclosure of PII, SBU or return information is identified, the KM Manager immediately contacts the poster’s Manager to begin the unauthorized disclosure reporting process.

4. KM Manager:



1. Document an audit log on the KM team's Collaboration Site: the name of the poster, the date and time posted, the title of the posting, the general nature of the disclosure, and actions taken to address it.

2. Move the PII, SBU or return information to the designed secured electronic folder on the shared server.

3. Remove from the KM website as soon as possible.

4. Notify the site collection administrator so the item can be deleted permanently from the recycle bin.


**Exhibit 1.4.7-1**

### TE/GE KM Decision Matrix

| Governance Area\* | Commissioner | Functional Director | Director\* | KM Senior Manager | KM Frontline Manager | Core Team | Assigned TEGE DC KM Attorney | C&L |
| :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: | :-: |
| R = Responsible;<br> A = Approver;<br> C = Consulted;<br> I = Informed; (All) = Consensus Required (Definitions Below) |  |  |  |  |  |  |  |  |
| Prioritization of Work |  |  |  |  |  |  |  |  |
| Set Strategic Priorities for Knowledge Management (KM) for the Fiscal Year |  | C | A | R | I | I | I |  |
| Create Annual Workplan for KM - Development of New Content (such as Training or Issue Snapshots) |  |  | A | R | R | I | I |  |
| Ensure KM Teams are performing work outlined in annual work plan |  |  | I | I | R |  |  |  |
| KM Processes |  |  |  |  |  |  |  |  |
| Create or change procedures that impact the goals of KM such as team collaboration processes (workplan, balanced measures, etc.) |  | A (All) | C | R | I | I |  |  |
| Approve changes to processes that impact users' interaction with KMs (response service levels, input forms) |  |  | A (all) | R | C |  |  |  |
| Approve process changes impacting an existing TE/GE-wide KM procedure or training (existing agreed upon procedures such as the IRM) |  |  | A (All) | R | R | I |  |  |
| SharePoint Site Structure |  |  |  |  |  |  |  |  |
| Create/change site design (creating or changing a Shelf) for Knowledge Base |  |  | A (All) | R (All) | R | I |  | I |
| Create/change site design for a Book on a Knowledge Base |  |  | I | A | C | R |  | I |
| KM Content |  |  |  |  |  |  |  |  |
| Posting of external new or revised content (issue snapshots\*, webcasts, Technical Guides, etc.) |  |  | A | A | R | I | C |  |
| Posting of new or revised internal content (FAQ, job aids, training materials, etc.) This includes new Knowledge Base content that is not created from existing materials. |  |  |  | A | R | I | C |  |
| Posting of links to law related resources (Code, Regs, Case Law, PLRs, etc.) |  |  |  |  | A | R |  |  |
| Link or post Training Materials (CPE or otherwise) |  |  |  | A | A | R |  |  |
| Post a hot topic or discussion forum topic. |  |  |  |  | A | R |  |  |
| Maintain content on Knowledge Base Pages |  |  |  |  | A | R |  |  |
| Maintain Contributor permissions for Knowledge Base |  |  |  | I | A / R |  |  |  |
| Staffing and Hiring |  |  |  |  |  |  |  |  |
| Make decisions on resource allocation for KM Teams |  |  | A | R | C |  |  |  |

\*Note: Issue Snapshots require Topic Approval by TEGEDC and EEE. TEGEDC and EEE also review Issue Snapshots after development for technical accuracy.

If at any point a decision cannot be resolved by consensus, OR if the position is not applicable, it will be elevated to the next level.

| Directors | Definitions |
| --- | --- |
| Director, EP Rulings and Agreements | **R – Responsible:**"The Doer." This is the individual(s) who actually complete the task and is responsible for the action. |
| Director, EO Rulings and Agreements | **A – Approver:**"The Buck Stops Here." This is the individual who is ultimately answerable for the activity or decision. |
| Director, Government Entities | **C – Consulted:**"In the Loop." This individual(s) is consulted and reviews the material prior to a final decision or action. This incorporates two-way communication. |
|  | **I – Informed:**"Keep in the Picture." This is the individual(s) who needs to be informed after a decision or action is taken. There is one-way communication |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-007#addtoany "Show all")

A2A