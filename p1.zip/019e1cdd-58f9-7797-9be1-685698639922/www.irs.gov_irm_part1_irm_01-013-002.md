---
url: "https://www.irs.gov/irm/part1/irm_01-013-002"
title: "1.13.2 Processing Management | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-013-002#main-content)

- 1.13.2 [Processing Management](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118648106880)
  - 1.13.2.1 [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647814784)
    - 1.13.2.1.1 [Background](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647836576)
    - 1.13.2.1.2 [Authority](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647827904)
    - 1.13.2.1.3 [Responsibilities](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118649056864)
    - 1.13.2.1.4 [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118649048432)
    - 1.13.2.1.5 [Program Controls](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118649043968)
    - 1.13.2.1.6 [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647807056)
    - 1.13.2.1.7 [Related Resources](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647779536)
  - 1.13.2.2 [SOI Statistical Editing Requirements](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647776944)
    - 1.13.2.2.1 [Performance Standards](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647772992)
    - 1.13.2.2.2 [Measuring Fulfillments of SOI Requests for Paper and Electronically Filed Returns](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647753952)
    - 1.13.2.2.3 [SOI Program Completion Requirements](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647717600)
    - 1.13.2.2.4 [SOI Edit Quality Procedures](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647598448)
  - 1.13.2.3 [SOI Individual and Tax Exempt Branch Programs](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647576496)
    - 1.13.2.3.1 [Sales of Capital Assets Study](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647548448)
    - 1.13.2.3.2 [Exempt Organizations](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647522368)
    - 1.13.2.3.3 [Tax-Exempt Bonds](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647478128)
    - 1.13.2.3.4 [Estate and Gift Tax Programs](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647457232)
  - 1.13.2.4 [SOI Corporation, Partnership, and International Branch Programs](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647407280)
    - 1.13.2.4.1 [Basic Corporation Program](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647404528)
    - 1.13.2.4.2 [Partnership Program](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647362128)
    - 1.13.2.4.3 [Minimum Effectively Connected Net Investment Income (MECNII) Study](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647355504)
    - 1.13.2.4.4 [Foreign Person's U.S. Source Income Subject to Withholding (Forms 1042-S)](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647350672)
    - 1.13.2.4.5 [Forms 8805 Study](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647348304)
    - 1.13.2.4.6 [Form 8288-A Study](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647343472)
    - 1.13.2.4.7 [Form 5471 Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647339840)
    - 1.13.2.4.8 [Form 1118 Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647335856)
    - 1.13.2.4.9 [Form 1118 Study, SOI Year 2017](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647330864)
    - 1.13.2.4.10 [Form 8832 Study, SOI Years 2018 and 2019](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647325872)
    - 1.13.2.4.11 [Form 8858 Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647320576)
    - 1.13.2.4.12 [Form 8865 Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647316800)
    - 1.13.2.4.13 [Form 8975 Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647312784)
  - Exhibit 1.13.2-1 [Basic Individual/Sole Proprietorship Studies, Tax Years 2016 and 2017](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647308992)
  - Exhibit 1.13.2-2 [Sales of Capital Assets (SOCA), Tax Years 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647284176)
  - Exhibit 1.13.2-3 [Corporation Program, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647270400)
  - Exhibit 1.13.2-4 [Corporation Program, SOI Year 2017](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647240768)
  - Exhibit 1.13.2-5 [Partnership Program, Tax Year 2017](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647211136)
  - Exhibit 1.13.2-6 [Partnership Program, Tax Year 2018](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647182416)
  - Exhibit 1.13.2-7 [Partnership Program, Tax Year 2019](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647153696)
  - Exhibit 1.13.2-8 [Minimum Effectively Connected Net Investment Income (MECNII) Studies, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647124928)
  - Exhibit 1.13.2-9 [Minimum Effectively Connected Net Investment Income (MECNII) Studies, SOI Year 2017](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647107024)
  - Exhibit 1.13.2-10 [Form 990 Studies, Tax Years 2015, 2016, 2017, and 2018](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647089072)
  - Exhibit 1.13.2-11 [Form 990-PF Studies, Tax Years 2015, 2016, 2017, and 2018](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118647002816)
  - Exhibit 1.13.2-12 [Form 990-T Studies, Tax Years 2014, 2015, 2016, and 2017](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646916496)
  - Exhibit 1.13.2-13 [Tax-Exempt Bonds Studies (Forms 8038), Tax Year 2017](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646824608)
  - Exhibit 1.13.2-14 [Tax-Exempt Bonds Studies (Forms 8038-G), Tax Years 2017 and 2019](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646806336)
  - Exhibit 1.13.2-15 [Estate Tax Studies, Tax Years 2017, 2018, and 2019](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646770720)
  - Exhibit 1.13.2-16 [Gift Tax Study, Filing Years 2017, 2018, and 2019](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646710016)
  - Exhibit 1.13.2-17 [Information Return of U.S. Persons with Respect to Certain Foreign Corporations (Form 5471) Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646657040)
  - Exhibit 1.13.2-18 [Corporation Foreign Tax Credit (Form 1118) Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646639808)
  - Exhibit 1.13.2-19 [Information Return of U.S. Persons With Respect To Foreign Disregarded Entities (Form 8858) Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646612496)
  - Exhibit 1.13.2-20 [Return of U.S. Persons With Respect to Certain Foreign Partnerships (Form 8865) Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646591904)
  - Exhibit 1.13.2-21 [Entity Classification Election (Form 8832) Study, SOI Year 2018](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646573216)
  - Exhibit 1.13.2-22 [Entity Classification Election (Form 8832) Study, SOI Year 2019](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646556880)
  - Exhibit 1.13.2-23 [Country By Country Report (Form 8975) Study, SOI Year 2016](https://www.irs.gov/irm/part1/irm_01-013-002#idm140118646540544)

# Part 1. Organization, Finance, and Management

# Chapter 13. Statistics of Income

# Section 2. Processing Management

* * *

## 1.13.2 Processing Management

#### Manual Transmittal

September 07, 2018

#### Purpose

(1) This transmits revised IRM 1.13.2, Statistics of Income, Processing Management.

#### Material Changes

(1) This section of the Internal Revenue Manual (IRM) describes the performance standards associated with the major Statistics of Income (SOI) studies. It also presents in the Exhibits section processing schedules that help the SOI units at the IRS submission processing centers meet critical processing dates during 2018 and later years.

(2) The SOI staff made editorial changes throughout this IRM section.

(3) Deleted section 1.13.2.4.5.

(4) Deleted Exhibit 1.13.2-17.

#### Effect on Other Documents

IRM 1.13.2, dated June 3, 2014, is superseded.

#### Audience

Submission Processing Centers across all Operating Divisions.

#### Effective Date

(09-07-2018)

Barry W. Johnson

Director

Statistics of Income Division OS:RAAS:S

**1.13.2.1** **(09-07-2018)**

### Program Scope and Objectives

1. **Purpose**: Section 1.13.2 of the Internal Revenue Manual (IRM) describes the quality standards and the critical processing dates of major studies of the Statistics of Income (SOI) Program.

2. **Audience**: The primary users of this IRM section include managers, statistical assistants, tax examiners, and IT computer specialists at the IRS submission processing centers and enterprise computing centers across the country; and, IRS managers, economists, statisticians, and IT computer specialists at the headquarters office of the Statistics of Income Division in Washington, D.C.

3. **Policy Owner**: Director, Statistics of Income Division.

4. **Program Owner**: The Statistics of Income Division, an organization within Research, Applied Analytics, and Statistics, is responsible for the administration, procedures, and updates related to the Statistics of Income (SOI) Program.

5. **Primary Stakeholders**: Areas within the IRS affected by the SOI program include the IRS submission processing centers and enterprise computing centers.

6. **Program Goals**: A division within the office of Research, Applied Analytics, and Statistics (RAAS), the Statistics of Income Division is responsible for formulating and executing the overall statistical policies and programs of the Internal Revenue Service (IRS). Its goals include:



   - formulating and executing the statistical policies, practices, and programs of the Internal Revenue Service;

   - collecting, analyzing, safeguarding, and disseminating information on Federal taxation in support of tax administration, economic policy development, and financial analysis;

   - serving a broad range of users in the IRS, the Federal government, the public, and the nonprofit sectors;

   - providing statistical support within the Service for a broad range of program evaluation and measurement analytics; and

   - leading efforts to modernize Federal statistical programs and practices through engagement with the Federal statistical community.


**1.13.2.1.1** **(09-07-2018)**

#### Background

1. The Statistics of Income (SOI) Division is one of the principal Federal statistical agencies. Economists, statisticians, computer specialists, and communication specialists primarily staff its four branches — Individual and Tax Exempt; Corporation, Partnership, and International; Information Management and Dissemination; and Statistical Services. These Branches are responsible for various SOI projects, producing tax statistics about individuals, estates, businesses, nonprofit organizations, trusts, and foreign investments. SOI uses both the Internet and traditional print publications to provide the public with data on the Federal tax system. It also provides answers to statistical inquiries (See [https://www.irs.gov/statistics/soi-tax-stats-tax-statistics-questions](https://www.irs.gov/statistics/soi-tax-stats-tax-statistics-questions)).

2. SOI provides tax statistics to the public, from individuals looking for tax information to executives engaged in strategic planning, and policy makers seeking data to evaluate and change tax laws. It also provide aggregate tax data, statistical services, and other support to the IRS Business Operating Divisions, Legislative Affairs, and Media Relations by responding to data requests, preparing testimony and reports, and conducting research. Other data users include:



   - Office of Tax Analysis

   - Joint Committee on Taxation

   - Bureau of Economic Analysis

   - U.S. Census Bureau

   - Board of Governors of the Federal Reserve

   - State and Local Governments

   - Non-profit research organizations

   - Academics

   - Tax Professionals

   - Citizens seeking to learn more about the tax system


**1.13.2.1.2** **(09-07-2018)**

#### Authority

1. Part III, General Administrative Provisions, Section 21, of the Revenue Act of 1916, which Congress approved September 8, 1916, stated:



> That the preparation and publication of statistics reasonably available with respect to the operation of the income tax law and containing classifications of taxpayers and of income, the amounts allowed as deductions and exemptions, and any other facts deemed pertinent and valuable, shall be made annually by the Commissioner of Internal Revenue with the approval of the Secretary of the Treasury.



In compliance with Section 21, the Office of Commissioner of Internal Revenue published the first report (Document No. 2817), entitled “Statistics of Income,” as compiled from the returns of personal and corporate income filed with the Treasury Department for the year ended December 31, 1916, on June 1, 1918. The summary section, located before the statistical tables at the beginning of the document, contained comparative figures for personal net income beginning with 1913, and corporate net income, beginning with 1909.

2. 26 U.S. Code § 6108 contains the following information about the preparation and publication of Statistical publications and studies:



1. Publication or other disclosure of statistics of income. The Secretary shall prepare and publish not less than annually statistics reasonably available with respect to the operations of the internal revenue laws, including classifications of taxpayers and of income, the amounts claimed or allowed as deductions, exemptions, and credits, and any other facts deemed pertinent and valuable.

2. Special statistical studies. The Secretary may, upon written request by any party or parties, make special statistical studies and compilations involving return information (as defined in section 6103(b)(2)) and furnish to such party or parties transcripts of any such special statistical study or compilation. A reasonable fee may be prescribed for the cost of the work or services performed for such party or parties.

3. Anonymous form. No publication or other disclosure of statistics or other information required or authorized by subsection (a) or special statistical study authorized by subsection (b) shall in any manner permit the statistics, study, or any information so published, furnished, or otherwise disclosed to be associated with, or otherwise identify, directly or indirectly, a particular taxpayer.


3. As one of the principal Federal statistical agencies, the activities of the Statistics of Income Division are largely the collection, compilation, processing, and analysis of federal tax information for statistical purposes. The other principal Federal statistical agencies are the:



   - Bureau of Economic Analysis

   - Bureau of Justice Statistics

   - Bureau of Labor Statistics

   - Bureau of Transportation Statistics

   - Census Bureau

   - Economic Research Service

   - Energy Information Administration

   - National Agricultural Statistics Service

   - National Center for Education Statistics

   - National Center for Health Statistics

   - National Center for Science and Engineering Statistics

   - Office of Research, Evaluation and Statistics (SSA)


Statistical work in the U.S. Government is also carried out by about programs in the Executive Branch that conduct statistical activities in conjunction with a program mission, such as providing services (for example, medical care benefits for the elderly and the poor) or enforcing regulations (for example, with respect to the environment, transportation, or occupational safety).

4. Additionally, there are other Federal agencies whose statistical activities are excluded because they are not part of the Executive Branch. These agencies include the:



   - Congressional Budget Office, which develops and applies projection models for the budgetary impact of current and proposed Federal programs;

   - Joint Committee on Taxation, which assists Congressional tax-writing committees and members of Congress with development and analysis of legislative proposals; prepares official revenue estimates of all tax legislation considered by the Congress; drafts legislative histories for tax-related bills; and investigates various aspects of the Federal tax system;

   - Federal Reserve Board, which compiles the widely used Flow of Funds report and other monetary statistical series and periodically conducts the Survey of Consumer Finances; and

   - U.S. Government Accountability Office, which develops statistical data in evaluations of government programs.


5. The 1995 reauthorization of the Paperwork Reduction Act of 1980 and other legislation give the Office of Management and Budget (OMB) the responsibility of approving agency information collection requests, including those for surveys and other statistical information. The OMB Office of Information and Regulatory Affairs (OIRA) coordinates the decentralized Federal statistical system. The OIRA Statistical and Science Policy (SSP) Office, headed by the U.S. Chief Statistician, coordinates the activities of the Federal statistical system to ensure the efficiency and effectiveness of the system as well as the integrity, objectivity, impartiality, utility, and confidentiality of information collected for statistical purposes. The Chief Statistician also promotes integration across the Federal statistical system by chairing the Interagency Council on Statistical Policy (ICSP), which enables OMB to obtain more direct participation from agencies in planning and coordinating Federal statistical activities. The ICSP is a vehicle for



   - coordinating statistical work, particularly when activities and issues cut across agencies;

   - exchanging information about agency programs and activities; and

   - providing advice and counsel to OMB on statistical matters.


6. Policy Statement 1-3 governs IRS research activities, which include statistics of income. The guidance in this IRM section conforms with Policy Statement 1-3 establishing the foundation for research in the IRS. The collection and analysis of data related to Service operations and strategic goals is essential in sound planning, management and evaluation of Service programs and activities. Studies, tests and research activities are conducted within the headquarter research function, RAAS, and within the operating divisions. See IRM 1.2.10.4.


**1.13.2.1.3** **(09-07-2018)**

#### Responsibilities

1. Research, Applied Analytics, and Statistics (RAAS) has general program oversight of research activities in the IRS. The Chief Research and Analytics Officer is responsible for coordination of research within the IRS and research conducted within the RAAS organization.

2. Responsibilities of the SOI Director, a senior executive who reports to the Chief Research and Analytics Officer, and the Senior Managers of the four SOI Branches (i.e., Individual and Tax Exempt; Corporation, Partnership, and International; Information Management and Dissemination; and Statistical Services) include



   - formulating and executing the statistical policies, practices, and programs of the Internal Revenue Service;

   - collecting, analyzing, safeguarding, and disseminating information on Federal taxation in support of tax administration, economic policy development, and financial analysis;

   - serving a broad range of users in the IRS, the Federal government, the public, and the nonprofit sectors;

   - providing statistical support within the Service for a broad range of program evaluation and measurement analytics; and

   - leading efforts to modernize Federal statistical programs and practices through engagement with the Federal statistical community.


3. Responsibilities of the SOI Senior managers and their Section Chiefs include



   - producing comprehensive statistics from the data collected from the income tax forms and associated schedules filed on individual, tax-exempt organization, tax-exempt bond, gift, and estate tax returns;

   - producing comprehensive statistics on corporation income tax returns, partnership returns, and international taxpayers, including businesses, individuals, and trusts, through a variety of studies;

   - providing IT support for numerous SOI studies and RAAS initiatives, preparing publications for printing and dissemination, and managing the Statistical information Services (SIS) office and the Tax Stats Web site; and

   - providing statistical services to various organizations across the IRS, producing sample designs and weights for the major SOI studies, providing statistical support for numerous IRS quality measures, surveys, and pilot programs throughout the IRS organization, as well as producing projections of tax return volumes for IRS workload planning.


**1.13.2.1.4** **(09-07-2018)**

#### Program Management and Review

1. All IRS research projects are listed on the Research and Analytics (R&A) Project Repository at https://organization.ds.irsnet.gov/sites/ras/raaspmo/SitePages/RAPCHome.aspx. The repository houses an inventory of all active research projects and studies and prior studies since 2016. It is accessible to all research personnel in the IRS and, therefore, provides a communication vehicle for sharing types of projects and programs that the research community is conducting in support of the IRS mission.

2. SOI conducts special statistical studies based on tax returns or performs certain functions related to statistical studies, often on a reimbursable basis. In the latter capacity, it provides data to agencies and individuals authorized by the Internal Revenue Code to receive tax return information for statistical use. Major SOI products include the annual SOI reports compiled from individual and corporation income tax returns, which feature income statement, balance sheet and tax data by industry and form type. SOI also compiles historical data tables for corporations, sole proprietorships, and partnerships. Most SOI studies are summarized for public use in the SOI Bulletin. The Bulletin includes data formerly published in separate reports, summary analyses of previously published tabulations, and results of special studies and analyses. SOI reports are available on Tax Stats not only for the public but also for analysts throughout the IRS, within the Treasury Department, and other Federal Government, including the Congressional Joint Committee on Taxation (JCT). SOI also produces a public-use file of individual income tax returns, which contains separate tax return records, stripped of identifying information and edited to prevent disclosure.


**1.13.2.1.5** **(09-07-2018)**

#### Program Controls

1. IRM 1.13.2 describes the Statistics of Income (SOI) program requirements. It includes information on the following:



   - Performance standards associated with SOI studies.

   - Descriptions of major SOI studies.

   - Schedules of critical processing dates in 2018 and later processing years.


2. SOI programs and services include:



   - Selecting IRS tax and information returns for its samples.

   - Statistical processing of tax and information returns in its samples.

   - Disseminating micro-level, aggregate, and tabular statistical data based on its samples.

   - Making returns in its samples available to other IRS functions.


3. Implementation of SOI program requirements occurs in the SOI National Headquarters, submission processing centers, and Martinsburg Computing Center. SOI staff furnish technical guidance and direction to the submission processing centers and Martinsburg Computing Center to implement the SOI programs. Such guidance is related to phases of the statistical work, including the identification of problems and the development of solutions, and often requires written procedures, including those necessary for the selection of samples. To assure that program implementation is correct, SOI evaluates the SOI work performed by the submission processing centers through quality assurance programs, internal audit reports, and on-site reviews of the SOI field processing operation.

4. The Submission Processing Center Work Plans include resources for carrying out the SOI programs.


**1.13.2.1.6** **(09-07-2018)**

#### Terms/Definitions/Acronyms

1. Below are words that require interpretation and their definitions.



**Acronyms**






| Acronyms and Abbreviations | Definition |
| --- | --- |
| BEA | Bureau of Economic Analysis (Department of Commerce) |
| BMF | Business Master File |
| ASPC | Austin Submission Processing Center |
| CSPC | Cincinnati Submission Processing Center |
| CY | Calendar Year |
| ECC-MTB | Enterprise Computing Center - Martinsburg |
| DLN | Document Locator Number |
| EIN | Employer Identification Number |
| ELMS | Enterprise Learning Management System |
| EQSP | Embedded Quality for Submission Processing |
| FOIA | Freedom of Information Act |
| FRB | Federal Reserve Board |
| FSPC | Fresno Submission Processing Center |
| JCT | Joint Committee on Taxation (Congress) |
| KSPC | Kansas City Submission Processing Center |
| IDRS | Integrated Document Retrieval System |
| IMF | Individual Master File |
| MEPS | Measured Employees Performance System |
| NAICS | North America Industry Classification System |
| OSPC | Ogden Submission Processing Center |
| OTA | Office of Tax Analysis (Department of Treasury) |
| PCD | Program Completion Date |
| PY | Processing Year |
| RAAS | Research, Applied Analytics, and Statistics |
| SOI | Statistics of Income |
| STARTS | Statistics of Income Automated Return Tracking System |
| TEPS | Total Evaluation Performance System |
| TY | Tax Year |
| W&I | Wage and Investment |


**1.13.2.1.7** **(09-07-2018)**

#### Related Resources

1. SOI makes its reports available to the general public on [https://www.irs.gov/statistics](https://www.irs.gov/statistics). These Web pages include annual reports, historical data, SOI Bulletins, tabulations, and micro-data files for tax-exempt organizations.


**1.13.2.2** **(09-07-2018)**

### SOI Statistical Editing Requirements

1. SOI selects returns for its studies at all the IRS submission processing centers that continue to accept paper returns and electronically-filed returns. It centralized statistical edit processing of its samples in five submission processing centers (i.e., Austin, Cincinnati, Fresno, Kansas City, and Ogden). SOI expects the current five submission processing centers to carry out all, or a portion thereof, the tasks described in this IRM section and other IRM sections SOI publishes. According to the current submission processing consolidation plan (http://win.web.irs.gov/Submission\_Processing/Consolidation.htm), the IRS will have only two submission processing centers in 2024. While the Kansas City submission processing center will focus on individual tax returns, and Ogden business tax returns, with both having the capability to process all kinds of paper and electronically filed tax and information returns, SOI plans to select and statistically edit various paper and electronically filed tax and information returns at both centers. In anticipation of the closing of submission processing operations in Covington, Kentucky (i.e., Cincinnati) in 2019, W&I will begin transition work from Cincinnati to Kansas City and Ogden in 2018. Consequently, SOI will support the creation of an SOI 1040 edit unit in Ogden and an SOI 1120 edit unit in Kansas City in 2018.


**1.13.2.2.1** **(09-07-2018)**

#### Performance Standards

01. IRS managers at the submission processing centers use the Measured Employees Performance System (MEPS), which replaced Total Evaluation Performance System (TEPS), to evaluate GS-08 and below employees measured in quality and/or efficiency under the Performance Standards concept as mandated in the 2016 National Agreement. The Performance Standards concept requires that employees receive information on how they must perform to achieve a quality and/or efficiency rating level (1 through 5) before the work is performed. MEPS was implemented consistent with the MEPS Memorandum of Understanding (MOU) for measured submission processing center employees between Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU). Effective October 1, 2013, MEPS became the system utilized by managers to provide evaluative ratings for employees measured in quality and/or efficiency.

02. Submission processing centers should establish a work environment for its employees that emphasizes quality in its products and services. This includes a locally-developed plan that ensures both manager and employee commitment to producing quality SOI data.

03. National Office SOI analysts may conduct visits to the SOI submission processing centers for training and on-site reviews, or employ tele- and video-conferencing to communicate with managers and employees at these centers. Closeout meetings should include representatives from SOI editing, SOI programming, Planning and Analysis Staff, Post-Processing Division, and any other function involved in, or affected by, SOI processing at the submission processing centers.

04. Centers should regularly conduct quality review of each editor's work as prescribed in an SOI study's quality measurement plan.



    1. The SOI edit application quality review systems provide results of editor quality reviews in the form of reports, charts, or graphs. Edit unit managers and editors should receive these outputs on a regular and timely basis.

    2. SOI distributes reports from the quality review systems to managers and editors each week as prescribed in the TEPS agreement. The centers use these guides to measure and improve their progress in quality management.


05. The submission processing centers should monitor photocopying, scanning, and rendering of SOI returns to ensure that the photocopies and images are complete and legible. They should continually screen a small sample of photocopies and images before releasing the original paper returns back to Files, another IRS function, or a Federal Records Center.

06. All the submission processing centers should monitor the shipping, or electronic transfer, of returns between centers. Periodic managerial reviews should occur at each step in this process.

07. Cincinnati and Ogden Submission Processing Centers, with the assistance of National Office SOI staff, will maintain a system to track electronic transmissions among their centers, National Office, and the Enterprise Computing Center in Martinsburg, to ensure timely receipt of SOI data.



    1. The programming staffs in Cincinnati and Ogden should conduct an annual survey of their documentation to ensure that the technical information contained in their operating and programming manuals is complete and current.

    2. Personnel should follow established documentation standards for the programs operating at their centers. They should work with National Office SOI staff to establish standards for documentation about hardware, software, processes, and user operations.


08. SOI improves its chances of meeting its quality standards when the SOI edit units at the centers:



    1. maintain a staff of trained and experienced editors and clerks;

    2. consider experience in returns processing as one criterion for selecting new editors and clerks;

    3. keep the same editors on a program for the entire processing cycle;

    4. provide additional training and coaching to improve the performance of editors who do not achieve minimum quality standards, as reflected in the quality review reports;

    5. monitor each editor's performance in meeting the minimum quality standards;

    6. recognize outstanding performances by employees, managers, management officials, analysts, programmers, statisticians, statistical assistants, tax examiners, etc., who work on SOI projects;

    7. identify mutually acceptable system improvement initiatives with National Office SOI analysts who conduct on-line reviews of actual editing during site visits, or query the SOI databases and convey their findings through other mediated communications;

    8. rank local issues and take action to resolve the more significant problems; and

    9. forward systemic issues outside their control to National Office for consideration.


09. SOI will provide centralized training for editors who work with returns selected for the major studies. The submission processing centers augment this training with local training when they deem it necessary. The centers should also measure the effectiveness of the local and centralized training with class evaluations.

10. Centers should implement "100 percent reviews" of the work of all the SOI editors as prescribed by each of the various SOI studies, and, share the results with the appropriate National Office SOI analysts. The SOI program overall benefits from these types of reviews because they



    1. identify systemic and training problems;

    2. refresh the skills of experienced editors who return to a study or shift to more complex returns in a particular study;

    3. generate suggested improvements in the editing procedures and future training sessions; and

    4. initiate more immediate refresher training sessions for specific problem areas.


**1.13.2.2.2** **(09-07-2018)**

#### Measuring Fulfillments of SOI Requests for Paper and Electronically Filed Returns

1. While SOI can identify many critical phases in its workflow, it considers the controlling of its samples as one of the most important. Although SOI control unit clerks no longer operate in the Files area of a submission processing center, SOI continues to measure the success of each submission processing center in obtaining and controlling paper returns, transcripts of electronically filed returns, and electronic records (text and images) of paper and electronically filed returns.

2. SOI relies on its infrastructure and the IRS infrastructure to increase the likelihood SOI edit unit managers will have an inventory of paper and electronically filed returns to distribute to their editors (i.e., tax examining technicians).



1. The Research, Applied Analytics, and Statistics Distributed Processing System (RAAS-DPS) includes databases, applications, and scanning/rendering processes Data Management (DM) Division and SOI personnel in National office and at the submission processing centers utilize to meet the Service’s requirement to report at least annually to the Secretary of Treasury and Congress on the numbers and types of returns filed, the characteristics of those returns, and the money amounts and text reported on those returns. DMD scanning operations include the LMSB Image Network (LIN), the Statistics of Income Exempt Organizations Return Image Network (SEIN), and the Distributive Processing System Image Network (DIN), the last giving SOI editors and analysts access to scanned images of the returns SOI selects for its Corporation, Partnership, and Estates programs.

2. The Service Center Recognition Image Processing System (SCRIPS) scans Forms 940 and 941, and the Schedules K-1 filers attach to Forms 1041, 1120S, and 1065. SCRIPS performs data capture via reading the printed 2D Bar Code, if this code is present on the Schedule K-1, and character recognition of data printed on the forms. SCRIPS operators perfect the data which is then output to Data Edit Validation (DED), and then the Generalized Mainline Framework (GMF). The SCRIPS unit sends the output data and scanned images of the Schedules K-1 to the RAAS systems in Ogden and Cincinnati.

3. The Modernized Tax Return Database Data Store (M-TRDB DS) is the legal repository for original electronically filed returns the IRS receives under Modernized e-File (MeF). Tax return data also includes Code and Edit Sheet Value Data, the DLN generated by the e-file system, and a copy of the data sent to Generalized Mainline Framework (GMF).

4. The Employee User Portal (EUP) is a Web hosting infrastructure. It supports an intranet portal that allows IRS employees to access business applications and data (e.g. Integrated Financial Services (IFS), e-Services (e-Services), Modernized E-File (MeF) and Customer Account Data Engine - Individual (CADE-I) in the future). The EUP infrastructure is located at ECC-MTB.

5. Individual Master File (IMF) is a reference term representing a number of systems such as Individual Master File Pre-Posting (IMF PRE-POSTING, IMF INPUTS), Individual Master File Posting and Analysis (IMF ANALYSIS), Individual Master File Outputs (IMF OUTPUTS), IMF Discriminant Index Function Inventory (IMF DIF INV), and Individual Master File On-Line (IMFOL). These systems make up the systems in the IMF E300. These systems are part of the Individual Master File Mainline Processing, except for IMF Doc Specific, which is considered part (sub system) of the Generalized Mainline Framework (GMF).

6. The Executive Control Program for IMF Extract (IMF 701 EXEC) reads all the individual master file accounts and the individual return transaction file. The executive system passes control to a series of load modules. Load modules analyze the taxpayer accounts and return data for reports and extracts. Load modules are documented under the Application System that performs the process that includes the extract. Run numbers are 701-61, 62, 63, 64, 65, 67, 69, 6B, 6C, 6D, 6E, 6F, 6G, 6L, and 445-91.

7. The Executive Control Program for Business Master File (BMF) Extract (BMF 701 EXEC) is the Executive Control Application System that reads all the business master file accounts. The executive system passes control to a series of load modules. Load modules analyze the taxpayer accounts for reports and extracts. Load modules are documented under the Application System that performs the process that includes the extract. Run numbers are 701-01, 701-0D, 701-0E, 701-02, 701-06, 701-07, 7A102, 7B102, 7C102, 7D102, and 7E102.


3. Securing paper returns in SOI samples as soon as possible before or after the delivery of charge-outs to Files is one of several steps different IRS offices take to meet the objectives of the SOI program. To ensure SOI can process its samples, various IRS offices, including SOI and DMD, will:



01. Run sampling and sub-sampling programs at the Enterprise Computing Center (ECC-MTB), and the submission processing centers in Cincinnati and Ogden;

02. Create charge-out files for specific SOI projects;



       ### Note:



       SOI units at the Cincinnati and Ogden campuses produce BMF outputs, such as charge-outs and selection sheets, from the BMF Statistics of Income Automated Return Tracking System (STARTS).

03. Transmit charge-out files to the main print rooms at the submission process centers, or the SOI Branch;

04. Ship charge-outs from SOI sites to the submission processing centers for special projects;

05. Use the charge-outs to pull returns in the Files area, or other storage areas of a submission processing center;

06. Monitor the inventory of returns in SOI control at the centers, as well as those returns not in SOI control;

07. Ship or move returns to the SOI edit units at the centers;

08. Account for each return in the sample in the SOI edit units;

09. Update the SOI IMF and BMF STARTS database applications in the SOI edit units, or the SOI Branch;

10. Check regularly the STARTS Missing Returns Reports which list what is still not in SOI control; and

11. Report the number of missing returns for each SOI project to SOI National Office.


4. Between cycles "03" and "52" (or "53" in some years), ECC-MTB, and the Cincinnati and Ogden Submission Processing Centers, produce and transmit information about SOI samples to the submission processing centers in the form of charge-outs (IRS and SOI (i.e., STARTS)) , selection sheets, and other useful media. The centers use this information to pull the samples of paper returns within one week of their selection. SOI Edit units are more productive when the centers secure all of the returns within the first week. Securing the returns first for SOI reduces the costs associated with attempting to obtain them from other IRS functions and increases the likelihood that the SOI edit units will meet SOI program completion dates.

5. A successful "First Pull" performance for each of the major SOI studies at a submission processing center is presented in the table below. The standards in the table refer to the average number of missing returns one week after the first attempt to find documents in the samples.




| SOI Program | Average Number of Returns Missing<br> One Week after First Pull Less than or Equal to: |
| :-- | :-- |
| 1040 | 3 |
| 1120 | 3 |
| 1065 | 1 |
| 990 Series | 2 |
| 8038 Series | 1 |
| 706 | 1 |
| 709 | 1 |


**1.13.2.2.3** **(09-07-2018)**

#### SOI Program Completion Requirements

1. For SOI to produce accurate and timely tax and financial information for its customers, the submission processing centers need to secure and edit timely the returns in the SOI samples. SOI program completion requirements shown below give the centers a schedule to meet these goals.




| Program/SOI<br> Year | Cutoff<br> ECC-MTB1<br> Cycle | Percent Edited<br> Standard at PCD2 | Standard<br> for<br> Maximum<br> Number<br> Missing<br> at PCD | Program<br> Completion<br> Date<br> (PCD) |
| :-: | :-: | :-: | :-: | :-: |
| TY 2016 Form 1040 Advance<br> Data | 201738 | 99.7% of<br> Cross-Sectional<br> Returns | 60 | 10-27-2017 |
| TY 2016 Form 1040 Complete<br> Report | 201752 | 99.7% of all returns | 30 | 02-16-2018 |
| TY 2017 Form 1040 Advance<br> Data | 201838 | 99.7% of<br> Cross-Sectional<br> Returns | 60 | 10-26-2018 |
| TY 2017 Form 1040 Complete<br> Report | 201852 | 99.7% of all returns | 30 | 02-08-2019 |
| SOI Year 2016<br> Corporations | 201826 | All controlled returns | 30 | 07-12-2018 |
| SOI Year 2017<br> Corporations | 201926 | All controlled returns | 30 | 07-11-2019 |
| Tax Year 2017<br> Partnerships | 201852 | All controlled returns | 5 | 01-30-2019 |
| Tax Year 2018<br> Partnerships | 201952 | All controlled returns | 5 | 01-30-2020 |
| Tax Year 2019<br> Partnerships | 202052 | All controlled returns | 5 | 01-30-2021 |
| 2017 Form 706 | 201752 | All controlled returns | 2 | 04-30-2018 |
| 2018 Form 706 | 201852 | All controlled returns | 2 | 04-30-2019 |
| 2019 Form 706 | 201952 | All controlled returns | 2 | 04-30-2020 |
| 2017 Form 709 | 201752 | All controlled returns | 2 | 06-30-2018 |
| 2018 Form 709 | 201852 | All controlled returns | 2 | 06-30-2019 |
| 2019 Form 709 | 201952 | All controlled returns | 2 | 06-30-2020 |
| 2015 Form 990 | 201752 | All controlled returns | 2 | 01-31-2018 |
| 2016 Form 990 | 201852 | All controlled returns | 2 | 01-31-2019 |
| 2017 Form 990 | 201952 | All controlled returns | 2 | 01-31-2020 |
| 2018 Form 990 | 202052 | All controlled returns | 2 | 01-31-2021 |
| 2015 Form 990-F | 201752 | All controlled returns | 2 | 04-15-2018 |
| 2016 Form 990-F | 201852 | All controlled returns | 2 | 03-30-2019 |
| 2017 Form 990-F | 201952 | All controlled returns | 2 | 03-30-2020 |
| 2018 Form 990-F | 202052 | All controlled returns | 2 | 03-30-2021 |
| 2014 Form 990-T | 201652 | All controlled returns | 2 | 06-30-2018 |
| 2015 Form 990-T | 201752 | All controlled returns | 2 | 12-30-2019 |
| 2016 Form 990-T | 201852 | All controlled returns | 2 | 06-30-2020 |
| 2017 Form 990-T | 201952 | All controlled returns | 2 | 06-30-2021 |
| 2017 Form 8038 | 201730 | All controlled returns | 5 | 12-31-2018 |
| 2017 Form 8038-G | 201730 | All controlled returns | 5 | 06-30-2017 |
| 2019 Form 8038-G | 201930 | All controlled returns | 5 | 06-30-2019 |
| 1 ECC-MTB is the acronym for Enterprise Computing Center - Martinsburg<br>2 PCD is the acronym for Program Completion Date |


**1.13.2.2.4** **(09-07-2018)**

#### SOI Edit Quality Procedures

1. The centers measure edit quality in the SOI Individual, Corporation, Partnership, and Special Studies programs by sampling continuously from all of the edited returns; having the samples edited independently by a second SOI editor; systemically comparing each element entered by both the first and second SOI editors; and, finally having a quality reviewer (quality lead) review and compare both sets of records and resolve any mismatches.



1. For product quality, "Edit Accuracy" means the percentage of editable elements completed correctly by the first editor. Errors by the second editor are not considered in measuring "Edit Accuracy " , but are part of the feedback discussion.

2. "Systemic" errors (errors that SOI attributes to resources provided by National Office, such as instructions or systems) and "judgment" differences (differences that SOI attributes to different interpretations about how an editor edits an element) are not counted when computing the Edit Accuracy Rate. In a judgmental situation both answers are acceptable. SOI requires discussion of systemic errors with the SOI program analyst in National Office. Each SOI editing center must achieve the following cumulative Edit Accuracy Rates:


| Program(s) | Minimum Required Edit<br> Accuracy Percent |
| :-- | :-- |
| Individual | 99.7 |
| Sales of Capital Assets (SOCA) | 99.3 |
| Corporation | 98.5 |
| Partnership | 98.5 |
| Estate | 98.5 |
| Gift Tax | 98.5 |
| Tax-Exempt Organizations | 99.5 |
| Tax-Exempt Bonds | 98.5 |

2. As suppliers of SOI data, each SOI unit at a submission processing center should develop customer service goals that will improve the communications between the centers and National Office SOI staff. The SOI units at the centers should develop the goals during meetings and conference calls they conduct with the different SOI project teams in National Office.

3. SOI managers at the submission processing centers are encouraged to use the on-line communication logs which are part of the edit applications in most studies. These electronic logs are a place to document significant problems in SOI processing, as well as suggestions and quality improvement opportunities, which National Office analysts survey when considering solutions and revising procedures and application capabilities.


**1.13.2.3** **(09-07-2018)**

### SOI Individual and Tax Exempt Branch Programs

01. The Individual SOI Program samples the Form 1040, Form 1040A, and Form 1040EZ, and collects data on the sources of income, exemptions, itemized deductions, and tax computations of individual tax filers. _Exhibit 1.13.2-1_ contains information about the processing schedule.

02. In addition to the regular Individual SOI sample, there is a high-income cohort of approximately 28,000 returns, which SOI selected from the Tax Year 2007 returns that the taxpayers filed and then SOI selects the current year return for the same set of taxpayers. SOI estimates that about 5,000 of these returns will overlap with the regular Individual SOI sample. This statistical concept requires collection and processing of information for both the primary and secondary taxpayers reported on a return. It will also include processing of dependent returns as part of a "family" . This will require an end-of-year computer sample run (Cycle 20XX54) at the Enterprise Computing Center - Martinsburg (ECC-MTB), which secures additional "family" returns that neither SOI nor ECC-MTB identified during the regular sampling period. However, none of these dependent returns will require edit processing at the centers.

03. Using the RAAS Distributed Processing System (RAAS-DPS), on-line editing of the selected returns occurs at the following centers: Austin, Cincinnati, Fresno, Kansas City, and Ogden. These SOI processing centers also find and control returns in the SOI samples. Upon completion of processing, the SOI edit units ship the paper returns back to the originating center's SOI control unit or Files for refiling.

04. The total sample size SOI expects to edit for the TY 2017 program is approximately 420,000 returns. The expected total sample volumes at each of the two SOI IMF program closeout dates are shown below.




    | Program | Closeout Date | Volume | Cycles |
    | :-: | :-: | :-: | :-: |
    | Advance<br> Data | October 26, 2018 | 355,000 | 201804 to 201838 |
    | Complete<br> Report | February 8, 2019 | 450,000 | 201804 to 201852 |

05. Training classes on the TY 2017 Prototype Individual SOI Modernization (PRISM) and Sales of Capital Assets (SOCA) edit systems are conducted for managers and tax examiners from the Austin, Cincinnati, Fresno, Kansas City, and Ogden SOI processing centers. The training addresses processing, systems, and quality features of the database applications.

06. The centers produce reports from the Individual Systematic Improvement System (ISI) to monitor program quality. They should inform National Office of any information that they believe the other centers would benefit from knowing about or using in their own PRISM operations.

07. SOI processing centers should staff the program with at least three tax examiners who are trained and experienced in the on-line editing operations for Individual returns. They should try to keep the same people on the program for the entire processing period.

08. At the beginning of each processing year, both Publishing Services and SPDER store in their electronic repositories a copy of IRM 1.13.3, Document Management. This section of the IRM contains the most current instructions for handling SOI samples. In addition, if controlling or shipping procedures change during the processing year, the SOI Individual Statistics Branch sends updated information to each SOI 1040 Edit Unit at the submission processing centers.

09. A feature in the PRISM edit application enables submission processing center personnel to report editing problems and issues on-line and to receive on-line responses from the National Office PRISM team. Use of this feature provides immediate sharing of information among all processing centers.

10. The Individual Systematic Improvement (ISI) system is applicable to all 1040 return types as a quality measurement tool for the centers.



    1. ISI is a "double-edit" system in which SOI compares in a nightly match program a sample of edited returns to the second edit (QR) of those same returns.

    2. A Quality Reviewer examines any differences between the two sets through a reconciliation process.

    3. National Office SOI and the centers can generate reports that show ISI data tabulations by discrepancy codes, tax examiner ID, and program accuracy rates, along with errors per element broken down by form or schedule.


11. As indicated earlier, all on-line review systems generate reports for the centers. Each center's interpretation and response to these output reports are a key means for identifying improvement opportunities.


**1.13.2.3.1** **(09-07-2018)**

#### Sales of Capital Assets Study

1. The Tax Year 2016 Sales of Capital Assets (SOCA) Panel Study will consist of returns chosen for the high-income cohort and returns in the Tax Year 2007 Individual SOI sample which have a primary or secondary SSN that matches one of the initial set of ten Continuous Work History Study (CWHS) ending digits (See <a href="http://irm.web.irs.gov/link.asp?link=1.13.2.3">IRM 1.13.2.3</a> for more information about the Tax Year 2016 Individual SOI Study; and also _Exhibit 1.13.2-2_ for the processing schedule). SOI expects to select a total of 275,000 returns for this 2007-Based SOCA Panel study with approximately 62,000 of the returns containing transaction data.

2. SOCA data consists of information that the filer reports on Form 1040, Schedule D, Form 8949, Sales and Other Dispositions of Capital Assets, and other supplementary schedules that provide transaction information about:



   - Sales of personal and depreciable property (Form 4797).

   - Computation of installment sales income (Form 6252 ).

   - Like kind exchanges (Form 8824).

   - Gains and losses from section 1256 contracts and straddles (Form 6781).


3. The PRISM system also identifies returns for SOCA. Photocopying of each return is not necessary if the unit edits from the original.

4. Before going into production, National Office will conduct asset coding and tax examiner training classes using manuals and on-line instruction.

5. The centers employ two methods to review the asset coding and editing.



1. The first entails the lead tax examiners and SOI managers conducting a 100 percent review of returns. For experienced editors the reviews are the lesser of twenty returns or sixteen hours of editing, while for inexperienced editors it is the lesser of forty returns or thirty-two hours of editing.

2. The second is a computer-generated random selection method that quality reviewers use to review continuously tax examiners' work throughout the life cycle of the project.


6. The SOI units edit SOCA returns and test the data in one phase. This allows for the detection of balancing inconsistencies in the data during data entry.

7. National Office analysts and the processing center management teams (including lead tax examiners) can use daily SOCA reports to keep track of the progress in editing and the number of errors.



1. Using reports will regularly help track areas that need improvement, consequently increasing the quality of the program.

2. A communication log which links the SOI editing sites, National Office, and the Files units will enhance communication between the submission processing centers and National Office.


8. If possible, each tax examiner should have access to the following books:




| Name | Order From: |
| :-- | :-- |
| Stock Guide (year-end edition) | Standard and Poors Corporation<br> 25 Broadway, 17th Floor<br> New York, NY 10004<br> (800) 221-5277 |
| Dictionary of Finance and Investment Terms<br> Barron's Financial Guides (ISBN:0-8120-9035-7) | Barron's Educational Services, Inc.<br> 250 Wireless Blvd.<br> Hauppauge, N.Y. 11788 |
| Dictionary of Business Terms<br> Barron's Business Guides (ISBN:0-8120-3775-8) | Barron's Educational Services, Inc.<br> 250 Wireless Blvd.<br> Hauppauge, N.Y. 11788 |


**1.13.2.3.2** **(09-07-2018)**

#### Exempt Organizations

1. Exempt Organization Programs that SOI manages during Processing Years (PY) 2018 and 2019 are the Tax Years (TY) 2015, 2016, 2017, and 2018 Private Foundations Studies (Form 990-PF); the TY 2015, 2016, 2017, and 2018 Exempt Organization Studies (Form 990 and Form 990-EZ); and, the TY 2014, 2015, 2016, and 2017 Exempt Organization Unrelated Business Income Returns Studies (Form 990-T).

2. The expected sample sizes and workloads associated with the SOI processing of the "Exempt" returns in Ogden during PY 2018 and 2019 are shown below.



**Form 990 Series Workloads**






| Study Year\* | Expected<br> Sample | PY 2018 | PY 2019 |
| :-: | :-: | :-: | :-: |
| 2015 Form 990-PF | 19,500 | 11,725 | Done |
| 2016 Form 990-PF | 19,500 | 11,700 | 7,800 |
| 2017 Form 990-PF | 19,500 | – | 16,575 |
| 2018 Form 990-PF | 19,500 | – | – |
| 2015 Form 990 | 22,000 | 1,000 | Done |
| 2016 Form 990 | 22,000 | 21,000 | 1,000 |
| 2017 Form 990 | 22,000 | – | 21,000 |
| 2018 Form 990 | 22,000 | – | – |
| 2014 Form 990-T | 7,000 | 3,500 | 3,500 |
| 2015 Form 990-T | 7,000 | 7,000 |  |
| 2016 Form 990-T | 7,000 | – | 3,500 |
| 2017 Form 990-T | 7,000 | – | – |
| \*The workload figures do not include returns selected for quality review double edit. |

3. Editing, transcription and error resolution are consolidated into one "data capture and cleaning" operation. The editing systems test certain data fields as editors enter information in them; it tests others as editors enter information in related fields.

4. Ogden should develop quality standards for data capture and cleaning (i.e., editing, transcription, and error resolution) and review them with National Office personnel. A plan to measure whether the center is meeting these standards should be developed during the first month of processing and steps for conducting a joint periodic review should be agreed upon.

5. Ogden should staff the SOI Unit with tax examiners who are trained and experienced in the edit/error resolution operations for exempt organization returns. These examiners should be pre-trained by OSPC personnel in the operation of the Oracle terminal keyboard and special function keys used for the exempt studies before receiving program training from the National Office analysts.

6. Ogden should establish an acceptance sampling process to detect whether a center has to re-photocopy, re-scan, or re-render batches of returns.


**1.13.2.3.3** **(09-07-2018)**

#### Tax-Exempt Bonds

1. The Tax-Exempt Bonds Studies for PY 2018 and 2019 involve locating, controlling, and editing 2017 Forms 8038, Information Return for Tax-Exempt Private Activity Bond Issues; and, 2017, 2018, and 2019 Forms 8038-G, Information Return for Tax-Exempt Governmental Obligations. The submission processing centers no longer edit Forms 8038-T, 8038-CP, and 8038-TC.

2. The workload goals for Ogden are presented below.



**Form 8038 Series Workloads**






| Filing Year | Expected<br> Population | PY 2018 | PY 2019 |
| :-: | :-: | :-: | :-: |
| 2017 Form 8038 | 3,000 |  | 3,000 |
| 2017 Form 8038-G | 24,400 | 24,400 | – |
| 2019 Form 8038-G | 24,400 | – | 12,2000 |


**1.13.2.3.4** **(09-07-2018)**

#### Estate and Gift Tax Programs

1. The pulling, controlling, and editing of returns in the Estate Tax Study occur at the Cincinnati Submission Processing Center. The 2019 Estate Tax study will be fully transitioned to the Kansas City Submission Processing Center.



1. The expected sample size of the 2017 study is 8,000 returns. Selection of the returns began in January 2017, and editing in March 2017.

2. The expected sample size of the 2018 study is 8,000 returns. Selection of these returns begins in January 2018, with editing starting in March 2018.

3. The expected sample size of the 2019 study is 4,000 returns. Selection of the returns begins in January 2019, and editing in March 2019.


2. The pulling and controlling of returns for the Gift Tax Study occur at the Cincinnati Submission Processing Center. The SOI unit at the Ogden Submission Processing Center currently edits these returns.



1. The expected sample size of the 2017 Gift Tax Study is 5,000 returns. The sample consists of returns filed in 2017 for gifts given in 2016. Sample selection of the Forms 709 began at the Cincinnati Submission Processing Center in 2017. SOI began editing these documents in Ogden in November 2017.

2. The expected sample size of the 2018 Gift Tax Study is 5,000 returns. The sample consists of returns filed in 2018 for gifts given in 2017. Sample selection of the Forms 709 begins at the Cincinnati Submission Processing Center in 2018. SOI expects to begin editing these documents in Ogden in November 2018.

3. The expected sample size of the 2019 Gift Tax Study is 5,000 returns. The sample consists of returns filed in 2019 for gifts given in 2018. Sample selection of the Forms 709 begins at the Cincinnati Submission Processing Center in 2019. SOI expects to begin editing these documents in Ogden in November 2019.


3. The following table shows the expected workload at the Cincinnati and Ogden Centers for the three Estate and three Gift Tax studies.



**Forms 706 and 709 Workloads**






| Study Year | Center | Expected Sample | PY 2017 | PY 2018 | PY 2019 | PY 2020 |
| :-: | :-: | :-: | :-: | :-: | :-: | :-: |
| 2017 Form 706 | Cincinnati | 8,000 | 6,000 | 2,000 | – | – |
| 2018 Form 706 | Cincinnati | 8,000 | – | 6,000 | 2,000 | – |
| 2019 Form 706 | Kansas City | 8,000 | – | – | 6,000 | 2,000 |
| 2017 Form 709 | Ogden | 5,000 | 5,000 | – | – | – |
| 2018 Form 709 | Ogden | 5,000 | – | 5,000 | – | – |
| 2019 Form 709 | Ogden | 5,000 | – | – | 5,000 | – |

4. Cincinnati should develop quality standards for data capture and cleaning (i.e., editing, transcription, and error resolution) and review them with National Office personnel. The center should complete the development of a plan to measure whether the center has met these standards during the first month of processing, as well as discuss with National Office the steps for conducting joint periodic reviews.

5. The Cincinnati Center should ensure that all original Forms 706, which are processed for the Estate study, are returned to Files within six weeks of receipt in its SOI edit unit.

6. Cincinnati should staff the SOI Units with tax examiners who are trained and experienced in the edit/error resolution operations for estate tax returns.


**1.13.2.4** **(09-07-2018)**

### SOI Corporation, Partnership, and International Branch Programs

1. The following information covers processing of the documents selected for the SOI Corporation, Partnership, and International Branch Programs for SOI Years 2016 and 2017. See _Exhibit 1.13.2-3_ through _Exhibit 1.13.2-9_ for information about the processing schedules.


**1.13.2.4.1** **(09-07-2018)**

#### Basic Corporation Program

1. During Processing Years (PY) 2018 and 2019, the submission processing centers will collect samples of Form 1120, Form 1120-L, Form 1120-PC, Form 1120S, Form 1120-F, Form 1120-REIT, and Form 1120-RIC for the SOI Years 2016 and 2017 Corporation Programs. The table below shows the estimated sample sizes for each of the SOI corporation program studies.




| SOI Year Study | Estimate |
| :-: | :-: |
| 2016 | 118,814 |
| 2017 | 121,923 |

2. Using the RAAS Distributed Processing System (RAAS-DPS) at the Ogden Submission Processing Center, on-line editing of scanned paper-filed returns and rendered electronically-filed returns occurs at the Cincinnati, Kansas City, and Ogden campuses.



1. Cincinnati, Kansas City, and Ogden submission processing centers will secure, control, and normally edit the SOI sampled paper-filed returns filed at the centers. Ogden edits all Forms 1120-L and 1120-PC, regardless of filing location.

2. In consultation with the centers, National Office may electronically transfer work from one center to another to ensure meeting program deadlines. Transfers of paper-filed returns to another center occur only after DMD scanning.


3. Quality reviewers should have SOI experience in editing 1120 returns and should attend editing/test resolution training classes.

4. Centers should plan to assign dedicated SOI editors to the SOI Corporation Program - i.e., individuals who develop expertise working on only one program.

5. Because SOI must find and edit all of the "critical case" returns in its samples and include the information on these returns in the files transmitted to both the Office of Tax Analysis (OTA) and the Joint Committee on Taxation (JCT), the primary customers of SOI data, submission processing centers must use the appropriate staffing to ensure that missing critical case returns are found, controlled, and edited before the respective close-outs of the SOI Corporation Program Studies.

6. Each center that scans paper returns for the SOI Corporation Program should set up a procedure to ensure that it completely scans these documents and that the images are readable and available for editing. Data Management Division (DMD) also renders images from the MeF XML files.



1. The centers scan as many paper returns as possible before the start of editing. The centers generate inventory reports in the BMF STARTS application to monitor the scanning progress.

2. To meet its editing completion deadlines SOI must receive from DMD 100 percent of the rendered images of the available electronically-filed corporation returns. While rendered images are generally available within two (2) weeks of DMD receipt of XML files, large cycles may take up to thirty (30) days to process. Below are the edit cutoff dates for the SOI Year 2016 and 2017 corporation studies.


**SOI Year 2016**

| Editing and Test Resolution | Cutoff Date |
| :-: | :-: |
| First Quarter (more than 25 percent of<br> estimated sample edited) | 09-15-2017 |
| Second Quarter (more than 50 percent of<br> estimated sample edited) | 12-15-2017 |
| Advance Data (more than 75 percent of<br> estimated sample edited) | 03-16-2018 |
| Final Data (100 percent of<br> estimated sample edited) | 07-12-2018 |

**SOI Year 2017**

| Editing and Test Resolution | Cutoff Date |
| :-: | :-: |
| First Quarter (more than 25 percent of<br> estimated sample edited) | 09-14-2018 |
| Second Quarter (more than 50 percent of<br> estimated sample edited) | 12-14-2018 |
| Advance Data (more than 75 percent of<br> estimated sample edited) | 03-15-2019 |
| Final Data (100 percent of<br> estimated sample edited) | 07-11-2019 |

7. Each processing center will generate periodic reports from the on-line quality review system. It uses these reports to measure the quality, individually and collectively, of the statistical edit process.

8. A center reviews 100 percent of the input work and test correction work of editors based on the following guidelines: an average of two (2) working days or thirty (30) returns for experienced SOI editors and an average of three (3) working days or forty (40) returns for new SOI editors after the first week of production. SOI has not intended for these guidelines to conflict with TEPS Learning Curve requirements.

9. Data produced from the on-line quality review system will form a basis for systemic improvements to the program. Sharing and analyzing the data is the key to identifying improvement opportunities. These results are very useful in identifying problems early and periodically in the program.


**1.13.2.4.2** **(09-07-2018)**

#### Partnership Program

1. In 2018 and 2019 the submission processing centers will sample and process returns for the SOI Form 1065 and Form 1065-B Partnership Programs for Tax Years 2017 and 2018, respectively. The projected sample size for each tax year study is approximately 40,000 returns. The SOI edit units in Cincinnati and Ogden complete the Tax Year 2017 sample in January 2019. SOI edit units in Kansas City and Ogden begin the Tax Year 2018 sample in July 2019 after editor training at the Ogden submission processing center.

2. The SOI samples include electronically filed partnership returns. SOI renders these MeF returns into images which the editors view on a split-screen monitor while editing. SOI also extracts and loads MeF data into the partnership application database.

3. Editing of partnership SOI returns will occur at both the Cincinnati and Ogden Submission Processing Centers. The Partnership Advance Data cut-off occurs in November each year with an objective of editing all the returns SOI selected through at least cycle 40 and producing the Partnership Preliminary File in December.

4. SOI sends processing instructions to Cincinnati and Ogden for review and comment before edit/error resolution training. This will provide a quality check on the instructions and allow for review/comment by the editors before training.

5. The Cincinnati and Ogden Submission Processing Centers should staff the SOI Unit with tax examiners who are trained and experienced in the SOI edit/error resolution operations for partnership returns.

6. Cincinnati and Ogden will generate periodic reports from the on-line quality review system. The centers use these reports to measure the quality, individually and collectively, of the tax examiners and the SOI statistical edit process. They also send copies to National Office.

7. Cincinnati and Ogden should establish an acceptance sampling process to review images of returns.

8. Data produced from the on-line quality review system conducted in Cincinnati and Ogden will form a basis for systemic improvements to the program. Sharing and analyzing the data is the key to identifying improvement opportunities. These results are very useful in identifying problems early and periodically in the program.


**1.13.2.4.3** **(09-07-2018)**

#### Minimum Effectively Connected Net Investment Income (MECNII) Study

1. Statistics of Income (SOI) conducts this annual study of Minimum Effectively Connected Net Investment Income (MECNII) for the Office of the Secretary of the Treasury in accordance with IRC Section 842. Data are collected from all of the filed U.S. Life Insurance Company Income Tax Returns (Forms 1120-L) and U.S. Property and Casualty Insurance Company Income Tax Returns (Forms 1120-PC).

2. Because the MECNII Study identifies a different set of 1120-L or 1120-PC returns from the basic SOI Corporation Study, the SOI edit unit at the Ogden Submission Processing Center orders these returns separately in BMF STARTS. _Exhibit 1.13.2-8_ and _Exhibit 1.13.2-9_ list the processing schedules for SOI Years 2016 and 2017, respectively.

3. SOI provides instructions for controlling, scanning, rendering, and ordering MECNII returns in IRM 1.13.3, Document Management.

4. Submission processing center quality improvement efforts for this study should concentrate on obtaining and controlling all MECNII returns. Particular emphasis is placed on improving methods for researching and obtaining large case returns shown on follow-up lists provided in STARTS.


**1.13.2.4.4** **(09-07-2018)**

#### Foreign Person's U.S. Source Income Subject to Withholding (Forms 1042-S)

1. For Tax Year 2016, ECC-MEM sends an e-mail to Adrianne Bell within 10 business days of completion of the final file or by December 1.

2. After the computing center notifies the National Office IT specialist processing of the returns is complete, the IT specialist downloads the records into an SOI database in Ogden.


**1.13.2.4.5** **(09-07-2018)**

#### Forms 8805 Study

1. The Ogden Submission Processing Center will process Forms 8805 which partnerships are now required to file, under provisions of the Tax Reform Act of 1986, when they make payments to foreign partners.

2. The center will send a file of Form 8805 data to National Office in April 2018. The file includes data for calendar year filers for Tax Year 2016 (January 1, 2016 to December 31, 2016).

3. The center will send another file of Form 8805 data to National Office in April 2019. The file includes data for calendar year filers for Tax Year 2017 (January 1, 2017 to December 31, 2017).

4. The expected population count is 225,000 Forms 8805.


**1.13.2.4.6** **(09-07-2018)**

#### Form 8288-A Study

1. The Ogden Submission Processing Center will control and process Form 8288-Afor inclusion in the final tables that it ships to National Office by the month of April in both 2018 and 2019.

2. The center will send a file of Form 8288-A data to National Office in April 2018. The file includes data for calendar year filers for Tax Year 2016 (January 1, 2016 to December 31, 2016).

3. The center will send a file of Form 8288-A data to National Office in April 2019. The file includes data for calendar year filers for Tax Year 2017 (January 1, 2017 to December 31, 2017).

4. The expected population is 15,000 Forms 8288-A. The tables delivered in April 2018 should include data only for Forms 8288-A filed for the period 2016. The tables delivered in April 2019 should include data only for Forms 8288-A filed for the period 2017.


**1.13.2.4.7** **(09-07-2018)**

#### Form 5471 Study, SOI Year 2016

1. This study examines all Forms 5471 attached to all Forms 1120 in the SOI Year 2016 Corporation Study.

2. Form 5471 editing is done at the Ogden Submission Processing Center (OSPC).

3. For Forms 5471 filed on paper or in portable data format (PDF), the data is keyed directly from scanned images of the forms and tested on-line by Ogden personnel. For Forms 5471 filed in extensible markup language (XML) format, Ogden personnel will match each Form 5471 to a prior year record and then load the data into the database. A "full-edit" is performed on all "active" Forms 5471, while a "short-edit" is performed on all "inactive" Forms 5471.

4. The goal in Ogden is the timely editing of all Forms 5471. See _Exhibit 1.13.2-17_.


**1.13.2.4.8** **(09-07-2018)**

#### Form 1118 Study, SOI Year 2016

1. In this study SOI examines Forms 1118 that it finds attached to Forms 1120 in the SOI Year 2016 Corporation Study.

2. The SOI edit unit in Ogden will complete all of the on-line Form 1118 data editing in 2018.



1. SOI expects to find about 5,400 Forms 1118 among approximately 115,200 corporation returns. The anticipated volume of paper-filed Forms 1118 is 740.

2. Editing is scheduled to begin in February 2018 (See _Exhibit 1.13.2-18_).


3. A goal for the Ogden Center is the timely editing of all returns in the order it receives them (See _Exhibit 1.13.2-18_).


**1.13.2.4.9** **(09-07-2018)**

#### Form 1118 Study, SOI Year 2017

1. In this study SOI examines Forms 1118 that it finds attached to Forms 1120 in the SOI Year 2017 Corporation Study.

2. The SOI edit unit in Ogden will complete all of the on-line Form 1118 data editing in 2019.



1. SOI expects to find about 5,400 Forms 1118 among approximately 122,000 corporation returns. The anticipated volume of paper-filed Forms 1118 is 740.

2. Editing is scheduled to begin in February 2019 (See _Exhibit 1.13.2-18_).


3. A goal for the Ogden Center is the timely editing of all returns in the order it receives them (See _Exhibit 1.13.2-18_).


**1.13.2.4.10** **(09-07-2018)**

#### Form 8832 Study, SOI Years 2018 and 2019

1. This annual study examines all Forms 8832 filed on paper at the Cincinnati and Ogden Submission Processing Centers, the IRS-designated central filing locations. SOI expects both centers to receive approximately 60,000 forms total each year for the 2018 and 2019 studies.

2. At the Ogden and Cincinnati Submission Processing Centers, the Forms 8832 are processed in Entity and Entity Unpostables and then sent directly to Files. SOI then requests the Forms 8832 from Files by submitting a Form 4251 for each return. The returns are then sent to SOI, scanned, and released back to Files.

3. All Form 8832 editing is done by the SOI edit unit at the Ogden Submission Processing Center. Editing begins in May of each year and ends in January 31 of the following year.

4. The goal in Ogden is the timely editing of all Forms 8832. See _Exhibit 1.13.2-21_ and _Exhibit 1.13.2-22_.



### Note:



See IRM 3.13.2.26 for instructions on processing Form 8832, Entity Classification Election.


**1.13.2.4.11** **(09-07-2018)**

#### Form 8858 Study, SOI Year 2016

1. This study examines the Form 8858, Information Return of U.S. Persons With Respect To Foreign Disregarded Entities, attached to all the Forms 1120 in the SOI Corporation Study.

2. All Form 8858 editing occurs at the Ogden Submission Processing Center (OSPC).

3. For Forms 8858 filed on paper or in PDF format, the data from Forms 8858 is keyed directly from images of the forms and tested on-line by Ogden personnel. For Forms 8858 filed in XML format, data are loaded into the database.

4. The goal in Ogden is the timely editing of all Forms 8858 (see _Exhibit 1.13.2-19_).


**1.13.2.4.12** **(09-07-2018)**

#### Form 8865 Study, SOI Year 2016

1. This study examines the Form 8865, Return of U.S. Persons With Respect to Certain Foreign Partnerships, attached to all the Form 1120 types in the SOI Year 2016 Corporation Study, and to all the Forms 1065 and 1065-B selected for the SOI Tax Year 2016 Partnership Study.

2. Form 8865 editing is done at the Ogden Submission Processing Center (OSPC).

3. SOI expects to complete all of the data entry for the SOI Year 2016 Form 8865 study during Fiscal Years (FY) 2019 and 2020. For Forms 8865 filed on paper, OSPC personnel key the data directly from the scanned images and test the data on-line. SOI personnel will load electronically-filed Forms 8865 into the database. OSPC personnel will resolve any errors.

4. The goal of the Ogden personnel is the timely editing of all Forms 8865 (See _Exhibit 1.13.2-20_).


**1.13.2.4.13** **(09-07-2018)**

#### Form 8975 Study, SOI Year 2016

1. This study examines the Form 8975, Country by Country Report, attached to all the Forms 1120 in the SOI Corporation Study.

2. All Form 8975 editing occurs at the Ogden Submission Processing Center (OSPC).

3. For Forms 8975 filed on paper in PDF format, the data from Forms 8975 is keyed directly from images of the forms and tested on-line by Ogden personnel. For Forms 8975 filed in XML format, data are loaded into the database.

4. The goal of the Ogden personnel is the timely editing of all Forms 8975 (_Exhibit 1.13.2-23_).


**Exhibit 1.13.2-1**

### Basic Individual/Sole Proprietorship Studies, Tax Years 2016 and 2017

| Tax Year | Function | Advance Data | Complete<br> Report |
| :-: | :-: | :-: | :-: |
| 2016 | Final submission processing center edited file transmittal | 10-27-2017 | 02-16-2018 |
| 2016 | ECC-MTB Cycle processed | 201738 | 201752 |
| 2017 | Final submission processing center edited file transmittal | 10-26-2018 | 02-08-2019 |
| 2017 | ECC-MTB Cycle processed | 201838 | 201852 |

**Exhibit 1.13.2-2**

### Sales of Capital Assets (SOCA), Tax Years 2016

| Tax Year | Function | Processing Begins | Processing<br> Ends |
| :-: | :-: | :-: | :-: |
| 2016 | 2007-Based Panel Returns edited | 10-30-2017 | 08-30-2018 |

**Exhibit 1.13.2-3**

### Corporation Program, SOI Year 2016

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Sample selection for all corporation returns, including Forms 1120S | 01-2016 | 06-2018 |
| Editing/test resolution (including "Giants" ): | 06-2017 | 07-2018 |
| First Quarter (more than 25 percent of<br> estimated sample edited) |  | 09-15-2017 |
| Second Quarter (more than 50 percent<br> edited) |  | 12-15-2017 |
| Advance Data (more than 75 percent<br> edited) |  | 03-16-2018 |
| Final Data (100 percent edited) |  | 07-12-2018 |
| Advance Data file closeout |  | 03-30-2018 |
| Final Data file closeout |  | 08-22-20181 |

|     |
| --- |
| 1SOI continues to add "missing" critical case and significant giant returns to the file as they are found until Final Data closeout. |

**Exhibit 1.13.2-4**

### Corporation Program, SOI Year 2017

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Sample selection for all corporation returns, including Forms 1120S | 01-2017 | 06-2019 |
| Editing/test resolution (including "Giants" ): | 06-2018 | 07-2019 |
| First Quarter (more than 25 percent of<br> estimated sample edited) |  | 09-14-2018 |
| Second Quarter (more than 50 percent<br> edited) |  | 12-14-2018 |
| Advance Data (more than 75 percent<br> edited) |  | 03-15-2019 |
| Final Data (100 percent edited) |  | 07-11-2019 |
| Advance Data file closeout |  | 03-29-2019 |
| Final Data file closeout |  | 08-21-20191 |

|     |
| --- |
| 1SOI continues to add "missing" critical case and significant giant returns to the file as they are found until Final Data closeout. |

**Exhibit 1.13.2-5**

### Partnership Program, Tax Year 2017

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Sample selection | 01-2018 | 12-2018 |
| Edit/error resolution training | 07-2018 | 07-2018 |
| Editing/error resolution: | 07-2018 | 01-31-2019 |
| 25 percent edited |  | 09-14-2018 |
| 50 percent edited |  | 10-12-2018 |
| Advance Data cutoff1 |  | 11-09-2018 |
| 100 percent edited |  | 01-31-2019 |
| Final closeout | 01-31-2019 | 02-28-20191 |

|     |
| --- |
| 1All available returns that are selected through cycle "40" are scanned/rendered at the submission processing centers; placed in workgroups; and, edited at the Cincinnati and Ogden submission processing centers by the designated date. |

**Exhibit 1.13.2-6**

### Partnership Program, Tax Year 2018

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Sample selection | 01-2019 | 12-2019 |
| Edit/error resolution training | 07-2019 | 07-2019 |
| Editing/error resolution: | 07-2019 | 01-31-2020 |
| 25 percent edited |  | 09-13-2019 |
| 50 percent edited |  | 10-11-2019 |
| Advance Data cutoff1 |  | 11-08-2019 |
| 100 percent edited |  | 01-31-2020 |
| Final closeout | 01-31-2020 | 02-28-20201 |

|     |
| --- |
| 1All available returns that are selected through cycle "40" are scanned/rendered at the submission processing centers; placed in workgroups; and, edited at the Kansas City and Ogden submission processing centers by the designated date. |

**Exhibit 1.13.2-7**

### Partnership Program, Tax Year 2019

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Sample selection | 01-2020 | 12-2020 |
| Edit/error resolution training | 07-2020 | 07-2020 |
| Editing/error resolution: | 07-2020 | 01-31-2021 |
| 25 percent edited |  | 09-11-2020 |
| 50 percent edited |  | 10-09-2020 |
| Advance Data cutoff1 |  | 11-06-2020 |
| 100 percent edited |  | 01-31-2021 |
| Final closeout | 01-31-2021 | 02-28-20211 |

|     |
| --- |
| 1All available returns that are selected through cycle "40" are scanned/rendered at the submission processing centers; placed in workgroups; and, edited at the Kansas City and Ogden submission processing centers by the designated date. |

**Exhibit 1.13.2-8**

### Minimum Effectively Connected Net Investment Income (MECNII) Studies, SOI Year 2016

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Editing/test resolution | 10-2017 | 07-2018 |
| First Quarter (more than 25 percent edited) |  | 11-17-2017 |
| Second Quarter (more than 50 percent edited) |  | 01-15-2018 |
| Third Quarter (more than 75 percent edited) |  | 04-16-2018 |
| Final Data (100 percent edited) |  | 07-12-2018 |
| Final Data file closeout |  | 07-12-2018 |

**Exhibit 1.13.2-9**

### Minimum Effectively Connected Net Investment Income (MECNII) Studies, SOI Year 2017

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Editing/test resolution | 09-2018 | 07-2019 |
| First Quarter (more than 25 percent edited) |  | 10-19-2018 |
| Second Quarter (more than 50 percent edited) |  | 01-18-2019 |
| Third Quarter (more than 75 percent edited) |  | 04-19-2019 |
| Final Data (100 percent edited) |  | 07-12-2019 |
| Final Data file closeout |  | 07-12-2019 |

**Exhibit 1.13.2-10**

### Form 990 Studies, Tax Years 2015, 2016, 2017, and 2018

**Tax Year 2015 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (22,000 returns) | 01-2016 | 12-2017 |
| Start-up | 03-2017 |  |
| 5 percent completed |  | 05-2017 |
| 30 percent completed |  | 07-2017 |
| 60 percent completed |  | 10-2017 |
| 90 percent completed |  | 12-2017 |
| 100 percent completed |  | 01-2018 |
| File closeout |  | 02-2018 |

**Tax Year 2016 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (22,000 returns) | 01-2017 | 12-2018 |
| Start-up | 02-2018 |  |
| 5 percent completed |  | 03-2018 |
| 30 percent completed |  | 05-2018 |
| 60 percent completed |  | 08-2018 |
| 90 percent completed |  | 11-2018 |
| 100 percent completed |  | 01-2019 |
| File closeout |  | 02-2019 |

**Tax Year 2017 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (22,000 returns) | 01-2018 | 12-2019 |
| Start-up | 02-2019 |  |
| 5 percent completed |  | 03-2019 |
| 30 percent completed |  | 05-2019 |
| 60 percent completed |  | 08-2019 |
| 90 percent completed |  | 11-2019 |
| 100 percent completed |  | 01-2020 |
| File closeout |  | 02-2020 |

**Tax Year 2018 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (22,000 returns) | 01-2019 | 12-2020 |
| Start-up | 02-2020 |  |
| 5 percent completed |  | 03-2020 |
| 30 percent completed |  | 05-2020 |
| 60 percent completed |  | 08-2020 |
| 90 percent completed |  | 11-2020 |
| 100 percent completed |  | 01-2021 |
| File closeout |  | 02-2021 |

**Exhibit 1.13.2-11**

### Form 990-PF Studies, Tax Years 2015, 2016, 2017, and 2018

**Tax Year 2015 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (19,500 returns) | 01-2016 | 12-2017 |
| Start-up | 08-2017 |  |
| 30 percent completed |  | 10-2017 |
| 45 percent completed |  | 12-2017 |
| 75 percent completed |  | 03-2018 |
| 90 percent completed |  | 04-2018 |
| 100 percent completed |  | 05-2018 |
| File closeout |  | 05-2018 |

**Tax Year 2016 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (19,500 returns) | 01-2017 | 12-2018 |
| Start-up | 06-2018 |  |
| 5 percent completed |  | 07-2018 |
| 25 percent completed |  | 09-2018 |
| 50 percent completed |  | 11-2018 |
| 75 percent completed |  | 01-2019 |
| 100 percent completed |  | 04-2019 |
| File closeout |  | 04-2019 |

**Tax Year 2017 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (19,500 returns) | 01-2018 | 12-2019 |
| Start-up | 03-2019 |  |
| 5 percent completed |  | 05-2019 |
| 25 percent completed |  | 07-2019 |
| 50 percent completed |  | 10-2019 |
| 75 percent completed |  | 12-2019 |
| 100 percent completed |  | 03-2020 |
| File closeout |  | 04-2020 |

**Tax Year 2018 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (19,500 returns) | 01-2019 | 12-2020 |
| Start-up | 03-2020 |  |
| 10 percent completed |  | 05-2020 |
| 30 percent completed |  | 07-2020 |
| 75 percent completed |  | 11-2020 |
| 85 percent completed |  | 12-2020 |
| 100 percent completed |  | 03-2021 |
| File closeout |  | 04-2021 |

**Exhibit 1.13.2-12**

### Form 990-T Studies, Tax Years 2014, 2015, 2016, and 2017

**Tax Year 2014 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (7,000 returns) | 01-2015 | 12-2016 |
| Start-up | 04-2018 |  |
| 5 percent completed |  | 08-2018 |
| 30 percent completed |  | 09-2018 |
| 50 percent completed |  | 11-2018 |
| 75 percent completed |  | 01-2019 |
| 90 percent completed |  | 03-2019 |
| 100 percent completed |  | 04-2019 |
| File closeout |  | 08-2019 |

**Tax Year 2015 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (7,000 returns) | 01-2016 | 12-2017 |
| Start-up | 06-2019 |  |
| 5 percent completed |  | 08-2019 |
| 30 percent completed |  | 09-2019 |
| 50 percent completed |  | 10-2019 |
| 75 percent completed |  | 11-2019 |
| 90 percent completed |  | 12-2019 |
| 100 percent completed |  | 01-2020 |
| File closeout |  | 04-2020 |

**Tax Year 2016 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (7,000 returns) | 01-2017 | 12-2018 |
| Start-up | 02-2020 |  |
| 5 percent completed |  | 05-2020 |
| 30 percent completed |  | 06-2020 |
| 50 percent completed |  | 08-2020 |
| 75 percent completed |  | 09-2020 |
| 90 percent completed |  | 11-2020 |
| 100 percent completed |  | 01-2021 |
| File closeout |  | 04-2021 |

**Tax Year 2017 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (7,000 returns) | 01-2018 | 12-2019 |
| Start-up | 04-2020 |  |
| 5 percent completed |  | 05-2020 |
| 30 percent completed |  | 06-2020 |
| 50 percent completed |  | 07-2020 |
| 75 percent completed |  | 10-2020 |
| 90 percent completed |  | 12-2020 |
| 100 percent completed |  | 01-2021 |
| File closeout |  | 03-2021 |

**Exhibit 1.13.2-13**

### Tax-Exempt Bonds Studies (Forms 8038), Tax Year 2017

**Tax Year 2017 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (3,000 returns) | 01-2017 | 12-2018 |
| Start-up | 11-2018 |  |
| 30 percent completed |  | 01-2019 |
| 60 percent completed |  | 02-2019 |
| 90 percent completed |  | 03-2019 |
| 100 percent completed |  | 04-2019 |

**Exhibit 1.13.2-14**

### Tax-Exempt Bonds Studies (Forms 8038-G), Tax Years 2017 and 2019

**Tax Year 2017 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (25,500 returns) | 01-2017 | 12-2018 |
| Start-up | 04-2018 |  |
| 30 percent completed |  | 07-2018 |
| 60 percent completed |  | 09-2018 |
| 90 percent completed |  | 11-2018 |
| 100 percent completed |  | 01-2019 |

**Tax Year 2019 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (25,500 returns) | 01-2018 | 12-2019 |
| Start-up | 10-2019 |  |
| 30 percent completed |  | 12-2019 |
| 60 percent completed |  | 03-2020 |
| 90 percent completed |  | 06-2020 |
| 100 percent completed |  | 07-2020 |

**Exhibit 1.13.2-15**

### Estate Tax Studies, Tax Years 2017, 2018, and 2019

**Tax Year 2017 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (8,000 returns) | 01-2017 | 12-2017 |
| Start-up | 03-2017 |  |
| 40 percent completed |  | 09-2017 |
| 60 percent completed |  | 11-2017 |
| 90 percent completed |  | 01-2018 |
| 100 percent completed |  | 02-2018 |
| File Closeout |  | \* |
| \*On notification by National Office |  |  |

**Tax Year 2018 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (8,000 returns) | 01-2018 | 12-2018 |
| Start-up | 03-2018 |  |
| 40 percent completed |  | 09-2018 |
| 60 percent completed |  | 11-2018 |
| 90 percent completed |  | 01-2019 |
| 100 percent completed |  | 02-2019 |
| File Closeout |  | \* |
| \*On notification by National Office |  |  |

**Tax Year 2019 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (8,000 returns) | 01-2019 | 12-2019 |
| Start-up | 03-2019 |  |
| 40 percent completed |  | 06-2019 |
| 60 percent completed |  | 09-2019 |
| 90 percent completed |  | 01-2020 |
| 100 percent completed |  | 02-2020 |
| File Closeout |  | \* |
| \*On notification by National Office |  |  |

**Exhibit 1.13.2-16**

### Gift Tax Study, Filing Years 2017, 2018, and 2019

**Tax Year 2017 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (5,000 returns) | 01-2017 | 12-2017 |
| Start-up | 11-2017 |  |
| 25 percent completed |  | 01-2018 |
| 50 percent completed |  | 03-2018 |
| 75 percent completed |  | 04-2018 |
| 100 percent completed |  | 06-2018 |

**Tax Year 2018 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (5,000 returns) | 01-2018 | 12-2018 |
| Start-up | 11-2018 |  |
| 25 percent completed |  | 01-2019 |
| 50 percent completed |  | 03-2019 |
| 75 percent completed |  | 04-2019 |
| 100 percent completed |  | 06-2019 |

**Tax Year 2019 Editing Schedule**

| Processing Phases | Begin Date | End Date |
| :-: | :-: | :-: |
| Sample selection at Ogden Submission Processing Center (5,000 returns) | 01-2019 | 12-2019 |
| Start-up | 11-2019 |  |
| 25 percent completed |  | 01-2020 |
| 50 percent completed |  | 03-2020 |
| 75 percent completed |  | 04-2020 |
| 100 percent completed |  | 06-2020 |

**Exhibit 1.13.2-17**

### Information Return of U.S. Persons with Respect to Certain Foreign Corporations (Form 5471) Study, SOI Year 2016

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Ogden Editing/Error Resolution | 11-2017 |  |
| 25 percent of total |  | 01-31-2018 |
| 50 percent of total |  | 04-30-2018 |
| 75 percent of total |  | 07-31-2018 |
| 100 percent of total |  | 09-30-2018 |

**Exhibit 1.13.2-18**

### Corporation Foreign Tax Credit (Form 1118) Study, SOI Year 2016

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| 2016 Editing/Error Resolution | 01-2018 | 07-2018 |
| 50 percent of total |  | 04-30-2018 |
| 100 percent of total |  | 07-14-2018 |

**Corporation Foreign Tax Credit (Form 1118) Study, SOI Year 2017**

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| 2017 Editing/Error Resolution | 01-2019 | 07-2019 |
| 50 percent of total |  | 04-30-2019 |
| 100 percent of total |  | 07-12-2019 |

**Exhibit 1.13.2-19**

### Information Return of U.S. Persons With Respect To Foreign Disregarded Entities (Form 8858) Study, SOI Year 2016

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Editing/Error Resolution | 10-2018 |  |
| 25 percent of total | 12-15-2018 |
| 50 percent of total | 02-28-2019 |
| 75 percent of total | 04-30-2019 |
| 100 percent of total | 06-30-2019 |

**Exhibit 1.13.2-20**

### Return of U.S. Persons With Respect to Certain Foreign Partnerships (Form 8865) Study, SOI Year 2016

**SOI Year 2016**

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Ogden Editing/Error Resolution | 10-2018 | 03-2019 |
| 25 percent of total |  | 10-31-2018 |
| 50 percent of total |  | 01-04-2019 |
| 75 percent of total |  | 02-08-2019 |
| 100 percent of total |  | 03-08-2019 |

**Exhibit 1.13.2-21**

### **Entity Classification Election (Form 8832) Study, SOI Year 2018**

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Ogden Editing/Error Resolution | 05-2018 | 01-2019 |
| 50 percent of total |  | 08-31-2018 |
| 90 percent of total |  | 12-31-2018 |
| 100 percent of total |  | 01-31-2019 |

**Exhibit 1.13.2-22**

### **Entity Classification Election (Form 8832) Study, SOI Year 2019**

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Ogden Editing/Error Resolution | 05-2019 | 01-2020 |
| 50 percent of total |  | 08-31-2019 |
| 90 percent of total |  | 12-31-2019 |
| 100 percent of total |  | 01-31-2020 |

**Exhibit 1.13.2-23**

### Country By Country Report (Form 8975) Study, SOI Year 2016

**SOI Year 2016**

| Function | Processing Begins | Processing Ends |
| :-: | :-: | :-: |
| Ogden Editing/Error Resolution | 11-2018 |  |
| 25 percent of total |  | 01-31-2019 |
| 50 percent of total |  | 03-15-2019 |
| 75 percent of total |  | 04-30-2019 |
| 100 percent of total |  | 05-15-2019 |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-013-002#addtoany "Show all")

A2A