---
url: "https://www.irs.gov/irm/part1/irm_01-017-003"
title: "1.17.3 Tax Products Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-017-003#main-content)

- 1.17.3  [Tax Products Program](https://www.irs.gov/irm/part1/irm_01-017-003#id1)
  - 1.17.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-017-003#id2)
    - 1.17.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-017-003#id4)
    - 1.17.3.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-017-003#id5)
    - 1.17.3.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-003#id6)
    - 1.17.3.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-017-003#id7)
    - 1.17.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-017-003#id8)
    - 1.17.3.1.6  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-017-003#id9)
    - 1.17.3.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-017-003#id10)
  - 1.17.3.2  [Tax Products Publishing Programs](https://www.irs.gov/irm/part1/irm_01-017-003#id11)
    - 1.17.3.2.1  [Tax Forms and Instructions](https://www.irs.gov/irm/part1/irm_01-017-003#id13)
    - 1.17.3.2.2  [Taxpayer Information Publications (TIPS)](https://www.irs.gov/irm/part1/irm_01-017-003#id14)
    - 1.17.3.2.3  [Tax Payment Voucher Mail Outs](https://www.irs.gov/irm/part1/irm_01-017-003#id15)
  - 1.17.3.3  [Availability of Tax Products and Services](https://www.irs.gov/irm/part1/irm_01-017-003#id16)
    - 1.17.3.3.1  [Electronic Availability via IRS.gov](https://www.irs.gov/irm/part1/irm_01-017-003#id17)
    - 1.17.3.3.2  [Electronic Availability via E-file](https://www.irs.gov/irm/part1/irm_01-017-003#id18)
    - 1.17.3.3.3  [Electronic Availability via the Core Repository of Published Products (CROPP)](https://www.irs.gov/irm/part1/irm_01-017-003#id19)
    - 1.17.3.3.4  [Ordering Availability via Mail](https://www.irs.gov/irm/part1/irm_01-017-003#id20)
    - 1.17.3.3.5  [Ordering Availability via Telephone](https://www.irs.gov/irm/part1/irm_01-017-003#id21)
    - 1.17.3.3.6  [Walk-in Availability for Tax Products and Services](https://www.irs.gov/irm/part1/irm_01-017-003#id22)
      - 1.17.3.3.6.1  [Walk-in Availability via the Taxpayer Assistance Center (TAC) Program](https://www.irs.gov/irm/part1/irm_01-017-003#id24)
      - 1.17.3.3.6.2  [Walk-in Availability via Volunteer Income Tax Assistance (VITA) Program](https://www.irs.gov/irm/part1/irm_01-017-003#id25)
      - 1.17.3.3.6.3  [Walk-in Availability via Tax Counseling for the Elderly (TCE) Program](https://www.irs.gov/irm/part1/irm_01-017-003#id26)
      - 1.17.3.3.6.4  [Walk-in Availability via Tax Forms Outlet Program](https://www.irs.gov/irm/part1/irm_01-017-003#id27)
      - 1.17.3.3.6.5  [Walk-in Availability via the International Program](https://www.irs.gov/irm/part1/irm_01-017-003#id28)
      - 1.17.3.3.6.6  [Walk-in Availability via Paid Return Preparers](https://www.irs.gov/irm/part1/irm_01-017-003#id29)
  - 1.17.3.4  [Tax Products Development Responsibilities within Media & Publications](https://www.irs.gov/irm/part1/irm_01-017-003#id30)
    - 1.17.3.4.1  [Tax Forms & Publications (TF&P) Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-003#id31)
    - 1.17.3.4.2  [Publishing Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-003#id32)
    - 1.17.3.4.3  [Distribution Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-003#id33)
      - 1.17.3.4.3.1  [National Distribution Center (NDC) Responsibilities](https://www.irs.gov/irm/part1/irm_01-017-003#id35)
  - 1.17.3.5  [Tax Products Workflow](https://www.irs.gov/irm/part1/irm_01-017-003#id36)
    - 1.17.3.5.1  [Initiation of the PSR](https://www.irs.gov/irm/part1/irm_01-017-003#id38)
    - 1.17.3.5.2  [Clearance of Tax Products Text](https://www.irs.gov/irm/part1/irm_01-017-003#id39)
    - 1.17.3.5.3  [Electronic Composition of Tax Products Text](https://www.irs.gov/irm/part1/irm_01-017-003#id40)
    - 1.17.3.5.4  [Issuing Tax Products OK-to-Print Notification](https://www.irs.gov/irm/part1/irm_01-017-003#id41)
    - 1.17.3.5.5  [Requesting a Form 2040 Distribution List/Pattern](https://www.irs.gov/irm/part1/irm_01-017-003#id42)
    - 1.17.3.5.6  [Procurement of Tax Products](https://www.irs.gov/irm/part1/irm_01-017-003#id43)
    - 1.17.3.5.7  [Procurement Vehicles](https://www.irs.gov/irm/part1/irm_01-017-003#id44)
  - 1.17.3.6  [Quality Control](https://www.irs.gov/irm/part1/irm_01-017-003#id45)
    - 1.17.3.6.1  [Quality Control Planning and Review](https://www.irs.gov/irm/part1/irm_01-017-003#id47)
    - 1.17.3.6.2  [Onsite Quality Control Planning and Review](https://www.irs.gov/irm/part1/irm_01-017-003#id48)
    - 1.17.3.6.3  [Offsite Quality and Quantity Assurance](https://www.irs.gov/irm/part1/irm_01-017-003#id49)

# Part 1. Organization, Finance, and Management

# Chapter 17. Publishing

# Section 3. Tax Products Program

* * *

## 1.17.3 Tax Products Program

#### Manual Transmittal

December 09, 2025

#### Purpose

(1) This transmits revised IRM 1.17.3, _Publishing - Tax Products Program_.

#### Material Changes

(1) Updated Signature to reflect current Publishing director.

(2) 1.17.3.1, _Program Scope and Responsibilities_ \- Updated to conform to format for Internal Controls.

(3) 1.17.3.3.6.4(2), _Walk-in Availability via Tax Forms Outlet Program (TFOP)_ \- Removed text because the product was officially obsolete in January 2023 and is no longer in use. Renumbered subsequent paragraphs after removing this content.

(4) Made editorial changes to conform to Plain Writing requirements and update hyperlinks where needed.

#### Effect on Other Documents

This update supersedes IRM 1.17.3 dated August 9, 2024.

#### Audience

All IRS employees, contractors, and vendors who design, publish, or distribute printed and/or electronic internal/external material.

#### Effective Date

(12-09-2025)

Tracey K. Quamie

Director, Publishing

Media & Publications Division

**1.17.3.1** **(12-09-2025)**

### Program Scope and Objectives

1. Publishing’s mission is to plan and produce or procure all IRS print and electronic communications products used by the public to comply with tax filing requirements and obligations and used internally within IRS for tax administration. The Publishing function (also known as "Publishing" ) under Media & Publications (M&P) within Taxpayer Services develops and delivers published products in electronic, paper, and other alternative formats for internal (employees) and external (taxpayers) use.

2. **Purpose:** This section covers the publishing programs for IRS tax products that provide informational, promotional, and instructional materials to businesses and individuals. Taxpayers use these materials for return submissions, taxpayer education and assistance, and tax payments and withholdings.

3. **Audience:** The audience for this IRM is IRS employees Servicewide.

4. **Policy Owner:** The Director of Publishing owns the policies contained herein.

5. **Program Owner:** Taxpayer Services (TS), Customer Assistance Relationships and Education (CARE), Media & Publications (M&P), Publishing is responsible for the administration, procedures, and updates related to the program.

6. **Primary Stakeholders.** Tax Forms & Publications (TF&P) and Distribution in M&P, CARE, TS; Chief Financial Officer of the IRS; IRS organizations servicewide. In M&P, the TF&P and Distribution functions are areas that these procedures affect that have input to the procedures. The effects may include a change in workflow, additional duties, changes in established time frames, and similar issues.

7. **Contact Information.** The Director of Publishing in M&P in CARE, TS.

8. **Program Goals**: Publishing’s authority encompasses integrated design, technical specification writing, production planning, acquisition and delivery/distribution coordination, to provide the highest quality products and services. We use all available print, electronic and accessible media and technology to accomplish this mission.


**1.17.3.1.1** **(12-09-2025)**

#### Background

1. Each tax product the IRS creates results from new or revised legislation, regulations, or rulings; court decisions; or suggestions from IRS employees or the taxpaying public. Publishing is the ONLY internal organization with the authority to publish tax products to IRS.gov and the Core Repository of Published Products (CROPP). See _IRM 1.17.3.3.3_, _Electronic Availability via the Core Repository of Published Products (CROPP)_, and to procure printed tax products refer to IRM 1.17.1.2, _Authorities of Government Publishing, Printing, and Duplicating_.


**1.17.3.1.2** **(12-09-2025)**

#### Authority

1. Publishing’s authority as the official IRS publisher is listed in IRM 1.17.9.6, _Roles and Responsibilities When Publishing a Product_.


**1.17.3.1.3** **(12-09-2025)**

#### Roles and Responsibilities

1. The M&P Publishing function:



   - Designs and maintains the Service’s publishing programs and systems.

   - Produces or procures all Servicewide print and electronic communications products for dissemination.

   - Serves as the liaison with the Department of Treasury’s Printing and Graphics Division on matters covered under Congressional JCP administration.

   - Approves or denies requests for color copiers (specialty) and high-speed (more than 100 impressions per minute) black and white copiers prior to the procurement process. Requests for regular-speed black and white copiers or multifunctional devices that scan, print, or fax fall under the Information Technology organization.

   - Coordinates the procurement of digital copying services.

   - Partners with internal and external stakeholders to communicate and distribute informational and instructional products to appropriate audiences.

   - The IRS Design office in Publishing is the authority for overseeing and managing all IRS visual design elements, including the use, placement and guidance of the IRS logo and seal and all visual branding elements within IRS.


**1.17.3.1.4** **(12-09-2025)**

#### Program Management and Review

1. **Program Reports.** Balanced measures for tax and non-tax products.

2. **Program Effectiveness.** The Computer Assisted Publishing System (CAPS) has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.3.1.5** **(12-09-2025)**

#### Program Controls

1. CAPS has reporting capabilities that enable management and employees to monitor and track delivery of Publishing products and services.


**1.17.3.1.6** **(12-09-2025)**

#### Terms/Definitions/Acronyms

1. This IRM section uses the following terms and acronyms to describe the involved processes and resources.



**Defined Terms**






| Term | Definition |
| --- | --- |
| Form | A product with spaces to store information. |
| Product | An item produced for any audience that requires cataloging and revision control to ensure proper usage and context of IRS published content. |
| Publish | Producing products intended for use or reading by persons inside (employees) or outside (public/customers) of the IRS. |
| Service | Something done on behalf of others. |







**Acronyms**






| Acronym | Definition |
| --- | --- |
| AMC | Alternative Media Center |
| BPOL | Banks, Post Offices, and Libraries |
| CAPS | Computer Assisted Publishing System |
| CARE | Customer Assistance, Relationships and Education |
| CROPP | Core Repository of Published Products |
| CSM | Contractor Security Management |
| E-File | Electronic Filing |
| EFTD | Electronic Tax Forms Distribution |
| EIN | Employee Identification Number |
| ESN | Electronic Status Notice |
| GPO | Government Publishing Office |
| HCO | Human Capital Office |
| HTML | HyperText Markup Language |
| ITM | Integrated Talent Management |
| M&P | Media & Publications |
| NDC | National Distribution Center |
| OCR | Optical Character Recognition |
| OMB | Office of Management and Budget |
| PDF | Portable Document Format |
| PII | Personally Identifiable Information |
| PPMC | Published Products Media Catalog |
| PSD | Publishing Services Data |
| PSR | Publishing Services Request |
| PTIN | Preparer Tax Identification Number |
| SBU | Sensitive but Unclassified Information |
| SPA | Simplified Purchase Agreements |
| TAC | Taxpayer Assistance Center |
| TCE | Tax Counseling for the Elderly |
| TFOP | Tax Forms Outlet Program |
| TIPS | Taxpayer Information Publications |
| TS | Taxpayer Services |
| VITA | Volunteer Income Tax Assistance |


**1.17.3.1.7** **(12-09-2025)**

#### Related Resources

1. Document 12687, _Getting Your Information Published at the IRS_

2. Document 12616, _Design Guidelines for IRS Internal and Non-Tax Public Use Forms_

3. IRM 1.17.7, _Use of the Official IRS Seal, IRS Logo, Program Logos and Internal Logos_

4. IRM 1.17.1, _Publishing, Overview of Publishing Authorities, Roles and Responsibilities, and Organizational Structure_

5. IRM 22.31.1, _Multilingual Initiatives, IRS Language Services_

6. IRM 1.17.2, _Publishing - Publishing Systems and Programs_

7. IRM 1.17.10, _Publishing - IRS Published Product Identification_


**1.17.3.2** **(11-16-2012)**

### Tax Products Publishing Programs

1. The IRS produces tax products in the following publishing programs:



   - Tax Forms and Instructions

   - Taxpayer Information Publications (TIPS)

   - Tax Payment Voucher Mail Outs


**1.17.3.2.1** **(08-03-2023)**

#### Tax Forms and Instructions

1. The IRS produces tax forms and instructions to assist the public with understanding and submitting tax information. All taxpayers use tax forms to submit tax returns. The forms usually include the instructions for general guidance; however, we occasionally separately furnish instructions. We categorize tax products by customer group, including Individual and Proprietor (Form 1040 series), Partnership (Form 1065 series), Corporation (Form 1120 series), Exempt Organizations (Form 990 series), Employers (Form 940 and Form 941 series), and other support and supplemental forms and instructions. Tax forms and instructions are available in print and/or electronic formats.

2. Office of Management and Budget (OMB) Numbers - All tax forms must have a valid OMB number before publication or printing. Contact your publishing specialist to get additional OMB information.


**1.17.3.2.2** **(10-14-2015)**

#### Taxpayer Information Publications (TIPS)

1. The TIPS program provides taxpayers with detailed information on key topics that assist with preparation of their tax returns. The IRS designed TIPS to supplement forms and instructions by answering typical tax questions and providing helpful examples for a particular topic. We provide TIPS in print or electronic formats. An example of TIPS is Pub. 225, _Farmer’s Tax Guide_.


**1.17.3.2.3** **(08-03-2023)**

#### Tax Payment Voucher Mail Outs

1. The 1040-ES/V & 1041-ES printed packages that we mail to individual taxpayers contain static content for the general public’s use printed in large volumes that are personalized as an add-on function of printing to create an efficient and cost-effective printing and delivery process. The IRS mails Package 1040-ES/V (Payment Vouchers), which includes estimated tax payment vouchers for individuals preprinted with the taxpayer’s name, address, and social security number (SSN), using Pre-sorted First Class Mail, to taxpayers who:



   - E-file

   - File using computer program (such as Turbo Tax)

   - File their returns using a tax return preparer

   - File paper returns


The taxpayer’s SSN is embedded in the scan line of the Form 1040-V and Form 1040-ES Optical Character Recognition (OCR) payment vouchers. The scan line identifies the taxpayer and enables efficient processing of payments. The payment vouchers contain a Portable Document Format (PDF) 417 2-D encrypted barcode with random scan-line information. The IRS uses these vouchers to collect quarterly tax payments and any balances due for the current year from taxpayers.



2. The IRS mails Package 1041-ES (Payment Vouchers), which includes estimated tax payment vouchers for fiduciaries such as estates and trusts preprinted with the taxpayer's name, address and Employee Identification Number (EIN), using Pre-sorted First Class Mail, to taxpayers who:



   - E-file

   - File using computer program (such as Turbo Tax)

   - File their returns using a tax return preparer

   - File paper returns


The EIN is embedded in the scan line of the Form 1041-ES (OCR) payment vouchers. The scan line identifies the taxpayer and enables efficient processing of payments. The payment vouchers contain a PDF 417 2-D encrypted barcode with random scan-line information. The IRS uses these vouchers to collect quarterly tax payments and any balances due for the year for an estate or trust.



3. The publishing specialists also work closely with Contractor Security Management (CSM) and the Human Capital Office (HCO) to ensure that the print contractors have the necessary clearances to work with Personally Identifiable Information (PII) and Sensitive but Unclassified Information (SBU). This process involves fingerprinting, background checks, credit checks, selective service enrollment and tax compliancy. Only after they receive clearance can a contractor work on IRS work involving PII.

4. The publishing specialist must ensure that each print contractor is up to date with their annual mandatory briefings and that their training is recorded in the Integrated Talent Management (ITM) system.


**1.17.3.3** **(10-14-2015)**

### Availability of Tax Products and Services

1. Customers can obtain IRS tax products and services in the following ways:



   - Electronically, e.g., via IRS website and IRWeb;

   - By placing an order; or

   - By Walk-In at an IRS-approved location.


**1.17.3.3.1** **(10-14-2015)**

#### Electronic Availability via IRS.gov

1. IRS tax products are accessible via the Internet from the IRS website at [www.irs.gov](https://www.irs.gov/irm/part1/www.irs.gov). In addition, several software products are available from retail outlets that generate IRS-acceptable versions of tax forms and instructions. Pub. 1167, _General Rules and Specifications for Substitute Forms and Schedules_, provides general guidelines on the acceptability of these products.


**1.17.3.3.2** **(10-14-2015)**

#### Electronic Availability via E-file

1. IRS e-file enables taxpayers and tax professionals to file tax returns electronically. Publishing prints the products maintained in the e-file program. E-file is the brand name of the electronic filing method established by the IRS.


**1.17.3.3.3** **(11-16-2012)**

#### Electronic Availability via the Core Repository of Published Products (CROPP)

1. The CROPP is a publishing management system that collects, stores, manages, and delivers published products for use in electronic publishing applications. Access to this system is only available to IRS employees.


**1.17.3.3.4** **(11-16-2012)**

#### Ordering Availability via Mail

1. Customers may order tax forms, instructions, and publications by mailing their request to the National Distribution Center (NDC). See IRM 1.18.5.3, _Order Entry_, for more information on ordering from the NDC.


**1.17.3.3.5** **(10-14-2015)**

#### Ordering Availability via Telephone

1. Customers can also order forms, instructions, and publications by phone from the NDC, which is part of the Distribution function in Media & Publications (for more information about NDC ordering, refer to IRM 1.18.5.3, _Order Entry_). Pub. 4604 (EN/SP), _Use the Web for IRS Tax Products & Information_, in English and Spanish (EN/SP) provides the telephone number for additional information on ordering from the NDC. The NDC mails requested products to taxpayers within 7 to 10 business days of order receipt, if the product ordered IS NOT in backorder status.


**1.17.3.3.6** **(08-03-2023)**

#### Walk-in Availability for Tax Products and Services

1. The IRS designed tax products in these programs to help taxpayers understand tax laws and IRS procedures, and to obtain assistance with tax return preparation. The products supplement IRS services such as Volunteer Income Tax Assistance (VITA), Tax Counseling for the Elderly (TCE), and Community Outreach Tax Education. See Taxpayer Education, Assistance and Awareness Program for details on the VITA and TCE programs, and [Understanding Taxes Program for Students](https://apps.irs.gov/app/understandingTaxes/student/index.jsp) for information about the Understanding Taxes Program for Students.


**1.17.3.3.6.1** **(10-14-2015)**

##### Walk-in Availability via the Taxpayer Assistance Center (TAC) Program

1. The Taxpayer Assistance Center (TAC) Program supplies IRS TAC Walk-In offices with tax forms, instructions, and publications for redistribution to the public. Information on the program is available under Services & Programs on the Publishing + Distribution website.


**1.17.3.3.6.2** **(10-14-2015)**

##### Walk-in Availability via Volunteer Income Tax Assistance (VITA) Program

1. The VITA Program uses trained volunteers to prepare basic tax returns for low-income taxpayers in both urban and rural locations, persons with disabilities, non-English speaking persons, taxpayers with Limited English Proficiency, elderly taxpayers, and Native Americans. See VITA program for more details.


**1.17.3.3.6.3** **(08-17-2018)**

##### Walk-in Availability via Tax Counseling for the Elderly (TCE) Program

1. The TCE Program offers FREE tax help to individuals who are aged 60 or older. The Revenue Act of 1978 authorizes this cooperative agreement by providing grants to private or non-governmental public non-profit agencies and organizations (grant recipients) to assist elderly taxpayers with preparing their federal income tax returns.

2. All TCE sites must have one physical or electronic copy of the following reference materials available for use by volunteer return preparers and quality reviewers:



   - Pub. 4012, _VITA/TCE Volunteer Resource Guide_

   - Pub. 17, _Your Federal Income Tax (For Individuals)_

   - Volunteer Tax Alerts – must be available at the site within five (5) days of Stakeholder Partnerships, Education and Communication (SPEC) issuance


In addition, all grant recipients must fill out a Form 13614-C, _Intake/Interview and Quality Review Sheet_.



3. The IRS provides tax return preparation assistance to elderly taxpayers during the usual period for filing federal income tax returns, which is from January 1 to April 15 each year. However, the program activities required to ensure that elderly taxpayers receive efficient and quality tax assistance can occur year-round.


**1.17.3.3.6.4** **(12-09-2025)**

##### Walk-in Availability via Tax Forms Outlet Program

1. Libraries, post offices, and other entities volunteer as distribution outlet partners in the Tax Forms Outlet Program (TFOP), formerly known as the Banks, Post Offices, and Libraries (BPOL) Program. The outlets order printed IRS tax products offered through the TFOP and make these printed tax products available to their respective patrons free of charge. Participants in the program provide various tax products that are available to them.

2. TFOP outlet partners use a program customized PDF Form 8635, _Order for Tax Forms Outlet Program (TFOP) Partners_, posted at online, to place their order by email to a designated email mailbox.

3. See TFOP details for details on the TFOP program.


**1.17.3.3.6.5** **(10-14-2015)**

##### Walk-in Availability via the International Program

1. The International Program (formerly Embassy Program) provides U.S. embassies, consulates, and military bases around the world with bulk tax products for redistribution. The IRS designed this program to make tax-filing materials available to many U.S. taxpayers traveling or stationed abroad.


**1.17.3.3.6.6** **(11-16-2012)**

##### Walk-in Availability via Paid Return Preparers

1. Taxpayers may also use paid tax return preparers to complete tax returns by paper or electronically. These preparers are required to use, order, and maintain approved IRS forms and e-file systems. New regulations require all paid tax return preparers to have a preparer tax identification number (PTIN). This includes enrolled agents, registered tax return preparers, certified public accountants (CPAs), or attorneys – all of whom have unlimited rights to work with tax returns. The IRS is also phasing in a new test requirement to make sure those who are not an enrolled agent, a CPA, or an attorney have met minimal competency requirements. Taxpayers are legally responsible for what is on their tax return even if someone else prepares it.


**1.17.3.4** **(10-14-2015)**

### Tax Products Development Responsibilities within Media & Publications

1. Although every functional area of the IRS is involved in the development and issuance of tax forms program material, the Director, Media & Publications is responsible for the overall development, printing, and distribution of tax products in a timely, cost-efficient manner.


**1.17.3.4.1** **(08-09-2024)**

#### Tax Forms & Publications (TF&P) Responsibilities

1. TF&P develops and revises tax products in accordance with legislation enacted by Congress and ensures that the products are technically accurate, understandable, as easy to use as possible, and in the appropriate languages so that taxpayers can fulfill their tax filling and payment obligations. TF&P then submits the content to Publishing for formatting and publication. Publishing partners with TF&P to produce products correctly and on time.

2. TF&P maintains product development and legislative data in appropriate M&P product databases and submits requests to Publishing to change the status of products and their revisions as required.


**1.17.3.4.2** **(08-17-2018)**

#### Publishing Responsibilities

1. Publishing plans, designs, prints, and distributes all official IRS published products in print or electronic formats for use by the public to comply with tax filing and payment requirements and obligations or for use within the IRS for tax administration. This encompasses the integrated design, specifications writing, production planning, acquisition, and delivery/distribution coordination required to provide the highest-quality products and services, using all print and electronic media and technology available. Publishing maintains data on products and their revisions in appropriate M&P product databases to control the availability of product revisions on [www.irs.gov](https://www.irs.gov/irm/part1/www.irs.gov) and in the Catalog.


**1.17.3.4.3** **(11-16-2012)**

#### Distribution Responsibilities

1. Distribution works closely with Publishing to coordinate with contractors on the movement of products and with publishing specialists to determine quantities and products to be printed. Both organizations cooperate to determine which methods of printing and distribution would be the best value. See IRM 1.18, _Distribution_, for more information on Distribution responsibilities.


**1.17.3.4.3.1** **(11-16-2012)**

##### National Distribution Center (NDC) Responsibilities

1. The IRS stores printed products at the NDC. The NDC receives bulk shipments of printed tax products and redistributes them based on requests from IRS internal and external customers. The NDC is located in Bloomington, IL and is a branch within the Distribution division of M&P. See IRM 1.18.5, _National Distribution Center_, for more information on the NDC programs and operations.


**1.17.3.5** **(11-16-2012)**

### Tax Products Workflow

1. The tax products workflow describes the steps for developing tax products. Document 12687, _Getting Your Information Published at the IRS_, also contains the workflow Publishing follows to produce tax and other IRS published products.

2. Customers use the Publishing Services Request (PSR) to initiate a product request. See IRM 1.17.9.5, _Importance of Standards and Submitting a Publishing Services Request_, for more information on the PSR process.


**1.17.3.5.1** **(08-09-2024)**

#### Initiation of the PSR

1. Publishing provides the PSR electronic application for customers to request Publishing products and services. Customers initiate a PSR by going to the PSR homepage. The PSR automates the process of obtaining business and funding approvals, gathering product information, and initiating contact with Publishing. Once the originator submits the PSR, a publishing specialist is assigned to service the PSR and originator. Customers can also use a PSR to request any type of publishing service that previously required a Form 1767, _Publishing Services Request_. M&P cannot design, publish, or distribute a product without a PSR. Please reference IRM 1.17.9, _Publishing, User Guide for Requesting Published Products and Services_, for additional information.


**1.17.3.5.2** **(11-16-2012)**

#### Clearance of Tax Products Text

1. After the PSR is approved, the clearance procedure begins by having a tax law specialist review the tax product for clarity and accuracy. During the clearance procedure, Publishing, TF&P, and the Tax Products Coordinating Committee prepare, review, and revise drafts of tax products. Once content is finalized, TF&P selects the "release to Publishing OK to print" option in the Composition Process Management system, sending notification to the Electronic Composition section.


**1.17.3.5.3** **(11-16-2012)**

#### Electronic Composition of Tax Products Text

1. The Electronic Composition Section obtains or creates a final reproducible PDF file of each tax product and performs a quality review of fillable PDFs of tax forms. The section creates and performs Section 508-compliant quality reviews of PDFs for tax products and forwards them to the Alternative Media Center (AMC). Composition also creates alternative electronic versions of publications and instructions for Section 508 compliance (e.g., an HTML version), and for use on mobile devices (e.g., an eBook version). Composition posts PDFs and other related files for all products in alternative formats to the Core Repository of Published Products (CROPP) and stages files for posting to [www.irs.gov](https://www.irs.gov/irm/part1/www.irs.gov) for upload via the Electronic Tax Forms Distribution (ETFD) application. Stakeholders (publishing specialists and distribution analysts) receive notification when OK-to-Print files are available for printing and posting.


**1.17.3.5.4** **(08-09-2024)**

#### Issuing Tax Products OK-to-Print Notification

1. Once Electronic Composition provides an OK-to-Print file, the publishing specialist updates and issues the product information in the Published Products Media Catalog (PPMC). Once the product is updated in PPMC, it is published in the Composition Process Management (CPM) system. This step communicates with the catalog page on the Publishing website, which houses all the products the IRS publishes, and makes the products available to all IRS employees. The catalog page reflects any changes made to the product’s information in ESN.


**1.17.3.5.5** **(11-16-2012)**

#### Requesting a Form 2040 Distribution List/Pattern

1. Form 2040, _Distribution List_, also includes the product and vendor information. Publishing specialists should email the distribution analyst to request a Form 2040 after issuing the product in ESN. Form 2040 is only available electronically, and only publishing specialists can access Form 2040 from the M&P Page 1 Intranet site.


**1.17.3.5.6** **(11-16-2012)**

#### Procurement of Tax Products

1. The Publishing Services Data (PSD) application is a software product used to track procurement information on each product. See IRM 1.17.2.5.2, _Publishing Services Data (PSD)_, for more information about PSD. This information consists of schedules of when a vendor procures the product, the cost of the procurement, the vendor that is doing the work, and the type of procurement vehicle used (for procurement vehicles, see the next topic). After receiving a Form 2040 from a distribution analyst, the publishing specialist inputs all necessary data (e.g., schedules, commitment of funds, and procurement information) in the PSD application.


**1.17.3.5.7** **(08-09-2024)**

#### Procurement Vehicles

1. There are three primary procurement vehicles the Government Publishing Office (GPO) established for producing tax products. Only publishing specialists are authorized to use these procurement vehicles. Publishing specialists initiate the procurement and print production of IRS published products using the following forms:



1. Term Contract - Publishing-established term contracts for products purchased on a repetitive basis. The GPO writes, awards, and administers these contracts.

2. Simplified Purchase Agreements (SPA) - Streamlined publishing procurement vehicles that the GPO authorizes. Using simplified purchase agreements, publishing specialists can help customers acquire printing and publishing services from commercial printing vendors by directly placing orders or soliciting competitive quotes.

3. One-Time Bids - Published products that are not suited to other procurement vehicles are procurable using a one-time bid. Publishing specialists forward product requirements to the GPO, where the requirements are advertised to potential vendors. The GPO awards the production contract to the lowest bidder that is considered responsive and responsible.


**1.17.3.6** **(11-16-2012)**

### Quality Control

1. The Tax Form Printing Program is one of the primary ways for the IRS to communicate the tax law to the general public. Therefore, quality is important during all phases of preparation and production. Quality, in terms of typography, design, format, readability, usability, and product printability, must be a prime part of all review and decision-making steps.


**1.17.3.6.1** **(11-16-2012)**

#### Quality Control Planning and Review

1. Prior to actual printing production, Publishing exercises quality control through a planning and review process that ensures:



1. The item is properly cleared, authorized, and identified through form numbering, catalog numbering, etc.;

2. The selected styles and sizes of type adhere to accepted tax forms standards;

3. The format and printed product specifications will produce the most effective and economical product to fulfill the need;

4. Adequate scheduling and planning time has been allowed, where possible, to minimize the possibility of error;

5. All proofs and copy are reviewed for accuracy;

6. The final reproduction proofs have consistent tonal density, high contrast, and sharp/clear images;

7. All printing instructions are precise, clearly understandable, and consistent with printing trade customs; and

8. Considering the impact on related items such as form size versus related envelopes, paper weight/size versus processing method, product format versus shipping/mailing requirements, etc.


**1.17.3.6.2** **(11-16-2012)**

#### Onsite Quality Control Planning and Review

1. During the production of IRS products, Publishing may conduct onsite press sheet inspection visits to control, as much as possible, the quality of the final product.

2. Quality, from a program management standpoint, also extends beyond the tangible parameters of the published product. Publishing schedules and coordinates all elements required to ensure a successful procurement including:



   - Planning and scheduling to meet critical deadlines;

   - Coordinating and communicating actual requirements among a diversity of sources;

   - Evaluating the importance of user needs and translating these into positive actions;

   - Providing guidance and advice on the impact of any program changes;

   - Evaluating procedures, methods, and costs on a continuing basis;

   - Determining alternatives necessary to ensure mission fulfillment; and

   - Instituting systems for monitoring and controlling all aspects of the procurement.


**1.17.3.6.3** **(10-14-2015)**

#### Offsite Quality and Quantity Assurance

1. To ensure an adequate level of quality, Publishing conducts a quality assurance review that may include Publishing onsite press sheet inspections. During or after an onsite press sheet inspection, Publishing personnel will:



   - Conduct a thorough quality assurance inspection of each selected tax item, using Form 5508, _Quality Assurance Inspection Report_, as a guide.

   - Notify the Government Publishing Office (GPO) by email or telephone of any situation that requires immediate corrective action.


2. Only the GPO, as the official contracting officer, is authorized to make any changes to the printing contracts. M&P Publishing personnel who perform press sheet inspections are not authorized to change printing contracts.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-017-003#addtoany "Show all")

A2A