---
url: "https://www.irs.gov/irm/part1/irm_01-004-013"
title: "1.4.13 TAS Guide for Managers | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-013#main-content)

- 1.4.13  [TAS Guide for Managers](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086091888)
  - 1.4.13.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086079056)
    - 1.4.13.1.1  [Authority](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086073536)
    - 1.4.13.1.2  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086069104)
    - 1.4.13.1.3  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086061968)
    - 1.4.13.1.4  [Terms](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086058624)
    - 1.4.13.1.5  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086056640)
    - 1.4.13.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048086054656)
  - 1.4.13.2  [Taxpayer Bill of Rights](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085425776)
  - 1.4.13.3  [TAS Guiding Principles](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085420720)
    - 1.4.13.3.1  [Empathy and the Taxpayer Experience](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085403696)
  - 1.4.13.4  [Maintaining Internal Controls](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085398480)
    - 1.4.13.4.1  [Federal Managers’ Financial Integrity Act](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085393552)
    - 1.4.13.4.2  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085391392)
    - 1.4.13.4.3  [Internal Controls Managerial Assessment](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085381184)
    - 1.4.13.4.4  [Internal Control Resources](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085375264)
    - 1.4.13.4.5  [Manual Refunds](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085365984)
      - 1.4.13.4.5.1  [Manual Refund Training](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085355312)
    - 1.4.13.4.6  [Payment Processing](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085342848)
    - 1.4.13.4.7  [Return Processing](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085337984)
    - 1.4.13.4.8  [IDRS](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085333904)
      - 1.4.13.4.8.1  [IDRS Security](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085328928)
        - 1.4.13.4.8.1.1  [Making Deviations from an IDRS MPAF and RSTRK Definer U](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085272160)
      - 1.4.13.4.8.2  [Authorized IDRS Access](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085265824)
      - 1.4.13.4.8.3  [IDRS Retention Criteria](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085252592)
      - 1.4.13.4.8.4  [IDRS Message File](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085250400)
      - 1.4.13.4.8.5  [Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085245808)
      - 1.4.13.4.8.6  [Reviewers of IDRS Adjustments](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085232640)
      - 1.4.13.4.8.7  [Unit Security Representative Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085218608)
      - 1.4.13.4.8.8  [Terminal Security Administrator](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085209920)
      - 1.4.13.4.8.9  [TAS IORS POC Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085201600)
      - 1.4.13.4.8.10  [TAS IDRS Business Unit POC Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085188416)
    - 1.4.13.4.9  [TAS Systems Access](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085182480)
      - 1.4.13.4.9.1  [TAMIS](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085177936)
        - 1.4.13.4.9.1.1  [Making Deviations from a TAMIS Permission Level](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085159536)
      - 1.4.13.4.9.2  [Systemic Advocacy Management System (SAMS)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085155552)
    - 1.4.13.4.10  [Clean Desk Policy](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085147552)
    - 1.4.13.4.11  [Confidentiality of Tax Returns and Tax Return Information](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085144048)
  - 1.4.13.5  [Hiring Employees](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085132944)
  - 1.4.13.6  [Assigning Work](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085130080)
    - 1.4.13.6.1  [TAS Case Assignment](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085125424)
      - 1.4.13.6.1.1  [CATS Case Assignment](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085108016)
      - 1.4.13.6.1.2  [Case Assignments for CATS Trainees](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085100608)
    - 1.4.13.6.2  [Systemic Advocacy Work Assignment](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085094336)
  - 1.4.13.7  [Employee Development](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085088144)
  - 1.4.13.8  [Communication Skills](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085085152)
    - 1.4.13.8.1  [Developing and Communicating Expectations](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085080128)
    - 1.4.13.8.2  [Distance Management – Working Effectively with Employees on Telework and Offsite Employees](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085064864)
    - 1.4.13.8.3  [Outreach](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085034208)
  - 1.4.13.9  [Managerial Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085030880)
    - 1.4.13.9.1  [Employee Engagement Lifecycle](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085023136)
    - 1.4.13.9.2  [Year-Round Employee Engagement and Support](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085018800)
    - 1.4.13.9.3  [Personalized Employee Coaching and Support](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085016384)
      - 1.4.13.9.3.1  [New Hire Reviews During On-the-Job Training (OJT)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048085002112)
      - 1.4.13.9.3.2  [Detail Assignment Performance Review](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084983728)
    - 1.4.13.9.4  [Weekly Employee Support Debrief](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084981296)
    - 1.4.13.9.5  [Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084978576)
      - 1.4.13.9.5.1  [Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084971008)
      - 1.4.13.9.5.2  [Mid-Year Assessment, End-of-Year Evaluation, and Discussion](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084967504)
      - 1.4.13.9.5.3  [Operational Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084956576)
      - 1.4.13.9.5.4  [Case Advocacy Employee Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084821568)
        - 1.4.13.9.5.4.1  [Ongoing Advocacy Review and Employee Support Discussion](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084817808)
        - 1.4.13.9.5.4.2  [Intake Advocate Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084807648)
        - 1.4.13.9.5.4.3  [Lead Case Advocate and Lead Intake Advocate Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084774144)
        - 1.4.13.9.5.4.4  [Case Advocate Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084763360)
        - 1.4.13.9.5.4.5  [Early Intervention Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084752784)
        - 1.4.13.9.5.4.6  [Manual Refund Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084736896)
        - 1.4.13.9.5.4.7  [Small Business Regulatory Enforcement Fairness Act (SBREFA) Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084701616)
        - 1.4.13.9.5.4.8  [Area Advocacy Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084689984)
        - 1.4.13.9.5.4.9  [Area Operational Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084676752)
        - 1.4.13.9.5.4.10  [365+ Day Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084666848)
        - 1.4.13.9.5.4.11  [Tailored Advocacy Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084657216)
        - 1.4.13.9.5.4.12  [OAR Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084638688)
        - 1.4.13.9.5.4.13  [100-day with No Action in Last 60 days](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084623120)
        - 1.4.13.9.5.4.14  [Relief and Outcome](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084613488)
        - 1.4.13.9.5.4.15  [Correspondence](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084603936)
        - 1.4.13.9.5.4.16  [IDRS Online Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084594560)
        - 1.4.13.9.5.4.17  [Pre-Closure Reviews (PCRs)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084581392)
      - 1.4.13.9.5.5  [Internal Technical Advisor Program (ITAP) Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084568176)
        - 1.4.13.9.5.5.1  [Technical Accuracy Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084561168)
        - 1.4.13.9.5.5.2  [Workload Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084549040)
        - 1.4.13.9.5.5.3  [TAO Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084538976)
      - 1.4.13.9.5.6  [TAG Program Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084528896)
      - 1.4.13.9.5.7  [Taxpayer Advocacy Panel (TAP) Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084181024)
      - 1.4.13.9.5.8  [Systemic Advocacy Reviews](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084155104)
    - 1.4.13.9.6  [Performance Management System Process/Performance Review Board](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084079696)
    - 1.4.13.9.7  [Contact Recording/Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084076240)
    - 1.4.13.9.8  [Statistics RRA 98 Section 1204 – 1204 Certification](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084068912)
  - 1.4.13.10  [Labor Relations](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084060640)
    - 1.4.13.10.1  [Conduct and Performance](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084050688)
    - 1.4.13.10.2  [Grievances and Arbitration](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084038448)
  - 1.4.13.11  [TAS Balanced Measures](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084034448)
  - 1.4.13.12  [Office Management](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084029216)
    - 1.4.13.12.1  [Outgoing Calls](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084027872)
    - 1.4.13.12.2  [Telephone-based Operations](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084025552)
    - 1.4.13.12.3  [Office Closures](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084019184)
    - 1.4.13.12.4  [Case Advocate Relocations](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048084005488)
    - 1.4.13.12.5  [Outgoing Recorded Phone Messages](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083988992)
    - 1.4.13.12.6  [Staffing and Monitoring CCI Incoming Phone Lines](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083986992)
      - 1.4.13.12.6.1  [Outgoing Calls](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083931008)
      - 1.4.13.12.6.2  [Telephone System Assistance](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083926400)
      - 1.4.13.12.6.3  [Real Time Reports](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083909872)
      - 1.4.13.12.6.4  [CTIOS Supervisor Desktop Application](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083898368)
      - 1.4.13.12.6.5  [Average Handle Time](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083887392)
    - 1.4.13.12.7  [Taxpayer Requests to Speak with a Manager](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083882528)
    - 1.4.13.12.8  [Managing Employees](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083876816)
      - 1.4.13.12.8.1  [Employee Performance File (EPF)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083875904)
      - 1.4.13.12.8.2  [Employee Drop File (EDF)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083870544)
      - 1.4.13.12.8.3  [Official Personnel File (OPF)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083867488)
      - 1.4.13.12.8.4  [Medical Documentation](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083865232)
      - 1.4.13.12.8.5  [Time and Attendance](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083863072)
        - 1.4.13.12.8.5.1  [Annual Leave](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083856752)
        - 1.4.13.12.8.5.2  [Sick Leave](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083852496)
        - 1.4.13.12.8.5.3  [Advanced Sick Leave](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083844480)
        - 1.4.13.12.8.5.4  [Family Leave](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083837616)
        - 1.4.13.12.8.5.5  [Maternity Leave](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083832240)
        - 1.4.13.12.8.5.6  [Leave without Pay](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083824976)
        - 1.4.13.12.8.5.7  [Absence without Leave](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083817184)
        - 1.4.13.12.8.5.8  [Other Leave](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083811712)
  - 1.4.13.13  [Reserved](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083805408)
  - 1.4.13.14  [Continuity Planning](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083803792)
    - 1.4.13.14.1  [Manager’s Roles and Responsibilities.](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083802064)
  - 1.4.13.15  [Security](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083791184)
  - 1.4.13.16  [Disclosure](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083783184)
  - Exhibit  1.4.13-1  [Terms](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083776944)
  - Exhibit  1.4.13-2  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083756656)
  - Exhibit  1.4.13-3  [TAS Manager Review Schedule](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083581776)
  - Exhibit  1.4.13-4  [IDRS MPAF for Case Advocates (Including Lead Case Advocates)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083579872)
  - Exhibit  1.4.13-5  [IDRS MPAF for Intake Advocates (Including Lead Intake Advocates)](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083529040)
  - Exhibit  1.4.13-6  [IDRS MPAF for Secretaries, Management Assistants, Program Analysts, Management Program Analysts, Tax Analysts, Systems Analysts, Case Advocacy Specialists, and Technical Advisors](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083488384)
  - Exhibit  1.4.13-7  [IDRS MPAF for Quality Analysts](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083451328)
  - Exhibit  1.4.13-8  [IDRS MPAF for TAS Managers](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083419664)
  - Exhibit  1.4.13-9  [Command Codes for IDRS Online Reviews of Account Adjustments](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083383856)
  - Exhibit  1.4.13-10  [Security Command Codes for Unit Security Representatives](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083376736)
  - Exhibit  1.4.13-11  [Security Command Codes for Terminal Security Administrators](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083367632)
  - Exhibit  1.4.13-12  [IDRS Multiple Access Approval Table](https://www.irs.gov/irm/part1/irm_01-004-013#idm140048083363344)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 13. TAS Guide for Managers

* * *

## 1.4.13 TAS Guide for Managers

#### Manual Transmittal

June 13, 2025

#### Purpose

(1) This transmits revised IRM 1.4.13, Resource Guide for Managers, TAS Guide for Managers.

#### Material Changes

(1) IRM 1.4.13.13, Updated to comply with January 2025 Executive Orders and OPM guidance.. IPU 25U0162 issued 02-03-2025.

(2) IRM 1.4.13 Contains editorial and grammatical changes throughout the IRM. IPU 25U0162 issued 02-03-2025.

(3) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.4.5 replaced reference to the TAS Manager Handbook with a cross reference to IRM 1.4.13.9.6.4.6(5) where information is currently located.

(4) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.4.8.1 clarified that Case Advocacy Specialists are included in the Research Profile Type for IDRS.

(5) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.4.8.5 updated reference to IRM 10.5.5.3.5.

(6) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.4.8.7 updated reference to IRM 10.8.34.2.1.3.

(7) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.4.8.9 updated references to IRM 10.5.5.3.5, IRM 10.8.34.2.2.5 and IRM 10.8.34.5.3.1.

(8) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.4.9 removed link to the TAS Security and New Hire Equipment and Software Requests as these are no longer available. Updated title of TAS Technology Place to TAS Technology Hub.

(9) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.6.1 added the elevation process for disagreements with case acceptance determinations to avoid employee communications on whether a case should be accepted into TAS.

(10) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.7 removed link to Leadership 365 Knowledge Base as it is no longer available. Replaced link to Career Planning and Development Resources with Leadership Development and Support Office, Servicewide Mentoring Program with IRS Coaching Resource Center, and Servicewide Opportunities with Career Opportunities.

(11) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.8.1 replaced link to Executive Compensation & Performance with Pay and Career Planning and Development Resources with Leadership Development and Support Office.

(12) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.8.2 updated to replace the telework portal with \*TAS TW Portal Agreements (TAS.TW.Portal.Agreements@irs.gov) per the Welcome Screen article, New email for approved TAS Telework agreements - Important Information for managers, published on May 23, 2023.

(13) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.9.6 replaced link to Executive Compensation & Performance with Pay Systems, Salary Tables, and Pay Administration and IRS Payband Resource Center with IRS Payband System (IR).

(14) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.9.6.3 clarified to add a deviation for Operational Reviews when approved by the first line executive.

(15) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.9.6.4.2 clarified that Lead Case Advocates (LCAs) may conduct non-evaluative reviews and updated the literal with this clarification.

(16) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.9.6.4.9 updated to include the review of open and closed cases for consistency with the TAS Manager Review Guide. Exchanged the scope with IRM 1.4.13.9.4.6.10.

(17) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.9.6.4.10 updated to include the review of open and closed cases. Exchanged the scope with IRM 1.4.13.9.4.6.9.

(18) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.9.7 replaced link to Executive Compensation & Performance website with Performance Evaluations and Payband Resource Center with IRS Payband system. Added a link to the Performance Review Board.

(19) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.9.9 replaced How to Input Section 1204 Information into HR Connect with RRA’98 Section 1204 Program. Added a link to Section 1204 Program – HR Connection Indication, How to Add Section 1204 Indicator in HR Connect (SHOTs Video).

(20) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.10 replaced link to Contact Field Operations site with Field Operations site.

(21) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.10.1 replaced link to Contact Field Operations site with Field Operations site.

(22) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.11 removed the link to the Business Assessment site as it is not currently available.

(23) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.1 removed the link to Tips for creating, maintaining and disposing of Employee Performance Files (EPFs) as is it no longer available.

(24) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.5.1 updated title from Employee Resource Center to Employee Resources.

(25) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.5.2 updated title from Employee Resource Center to Employee Resources.

(26) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.5.3 updated title from Employee Resource Center to Employee Resources.

(27) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.5.4 updated title from Employee Resource Center to Employee Resources.

(28) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.5.5 added link to IRM 6.630.5, Leave and Flexibilities for Birth, Adoption, Foster Care, or Child Bereavement.

(29) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.5.6 added new link to Employee Resources, Leave Without Pay.

(30) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.12.8.5.8 updated title from Employee Resource Center to Employee Resources.

(31) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.15 added link to Document 13347, Data Breach Response Playbook and Report Losses, Thefts or Disclosures of Sensitive Data; Report Lost or Stolen IT Assets and BYOD Assets.

(32) IPU 23U0733 issued 06-15-2023 IRM 1.4.13.16 replaced link to CSIRC Website with Cyber Security.

(33) IPU 23U0733 issued 06-15-2023 IRM 1.4.13-6 clarified the title by adding Case Advocacy Specialists.

(34) IPU 23U0733 issued 06-15-2023 IRM 1.4.13-8 added command code (CC) COMPA as managers use it to verify calculations.

(35) IPU 23U0856 issued 07-28-2023 IRM 1.4.13.4.5 added additional cross references and added a note concerning manual monitoring for manual refunds input after June 16, 2023.

(36) IPU 23U0856 issued 07-28-2023 IRM 1.4.13.4.5.1(1) updated for consistency with training requirements for employees initiating, reviewing, signing, and monitoring manual refunds in IRM 3.17.79.1.1.1. Per IRM 21.4.4.6.1(1) (6/15/2023), effective June 20, 2023, do not add any manual refunds into the EMT/Case Monitoring Tool. Monitoring will continue for those manual refunds input before June 20, 2023. Added a note concerning manual monitoring for manual refunds input after June 16, 2023.

(37) IPU 23U0856 issued 07-28-2023 IRM 1.4.13.9.6.4.6 per SERP Alert 23A0413 use of the EMT/ Case monitoring tool is no longer required for manual refunds input after June 16, 2023. Daily manual refund monitoring is performed in headquarters. Daily manual refund monitoring is required for manual refunds input before June 17, 2023. It is not required for manual refunds input after June 16, 2023.

(38) IPU 23U0856 issued 07-28-2023 IRM 1.4.13.10.1 added link to IRM 6.432.1, Addressing Poor Performance.

(39) IPU 23U0856 issued 07-28-2023 Exhibit 1.4.13-12 added reactivated unit 63861 to 1-Andover.

(40) IPU 23U1134 issued 11-29-2023 IRM 1.4.13.4.5 updated to remove manual refund monitoring requirements per IRM 21.4.4.6.1, Monitoring Manual Refunds.

(41) IPU 23U1134 issued 11-29-2023 IRM 1.4.13.4.5.1 updated to correct training requirements per IRM 3.17.79.1.1.1, Training, and removed training related to manual refund monitoring as manual refund monitoring per IRM 21.4.4.6.1, Monitoring Manual refunds.

(42) IPU 23U1134 issued 11-29-2023 IRM 1.4.13.4.8.2 updated to clarify when a Form 11377-E, Taxpayer Data Access, should be completed when an inquiry or case concerns an IRS employee.

(43) IPU 23U1134 issued 11-29-2023 IRM 1.4.13.9.6.4.6 updated to remove manual refund monitoring requirements per IRM 21.4.4.6.1, Monitoring Manual Refunds.

(44) IPU 23U1134 issued 11-29-2023 IRM 1.4.13.9.6.4.7 on October 12, 2023, TAS ended its special case processing steps for the Offshore Voluntary Disclosure Program cases (OVDP), including the mandatory OVDP case reviews.

(45) IPU 23U1134 issued 11-29-2023 Exhibit 1.4.13-2 added acronym Direct Debit Installment Agreement (DDIA) and removed acronyms no longer used in the IRM.

(46) IPU 23U1134 issued 11-29-2023 Exhibit 1.4.13-4 removed Command Code (CC) EFTOF. TAS employees do not have the delegated authority to input skip payments on DDIAs, since this CC is solely used to input skip payments for DDIAs it has been removed.

(47) IPU 24U0127 issued 01-25-2024 IRM 1.4.13.10 updated to incorporate changes to requesting assistance with Labor Relations issues.

(48) IPU 24U0127 issued 01-25-2024 IRM 1.4.13.10.1 updated to incorporate changes to requesting assistance with Labor Relations issues.

(49) IPU 24U0127 issued 01-25-2024 IRM 1.4.13.10.2 updated to add an additional resource.

(50) IPU 24U0274 issued 02-21-2024 IRM 1.4.13.9.4.1 updated to clarify that managers will complete mandatory reviews during On-the-Job training (OJT).

(51) IPU 24U0274 issued 02-21-2024 IRM 1.4.13.10.1 updated to add Document 12109, The IRS Supervisors Guide to Conduct and Discipline and Related Topics, as an additional resource.

(52) IPU 24U0376 issued 03-08-2024 Exhibit 1.4.13-12 updated to correct the IDRS unit code for the Quality Review Program to 63714 and Northern Kentucky to Covington.

(53) IPU 24U0566 issued 04-25-2024 IRM 1.4.13.6.1(7) added paragraph to reference case assignments for the Case Advocate Training Support (CATS) Program.

(54) IPU 24U0566 issued 04-25-2024 IRM 1.4.13.6.1.1 added section CATS Case Assignment based on Interim Guidance Memorandum (IGM) TAS-13-0522-0006, Interim Guidance on Taxpayer Advocate Case Procedures Performed by Employees of the Case Advocate Training Support Program.

(55) IPU 24U0566 issued 04-25-2024 IRM 1.4.13.6.1.2 added section Case Assignments for CATS Trainees based on Interim Guidance Memorandum (IGM) TAS-13-0522-0006, Interim Guidance on Taxpayer Advocate Case Procedures Performed by Employees of the Case Advocate Training Support Program.

(56) IPU 24U0566 issued 04-25-2024 IRM 1.4.13.10.1(7)(h) updated title of hyperlink.

(57) IPU 24U0566 issued 04-25-2024 Exhibit 1.4.13-2 added acronyms.

(58) IPU 24U0566 issued 04-25-2024 IRM 1.4.13 contains editorial and grammatical changes throughout the IRM.

(59) IPU 24U0955 issued 09-04-2024 IRM 1.4.13.4.8.8 corrected spelling error per SERP Feedback #22788.

(60) IPU 24U0955 issued 09-04-2024 IRM 1.4.13.9.1 removed reference to the First Quarter Skills Assessment as these have been suspended.

(61) IPU 24U0955 issued 09-04-2024 IRM 1.4.13.9.3 removed section as the First Quarter Skills Assessment as these have been suspended.

(62) IPU 24U0955 issued 09-04-2024 IRM 1.4.13.9.5.2 removed reference to the First Quarter Skills Assessment as these have been suspended.

(63) IPU 24U0955 issued 09-04-2024 IRM 1.4.13.9.5.3 removed reference to the First Quarter Skills Assessment as these have been suspended.

(64) IPU 24U1125 issued 11-12-2024 IRM 1.4.13.6.1.1 updated for plain language.

(65) IPU 24U1125 issued 11-12-2024 IRM 1.4.13.6.1.2 updated to clarify case assignment to new Case Advocates.

#### Effect on Other Documents

IRM 1.4.13, dated 3-13-2023, is superseded. The IRM Procedural Update (IPU) 23U0733 (issued 6/15/2023), IPU 23U0856 (issued 7/28/2023), IPU 23U1134 (issued 11-29-2023), IPU 24U0127 (issued 1-25-2024), IPU 24U2074 (issued 2-21-2024), IPU 24U0376 (issued 3-8-2024), IPU 24U0566 (issued 4-25-2024), IPU 24U0955 (issued 9-4-2024), IPU 24U1125 (issued 11-12-2024), and IPU 25U0162 (issued 2-3-2025) have been incorporated into this IRM. IGM TAS-13-0522-0006, Interim Guidance on Taxpayer Advocate Case Procedures Performed by Employees of the Case Advocate Training Support Program, is superseded with the publishing of this IPU.

#### Audience

Taxpayer Advocate Service employees

#### Effective Date

(06-13-2025)

Elizabeth R. Blazey-Pennel

Acting Executive Director Case Advocacy, Intake and Technical Support

**1.4.13.1** **(03-13-2023)**

### Program Scope and Objectives

1. _Purpose:_ This section supplements IRM 1.4, Resource Guide for Managers, and provides Taxpayer Advocate Service (TAS) managers with TAS specific guidelines, methods, and techniques for managing TAS employees.

2. _Audience:_ These procedures apply to all TAS managers.

3. _Policy Owner:_ The Deputy National Taxpayer Advocate, who reports to the National Taxpayer Advocate.

4. _Program Owner:_ The Executive Director Case Advocacy, Intake & Technical Support (EDCA-ITS), who reports to the Deputy National Taxpayer Advocate.


**1.4.13.1.1** **(03-13-2023)**

#### Authority

1. Under IRC 7803(c)(2)(A)(i)-(iv), TAS’s statutory mission is to:



1. Assist taxpayers in resolving problems with the Internal Revenue Service;

2. Identify areas in which taxpayers have problems in dealings with the Internal Revenue Service;

3. To the extent possible, propose changes in the administrative practices of the Internal Revenue Service to mitigate problems identified; and

4. Identify potential legislative changes which may be appropriate to mitigate such problems.


2. The TAS Focus Guide (formerly Program Letter) (issued annually) supports IRM 1.4.13.


**1.4.13.1.2** **(03-13-2023)**

#### Responsibilities

1. TAS managers should be aware and should educate their employees about TAS’s goals, mission, and organizational priorities.

2. TAS managers are committed to improving the workplace for employees, including:



1. Securing equipment and supplies necessary for employees (including remote employees co-located with the manager who do not report to the manager) to work.

2. Identifying employee training opportunities.

3. Developing employees to enhance their careers.

4. Encouraging employees to empathize with their customers.

5. Helping employees to balance work and family life.

6. Listening to employee suggestions and, when appropriate, working to implement these suggestions.

7. Ensuring employees have the tools necessary to conduct day-to-day operations. For example, managers should ensure employees (who may not travel frequently) are prepared to travel, have the information necessary to travel safely, and know who to contact if something unexpected happens while travelling. For additional information concerning official IRS travel, see Traveler’s Toolkit.

8. Encouraging an atmosphere that is free from discrimination.


**1.4.13.1.3** **(07-16-2021)**

#### Program Management and Review

1. TAS managers will integrate advocacy in all aspects of their position and when working with their employees.

2. TAS managers follow program review guidelines set forth in _IRM 1.4.13.9_, Managerial Reviews.

3. TAS managers follow the Performance Agreement Responsibilities and Commitments contained in Form 12450-A, IRS Performance Management System – Manager Performance Agreement.


**1.4.13.1.4** **(03-13-2023)**

#### Terms

1. _Exhibit 1.4.13-1._ contains a list of terms used throughout this IRM.


**1.4.13.1.5** **(03-13-2023)**

#### Acronyms

1. _Exhibit 1.4.13-2._ contains a list of acronyms used throughout this IRM.


**1.4.13.1.6** **(03-13-2023)**

#### Related Resources

1. TAS managers will use the following resources in conjunction with this IRM:



1. The TAS Leadership Development site provides TAS leaders with the necessary resources to help them enhance their knowledge and skills, achieve personal goals, improve the productivity of the organization, and provide leadership and service.

2. iManage is a virtual community accessible only by IRS managers. It provides information on the actual work managers performs, along with handy bits of advice such as performance evaluation tips and leave approval.

3. The TAS Managers Handbook provides detailed information on a variety of topics to assist TAS managers in their day-to-day duties.

4. The National Taxpayer Advocate’s [National Taxpayer Advocate Reports to Congress and Research](https://www.irs.gov/advocate/reports-to-congress) due on or before June 30 (Objectives Report) and December 31 (Annual Report) each fiscal year provides the objectives for the upcoming fiscal year for TAS, and activities taken during the current fiscal year, including the Most Serious Problems encountered by taxpayers, etc. See IRC 7803(c)(2)(B)(i), (ii).

5. The TAS Focus Guide (proceeded by the Program Letter), issued annually, provides a concise road map of the actions TAS will take in the upcoming fiscal year.


**1.4.13.2** **(03-13-2023)**

### Taxpayer Bill of Rights

1. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see [https://www.irs.gov/taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights).

2. Taxpayers have always had these Rights but often were not aware of them. These Rights are now part of Publication 1, Your Rights as a Taxpayer and codified in IRC section 7803(a)(3), which requires the Commissioner of the IRS to ensure IRS employees are familiar with and act in accordance with the TBOR.

3. Managers are responsible for ensuring employees are aware of taxpayer rights, understand how taxpayer rights apply to their day-to-day work, and protect taxpayers through their advocacy efforts.

4. For more information on how these rights might apply to specific situations see Learn What This Means for You.

5. See IRM 1.2.1.2.36, Policy Statement 1-236, for information concerning Fairness and Integrity in Enforcement Selection.


**1.4.13.3** **(03-13-2023)**

### TAS Guiding Principles

1. TAS Guiding Principles govern the way TAS does business, and represent the essence of what the customer needs, wants, and expects. These principles reflect how the customer expects to be engaged. The principles should inspire, focus, and help promote the TAS mission for all functions within TAS. They help anchor and drive the organization’s performance and should be reinforced at all times and levels throughout the organization. These seven principles will guide TAS in advocating for customers.

2. **Advocacy** is the willingness and ability to see the situation from a taxpayer’s perspective, advocate for the taxpayer’s rights, and assist IRS leadership in integrating the taxpayer’s perspective into tax administration.



1. Advocacy is best achieved by adhering to three interrelated concepts that are fundamental to the operation of TAS — independence, impartiality, and confidentiality. The role of TAS employees is to advocate on behalf of all taxpayers. The TAS employee’s job goes beyond resolving a taxpayer’s current problem; the TAS employee educates the taxpayer to help prevent any future problems or misunderstandings. TAS has a responsibility to think systemically about each case and recommend changes to mitigate those problems for taxpayers in the future. The vast majority of U.S. taxpayers, year after year, try to get things right with the IRS. It is a privilege to speak up for them, to the best of our abilities, and to make sure that the IRS treats them fairly.

2. Advocacy is also achieved by providing training, guidance, tools, etc., that support our individual and systemic advocacy efforts along with means of communicating key messages to TAS employees.


3. **Independence** is the ability to objectively advocate for the taxpayer separately from the IRS.



1. Each Local Taxpayer Advocate (LTA) must have a phone, fax, electronic communication, separate office space, and mailing address separate from those of the IRS. See IRC section 7803(c)(4)(B). See also IRM 13.6.1, Internal and External Communications.

2. The LTA must advise taxpayers at their first contact of the fact that “the Taxpayer Advocate offices operate independently of any other Internal Revenue Service office and report directly to Congress through the National Taxpayer Advocate.” See IRC section 7803(c)(4)(A)(iii). See also IRM 13.1.18.6(1), Initial Contact Completed by Case Advocates.

3. Each year, the National Taxpayer Advocate submits two reports to Congress: an Annual Report, due not later than December 31, and an Objectives Report, due not later than June 30. The National Taxpayer Advocate delivers these reports to the Senate Committee on Finance and the House Committee on Ways and Means with no prior review or comment from the Commissioner, the IRS Oversight Board, the Secretary of the Treasury, any other Treasury officer or employee, or the Office of Management and Budget. See IRC section 7803(c)(2)(B)(iii).

4. Congress also granted the LTAs discretion to not disclose the fact the taxpayer contacted the Office of the Taxpayer Advocate, or any information provided by the taxpayer to that office. See IRC section 7803(c)(4)(A)(iv). See also IRM 13.1.5, Taxpayer Advocate Service (TAS) Confidentiality.

5. TAS employees must constantly remind the IRS that we bring an independent point of view.


4. **Confidentiality** is the discretion in disclosing information to the IRS. See IRM 13.1.5, Taxpayer Advocate Service (TAS) Confidentiality.

5. **Competence** is the knowledge and ability to understand the taxpayer’s issue and how to resolve it.

6. **Empathy** is the understanding of and compassion for the taxpayer’s situation and feelings.

7. **Communications** is the commitment to engage in clear and open communications, listen to taxpayers and stakeholders, understand their perspectives and issues, educate them about the tax system, and effect changes.

8. **Improvement**is the pursuit of opportunities to improve tax administration for the benefit of taxpayers.


**1.4.13.3.1** **(03-13-2023)**

#### Empathy and the Taxpayer Experience

1. To advocate fully, TAS must seek to understand the people we serve. Our employees must understand the challenges facing different taxpayers and groups, recognize how a taxpayer’s emotions may affect the taxpayer’s behavior, and appreciate how to connect with taxpayers in a way that builds mutual trust and respect.

2. TAS employees play a critical role in reassuring taxpayers that TAS is doing all we can to assist them with their tax issue.

3. We must be empathetic. Empathy goes beyond advocating for taxpayers.

4. TAS managers must be empathetic to employees’ personal situations as well.

5. TAS managers will help employees enhance their skills and use them to enhance the taxpayer experience when advocating for the taxpayer. Offices will create a plan to develop empathy skills by practicing empathy throughout the year.


**1.4.13.4** **(07-16-2021)**

### Maintaining Internal Controls

1. The IRS and TAS are required to maintain an effective internal control program that complies with legislative requirements and related regulations and directives, such as the Standards for Internal Control in the Federal Government, commonly known as the "Green Book."

2. Internal controls are the programs, policies, and procedures established to ensure:



1. Mission and program objectives are efficiently and effectively accomplished.

2. Program and resources are protected from waste, fraud, abuse, mismanagement, and misappropriation of funds.

3. Laws and regulations are followed.

4. Financial reporting is reliable.

5. Reliable information is obtained and used for decision making.


3. This guidance applies to all TAS managers. TAS managers are expected to understand the risks associated with their operations, to ensure controls are in place and operating effectively to mitigate known risks, and to provide candid, reliable, and supportable annual reports on the status of those controls. For more information, see IRM 1.4.2, Resource Guide for Managers, Monitoring and Improving Internal Control.


**1.4.13.4.1** **(07-16-2021)**

#### Federal Managers’ Financial Integrity Act

1. The Budget and Accounting Procedures Act of 1950 requires the head of each Federal department and agency to establish and maintain adequate systems of management controls. Further, the Federal Managers' Financial Integrity Act of 1982, Public Law 97-255 (hereinafter "FMFIA"), requires each executive agency to establish internal accounting and administrative controls in accordance with standards prescribed by the Comptroller General. See IRM 1.4.2.1.2, Authorities, for more information.


**1.4.13.4.2** **(09-17-2019)**

#### Roles and Responsibilities

1. The National Taxpayer Advocate is responsible for:



1. Establishing adequate and effective controls for all operations and activities in TAS’s area of mission responsibility;

2. Ensuring established controls are followed throughout the organization.

3. Conducting a self-assessment and reporting on the status of internal controls in the organization to the Management Controls Executive Steering Committee (MC ESC) annually. Managers throughout the IRS are responsible for participating in this annual assessment in accordance with the annual guidance issued.

4. Evaluating reports of significant deficiencies and providing comments to the MC ESC.

5. Providing adequate resources to correct identified material weaknesses and significant deficiencies.

6. Designating an Internal Control Coordinator to serve as a single point of contact for the assurance process and for FMFIA corrective actions and audit follow-up for their organization.

7. Preparing executive summaries for agenda topics at MC ESC meetings.


2. All TAS managers are responsible for:



1. Providing a positive control environment;

2. Identifying potential risk areas;

3. Ensuring adequate and effective controls are in place;

4. Reporting results of reviews to the next level of management;

5. Ensuring reports are supportable, accurate, and candid;

6. Providing adequate resources to correct identified problems;

7. Implementing corrective actions timely; and

8. Validating outcomes.


**1.4.13.4.3** **(03-13-2023)**

#### Internal Controls Managerial Assessment

1. The Internal Controls Managerial Assessment (ICMA) focuses on the adequacy of internal controls within each organization. Managers assess risks (i.e., the probability of a negative, unanticipated occurrence) of operations, determine if controls mitigate those risks, and certify those controls are effective. If not, managers will identify significant deficiencies found in the internal control procedures. See IRM 1.4.2.5, Annual Assurance Review Process, for more information.

2. All managers conduct an annual self-assessment whereby they must review the effectiveness of controls within their own area of responsibility. Managers document these self-assessments by completing individual online ICMA assessments.

3. Managers generally receive personalized links for the ICMA assessment from the Chief Financial Officer , but those who do not are provided “open links” by the TAS Annual Assurance Review Program Leader in Business Assessment. In addition to the questions all IRS managers are required to answer as part of the online assessment, TAS managers answer TAS-specific questions to ensure that all necessary controls are addressed.

4. The Statement of Assurance memorandum, which is drafted by Business Assessment for review and approval by the National Taxpayer Advocate, is a certification containing a specific statement on the status of TAS’s internal controls.

5. Corrective action plans for newly identified significant deficiencies should be included with the assurance memorandum (see IRM 1.4.2.4.6, Document, Report, and Correct Internal Control Weaknesses).

6. See the Annual Assurance Reviews site for additional information.


**1.4.13.4.4** **(07-16-2021)**

#### Internal Control Resources

1. The following statutes and regulations are the most significant authorities that affect the management controls program at the IRS:



01. Federal Managers' Financial Integrity Act (FMFIA) of 1982;

02. Federal Financial Management Improvement Act of 1996;

03. Chief Financial Officers Act of 1990;

04. [OMB Circular A-123](https://obamawhitehouse.archives.gov/omb/circulars_default/), Management Accountability and Control;

05. [Treasury Directive 40-04](https://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td40-04.aspx), Treasury Internal Control Program;

06. Inspector General Act of 1978, as amended;

07. [Standards for Internal Control in the Federal Government](https://www.gao.gov/greenbook/overview);

08. Government Performance and Results Act (GPRA) Modernization Act of 2010;

09. IRM 1.4.32, Internal Control Review Program;

10. IRM 1.4.3, Financial Assurance Control Testing;

11. IRM 1.5.1, Managing Statistics in a Balanced Measurement System, The IRS Balanced Performance Measurement System; and

12. IRM 13.5.1, TAS Balanced Performance Measurement System.


**1.4.13.4.5** **(11-29-2023)**

#### Manual Refunds

1. The purpose of issuing a manual refund is to provide the taxpayer quick access to overpayments and credits. See IRM 21.4.4.3, Why Would a Manual Refund be Needed?, for details about when a manual refund may be necessary. A manual refund is not generated through normal computer processing. It requires special preparation to allow the refund's release under unusual circumstances. This preparation includes suppressing the normal computer processes that automatically refund overpayments, to prevent the taxpayer from receiving two refunds for the same overpayment. Management is responsible for ensuring all actions are taken to avoid the issuance of a duplicate erroneous refund.

2. Initiators of manual refunds are required to research for potential duplicate refunds. See IRM 21.4.4.5, Preparation of Manual Refund Forms.



1. In situations where documentation of the taxpayer’s hardship cannot be obtained, initiators of manual refunds should have a discussion with the LTA. The LTA can substitute a signed statement which must contain a description of the hardship and the actions taken to verify the hardship. See IRM 3.17.79.3.3(2), Issuing Hardship Refunds.


3. Only LTAs (or LTAs acting 60 days or more) may approve manual refunds.



1. LTAs (or LTAs acting 60 days or more) must have a designation on file in the Campus Branch to approve a manual refund. See IRM 3.17.79.3.5, Employees Authorized to Sign Requests for Refunds.

2. LTAs approving manual refunds automatically have their Integrated Data Retrieval System (IDRS) profile restricted. See IRM 10.8.34.5.2, Access Control.

3. LTAs must verify that proper research was conducted. This includes, but is not limited to, consideration of statute expiration dates.

4. LTAs must ensure the manual refund is within TAS’s authorities (see IRM 13.1.4, TAS Authorities) and the circumstances of the case warrant such action. Make an Account Technical Advisor (ATA) referral if you have questions or issues. See IRM 13.1.12.2.2 , Requesting Assistance from Technical Advisors.

5. Before the LTA approves the manual refund request, the LTA will ensure it is appropriately reviewed. If an LTA in another office approved and signed the manual refund, the initiator’s manager is still responsible for this review. See _IRM 1.4.13.9.5.4.6_, Manual Refund Reviews, for details on how to conduct a manual refund review.


4. In the event an erroneous and duplicate manual refunds occurs, LTAs will follow the procedures found in IRM 21.4.5, Erroneous Refunds.

5. Area Offices are responsible for conducting Area Analyst MR Reviews and reviews of MR processing during Operational Reviews. See _IRM 1.4.13.9.5.4.6_(5), Manual Refund Reviews.


**1.4.13.4.5.1** **(11-29-2023)**

##### Manual Refund Training

1. TAS employees involved in initiating, reviewing, and signing manual refunds must complete the most recent manual refund training courses available via Integrated Talent Management (ITM) as identified below:




| ITM Course Number and Name: | Required for: |
| --- | --- |
| Course 30914, Manual Refunds | All employees that initiate, review, and sign manual refunds are required to complete the most recent training available.<br> <br>### Note:<br>An employee can take Course 30914a instead of Course 30914 if the employee completed Course 30914 in the previous year. This substitution does not apply if there is a change to Course 30914 in the current year or if there is a gap between years when the employee took Course 30914 or Course 30914a. |

2. All training must be completed annually within the period of **January 1 to February 1** or **prior to** being assigned Integrated Data Retrieval System (IDRS) command code (CC) RFUND or a manual refund profile restriction (RSTRK (M)).

3. **Timely** completion of all training is required. IDRS Unit Security Representatives (USRs) will remove CC RFUND from the IDRS profile of any employee who fails to timely complete the required annual training.

4. Documentation of **all** training must be maintained, available for review by internal and external stakeholders and recorded in ITM.


**1.4.13.4.6** **(07-16-2021)**

#### Payment Processing

1. Generally, TAS does not accept non-cash remittances. However, if TAS mistakenly receives non-cash remittances, refer to IRM 21.1.7.9.20, Discovered Remittance, and IRM 3.8.46, Discovered Remittance. Guidance on remittance issues change frequently and an awareness of procedures for remittance allows TAS to accurately and timely assist taxpayers. Keep in mind:



1. TAS cannot accept cash payments. Instead, TAS should refer the taxpayer to the local Taxpayer Assistance Center for payment processing. See IRM 21.3.4.7, Remittance Processing, for additional information.

2. Procedures are in place to ensure non-cash remittances are handled appropriately and timely within one day.

3. Form 3244, Payment Posting Voucher, is prepared for all remittances.

4. Form 3210, Document Transmittal, is used to send payments to the Campus for posting.

5. If a critical error is observed by the Teller, the manager will be informed via e-Trak. See IRM 3.8.47.7.1, Critical Errors.


**1.4.13.4.7** **(03-13-2023)**

#### Return Processing

1. Situations in which TAS employees should accept an unprocessed original or amended return are extremely rare. If TAS receives a return that is time-sensitive (e.g., received on the due date for filing or on the last day a taxpayer can claim a refund), and it is not possible to get the original document to the appropriate campus that same day, then TAS may accept the return for processing. **A hardship alone is not reason to accept an original or amended tax return.** For additional guidance on receiving original returns refer to IRM 13.1.18.8.3, Taxpayers Delivering Returns to TAS and TAS Date Stamp.

2. See also IRM 13.1.24.6.2, Advocating for Taxpayers Seeking Offset Bypass Refunds.


**1.4.13.4.8** **(03-13-2023)**

#### IDRS

1. IDRS accesses Master File account information using IDRS Command Codes (CCs). Through wide-area networks, IDRS accesses:



   - Corporate Files On-line (CFOL);

   - Files residing at the computing centers; and

   - Taxpayer Information Files (TIF).


2. IDRS provides the means to:



   - Take control of and take action on cases. For more information on creating, modifying, and closing IDRS control bases, see IRM 13.1.16.8(5) and (6), Sources of TAS Cases and Initial Intake Actions, IRM 13.1.18.5(5), Initial Actions, and IRM 13.1.21.2.1(3), Closing Actions.

   - Request and receive printouts of modules.

   - Research accounts.

   - Research or extract from Master File tapes.


**1.4.13.4.8.1** **(06-15-2023)**

##### IDRS Security

1. It is the policy of the IRS to protect its information resources and allow the use, access, and disclosure of information in accordance with applicable laws, policies, federal regulations, Office of Management and Budget (OMB) Circulars, Treasury Directives, National Institute of Standards and Technology Publications, and other regulatory guidance. All Information Technology (IT) resources belonging to, or used by the IRS, shall be protected at a level commensurate with the risk and magnitude of harm that could result from loss, misuse, or unauthorized access to that IT resource.

2. The IDRS Security System provides protection for both taxpayers and the employee use. Taxpayers must be protected from:



   - Unauthorized disclosures of account information;

   - Unauthorized changes of account information; and

   - Unauthorized accesses (UNAX) to account information.


3. IDRS allows users to sign-off the system using the F12 function key, then Page Up or XMIT. A user, with an open IDRS session, who is inactive for 120 minutes is systemically signed off of IDRS. A screen message notifies the user that they are signed off IDRS. Users with systemic sign-off may sign back onto IDRS.



1. A user who wants to prevent a systemic sign-off may return to IDRS, clear the IDRS screen, and press the transmit key to restart the 120 minute count down.

2. A user who expects to be away from their workstation for less than 120 minutes may either sign-off IDRS and remove their SMART ID card to lock their computer or remove their SMART ID card to lock their computer.

3. A user who expects to be away from their workstation for 120 minutes or more must sign off IDRS and remove their SMART ID card to lock their computer.

4. The IDRS security system provides a report with the monthly count of IDRS systemic user sign-offs.

5. Managers are required to advise users, with 15 or more systemic sign-offs for the month, of the need to properly sign-off when away from their workstations.


4. TAS has Maximum Profile Authorization Files (MPAFs) for position groups that access IDRS. Each MPAF is based upon command codes consistent with each position group’s business needs and delegated authority to research and adjust a taxpayer’s account. See IRM 13.1.4, TAS Authorities. The TAS MPAFs are found in:



   - _Exhibit 1.4.13-4_, IDRS MPAF for Case Advocates (Including Lead Case Advocates);

   - _Exhibit 1.4.13-5_, IDRS MPAF for Intake Advocates (Including Lead Intake Advocates);

   - _Exhibit 1.4.13-6_, IDRS MPAF for Secretaries, Management Assistants, Program Analysts, Management Program Analysts, Tax Analysts, Systems Analysts, Case Advocacy Specialists, and Technical Advisors;

   - _Exhibit 1.4.13-7_, IDRS MPAF for Quality Analysts;

   - _Exhibit 1.4.13-8_, IDRS MPAF for TAS Managers;

   - _Exhibit 1.4.13-9_, Command Codes for IDRS Online Reviews of Account Adjustments;

   - _Exhibit 1.4.13-10_, Security Command Codes for Unit Security Representatives; and

   - _Exhibit 1.4.13-11_, Security Command Codes for Terminal Operators.


5. While TAS MPAFs specify which command codes may be granted to a user by profile type and position, these command codes should only be granted to a user with the delegated authority to use the command code and when the command code is needed to accomplish the user’s official duties. Managers with a business justification may approve temporary deviations from the default MPAFs described in _IRM 1.4.13.4.8.1.1_, Making Deviations from an IDRS MPAF.

6. TAS has defined the following profile types for TAS IDRS users:



### Note:



A user may have more than one profile type.






| Profile Type | Description of Profile Type | TAS Position(s) with a business reason to access IDRS that are typically assigned to the profile type | TAS MPAF typically assigned to the profile type |
| --- | --- | --- | --- |
| Full Access | User has research, sensitive, and adjustment CCs. Adjustment CCs allow the user to make changes to tax credits and entitles. Employees must have the delegated authority to take the action on IDRS and have a business reason to use the CCs. See IRM 13.1.4, TAS Authorities. | - Lead Case Advocates (LCAs);<br>     <br>   - Lead Intake Advocates (LIAs);<br>     <br>   - CAs; and<br>     <br>   - Intake Advocates (IAs). | - _Exhibit 1.4.13-4_; and<br>     <br>   - _Exhibit 1.4.13-5_. |
| Manager | User has manager security command and Unit Security Representative (USR) CCs. | - LTA;<br>     <br>   - TAGM; and<br>     <br>   - Other TAS Manager whose employees have access to IDRS | - _Exhibit 1.4.13-8_. |
| Research | User has research CCs and a business reason to research taxpayer accounts. Employees in this group do not have the delegated authority and/or business need for IDRS adjustment codes. TAS will use RSTRK Definer U (see IRM 10.8.34-11) to restrict employees with a Research profile to ensure CCs are not inadvertently added to employees with research profiles. | - Secretary;<br>     <br>   - Management Assistant;<br>     <br>   - Program Analyst;<br>     <br>   - Management Program Analyst;<br>     <br>   - Tax Analyst;<br>     <br>   - System Analyst;<br>     <br>   - Case Advocacy Specialists; and<br>     <br>   - Technical Advisor. | - _Exhibit 1.4.13-6_. |
| Research - Quality Review | User has research CCs and a business reason to research taxpayer accounts. Employees in this group are prohibited from having any command codes that could potentially change the outcome of a case review. TAS will use RSTRK Definer U (see IRM 10.8.34-11) to restrict employees with a Research - Quality Review profile to ensure CCs are not inadvertently added to employees with research profiles. | - Quality Analyst. | - _Exhibit 1.4.13-7_. |
| Reviewer | User has quality review CCs needed to conduct IDRS online reviews of account adjustments. See _IRM 1.4.13.9.5.4.16_. | - LTA;<br>     <br>   - TAGM;<br>     <br>   - Centralized Case Intake (CCI) Manager;<br>     <br>   - LIA; and<br>     <br>   - LCA. | - _Exhibit 1.4.13-9_. |
| USR | User has the CCs needed to complete USR responsibilities. _IRM 1.4.13.4.8.2_ | - Individuals with USR responsibilities. | - _Exhibit 1.4.13-10_. |
| Terminal Security Administrator (TSA) | User has the CCs needed to complete terminal security administration. | - Individuals with terminal security responsibilities. See IRM 10.8.34.2.2.10. | - _Exhibit 1.4.13-11_. |

7. TAS will use RSTRK Definer U (see IRM 10.8.34-11) to restrict employees with a Research Profile Type. For exceptions to the use of RSTRK Definer U for employees with a Research Profile Type, see _IRM 1.4.13.4.8.1.1_.

8. TAS will restrict IDRS profiles of LTAs approving manual refunds. See IRM 10.8.34-9.

9. TAS IDRS units and the multiple accesses authorized for them are as follows:



1. Groups 63100, 63110, 63200, 63300, 63400, 63500, 63600, 63700, 63800, 63850 and 63880 are Manager Units and read ANY for all campuses access.

2. Technical Analysis and Guidance (TAG), Executive Director Systemic Advocacy (EDSA), and Internal Technical Advisor Program (ITAP) groups read ANY for all campuses access for 63102, 63111 through 63113 and 63120 through 63125.

3. Any user with CC RFUND in their profile may have access to all of the five Submission Processing Campuses.

4. See _Exhibit 1.4.13-12_, IDRS Multiple Access Approval Table.



      ### Note:



      Managers must check new members of your groups profile for any SSN restrictions. (If any restrictions exist, managers must not add adjustment command codes to that user’s profile.





      ### Reminder:



      Managers must address changes to profiles as users change positions, either permanently or on detail.


**1.4.13.4.8.1.1** **(03-13-2023)**

###### Making Deviations from an IDRS MPAF and RSTRK Definer U

1. Managers with a business justification may approve temporary deviations from the default MPAFs described in _IRM 1.4.13.4.8.1 (6)_. However, managers cannot approve the inclusion of any IDRS CC that is not within the user’s delegated authority and _Exhibit 1.4.13-4_. The manager will track all approved deviations on the IDRS CC Deviation Tracking Sheet and provide a copy to their Deputy Executive Director Case Advocacy (DEDCA), DEDSA, or Director (if Headquarters) monthly.

2. Managers with a business justification may approve temporary deviations from the use of RSTRK Definer U for employees with a Research Profile Type (see _IRM 1.4.13.4.8.1 (7)_). However, managers cannot approve the inclusion of any IDRS CC that is not within the user’s delegated authority and _Exhibit 1.4.13-4_. The manager will track all approved deviations on the IDRS CC Deviation Tracking Sheet and provide a copy to their DEDCA, DEDSA, or Director (if Headquarters) monthly.

3. Managers will review all their approved deviations every 30 days and are responsible for ensuring the CC(s) are removed from the employee’s profile when the CC(s) is no longer needed.

4. Each month, the DEDCA, DEDSA, Director, or designee will compare the tracking sheet to the appropriate MPAF. The DEDCA, DEDSA, or Director will discuss any deviations, concerns, or issues with the manager. This process will also be reviewed during all Operational Reviews.


**1.4.13.4.8.2** **(11-29-2023)**

##### Authorized IDRS Access

1. You are permitted to access only those tax modules required to accomplish your official duties.

2. You may access another IRS employee’s account information (including TAS employees) the same as any other taxpayer when:



1. An inquiry is received in writing or by telephone or you are assigned a Taxpayer Advocate Management Information System (TAMIS) case, and

2. You do not know the employee.



      ### Caution:



      If you know the employee making the account inquiry, you must refer the inquiry/case to your manager. See IRM 13.1.17.2(6), Routing a TAS Case.


3. There are special procedures that you must follow to protect yourself and the" taxpayer employee." See IRM 10.5.5.3.4, Employee and Contractor UNAX Responsibilities.

4. If you receive an inquiry (telephone or written) or are assigned a case of an IRS employee (including TAS employees) and you do not know the employee, complete the authentication check, and work the inquiry or case following TAS procedures in IRM 13.1.16 or IRM 13.1.18. In addition:



|     |     |
| --- | --- |
| If | Then |
| You receive an inquiry (telephone or written) of an IRS employee (including TAS employees), you do not know the employee, and there is no open case on TAMIS | Complete a Form 11377-E, Taxpayer Data Access, for each access. |
| You receive an inquiry (telephone or written) of an IRS employee (including TAS employees), you do not know the employee, and you are assigned the open case on TAMIS | Complete a Form 11377-E, Taxpayer Data Access, for the initial access only. |
| You receive an inquiry (telephone or written) of an IRS employee (including TAS employees), you do not know the employee, and there is an open case on TAMIS, but you are not assigned the case | Complete a Form 11377-E, Taxpayer Data Access, for each access. |

5. If you receive an inquiry (telephone or written) or are assigned a case of an IRS employee (including TAS employees), and you do know the employee, refer the inquiry or case to your manager. If you accessed the employee’s account on IDRS, complete Form 11377-E to document the access.

6. All actions taken on IDRS, both authorized and unauthorized, are recorded for an audit trail of the user.


**1.4.13.4.8.3** **(03-13-2023)**

##### IDRS Retention Criteria

1. An account is retained on IDRS as long as activity exists as outlined in IRM 2.9.1.13, IDRS Module Retention Criteria for the TIF.

2. After three weeks with no activity, the account is removed from IDRS.


**1.4.13.4.8.4** **(03-13-2023)**

##### IDRS Message File

1. Use CC MESSG to display the information on the IDRS message file.

2. Campus Information System employees use the IDRS message file to alert users to problems with local IDRS files and to share pertinent information.

3. The information may pertain only to local systems or to problems experienced by all sites.

4. CC MESSG will route the user to their campus. If you want to view another campus, use CC MESSG and the campus location code (e.g., MESSG@08).

5. Some campuses use the message file to issue IDRS bulletins or local decisions.

6. The file advises users of changes in IDRS letters. It also alerts sites to the volumes of special notices mailed to taxpayers that may cause an increase in taxpayer contacts.

7. The file may also show campus IDRS profiles, telephone numbers and PO Box listings.


**1.4.13.4.8.5** **(06-15-2023)**

##### Manager Responsibilities

1. TAS managers of IDRS users are responsible for day-to-day implementation and administration of IDRS security in their unit/group.

2. All TAS managers who have employees with access to IDRS will:



01. Review and certify profiles of users with sensitive command code combinations in a timely manner. If the USR is responsible for this action, the manager will ensure that the USR takes all required actions.

02. Review and certify users only have IDRS command codes based upon the user’s profile type. See _IRM 1.4.13.4.8.1 (6)_. If the USR is responsible for this action, the manager will ensure that the USR takes all required actions.

03. Ensure RSTRK Definer U (see IRM 10.8.34-11) is used to restrict employees with a Research or Research - Quality Review Profile Type.

04. Ensure that user profiles are locked when an employee is on leave, in non-duty status, or when the employee will not require IDRS access for 15 to 60 consecutive calendar days (in this case the profile shall be locked on the first day). If the USR is responsible for this action, the manager ensures that the USR takes all required actions.

05. Take prompt action to amend the employee access profile or remove the employee from IDRS if access is no longer needed, when an employee changes manager, assignments, or leaves the IRS.

06. Encourage employees to use the command code LOKME to lock their profiles when system access will not be needed for between three and 45 days. If the USR is responsible for this action, the manager ensures that the USR takes all required actions.

07. Ensure that primary and alternate USRs and IDRS users complete the required initial and annual refresher training.

08. Timely review and certify weekly and monthly IDRS Security Reports and confirm appropriate actions are taken to correct security violations or weaknesses. If the USR is responsible for this action, the manager will ensure that the USR takes all required actions.

09. Ensure that managers/USRs are not in the same IDRS unit as the users they oversee. Manager ensures that USRs have been appointed to cover all IDRS units.

10. Ensure that IDRS users, who meet the criteria for restricted profile types, have the appropriate restrictions added to their profiles. In addition, ensure that IDRS users who no longer have restricted roles have the restrictions removed from their profiles. If the USR is responsible for this action, the manager ensures that the USR takes all required actions.

11. Encourage the use of Password Management Capability by IDRS users. If the USR is responsible for this action, the manager ensures that the USR takes all required actions.

12. Advise users, with 15 or more systemic sign-offs for the month, of the need to properly sign-off when away from their workstations. See _IRM 1.4.13.4.8.1 (3)_.

13. Reinforce IDRS security through discussions at group meetings.

14. Periodically verify the accuracy and completeness of the IDRS Unit and USR Database for their office using the IDRS Unit &USR Database (IUUD).

15. Upon receipt of Form 11377 or Form 11377-E, sign and date the form, return a copy to the employee, and upload it along with any supporting documents within five business days of receipt to the Taxpayer Data Access Library. Managers will contact the TAS IDRS Online Reports Services (IORS) Point-of-Contact (POC) for assistance with using this process or gaining access to the library. See IRM 10.5.5.3.5.


3. Managers are responsible for the activities outlined in IRM 10.8.34.2.1.3, Manager.


**1.4.13.4.8.6** **(03-13-2023)**

##### Reviewers of IDRS Adjustments

01. IDRS Adjustment reviews ensure the integrity and accuracy of adjustments made to taxpayer accounts. This section deals with performing quality reviews of the following IDRS transactions: ADJ54, DRT24, DRT48, FRM34, FRM77 (except TCs 053, 136, 137, 122, 126, and 971 (Action Code 517 only), CHK64, BNCHG, INCHG, CHKCL, and LPAGE (except inputs without a TIN).

02. Reviewers will review:



    1. 100 percent of on-line transactions for each newly trained IA and CA; and

    2. 100 percent of all other on-line transactions for the IDRS group.


03. Typically, LTAs, TAGMs, and CCI Managers conduct reviews of IDRS Adjustments. These reviews may be delegated to LIAs and LCAs. An employee may not conduct a review of their own cases. If a manager delegates the review, the employee conducting the review briefs the manager and the employee involved.

04. Reviews will use the IDRS command codes in _Exhibit 1.4.13-8_ to review on-line adjustments. See IRM 2.4.5, Command Codes QRADD, QRADDO, QRNCH, QRNCHG, RVIEW, QRACN, and QRIND for the Quality Review System, for procedures for conducting reviews. Contact the IORS POC with questions or concerns.

05. Use CC QRADD to enter the employee numbers of employees you plan to review. Suspend all transactions input by your employee or group using CC QRADD or CC QRADDG for the same day. Transactions remain suspended for review for two days. After two days, all transaction not reviewed are released systemically for processing to the Master File.

06. When a new IDRS unit is created or reactivated, USRs must ask IDRS User Support at the following Campuses to add their IDRS unit numbers to the EOD02 data file. Adding the IDRS unit numbers to EOD 02 data file, instructs IDRS at each campus to automatically suspend transactions for review ("auto-select" ), alleviating the daily input of QRADD for each of these campuses. For adjustments at the campuses that do not use auto-select, reviewers must continue to input QRADD daily to suspend transactions for review.



    - Kansas City Campus (KCSC);

    - Atlanta Campus (ATSC);

    - Cincinnati Campus (CSC);

    - Memphis Campus (MSC); and

    - Philadelphia Campus (PSC).


07. Use CC QRIND with CC RVIEW to control workloads. CC QRIND requests a summary of a user’s transactions available for review for a specific day. Evaluate adherence to IDRS security and procedures.

08. Use CC RVIEW to review all transactions or selected transactions input by individual users. Input CC RVIEW within two days after a CC QRADD or a CC QRADDG request to review an adjustment.

09. Use CC QRACN to accept, reject, or review your employee’s transaction input screens, displayed by using CC RVIEW. Review the displayed transaction for quality and appropriate documentation requirements before using CC QRACN.



    1. Accepted transactions release to the Master Files for processing after the standard two-day hold.

    2. Rejected transactions change from IDRS status "AP" to "DQ" for following work day. The reviewer must print the action after rejecting the transaction. Send these prints back to the employee for corrective action.


10. See _IRM 1.4.13.9.5.4.16_, IDRS Online Reviews, for the focus of the review.


**1.4.13.4.8.7** **(06-15-2023)**

##### Unit Security Representative Responsibilities

1. The USR is an individual who implements and administers IDRS security at the IDRS unit level. TAS will appoint primary USRs in accordance with IRM 10.8.34.2.2.8, Unit Security Representative (USR).

2. TAS shall appoint alternate USRs in accordance with IRM 10.8.34.2.2.9, Alternate USR, to assist and/or perform the duties of the primary USR when that individual is not available.

3. Temporary USR and alternate USR appointments for employees on detail assignments not less than 120 days may be made in accordance with IRM 10.8.34.2.2.8 and IRM 10.8.34.2.2.9.

4. TAS USRs are responsible for



1. Reviewing IORS reports for their IDRS unit in accordance with IRM 10.8.34.2.2.11.1, IORS Primary Report Reviewer, IRM 10.8.34.5.3.1.1, IDRS Online Reports Services (IORS), and IRM 10.8.34.5.3.1.2, Review and Certification of Security Reports in IORS.

2. Ensuring new and returning users in their IDRS units receive an IDRS security awareness briefing prior to accessing IDRS. See IRM 10.8.34.4.1.1.1, IDRS User Security Awareness Training.

3. Ensuring users in their IDRS units receive periodic (at a minimum annual) IDRS security awareness briefings. See IRM 10.8.34.4.1.1.1.

4. Ensuring managers of their IDRS units are fully aware of their IDRS security responsibilities as outlined in IRM 10.8.34.2.1.3.

5. Completing the required initial and annual refresher training. See IRM 10.8.34.4.1.2.5, Unit Security Representative (USR) and Alternate USR Training.

6. Monitoring the command code usage of employees with sensitive command code combinations in their profiles. See IRM 10.8.34.5.2.1.6.6, Sensitive Command Codes and Sensitive Command Code Combinations.

7. Ensuring IDRS profiles of LTAs approving manual refunds are restricted. See IRM 10.8.34.5.2.

8. Using RSTRK Definer U (see IRM 10.8.34-11) to restrict employees with a Research or Research - Quality Review Profile Type. See _IRM 1.4.13.4.8.1 (6)_.


**1.4.13.4.8.8** **(09-04-2024)**

##### Terminal Security Administrator

1. The TSA is an individual assigned by TAS to unlock IDRS terminals and unlock employee profiles locked due to 17 consecutive days of inactivity.

2. The intent of the TSA role is to reduce USR workload.

3. TSAs may either be a non-bargaining unit (NBU) or bargaining unit (BU) employee.

4. A TSA designation will be approved by a TAS DEDCA or TAS Director. The IDRS Security TAS POC will be submitted to the IDRS Security Account Administration staff on Form 13230, IDRS Security Personnel Designation Form. Before submission, IDRS Security TAS POC will notify the unit’s primary USR of the TSA designation so that the USR is aware of who is being given security command codes.

5. The TSA’s manager shall submit a Business Entitlement Access Request System (BEARS) modify user request to the IDRS Security Account Administrator to have the appropriate security command codes added to the TAS’s IDRS employee profile. See _Exhibit 1.4.13-10_, Security Command Codes for Terminal Security Administrators. The BEARS modify user request must be approved by the TSA’s primary USR.

6. The primary USR is required to instruct the TSA on the duties of this position.

7. Command code SECOP is to be placed in the user profile of TSA. SECOP is the command code used to unlock IDRS terminals. At the request of the manager, TSAs may also be given command code UNLEM. UNLEM is the command code used by a TSA to unlock an employee profile that has been locked by the system because the user has been inactive for 17 days.

8. When a TSA is given the capability to unlock employee profiles, USRs are authorized to provide a copy of the "Master Register of Active Users" report or a command code SFINQA screen print to the TSA that lists the IDRS employee numbers of users in their unit(s). TSAs are only authorized to unlock IDRS profiles for new users.

9. For IDRS security purposes, the TSA’s security activity is under the purview of the designated primary USR(s) for that unit or area. If the primary USR has concerns regarding the security actions taken by the TSA, the primary USR may request an IDRS Security Analyst provide an audit trail extract of the TSA activities for a designated date or date range.


**1.4.13.4.8.9** **(06-15-2023)**

##### TAS IORS POC Responsibilities

1. The TAS IORS POC ensures TAS effectively performs IDRS security administration and monitoring. The TAS IORS POC shall:



01. Coordinate TAS’s response to IORS security report certification related issues.

02. Work with USRs and Managers to ensure compliance with the review and certification of IORS reports.

03. Participate in Operational Reviews to train Area Analysts on how to conduct a review of IDRS security. See _IRM 1.4.13.9.5.3_.

04. Perform quarterly testing of compliance with the TAS MPAF restrictions on IDRS users based on Profile Types. See _IRM 1.4.13.4.8.1_.

05. Represent TAS at IDRS Security related stakeholder meetings.

06. Conduct an annual review of the TAS MPAFs to ensure CCs are consistent with business needs. TAS MPAFs are located at: _Exhibit 1.4.13-4_, _Exhibit 1.4.13-5_, _Exhibit 1.4.13-6_, _Exhibit 1.4.13-7_, _Exhibit 1.4.13-8_, _Exhibit 1.4.13-9_, _Exhibit 1.4.13-10_, and _Exhibit 1.4.13-11_.

07. Obtain the approval of the Executive Director Case Advocacy (EDCA) prior to making any changes to the MPAF.

08. Conduct routine testing of IDRS adjustment reviews to ensure reviews are completed as intended. See _IRM 1.4.13.9.5.4.16_.

09. Identify training needs for TAS IDRS users, managers, USRs, reviewers of IDRS adjustments, and TSAs.

10. Prepares and implements the annual IDRS training plan to ensure users, managers, reviews of IDRS adjustments, TSAs, and USRs complete initial and annual refresher training (as required), security awareness, understand TAS profile types and restrictions for TAS employees with a Research Profile Type, responsibilities, and other training as identified.

11. Serves as the TAS POC for questions concerning the use and processing of Form 11377-E. See IRM 10.5.5.3.5.


2. See IRM 10.8.34.2.2.5, IDRS Security Account Administrator, and IRM 10.8.34.5.3.1, IDRS Security Reports, for additional information.


**1.4.13.4.8.10** **(03-13-2023)**

##### TAS IDRS Business Unit POC Responsibilities

1. The TAS IDRS Business Unit POC ensures TAS effectively performs IDRS security administration and monitoring. The TAS IORS POC shall:



1. Serve as the TAS POC with the IDRS Security Program Management Office.

2. Serve as a liaison between the IDRS Security Program Management Office and TAS in addressing IDRS security issues.

3. Coordinate TAS’s response to IDRS security related issues.

4. Represent TAS at IDRS Security related stakeholder meetings.

5. Works with TAS managers and the TAS IORS POC to identify trends or potential IDRS misuse. See IRM 10.8.34.5.3.2, Audit Trails.


2. See IRM 10.8.34.2.2.2, IDRS Security Business Division Point-of-Contact, for additional information.


**1.4.13.4.9** **(06-15-2023)**

#### TAS Systems Access

1. Managers are responsible for ensuring employees are provided with systems access to meet business needs, that employees follow the rules pertaining to the use of systems, and timely notifying the system administrators when access is no longer needed. The following tools are available for assistance:



1. IRM 10.8.1, Policy and Guidance;

2. IRM 10.8.2, IT Security Roles and Responsibilities;

3. Advocacy Tools; and

4. TAS Technology Hub.


2. Managers must ensure that employees have access to IRS internal or external computer systems containing taxpayer information only necessary to complete their IRS officially assigned duties. See IRM 10.5.5.3.2, Manager UNAX Responsibilities.

3. Employees may complete Form 11377, Taxpayer Data Access, or Form 11377-E by close of business on the day of the access and forward the signed copy to their manager to document certain inadvertent accesses. See IRM 10.5.5.3.4, Employee and Contractor UNAX Responsibilities.


**1.4.13.4.9.1** **(03-13-2023)**

##### TAMIS

1. TAMIS is a database dedicated to the recordation, control, and processing of TAS taxpayer cases. It is also used to capture and analyze core tax issues, laws, policies, and internal IRS functional processes that cause taxpayer burden and impact taxpayer rights.

2. Managers are responsible for ensuring:



1. All TAS personnel designated to use TAMIS receive TAMIS training;

2. All TAS personnel designated to use TAMIS understand the hazards of UNAX;

3. Evaluative employee performance comments are **not** documented within TAMIS histories;

4. Procedures are in place to ensure all required TAMIS data entries and coding are accurate, e.g., Primary Core Issue Codes (PCIC), special case, relief, and criteria codes.

5. Procedures are in place conform with document retention per Document 12990, Records and Information Management Records Control Schedules, and the TAS Managers Handbook.

6. Procedures are adhered to when (in the rare event) a case must be deleted from TAMIS. See IRM 13.4.2.8, Deleting Cases.

7. Actions are documented on TAMIS as cases are worked. If TAMIS is down, histories are documented as soon as TAMIS becomes available. See the TAMIS User Guide.

8. To establish a profile for a new TAMIS user, see IRM 13.4.2.5.1, Obtaining a Login and Password for TAMIS.


3. Generally, employees are assigned one of the TAMIS permission levels as follows:



|     |     |
| --- | --- |
| Permission Level | Position Assigned to Permission Level |
| 0 | General |
| 1 | Intake or Case Advocate Limited, Quality Review Analyst, Headquarters Analyst, EDCA-ITS Directors, and EDCA level support (Technical Advisors, Assistants, Executive Assistants) |
| 2 | IA, CA, Local Office Analyst, Secretary |
| 3 | Taxpayer Advocate Group Manager (TAGM), LCA, LIA, EDCA Area Analyst, EDSA, ITAP Technical Advisor |
| 4 | LTAs, EDCA, Assistant Executive Director of Case Advocacy, DEDCA, EDCA-ITS Managers |
| 5 | National Office Headquarters Employees (Business Systems Planning and EDCA-ITS) designated as Super Users (Limited to 4) |

4. Employees assigned to TAMIS Organization Code 00 will be granted TAMIS permission level 1 unless the employee:



1. Performs TAMIS Administration duties requiring permission level 4;

2. Is assigned duties, e.g., the Taxpayer Assistance Order (TAO) database, where permission level 4 is necessary to perform such duties; or

3. Is identified as a TAMIS super-user (TAMIS permission level 5).


5. See the TAMIS User Guide for additional information.


**1.4.13.4.9.1.1** **(07-16-2021)**

###### Making Deviations from a TAMIS Permission Level

1. LTAs with a business justification may approve temporary deviations from the default TAMIS Permission Levels described in IRM 1.4.13.4.9.1(3). The LTA will track all approved deviations on the TAMIS Permission Level tracking sheet and provide a copy to the assigned area analyst monthly.

2. The LTAs will review all their approved deviations every 30 days and are responsible for ensuring employees are converted back when the increased permission level is no longer needed.

3. Each month, area analysts will compare the LTA tracking sheet to the TAMIS Permission Level and 30 Day Audit Log report published to Business Objects Enterprise (BOE). The area analyst will elevate deviations, concerns, or issues to the DEDCA, who will discuss these issues with the LTA. This process will also be reviewed during all Operational Reviews.

4. TAMIS users not reporting to an LTA, such as ITAP and Systemic Advocacy employees will follow the same process. The TAMIS Coordinator will fulfill the role of the LTA, and a designated senior manager within the organization will fulfill the role of the DEDCA. This process will also be reviewed during all Operational Reviews.


**1.4.13.4.9.2** **(07-16-2021)**

##### Systemic Advocacy Management System (SAMS)

1. Systemic Advocacy receives issue submissions from TAS advocates, other IRS employees, the public, and other external stakeholders through an automated system called the SAMS for review, analysis, and potential development as projects. SAMS gives TAS a way to create, work, and monitor these projects. SAMS is available to employees on the TAS intranet at http://samsii.web.irs.gov/ and to the public at www.irs.gov/sams. TAS employees should always use the intranet site to submit a systemic issue for review.

2. Once TAS identifies a systemic issue in need of attention, Systemic Advocacy can work it as:



1. Information Gathering Projects (IGPs) identify emerging trends or issues generated from new legislation or significant IRS policy, process, or procedural changes;

2. Immediate Interventions are the result of an operational issue that causes immediate, significant harm to multiple taxpayers and demands an urgent response; and

3. Advocacy Projects identify and address systemic and procedural issues, analyze the underlying causes of problems, and propose corrective action.


3. Managers are responsible for ensuring all TAS personnel using SAMS are:



1. Properly trained;

2. Educated on the hazards of UNAX;

3. Educated on the importance of accurate coding; and

4. Educated on the importance of not entering individual taxpayer data on SAMS to protect taxpayers; instead, when referring to an individual case(s), the employee should enter the TAMIS case file number, see IRM 13.2.2.4, Security Rules.


4. See IRM 13.2.2.2, Systemic Advocacy Management System (SAMS), for additional information.


**1.4.13.4.10** **(03-13-2023)**

#### Clean Desk Policy

1. TAS managers will conduct a review to ensure employees are following the Clean Desk Policy. See IRM 1.4.6.3.18, Clean Desk Policy, for information on how to conduct a review.

2. Managers will conduct the reviews at least once a year.

3. Managers will conduct clean desk reviews on all TAS employees including those co-located in their office space.

4. Managers will document the completion of the review in a memo format and make the memo available to their immediate supervisor upon request. For co-located employees, the LTA (or other TAS manager) will document the completion of the review in a memo format for each employee and send the memo via secure email to the manager of the employee, when applicable.


**1.4.13.4.11** **(03-13-2023)**

#### Confidentiality of Tax Returns and Tax Return Information

1. All TAS managers must take an active role to prevent willful and attempted unauthorized access, and inspection of taxpayer information in electronic and paper form. This involves overseeing employees’ work as well as continually stressing the importance of protecting and securing taxpayer records.

2. Document 11500, IRS Manager’s Guide to Penalty Determinations, states managers may be subject to written reprimand, suspension, or removal for failure to adequately instruct, train, or supervise employees in their responsibilities for record and information protection.

3. All managers must:



01. Communicate with employees on a regular basis to ensure they are aware of UNAX prohibitions and penalties. Frequent communication also ensures employees know how to document and report inadvertent or unintentional access.

02. Be responsible for the timely and thorough review of available system security reports.

03. Report suspected UNAX violations or any unusual activity to Treasury Inspector General for Tax Administration (TIGTA) for investigation.

04. Monitor and ensure employees have access to IRS internal or external computer systems containing taxpayer information only when necessary to complete their IRS officially assigned duties.

05. Ensure employees who are being investigated for UNAX violations are promptly removed from IDRS and any other IRS computer system requiring administrative approval and containing taxpayer information. These employees must also be removed from other tax-related duties.

06. Ensure Form 11377, or Form 11377-E, Taxpayer Data Access, is forwarded to the designated head of office designee. Form 11377 or Form 11377-E is used to document accesses to taxpayer information not supported by direct case assignment or which may otherwise appear questionable. A manager’s signature on this form does not imply authorization for documented accesses. The access may still be subjected to further review and investigation.

07. Make timely reassignments whenever an employee reports having a covered relationship with an individual or organization in an assigned tax duty which may cause a conflict of interest. Form 4442, Inquiry Referral, is used by the employee to request such reassignments, thus avoiding a possible conflict of interest.

08. Educate employees to avoid UNAX violations, and assure employees know the potential consequences of their actions.

09. Lead by example.

10. Ensure their employees’ access of IRS internal or external computer systems are controlled through the BEARS approval process, granted only when required to complete official duties, and removed when no longer required to complete official duties.

11. Always refer questionable accesses to TIGTA.


**1.4.13.5** **(07-16-2021)**

### Hiring Employees

1. TAS continues to identify the organization’s most critical hiring needs and makes targeted hiring decisions. TAS’s hiring is made on a case-by-case basis. See the TAS Manager’s Handbook for specific direction when hiring employees.


**1.4.13.6** **(03-13-2023)**

### Assigning Work

1. Assigning work and assisting employees with inventory management is a key component of a manager’s duties. Generally, managers will determine work assignments for BU and NBU employees. Managers should not routinely delegate the duty of assigning work.

2. Every TAS department will document the procedure for assigning work within the office and have that document available for the Operational Review.

3. Per Document 11678, 2022 National Agreement – Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU), Article 16, an employee may spend up to 25 percent of their direct time during any four-month period, working higher graded cases or duties for developmental purposes.



### Caution:



If you allow an employee to work higher graded cases it is essential that you track the percentage of direct time spent on higher graded work to ensure the 25 percent threshold is not being exceeded. Employees who exceed the 25 percent level for the preceding four-month period may be entitled to a temporary promotion. Managers should consult with Labor Relations to discuss any questions concerning higher graded cases or duties. See _IRM 1.4.13.10_, Labor Relations.


**1.4.13.6.1** **(04-25-2024)**

#### TAS Case Assignment

1. Upon acceptance into the TAS program, cases are ready for assignment to advocates. If possible, assign cases to advocates no later than two workdays after the Taxpayer Advocate Received Date (TARD) for Criteria 1-4 cases and three workdays after the TARD for Criteria 5-9 cases.

2. Listed below are some items to consider when assigning case work:



1. Multiple issues;

2. Multiple TAS offices with more than one DEDCA involved;

3. Technical complexity (or difficulty of resolving case);

4. If the case involves issues like Offset Bypass Refunds or levy releases, that often need immediate action;

5. Sensitivity of the case ( _e.g._, Senate Finance Committee Cases, suicide, media impact);

6. Taxpayer’s primary language; and

7. On-the-job training needs.


3. Use the TAMIS Manager Inventory Screen to assign cases to a CA. See TAMIS User Guide for instructions on how to use the TAMIS Manager Inventory Screen.

4. Individual TAS offices will determine how cases are screened and assigned within their office. Managers will determine case assignment, but TAMIS actions to move cases into employee inventories may be taken by other staff. See IRM 13.1.16.15.3, Bulk Receipts, for additional information on bulk case receipts.

5. Elevation process for cases where the CA believes an IA accepted a case in error:



|     |     |
| --- | --- |
| If | Then |
| A CA receives a new case that they do not believe meets TAS case acceptance criteria | Elevate the case to the LTA. |
| The LTA agrees with the assessment that the case did not meet TAS case acceptance criteria | Elevate the case to the DEDCA. |
| The DEDCA agrees with the assessment that the case did not meet TAS case acceptance criteria | The DEDCA will refer examples of cases not meeting case acceptance criteria to the Director CCI to educate the IA. |
| The DEDCA or LTA determines the case did meet TAS case acceptance criteria | The DEDCA or LTA will discuss the case acceptance guidance with the CA. |





### Note:



The CA will not contact the IA directly to discuss case acceptance determinations.

6. To balance workload across the TAS organization, TAS uses a national workload balancing (N-WLB) system. For additional information, see IRM 13.1.22, Manual Inventory Balancing Procedures and TAS Zip Code Routing and Toll-Free Resources.

7. For case assignment pertaining to the Case Advocate Training Support (CATS) program, see _IRM 1.4.13.6.1.1_, CATS Case Assignment, and _IRM 1.4.13.6.1.2_, Case Assignments for CATS Trainees.


**1.4.13.6.1.1** **(11-12-2024)**

##### CATS Case Assignment

1. A Lead Case Advocate Training Specialist (LCATS) will carry an inventory to maintain expertise and technical knowledge. CATS Front-Line Managers (FLMs) will monitor LCATS inventory to ensure their LCATS have sufficient inventory to maintain expertise.

2. The CATS FLM will request cases through the CATS Analyst. The CATS FLM will provide the number of cases needed along with the PCICs.

3. The CATS Analyst will search TAS-wide inventories to identify unassigned cases with the PCICs requested by the CATS FML and use the transfer override function in TAMIS to move the cases to TAMIS Org. CT. The CATS Analyst will document TAMIS with the literal \*\*TRANSFER\*\*, see IRM 13.1.22.7.1, Exception on Time Requirements for Transferring a Case Received via the TAS AMS Centralized e-911 Inventory Using National Workload Balancing.



### Note:



Generally, existing cases where advocacy is already in progress and re-opened cases previously closed by a TAS local office will not be transferred to TAMIS Org. CT. However, cases previously worked and closed by LCATS in TAMIS Org. CT that require reopening will remain in TAMIS Org. CT to perform the additional case work. Deviation from any of these procedures will be at the concurrence of the EDCA or their designee and the CATS Director.

4. For cases transferred to TAMIS Org. CT, the CATS FLMs will balance assignments within their own teams with consultation from the CATS Director. FLMs will distribute the work to LCATS based on scheduling needs **(e.g.**, training, on-the-job instruction, coaching).

5. Cases received in TAMIS Org. CT will **NOT** be returned to originating local offices. Instead, CATS managers will reassign cases within TAMIS Org. CT based on the needs of the CATS organization.


**1.4.13.6.1.2** **(11-12-2024)**

##### Case Assignments for CATS Trainees

1. Management in the local TAS office will assign new cases for Case Advocates being trained by the CATS program in the local TAS office in which they reside. These cases **will not** be assigned to TAMIS Org. CT.

2. The types of cases assigned should be consistent with the training the Case Advocate is receiving. Managers will follow the Training Schedule and Case Assignment Guidance Table in the TAS Managers OJT Guide.

3. For new Case Advocates participating in the CATS program, update the TAMIS, Employee Screen, Office Symbol field to TA:CATS.



### Note:



Once the Case Advocate completes the CATS program, update the Office Symbol field to reflect the office symbols where the Case Advocate is assigned.

4. The LCATS working with these Case Advocates will ensure that all case coding in TAMIS, including the Office Symbol, is correct, as accurate case coding is an important skill that supports the validity of TAS data in the Reports to Congress and other TAS data reporting.

5. Once a Case Advocate completes the CATS program, their manager will determine the cases assigned to them. Managers will not limit case assignment to specific technical topics covered in FCAT, rather managers will assign cases that allow Case Advocates to apply the skills learned during FCAT. Managers will assign cases based on the business needs of Case Advocacy. See _IRM 1.4.13.6_, Assigning Work.


**1.4.13.6.2** **(07-16-2021)**

#### Systemic Advocacy Work Assignment

1. Systemic Advocacy managers are responsible for making the following work assignments:



1. **Advocacy Project** \- Once TAS determines it will accept an issue as a project, the manager will determine whether the project will have a single project leader or if the issue requires multiple resources, the manager will establish a team to address the issue. A team may include Analysts, LTA, Attorney Advisors, Technical Advisors, and Research Analysts.

2. **Internal Management Document (IMD) Reviews** – TAS receives IMD reviews through its mailbox \*TAS IMD SPOC. TAS IMD Single Point of Contact (SPOC) assigns these IMD reviews to subject matter experts (SMEs) using the IMD Center on SharePoint. See IRM 1.11.13.8.3, Assigning an IMD.

3. **Systemic Issue Review** – TAS receives potential systemic issues on SAMS. A level 1-2-3 review process is used by Systemic Issue Review and Evaluation (SIRE) to assign and work these issues to completion. See IRM 13.2.3.4.1, Processing Systemic Issues.


**1.4.13.7** **(06-15-2023)**

### Employee Development

1. TAS is committed to developing and maintaining a highly skilled workforce equipped to meet present and future challenges. Our primary responsibility, as a learning organization, is to develop TAS employees and help them succeed.

2. To assist managers and employees, TAS has many Training and Employee Development Initiatives that encourage continuous growth and learning for every career track in TAS.

3. See the TAS Manager Handbook, the Leadership Development and Support Office, IRS Coaching Resource Center, TAS Detail Opportunities, and Career Opportunities for additional information.


**1.4.13.8** **(03-13-2023)**

### Communication Skills

1. To be a successful TAS leader, managers must be able to communicate effectively with taxpayers, representatives, other stakeholders ( _e.g._, members of Congress), other TAS employees and managers, and IRS employees and managers across the organization.

2. The ability to project and hear messages has a major impact on how managers:



1. Evaluate and guide employees' performance;

2. Accomplish the goals of the organization; and

3. Serve customers.


3. See IRM 13.6.1, Internal and External Communications, for additional information.


**1.4.13.8.1** **(06-15-2023)**

#### Developing and Communicating Expectations

1. Management's challenge is to accomplish goals or objectives through the judicious use of resources. The major resource of TAS, as well as its greatest cost, is people. Employee productivity depends on management’s ability to develop people. Employees who are adequately trained and informed are motivated and better equipped to produce the best results. This can be accomplished by:



1. **Ensuring that employees know where to obtain guidance** \- Refer employees to the Internal Revenue Manual which serves as the single official compilation of policies, delegated authorities, procedures, instructions, and guidelines relating to the organization, functions, administration, and operations of the IRS. Managers should also refer employees to the Case Assistance by Issue Code (CABIC), Question Resolution Information System (QRIS) Library, Service Level Agreements (SLAs), Case Advocacy Technical Library (CATL), and other case advocacy tools.



      ### Note:



      Due to e-FOIA, TAS commitment to transparency, and the Taxpayer’s Right to Be Informed, TAS does not use or circulate locally developed job aids. The IRS decided that the Internal Revenue Manual (IRM) is the method the IRS will use to comply with e-FOIA to publish instructions to staff. The IRS and TAS also use published Interim Guidance Memorandum (IGM) if guidance to employees is needed before it can be incorporated into the IRM, or if the guidance is temporary. TAS employees should use IRM 13, Taxpayer Advocate Service, IRS functional IRMs, and the law as primary reference sources when conducting research. When TAS designs CABIC pages and publishes QRIS responses, we keep in mind that CABIC and QRIS are not published to irs.gov and should not contain instructions to staff subject to e-FOIA. CABIC pages and QRIS responses will generally not copy/paste content from the IRM into the body of a CABIC page or QRIS response, because we want employees to read the guidance directly from the primary source. Instead, CABIC and QRIS responses will point to the published IRM reference, Internal Revenue Code section, Regulation, etc. that covers that topic, so employees can conduct research and apply the published procedures to the facts and circumstances of the case.

2. **Guiding employees’ performance** \- Communicate expectations including the Retention Standard for the Fair and Equitable Treatment of Taxpayers; and the Responsibilities and Commitments; or Critical Job Elements (CJEs) and Performance Aspects. Provide clear guidelines and ensure employees understand your expectations for job performance. Reminder, expectations are set by the CJEs, Performance Aspects, Responsibilities and Commitments, and the Retention Standards, managers should not create a separate Expectations Memo. The Pay site provides guidance and suggestions for making effective Performance Plans for managers, management officials, and employees under CJEs. Another important Performance Management resource is IRM 6.430.1, Performance Management, Section 1, Introduction to Performance Management, which sets forth the policy and guidance for performance management within the IRS.

3. **Providing performance feedback**\- Continuously monitor employees’ progress against performance expectations, identify deficiencies, and initiate corrective actions. Managers will provide feedback during face-to-face conversations with the employee, except for those managers who are not physically-located in the same post of duty (POD) as the employee, in these instances, the manager will provide feedback via a phone call. Provide positive feedback as well as feedback on identified weaknesses. If the feedback is going to be used for evaluative purposes, the feedback must be documented in writing and must be provided within timeframes established by the negotiated agreement.

4. **Evaluating employees’ performance** \- Performance expectations (set at the beginning of the appraisal period) serve as the basis for the annual performance evaluation. The IRS Intranet provides specific guidance on Pay. Guidance can also be found in Document 11678, 2022 National Agreement – Internal Revenue Service (IRS) and NTEU, Article 12, Performance Appraisal System, and IRM 6.430.1.

5. **Using Career Learning Plans (CLPs)** \- Discuss realistic CLPs and help the employee assess and address any deficiencies. See Leadership Development and Support Office for more information.

6. **Sharing information** \- Provide employees as much information as possible regarding program direction, expectations, and business needs. Solicit from employees their career expectations and what they need from you to be successful in their position.

7. See IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to CJEs, and IRM 6.430.3, Performance Management Program for Evaluating Managers, Management Officials and Confidential Management/Program Analysts.


**1.4.13.8.2** **(06-15-2023)**

#### Distance Management – Working Effectively with Employees on Telework and Offsite Employees

1. The telework program gives employees the opportunity to work at home or at other approved locations remote to the assigned POD with an approved Telework Agreement. Information on telework can be found in the Document 11678 at Article 50, Telework, the IRS Telework Portal, and IRM 6.800.2, IRS Telework Program.

2. Managers are responsible for:



1. Reviewing, approving, or denying Form 11386, IRS Telework Agreement for Bargaining Unit (BU) or IRS Telework Agreement for Non-Bargaining Unit (NBU) Form 11386-B.

2. Ensuring that employees take all required Telework training and securely emailing the training certificate to \*TAS TW Portal Agreements (TAS.TW.Portal.Agreements@irs.gov).

3. Ensuring all Teleworking employees have an approved Telework Agreement in place and a copy of the agreement is filed in the employee drop file and securely emailed to \*TAS TW Portal Agreements (TAS.TW.Portal.Agreements@irs.gov). See _IRM 1.4.13.12.8.2_, Employee Drop File.

4. Ensuring the employee is on the appropriate type of telework (frequent, recurring, ad hoc) for their position, and that the Telework Type and Indicators are identified in the Single Entry Time Reporting (SETR) System is correct.

5. Ensuring that any updates to Telework agreements are sent to the TAS Telework Coordinator to update the Telework Database.

6. Ensuring HR Connect identifies that the employee is Telework Eligible.


3. Managers will meet with teleworking employees, except BU employees on ad hoc telework agreements at least annually, to discuss, review, and update the employee’s telework agreement, if needed. Managers will use the Telework Dashboard and a copy of each of your employee’s telework agreements to:



1. Confirm a telework agreement is on file.

2. Confirm completion of mandatory telework training in ITM.

3. Confirm that the Telework Eligibility Indicator is accurately set in HRConnect.

4. Verify that the SETR Telework Type Indicator aligns with the employee’s Telework Agreement.

5. Ensure the Telework Agreement type (such as recurring, frequent, etc.) aligns with telework hours being worked and recorded in SETR.

6. Confirm that the latest performance appraisal rating meets program requirements.

7. Confirm that the telework location has not changed and remains within 200 miles of the POD.

8. Ensure the employee’s duties have not changed, such as, the employee no longer meets the telework eligibility criteria.


4. With employees being managed remotely and others teleworking, the day-to-day dynamics of management and leadership have changed. The practice of "management by walking around" must be expanded to stay in contact with remotely managed and teleworking employees.

5. Employees who work telework should be accessible during their tour of duty. Communication may be done via Teams, email, or calling the employee at the telework location. If the employee does not respond to requests for managerial contact within a reasonable amount of time, the manager should contact their Labor Relations specialist to discuss the situation.

6. Managers must make an extra effort to ensure that remotely managed and teleworking employees are connected to their coworkers. Taking a few simple steps can ensure that employees remain in touch.



1. Managers should strive to keep their Teams indicator set to "Available" (green) as much as possible, to make it easy for employees to reach them. The goal is to make it as easy for someone to chat with the manager virtually as it is for someone physically located in the office.

2. Web-camera technology can enhance online communications. Adding a visual layer makes a substantial difference, especially when serving as a presenter or leader of a discussion.

3. Use screen shots and photos in documents when providing instructions or processing guides.

4. Take roll call at the beginning of group conference calls to acknowledge all members of the team; at the end, make it a point to ask each individual if they have anything more to add.

5. Hold regular staff meetings on Teams and use the virtual tools available to connect with all of the employees, not just those physically-located with the manager.

6. Use screen sharing functionality in Teams to work together on projects and documents.

7. Find ways to team-build during meetings and allow employees to get to know one another. For example, ask employees to come up with topics to help the team get to know each other better and ask for volunteers for each meeting. Topics could include favorite foods, vacation spots, movies, books, or even a discussion about their home state or town.

8. Encourage employees to give shout-outs to one another as a way to show employee appreciation and use the team meetings to emphasize this appreciation.


7. When managing remotely, managers should:



1. **Foster Trust** \- Trust starts with respect and empathy. If you’re interacting by phone you can’t see their faces or read their body language. Without the advantage of physical presence, you must trust peoples’ intent. So, early on, leaders should encourage team members to describe their backgrounds, the value they hope to add to the group, and the way they prefer to work.

2. **Encourage Open Dialogue** \- If you’ve established trust, you’ve set everyone up for open dialogue. When delivering negative feedback, use phrases like “I might suggest” and “Think about this.” When receiving such feedback, thank the person who offered it and confirm points of agreement. A tactic for conference calls is to designate one team member to act as the official advocate for candor—noticing and speaking up when something is being left unsaid and calling out criticism that’s not constructive. You should also recognize individuals for practices that improve team communication and collaboration.

3. **Emphasize Clear Communication** \- Communication on virtual teams is often less frequent, and always is less rich than face-to-face interaction, which provides more contextual cues and information about emotional states — such as engagement or lack thereof. The only way to avoid the pitfalls is to be extremely clear and disciplined about how the team will communicate. Establish norms of behavior when participating in virtual meetings, such as limiting background noise and side conversations, talking clearly and at a reasonable pace, listening attentively and not dominating the conversation, etc. Practice active listening. In addition, provide guidelines on when employees should reply via email versus calling on the phone.

4. **Host Regular Team Meetings** \- Ideally these should be on the same day and time each week. Establish and share meeting agendas in advance and implement clear communications during the meetings. Celebrate team and individual achievements. Emphasize that it isn’t okay to multi-task during calls.

5. **Create a “Virtual Water Cooler”** \- Create bonds within the team by engaging in virtual team-building exercises, create time for employees to discuss their day, or help the team get to know each other by setting time aside during each weekly meeting for team members to volunteer to discuss topics like their favorite food, vacation spot, or the place where they live.


8. The following resources provide additional information for working with offsite and telework employees:



1. IRS Telework Program;

2. IRM 6.800.2.3.1.3.2, Temporary Telework Arrangements Due to Hardship;

3. IRM 6.800.2.3.1.3.3, Telework and Reasonable Accommodation; and

4. IRM 6.800.2.3.1.4.2, Equipment and Furniture Requests.


**1.4.13.8.3** **(03-13-2023)**

#### Outreach

1. Every LTA office and other TAS functions required to conduct outreach are expected to develop and deliver plans outlining the activities identified to deliver a successful outreach program. The goal is for the LTAs to be known resources on tax issues within their communities.

2. TAS LTAs and managers of other TAS functions will assume primary responsibility for their outreach programs, including all personal interactions such as presentations, roundtable discussions, and personal visits. See TAS Outreach and Recruitment for additional information.


**1.4.13.9** **(03-13-2023)**

### Managerial Reviews

1. The most critical role of a manager is to constantly engage with our employees to ensure they have the skills and support necessary to do their job and provide top notch service to taxpayers and internal customers. It is not enough to conduct outreach and focus on quality scores. To best serve taxpayers, we need to focus on the quality of the advocacy efforts taking place within our offices, while teaching our employees how to be exceptional advocates.

2. Unless specifically noted otherwise, the procedures contained within IRM 1.4.13 and subsections apply to all TAS managers.

3. TAS gauges its advocacy efforts through ongoing reviews. Evaluative reviews are the building blocks for employee ratings. Non-evaluative reviews assist with coaching and ensure taxpayer and internal customer needs are met. These reviews form the basis of conversations managers and Leads will hold with employees. Front-line managers should work closely with their Leads to promote teaching and coaching, as these efforts can accelerate employee development through changes in how each employee approaches their work.

4. Coaching, mentoring, counseling, and training can improve employee skills and confidence, which positively impact advocacy, service, quality, and employee satisfaction. Manager’s conversations with employees also provide the opportunity to recognize exceptional work.

5. Simply completing the number of required reviews and documenting TAMIS or providing guidance electronically without this direct “face-to-face” engagement minimizes the value and purpose of our efforts. And relying on subordinate managers to conduct the reviews is not enough. It is essential that our reviews and discussions provide direction, recommendations, and actionable improvement opportunities. These ongoing conversations ensure that employees are continually aware of their performance and are not surprised by their mid-year or year-end evaluation.

6. Managerial oversight and follow-up at all levels of the management chain is necessary so employees know their leadership is invested in their development as we advocate for our taxpayers.

7. _IRM 1.4.13.9.5_, Reviews, provides Reviews that are designed to assist managers in meeting organizational goals and with developing employees.

8. Remember, evaluative recordation for BU employees must be furnished to an employee within fifteen (15) workdays of the time the supervisor becomes aware, or should have been aware, of the event which it addresses. If furnished after that time, it may not be used by the Employer to evaluate performance. Any material which may have an adverse effect on an employee’s appraisal, the maintenance of which is not required by the IRM, and which is not shared with the employee, shall be removed and destroyed.


**1.4.13.9.1** **(09-04-2024)**

#### Employee Engagement Lifecycle

1. While the items noted on the Engagement Lifecycle that follows are not intended to be all inclusive or necessarily accomplished in order, it provides the essential leadership building blocks for success. Engaging employees through discussions should strengthen relationships, build trust, and promote collaboration. Discussions help us identify barriers and agree on changes toward improvement. The Employee Engagement Lifecycle includes:



1. Year-Round Employee Engagement and Support;

2. Regular, On-going Individual Employee Coaching and Support;

3. Weekly employee and manager – Employee Support Debrief; and

4. Mid-Year Assessment and End of Year Evaluation.


**1.4.13.9.2** **(09-17-2019)**

#### Year-Round Employee Engagement and Support

1. Employee engagement is not an annual undertaking during only certain points in the year or after TAS has received an employee satisfaction survey score. Promoting engagement is a critical part of your role as a leader within TAS. TAS employees’ concerns should be addressed on an ongoing basis. TAS must be proactive with messaging and identify and address issues and concerns when presented.


**1.4.13.9.3** **(03-13-2023)**

#### Personalized Employee Coaching and Support

1. TAS must revisit and reaffirm the role of our LCAs and LIAs in employee development. Although they will continue to support advocates by responding to questions, the primary role of our LCAs and LIAs is to teach and develop our employees by regularly engaging each employee one-on-one in person to improve their skills.

2. LCAs and LIAs should schedule and conduct face-to-face conversations regularly, like an On-the-Job Instructor (OJI) process, but with weekly sessions instead of daily support. Non-evaluative Early Intervention Reviews (EIRs) and Advocacy Case Reviews (ACRs) should form the basis for a unique review and support strategy for each employee.

3. Managers will have discussions with newly hired CAs and IAs. These discussions will include the OJI assigned to the new hire. Initial conversations will:



1. Build rapport with the new employees and discuss what is expected during the OJI period.

2. Occur during the first week after the new hire reports to the team, if possible.

3. Clearly state the roles of the frontline manager, the OJI, and the new hire during the OJI period.

4. Provide the purpose and timeframe of when the new employee will start receiving non-evaluative information from the OJI.

5. Provide the purpose and timeframe of when the new employee will start receiving evaluative information from the manager. Generally, evaluative reviews start 60 days from the date the employee signs Form 6774, Receipt of Critical Job Elements and Retention Standard.


4. Using non-evaluative reviews as a starting point for discussions, TAS will provide personalized support as described in the Advocacy, Communication, and Employee Engagement (ACE) model:



1. **Case Review**. Reviews focus on Advocacy and Service. Consider the Focus Guide, and Operations Reviews. Reference employees’ unique strengths and opportunities for improvement.

2. **Face-to-Face (Telephone)**. Communicate case review findings (both positive and areas of improvement) on a regular, on-going basis.

3. **Discover Ways to Improve**. Engage and jointly identify new approaches to address advocacy and performance gaps identified during case review discussions. Provide tailored support.

4. **Follow Up and Confirm**. Validate and discuss impact of new approaches. Update approaches not having the desired effect. Celebrate Successes.


5. EIRs should generally be reserved for employees struggling with initial advocacy steps, including verbal communications with their taxpayers, research, and action plans. Conversely, if an employee has problems with decision making after the initial stages of the case, then the case review strategy might be more focused on the ACR. If the employee struggles with certain types of issues, i.e., collection cases, then reviews and support should focus on those case issues.

6. This personalized employee support is critical to recognizing advocacy opportunities unique to each employee and working with them individually to change advocacy approaches and enhance skills. When adopted throughout TAS, this will lead to organizational success. Each manager should continually reassess their operation and ensure the Leads are focusing on employee development. While managers must evaluate performance, they are expected to teach and support as well.

7. Employees and Leads will jointly discover ways to support growth and success from training, mentoring, coaching, and demonstration. Follow-up is critical to ensure the revised approaches are successful. Employee development is continuous throughout the year and is not just limited to the mid-year and year-end reviews.


**1.4.13.9.3.1** **(02-21-2024)**

##### New Hire Reviews During On-the-Job Training (OJT)

1. For all newly hired TAS employees (on board three (3) months or less), an OJI will generally perform reviews of work assigned to the new employee.



### Note:



ITAP managers will review the case referred to a newly hired Technical Advisor before it is returned to the CA.

2. Managers will conduct evaluative reviews, as required, through the OJT period. The TAS Manager Review Schedule is a listing of mandatory and discretionary reviews and provides the number of reviews TAS managers will complete each year by review type. See _Exhibit 1.4.13-3_, TAS Manager Review Schedule. Generally, when employees are in OJT, managers should focus more on a coaching role, therefore managers may decide based on good judgement, to limit the discretionary reviews during OJT.



|     |     |
| --- | --- |
| Reviewer | OJI |
| Delegate: | No |
| Evaluative: | No |
| Review of: | Work assigned to the employee during OJT. For example, an OJI for a:<br> <br>   - Technical Advisor may review TAMIS Case Referrals, IMD Reviews, CATL topics, SAMS submissions, Training Materials, and Presentations.<br>     <br>   - CA may conduct EIRs. See _IRM 1.4.13.9.5.4.5_, OAR Reviews, _IRM 1.4.13.9.5.4.12_, Pre-Closure Reviews, _IRM 1.4.13.9.5.4.17_, etc.<br>     <br>   - IA may conduct observations of the new employee's phone conversations with taxpayers.<br>     <br>     <br>     <br>     ### Note:<br>     <br>     <br>     <br>     This list is not all-inclusive. |
| Scope: | For all new hired employees (on board three months or less). |
| Written Documentation: | - Typically, these are coaching sessions. Document TAMIS with non-evaluative case guidance, if appropriate.<br>     <br>   - Lead Case Advocate Training Specialists (LCATS) will use the Case Advocate Skillset Observation Form to document all aspects of a new case advocate’s OJT. |
| TAMIS Literal: | \*\*ITNHR\*\* non-evaluative case guidance provided to newly hired Technical Advisors. |

3. Managers are not required to wait 60 days after the employee receives their CJEs or performance plan, finishes OJT, or is certified in an individual skill or skillset group ( _e.g._, general, accounts, examination, or collection) to issue evaluative performance documentation. They can issue this type of documentation at any time after the employee received their CJEs or performance plan.

4. Managers with employees participating in the OJI Cadre observe the OJI coaching other employees and include their observations as part of the employee’s performance review.


**1.4.13.9.3.2** **(03-13-2023)**

##### Detail Assignment Performance Review

1. The TAS Leadership Development Office created the Detail Assignment Feedback/Performance Review form and instructions to help managers provide assessments of employees on NBU detail assignments or temporary promotions to NBU positions.

2. Managers are required to use the Detail Assignment Feedback/Performance Review Form for all NBU detail assignments and prepare a monthly performance review of the detailee.


**1.4.13.9.4** **(09-17-2019)**

#### Weekly Employee Support Debrief

1. TAS must ensure our support of each employee hits the mark. LCAs and LIAs should check-in with managers weekly to review the support provided to each employee and any progress. This also allows for a discussion regarding the types of cases which can be assigned to the employee going forward to assist in their development.


**1.4.13.9.5** **(06-15-2023)**

#### Reviews

1. Efficient and effective employee job performance depends on timely direction. This direction encompasses continuous involvement, instruction, and evaluation of each employee's work. Positive feedback is essential to maintain and improve strengths and by being involved, managers can develop each employee's skills to improve job performance. Managers should refer to:



1. IRM 6.430.1, Introduction to Performance Management;

2. Pay Systems, Salary Tables, and Pay Administration;

3. iManage, Documenting Employee Performance;

4. Document 11678, 2022 National Agreement – Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU), Article 12, Performance Appraisal System;

5. Job Aid – Rating Employees on Temp Promotions IR to IR and GS to IR;

6. Job Aid – Rating Employees on Temporary Promotions IR to GS;

7. 2023 IR Conversion-out Charts;

8. IRS Payband System (IR); and

9. Departure Appraisal Guidance: Job Aid for Departures in HR Connect.


2. Managers may not delegate evaluative reviews. However, the manager or individual acting as manager may have a technical advisor manager, LCA, LIA, or analyst review aspects of the work and provide comments to the manager.

3. All TAS managers will refer to _Exhibit 1.4.13-3_, TAS Manager Review Schedule.


**1.4.13.9.5.1** **(03-13-2023)**

##### Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard

1. Sharing the performance plan with the employee timely is critical. Supervisors are required to get a Form 6774 signed at the beginning of each rating period. The supervisor’s assessment of an employee against their CJE performance plan serves as the basis for several actions, including within-grade increase, promotion, recognizing and rewarding the employee, determining employee development needs, helping the employee improve, resolving performance deficiencies, or taking performance actions on an employee who continues to perform at a less than "Fully Successful" level. For more information, see IRM 6.430.2.2, Step 1: Planning Expectations.

2. Managers are required to talk annually with employees about the behaviors that meet the retention standards. Retention Standard discussions helps employees understand their job responsibilities, communicates the importance of effectively engaging with customers, and demonstrates to stakeholders how we are ensuring the fair and equitable treatment of taxpayers. See IRM 6.430.2.2.5, Discussing the Retention Standard for the Fair and Equitable Treatment of Taxpayers.


**1.4.13.9.5.2** **(09-04-2024)**

##### Mid-Year Assessment, End-of-Year Evaluation, and Discussion

1. The mid-year assessment should be a measure of any improvement realized. It gives the manager additional time to provide non-evaluative support through the Leads, if applicable, and gives the employee additional opportunities to improve performance before the end of evaluative period. Mid-year reviews should provide specific meaningful narratives based on the work reviewed. It serves as an opportunity to recap performance discussions throughout the rating period, highlighting the positives as well and the areas for improvement, and to assess employee development, e.g., Career Learning Plans.

2. The end of year evaluation should be an honest assessment of the employee’s performance, based on reviews of work products, and considers TAS’s efforts to support the employee. Since managers are having ongoing discussions throughout the year, employees should not be surprised by what they read in their mid-year and end of year evaluations. The evaluation should reflect the feedback the manager has been giving the employee throughout the year.

3. All TAS managers will conduct mid-year assessments, end-of-year evaluations, and have on-going discussions with their employees.

4. These reviews may not be delegated; however, the manager, or individual acting in that positions may have a Lead, if applicable, review aspects of advocacy delivery and inventory management and provide input to the manager. Consider whether actions are timely. Identify accomplishments and opportunities for improvement. Update the CLP and discuss career planning leading to Leadership Succession Review (LSR).

5. General review process:



1. Schedule a face-to-face meeting between the manager and employee.

2. Summarize the results of the reviews you have already shared throughout the year.

3. Prepare and share a brief cover memo summarizing the results of the workload reviews and documenting accomplishments, advocacy efforts, progress made and any opportunities for improvement through the rating period. Include any updates to the CLP.


6. Document these discussions on the performance review tracking sheet maintained by the office, if applicable.

7. For reviews of CAs and LCAs, notate the TAMIS history with \*\*MER\*\* for CAs and LCAs. Document substantive non-evaluative direction.

8. The following resources provide additional information:



1. IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs);

2. IRM 6.430.3, Performance Management Program for Evaluating Managers, Management Officials and Confidential Management/Program Analysts;

3. IRM 6.430.5, Performance Appraisals for Temporary Assignments; and

4. Document 11948, Performance Appraisal Self-Assessment Tutorial.


**1.4.13.9.5.3** **(09-04-2024)**

##### Operational Reviews

1. This evaluative review of a subordinate manager and their organizational component tests the soundness of the operation in carrying out TAS’s mission of advocating for taxpayers, communicating with and engaging employees; or supporting that mission and initiative. It provides an opportunity to improve overall effectiveness of the group, operations, and identify best practices. Operational reviews also provide an assessment of the manager's performance, engagement, growth, and development. All TAS managers of subordinate managers will conduct an annual operational review of the subordinate operations. A targeted operational review may be conducted on specific items every other year. Deviations from this policy, when necessary, should be documented and approved by the first level executive.

2. Prior to conducting a review of a subordinate manager’s operation, there are several tasks that should be completed before meeting with leadership and employees of the group. Group performance reports and data should be generated in advance of the review. Review the group’s Federal Employee Viewpoint Survey (FEVS) results (if applicable), Labor Relation activity, and gauge overall employee engagement, support, and teamwork. It is also important to define the operation's primary challenges and areas of focus. If the review will be performed remotely, it may be prudent to perform other tasks, such as reviews of Employee Performance Files (EPFs), prior to meeting with group personnel.

3. The reviewer should assess how the group is performing and document that performance under each operational section in the draft report. Action items and/or recommendations should be documented when performance must be addressed. At the end of the report is a summary where all action items are recorded and target completion dates established.

4. Once the draft report is finalized and delivered, schedule a close-out meeting with the manager to discuss action items, concerns, and an overall assessment. Schedule a follow-up review, if warranted. The reviewing manager should also forward a copy of the report to their manager.

5. The operational review should be tailored to the specific needs of the unit being reviewed. Generally, the TAS Operational Review reports will contain the following information:



1. Introduction:




      | Section Name | Description |
      | --- | --- |
      | Participants | The reviewer will list the participants who contributed content to the operational review and job title. List in order of leadership hierarchy. |
      | Previous Operational Review Follow-up | The reviewer will address any remaining action items from the most recent operational review by securing a status update and completion date or projected completion date. |
      | Office/Group Challenges | Review should define the office/group’s primary challenges and areas of focus. |
      | Senior Manager/Director Summary | This section is not a repeat of findings in the report, rather it provides the reader with a broad overall indication of the group’s strengths and opportunities for improvement. The summary should include a person to contact if the group has questions or if further discussion is needed. It should provide a name to report status updates of action items requiring completion. The reviewer will:<br> <br>      - Summarize overall group operations and how leadership is fostering a culture of engagement and advocacy in the group.<br>        <br>      - Engage employees in one-on-one conversations in order to assess the level of employee engagement and overall environment in the group. It is a good practice to solicit participation from employees of different job titles, groups, etc. |

2. Leadership and Human Capital Management




      | Section Name | Description |
      | --- | --- |
      | Outstanding Issues Raised from National Taxpayer Advocate (NTA)/Deputy National Taxpayer Advocate (DNTA) Town Halls | The reviewer should list all issues raised by the employees of the group at the last NTA or DNTA town hall visit and explain how these issues were resolved. If there are unresolved issues, please provide an update of the action plan to address the issues. |
      | Performance Evaluations/Skillset Assessment & Development (for Leaders and Employees) - Leadership Development | The reviewer will:<br> <br>      - Review the training plan for all leaders in the group and ensure all training has been provided timely. Are there other developmental needs and opportunities?<br>        <br>      - Identify formal and informal mentors of group leaders. Discuss impact of support with manager being mentored.<br>        <br>      - Assess organizational leadership succession plan and review possible attrition, employees interested in leadership, etc. |
      | Performance Evaluations/Skillset Assessment & Development (for Leaders and Employees) - Mid-Year Evaluation and Skills Assessment - Discussions and Actions | The reviewer will review EPFs to determine the timeliness and quality of documentation and guidance from the evaluative reviews, see _IRM 1.4.13.9.5.2_, Mid-Year Assessment, End-of-Year Assessment, and Discussion. Consider meeting with employees to assess effectiveness and value of these discussions. |
      | Performance Evaluations/Skillset Assessment & Development (for Leaders and Employees) - End-of-Year Evaluation and Shills Assessment - Discussion and Actions | The reviewer will review EPFs to determine the timeliness and quality of documentation and guidance from the evaluative reviews, see _IRM 1.4.13.9.5.2_. Consider meeting with employees to assess effectiveness and value of these discussions. |
      | Performance Evaluations/Skillset Assessment & Development (for Leaders and Employees) - Reviews of subordinate managers (if applicable) | The reviewer will:<br> <br>      - Assess the quality of overall leadership by subordinate managers. Hold discussions with senior manager and examine operational reviews of manager’s group and appraisals. What challenges has the subordinate manager(s) faced and how has/have the manager(s) dealt with these challenges?<br>        <br>      - Ensure an Operational Review of the subordinate manager(s) was conducted and provided meaningful exchanges to sustain efficiencies, resolve deficiencies, and implement improvement initiatives. |
      | Performance Evaluations/Skillset Assessment & Development (for Leaders and Employees) - CLP | The reviewer will:<br> <br>      - Review EPFs to determine the timeliness and quality of the CLP documentation and guidance. Consider meeting with employees one-on-one to assess effectiveness and value of these discussions. Look for evidence of Frontline Leadership Readiness Program (FLRP) discussions with employees who have expressed interest in management.<br>        <br>      - Review CLPs and any meeting minutes/calendars that support the encouragement of employees to participate in the CLP and LSR processes, including any developmental opportunities sought and/or afforded employees. |
      | Performance Evaluations/Skillset Assessment & Development (for Leaders and Employees) - Leadership Succession Review | The reviewer will:<br> <br>      - Look for instances where an employee has interest in the LSR process. There should be evidence of follow through by management to ensure completion of the LSR contract.<br>        <br>      - Review the EPF and documented actions at mid-year and end-of-year to identify evidence of a discussion about LSR.<br>        <br>      - See the TAS Manager Handbook, Chapter 2G, Leadership Succession Review, for more information. |
      | Performance Evaluations/Skillset Assessment & Development (for Leaders and Employees) - Details and Special Assignments | The reviewer will:<br> <br>      - Look for instances where an employee has expressed an interest in details or special assignments. There should be evidence of follow through by management to document expectations and outcomes of these details and special assignments.<br>        <br>      - Review the EPF and documented actions at mid-year and end-of-year to identify evidence of a discussion about the details and special assignments. |
      | Customized Employee Engagement and Support - Non-evaluative review strategy for the group | The reviewer will:<br> <br>      - Ask the manager to describe their review strategy.<br>        <br>      - Ask the leadership team to describe their coaching and support strategy.<br>        <br>### Note:<br>Groups should be able to provide an overview of their non-evaluative review process and how their employees are supported. Groups should be able to provide examples of steps taken to support employee learning and growth. |
      | Customized Employee Engagement and Support - Regular face-to-face/verbal engagement and discussions | The reviewer will:<br> <br>      - Ask the manager to summarize their one-on-one engagement approach.<br>        <br>      - Conduct a review of scheduled dialogue with staff members to ensure meetings were conducted or timely rescheduled and that the topics covered included technical issues, work-life balance, and any issues elevated by participants.<br>        <br>### Note:<br>The group should be able to describe steps taken to ensure leadership holds regular one-on-one discussions with employees.<br>### Note:<br>Meeting minutes may provide insight into employee engagement. |
      | Customized Employee Engagement and Support - Impact on Employee Development | The reviewer will ask the managers to give example(s) of how their coaching and support strategy for employees, coupled with regular one-on-one engagement, has positively impacted employee development.<br> <br>### Note:<br>The group should provide example(s) of how they identified employee(s) who needed support in a specific skillset, and the approach taken to help them improve. |
      | Customized Employee Engagement and Support - Weekly Leadership strategy Sessions | The reviewer will:<br> <br>      - Ask if weekly meetings between managers and staff and employees (as applicable) are being held and ask leadership to summarize the outcomes from these meetings.<br>        <br>      - Look for evidence of changes to employee coaching, workload assignments, process changes, etc. |
      | Training for Employees and Leaders | The reviewer should:<br> <br>      - Validate that national training has been completed timely by all employees and managers.<br>        <br>      - Determine if the group has requested additional training.<br>        <br>      - Determine if the training has been developed and delivered since the last operational review.<br>        <br>      - Determine how training needs were identified, who delivered the training, and the impact of the training.<br>        <br>      - Determine the status of manager training and onboarding, include Leadership 360, LinkedIn Learning, self-development, etc. |
      | Summary of new hire and OJI program | The reviewer should:<br> <br>      - Describe the new-hire training delivered by OJIs.<br>        <br>      - Describe the roles of manager(s) and OJIs to ensure employees receive consistent and comprehensive OJT.<br>        <br>      - Determine if any employees received approval for extended OJT. If so, why was the training period extended?<br>        <br>      - Validate the manager’s completion of non-evaluative New Hire Reviews (when applicable). If developmental needs were identified, how are they being addressed?<br>        <br>      - Solicit feedback from the OJI regarding the coaching sessions with the new employee. Does the OJI have feedback regarding the overall OJT process, or any specific concerns?<br>        <br>      - Solicit feedback from the new employee(s) regarding the OJT process, and if they have any concerns. |
      | Continuous Employee Engagement | The reviewer will ensure manager commitments include an expectation that leaders will continue to develop relationships with employees and support others that are building relationships with employees. |
      | FEVS and elevation of employee recommendations | The reviewer should:<br> <br>      - Identify how leadership encourages participation in FEVS.<br>        <br>      - Describe how group leadership is identifying and addressing employee engagement and satisfaction opportunities, including those groups which have not received a FEVS report.<br>        <br>      - Secure examples where leaders solicited and addressed elevated issues on an ongoing basis. |
      | Development of relationships and trust with employees | The reviewer should:<br> <br>      - Determine if managers are participating in a scheduled one-on-one dialogue with each member of their staff.<br>        <br>      - Ask managers to share examples of progress in building relationships. |
      | Space Issues | The reviewer should:<br> <br>      - Interview persons with knowledge of space issues identified in the workspace, including remote workspace, occupied by the staff.<br>        <br>      - Interview managers to identify any security, safety, fire hazard concerns that exist in the space and determine if coordination with Financial Operations is needed. |
      | Staffing | The reviewer should:<br> <br>      - Review the TAS Directory, Employee Service Record Report (ESRR), or other staffing reports to identify the current staffing of the organization.<br>        <br>      - Discuss succession planning with the leadership.<br>        <br>      - Discuss attrition and hiring plans with leadership and assess whether they are sufficient. |
      | Reasonable Accommodations | The reviewer should:<br> <br>      - Identify where leadership has taken steps to work with employees who have requested accommodations.<br>        <br>      - Identify any outstanding reasonable accommodation requests and the status. |
      | Hardship Requests | The reviewer should:<br> <br>      - Identify where the group has received a hardship relocation request from an employee and document timely and accurate processing of the request.<br>        <br>      - Identify any outstanding reasonable accommodation requests and the status. |
      | NTEU Grievances and Communications | The reviewer should:<br> <br>      - Identify where grievances have been filed and document the timely processing of those grievances through resolution or invocation of arbitration.<br>        <br>      - Identify where regular meetings with NTEU have been held.<br>        <br>### Note:<br>Identify the grieved issue, not employee names. |

3. Customer Service and Collaboration - review of this topic will depend upon the work performed by the group. See the Operational Review template for specifics relating to this topic.




      | Section Name | Description |
      | --- | --- |
      | Customer Satisfaction | The reviewer should:<br> <br>      - Describe steps taken to improve products and services to enhance customer satisfaction. What has been the impact of these efforts?<br>        <br>      - Review the office’s business results metrics, if available, to identify areas of opportunity. |
      | Outreach | The reviewer should:<br> <br>      - Ensure outreach events for each office are completed according to the plan or as close as possible.<br>        <br>      - Ensure TAS departments without their own Outreach plan identify how their staff have assisted with the Outreach performed by other departments in TAS; such as their staff’s local LTA offices. |
      | Systemic Advocacy Activities and SAMS submissions | The reviewer should:<br> <br>      - Ask office leadership to describe efforts to identify systemic issues in casework. How do you raise awareness to your employees? What were the results?<br>        <br>      - Determine whether anyone in the office is engaging with Systemic Advocacy on any projects, Annual Report assignments, or other activities.<br>        <br>      - Determine how the office promotes the use of SAMS in both internal and external outreach events.<br>        <br>      - Generate a SAMS Issue Submission Report to identify issues submitted by the office.<br>        <br>      - Gauge whether the office is promoting effective use of SAMS on an ongoing basis.<br>        <br>      - Discuss with leadership how SAMS is being promoted in outreach events and efforts to educate employees on use and importance of SAMS.<br>        <br>### Note:<br>SAMS allows TAS to record and manage advocacy activities that benefit groups of taxpayers. TAS employees are in a unique position to identify systemic issues and may submit issues that affect a segment of taxpayers involving systems, processes, policies, procedures or legislation. Recognizing and submitting potential systemic issues is important to protecting taxpayer rights and reducing taxpayer burden. |
      | Contributions to National Initiatives | The reviewer should:<br> <br>      - Describe the office’s contributions to National initiatives or special projects; e.g., employees working on National teams, panels, task forces, etc.<br>        <br>      - Describe any trends in case advocacy observed and elevated to the National level.<br>        <br>      - Give examples of support provided to Headquarters (HQ), for example, employee is detailed to HQ, served as an instructor for Symposium, etc. |

4. Program Management - review of this topic will depend upon the work performed by the group. See the Operational Review template for specifics relating to this topic.




      | Section Name | Description |
      | --- | --- |
      | Work Assignment | The reviewer should secure the written procedures for how work is assigned within the department and confirm that work is assigned by a manager and not delegated to a non-management employee. |
      | Back-up Processes (employee leave, unscheduled absence) | The reviewer should:<br> <br>      - Describe the procedures for employees to request planned and unscheduled leave.<br>        <br>      - Describe the procedures to ensure the timely processing of work during employee leave and unexpected absences.<br>        <br>      - Secure written leave approval procedures, if any.<br>        <br>      - Access whether leave approval process is adequate and if there is sufficient office coverage. |
      | Use of data and reports | The reviewer should:<br> <br>      - Ask the manager to explain their approach to using reports and data as it relates to the performance of the operation.<br>        <br>      - Ask how they ensure proper balance between employee engagement, customer satisfaction, and business results.<br>        <br>      - Ask the manager to identify the current areas of focus for improvement.<br>        <br>      - Ask for the manager for two examples of how they identified specific areas of opportunity and what steps were taken to address these opportunities. |
      | Adherence to Reviews, see _IRM 1.4.13.9.5_, Reviews | The reviewer should:<br> <br>      - Determine which reviews are being completed.<br>        <br>      - Identify who is responsible for review oversight.<br>        <br>      - Identify the actions take to improve advocacy or operations as a result of the reviews. |
      | Internal Group Controls - Risk Assessment: FMFIA, see _IRM 1.4.13.4.1_, Federal Managers’ Financial Integrity Act. | The reviewer should validate that the group reviews the annual self-assessment document periodically to ensure controls are implemented and still in place. If deficiencies were identified in the last assessment, were they corrected? |
      | Internal Group Controls - Risk Assessment: Computer Security (including IDRS), see _IRM 1.4.13.4.8_, IDRS Responsibilities, _IRM 1.4.13.4.9_, TAS Systems Access, and _IRM 1.4.13.4.8_. | The reviewer should:<br> <br>      - Ask group representative to outline security policies and procedures for systems and data.<br>        <br>      - Determine if abandoned IDRS control reviews are conducted monthly and identify the steps taken to reduce the number of abandoned IDRS controls.<br>        <br>      - Review the progress made in reducing the number of abandoned IDRS controls and consider the impact of implemented improvement plans.<br>        <br>      - Review the summary of the monitoring process for the timely certification of IDRS security reports. What action is taken on potential issues identified? Are managers/USRs holding the required session on IDRS security and refreshed training?<br>        <br>      - Identify how the group reinforces employee awareness and compliance with UNAX rules.<br>        <br>      - Ensure all employees have cable locks for their computers.<br>        <br>      - Discuss with leadership the group security, policies, written procedures, and oversight, including Safeguarding Personally Identifiable Information Data Extracts.<br>        <br>      - Identify the IDRS USR. Verify how they use the IORS reports to identify potential UNAX violations and/or fraud.<br>        <br>      - Review a statistically-valid sample of cases to verify appropriate reviews of IDRS adjustments are conducted and properly documented (see _IRM 1.4.13.9.5.4.16_, IDRS Online Reviews).<br>        <br>      - Verify procedures for Form 11377-E are being followed timely. |
      | Internal Group Controls - Risk Assessment: Continuity Plan, see _IRM 1.4.13.14_, Continuity Planning. | The reviewer should:<br> <br>      - Describe actions taken by the group in supporting the continuity plan. At a minimum, each TAS group’s Continuity Plan should be updated to sure the plan is accurate and that managers have up to date contact information for employees and business unit contacts.<br>        <br>      - Ensure a copy of the group’s plan was provided to the Senior Commissioner’s Representative (SCR) in the state the group or its employees are located.<br>        <br>      - Verify the accuracy of the calling tree.<br>        <br>      - Verify the group’s participation in the calling tree exercise. When did it occur? What were the results? |
      | Internal Group Controls - Risk Assessment: Travel Vouchers and Travel Cards | The reviewer should look at a random sample of travel vouchers from the group in Concur. There is no minimum number but should include vouchers from a variety of travelers. Review for the following:<br> <br>      - Verify travel dates. Dates on travel authorization match travel dates on official itinerary invoice and lodging receipts.<br>        <br>      - Verify the submission of receipts. In Concur, all of the required receipts must be attached to the voucher.<br>        <br>      - Verify class of travel on itinerary invoice. Invoice must indicate coach class unless the employee received approval prior to the travel to use first or business class. If first or business class was approved, then copies of authorizations must be attached to the voucher.<br>        <br>      - Verify that the invoices and receipts for amounts over $75 indicate method of payment.<br>        <br>      - Verify amounts claimed on the voucher. Voucher expenses must match the approved authorization amount. The official itinerary invoice must match the amount claimed on the voucher. The lodging invoice, including any additional taxes, must match the amount claimed on the voucher. The amount on a rental car agreement must match the voucher amount. The voucher should not include transportation expenses paid for by the Centrally Billed Account.<br>        <br>      - Verify that the employee has accounted for any advances received via electronic funds transfer (EFT). The claimed expenses must liquidate any advances received via EFT. If not, then the employee should have remitted payment for the difference to the Beckley Finance Center (BFC).<br>        <br>      - Verify the line of accounting (LOA). If using an LOA other than the default LOA, the employee must submit reporting instructions or other documentation to support the LOA being used.<br>        <br>      - Verify trip cancellation actions. Unused paper or electronic tickets must be returned to the travel vendor. Travel authorization should have been canceled. Employee should have remitted the full amount of an EFT advance to the BFC. Only the Travel Management Center and TAV fees are on the voucher if the travel vendor issued the airline tickets prior to the trip cancellation.<br>        <br>      - Summarize the travel voucher review results. Are vouchers submitted and approved timely? Are vouchers approved appropriately? If not, what corrective actions are needed. |
      | Internal Group Controls - Risk Assessment: Time Reporting and Leave Administration | The reviewer should:<br> <br>      - Analyze the Work Planning & Control (WP&C) report for the group to gauge whether time is being charged to special categories.<br>        <br>      - Review WP&C for absent without leave (AWOL), leave without pay (LWOP), and other excessive leave patterns to consider. Are there problems to address and were employees advised of potential leave accrual cutbacks?<br>        <br>      - Review SETR for advanced annual and advanced sick leave. Are there any issues or concerns? what controls are in place to verify or audit SETR input?<br>        <br>      - Determine if there are any leave abuse concerns that need to be addressed. See _IRM 1.4.13.12.8.5_, Time and Attendance. |
      | Internal Group Controls - Risk Assessment: Overtime Allocation | The reviewer should verify that the group has a process to track overtime usage to prevent exceeding their allocation, if applicable. |
      | Internal Group Controls - Risk Assessment: Meeting Minutes and Conference Calls | The reviewer should:<br> <br>      - Assess the group communication strategy, conferencing, and briefings, meetings, town halls, etc.<br>        <br>      - Review a copy of meeting notes for the past six months. |
      | Internal Group Controls - Risk Assessment: Physical Security | The reviewer should:<br> <br>      - Determine how the manager ensures the physical safety of their employees who are not co-located with other TAS staff.<br>        <br>      - Interview a sample of employees to ensure familiarity with reporting procedures (see _IRM 1.4.13.15_, Security.<br>        <br>      - Discuss with leadership the efforts and oversight made for group security. If possible, conduct an independent after-hours security check to verify compliance with IRM procedures and adherence to the clean desk policy (see _IRM 1.4.13.4.10_, Clean Desk Policy. |


6. The following are suggested employee one-on-one questions that can be used during an operational review.



   - If a friend or employee from another business division expressed an interest in taking a position with TAS in your group, would you recommend it? Why or why not?

   - How would you describe your group environment? Do your colleagues support each other and act as a team?

   - All TAS organizations experience change in leadership and personnel from time to time, what impact has this had on your group?

   - Describe your communications with your manager and what you value most.

   - How does your manager support your success, including CLPs, training, and coaching?

   - Talk about your work-life balance. Does your manager encourage your efforts to achieve this balance?

   - How do you manage stress?

   - If your manager was asked to take a temporary assignment and you were asked to manage the group for a few months, what would be the one thing you would work on to make the group more successful?

   - If you could change one thing in your work group, what would it be and why?


7. Draft a written report of the findings using the Operational Review templates and provide a copy to the manager. If action items result from the review, establish target completion dates and schedule a follow-up review, if warranted.

8. See IRM 1.4.1.8, Evaluating Performance, for general guidelines related to performance evaluations.


**1.4.13.9.5.4** **(03-13-2023)**

##### Case Advocacy Employee Reviews

1. Managers of Case Advocacy employees will complete the following reviews, when applicable.

2. EDCA and EDCA-ITS managers will refer to _Exhibit 1.4.13-3._, TAS Manager Review Schedule.

3. Managers will conduct timely reviews, including reviews of new hires, even those assigned an OJI. Managers will have regular meetings with new hires and OJIs throughout the OJT period. For individuals who are OJIs, managers will continue to complete reviews while the individual is an OJI, by reviewing their assignments in conjunction with the individual’s CJEs.


**1.4.13.9.5.4.1** **(07-16-2021)**

###### Ongoing Advocacy Review and Employee Support Discussion

1. This one-on-one review is critical in encouraging employee engagement and identifying advocacy opportunities on a frequent basis. These discussions should be tailored to the individual employee and based on the employee’s needs. There is no time limit for these discussions, but they should not last so long as to become burdensome, nor so short to be ineffective.



|     |     |
| --- | --- |
| Reviewer: | LCAs and LIAs |
| Delegate? | Not applicable. |
| Evaluative? | No |
| Review of: | Peer to peer mentoring that results from a variety of reviews including EIR, Operations Assistance Request (OAR) Screening, 60-day, 100-day, contact recording, walk-in, 4442s, new receipts, etc. |
| Scope: | This provides face-to-face support based on the ACE model. LCAs/LIAs reference/update Individual Support Focus. |
| Written Documentation: | Not applicable. |
| TAMIS Literal: | Not applicable. |


**1.4.13.9.5.4.2** **(06-15-2023)**

###### Intake Advocate Reviews

1. These reviews are specifically designed for IAs and Leads to foster a coaching environment and encourage employee engagement to sustain an Advocacy centric environment.

2. For managers of new employees, managers will provide thoughtful comments on the new employee’s performance, highlighting achievements and discussing opportunities for improvement in sufficient detail that the employee understands what they need to do to improve performance.

3. Managers are not required to wait 60 days after the employee receives their CJEs, finishes OJT, or is certified in an individual skill or skillset group (i.e., General, Accounts, Examination, or Collection) to issue evaluative performance documentation. They can issue this type of documentation at any time after the employee receives their CJEs. Managers may provide evaluative documentation related to Critical Job Element (CJE 1), Professionalism and Teamwork.



### Reminder:



Managers will observe the use of time by new hires (time utilization and meeting deadlines). Such as ensuring SETR is input timely and accurately, employee is reporting to work timely, employee is interacting with the manager, OJI, and peers in a professional manner, etc.

4. Finally, managers will conduct reviews timely allowing employees sufficient time to improve performance prior to certification. In addition, managers will have regular meetings with OJIs to discuss the OJI’s non-evaluative observations of the new employee and updating the OJT plan accordingly. The reviews that OJIs complete on case inputs or items worked in TAMIS need to be documented.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, IA Manager, or individual acting in those positions |
| Delegate: | No, may have a technical advisor, LCA, LIA or analyst review aspects of the cases and provide comments to the manager. |
| Evaluative? | Yes |
| Review of: | - Calls (Contact Recording when available);<br>     <br>   - New Case Receipts; and<br>     <br>   - Quick Closures. |
| Scope: | Managers will review for (not all inclusive):<br> <br>   - Communication techniques;<br>     <br>   - Advocacy actions;<br>     <br>   - Accuracy of case input, including TAMIS case coding;<br>     <br>   - Accuracy of case building and education of the taxpayer;<br>     <br>   - History documentation; and<br>     <br>   - Issue identification/elevation. |
| Written Documentation: | Form 14766, TAS Intake Advocate and LIA Review Sheet, and discuss the results with the employee. |
| TAMIS Documentation: | Document substantive non-evaluative direction.<br> <br>   - TAMIS history literal for new case receipts or quick closure case reviews, \*\*IA MER\*\*.<br>     <br>   - Create a Contact Record and use "Managerial Review" as the Reason for No Case for reviews of contacts not accepted as a TAS case. Input literal \*\*IA MER\*\* in the Additional Information field on the Contact Record. |

5. In addition to the evaluative reviews conducted by managers, LIAs, LCAs, coaches, or managers (or their delegates) need to complete at least one non-evaluative review each month for fully trained IAs in their team.



|     |     |
| --- | --- |
| Reviewer: | LIA, LCA, coach, manager (or delegate) |
| Delegate: | Yes |
| Evaluative: | No |
| Review of: | - Calls (Contact Recording, when available);<br>     <br>   - New case receipts; and<br>     <br>   - Quick closure cases. |
| Scope: | LIA, LCA, coach, or manager will review for (not all inclusive):<br> <br>   - Are communications proactive, explain the advocacy process and TAS’s role, timely, and set taxpayer expectations?<br>     <br>   - Are initial advocacy steps proactive?<br>     <br>   - Are issue(s) or root cause(s) correctly identified?<br>     <br>   - Did the IA educate the taxpayer on the next steps?<br>     <br>   - Is there a sound action plan and is it documented in TAMIS?<br>     <br>   - Has the IA reached out for support (coach, LIA, manager) as needed?<br>     <br>   - Are next contact and follow-up dates established, as appropriate? |
| Written Documentation: | Form 14766 and discuss the results with the employee. |
| TAMIS Documentation: | Document substantive non-evaluative direction.<br> <br>   - For LIA/LCA reviews - TAMIS history literal for new case receipt or quick closure case review is \*\*LEAD NER\*\*.<br>     <br>   - For coach reviews - TAMIS history literal for new case receipt or quick closure case review is \*\*OJI NER\*\*.<br>     <br>   - Create a Contact Record and use "Managerial Review" as the Reason for No Case for reviews of contacts not accepted as a TAS case. Input \*\*LEAD NER\*\* for LIA/LCA reviews or \*\*OJI NER\*\* for coach reviews in the Additional Information field of the Contact Record. |


**1.4.13.9.5.4.3** **(03-13-2023)**

###### Lead Case Advocate and Lead Intake Advocate Reviews

1. Managers conduct reviews to measure LCA and lead intake advocate performance.

2. |     |     |
| --- | --- |
| Reviewer: | LTAs, TAGMs, IA managers. |
| Delegate? | No, may have a technical advisor, LCA (for LIA reviews), or analyst review aspects of the cases and provide comments to the manager. |
| Evaluative? | Yes |
| Review of: | Open or closed cases |
| Scope: | These reviews will assess the effectiveness and accuracy of guidance provided to CAs and IAs and the impact on improvement. Identify significant advocacy and general performance gaps to share with management. When reviewing cases assigned to the LCA and LIA the reviews will gauge the efforts taken to advocate to the extent allowable by law and within the applicable delegated authorities. |
| Written Documentation: | Form 13095 for LCAs and Form 14766 for LIAs, if additional comments are needed attach a memo to the form, and the results discussed with the employee in a face-to-face meeting. |
| TAMIS Literal: | \*\*QERL\*\*<br> Document substantive non-evaluative direction in the TAMIS History. |


**1.4.13.9.5.4.4** **(03-13-2023)**

###### Case Advocate Reviews

1. Managers will conduct reviews to measure CA’s performance.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, or individual acting in those positions. |
| Delegate? | No, may have a technical advisor, LCA, or analyst review aspects of the cases and provide comments to the manager. |
| Evaluative? | Yes |
| Review of: | Open and closed cases. |
| Scope: | The review will cover all actions and gauge the efforts taken to advocate to the extent allowable by law. |
| Written Documentation: | Form 13095, Taxpayer Advocate Service Case Review Form, and the results must be shared with the employee within 15 workdays of when the review was conducted. All evaluative reviews must be discussed with the employee. |
| TAMIS Literal: | \*\*MER\*\*<br> Managers will discuss case specific directions (e.g., update the action plan to include a specific action, additional documentation requests, use of TAOs and other advocacy tools, etc.) with the employee and document specific directions in the TAMIS history, as appropriate. Leaving case direction memorializes necessary next steps in the case. The manager will conduct timely follow up to ensure the appropriate actions were taken. |


**1.4.13.9.5.4.5** **(03-13-2023)**

###### Early Intervention Reviews

1. EIRs are effective as a proactive step to ascertain whether the CA has verbally communicated with the taxpayer in a timely manner and clearly identified the taxpayer issues; has documented an action plan and taken substantive actions to move the case forward. The review should identify instances where an employee is having difficulty developing the case.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, or LCA |
| Delegate? | Yes |
| Evaluative? | No |
| Review of: | Open cases. Criteria used for selecting cases shall be at the discretion of the office LTA, such as:<br> <br>   - Experience of CA;<br>     <br>   - Strengths and weaknesses of CA;<br>     <br>   - Criteria of case; and<br>     <br>   - Focus should be on complex issues (there is no reason to conduct an EIR on routine cases). |
| Scope: | Reviews should be focused on the following:<br> <br>   - Are communications proactive, explain the advocacy process and TAS’s role, timely, and set taxpayer expectations?<br>     <br>   - Are initial advocacy steps proactive?<br>     <br>   - Are issue(s) or root cause(s) correctly identified?<br>     <br>   - Is there a sound action plan and is it documented on TAMIS?<br>     <br>   - Has the CA reached out for support (ITAP, TAGM, LCA) as needed?<br>     <br>   - Are OARs developed, as appropriate?<br>     <br>   - Are TAOs recommended, as appropriate?<br>     <br>   - Did the CA take multiple steps or actions where possible to move the case forward?<br>     <br>   - Are next contact and follow-up dates established, as appropriate? |
| Written Documentation: | Document the TAMIS History with substantive non-evaluative direction. An advocacy conversation regarding initial steps with the employee may be appropriate. Follow up to ensure action was taken. |
| TAMIS Literal: | \*\*EIR\*\* |


**1.4.13.9.5.4.6** **(11-29-2023)**

###### Manual Refund Reviews

1. The purpose of issuing a manual refund is to provide the taxpayer quick access to overpayments and credits. A manual refund is not generated through normal computer processing. It requires special preparation to allow the refund to release under unusual circumstances. Management is responsible for ensuring all actions are taken to avoid the issuance of a duplicate erroneous refund.

2. Manual Refund Review:



|     |     |
| --- | --- |
| Reviewer: | LTA |
| Delegate? | No, but the LTA should seek the assistance of a technical advisor, LCA, or analyst if they need technical assistance with this review. |
| Evaluative? | No |
| Review of: | Manual refund forms and supporting documentation |
| Scope: | - Review for accuracy and ensure all applicable supporting documentation is attached.<br>     <br>   - Verify that proper research was conducted. This includes, but is not limited to, consideration of statute expiration dates.<br>     <br>   - Ensure the manual refund is within TAS Authorities and the circumstances of the case warrant such action. |
| Written Documentation: | - Update TAMIS to indicate the manual refund was reviewed and approved.<br>     <br>   - Complete the Manual Refund Tracking Tool (spreadsheet) and forward it to the Area office within 21 days after the end of each quarter. |
| TAMIS Literal: | \*\*MRR\*\* |

3. Area Analyst Manual Refund Reviews:



|     |     |
| --- | --- |
| Reviewer: | Area Analyst |
| Delegate? | No |
| Evaluative? | No |
| Review of: | Sample of manual refunds each quarter for each office. |
| Scope: | - Identify the sample was selected, the percentage of manual refunds sampled, the review process, the results, and how the Area followed up on the prior quarter’s findings.<br>     <br>   - Verify the manual refunds listed on the Manual Refund Tracking Tool against the IDRS report of RFUNDS input for cases with a TAS control.<br>     <br>   - The reviewer should discuss with leadership the oversight and backup process, for manual refund approvals . Assess whether the oversight process is adequate to eliminate the possibility of duplicate, erroneous manual refunds, and to reduce the number of rejected requests. Review the office records, as there are no BOE reports to extract duplicate, erroneous manual refund data, or to count rejected manual refund requests. BOE reports may be generated to identify TAMIS histories noted when a manual refund was approved (MRR). |
| Written Documentation: | Area Analysts will summarize the results of this review on a memorandum. |
| TAMIS Literal: | \*\*AMRCR\*\* |

4. Operational Review of an Office Issuing Manual Refunds:



|     |     |
| --- | --- |
| Reviewer: | DEDCA, Area Analyst |
| Delegate? | No |
| Evaluative? | Yes |
| Review of: | Operational reviews of offices whose employees can initiate, approve, or monitor a manual refund. |
| Scope: | For each office, the reviewer shall ensure:<br> <br>   - Employees authorized to request manual refunds have IDRS command code RFUND in their profile.<br>     <br>   - Only LTAs or above, or anyone officially designated to act for an LTA for 60 days or more, are authorized to approve manual refunds. See IRM 3.17.79.3.5.<br>     <br>   - LTAs approving manual refunds are following the IDRS restrictions in IRM 10.8.34.5.2.1.6.8.<br>     <br>   - The office has identified backups and put a process in place, so that if the first or second level monitors are out of the office, the backup will complete the monitoring.<br>     <br>   - Employees are documenting the TAMIS history for the manual refund approvals (MRR).<br>     <br>   - Offices identify erroneous and duplicate manual refunds occurring during the past year. See IRM 21.4.5, Erroneous Refunds.<br>     <br>   - Offices identify the number of manual refund requests that were rejected to determine whether the staff needs training on manual refund requests.<br>     <br>   - That annual refresher training, as required by the IRM, is completed every 12 months for manual refund initiators, reviewers, and approvers. Ensures the appropriate IDRS command codes are removed if the training is not completed. |
| Written Documentation: | Area Analysts will summarize the results of this review on a memorandum. |
| TAMIS Literal: | Not applicable |


**1.4.13.9.5.4.7** **(07-16-2021)**

###### Small Business Regulatory Enforcement Fairness Act (SBREFA) Case Reviews

1. The purpose of open SBREFA case reviews are to determine if the issues are identified, a proper action plan adopted, taxpayer contacts are made, and advocacy and systemic issues addressed in the NTA letter.



|     |     |
| --- | --- |
| Reviewer: | LTA or TAGM |
| Delegate? | No |
| Evaluative? | No |
| Review of: | Open SBREFA cases. |
| Scope: | This is a review to determine:<br> <br>   - Whether taxpayer concerns raised in Small Business Administration (SBA) referral letter and other issues to resolve case are addressed;<br>     <br>   - Difficulties with taxpayer contacts were referred to the District of Columbia (DC) analyst;<br>     <br>   - The letter to SBA was reviewed to ensure taxpayer concerns were addressed and case resolved, and systemic concerns addressed; and<br>     <br>   - The case remained open until SBREFA letter is signed; and Interim letters were sent to SBA updating progress on the case every 30 days. |
| Written Documentation: | Document substantive non-evaluative direction in the TAMIS History. |
| TAMIS Literal: | \*\*SBREFA\*\* |


**1.4.13.9.5.4.8** **(06-15-2023)**

###### Area Advocacy Case Reviews

1. Area advocacy case reviews identify advocacy opportunities.



|     |     |
| --- | --- |
| Reviewer: | Deputy and Area Analysts |
| Delegate? | No. The reviewer may use available resources, including ITAP, where additional support is needed. |
| Evaluative? | No |
| Review of: | Open or Closed cases |
| Scope: | This is a case review to determine the status, delays, or actions needed. Document TAMIS with case guidance to move the case forward and follow-up as warranted. Consider why you are reviewing the case. Is the CA:<br> <br>   - Responsive to the taxpayer and Business Operating Division (BOD)? Timely contacts, answering questions or getting information for the BOD.<br>     <br>   - Acting on information received timely?<br>     <br>   - Moving the case forward? Why not?<br>     <br>   - Taking all actions possible at one time, not setting a follow-up to do an OAR or close a case.<br>     <br>   - Having trouble and needs assistance from the LCA, TAGM, LTA, or ITAP?<br>     <br>   - Is there a reason for this case to be open ( _e.g._, waiting for an IDRS transaction to post)? |
| Written Documentation: | Document the TAMIS history with substantive non-evaluative direction. |
| TAMIS Literal: | \*\*AACR\*\* |


**1.4.13.9.5.4.9** **(06-15-2023)**

###### Area Operational Case Reviews

1. Area advocacy case reviews identify advocacy opportunities.



|     |     |
| --- | --- |
| Reviewer: | Deputy and Area Analysts |
| Delegate? | No. The reviewer may use available resources, including ITAP, where additional support is needed. |
| Evaluative? | No |
| Review of: | Open or closed cases |
| Scope: | This is a comprehensive review of TAS’s advocacy efforts on each case, including employee engagement and case progression and resolution. Reviews are completed using available resources and the review results and observations and shared and discussed between the Deputy and the LTA. |
| Written Documentation: | Document the TAMIS history with substantive non-evaluative direction. |
| TAMIS Literal: | \*\*AOPR\*\* |


**1.4.13.9.5.4.10** **(09-17-2019)**

###### 365+ Day Case Reviews

1. Three hundred sixty-five day plus (365+) case reviews include a comprehensive analysis to identify actions taken, actions needed to resolve the case, and the identification of potential training needs.



|     |     |
| --- | --- |
| Reviewer: | DEDCA and Area Analysts |
| Delegate? | No |
| Evaluative? | No |
| Review of: | Cases open more than 365 days. |
| Scope: | This review will determine the next steps necessary to advocate or bring the case to closure. Review results are shared and discussed between the DEDCA and the LTA. Consider whether case follow ups are timely and if extensions provided to the IRS are warranted before issuing a TAO. |
| Written Documentation: | Notate TAMIS history with substantive non-evaluative direction. |
| TAMIS Literal: | \*\*365R\*\* |


**1.4.13.9.5.4.11** **(03-13-2023)**

###### Tailored Advocacy Case Reviews

1. The advocacy case reviews are generally non-evaluative advocacy driven events that give the reviewer a picture of what is going on in a case. These reviews should never be just perfunctory TAMIS documentation but should provide meaningful guidance or direction to reach the best possible outcome for the taxpayer, move the case to resolution, and to improve the skills of the CA.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, or LCA |
| Delegate? | Yes |
| Evaluative? | No |
| Review of: | Open cases. |
| Scope: | Document TAMIS with case guidance to move the case forward and follow-up as warranted. Offices should consider office-wide opportunities when selecting cases for review, as well as the unique needs of individual CAs. For example, relief rates on Collection cases may point to a need for reviews. Items to consider:<br> <br>   - Has the CA clearly identified the taxpayer’s issues and taken steps to advocate with a sense of urgency?<br>     <br>   - Will the Action Plan resolve the issues?<br>     <br>   - Is the CA being responsive to the taxpayer?<br>     <br>   - Does the CA communicate via telephone whenever possible?<br>     <br>   - Were substantive actions taken to move the case forward for the best possible outcome?<br>     <br>   - Is the CA is unclear on next steps, have they sought assistance from the LCA or manager?<br>     <br>   - Has the CA sought ITAP assistance via a referral?<br>     <br>   - Was the OAR developed and issued at the first possible opportunity?<br>     <br>   - Has the BOD been unresponsive or untimely (expired, extended)?<br>     <br>   - Are there systemic issues that need to be reported on SAMS? Consider what IRS problem caused the taxpayer to seek TAS assistance.<br>     <br>   - Is the case is on track for resolution? Are additional issues that need to be worked or addressed?<br>     <br>   - Does a TAO need to be issued? Consider whether case follow-ups are timely and if extensions provided to the IRS are warranted before issuing a TAO.<br>     <br>   - Have IRS delays been identified and remedies pursued?<br>     <br>   - Are there misrouted OARs? Is there a training opportunity for either TAS or operational employees?<br>     <br>   - Is there a reason for this case to be open (e.g., waiting for an IDRS transaction to post)?<br>     <br>   - Is this a politically sensitive issue that should be elevated to the EDCA? |
| Written Documentation: | Document the TAMIS history with substantive non-evaluative direction. Where possible, meet with CAs on select cases to discuss advocacy efforts and alternatives. Follow up to ensure requested actions were taken. |
| TAMIS Literal: | \*\*ACR\*\*<br> If this review or any other results in a TAO discussion with the function, document TAMIS with the literal \*\*TAO-D\*\* to indicate a TAO will be issued as the next step if the OAR action is not taken. |


**1.4.13.9.5.4.12** **(07-16-2021)**

###### OAR Reviews

1. The purpose of the OAR Review is to determine if the OAR is properly issued and to identify any training needs.

2. OAR Screening. The purpose of reviewing outgoing OARs is to make sure the OAR is fully developed by:



1. Appropriately using advocacy centric language;

2. Sending the OAR to the proper location;

3. Clearly stating the requested action;

4. Ensuring adequate documentation is attached to allow the BOD to take the actions requested; and

5. Reviewing these cases can also identify instances in which the taxpayer is in critical need of assistance so the manager can track the case to ensure the issue is favorably resolved.


3. OAR Post-Issuance. Review expired, aged, or rejected OARs for missed advocacy opportunities and potential issuance of a TAO.

4. Procedures regarding management responsibilities in the OAR process can be found in IRM 13.1.19, Advocating with Operations Assistance Requests (OARs), and in the Service Level Agreements (SLAs).



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, LCA, or Analyst |
| Delegate? | Yes |
| Evaluative? | No |
| Review of: | OARs |
| Scope: | Steps for individual OAR review:<br> <br>   - Verify actions requested are clear and concise;<br>     <br>   - Verify destination of OAR;<br>     <br>   - Verify supporting documents are attached; and<br>     <br>   - Verify requested completion date is appropriate for the issue and circumstances; and consider prompt issuance of a TAO to advocate where appropriate. |
| Written Documentation: | Document the TAMIS history with substantive non-evaluative direction. |
| TAMIS Literal: | \*\*OAR\*\* |


**1.4.13.9.5.4.13** **(03-13-2023)**

###### 100-day with No Action in Last 60 days

1. The purpose of this review is to ensure all actions are being taken to move the case toward a timely resolution.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, or LCA |
| Delegate? | Yes |
| Evaluative? | No |
| Review of: | Open Cases |
| Scope: | Reviews identify cases that are open more than 100 calendar days with no action within the last 60 days to determine if there are unnecessary delays, if technical or managerial guidance is needed, training needs, or inventory management concerns that could impact timely and effective case resolution. Determine if case is stalled or being adequately developed. |
| Written Documentation: | The reviewer should document case guidance on TAMIS and follow up as needed. |
| TAMIS Literal: | \*\*100R\*\* |


**1.4.13.9.5.4.14** **(09-17-2019)**

###### Relief and Outcome

1. The purpose of this review is to determine if TAS reached the best possible outcome for the taxpayer with the appropriate sense of urgency.



|     |     |
| --- | --- |
| Reviewer: | LTA |
| Delegate? | No |
| Evaluative? | No |
| Review of: | Closed cases |
| Scope: | Reviews should generally consist of categories of cases identified with broad improvement opportunities (such as Collection or Exam cases) and give the reviewer a picture of what advocacy efforts were taken. |
| Written Documentation: | LTAs will summarize the results on a memorandum. Discussion will be led by LTA with office leadership. When warranted, LCAs will use review findings in advocacy conversations. |
| TAMIS Literal: | Not applicable. |


**1.4.13.9.5.4.15** **(07-16-2021)**

###### Correspondence

1. The purpose of this review is to ensure taxpayer communications are clear, concise, and grammatically-correct.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, IA Manager, LIA, or LCA |
| Delegate? | Yes |
| Evaluative? | No |
| Review of: | Outgoing taxpayer correspondence |
| Scope: | The review of outgoing taxpayer correspondence should focus on the accuracy of grammar and format and identifying training needs for the employee or office. |
| Written Documentation: | Not applicable |
| TAMIS Literal: | Not applicable |


**1.4.13.9.5.4.16** **(03-13-2023)**

###### IDRS Online Reviews

1. The purpose of these reviews is to make sure adjustments input by TAS are technically accurate, adhere to IRM procedures, are within TAS authority, and protect the integrity of IDRS.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, CCI Manager, LIA, or LCA |
| Delegate? | Yes |
| Evaluative? | No |
| Review of: | On-line IDRS Adjustment(s) |
| Scope: | - Reviews include account adjustment actions that adjust, change, or move tax or credits.<br>     <br>   - The reviewer should be very knowledgeable of account actions, statutes (e.g., expiration dates) and TAS authorities. Reviewers should consider the following: Does TAS have the authority to make this adjustment? Was the action appropriate? Are the entries accurate and complete?<br>     <br>   - If any of the above actions are incorrect, the reviewer should have a conversation with the person who input the adjustment (if time allows) and immediately delete the adjustment. The reviewer should provide immediate guidance to the TAS employee, with priority given to actions needing correction. Contact an ATA, if necessary.<br>     <br>   - For more information on how to conduct the reviews, see IRM 2.4.5, Command Codes, QRADD, QRADDO, QRNCH, QRNCHG, RVIEW, QRACN, and QRIND for the Quality Review System.<br>     <br>   - Offices may partner with another office or offices for help performing these reviews.<br>     <br>   - See _IRM 1.4.13.4.8.6_, Reviewers of IDRS Adjustments, for additional information. |
| Written Documentation: | Document the TAMIS history with substantive non-evaluative direction, when applicable. |
| TAMIS Literal: | \*\*IDRSR\*\* |


**1.4.13.9.5.4.17** **(09-17-2019)**

###### Pre-Closure Reviews (PCRs)

1. PCRs ensure all taxpayer issues are resolved and addressed before the case is closed and verify the accuracy of TAMIS case coding. Pre-Closure Reviews may identify training needs.



|     |     |
| --- | --- |
| Reviewer: | LTA, TAGM, or LCA |
| Delegate? | Yes |
| Evaluative? | No |
| Review of: | Open cases just prior to closing. |
| Scope: | Reviewers should consider the following:<br> <br>   - Were all issues resolved?<br>     <br>   - Were all related issues addressed?<br>     <br>   - Is the TAMIS coding accurate?<br>     <br>   - Did the correspondence contain the appropriate content, use the correct format, or contain grammatical errors?<br>     <br>   - If Collection holds were placed, were they extended and released timely?<br>     <br>   - Were actions procedurally correct?<br>     <br>   - Was the Action Plan documented and updated throughout the life of the case?<br>     <br>   - Did the TAS employee make specific apologies to the taxpayer? |
| Written Documentation: | Document the TAMIS history with substantive non-evaluative direction. |
| TAMIS Literal: | \*\*PCR\*\* |


**1.4.13.9.5.5** **(03-13-2023)**

##### Internal Technical Advisor Program (ITAP) Reviews

1. The purpose of the ITAP Referral Reviews is to:



1. Determine if TAS is effectively advocating on behalf of the taxpayer.

2. Determine if the technical guidance is timely, complete, accurate, and references the law or IRM procedure.

3. Verify that follow-ups, next contact dates, and estimated completion dates are documented in the TAMIS histories and are timely delivered.

4. Achieve active, ongoing communication between the Technical Advisors and CAs.

5. Address Appeals/Compliance issues in TAMIS history.

6. Provide proper guidance and conduct negotiations with the BOD by ITAP on behalf of the CA, as appropriate.

7. Document disclosure verification when the Technical Advisor directly speaks with the taxpayer or representative and giving accurate information on where to send an OAR after the CA has followed the SLA procedures.

8. Close referrals timely.

9. Identify skill gaps.


2. The following reviews are conducted by ITAP and provide fact-based information to support mid-year and end-of-year appraisals.


**1.4.13.9.5.5.1** **(03-13-2023)**

###### Technical Accuracy Evaluative Reviews

1. The purpose of this review is to measure the technical accuracy of the guidance given.



|     |     |
| --- | --- |
| Reviewer: | Managers, Internal Technical Advisor Program |
| Delegate? | No |
| Evaluative? | Yes |
| Review of: | - TAMIS case referral;<br>     <br>   - IMD reviews;<br>     <br>   - CATL topics;<br>     <br>   - SAMS submissions;<br>     <br>   - Training materials; and<br>     <br>   - Presentations. |
| Scope: | Managers must address evaluative performance based reviews on the critical job elements. Was the guidance case or issue specific, did it completely address the taxpayer and CA concerns, and how effective the guidance was in promoting advocacy in TAS? |
| Written Documentation: | Managers will supply Technical Advisors (TAs) with a written evaluation of the review. The results from these reviews should be summarized in a monthly report to the ITAP Director to identify training opportunities, trends, etc. |
| TAMIS Literal: | \*\*ITTAR\*\* |


**1.4.13.9.5.5.2** **(09-17-2019)**

###### Workload Evaluative Reviews

1. The purpose of a workload review is to provide the manager with a "snapshot" of the TA's assigned workload at a specific point in time. This snapshot provides the manager with valuable information regarding the employee’s workload management skills and technical expertise.



|     |     |
| --- | --- |
| Reviewer: | Managers, Internal Technical Advisor Program |
| Delegate? | No |
| Evaluative? | Yes |
| Review of: | This will include referrals, IMD reviews, CATL topics, and other training material review or preparation and office visits, task force, and project assignments. |
| Scope: | It is important the workload review includes a discussion between the TA and manager regarding open referred cases or assignments in the employee's workload. |
| Written Documentation: | Managers will summarize the results of the workload evaluative reviews and capture this on a memorandum. |
| TAMIS Literal: | \*\*ITWLR\*\* |


**1.4.13.9.5.5.3** **(09-17-2019)**

###### TAO Reviews

1. The purpose of this review is to determine technical advisor involvement in cases where a TAO has been issued.

2. TAO trends discovered during these reviews will be provided to the EDCA-ITS.



|     |     |
| --- | --- |
| Reviewer: | EDCA-ITS, Technical Advisors |
| Delegate? | No |
| Evaluative? | No |
| Review of: | TAOs |
| Scope: | If a TA was consulted before the TAO was issued, the advice provided will be reviewed to ensure the TA provided timely, technically correct, and advocacy-focused guidance. If a TA was not consulted before the TAO was issued, the case will be reviewed to see if TA assistance would have been helpful. Observations on some TAOs may be provided to LTAs. |
| Written Documentation: | Results will be summarized and captured in a briefing document. |
| TAMIS Literal: | Not applicable |


**1.4.13.9.5.6** **(03-13-2023)**

##### TAG Program Reviews

1. The following reviews are conducted by TAG and provide fact-based information to support mid-year and end-of-year appraisals.

2. TAG Written Product Review



|     |     |
| --- | --- |
| Reviewer: | TAG Director and Managers |
| Delegate? | No |
| Evaluative? | Yes |
| Review of: | Written products (e.g., CABIC, QRIS, Town hall Response, or Executive Briefing). |
| Scope: | The written product review should look for:<br> <br>   - Accuracy of information;<br>     <br>   - Technical knowledge;<br>     <br>   - Presentation; and<br>     <br>   - Organizational impact. |
| Written Documentation: | Managers will summarize the results of this review on a memorandum. |
| TAMIS Literal: | Not applicable |

3. TAG Data Analysis Accuracy Review



|     |     |
| --- | --- |
| Reviewer: | TAG Director and Managers |
| Delegate? | No |
| Evaluative? | Yes |
| Review of: | Review of data analysis products (e.g., BPR, Report to Congress, Quarterly BOD Report). |
| Scope: | The Data Analysis Accuracy Review should look for:<br> <br>   - Accuracy of data;<br>     <br>   - Issue identification; and<br>     <br>   - Research and analysis. |
| Written Documentation: | Managers will summarize the results of this review on a memorandum. |
| TAMIS Literal: | Not applicable |

4. TAG Case Advocacy Specialist Review



|     |     |
| --- | --- |
| Reviewer: | TAG Managers |
| Delegate? | No |
| Evaluative? | Yes |
| Review of: | Work completed by Case Advocacy Specialists, such as:<br> <br>   - IMD reviews;<br>     <br>   - CATL assignments;<br>     <br>   - Training Material reviews;<br>     <br>   - Data Collection Instruments; and<br>     <br>   - Reviews of cases transferred into a TAMIS organization code for TAG monitoring. |
|  | The TAG Case Advocacy Specialist Review should look for:<br> <br>   - Accuracy of information;<br>     <br>   - Technical knowledge; and<br>     <br>   - Organizational impact. |
| Written Documentation: | Managers will summarize the results of this review on a memorandum that discusses these activities as they relate to the Case Advocacy Specialist’s CJEs. |
| TAMIS Literal: | Not applicable |


**1.4.13.9.5.7** **(09-17-2019)**

##### Taxpayer Advocacy Panel (TAP) Reviews

1. TAP managers will conduct the following reviews.

2. Initial Advocacy Review



|     |     |
| --- | --- |
| Reviewer: | TAP Manager |
| Delegate? | No |
| Evaluative? | Manager’s Discretion |
| Review of: | TAP Project |
| Scope: | Assess direction of project and employee’s performance in supporting and/or directing project committee. |
| Written Documentation: | Managers will summarize the results of this review on a memorandum. |
| TAMIS Literal: | Not applicable |

3. In-Process Reviews



|     |     |
| --- | --- |
| Reviewer: | TAP Manager |
| Delegate? | No |
| Evaluative? | Manager’s Discretion |
| Review of: | TAP Project |
| Scope: | Assess direction and employee’s performance in supporting and/or directing team. |
| Written Documentation: | Managers will summarize the results of this review on a memorandum. |
| TAMIS Literal: | Not applicable |

4. Closed Deliverable Reviews



|     |     |
| --- | --- |
| Reviewer: | TAP Manager |
| Delegate? | No |
| Evaluative? | Yes |
| Review of: | TAP Project |
| Scope: | Review closing actions for each committee referral. |
| Written Documentation: | Managers will summarize the results of this review on a memorandum. |
| TAMIS Literal: | Not applicable |


**1.4.13.9.5.8** **(07-16-2021)**

##### Systemic Advocacy Reviews

01. Systemic Advocacy managers will conduct the following reviews.

02. Initial Advocacy Review – Technical Accuracy



    |     |     |
    | --- | --- |
    | Reviewer: | Systemic Advocacy (SA) Technical Advocacy Director |
    | Delegate? | No |
    | Evaluative? | Manager’s Discretion |
    | Review of: | Advocacy projects, collaborative efforts, IMD reviews, IGPs, etc. |
    | Scope: | Ensure action plan and actions are appropriate. Manager will provide guidance on the quality of the work and direction, if needed. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

03. In-Process Review – Technical Accuracy



    |     |     |
    | --- | --- |
    | Reviewer: | SA Manager |
    | Delegate? | No |
    | Evaluative? | Manager’s Discretion |
    | Review of: | Review a sample of open assignments |
    | Scope: | Review to ensure applicable expectations and timeframes for specific assignments are met. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

04. Closed Deliverable Reviews – Technical Accuracy



    |     |     |
    | --- | --- |
    | Reviewer: | SA Manager |
    | Delegate? | No |
    | Evaluative? | Yes |
    | Review of: | Review the completed work efforts of each employee for that quarter. |
    | Scope: | Review to ensure applicable expectations and timeframes for specific assignments are met. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

05. Initial Advocacy Review – SIRE



    |     |     |
    | --- | --- |
    | Reviewer: | SIRE Manager |
    | Delegate? | No |
    | Evaluative? | Manager’s Discretion |
    | Review of: | Review a sample of SAMS issues recently assigned to an employee as a Level 1 reviewer. |
    | Scope: | Items for consideration can include whether the issue was correctly defined by the employee and if employee took the appropriate initial actions, etc. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

06. In-Process Advocacy Review – SIRE



    |     |     |
    | --- | --- |
    | Reviewer: | SIRE Manager |
    | Delegate? | No |
    | Evaluative? | Manager’s Discretion |
    | Review of: | Review any assigned SAMS issues open more than 60 days and other pending assignments. |
    | Scope: | Review of SAMS issues may include whether the issue is being actively moving toward completion of Level 1 review, if appropriate SMEs have been consulted, etc. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

07. Closed Deliverable Reviews – SIRE



    |     |     |
    | --- | --- |
    | Reviewer: | SIRE Manager |
    | Delegate? | No |
    | Evaluative? | Yes |
    | Review of: | Review closing actions on a sample of closed SAMS issues. |
    | Scope: | Review for appropriate documentation including communication with the submitter. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

08. Initial Advocacy Review – IMD/SPOC



    |     |     |
    | --- | --- |
    | Reviewer: | IMD/SPOC Manager |
    | Delegate? | No |
    | Evaluative? | Manager’s Discretion |
    | Review of: | Review of sample of IMD reviews loaded into the IMD Center and assigned. |
    | Scope: | Review to ensure applicable expectations and timeframes for IMD Reviews are met. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

09. In-Process Review – IMD/SPOC



    |     |     |
    | --- | --- |
    | Reviewer: | IMD/SPOC Manager |
    | Delegate? | No |
    | Evaluative? | Manager’s Discretion |
    | Review of: | Review of sample of in process IMD reviews. |
    | Scope: | Review to ensure applicable expectations and timeframes for IMD Reviews are met. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |

10. Closed Deliverable Reviews – IMD/SPOC



    |     |     |
    | --- | --- |
    | Reviewer: | IMD/SPOC Manager |
    | Delegate? | No |
    | Evaluative? | Yes |
    | Review of: | Review a sample of closed IMD reviews. |
    | Scope: | Review to ensure applicable expectations and timeframes for IMD Reviews are met. |
    | Written Documentation: | Managers will summarize the results of this review on a memorandum. |
    | TAMIS Literal: | Not applicable |


**1.4.13.9.6** **(06-15-2023)**

#### Performance Management System Process/Performance Review Board

1. Managers are evaluated annually based on performance during the performance appraisal period of October 1 through September 30. To receive an Internal Revenue (IR) summary evaluation rating or IR rating of record, permanent managers must be in an IR payband position on the performance appraisal ending date of September 30. Performance evaluations are made in accordance with the concepts and requirements of the IRS Performance Management Program for Managers/Management Officials and Confidential Management/Program Analysts, and corporate and organizational goals as described in IRM 6.430.3, Performance Management Program for Evaluating Managers, Management Officials and Confidential Management/Program Analysts, and IRM 6.430.5, Performance Appraisals for Temporary Assignments.

2. Visit Performance Evaluations for additional information and policy guidance on performance management.

3. See the IRS Payband System for additional information on the IRS Payband System, and Performance Review Board.


**1.4.13.9.7** **(03-13-2023)**

#### Contact Recording/Telephone Monitoring

1. Contact Recording is a telephone application/tool/system that records incoming telephone contacts transferred from the NTA toll-free line to the CCI lines, for possible monitoring for evaluative and non-evaluative reviews.

2. This system captures voice and in ten percent of calls, the system will screen capture computer activity for later retrieval and review.

3. Managers use the tool to perform required random reviews of incoming telephone contacts.

4. All calls are recorded in their entirety under Contact Recording and are normally erased within 45 days.



### Note:



Management may request a recorded contact be downloaded. Refer to IRM 1.4.21.2.1.5, Managerial Requests, for more information concerning this type of request.

5. If the caller objects to the recording of the call Use the “Stop Recording” icon to disable the Contact Recording feature. For additional information, refer to IRM 21.1.1.8, Contact Recording.

6. Managers and Reviewers requiring access to contact recording use BEARS to request access for their site or the site they will be reviewing.

7. The Contact Recording database contains information on each manager and assistor in a site and the group to which they belong. It is important that managers submit requests to update the Contact Recording database with staffing changes as soon as they are identified. Send a secure email to the Business Application Administrator with the name, login name, SEID, Aspect Login Number, group number, and manager's name to implement the change.

8. When using Contact Recording for evaluative purposes, refer to Document 11678, 2022 National Agreement – Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU), Article 12, Section 9B, Contact Recording and Monitored Contacts.


**1.4.13.9.8** **(06-15-2023)**

#### Statistics RRA 98 Section 1204 – 1204 Certification

1. Key components of Section 1204 include:



1. Section 1204(a) - In General - The IRS shall not use records of tax enforcement results (ROTERs) to evaluate employees or to impose or suggest production quotas or goals with respect to such employees.

2. Section 1204(b) - Taxpayer Service - The IRS shall use fair and equitable treatment of taxpayers as one of the standards for evaluating employee performance.

3. Section 1204(c) - Certification - Each appropriate supervisor shall certify quarterly by letter to the IRS Commissioner whether tax enforcement results are being used in a manner prohibited by Section 1204(a).


2. Additional information concerning Section 1204 and manager certification is available at:



1. IRM 1.5.2, Managing Statistics in a Balanced Measurement System, Uses of Section 1204 Statistics;

2. IRM 1.5.3, Manager’s Self-Certification and the Independent Review Process;

3. IRM 1.5.8, Section 1204/Regulation 801 Guidance for Taxpayer Advocate Service (TAS);

4. RRA’98 Section 1204 Program;

5. Section 1204 Program - HR Connection Indication, How to Add Section 1204 Indicator in HR Connect (SHOTs Video);

6. IRM 6.430.2.4.5.1, Using ROTERs in Self-Assessments; and

7. IRM 6.430.3.5.2.2, Using Records of Tax Enforcement Results (ROTERS) in Self Assessments.


**1.4.13.10** **(01-25-2024)**

### Labor Relations

1. The purpose of this section is to provide managers information about where to go to get information on employee and labor relations issues.

2. The Manager Advantage site is a federal guidelines and research tool that will help managers initially research a labor relations issue.

3. The LR Resources site is a TAS-specific toll for TAS managers to use to research a variety of employee and labor relations issues.

4. HCO Labor Employee Relations & Negotiations (LERN) offers products and services on the IRS Service Central platform. LERN used a tiered approach to customer service:



1. Tier 0 - Self Service (you can resolve issues on your own via IRS Source, Employee Support Virtual Agent Chatbot, iManage, and SHOTs videos).

2. Tier 1 - Employee Resource Center (ERC) (phone gate is staffed by LERN Human Resource (HR) Specialists

3. Tier 2 - LERN HR Specialists (more complex casework elevated to LERN subject matter experts)

4. Tier 3 - Program Execution Office’s Compliance & Accountability Team (review, edit, and add new policies and procedures to improve customer service when necessary)


5. You can reach the LERN gate by calling 866-743-5748 option 1, for ERC, and option 6 for Labor Employee Relations, Monday - Friday, 7 am to 7 pm CST.

6. LERN HR Specialists will answers general questions on performance, discipline, leave, telework, probationary employees, National Agreement, worker’s compensation, and much more. If necessary, customer requests will be escalated through the ticketing system to a LERN SME for resolution.

7. Become familiar with TAS/NTEU Agreements, Letters and Memorandums of Understanding.

8. LERN Employee and Labor Relations Specialists provide support to TAS management on specific cases that involve performance, discipline, leave, grievances, or similar issues. If you have an issue with an individual employee, you will go to LERN.

9. TAS’s Embedded Labor Relations staff members assist with TAS LR policy issues and issues that are national in scope. They also assist with LR issues such as determining negotiability of initiatives, contract interpretation, and other LR issues unique to TAS.


**1.4.13.10.1** **(04-25-2024)**

#### Conduct and Performance

1. The first step in addressing any employee performance or conduct issue is to research the issue using available resources such as the LR Resources site, the Manager Advantage site and self-help resources found on the IRS Service Central platform, such as Employee Support Virtual Agent Chatbot, iManage, and SHOTs videos. If you still have questions, you can call the LERN gate at 866-743-5748 option 1, for ERC, and option 6 for Labor Employee Relations to discuss the issue with LERN HR Specialists.

2. In cases where employee conduct negatively impacts individual or organizational performance, managers must take steps to address the issue.

3. In cases where management determines formal discipline is necessary to correct the behavior, the appropriate manager will be required to input a ticket to recommend a disciplinary or adverse action through IRS Service Central. For assistance with determining what level of discipline is appropriate, managers should review Document 11500, IRS Manager’s Guide to Penalty Determinations.

4. In cases where management determines that formal discipline is not required to correct the behavior, management should consider issuing written counseling. Three rules for effective conduct counseling and documentation are to be fair, consistent, and specific. Address conduct issues immediately and document counseling sessions.

5. TAS’s Embedded Labor Relations Specialists are generally involved with unusual or high-profile cases and will facilitate the resolution of any different opinions between Field LR and management that may arise.

6. For more information on how to address employee performance issues, see _IRM 1.4.13.9_, Managerial Reviews.

7. The following resources are available to assist managers with conduct and performance matters:



01. IRM 6.751.1, Discipline and Disciplinary Actions: Policies, Responsibilities, Authorities, and Guidance;

02. IRM 6.752.1, Disciplinary Suspensions of 14 Calendar Days or Less;

03. IRM 6.752.2, Adverse Actions;

04. IRM 6.432.1, Addressing Poor Performance;

05. IRM 6.531.1.3.7, Acceptable Level of Competence Determinations - Denying Within-Grade Increases;

06. Document 12109, The IRS Supervisors Guide to Conduct and Discipline and Related Topics;

07. LR Resources;

08. iManage, Disciplinary and Adverse Actions;

09. Manager Advantage site;

10. IRS Service Central platform; and

11. Delegation Order TAS-HR-1, Delegation of Authority in Disciplinary/Adverse and Other Actions.


**1.4.13.10.2** **(01-25-2024)**

#### Grievances and Arbitration

1. In simplest terms, a grievance is an expression of dissatisfaction with a situation: generally, an agency’s action or failure to take some action desired by an employee.



1. For BU employees, the negotiated grievance system is codified in the 2022 National Agreement, Article 41 and 42, Employee Grievance and Local Institutional Grievances, and National Institutional Grievance Procedure, respectively.

2. For NBU employees, the mechanism for handling grievances is the Agency Grievance System contained in IRM 6.771.1, Agency Grievance System (AGS).


2. See Grievances and IRM 6.711.1, Labor-Management Relations, for additional information.


**1.4.13.11** **(06-15-2023)**

### TAS Balanced Measures

1. TAS’s balanced measures are structured to assess the organizational effectiveness of TAS achieving its mission of protecting taxpayer rights under the Taxpayer Bill of Rights, helping taxpayers resolve problems with the IRS, and recommending changes that will prevent future problems. TAS’s Balanced Performance Measurement System includes the following components:



1. Employee Satisfaction;

2. Customer Satisfaction; and

3. Business Results (Quality and Quantity).


2. See IRM 13.5.1, TAS Balanced Measures – TAS Balanced Measures System.


**1.4.13.12** **(03-13-2023)**

### Office Management

1. TAS managers are responsible for the day-to-day operations of their office. TAS managers with remote employees will use technology such as Teams for Business, email, telephone and conference calls, and work with other managers who are physically located with their employees to maintain day-to-day operations, including employee safety, workspace, and office supply support. TAS managers with remote employees should develop a relationship with the local manager to ensure issues are addressed promptly and appropriately.


**1.4.13.12.1** **(09-17-2019)**

#### Outgoing Calls

1. Calls to taxpayers will generally be made between the hours of 8:00 a.m. and 6:00 p.m. in the taxpayer's time zone unless a time outside these hours is requested by the taxpayer and falls within the employee’s tour of duty. When the taxpayer makes this request, update the "Best Time to Call" field on TAMIS and notate the taxpayer’s request in the history.


**1.4.13.12.2** **(03-13-2023)**

#### Telephone-based Operations

1. Managers of employees whose primary duty is telephone-based operations (e.g., intake advocates assigned to the CCI organization or a local office) will ensure:



1. Assigned work is consistent with the employee’s position description.

2. Breaks (lunch and other breaks) are consistent with Document 11678, Article 28. Managers will permit impacted employees to adjust their breaks and lunch times in the event that a meeting, other scheduling conflict, or the inability to end assistance to a taxpayer prevents the employee from commencing the break or lunch period at the anticipated time.

3. Read time is scheduled outside of the time the employee is scheduled to answer telephones. Employees will be afforded ten (10) minutes of read time each day. Additional read time may be scheduled at the manager’s discretion.

4. Reasonable time at the start and end of shifts is provided to open and close operations and input time on SETR. Managers will allow ten (10) minutes to open operations and twelve (12) minutes for end of shift activities.


2. CCI is primarily a telephone-based operation. The hours of operation are 6:00 AM ET to 6:00 PM PT. For tour of duty questions, see Document 11678, Article 23.



### Note:



IAs located in Puerto Rico and assigned to the CCI organization are required to maintain a tour of duty that adjusts to Daylight Savings Time. the earliest tour of duty is 6 AM ET.


**1.4.13.12.3** **(03-13-2023)**

#### Office Closures

1. TAS's Business Assessment continuity and contingency planner will coordinate with Communications, Stakeholder Liaison and Online Services to announce office closures and other events.

2. Managers should remind employees to direct any questions about telework during an emergency to the manager, including situations where an office remains open and emergency situations exist that prevent an employee from arriving at work. See Document 11678, Article 36, Section 15, Office Closures and Emergencies, and IRM 6.630.4.5.5.4, Office is Open, but Employee Cannot Report.

3. The appropriate administrative leave OFP codes for weather and safety leave are:




| OFP Code | Description |
| --- | --- |
| 990-59511 | Office Closed, Severe Weather |
| 990-59512 | Office Closed, Other Building Issue |
| 990-59513 | Office Open, Cannot Safely Report |
| 990-59514 | Telework Site Unsafe, Office Closed |
| 990-59515 | Telework Site Unsafe, Office Open |

4. For additional information on Office Closures, see:



1. Office closure information.

2. Document 11678, "Article 50, Section 7, Emergencies" .

3. IRM 6.800.2.

4. Disaster Handbook

5. See TAS Manager Handbook, for additional information concerning Emergency Situations, Occupant Emergency Plans, and Continuity Planning.


**1.4.13.12.4** **(03-13-2023)**

#### Case Advocate Relocations

1. When a CA is relocating to another TAS office, they should be placed in deferral status for two weeks (14 calendar days) prior to the departure from the old office. Recognizing case assignment is best left with the local office management team, TAS encourages managers, to the extent possible, not to assign the departing CA new cases.



### Note:



This includes CAs relocating to another TAS office because they have been hired as a LCA.

2. During the two weeks before departure, the manager of the losing office will work with the CA to identify any cases that will remain with the losing office, and those that will remain with the CA after relocation.

3. The CA will focus their energy on closing cases, and for all cases being reassigned, documenting the TAMIS histories with a summary of past actions and needed future actions.

4. Several factors should be considered in determining which cases should remain with the CA, and which cases should remain with the losing office. Generally, _special cases_ will remain with the losing office, absent mitigating circumstances where it might be in the taxpayer’s best interest to have the case remain with the CA. Examples of _special case_ types are:



   - National Taxpayer Advocate – Headquarters cases (NTA-HQ);

   - SBREFA;

   - Cases where a TAO has been issued; or

   - Cases involving a Congressional Office.


5. The best interest of the taxpayer needs to be at the forefront of the discussion when considering who will retain and work the cases. Also consider if case reassignment could delay resolution or cause undue burden or harm to the taxpayer. In many cases the CA and taxpayer have formed a partnership of trust we should not violate. Examples of situations where the case would be better left with the CA are:



   - The CA has taken substantive and substantial actions; i.e., significant OAR activity.

   - Case reassignment would cause disruption of case processing time.

   - There would be significant _up to speed_ time for the new CA.

   - The case is complex, with multi-faceted issues.

   - Situations where the taxpayer, their representative, or a congressional staffer specifically request to continue with the current CA.



     ### Note:



     Cases with an open OAR can now be transferred between offices by a TAMIS permission level 5 user. If the relocating CA will be retaining a case with an open OAR, the LTA will contact the EDCA-ITS National Workload Balancing and Inventory analysts for assistance.


6. Reassignment of cases should happen prior to the CA’s departure date. This will allow the departing CA time to inform the taxpayer of the reassignment, provide the name and phone number of the CA that will continue to work the taxpayer’s case, and to establish a next contact date.

7. In the event the manager is unable to complete the reassignment prior to the CA’s departure, the CA will provide the taxpayer with their manager’s name, phone number, and a next contact date. The CA will document the discussion with the taxpayer in the TAMIS history.

8. Inventory decisions should include discussions between the losing and gaining LTAs.

9. The losing office must notify the EDCA-ITS Inventory and National Workload Balancing analysts through their area offices. These analysts will determine, in conjunction with the DEDCA and local office, if any special inventory consideration is warranted to mitigate the impact of absorbing open cases on the offices. If the losing office is unable to absorb the inventory remaining with the office, the EDCA-ITS analysts will work with the area to identify an office to take the remaining cases. Inventory should not be reassigned outside the losing office without first consulting these analysts.


**1.4.13.12.5** **(07-16-2021)**

#### Outgoing Recorded Phone Messages

1. Managers will ensure the use of the standardized script for outgoing recorded phone messages for employees having contact with taxpayers as provided in IRM 13.1.6.6(5), Telephone Listings & TAS Answering Machines.


**1.4.13.12.6** **(03-13-2023)**

#### Staffing and Monitoring CCI Incoming Phone Lines

01. Level of Service (LOS) and historical call volume drive the scheduling methodology for CCI. CCI receives incoming English and Spanish calls in two distinct categories:




    | Type of Call | Associated Phone Line |
    | --- | --- |
    | New Cases - Calls from taxpayers requiring the establishment of a new TAS case where fully trained IAs perform the necessary research to determine proper disposition or establishment of a case in TAMIS. | - 788 - NTA English<br>      <br>    - 789 - NTA Spanish |
    | Status Calls on Existing Cases (Express Lane) - Calls from taxpayers who already have an open case in TAS where IAs review an existing case currently open in TAMIS, provide the taxpayer with their CA’s name and contact information, and relay the current status of the case along with recent actions completed by the CA. | - 791 - Express Lane English<br>      <br>    - 792 - Express Lane Spanish |

02. Due to the hierarchical nature of call delivery, IAs need to identify the incoming call type (application) and address calls appropriately using established guidelines and procedures.



    - IAs staffing NTA English (788) receive calls in skill groups 788 (primary) and 791 (secondary).

    - IAs staffing NTA Spanish (789) receive calls in skill groups 789 (primary), 792 (secondary), 788 (tertiary) and 791 (tertiary).

    - IAs staffing an Express Lane skill group only receive Express Lane English (791) or Express Lane Spanish (792).


03. Scheduling Methodology is determined according to the required phone staffing by IAs needed to clear a specific percentage of calls. This is based on a certain level of anticipated call volume and queue time while balancing resources to complete non-NTA work products.




    | Type of Schedule | Description |
    | --- | --- |
    | As REQUIRED – This schedule meets the need of the phone demand and limits non-essential activities (PEAK/All-Hands-On-Deck). | - Typically, CCI peak schedules occur in mid-January through July.<br>      <br>    - The staffing model requires all IAs be assigned to the NTA queue.<br>      <br>    - One IA is assigned to each local TAS phone line.<br>      <br>    - Demand for Non-NTA phone work product is considered by the manager, Department Manager, and System Analyst. |
    | As PLANNED - This schedule encompasses all activities planned for staff (OFF-PEAK). | Typically, CCI planned schedules occur in August through early January. |

04. Non-NTA phone work consists of locally assigned work not associated with the transfer of a call from NTA toll-free assistors through the call routing system. Non-NTA phone work typically involves taxpayer requests for TAS assistance through:



    - Telephone contacts or walk-ins to a TAS office, see IRM 13.1.16.8.3;

    - Correspondence (mail, E-fax, or fax), see IRM 13.1.16.8.4;

    - Referrals from IRS Operating Divisions/Functions, see IRM 13.1.16.8.5;

    - Congressional office contacts, see IRM 13.1.16.8.7; and

    - Other Inquiries, (e.g., Senate Finance Committee, SBREFA), see IRM 13.1.16.8.8.


### Note:

If non-NTA phone work goes beyond the scope of this list, the manager should discuss the activity with the Department Manager and System Analyst to determine whether time can be allotted for work beyond the scope of the list.

05. Inventory days and clean-up events are scheduled on a regular and rotational basis to help CCI sites remain current on non-NTA phone work. The manager, Department Manager, and System Analyst will routinely canvas CCI sites to determine needs and schedule events, as appropriate.

06. Read time is allotted for 60 minutes each week. This time is generally spent on reading and filing activities (e.g., TAS Welcome Screen articles, technical or procedural information, QRIS, IRM, and CABIC updates, work related email, and management directed topics). Read time can be scheduled once a week or in smaller increments (for example, 15 or 30 minute increments) throughout the week. Read time is typically used at the end of a shift.

07. Managers will schedule weekly meeting time for 30 to 60 minutes to focus on clarifying technical, procedural, and administrative topics. Meeting time is typically 30 minutes during peak scheduling and 60 minutes during planned scheduling.

08. Training and self-development time must be scheduled in advance and may be limited during peak scheduling.

09. Managers and System Analysts must determine on a half-hour basis by application staff availability. If less than the required number of IAs sign on, Manager and System Analysts must provide an explanation for the staffing shortfall. For events planned in advance, any projected deficits should be covered with CCI employees. Managers and System Analysts will discuss projected deficits with the Director CCI (or designee) to ensure appropriate telephone coverage. For unplanned everts, e.g., local inclement weather, traffic issues, the site must promptly notify the Director CCI (or designee) of the staffing shortfall.

10. All IAs are required to sign into the Computer Telephony Integrations Object Server (CTIOS) soft telephone system and use Idle Reason Codes. The purpose of IAs signing on CTIOS is to identify in real time the number of employees that are available for assignment to phone or inventory activities. IAs will connect to CTIOS using one of the following methods:




    | Method | Description |
    | --- | --- |
    | Call Center | IAs log on to an extension mobility phone (a separate hard phone sitting in a workstation) to log into CTIOS. |
    | Mobile Agent | IAs connect to Call Manager on CTIOS via a Direct Inward Dialing (DID) phone line. |





    ### Exception:



    IAs who are teleworking use the Mobile Agent configuration and are unable to sign into the CTIOS phone application.

11. IAs will sign into CTIOS at the beginning of their tour of duty (TOD) including periods of overtime.

12. Managers must ensure their employees are signed into CTIOS and taking calls when scheduled. this reduces shrinkage, which is considered unscheduled time away from normal scheduled activities. Examples of shrinkage include:



    - Extended read and meeting times;

    - Tardiness;

    - Leaving early;

    - Higher than expected attrition for the day (e.g., sick leave);

    - Scheduled breaks not followed;

    - Unauthorized breaks;

    - Extended breaks or lunch periods; and

    - Details-out scheduled at peak periods.


13. Idle time consists of those times when employees are signed on the telephone system, but not in the Available, Ready, Wrap, or Out Call status. IAs must use a reason code when in idle status. Idle reason codes determine activity and availability. See IRM 13.1.16.8.6.1, Computer Telephony Integrations Object Server (CTIOS) Soft Telephone System. Idle Reason Codes for IAs are as follows:



    |     |     |     |
    | --- | --- | --- |
    | Reason Code | Reason | Explanation |
    | 1 | Temporarily Off the Telephone | Use this code when you will be unavailable for telephone work for a period of time not specified by other reason codes. For example, time spent inputting SETR, individual meetings with your manager, rest room breaks. IAs should use this code when first signing on CTIOS while waiting for all applications to become available prior to receiving the first call. |
    | 2 | Inventory, First Available | Use this code when you are available for telephone work, if necessary, but your work assignment is local inventory, including related outgoing local line telephone calls. |
    | 3 | Inventory, Second Available | Use this code when you will be available for telephone work only when employees in the Inventory, First Available category, have been used for telephone work and the call demand remains high. |
    | 4 | Training, Partly Available | Use this code when you will be unavailable for telephone work because of training- related activities for a portion of the day. Examples include Partial day off-site training, OJT, or instructor preparation. Do not sign on to the telephone if you will be in training for your entire TOD. |
    | 5 | Read Time | Use this code when you will be unavailable for telephone work during a specified portion of the TOD because of read time. |
    | 6 | Meeting Time | Use this code when you will not be available for telephone work during a specified portion of the TOD because of team meeting time. |
    | 7 | Break Time | Use this code when you will be unavailable for telephone work during a specified portion of the TOD because of a scheduled rest break (other than lunch). |
    | 8 | Lunch Time | Use this code when you will be unavailable for telephone work during a specified portion of the TOD because of a lunch break. |
    | 9 | Stress Break | Use this code when you will be unavailable because of a stressful situation. Use of this code does not require pre-approval. |

14. Managers should ensure all employees assigned to answer calls are at their workstations taking calls as scheduled. Only the Director CCI (or designee) can approve IA exemptions from answering phone calls.

15. System Analysts or Department Managers will notify managers if changes are needed in scheduled staffing approved by the Director CCI (or designee). This may include moving IAs from telephones to do other work.


**1.4.13.12.6.1** **(03-13-2023)**

##### Outgoing Calls

1. IAs may need to make outgoing calls to secure additional information to resolve an inquiry.

2. Managers should monitor the number of outgoing calls to ensure they are necessary.

3. The wrap time for an IA for outgoing calls should be appropriate to the type of call.

4. If an IA needs to make outgoing calls but cannot, contact your local System Analyst for assistance. A Unified Contract Center Enterprise (UCCE) KISAM ticket may need to be opened by the System Analyst.

5. If an IA needs to make outgoing calls on their CTIOS/IPBlue desktop application, they will place themselves in an idle state.



### Exception:



Outcalls to international phone numbers cannot be completed through CTIOS. IAs working these calls will need to use a DID phone line.


**1.4.13.12.6.2** **(03-13-2023)**

##### Telephone System Assistance

1. The System Analysts and Management Program Analysts are a valuable resource person regarding the features of the telephone system.

2. Managers must coordinate with their analyst on any activity limiting the site's ability to deliver its commitment for scheduled telephone staffing.

3. The analyst provides the following:



01. Information about system operations and call routing;

02. Explanation of various telephone reports;

03. Identification of data availability and creating reports;

04. Assessment of current call site performance;

05. Networking information;

06. Monitoring procedures;

07. Assistance with Enterprise Telephone Database (ETD);

08. Telephone equipment repair;

09. Database changes; and

10. Move employees from one agent group/skill group Agent and Reskilling Tool (ART) to another to meet planned staffing requirements and changes in current demand.


4. Managers, Leads, and System Analysts use Cisco Unified Intelligence Center ACEYUS Real Time reporting to monitor call traffic within the CCI offices. The reports in ACEYUS measure how many IAs are staffing the phone lines (English, Spanish and Express Lane) or are in a non-telephone ready state (Idle Reason Codes). Managers use the following two main reports to monitor incoming calls to CCI. See _IRM 1.4.13.12.6.3_, Real Time Reports.



|     |     |
| --- | --- |
| Report | Description |
| Ask TAS Agent Report (ID #5084) | Provides information as to which IA is logged on the phone system and the agent state by each CCI site.<br> <br>   - Monitor specific use of Idle Reason Codes.<br>     <br>   - Identify active call components of Talk, Hold, and Wrap.<br>     <br>   - Determine availability of IAs for phone calls. |
| Ask TAS Call Queue Report (ID #5110) | Provides managers with information concerning the number of calls in the queue, the number of abandoned calls, and the Level of Service provided.<br> <br>   - Gauge telephone traffic demand and determine total number of IAs staffing the phones.<br>     <br>   - To avoid a taxpayer receiving a Voice Call Recording indicating no agents are available, staffing is required in 788 NTA English and 789 NTA Spanish applications during all business hours. |


**1.4.13.12.6.3** **(03-13-2023)**

##### Real Time Reports

1. CCI managers use Aceyus UCCE real-time reports to observe the IA's telephone status immediately after the call ends. Managers can determine the status the IA has selected at the end of the call and the length of time spent in that status. The following configurations may apply:



   - An employee using auto available with conditional wrap will immediately go to available status at the end of each call with a taxpayer unless the employee presses the conditional wrap or idle button prior to the conclusion of the call.

   - If the employee presses the Wrap button during the call, the employee will go into wrap status at the conclusion of the call.

   - If the employee presses the Idle button during the call, the employee will go into idle status at the conclusion of the call and must enter the correct reason code for idle status.


2. CCI managers also use the Aceyus UCCE real-time reports to indicate if an employee might need further monitoring or action. This may include:



   - Monitoring the end of a call exceeding 20 minutes (or locally established time frame) to determine if the issue is being resolved as expeditiously as possible.

   - Checking with employee to see what activity is creating the need to be off-line in wrap time.

   - Identifying an employee with headsets connected, etc., but not in ready mode to take the next call.


3. Managers can design Aceyus UCCE Real Time Reports to:



   - Display call center activity on demand.

   - List IAs and their current telephone status.

   - Display general call information for the application handled by the site or individual.


4. The Aceyus UCCE real time reports assist CCI managers with:



   - Gauging telephone traffic demand.

   - Choosing the most convenient times to monitor or share information with an employee.

   - Confirming the number of IAs who are ready and/or taking calls to provide a complete picture of staff available to meet customer demand.

   - Identifying Emergency alerts in the event an IA presses need immediate assistance.

   - Identifying trends of excessive wrap.


5. The Aceyus UCCE real-time reports show the number of IAs who are actually at their workstations handling incoming calls. This data, compared to the total number assigned, provides information about the realization of the scheduled staff.


**1.4.13.12.6.4** **(03-13-2023)**

##### CTIOS Supervisor Desktop Application

1. The CTIOS Supervisor desktop application gives managers, Leads and System Analysts access to features such as the ability to:



1. View team information and monitor agent activity and IA telephone states/statuses;

2. Logout an IA;

3. Remote Silent Monitoring ;

4. Send an IA notification/message to an IA on the team;

5. Receive visual notification of an emergency event when an IA press the ER toolbar button; and

6. Enroll and access to the IRS Infrastructure Upgrade Project - Endpoint Replacement voicemail system.


2. A manager, Lead or System Analyst may be required to reskill IAs using the ART to meet real-time call demand.



1. IA skill groups are determined by the level of training completed.

2. Each IA is assigned an interpreter pin to use when a language barrier exists. See IRM 13.1.16.4.5, Assisting Taxpayers Speaking a Language Other Than English.


3. Managers should review telephone reports on a regular basis to cover at least the following items:



1. Peak times for calls received and calls abandoned to ensure proper staffing of incoming calls.

2. Average Handle Time (AHT) to include Talk Time, Hold Time and Wrap Time components. See , Average Handle Time.



      ### Note:



      Due to inconsistencies with the VERINT/Workforce Research & Analysis Program (WRAP) calculation, some calls will be missed by quality review coding for WRAP. Until the problem is corrected the reviewer will only review calls with screen capture.

3. Adherence to employee assignment schedule to reduce shrinkage.

4. Employee time utilization to determine productivity levels.


**1.4.13.12.6.5** **(07-16-2021)**

##### Average Handle Time

1. AHT is the sum of average talk, hold and wrap time. AHT helps TAS determine resources needed in TAS to achieve a budget-driven LOS. LOS is a measure used to determine efficiency.

2. Very long talk times can increase the number of abandoned calls. It is usually an indicator that additional training may be needed in conversation control.

3. Managers should identify IAs with excessively long or short times when handling calls. Monitor a few of their calls to identify problems such as:



   - Training deficiency;

   - Failing to keep a call brief while maintaining standards of courtesy and full service;

   - Placing a call on hold during the research process when it is inappropriate instead of arranging for a call back; and

   - Failing to provide a complete or accurate response.


**1.4.13.12.7** **(09-17-2019)**

#### Taxpayer Requests to Speak with a Manager

1. If a caller requests to speak to a supervisor, follow the instructions below:



1. Managers are encouraged to speak with the taxpayer at the time the taxpayer makes the request, if possible.

2. If the manager is not available, the TAS employee will advise the taxpayer and obtain the best time and day to call. The manager will contact the taxpayer as soon as possible.

3. Managers will review the case to determine if there are any questions about what relief is appropriate or the best way to proceed with the case. Managers will consider seeking technical assistance.

4. When speaking with the taxpayers, managers should apologize for any issues or delays caused by TAS, discuss how the case will be handled going forward, and communicate what the taxpayer can expect to happen as the case moves forward.


2. Excessive calls referred for managerial assistance may be an indication of a training issue.


**1.4.13.12.8** **(09-17-2019)**

#### Managing Employees

1. The following sections cover a number of topics that will assist managers with day-to-day operations.


**1.4.13.12.8.1** **(06-15-2023)**

##### Employee Performance File (EPF)

1. The EPF is a system consisting of all performance ratings and other performance-related records maintained on an employee in accordance with 5 CFR 293, Subpart D. For additional information on EPFs, see:



1. IRM 6.430.2.3.5, Employee Performance File (EPF);

2. IRM 6.430.3.4.3, Employee Performance File (EPF);

3. Document 11678, Article 7, Personnel Records;

4. Document 11678, Article 12, Section 9, Evaluative Recordation; and

5. EPF Guide for Managers.


2. All TAS managers will maintain EPFs for all employees within their purview in a timely manner. When an employee moves to another TAS or IRS office, the losing manager will send the EPF to the receiving manager within 30 days of the employee’s departure.


**1.4.13.12.8.2** **(07-16-2021)**

##### Employee Drop File (EDF)

1. In addition to the EPF, a second file should be established for each employee. This is referred to as the drop file. The EDF is for other documentation not related to performance. The EDF should contain anything that is not performance related such as leave counseling and copies of disciplinary actions with the exception of medical documentation. Medical documents are kept in a separate locked file away from the EPF and EDF . If you have any questions about the use of a Drop file, contact your servicing Labor Relations office.

2. All TAS managers will maintain EDFs for all employees within their purview in a timely manner. When an employee moves to another TAS or IRS office, the losing manager will send the EDF to the receiving manager within 30 days of the employee’s departure.


**1.4.13.12.8.3** **(07-16-2021)**

##### Official Personnel File (OPF)

1. The OPF is the employee’s official record of Federal employment. It is a personnel file maintained by the employer that contains records covering an individual’s employment history. The OPF contains long-term records affecting the employee’s status and service as required by the Office of Personnel Management (OPM). See IRM 10.5.6.8.14, Official Personnel Folder (OPF).


**1.4.13.12.8.4** **(07-16-2021)**

##### Medical Documentation

1. Employee medical information must be maintained separately from the EPF and EDF.

2. For more information see IRM 6.630.1.5.4, Safeguarding Medical Information.


**1.4.13.12.8.5** **(03-13-2023)**

##### Time and Attendance

1. TAS managers are responsible for understanding the rules and regulations concerning leave, approving leave requests, ensuring employees understand leave rules and responsibilities, balancing employee needs while maintaining office coverage, performing timekeeping reviews, and validating the accuracy of SETR. Managers having questions about an employee’s use of leave should contact their Labor Relations Specialist.

2. For information on leave-related items, see:



1. Document 11678, Articles 31 through 36;

2. OPM Title 5, Overtime Pay Fact Sheet;

3. IRM 1.2.2.7.9, Delegation Order 6-12 (Rev. 2), Absence and Leave;

4. IRM 6.610.1, Hours of Duty;

5. IRM 6.630.1, IRS Absence and Leave;

6. iManage, Leave; and

7. iManage, Leave Counseling.


**1.4.13.12.8.5.1** **(06-15-2023)**

###### Annual Leave

1. Annual Leave is used for absences from work for events such as vacations, personal business, or emergencies (including illness).

2. Generally, employees must request annual leave in advance for managerial approval. When making approval determinations, managers will consider office coverage. Managers will remind employees in Use or Lose situations to timely schedule and submit leave requests.

3. For additional resources, see:



   - IRM 6.630.1.6.1, Advanced Annual Leave;

   - Document 11678, Article 32, Section 6; and

   - Employee Resources, Annual Leave.


**1.4.13.12.8.5.2** **(06-15-2023)**

###### Sick Leave

1. Sick Leave is used when an employee is absent or incapacitated due to:



   - Physical or mental illness;

   - Injury;

   - Pregnancy;

   - Childbirth;

   - Activities required to adopt a child;

   - Visits to a doctor, optometrist, or dentist; or

   - Exposure to a communicable disease.


### Note:

Employees should request sick leave as far in advance as possible.

2. Managers are responsible for ensuring that employees are using sick time appropriately and requesting a medical certificate from employees (as appropriate), and keeping medical information provided by employees confidential.

3. For additional resources, see:



   - IRM 6.630.1.5, Sick Leave;

   - Document 11678, Article 34; and

   - Employee Resources, Sick Leave.


**1.4.13.12.8.5.3** **(06-15-2023)**

###### Advanced Sick Leave

1. Advanced Sick Leave, employees may request advanced sick leave when all the following conditions are met:



   - The employee is adopting a child, has a serious health condition, or needs to care for a family member with a serious health condition;

   - The employee is eligible to earn sick leave and is not subject to a leave restriction letter;

   - The request (plus any existing advanced sick leave) does not exceed 30 days, or whatever lesser amount complies with applicable regulations (e.g., 104 hours for bereavement leave);

   - There is no reason for the manager to believe the employee will not return back to work after having used the leave; and

   - The employee provides acceptable medical documentation.


2. Managers are responsible for approving advanced sick time (when appropriate), securing medical documentation from the employee, and keeping medical information provided by employees confidential.

3. For additional resources, see:



   - IRM 6.630.1.6.2, Advanced Sick Leave;

   - Document 11678, Article 34; and

   - Employee Resources, Sick Leave.


**1.4.13.12.8.5.4** **(06-15-2023)**

###### Family Leave

1. Family Leave, full-time employees may use a total of 12 weeks of sick leave during any 12 month period to care for a family member with a serious health condition.


    Employees are also granted up to 104 hours of sick leave for general family care purposes, such as bereavement or to care for a family member who is incapacitated by a medical or mental condition or to attend to a family member receiving medical, dental, or optical examinations or treatment.


    Employees must deduct the portion of the 13 days of general family care or bereavement from the 12-week entitlement.

2. Managers are responsible for ensuring that employees are using sick time appropriately and requesting a medical certificate from employees (as appropriate), and keeping medical information provided by employees confidential.

3. For additional resources, see:



   - IRM 6.630.1.9, Family and Medical Leave Act (FMLA);

   - Document 11678, Article 33;

   - Employee Resources, Sick Leave.


**1.4.13.12.8.5.5** **(06-15-2023)**

###### Maternity Leave

1. Maternity Leave, various leave and work scheduling flexibilities are available to assist employees in meeting work and family obligations for maternity purposes. The leave options are available to use separately or in combination to help balance work and family life related to pregnancy, childbirth, bonding with a new baby, adoption, and foster care. The National Defense Authorization Act for Fiscal Year 2020 provides up to 12 weeks of Paid Parental Leave (PPL) in connection with the birth, adoption, or foster care placement of a child for all employees covered by the FMLA, regardless of sex. The new law is effective for employees who invoke FMLA for birth or placement purposes on or after October 1, 2020.



### Note:



Telework is inappropriate for employees to care for family members while working at home or an alternative worksite.

2. Managers are responsible for approving and ensuring that employees are using Maternity Leave appropriately.

3. For additional resources, see:



   - IRM 6.630.1.12, Maternity Leave – Leave Options for Birth, Adoption, and/or Foster Care of a Child, and Additional Flexibilities for Family Purposes;

   - IRM 6.630.5, Leave and Flexibilities for Birth, Adoption, Foster Care, or Child Bereavement;

   - OPM’s Handbook on Leave and Workplace Flexibilities for Childbirth, Adoptions, and Foster Care;

   - Employee Resources, Maternity Leave and Paid Parental Leave (PPL);

   - Document 11678, Article 33, Section 4; and

   - IGM HCO-06-0922-0010, Reissuance of Interim Guidance (IG) on Paid Parental Leave (PPL).


**1.4.13.12.8.5.6** **(06-15-2023)**

###### Leave without Pay

1. LWOP is authorized nonpay status and is entitled for:



   - Disabled veterans needing medical treatment per Executive Order 5396;

   - Employees who invoke and meet the criteria for approval of up to 12 weeks LWOP under the FMLA; and

   - Employees who have filed a claim for job related illness or injury with the U.S. Department of Labor, Office of Workers’ Compensation Program.


2. Separate from FMLA, the IRS allows 24 hours of LWOP per year for specific family-related purposes:



   - School and Early Childhood Educational Activities;

   - Routine Family Medical Purposes; and

   - Elderly Relatives Health or Care Needs.


3. Managers are responsible for approving and ensuring that employees are using LWOP appropriately.

4. For additional information, see



   - IRM 6.630.1.10, Leave Without Pay;

   - Employee Resources, Leave Without Pay (LWOP); and

   - Document 11678, Article 36, Section 15(E), pertaining to LWOP and Office Closures and Emergencies.


**1.4.13.12.8.5.7** **(03-13-2023)**

###### Absence without Leave

1. AWOL is a non-pay status for any absence of duty not officially and properly authorized. AWOL may be changed later to an appropriate type of leave if it is determined that the employee has satisfactorily explained the absence or presented acceptable documentation. AWOL should be charged when an employee:



   - Is absent without permission;

   - Has not notified their manager of the absence in accordance with established procedures; or

   - Has not provided satisfactory documentation or an explanation for absence from duty.


2. Although AWOL is not considered a disciplinary action, it can form the basis for future disciplinary action.

3. Managers will consult with their Labor Relations Specialist prior to putting an employee in AWOL status.

4. For additional resources, see:



   - IRM 6.630.1.13, Absence Without Leave (AWOL).


**1.4.13.12.8.5.8** **(06-15-2023)**

###### Other Leave

1. There are a number of other situations where an employee may be granted leave including:



   - Bone Marrow and Organ Donation Leave;

   - Court Leave;

   - Military Leave;

   - Excused Absence (Administrative Leave);

   - This listing is not all inclusive.


2. Managers are responsible for approving and ensuring that employees are using leave appropriately.

3. For additional resources, see:



   - IRM 6.630.1, IRS Absence and Leave;

   - Document 11678, Article 36; and

   - Employee Resources, Leave.


**1.4.13.13** **(06-13-2025)**

### Reserved

1. Under construction.


**1.4.13.14** **(09-17-2019)**

### Continuity Planning

1. TAS is committed to minimizing the disruption of TAS services in support of the IRS mission under all circumstances as appropriate.


**1.4.13.14.1** **(07-16-2021)**

#### Manager’s Roles and Responsibilities.

1. The NTA and DNTA are responsible for:



1. Ensuring that IRS and TAS continuity policies, guidance, and procedures are implemented and followed.

2. Managing their organization’s day-to-day continuity programs.

3. Ensuring they are capable of carrying out the respective Mission Essential Functions related to continuity operations, including planning, activation, execution, and reconstitution.

4. Planning, programming, and budgeting for continuity capabilities.

5. Ensuring comprehensive and viable continuity plans are developed, exercised, implemented, and maintained.


2. When addressing mission essential functions, the NTA and DNTA are required to:



01. Identify and prioritize the functions within their organization (if any).

02. Identify critical data (vital records) and systems needed to perform each mission essential function.

03. Establish critical resource requirements needed to perform each function.

04. Identify communications systems needed to support each function.

05. Develop recovery or resumption strategies for each identified function.

06. Establish a roster of knowledgeable key personnel to serve on continuity operations or recovery teams.

07. Establish orders of succession to key leadership positions within their organization.

08. Pre-delegate authorities for making policy determinations and decisions within their organization, as appropriate.

09. Establish and periodically (at least annually) test the capability to perform their functions.

10. Ensure that required continuity information is documented in the appropriate continuity plans and procedures.


3. See the TAS Manager Handbook for a detailed discussion.


**1.4.13.15** **(06-15-2023)**

### Security

1. IRM 1.4.6, Managers Security Handbook, sets forth the manager’s security responsibilities.

2. Additional resources are available at:



01. IRM 10.2.1, Physical Security;

02. IRM 10.5.4, Incident Management Program;

03. IRM 10.2.18, Physical Access Control (PAC);

04. IRM 10.8.1, Information Technology (IT) Security;

05. IRM 10.5.4, Incident Management Program;

06. Disclosure and Privacy Knowledge Base;

07. Employee Resources, Employee Security;

08. ERC, IRS Identification Cards;

09. iManage, Health, Safety and Security Category;

10. Employee Resources, Emergency and Safety;

11. Document 13347, Data Breach Response Playbook; and

12. Report Losses, Thefts or Disclosures of Sensitive Data; Report Lost or Stolen IT Assets and BYOD Assets.


**1.4.13.16** **(06-15-2023)**

### Disclosure

1. IRM 11.3, Disclosure of Official Information, provides the instructions, guidelines, and procedures necessary for managers to fulfill their obligations under the disclosure laws.

2. The Disclosure and Privacy Knowledge Base has many tools available to assist TAS employees and managers in understanding and applying their disclosure responsibilities.

3. Additional resources:



1. What is considered PII?;

2. IRM 10.5.4, Incident Management Program;

3. Cyber Security;

4. Incidents involving intentional unauthorized disclosures must be reported to [TIGTA](https://www.treasury.gov/tigta/contact.shtml);

5. IRM 11.3.38.5.1, Reporting Non-willful Inadvertent Disclosures of Sensitive Information, and IRM 11.3.38.5, Reporting of Suspected Willful Unauthorized Accesses or Disclosures.


**Exhibit 1.4.13-1**

### Terms

The following table contains a list of terms used throughout this IRM.

|     |     |
| --- | --- |
| Term | Definition |
| Advocacy | The willingness and ability to see the situation from a taxpayer’s perspective, advocate for the taxpayer’s rights, and assist IRS leadership in integrating the taxpayer’s perspective into tax administration. |
| Case Advocacy | Any employee working to advocate for the taxpayer. (This could include IAs, CAs, LIAs, LCAs, TAGMs, LTAs etc.). |
| Communications | The commitment to engage in clear and open communications, listen to taxpayers and stakeholders, understand their perspectives and issues, educate the taxpayer about the tax system, and effect changes. |
| Competence | The knowledge and ability to understand the taxpayer’s issue and how to resolve it. |
| Confidentiality | The discretion in disclosing certain information to the IRS. |
| Empathy | The understanding of and compassion for the taxpayer’s situation. |
| Improvement | The pursuit of opportunities to improve tax administration for the benefit of taxpayers. |
| Independence | The ability to objectively advocate for the taxpayer separately from the IRS. |
| Internal Controls | The programs, policies, and procedures established to ensure:<br> 1\. Mission and program objectives are efficiently and effectively accomplished;<br> 2\. Program and resources are protected from waste, fraud, abuse, mismanagement, and misappropriation of funds;<br> 3\. Laws and regulations are followed;<br> 4\. Financial reporting is reliable; and<br> 5\. Reliable information is obtained and used for decision making. |
| Leadership 365 | An onboarding, orientation and training program for new TAS leaders in their first year with TAS. |
| Systemic Advocacy | The TAS office whose purpose is to identify areas in which groups of taxpayers are experiencing problems with the IRS and to the extent possible, propose administrative or legislative changes to resolve or mitigate those problems. |
| SAMS | Taxpayer, practitioners, and IRS and TAS employees use SAMS to submit systemic issues to TAS. |
| TBOR | The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see [https://www.irs.gov/taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights). |
| TAMIS | TAS uses TAMIS to record, control, and process cases and to analyze the issues that bring taxpayers to TAS. |
| TARD | The date TAS received the taxpayer’s inquiry. |

**Exhibit 1.4.13-2**

### Acronyms

The following table contains a list of acronyms and their definitions used throughout this IRM.

| Acronym | Definition |
| :-: | :-: |
| \*\*100R\*\* | 100-day with No Action in Last 60 days Literal |
| \*\*365R\*\* | 365+ Days Case Review Literal |
| \*\*AACR\*\* | Area Advocacy Case Review Literal |
| \*\*ACR\*\* | Advocacy Case Review Literal |
| ACE | Advocacy, Communication, and Employee Engagement |
| AGS | Agency Grievance System |
| AHT | Average Handle Time |
| \*\*AMRCR\*\* | Area Analyst Manual Refund Review Literal |
| \*\*AOPR\*\* | Area Operational Case Review Literal |
| ART | Agent and Reskilling Tool |
| ATA | Accounts Technical Advisor |
| AWOL | Absent without Leave |
| BEARS | Business Entitlement Access Request System |
| BFC | Beckley Finance Center |
| BOD | Business Operating Division |
| BOE | Business Objects Enterprise |
| BU | Bargaining Unit |
| CA | Case Advocate |
| CABIC | Case Assistance by Issue Code |
| CATL | Case Advocate Technical Library |
| CATS | Case Advocate Training Support |
| CC | Command Code |
| CCI | Centralized Case Intake |
| CFR | Code of Federal Regulations |
| CJE | Critical Job Element |
| CLP | Career Learning Plan |
| CTIOS | Computer Telephony Integrations Object Server |
| DC | District of Columbia |
| DDIA | Direct Debit Installment Agreement |
| DEDCA | Deputy Executive Director Case Advocacy |
| DEDSA | Deputy Executive Director Systemic Advocacy |
| DID | Direct Inward Dialing |
| DNTA | Deputy National Taxpayer Advocate |
| EDCA | Executive Director Case Advocacy |
| EDCA-ITS | Executive Director Case Advocacy, Intake & Technical Support |
| EDF | Employee Drop File |
| EDSA | Executive Director Systemic Advocacy |
| EFT | Electronic Funds Transfer |
| \*\*EIR\*\* | Early Intervention Review Literal |
| EIR | Early Intervention Review |
| EMT | Erroneous Manual Refund Tool |
| EPF | Employee Performance File |
| ERC | Employee Resource Center |
| FEVS | Federal Employee Viewpoint Survey |
| FLM | Front-Line Manager |
| FLRP | Frontline Leadership Readiness Program |
| FMFIA | Federal Managers’ Financial Integrity Act |
| FMLA | Family Medical Leave Act |
| GAO | Government Accountability Office |
| GS | General Schedule |
| HCO | Human Capital Office |
| HQ | Headquarters |
| HR | Human Resource |
| IA | Intake Advocate |
| \*\*IA MER\*\* | Intake Advocate Monthly Review Literal |
| IAT | Integrated Automation Technologies |
| ICMA | Internal Controls Managerial Assessment |
| IDRS | Integrated Data Retrieval System |
| \*\*IDRSR\*\* | IDRS Online Review Literal |
| IGP | Information Gathering Project |
| IMD | Internal Management Documents |
| IORS | IDRS Online Reports Services |
| IR | Internal Revenue |
| IRC | Internal Revenue Code |
| IT | Information Technology |
| ITAP | Internal Technical Advisor Program |
| ITM | Integrated Talent Management System |
| \*\*ITNHR\*\* | ITAP New Hire Review Literal |
| \*\*ITTAR\*\* | ITAP Technical Accuracy Evaluative Review Literal |
| \*\*ITWLR\*\* | ITAP Workload Evaluative Review Literal |
| LCA | Lead Case Advocate |
| LCAT | Lead Case Advocate Training Specialist |
| LERN | Labor Employee Relations & Negotiations |
| LIA | Lead Intake Advocate |
| \*\*LIA NER\*\* | For LIA reviews, literal for new case receipt or quick closure case review. |
| LLRP | Leading Leaders Readiness Program |
| LOA | Line of Accounting |
| LOS | Level of Service |
| \*\*LTAOVDP\*\* | OVDP Case Review Literal |
| LTA | Local Taxpayer Advocate |
| LSR | Leadership Succession Review |
| LWOP | Leave without Pay or unpaid leave |
| MC ESC | Management Controls Executive Steering Committee |
| \*\*MER\*\* | Case Advocate Review, SBREFA Review Literal |
| MPAF | Maximum Profile Authorization File |
| MRR | Manual Refund Approvals |
| \*\*MRR\*\* | Manual Refund Reviewed and Approved Literal |
| MRTT | Manual Refund Tracking Tool |
| NBU | Non-Bargaining Unit |
| NTA | National Taxpayer Advocate |
| NTA-HQ | National Taxpayer Advocate - Headquarters |
| NTEU | National Treasury Employees Union |
| N-WLB | National Workload Balancing |
| \*\*OAR\*\* | OAR Review Literal |
| OAR | Operations Assistance Request |
| OJI | On-the-Job Instructor |
| \*\*OJI NER\*\* | For coach reviews, literal for new case receipt or quick closure case review. |
| OMB | Office of Management and Budget |
| OPF | Official Personnel File |
| OJT | On-the-Job Training |
| OVDP | Offshore Disclosure Program |
| PCIC | Primary Core Issue Code |
| \*\*PCR\*\* | Pre-Closure Review Literal |
| POD | Post-of-Duty |
| PPL | Paid Parental Leave |
| \*\*QERL\*\* | LCA Review Literal |
| QRIS | Question Resolution Information System |
| RATA | Revenue Agent Technical Advisor |
| SA | Systemic Advocacy |
| SAMS | Systemic Advocacy Management System |
| SBA | Small Business Administration |
| \*\*SBREFA\*\* | SBREFA Case Review Literal |
| SBREFA | Small Business Regulatory Enforcement Fairness Act |
| SETR | Single-Entry Time Reporting |
| SIRE | Systemic Issue Review and Evaluation |
| SME | Subject Matter Expert |
| SPOC | Single Point of Contact |
| TAG | Technical Analysis and Guidance |
| TAGM | Taxpayer Advocate Group Manager |
| TAMIS | Taxpayer Advocate Management Information System |
| TAO | Taxpayer Assistance Order |
| \*\*TAO-D\*\* | TAO Issued at Next Step Literal |
| TAP | Taxpayer Advocacy Panel |
| TARD | Taxpayer Advocate Received Date |
| TAS | Taxpayer Advocate Service |
| TBOR | Taxpayer Bill of Rights |
| TIGTA | Treasury Inspector General for Tax Administration |
| TOD | Tour of Duty |
| UCCE | Unified Contact Center Enterprise |
| UNAX | Unauthorized Access |
| USC | United States Code |
| USR | Unit Security Representative |
| WRAP | Workforce Research & Analysis Program |
| WP&C | Work Planning & Control |

**Exhibit 1.4.13-3**

### TAS Manager Review Schedule

The TAS Manager Review Schedule provides the number of reviews TAS managers will complete each year by review type. For a detailed explanation of how to conduct each review, see _IRM 1.4.13.9.5_, Reviews, and TAS Manager Review Schedule.

**Exhibit 1.4.13-4**

### IDRS MPAF for Case Advocates (Including Lead Case Advocates)

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| ACTON | ADC24 | ADC34 | ADC48 | ADD24 | ADD34 |
| ADD48 | ADJ54 | ADOPT | AMDIS | ATINQ | BMFOL |
| BMFOR | BNCHG | BRTVU | CDPTR | CFINK | CHK64 |
| CHKCL | COMPA | DDBCV | DDBKD | DDBOL | DDPOL |
| DFAST | DLITE | DM1DT | DOALL | DRT24 | DRT48 |
| DTVUE | DUPED | DUPOL | EFTAD | EFTPS | EICMP |
| EICPV | ELFRQ | EMFOL | ENMOD | ENREQ | EOGEN |
| ERINV | ERTVU | ERUTL | ESTAB | FINDE | FINDS |
| FFINQ | FIEMP | FRM34 | FRM49 | FRM77 | FTBOL |
| FTDPN | FTPIN | IADIS | IAGRE | IAORG | IAPND |
| IAREV | ICOMP | IMFOB | IMFOL | IMFOR | INCHG |
| INOLE | INTST | IRCHG | IRPOL | IRPTR | ISTSR |
| LETER | LEVYS | LOCAT | LPAGE | LPAGD | MFREQ |
| MFTRA | NAMEB | NAMEE | NAMEI | NAMES | NOREF |
| P8453 | PATRA | PICRD | PIEST | PIFTD | PIFTF |
| PINEX | PMFOL | R8453 | RECON | REINF | REQ54 |
| REQ77 | RFINK | RFUND | RPINK | RPVUE | RTFTP |
| RTVUE | SCFTR | STAUP | STATB | STATI | SUMRY |
| TDINQ | TELEA | TELEC | TELED | TELER | TERUP |
| TPCIN | TPCOL | TPIIP | TRDBV | TRDPG | TRPRT |
| TSUMY | TXCMP | TXMOD | UNLCE | UPCAS | UPDIS |
| UPRES | UPTIN | URNIQ | VPARS | XSINQ |  |

Revision History for Command Codes:

- Added DFAST on 1/22/2013;

- Added EOGEN on 4/1/2013;

- Added IRPOL on 3/15/2016;

- Added DLITE on 6/11/2018;

- Added TRDPG on 7/27/2019;

- On 2/23/2022, changed the MPAF from applying to all TAS IDRS users to applying to only Case Advocates and created new MPAFs for all other positions. Removed the following Command Codes (CCs) as a result of an IDRS Risk Assessment: ASGNB, ASGNI, EFTNT, IADFL, LEVYD, LEVYE, LEVYM, LEVYR, TDIRQ, and TSIGN; and

- Removed EFTOF on 9/7/2023, TAS employees do not have the delegated authority to input skip payments on Direct Debit Installment Agreements (DDIAs), since this CC is solely used to input skip payments for DDIAs it has been removed.


**Exhibit 1.4.13-5**

### IDRS MPAF for Intake Advocates (Including Lead Intake Advocates)

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| ACTON | ADJ54 | ADOPT | AMDIS | ATINQ | BMFOL |
| BMFOR | BNCHG | BRTVU | CDPTR | CFINK | CHK64 |
| CHKCL | DDBCV | DDBKD | DDBOL | DDPOL | DFAST |
| DLITE | DOALL | DTVUE | DUPOL | EFTAD | EFTPS |
| EICMP | EICPV | ELFRQ | EMFOL | ENMOD | ENREQ |
| EOGEN | ERINV | ERTVU | ERUTL | ESTAB | FINDE |
| FINDS | FFINQ | FIEMP | FTBOL | FTPIN | IADIS |
| IAGRE | IAORG | IAPND | IAREV | ICOMP | IMFOB |
| IMFOL | IMFOR | INCHG | INOLE | INTST | IRCHG |
| IRPOL | IRPTR | ISTSR | LETER | LEVYS | LOCAT |
| LPAGE | LPAGD | MFREQ | MFTRA | NAMEB | NAMEE |
| NAMEEI | NAMES | P8453 | PATRA | PICRD | PIEST |
| PIFTD | PIFTF | PINEX | PMFOL | R8453 | RECON |
| REINF | REQ54 | RFINK | RPINK | RPVUE | RPFTP |
| RTVUE | SCFTR | STAUP | STATB | STATI | SUMRY |
| TDINQ | TELER | TERUP | TPCIN | TPCOL | TPIIP |
| TRDBV | TRDPG | TRPRT | TSUMY | TXCMP | TXMOD |
| UNLCE | UPCAS | UPDIS | UPTIN | URINQ | VPARS |
| XSINQ |  |  |  |  |  |

**Exhibit 1.4.13-6**

### IDRS MPAF for Secretaries, Management Assistants, Program Analysts, Management Program Analysts, Tax Analysts, Systems Analysts, Case Advocacy Specialists, and Technical Advisors

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| ACTON | ADOPT | AMDIS | ATINQ | BMFOL | BMFOR |
| BRTVU | CDPTR | CFINK | COMPA | DDBCV | DDBKD |
| DDBOL | DDPOL | DFAST | DLITE | DOALL | DTVUE |
| DUPOL | EFTAD | EFTPS | EICMP | EICPV | ELFRQ |
| EMFOL | ENMOD | EOGEN | ERINV | ERTVU | ERUTL |
| ESTAB | FINDE | FINDS | FFINQ | FIEMP | FTBOL |
| FTPIN | IADIS | ICOMP | IMFOB | IMFOL | IMFOR |
| INOLE | INTST | IRPOL | IRPTR | ISTSR | LETER |
| LEVYS | LOCAT | LPAGE | LPAGD | MFREQ | MFTRA |
| NAMEB | NAMEE | NAMEI | NAMES | P8453 | PATRA |
| PICRD | PIEST | PIFTD | PIFTF | PINEX | PMFOL |
| R8453 | RECON | REINF | RFINK | RPINK | RPVUE |
| RPFTP | RTVUE | SCFTR | STAUP | STATB | STATI |
| SUMRY | TDINQ | TELER | TPCIN | TPCOL | TPIIP |
| TRDBV | TRDPG | TRPRT | TSUMY | TXCMP | TXMOD |
| UNLCE | UPCAS | UPDIS | UPTIN | URINQ | VPARS |
| XSINQ |  |  |  |  |  |

**Exhibit 1.4.13-7**

### IDRS MPAF for Quality Analysts

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| ACTON | ADOPT | AMDIS | ATINQ | BMFOL | BMFOR |
| BRTVU | CDPTR | CFINK | COMPA | DDBCV | DDBKD |
| DDBOL | DDPOL | DFAST | DLITE | DTVUE | DUPOL |
| EFTAD | EFTPS | EICMP | EICPV | ELFRQ | EMFOL |
| ENMOD | EOGEN | ERINV | ERTVU | ERUTL | ESTAB |
| FINDE | FINDS | FFINQ | FIEMP | FTBOL | FTDPN |
| FTPIN | IADIS | ICOMP | IMFOL | IMFOR | INOLE |
| INTST | IRPOL | IRPTR | ISTSR | LEVYS | LOCAT |
| MFTRA | NAMEB | NAMEE | NAMEI | NAMES | P8453 |
| PATRA | PICRD | PIEST | PIFTD | PIFTF | PINEX |
| PMFOL | R8453 | REINF | RFINK | RPINK | RPVUE |
| RPFTP | RTVUE | SCFTR | SUMRY | TDINQ | TPIIP |
| TRDBV | TRDPG | TRPRT | TSUMY | TXCMP | TXMOD |
| UPTIN | URINQ | XSINQ |  |  |  |

**Exhibit 1.4.13-8**

### IDRS MPAF for TAS Managers

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| ACTON | ADOPT | AMDIS | ATINQ | BMFOL | BMFOR |
| BRTVU | CDPTR | CFINK | COMPA | DDBCV | DDBKD |
| DDBOL | DDPOL | DFAST | DLITE | DOALL | DTVUE |
| DUPOL | EFTAD | EFTPS | EICMP | EICPV | EMFOL |
| ENMOD | EOGEN | ERINV | ERTVU | ERUTL | ESTAB |
| FINDE | FINDS | FFINQ | FIEMP | FTBOL | FTPIN |
| IADIS | ICOMP | IMFOB | IMFOL | IMFOR | INOLE |
| INTST | IRPOL | IRPTR | ISTSR | LETER | LEVYS |
| LOCAT | LPAGE | LPAGD | MFREQ | MFTRA | NAMEB |
| NAMEE | NAMEI | NAMES | P8453 | PATRA | PICRD |
| PIEST | PIFTD | PIFTF | PINEX | PMFOL | R8453 |
| RECON | REINF | RFINK | RPINK | RPVUE | RPFTP |
| RTVUE | SCFTR | STAUP | STATB | STATI | SUMRY |
| TDINQ | TELER | TPCIN | TPCOL | TPIIP | TRDBV |
| TRDPG | TRPRT | TSUMY | TXCMP | TXMOD | UNLCE |
| UPCAS | UPDIS | UPTIN | URINQ | VPARS | XSINQ |

**Exhibit 1.4.13-9**

### Command Codes for IDRS Online Reviews of Account Adjustments

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| QRACN | QRADD | QRIND | QRNCH | RVIEW |

**Exhibit 1.4.13-10**

### Security Command Codes for Unit Security Representatives

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
| MRINQ | REPTS | RSTRK | SECOP | SFINQ | UPEMP |
| UPTRM |  |  |  |  |  |

**Exhibit 1.4.13-11**

### Security Command Codes for Terminal Security Administrators

|     |     |
| --- | --- |
| SECOP | UNLEM |

**Exhibit 1.4.13-12**

### IDRS Multiple Access Approval Table

TAS employees with adjustment CCs, including CC STAUP, is required to CMODE out of Andover to the designated IMF and BMF office. The user must have the Null feature set to "On" .

| TAS Function | IDRS Unit Number | Multiple Access | Campus for Manual Refunds |
| --- | --- | --- | --- |
| TAS USRs | 63110 | Any | N/A |
| 1 - DEDCA | 63100 | Any | N/A |
| 1 - Albany | 63165 | BR and FR | KC and OG |
| 1 - Andover | 63850, 63861, 63862, 63863 | KC and PH | KC and OG |
| 1 - Augusta | 63851 | KC and PH | KC and OG |
| 1 - Boston | 63856 | KC and PH | KC and OG |
| 1 - Brookhaven | 63131 - 63134 | BR, CI, and FR | KC and OG |
| 1 - Brooklyn | 63170 | BR, CI, and FR | KC and OG |
| 1 - Buffalo | 63181 | CI and FR | KC and OG |
| 1 - Burlington | 63855 | KC and PH | KC and OG |
| 1 - Hartford | 63859 | KC and PH | KC and OG |
| 1 - Manhattan | 63190 - 63191 | BR and FR | KC and OG |
| 1 - Portsmouth | 63854 | KC and PH | KC and OG |
| 1 - Providence | 63857 | KC and PH | KC and OG |
| 1 - Reserved | 63880 | N/A | N/A |
| 2 - DEDCA | 63200 | Any | N/A |
| 2 - Baltimore | 63231 - 63232 | AT, OG, and PH | KC and OG |
| 2 - Charlotte | 63259 | OG and PH | KC and OG |
| 2 - Greensboro | 63211 | AT and PH | KC and OG |
| 2 - Newark DE | 63270 | AT, CI, OG, and PH | KC and OG |
| 2 - Philadelphia | 63252 - 63254 | OG and PH | KC and OG |
| 2 - Pittsburgh | 63260 | AT, OG, and PH | KC and OG |
| 2 - Richmond | 63220 | AT and PH | KC and OG |
| 2 - Springfield NJ | 63140 | AT, CI, and PH | KC and OG |
| 2 - Trenton NJ | 63241 | AT, CI, and PH | KC and OG |
| 3 - DEDCA | 63300 | Any | N/A |
| 3 - Atlanta City Center | 63301 - 63304 | AU, CI, and ME | KC and OG |
| 3 - Birmingham | 63311, 63331 | AU and ME | KC and OG |
| 3 - Columbia SC | 63201 | AT and PH | KC and OG |
| 3 - Jacksonville | 63330 - 63334 | AU, CI, and ME | KC and OG |
| 3 - Ft. Lauderdale | 63371 - 63372 | AU, AT, CI, and ME | KC and OG |
| 3 - Puerto Rico | 63171 - 63173 | OG and PH | KC and OG |
| 3 - St. Petersburg | 63373 | AU, AT, CI, and ME | KC and OG |
| 4 - DEDCA | 63400 | Any | N/A |
| 4 - Cincinnati | 63440 | CI and KC | KC and OG |
| 4 - Cleveland | 63450 - 63452 | CI and KC | KC and OG |
| 4 - Covington | 63343 | CI and KC | KC and OG |
| 4 - Detroit | 63410 - 63420 | CI and KC | KC and OG |
| 4 - Indianapolis | 63461 - 63463 | CI and KC | KC and OG |
| 4 - Louisville | 63470 | CI and KC | KC and OG |
| 4 - Memphis | 63482 - 63483 | KC and ME | KC and OG |
| 4 - Nashville | 63490 - 63491 | CI and KC | KC and OG |
| 4 - West Virginia | 63480 | CI and KC | KC and OG |
| 4 - Reserved | 63487 | N/A | N/A |
| 5 - DEDCA | 63500 | Any | N/A |
| 5 - Austin | 63511, 63514, 63518 | AU and ME | KC and OG |
| 5 - Dallas | 63520 - 63524 | AU and ME | KC and OG |
| 5 - El Paso | 63510 | FR and OG | KC and OG |
| 5 - Houston | 63501, 63503, 63504 | AU and ME | KC and OG |
| 5 - Jackson | 63321 | AU and ME | KC and OG |
| 5 - Little Rock | 63350 | AU and ME | KC and OG |
| 5 - New Orleans | 63355 - 63356 | AU, CI, and ME | KC and OG |
| 5 - Oklahoma City | 63630, 63531 | FR and OG | KC and OG |
| 6 - DEDCA | 63600 | Any | N/A |
| 6 - Aberdeen | 63655 | FR and OG | KC and OG |
| 6 - Chicago | 63806 - 63807 | KC and ME | KC and OG |
| 6 - Des Moines | 83826 | AU and ME | KC and OG |
| 6 - Fargo | 63648 | FR and OG | KC and OG |
| 6 - Kansas City | 63803 - 63805, 63808 - 63809 | KC and ME | AU, KC, and OG |
| 6 - Milwaukee | 63809 | CI and KC | KC and OG |
| 6 - Sioux Falls | 63655 | FR and OG | KC and OG |
| 6 - Springfield, IL | 63808 | CI and KC | KC and OG |
| 6 - St. Louis | 63828 - 63829 | AU and ME | KC and OG |
| 6 - St. Paul | 63810 | AU and ME | KC and OG |
| 6 - Wichita | 63831 | FR and OG | KC and OG |
| 7 - DEDCA | 63700 | Any | N/A |
| 7 - Albuquerque | 63507 | FR and OG | KC and OG |
| 7 - Boise | 63630 | FR and OG | KC and OG |
| 7 - Cheyenne | 63610 | FR and OG | KC and OG |
| 7 - Denver | 63540 - 63542 | FR and OG | KC and OG |
| 7 - Helena | 63640 | FR and OG | KC and OG |
| 7 - Las Vegas | 63775 | FR and OG | KC and OG |
| 7 - Ogden | 63691 - 63694 | FR and OG | KC and OG |
| 7 - Omaha | 63830 | AU and OG | AU and OG |
| 7 - Phoenix | 63560 | FR and OG | KC and OG |
| 7 - Reserved | 63601 | N/A | N/A |
| 7 - Reserved | 63660 | N/A | N/A |
| 8 - DEDCA | 63800 | Any | N/A |
| 8 - Anchorage | 63795 | FR and OG | KC and OG |
| 8 - Fresno (LTA) | 63751 - 63753 | FR and OG | KC and OG |
| 8 - Honolulu | 63750 | FR and OG | KC and OG |
| 8 - Laguna Niguel | 63741 - 63742 | FR and OG | KC and OG |
| 8 - Los Angeles | 63702 - 63704 | FR and OG | KC and OG |
| 8 - Oakland | 63711 | FR and OG | KC and OG |
| 8 - Portland | 63670 | FR and OG | KC and OG |
| 8 - Sacramento | 63721 | FR and OG | KC and OG |
| 8 - San Diego | 63732 | FR and OG | KC and OG |
| 8 - San Jose | 63730 | FR and OG | KC and OG |
| 8 - Seattle | 63686, 63689 | FR and OG | KC and OG |
| DC LTA | 63101 | AT and PH | KC and OG |
| EDCA-ITS, CCI - Managers | 63380 | Any | N/A |
| EDCA-ITS, CCI -Covington KY | 63376 and 63388 | Any | N/A |
| EDCA-ITS, CCI - Dallas | 63384 - 63385, 63402 | Any | N/A |
| EDCA-ITS, CCI - Fresno | 63381 - 63382 | Any | N/A |
| EDCA-ITS, CCI - Memphis | 63386 - 63387, 63345 | Any | N/A |
| EDCA-ITS, CCI - Ogden | 63383, 63403 | Any | N/A |
| EDCA-ITS, CCI - Puerto Rico | 63389, 63401 | Any | N/A |
| EDCA-ITS, CCI - St. Louis | 63379 | Any | N/A |
| EDCA-ITS, CCI - Seattle | 63377 - 63378 | Any | N/A |
| EDSA | 63113, 63811, 63813 | Any | N/A |
| ITAP | 63120 - 63126, 63822 | Any | N/A |
| LCATS | 63394 - 63397 | Any | KC and OG |
| Quality Review Program | 63710, 63713 - 63714 | Any | N/A |
| TAG | 63102 | Any | N/A |

Below is a key of the acronyms used in the Multiple Access and Campus for Manual Refunds columns in the table above.

| Acronym | Campus |
| --- | --- |
| AT | Atlanta |
| AU | Austin |
| BR | Brookhaven |
| CI | Cincinnati |
| FR | Fresno |
| KC | Kansas City |
| ME | Memphis |
| OG | Ogden |
| PH | Philadelphia |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-013#addtoany "Show all")

A2A