---
url: "https://www.irs.gov/irm/part1/irm_01-001-028"
title: "1.1.28 Return Preparer Office | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-028#main-content)

- 1.1.28  [Return Preparer Office](https://www.irs.gov/irm/part1/irm_01-001-028#id1)
  - 1.1.28.1  [Introduction to the Return Preparer Office](https://www.irs.gov/irm/part1/irm_01-001-028#id2)
  - 1.1.28.2  [Return Preparer Office Strategic Goals](https://www.irs.gov/irm/part1/irm_01-001-028#id3)
  - 1.1.28.3  [Return Preparer Office Continuity Plan](https://www.irs.gov/irm/part1/irm_01-001-028#id4)
  - 1.1.28.4  [Office of the Director](https://www.irs.gov/irm/part1/irm_01-001-028#id5)

    - 1.1.28.4.1  [Strategy and Finance](https://www.irs.gov/irm/part1/irm_01-001-028#id7)
    - 1.1.28.4.2  [Vendor Processes and Business Requirements](https://www.irs.gov/irm/part1/irm_01-001-028#id8)
    - 1.1.28.4.3  [Competency and Standards](https://www.irs.gov/irm/part1/irm_01-001-028#id9)
    - 1.1.28.4.4  [Compliance](https://www.irs.gov/irm/part1/irm_01-001-028#id10)
    - 1.1.28.4.5  [Return Preparer Suitability](https://www.irs.gov/irm/part1/irm_01-001-028#id11)
    - 1.1.28.4.6  [Enrolled Agent Policy and Management](https://www.irs.gov/irm/part1/irm_01-001-028#id12)
    - 1.1.28.4.7  [Joint Board for the Enrollment of Actuaries](https://www.irs.gov/irm/part1/irm_01-001-028#id13)

  - Exhibit  1.1.28-1  [Return Preparer Office Organizational Chart](https://www.irs.gov/irm/part1/irm_01-001-028#id14)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 28. Return Preparer Office

* * *

## 1.1.28 Return Preparer Office

#### Manual Transmittal

May 06, 2026

#### Purpose

(1) This transmits revised IRM 1.1.28, Organization and Staffing, Return Preparer Office.

#### Material Changes

(1) The following changes were made in this section:

- Changed Director’s name.

- IRM 1.1.28.2 Revised strategic goals.

- Updated responsibilities for each department.

- 1.1.28-1 Revised the Organizational Chart.


#### Effect on Other Documents

IRM 1.1.28 dated May 21, 2021, is superseded.

#### Audience

All IRS Business Divisions

#### Effective Date

(05-06-2026)

Christopher J. Pleffner

Director, Return Preparer Office

**1.1.28.1** **(05-21-2021)**

### Introduction to the Return Preparer Office

1. The Return Preparer Office is responsible for matters relating to the registration, renewal and compliance of return preparers who prepare tax returns for compensation. Responsibilities include but are not limited to:



   - Issuing and renewing Preparer Tax Identification Numbers (PTINs),

   - Managing the enrolled practitioner program,

   - Administering the Enrolled Agent - Special Enrollment Exam, Annual Filing Season Program, Enrolled Actuary Program and Conducting Disciplinary Proceedings,

   - Making suitability determinations,

   - Processing complaints against return preparers,

   - Ensuring programmatic compliance by return preparers,

   - Coordinating with other business units regarding identified noncompliance, and

   - Researching the effectiveness of return preparer treatments on overall compliance.


2. The Return Preparer Office’s mission is to improve taxpayer compliance by ensuring minimum standards for tax professionals and providing them with ongoing support.

3. The Return Preparer Office’s vision is to foster a community of professional tax practitioners working with the IRS to improve tax administration

4. The Return Preparer Office is comprised of an Office of the Director and the following seven departments:



   - Strategy and Finance

   - Vendor Processes and Business Requirements

   - Competency and Standards

   - Compliance

   - Return Preparer Suitability

   - Enrolled Agent Policy and Management

   - Joint Board for the Enrollment of Actuaries


**1.1.28.2** **(05-06-2026)**

### Return Preparer Office Strategic Goals

1. Protect the integrity of the tax system by developing robust compliance processes and expanding enforcement in areas where coverage has declined.

2. Ensure programmatic compliance by promoting and registering qualified tax professionals

3. Support stakeholder engagement and preparer competence by encouraging enrollment in voluntary credentialing programs.

4. Modernize systems and processes to improve self-service options and ensure employees have the right tools.


**1.1.28.3** **(05-06-2026)**

### Return Preparer Office Continuity Plan

1. The Return Preparer Office maintains an updated Continuity Plan to ensure its operations are performed efficiently with minimal disruption.

2. If normal communications are disrupted, the Return Preparer Office will activate its order of succession in a non-impacted area.

3. If an incumbent is incapable or unavailable to fulfill essential duties, the successors shown in _IRM 1.1.28.3 (4)_ will have the right to make decisions on behalf of the Return Preparer Office.

4. The order of succession for the Director, Return Preparer Office, is as follows:



1. 1st successor: Director, Return Preparer Office, Strategy and Finance

2. 2nd successor: Director, Return Preparer Office, Vendor Processes and Business Requirements

3. 3rd successor: Director, Return Preparer Office, Suitability


**1.1.28.4** **(05-06-2026)**

### Office of the Director

1. The mission of the Office of the Director is to provide executive leadership, strategic direction and policy oversight to the Return Preparer Office departments.

2. The Director of the Return Preparer Office reports to the Chief, Tax Compliance Officer. The Director is responsible for:



1. Supervising and coordinating Return Preparer Office activities in accordance with its strategic goals.

2. Establishing operational policies for the Return Preparer Office.

3. Supporting the departments in defining and delivering current program responsibilities; engaging and developing personnel; and ensuring prospective program planning.

4. Strengthening partnerships with the tax professional community and stakeholders to ensure effective tax administration.

5. Identifying potential risks that could impact the Return Preparer Office and developing mitigation plans.

6. Develop and execute comprehensive communications strategies aligned with organizational goals.

7. Create and manage communication products to promote organizational initiatives and events, oversee internal communications to ensure consistent messaging across channels and departments.


**1.1.28.4.1** **(05-06-2026)**

#### Strategy and Finance

1. The mission of the Strategy and Finance department is to develop and execute the Return Preparer Office staffing plan, manage its funding model and budgets, and administer its policies and procedures.

2. The Director, Strategy and Finance, reports to the Director, Return Preparer Office, and is responsible for:



01. Strategic planning.

02. Budgeting.

03. Financial forecasting.

04. Organizing spending plans.

05. Providing and coordinating training.

06. Supporting personnel and labor relations.

07. Measuring departmental and operational performance.

08. Responding to external auditors.

09. Responding to requests under the Freedom of Information Act.

10. Resolving issues identified via Commissioner and Congressional correspondence.

11. Performing quality and operational reviews.

12. Overseeing the Return Preparer Office’s RIsk Management activities.


**1.1.28.4.2** **(05-06-2026)**

#### Vendor Processes and Business Requirements

1. The mission of the Vendor Processes and Business Requirements department is to provide oversight of all Return Preparer Office activities outsourced to third-party vendors, manage the office’s information technology needs, oversee security, and provide contract management oversight through the Contracting Officer Representatives.

2. The Director, Vendor Processes and Business Requirements, reports to the Director, Return Preparer Office, and is responsible for:



1. Administering the PTIN registration and renewal program, and the Annual Filing Season Program.

2. Overseeing the PTIN vendor contract.

3. Managing the IT Security and (FISMA) activities for RPO Systems.

4. Security Program Managment Officer (SPMO) activities - IT security, IRM 10.8.1; FISMA and (NIST) 800-53 compliance throughout RPO’s systems and business operations.

5. Developing and maintaining systems used by the Return Preparer Office, including One Solution Development Lifecycle (SDLC) activities and Section 508 compliance.

6. Planning and managing business systems requirements.

7. Overseeing the Return Preparer Office‘s Case Management Program.

8. Overseeing the Return Preparer Office’s Business Systems Planning program.


**1.1.28.4.3** **(05-06-2026)**

#### Competency and Standards

1. The mission of the Competency and Standards department is to provide program oversight and guidance for the development and administration of both the Enrolled Agent - Special Enrollment Examination and the Continuing Education program.

2. The Director, Competency and Standards, reports to the Director, Return Preparer Office, and is responsible for:



1. Managing the Special Enrollment Examination and Continuing Education provider system vendor relationships and contracts.

2. Overseeing of the Enrolled Agent Special Enrollment Exam and Continuing Education vendor contracts.

3. Managing the contractor security clearance/background investigation process for the Enrolled Agent Special Enrollment Examination vendor contract.

4. Overseeing development and administration of the Enrolled Agent Special Enrollment Examination.

5. Overseeing the Continuing Education provider application approval and renewal processes, including completing compliance reviews for new and established Continuing Education programs and facilitating the delivery of quality continuing education.

6. Developing the Annual Federal Tax Refresher course outline and test parameters for the Annual Filing Season Program, processing Annual Filing Season Program appeals, and conducting reviews of Annual Federal Tax Refresher courses offered by Continuing Education providers.

7. Maintaining regular communication and collaboration with Enrolled Agent - Special Enrollment Exam candidates and the Continuing Education provider community regarding program developments and related issues.


**1.1.28.4.4** **(05-06-2026)**

#### Compliance

1. The mission of the Compliance department is to address return preparer program and PTIN noncompliance, and process complaints involving compensated return preparers. Compliance identifies and develops treatments and referral criteria for varying types of return preparer noncompliance.

2. The Director, Compliance, reports to the Director, Return Preparer Office, and is responsible for:



1. Evaluating and treating preparers who are not complying with PTIN program or personal tax requirements.

2. Developing referrals to other IRS business units for habitual non-compliance with PTIN requirements or personal tax obligations.

3. Evaluating and processing complaints against return preparers.

4. Supporting return preparer programs in other IRS business units.


**1.1.28.4.5** **(05-06-2026)**

#### Return Preparer Suitability

1. The mission of the Suitability department is to perform suitability checks and determine program eligibility of certain individuals who apply for a Preparer Tax Identification Number or for enrollment to practice before the IRS.

2. The Director, Return Preparer Suitability, reports to the Director, Return Preparer Office, and is responsible for:



1. Conducting personal tax compliance checks.

2. Reviewing reported professional designations.

3. Conducting criminal background checks.

4. Ensuring persons incarcerated or enjoined are not preparing tax returns

5. Preparing referrals for necessary disciplinary action.

6. Performing the review of Specially Designated Nationals.

7. Processing individual return preparers referred for a suitability check.


**1.1.28.4.6** **(05-06-2026)**

#### Enrolled Agent Policy and Management

1. The mission of the Enrolled Agent Policy and Management department is to provide oversight, management and subject matter expertise for the enrolled practitioner program.

2. The Director, Enrolled Agent Policy and Management, reports to the Director, Return Preparer Office, and is responsible for:



1. Processing applications and renewals for Enrolled Agents and renewals for Enrolled Retirement Plan Agents.

2. Ensuring compliance with PTIN and Continuing Education annual requirements.

3. Conducting audit of continuing education requirements.

4. Evaluating and updating enrollment status for public facing directory and Freedom Of Informtion Act reporting.

5. Providing toll-free telephone service for enrolled practitioners.

6. Establishing, revising and maintaining currency of documents and procedures in support of PTIN registration, renewal and call center operations.


**1.1.28.4.7** **(05-06-2026)**

#### Joint Board for the Enrollment of Actuaries

1. The mission of the Joint Board for the Enrollment of Actuaries department is to provide administrative and legal support to the Joint Board for the Enrollment of Actuaries, which is responsible for establishing reasonable standards and qualifications for persons performing actuarial services for plans subject to the Employee Retirement Income Security Act of 1974.

2. The Executive Director, Joint Board for the Enrollment of Actuaries, reports to the Director, Return Preparer Office, and is responsible for:



1. Processing applications and renewals for Enrolled Actuaries.

2. Recognizing organizations approved as a Qualifying Sponsor of Continuing Education credit.

3. Maintaining records for Enrolled Actuaries and Qualifying Sponsors.

4. Conducting audits of Enrolled Actuary Continuing Education as well as Qualifying Sponsor programs to ensure compliance with the Joint Board regulations.

5. Providing administrative support to the Joint Board’s Advisory Committee on Actuarial Examinations, which is responsible for preparing the three enrollment examinations administered by the Joint Board.

6. Ensuring that the Advisory Committee on Actuarial Examinations complies with the Federal Advisory Committee Act.

7. Monitoring the conduct of Enrolled Actuaries and initiating disciplinary cases before an administrative law judge when necessary.

8. Acting as the appellate authority of Annual Filing Season Program denials requesting appeal under Rev. Proc 2014-42.


**Exhibit 1.1.28-1**

### Return Preparer Office Organizational Chart

![This is an Image: 59791002.gif](https://www.irs.gov/pub/xml_bc/59791002.gif)

> Description: This chart lists the Office of the Director and the Director’s staff, followed by the seven Return Preparer Office Departments: Joint Board for Enrollment Actuaries: Acting Director, Theresa WellonsEnrolled Agent Policy & Management: Acting Director, Theresa WellonsStrategy & Finance: Acting Director, Nicholas SampsonSuitability: Director, Kevin KingCompliance: Acting Director, Paul DelongVendor Processes & Business Requirements: Acting Director, Michael CannonCompetency & Standards: Acting Director, Michael Cannon

[Please click here for the text description of the image.](https://www.irs.gov/media/460596 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-028#addtoany "Show all")

A2A