---
url: "https://www.irs.gov/irm/part1/irm_01-004-040"
title: "1.4.40 SB/SE Field and Office Examination Group Manager | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-040#main-content)

- 1.4.40  [SB/SE Field and Office Examination Group Manager](https://www.irs.gov/irm/part1/irm_01-004-040#id1)
  - 1.4.40.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-040#id2)
    - 1.4.40.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-040#id4)
    - 1.4.40.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-040#id5)
    - 1.4.40.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-040#id6)
    - 1.4.40.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-040#id7)
    - 1.4.40.1.5  [Terms](https://www.irs.gov/irm/part1/irm_01-004-040#id8)
    - 1.4.40.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-040#id9)
    - 1.4.40.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-040#id10)
    - 1.4.40.1.8  [Operating Divisions](https://www.irs.gov/irm/part1/irm_01-004-040#id11)
  - 1.4.40.2  [SB/SE Operating Units](https://www.irs.gov/irm/part1/irm_01-004-040#id12)
  - 1.4.40.3  [Role](https://www.irs.gov/irm/part1/irm_01-004-040#id13)
    - 1.4.40.3.1  [Role of a Group Manager](https://www.irs.gov/irm/part1/irm_01-004-040#id14)
    - 1.4.40.3.2  [Balanced Measures](https://www.irs.gov/irm/part1/irm_01-004-040#id15)
    - 1.4.40.3.3  [Accomplishments](https://www.irs.gov/irm/part1/irm_01-004-040#id16)
    - 1.4.40.3.4  [Managing Statistics](https://www.irs.gov/irm/part1/irm_01-004-040#id17)
    - 1.4.40.3.5  [Annual Examination Goals](https://www.irs.gov/irm/part1/irm_01-004-040#id18)
    - 1.4.40.3.6  [Performance Feedback](https://www.irs.gov/irm/part1/irm_01-004-040#id19)
    - 1.4.40.3.7  [Dealing with Taxpayers and External Customers](https://www.irs.gov/irm/part1/irm_01-004-040#id20)
      - 1.4.40.3.7.1  [Taxpayer Concerns or Complaints](https://www.irs.gov/irm/part1/irm_01-004-040#id22)
      - 1.4.40.3.7.2  [Management Responsibility Regarding Right of Consultation](https://www.irs.gov/irm/part1/irm_01-004-040#id23)
      - 1.4.40.3.7.3  [Procrastinating Taxpayers and Representatives](https://www.irs.gov/irm/part1/irm_01-004-040#id24)
      - 1.4.40.3.7.4  [By-Pass of a Representative](https://www.irs.gov/irm/part1/irm_01-004-040#id25)
    - 1.4.40.3.8  [Time Accounting Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-040#id26)
    - 1.4.40.3.9  [Acting Manager Assignments and Designations](https://www.irs.gov/irm/part1/irm_01-004-040#id27)
  - 1.4.40.4  [Workload Planning](https://www.irs.gov/irm/part1/irm_01-004-040#id28)
    - 1.4.40.4.1  [Importance of Accuracy of Case Databases](https://www.irs.gov/irm/part1/irm_01-004-040#id29)
      - 1.4.40.4.1.1  [Access to Inventory Control Systems](https://www.irs.gov/irm/part1/irm_01-004-040#id30)
        - 1.4.40.4.1.1.1  [Integrated Data Retrieval System (IDRS)](https://www.irs.gov/irm/part1/irm_01-004-040#id32)
        - 1.4.40.4.1.1.2  [Access to Group Inventory and Case Controls](https://www.irs.gov/irm/part1/irm_01-004-040#id33)
      - 1.4.40.4.1.2  [Taxpayer Browsing Protection Act/UNAX](https://www.irs.gov/irm/part1/irm_01-004-040#id34)
      - 1.4.40.4.1.3  [Control Systems for Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id35)
    - 1.4.40.4.2  [Case Control Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id36)
      - 1.4.40.4.2.1  [Requisition of Returns](https://www.irs.gov/irm/part1/irm_01-004-040#id37)
      - 1.4.40.4.2.2  [Nonfiler Case Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id38)
      - 1.4.40.4.2.3  [Updating Case Databases](https://www.irs.gov/irm/part1/irm_01-004-040#id39)
      - 1.4.40.4.2.4  [Use of AIMS Codes](https://www.irs.gov/irm/part1/irm_01-004-040#id40)
      - 1.4.40.4.2.5  [Closing of Returns](https://www.irs.gov/irm/part1/irm_01-004-040#id41)
      - 1.4.40.4.2.6  [Shipping Personally Identifiable Information (PII)](https://www.irs.gov/irm/part1/irm_01-004-040#id42)
        - 1.4.40.4.2.6.1  [Form 3210 - Quarterly Audits](https://www.irs.gov/irm/part1/irm_01-004-040#id44)
    - 1.4.40.4.3  [Statute Controls](https://www.irs.gov/irm/part1/irm_01-004-040#id45)
      - 1.4.40.4.3.1  [Statute Control File](https://www.irs.gov/irm/part1/irm_01-004-040#id47)
      - 1.4.40.4.3.2  [Generating, Printing and Processing Forms 895](https://www.irs.gov/irm/part1/irm_01-004-040#id48)
      - 1.4.40.4.3.3  [Imminent Statute Returns](https://www.irs.gov/irm/part1/irm_01-004-040#id49)
      - 1.4.40.4.3.4  [Expired Statutes](https://www.irs.gov/irm/part1/irm_01-004-040#id50)
    - 1.4.40.4.4  [Monitoring 30-Day Letters and Requests for Appeals Conferences](https://www.irs.gov/irm/part1/irm_01-004-040#id51)
    - 1.4.40.4.5  [Inventory Management](https://www.irs.gov/irm/part1/irm_01-004-040#id52)
      - 1.4.40.4.5.1  [Examination Cycle](https://www.irs.gov/irm/part1/irm_01-004-040#id54)
      - 1.4.40.4.5.2  [Inventory Types](https://www.irs.gov/irm/part1/irm_01-004-040#id55)
      - 1.4.40.4.5.3  [Securing Returns](https://www.irs.gov/irm/part1/irm_01-004-040#id56)
    - 1.4.40.4.6  [Assigning Returns](https://www.irs.gov/irm/part1/irm_01-004-040#id57)
      - 1.4.40.4.6.1  [Priority Work](https://www.irs.gov/irm/part1/irm_01-004-040#id58)
      - 1.4.40.4.6.2  [Restrictions on Examiners and Managers Consecutive Audit or Survey - Policy Statement 4-5](https://www.irs.gov/irm/part1/irm_01-004-040#id59)
      - 1.4.40.4.6.3  [Surveying Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id60)
        - 1.4.40.4.6.3.1  [Group Manager Risk Analysis](https://www.irs.gov/irm/part1/irm_01-004-040#id61)
        - 1.4.40.4.6.3.2  [Survey Before Assignment](https://www.irs.gov/irm/part1/irm_01-004-040#id62)
          - 1.4.40.4.6.3.2.1  [Paperless Survey Before Assignment](https://www.irs.gov/irm/part1/irm_01-004-040#id64)
          - 1.4.40.4.6.3.2.2  [Paper Survey Before Assignment](https://www.irs.gov/irm/part1/irm_01-004-040#id65)
          - 1.4.40.4.6.3.2.3  [Survey Before Assignment - Claims for Refund and Requests for Abatement](https://www.irs.gov/irm/part1/irm_01-004-040#id66)
        - 1.4.40.4.6.3.3  [Survey After Assignment Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id67)
      - 1.4.40.4.6.4  [Transferring Office Examination Cases to Field Examination](https://www.irs.gov/irm/part1/irm_01-004-040#id68)
      - 1.4.40.4.6.5  [Delinquent Returns and Nonfiler Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id69)
      - 1.4.40.4.6.6  [Grade Level of Work for Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id70)
        - 1.4.40.4.6.6.1  [Guidelines for Determining the Grade Levels of Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id71)
        - 1.4.40.4.6.6.2  [Characteristics of Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id72)
          - 1.4.40.4.6.6.2.1  [Part I — Chart of Case Grading Factors](https://www.irs.gov/irm/part1/irm_01-004-040#id74)
          - 1.4.40.4.6.6.2.2  [Part II - North American Industry Classification System (NAICS) Listing](https://www.irs.gov/irm/part1/irm_01-004-040#id75)
          - 1.4.40.4.6.6.2.3  [Part III—Probable Grade Levels of Cases Based on Type of Industry/Occupation and Size](https://www.irs.gov/irm/part1/irm_01-004-040#id76)
          - 1.4.40.4.6.6.2.4  [Part IV—List of Upgradable Issues that May Result in an Upgrade for Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id77)
        - 1.4.40.4.6.6.3  [Procedures for Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id78)
        - 1.4.40.4.6.6.4  [Case Grading for Special Situations for Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id79)
        - 1.4.40.4.6.6.5  [Relationship of Guide to Position Management for Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id80)
        - 1.4.40.4.6.6.6  [Recording Grade of Case on Form 5344, Examination Closing Record for Field Examination Cases](https://www.irs.gov/irm/part1/irm_01-004-040#id81)
    - 1.4.40.4.7  [Managing Open Inventories](https://www.irs.gov/irm/part1/irm_01-004-040#id82)
    - 1.4.40.4.8  [Collectibility](https://www.irs.gov/irm/part1/irm_01-004-040#id83)
    - 1.4.40.4.9  [Case Inactivity](https://www.irs.gov/irm/part1/irm_01-004-040#id84)
    - 1.4.40.4.10  [Related Pickup Work](https://www.irs.gov/irm/part1/irm_01-004-040#id85)
    - 1.4.40.4.11  [Closing Returns — General](https://www.irs.gov/irm/part1/irm_01-004-040#id86)
      - 1.4.40.4.11.1  [Advance Payments/Deposits](https://www.irs.gov/irm/part1/irm_01-004-040#id87)
      - 1.4.40.4.11.2  [No Change Closing Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id88)
      - 1.4.40.4.11.3  [Agreed Closing Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id89)
      - 1.4.40.4.11.4  [Partially Agreed Closing Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id90)
      - 1.4.40.4.11.5  [Unagreed Closing Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id91)
        - 1.4.40.4.11.5.1  [Unagreed Closing Procedures - RA Group Managers](https://www.irs.gov/irm/part1/irm_01-004-040#id93)
        - 1.4.40.4.11.5.2  [Unagreed Closing Procedures - TCO Group Managers](https://www.irs.gov/irm/part1/irm_01-004-040#id94)
      - 1.4.40.4.11.6  [Short Statute Cases — 180 Days or Less](https://www.irs.gov/irm/part1/irm_01-004-040#id95)
  - 1.4.40.5  [Monitoring Reports Overview](https://www.irs.gov/irm/part1/irm_01-004-040#id96)
    - 1.4.40.5.1  [AIMS Tables 36](https://www.irs.gov/irm/part1/irm_01-004-040#id97)
    - 1.4.40.5.2  [AIMS Table 4.1](https://www.irs.gov/irm/part1/irm_01-004-040#id98)
    - 1.4.40.5.3  [Other AIMS Tables](https://www.irs.gov/irm/part1/irm_01-004-040#id99)
    - 1.4.40.5.4  [Inventory Analysis Report - TCO](https://www.irs.gov/irm/part1/irm_01-004-040#id100)
    - 1.4.40.5.5  [NQRS and EQRS Reports](https://www.irs.gov/irm/part1/irm_01-004-040#id101)
    - 1.4.40.5.6  [PCS Reports](https://www.irs.gov/irm/part1/irm_01-004-040#id102)
    - 1.4.40.5.7  [ERCS Reports](https://www.irs.gov/irm/part1/irm_01-004-040#id103)
    - 1.4.40.5.8  [Reports to be Worked by the Group](https://www.irs.gov/irm/part1/irm_01-004-040#id104)
      - 1.4.40.5.8.1  [Inventory Validation Listing (IVL)](https://www.irs.gov/irm/part1/irm_01-004-040#id106)
      - 1.4.40.5.8.2  [AIMS Weekly Update Reports](https://www.irs.gov/irm/part1/irm_01-004-040#id107)
      - 1.4.40.5.8.3  [TC 424 Reject Register](https://www.irs.gov/irm/part1/irm_01-004-040#id108)
      - 1.4.40.5.8.4  [Statute Date Override Report](https://www.irs.gov/irm/part1/irm_01-004-040#id109)
      - 1.4.40.5.8.5  [Unexplained Update Report](https://www.irs.gov/irm/part1/irm_01-004-040#id110)
      - 1.4.40.5.8.6  [Dropped AIMS Report](https://www.irs.gov/irm/part1/irm_01-004-040#id111)
      - 1.4.40.5.8.7  [AAC Difference Report (ADIF)](https://www.irs.gov/irm/part1/irm_01-004-040#id112)
  - 1.4.40.6  [Group Manager Expectations](https://www.irs.gov/irm/part1/irm_01-004-040#id113)
    - 1.4.40.6.1  [Performance Management System (PMS)](https://www.irs.gov/irm/part1/irm_01-004-040#id115)
    - 1.4.40.6.2  [Federal Managers’ Financial Integrity Act of 1982 (FMFIA)](https://www.irs.gov/irm/part1/irm_01-004-040#id116)
    - 1.4.40.6.3  [Developing Group/Team Expectations](https://www.irs.gov/irm/part1/irm_01-004-040#id117)
    - 1.4.40.6.4  [Communicating Expectations to Employees](https://www.irs.gov/irm/part1/irm_01-004-040#id118)
    - 1.4.40.6.5  [Monitoring and Follow-up Procedures](https://www.irs.gov/irm/part1/irm_01-004-040#id119)
  - 1.4.40.7  [Guiding and Evaluating Employees](https://www.irs.gov/irm/part1/irm_01-004-040#id120)
    - 1.4.40.7.1  [Performance Appraisal](https://www.irs.gov/irm/part1/irm_01-004-040#id121)
    - 1.4.40.7.2  [IRS Policies, Procedures and Guidelines](https://www.irs.gov/irm/part1/irm_01-004-040#id122)
    - 1.4.40.7.3  [Performance Reviews](https://www.irs.gov/irm/part1/irm_01-004-040#id123)
    - 1.4.40.7.4  [Awards](https://www.irs.gov/irm/part1/irm_01-004-040#id124)
      - 1.4.40.7.4.1  [Processing Awards](https://www.irs.gov/irm/part1/irm_01-004-040#id126)
    - 1.4.40.7.5  [Employee Performance Files (EPFs)](https://www.irs.gov/irm/part1/irm_01-004-040#id127)
    - 1.4.40.7.6  [Group Manager Concurrence Meeting (GMCM) for Revenue Agents](https://www.irs.gov/irm/part1/irm_01-004-040#id128)
    - 1.4.40.7.7  [In-Process Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-040#id129)
    - 1.4.40.7.8  [Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-040#id130)
      - 1.4.40.7.8.1  [Compare Group Controls with Examiner's Inventory](https://www.irs.gov/irm/part1/irm_01-004-040#id131)
      - 1.4.40.7.8.2  [Items to Address During the Workload Review](https://www.irs.gov/irm/part1/irm_01-004-040#id132)
        - 1.4.40.7.8.2.1  [Adequacy of Inventory](https://www.irs.gov/irm/part1/irm_01-004-040#id134)
        - 1.4.40.7.8.2.2  [Priority Work](https://www.irs.gov/irm/part1/irm_01-004-040#id135)
        - 1.4.40.7.8.2.3  [Cases in Process for Extended Periods of Time](https://www.irs.gov/irm/part1/irm_01-004-040#id136)
        - 1.4.40.7.8.2.4  [Status 10 Inventory](https://www.irs.gov/irm/part1/irm_01-004-040#id137)
        - 1.4.40.7.8.2.5  [In Process Inventory](https://www.irs.gov/irm/part1/irm_01-004-040#id138)
        - 1.4.40.7.8.2.6  [Workload Problems and Delays](https://www.irs.gov/irm/part1/irm_01-004-040#id139)
        - 1.4.40.7.8.2.7  [Compatibility of Work with Employee's Grade](https://www.irs.gov/irm/part1/irm_01-004-040#id140)
        - 1.4.40.7.8.2.8  [Specialist Referrals and Technical Assistance](https://www.irs.gov/irm/part1/irm_01-004-040#id141)
        - 1.4.40.7.8.2.9  [Use of Time](https://www.irs.gov/irm/part1/irm_01-004-040#id142)
        - 1.4.40.7.8.2.10  [AIMS/ERCS Controls](https://www.irs.gov/irm/part1/irm_01-004-040#id143)
    - 1.4.40.7.9  [On-the-Job Visit](https://www.irs.gov/irm/part1/irm_01-004-040#id144)
      - 1.4.40.7.9.1  [Planning and Scheduling the Examination](https://www.irs.gov/irm/part1/irm_01-004-040#id146)
      - 1.4.40.7.9.2  [Accounting Skills and Tax Knowledge](https://www.irs.gov/irm/part1/irm_01-004-040#id147)
      - 1.4.40.7.9.3  [Workpapers and Reports](https://www.irs.gov/irm/part1/irm_01-004-040#id148)
      - 1.4.40.7.9.4  [Closing the Examination](https://www.irs.gov/irm/part1/irm_01-004-040#id149)
    - 1.4.40.7.10  [Closed Case Review](https://www.irs.gov/irm/part1/irm_01-004-040#id150)
      - 1.4.40.7.10.1  [Examination Planning and Scheduling](https://www.irs.gov/irm/part1/irm_01-004-040#id152)
      - 1.4.40.7.10.2  [Accounting Skills and Tax Law Knowledge](https://www.irs.gov/irm/part1/irm_01-004-040#id153)
      - 1.4.40.7.10.3  [Workpapers and Reports](https://www.irs.gov/irm/part1/irm_01-004-040#id154)
      - 1.4.40.7.10.4  [Use of Time](https://www.irs.gov/irm/part1/irm_01-004-040#id155)
    - 1.4.40.7.11  [Review of Examination Technical Time Reports (ETTR)/Examination Process Review (EPR)](https://www.irs.gov/irm/part1/irm_01-004-040#id156)
      - 1.4.40.7.11.1  [ETTR/EPR Analysis](https://www.irs.gov/irm/part1/irm_01-004-040#id158)
    - 1.4.40.7.12  [On-Going Observation](https://www.irs.gov/irm/part1/irm_01-004-040#id159)
    - 1.4.40.7.13  [Feedback from Other Areas](https://www.irs.gov/irm/part1/irm_01-004-040#id160)
    - 1.4.40.7.14  [Disciplinary and Adverse Actions](https://www.irs.gov/irm/part1/irm_01-004-040#id161)
    - 1.4.40.7.15  [Grievances](https://www.irs.gov/irm/part1/irm_01-004-040#id162)
    - 1.4.40.7.16  [Protecting Taxpayer Rights](https://www.irs.gov/irm/part1/irm_01-004-040#id163)
  - 1.4.40.8  [Employee Development](https://www.irs.gov/irm/part1/irm_01-004-040#id164)
    - 1.4.40.8.1  [New Employee Training](https://www.irs.gov/irm/part1/irm_01-004-040#id166)
    - 1.4.40.8.2  [Employee Training](https://www.irs.gov/irm/part1/irm_01-004-040#id167)
    - 1.4.40.8.3  [Employee Career Learning Plan](https://www.irs.gov/irm/part1/irm_01-004-040#id168)
    - 1.4.40.8.4  [Helping People Achieve](https://www.irs.gov/irm/part1/irm_01-004-040#id169)
    - 1.4.40.8.5  [Group Manager Development](https://www.irs.gov/irm/part1/irm_01-004-040#id170)
  - 1.4.40.9  [Programs and Priorities](https://www.irs.gov/irm/part1/irm_01-004-040#id171)
    - 1.4.40.9.1  [Work Categories](https://www.irs.gov/irm/part1/irm_01-004-040#id173)
    - 1.4.40.9.2  [Technical Advisors/Issue Specialists](https://www.irs.gov/irm/part1/irm_01-004-040#id174)
    - 1.4.40.9.3  [Headquarters Directed Projects](https://www.irs.gov/irm/part1/irm_01-004-040#id175)
    - 1.4.40.9.4  [Compliance Initiative Projects (CIP)](https://www.irs.gov/irm/part1/irm_01-004-040#id176)
    - 1.4.40.9.5  [Local Source Projects](https://www.irs.gov/irm/part1/irm_01-004-040#id177)
    - 1.4.40.9.6  [Compliance Data Environment (CDE)](https://www.irs.gov/irm/part1/irm_01-004-040#id178)
    - 1.4.40.9.7  [Governmental Liaison Program](https://www.irs.gov/irm/part1/irm_01-004-040#id179)
    - 1.4.40.9.8  [Specialty Areas](https://www.irs.gov/irm/part1/irm_01-004-040#id180)
    - 1.4.40.9.9  [Fraud](https://www.irs.gov/irm/part1/irm_01-004-040#id181)
  - 1.4.40.10  [Security](https://www.irs.gov/irm/part1/irm_01-004-040#id182)
    - 1.4.40.10.1  [Periodic Security Review](https://www.irs.gov/irm/part1/irm_01-004-040#id184)
    - 1.4.40.10.2  [Mandatory Briefings](https://www.irs.gov/irm/part1/irm_01-004-040#id185)
  - 1.4.40.11  [Interactions with Other Functions](https://www.irs.gov/irm/part1/irm_01-004-040#id186)
    - 1.4.40.11.1  [Appeals and Area Counsel](https://www.irs.gov/irm/part1/irm_01-004-040#id188)
    - 1.4.40.11.2  [Collection](https://www.irs.gov/irm/part1/irm_01-004-040#id189)
    - 1.4.40.11.3  [Criminal Investigation](https://www.irs.gov/irm/part1/irm_01-004-040#id190)
    - 1.4.40.11.4  [Disclosure](https://www.irs.gov/irm/part1/irm_01-004-040#id191)
    - 1.4.40.11.5  [Treasury Inspector General for Tax Administration (TIGTA)](https://www.irs.gov/irm/part1/irm_01-004-040#id192)
    - 1.4.40.11.6  [NTEU Notification - 7114 Meetings](https://www.irs.gov/irm/part1/irm_01-004-040#id193)
    - 1.4.40.11.7  [Research, Applied Analytics & Statistics (RAAS)](https://www.irs.gov/irm/part1/irm_01-004-040#id194)
    - 1.4.40.11.8  [Taxpayer Advocate Service (TAS)](https://www.irs.gov/irm/part1/irm_01-004-040#id195)
    - 1.4.40.11.9  [Communications & Liaison (C&L)](https://www.irs.gov/irm/part1/irm_01-004-040#id196)
    - 1.4.40.11.10  [Campus Contacts](https://www.irs.gov/irm/part1/irm_01-004-040#id197)
  - 1.4.40.12  [Collateral Duties](https://www.irs.gov/irm/part1/irm_01-004-040#id198)
    - 1.4.40.12.1  [Classroom Instructor](https://www.irs.gov/irm/part1/irm_01-004-040#id200)
    - 1.4.40.12.2  [Commissioner Representative](https://www.irs.gov/irm/part1/irm_01-004-040#id201)
    - 1.4.40.12.3  [Recruiting](https://www.irs.gov/irm/part1/irm_01-004-040#id202)
    - 1.4.40.12.4  [Taxpayer Services (TS) Customer Service](https://www.irs.gov/irm/part1/irm_01-004-040#id203)
  - 1.4.40.13  [General Group Management Issues](https://www.irs.gov/irm/part1/irm_01-004-040#id204)
  - 1.4.40.14  [Telework](https://www.irs.gov/irm/part1/irm_01-004-040#id205)
  - Exhibit  1.4.40-1  [Terms](https://www.irs.gov/irm/part1/irm_01-004-040#id206)
  - Exhibit  1.4.40-2  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-040#id207)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 40. SB/SE Field and Office Examination Group Manager

* * *

## 1.4.40 SB/SE Field and Office Examination Group Manager

#### Manual Transmittal

August 25, 2025

#### Purpose

(1) This transmits a limited revision of IRM 1.4.40, Resource Guide for Managers, SB/SE Field and Office Examination Group Manager.

#### Material Changes

(1) Significant changes to this IRM are listed in the table below.

| **Reference** | **Description** |
| --- | --- |
| IRM 1.4.40.1 | Updated Internal Controls in accordance with IRM 1.11.2.2.4. |
| IRM 1.4.40.5.8, Reports to be Worked by the Group | Moved (1) through (7) to IRM 1.4.40.5.8.1 through 1.4.40.5.8.7. |
| IRM 1.4.40.7.3, Performance Reviews | Moved recordation definition to Exhibit 1.4.40-1, Terms. |
| Exhibit 1.4.40-1, Terms | Moved 1.4.40.1.6, Terms to exhibit due to size. Removed definition of Form 3210 based on updates made to IRM 1.4.40.4.2.6, Shipping Personally Identifiable Information (PII). Added recordation definition from IRM 1.4.40.7.3, Performance Reviews. Added Controlled Unclassified Information (CUI). |
| Exhibit 1.4.40-2, Acronyms | Moved 1.4.40.1.7, Acronyms to exhibit due to size of section. Added and removed acronyms as needed. |
| Throughout IRM 1.4.40 | Minor editorial changes have been made throughout this IRM and website addresses were reviewed and updated as necessary. |

#### Effect on Other Documents

This IRM supersedes IRM 1.4.40 dated April 14, 2021.

#### Audience

SB/SE Field Examination

#### Effective Date

(08-25-2025)

Heather J. Yocum

Director, Examination Field and Campus Policy

Small Business/Self-Employed Division

CTCO:S:E:HQ:EFCP

**1.4.40.1** **(04-14-2021)**

### Program Scope and Objectives

1. **Purpose**. This section discusses responsibilities for managers in SB/SE Field Examination. The primary focus of this section is guidance related to SB/SE Field Examination case work. While many topics are touched upon in this section, comprehensive guidance about all topics cannot be included here; therefore, remain alert for references to other resources, such as related IRMs and websites and access that guidance as needed to ensure a thorough understanding of topics.

2. **Audience**. These procedures apply to group managers in SB/SE Field Examination. This IRM applies to both field (i.e., revenue agent) and office (i.e., tax compliance officer) examination group managers unless specifically directed to "Field" or "Office" Examination.

3. **Policy Owner**. The Director, Examination - Field and Campus Policy, reports to the Director, Headquarters Examination.

4. **Program Owner**. Field Examination General Processes (FEGP), reports to the Director, Examination Field and Campus Policy.

5. **Primary Stakeholders**: SB/SE Field Examination managers are the primary stakeholders of this IRM.

6. **Contact Information**. To recommend changes or make any other suggestions related to this IRM section, see IRM 1.11.6.5, Providing Feedback About an IRM Section - Outside of Clearance.


**1.4.40.1.1** **(07-24-2020)**

#### Background

1. This IRM contains procedures, guidance and information for both field (i.e., revenue agent) and office (i.e., tax compliance officer) examination group managers. The content includes general administrative responsibilities, performance management, internal controls, assignment of work, approval of work, quality and program reviews.


**1.4.40.1.2** **(07-24-2020)**

#### Authority

1. By law, the IRS has the authority to conduct examinations under Title 26, Internal Revenue Code, Subtitle F – Procedure and Administration, Chapter 78, Discovery of Liability and Enforcement of Title, Subchapter A, Examination and Inspection, which includes, but is not limited to, the following IRC sections:



   - IRC 7602, Examination of books and witnesses

   - IRC 7605, Time and place of examination

   - IRC 7803, Commissioner of Internal Revenue; other officials, which refers to taxpayer rights.


2. The authorities for this IRM include:



   - Section 1203, Internal Revenue Service Restructuring & Reform Act of 1998

   - Section 1204, Internal Revenue Service Restructuring & Reform Act of 1998

   - 26 CFR 601.106, Appeals Function, Settlement of Cases, Docketed in the United States Tax Court

   - Rev. Proc. 2012-18, Ex Parte Communications Between Appeals and Other Internal Revenue Service Employees

   - IRC 7521, Procedures involving taxpayer interviews


**1.4.40.1.3** **(08-25-2025)**

#### Roles and Responsibilities

1. The Director, Examination Headquarters, is the executive responsible for providing policy and guidance for SB/SE Examination employees and ensuring consistent application of policy, procedures and tax law to effect tax administration while protecting taxpayers’ rights. See IRM 1.1.16.5.5, Examination Headquarters, for additional information.

2. The Director, Examination Field and Campus Policy, reports to the Director, Examination Headquarters, and is responsible for the delivery of policy and guidance that impacts the field examination process. See IRM 1.1.16.5.5.1, Examination Field and Campus Policy, for additional information.

3. Field Examination General Processes, which is under the Director, Examination Field and Campus Policy, is the group responsible for providing policy and procedural guidance on standard examination processes to field employees. See IRM 1.1.16.5.5.1.1, Field Examination General Processes, for additional information.

4. SB/SE Field Examination managers should thoroughly acquaint themselves with the examination procedures and information contained in this IRM, as well as other resources, such as those listed in _IRM 1.4.40.1.7_, Related Resources, below.


**1.4.40.1.4** **(08-25-2025)**

#### Program Management and Review

1. The data for management information reports and tables is derived from the AIMS database. Additional information can be found in IRM 4.4.27, Reports, and _IRM 1.4.40.5_, Monitoring Reports Overview.

2. Periodic program reviews are conducted to:



   - Assess the effectiveness of specific programs within Examination or across the organization,

   - Determine if procedures are being followed,

   - Validate policies and procedures, and

   - Identify and share best/proven practices.


**1.4.40.1.5** **(08-25-2025)**

#### Terms

1. See _Exhibit 1.4.40-1_, Terms.


**1.4.40.1.6** **(08-25-2025)**

#### Acronyms

1. See _Exhibit 1.4.40-2_, Acronyms.


**1.4.40.1.7** **(08-25-2025)**

#### Related Resources

1. The IRMs in Part 4, Chapter 10 contain many of the procedures and guidelines managers use, including:



   - IRM 4.10.1, Overview of Examiner Responsibilities

   - IRM 4.10.2, Pre-Contact Responsibilities

   - IRM 4.10.3, Examination Techniques

   - IRM 4.10.4, Examination of Income

   - IRM 4.10.5, Required Filing Checks

   - IRM 4.10.6, Penalty Considerations

   - IRM 4.10.7, Issue Resolution

   - IRM 4.10.8, Report Writing

   - IRM 4.10.9, Workpaper System and Case File Assembly


2. In addition to the list above, there are other relevant IRMs managers use, including, but not limited to:




| Citation | Title |
| --- | --- |
| IRM 1.1.16 | Small Business/Self-Employed Division |
| IRM 1.2.2.2.2 | Delegation Order 1-2 (formerly DO-12, Rev. 14), Designation of Acting Supervisory Officials |
| IRM 1.4.1 | Management Roles and Responsibilities |
| IRM 1.4.2 | Monitoring and Improving Internal Control |
| IRM 1.4.32 | Internal Control Review Program |
| IRM 1.5.1 | The IRS Balanced Performance Measurement System |
| IRM 1.11.4 | Servicewide Delegation Order Process |
| IRM 1.20.2 | Providing Reasonable Accommodation for Individuals with Disabilities |
| IRM 1.35.4 | Purchase Card Program |
| IRM 4.1.5.3.2.6 | Grading Returns (RA, TCO-11, TCO-09 or below) |
| IRM 4.2.1 | General Examination Information |
| IRM 4.2.2 | Disaster Assistance Relief |
| IRM 6.430.2 | Performance Management Program for Evaluating Bargaining Unit and Non-Bargaining Unit Employees Assigned to Critical Job Elements (CJEs) |
| IRM 6.751.1 | Discipline and Disciplinary Actions: Policies, Responsibilities, Authorities, and Guidance |
| IRM 6.752 | Disciplinary Suspensions and Adverse Actions |
| IRM 6.800.2 | IRS Telework Program |
| IRM 10.2 | Physical Security Program |
| IRM 10.5 | Privacy and Information Protection |
| IRM 10.5.7 | Use of Pseudonyms by IRS Employees |
| IRM 25.6 | Statute of Limitations |

3. Some helpful leadership information can be found on SharePoint, including:



   - Human Capital Office

   - iManage

   - Integrated Talent Management

   - New Manager Orientation Support Center

   - Performance Management

   - School of Leadership Excellence

   - Source SBSE

   - Telework Portal

   - UNAX

   - 1203 Cases


4. The following are links to additional resources in the Virtual Library on KM:



   - Centralized Case Processing (CCP)

   - Critical Job Elements (CJE) Resource Center

   - Embedded Quality


5. The following are links to other helpful resources and job aids:



   - National Agreement

   - Signature Guidance for Acting Group Managers

   - ERCS Group Handbook


**1.4.40.1.8** **(05-19-2010)**

#### Operating Divisions

1. Compliance activities are divided into categories. A general distinction is those activities that require face-to-face interaction and those that can be accomplished without face-to-face interaction. The IRS has four primary operating divisions, each serving a group of taxpayers with similar needs:



1. Taxpayer Services (TS), serves individual taxpayers, including those who file jointly, with wage and investment income. Compliance issues are found on a limited range of issues such as dependent exemptions, credits, filing status and deductions. See IRM 1.1.13, Wage and Investment.

2. Small Business and Self-Employed (SB/SE), serves self-employed persons, supplemental income earners, small business corporations and partnerships with assets of less than $10 million, and filers of employment, excise, estate, gift and fiduciary returns. See IRM 1.1.16, Small Business/Self-Employed Division.

3. Large Business and International (LB&I), serves corporations, subchapter S corporations and partnerships with assets greater than $10 million. These entities typically have large numbers of employees, deal with complicated issues involving tax law and accounting principles and conduct their operations in an expanding global environment. See IRM 1.1.24, Large Business and International Division.

4. Tax-Exempt and Government Entities (TE/GE), serves employee plans, exempt organizations and governmental entities. See IRM 1.1.23, Tax Exempt and Government Entities Division.


**1.4.40.2** **(04-05-2017)**

### SB/SE Operating Units

1. The SB/SE operating units are:



1. Collection - enforces filing and payment requirements, secures delinquent returns and collects payments on unpaid accounts. See IRM 1.1.16.3, Collection.

2. Examination - provides SB/SE taxpayers service by helping them understand and meet tax responsibilities and by applying the tax law with integrity and fairness. See IRM 1.1.16.5, Examination.

3. Operations Support - provides centralization of all SB/SE support functions, in a customer centric environment, to ensure SB/SE Collection and Examination are properly equipped with the tools and resources to execute compliance activities. See IRM 1.1.16.6, Operations Support.


**1.4.40.3** **(05-19-2010)**

### Role

1. This section describes the role of a field and office examination group manager.


**1.4.40.3.1** **(05-19-2010)**

#### Role of a Group Manager

1. A group manager is responsible for the actions of a group of employees and instilling organizational values by providing direction and leadership. In addition to providing written and verbal directions, a group manager must lead by example.

2. A group manager serves as a role model for subordinates, is responsible for encouraging change and providing suggestions to implement programs.

3. A group manager is also responsible for developing employees and for inventory management. Listed below are some areas requiring managerial involvement:



   - Communicating the mission of the IRS

   - Ensuring the actions of the workgroup are aligned with the mission of the IRS

   - Transferring skills, knowledge and experience

   - Empowering employees with additional responsibilities

   - Providing training and developmental experiences


**1.4.40.3.2** **(05-19-2010)**

#### Balanced Measures

1. The [IRS’s Mission Statement](https://www.irs.gov/about-irs/the-agency-its-mission-and-statutory-authority) sets forth the purpose and direction of our operations. The mission focuses on three strategic goals:



   - Service to each taxpayer

   - Service to all taxpayers

   - Productivity through a quality work environment


2. In order to assess progress in meeting these goals, the IRS developed a set of balanced measures in three major areas:



   - Customer Satisfaction

   - Employee Satisfaction

   - Business Results


3. **Customer Satisfaction –** is defined as providing accurate and professional services to internal and external customers in a courteous and professional manner. Examples include:



   - Communicating effectively

   - Providing timely service

   - Empathizing with customers

   - Discussing how the IRS is using customer surveys with employees


4. **Employee Satisfaction –** is defined as the measure made up of employee perceptions of the management practices, organizational barriers and the overall work environment that affects their efforts to do a good job. Examples include:



   - Having a dialogue with employees

   - Identifying employees' training needs

   - Ensuring employees receive the training they need to perform job task

   - Elevating employee workplace issues


5. **Business Results –** is defined as generating a productive quantity of work in a quality manner and providing meaningful outreach to all customers. Examples include:



   - Identifying resources required for employees to adequately perform their jobs

   - Developing work processes to achieve the IRS’ goals in the most efficient and effective manner

   - Engaging employees and embracing ideas that provide best practices for work processes

   - Interacting regularly with employees to identify opportunities for improving work processes

   - Recognizing that the group's work is part of the delivery of a Servicewide goal


**1.4.40.3.3** **(05-19-2010)**

#### Accomplishments

1. A group manager's accomplishments will be measured by leadership competencies that are linked with the Balanced Measurement System. The leadership competencies are grouped by primary core responsibility areas:



   - Leadership

   - Employee Satisfaction

   - Customer Satisfaction

   - Business Results

   - EEO


**1.4.40.3.4** **(05-19-2010)**

#### Managing Statistics

1. Refer to IRM 1.5, Managing Statistics in a Balanced Measurement System, for additional information.

2. No goals or targets will be set for Records of Tax Enforcement Results (ROTERS). See 26 CFR 801.1 through 801.8.


**1.4.40.3.5** **(04-14-2021)**

#### Annual Examination Goals

1. An examination business plan is developed annually at the headquarters level. The plan is then subdivided into smaller components to set goals at the operating unit level and Area level. Work plans are developed for each level. The fiscal year goals and priorities are shared each fiscal year and can be found in Pub 5448, SB/SE Focus Guide.


**1.4.40.3.6** **(05-19-2010)**

#### Performance Feedback

1. The primary responsibility for case quality is at the group level. A group manager conducts both technical, procedural and administrative reviews. These reviews are generally workload, closed case, in-process, on the job visits, day/morning after, Exam Technical Time Report (ETTR) (field examination) and Examination Process Reviews (EPR) (office examination), etc. Reviews may be either informal or formal. Informal reviews may not require written documentation. See _IRM 1.4.40.7_, Guiding and Evaluating Employees, for specific guidance. **All documented reviews must be conducted in the Embedded Quality Review System (EQRS).**



### Note:



The requirement to conduct all reviews in EQRS does not include reviews on CJE 1 - Employee Satisfaction.

2. EQRS is used to conduct all managerial reviews of examiners. EQRS automatically links the quality attributes to an employee's CJEs and provides a group manager with reports on the performance of employees. The reports provide information on performance relative to the attributes and the CJEs. The National Quality Review System (NQRS) is a parallel system to EQRS that uses quality attributes to provide an assessment of organizational quality results. The EQRS and NQRS quality attributes are found in Document 12354, Embedded Quality, Field & Office Examination Job Aid. See _IRM 1.4.40.5.5_, NQRS and EQRS Reports, for additional information regarding the NQRS system.

3. All group managers **must** complete the Embedded Quality (EQ) training available on Integrated Talent Management (ITM). The course numbers are #22339 for Field Examination and #26807 for Office Examination.

4. Contact your Area EQ Coordinator if you have specific EQRS related questions.

5. Listed below are additional resources that provide guidance to assist in conducting reviews on EQRS:



1. Embedded Quality website;

2. Guide to Applying Attributes in Different Types of Reviews;

3. Multi Case Review Guidance Introduction; provides helpful guidance for conducting workload and ETTR/EPR reviews.


6. See _IRM 1.4.40.5.7_, for Examination Returns Control System (ERCS) reports that may be useful in conducting a case review.


**1.4.40.3.7** **(05-19-2010)**

#### Dealing with Taxpayers and External Customers

1. Group managers must ensure employee contacts are conducted in a manner that is conducive to promoting a positive image of the IRS.

2. All contacts must be conducted in a fair, professional, impartial and competent manner. IRM 4.10.1.3, Communication, provides information regarding the importance of quality communications.

3. When appropriate standardized forms and letters are available, they must be used. The specific wording in these documents has been approved.

4. Examiners must receive approval from their group manager prior to preparing original correspondence. A group manager must approve the content prior to its use and such approval must be documented in the case file. See IRM 4.10.1.3.2, Written Communication.

5. See IRM 4.10.1, Overview of Examiner Responsibilities, for additional information concerning taxpayer rights and employee responsibilities when contact is made with taxpayers.

6. A group manager must have an in-depth working knowledge of the content of Circular 230, Regulations Governing Practice before the Internal Revenue Service.


**1.4.40.3.7.1** **(05-19-2010)**

##### Taxpayer Concerns or Complaints

1. Ensuring good customer relations with taxpayers is important. A group manager must listen to a taxpayer's concerns or complaints. Complex tax laws and procedures are often the source of many concerns or complaints. A simple explanation or clarification is generally sufficient to resolve most concerns.

2. One of a group manager's responsibilities is to facilitate discussions between employees and taxpayers. Let the taxpayer fully explain their position. Neither agree nor disagree with the taxpayer until the employee has responded to the taxpayer's concerns. A group manager should avoid quick answers until they are in a position to make a fair and objective decision based on the facts presented by all parties to the examination. After all the facts are determined, a group manager or their employee should promptly respond to the taxpayer's complaint.


**1.4.40.3.7.2** **(04-05-2017)**

##### Management Responsibility Regarding Right of Consultation

1. Taxpayers have the right to representation at any time during the examination process. If a taxpayer requests time to secure representation, a group manager must ensure examiners allow a reasonable amount of time to do so.

2. Group managers must take steps to ensure that examiners are complying with IRC 7521. Specifically, examiners are required to:



1. Suspend the interview with a taxpayer (unless the interview was initiated by an administrative summons issued to the taxpayer under IRC 7602) whenever a taxpayer requests to consult with a representative and allow the taxpayer a minimum of 10 business days to secure representation. See IRM 4.10.3.4.5.2, Request for Representation - Suspension of Interview, for additional guidance as well as the actions an examiner can take during the 10 business days.

2. Observe the right of the taxpayer to not accompany the representative during an interview in the absence of an administrative summons issued to the taxpayer under IRC 7602.

3. Obtain appropriate managerial approval to notify the taxpayer, if the employee believes the representative is responsible for unreasonably delaying or hindering the examination of the taxpayer. See IRM 4.11.55.4, By-Pass of a Representative.


3. Opportunities to reinforce and ensure compliance with IRC 7521 by examiners are:



   - Group meetings

   - Case reviews

   - Workload reviews

   - Field visitations

   - Office visitations

   - Taxpayer/representative inquiries


4. See the following resources for more detailed information pertaining to complying with IRC 7521:



   - IRC 7521(b)(2), Right of consultation,

   - IRC 7521(c), Representatives holding power of attorney,

   - IRM 4.11.55.3.1.1, Request for Representation - Suspension of Interview, and

   - IRM 4.11.55.4, By-Pass of a Representative.


**1.4.40.3.7.3** **(05-19-2010)**

##### Procrastinating Taxpayers and Representatives

1. Group managers must effectively interact with taxpayers and representatives. Group managers must maintain control over in-process examinations and not permit taxpayers and/or representatives to attempt to stall progress. See IRM 4.11.55, Power of Attorney Rights and Responsibilities, and IRM 4.11.51, Return Preparer Program, for guidance.


**1.4.40.3.7.4** **(05-19-2010)**

##### By-Pass of a Representative

1. If a representative fails to timely respond to an examiner and is creating a hindrance, procrastination, or unreasonable delay, a group manager should review the facts and circumstances to determine if a by-pass is warranted.

2. The authority for by-pass procedures are found in Treas. Reg. 601.506(b). A by-pass permits an examiner to contact a taxpayer directly to request information necessary to complete an examination. The representative still continues to represent the taxpayer and is provided copies of all correspondence provided to the taxpayer. IRM 4.11.55.4, details the procedures for by-pass of a representative.


**1.4.40.3.8** **(05-19-2010)**

#### Time Accounting Responsibilities

1. Time and attendance is documented in the Single-Entry Time Recording (SETR) portion of the Totally Automated Personnel System (TAPS).

2. A group manager is responsible for the following:



   - Ensuring that the time and attendance records are correct for each reporting period,

   - Administering the leave rules, regulations, and procedures in accordance with established IRS policies, while balancing the needs of both the IRS and employees,

   - Complying with all requirements for scheduling and documenting leave, including securing any required signatures,

   - Establishing leave schedules early in the year to provide for adequate coverage at all times, to afford employees the opportunity to use their annual leave, and to avoid forfeiture of leave and compensatory time,

   - Ensuring leave charges are properly recorded to the appropriate leave category,

   - Counseling employees on policies, regulations, and procedures related to leave and absence,

   - Identifying and correcting, by appropriate methods, abuse of leave,

   - Timely requesting and receiving authorization for overtime and for compensatory time from the appropriate management level. This is done using Form 2787, Authorization and Report of Overtime Worked, and

   - Reporting pay and leave issues to the servicing Transactional Processing Center (TPC) and working with them to resolve problems.


3. The group manager is also responsible for checking Document 11678, National Agreement - Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU), hereinafter referenced as Document 11678, National Agreement, for leave policies and procedures. The following Agreement Articles may be of interest:



   - 22 - Work Schedules

   - 23 - Hours of Work

   - 24 - Overtime

   - 31 - Leave Sharing Program

   - 32 - Annual Leave

   - 33 - Family Leave

   - 34 - Sick Leave

   - 35 - Leaves of Absence

   - 36 - Administrative, Weather and Safety, and Other Leave


**1.4.40.3.9** **(04-14-2021)**

#### Acting Manager Assignments and Designations

1. The group manager must formally designate an acting manager during periods of absence of a full workday or longer. Form 10247, Designation to Act, should be completed and maintained in the acting manager’s drop file for one year as referenced in Document 12829, The General Records Schedules, 2.2: Employee Management Records, item 80. See IRM 1.11.4.5(7) and IRM 1.11.4.5(8), Purpose and Contents of Delegation Orders, for additional information.

2. Managerial tasks performed and those to be deferred until the permanent manager returns generally depend on the duration of the assignment. Managerial tasks performed should be agreed to between the group manager and the acting manager in advance. The acting manager should be given specific expectations at the beginning of the assignment. This will form the basis for performance feedback of the acting assignment. See Document 11678, National Agreement, Article 12, Section 4, B4, for restrictions related to performance evaluations (i.e., if the acting manager is a bargaining unit employee who has not been acting in a managerial capacity for sixty (60) days or more, appraisals will be made by the next higher-level supervisor).

3. The group manager should determine if the acting manager’s case inventory level needs to be adjusted during the acting assignment. Factors to consider are:



   - Length of acting assignment, and

   - Duties to be performed during the assignment.


4. Examiners may be asked to perform specific managerial tasks (e.g., review closed cases, survey status 10 inventory, etc.) when the group manager is not absent. This enables the group manager to provide developmental opportunities to employees aspiring to the next level to gain useful experience. In this situation, Form 10247 is not required.



### Caution:



Tasks that require managerial approval cannot be performed without a formal designation (e.g., 30-day letter signatures; managerial approval of penalties (see IRM 20.1.1.2.3, Approval Prerequisite to Penalty Assessments); executing Form 872, Consent to Extend the Time to Assess Tax, etc.).


**1.4.40.4** **(05-19-2010)**

### Workload Planning

1. This subsection provides specific guidance on workload processes and tools available to a group manager to effectively and efficiently manage a group. Included is information relative to the various automated systems that a group manager has responsibility for ensuring are updated and safeguarded.

2. A group manager must maintain effective controls to:



   - Physically protect returns and return information,

   - Maintain an adequate inventory of tax returns,

   - Ensure prompt completion and closure of examinations, and

   - Protect statutes of limitations.


**1.4.40.4.1** **(05-19-2010)**

#### Importance of Accuracy of Case Databases

1. The management of a group’s inventory and the accuracy of the case inventory database are critical to the success of a group. Accurate inventory controls will assist in:



   - Maintaining appropriate statute controls,

   - Responding to both internal and external customers,

   - Ensuring priority case work is readily identified and promptly worked, and

   - Ensuring adequate examiner inventory.


2. The primary automated tool used to manage inventory at a group level is ERCS. Data entered through ERCS updates the Audit Information Management System (AIMS).


**1.4.40.4.1.1** **(05-19-2010)**

##### Access to Inventory Control Systems

1. A group manager is responsible for ensuring that information is protected commensurate with its level of sensitivity.

2. A group manager must ensure that employee access to the Integrated Data Retrieval System (IDRS) and ERCS is properly safeguarded.


**1.4.40.4.1.1.1** **(05-19-2010)**

###### Integrated Data Retrieval System (IDRS)

1. The support staff at the group level may be assigned primary responsibility for conducting IDRS research. Their level of access to IDRS command codes will be greater than that of managers and examiners. Generally, managers and examiners at the group level should only have IDRS research capability.

2. A group manager is required to review IDRS usage reports to ensure employee access levels are appropriate (IDRS Online Reports Services (IORS).

3. A group manager's security responsibilities include but are not limited to the following:



   - Controlling employees' access to IDRS by using the Business Entitlement Access Request System (BEARS) application to initiate or change user access to automated information systems,

   - Annual BEARS certification,

   - Ensuring employees have only those command codes necessary to accomplish their official duties and sensitive command code usage is closely monitored, and

   - Ensuring profile changes due to separation, work assignments, termination or non-work status, are completed in a timely manner.


4. If an employee has a case in their inventory, they can perform appropriate IDRS research without securing specific managerial approval. This includes research on employee audit cases in their inventory.

5. Employees are prohibited from accessing their own account using IDRS. However, an employee can submit a request for their personal tax information through TS.

6. See IRM 10.5.5, IRS Unauthorized Access, Attempted Access or Inspection of Taxpayer Records (UNAX) Program Policy, Guidance, and Requirements, and IRM 21.2.2.3.2, Taxpayer Browsing Protection Act, for Unauthorized Access (UNAX) rules.

7. See IRM 10.8.34, IDRS Security Controls, for IORS procedures, annual BEARS certification process, and the use of Form 11377, Taxpayer Data Access.


**1.4.40.4.1.1.2** **(05-19-2010)**

###### Access to Group Inventory and Case Controls

1. To ensure the integrity of the system, a group manager must limit opportunities for access to the group inventory records. Generally, only the group manager and support staff should have access. With any group inventory and case control system the following rules must be enforced.



1. The systems must be password protected.

2. Users must always log off when leaving their computer.

3. Persons without a "need to know" should not be allowed to view information on the computer or in hardcopy.


**1.4.40.4.1.2** **(05-19-2010)**

##### Taxpayer Browsing Protection Act/UNAX

1. The Taxpayer Browsing Protection Act, IRC 7213A, Unauthorized inspection of returns or return information, provides a criminal misdemeanor penalty for the willful, unauthorized inspection of tax returns or return information. See IRM 10.5.5 and IRM 21.2.2.3.2.

2. A group manager must ensure employees complete their annual UNAX Awareness certification. See _IRM 1.4.40.10.2_, Mandatory Briefings, for information on annual certification.


**1.4.40.4.1.3** **(05-19-2010)**

##### Control Systems for Cases

1. IDRS is the system the IRS uses to access taxpayer account file information on Master File (MF) and Non-Master File (NMF). This system is the parent to all enforcement division management systems of the IRS. Within the IDRS system are AIMS and Pass-Through Control System (PCS).



1. AIMS is a system used by Examination to control returns, input assessment/adjustments to MF, and provide management reports. While a tax return or an open account is charged to Examination, the AIMS data base tracks its location, age, and status. Information on the management reports can be found in _IRM 1.4.40.5_, Monitoring Reports Overview.

2. The accuracy and integrity of AIMS information is a group manager's responsibility although primary responsibility for the verification of the data should be assigned to a member of the support staff. A group manager must have a working knowledge of AIMS procedures and reports to provide effective management oversight of a group.

3. PCS is a system that contains information regarding the examinations of flow-through entities (Partnerships, S Corporations, Trusts) and the related investors. PCS controls both TEFRA and Non-TEFRA entities. PCS controls for entities are established with information submitted at the group level. The system establishes a linkage between the key entity and the related returns. It ensures that all investor returns are established on AIMS. Also, it ensures returns are charged to the Campus TEFRA/non-TEFRA function or to Area examination personnel so that statutes are protected and necessary adjustments may be made. A group manager is responsible for the accuracy and integrity of the information input into the system.


2. ERCS is an automated inventory management system. It is used for controlling tax returns, penalty investigations, open accounts, and recording technical time charges. Through the use of an interactive menu-driven database, records can be requested, assigned/reassigned, updated, and closed. A group manager must use various ERCS reports to effectively and efficiently manage group operations.

3. Updating ERCS will update the Summary Examination Time Transmission System (SETTS) monthly and AIMS daily. On a weekly basis, an AIMS file is run against the ERCS database, and any differences are updated or a difference report is printed that must be reconciled (primarily by the group support staff). Refer to the ERCS IRM 4.7.5, Group and Territory, and the AIMS and ERCS websites.

4. The SETTS consolidates examiners’ time entries for electronic summarization. An examiner's time charges are input primarily by the support staff using the ERCS Exam Technical Time Report (ETTR), or ERCS Tax Auditor Daily Report (Daily). See IRM 4.9.1, Outline of System.


**1.4.40.4.2** **(05-19-2010)**

#### Case Control Procedures

1. This subsection describes various case control procedures used to manage the group's inventory.


**1.4.40.4.2.1** **(04-14-2021)**

##### Requisition of Returns

1. When an examination is initiated, controls are requested using Form 5345-D, Examination Request - ERCS (Examination Returns Control System) Users.

2. A group manager must ensure there is a valid reason for the request and the entries on the form are correct prior to approval. Refer to the AIMS/Processing Handbook, IRM 4.4.23, Openings.



### Note:



When completing Form 5345-D, an examiner can establish controls with or without ordering the original tax return.

3. Source Code 45 is used to order reference returns (e.g., a tax return secured for information only). The reason for the request must be annotated on Form 5345-D. A copy of the approved Form 5345-D must be attached to the back of the referenced return as a permanent record. Upon receipt of the original reference return, an examiner must determine within 30 days of receipt, whether the return will be examined or closed on AIMS.



### Note:



If the original reference return must be retained for greater than 30 days, an examiner must initiate an update to an appropriate source code other than 45 that reflects the reason for retaining the return at the group level.

4. It takes approximately two weeks for full AIMS controls to be established. When an original tax return document is required, it will generally take between six to eight weeks to receive the original document.

5. The group support staff must maintain Form 5345-D in a pending requisition file until AIMS controls are established and, when applicable, the original tax return is received in the group. A group manager must ensure that appropriate follow-ups are conducted by the group's support staff, when necessary, to secure AIMS controls and, when applicable, receipt of an original tax return.



### Reminder:



Form 5345-D must be maintained in the case file. If the case file is split, a copy of Form 5345-D should be in the primary case file and the original included with the year of the request. See IRM 4.10.5.3.2, Examination of Prior and Subsequent Returns.

6. For additional information on completion of Form 5345-D, refer to IRM 4.4.23, Openings, and the ERCS Group Handbook.


**1.4.40.4.2.2** **(05-19-2010)**

##### Nonfiler Case Procedures

1. Delinquent returns and substitutes for returns require special procedures. See IRM 4.12.1, Nonfiled Returns; and IRM 4.4.9, Delinquent and Substitute for Return Processing.


**1.4.40.4.2.3** **(05-19-2010)**

##### Updating Case Databases

1. It is a group manager's responsibility to ensure that case databases (ERCS/AIMS) are timely and properly updated to reflect the correct status code, source code, statute date, organization code, claim amount, project code, SFR activity code, and aging reason code. A group manager will be actively involved in the progress of each employee’s work and ensure updates are made timely by employees.


**1.4.40.4.2.4** **(05-19-2010)**

##### Use of AIMS Codes

1. Source codes, status codes and project codes are important because they allow for a compilation of data regarding inventory levels and composition, resource utilization, and program accomplishments. Data entered into AIMS is relied upon throughout the IRS when assessing program accomplishments and setting goals. Additional information can be found in IRM 4.4.1, Introduction, at:



   - IRM Exhibit 4.4.1-1, Reference Guide - Source Codes

   - IRM Exhibit 4.4.1-1, Reference Guide - Status Codes

   - Project Codes can be located on the AIMS/ERCS website at ERCS Code Listings


2. Push codes are used to allow controls to be established when no record of a return filing is present on MF. See IRM Exhibit 4.4.1-1, Reference Guide - Push Codes.


**1.4.40.4.2.5** **(05-19-2010)**

##### Closing of Returns

1. Cases are closed from the group on ERCS and RGS (Report Generation Software). Refer to IRM 4.7.5, Group and Territory, IRM 4.4.12, Examined Closings, Surveyed Claims, and Partial Assessments, and Manager/Clerk/Secretary Training.


**1.4.40.4.2.6** **(07-24-2020)**

##### Shipping Personally Identifiable Information (PII)

1. The group manager must establish and maintain control procedures for shipping and receiving Personally Identifiable Information (PII), including Form 3210, Document Transmittal, retention, monitoring, and follow-up.

2. Group procedures must be established for the maintenance of all Forms 3210 (incoming and outgoing) whether the forms are prepared, or are computer generated; for example, a log book, binder system or log file should be established for all incoming Forms 3210 and for all outgoing Forms 3210.

3. IRM 4.10.1.4.8, Shipping Personally Identifiable Information (PII), provides guidance and procedures for shipping PII and using Form 3210. IRM 4.10.1.4.8.2, Form 3210 - Acknowledgement, provides guidance and procedures for time frames and follow-up actions.


**1.4.40.4.2.6.1** **(07-24-2020)**

###### Form 3210 - Quarterly Audits

1. Managers must perform, at a minimum, quarterly audits of the acknowledgement process for packages containing PII to ensure appropriate follow-up is occurring. The audit provides the opportunity to validate that PII senders are following up on Form 3210 acknowledgments within defined time frames, so lost shipments are identified quickly. See IRM 10.5.1.6.9.3(27), Shipping through Private Delivery Carrier.

2. At a minimum the audit should confirm and document there is a process for shipping and receiving PII and it is followed. The following audit points should be considered:



   - Form 3210 is used when shipping PII.

   - Form 3210 lists only documents transmitted and does not list documents that were not transmitted.

   - The "To be retained by originator" (control copy) is maintained until the acknowledgement copy is received (the control copy must be printed for electronic Forms 3210).

   - Forms 3210 still pending acknowledgment after the established time frame have documentation showing follow-up action was taken. See IRM 4.10.1.4.8.1, Form 3210 - Monitoring, for time frames and required follow-up action.

   - Forms 3210 are retained for one year prior to disposition in accordance with Records Control Schedule (RCS) 23, Tax Administration - Examination, Item number 36, in Document 12990.


**1.4.40.4.3** **(04-14-2021)**

#### Statute Controls

1. A group manager should refer to IRM 25.6.23, Examination Process - Assessment Statute of Limitations Controls, for comprehensive instructions regarding statute controls and responsibilities for protecting the period of time for assessment of tax. Should there appear to be a conflict between the provisions of IRM 1.4.40 and IRM 25.6.23, with respect to the limitations on the period of time for making tax assessments, IRM 25.6.23 should be followed.

2. For all tax returns which are filed (whether timely or late filed), statute controls are required to be established no later than 180 days prior to the actual assessment statute expiration date (based on the later of the date the return was filed or due, without regard to extensions). Statute expiration dates may be determined by referring to IRM 25.6.1.6.4, Statute of Limitations Chart for Tax Returns.

3. As tax returns or ERCS/AIMS data are received in or charged to the group, it is extremely important to screen the return and/or ERCS/AIMS data to determine the accuracy of the assessment statute information and to identify the need for establishing statute controls. The statute information reflected on ERCS/AIMS is not to be accepted as accurate but must be confirmed by reviewing case file information and conducting appropriate IDRS research. See IRM 25.6.23.5.1.2, Screening for Statute Accuracy.

4. If a tax return is not filed, statute controls are established at 180 days before the normal assessment statute expiration date had the return been timely filed, or at the time the substitute for return is input, whichever is earlier. If alpha code EE is used in the ASED field for the nonfiler, then ERCS will automatically generate the Form 895, Notice of Statute Expiration, when the forms are generated for the group by the support staff. See alpha code EE instructions in IRM Exhibit 25.6.23-3, Instructions for Updating the Statute on AIMS.

5. ERCS must be updated to reflect the accurate Assessment Statute Expiration Date (ASED) on the entire inventory of the group. ERCS will then update AIMS.

6. A group manager has the authority and responsibility to allow the normal assessment statute of limitations (SOL) to expire if certain special conditions are present, as described in detail in IRM Exhibit 25.6.23-3. In addition, see IRM 25.6.23.5.7.2, Reliance on IRC Provisions Which Extend the Normal Assessment Statute, for those instances when territory manager concurrence is required to allow the period for assessment to expire based on a special statute condition.

7. Certain conditions warrant soliciting a consent to extend the SOL. See IRM 25.6.22.2.1, Assessment Statute Extension. The list in IRM 25.6.22.2.1 is not all inclusive and in certain circumstances consents can be solicited before the 180–day time frame specified, but for situations other than those listed, the case file must be documented with the reasons approval to extend the statute was granted.



### Exception:



Managerial approval is not required to solicit the consent if it is needed so the case can go to Appeals. See IRM 25.6.22.2.1(2) for additional information.





### Note:



Generally, an examiner cannot initiate an examination on any return with less than 12 months remaining on the SOL for assessment, without prior managerial approval. Approval should be documented on Form 9984, Examining Officer’s Activity Record. See IRM 4.10.2.2.1(3), Statute of Limitations.

8. IRC 6501(c)(4)(B), Limitations on assessment and collection, enacted by the IRS Restructuring and Reform Act of 1998 (RRA 98), requires the IRS to notify the taxpayer of certain rights in each instance when a request to extend the assessment period is solicited. See IRM 25.6.22.3, Notification of Taxpayer’s Rights, for detailed instructions for notifying taxpayers of their rights.


**1.4.40.4.3.1** **(05-19-2010)**

##### Statute Control File

1. A group manager must maintain statute controls on all returns and investigations in the manager’s custody to ensure that accurate statute information is entered on ERCS/AIMS. Statute expiration information entered on ERCS is automatically sent to AIMS, but it's possible the update can reject. The manager must monitor reject reports to ensure the AIMS database is correct. This includes returns:



1. Controlled on AIMS; and

2. Investigations/Examinations controlled on ERCS, but not AIMS, e.g., penalty cases. See IRM 25.6.23.5.4, Area Office Group Statute Controls, for detailed instructions.


2. The statute control system must monitor the following returns:



   - Returns with statute expiring within 180 days (at a minimum)

   - All alpha statute returns except for _ZZ_ alpha statutes


3. Group statute controls must be contemporaneously maintained, monitored, and reconciled with AIMS Table 4.1, Returns with Statute Date Pending. See IRM 25.6.23.5.10.2, Verification of ERCS and AIMS Tables 4.1 and 4.0 Data, for detailed information on verification of ERCS and AIMS Table 4.1 data.


**1.4.40.4.3.2** **(04-14-2021)**

##### Generating, Printing and Processing Forms 895

1. ERCS generates a Form 895 for each return in the group whose statute expires within a specified number of days (usually 210, but at a minimum 180). The Form 895 must be issued to the employee charged with the return.



1. It is the responsibility of the examiner to reconcile the information on Form 895 with information in the case file and taxpayer account data to verify the accuracy of the assessment statute expiration date and return the Form 895 to the group manager within 10 days of receipt.

2. If the examiner or specialist does not return the completed Form 895 to the manager within 10 days of the date the Form 895 is generated, the manager will follow up with the examiner or specialist to secure the Form 895.

3. The group manager must secure the Form 895 from the examiner and approve the accuracy of the completed Form 895 information within 20 days of the date the Form 895 is generated.

4. The support staff must update ERCS within 3 days of the date that the manager approves the accuracy of the information reflected on the Form 895. See IRM 25.6.23.5.3, Form 895 Completion Requirements for Area Office Managers and Applicable Campus Operations Managers.


### Note:

The manager has the responsibility for statute control for returns in unassigned inventory, and must timely complete Form 895. See IRM 25.6.23.5.1.3, Initiation of Controls by Manager - Area Offices, and IRM 4.7.3.2.1, Manager, for additional information.

2. Any return with alpha codes in the statute date for which a Form 895 has not been issued will generate a Form 895 (except for _ZZ_ alpha statutes).

3. When a case is transferred from one work group to another, the receiving group manager assumes the responsibility for statute control upon receipt of the case. Accordingly, the accuracy of the assessment statute information must be verified by the receiving organization and a Form 895 prepared if warranted. If the ERCS/AIMS shows that the control is charged to the group but receipt of the case file in the group is delayed, the group charged with the return must take action to locate the return if the ASED is imminent.

4. The support staff will generally identify the relevant returns, print Form 895 and forward those forms to examiners. A group manager must emphasize the support staff's and examiner's responsibilities for timely and accurately processing Form 895.

5. See IRM Exhibit 25.6.23-1, Form 895, Notice of Statute Expiration Instructions, for line-by-line instructions for manually prepared Form 895

6. See IRM Exhibit 25.6.23-2, ERCS Form 895, Notice of Statute Expiration Instructions, for line-by-line instructions for ERCS generated Form 895.


**1.4.40.4.3.3** **(05-19-2010)**

##### Imminent Statute Returns

1. Imminent assessment statute cases require special handling and it is imperative that examiners and managers allow adequate time from case closing until the statute expiration date for the necessary case review, case processing and deficiency assessment.

2. When an unagreed case includes a tax period that has less than 90 days remaining on the assessment SOL at the time of closing from the group, the group manager must contact the Technical Services Group Manager concerning the issuance of a Statutory Notice of Deficiency (SNOD). CCP is to be contacted in agreed case situations when the statute has less than 90 days remaining at the time of closing from the group. See IRM 25.6.23.7.2, Cases With Less Than 90 Days to ASED Expiration. TEFRA cases should be closed from the group prior to 240 days of the ASED. See IRM 25.6.23.7.3, TEFRA Cases With Less Than 240 Days to ASED Expiration.


**1.4.40.4.3.4** **(05-19-2010)**

##### Expired Statutes

1. IRM 25.6.1.13.2.8, Statute Expiration Reporting Responsibilities and Procedures for SB/SE Area Office Involved Directly with or Providing Support for Tax Return Examinations, discusses preparation and submission of Form 3999, Statute Expiration Report, and Form 3999-T, Statute Expiration Report (for a TEFRA key case).

2. A preliminary Form 3999 is required to be submitted to the territory manager within 3 days of discovery of a potentially expired statute. See IRM Exhibit 25.6.1-4, SB/SE Statute Expiration Reporting Timetable (for examination-related activities).


**1.4.40.4.4** **(04-14-2021)**

#### Monitoring 30-Day Letters and Requests for Appeals Conferences

1. Group managers are responsible for maintaining a control system to monitor cases when a 30-day letter has been issued. For additional information and guidance regarding 30-day letters see IRM 4.10.8.12.1, 30-Day Letters. ERCS reports may be used for monitoring cases. See _IRM 1.4.40.5.7_, ERCS Reports, for additional information specific to ERCS reports.

2. **Revenue agent (RA) groups:** When a 30-day letter is issued the returns must be updated to status code 13. Group managers can use the ERCS Status Report to monitor cases in status 13 in order to determine appropriate follow up actions. See IRM 4.7.6.4.10, Status Report, for additional information.

3. **Tax compliance officer (TCO) groups:** When a 30-day letter is issued, the returns must be updated to action code 04, Issue 15 Day Letter, and purged for 15 calendar days. If the taxpayer does not respond within 15 days, the examiner will sign and issue Letter 1912, Follow-Up Letter Transmitting Examination Reports, and update the action code to 07, Closed Unagreed, with a purge date for 15 calendar days. Group managers can use the Action Code Report and Overage Purge Report to monitor cases in action codes 04 and 07 in order to determine appropriate follow up actions. See IRM 4.7.6.9.1, Action Code Report, and IRM 4.7.6.9.6, Overage Purge Report. If an Appeals request is received, the examiner will update the case to ERCS action code 03, Request for Appeals Conference, and set the purge date to 7 days. When the examiner has completed all actions and the case is ready to close, it must be updated to action code 11, Manager Review and Protests, which defaults to a purge date of "Today" and submitted to the group manager. Group managers must use Action Code Reports to monitor action codes 03 and 11 to ensure request for appeals cases are moving in a timely manner.

4. All examiners follow the guidance in IRM 4.10.8.12.9.3, Request for Appeals Conference, when a request to go to Appeals is received.



### Reminder:



The case should be closed from the group within 20 days from the date the 30-day letter defaults or the date the request for an Appeals conference is received (unless the case requires additional development). See IRM Exhibit 4.2.8-1, National Standard Time Frames for Case Action, for time frames for closing a case from the group.


**1.4.40.4.5** **(04-14-2021)**

#### Inventory Management

1. A group manager must plan, monitor, and direct input of work to accomplish program priorities and effectively utilize resources.

2. A group manager must maintain within the group:



   - Sufficient inventory levels (started and unstarted)



     ### Note:



     TCO group managers utilize the examiner’s Microsoft Outlook calendar to assess examiner availability when ordering and assigning cases. The ERCS Inventory Analysis Report (TCO) should be reviewed when ordering and assigning new work to ensure examiner inventories are balanced to address overall quantity and cycle time concerns. See IRM 4.7.6.9.4, Inventory Analysis, and IRM 4.10.2.6, Office Examination Scheduling and Use of Microsoft Outlook Calendar, for additional information on the Microsoft Outlook calendar.

   - Appropriate categories of returns (as established in the Examination Plan)


3. To do so, a group manager must:



   - Consider experience and training level of examiners,

   - Anticipate and factor current and future priority work,

   - Consider historical rates of related pickups, and

   - Anticipate details and other assignments of examiners.


4. Area procedures will provide guidance regarding the assignment of status 10 inventory to examiners.


**1.4.40.4.5.1** **(04-14-2021)**

##### Examination Cycle

1. For income tax returns, the examination and all processing (e.g., appeal, assessment, etc.), through and including the issuance of the closing letter, should generally be completed within 26 months for individual returns and within the 27 months for business returns. See IRM 4.10.2.2.2, 26/27 Month Examination Cycle, and IRM 4.10.5.3.2, Examination of Prior and Subsequent Returns, for guidance. If the examination of a prior or subsequent year return(s) is warranted, the return(s) should be audited concurrently with the assigned return.


**1.4.40.4.5.2** **(05-19-2010)**

##### Inventory Types

1. A group’s work can be divided into three categories.



1. Mandatory — Neither a group manager nor an examiner has the authority or discretion to survey; these returns must be worked.

2. Priority — Both a group manager and an examiner are empowered to survey if the case justifies such action. However, once the commitment is made to examine, it should be handled expeditiously.

3. Discretionary — Both a group manager and an examiner are expected to evaluate the degree of noncompliance before initiating the examination.


2. See _IRM 1.4.40.9.1_ for a list of priority cases.


**1.4.40.4.5.3** **(05-19-2010)**

##### Securing Returns

1. If priority returns are in process and the group's status 10 inventory is inadequate, a group manager may need to order returns.

2. Requests for new work should be submitted to Planning and Special Programs (PSP) through the territory manager (TM). Requests should include an explanation of the work required based on the grade level of the agents needing the work. PSP monitors priorities, program requirements, and local directives and will provide coordination to furnish the proper type of work.

3. A group manager should always be alert to the potential for areas of noncompliance and prepare project recommendations where appropriate.

4. While there are a number of factors that affect the time it takes to receive returns, a group manager should be aware of the general time frames involved and plan accordingly.


**1.4.40.4.6** **(02-03-2015)**

#### Assigning Returns

1. Many factors influence the actions a group manager may take when assigning work. Some examples include:



   - Volume, complexity, specialization, and diversity of work flowing into the group,

   - Structure, experience, and training level of the examiners,

   - Geographic location of examiners and status 10 inventory,

   - Area priorities, and

   - Status of in-process work.


2. Program/project cases, including National Research Program (NRP), may be assigned to newly trained examiners, when appropriate, to enhance their career development. When making case assignment decisions, group managers should consider the complexity of the case plus the experience and training level of the examiner.

3. In accordance with IRM 25.6.22.2.1(2), Assessment Statute Extension, group managers should ensure examiners do not initiate an examination on any return with less than 12 months remaining on the SOL for assessment, without prior managerial approval. Therefore, cases with less than one year on the SOL should generally not be assigned to an examiner unless significant issues are present on the return.


**1.4.40.4.6.1** **(05-19-2010)**

##### Priority Work

1. The Examination Program Letter is issued each fiscal year by Headquarters to provide guidance on program emphasis and effective utilization of resources. Each Area establishes its own goals and priorities tailored to meet those outlined by Headquarters. TMs will communicate the Area goals and priorities to their group managers.

2. When a group manager assigns returns to examiners, mandatory start and priority case work must receive first consideration. See _IRM 1.4.40.9.1_. While transfer of cases between examiners is not desirable, it should be accomplished when necessary to achieve priority needs.

3. It is essential that a group manager understands all priorities, monitors them closely, and ensures their timely completion. See _IRM 1.4.40.3.5_, Annual Examination Goals.


**1.4.40.4.6.2** **(04-14-2021)**

##### Restrictions on Examiners and Managers Consecutive Audit or Survey - Policy Statement 4-5

1. Policy Statement 4–5 (P-4-5) prohibits an examiner or specialist from examining or surveying a tax return of a taxpayer for more than five consecutive years (60 months) from date of assignment. If the examination is in process at the five consecutive year point, the examiner or specialist is allowed to complete the examination provided the current cycle or audit has less than 12 months remaining from the five consecutive year point. An examiner or specialist will not be reassigned to the same taxpayer for the examination of one intervening tax period or surveying of two intervening tax periods.



### Note:



See Policy Statement 4-5 for information regarding deviations and exceptions to the general limitations (IRM 1.2.1.5.3, Policy Statement 4-5 (Rev.1), Restrictions on Examiners’ and Specialists’ Consecutive Survey or Examination Responsibilities.)

2. SB/SE front-line managers may not be engaged in the examination or survey of a taxpayer for more than 5 consecutive years (60 months) from date of assignment. The manager’s "date of assignment" starts when their employee applies time to the return and the manager is assigned as the case and/or issue manager.



### Note:



P-4-5 was revised to include SB/SE front-line managers on June 17, 2019. Managers now subject to P-4-5 have a 24-month transition period from June 17, 2019 to comply with the new policy for cases that were in process prior to June 17, 2019. For all new examinations started on or after June 17, 2019, the revised policy statement applies.

3. Employees who spend 200 hours or less on an examination cycle will not have that time considered in determining the 60-month limitation for the purposes of rotation requirements under P-4-5.

4. All appropriate levels of management are responsible for monitoring assignments to ensure proper examination rotation practices are followed. Group managers should use historical information systems, such as ERCS, to obtain inventory management data to assist with P-4-5 compliance, when assigning cases to their examiners. Managers should also refer to IRM 1.4.2.4, Control Activities, for additional information on identifying risk and establishing internal controls.


**1.4.40.4.6.3** **(04-05-2017)**

##### Surveying Cases

1. While cases should be started in accordance with Examination priorities, there may be returns that in the judgment of the manager or examiner warrant survey without taxpayer contact.

2. A return is surveyed before assignment if it is disposed of before contact with the taxpayer and prior to assignment to an examiner.



### Note:



The group manager must conduct a risk analysis prior to surveying a return before assignment. See _IRM 1.4.40.4.6.3.1_, Group Manager Risk Analysis, below.

3. A return is "surveyed after assignment" if after completing the initial return screening and/or the pre-contact analysis and evaluation of audit potential, but before examining any books and records, the examiner concludes that an examination is not warranted. See IRM 4.10.2.2, Initial Return Screening, and IRM 4.10.2.5, Decision to Survey a Return.


**1.4.40.4.6.3.1** **(04-05-2017)**

###### Group Manager Risk Analysis

1. Prior to assignment of a "non-mandatory" return or amended return, the group manager must conduct a thorough review of the return and case file information to complete a risk analysis and determine if the return should be assigned to an examiner in the group, transferred to another group, or closed survey before assignment.

2. The group manager's risk analysis considers:



   - Nature of the work (e.g. non-mandatory, priority, etc.),

   - Whether the examination will result in a material change,

   - Large, unusual or questionable (LUQ) items including those not selected during classification,

   - No change in prior year,

   - Statute of limitations (SOL),

   - Examination cycle, and

   - Group resources (e.g., the number of returns assigned to the group exceeds the number that can be examined and processed within the examination cycle; returns outside the group’s area of expertise; etc.).



     ### Note:



     If a return contains LUQ items, before surveying the return due to group resources, the group manager must consider transferring the return to another group with available resources.


3. After the risk analysis, if the group manager determines the return:



1. Warrants further review by an examiner, it will be assigned or transferred.

2. Should be closed survey before assignment, the group manager must follow the procedures in _IRM 1.4.40.4.6.3.2_, Survey Before Assignment, to document the reason for the survey.


**1.4.40.4.6.3.2** **(04-05-2017)**

###### Survey Before Assignment

1. A group manager may survey "non-mandatory" cases before assignment if the group manager's risk analysis indicates the return should be surveyed. It is critical that a group manager closely evaluate work needs when ordering returns, and that surveys be kept to a minimum.

2. Generally, group managers must use Disposal Code (DC) 31, Survey Before Assignment by PSP or Group, to close a return as survey before assignment.

3. Group managers must use DC 34, Surveyed Claims, to close claims for refund and requests for abatement as survey before assignment. In addition, claims for refund and requests for abatement surveyed before assignment cannot be closed paperless. See _IRM 1.4.40.4.6.3.2.3_, Survey Before Assignment - Claims for Refund and Requests for Abatement, below.


**1.4.40.4.6.3.2.1** **(04-14-2021)**

###### Paperless Survey Before Assignment

1. The group manager may survey a return before assignment using paperless survey procedures if at the time of closure the only paper in the case file is an electronic print (BRTVU, CDE, TRDBV, TRPRT, IMFOLT, TXMOD), and:



1. There are no workpapers or other documentation (e.g., Form 1900, Income Tax Survey) in the case file that needs to be retained, and

2. The original return was NOT requested (page 2 of the AMDISA does not show "Return Requested" ).


If the return does not meet the above criteria, it must be closed using paper survey before assignment procedures. See _IRM 1.4.40.4.6.3.2.3_, Survey Before Assignment - Claims for Refund and Requests for Abatement.



### Caution:

Survey before assignment claims for refund and requests for abatement cannot be closed paperless. Group managers must follow the procedures in _IRM 1.4.40.4.6.3.2.3_, Survey Before Assignment - Claims for Refund and Requests for Abatement, below.

2. The group manager must document the reason to survey a return before assignment using a Survey Reason Code (SRC) on Form 5351, Examination Non-Examined Closings, to the right of the Disposal Code field. The SRC (listed in paragraph (3) below) must also be entered on ERCS when closing the return from the group.

3. The SRC values and definitions available for paperless survey procedures are:



1. SRC A: No Large, Unusual or Questionable (LUQ) Items – Use if the primary reason for the survey is because there are no LUQ items on the return.

2. SRC B: No Change in Prior Year – Use if the primary reason for the survey is that the same issues identified on the current year return were just as significant in either of the two preceding years and were no-changed or had a small tax change.

3. SRC C: Beyond Cycle (includes statute issue) – Use if the primary reason for the survey is based upon currency and/or statute considerations.

4. SRC D: Lack of Resources – Use if the primary reason for the survey is due to a lack of resources.



      ### Reminder:



      SRC D cannot be used by examiners.

5. SRC E: Other – Use if no other code applies, and document the reason for the survey.

6. SRC F: Collectibility – Use if the primary reason for survey is based upon collectibility.

7. SRC G: Combat Zone – Use if the primary reason for the survey is because the taxpayer or taxpayer’s spouse is in a combat zone.

8. SRC H: Timing Issues – Use if the primary reason for the survey is a timing issue.

9. SRC I: De minimis Tax – Use if the primary reason for the survey is because there would be a de minimis tax change.


### Note:

Only one SRC can be entered. If more than one SRC applies, use the code that reflects the primary reason for the survey.

4. The return must be updated to status code 51 on ERCS. See IRM 4.7.5.7.3(9), Transfers and Closing.

5. The group must e-Fax Form 5351 and Form 3210 to Memphis CCP. See IRM 4.4.21.5.1.3, Form 5351, for instructions on completion of the form.



### Note:



Shred the electronic print. Do not send to CCP.


**1.4.40.4.6.3.2.2** **(04-05-2017)**

###### Paper Survey Before Assignment

1. The group manager **must use paper survey procedures** to survey a return before assignment if it doesn’t meet the conditions in _IRM 1.4.40.4.6.3.2.1_, Paperless Survey Before Assignment.



### Note:



For survey before assignment procedures for claims for refund and requests for abatement. See _IRM 1.4.40.4.6.3.2.3_, Survey Before Assignment - Claims for Refund and Requests for Abatement, below.

2. If the primary reason for the survey is other than those indicated in SRCs A through D listed in _IRM 1.4.40.4.6.3.2.1_, Paperless Survey Before Assignment, above, the group manager must document the SRC E: Other, on Form 5351, and include Form 1900 in the administrative case file clearly explaining the reason for the survey. See IRM 4.4.21.5.1.3, Form 5351, for instructions on completion of the form.

3. If a return is closed as survey before assignment using paper survey before assignment procedures, the GM must sign and date a stamp imprinted on each return (or return print). The format of the stamp should be as follows:



|     |
| --- |
| CLOSED—SURVEY BEFORE ASSIGNMENT<br> By \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ Date\_\_\_\_\_\_\_\_\_\_ |

4. The return must be updated to status code 51 on ERCS and closed to Memphis CCP using DC 31. See IRM 4.7.5.7.3(9), Transfers and Closing.


**1.4.40.4.6.3.2.3** **(04-05-2017)**

###### Survey Before Assignment - Claims for Refund and Requests for Abatement

1. Prior to surveying a claim for refund or request for abatement, managers must conduct a risk analysis. See _IRM 1.4.40.4.6.3.1_, Group Manager Risk Analysis.

2. Form 5344 is required to be completed to process the survey before assignment of a claim for refund or request for abatement because it results in a full allowance. See I4.38.1.7.3.1.22.7, Surveyed Claims, for instructions on completing Form 5344 for this purpose.

3. The group manager must document the reason for surveying a claim for refund or request for abatement on Form 1900 or an activity record.

4. The group manager must sign and date a stamp imprinted on each return (or return print). The format of the stamp should be as follows:



|     |
| --- |
| CLOSED—SURVEY BEFORE ASSIGNMENT<br> By \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ Date\_\_\_\_\_\_\_\_\_\_ |

5. The return must be updated to status code 51 on ERCS and closed to Memphis CCP using DC 34. See IRM 4.7.5.7.3(9).


**1.4.40.4.6.3.3** **(04-14-2021)**

###### Survey After Assignment Procedures

1. Group managers are required to indicate concurrence with the examiner’s decision to survey a return after assignment by signing and dating the stamp imprinted on each return (or return print). See IRM 4.10.2.5.2, Procedures for Surveying Returns After Assignment, for survey after assignment procedures used by examiners.



### Caution:



Cases closed as survey after assignment cannot be closed paperless because the examiner must complete the initial return screening or the pre-contact analysis and the evaluation of audit potential and document the reason for the survey and all actions taken to support the decision on Form 1900.


**1.4.40.4.6.4** **(02-03-2015)**

##### Transferring Office Examination Cases to Field Examination

1. There are instances when it is determined that an office examination case requires a field examination. This determination may occur at any time during the audit process; however, the decision to transfer the case should be made as early as possible. See IRM 4.11.29.15, Transferring Office Examination Cases to Field Examination, for detailed procedures.



### Note:



Cases that must be transferred outside of the area will be sent through PSP. The examiner must prepare Form 3185, Transfer of Return.


**1.4.40.4.6.5** **(05-19-2010)**

##### Delinquent Returns and Nonfiler Cases

1. Nonfiler cases may be assigned to a group for examination as a result of:



   - Collection referrals

   - Package audit procedures in open examinations

   - Information reports

   - Various projects


2. These cases require special treatment and consideration. Review IRM 4.12.1, Nonfiled Returns, for additional procedures.


**1.4.40.4.6.6** **(05-19-2010)**

##### Grade Level of Work for Field Examination Cases

1. Every employee must perform work consistent with the grade of their position.

2. See _IRM 1.4.40.4.6.6.1_, which provides guidelines for the grading of all field individual, corporate, and partnership returns. The IRM provides case assignment guides for other types of work.

3. During case assignment the group manager will review the case, and based on the grading criteria, determine the grade level for assignment. A final grade is determined at case closing and entered on the electronic Form 5344, Examination Closing Record, within RGS, if available, based on issues developed in the case.

4. Employees may perform some work above or below their grade level.

5. A group manager may provide an employee with the opportunity to perform a limited quantity of higher graded work, when appropriate, to enhance their career development.



### Caution:



A group manager must ensure, prior to the assignment of higher-graded work, that such work will not require more than 25 percent of the examiner’s direct examination time (DET). Review Document 11678, National Agreement, Article 16, for details. Retroactive pay is required when it is determined that the time spent on higher-graded work exceeds 25 percent in any four-month period. A group manager should either assign the work at the appropriate grade level or secure permission for a temporary promotion in advance. The National Agreement also provides for opportunities for developmental work in LB&I without a temporary promotion.

6. Once a case is placed in process, it is difficult for a group manager to control the time applied to the case. It is also difficult to control DET versus total time. Adequate managerial involvement is critical to ensure the 25 percent DET is not inadvertently exceeded when higher graded work is assigned to an examiner for developmental purposes.


**1.4.40.4.6.6.1** **(05-19-2010)**

###### Guidelines for Determining the Grade Levels of Field Examination Cases

1. This text provides guidance to a group manager for assigning and determining the final grade levels of regular field examination income tax cases.

2. The objectives of this guide are to establish a uniform system for evaluating income tax cases selected for assignment to revenue agents under the "one case, one agent" concept; to provide a better basis for determining workloads for financial planning; to provide valuable information in making position classification determinations; and to improve the utilization of an RA’s time and talents.

3. This guide will also aid in reviewing internal RA positions for grade structure change purposes. It does not evaluate an RA’s performance. In addition, it cannot be considered as the sole predictor of the appropriate overall grade level for individual positions. Variables such as extent of supervision or the impact of other duties are not given consideration in the guide.

4. It is emphasized this is primarily a guide and not a substitute for supervisory judgment.


**1.4.40.4.6.6.2** **(05-19-2010)**

###### Characteristics of Field Examination Cases

1. These guidelines apply to all individual returns (non-business and business), fiduciary returns, all types of corporations and partnership returns.

2. For purposes of this guidance, a case is defined as the primary return for one year plus other returns, if any, involving interrelated interests and/or transactions that require concurrent examination. The primary return is the return around which related entities and other types of returns revolve, regardless of how and when selected or assigned. Other returns are defined to include returns subsequent and/or prior to the primary return of the taxpayer, as well as returns for related taxpayers for the primary year and subsequent and/or prior years. When the primary return and related returns are examined by the same agent, the related returns will usually (for Management Information System purposes) carry the same grade as the primary return. If related entities are examined by other agents, each group of entities examined by a separate agent will be graded as a separate case under this guide.

3. This guidance has four parts as follows:



   - _PART I:_ Chart of Case Grading Factors (based on GS–0512 Classification Standards)

   - _PART II:_ NAICS Codes

   - _PART III:_ Probable Grade Levels of Cases Based on Type of Industry/Occupation, and Size

   - _PART IV:_ Matrix of Issues that may change determination made in Part I


4. The case grading guidelines discussed in this IRM are not intended to cover all possible factors that may influence a final case grade. New projects or programs, and other unusual situations that were not present in the sample at the time this guide was developed, will require a group manager to use judgment in grading a case. More reliance must be placed on the case grading factors in Part I for these situations.


**1.4.40.4.6.6.2.1** **(05-19-2010)**

###### Part I — Chart of Case Grading Factors

1. Part I consists of the position classification standard for the GS–512 RA occupation which forms the basis for determining the grade of a case. The standards have been adapted to evaluate cases rather than positions, therefore, factors such as supervision/guidance have not been included.

2. The case grading factors listed in the table below should be used for the final grading of cases.




| **Part I — Chart of Case Grading Factors** |
| --- |
| In arriving at a final grade, all factors do not have to be met, however, normally, more than one of the most important factors is necessary. These are: Accounting Systems and Methods, Issues and Knowledge, Guidelines and Tax Laws, and Scope and Effect. |






| GS–11<br> Accounting Systems | GS–12<br> Accounting Systems | GS–13<br> Accounting Systems |
| :-: | :-: | :-: |
| Independently examines systems which require a basic knowledge of principles/ methods of accounting and auditing as found in a variety of individuals, relatively small businesses, exempt organizations, and simple employee plans. Systems involve a variety of financial operations and accounting methods or specialized accounting practices unique to a particular industry. Use of basic investigative procedures to elicit information and establish facts. | In addition to GS–11 characteristics, the following concepts should be involved: Comprehensive knowledge of the principles/ methods of accounting and auditing to plan and conduct independently the complete range of examination and related investigations of a broad range of sizable business operations. Systems involve a variety of complex financial operations and unusual accounting methods or specialized accounting practices unique to a particular industry. Uses investigative skills to analyze incomplete records and reconstruct transactions from third party records. Develop information relative to complex fraud. | In addition to GS–12 characteristics, the following concepts should be involved: Mastery of the principles/ methods of accounting, auditing and corporate financial management to plan, coordinate, and conduct examinations of large, complex businesses, including those with substantial subsidiaries, diversified activities multiple partners, and national and international scope and operations. Accounting systems of size and complexity may warrant planning and coordinating the work of others. |






| GS–11<br> Issues/Knowledge | GS–12<br> Issues/Knowledge | GS–13<br> Issues/Knowledge |
| :-: | :-: | :-: |
| Fundamental knowledge of business and trade practices, procedures and conditions to analyze tax returns and related records to determine the reasonableness of deductible items, the reliability of reported income and expenses, including probable earnings in a wide variety of small businesses/industries and similar questions extending beyond the area covered by specific accounting or legal guides. | In addition to GS–11 characteristics, the following concepts should be considered: Knowledge of business financial management principles and practices concerning a variety of kinds and sizes of businesses, or specialized knowledge in a particular industry to (1) determine sources of income and verify expenses, (2) judge the propriety of such matters as intercompany transactions, accumulation of surplus, or compensation of officers, (3) examine trust activities and transactions in order to determine unrelated business income or prohibited transactions, or (4) determine items related to pension plans and appropriate deductions. | In addition to GS–12 characteristics, the following concepts should be involved: Specialized knowledge of major industries may be required so that expert judgements can be applied to business transactions. Business transactions may include mergers, acquisitions, leverage buyouts, and similar transactions. |






| GS–11<br> Guidelines/Tax Law | GS–12<br> Guidelines/Tax Law | GS–13<br> Guidelines/Tax Law |
| :-: | :-: | :-: |
| Guidelines include basic tax laws, IRS policies, rules and regulations to determine the taxpayer’s correct tax liability. Guidelines normally are specific to issues, but because of number/variety of issues, research is required to locate precedents. | In addition to GS–11 characteristics, cases require research and analysis of the Internal Revenue Code, rulings, court decisions, and IRS policies to examine returns where tax law or precedent cases do not directly apply including consideration of judicial decisions and legislative intent in cases involving the adoption of precedents. | In addition to GS–12 characteristics, cases require the use of the Internal Revenue Code, rulings, court decisions to resolve problems where there is little or no previous interpretation of statutory provisions. Laws are highly subjective, precedents are non existent, obscure or conflicting and significant tax change or precedent setting issues are involved. |






| GS–11<br> Scope and Effect | GS–12<br> Scope and Effect | GS–13<br> Scope and Effect |
| :-: | :-: | :-: |
| Results of audits affect the taxpayer by requiring corrective action for prior and current tax years and having a deterrent effect for future tax years. The impact may extend to other related taxpayers and/or unrelated taxpayers throughout whole industries. | In addition to GS–11 characteristics results of the audit affect the tax liability and, therefore profitability of major business entities and in some instances the treatment of accounting methods and techniques for tax purposes as they are employed throughout whole industries. | In addition to GS–12 characteristics, tax results are of major significance which affects the financial condition of many categories of taxpayers involving very large tax responsibilities. Important principles are developed resulting in new precedents. |






| GS–11<br> Contacts | GS–12<br> Contacts | GS–13<br> Contacts |
| :-: | :-: | :-: |
| Generally involve individual proprietor, corporate official, self-professional, most represented by local practitioners. The purpose of contacts is to influence and persuade the taxpayer or representative to comply with requirements, to provide information to resolve outstanding problems and issues or to pay tax liability. Contacts hold strong opposing views. They may be hostile, skeptical or uncooperative requiring the agent to use tact, persuasiveness, and diplomacy to obtain the desired results. | In addition to GS–11 characteristics, the following concepts should be involved: Officials of corporations of significant size, public officials, or practitioners of considerable attainment. Prominence of taxpayer presents problem of publicity or attitudes in locality. | In addition to GS–12 characteristics, cases involve contacts with persons who are prominent because of their reputation in their field, especially the accounting and tax fields; officials of large businesses with national reputations. |


**1.4.40.4.6.6.2.2** **(05-19-2010)**

###### Part II - North American Industry Classification System (NAICS) Listing

1. The North American Industry Classification System (NAICS) replaced the Principle Industry Activity (PIA) and the Principle Business Activity (PBA) PIA/PBA codes for tax periods 199812 and subsequent for individual returns. These codes appeared on some corporate and partnership returns starting in 1997 due to fiscal year overlaps.

2. Reference will be made to the appropriate NAICS to determine the class of the case. The primary return NAICS will be the determinant factor for placement in the appropriate class. If no NAICS appears on a return, group managers will determine the proper class based upon a review of the case file. Once a class has been determined, Parts I, III and IV should be used to determine the final grade. See NAICS Codes in RGS and ERCS, for NAICS classification codes.

3. The listing below reflects the respective Class Number for individual, business and fiduciary returns:



   - Class 1 – Manufacturing, Construction, Mining

   - Class 2 – Retail, Wholesale, Transportation

   - Class 3 – Services, Farming

   - Class 4 – Financial and Utilities

   - Class 5 – Nonbusiness Individual and Fiduciary


**1.4.40.4.6.6.2.3** **(05-19-2010)**

###### Part III—Probable Grade Levels of Cases Based on Type of Industry/Occupation and Size

1. The type of business or occupation and its relative size as measured by total assets and/or gross receipts and the dollar criteria for each business type is indicative of the issues encountered, tax law knowledge and accounting complexities normally encountered by revenue agents at the GS–12 and GS–13 levels. Part III is most applicable to the assignment of cases to revenue agents; whereas all four parts of the guide must be used when the case closes and a final grade is assigned.

2. The following criteria may be used for both case assignment and final grading. Size criteria alone must **not** be relied upon in arriving at a final grade; more weight should be placed on the case grading factors in Part I. If a case is graded at GS–11 based on industry class and size, and an upgradable issue is identified on the return, the case may be upgraded. See Part IV for the listing of upgradable issues.

3. The dollar criteria for each industry type was derived from a review of various cases in each class and is indicative of the issues, tax law knowledge and accounting complexities normally encountered by revenue agents at the GS–12 and GS–13 levels.

4. Determination of industry class for business returns will be made by reference to NAICS codes. Individual and fiduciary returns will be placed in Class 5 (Nonbusiness) unless their primary source of income is from a business. The classes are listed in the table below:



|     |
| --- |
| **CLASS 1**<br>**MANUFACTURING**<br> (Manufacturing, Construction and Mining) |






| Criteria | Probable<br>**GS–12** | Probable<br>**GS–13** |
| --- | --- | --- |
| Total Assets | $250K to $12M | Over $12M |
| or | - | - |
| Gross Receipts | $1M to $15M | Over $15M |





|     |
| --- |
| **CLASS 2**<br>**RETAIL, WHOLESALE AND TRANSPORTATION** |






| Criteria | Probable<br>**GS–12** | Probable<br>**GS–13** |
| --- | --- | --- |
| Total Assets | $1M to $12M | Over $12M |
| or | - | - |
| Gross Receipts | $2M to $33M | Over $33M |





|     |
| --- |
| **CLASS 3**<br>**SERVICES AND FARMING** |






| Criteria | Probable<br>**GS–12** | Probable<br>**GS–13** |
| --- | --- | --- |
| Gross Receipts | $3M to $33M | Over $33M |





|     |
| --- |
| **CLASS 4**<br>**FINANCIAL AND UTILITIES**<br> (Banking, Insurance and Utilities) |






| Criteria | Probable<br>**GS–12** | Probable<br>**GS–13** |
| --- | --- | --- |
| Total Assets | $0M to $115M | Over $115M |





|     |
| --- |
| **CLASS 5**<br>**NONBUSINESS INDIVIDUAL AND NONBUSINESS FIDUCIARY** |
| Cases under this class are graded as GS–11 unless possessing an upgradable issue as listed in Part IV of this Exhibit. If the primary source of income is from wages/salaries, the case will fall under this class even if a Schedule C or F is attached. If the primary source of income is from a business, the case will fall under one of the other classes. |


**1.4.40.4.6.6.2.4** **(05-19-2010)**

###### Part IV—List of Upgradable Issues that May Result in an Upgrade for Field Examination Cases

1. If a case is graded at a GS–11 level based upon Parts I, II and III, and an upgradable issue appears on the return, the case may be upgraded to a GS–12 after consideration of the facts in the case. These same 13 upgradable issues may cause a case to be upgraded from GS–12 to GS–13. However, the decision to upgrade a case to GS–13 is most often a determination that is based on case size and case complexity. Additionally, a 14th upgradable issue called "Unusual Complexity" is included to allow group managers to upgrade a case based upon features, facts and circumstances encountered during a particular examination.

2. The following table presents 13 upgradable issues which may cause a case to be upgraded from GS–11 to GS–12 and a 14th category "Unusual Complexity."




| _Part IV—List of Upgradable Issues that May Result in an Upgrade_ |
| --- |
| I. Controlled Group |
| 2\. Complex Like Kind Exchange |
| 3\. Liquidation/Reorganization |
| 4\. Foreign controlled (Exclusive of Significant Specialist Involvement) |
| 5\. Valuation issues (Exclusive of Significant Engineering Support) |
| 6\. Financial Products. e.g., commodities, straddles, etc. |
| 7\. LIFO |
| 8\. IRC 263A — Capitalization of Inventory Costs |
| 9\. IRC 482 — Allocation of Income/Deductions among two or more trades/business |
| 10\. IRC sections 741/742/743, Recognition/Character of Gain/Loss & Basis on Sale of a partnership. |
| 11\. Key Case TEFRA |
| 12\. Complex Fraud Development |
| 13\. Sensitive, High-Profile Taxpayer |
| 14\. Unusual Complexity |


**1.4.40.4.6.6.3** **(05-19-2010)**

###### Procedures for Field Examination Cases

1. The first step in applying this guide is to relate the return being assigned or graded to the five classes listed in Part III of these guidelines. All income tax cases will be graded. Classification of business returns in Classes 1 through 4 will be determined by reference to the NAICS code listings. If no NAICS code appears on a return, group managers will determine the proper class based upon a review of the case file. Individual and Fiduciary cases will be placed in Class 5 (Nonbusiness), unless it is more appropriate to place the case in another class. Primary source of income for cases in Class 5 is salaries/wages even though a Schedule C or F may be attached to the return.

2. During case assignment, a group manager will relate all facts known about a case to Parts I–IV. Part III may be most applicable, particularly the size criteria, such as total assets. Specific issues may not be known until the case is fully examined. However, during final case grading all four parts of the guide must be used, especially the case grading factors in Part I. Size criteria alone must not be relied upon for final case grading because normally other factors influence the difficulty of a case.

3. When assigning a final grade to a case, a group manager will first make reference to Part I of the guide. A general assessment will be made as to how each factor grades out. Normally, more than one of the major factors is necessary to influence the final grade. Following this process, reference can then be made to Parts II, III, and IV of the guide to determine how the size criteria grades out and whether any upgradable issues are present that might influence the final case grade. The objective is to use these four parts of the guide to make a decision on the difficulty of the case.

4. See _IRM 1.4.40.4.6.6.6_, which provides instructions for completing Item 32, grade of case, on Form 5344.


**1.4.40.4.6.6.4** **(05-19-2010)**

###### Case Grading for Special Situations for Field Examination Cases

1. A group manager may use their judgment to change the probable grade of a case before making an assignment. A group manager may suspect that special or complex issues or problems will be encountered in the examination and this is sufficient reason to justify upgrading the probable level of the case. On the other hand, a group manager, in view of the prior agent’s report, etc., may lower the probable grade level of a case on the basis that the scope of the examination will be limited or will only involve continuing and/or recurring issues such as travel and entertainment, repairs, depreciation, etc. These are sufficient reasons to justify assigning a lower grade level to the case.

2. Special situations that will require judgment in determining case grade are:



1. Package Examination—Give full credit for developing KEY CASE and all other cases in the package.

2. Flow-Through/Information Reports (e.g. AIMS control of Related Returns Procedures)—Give full credit if normal range of knowledge and auditing techniques is required to apply a previously identified issue. Give less than full credit if issues have been previously identified and are applied in a mechanical manner with less than normal knowledge requirements.

3. Subsequent Years—Refer to Flow-Through/Information Reports definition; full credit may be considered if additional issues evolve or are developed in subsequent years requiring a normal range of knowledge and auditing techniques.

4. Limited Scope—Give less than full credit if examination is so restricted in scope that the normal range of knowledge and auditing techniques is not required. Give full credit for examination of limited scope where normal range of knowledge and auditing techniques is required. (In this situation, the RA usually limits the scope.)

5. Specialist Involvement—Complexity of the case will include specialist’s involvement; however, final grade will depend on knowledge and auditing techniques required of the RA.


3. The difficulty of a case cannot be finally determined until the examination is completed. The determinations made prior to examination are not controlling. A group manager’s final determination of the case grade will be made upon completion of the examination. A group manager should note the basis used to downgrade the case within the case file.


**1.4.40.4.6.6.5** **(05-19-2010)**

###### Relationship of Guide to Position Management for Field Examination Cases

1. This guide does not supersede the existing Office of Personnel Management (OPM) standards for classifying internal RA positions. Rather, the provisions of this guide are consistent with the grade level criteria outlined in the OPM standards for the GS–0512 series. However, such position classification factors as supervision and guidance received, cannot be measured by this guide. Such factors are primarily related to the technical skills and knowledge demonstrated by an individual RA. The amount and kind of supervision required by a RA on a continuing basis may affect the grade of a position but not the grade of the cases assigned. Under normal supervision, the grade of an RA’s position depends upon a continuing workload of a wide range of cases at a given grade level.

2. Revenue agents may be assigned a limited number of cases above their grade level for developmental purposes. The assignment of higher or lower-level cases for short periods of time, to provide developmental opportunities, or to meet specific operational needs, does not affect the grade level of an RA’s position. Also, cases assigned at one grade level sometimes become significantly more difficult during the examination process. Such assignments often provide adequate developmental experiences. When developmental or priority assignments above the grade level of an RA are completed under closer than normal supervision, or supervisory instructions limit the scope of the examination, the assignment may be considered to be consistent with the RA’s grade.

3. A group manager and position classifiers must be aware of the distinctions between the grade levels of positions and grade levels of cases assigned.



1. A group manager is responsible for assigning cases consistent with a RA’s grade level, keeping developmental assignments within reasonable limits, and periodically apprising a RA of the distinctions between the grades of cases and the grades of their positions.

2. Position classifiers are responsible for making the final determinations on the grade levels of positions and providing advisory services to a group manager on position management and work assignment practices.


**1.4.40.4.6.6.6** **(05-19-2010)**

###### Recording Grade of Case on Form 5344, Examination Closing Record for Field Examination Cases

1. A group manager determines the grade of case for all field examination income tax returns including non-business and business, individual, fiduciary, partnership and all types of corporations, and tax shelter cases. The case grade is entered as a three digit number in item 32 of Form 5344. When a related return is being closed by the same RA who examined the primary return, enter the same three digit code as for the primary return, but followed by an "R" (for related). If related returns are examined by a different RA, each will be graded as a separate case, and the "R" will not be recorded. (See _IRM 1.4.40.4.6.6.4_, Case Grading for Special Situations for Field Examination Cases, for guidelines on grading cases with special situations).

2. In Item 32 of Form 5344, the first digit represents the class of return, the second digit represents the grade of the case at closing, and the third digit which will always be a "1" , has not been assigned a use; however, it must be completed to prevent terminal rejects. (Previously, the third digit was used for case upgrading based on complexities found during the examination).

3. Referring to Parts I, II, III and IV (IRM 1.4.40.4.6.1.2.1 through 4): The first digit on Item 32 of Form 5344 is the class number for the industry, occupation, or type of case that most closely resembles the activity on the examined return. The second digit is the second digit of the closing grade; that is, 1 represents GS–11 and below, 2 represents GS–12, and 3 represents GS–13. All four parts of the Case Guidelines for Determining Grade level of Case are needed to make the final grade determination. A "1" will be entered in the third digit for all cases.



### Example:



A Form 1065, U.S. Return of Partnership Income, filed by a taxpayer who raises race horses, has been graded as a GS–12 case by the group manager using all four parts of the Case Assignment and Grading Guide. Item 32 of Form 5344 would be completed as 321 for Class 3 (Services and Farming) and a final grade of GS–12. (remember that the third digit will always be a ‘1 ’). Related returns examined by the same RA who examined the primary return would be coded 321R. Related returns examined by other revenue agents would be coded without the R and graded as a separate case.


**1.4.40.4.7** **(04-05-2017)**

#### Managing Open Inventories

1. Effective inventory management is critical to all three balanced measures. A group manager should:



01. Communicate expectations,

02. Monitor progress,

03. Guide employee performance,

04. Improve the effectiveness of audit practices,

05. Meet procedural requirements,

06. Maintain an awareness of the status of cases under examination,

07. Regularly interact with examiners,

08. Make prompt decisions regarding examination scope,

09. Facilitate the timely completion of examinations, including discussing the case with the taxpayer or representative to facilitate receipt of requested information if the taxpayer/representative refused to provide it to the examiner and

10. Make timely decisions to expand the case to include other years or related taxpayers when applicable.


**1.4.40.4.8** **(05-19-2010)**

#### Collectibility

1. The starting point of addressing collectibility is conducting a quality audit. Quality Attribute 409 states collectibility should be considered throughout the examination. Examiners' pre-contact responsibility for collectibility potential is described in IRM 4.10.2.4.1, Collectibility, and IRM 4.20.1.2, Pre-Contact and Fact Finding - Determining the Scope. If collectibility is an issue in an assigned case, a group manager will make the final determination whether to survey the return or to limit the scope/depth of an examination. See IRM 4.20.1, Examination Collectibility Procedures, for additional information.


**1.4.40.4.9** **(05-19-2010)**

#### Case Inactivity

1. A fundamental philosophy of quality responsiveness to our external customers is that they are entitled to the prompt and proper resolution of their examinations. This philosophy also helps minimize the level of overage work in group inventories. The case file should document reasons for significant periods of inactivity. Refer to IRM Exhibit 4.2.8-1, National Standard Time Frames for Case Action.

2. While considering and keeping morale concerns in mind, as well as the relationships between examiners, a group manager should utilize transfers of cases between examiners to ensure continuity of case work. Cases should not be allowed to remain inactive for prolonged periods of time. The case file should clearly document reassignment actions taken.


**1.4.40.4.10** **(05-19-2010)**

#### Related Pickup Work

1. A group manager should strongly encourage and monitor multi-year and related pickup work. This is a specific area in which a group manager can have a key role in inventory management and one in which the use of time can be directly impacted. Quality Attribute 112 states prior/subsequent and related returns should be considered during the examination. See IRM 4.10.5, Required Filing Checks.

2. When approving related pickups, risk analysis should be considered to determine if the time required is worthy of the potential return on the investment.

3. Requisitions for returns and/or controls should be approved by a group manager after reviewing the examiner's reason for requesting the return.

4. A group manager should ensure that all examiners obtain approval before initiating an examination of a return previously requested for reference and information purposes (Source Code 45). A photocopy of Form 5345-D will be attached to the tax return as a permanent record.


**1.4.40.4.11** **(04-14-2021)**

#### Closing Returns — General

1. The group manager is responsible for ensuring that quality examinations are conducted. When a case is closed by an examiner, the group manager should review the case to ensure it is procedurally and technically correct. The scope of the review will vary based on the group manager’s knowledge of the specific examiner’s level of experience and work. At a minimum, the group manager must ensure the examiner:



   - Considered, applied and documented assertion and non-assertion of penalties when applicable.



     ### Reminder:



     If written supervisory approval of penalties subject to IRC 6751(b) was not obtained timely, impacted penalties must be removed from the report and the examiner must issue a corrected report (without impacted penalties) to the taxpayer prior to the case closing from the group. To be considered timely, effective for cases where the initial report was issued prior to May 20, 2020, written supervisory approval of penalties must have been secured prior to the issuance of a 30-day letter (e.g., Letter 915, Examination Report Transmittal; Letter 950, 30-Day Letter – Straight Deficiency). Effective for cases where initial reports are issued May 20, 2020, or later, written supervisory approval must be obtained prior to issuing any written communication of penalties that offers the taxpayer an opportunity to sign an agreement, sign a consent to assessment, or consent to proposal of a penalty.

   - Made required follow-up attempts to contact the taxpayer if the taxpayer did not respond to the initial contact letter (IRM 4.10.2.8.3, No Response/No Show Procedures.)

   - Considered and documented prior/subsequent year and related returns.

   - Properly completed and documented the minimum income probes.

   - Reconciled the tax and taxable income on the examination report to current TXMODA information.

   - Followed proper procedures to solicit payment if there is an unpaid deficiency and the case is agreed.

   - Reviewed the formal written protest or small case request, if applicable, and determined its adequacy, the need for further case development or prepared a rebuttal.

   - Reconciled the time on ERCS to Form 5344.


2. The goal is to forward a closed case as quickly as practical and in accordance with the National Standard Time Frames. See IRM 4.10.8.2.4.4, Time Frames for Closing Cases from the Group, and IRM Exhibit 4.2.8-1.

3. If a procedural or technical deficiency is noted, the case should be returned to the examiner for correction. The group manager should consider sharing the observation with the examiner as formal documentation.

4. Technical Services may return a case to a group for further development if the case meets the criteria in IRM 4.8.2.9.1, Case Return Criteria. Form 3990 is generally used to communicate between Technical Services and a group regarding reviewed cases.



### Note:



Technical Services' communication (e.g., Form 3990) should be given prompt and appropriate attention. In most instances, the case should be returned to Technical Services within 60 days of receipt in the group. If there is disagreement with the findings of Technical Services, the group manager should discuss the matter with the Technical Services group manager.


**1.4.40.4.11.1** **(02-03-2015)**

##### Advance Payments/Deposits

1. The group manager must emphasize to examiners the need to solicit payment in both fully and partially agreed examinations. See IRM 4.20.1.3, Issue Resolution - Solicit Payment, for guidelines for using the tiered interview approach for soliciting payment, securing levy source information, and coordinating with Collection.

2. An examiner will not solicit payment from a taxpayer until the examination is complete. However, if the taxpayer offers payment prior to closing as a means of stopping the accrual of interest, such payment will be accepted and processed as an advance payment on deficiency. See IRM 4.20.1.3.1.1, Process Payment Received.

3. If no agreement is secured and the taxpayer wants to make a remittance prior to closing as a means of stopping the accrual of interest, such remittance will be accepted. Prior to processing the remittance the examiner must determine whether it's a payment of tax or a deposit under IRC 6603, Deposits made to suspend running of interest on potential underpayments, etc. See IRM 4.20.1.3.1(4), Request Full Payment and IRM 20.2.4.9.2, IRC 6603 Deposits. In addition, see Rev. Proc. 2005–18, which provides procedures for taxpayers to make, withdraw, or identify deposits to suspend the running of interest on potential underpayments under IRC 6603.

4. The group manager must ensure that employees timely transmit remittances to the Submission Processing Center designated on SBSE Exam Payment Processing within 24 hours. Payments over $100,000 require special attention. See IRM 4.10.8.2.4, Large Dollar Cases.

5. Agreed unpaid deficiencies or overassessments in excess of $100,000 should close from the group within four calendar days of receipt of the report or waiver. See IRM 4.10.8.2.4.3.1, Large Dollar Cases: Agreed and Unpaid Deficiency, for additional processing instructions.

6. "Large dollar" cases require special processing. See IRM 4.10.8.2.4.3 for definitions and processing instructions.


**1.4.40.4.11.2** **(02-03-2015)**

##### No Change Closing Procedures

1. In addition to the steps in _IRM 1.4.40.4.11_(1) group managers should review the closed case to ensure:



1. The examiner has prepared the appropriate closing letter(s). The group manager must sign the closing letter before closing the case to CCP. See IRM 4.10.8.3, No-Change and No Liability Cases.

2. The examiner has followed the procedures in IRM 4.10.8.3.3, No-Change Report with Adjustments Impacting Other Tax Year(s) Filed, Delinquent or Not Due to be Filed, when applicable.


**1.4.40.4.11.3** **(04-14-2021)**

##### Agreed Closing Procedures

1. In addition to the steps in _IRM 1.4.40.4.11_(1) group managers should review the closed case to ensure:



1. The examiner has prepared the appropriate closing letter(s). The group manager must sign the closing letter before closing the case to CCP. See IRM 4.10.8.4.5, Closing Letters for Agreed Cases.

2. Penalties have been considered and applied when applicable and supervisory approval has been documented under IRC 6751(b). If approval was not timely, penalties under IRC 6751(b) must be removed from the report and the examiner must issue a corrected report (without impacted penalties) to the taxpayer following the guidance in IRM 4.10.8.13, Corrected Reports, prior to the case closing from the group.

3. The taxpayer(s) has signed the report. See IRM 4.10.8.2.4.2, Execution and Receipt of Audit Reports and Waivers.

4. The examiner has date stamped the report. See IRM 4.10.8.2.4.2(1).


**1.4.40.4.11.4** **(02-03-2015)**

##### Partially Agreed Closing Procedures

1. A group manager should encourage examiners to request partial agreements and solicit advance payment. See IRM 4.10.8.6, Partially Agreed Cases, for additional processing instructions.

2. After the partial agreement is processed, the completed case is closed as unagreed.


**1.4.40.4.11.5** **(04-14-2021)**

##### Unagreed Closing Procedures

1. It is in the IRS’ best interest to resolve tax controversies at the lowest possible level. A group manager and examiner are empowered to consider all the facts and taxpayer documentation provided. In addition, materiality and collectibility should be considered in resolving cases.

2. Examiners must inform their group manager when they believe a case will have unagreed issues (except no show/no response cases). The reason for the case being unagreed should be clearly communicated to the manager.

3. Unless specifically excluded from Appeals consideration, all cases are eligible to be forwarded to Appeals as long as the taxpayer submits an adequate small case request or formal written protest that includes the information required in Pub 5, Your Appeal Rights and How to Prepare a Protest If You Disagree. The following are specifically excluded from Appeals consideration:



1. Fewer than 365 days remain on the SOL when the case is received in Appeals (180 days if Appeals previously released jurisdiction of the case and returned it to Examination for additional work). See IRM 8.2.1.4, Receipt of New Assignment by an Appeals Technical Employee (ATE).



      ### Note:



      Examiners should issue a 30-day letter with a minimum of 240 days remaining on the SOL. If there are fewer than 240 days remaining on the SOL, examiners should issue Letter 5153, Examination Report Transmittal - Statute <240 Days (Straight Deficiency) (or similar letter depending on the type of closure), to transmit the report and notify the taxpayer additional time is needed for Appeals to consider their case if it is unagreed. See IRM 4.10.8.12.1, 30-Day Letters.

2. Request/claim for abatement of unpaid tax that is not an audit reconsideration. See IRM 4.10.11.3.2, Requests for Abatement - Overview of Examiner’s Responsibilities.

3. Taxpayer disagrees solely on moral, religious, political, constitutional, conscientious, or similar grounds. See IRM 8.1.1.4.1, No Appeals Conference or Concession on Certain Arguments.

4. Fraud cases involving pending criminal prosecution. See IRM 8.2.1.5, Returning a Case to Examination – ATE.


4. A fully developed case should contain an easy to follow audit trail and the evidence needed to support the adjustments proposed in the examination report. At a minimum, the workpapers should:



   - Address the facts, law and argument for each issue,

   - Indicate that any court cases cited by the taxpayer were reviewed,

   - Clearly reflect the dollar-amounts allowed and disallowed, and

   - Contain an alternative position, if applicable.



     ### Note:



     If an alternative penalty is subject to IRC 6751(b), it is subject to the same supervisory approval requirements as a primary position.


5. The group manager must review an unagreed case file and return it to the examiner if:



1. Penalties were not timely approved under IRC 6751(b). If approval was not timely, penalties under IRC 6751(b) must be removed from the report and the examiner must issue a corrected report (without impacted penalties) to the taxpayer prior to the case closing from the group; or,

2. The issues were not adequately developed.


### Note:

If the case is being closed to Appeals, see IRM 4.10.8.12.9.3(2), Request for Appeals Conference, for guidance on adequacy of formal written protests and small case requests.

6. The group manager's actions must be documented on Form 9984 or its RGS equivalent.


**1.4.40.4.11.5.1** **(04-05-2017)**

###### Unagreed Closing Procedures - RA Group Managers

1. ) RA group managers are **required** to make contact in person or by telephone with taxpayers and/or representatives on all unagreed cases to attempt to resolve the tax controversies in order to reach an agreement. If agreement cannot be reached, Fast Track Settlement (FTS) should be offered, if applicable. FTS should not be offered if the group manager has not spoken to the taxpayer and/or representative. See IRM 4.10.7.5.6, SB/SE Fast Track Settlement, for additional information.



### Note:



The 30-day letter generally should not be issued unless the manager has contacted the taxpayer and/or representative.

2. If the issues cannot be resolved, a conference is not desired, or FTS is not initiated, the group manager will return the case to the examiner for preparation of a 30-day letter and report.

3. The group manager must review the unagreed report for accuracy and sign the 30-day letter prior to the issuance of the unagreed report to the taxpayer and representative, if applicable.



### Note:



The 30-day letter should not be issued if there are fewer than 240 days remaining on the SOL. See _IRM 1.4.40.4.11.5_(3), Unagreed Closing Procedures.


**1.4.40.4.11.5.2** **(04-14-2021)**

###### Unagreed Closing Procedures - TCO Group Managers

1. When a taxpayer has requested their case be sent to Appeals, TCO group managers are **required** to make contact in person or by telephone with the taxpayer and/or representative to conduct a group manager’s conference and attempt to resolve the tax controversies in order to reach an agreement. ERCS action code 09, Conference with Manager, should be used to identify the date and time of a scheduled managerial conference. If agreement cannot be reached, FTS should be offered, if applicable. FTS should not be offered if the group manager has not spoken to the taxpayer and/or representative. See IRM 4.10.7.5.6 for additional information.



### Note:



With the exception of no-show cases, TCO group managers are **strongly encouraged** to make contact with taxpayers and/or representatives on unagreed cases closed for issuance of a notice of deficiency.

2. If the issues cannot be resolved, a conference is not desired, or FTS is not initiated, the group manager will forward the case to Appeals.


**1.4.40.4.11.6** **(02-03-2015)**

##### Short Statute Cases — 180 Days or Less

1. The group manager **must** avoid having short statute cases in group inventory. See _IRM 1.4.40.4.3_, Statute Controls, for guidance.

2. Returns with 180 days or less remaining on the SOL must be placed in a red folder. This folder will flag the case until it is closed by CCP.


**1.4.40.5** **(04-14-2021)**

### Monitoring Reports Overview

1. The data for management information reports and tables is derived from the AIMS database. The Tennessee Computing Center produces tables for each area, territory, group and campus examination function. The data are transmitted monthly to the Detroit Computing Center for additional report generation.

2. ERCS reports are generated at the group level and are used to monitor case statutes, progress, and status. The group, territory, and Area can generate reports from ERCS. See _IRM 1.4.40.5.8_, Reports to be Worked by the Group, for more detailed discussion.

3. A group manager should consult with their TM regarding the monitoring tools they are **required** to use and the frequency for using such tools. Some monitoring tools are optional and others have required use. For example, AIMS Table 4.1 must be worked within 5 days of receipt of the email in the group manager's inbox, see _IRM 1.4.40.5.2_, AIMS Table 4.1; and TCO managers should review the Inventory Analysis Report (TCO) weekly, for all examiners in the group, see _IRM 1.4.40.5.4_(2), Inventory Analysis Report - TCO.


**1.4.40.5.1** **(05-19-2010)**

#### AIMS Tables 36

1. Table 36, _Examination Program Monitoring_, provides all levels of management concise analytical information for use in managing the Examination function. The table provides data from AIMS which is used to monitor examinations, inventory, surveyed returns, and accepted returns from classification.

2. Table 36 shows a group’s accomplishments for the current fiscal year **excluding dollar accomplishments**. These accomplishments are divided between training and non-training returns. Data is categorized by type of returns such as individual, corporate, partnership, and claims. Table 36 shows cases in Status 10 through Status 90 and contains the following:



   - Inventory aging information

   - Current month closures

   - Hours per return

   - Total claims closed

   - Returns started in current month

   - Mix of returns


3. This information is grouped into the following categories:



   - Activity Code

   - File Year

   - DIF/DIF Related

   - Local Source

   - Shelters

   - NRP

   - Campus Contacts/IRP

   - Fraud/Enforcement


4. When analyzing Table 36, it is important to look behind the numbers. The statistics provided by this table provide trends. To understand the trends identified:



1. High hours per return may reflect the group is pursuing issues which do not warrant the time being expended. Ineffective planning and scheduling practices or poor examination techniques contribute to higher time on cases.

2. Table 36 also provides the number of prior year returns assigned to the group. By monitoring the "returns beyond cycle" columns, a group manager can adjust the inventory mix to meet the examination cycle and prior year guidelines.

3. Fraud, joint committee, and other cases are excluded and are categorized on Table 36 as "returns with exclusions."

4. The differentiation "with or without exclusions" is determined based on source code, status code and project code information. This highlights one important aspect of proper code utilization.

5. Review the "no time applied" and "program monitoring" columns to monitor priority returns in unopened status.

6. "Aging time applied" categorizes a group's inventory by months in-process (status 12). Cases "over 12" months should be a relatively small portion of a group's inventory and require the immediate attention of a group manager. An excessive number of cases in either the "6–9" month or "10–12" month category is an indicator of a potential future problem. Consider conducting in-process case reviews when cases are 4–6 months of age with the emphasis on completion of these cases. This will assist in reducing the percentage of overage cases.

7. When claims are identified in the "Claims on Hand" column, consult Table 8.1 to identify claims which require prompt attention.

8. There are additional uses for Table 36. A group manager should consult the TM on a regular basis to determine monitoring priorities.


**1.4.40.5.2** **(05-19-2010)**

#### AIMS Table 4.1

1. Table 4.1 is one of the most urgent of the AIMS tables. It must be worked within **five days** of receipt of the email in the group manager's inbox. It must be dated and initialed by a group manager and a support staff member upon completion. Table 4.1 is a monthly report which lists returns in status codes 05, 06, 08-19, with statute dates that (according to AIMS) have expired or will expire within 180 days.

2. The PCS also generates a similar statute control report (PCS Report 4–4, TEFRA One-Year Assessment Statute Date List. See Exhibit 4.29.4-1, PCS Reports).

3. The ultimate responsibility for statute protection rests with a group manager. Accordingly, the Table 4.1 should be reviewed carefully to ensure that all prior year returns are properly accounted for on AIMS. IRM 4.4.27.5.1.1, Procedures for Working Statute Control Report, provides the necessary steps required to work this table. Also see IRM 25.6.23.5.10, AIMS Tables 4.1 and SC 4.0.


**1.4.40.5.3** **(05-19-2010)**

#### Other AIMS Tables

1. A description of other AIMS Tables may be found in IRM 4.4.27, Reports.


**1.4.40.5.4** **(04-14-2021)**

#### Inventory Analysis Report - TCO

1. The Inventory Analysis Report (TCO) provides a "snapshot" of the inventory currently assigned to each TCO. The report provides the number of cases by activity code and whether or not a return has been in process more than 120 days. The report also provides information on the number of returns by action code. A careful analysis of this report provides the group manager with current information regarding the amount of "workable" inventory, i.e. inventory in action codes 05, 06, 08, or 10. These action codes indicate cases that are in process versus cases that are in report status or awaiting closure or action by the group manager or clerk. The ERCS Inventory Analysis Report (TCO) should be reviewed when ordering and assigning new work to ensure examiner inventories are balanced to address overall quantity and cycle time concerns.

2. On a weekly basis, the group manager should review the Outlook Planning Calendar and the Inventory Analysis Report (TCO) for all examiners in the group. See IRM 4.10.2.6, for guidance on TCO’s use of the planning calendar. If inventory level issues are identified, the manager should review the Action Code Report. The weekly review may prompt the manager to meet with the employees to discuss inventory scheduling practices.


**1.4.40.5.5** **(05-19-2010)**

#### NQRS and EQRS Reports

1. The Field and Specialty Exam Quality (FSEQ) reviews a statistically valid area level sample of closed SB/SE cases against the quality attributes. NQRS is a parallel system to EQRS and is used to collect data from FSEQ reviews. NQRS data is used to provide quality scores for field and office examination that are included as a component of the Business Results measurement.

2. The FSEQ is responsible for providing quarterly reports of quality results at the area and national levels. NQRS provides various standard reports that can be accessed by users at the area, territory and group levels; however, data is not available below the territory level. Territory data is not statistically valid, but may be used as indicators in quality improvement efforts. Reports and data should be generated using 12-month periods in order to provide the best comparative analysis. NQRS trends and corrective measures requiring attention will generally be covered at territory meetings. Inquiries involving NQRS quality data/interpretation and requests for presentations should be made by the TM to the FSEQ program manager.

3. NQRS reports are additional tools to assist a group manager in the development of examiners and in the accomplishment of quality examinations. A group manager should involve examiners in identifying improvement opportunities for attributes that necessitate corrective action. This is a good forum for sharing expertise and experience among all examiners in a group.

4. Group managers can secure current NQRS reports for their territory and Area from NQRS. See Quality Knowledge Base.

5. EQRS reports can be generated at the group level. EQRS provides a group manager the ability to generate reports on the results of the reviews that have been entered into the system. These reports can be used to:



1. Share the results of individual reviews with an employee;

2. Compile the results of multiple reviews during a rating period for use when preparing an employee's mid-year review or annual performance appraisal provided that the reviews have been shared timely with the employee;

3. Identify the top-scoring and bottom-scoring quality attributes within your group; and

4. Compare the group results to territory, Area and National NQRS results.


6. To secure EQRS or NQRS reports, group managers must request access through BEARS. See Embedded Quality Field System Information.


**1.4.40.5.6** **(05-19-2010)**

#### PCS Reports

1. Pass-Through Control System Reports — PCS has a variety of reports available for use by campus personnel, area coordinators, and field groups. Refer to IRM 4.29.4, PCS Reports, for a list of the reports.

2. Report 4–4, TEFRA One-Year Assessment Statute Date List — Lists all records on the PCS with a TEFRA one-year assessment date on the investor record. Key case information for linkage records are reflected on the report.



### Note:



It would be rare for an SB/SE group to have a TEFRA investor return in the group. Generally, investors worked in the group for non-TEFRA issues are routed to the Campus CTF after a partial assessment. The RA should coordinate closure with the Technical Services TEFRA coordinator if the RA issues a RAR for both the non-TEFRA and TEFRA issues so PCS controls can be removed before closure at the terminal.


**1.4.40.5.7** **(04-14-2021)**

#### ERCS Reports

1. IRM 4.7.6, Reports, provides information on all ERCS reports and their uses. The reports a group manager will generally use at the group level can be found within the following sections:



   - Statute Expiration Reports — IRM 4.7.6.8

   - Inventory Reports — IRM 4.7.6.4

   - Time Analysis Reports — IRM 4.7.6.5

   - Monitoring Reports — IRM 4.7.6.6

   - Count Reports — IRM 4.7.6.7

   - Tax Auditor Reports — IRM 4.7.6.9

   - Miscellaneous User Reports — IRM 4.7.6.14 (e.g., Form 3210 Reports — IRM 4.7.6.14.4)


2. Statute Expiration Reports — IRM 4.7.6.8.



   - Pending Statute Report — IRM 4.7.6.8.4

   - 895 Report — IRM 4.7.6.8.1

   - Examination Returns Control System (ERCS), Statute of Limitations - IRM 4.7.3


3. Inventory Reports — IRM 4.7.6.4.



   - Overage Report (IVL) — IRM 4.7.6.4.7

   - Status Report — IRM 4.7.6.4.10

   - Unassigned Inventory Report — IRM 4.7.6.4.15 and Unassigned Inventory by TSC — IRM 4.7.6.4.14

   - Overage Requisitions Report — IRM 4.7.6.4.8

   - Alpha IVL (Inventory Validation Listing) — IRM 4.7.6.4.2

   - Agent Analysis (4502) — IRM 4.7.6.4.1

   - Closed Case Report — IRM 4.7.6.4.4

   - In Transit Status Report — IRM 4.7.6.4.5


4. Time Analysis Reports — IRM 4.7.6.5.



   - High Time Report — IRM 4.7.6.5.6

   - Case Time Analysis — IRM 4.7.6.5.2

   - DET and Non-DET Analysis — IRM 4.7.6.5.5

   - Inactive Case Report — IRM 4.7.6.5.7

   - Daily Time Report — IRM 4.7.6.5.4

   - Status 12 with No Time —IRM 4.7.6.5.8


5. Monitoring Reports — IRM 4.7.6.6.



   - Prior Year Report — IRM 4.7.6.6.4

   - Previously Closed Returns — IRM 4.7.6.6.3

   - Fraud Report — IRM 4.7.6.6.1

   - Returns by Activity Code — IRM 4.7.6.6.5

   - Returns by Project Code — IRM 4.7.6.6.6

   - Returns by Source Code — IRM 4.7.6.6.7

   - Work Awaiting Approval — IRM 4.7.6.6.10

   - Returns Related to a Specific Return Report — IRM 4.7.6.6.8


6. Activity Code Count Report — IRM 4.7.6.7.1. The Activity Code Count Report provides a count of all cases in an AAC by employee and activity code. This report also counts cases in status 10 and 12.

7. In addition to the reports listed above, TCO group managers will generally use the following Tax Auditor Reports — IRM 4.7.6.9



   - Action Code Report — IRM 4.7.6.9.1

   - Appointment Scheduled Report — IRM 4.7.6.9.2

   - Group Purge Report — IRM 4.7.6.9.3

   - Inventory Analysis — IRM 4.7.6.9.4

   - Monthly/Weekly Schedule — IRM 4.7.6.9.5

   - Overage Purge Report — IRM 4.7.6.9.6

   - Overnight Inventory Report — IRM 4.7.6.9.7

   - Tax Auditor Daily Report — IRM 4.7.6.9.8

   - Tax Auditor Scheduler — IRM 4.7.6.9.9


**1.4.40.5.8** **(08-25-2025)**

#### Reports to be Worked by the Group

1. Examination groups will work the following reports as applicable:



   - _IRM 1.4.40.5.8.1_, Inventory Validation Listing (IVL)

   - _IRM 1.4.40.5.8.2_, AIMS Weekly Update Reports

   - _IRM 1.4.40.5.8.3_, TC 424 Reject Register

   - _IRM 1.4.40.5.8.4_, Statute Date Override Report

   - _IRM 1.4.40.5.8.5_, Unexplained Update Report

   - _IRM 1.4.40.5.8.6_, Dropped AIMS Report

   - _IRM 1.4.40.5.8.7_, AAC Difference Report (ADIF)


**1.4.40.5.8.1** **(08-25-2025)**

##### Inventory Validation Listing (IVL)

1. Annually, each group performs a complete inventory validation retrieved from the statistical sample inventory validation system (SSIVL). The validation involves verifying the physical presence of returns and all AIMS data on all returns shown on the IVL. IRM 4.4.16, Inventory Control, provides time frames and instructions for performing this validation.


**1.4.40.5.8.2** **(08-25-2025)**

##### AIMS Weekly Update Reports

1. The report informs a group a change has occurred on the taxpayer’s account or other information which a group needs to know. It’s generated only when a change occurs at Master File that affects a case in a group. The reports reflect changes such as the filing of an amended return or a change in the taxpayer’s address. See IRM 4.4.27.5.7, AIMS Weekly Update Reports.


**1.4.40.5.8.3** **(08-25-2025)**

##### TC 424 Reject Register

1. This report informs a group manager a request to establish a database and/or secure a return Transaction Code (TC) 424 has not been accepted at Master File. The report os distributed weekly to all affected examination groups. It provides a code which explains why the account rejected. A taxpayer’s account appearing on the register will require follow-up, correction, monitoring, and/or re-input of the requisition.


**1.4.40.5.8.4** **(08-25-2025)**

##### Statute Date Override Report

1. This report lists returns when statute dates on ERCS and AIMS are different and ERCS has been changed to reflect the statute date on AIMS. For example, when the return was requested through ERCS, the normal statute date was generated. When the requisition became fully established on AIMS, the statute date reflected a late-filed return. ERCS is corrected to reflect the AIMS statute date.


**1.4.40.5.8.5** **(08-25-2025)**

##### Unexplained Update Report

1. During the weekly comparison, the AIMS values for project codes, source codes, status codes, activity codes, aging reasons, claim amounts, and POD codes are compared to the ERCS values. If ERCS is updated from the information on AIMS, this report is generated. Special attention should be given to status code changes. See IRM 4.7.6.12.5, UUPF (Unexplained Update) Report.


**1.4.40.5.8.6** **(08-25-2025)**

##### Dropped AIMS Report

1. This report lists records open on ERCS but reflecting no data on AIMS. The report is distributed to the group and must be worked. The report should be compared with AIMS and action taken to resolve the discrepancy. See IRM 4.7.6.12.2, DARF (Dropped AIMS) Report.


**1.4.40.5.8.7** **(08-25-2025)**

##### AAC Difference Report (ADIF)

1. This report lists returns where the AIMS and ERCS AAC’s differ and there are no pending updates or flags in the ERCS database to explain the difference. This report should be printed and worked weekly after the AM7109 file has been processed. See IRM 4.7.6.12.1, ADIF (AAC Difference) Report.


**1.4.40.6** **(05-19-2010)**

### Group Manager Expectations

1. A group manager plays a vital role in accomplishing the mission of the IRS. It is essential that all levels of management identify and prioritize expectations.

2. A group manager develops the expectations for the group in conjunction with the TM. The TM will share the Area business plan, emphasizing the relationship of the Area business plan to the Balanced Measurement System and individual commitments. A group manager and TM will jointly identify opportunities, agree on goals, develop plans and jointly reach commitments on those plans. These should include the performance management objectives in a group manager's Managerial Performance Plan. These expectations must come within the provisions of section 1204 of the Restructuring and Reform Act of 1998 (RRA 98).


**1.4.40.6.1** **(05-19-2010)**

#### Performance Management System (PMS)

1. PMS is the appraisal system used to evaluate IRS non-bargaining unit employees. It consists of an ongoing process of setting expectations, monitoring, evaluating and recognizing performance. The IRS’ performance management system is designed to strengthen the linkages between performance management and the IRS’ mission, strategic business goals, business plans and the Balanced Measurement System.

2. The performance agreement for a group manager consists of:



   - Responsibilities – representing the core values of the IRS, what is important to us as an organization and common to all executives, managers and management officials

   - Commitments – distinct actions/desired results to be achieved during the performance period

   - Summary Evaluation – balances the Retention Standard, Responsibilities and Commitments to determine the final rating


3. Objectives establish specific expectations for each group manager. They provide the basis for monitoring work, providing feedback on progress and recognizing accomplishments. A group manager's success in executing programs and implementing IRS policies is reflected in their achievement of PMS objectives.

4. Feedback on the progress toward these goals based on a group manager's actions and activities during the year will be obtained through the following:



   - Operational reviews

   - Periodic briefings

   - Mid-year assessments

   - Year-end PMS appraisal


5. Refer to the Human Capital Office IRS Leadership Competencies website located at IRS Leadership Competencies for a listing of core responsibilities and leadership competencies for group managers.

6. A group manager is expected to prepare a self-assessment. For guidance visit the Human Capital Office, Performance Management website Performance Management - Writing Self-Assessments.


**1.4.40.6.2** **(04-14-2021)**

#### Federal Managers’ Financial Integrity Act of 1982 (FMFIA)

1. An important aspect of workload management and quality control is the establishment of group controls and reviews. Internal controls are a vital tool allowing each manager to evaluate and monitor their programs proactively and eliminate deficiencies timely.

2. All managers have a responsibility to perform periodic monitoring to review the accuracy and effectiveness of internal controls. As required by IRM 1.4.2, Monitoring and Improving Internal Control, all managers are responsible for ensuring their programs have effective controls in place and to monitor those controls for continued effectiveness over time. See Risk Management and Internal Controls and OMB Circular A-123, Management’s Responsibility for Enterprise Risk Management and Internal Controls, for additional information.

3. The Federal Managers’ Financial Integrity Act of 1982 (FMFIA) was implemented by the Office of Management and Budget (OMB) Circular A-123, Management Accountability and Control. Its purpose is to safeguard assets and to provide for compliance with law. Refer to IRM 1.4.2 for a detailed explanation.


**1.4.40.6.3** **(05-19-2010)**

#### Developing Group/Team Expectations

1. A group manager's relationship with the TM is very important. The first step in establishing this relationship is to understand the TM’s expectations. A discussion with the TM regarding Operating Division, Area, and territory goals and the assessment of the current condition of the group is the best starting point.

2. Open lines of communication are very important. A group manager should keep both the TM and the group informed of significant matters. Priorities during the year will change and the TM expects a group manager to be flexible. At the same time, a group manager should let the TM know the impact of shifting priorities on resources and programs. A group manager is expected to be a team player. This may result in sacrificing group goals to meet broader organization goals.

3. After a group manager prepares expectations, ensure each is understood and strive to accomplish the expectations. Ensure the provisions of IRM 1.5, Managing Statistics in a Balanced Measurement System, and section 1204 of the Restructuring and Reform Act of 1998 are met when setting expectations for the group or agreeing to those set at a higher level.



### Reminder:



IRM 1.5, Managing Statistics in a Balanced Measurement System, provides guidance in using enforcement statistics. A group manager's expectations and evaluation of an examiner's performance must not be based on enforcement statistics. For example, a group manager should be concerned about the group’s no-change rate. However, a group manager **cannot** establish a numeric goal/percentage for the no-change rate for examiners. Each examiner’s work and inventory must be assessed on its own merits.


**1.4.40.6.4** **(05-19-2010)**

#### Communicating Expectations to Employees

1. Communicating a group manager's expectations and procedures to employees is very important. The high-level definitions of the CJEs are the same across all IRS occupations. The elements are:



1. Employee Satisfaction – Employee Contribution

2. Customer Satisfaction – Knowledge

3. Customer Satisfaction – Application

4. Business Results – Quality

5. Business Results – Efficiency


2. All of a group manager's employees have predetermined CJEs and expectations are linked to these elements. For example:



1. Element — Employee Satisfaction–Employee Contribution: an employee willingly helps other employees in the group to resolve a problem and shares knowledge with the group.

2. Element — Customer Satisfaction–Knowledge: an employee identified a potential hardship on a refund hold and made a decision that the issue did not meet hardship criteria; an employee demonstrated knowledge to deal with the unanticipated situation and applied knowledge of IRS procedures and research materials to make the correct decision.


3. A group manager should establish themself as the leader, but at the same time maintain an atmosphere of flexibility. Encourage employee engagement and discuss their ideas in an open forum. Once a decision is made, solicit mutual agreement and ensure understanding on the direction to be taken.

4. New procedures and programs will require implementation. As the team leader, it is a group manager's responsibility to communicate any new practices to employees in a positive manner, using a partnership approach. The success of new procedures and programs rests on a group manager's ability to share and implement them in a positive manner. Remember, it is a group manager's responsibility to keep the morale of the group high by taking positive actions toward group activities and operations.



### Reminder:



Managers must communicate established practices and procedures to new employees (e.g., Form 3210 procedures).

5. Through open communication, a group manager has the best chance of gaining the group’s commitment to the organization’s goals and expectations. As a group manager prepares to set and communicate the expectations for the group, they should remember the style and methods of communication used by former supervisors. A group manager should use the effective communication methods used by others as a model. To be successful a group manager should be prepared to do the following:



1. Share the area/territory goals;

2. Share group expectations;

3. Ensure employee understanding;

4. Encourage employee input; and

5. Solicit employee support.


6. Remember, realistic, challenging goals should motivate and encourage a high level of performance by group employees. A group manager sets the tone for the group.


**1.4.40.6.5** **(05-19-2010)**

#### Monitoring and Follow-up Procedures

1. Once a group manager has established and communicated expectations to employees, monitoring systems should be established to assess progress. Achievements and accomplishments require planning, execution, and monitoring. Depending on what area a group manager is monitoring, feedback may be specific, written, or informal. Some key areas a group manager will monitor are: direct exam time, overage inventory, quality, and statutes. Occasionally, review the monitoring system to determine if it requires revision based on changing priorities and needs.

2. After expectations have been established, shared, and a monitoring system is in place, establish follow-up procedures. The formality and structure of follow-up procedures will depend on the area involved.



### Example:



Abusive trust arrangement cases being monitored by Project Code 0233 may no longer be a priority area. Thus, discontinue running Project Code Report on ERCS. Share changes in priorities with examiners.


**1.4.40.7** **(05-19-2010)**

### Guiding and Evaluating Employees

1. A group manager is responsible for guiding the activities of the group and evaluating employees. There are a number of management tools available. They include but are not limited to the following:



   - Group manager concurrence meetings (Field Exam only)

   - In-process case reviews

   - Workload reviews

   - On-the-job visits

   - Closed case reviews

   - Technical time report reviews (ETTR/EPR)

   - Day/Morning After reviews

   - Ongoing observation


2. Information obtained through the above reviews and visits must conform to the requirements of Document 11678, National Agreement.


**1.4.40.7.1** **(04-14-2021)**

#### Performance Appraisal

1. The formal mechanism for providing written feedback about an employee’s accomplishments is Form 6850-BU or Form 6850-NBU. IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs), contains detailed guidance for evaluating performance. The performance appraisal serves as a:



   - Record of performance;

   - Basis to provide further training;

   - Tool to improve performance;

   - Document for personnel actions; and

   - Rating of Record.


2. Under the performance evaluation system, during an employee’s probationary period, they must demonstrate fully successful performance. This requires a group manager to closely monitor and review a probationary employee’s work. See IRM 6.430.2.4.3, Employees Serving Probationary Periods.

3. Managers should work closely with employees who are performing poorly, including probationary employees and provide them with guidance/direction designed to assist them in improving performance. If performance improves, managers should document the improvement accordingly. If performance fails to improve, refer to IRM 6.430.2 and seek appropriate advice to determine next steps.



### Caution:



Managers should seek advice from their TM and LR Specialist as soon as they recognize the performance of an employee is unacceptable.

4. Documentation of Performance:



1. Providing feedback to the employee (positive and constructive) is essential to maintaining and/or improving their performance.

2. Managers should keep an employee's overall performance in mind when they discuss work and other activities. Let them know when some aspect of performance may influence their performance rating, a promotional opportunity or other personnel action.

3. Recordation serves as a snapshot of employee performance. Adequate documentation will remind managers of changes in performance over the rating period.


### Reminder:

Employees must be notified of decreased work performance per guidance in IRM 6.430.2.3.3, Acknowledging Decreased Work Performance.

5. Managers should be concise when writing review narratives, but descriptive enough to provide an accurate picture of the strengths, development needs, and accomplishments of the employee in each CJE. See IRM 6.430.2.4.6, Completing Appraisal Narratives.

6. Performance evaluations provide a uniform means for a written evaluation and rating of each employee's proficiency.



   - IRM 1.5, Managing Statistics in a Balanced Measurement System, describes how balanced measures are used to support individual as well as organizational performance. The three balanced measures are: Employee Satisfaction, Customer Satisfaction, and Business Results. These three balanced measures are part of every individual and organizational performance evaluation system within IRS.

   - IRM 1.5.2 Uses of Section 1204 Statistics, provides specific guidance for SB/SE use of measures. This IRM provides information about the prohibition on the use of ROTERs to evaluate employees or to impose or suggest production quotas or goals.


7. Formal employee evaluations represent the sum of what the manager has observed in each employee's work, using feedback, reviews, visitations and other techniques discussed in this manual. Managers should consider the following when evaluating performance for an annual appraisal:



   - Position description

   - Critical Job Elements (CJEs)

   - Mid-year and other progress reviews

   - Employee’s work products (management briefings, memos)

   - Employee’s self-assessment

   - Feedback from taxpayers and representatives

   - Team assignments and contributions to work group

   - Special achievements


8. Each employee will receive an annual performance evaluation. See information about Performance Appraisal Due Dates in the National Agreement, Article 12, Exhibit 12-1.

9. Employees may submit a self-assessment, limited to four pages in length, no later than the last workday of their annual appraisal rating period. See IRM 6.430.2.4.5, Self-Assessments and IRM 6.430.2.6 (3), Conducting the Performance Appraisal Meeting.


**1.4.40.7.2** **(05-19-2010)**

#### IRS Policies, Procedures and Guidelines

1. A group manager's evaluation of employee performance must conform to procedures detailed in the IRM and Document 11678, National Agreement.

2. Policies of the IRS must be adhered to when evaluating performance. These policies prohibit the use of predetermined quantitative standards, enforcement results, or quotas to influence the evaluation of an examiner’s performance. See IRM 1.5, Managing Statistics in a Balanced Measurement System and section 1204 of RRA 1998. A group manager may look to the TM, LR, and Human Resources for additional direction and guidance.


**1.4.40.7.3** **(08-25-2025)**

#### Performance Reviews

1. An efficient and effective employee appraisal depends on a group manager's active involvement and timely direction. Fair and balanced feedback is essential to maintain and improve skills.

2. Providing ongoing employee feedback that is candid and meaningful is essential to employee satisfaction and is an integral part of the group manager’s responsibilities. Reviews of employee work should serve to:



   - Assess the employee’s effectiveness in meeting the expectations established in their CJEs.

   - Determine the employee’s efficiency in carrying out the laws, procedures, and policies of the IRS.

   - Identify and address performance problems.

   - Evaluate the employee's ability to properly plan and schedule field, office, and telework activity.

   - Ensure the employee is taking timely and appropriate actions to bring the case to a prompt and proper resolution.

   - Assess employee effectiveness in developmental case assignments.

   - Determine the employee's effectiveness in meeting the IRS Retention Standard for the Fair and Equitable Treatment of Taxpayers.


3. Formal reviews must be in writing and completed in EQRS. See _IRM 1.4.40.3.6_, Performance Feedback. Managers must be familiar with attribute definitions and can access the Embedded Quality website for information about EQ attributes. Document 12354 should also be reviewed for specific guidance related to EQ attributes and how to use them.

4. Managers must keep an employee’s overall performance in mind when work and related activities are discussed. They must timely inform an employee when some aspect of performance may negatively influence the next performance rating. Verbal notification must be followed by written documentation. Recordation **must be shared** with bargaining unit employees **within 15 work days** of the time the group manager becomes aware, or should have been aware, of the event which it addresses. See Document 11678, National Agreement, Article 12, Section 9.

5. A group manager's role as an instructor and evaluator is to assess the quality of the employee’s work and provide timely feedback and guidance. By maintaining documentation throughout the rating period, sufficient information will be available to prepare the annual appraisal. Managers should remember that performance appraisals are used to give employees official feedback and need to be clearly and timely communicated. Refer to IRM 6.430.2 for additional information.


**1.4.40.7.4** **(05-19-2010)**

#### Awards

1. Employee recognition is designed to reward and recognize employees, either individually or as a member of a team or group, for their performance, adopted suggestion ideas, or other exemplary contributions to the IRS's mission. Employee recognition may include monetary awards, time-off awards, honorary recognition (e.g., plaques, certificates, etc.), informal recognition items, or a combination. Listed below are some forms of recognition:



   - Performance Awards–See IRM 6.451,

   - Quality Step Increase (QSI)–See IRM 6.451.1.10,

   - Special Act and Manager’s Awards–See IRM 6.451.1.11,

   - Time-Off Awards–See IRM 6.451.1.12,

   - Bilingual Awards–See IRM 6.451.1.13,

   - Secretary of the Treasury Honor Awards–See IRM 6.451.1.17, (e.g., Commissioner's Award, IRS Career Service Recognition Program, and Certificates of Recognition), and

   - Albert Gallatin Award–See IRM 6.451.1.18.


2. For additional information on awards visit the Human Capital Office website located at Awards and Recognition Programs.


**1.4.40.7.4.1** **(05-19-2010)**

##### Processing Awards

1. Form 6850-BU, Form 6850-NBU, and Form 9127, Recommendation for Recognition, are used to process awards. See the Human Capital Office website located at Awards and Recognition Programs for additional information.


**1.4.40.7.5** **(04-14-2021)**

#### Employee Performance Files (EPFs)

1. An EPF is a record of performance-related data maintained on all employees. EPFs must be established and maintained for all full-time, part-time, seasonal, intermittent, term and temporary employees expected to be employed at least 120 days in a calendar year.

2. A group manager is responsible for maintaining and assuring effective use of the EPF system by:



   - Establishing EPFs,

   - Updating EPFs,

   - Securing performance records/documents, and

   - Forwarding EPFs to the new group manager upon transfer or reassignment.


3. Each EPF must be clearly labeled as "Employee Performance File" , along with the employee's name and last four digits of their social security number, or, as an alternative, their SEID. Access to an EPF is limited to the employee, management officials with a need to know, and any representative designated by the employee, such as NTEU. EPFs should be kept in a locked cabinet, room, or other secured area.

4. Information to be retained in the EPF includes:



   - Performance plan (critical elements and standards),

   - Form 6774, Receipt of Critical Job Elements and Retention Standard (managers must update the form annually and ensure it is signed and dated by the employee; see IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers),

   - Annual appraisals, departure appraisals and ratings,

   - Any records of performance documentation such as workload reviews, case file reviews, job visitations, progress reviews, mid-year assessments and all appraisal forms, such as Form 6850, needed to justify a personnel action (e.g., promotion, award, furlough, or removal),

   - Records of performance counseling,

   - Rebuttal statements submitted by the employee,

   - Career Learning Plan,

   - Student employment work agreement, and

   - Employee self-assessments.


5. No documentation related to disciplinary or adverse action will be placed in an EPF, unless such action was based on performance.

6. All EPFs should be purged annually to remove documentation over four years old. Refer to Document 12829, The General Records Schedules, 2.2: Employee Management Records, Item 70, for the retention and disposition to prevent inadvertent/unlawful destruction of records. See Item 71 for unacceptable performance appraisal retention.

7. If an employee leaves the IRS, some items from the EPF are sent to the servicing Transactional Processing Center (TPC). Contact the Area Labor Relations Office to identify the specific items that should not be sent to the TPC. Additional information can be accessed at iManage.

8. Documents related to an employee's conduct, such as failure to file taxes, tardiness, or leave abuse, may be filed in a "drop" file which will be kept separate from the EPF. Documents should be sanitized for any items the maintenance of which is not consistent with the underlying purpose of keeping the record or in violation of federal law or regulations (e.g., date of birth).



### Caution:



Employee medical information must be maintained in a confidential medical file, separate from the EPF and drop file. For more information, see IRM 6.630.1.5.4, Safeguarding Medical Information.

9. For additional information regarding the specific items to be placed in the EPF and the retention period, refer to:



1. Document 11678, National Agreement, Article 7,

2. Human Capital Office (HCO),

3. IRM 6.430.2.3.5, Employee Performance File (EPF) and

4. 5 CFR 293, Subpart D.


**1.4.40.7.6** **(07-24-2020)**

#### Group Manager Concurrence Meeting (GMCM) for Revenue Agents

1. The GMCM is an opportunity for the group manager and RA to discuss the scope and depth of the examination, as well as the mutual commitment date (MCD). Group manager involvement in the early stages of an examination results in fewer delays, increased efficiency and higher quality cases.

2. The GMCM should occur no later than 30 business days after completion of the initial appointment or 60 business days after the case is updated to Status 12, Started, in ERCS, whichever is first. The GMCM may also be conducted prior to the initial appointment, for example, when the taxpayer or representative is procrastinating and has rescheduled the initial appointment multiple times.

3. The RA is responsible for scheduling the GMCM. It should be scheduled as soon as the initial appointment is scheduled or when the case has been in process 45 days, whichever comes first.

4. GS-12 revenue agents and below are required to use the GMCM.

5. GS-13 revenue agents are encouraged to utilize a GMCM in order to provide updates on cases and obtain guidance from managers.

6. At a minimum, the RA should be prepared to discuss:



   - The initial appointment meeting and MCD,

   - Accomplishments and planned actions for completing the case,

   - Issues currently identified,

   - Required filing checks,

   - Location of the audit work and

   - Concerns or barriers to closing the case.


7. The GMCM should be documented on the Group Manager Concurrence Meeting (GMCM) and Managerial Involvement lead sheet.

8. The GMCM can be evaluative or non-evaluative. If the GMCM is evaluative, see Group Manager Concurrence Meeting (GMCM) Guidelines for a list of EQRS quality attributes to consider during their review. This list is not meant to be all-inclusive, but rather to provide a starting point for a GMCM evaluative review. The group manager should use their judgment to determine which quality attributes are most applicable. Refer to Document 12354 for points to consider.


**1.4.40.7.7** **(05-19-2010)**

#### In-Process Case Reviews

1. An in-process case review is an opportunity for a group manager to be involved in an examination while the case is ongoing. The involvement may be extensive or may be limited to a very specific part of the examination. Some areas a group manager may wish to consider are:



|     |
| --- |
| Determining overall examination abilities, |
| Training in a new or unique issue, |
| Developing accounting and/or auditing skills, |
| Observing communication skills, |
| Assisting in the proper development of technical issues, |
| Determining and/or improving proper time utilization, |
| Reviewing and/or improving workpaper documentation, |
| Determining scope and depth of examinations, |
| Improving your knowledge of certain industries and/or issues, |
| Observing interview techniques and offering constructive feedback, and |
| Providing assistance with overage cases. |

2. Completion of in-process reviews should be annotated in the case file on Form 9984.

3. See Case Review Guidelines for a list of EQRS quality attributes that lend themselves to being rated in an in-process case review. The list is not meant to be all-inclusive, but rather to assist a group manager in this particular type of case review. A group manager should use their own judgment to determine which quality attributes are most applicable for a specific review.


**1.4.40.7.8** **(05-19-2010)**

#### Workload Reviews

1. Workload reviews will give a group manager the best overall picture of each examiner’s work and activities. A good understanding of the employee's work is necessary for evaluating performance, providing direction, and deciding when a group manager should become more involved in specific examinations.

2. Workload reviews should foster open and honest interaction between a group manager and employees; therefore, it is essential that a group manager discuss areas where there is above-average performance as well as areas that require improvement. Agreed actions and directions provided during the review should be noted in the workload review documentation**and** a comment placed on Form 9984 that the case was reviewed as part of a workload review.

3. Workload reviews should be timely summarized in writing, addressing the quality attributes and as many of the job elements as practical. The workload review feedback should be timely discussed with the employee in person. The meeting to discuss the workload review should occur within the first few days after the review is completed to achieve the most value.

4. Workload reviews are valuable management tools; therefore, timely follow-up to determine if the agreed-upon actions have been completed is very important.

5. See Workload Review Guidelines for a list of EQRS quality attributes that lend themselves to being rated in a workload review. The list is not meant to be all-inclusive, but rather to assist a group manager in this particular type of case review. A group manager should use their own judgment to determine which quality attributes are most applicable for a specific review.


**1.4.40.7.8.1** **(05-19-2010)**

##### Compare Group Controls with Examiner's Inventory

1. Begin the workload review by securing a list of all returns assigned to the examiner. With ERCS, the inventory list can be sorted by several different categories, including but not limited to priorities, status codes, days in process, and activity codes. The review can be limited to priority work and overage cases, or a complete review of the examiner's inventory including status 10 work. See also _IRM 1.4.40.5.7_, for a list of reports that may be useful when conducting workload reviews.

2. All cases assigned to the examiner should be available and matched against the 100 IVL listing during the workload review. Inspecting all cases available will identify "copies of returns" and years which are being worked but are not controlled on ERCS/AIMS. It will also identify potential "missing" or reassigned returns where the ERCS controls were never properly reassigned or closed.


**1.4.40.7.8.2** **(05-19-2010)**

##### Items to Address During the Workload Review

1. Items to address during a workload include but are not limited to the following:



   - Adequacy of inventory

   - Priority work

   - Cases in process for extended periods of time

   - Status 10 inventory

   - Workload problems and delays

   - Compatibility of work with employee's grade

   - Specialist referrals

   - Use of time

   - AIMS/ERCS controls


**1.4.40.7.8.2.1** **(05-19-2010)**

###### Adequacy of Inventory

1. The employee’s total inventory should be reviewed to determine if the employee has a good balance of work in process.

2. A determination should be made as to whether inventory is balanced among cases in opening, active, and closing stages of the examination.

3. The complexity of the cases in process should be considered.

4. The total amount of priority work assigned to the employee and the time required for timely completion should be considered.


**1.4.40.7.8.2.2** **(05-19-2010)**

###### Priority Work

1. The group manager should review priority work areas including but not limited to: short statute cases, audit reconsiderations, reviewer's reports, request for information, collateral investigations, claims, informant claims for rewards, inadequate records, refund hold, and overage cases.



### Note:



The listing above may change depending on strategic program initiatives.

2. A group manager should:



1. Determine if priority work has been identified and scheduled,

2. Determine if the highest priority work has been scheduled first,

3. Determine when priority status 10 work can be started or if it should be reassigned or closed by survey, and

4. Determine if any barriers to closing exist for started inventory.


**1.4.40.7.8.2.3** **(05-19-2010)**

###### Cases in Process for Extended Periods of Time

1. A group manager should review cases in process for extended periods of time to:



1. Determine if delays result from taxpayer relations, follow-up procedures, examination planning, or examination techniques,

2. Determine if the employee has a pattern of keeping cases in process for excessive periods of time, and

3. Determine if the employee is experiencing difficulty recognizing and developing issues.


**1.4.40.7.8.2.4** **(05-19-2010)**

###### Status 10 Inventory

1. The cases that are not in process should be reviewed to:



1. Determine if returns with the most potential are worked first.

2. Determine if the employee initiates examinations or appropriately surveys returns.

3. Determine if managerial approval should be required prior to the employee starting new cases.

4. Determine if any case should be reassigned.


**1.4.40.7.8.2.5** **(05-19-2010)**

###### In Process Inventory

1. The cases that are in process should be reviewed to:



1. Determine the progress of each case.

2. Determine if the pre-examination plan is effective.

3. Determine if risk analysis was conducted by the employee during the planning process (Field Examination only).

4. Determine if mutual commitment dates are secured on cases in process with the taxpayer or representative (Field Examination only).

5. Determine if the examiner's time charges exceed guidelines (preplan, interview, or closing activities) without managerial approval (Office Examination only.)

6. Determine if the examination was conducted in a logical manner and appropriate examination techniques were used.

7. Determine if fraud indicators were recognized and properly considered.


**1.4.40.7.8.2.6** **(05-19-2010)**

###### Workload Problems and Delays

1. Pinpoint specific actions which should be taken to improve the status of the examination and/or an employee’s work performance. These actions include:



01. Prevent frequent cancellation of appointments by taxpayer or representative and suggest new approaches for scheduling appointments,

02. Correct deficiencies in pre-audit examination plans to eliminate substantial deviation,

03. Address any delays in securing records (e.g., curtail repeated contacts for piecemeal information; address any taxpayer complaints regarding requests for information; point out valid objections by the taxpayer which the employee has failed to consider),

04. Address any problems and delays in the development of facts (e.g., diversionary tactics by taxpayers and representatives to impede case development; excessive time spent to develop facts, and research issues; complaints by the examiner concerning unreasonable taxpayers or representatives),

05. Address any problems and delays in the development of issues (e.g., lack of ability to recognize issues; lack of ability to develop issues; lack of ability to use indirect methods or other examination techniques),

06. Set target dates for completion of specific actions,

07. Resolve unwarranted case closing delays,

08. Require follow-up on unanswered requests for information,

09. Follow-up on progress in fraud cases,

10. Evaluate the tax potential of cases and determine if any compliance problems exist,

11. Research specific technical issues,

12. Review appropriate examination techniques, and

13. Urge employees to reach decisions when there is enough information to do so.


2. Review repeat cases from the last workload review to determine if the employee has followed the directions provided or previously agreed upon.

3. Review cases inactive for a specified period of time.



1. Identify the specific reason for no action or follow up by the employee.

2. Identify and evaluate delays caused by the taxpayer or practitioner.

3. Determine if the employee consistently has inactive cases and why.


4. Identify cases that require mutual agreement on additional work required and set target dates for completion.


**1.4.40.7.8.2.7** **(05-19-2010)**

###### Compatibility of Work with Employee's Grade

1. Work in process and status 10 inventory should be reviewed during the workload review to ensure assigned work is commensurate with the employee's grade.


**1.4.40.7.8.2.8** **(05-19-2010)**

###### Specialist Referrals and Technical Assistance

1. Determine during the workload review if specialist referrals are warranted (international, engineering, employment, employee plans, exempt organizations, and computer audit specialist, etc.). See IRM 4.10.2.7.5, Specialist Referrals, for additional information.

2. Review cases involving specialists to ensure effective and efficient use of resources.

3. Review issues to determine if technical advice or Area Counsel involvement is warranted.


**1.4.40.7.8.2.9** **(05-19-2010)**

###### Use of Time

1. During the workload review the technical time report should be reviewed for the last month to obtain a pattern regarding time charged.

2. The manager should analyze case files and ERCS reports for the following:



   - Consider the time charged by the examiner in relation to information in the case file.

   - Determine if the employee is planning time and scheduling activities in advance to prevent down time.

   - Analyze time spent to determine if examiners are working partial days versus whole days. If partial days are being worked, is this the most efficient and effective use of time. (Field Examination only.)

   - Determine if work is scheduled at the appropriate location. (Field Examination only.)

   - Determine if the time and span is commensurate with the complexity of the issues.

   - Determine if IDR’s are issued timely with specific due dates.

   - Analyze time spent on non-examination activities.

   - Ensure that time charges on ERCS match time charges on Form 9984.


**1.4.40.7.8.2.10** **(05-19-2010)**

###### AIMS/ERCS Controls

1. During a workload review the following actions should be taken:



   - Resolve any differences between the employee's inventory and group controls,

   - Verify the timely requisitioning of related returns under examination,

   - Confirm statute updates and that the correct alpha codes have been used when required,

   - Determine if applicable partnership control procedures (PCS) were followed,

   - Verify that proper controls have been established for substitute/delinquent returns,

   - Ensure the project, source, and status codes are correct and timely updated, and

   - Confirm Forms 895 are issued and returned timely.


**1.4.40.7.9** **(05-19-2010)**

#### On-the-Job Visit

1. To achieve our quality objectives, there must be managerial involvement at all stages of the examination. The on-the-job visit (OJV) is one of the most effective tools a group manager has to accomplish this task and is essential since much of an employee’s work and activities are performed independent of a group manager's direct observation.

2. The manager should have a purpose for making a visit such as observing an examiner’s auditing abilities, observing an examiner’s communication skills, teaching an examiner new auditing techniques, etc. Purposeful and essential visits are valuable. Frequency of visits should be dictated by the needs of the employee and/or the specific case.

3. Visitation needs can often be pinpointed during a workload review. A group manager should avoid making on-the-job visits only at the conclusion of examinations. Visitations made earlier in the audit process provides an opportunity to take corrective actions earlier rather than at the conclusion of an examination when it is too late to impact the progress of the case. Earlier intervention will foster better taxpayer relations.

4. Managers should explain the reason and purpose of their visit to the examiner. Generally, managers will advise the examiner of their planned visit.



### Reminder:



Some taxpayers and virtually all representatives are well-acquainted with the normal practices of examiners and may wonder about the purpose of the group manager visitation.

5. Communicate the observations to the examiner after every visit. The observations should include specific factual comments related to the examination and recommendations concerning future actions. They should be documented or summarized in timely feedback addressing as many of the CJEs as practical. This feedback, as well as other documented feedback, will serve as a basis for the annual performance evaluations.

6. An on-the-job visit can be used to observe, assist, and assess employee's knowledge, skills and taxpayer relations. Listed below are areas that should be considered during the on-the-job visit:



1. Planning and scheduling the examination,

2. Accounting skills and tax law knowledge,

3. Workpapers and reports, and

4. Closing the examination.


7. See On-the-Job Visit Guidelines for a list of EQRS quality attributes that lend themselves to being rated in an on-the-job visit. The list is not meant to be all-inclusive, but rather to assist a group manager in this particular type of case review. A group manager should use their own judgment to determine which quality attributes are most applicable for a specific review.


**1.4.40.7.9.1** **(05-19-2010)**

##### Planning and Scheduling the Examination

1. Review the employee's work plan to determine if all large, unusual, and questionable issues (LUQ) have been addressed. Provide suggestions to the employee when warranted.

2. Observe the examiner's professionalism, taxpayer relations, and communication skills.

3. Determine if employee has requested proper books and records.

4. Determine if the taxpayer has submitted the requested books and records. If not, determine if proper follow-up has been made to secure the necessary records.


**1.4.40.7.9.2** **(05-19-2010)**

##### Accounting Skills and Tax Knowledge

1. The group manager should review the case file during an OJV for proper financial and tax accounting. The manager should:



1. Determine if the examiner considered LUQ items throughout the course of the examination.

2. Determine if the examiner expanded and contracted the scope as appropriate.

3. Determine if the examiner properly evaluated oral testimony.

4. Determine if the examination techniques used are appropriate based on internal controls.


**1.4.40.7.9.3** **(05-19-2010)**

##### Workpapers and Reports

1. The group manager should review the case file to determine the following:



1. Workpapers are being contemporaneously prepared.

2. Workpapers document the appropriate information to support the issues examined during and at the conclusion of the examination. Copies of information are included in the workpaper file only when relevant. Unnecessary copies of taxpayer records have not been included.

3. Risk analysis workpapers (Field Examination only), mandatory lead sheets, and issue lead sheets are being prepared, used, and properly indexed to Form 4318, Examination Workpapers Index.


**1.4.40.7.9.4** **(05-19-2010)**

##### Closing the Examination

1. Observe the examiner's presentation of the audit findings. Audit findings should be presented in a professional manner.

2. Observe the interaction between the examiner and the taxpayer and/or representative. Ensure the examiner provides them with an opportunity to present any additional evidence, oral testimony, or other pertinent arguments regarding the audit issues.


**1.4.40.7.10** **(05-19-2010)**

#### Closed Case Review

1. Perform a cursory inspection of every closed case. See _IRM 1.4.40.4.11_, Closing Returns — General. From this inspection and your knowledge of the case, you can determine if a more in-depth review is warranted.

2. Assessment of an examiner's performance and feedback should be summarized in timely documentation, addressing as many of the quality attributes as applicable.

3. A group manager should be satisfied that the work product flowing from the group meets or exceeds the quality attributes. The EQRS quality attributes are found in the Attribute Job Aid, Document 12354.

4. A group manager should not rely solely on closed case reviews to assess performance, identify concerns, solve problems, and manage inventories. Although a closed case review is a helpful tool, a group manager must realize that, at this point, the examination has been completed. It is too late to change the direction of the examination and ensure that quality is built into the process. In-process case reviews may provide a better opportunity for earlier managerial involvement to enhance communication with the taxpayer and/or representative, reduce examination span, identify additional compliance issues, or provide guidance regarding scope limitations.

5. A closed case review can be used to assess the knowledge, skills, and taxpayer relations of the examiner. It can also be used to assess the quality of the examination. Listed below are areas that should be considered during a closed case review:



1. Examination planning and scheduling

2. Accounting skills and tax law knowledge

3. Workpapers and reports

4. Use of time


**1.4.40.7.10.1** **(05-19-2010)**

##### Examination Planning and Scheduling

1. The group manager should review the case file to determine if:



1. The examiner recognized and addressed all LUQ issues.

2. The examination span was reasonable.

3. Compliance checks were completed and documented in the case file.

4. The preplan time was commensurate with the complexity of the return.

5. Related and multiple year returns warranting examination were examined.


**1.4.40.7.10.2** **(05-19-2010)**

##### Accounting Skills and Tax Law Knowledge

1. The group manager should review the case file to determine if:



1. The examiner expanded and contracted the scope as appropriate.

2. The examiner used appropriate techniques to verify income.

3. The examiner properly evaluated the relationship between financial accounting and tax accounting.

4. The examiner properly evaluated oral testimony.

5. The examiner applied the required accounting and financial skills and knowledge to reconcile the books and records to the tax return and analyze financial statements.

6. The examiner recognized and pursued indications of fraud if they were present.

7. The tax law has been appropriately applied. The factual development of the case should support the conclusion reached.


**1.4.40.7.10.3** **(05-19-2010)**

##### Workpapers and Reports

1. The group manager should review the case file to determine if:



1. The workpapers were properly documented. They should reflect examination techniques employed, records reviewed, applicable tax law citations and conclusion reached.

2. The workpapers were contemporaneously prepared. Determine if the examiner spent time duplicating effort by recreating workpapers.

3. Mandatory leadsheets and issue leadsheets were prepared, used and properly indexed to Form 4318.

4. The depth of the examination was sufficient. If not, provide the examiner with constructive feedback.

5. The final report submitted to the taxpayer was professional in appearance and supports the conclusions reached during the examination.


**1.4.40.7.10.4** **(05-19-2010)**

##### Use of Time

1. The manager should determine if the time expended is commensurate with work performed and reflected in the case file. An ERCS time analysis report can assist and provide the following:



1. Total time charged to the key return and related returns, if applicable,

2. List of dates and corresponding time charged to the case, and

3. Whether consecutive days were worked on the case or there are partial day time charges on nonconsecutive days (Field Examination only).



      ### Caution:



      All related returns should be linked to the key case on ERCS to provide an accurate reflection of time application by the examiner.


2. The manager should determine if the workload priorities of the examiner had an impact on the planning and scheduling activities on the case.



1. Total cases in process

2. Other priority work

3. Details, training, or other assignments


**1.4.40.7.11** **(05-19-2010)**

#### Review of Examination Technical Time Reports (ETTR)/Examination Process Review (EPR)

1. ETTR (field examination) and EPR (office examination) reviews should be focused upon effective planning and scheduling techniques, with an emphasis on taking "meaningful" timely actions on in-process cases to bring them to closure.

2. A group manager should ensure examiners are properly determining when to expand or limit the audit scope.

3. Assessment of the employee's work observed during the review should be communicated in timely written or oral feedback.

4. ETTR/EPR reviews should provide a quality check on the accuracy of the form preparation.

5. The depth and timing of these reviews is determined by area director or territory manager guidelines.

6. See ETTR/EPR Review Guidelines for a list of EQRS quality attributes that lend themselves to being rated in an ETTR/EPR. The list is not meant to be all-inclusive, but rather to assist a group manager in this particular type of case review. A group manager should use their own judgment to determine which quality attributes are most applicable for a specific review.


**1.4.40.7.11.1** **(05-19-2010)**

##### ETTR/EPR Analysis

01. The analysis process should be utilized to review the ETTR (field examination) or EPR (office examination) to observe planning, scheduling, time management skills, and to identify inactive cases.

02. The time analysis and review process should verify timely contacts are made and work is properly planned and scheduled.

03. Ensure there is a balance of inventory in the opening, active, and closing stages. Determine if there is a need for additional case assignments.

04. Determine if time is effectively utilized by analyzing direct versus indirect time. Review reports to determine if time is charged in full or partial day time increments and on consecutive days.

05. Review planning calendars to determine if:



    - Time is scheduled for pre-audit work on new cases and

    - Portion of audit spent in field vs. office vs. telework.


06. Determine if related return pick-ups are completed at the appropriate time when significant noncompliance issues exist. Cases should be updated to Status 12 when started.

07. Verify the examiner is working on cases in priority sequence to the extent possible.

08. For Field Examination only, determine if MCDs are set for all cases in process according to guidelines. Ensure that dates are realistic and that planned actions are documented on the examiner's planning calendars to aid in meeting the MCDs.

09. The following items can be used during this review:



    1. Planning calendar

    2. ERCS Overage Report (IVL)

    3. ERCS Inactive Case Report

    4. ERCS Closed Case Report


10. Managerial directions and guidance should be summarized and recorded on specific cases on Form 9984.


**1.4.40.7.12** **(05-19-2010)**

#### On-Going Observation

1. Observations of general activities in the work area can provide a group manager with indicators of the work atmosphere of the group and whether a productive work environment exists. Casual and brief visits with employees in the work area permit a group manager to provide assistance in an informal and time-saving manner. Some of the benefits gained through informal interactions are:



1. Solutions to work difficulties,

2. Substitution of oral feedback for written feedback,

3. Timely communication of new procedural and technical developments, and

4. Identify and correct improper or ineffective work habits.


2. Informal discussions with employees may result in solving many work problems. To foster effective communication with employees, avoid assessing negative performance as a result of informal interactions.


**1.4.40.7.13** **(05-19-2010)**

#### Feedback from Other Areas

1. Solicit written feedback when employees are given assignments outside of the group. Some of these assignments will include:



   - Classifying returns

   - Details to Technical Services staff

   - Instructing

   - Acting group manager

   - Details to other divisions


**1.4.40.7.14** **(05-19-2010)**

#### Disciplinary and Adverse Actions

1. Disciplinary and adverse actions are tools that a group manager can use to enforce the rules, regulations, and work requirements that allow the IRS to accomplish its mission in an effective and efficient manner.

2. The goal of both disciplinary and adverse actions is to use the lowest level of discipline possible to correct inappropriate behavior. Each case is considered individually. See the references below for various actions and options.

3. Seek assistance from the Labor and Employee Relations Office whenever dealing with any conduct problem that has the potential to result in a disciplinary action.

4. Below are resources to assist with disciplinary and adverse actions:



1. IRM 6.752, Disciplinary Suspensions and Adverse Actions

2. iManage - Performance Issues (Counseling)

3. iManage - Performance Management

4. Document 11678, National Agreement


**1.4.40.7.15** **(05-19-2010)**

#### Grievances

1. Employees are entitled to present grievances without restraint, interference, coercion, discrimination, or reprisal. Grievances should be considered fairly and impartially and processed expeditiously. Listed below are resources that provide guidance processing grievances:



1. IRM 6.771.1, Agency Grievance System (AGS)

2. iManage - Grievances

3. Document 11678, National Agreement


**1.4.40.7.16** **(04-14-2021)**

#### Protecting Taxpayer Rights

1. A primary responsibility of managers is to monitor employee practices and actions to ensure taxpayer rights are always observed.

2. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see Taxpayer Bill of Rights and IRM 4.10.1.2.1, Taxpayer Bill of Rights (TBOR). Taxpayer rights include, but are not limited to the following:



01. The right to be informed.

02. The right to quality service.

03. The right to pay no more than the correct amount of tax.

04. The right to challenge the IRS’s position and be heard.

05. The right to appeal an IRS decision in an independent forum.

06. The right to finality.

07. The right to privacy.

08. The right to confidentiality.

09. The right to retain representation.

10. The right to a fair and just tax system.


3. Examiners should be aware of and observe all taxpayer rights provided by Public Laws, including the IRS Restructuring and Reform Act of 1998 (RRA 98), the IRC, and IRS policies, including those rights summarized in the TBOR.

4. Section 1203 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA ‘98) calls for the termination of any employee of the IRS if there is a final administrative or judicial determination that the employee committed any act or omission described below:



01. Willfully failing to obtain required approval signatures when making a seizure.

02. Providing a sworn, false statement in a "material matter" concerning a taxpayer.

03. Violating the constitutional rights of or discriminating against taxpayers or employees.

04. Falsifying or destroying documents to cover a mistake concerning a taxpayer.

05. Receiving a criminal conviction or civil judgment for assault or battery on a taxpayer or employee.

06. Violating the IRC, IRS regulations or policies to retaliate against or harass taxpayers or employees.

07. Willfully misusing IRC 6103 to conceal information from Congressional inquiry.

08. Willfully failing to file a federal tax return on or before its due date, unless it is due to reasonable cause.

09. Willfully understating federal tax liability, unless it is due to reasonable cause.

10. Threatening an audit for personal gain.


5. See the following resources:



   - IRM 6.430.2.4.7, Rating Performance Against The Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRM 6.430.2.2.5, Discussing The Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - iManage - Managing Employees

   - iManage - Section 1203 and Non-1203 Misconduct

   - Performance Management - Evaluating Bargaining Unit (BU) and Non-Bargaining Unit (NBU) employees covered by CJEs

   - Pub 947, Practice Before the IRS and Power of Attorney


**1.4.40.8** **(05-19-2010)**

### Employee Development

1. A group manager must ensure that support staff, paraprofessional, and technical employees receive training and guidance for successful performance in their group. Assess each employee’s abilities and performance, in order to develop the individual in their current position and for higher-level and more responsible work. In many instances, the IRS provides formal training programs designed to meet the employee’s basic and advanced needs. These programs provide for classroom training, on-the-job instruction, continuing professional education (CPE), correspondence courses, and other approaches. Become familiar with the purpose and content of the various training programs and contact the Area training coordinator for additional assistance.

2. To be successful, a group manager must be aware of the talents, current level of accomplishments, goals, and aspirations of the group's employees. Completing employee profiles for the group's employees will provide a basic foundation for assessing the group’s training and development needs. The degree of imagination, ingenuity, and creativity in this vital area is up to the group manager. Mentoring and frontline management readiness programs provide for the identification and development of employees who exhibit management skills and potential. Review each employee’s Career Learning Plan (CLP) and provide assignments to implement the plan.

3. Listed below are references that may be helpful in developing employees:



1. IRM 1.4.1.6, Employee Development,

2. Career Opportunities,

3. Developing Employees,

4. Document 11678, National Agreement, Article 30, Section 2(D), Training,

5. Form 10094, Career Learning Plan - Employee, can be used to prepare a Career Learning Plan,

6. Integrated Talent Management,

7. [Learn and Lead 24/7](https://learningtreas.skillport.com/skillportfe/login.action) offers a wide variety of courses, books, videos, job aids and more.


**1.4.40.8.1** **(05-19-2010)**

#### New Employee Training

1. A group manager is responsible for ensuring new employees receive quality training. A group manager must be involved with trainees throughout their classroom and on-the-job training, and work closely with the Area training coordinator.


**1.4.40.8.2** **(05-19-2010)**

#### Employee Training

1. A group manager is responsible for ensuring employees receive quality CPE. CPE should be presented in accordance with the current fiscal year guidelines. A group manager is responsible for ensuring examiners and support staff receive the training they need to perform their job.

2. A group manager may identify other training needs. Group meetings, self-study, external seminars or memoranda may be effective methods for delivering other training needs.


**1.4.40.8.3** **(05-19-2010)**

#### Employee Career Learning Plan

1. Employee development is a shared responsibility between a group manager and employees. Each employee should prepare a CLP to meet their specific needs. This plan should be updated as actions are accomplished.

2. Document 11678 provides that employees should also spend their own time on self-development.

3. A group manager should develop a monitoring and follow-up system to meet the individual needs of each employee. An effective CLP should be:



   - Mutually developed

   - Realistic

   - Balanced

   - Attainable

   - Mutually supported


4. Employee development is directed toward improving skills in present and target positions. This can be accomplished through a variety of activities including: details to other areas or functions, instructing, OJI, acting group manager assignments, task force and special projects.


**1.4.40.8.4** **(05-19-2010)**

#### Helping People Achieve

1. A group manager is an advocate for group employees. A group manager can help employees achieve their career objectives by remembering:



1. Enthusiasm is contagious

2. Clearly shared objectives and standards are a must

3. Intermediate goals must be set, shared, and monitored

4. Small successes build confidence

5. Individual performance is evaluated against set standards

6. Prompt corrective action may be necessary


2. Identifying, planning, and monitoring of employee needs and their development requires open communication. Direct involvement and ongoing attention are essential to the enhancement of employees’ skills and career advancement.

3. Remember, a group manager is only as effective as the employees in the group. Thus, it stands to reason a group manager needs to assist in employee’s development by:



1. Encouraging and appreciating excellence,

2. Creating a climate of support, encouragement, recognition and team spirit, and

3. Remaining flexible and resourceful.


**1.4.40.8.5** **(05-19-2010)**

#### Group Manager Development

1. Personal career objectives are a shared responsibility between a group manager and TM. Look for guidance in developing professional goals and objectives.

2. Increased responsibility, advancement, and job enrichment should continue throughout a group manager's career. A group manager should develop and fully utilize a career developmental plan. Managerial career planning requires goals, actions, and commitment. Visit Career Opportunities for additional information.


**1.4.40.9** **(05-19-2010)**

### Programs and Priorities

1. A group manager plays a vital role in accomplishing the IRS’ mission. It is essential that all levels of management identify and prioritize expectations.

2. The SB/SE Commissioner establishes and prioritizes goals for each fiscal year as outlined in Pub 5448, SB/SE Focus Guide, for the fiscal year. Policy statements, internal revenue manual procedures, and other documents provide guidelines for achieving these strategies.


**1.4.40.9.1** **(05-19-2010)**

#### Work Categories

1. Determine the priority of available workload in light of existing commitments, planned objectives, and procedural requirements.

2. A group’s work can be divided into three categories. See _IRM 1.4.40.4.5.2_, Inventory Types.

3. It is essential that a group manager understands priorities, monitors them closely, and ensures their attainment. Some mandatory programs, such as headquarters directed projects, have definite interim completion goals that should be attained. When assigning returns to examiners, mandatory and priority cases must receive first consideration. Although transferring work between examiners is not desirable, it could be required to satisfy priority needs.

4. Some examples of priority cases are:



|     |
| --- |
| Cases in which either the government’s or the taxpayer’s interest is in jeopardy due to imminent expiration of the SOL. |
| Bankruptcy or receivership cases on which the date for filing claims is about to expire (see IRM 4.27.1.7.4, Returns Under Examination When the Bankruptcy Petition is Filed). |
| Taxpayer Advocate Service (TAS) cases. |
| Cases returned by Technical Services for reconsideration on Form 3990, Reviewers Report. See IRM 4.10.8.8.1(2), 90-Day / Notice of Deficiency Reconsideration Cases. |
| Requests for prompt assessment. |
| Pre-identified art evaluation cases. |
| Delinquent account cases being held by Collection pending action by Examination |
| Cases involving informant’s claims/letters. |
| Partnership and fiduciary cases involving Form 8340, PCS Establish or Add with Notice Generation. |
| Inadequate records follow-up examination. |
| Claims for refund. See IRM 4.10.11.2.3(2), Claims for Refund - Overview of Examiner’s Responsibilities. |
| Overage cases. |
| Offers in Compromise. See IRM 4.18.1.3(4), Return Controls. |


**1.4.40.9.2** **(05-19-2010)**

#### Technical Advisors/Issue Specialists

1. Technical advisors/issue specialists facilitate the development of examiners' expertise by providing guidance on issues specific to certain industries or return types and provide technical support to Area examiners. They are responsible for preparing issue guidance and [Audit Techniques Guide (ATGs)](https://www.irs.gov/businesses/small-businesses-self-employed/audit-techniques-guides-atgs) that provide auditing techniques, assist with issue identification and development, and tax law interpretation.

2. The technical advisory program involves industries and businesses selected because of possible noncompliance. The purpose of specializing is to allow technicians to develop expertise in the industry. Industry specialization also allows the IRS to take consistent positions with certain industries and issues. Technical advisors located in LB&I and issue specialists located in SB/SE are both available to assist examiners.


**1.4.40.9.3** **(05-19-2010)**

#### Headquarters Directed Projects

1. These are high priority programs which have significant impact on future compliance with widespread geographic implications. These projects may be initiated at any time. A group manager's early involvement and continual monitoring is critical.


**1.4.40.9.4** **(05-19-2010)**

#### Compliance Initiative Projects (CIP)

1. The objectives of CIPs are to identify whether noncompliance exists, determine the reasons for noncompliance, reduce noncompliance, and make recommendations for increasing future compliance.

2. CIPs are any activities involving contact with specific taxpayers within a group, using either internal or external data to identify potential areas of noncompliance within the group, for the purpose of correcting the noncompliance. The term CIP refers to activities formerly categorized as Return Compliance Programs (RCP), Information Gathering Projects (IGP), Compliance 2000 Projects, etc. See IRM 4.17, Compliance Initiative Projects, for additional information on CIPs.


**1.4.40.9.5** **(05-19-2010)**

#### Local Source Projects

1. Local source work consists of high-yield returns identified at the group level and coordinated with the local Planning and Special Programs (PSP) function.

2. A group manager has a responsibility to be innovative in developing local source work. Ensure appropriate guidelines are followed to approve initializing this type of case work.


**1.4.40.9.6** **(05-19-2010)**

#### Compliance Data Environment (CDE)

1. CDE is a workload identification, planning and delivery system operating in a web-based environment.

2. The benefits of CDE are:



1. Faster delivery of returns into the audit stream from the time of filing,

2. Provides 3-year return facsimile, entity data, and related returns,

3. Automated case building options include IDRS, Schedules K-1, and related returns,

4. Just in time delivery - return orders no longer need to be placed months in advance, and

5. Most classification can be performed locally.


3. CDE facsimile returns are used in place of the original return.

4. For additional information and help refer to the Compliance Data Environment (CDE) Knowledge Base.


**1.4.40.9.7** **(05-19-2010)**

#### Governmental Liaison Program

1. Governmental Liaison is a program designed to foster joint tax administration between the IRS and state taxing agencies. It also promotes joint initiatives with other federal agencies, local governments, state agencies (other than taxing agencies), and private-sector organizations.

2. Governmental Liaison objectives include:



   - Improve voluntary and enforced compliance

   - Reduce taxpayer burden

   - Enhance service to taxpayers

   - Allow IRS and state agencies to perform more efficiently and cost effectively


3. Field Governmental Liaison initiatives may include:



   - Information exchange

   - Joint early intervention and education

   - Joint enforcement

   - Joint technological activities


**1.4.40.9.8** **(05-19-2010)**

#### Specialty Areas

1. Ensure that referrals to specialists, when warranted, are made in a timely manner and that examiners are working together to complete the examination as soon as possible. Examples of referrals that may be necessary are:



   - Employment Tax Specialist

   - Employee Plans Specialist

   - Excise Tax Specialist

   - Computer Audit Specialists

   - International Examiners

   - Engineers

   - Economists


2. For additional information on specialist referrals see IRM 4.10.2.7.5, Specialist Referrals.


**1.4.40.9.9** **(05-19-2010)**

#### Fraud

1. Fraud awareness is part of every program. Examiners should be alert for indications of fraud and are encouraged to discuss these cases with a group manager. The determination of civil or criminal fraud and the development necessary in the case should be discussed thoroughly. A Fraud Enforcement Advisor (FEA) can provide assistance in developing fraud cases. See IRM 25.1, Fraud Handbook.

2. Examiners must discuss any potential fraud case they have with their group manager.

3. Occasionally, a group manager will be requested to provide resources to assist in conducting grand jury investigations. Because of the confidentiality of grand jury information, only a limited number of designated officials are permitted to receive this information. This does not include examination group managers, unless the manager is included on the 6(e) order.

4. Examiners should be made aware of their limited responsibility when assisting in grand jury investigations. The sole responsibility of the examiner is to examine books and records and interview third parties to determine the income of the targets of the grand jury. Investigations frequently continue for extended periods; therefore, it is important that feedback on examiner performance is received from the CI manager. The specifics of the investigation activity cannot be provided. However, specifics concerning the examiner’s performance level should be made available to a group manager.

5. See Fraud Development Knowledge Base.


**1.4.40.10** **(04-05-2017)**

### Security

1. Group managers are responsible for ensuring that information and property assigned to the group is provided protection commensurate with its level of sensitivity and that all assets are protected against destruction, theft, or abuse.


**1.4.40.10.1** **(04-05-2017)**

#### Periodic Security Review

1. At least annually, a group manager must perform periodic "functional reviews" of their employees’ work-space to ensure that laptop computers, Sensitive But Unclassified (SBU) information, and PII are protected at all times. Functional reviews measure adherence to security requirements and procedures that apply to each manager's office or functional area.

2. A group manager should periodically perform "after hours reviews" to determine whether documents; property; Form 3210 log; and monies are being adequately protected when not in the custody of authorized IRS personnel

3. For additional information visit the following websites:



1. Facilities Management & Security Services for information and points of contact for facilities and security-related questions and issues.

2. MITS Cybersecurity for information on how to report a security incident.

3. Disclosure and Privacy Knowledge Base for protecting and safeguarding SBU data and PII.


**1.4.40.10.2** **(05-19-2010)**

#### Mandatory Briefings

1. Annual mandatory briefings can seem routine. The information a group manager and employees learn is integral to sustaining the integrity of our workforce and ensuring a secure and safe workplace.

2. A group manager must ensure all mandatory briefings are timely completed. If there are questions concerning these briefings the TM should be consulted. The Mandatory Briefings website contains an up-to-date list of briefings for managers and employees.


**1.4.40.11** **(05-19-2010)**

### Interactions with Other Functions

1. Throughout this manual the importance of working as a team in order to accomplish the mission of the IRS is discussed. The team is made up of all the employees of our organization. The interaction of employees is the lifeblood of the organization. Initial interactions in a work environment will form the basis for relationships with the key people a group manager must work for, with, and through.

2. The following presents an overview of the individuals and functions a group manager will look to for information, assistance, and guidance. These are all members of the team with whom a group manager must work effectively in order to accomplish the organization’s goals.


**1.4.40.11.1** **(04-05-2017)**

#### Appeals and Area Counsel

1. For the most part, an examiner's contact with Appeals and Area Counsel is through their group manager. Recognize Appeals' and Area Counsel's responsibilities and support their efforts.

2. Cases in which taxpayers request an Appeals conference should be promptly transferred. See _IRM 1.4.40.4.11.5_, Unagreed Closing Procedures.

3. An examiner must request and receive permission from their group manager before initiating any communication related to a case with an Appeals employee, unless the case is being worked through Fast Track Settlement. The group manager will determine if the proposed communication is appropriate and whether it is an ex parte communication covered by RRA 98 limitations and further clarified by Rev. Proc. 2012–18. See IRM 4.2.7.3(4), Responsibility for Compliance with the Provisions of the Restructuring and Reform Act (RRA) 98 Section 1001(a)(4), for the group manager’s responsibilities with respect to the request.

4. Area Counsel is available for legal guidance in situations such as summons enforcement, assertion of the civil fraud penalty, and interpretation of any legal issues where Counsel can be of assistance.


**1.4.40.11.2** **(04-14-2021)**

#### Collection

1. Close coordination with Collection personnel is essential on failure-to-file referrals, frivolous filer/nonfiler cases, and claims for refunds submitted during the collection process, see _IRM 1.4.40.4.8_, Collectibility, for additional information.

2. Examiners are required to use the Specialist Referral System (SRS) to submit a mandatory collection referral if the taxpayer’s aggregate unpaid balance of assessment plus the agreed unpaid portion of the amount due (tax, penalty and interest) shown on the examination report exceeds certain dollar criteria. See IRM 4.20.1.3.3, Coordinate with Collection, for additional information.


**1.4.40.11.3** **(05-19-2010)**

#### Criminal Investigation

1. The success of the area fraud program requires cooperation between group employees and Criminal Investigation. A group manager must ensure that adequate staffing is available and properly utilized to complete joint investigations, ensure that quarterly meetings are conducted to monitor the timely completion of joint investigations, and obtain feedback on the quality of fraud referrals. In addition, consider utilizing Criminal Investigation employees to conduct workshops on fraud development.


**1.4.40.11.4** **(05-19-2010)**

#### Disclosure

1. The Disclosure Manager can provide invaluable assistance in resolving questions regarding disclosures of tax returns, tax return information and Privacy Act (PA) information, such as personnel records. The Disclosure Manager handles all requests for information under the Freedom of Information Act (FOIA) or the PA. A FOIA or PA request received in the group should be immediately forwarded to the Disclosure Manager for processing. However, absent a FOIA or PA request, the examiner/group manager has the authority to provide the taxpayer/representative with copies of documents related to the issues in question after reviewing the requested documents for any questionable items. Disclosure should be contacted if there are any questionable items that may be withheld from the requester.

2. Subpoenas received by employees must be immediately faxed or hand-carried to the Disclosure Manager for processing. An employee is allowed to testify in a tax administration case as a witness for the government without a subpoena and without an authorization from the TM. A group manager should make full use of the local Disclosure Manager by extending an invitation to attend a group meeting and requesting orientation for new employees (including technical, para-professional, and support staff). See IRM 11.3, Disclosure of Official Information.


**1.4.40.11.5** **(05-19-2010)**

#### Treasury Inspector General for Tax Administration (TIGTA)

1. TIGTA should be viewed as a positive resource in maintaining a respected, ethical organization. They support employees against false claims, threats, and accusations, as well as investigate allegations of wrongdoing. Invite TIGTA to group meetings to emphasize their role.

2. A group manager should not conduct an investigation into the matters listed above under any circumstances unless TIGTA concurrence is obtained.

3. All information received concerning misconduct of IRS employees or officials will be reported to the local TIGTA office, TIGTA hotline at 1-800-366-4484, or email through the [TIGTA](https://www.treas.gov/tigta/) website.

4. After TIGTA conducts an investigation of alleged improper conduct, the report will be presented to management for review and decision on whether disciplinary action will be required. If no disciplinary action is required, one of the following actions must be taken:



1. Clearance letter

2. Closed without action letter

3. Warning or caution letter


5. TIGTA, Office of Audit, is an independent third party which reviews IRS systems, procedures, and effectiveness.


**1.4.40.11.6** **(04-14-2021)**

#### NTEU Notification - 7114 Meetings

1. Group managers who supervise bargaining unit (BU) employees must:



   - Notify the requisite chapter(s) regarding 7114 meetings when they plan to discuss changes in personnel policies, practices and working conditions with their employees. Generally, five workdays notice is provided. See Document 11678, National Agreement, Article 8, Union Rights.

   - Make sure employees have the opportunity to be represented at formal discussions regarding employee grievances. See IRM 6.771.1, Agency Grievance System (AGS) and IRM 1.4.1.4, Agreements with NTEU.


2. Group managers may contact their assigned LR Specialist if assistance is needed to determine if a meeting is a 7114 meeting.


**1.4.40.11.7** **(05-19-2010)**

#### Research, Applied Analytics & Statistics (RAAS)

1. RAAS is comprised of the following offices:



   - National Research Program (NRP)

   - Office of Program Evaluation & Risk Analysis (OPERA)

   - Servicewide Policy, Directives & Electronic Research (SPDER)

   - Statistics of Income (SOI)

   - Office of Research (OR)


2. RAAS identifies noncompliance at the issue level. Their activities may include demographic, economic, and other studies as requested by the Director, Examination.


**1.4.40.11.8** **(05-19-2010)**

#### Taxpayer Advocate Service (TAS)

1. The Taxpayer Advocate Service (TAS) is an independent organization within the IRS, led by the National Taxpayer Advocate. Each state, the District of Columbia, and Puerto Rico has at least one Local Taxpayer Advocate, who is independent of the local IRS office and reports directly to the National Taxpayer Advocate. TAS helps taxpayers resolve problems with the IRS and recommends changes that will prevent the problems.

2. If a group manager is unable to resolve certain taxpayer complaints or inquiries meeting TAS criteria, a referral may be warranted. Form 911, Request for Taxpayer Advocate Service Assistance (And Application for Taxpayer Assistance Order), should be completed and forwarded to the local TAS office. See IRM 13.1.7.2, Introduction to TAS Case Criteria, which provides the criteria for referral to TAS.

3. Prompt action to resolve a taxpayer’s complaint will result in increased respect for the IRS. A group manager and their employees share the responsibility for maintaining favorable public relations.


**1.4.40.11.9** **(05-19-2010)**

#### Communications & Liaison (C&L)

1. C&L coordinates all media contacts. All media contacts must be cleared through the C&L office. C&L may request that a group manager or technical employees make presentations to groups of taxpayers through taxpayer education programs.


**1.4.40.11.10** **(05-19-2010)**

#### Campus Contacts

1. The support staff may occasionally have to contact one of the campuses to resolve a return requisition, payment posting, or other problems. Each Campus has three Directors: Accounts Management, Submission Processing and Compliance Services. The relationships established with Campus personnel will prove invaluable to the smooth operation of the group.


**1.4.40.12** **(05-19-2010)**

### Collateral Duties

1. The importance of working as a team in order to accomplish the mission of the IRS has been discussed throughout this IRM. This team is made up of all IRS employees. The following presents an overview of some collateral duties which a group manager may be called upon to handle.


**1.4.40.12.1** **(05-19-2010)**

#### Classroom Instructor

1. Group managers may be given instructor assignments in both technical and administrative areas. These assignments give a group manager a change of pace and the ability to refresh their skills.


**1.4.40.12.2** **(05-19-2010)**

#### Commissioner Representative

1. The Senior Commissioner Representative and Commissioner Representatives provide management leadership for cross-functional administrative activities in field offices of the IRS. Duties may include taxpayer concerns, security, supplies, safety, and general operating guidance. See IRM 1.4.12.3, Roles of the Commissioner’s Representatives (CRs and Alternates), for additional information.


**1.4.40.12.3** **(05-19-2010)**

#### Recruiting

1. A group manager may play a key role in recruiting qualified candidates. When internal employees are being considered for a crossover to another position or external applicants are seeking initial appointments, a group manager may be in a position to influence an individual’s decision to work for the IRS. Represent the IRS in a professional manner when talking with prospective employees or school officials. Review recruitment literature and talk with a personnel staffing specialist before making recruitment visits to obtain knowledge regarding job duties and educational requirements.


**1.4.40.12.4** **(05-19-2010)**

#### Taxpayer Services (TS) Customer Service

1. A group manager may receive a request to provide examination staffing during filing season to assist taxpayers with the preparation of their returns or technical assistance.


**1.4.40.13** **(05-19-2010)**

### General Group Management Issues

1. A group manager is responsible for end-to-end management of the group. Some additional areas of responsibility include the following:




| Additional Areas of Responsibility | Examples |
| --- | --- |
| Dissemination of instructions - a group manager should ensure instructions and guidelines from management are timely disseminated to the work group. | Meet with the group and discuss emerging issues, new developments, and revised procedures as warranted. |
| Managerial controls - a group manager should maintain effective group controls to ensure work assigned is completed in an efficient manner. | - Ensure work assignments are completed in a fair and impartial manner.<br>     <br>   - Ensure all employees are made aware when another person has been designated to act on behalf of the group manager.<br>     <br>   - Consider employee suggestions for improvements.<br>     <br>   - Encourage full employee engagement. |
| Personnel Issues - personnel issues that may occur in the group include the following: | - Review time and attendance records periodically to determine if any areas require attention.<br>     <br>   - Employees should promptly notify their group manager when they will be absent.<br>     <br>   - Employee vacation time should be scheduled in advance to facilitate proper planning and ensure employees are given an opportunity to take their accrued annual leave.<br>     <br>   - A group manager should review employee position descriptions and CJEs to ensure they are current. |
| Access to tax administration tools - A group manager should ensure employees have access to tax administration tools needed to do their job. They may include but are not limited to the following: | - Tax law research tools,<br>     <br>   - Internet,<br>     <br>   - Asset locator tools, and<br>     <br>   - IDRS. |


**1.4.40.14** **(04-14-2021)**

### Telework

1. Telework is a program that permits employees to work at home, or at other approved locations other than the assigned post of duty, and provides employees the flexibility to better manage work, family and personal responsibilities. The following resources provide information regarding the telework process and requirements:



   - IRM 1.4.1.12.3, Telework Program,

   - IRM 6.800.2, IRS Telework Program,

   - IRS Telework Portal, and

   - National Agreement.


**Exhibit 1.4.40-1**

### Terms

The following table contains a list of terms used throughout this IRM.

| Term | Definition |
| --- | --- |
| Bargaining Unit Employee | An employee who is covered by the National Agreement with the National Treasury Employees Union (NTEU). |
| Drop File | A file established for each employee for non-performance related, conduct or administrative issues. The employee drop file should contain everything that is not performance related such as leave counseling and copies of disciplinary actions. See IRM 1.4.1.8.5(5), Employee Performance File (EPF). |
| Employee Performance File (EPF) | A file maintained by the employee’s immediate supervisor consisting only of performance-related documents covering the past four years. See IRM 6.430.3.4.3, Employee Performance File (EPF). |
| Ex Parte Communication | Communication between any Appeals employee and an employee of another IRS function without the taxpayer/representative being given the opportunity to participate in the communication. See Rev. Proc. 2012-18 at 2.01(1) and IRM 4.2.7.2, Definitions. |
| Indirect Time | Time spent on technical duties that cannot be charged to a specific case or activity. Generally, this includes attending group meetings, reading procedural / technical material, preparing and attending technical / procedural conferences, completing forms, working on committees, managing records, preparing time reports / travel vouchers, general housekeeping (e.g., moving, ordering supplies and surveying space) and answering email/VMS. Group managers will not charge time to this code. See IRM Exhibit 4.9.1-1, Definitions of Miscellaneous Examination Activity Codes. |
| Form 3210 Log | A repository to retain control and acknowledgement copies of Form 3210. |
| Personally Identifiable Information (PII) | Information that can be used to distinguish or trace an individual’s identity, either alone or when combined with other information that is linked or linkable to a specific individual. See IRM 10.5.1.2.3, Personally Identifiable Information (PII). |
| Overage | When a case is in process in excess of 180 days for office examination and 270 days for field examination. See IRM 4.10.1.4.5, Timely Actions. |
| Recordation | A group manager’s written record evaluating an employee in a positive or negative manner. |
| Risk Analysis | The process that compares the potential benefits to be derived from examining a specific area on a tax return with the resources needed to complete the examination. The risk analysis utilizes resources more efficiently, improves the audit planning process, reduces cycle time and reduces delays during the examination. Risk analysis is an on-going process throughout the examination. |
| Survey Before Assignment | The process by which a manager makes the determination to close a return without assigning it for examination. |
| Survey After Assignment | The process by which an examiner makes the determination not to audit the tax return after completing and documenting the pre-contact analysis, but before examining any books and records, because an examination would not result in a material change to the taxpayer’s tax liability. |

**Exhibit 1.4.40-2**

### Acronyms

The following table lists commonly used acronyms and their definitions used throughout this IRM:

| Acronym | Definition |
| --- | --- |
| AD | Area Director |
| ADRR | AIMS Duplicate Records Report |
| AGS | Agency Grievance System |
| AIMS | Audit Information Management System |
| ASED | Assessment Statute Expiration Date |
| ATG | Audit Technique Guide |
| BEARS | Business Entitlement Access Request System |
| BU | Bargaining Unit |
| C&L | Communications & Liaison |
| CAU | Caution Upon Contact |
| CCP | Centralized Case Processing |
| CDE | Compliance Data Environment |
| CIP | Compliance Initiative Project |
| CJE | Critical Job Elements |
| CLP | Career Learning Plan |
| CPE | Continuing Professional Education |
| CR | Commissioner’s Representative |
| CUI | Controlled Unclassified Information |
| DC | Disposal Code |
| DET | Direct Examination Time |
| DIF | Discriminant Index Function |
| EPF | Employee Performance File |
| EPR | Examination Process Report |
| EQ | Embedded Quality |
| EQRS | Embedded Quality Review System |
| ERCS | Examination Returns Control System |
| ETTR | Examination Technical Time Reports |
| FEA | Fraud Enforcement Advisor |
| FMFIA | Federal Managers’ Financial Integrity Act |
| FMSS | Facilities Management and Security Services |
| FOIA | Freedom of Information Act |
| FSEQ | Field and Specialty Exam Quality |
| FTS | Fast Track Settlement |
| GM | Group Manager |
| GMCM | Group Manager Concurrence Meeting |
| GRS | The General Records Schedules |
| HCO | Human Capital Office |
| ICMA | Internal Controls Managerial Assessment |
| IDRS | Integrated Data Retrieval System |
| IORS | IDRS Online Reports Services |
| IRC | Internal Revenue Code |
| IRP | Information Reporting Program Transcripts |
| ITM | Integrated Talent Management |
| IVL | Inventory Validation Listing |
| LB&I | Large Business and International |
| LIFO | Last In-First Out |
| LR | Labor Relations |
| LUQ | Large, Unusual and Questionable |
| MF | Master File |
| MCD | Mutual Commitment Date |
| NAICS | North American Industry Classification System |
| NMF | Non Master File |
| NQRS | National Quality Review System |
| NRP | National Research Program |
| NTEU | National Treasury Employees Union |
| OMB | Office of Management and Budget |
| OPM | Office of Personnel Management |
| OJV | On-the-Job Visit |
| PA | Privacy Act |
| PBA | Principle Business Activity |
| PCS | Pass-Through Control System |
| PDT | Potentially Dangerous Taxpayer |
| PEO | Professional Employer Organization |
| PII | Personally Identifiable Information |
| PIA | Principle Industry Activity |
| PMS | Performance Management System |
| PSP | Planning & Special Programs |
| QSI | Quality Step Increase |
| RA | Revenue Agent |
| RAAS | Research, Applied Analytics & Statistics |
| RCS | Records Control Schedule |
| RGS | Report Generation Software |
| ROTERS | Records of Tax Enforcement Results |
| SBU | Sensitive But Unclassified |
| SB/SE | Small Business/Self-Employed |
| SCR | Sensitive Case Report |
| SEID | Standard Employee Identifier |
| SETR | Single-Entry Time Recording |
| SETTS | Summary Examination Time Transmission System |
| SFR | Substitute for Return |
| SHIMS | Safety and Health Information Management System |
| SNOD | Statutory Notice of Deficiency |
| SOL | Statute of Limitations |
| SRC | Survey Reason Code |
| SRS | Specialist Referral System |
| SSC | Security Section Chief |
| SSIVL | Statistical Sample Inventory Validation System |
| TA | Technical Advisors |
| TAPS | Totally Automated Personnel System |
| TAS | Taxpayer Advocate Service |
| TBOR | Taxpayer Bill of Rights |
| TC | Transaction Code |
| TCO | Tax Compliance Officer |
| TEFRA | Tax Equity and Fiscal Responsibility Act of 1982 |
| TER | Tax Enforcement Result |
| TE/GE | Tax-Exempt and Government Entities |
| TIGTA | Treasury Inspector General for Tax Administration |
| TPC | Transactional Processing Center |
| UNAX | Unauthorized Access |
| TS | Taxpayer Services |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-040#addtoany "Show all")

A2A