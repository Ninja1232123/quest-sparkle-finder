---
url: "https://www.irs.gov/irm/part1/irm_01-002-061"
title: "1.2.61 Business Unit Delegations of Authority for Taxpayer Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-002-061#main-content)

- 1.2.61  [Business Unit Delegations of Authority for Taxpayer Services](https://www.irs.gov/irm/part1/irm_01-002-061#id1)
  - 1.2.61.1  [Introduction to Business Unit Delegation of Authorities for Taxpayer Services](https://www.irs.gov/irm/part1/irm_01-002-061#id2)
  - 1.2.61.2  [Current Taxpayer Services Business Unit Delegations of Authority](https://www.irs.gov/irm/part1/irm_01-002-061#id3)
    - 1.2.61.2.1  [Delegation Order WI 1-1-1, Order of Succession and Designation to Act as Commissioner, Wage and Investment Division](https://www.irs.gov/irm/part1/irm_01-002-061#id5)
    - 1.2.61.2.2  [Delegation Order WI 1-3-1 (formerly DO 19-WI), Authorization of Employee Relocation Allowances and Approval of Relocation Reimbursements](https://www.irs.gov/irm/part1/irm_01-002-061#id6)
    - 1.2.61.2.3  [Delegation Order WI 1-5-1, Reimbursement for Actual Expenses](https://www.irs.gov/irm/part1/irm_01-002-061#id7)
    - 1.2.61.2.4  [Delegation Order WI 1-7-1 (formerly DO 47-WI), To Authorize Attendance at Meetings at Government Expense](https://www.irs.gov/irm/part1/irm_01-002-061#id8)
    - 1.2.61.2.5  [Delegation Order WI 1-13-1 (formerly DO WI-100-1), Furnishing Special Statistical Studies, Compilations, Return and Return Information, Training, and Training Aids](https://www.irs.gov/irm/part1/irm_01-002-061#id9)
    - 1.2.61.2.6  [Delegation Order WI 1-21-1 (formerly DO 188-WI), To Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 USC 208](https://www.irs.gov/irm/part1/irm_01-002-061#id10)
    - 1.2.61.2.7  [Delegation Order WI 1-23-1 (formerly DO WI-193-1), Approve Instructor Allowance Certifications](https://www.irs.gov/irm/part1/irm_01-002-061#id11)
    - 1.2.61.2.8  [Delegation Order WI 1-23-2 (formerly DO WI-193-3), Authorization to Perform Functions of the Chief, Taxpayer Services](https://www.irs.gov/irm/part1/irm_01-002-061#id12)
    - 1.2.61.2.9  [Delegation Order WI 1-30-1 (formerly DO 95-WI), Approval of Travel Advances, Travel and Transportation Services, and Travel Vouchers](https://www.irs.gov/irm/part1/irm_01-002-061#id13)
    - 1.2.61.2.10  [Delegation Order WI 1-35-1 (formerly DO 95-WI), Authority to Approve the Use of Non-Contract Air Carriers](https://www.irs.gov/irm/part1/irm_01-002-061#id14)
    - 1.2.61.2.11  [Delegation Order WI 1-69-1, Authorization to Approve an Internal Management Document (IMD)](https://www.irs.gov/irm/part1/irm_01-002-061#id15)
    - 1.2.61.2.12  [Delegation Order WI 6-1-1 (formerly DO 6-1A), Authority to Create and Abolish Positions](https://www.irs.gov/irm/part1/irm_01-002-061#id16)
    - 1.2.61.2.13  [Delegation Order WI 6-4-1 (formerly DO WI-105-1), Authorization to Engage in Outside Employment, Business, and Other Activities](https://www.irs.gov/irm/part1/irm_01-002-061#id17)
    - 1.2.61.2.14  [Delegation Order WI 6-6-1 (formerly DO WI-81-1), Adverse/Disciplinary and Other Actions](https://www.irs.gov/irm/part1/irm_01-002-061#id18)
    - 1.2.61.2.15  [Delegation Order WI 6-6-3 (formerly DO WI-81-3), Performance Evaluations](https://www.irs.gov/irm/part1/irm_01-002-061#id19)
    - 1.2.61.2.16  [Delegation Order WI 6-7-1 (formerly DO WI-258-1), Temporary Office Closures and Dismissals](https://www.irs.gov/irm/part1/irm_01-002-061#id20)
    - 1.2.61.2.17  [Delegation Order WI 6-11-1 (formerly WI-39-1), Tours of Duty](https://www.irs.gov/irm/part1/irm_01-002-061#id21)
    - 1.2.61.2.18  [Delegation Order WI 6-22-1 (formerly DO WI-6-6-2), Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases](https://www.irs.gov/irm/part1/irm_01-002-061#id22)
    - 1.2.61.2.19  [Delegation Order TS 6-29-1, Address Employee Performance or Conduct Issues](https://www.irs.gov/irm/part1/irm_01-002-061#id23)
    - 1.2.61.2.20  [Delegation Order WI 11-2-1, Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents](https://www.irs.gov/irm/part1/irm_01-002-061#id24)
  - 1.2.61.3  [Rescinded Taxpayer Services Business Unit Delegations of Authority](https://www.irs.gov/irm/part1/irm_01-002-061#id25)
    - 1.2.61.3.1  [Delegation Order WI 4-37-1, Record Keeping Requirement](https://www.irs.gov/irm/part1/irm_01-002-061#id27)
    - 1.2.61.3.2  [Delegation Order WI 4-38-1, To Designate Qualified General Assistance Programs Described in IRC 51 (d) (6)](https://www.irs.gov/irm/part1/irm_01-002-061#id28)
    - 1.2.61.3.3  [Delegation Order WI 6-6-4 (formerly DO WI-81-4), To Initiate or Approve Personnel Actions (Form SF-50 and Form SF-52)](https://www.irs.gov/irm/part1/irm_01-002-061#id29)
    - 1.2.61.3.4  [Delegation Order WI 6-6-5, Approve Merit Promotion Selections](https://www.irs.gov/irm/part1/irm_01-002-061#id30)
    - 1.2.61.3.5  [Delegation Order WI 6-6-6, Authority to Approve Personnel Actions for Corrective Actions Including Retroactive Promotion and Retroactive Back Pay](https://www.irs.gov/irm/part1/irm_01-002-061#id31)
    - 1.2.61.3.6  [Delegation Order WI 6-12-1 (formerly DO WI-104-1), Absence and Charges to Leave](https://www.irs.gov/irm/part1/irm_01-002-061#id32)
    - 1.2.61.3.7  [Delegation Order WI 6-14-1, Overtime](https://www.irs.gov/irm/part1/irm_01-002-061#id33)
    - 1.2.61.3.8  [Delegation Order WI 11-5-1, Seal of the Office of the Internal Revenue Service and Certification to the Authenticity of Official Documents](https://www.irs.gov/irm/part1/irm_01-002-061#id34)
    - 1.2.61.3.9  [Delegation Order WI 23-1 (formerly DO 23-WI), Settlement of Tort Claims; Claims Under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damages to or Loss of Personal Property Incident to Service](https://www.irs.gov/irm/part1/irm_01-002-061#id35)
    - 1.2.61.3.10  [Delegation Order WI 25-2-1 (formerly DO WI 42-1), Authority to Execute Consents Fixing the Period of Limitations on Assessment or Collection under Provisions of the 1939, 1954, and 1986 Internal Revenue Codes](https://www.irs.gov/irm/part1/irm_01-002-061#id36)
    - 1.2.61.3.11  [Delegation Order WI 77-1 (formerly DO 77-WI), Issue or Execute Agreement to Rescind Notices of Deficiency](https://www.irs.gov/irm/part1/irm_01-002-061#id37)
    - 1.2.61.3.12  [Delegation Order WI 189-1 (formerly DO 189-WI), To Authorize Travel Not at Government Expense](https://www.irs.gov/irm/part1/irm_01-002-061#id38)
    - 1.2.61.3.13  [Delegation Order WI 191-1 (formerly DO 191-WI), Levy on Property in the Hands of a Third Party (not to include Form 668-B)](https://www.irs.gov/irm/part1/irm_01-002-061#id39)
    - 1.2.61.3.14  [Delegation Order WI 192-1 (formerly DO 192-WI), Approve the Use of Cash to Purchase Official Passenger Transportation Services Exceeding $500](https://www.irs.gov/irm/part1/irm_01-002-061#id40)
    - 1.2.61.3.15  [Delegation Order WI 193-2 (formerly DO 193B), Authority in Personnel Matters and Budget Execution](https://www.irs.gov/irm/part1/irm_01-002-061#id41)

# Part 1. Organization, Finance, and Management

# Chapter 2. Servicewide Policies and Authorities

# Section 61. Business Unit Delegations of Authority for Taxpayer Services

* * *

## 1.2.61 Business Unit Delegations of Authority for Taxpayer Services

#### Manual Transmittal

July 28, 2025

#### Purpose

(1) This transmits revised IRM 1.2.61, Servicewide Policies and Authorities, Business Unit Delegations of Authority for Taxpayer Services.

#### Material Changes

(1) IRM 1.2.61.2(2), Added clarification on Wage and Investment name change to Taxpayer Service.

(2) IRM 1.2.61.2.4(3), Removed Director, Equity, Diversity and Inclusion pursuant to Executive Order 14151, **Ending Radical and Wasteful Government DEI Programs and Preferencing**. (IPU 25U0173 issued 02-06-2025)

(3) IRM 1.2.61.2.19, New Subsection: Taxpayer Service Delegation Order TS 6-29-1, Address Employee Performance or Conduct Issues, Issued April 30, 2024. Source of Authority comes from Servicewide Delegation Order 6-29. (IPU 25U0151 issued 01-31-2025)

(4) Editorial changes made throughout the IRM: (IPU 25U0151 issued 01-31-2025)

- Updated Wage and Investment Division to Taxpayer Services.

- Updated title of the Wage and Investment Commissioner to Chief, Taxpayer Services.

- Updated Wage and Investment, Deputy Commissioner to Deputy Chief, Taxpayer Service.

- Updated titles to include Delegation Order (DO) Titles.

- Added the IRM links to DO Sources of Authorities.

- Editorial changes made for clarity.

- Updated email addresses and website links.


#### Effect on Other Documents

IRM 1.2.61 dated June 17, 2022 (effective June 17, 2022), is superseded. This revision incorporates IRM Procedural Update (IPU) 25U0151 issued January 31, 2025, and IPU 25U0151 issued February 6, 2025.

#### Audience

All organizations in Taxpayer Services

#### Effective Date

(07-28-2025)

Robert J Bedoya

Director, Business Technology Operations

Taxpayer Services

**1.2.61.1** **(10-27-2016)**

### Introduction to Business Unit Delegation of Authorities for Taxpayer Services

1. This IRM contains business unit delegation orders (DO) for Taxpayer Services (TS). Distribution of this IRM includes all persons with a need for any of the authorities or information in this section. All approved TS Division Delegation Orders are listed in numerical order. Rescinded Division Delegation Orders for TS are retained in this IRM for documentation and audit purposes and follow current delegation orders.

2. Taxpayer Services delegation orders are approved and signed by the Chief, Taxpayer Services and issued through TS Headquarters. Direct any questions regarding current division DOs, including revisions or issuance of new division DOs, to the TS Internal Management Document (IMD) Team at ts.irms@irs.gov.

3. Information on Servicewide Delegations of Authority is found in IRM 1.2.2, Servicewide Policies and Authorities, Servicewide Delegations of Authority. Furthermore, additional information on the delegation order process is found in IRM 1.11.4, Internal Management Document System, Servicewide Delegation Order Process.

4. Authority is delegated directly to the lowest level expected to take final action. Doing so eliminates the need to issue redelegations of authority to heads of office. Delegating authority to the lowest level for action means that: **Every intervening supervisory position above the lowest level, including the Chief, has the same authority**.

5. Management levels are arranged from the lowest level to the highest level. This IRM will use the general management level terms, and their definitions are as follows:




| **Term** | **Definition** | **Examples** |
| --- | --- | --- |
| First Level Manager | A manager who only has employees reporting to him/her; no other managers report to this manager | Team manager, group or section manager without subordinate managers |
| Second Level Manager | A manager of a first level manager | Department, section manager with subordinate managers |
| Third Level Manager | A manager of a second level manager | Operations manager with subordinate second level managers, Section level or branch level managers with managers |
| First Level Executive | An executive who does not have another executive reporting to him/her | Field Director, Campus Director, Area Director |
| Second Level Executive | An executive who has a first level executive reporting to him/her | Director with subordinate Executives (e.g., Director, Customer Account Services; Director Customer Assistance, Relationships and Education; etc.) |
| Third Level Executive | An executive who has a second level executive reporting to him/her | Chief Taxpayer Services and Deputy Chief Taxpayer Services |


**1.2.61.2** **(07-28-2025)**

### Current Taxpayer Services Business Unit Delegations of Authority

1. Current Taxpayer Service (TS) business unit (BU) delegation orders are listed as recent, revised and obsoleted. New TS BU delegation orders, approved after this IRM revision, can be found at [https://www.irs.gov/uac/recently-approved-division-function-delegation-orders](https://www.irs.gov/uac/recently-approved-division-function-delegation-orders); all documents are maintained on the website until the next IRM revision.

2. On April 7, 2024, the Wage and Investment Division (W&I) was renamed to Taxpayer Services (TS). Any references to W&I will be treated as TS. The Third Level Executives titles changed from W&I Commissioner and W&I Deputy Commissioner to Chief, Taxpayer Services and Deputy Chief, Taxpayer Services.


**1.2.61.2.1** **(01-09-2019)**

#### Delegation Order WI 1-1-1, Order of Succession and Designation to Act as Commissioner, Wage and Investment Division

1. **Order of Succession and Designation to Act as Commissioner, Wage and Investment Division**

2. **Authority:** To act and perform the functions of the Commissioner of the Wage and Investment Division of the Internal Revenue Service in the absence of the Division Commissioner and the Division Deputy Commissioner due to an enemy attack on the United States, disability, other emergency or vacancy/absence in the office; thus, ensuring the continuity of the functions of the office.

3. **Delegated to:**



   - Director, Customer Account Services

   - Director, Customer Assistance, Relationships and Education

   - Director, Operations Support (W&I)

   - Director, Return Integrity and Compliance Services


4. **Redelegation:** In the absence of these officials, the authority is redelegated in the order as follows:



   - Director, Accounts Management

   - Director, Submission Processing

   - Director, Stakeholder Partnerships, Education and Communication

   - Director, Field Assistance


5. **Source of Authority:** Servicewide Delegation Order 1-1 and Servicewide Delegation Order 1-2.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.2.2** **(02-13-2017)**

#### Delegation Order WI 1-3-1 (formerly DO 19-WI), Authorization of Employee Relocation Allowances and Approval of Relocation Reimbursements

1. **Authorization of Employee Relocation Allowances and Approval of Relocation Reimbursements**

2. **Authority:** To authorize relocation allowances for transfers and appointments to a new official station for Basic Moving Expenses in accordance with the IRS relocation guidance.

3. **Delegated to:**



   - Director, Customer Account Services

   - Director, Customer Assistance, Relationships and Education

   - Director, Operations Support (W&I)

   - Director, Return Integrity and Compliance Services


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-3.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.2.3** **(11-09-2015)**

#### Delegation Order WI 1-5-1, Reimbursement for Actual Expenses

1. **Reimbursement for Actual Expenses**

2. **Authority:** To authorize and approve reimbursement for subsistence on an actual expense basis in accordance with the Federal Travel Regulation and IRM 1.31.11, Official IRS City-to-City Travel Guide.

3. **Delegated to:** Deputy Commissioner, Wage and Investment.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-5.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Debra Holland, Commissioner, Wage and Investment Division.


**1.2.61.2.4** **(02-13-2017)**

#### Delegation Order WI 1-7-1 (formerly DO 47-WI), To Authorize Attendance at Meetings at Government Expense

1. **To Authorize Attendance at Meetings at Government Expense**

2. **Authority:**



1. To authorize the attendance of employees at meetings of scientific or professional societies; municipal, state, federal, or international organizations; Congress; and law enforcement or other groups.

2. To authorize or approve attendance of employees at meetings held by employee groups, organizations or associations.


3. **Delegated to:**



   - Director, Communications and Liaison (W&I)

   - Director, Customer Account Services

   - Director, Customer Assistance, Relationships and Education

   - Director, Operations Support (W&I)

   - Director, Return Integrity and Compliance Services


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-7.

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.2.5** **(07-28-2016)**

#### Delegation Order WI 1-13-1 (formerly DO WI-100-1), Furnishing Special Statistical Studies, Compilations, Return and Return Information, Training, and Training Aids

1. **Furnishing Special Statistical Studies, Compilations, Return and Return Information, Training, and Training Aids**

2. **Authority:** To enter into contracts to furnish information on a reimbursable basis.

3. **Delegated to:** Director, Strategies and Solutions.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-13.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Debra Holland, Commissioner, Wage and Investment Division.


**1.2.61.2.6** **(09-01-2002)**

#### Delegation Order WI 1-21-1 (formerly DO 188-WI), To Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 USC 208

1. **To Grant Case by Case Exemptions to the Financial Conflict of Interest Provision in 18 USC 208**

2. **Authority:** To make written determinations under 18 USC 208 that financial interests of employees under their supervision and control are not so substantial as to be deemed likely to affect the integrity of the services which the Government may expect from such employees if they participate personally and substantially in a matter in which they have a financial interest.

3. **Delegated to:** All executives.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-21.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, John M. Dalrymple, Commissioner, Wage and Investment Division.


**1.2.61.2.7** **(09-15-2003)**

#### Delegation Order WI 1-23-1 (formerly DO WI-193-1), Approve Instructor Allowance Certifications

1. **Approve Instructor Allowance Certifications**

2. **Authority:** To approve Instructor Allowance Certifications.

3. **Delegated to:** First level executives.



### Note:



The delegated official approving the allowance must be at a higher organizational level than the reviewing/certifying official.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Henry O. Lamar, Jr., Commissioner, Wage and Investment Division.


**1.2.61.2.8** **(05-27-2020)**

#### Delegation Order WI 1-23-2 (formerly DO WI-193-3), Authorization to Perform Functions of the Chief, Taxpayer Services

01. **Authorization to Perform Functions of the Commissioner, Wage and Investment Division**

02. **Authority 1:** To perform any function the Commissioner, Wage and Investment Division is authorized to perform; however, excluding those functions that have been delegated by the Commissioner, Internal Revenue Service, to the Commissioner, Wage and Investment Division, and which may not be redelegated.

03. **Delegated to:** Deputy Commissioner, Wage and Investment Division.

04. **Authority 2:** To perform the functions the Commissioner, Wage and Investment Division is authorized to perform, which arise out of, relate to or concern matters under their jurisdictions and cases under their responsibilities; except when delegation of a function is prohibited by law, when delegation would be inconsistent with another delegation, or when a function has been delegated by the Commissioner, Internal Revenue Service, to the Commissioner, Wage and Investment Division, and may not be redelegated, where prohibited by law or inconsistent with another delegation. Each official will exercise this authority in his or her own capacity, under his or her own title, and is responsible for referring matters to the Commissioner, Wage and Investment Division, for action when appropriate.

05. **Delegated to:**



    - Director, Customer Account Services

    - Director, Customer Assistance, Relationships and Education

    - Director, Operations Support (W&I)

    - Director, Return Integrity and Compliance Services

    - Director, Accounts Management

    - Director, Submission Processing

    - Director, Stakeholder Partnerships, Education and Communication

    - Director, Field Assistance


06. **Authority 3:** To take actions previously delegated to District Directors, Regional Commissioners, Directors of Service Centers, and Assistant Commissioners by Treasury Regulations, Treasury Decisions, or Revenue Procedures for matters under their jurisdiction or cases under their responsibility; and to delegate same to officers and persons under their supervision, except where prohibited by law or where inconsistent with delegations reprinted in IRM 1.2, Section 2.

07. _Delegated to:_ All Executives.

08. **Redelegation:** The authorities listed in this Delegation Order (1, 2 and 3) may not be redelegated.

09. **Source of Authority:** Servicewide Delegation Order 1-23 and Servicewide Delegation Order 1-2.

10. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified. This order supersedes Division Delegation Order WI 1-23-2, effective February 13, 2017.

11. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.2.9** **(10-01-2000)**

#### Delegation Order WI 1-30-1 (formerly DO 95-WI), Approval of Travel Advances, Travel and Transportation Services, and Travel Vouchers

1. **Approval of Travel Advances, Travel and Transportation Services, and Travel Vouchers**

2. **Authority:** To direct official travel and approve advances and travel vouchers for reimbursement of expenses, including non-workday travel, under the Federal Travel Regulation and Treasury and Service travel and relocation guidance.

3. **Delegated to:** First level managers.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-30.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, John M. Dalrymple, Commissioner, Wage and Investment Division.


**1.2.61.2.10** **(11-09-2015)**

#### Delegation Order WI 1-35-1 (formerly DO 95-WI), Authority to Approve the Use of Non-Contract Air Carriers

1. **Authority to Approve the Use of Non-contract Air Carriers**

2. **Authority:** To approve the use of non-contract air carriers rather than contract air carriers between city-pairs when justified in accordance with the Federal Travel Regulations and IRM 1.32.11, Official IRS City-to-City Travel Guide.

3. **Delegated to:** First level executives.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-35.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Debra Holland, Commissioner, Wage and Investment Division.


**1.2.61.2.11** **(11-19-2021)**

#### Delegation Order WI 1-69-1, Authorization to Approve an Internal Management Document (IMD)

1. **Authorization to Approve an Internal Management Document (IMD)**

2. **Authority:** To approve and authorize issuance of a new, revised, or obsolesced Internal Revenue Manual (IRM) section, IRM procedural update (IPU), interim guidance memorandum (IGM), or operating level directive without newly designated or changed official use only (OUO).

3. **Delegated to:** A supervisory manager with program oversight of the IMD content. The supervisory manager’s designation must be on record with the W&I IMD Team.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-69.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.2.12** **(01-28-2021)**

#### Delegation Order WI 6-1-1 (formerly DO 6-1A), Authority to Create and Abolish Positions

1. **Authority to Create and Abolish Positions**

2. **Authority:** To create and abolish positions. The abolishment of a position is defined as the actual termination of the position, with the duties eliminated entirely or combined with the duties of another position or positions.

3. **Delegated to:** Director, Capital Management and Oversight.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 6-1.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.2.13** **(02-01-2011)**

#### Delegation Order WI 6-4-1 (formerly DO WI-105-1), Authorization to Engage in Outside Employment, Business, and Other Activities

01. **Authorization to Engage in Outside Employment, Business, and Other Activities**

02. **Authority 1:** To approve or disapprove the acquisition or retention of direct or indirect interests in the manufacture of tobacco, snuff, or cigarettes, firearms, ammunition, or explosives, or in the production, rectification, or redistillation of distilled spirits, or in the production of fermented liquors, by employees under their supervision and control.

03. **Delegated to:** All executives.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority 2:** To approve or disapprove requests from employees under their supervision and control, to engage in outside employment, business, and other activities.

06. **Delegated to:** Third level managers.

07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:** Servicewide Delegation Order 6-4.

09. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

10. Signed, John M. Dalrymple, Commissioner, Wage and Investment Division.


**1.2.61.2.14** **(10-02-2014)**

#### Delegation Order WI 6-6-1 (formerly DO WI-81-1), Adverse/Disciplinary and Other Actions

01. **Adverse/Disciplinary and Other Actions**

02. **Authority 1****:** Propose adverse actions (i.e., removals, reductions in grade or pay, suspensions of more than 14 calendar days, furloughs without pay) and actions based on unacceptable performance (i.e., removals, reductions in grade) for employees under their supervision.

03. **Delegated to:** Supervisors two levels above the employee for who the action is proposed.

04. ****Redelegation**:** This authority may not be redelegated.

05. **Authority 2:** Effect adverse actions and an action based on unacceptable performance.

06. **Delegated to:** All executives to whom a subordinate manager has proposed an action; must be at least three (3) supervisory levels above individual for whom the action is proposed**.**

07. **Redelegation:** This authority may not be redelegated.

08. **Authority 3:** Propose and/or effect suspensions of 14 calendar days or less, written reprimands, admonishments, warning letters and letters of caution, closed without action and clearance letters, and suitability determinations.

09. **Delegated to:** Two supervisory levels above the employee for whom the action is proposed and/or effected.

10. **Redelegation:** This authority may not be redelegated.

11. **Source of Authority:** Servicewide Delegation Order 6-6.

12. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

13. Signed, Debra Holland, Commissioner, Wage and Investment Division.


**1.2.61.2.15** **(02-01-2011)**

#### Delegation Order WI 6-6-3 (formerly DO WI-81-3), Performance Evaluations

1. **Performance Evaluations**

2. **Authority:** To determine that work is or is not of an acceptable level of competence for within-grade step increases for employees under their jurisdiction.

3. **Delegated to:** All managers.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 6-6.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, John M. Dalrymple, Commissioner, Wage and Investment Division.


**1.2.61.2.16** **(05-13-2013)**

#### Delegation Order WI 6-7-1 (formerly DO WI-258-1), Temporary Office Closures and Dismissals

1. **Temporary Office Closures and Dismissals**

2. **Authority:** To close posts of duty and local offices, foreign posts, and offices in Puerto Rico.

3. **Delegated to:** Senior Commissioner's Representative or official having administrative supervision at such subordinate offices.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 6-7.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Peggy Bogadi, Commissioner, Wage and Investment Division.


**1.2.61.2.17** **(02-01-2011)**

#### Delegation Order WI 6-11-1 (formerly WI-39-1), Tours of Duty

01. **Tours of Duty**

02. **Authority 1:** To prescribe the official hours of duty and, when necessitated by operating requirements, establish an administrative workweek of five, 8 hour, days other than Monday through Friday for individual employees or groups of employees whose services are required on Saturday and/or Sunday in accordance with applicable statutes, executive orders, regulations and policies.

03. **Delegated to:** First level managers.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority 2:** To establish tours of duty for educational purposes in accordance with applicable statutes, executive orders, regulations and policies.

06. **Delegated to:**



    - Operations/Branch Managers or equivalent

    - Customer Assistance, Relationships and Education Territory Managers


07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:** Servicewide Delegation Order 6-11.

09. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

10. Signed, John M. Dalrymple, Commissioner, Wage and Investment Division.


**1.2.61.2.18** **(11-17-2021)**

#### Delegation Order WI 6-22-1 (formerly DO WI-6-6-2), Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases

01. **Authority to Approve Monetary and Time-Off Performance Awards, Performance Bonuses, Individual and Group Special Act Awards, Managers’ Awards, Bilingual Awards, Honorary Awards, Employee Suggestion Awards, Informal Recognition, and Quality Step Increases**



    ### Note:



    All award approvals are subject to budgetary limitations.





    1. ### Note:



       This delegation order does not cover awards granted to members of the Senior Executive Service (SES), Streamlined Critical Pay Executives, and other employees serviced by the Human Capital Office’s Office of Executive Services (OES), or awards or Quality Step Increases granted to Chief Counsel employees.


02. **Authority 1:** To approve performance awards not to exceed the lesser amount of $10,000 or 10% of the annual rate of basic pay (including locality) for employees under their jurisdiction. Also, Bargaining Unit employee performance awards are subject to the requirements outlined in the current National Agreement and the National Performance Awards Agreement (NPAA).

03. **Delegated to:** The Commissioner of the Wage and Investment Division.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority 2:** To approve:



    1. Special Act, Service, Superior Accomplishment, or Employee Suggestion Awards not to exceed $10,000.

    2. Group Awards not to exceed $50,000 for the group, provided that no individual employee in the group is granted more than $10,000.


06. **Delegated to:** All executives who are a minimum of at least 3 levels above the employee(s) being recommended for the award.

07. **Redelegation:** This authority may not be redelegated.

08. **Authority 3:** To approve:



    1. Special Act, Service, Superior Accomplishment, or Employee Suggestion Awards not to exceed $3,500.

    2. Group Awards not to exceed $20,000 for the group, provided that no individual employee in the group is granted more than $3,500.

    3. Managers’ Awards from $251 to $500. Managers may approve Manager Awards up to $250 without higher level management review or approval (subject to any management or financial coordination required by W&I).

    4. Bilingual Awards in the amounts permitted by IRS policy and applicable negotiated agreements.


09. **Delegated to:** Two supervisory levels above the employee(s) being recommended for the award.

10. **Redelegation:** This authority may not be redelegated.

11. **Authority 4:** To approve Quality Step Increases.

12. **Delegated to:** Senior Executive Service or Senior Executive Service-in-Waiting.

13. **Redelegation:** This authority may not be redelegated.

14. **Source of Authority:** Servicewide Delegation Order 6-22.

15. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

16. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.2.19** **(04-30-2024)**

#### Delegation Order TS 6-29-1, Address Employee Performance or Conduct Issues

01. **Address Employee Performance or Conduct Issues**

02. **Authority 1:** To effect non-disciplinary actions such as oral and written counseling.

03. **Delegated to:** The subject’s first-level supervisor.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority 2:** To effect non-disciplinary actions such as closed without action letters, clearance letters, and caution letters.

06. **Delegated to:** Supervisors within an employee’s supervisory chain at least two levels above the employee who is the subject of the action.

07. **Redelegation:** This authority may not be redelegated.

08. **Authority 3:** To propose suspensions of 14 calendar days or less.

09. **Delegated to:** Supervisors within an employee’s supervisory chain at least two levels above the employee who is the subject of the action.

10. **Redelegation:** This Authority may not be redelegated.

11. **Authority 4:** To effect suspension of 14 calendar days or less.

12. **Delegated to:** Supervisors within an employee’s Supervisory chain at least three levels above the employee who is the subject of the proposal. In no case may the proposing official and deciding official be the same person.

13. **Redelegation:** This authority may not be redelegated.

14. **Authority 5:** To propose performance-based actions, such a reduction in grade or pay, or removal, and adverse actions, such as suspensions of more than 14 calendar days, indefinite suspensions, furloughs of 30 calendar days or less, and removals.

15. **Delegated to:** Supervisors within an employee’s supervisory chain at least two levels above the employee who is the subject of the proposal.



    ### Exception:



    If the Deputy Chief is the subject’s second level supervisor, they may redelegate this authority to a similarly situated manager.

16. **Redelegation:** This authority may not be redelegated.

17. **Authority 6:** To effect performance-based actions, such as reductions in grade or pay, or removal, and adverse actions such as suspensions of more than 14 calendar days, indefinite suspensions, furloughs of 30 calendar days or less, and removals.

18. **Delegated to:** All executives to whom a subordinate manager has proposed an action; must be at least three (3) supervisory levels above the individual for whom the action is proposed. In no case may the proposing official and deciding official be the same person.

19. **Redelegation:** This authority may not be redelegated.

20. **Authority 7:** To effect non-disciplinary actions for positions covered by the Executive Misconduct Unit (EMU) - i.e., Executives (Senior Executive Services \[SES\]; Administratively Determined \[AD; includes Streamlined Critical Pay\]), Senior-Level (SL), Senior Managers (IR-01), Frontline Managers (IR-03), and GS-15 non-bargaining unit employees. Examples of non-disciplinary actions include oral/written counseling, closed without action letters, clearance letters, and caution letters.

21. **Delegated to:** The subject’s second-level supervisor.

22. **Redelegation:** This authority may not be redelegated.

23. **Authority 8:** To propose performance-based actions, disciplinary or adverse actions for positions covered by the EMU - i.e., Executives (SES; AD), Senior-Level (SL); Senior Managers (IR-01), Frontline Managers (IR-03) and GS-15 non-bargaining unit employees.

24. **Delegated to:** The subject’s second-level supervisor.

25. **Redelegation:** This authority may not be redelegated.

26. **Authority 9:** To effect performance-based, disciplinary, or adverse actions for positions covered by the EMU - i.e., Executives (SES; AD), Senior-Level (SL), Senior Managers (IR-01), Frontline Managers (IR-03) and GS-15 non-bargaining unit employees.

27. **Delegated to:** The subject’s third-level supervisor. However, in no case may the deciding official for these actions be redelegated below the Deputy Chief, Taxpayer Services for employees in their span of control.

28. **Redelegation:** This authority may not be redelegated.

29. **Source of Authority:** Servicewide Delegation Order 6-29.

30. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

31. Signed, Kenneth C. Corbin, Chief, Taxpayer Services.


**1.2.61.2.20** **(02-23-2005)**

#### Delegation Order WI 11-2-1, Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents

1. **Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents**

2. **Authority:** To disclose, under IRC 6103 (l)(4) returns or return information for use in personnel or claimant representative matters.

3. **Delegated to:** One management level above the supervisory level of the underlying action.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 11-2.

6. To the extent that authority previously exercised consistent with the order may require ratification, it is hereby affirmed and ratified.

7. Signed, Henry O. Lamar, Jr., Commissioner, Wage and Investment Division.


**1.2.61.3** **(09-27-2013)**

### Rescinded Taxpayer Services Business Unit Delegations of Authority

1. Taxpayer Services (TS) Rescinded Delegation Orders approved after this revision of the IRM can be found at: [https://www.irs.gov/uac/recently-approved-division-function-delegation-orders](http://www.irs.gov/uac/Recently-Approved-Division-Function-Delegation-Orders); all documents are maintained on the web site until the next IRM revision.


**1.2.61.3.1** **(07-25-2013)**

#### Delegation Order WI 4-37-1, Record Keeping Requirement

1. **Record Keeping Requirement**

2. This Division Delegation Order (DO) has been rescinded. Division DO WI 4-37-1, granted authority to require any person, by notice served them to keep records reflecting whether or not the person is liable for tax, to Field Assistance Group Managers and does not coincide with Servicewide DO 4-37, which grants the authority to Reporting Compliance Managers (Wage and Investment) and does not allow for redelegation. Therefore, Division DO WI 4-37-1 is no longer valid.

3. Signed, Peggy Bogadi, Commissioner, Wage and Investment Division.


**1.2.61.3.2** **(03-25-2013)**

#### Delegation Order WI 4-38-1, To Designate Qualified General Assistance Programs Described in IRC 51 (d) (6)

1. **To Designate Qualified General Assistance Programs Described in IRC 51 (d) (6)**

2. This Division Delegation Order (DO) is rescinded. The Servicewide source of authority, 4-38, To designate Qualified General Assistance Programs described in IRC 51 (d) (6) has been revoked.



> **Rationale:** The authority on which Servicewide Delegation Order 4-38 was founded, Section 51 (d) (6) of the Internal Revenue Code, no longer includes a provision for a General Assistance Program Determination. The organizations confirm that there are no longer any active cases related to the order; therefore, the Division delegation order is obsolete.

3. Signed, Peggy Bogadi, Commissioner, Wage and Investment Division.


**1.2.61.3.3** **(03-14-2017)**

#### Delegation Order WI 6-6-4 (formerly DO WI-81-4), To Initiate or Approve Personnel Actions (Form SF-50 and Form SF-52)

1. **To Initiate or Approve Personnel Actions (Form SF-50 and Form SF-52)**

2. This division delegation order (DO) has been rescinded. The DO WI 6-6-4 granted the following authorities:



1. All managers - the authority to initiate requests for personnel action (SF-52/TAPS) for employees under their jurisdiction to all managers.

2. Second level managers - the authority to approve/initiate requests for personnel action (SF-52/TAPS) for employees under their jurisdiction to second level managers.


The Servicewide (SW) source of authority, 6-6, Delegation of Authority in Various Personnel Matters (Updated 05-31-2000) to reflect additional new organizational titles required by IRS Modernization), was revoked and a portion of the information has been incorporated into new SW DO 6-24, Delegation of Authorities to Initiate and Approve Personnel Actions, signed August 9. 2016. The SW DO 6-24 grants authorities for the actions in DO WI 6-6-4 at levels appropriate for W&I. Therefore, WI DO 6-6-4 is no longer needed.



3. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.3.4** **(01-27-2015)**

#### Delegation Order WI 6-6-5, Approve Merit Promotion Selections

1. **Approve Merit Promotion Selections**

2. This Division Delegation Order (DO) has been rescinded. The source of authority, Servicewide (SW) DO 6-6, Delegation of Authority in Various Personnel Matters, does not grant authorities related to signing merit promotion certificates and approving selections.

3. Therefore, WI 6-6-5, Approve Merit Promotion Selections, is not valid and cannot use SE DO 6-6 as a source of authority.

4. Signed, Debra Holland, Commissioner, Wage and Investment Division.


**1.2.61.3.5** **(11-09-2015)**

#### Delegation Order WI 6-6-6, Authority to Approve Personnel Actions for Corrective Actions Including Retroactive Promotion and Retroactive Back Pay

1. **Authority to Approve Personnel Actions for Corrective Actions Including Retroactive Promotion and Retroactive Back Pay**

2. This division delegation order (DO) has been rescinded. Delegation Order WI DO 6-6-6 provided authority to approve actions for corrective actions for employees including retroactive promotions and retroactive back pay with documented approval to associate with the corresponding SF-52, Request for Personnel Action, and/or SF-50, Notification of Personnel Action. Servicewide DO 6-23, Delegations of Authority to Accomplish Pay Administration, signed February 23, 2015, is revised to include the provision for this action in Authority 13, with the authority delegated to HCO, Employment, Talent and Security Division, Employment Branch Chiefs for employees they service, with redelegation to Human Resource Specialists In the absence of these officials.

3. Servicewide DO 6-23, Delegation of Authority to Accomplish Pay Administration, grants authority at the appropriate level, therefore, WI DO 6-6-6 is no longer needed.

4. Signed, Debra Holland, Commissioner, Wage and Investment Division.


**1.2.61.3.6** **(03-04-2017)**

#### Delegation Order WI 6-12-1 (formerly DO WI-104-1), Absence and Charges to Leave

1. **Absence and Charges to Leave**

2. This division delegation order (DO) has been rescinded. The DO WI 6-12-1 granted the authority to approve leave including approval of the correction of administrative errors and determination that a period of sickness or injury interfered with the use of scheduled annual leave, charge absence without leave for unauthorized absences, and authorize brief absences from duty without charge to leave or loss of pay, for individual employees under their supervision and control in accordance with applicable statutes, executive orders, regulations and policies to all managers.

3. The Servicewide (SW) DO 6-12, Absence and Leave, revised April 29, 2016, combined the following absence and leave SW DOs for human resources management activities (IRM 1.2.45) into one SW DO:



   - SW DO 6-8, Human Resources Authorities Granted by the Treasury Human Capital Issuance System (HCIS), Law, and Regulation, in part, dated June 22, 2009

   - SW DO 6-12 (formerly DO-104 (Rev.14)), Absence and Charges to Leave, updated October 2, 2000, to reflect additional new organizational titles required by IRS Modernization

   - SW DO 6-15 (formerly DO-256), Leave Without Pay in Excess of One Year, updated October 2, 2000, to reflect additional new organizational titles required by IRS Modernization

   - SW DO 6-16 (formerly DO-257), Carryover of Annual Leave, updated October 2, 2000, to reflect additional new organizational titles required by IRS Modernization


4. The SW DO 6-12 grants authority at the appropriate level for W&I. Therefore, DO WI 6-12-1 is no longer needed.

5. Signed, Kenneth C. Corbin, Commissioner, Wage and Investment Division.


**1.2.61.3.7** **(11-09-2015)**

#### Delegation Order WI 6-14-1, Overtime

1. **Overtime**

2. This division delegation order (DO) has been rescinded. Delegation Order WI 6-14-1 provided authority to approve overtime to second level managers. Servicewide DO 6-23, Delegations of Authority to Accomplish Pay Administration, signed February 23, 2015, is revised to include this action in Authority 7, with the authority delegated to all second-level managers for employees under their jurisdiction with no further redelegation.

3. Servicewide DO 6-23, Delegations of Authority to Accomplish Pay Administration grants authority at the appropriate level, therefore, WI DO 6-14-1 is no longer needed.

4. Signed, Debra Holland, Commissioner, Wage and Investment Division.


**1.2.61.3.8** **(07-25-2013)**

#### Delegation Order WI 11-5-1, Seal of the Office of the Internal Revenue Service and Certification to the Authenticity of Official Documents

1. **Seal of the Office of the Internal Revenue Service and Certification to the Authenticity of Official Documents**

2. This Division Delegation Order (DO) has been rescinded. Division DO WI 11-5-1 granted the authority to affix the official seal of the Internal Revenue Service to any certificate or attestation required to be made in authentication of originals and copies of books, records, papers, writings and documents of the Internal Revenue Service in the custody of the Commissioner of Internal Revenue as described in paragraph (2) of Servicewide DO 11-5, to Accounting Operations Managers, Submission Processing and Operations Managers, Field Compliance Services. Division DO WI 11-5-1 does not coincide with Servicewide DO 11-5, which grants the authority to Field Directors, Submission Processing and Directors, Campus Compliance Operations, and the Servicewide DO does not allow the authority to be redelegated. Therefore, Division DO WI 11-5-1 is no longer valid.

3. Signed, Peggy Bogadi, Commissioner, Wage and Investment Division.


**1.2.61.3.9** **(07-01-2005)**

#### Delegation Order WI 23-1 (formerly DO 23-WI), Settlement of Tort Claims; Claims Under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damages to or Loss of Personal Property Incident to Service

1. **Settlement of Tort Claims; Claims Under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damages to or Loss of Personal Property Incident to Service**

2. This Division Delegation Order has been rescinded. The authority delegated to the employees identified in former Delegation Order 23-WI is superseded by Delegation Order 1-4 (formerly DO-23, Rev. 15). In accordance with this revised Delegation Order, authority for the Settlement of Tort Claims; Claims Under the Small Claims Act, and Claims Made by an Employee of the Internal Revenue Service for Damaged or Loss of Personal Property Incident to Service cannot be delegated lower than second level supervisors, GS-13 or above, and first level supervisors, GS-10 and above, and may not be redelegated.

3. Signed, Henry O. Lamar, Jr., Commissioner, Wage and Investment Division.


**1.2.61.3.10** **(07-25-2013)**

#### Delegation Order WI 25-2-1 (formerly DO WI 42-1), Authority to Execute Consents Fixing the Period of Limitations on Assessment or Collection under Provisions of the 1939, 1954, and 1986 Internal Revenue Codes

1. **Authority to Execute Consents Fixing the Period of Limitations on Assessment or Collection under Provisions of the 1939, 1954, and 1986 Internal Revenue Codes**

2. This Division Delegation Order (DO) has been rescinded. Division DO 25-2-1 granted the following authorities:



   - Execute Consents fixing the period of limitations on assessment or collection under provisions of the 1939, 1954 and 1986 Internal Revenue Codes

   - Sign all consents fixing the period of limitations on assessment or collection, pursuant to authority vested in the Commissioner of Internal Revenue


> Division DO WI 25-2-1 granted these authorities to "Group Manager" level, and does not coincide with Servicewide DO 25-2, which grants authority at the "Department Manager" level and does not allow the authority to be redelegated. Therefore, Division DO WI 25-2-1 is no longer Valid.

3. Signed, Peggy Bogadi, Commissioner, Wage and Investment Division.


**1.2.61.3.11** **(07-01-2005)**

#### Delegation Order WI 77-1 (formerly DO 77-WI), Issue or Execute Agreement to Rescind Notices of Deficiency

1. **Issue or Execute Agreement to Rescind Notices of Deficiency**

2. This Division Delegation Order (DO) has been rescinded. The authority delegated to employees identified in former Delegation Order 77-WI is superseded by Delegation Order 4-8 (formerly DO-77, Rev. 28). In accordance with this revised Delegation Order, authority to Issue or Execute Agreement to Rescind Notice of Deficiency cannot be delegated to Campus Directors or Territory Managers, and may not be redelegated.

3. Signed, Henry O. Lamar, Jr., Commissioner, Wage and Investment Division.


**1.2.61.3.12** **(07-01-2005)**

#### Delegation Order WI 189-1 (formerly DO 189-WI), To Authorize Travel Not at Government Expense

1. **To Authorize Travel Not at Government Expense**

2. This Division Delegation Order has been rescinded. The authority delegated to the employees identified in former Delegation Order 189-WI is superseded by Delegation Order 189 (subsequently renumbered; now Delegation Order 1-22). In accordance with this revised Delegation Order, authority to Authorize Travel Not at Government Expense cannot be delegated outside of the Chief Counsel function.

3. Signed, Henry O. Lamar, Jr., Commissioner, Wage and Investment Division.


**1.2.61.3.13** **(10-01-2009)**

#### Delegation Order WI 191-1 (formerly DO 191-WI), Levy on Property in the Hands of a Third Party (not to include Form 668-B)

1. **Levy on Property in the Hands of a Third Party (not to include Form 668-B)**

2. This Division Delegation Order has been rescinded. The Servicewide source of authority, Delegation Order 191, Levy on Property in the Hands of a Third Party, is superseded by Servicewide Delegation Order 5-3 with the same title. This delegation order grants the necessary authority to the lowest level eliminating the need for a Division Delegation Order.

3. Signed, Richard Byrd, Jr., Commissioner, Wage and Investment Division.


**1.2.61.3.14** **(10-01-2009)**

#### Delegation Order WI 192-1 (formerly DO 192-WI), Approve the Use of Cash to Purchase Official Passenger Transportation Services Exceeding $500

1. **Approve the Use of Cash to Purchase Official Passenger Transportation Services Exceeding $500**

2. This Division Delegation Order is rescinded. The authority delegated to Headquarters Second Level Managers and Territory Managers in WI 192-1 is superseded by Delegation Order 1-40 (formerly Delegation Order 192). In accordance with the new Delegation Order, approval of Non-Emergency and Emergency Common Carrier Purchases Over $100 cannot be redelegated below the level of the Deputy Commissioner, Wage and Investment.

3. Signed, Richard Byrd Jr., Commissioner, Wage and Investment Division.


**1.2.61.3.15** **(10-01-2009)**

#### Delegation Order WI 193-2 (formerly DO 193B), Authority in Personnel Matters and Budget Execution

1. **Authority in Personnel Matters and Budget Execution**

2. W&I Division Delegation Order WI 193-2 is rescinded. W&I Delegation Order WI-6-1-1 (formerly DO 6-1A), Authority to Create and Abolish Positions provides similar authority, therefore this delegation order is no longer needed. W&I Division Delegation Order WI 193-2 is therefore obsolete.

3. Signed, Richard Byrd, Jr., Commissioner, Wage and Investment Division.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-002-061#addtoany "Show all")

A2A