---
url: "https://www.irs.gov/irm/part1/irm_01-004-010"
title: "1.4.10 Return Integrity & Verification Operation Managers Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-010#main-content)

- 1.4.10  [Return Integrity & Verification Operation Managers Guide](https://www.irs.gov/irm/part1/irm_01-004-010#id1)
  - 1.4.10.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-010#id2)
    - 1.4.10.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-010#id4)
    - 1.4.10.1.2  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-010#id5)
    - 1.4.10.1.3  [Authority](https://www.irs.gov/irm/part1/irm_01-004-010#id6)
    - 1.4.10.1.4  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-010#id7)
    - 1.4.10.1.5  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-010#id8)
  - 1.4.10.2  [Operational Guidelines](https://www.irs.gov/irm/part1/irm_01-004-010#id9)
  - 1.4.10.3  [Operational Reviews Overview](https://www.irs.gov/irm/part1/irm_01-004-010#id10)
    - 1.4.10.3.1  [Operational Reviews](https://www.irs.gov/irm/part1/irm_01-004-010#id12)
  - 1.4.10.4  [Front Line Manager Responsibility](https://www.irs.gov/irm/part1/irm_01-004-010#id13)
  - 1.4.10.5  [Managerial Quality and Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-010#id14)
    - 1.4.10.5.1  [Certification of New Hire Employees](https://www.irs.gov/irm/part1/irm_01-004-010#id16)
    - 1.4.10.5.2  [Quality Assurance](https://www.irs.gov/irm/part1/irm_01-004-010#id17)
    - 1.4.10.5.3  [Workload Management / Efficiency Reviews](https://www.irs.gov/irm/part1/irm_01-004-010#id18)
    - 1.4.10.5.4  [Monitoring the Automated Age Listing (AAL)](https://www.irs.gov/irm/part1/irm_01-004-010#id19)
  - 1.4.10.6  [Employee and Building Security Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-010#id20)
  - 1.4.10.7  [Integrated Talent Management (ITM)](https://www.irs.gov/irm/part1/irm_01-004-010#id21)
  - 1.4.10.8  [Managing Seasonal Employees: Release and Recall](https://www.irs.gov/irm/part1/irm_01-004-010#id22)
  - 1.4.10.9  [Managing Employees with Disabilities](https://www.irs.gov/irm/part1/irm_01-004-010#id23)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 10. Return Integrity & Verification Operation Managers Guide

* * *

## 1.4.10 Return Integrity & Verification Operation Managers Guide

#### Manual Transmittal

August 08, 2025

#### Purpose

(1) This transmits a revision to IRM 1.4.10, Resource Guide for Managers, Return Integrity & Verification Operation Managers Guide.

#### Material Changes

(1) IRM 1.4.10.1.5(1) Removed EDI acronym and definition from the table per operational directive IPU 25U0205

(2) IRM 1.4.10.9(5) Removed EDI specific guidance per operational directive IPU 25U0205

(3) IRM 1.4.10.9(7) Removed link to IRM 1.1.13.2 Wage and Investment (W&I) Equity, Diversity & Inclusion (EDI) and Document 11953, EEO and Diversity Manager's Toolkit per operational directive IPU 25U0205

(4) IRM 1.4.10.9(8) Removed Equity, Diversity & Inclusion web link, per operational directive IPU 25U0205

(5) Editorial changes to adhere to plain writing guidelines, standards and organizational term updates with renumbering when applicable including a correction of Wage & Investment (W&I) to Taxpayer Services (TS) per BOD realignment IPU 25U0205

#### Effect on Other Documents

Revision supersedes IRM 1.4.10 dated October 1, 2024.

#### Audience

Managers in Return Integrity & Verification Operation

#### Effective Date

(10-01-2025)

Denise D. Davis

Director, Return Integrity Verification Program Management

Taxpayer Services

**1.4.10.1** **(09-07-2021)**

### Program Scope and Objectives

1. **Purpose:** To provide managers with techniques, methods, and guidelines for managing employees in the Return Integrity Verification Operation (RIVO). RIVO employees are responsible for fraud detection and prevention, revenue protection, and account correction.

2. Managers must be knowledgeable in the use of various tools/resources. Examples of these tools/resources include (list is not all inclusive):



   - Electronic Fraud Detection System (EFDS)

   - Selections and Analytics Platform (SNAP)

   - Account Management Services (AMS)

   - Integrated Data Retrieval System (IDRS)

   - Integrated Automation Technologies (IAT)

   - Service wide Electronic Research Program (SERP)


3. **Audience:** The primary users of this IRM are RIVO Managers.

4. **Policy Owner:** The policies are owned by the Director of Return Integrity Verification Program Management, (RIVPM).

5. **Program Owner:** RIVO is the program office responsible for oversight over this program.

6. The Human Capital Office (HCO) provides managerial tools and information via a page on its website titled,"New Manager Orientation Support Center" which is found at: http://hco.web.irs.gov/apps/leads/nmo.html. Examples of the tools found on this resource page include:



   - Management 101 ("New Manager Orientation Tutorial" , "Ten Tips for New Managers" , etc.)

   - Orientation Resources ("My Guide - Leadership Development Guide" , etc.)

   - Performance Management ("Critical Job Elements (CJEs)" , "National Agreement Resource Center" , etc.)

   - Group Controls ("Managing Leave" , "Tours of Duty" , etc.)

   - Time & Attendance Guidance

   - Leadership Development ("Leadership Curriculum and Competencies" , etc.)

   - Systems Help for Managers ("Integrated Talent Management (ITM)" , "Single Entry Time Reporting (SETR)" , "Concur" , "Human Resources (HR) Connect" , etc.)


7. A resourceful managerial tool is iManage. It is a virtual community for Internal Revenue Service (IRS) managers. It contains targeted information, advice and interactive features to help the manager in working more efficiently. The iManage site automatically grants access to employees coded as managers in HRConnect. Access the iManage site at https://irsgov.sharepoint.com/sites/iManage.


**1.4.10.1.1** **(09-04-2020)**

#### Background

1. Return Integrity Verification Operation (RIVO) strengthens the integrity of the tax system by:



   - Protecting the public interest by improving IRS’s ability to detect and prevent improper refunds

   - Serving the public interest by taking actions fairly and correctly to identify, evaluate and prevent the issuance of improper refunds

   - Helping taxpayers understand the refundable tax credits for which they are eligible.

   - Recover Improper Payments


**1.4.10.1.2** **(06-22-2017)**

#### Program Management and Review

1. The program has reports to track the inventory, including receipts and closures.

2. A quality program is in place to review all processes to ensure accuracy and effectiveness.


**1.4.10.1.3** **(09-07-2021)**

#### Authority

1. Refer to the following:



   - IRM 1.2.1, Service wide Policies and Authorities, Service wide Policy Statements

   - IRM 1.1.13, Organization and Staffing, Taxpayer Services.


**1.4.10.1.4** **(09-07-2021)**

#### Responsibilities

1. Return Integrity Verification Operation (RIVO) has responsibility for information in this IRM. Information is published in the IRM on a yearly basis.

2. The Director of RIVPM is responsible for the policy related to this IRM.

3. The Chief of the Return Integrity Verification Program Management (RIVPM) is responsible for ensuring this IRM is timely submitted to publishing each year.

4. More information can be found in IRM 1.1.13.7, Customer Account Services (CAS).


**1.4.10.1.5** **(02-11-2025)**

#### Acronyms

1. The acronyms listed below are used throughout Return Integrity Verification Operation (RIVO) Management Guide:




| _Acronym_ | _Definition_ |
| --- | --- |
| AAL | Automated Age List |
| AMC | Alternative Media Center |
| AMS | Accounts Management Service |
| BMF | Business Master File |
| BU | Bargaining Unit |
| CAC | Chief Accessibility Coordinator |
| CAS | Customer Account Services |
| CCA | Case Control Activity |
| CER | Centralized Evaluative Review |
| CJE | Critical Job Element |
| CPE | Continuing Professional Education |
| DCI | Data Collection Instrument |
| DM | District Manager |
|  |  |
| EEO | Equal Employment Opportunity |
| EFDS | Electronic Fraud Detection System |
| EPF | Employee Performance File |
| EOD | Enter on Duty |
| EQ | Embedded Quality |
| EQRS | Embedded Quality Review System |
| HCO | Human Capital Office |
| HR | Human Resources |
| IAT | Integrated Automation Technologies |
| ICAN | IRS Center for Accessibility Needs |
| IDO | IRS Disability Office |
| IDRS | Integrated Data Retrieval System |
| IDT | Identity Theft |
| IORS | IDRS Online Reports Services |
| IPU | SERP IRM Procedural Update |
| IRAP | Information Resource Accessibility Program |
| IRM | Internal Revenue Manual |
| ITM | Integrated Talent Management |
| JAN | Job Accommodation Network |
| LAC | Local Accessibility Coordinator |
| NQRS | National Quality Review System |
| NTEU | National Treasury Employees Union |
| OAR | Operation Assistance Request |
| OFP | Organization, Function and Program |
| OJT | On-the-Job Training |
| OM | Operation Manager |
| RA | Reasonable Accommodation |
| RICS | Return Integrity & Compliance Services |
| RIVO | Return Integrity Verification Operation |
| RIVPM | Return Integrity Verification Program Management |
| SERP | Servicewide Electronic Research Program |
| SETR | Single Entry Time Reporting |
| SNAP | Selections aNd Analytics Platform |
| SPRG | Specialized Product Review Group |
| TE | Tax Examiner |


**1.4.10.2** **(09-04-2020)**

### Operational Guidelines

1. Return Integrity & Verification Operation (RIVO) managers are accountable for:



   - Ensuring controls are in place to prevent the unauthorized disclosure of taxpayer documents and information

   - Facilitating the delivery of their team's performance, as related to program goals

   - Listening to and formally and informally resolving employees' concerns

   - Sharing continuous performance feedback with employees

   - Leading, mentoring and coaching subordinate employees

   - Identifying potential process improvements

   - Ensuring best practices are properly documented (e.g., IRM, SERP IRM Procedural Update (IPU), training documents) and shared with RIVO and Return Integrity and Compliance Services (RICS) Headquarters

   - Ensuring proper training is delivered to subordinate employees

   - Personally participating in technical training classes with employees

   - Ensuring the maintenance of a safe and healthy work environment

   - Communicating issues and concerns to leadership, peers and subordinates, as applicable.

   - Performing conduct and/or leave counseling

   - Developing and supporting a positive relationship with National Treasury Employees Union (NTEU) organization

   - Applying staffing resources to meet all responsibilities and deliver all inventory products within proper time frames.

   - Delivering quality customer service

   - Coordinating with other managers to address programs and inventory issues, as needed, to effectively deliver program responsibilities

   - Providing timely and accurate resolution of inventory cases


2. Managers must ensure read and meet time is met per the guidance below:



1. Schedule read and meeting time for your team each week.



      > Read time is generally spent on reading SERP IPUs, SERP Alerts, technical meeting notes, administrative information or as directed by management.





      > Meeting time is usually 30 minutes per week with an extra 30 minutes, if needed. This time is generally spent clarifying IRM procedures, supplemental training or administrative information.

2. Ensure the correct organization, function and program (OFP) codes are used on Form 3081, Employee Time Report, and SETR with the actual times used. See below:


       990-59221 – Read time


       990-59222 – Technical Meeting time


       990-59300 – Administrative Meeting time


**1.4.10.3** **(06-22-2022)**

### Operational Reviews Overview

1. An Operational review is an in-depth review and analysis of a particular program or function.

2. Operational reviews are conducted by Return Integrity Verification Operation (RIVO) Planning and Analysis.

3. Follow guidance in the 2022 National Agreement between the IRS and the National Treasury Employees Union (NTEU) about the rating of work.


**1.4.10.3.1** **(10-01-2019)**

#### Operational Reviews

01. The operational reviews must:



    - Evaluate and assess

    - Identify areas to improve

    - Establish target dates for improvement

    - Identify and praise accomplishments

    - Provide a follow-up on action items


02. The review should address the following:



    - Workload management practices

    - Personnel management practices

    - Administrative practices


03. Compare the above practices to the following:



    - Mission statement

    - Policies and regulations

    - 2022 National Agreement

    - Interim Guidance Memorandums

    - Memorandum of Understanding (MOUs)

    - Business measures and goals


04. Prepare a schedule of planned reviews at the beginning of each fiscal year and no later than November 1st. Schedule reviews to ensure that all teams, including expansion teams, are addressed. Provide the operations manager and/or director a copy of the review schedule.

05. Request the information needed from the manager in advance, generally 30 days. This will ensure all information is available at the start of the review. This may include the following items:



    - Employee performance file (EPF)

    - Personnel files

    - Drop files (including meeting minutes)

    - Training files (access employee Integrated Talent Management (ITM) reports)

    - AMS data

    - Local inventory reports

    - Automated Age Listing (AAL)

    - Sample of closed cases and open cases

    - Leave tracking

    - Evaluation/Midyear sample pulls and tracking records

    - Engagement Plans/Activities

    - Quality/Productivity/Improvement Initiatives

    - Managerial Controls Tracking


06. It is recommended when EPFs are reviewed, include a work leader, one team clerk/secretary (if one is assigned) and tax examiners (TEs), or another applicable team employee. Try to review EPFs of employees with different levels of experience.

07. EPF review should cover the following:



    1. Personnel management practices

    2. Workload management practices

    3. Administrative, security, and safety practices

    4. Manager's organization


08. Review personnel management practices of keeping EPFs, drop files, and personal/training files for the following:




    | **Department Review** | **Operation Review** |
    | :-: | :-: |
    | Critical Job Elements (CJEs) | Form 12450-A, Manager Performance Agreement |
    | Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard (must be issued to employees within 30 days of the beginning of the performance period.) | Training operation reviews |
    | Seasonal agreements (if applicable) (annually) | Evaluations (annually) |
    | Training, on-the-job training (OJT) and certification documentation | Poor performance |
    | Evaluative reviews, including content, scope and amounts (monthly employee reviews) | Non-evaluative reviews and coaching |
    | Mid-year progress reviews (from Front line manager) (annually) | Position management |
    | Appraisals (annually) | Front line manager / employee development |
    | Poor performance | Communication including team meetings notes |
    | Awards | Section 1204 quarterly certification |
    | Non-evaluative reviews and coaching | Managerial control tracking |
    | Position management | IDRS Online Reports Services (IORS) |
    | Leave administration |  |
    | Employee development |  |
    | Communication including team meetings notes |  |

09. Review administrative, privacy, security, and safety practices, including the following:



    - Time reporting

    - Mandatory briefings

    - Release/Recall correctly updated

    - Annual Assurance and Security reviews

    - Section 1204 quarterly certification


10. Review manager's organization effectiveness:



    - Timeliness of controlled responses

    - Effectiveness of method for managing tasks or assignments, completeness, thoroughness, timeliness of reviews, projects, etc.


11. Allow sufficient time for performing the review, writing the report, and providing feedback from the final report to the manager or director.



    ### Note:



    The feedback should follow the critical elements (i.e., Leadership, Employee Satisfaction, Customer Satisfaction, Business Results) and specify items reviewed. It should also follow the responsibilities outlined in the managerial performance plans (Leadership & Human Capital Management; Customer Service & Collaboration; and Program Management).

12. Promptly document the operation review in a memorandum to the Manager or Department Head. Include the following in the memorandum:



    1. Summary of the observations (positive and negative)

    2. Recommendations and action items

    3. Follow-up dates



       ### Note:



       Follow-up timely with the manager on action items and document all follow-up actions.


**1.4.10.4** **(06-12-2023)**

### Front Line Manager Responsibility

1. Front line managers must attend the entire Continuing Professional Education (CPE) training with their employees in order to actively participate with employees in addressing quality issues.

2. Managers will use EFDS, the Selections aNd Analytics Platform (SNAP) queries, and other management designated processes to move inventory through the system(s) and workflow. Queries will be consistent between sites for like work products and will be run periodically (daily, weekly, monthly, or ad hoc), as directed by management. Queries will be run to identify and resolve inventory discrepancies.

3. Managers will be responsible for monitoring and tracking inventory at the site, group and individual levels, as directed by management. Specific EFDS and SNAP queries and other management designated processes i.e., IDRS Case Control Activity (CCA) reports will be used for these tasks. Queries will be consistent between sites for like work products and will be run periodically, as directed by management.

4. Proper workload management is essential for timely responses to customers and prompt and accurate account transactions. Due to the variety and complexity of work, managers must be familiar with the many aspects of managing workloads such as:



   - Immediate supervisor, acting immediate supervisor, or designated higher level official must timely approve and sign Form 8278, Assessment and Abatement of Miscellaneous Civil Penalties, prior to the assessment of the IRC 6702 penalty.

   - Establishing controls and priorities

   - Conducting Reviews

   - Processing work within established time frames

   - Providing adequate training

   - Being involved in the daily operations of the unit

   - Managing time effectively

   - Using available reports and management tools to monitor the team’s productivity

   - Monitoring and closing necessary case controls

   - Transferring cases correctly

   - Analyzing data correctly and making correct decisions

   - Working cases according to aged order or other priorities as established by management directives


**1.4.10.5** **(06-22-2022)**

### Managerial Quality and Workload Reviews

1. Managers will be responsible for documented monitoring as part of the evaluation process. The 2022 National Agreement governs such recordings. When completing reviews, ensure they are:



   - Conducted according to department or other requirements

   - Completed by a manager, an individual in an official acting manager capacity, or a Centralized Evaluative Review (CER) quality reviewer

   - Input to the Embedded Quality Review System (EQRS) using the approved Data Collection Instrument (DCI) for each applicable Specialized Product Review Group (SPRG)

   - Shared in a timely manner as required by the 2022 National Agreement found at http://core.publish.no.irs.gov/docs/pdf/d11678--2021-10-00.pdf



     ### Note:



     Supplemental evaluative reviews may be performed by technical leads using the EQRS system; however, like all evaluative information, managers must share the review. The lead must sign the document as the reviewer and the manager must sign prior to sharing the review.


2. Managers will use EFDS, SNAP queries, IDRS, CCA reports, Accounts Management Services (AMS), and other management designated processes to complete and document individual employee performance reviews on front line work products. All management reviews must be documented in writing, shared with the employee in a timely manner, and keep in the EPF.

3. RIVO Managers must complete a minimum of two (2) evaluative quality reviews each month for each employee. Managers are responsible for communicating expectations and evaluating employee performance relative to their critical elements. Reviews are performed to ensure:



   - Accurate resolution of inventory cases

   - An objective assessment of an employee's performance on an ongoing basis

   - Adequate information is available for mid-year and annual appraisals

   - The rights of taxpayers are protected

   - Training needs are identified


4. Managers will document the results of the review. The documentation must include IRM references, impact to taxpayers, and both positive and negative feedback about the employee's performance.

5. Managerial review is performed to help employees with identified quality concerns in their work processes and products.



   - Managers will perform extra reviews on employees who have received errors and/or issues with their processes and work products to determine areas for improvement.

   - Managers will review more work samples, as needed, to analyze problem areas and improvement opportunities.

   - The extra reviews will be documented as required.

   - Employees, whose performance is substandard, will be placed on a performance plan.


6. Sharing results is a two-way communication. After sharing the review, managers must determine if the employee agrees with their assessment. Share review results as soon as possible (follow 2022 National Agreement). Notate the reason on the review sheet if the time frame was not meet (e.g., due to unexpected leave, etc.).



   - If the employee agrees - Commend the positive performance or discuss areas for improvement.

   - If employee disagrees - Discuss openly to resolve the disputed issue. Discuss areas for improvement and develop plan to improve performance.


7. Obtain the employee's acknowledgement on the review form. Provide one copy to the employee and keep the other copy for the EPF. Sanitize all employee data containing a social security number or name on the documents.



### Note:



Determine if more monitoring/review is necessary based on the employees training, ongoing performance, and review feedback.

8. If reviews cannot be conducted on an employee (e.g., extended illness, furlough, managerial absence, etc.) a review waiver is placed in the EPF explaining why the required number of reviews were not conducted.



### Note:



These waivers must be approved at the department level

9. Follow guidance in the 2022 National Agreement about the review of work and evaluating employees.


**1.4.10.5.1** **(10-01-2014)**

#### Certification of New Hire Employees

1. Perform 100 percent review of an employee's work product(s) until they meet established accuracy expectations. The 100 percent review will be non-evaluative. The employee will be certified once they reach an acceptable level of performance as outlined in the Return Integrity Verification Operation’s established certification requirements.

2. Once the new hire employee has been certified on a process (i.e., screening, verification, etc.) evaluative reviews should be conducted. If employee does not perform an acceptable, you may reinstate the 100 percent review (managerial review) to help the employee in improving performance.

3. The manager is responsible for documenting the certification in the EPF.


**1.4.10.5.2** **(09-28-2016)**

#### Quality Assurance

1. Quality measurements are used to evaluate performance. The Quality Review process provides a method to monitor, measure, and improve the quality of work in the Return Integrity & Compliance Services, Return Integrity Verification Operations (RICS RIVO). RICS RIVO uses the Embedded Quality Review System (EQRS) and National Quality Review System (NQRS) to monitor employee and operational performance. It helps in building commitment and capability to continually improve performance. IRM 21.10, Quality Assurance, provides guidance about the Quality Assurance processes.


**1.4.10.5.3** **(04-23-2021)**

#### Workload Management / Efficiency Reviews

1. Managers will be responsible for ensuring that individual employees within their group timely and accurately resolve the inventory that they work.

2. Critical Job Element (CJE) 5, Business Results - Efficiency, provides the performance expectations for Timeliness, Time Utilization and Workload Management. This involves the following:



   - Inventory time is correctly used to work cases

   - Casework is completed in an efficient manner

   - Inventory is properly managed


3. Managers will conduct a quarterly Workload Management/Efficiency review to evaluate employees when they are assigned to work paper inventory programs. This review will evaluate employee performance as it relates to Time Utilization, Timeliness and Workload Management. Paper inventory includes:



   - RIVO Accounts Resolution

   - RIVO BMF IDT

   - RIVO Identification

   - RIVO Screening and Verification


4. The quarterly review will include the time or period the employee was assigned to work inventory programs. This review can be performed by directly observing the employee (side by side) or reconstructing the actions taken by the employee during the defined period. Typically, this would be a block of time measured by specific time reported to work the program being reviewed based on managerial directive.



   - Open Cases - including overage cases, uncontrolled cases, open controls, and suspense cases

   - Closed Cases/Completed Cases


### Note:

All reviews _MUST_ be documented.

5. Conducting the review using the side-by-side approach (as directed above), will allow the manager to complete the reviews timely and improve the quality of the feedback.

6. Inventory reviews will be documented by completing the Data Collection Instrument (DCI) on the EQ system. The EQ system update enables the multi-case review process. Workload Management/Efficiency Reviews can now be completed using the EQ system for all Paper SPRGs. Job Aid and instructions are located on the EQRS/NQRS Campus SharePoint Support Site at https://irsgov.sharepoint.com/sites/eqrsc-support.

7. Workload Management/Efficiency reviews determine if an employee is:



   - Completing casework in an efficient manner (time spent commensurate with complexity and training level)

   - Properly managing their inventory

   - Following procedural guidelines

   - Completing efficient research

   - Accessing available electronic research tools

   - Using applicable IDRS Accessory Manager Tools, i.e., IAT, EFDS, etc.

   - Transferring cases correctly

   - Monitoring and closing necessary case controls

   - Transcribing pertinent data accurately

   - Analyzing data correctly

   - Making correct decisions

   - Initiating timely and effective follow up actions including updating EFDS, AMS and IDRS

   - Working cases according to aged order or other priorities as established by management directives

   - Reporting time accurately using the proper Organization Function Program (OFP) codes for working paper inventory programs


**1.4.10.5.4** **(04-23-2021)**

#### Monitoring the Automated Age Listing (AAL)

01. To ensure work is resolved timely and inventory reports reflect the correct data, download the Case Control Activity (CCA) 4243, IDRS Overage Report, and CCA 4244, IDRS Multiple Case control Report, from Control-D Web Access (CTDWA). These reports are downloaded _weekly_ to an Excel file, which becomes the Automated Age Listing (AAL).

02. The AAL allows the Inventory Control Manager (ICM), Planning and Analysis (P&A) analysts, and management to sort assigned cases by relevant criteria (e.g., age, category, last action date) to identify and prioritize workable overage cases or cases requiring follow-up actions.

03. RIVO Managers _must monitor_ overage inventory for their assigned teams using the AAL and share feedback with each employee weekly to ensure the employee is working inventory in accordance with established guidelines.

04. Managers of all teams with inventory will use the AAL to perform weekly reviews of employee’s assigned cases to ensure employees are closing cases according to established program priority. Inventory should include:



    1. Adjustments

    2. Statutes

    3. Unpostables

    4. Operation Assistance Requests (OARs)

    5. Identity Theft


05. Managers of teams with uncontrolled inventory must perform reviews of employee’s work (desk reviews) to ensure established priorities are followed.

06. Age list reviews are performed for the following reasons:



    1. Identify specific cases for review

    2. Monitor the volume of the employee’s inventory

    3. Set overage closure expectations

    4. Identify potential problem cases


07. Some important items to watch in any age list review include:



    1. Cases over the aging criteria

    2. Incorrect activity code

    3. Expired purge/action dates

    4. Excessive time elapsed since last action

    5. Expired Statute

    6. Incorrect suspense cases


08. There are several methods available to conduct an age list review. Two methods are shown below.



    1. Print the entire list for each employee and use color-coded high-lighters or other notations to point out priority issues on the hard copy.

    2. Use the AAL filters to reduce the overall list and display only priority cases. Add emphasis with color-coded cell highlights within Excel. If the data is stored on a shared drive, ensure PII information is protected in compliance with Data Security requirements. Share each employee’s list with an added column for follow-up comments. Print the reduced list if sharing files is difficult.


09. The AAL review is a required management review and **must** be documented and filed in the employee’s EPF per IRM 6.430.2.3.5, Employee Performance File.

10. ITM Course 34765, Inventory Management for AM Managers, includes guidance about the AAL and other inventory management topics.


**1.4.10.6** **(10-01-2014)**

### Employee and Building Security Responsibilities

1. You must use the standard emergency closing procedures, as provided for all sites, for weather and other emergency situations, such as threats.

2. RIVO employees should follow threat and other emergency procedures outlined in IRM 21.1.3.10, Safety and Security Overview and on the Emergency website.

3. You must ensure employees follow the procedures for threats received on the telephone (e.g., bomb threats, suicide threats, or other threats). Emergency procedures are outlined in:



   - IRM 21.1.3.10.3, Assault/Threat Incidents/Abusive Practitioners

   - IRM 21.1.3.10.7, Bomb Threats

   - IRM 21.1.3.12, Suicide Threats


4. In addition to the procedures above, you must reserve at least one voice port on your phone for emergencies. Also, you must obtain the following information for tracing the call:



   - Name of employee

   - Time received

   - Length of call


5. For applicable safety/security incidents, you will contact the Treasury Inspector General for Tax Administration (TIGTA) and Security. See the Threat/Assault Reporting on the Employee Resource Center (ERC) web page.


**1.4.10.7** **(09-04-2020)**

### Integrated Talent Management (ITM)

1. The Integrated Talent Management (ITM) is an automated training system found at: https://irssource.web.irs.gov/Pages/ITM.aspx. The ITM is comprised of five modules: Learning, Performance, Workforce Planning, Succession Planning and Compensation. It allows the employee and manager to be directly engaged in planning, communicating, and coordinating training and development activities online.

2. As a manager, you can monitor and view your employees' ITM items and curricula. The alignment of your employees shown in ITM is based on information provided weekly by HR Connect into ITM. A Personnel Action Request (PAR) aligns employees under you as their manager.



### Note:



The accuracy of this information is important because ITM sends a system-generated e-mail to your employee and you, as the manager, about scheduled training for the employee.

3. You can access helpful job aids for managers and employees on the ITM website. A User Support link provides job aids for Administrator, Manager and User.


**1.4.10.8** **(06-12-2023)**

### Managing Seasonal Employees: Release and Recall

1. Seasonal employees work during high workload volume periods as specified in their seasonal employment agreement each year. Form 8506, Seasonal Employment Agreement, must be signed annually by each seasonal employee and manager.

2. The Form 8506 is filed in the employee's Employee Drop File within the first week of employment or return to duty. The seasonal agreement outlines the stated work season for the employee and the season must be specific on the agreement, including the specific months the seasonal employee will work. See also Human Capital Office Seasonal Employment website at http://hco.web.irs.gov/recruitstaff/internalplac/employprog/seasemploy/.

3. Seasonal Probationary periods are defined as one calendar year (12 months) beginning with the seasonal employee’s enter on duty (EOD). This is regardless of the amount of time worked during the 12-month period.

4. Newly Hired Seasonal employees cannot be held accountable for their performance under their critical job elements (CJE) until on their performance plan for 60 days. Managers must provide all new hires their Performance Plans and CJE document as early as possible but not later than 30 days of beginning of an employee’s appraisal period or when assigned to a new position that is expected to last at least 60 days (e.g., temporary promotions, detail).



1. A Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard, must be signed by the manager, shared with and signed by the employee within 30 days of starting the position.

2. Provide employee a signed copy of the Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard.

3. When providing performance feedback to newly hired employees, during the first or second feedback sessions, discuss CJEs in detail to ensure the employees' understanding.


5. Seasonal employees are subject to being periodically released from and recalled to work. All employees subject to release recall are ranked on a Release/Recall List and either released or recalled based on their position on this list. The actual determination of the release/recall roster will be made by the type of appointment, IRS enter on duty date (EOD), employee performance, and the employee possessing the skills needed.

6. Managers should check SETR to make sure returning seasonal employees have time posted and should also remind returning seasonal employees to make sure their direct deposit information is still current. If not, changes should be made as soon as possible to ensure employees receive their pay timely.

7. Managers should track/monitor promotions (salary grade increases) for seasonal employees to ensure promotions are processed timely.

8. Prepare appraisals using Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request. Refer to the 2022 National Agreement for information on resolving tie scores and for specific details about the release/recall process.

9. Release/Recall must be accomplished in accordance with the 2022 National Agreement II, Article 14, Release/Recall Procedures, found at: http://core.publish.no.irs.gov/docs/pdf/d11678--2021-10-00.pdf.


**1.4.10.9** **(02-11-2025)**

### Managing Employees with Disabilities

1. Managers must ensure the employees with disabilities are equipped with the tools and accommodations to perform their jobs. There are procedures in place to help in accomplishing this task.

2. If an employee with a disability needs an accommodation, contact the Reasonable Accommodation (RA) Coordinator in your area for support

3. Information about reasonable accommodations can be found on the Reasonable Accommodation website under the Reasonable Accommodations Process link at: https://irssource.web.irs.gov/Lists/Accessibility/DispItemForm.aspx?ID=13.

4. In addition, the employee may need help with accessibility-type issues, such as ordering reference or training materials in alternative media. The Local Accessibility Coordinator (LAC) serves as the main point of contact to help managers and employees with disabilities in the day-to-day accessibility issues. The Local Accessibility Coordinators report to the Chief Accessibility Coordinator.

5. The Office of the Chief Accessibility Coordinator (CAC) was established to help management with inquiries concerning accessibility, i.e., adaptive equipment/software compatibility and usability issues; reasonable accommodation concerns; and performance issues for disabled employees, etc., to name a few. The CAC has program oversight for: the Lions World Services for the Blind (LWSB) and the LAC program. The CAC works in close partnership with Reasonable Accommodation (RA) Coordinators, IRS Disability Office (IDO), IRS Center for Accessibility Needs (iCAN), Alternative Media Center (AMC), and Information Resources Accessibility Program (IRAP).

6. Course 33788, Managing Employees with Disabilities, is available to all managers and LACs through the Integrated Talent Management (ITM) program. This course offers a comprehensive overview of the various facets involved in supervising employees with disabilities such as disability etiquette guidelines, the reasonable accommodation process, hiring, and various resources available to all IRS managers. For more information, visit the Accessibility Office website at: https://irssource.web.irs.gov/SitePages/Accessibility.aspx.

7. Other useful resources on managing employees with disabilities include:



   - IRM 1.4.1, Management Roles and Responsibilities

   - IRM 6.410.1, Learning and Education Policy


8. In addition, the following websites provide useful information on managing employees with disabilities:



   - Information Resource Accessibility Program (IRAP) Office: https://irsgov.sharepoint.com/sites/508site.

   - Alternative Media Center (AMC): http://amc.enterprise.irs.gov/

   - Job Accommodation Network (JAN): [http://www.jan.wvu.edu/](http://www.jan.wvu.edu/%20)

   - National Treasury Employee Union (NTEU): http://core.publish.no.irs.gov/docs/pdf/d11678--2021-10-00.pdf


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-010#addtoany "Show all")

A2A