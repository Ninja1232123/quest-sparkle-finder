---
url: "https://www.irs.gov/irm/part1/irm_01-004-028"
title: "1.4.28 Appeals Managers Procedures | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-028#main-content)

- 1.4.28  [Appeals Managers Procedures](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332017472)
  - 1.4.28.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332346288)
    - 1.4.28.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331507520)
    - 1.4.28.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331142352)
    - 1.4.28.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331303520)
    - 1.4.28.1.4  [Program Reports](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331390288)
    - 1.4.28.1.5  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332075424)
    - 1.4.28.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331668704)
  - 1.4.28.2  [Appeals' Mission, Organizational Structure, Vision and Core Values](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331091760)
  - 1.4.28.3  [Guidelines for Management Engagement (GME)](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331707568)
    - 1.4.28.3.1  [GME Concept - Compliance with Program Objectives and Policies](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331159280)
      - 1.4.28.3.1.1  [GME Concept - Inquiry Procedures](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331446512)
        - 1.4.28.3.1.1.1  [GME Concept - Policy and Guidance](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331611600)
  - 1.4.28.4  [Assignment and Control of Work](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331606576)
    - 1.4.28.4.1  [Assignment of Work Units and Initial Case Actions](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331603504)
      - 1.4.28.4.1.1  [Considerations for Assignment of Work Units](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332322496)
    - 1.4.28.4.2  [Control of Work](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332305664)
      - 1.4.28.4.2.1  [Inventory and Unit Time Report](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332300640)
      - 1.4.28.4.2.2  [Case Summary Cards](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332294352)
      - 1.4.28.4.2.3  [Case Activity Record and Automated Timekeeping System](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332117104)
    - 1.4.28.4.3  [ACDS Manager Proxy](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010332114560)
  - 1.4.28.5  [Appeals Team Manager Duties and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333194256)
    - 1.4.28.5.1  [Right of Consultation](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333185232)
    - 1.4.28.5.2  [Restricted Contact with Taxpayer](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333181216)
    - 1.4.28.5.3  [Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333175808)
    - 1.4.28.5.4  [Workload Review Preparation](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331554320)
    - 1.4.28.5.5  [Live Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331545184)
    - 1.4.28.5.6  [AARS ATM Priority Review](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331524976)
  - 1.4.28.6  [Conference Observation](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331069424)
    - 1.4.28.6.1  [AARS ATM Live Call Review](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331061520)
  - 1.4.28.7  [Overall Control of Work](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331052064)
  - 1.4.28.8  [Case Work Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331043568)
    - 1.4.28.8.1  [Extent of Case Work Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010331035120)
    - 1.4.28.8.2  [Closed Case Work Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333162640)
    - 1.4.28.8.3  [AARS ATM Closed Case Review](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333154384)
    - 1.4.28.8.4  [Correspondence Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333146800)
    - 1.4.28.8.5  [Work of Tax Computation Specialists (TCS)](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333143008)
      - 1.4.28.8.5.1  [Case Reviews of Tax Computation Specialists](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333137072)
    - 1.4.28.8.6  [Shared Team of Administrative & Redaction Support (STARS)](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333119584)
  - 1.4.28.9  [Guidelines for Determining the Grade Levels of Appeals Work Units](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333114752)
    - 1.4.28.9.1  [Relationship of These Guidelines to Position Management](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333105488)
  - 1.4.28.10  [Referrals to Appeals Technical Guidance, International Operations, and TEGE](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333095648)
  - 1.4.28.11  [Direct Shipment of Cases to Account and Processing Support](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333074576)
  - 1.4.28.12  [Timely Processing of Remittances](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333040416)
  - 1.4.28.13  [APS Processing Team Manager Duties and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010333035968)
    - 1.4.28.13.1  [Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330181648)
    - 1.4.28.13.2  [Workload Review Preparation](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330102480)
    - 1.4.28.13.3  [Live Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330084128)
    - 1.4.28.13.4  [Closed Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330072512)
    - 1.4.28.13.5  [APS Inventory and Time Management Tools](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330058144)
      - 1.4.28.13.5.1  [Appeals Centralized Database System (ACDS) Reports](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330056336)
      - 1.4.28.13.5.2  [Processing Employee Automated System (PEAS) Reports](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330052672)
      - 1.4.28.13.5.3  [PEAS Case Activity Records (CAR)](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330043296)
  - Exhibit  1.4.28-1  [Case Grading Factors to Consider for Examination Sourced Cases](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330037024)
  - Exhibit  1.4.28-2  [Upgrading Examination Sourced Cases - Considerations](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010330013632)
  - Exhibit  1.4.28-3  [Downgrading Examination Sourced Cases - Considerations](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010329913456)
  - Exhibit  1.4.28-4  [Case Grading Matrix for Collection Sourced Cases](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010329890896)
  - Exhibit  1.4.28-5  [Case Grading Matrix for Art Appraisal Services Cases](https://www.irs.gov/irm/part1/irm_01-004-028#idm140010329646496)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 28. Appeals Managers Procedures

* * *

## 1.4.28 Appeals Managers Procedures

#### Manual Transmittal

December 12, 2024

#### Purpose

(1) This revises IRM 1.4.28, Organization, Finance, and Management, Resource Guide for Managers, Appeals Managers Procedures.

#### Material Changes

(1) In _IRM 1.4.28.1_, Program Scope and Objectives, changed Appeals’ policy owner title from "Director, Case and Operations Support" to "Director, Operations Support"

(2) In _IRM 1.4.28.1.1_ , Background, revised the first sentence for consistency with similar language in IRM 8.1.1.1.1, Appeals Function, Background.

(3) Revised _IRM 1.4.28.1.3_, Responsibilities, to separately identify responsibilities of the "Director, Case Support" and the "Director, Operations Support," instead of the "Director, Case and Operations Support."

(4) Revised _IRM 1.4.28.1.5_, Terms and Acronyms, to add additional terms and acronyms.

(5) Revised _IRM 1.4.28.1.6_, Related Resources, as follows:

1. Revised paragraph (1) to remove reference to obsolete IRM 1.4.6, Managers Security Handbook.

2. Revised paragraph (2) with links to management intranet resource sites.

3. Added new paragraph (3) on the Taxpayer Bill of Rights (TBOR), based on guidance from the Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) and Branch 3 of the Associate Chief Counsel (Procedure and Administration).

4. Added new paragraph (4) to reference IRM 25.30.2, Service Level Agreement between the IRS Independent Office of Appeals and the Taxpayer Advocate Service.


(6) Changed the organizational title of "APS area manager" to "APS department manager" , as shown in the current standard position description (SPD) 22456 for IR-592-02, in the following subsections:

1. _IRM 1.4.28.3_, Guidelines for Management Engagement (GME)

2. _IRM 1.4.28.3.1_, GME Concept - Compliance with Program Objectives and Policies

3. _IRM 1.4.28.3.1.1_, GME Concept - Inquiry Procedures

4. _IRM 1.4.28.3.1.1.1_, GME Concept - Policy and Guidance

5. _IRM 1.4.28.4.3_, ACDS Manager Proxy

6. _IRM 1.4.28.13_, APS Processing Team Manager Duties and Responsibilities, and its related subsections


(7) Added to _IRM 1.4.28.4.1.1_, Considerations for Assignment of Work Units, information for locating Appeals’ Ex Parte Communications SharePoint, with a link to Appeals ex parte report system for use by Appeals technical advisors, per IRM 8.1.10.6, Curing Ex Parte Communications Breaches.

(8) Revised _IRM 1.4.28.4.3_, ACDS Manager Proxy, to reference IRM 1.11.4, Servicewide Delegation Order Process, that contains rules and authority for designating acting supervisory officials. In paragraphs (6) and (8), changed "OS GetServices ticket" to IRS Service Central (IRWorks) ticket for requesting an ACDS proxy assignment.

(9) Changed title of _IRM 1.4.28.5_ from "Introduction to Appeals Team Manager (ATM) Duties and Responsibilities" to "Appeals Team Manager Duties and Responsibilities." Moved the first sentence in paragraph (2) to the end of paragraph (1), and changed the word "flexiplace" to "telework."

(10) Revised _IRM 1.4.28.5.5_, Live Case Reviews, to remove the "Appeals Tax Specialists" position from the list of employees in paragraph (3) for live (open) case reviews. This position was replaced with the "Appeals Officer" Grade 9 and Grade 7 positions, per SPD 21100 and SPD 21101 for GS 930-09 and GS 930-07, respectively. These employees continue to work the same type of cases, primarily campus generated post-assessment penalty appeals and barred statute claims.

(11) Revised _IRM 1.4.28.7_, Overall Control of Work, to reflect the work by personnel performing redaction services, as well as administrative services. Made other minor changes and referenced other parts of this IRM section.

(12) Changed title of _IRM 1.4.28.8.6_, from "Shared Support (Case Processor)" to "Shared Team of Administrative & Redaction Support (STARS)" due to organizational changes that added services by redaction support employees (government information specialists) to the shared support organization, along with other organizational changes.

(13) Revised _IRM 1.4.28.9.1_, Relationship of These Guidelines to Position Management, to reference delegation order for identifying "position classifiers."

(14) Revised _IRM 1.4.28.10_, Referrals to Appeals Technical Guidance, International Operations, and TE/GE, to reflect changes made on December 1, 2022 to IRM 8.7.3.2, Overview of Appeals Technical Guidance and International Operations. For consistency with recent changes to IRM 8.7.3.2(3), IRM 1.4.28.10, paragraph 2, issue categories (with required feature codes) were changed as follows:

| **IRM 1.4.28.10, para 2, on 02/26/2020** | **IRM 1.4.28.10, para 2, as revised** |
| :-: | :-: |
| a. Compliance coordinated issues (CI | a. Appeals coordinated issues (AI) |
| b. Appeals coordinated issues (ACI) | b. Appeals coordinated issues with review and concurrence (AI) |
| c. Appeals emerging issues (EM) | c. Abusive tax avoidance transactions (LT) |
| d. Abusive tax avoidance transactions (LT) |  |

(15) Changed title of _IRM 1.4.28.13_ from " Introduction to APS Processing Team Manager (PTM) Duties and Responsibilities" to "APS Processing Team Manager Duties and Responsibilities." Removed paragraph 14 regarding a case processor because this position is no longer part of the APS organization.

(16) Revised _IRM 1.4.28.13.1_, Workload Reviews, paragraph 6, to change the term/acronym "ELMS" to "integrated talent management (ITM)" in the table regarding "workload review close-out discussion with the employee" .

(17) Revised _IRM 1.4.28.13.5.1_, Appeals Centralized Database System (ACDS) Reports, paragraph (2), to incorporate Interim Guidance Memorandum # AP-08-0922-0014, Disbandment of APS Reports Team, dated September 20, 2022. This IGM changed the national report responsibility for designated reports and database maintenance to APS management or its designated employees.

(18) Revised _Exhibit 1.4.28-1_, Case Grading Factors to Consider for Examination Sourced Cases, to add reference to _IRM 1.4.28.9.1_, Relationship of These Guidelines to Position Management.

(19) Rearranged information in _Exhibit 1.4.28-2_, Upgrading Examination Sourced Cases - Considerations, with no change to the case grade assignment.

(20) Rearranged information in _Exhibit 1.4.28-3_, Downgrading Exam Sourced Cases - Considerations, with no change to the case grade assignment.

(21) Revised _Exhibit 1.4.28-4_, Case Grading Matrix for Collection Sourced Cases, for compliance with Section 508 accessibility requirements for people with disabilities, with no change to case grade assignment. See IRM 1.11.8.5, Section 508 Compliant Content. In tables for Collection Due Process Levy Cases (DPLV) and Collection Due Process Lien Cases (DPLN), removed case grading issues that reference obsolete Forms 1040A and 1040EZ.

(22) Replaced _Exhibit 1.4.28-5_, Case Grading Matrix for Art Appraisal Services Cases, with the Art Appraisal Services team’s reorganized case grading criteria, compliant with Section 508 accessibility requirements. See IRM 1.11.8.5, Section 508 Compliant Content.

#### Effect on Other Documents

This IRM supersedes IRM 1.4.28, Appeals Managers Procedures, dated February 26, 2020, and incorporates Interim Guidance Memorandum # AP-08-0922-0014, Disbandment of APS Reports Team, dated September 20, 2022.

#### Audience

IRS Independent Office of Appeals Managers

#### Effective Date

(12-12-2024)

Patrick E. McGuire

Acting Director, Operations Support

**1.4.28.1** **(12-12-2024)**

### Program Scope and Objectives

1. _Purpose_ \- This IRM section contains guidelines for the IRS Independent Office of Appeals (Appeals) management engagement, assignment and control of work, conference observation, case work reviews, and is a supplement to general guidelines for all IRS managers contained in IRM 1.4, Resource Guide for Managers.

2. _Audience_ \- Appeals managers

3. _Policy Owner_ \- Director, Operations Support

4. _Program Owner_ \- Director, Policy, Planning, Quality and Analysis (PPQA)

5. _Contact Information_ \- Appeals employees should follow established procedures on How to Contact an Analyst. Other employees should contact the "content point of contact" shown on the product catalog results page for this IRM.


**1.4.28.1.1** **(12-12-2024)**

#### Background

1. Appeals is the only administrative function of the IRS with authority to consider settlements of tax controversies and has the primary responsibility to resolve these disputes without litigation to the maximum extent possible through an administrative settlement of the matter. Appeals’ mission is to resolve federal tax controversies without litigation on a basis which is fair and impartial to both the government and the taxpayer, promotes a consistent application and interpretation of, and voluntary compliance with, the federal tax laws, and enhances public confidence in the integrity and efficiency of the IRS. See IRC 7803(e)(3), Purposes and Duties of Office.

2. Appeals accomplishes this mission by considering protested and Tax Court cases, holding conferences, and negotiating settlements in a manner which ensures Appeals employees act in accordance with the Taxpayer Bill of Rights (TBOR) in every interaction with taxpayers. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights, and IRM 8.1.1.2, Accomplishing the Appeals Mission. All Appeals managers are accountable for supporting Appeals’ mission and core values and for managing their employees’ activities. Managers are expected to motivate their employees and establish a positive work climate.


**1.4.28.1.2** **(12-30-2019)**

#### Authority

1. **Settlement Authority in Protested and Tax Court Cases** \- The authority to settle protested and Tax Court cases is delegated to Appeals team managers (ATMs) and Appeals team case leaders (ATCLs) as to their respective cases. This does not include the authority to set aside a closing agreement. See IRM 1.2.2.9.1, Delegation Order 8-1 (formerly DO-60, Rev. 7), Appeals Functions - Settlement of Cases Docketed in the United States Tax Court, and IRM 1.2.2.9.8, Delegation Order 8-8 (Rev. 1) (formerly DO-66, Rev. 15), Authority of Appeals in Protested and Tax Court Cases.

2. **Authority to Enter into Closing Agreement** \- The authority to enter into and approve a written agreement with any person relating to the internal revenue tax liability for such person (or of the person or estate for whom he or she acts) for a taxable period or periods ended prior to the date of the agreement and related specific items affecting other taxable periods. This does not include the authority to set aside any closing agreement. See IRM 1.2.2.9.3, Delegation Order 8-3 (formerly DO-97, Rev. 34), Closing Agreements Concerning Internal Revenue Tax Liability. This authority is delegated to the following for cases under their jurisdiction (but excluding cases docketed before the United States Tax Court):



1. Director, Collection Appeals

2. Director, Examination Appeals

3. Director, Specialized Examination Programs and Referrals

4. Appeals Area Directors

5. Appeals Team Managers

6. Appeals Team Case Leaders


3. **Authority to Execute Consent to Extend Period of Limitation on Taxpayer Suits Under IRC 6532** \- Delegated to Directors, Appeals Operating Units (Appeals Area Directors). See IRM 1.2.2.9.4, Delegation Order 8-4 (formerly DO 171, Rev. 2), Authority of Appeals Under 26 CFR 301.6511 and 26 CFR 301.6532, and IRM 8.7.7.3.3, Form 907, Agreement to Extend the Time to Bring Suit.

4. **Authority to Administer Dispute Resolution Procedures under IRC 7123** \- Redelegated by the Chief, Appeals, as identified in IRM 1.2.2.9.9, Delegation Order 8-9, Authority of Appeals to Administer Dispute Resolution Procedures, and IRM 8.26, Alternative Dispute Resolution (ADR) Program.

5. **Authority to Designate Appeals Coordinated Issues** \- Delegated to the Director, Specialized Examination Programs and Referrals (SEPR). See IRM 1.2.2.9.6, Delegation Order 8-6 (formerly DO-179, Rev. 2), Coordination of Certain Issues Before Approval of Settlement or Other Disposition in Appeals. The Director, SEPR is authorized to make the final determination as to the disposition of the Appeals coordinated issue (ACI) in any case involving an ACI if the coordinating official has not concurred and the ATM cannot resolve the dispute. See IRM 1.2.2.9.8, Delegation Order 8-8 (Rev. 1) (formerly DO-66, Rev. 15), Authority of Appeals in Protested and Tax Court Cases, and IRM 8.7.3, Domestic and International Operations Programs.



### Note:



To determine the appropriate "ACDS feature code" for referrals to Appeals’ Technical Guidance and/or International Operations specialists, see _IRM 1.4.28.10_, Referrals to Appeals Technical Guidance, International Operations, and TE/GE.

6. **Authority to Decide Appeals of Participation Denial and Sanctions in the IRS _e-File_ Program** \- Delegated to ATMs to make final agency decisions. See IRM 1.2.2.9.5, Delegation Order 8-5, Authority to Decide Appeals of Participation Denial and Sanctions in the Internal Revenue Service.

7. **Authority of Appeals in Termination Assessments of Income Tax, Jeopardy Assessments and Jeopardy Levies** \- Delegated to ATM and ATCLs as to their respective cases. See IRM 1.2.2.9.7, Delegation Order 8-7 (formerly DO-160, Rev. 6), Authority of Appeals in Termination Assessments of Income Tax, Jeopardy Assessments and Jeopardy Levies.

8. Authorities **do not include authority** to:



1. Eliminate the fraud penalty in any case in which the penalty has been determined by an originating office for which criminal prosecution against the taxpayer (or related taxpayer involving the same transaction) has been recommended to the Department of Justice for willful attempt to evade or defeat tax, or for willful failure to file a return, except upon the recommendation or concurrence of the Office of Chief Counsel (Counsel);

2. Act in any case in which a recommendation for criminal prosecution is pending, except with the concurrence of Counsel;

3. Make a final decision in any case if Appeals’ proposed disposition is contrary to the Headquarters ruling or technical advice on the case concerning tax exemption, private foundation classification, or plan qualification; or

4. Determine liability for an excise tax imposed on alcohol, tobacco and firearms.



      ### Note:



      See IRM 1.2.2.9.8 for Delegation Order 8-8 (Rev. 1) and IRM 8.6.3.3, Procedures if Appeals Conclusion is Contrary to Service Position.


**1.4.28.1.3** **(12-12-2024)**

#### Responsibilities

01. The Chief, Appeals, reports to the Commissioner of IRS and is responsible for planning, managing, directing, and executing nationwide activities for Appeals. The Chief/Deputy Chief, Appeals, has functional responsibility for all Headquarter operations in Appeals, including the following and their staff:



    - Director, Collection Appeals

    - Director, Examination Appeals

    - Director, Specialized Examination Programs and Referrals

    - Director, Case Support

    - Director, Operations Support

    - Communications


02. Appeals’ operations executive directors are responsible for providing operational support in meeting the Appeals Strategic Business Plan in a manner consistent with Appeals’ mission and vision statements. The operations directors supervise and are responsible for activities of Appeals area directors, senior operations advisors, and technical advisors.



    1. _Collection Appeals_ \- The Director, Collection Appeals, is responsible for collection issues. This mission is accomplished by providing oversight through directors and staff of policies and tax issues not otherwise coordinated by the Appeals subject matter experts. This function is primarily staffed by Appeals settlement officers.

    2. _Examination Appeals_ \- The Director, Examination Appeals, is responsible for examination issues not in a specialized examination program. This mission is accomplished by providing oversight through directors and staff of policies and tax issues not otherwise coordinated by the Appeals subject matter experts. This function is primarily staffed by Appeals officers, including ATCLs.

    3. _Specialized Examination Programs and Referrals (SEPR)_ \- The Director, SEPR is responsible for overseeing timely identification of significant tax issues and coordination of issue resolution through subject matter experts to insure technically consistent, impartial and independent settlements across Appeals. This mission is accomplished through directors and staff of International Operations, Technical Guidance, Appeals TEFRA Team (ATT), and Technical Support (a/k/a Tax Computation Specialists or TCS). SEPR includes Appeals technical employees (ATEs) who consider the following cases: estate and gift, innocent spouse relief, penalty Appeals (PENAP), and cases from Compliance TE/GE functions. The Director, SEPR also provides oversight of the Commissioner’s Art Advisory Panel (Art Appraisal Services).


### Note:

Appeals officers and settlement officers are included in the umbrella term "Appeals Technical Employee" (ATE), used to refer to any Appeals employee assigned a case for settlement consideration.

03. Appeals area directors report to their operations executive director for planning, organizing, directing, and evaluating activities associated with the hearing, negotiation, and settlement of taxpayer appeals.

04. ATMs reports to their area director and have full accountability for their overall team success in delivering and balancing customer satisfaction, employee satisfaction, and business results. ATMs plan, organize, lead, and evaluate their team of ATEs and appropriately support personnel engaged in the hearing, negotiation, and settlement of taxpayer appeals. For non-ATCL cases, the ATM approves case settlements, ensuring team member settlements and team objectives comply with Appeals vision and values.

05. The Director, Case Support, is responsible for performing all case processing actions, from intake and assignment to closing cases out of Appeals, providing shared administrative services to Appeals personnel, and performing redaction of case files requested under the Taxpayer First Act. The Case Support function combines Account and Processing Support (APS) and the Shared Team of Administrative and Redaction Support (STARS).

06. The Director, Operations Support, is responsible for providing technical and procedural guidance, coordinating with the Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA), overseeing the Appeals internal management document (IMD) program, developing and implementing alternative dispute resolution programs (ADR), providing trend and data analyses, planning expertise, detailed summary reports and assistance, conducting quality reviews of cases, providing guidance on human capital issues, planning and executing Appeals budget, supporting Appeals information technology needs, and developing and delivering training and implementing knowledge management strategies.

07. Communications is responsible for facilitating effective communication with Appeals employees and other internal and external stakeholders. For more information, visit Appeals Communications webpage.

08. All managers are responsible for:



    1. Ensuring the development, performance, and conduct of each employee they direct;

    2. Defining clear goals and courses of action to their employees and ensuring such actions are carried out;

    3. Ensuring the well-being and progress of their employees;

    4. Displaying proper attitude and behavior, job knowledge, and effective communication to build good working relationships thereby motivating people to accomplish programs and meet objectives.


09. For internal control responsibilities, see IRM 1.4.2, Monitoring and Improving Internal Control.

10. This IRM section focuses on Appeals’ case-related management roles.


**1.4.28.1.4** **(12-30-2019)**

#### Program Reports

1. The Director, PPQA, provides trends and data analyses and detailed summary reports for Appeals. The systems and reports shown below are available to authorized Appeals users depending on their position description, access level, and responsibilities.




| **System/Report** | **Description** |
| --- | --- |
| Appeals BOE | Appeals business operating environment |
| AIR | Appeals inventory reports |
| D&BAM BOE | Diagnostics & balanced measures business operating environment |
| PCS | Partnership control system |
| PROMS | Process & results measurement reports |
| TAXCAL | Tax Court calendar reports |

2. There are a series of reports available within ACDS from the Main Reports Menu.


**1.4.28.1.5** **(12-12-2024)**

#### Terms and Acronyms

1. The table lists commonly used acronyms and their definitions:




| **Terms and Acronyms** | **Definition** |
| --- | --- |
| AARS | Appeals account resolution specialist |
| ACAP | Denotes appeals team manager’s approval (see IRM 8.20.3.4.41 ) |
| ACDS | Appeals centralized database system |
| AIMS | Automated information management system (see IRM 8.1.3.3.1) |
| APS | Account and Processing Support |
| APS TE | Account and Processing Support tax examiner |
| AQMS | Appeals quality measurement system (see IRM 8.1.7.2 ) |
| AOIC | Automated offer in compromise system |
| ASED | Assessment expiration date |
| ASFR | Automated substitute for return |
| ATAT | Abusive tax avoidance transactions |
| ATCL | Appeals team case leader |
| ATCL/TL | Appeals team case leader/team leader |
| ATCTM | Appeals tax computation team manager |
| ATE | Appeals technical employee |
| ATM | Appeals team manager |
| CAR | Case activity record |
| CARATS | Case activity record and automated timekeeping system |
| CDP | Collection due process (see IRM 8.22) |
| CIT | Complex interest team |
| CJE | Critical job element |
| CLP | Career learning plan |
| DIMS | Docketed information management system |
| DPL2 | ACDS type code for CDP lien and levy work unit |
| DPLN | ACDS type code of CDP lien work unit |
| DPLV | ACDS type code for CDP levy work unit |
| EP/EO | Employee Plan / Exempt Organization |
| EPF | Employee personnel file |
| Feature code | A two-digit code used in ACDS for identifying special features of a case (see IRM 8.20.3.4.9) |
| IDRS | Integrated data retrieval system (see IRM 8.1.3.3.2) |
| ISTS | Innocent spouse tracking system |
| ITM | Integrated talent management (see IRM 6.410.8) |
| IVL | Inventory validation listing (see IRM 8.10.3) |
| LR | Labor Relations |
| LTE | Lead tax examiner |
| OJI | On-the-job instructor |
| OJT | On-the-job training |
| Panel | Art Advisory Panel (see IRM 4.48.2.2.1) |
| PEAS | Processing Employee Automated System (see IRM 8.20.10) |
| PENAP | Penalty Appeals (see IRM 8.11.4) |
| PII | Personally identifiable information (see IRM 10.5.1.2.3) |
| PTM | Processing team manager |
| Sequa worksheet /spreadsheet | Rev. Rul. 99-40 computations (see IRM 8.17.6.10 and IRM 8.20.7.10.11) |
| SFR | Substitute for return |
| SND | Statutory notice of deficiency or notice of deficiency |
| STARS | Shared Team of Administrative & Redaction Support |
| TCS | Tax computation specialist |
| TE | Tax examiner |
| TEFRA | Tax Equity and Fiscal Responsibility Act of 1982 |
| TG | Technical Guidance |
| TEGE | Tax Exempt and Government Entities |
| TFRP | Trust Fund Recovery Penalty |
| WUNO | Work unit number (see IRM 8.20.5.3.1.6) |
| Other common terms used by Appeals | See Exhibit 8.1.1-1 |


**1.4.28.1.6** **(12-12-2024)**

#### Related Resources

1. IRM 1.4, Resource Guide for Managers, and IRM Part 6, Human Resources Management, contain information on several employee-related matters, including those listed below:




| **IRM or Document** | **Title** |
| --- | --- |
| IRM 1.4.1 | Management Roles and Responsibilities |
| IRM 1.4.2 | Monitoring and Improving Internal Control |
| IRM 6.511.1.6.4.5 | Assignment of Higher-Graded Work |
| IRM 6.630.1 | IRS Absence and Leave |
| IRM 6.735.1 | Ethics and Conduct Matters |
| IRM 6.751.1 | Discipline and Disciplinary Actions: Policies, Responsibilities, Authorities, and Guidance |
| IRM 6.800.2 | IRS Telework Program |
| IRM 8.1.1.5.3 | Testimony by Appeals Employees in IRS Tax Cases |
| IRM 8.6.1.3 | Transfer Procedures |
| IRM 8.6.1.5.1.1 | Circuit Riding |
| Document 11678 | IRS and NTEU National Agreement (IRS/NTEU Agreement) |

2. Employees can find helpful information on performance management, leadership development, and various other topics on the following intranet sites:



1. Appeals Exchange (ApEx) Leadership Knowledge Library

2. Appeals Labor Relations Resources

3. EthicsLink - maintained by General Legal Services (GLS)

4. iManage - Virtual community for IRS Managers (includes 7114 meeting guidance)

5. IRS Human Capital Office - Critical Job Elements (CJE)

6. IRS Human Capital Office - Labor Relations

7. Managers Advisory Group (MAG)

8. Security Awareness


3. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accordance with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see https://www.irs.gov/taxpayer-bill-of-rights.

4. In accordance with IRM 25.30.2.3, Statement of Commitment, Appeals will work collaboratively with the Taxpayer Advocate Service (TAS) to enhance the taxpayer experience. For more information, see IRM 25.30.2, Service Level Agreement between the IRS Independent Office of Appeals and the Taxpayer Advocate Service.


**1.4.28.2** **(11-20-2013)**

### Appeals' Mission, Organizational Structure, Vision and Core Values

1. For a complete discussion on the Appeals mission and organizational structure, refer to IRM 1.1.7 , Organization and Staffing, Appeals. Appeals’ vision is to promote an independent and innovative environment that drives quality and timely resolution of tax disputes by empowering a highly skilled, motivated and cohesive workforce.

2. Appeals’ core values are:



   - Independence

   - Professionalism

   - Collaboration

   - Resourcefulness


**1.4.28.3** **(12-12-2024)**

### Guidelines for Management Engagement (GME)

1. Management engagement is a concept of active, personal, directional involvement by area directors, Account and Processing Support (APS) directors, APS department managers, ATMs, Appeals tax computation team managers (ATCTMs), and processing team managers (PTMs). Focusing on directional involvement and accountability positively impacts customer satisfaction, employee satisfaction and business results. Managers are expected to motivate their employees and establish a positive work climate where the approach is one of engagement and commitment with a focus on improvement in operational measures. The emphasis needs to be on the positive: what we can do, what we will do, and why it’s important. The expectation is that Appeals managers will:



1. Engage the workforce in achieving IRS and Appeals goals, objectives and modernization vision;

2. Take ownership of the workload, data bases and other systems; and

3. Develop their employees.


### Note:

The Appeals account resolution specialist (AARS) team manager reports to an APS director. Due to the nature of the AARS work and their respective job series and position description, this IRM’s ATM guidance also applies to the AARS manager except where specifically identified as not applicable.

2. Management engagement requires a high level of emphasis on the concept of ownership of work at each organizational level. Frequent and direct communication is critical. The expectation is that managers will communicate organizational policies and objectives in the context of the employees’ day-to-day actions. Engagement and commitment are necessary at all management levels to achieve continuous improvement in customer satisfaction, employee satisfaction and business results. The concept of ownership of the work applies to operations and programs. The executive and management levels address this guideline as follows:




| **Operating Executive** |
| :-: |
| Business reviews and direction |
| Guidance from program analysts |
| Customer outreach - internal and external stakeholders |
| Monitoring business results and resources |






| **Area Director** |
| :-: |
| Operational reviews and direction |
| Customer outreach - internal and external stakeholders |
| Monitoring business results and taking actions to improve |
| Monitoring resources and actively addressing imbalances |






| **Account and Processing Support Director** |
| :-: |
| Operational reviews and direction |
| Customer outreach - internal and external stakeholders |
| Monitoring business results and taking actions to improve |
| Monitoring resources and actively addressing imbalances |






| **Account and Processing Support Department Manager** |
| :-: |
| Operational reviews and direction |
| Monitoring business results and taking actions to improve |
| Monitoring resources and actively addressing imbalances |






| **Appeals Team Manager** |
| :-: |
| Interactions with employees |
| Team meetings, training and workshops |
| Review and feedback on live and closed cases |
| Customer outreach - internal and external stakeholders |
| Addressing performance issues promptly |






| **Appeals Tax Computation Team Manager** |
| :-: |
| Interactions with employees |
| Team meetings, training and workshops |
| Review and feedback on live and closed cases |
| Customer outreach - internal and external stakeholders |
| Addressing performance issues promptly |






| **Processing Team Manager** |
| :-: |
| Interactions with employees |
| Team meetings, training and workshops |
| Review and feedback on live and closed cases |
| Employee development |
| Addressing performance issues promptly |

3. **What is ownership?**The concept of ownership includes commitment to doing the best possible job and performing every act to consistently achieve the correct results or appropriate action. The area director, APS department manager, ATM, ATCTM, and PTM are the critical links between broader goals and the operational objectives and measures. _Management ownership_ requires consideration of what is important to all taxpayers and balances operational efficiency with the achievement of high quality results. Taxpayers seeking appeal rights are interested in resolving their dispute on a timely basis with courtesy and in receiving the _correct_ application of the tax law. The rest of the tax paying public is generally concerned with safeguarding the public trust concerning the protection and conservation of their tax dollars and rights through operational efficiency and accuracy.

4. A significant aspect of employee development is fostering the attitude and expectation that all employees, including managers, take personal ownership in continual development and for becoming experts in their area of responsibility. There are many internal resources available, including Skillsoft courses, specialized formal training, and other training opportunities. Area directors, department managers and front-line managers must plan actions to ensure all employees are availed of these resources. Informal training, such as presentations by Counsel or specialists, or assigning employees to make presentations on technical issues at team meetings, provides benefits at minimum cost.

5. ATMs, ATCTMs, and PTMs are responsible for ensuring employees can work the full range of issues at their grade level and that they stay current and proficient as changes occur. While the nature of the case receipts can present a challenge in providing sufficient variety of work, whenever feasible, employees are assigned higher graded work for developmental purposes in accordance with IRM 6.511.1.6.4.5, Assignment of Higher Graded Work. This provides lower-graded employees with an opportunity to demonstrate their potential to perform work at the higher level.


**1.4.28.3.1** **(12-12-2024)**

#### GME Concept - Compliance with Program Objectives and Policies

1. Managers obtain and ensure a high level of compliance with program objectives and policies through communication, review, and follow-up on:



   - Program and case decisions

   - Workload management

   - Performance and commitments


2. The executive and management levels address this as follows:




| **Operating Unit Executive** |
| :-: |
| National business reviews |
| Town hall meetings |
| Management conference calls |
| Office visitations |
| Monitoring achievement of performance and commitment goals |
| Analysis and evaluation of programs |






| **Area Director** |
| :-: |
| Continuing personal involvement in program and workload management |
| Operational reviews |
| Monitoring achievement of performance and commitment goals |
| Reviews of open and closed cases |
| Management conference calls |
| Town hall meetings |
| Analysis and evaluation of programs and statistical data |






| **Account and Processing Support Director** |
| :-: |
| Continuing personal involvement in program and workload management |
| Operational reviews |
| Monitoring achievement of performance and commitment goals |
| Management conference calls |
| Town hall meetings |
| Analysis and evaluation of programs and statistical data |






| **Account and Processing Support Department Manager** |
| :-: |
| Continuing personal involvement in program and workload management |
| Operational reviews |
| Monitoring achievement of performance and commitment goals |
| Management conference calls |
| Analysis and evaluation of programs and statistical data |






| **Appeals Team Manager** |
| :-: |
| Priority reviews |
| Live case reviews |
| Workload reviews |
| Closed case reviews |
| Conference observations |
| Analysis and evaluation of monthly statistical data |
| Team meetings |






| **Appeals Tax Computation Team Manager** |
| :-: |
| Live case reviews |
| Workload reviews |
| Closed case reviews |
| Analysis and evaluation of monthly statistical data |
| Team meetings |






| **Processing Team Manager** |
| :-: |
| Priority reviews (mandatory review) |
| Live case reviews |
| Workload reviews |
| Closed case reviews |
| Analysis and evaluation of monthly statistical data |
| Team meetings |


**1.4.28.3.1.1** **(12-12-2024)**

##### GME Concept - Inquiry Procedures

1. The GME concept requires managers’ acceptance of responsibility for their actions and decisions regarding the achievement of Appeals’ overall goals and objectives and to balance the needs of all of Appeals’ customers. Inquiry procedures include:



   - Analysis of case management activity

   - Performance documentation and feedback

   - Quality measurement results


2. Area directors and APS department managers need to inquire how effectively managers are carrying out their responsibilities for ownership of the work by seeing that managers are:




| **Area Director / Account and Processing Support Department Manager** |
| :-: |
| Fully engaging their employees in the work |
| Utilizing their time efficiently |
| Monitoring the quality of decisions and quality of case actions |
| Monitoring the timeliness of case resolution |
| Utilizing resources effectively |
| Ensuring taxpayer privacy |
| Making correct decisions |

3. To ascertain the level of engagement, area directors and department managers should monitor the quality of their work and the work climate. This can be accomplished by:



1. Appraising the efficiency of the office with the aid of statistical data – Monthly ACDS, Appeals BOE reports, AARS referrals, unpostable reports (AIMS and Non-AIMS) and AQMS results (Business, Results, Quality)

2. First hand knowledge through appropriate operational and ad hoc reviews

3. Reviewing performance documentation at the team and individual levels

4. Feedback from practitioners and taxpayers (customer satisfaction surveys)

5. Analyzing employee satisfaction surveys and workgroup meeting results

6. Observing non-verbal communications (i.e. reading body language, emotions and attitude of employees)

7. Observing the ability of managers and employees to accurately and efficiently perform their work


4. The GME concept requires managers to accept responsibility for their actions in meeting the organization’s goals and objectives and to balance customers’ needs. Managers should inquire how effectively employees are carrying their responsibilities. This is accomplished by:




| **Appeals Team Manager** |
| :-: |
| Timely involvement at the decision-making stage |
| Intervening in cases where value can be added |
| Determining where to concentrate the employee’s time and effort |
| Providing open and frank feedback |
| Conducting an appropriate analysis of case decisions and inventory management activity |
| Observing conferences |






| **Appeals Tax Computation Team Manager** |
| :-: |
| Timely and accurately assigning work appropriate to the employee’s skill level |
| Involvement in work requests where value can be added |
| Prioritizing and balancing their time and effort towards accomplishment of team goals |
| Providing the employee with open and constructive feedback |
| Conducting an appropriate analysis of case activity and inventory management |
| Identifying training needs specific to each employee to support performance and skill development |






| **Processing Team Manager** |
| :-: |
| Timely assigning work appropriate to the employee’s skill level |
| Involvement in cases |
| Prioritizing and balancing their time and effort towards accomplishment of team goals |
| Providing the employee with open and constructive feedback |
| Conducting an appropriate analysis of processing actions and inventory management activity |
| Identifying training needs specific to each employee to support performance and skill development |
| Establishing practical methods for developing their employees’ technical competency |

5. ATMs are expected to maintain direct knowledge of cases within their team. With ownership, the ATM is a stakeholder in the work product. To ensure a high quality work product, the ATM should be knowledgeable and involved in cases up front. This is accomplished by conducting live case reviews, workload reviews, conference observations, and closed case reviews to:



1. Evaluate if the case is being properly handled before the decision is made

2. Evaluate if effective inventory management practices are being followed

3. Evaluate if the time span and time applied are appropriate

4. Determine if the settlement obtained was appropriate – was the law correctly applied

5. Evaluate whether the ATE was objective\*

6. Obtain and utilize feedback from AQMS for trends in case quality\*


\\* _This item is not applicable for AARS ATM_

6. ATCTMs are expected to maintain direct knowledge of cases within their team. This is accomplished by conducting live case reviews, closed case reviews, workload reviews, ACDS, and Appeals TCS Statistical (ATS) Reports analysis to:



1. Evaluate effective inventory management practices

2. Evaluate time span and time applied

3. Determine correct tax law application

4. Utilize AQMS feedback to identify trends, training needs, and opportunities for improvement


7. The PTMs and AARS ATM are expected to maintain direct knowledge of cases within their team’s inventory. This is accomplished by conducting live case reviews, workload reviews, ACDS and PEAS report analysis, and closed case reviews to:



1. Evaluate if the ASED is accurately controlled and protected

2. Evaluate if effective inventory management practices are being followed

3. Evaluate if the time span and time applied are appropriate

4. Determine if the PEAS Case Activity Record (CAR) is being documented correctly and suspended when appropriate

5. Evaluate if the APS Tax Examiner (TE) accurately analyzed the case file documents and took appropriate action to resolve discrepancies

6. Determine if the APS TE updated/closed all applicable systems according to the respective policy and procedure

7. Obtain and consider feedback to identify trends, training needs, and opportunities for improvement from:


       \- Appeals Quality Measurement System (AQMS)\*


       \- Complex Interest Quality Measurement System (CIQMS)\*


       \- AARS Referrals\*\*


       \- Unpostable reports (AIMS and Non-AIMS)


\\* _This item is not applicable for AARS ATM_

\*\* _This item applies only to AARS ATM_

**1.4.28.3.1.1.1** **(12-12-2024)**

###### GME Concept - Policy and Guidance

1. This component of GME addresses policy and guidance as it flows from Headquarters through the area director/department manager to the manager. The IRS performance management system (PMS) contracts define responsibilities. Operating unit directors provide guidance in specific program areas. IRS policies, such as the IRS and NTEU provisions, are emphasized at each management level. Policy and guidance include:



   - Clearly defined roles and responsibilities

   - IRS and National Treasury Employees Union (NTEU) provisions

   - Strategic program guidance


2. The Appeals strategic/program plan provides strategic program direction. Area directors/department managers and frontline managers have a stake in the ownership of program direction and guidance contained in the Appeals strategic/program plans and are charged with delivering on the objectives through execution of all necessary actions.


**1.4.28.4** **(04-19-2016)**

### Assignment and Control of Work

1. Appeals managers are responsible for the control of work units from the time the unit comes into the office until it goes out of the office.

2. Monthly and quarterly statistical reports summarize information on receipts, disposals, inventory, overage units, etc., and provide a means of controlling work on an overall basis.

3. APS is the control center for the returns in inventory. See IRM 8.20, Account and Processing Support (APS), for instructions on maintaining a uniform record and reporting system on Appeals operations.

4. See _IRM 1.4.28.13_, APS Processing Team Manager Duties and Responsibilities.


**1.4.28.4.1** **(12-30-2019)**

#### Assignment of Work Units and Initial Case Actions

1. ATMs are responsible for promptly assigning work units. At the time of assignment, the ATM determines:



1. The grade level of the work unit (see IRM exhibits),

2. Whether the associated group of cases received constitutes a proper package of cases for inclusion as an Appeals work unit, and;

3. Whether cases involve an ACI or a tax shelter



      ### Note:



      Compare the date stamped on Compliance’s transmittal memorandum and the ACDS assignment date to indicate whether work units were unduly delayed in being made available for assignment.


2. The ATE will complete the statute verification and send the appropriate initial contact letter within the time frames shown below:




| **For** | **Verify statute** | **Send letter** |
| --- | --- | --- |
| Liability, penalty appeals, and innocent spouse | 45 days | 45 days |
| Collection due process | 30 days | 30 days |
| Offer in compromise | 30 days | 30 days |





> **Re: Liability, Penalty Appeals, and Innocent Spouse work streams**
>
> ATMs will be reasonable in extending the contact time frame if circumstances (e. g. leave, workload, case complexity or other priorities) prevent the ATE from meeting them. If the ATE extends the time frame, the ATE will document this decision and the agreed upon time frame in the CARATS on ACDS. **The statute verification time frame will not be extended beyond 45 days.** If the contact time frame is extended beyond 75 days, the ATM will contact the taxpayer/representative by correspondence providing a status of the case and to whom the case is assigned.





### Note:



For TEFRA/BBA key cases, the 45-day time frame for statute verification applies to field ATEs only. The TEFRA/BBA team ATE will verify the statute within five (5) workdays prior to assignment of the case to a field ATE.

3. For more information on initial case actions, see the following:



   - IRM 8.6.1.2 , New Receipts and Initial Case Actions, and

   - IRM Exhibit 8.6.1-1, Pre-Selected Enclosures for Initial Contact Letters Based on Category and Case Type


**1.4.28.4.1.1** **(12-30-2019)**

##### Considerations for Assignment of Work Units

01. Consider the status or condition of each ATE's inventory, as well as the ATE’s areas of particular expertise and experiences. To make an intelligent assignment decision, a manager must have knowledge of the:



    1. Employee's ability

    2. Size and status of assigned inventory, including collateral duties/assignments

    3. Grade of the case; and

    4. Frequency of assignments



       ### Note:



       Avoid assigning a large number of cases at one time whenever possible.


02. Inspect newly received work units to determine the issues, case grades, and separate into groups of possible conference sites. For information regarding _case grading,_ see _IRM 1.4.28.9_, Guidelines for Determining the Grade Levels of Appeals Work Units.

03. During inspection of work units, be alert for circumstances that might prevent Appeals from properly considering, deciding, and/or processing the case. IRM 8.2.1.5 , Returning a Case to Examination - ATE, contains a list of circumstances, not all inclusive, that might be grounds for returning a case.



    ### Note:



    It may be beneficial to discuss the return of a work unit with an Examination representative before making a decision on whether to retain or release jurisdiction of the work unit. However, if such discussion extends beyond ministerial, administrative or procedural matters, the taxpayer must be given an opportunity to participate. For _ex parte_ communication guidance, see Rev. Proc. 2012-18, 2012-10 I.R.B. 455, and IRM 8.1.10, Ex Parte Communications. In the event of an ex parte communications breach, the ATM will contact the area technical advisor with the necessary details. See IRM 8.1.10.6, Curing Ex Parte Communications Breaches, and IRM 8.1.10.7, Documenting Ex Parte Communications. The area technical advisor is responsible for entering ex parte breaches on Appeals’ ex parte report SharePoint site by clicking on the Ex Parte entry link located on Appeals Ex Parte Communications page, under "Guidance and Procedures."

04. Take special care in making assignments when travel away from a headquarters office or post of duty is involved. Cost effectiveness of circuit-riding conferences is best achieved when an employee has _sufficient assignments_ to schedule _multiple conferences_ at each circuit-riding location. See IRM 8.6.1.5, Conference Techniques Used by Appeal Technical Employees (ATEs), for assistance in evaluating the merits of circuit riding requests.

05. Bring any unusual features or special instructions to the attention of the ATE assigned the case.

06. In general, rotate ATEs on cases so they are not assigned more than two consecutive work units of the same taxpayer. However, if most of the substantial issues in a subsequent receipt are identical, good management practice favors continuation of the same ATE. For CDP cases, see IRM 8.22.5.4.1, No Prior Involvement.

07. It is good practice to assign an ATE as a team member to consider continuing issues from prior years. Also, units involving a different year or different type of tax on a taxpayer already having a case pending may be assigned to the same ATE if the old work unit is not nearing completion. Assign a work unit requiring reconsideration, for whatever cause, to the ATE who originally handled it.

08. The AARS ATM assigns work based on inventory levels and efficient inventory management strategy.

09. Encourage your employees to discuss unmanageable inventory problems at any time.



    ### Reminder:



    An ATM can extend the contact time frame if circumstances (e.g. leave, workload, case complexity or other priorities) prevent the ATE from meeting them.

10. When an unexpected excess of inventory occurs (i.e. retirement, prolonged leave, temporary or permanent reassignment of a team member, etc.) consider inventory balancing throughout the area, not just among the remaining team members. Consult with your area director as situations arise.


**1.4.28.4.2** **(08-15-2017)**

#### Control of Work

1. APS is responsible for controlling and processing work units in Appeals and Counsel’s jurisdiction. See IRM 8.20, Account and Processing Support (APS), and IRM 8.1.3.11 , Account and Processing Support (APS). Each employee is responsible for controlling assigned inventory and monitoring work units while in process. Basic management tools available are workload reviews and live case reviews.

2. In addition, Appeals managers should utilize trial status requests and trial calendars in order to achieve Appeals' objectives under Rev. Proc. 2016-22 for cases docketed in the United States Tax Court.



### Note:



ATMs are responsible for entering the ACAPDATE on ACDS.

3. The AARS manager is responsible for controlling AARS inventory. The AARS manager’s closing actions do **not** include entering an ACAPDATE on ACDS.


**1.4.28.4.2.1** **(08-16-2013)**

##### Inventory and Unit Time Report

1. The inventory and unit time report contains a variety of information. For example, an analysis of an Appeals employee’s time report shows -



1. Size of the employee's inventory

2. Employee's use of time

3. Whether inventory is being managed with regard to proper priorities

4. Whether inventory is being managed in an organized manner

5. Periods of inactivity on specific work units

6. Accumulated time per work unit

7. General status of the inventory

8. Greater amount of time applied to indirect activities than appears justified


2. Managers may wish to make written comments regarding case progress, etc., on the time report, where appropriate.


**1.4.28.4.2.2** **(12-30-2019)**

##### Case Summary Cards

1. Appeals Centralized Database System (ACDS) is a computerized case control system used by Appeals to control and track cases coming into and leaving Appeals. See IRM 8.20.3, Appeals Centralized Database System, and the ACDS User Guide. Access this guide from Appeals Intranet Home Page > Systems and Technology > ACDS Page > ACDS User Guide. The case summary card is generated by the computer after the case and return level information are input. The case summary card displays all information for the case. The total work unit dollars and grade of the work unit appear on the card.

2. ATEs use the case summary card to identify and control cases in their inventory. Use the case summary card for many of the same purposes as the time report is used, but cards must be used to record and accumulate information not available in an ATE's time report. Thus, use the cards as an adjunct to the time report.



### Note:



This section does not apply to AARS ATM.


**1.4.28.4.2.3** **(08-15-2017)**

##### Case Activity Record and Automated Timekeeping System

1. The Case Activity Record and Automated Timekeeping System (CARATS) is a sub-system within ACDS used to record case time, prepare timesheets, and record case activity. The computer program automatically posts time on the time sheet and CAR based on information input into the system by the ATE, AARS, TCS, or TE.

2. At the end of the month, the computer generates both the CAR and monthly time sheet. The specific CARATS entries by the ATE, AARS, or TE are designed to assist management in measuring and improving case processes.


**1.4.28.4.3** **(12-12-2024)**

#### ACDS Manager Proxy

1. The ACDS proxy module provides managers with a means to delegate access to their ACDS accounts to acting managers. See IRM 1.11.4, Servicewide Delegation Order Process, for rules and the authority for designating acting supervisory officials.



### Caution:



Avoid any open ended or long-term proxies for bargaining unit employees to minimize risks of inadvertent accesses and/or browsing.

2. A proxy has full managerial access to ACDS and all actions taken by the proxy will be recorded as those having been completed by the manager. ACDS does not record the proxy’s name on these actions. However, ACDS lists all proxies assigned.

3. An ACDS proxy manager's guide was prepared by Appeals and should be utilized to answer general, functional questions about the proxy program. Access this guide from the Appeals intranet home page > Systems and Technology > ACDS page > Resources > Manager Proxy User Guide.

4. The following managers will have permissions to assign a proxy on ACDS. The bulleted positions below identify the proxy population appropriate for each manager:




| **Manager** | **Allowable Proxy Positions** |
| :-- | :-- |
| Appeals team manager (ATM) | - Any other ATM, nationwide<br>     <br>   - Any ATE, nationwide |
| Appeals account resolution specialist (AARS) team manager | - Lead account resolution specialist |
| Processing Team Manager (PTM) | - Any other PTM, nationwide<br>     <br>   - A lead tax examiner (LTE) in their group |
| Appeals tax computation team manager (ATCTM) | - Any other TCS manager, nationwide<br>     <br>   - Any TCS, nationwide<br>     <br>   - Any AO, nationwide<br>     <br>   - TCS area technical advisor |
| Tax computation specialist (TCS) technical advisor | - Any other TCS manager, nationwide<br>     <br>   - Any TCS, nationwide<br>     <br>   - Any AO nationwide |
| Area director | - Any ATM, nationwide<br>     <br>   - Any ATE, nationwide<br>     <br>   - Any area technical advisor, nationwide |
| Area technical advisor | - Any ATM, nationwide<br>     <br>   - Any ATE nationwide<br>     <br>   - Any area technical advisor, nationwide |
| APS department manager | - Any PTM, nationwide<br>     <br>   - Any APS technical advisor, nationwide |
| APS technical advisor | - Any PTM, nationwide<br>     <br>   - Any APS technical advisor, nationwide |
| APS director | - Any PTM, nationwide<br>     <br>   - Any APS technical advisor, nationwide |
| APS National technical advisor | - Any PTM, nationwide<br>     <br>   - Any APS technical advisor, nationwide |

5. Business Systems Planning (BSP) account administrators have **global access** and permission to assign a proxy on ACDS when a manager is not available to make the assignment.

6. The following limitations apply:



1. The manager can assign multiple proxies, but the _effective_ dates cannot overlap.

2. A manager cannot assign a proxy for any other manager.

3. If a manager is unavailable to assign a proxy, the office of the area director/department manager will request a proxy assignment by submitting an via an IRS Service Central (IRWorks) ticket.


7. Actions of the proxy will be restricted as follows:



1. The proxy cannot approve an update to his or her own case.

2. The proxy cannot approve a closure of his or her own case.

3. The proxy cannot assign another employee as proxy.


8. The following question and answer scenarios discuss the most routine situations encountered where a proxy is involved:




|  | **Question** | **Answer** |
| --- | :-- | :-- |
| 1 | When a manager needs to extend an assignment but does not have access to ACDS, who extends the assignment? | If the manager is not available, direction should be obtained from the area director/department manager and _IRM 1.4.28.4.3_ should be followed to make the assignment. |
| 2 | When a manager assigns a proxy for a specific period but returns earlier than scheduled, what happens to the proxy? | The manager amends the proxy assignment to an earlier ending date. |
| 3 | When the manager is away and the assigned proxy cannot complete the assignment, who assigns the new proxy? | The area director/department Manager requests the assignment via an IRS Service Central (IRWorks) ticket. |
| 4 | When a manager assigns a proxy (proxy #1) to serve for an extended period of time, can the manager assign another proxy (proxy #2) to the same group for the sole purpose of assigning cases to and approving the closures of proxy #1? | No. This creates two proxies with overlapping periods. Instead, consider reassigning the proxy on ACDS to another local ATM. |


**1.4.28.5** **(12-12-2024)**

### Appeals Team Manager Duties and Responsibilities

1. Managers’ timely, ongoing, accurate review of their employees’ work is one of the most important duties of a manager. Providing ongoing, candid, and meaningful employee feedback is essential to employee satisfaction. Many potential problems can be caught and corrected in their initial stages before they become a significant issue when reviews are completed timely on an ongoing basis. This is an integral part of an ATM's responsibilities.

2. Managerial reviews of employee work allows the manager to:



1. Assess the employee's effectiveness in meeting expectations established in their critical job elements (CJEs)

2. Determine the employee's efficiency in carrying out the laws, procedures, and policies of the IRS

3. Identify and acknowledge exceptional work

4. Identify and address performance problems

5. Evaluate the employee's ability to properly plan and schedule office and telework activity

6. Ensure the employee is taking timely and appropriate actions to bring the case to prompt and proper resolution

7. Assess employee effectiveness in developmental case assignments

8. Ensure correspondence is sent to the appropriate parties and reinforce the importance of power of attorney involvement in case activities\*


\\* _This item is not applicable for AARS ATM_

3. To ensure better engaged and informed managers in Appeals; meaningful review and discussion of targeted case assignments, followed with written evaluative feedback, must happen throughout the rating year. As part of this feedback, ATMs should complete both workload reviews and live/closed case reviews during their review of each employee’s work.


**1.4.28.5.1** **(12-30-2019)**

#### Right of Consultation

1. ATMs should ensure that their employees properly adhere to IRC 7521(b)(2), Right of Consultation, and IRC 7521(c), Representatives Holding Power of Attorney, pertaining to the taxpayer's right to consultation and power of attorney authorization. ATMs should include this item in case reviews to ensure ATEs are involving representatives in all case actions. Taxpayers are afforded the right to designate a qualified representative to act on their behalf when interacting with the IRS. IRS employees are required to stop an interview if the taxpayer requests to consult with a representative and may not bypass a representative without supervisory approval. See IRM 8.6.1.5.3, Right of Consultation with Representative, and IRM 8.6.1.5.3.3, Bypass of a Representative, on the ATM’s role where a recognized representative has unreasonably delayed or hindered the appeal process.

2. The ATM should also ensure that employees adhere to the requirements of IRC 6304 , Fair Tax Collection Practices, in their communications with taxpayers in connection with the collection of any unpaid tax. See IRM1.4.28.5.2, Restricted Contact with Taxpayer.


**1.4.28.5.2** **(12-30-2019)**

#### Restricted Contact with Taxpayer

1. A taxpayer's right to representation is protected under the fair tax collection practices found in IRC Section 6304(a)(2). Without prior consent of the taxpayer given directly to an employee, or the express permission of a court of competent jurisdiction, the employee is prohibited from communicating with a taxpayer in connection with the collection of any unpaid tax, if the employee knows the taxpayer is represented by any person authorized to practice before the IRS with respect to such unpaid tax. Contact is also prohibited if the employee has knowledge of, or can readily determine the authorized representative’s name and address, unless the authorized representative fails to respond within a reasonable period of time to a communication or consents to direct communication with the taxpayer. See IRM 8.6.1.5.3.3, Bypass of a Representative.



### Note:



Contacting a taxpayer to update or validate representation when all periods are not listed on Form 2848, Power of Attorney and Declaration of Representative, does not constitute a violation of taxpayer rights nor does it constitute a bypass procedure because the taxpayer is not represented with respect to the unresolved periods.

2. During a case review or upon receiving a complaint from a taxpayer, managers may identify a potential violation of the restrictions under IRC Section 6304. The manager must report potential employee violations of IRC Section 6304 to the area director by the close of the next business day following the identification of the potential violation. If the area director concurs, the area director will report the violation to Labor Relations (LR) by the close of the next business day following the notification of the alleged violation. If the violation is confirmed, the area director will work with a LR Specialist to determine the next appropriate action.


**1.4.28.5.3** **(04-19-2016)**

#### Workload Reviews

01. Workload reviews, when combined with live/closed case reviews, are the best tools available to a manager when evaluating case management practices and work habits of Appeals personnel.

02. Managers will do a minimum of one workload review per year; preferably at mid-year, which will focus on case management issues such as imminent statutes, overage cases, significant time on case and cases with no conference or no activity for an extended period of time. This review should also help you identify exemplary casework, good workload management skills and employee strengths. The review can also confirm workload issues, calendar management skills and areas of training needs for the manager’s employee and team.

03. More frequent reviews are necessary when serious performance deficiencies and a need for development are identified.

04. Generally, the tools in conducting a workload review are the CAR, time report, the Appeals case summary cards, copy of the prior workload review report, if any, discussion with the employee and live case reviews.

05. The primary objective of a workload review is for the manager to gain a specific understanding of the status of each work unit in an employee's inventory. Workload reviews, when properly conducted, involve a substantial amount of time. This will be time well spent as it gives the manager insight into each employee's work habits, case management practices, technical abilities and identifies areas where training and development are needed. It provides managerial insight as to the exact status of each employee's inventory and gives the manager a basis for frequent but quick follow-up. Strengths and weaknesses in performance are clearly identified with specific examples. A workload review also offers an opportunity to give specific guidance and direction with respect to specific management practices and technical abilities.

06. A workload review enables the manager to evaluate and give feedback on how well an employee is managing inventory by appraisal of the following factors:



    01. Adequate initial review of new work units

    02. Adequate statute procedures and documentation

    03. Adequacy of inventory

    04. Units being worked on a first in, first out (FIFO), basis except when priorities dictate otherwise

    05. Overall workload planning

    06. Prompt conferences\*

    07. Conference preparation (for prompt decision and to minimize number of conferences)\*

    08. Additional information requested, whether actually needed, timely target dates for its submission established

    09. Timely follow-up, follow-up control

    10. Prompt decisions reached\*

    11. Prompt submission of work unit for review\*

    12. Accumulated time-in-process in total and on individual work units (in relationship to the status of the work unit)\*

    13. A workload review helps the manager identify whether the employee is maintaining communications with the taxpayer, keeping the taxpayer aware of their options and appropriately including their representative in all communications\*



        ### Note:



        Managers are to monitor this on all non-docketed cases that remain in inventory over one year.


\*This item is not applicable for AARS ATM


07. In addition to the above, a workload review enables the manager to make judgments concerning an employee's:



    1. Overall workload planning ability

    2. Application of technical and procedural guidelines

    3. Effective use of time

    4. Efficient travel habits\*

    5. Compatibility of work with grade\*

    6. Need for special advice and assistance


\\* This item is not applicable for AARS ATM


08. A workload review also offers an opportunity for:



    1. Early identification of unagreed units\*

    2. Identification of units on which a decision is needed

    3. Resolution of unwarranted case closing delays

    4. Curtailment of repeated contacts for piecemeal development of facts

    5. Establishing priorities

    6. Verification of the grade of the work unit\*

    7. Determining if the employee's workload is appropriately balanced in regard to time spent working on units below, at, and above their grade level\*

    8. A forum for discussion of the employee’s career goals and career learning plan (CLP)


\\* This item is not applicable for AARS ATM


09. Following a workload review, the manager should promptly give the employee their written analysis and summary. Cite specific instances of exemplary performance or weaknesses in performance. Clearly state guidance and direction. Set out any agreements between you and the employee with respect to specific action, target dates and overall performance.

10. Have the employee acknowledge receipt of the memorandum or any other document summarizing the results of the workload review by initialing the manager's copy.


**1.4.28.5.4** **(04-19-2016)**

#### Workload Review Preparation

1. The initial preparation for the workload review can be done in advance. This includes a worksheet listing all work units in the employee's inventory, setting out the following information for each work unit:



1. Name of key taxpayer

2. Date assigned

3. Number of cases

4. Deficiency (overassessment)\*

5. Accumulated time

6. Initial conference date\*

7. Closed case referral acknowledgement provided timely (applies to AARS ATM only)

8. Status of the work unit

9. Statute of limitations dates


\\* This item is not applicable for AARS ATM


2. The information required in paragraph (1) above is obtainable from the employee's most recent time report and the ACDS case inventory screen. Obtain additional information for the workload review from the "Diagnostic and Balanced Measures" (D&BAM) database, ACDS statute listings and AdHoc reports. Make sure the work sheet provides space for the manager to make notes during the live case review.

3. The worksheet described in paragraph (1) above could be the foundation, at the conclusion of the workload review, for the memorandum to the employee. Set out any brief discussions of each work unit reviewed, including the information itemized.

4. Whenever possible, a manager may use ACDS to document reviews. The manager can then use ACDS to document and share workload and live case reviews and conference observations with their employees.



### Note:



Guidance in paragraphs (2), (3) and (4) above does not apply to AARS ATM.


**1.4.28.5.5** **(08-15-2017)**

#### Live Case Reviews

01. A live case review is a review conducted by a manager before the employee submits a work unit for approval, but generally after the employee has had an opportunity to make significant progress with the work unit.

02. A closed case review is a review conducted by a manager after the employee has submitted a work unit for approval. See _IRM 1.4.28.8.2_, Closed Case Work Reviews.

03. The following lists the minimum number of live (open) and/or closed case reviews required each year by employee grade level. The mix of reviews conducted annually is at the discretion of the manager.



    - GS 7/9/11/12 Appeals officers and Appeals account resolution specialists - seven cases reviewed per year

    - GS 13 Appeals officers - five cases reviewed per year

    - GS 14 Appeals officers - three cases reviewed per year


04. The grade (case difficulty) of the case selected for these reviews should be the same as the grade level of the employee being reviewed. See case grading exhibits at the end of this IRM starting with _Exhibit 1.4.28-1_.

05. Where there are observed deficiencies in case work performance, whether related to timeliness or decision quality, the manager will review additional cases beyond the required number noted above sufficient to impact improvements or to support rating reductions.

06. The scope of these evaluative reviews will be limited to a simple affirmation next to each performance standard that it has been met. Additional supporting narrative will only be required when a standard is not met, or when it has been exceeded.



    ### Note:



    It is important that noteworthy accomplishments are documented, as well as failures, to meet standards of performance. The reviews should encompass comments which document all of the critical elements for the employee.

07. A thorough live case review gives a manager an in-depth view of the employee’s work habits that cannot be obtained during normal review of the case file at closing. A live review during the time a work unit is in process also saves review time at closing.

08. The use of ACDS to document workload and case reviews (open and closed) is encouraged.

09. If ACDS is not used to document the review, prepare a memorandum briefly setting out the following with respect to each work unit reviewed:



    01. Work unit number (WUNO)

    02. Date assigned

    03. Number and dates of conferences

    04. Time (hours) to date

    05. Tax and penalties in dispute

    06. Major issues and status

    07. Case management (prompt contact, prompt conference)

    08. Adherence to power of attorney requirements

    09. Rough draft of the Appeals Case Memo (issues framed properly: facts, law and argument adequate, questions set forth)

    10. Work papers filed in chronological order

    11. Conference memo (if appropriate)

    12. Specific target dates set

    13. Follow-up made

    14. Progress towards settlement (a proposal by taxpayer, proposal by ATE, ATE's settlement position known by taxpayer)

    15. Time commensurate to work performed

    16. Other information and observations

    17. Agreements between employee and manager with respect to future action


10. Have the employee acknowledge receipt of the memorandum or other document summarizing the results of the live case review by initializing the manager's copy. This can be done electronically if ACDS is used for the live or closed case review.

11. The AARS ATM performs a _priority review_ in place of a live case review based on inventory prioritization needs and cases requiring special attention. For additional information, see _IRM 1.4.28.5.6_, AARS ATM Priority Review.


**1.4.28.5.6** **(08-15-2017)**

#### AARS ATM Priority Review

1. The AARS ATM performs priority reviews which also serve as a modified workload review based on the following guidelines:



   - Cases older than 60 days

   - Cases 30 - 59 days old - discuss as necessary

   - Cases with missed follow-up dates

   - Random statute review on open inventory to include assessment, collection, and refund statute expiration dates - as appropriate to the case type

   - Transcripts of taxpayer accounts related to the selected case(s)


2. The AARS ATM provides written documentation of the items reviewed and includes the following information:



   - Examples of exemplary performance or weaknesses in performance

   - Clearly stated managerial guidance and direction as applicable

   - Set out any agreements between the manager and employee with respect to specific actions, target dates and overall performance expectations

   - Document special activities \[e.g., collateral duties, on-the-job instructor (OJI) activities, team workshop presentations, developing or reviewing training material, or assisting team members with inventory management and case closing\]


3. The AARS ATM will provide the employee with the written priority review within 15 workdays of completing the review.

4. The AARS ATM will set a meeting date and time to discuss the priority review document with the employee and, upon conclusion of the meeting, request the employee sign the document which then becomes part of the employee performance file (EPF).


**1.4.28.6** **(04-19-2016)**

### Conference Observation

1. Periodically, the ATM may evaluate the ATE’s performance during a conference. Factors to observe include the following:



01. Conference preparation

02. Exchange of information

03. Open discussion

04. Appearance of impartiality

05. Discussion of proposed settlement

06. Solicitation of settlement proposal

07. Action on proposal

08. Additional information, documentation needed

09. Who will take the next action

10. When is it to be accomplished


2. Give the employee feedback with respect to the conference performance promptly afterwards, concentrating on strengths and need for improvement.

3. The AARS ATM performs a live call review in place of a conference observation. See _IRM 1.4.28.6.1_, AARS ATM Live Call Review, below for additional information.


**1.4.28.6.1** **(04-19-2016)**

#### AARS ATM Live Call Review

1. Periodically, the AARS ATM will observe a live customer service call to review the AARS employee’s preparation for the call and performance during the call. Factors to observe include:



01. Preparation for the call

02. Adherence to security and disclosure guidelines

03. Exchange of information

04. Engagement to facilitate an open discussion

05. Clarity and appropriateness of communication

06. Appearance of impartiality

07. Identification of issue(s)

08. Application and analysis of relevant technical and procedural information

09. Technical and procedural information shared in a strategic and productive manner (as appropriate) to fully address the customer’s inquiry

10. Identification of additional information and/or documentation needs

11. Discussion of proposed timeframe for resolution

12. Consideration of taxpayer’s rights and resolution of taxpayer’s concerns

13. Duration of the call is commensurate with the items identified and addressed

14. Documentation of the call interaction and relevant facts


2. The AARS ATM will provide the employee with written documentation of the live call review within 15 workdays. The documentation is written in relation to the applicable CJEs and aspects and once signed by the employee becomes part of the EPF.


**1.4.28.7** **(12-12-2024)**

### Overall Control of Work

1. In addition to controlling work in the hands of ATEs and AARS employees, managers also control work performed by the following:



1. APS TE teams, headed by a PTM (see _IRM 1.4.28.13_)

2. TCS teams, headed by an ATCTM (see _IRM 1.4.28.8.5_)

3. STARS personnel, under the control of a team manager (see _IRM 1.4.28.8.6_)


2. Operational reviews are a major means available to ensure efficient operation of the support areas.

3. An important task of the reviewing administrative personnel or other designee is to conduct a _procedural review_ of case files before submission to the manager for technical review. Spot check the quality of the procedural review and the quality of the computation during the manager's technical review of the case file. Sometimes feedback from ATEs gives a good clue as to whether or not the TCS area is operating efficiently. Frequently, indications of how efficiently APS is processing cases is determined at the time units are assigned.



### Note:



This guidance does not apply to the AARS ATM.


**1.4.28.8** **(08-15-2017)**

### Case Work Reviews

1. Taxpayers, their representatives, Compliance personnel, and the IRS as a whole look to Appeals to render decisions based on the facts, judicious application of IRS policy and sound legal principles.

2. Delegation Order No. 8-8 (Rev. 1) delegates settlement authority to ATMs and ATCLs. ATMs’ settlement authority may not be redelegated to their ATEs. The non-ATCL ATE's proposed settlement is only a recommendation. The ATM has the authority and responsibility to accept their ATE’s proposed settlement by signing Form 5402, Appeals Transmittal and Case Memo, or reject the settlement. The ATM must be assured of the quality of the ATE's decision and recommendation. Accomplish this through review of the settlement memorandum and case file, prior knowledge of the case during the negotiation process, or knowledge of the ATE's technical expertise and quality of decisions.



### Note:



Delegation Order 8-9 delegates settlement authority to ATCLs and ATEs in Fast Track Settlement cases; ATMs do not sign Form 5402.

3. The ATM must sign Forms 5402 for all work units except for where it is otherwise provided in the IRM. For cases worked in ATCL Operations, the ATCL team manager (ATCLTM) must sign Form 5402 confirming the ATCLTM reviewed and has no proposed changes to the settlement.

4. Case work review provides one of the best means of evolving a day-to-day evaluation of an ATE's performance. More importantly, it gives the manager continuously updated data on strengths and weaknesses for use in training, motivating through job enrichment, and otherwise helping the employee develop maximum potential. It provides facts to use at rating time, as opposed to impressions gained from recent sampling of work performance. When reviewing a case, be alert to areas of weakness in an employee's handling of cases, which should be corrected through discussion or further training, as well as the employee's strengths and abilities.

5. Recognize that the majority of issues referred to Appeals are controversial and rest upon judgment and opinion on which reasonable and honest people may hold divergent views. The manager, as reviewing official in striving to ensure high-quality decisions, ordinarily will not substitute personal judgment for that of the ATE when the decision is fairly supported by facts and applicable law. If the manager’s review shows that the ATE understands and correctly applies Appeals’ basic settlement philosophy as set forth in IRM 8.6. Conference and Settlement Practices, the ATE's conclusions resting on judgment will ordinarily be accepted. If in the manager’s judgment the proposed settlement is not supported and is inappropriate, however, or if it would result in inconsistencies, the manager must reject the settlement.

6. In a case in which there is a verbatim recording of the proceedings and a potential conference performance problem is identified, the manager may wish to listen to the tape(s) to determine whether counseling or training of the employee is necessary. Make disciplinary actions or evaluations of performance involving a verbatim recording of a conference in accordance with current IRS-union agreements. Consult with the LR specialist. You must also determine whether to have a transcript made of appropriate portions of the recording in case later access to it becomes necessary as provided for in any current union contract.

7. For AARS case review guidance, see _IRM 1.4.28.5.6_, AARS ATM Priority Review.


**1.4.28.8.1** **(08-15-2017)**

#### Extent of Case Work Reviews

01. The ATM must make a review of sufficient depth to assure the correctness of the action proposed. Judgment must be exercised, however, in determining the scope of the review activity. ATMs are expected to know their staff and adapt the depth of review to what is actually needed. For example, close review is needed for new employees, those with identified performance deficiencies, and employees going into new areas of marked increased difficulty. Some work of all employees should be comprehensively reviewed on a random basis. Tailor the degree of review to the ability of the employee and the characteristics of the specific case.

02. A comprehensive review includes technical and procedural accuracy as well as case management practice and adherence to Appeals' objectives and policy statements. Documents to be inspected in a comprehensive review include:



    01. Transmittal memorandum (Customized Form 5402, Appeals Transmittal and Case Memo)

    02. Settlement memorandum

    03. Agreement documents

    04. Closing agreements

    05. Contracts and other supporting documental evidence

    06. Revenue agent's or revenue officer's report (special agent's report, if any)

    07. Returns

    08. Power of attorney

    09. Correspondence

    10. Conference memos

    11. Affidavits

    12. Protest

    13. Notice of deficiency and petition (if docketed)

    14. Revenue agent's, revenue officer's, and ATE's workpapers

    15. Applicable statutory and case law

    16. Case summary cards

    17. ATE inventory and unit time report

    18. Case activity record (CAR)


03. Additional information regarding possible material to be reviewed is provided in this IRM.

04. Notify the employee in writing when exemplary performance or a deficiency in performance is identified during a case review. Place copies of such documentation in the EPF.

05. Generally the ATM reviews cases submitted by employees under the ATM’s supervision. However, in rare instances, such as when the ATM’s workload is very heavy, selected cases may be assigned to an ATE for preliminary review. The ATM remains responsible for the correctness of the conclusion.

06. Review functions are necessary to ensure accuracy in transmittal memoranda, supporting statements, and related materials. Such a review could range from verification of format, caption data and grammar to soundness of determination of tax liability. Many of these functions can, and should, be handled by clerical personnel.

07. It is important that review of cases occur promptly upon submission by the employee. This is a continuation of the attitude of experience and good case management expected of Appeals employees. If it is an agreed case, proposed assessment or overassessment, it is incumbent upon the IRS to have the tax assessed and to process refunds for overassessments as promptly as possible in order to stop the accrual of interest. See IRM 8.2.1.10.1, Expedite Processing for Certain Large Dollar Cases, and IRM 8.7.7.14, Expedite Closing of Large Dollar Examination-Sourced Overpayment Cases.

08. For agreed collection cases, prompt case review is very important for timely processing installment agreements, offers in compromise, updates to currently not collectible (CNC) status, and input of account adjustments.

09. Prompt review of unagreed collection type cases is also critically important to ensure the timely issuance of determination letters so that cases can be resolved as soon as possible and returned to Collection for enforcement actions, if appropriate.

10. For AARS case review guidance, see _IRM 1.4.28.5.6_, AARS ATM Priority Review.


**1.4.28.8.2** **(08-15-2017)**

#### Closed Case Work Reviews

1. Prepare closed case evaluations on a random or systematic basis (every xth case), consistent with area policy and the ATE’s performance and experience level. Specific cases will also be selected for review as determined by the ATM.



### Note:



See _IRM 1.4.28.5.5 (3)_, Live Case Reviews, for the minimum number of live (open) and/or closed case reviews required each year by employee grade level.

2. Once the ATM approves the "recommended disposition" of a case selected for evaluation, the ATM may utilize ACDS to prepare the closed case review. The ACDS format allows rating of individual aspects of each CJE and provides space for narrative for each aspect.

3. When the ATM does not approve a settlement recommendation in certain pre-90-day, 90-day and agreed 90-day income tax cases, the taxpayer may be entitled to a conference with the ATM. See IRM 8.2.1.9.2, Reviewing Official's Rejection of Settlement Proposal.



### Note:



Cases worked in ATCL Operations are not subject to the provisions in IRM 8.2.1.9.1, Reviewing Official’s Acceptance of Settlement Proposal, and IRM 8.2.1.9.2, Reviewing Official’s Rejection of Settlement Proposal, and the related subsections regarding a reviewing official’s approval or rejection of the ATCL’s settlement proposal.

4. Case evaluations must address specific facets of the performance, tying the description and evaluation of the performance to the aspects of the ATE’s position. See IRM 8.6.2, Appeals Case Memo Procedures.

5. Written case reviews must be shared with the employee according to the provisions of the IRS/NTEU contract.

6. For additional information, see _IRM 1.4.28.8.3_, AARS ATM Closed Case Review.


**1.4.28.8.3** **(04-19-2016)**

#### AARS ATM Closed Case Review

1. The AARS ATM will perform a random review of closed cases. Items to review include:



01. Adherence to security and disclosure guidelines

02. Clarity and appropriateness of written communication

03. Appearance of impartiality

04. Identification of issue(s)

05. Technical and procedural application and analysis

06. Strategically informing the customer of technical and procedural information related to their inquiry

07. Timeliness of actions

08. Additional information, documentation needed

09. Taxpayer rights and concerns were considered and addressed

10. Time span is commensurate with the items identified and addressed

11. Documentation of actions and relevant facts


2. The AARS ATM will provide the employee with written documentation of the closed case review within 15 workdays. The documentation is provided in relation to the CJEs and aspects and once signed by the employee becomes part of the EPF.


**1.4.28.8.4** **(04-19-2016)**

#### Correspondence Reviews

1. ATEs are authorized to sign, in their own names, certain correspondence such as scheduling conferences, transmittal or agreement forms, forwarding consent forms, etc. Routine correspondence authorized to be signed by ATEs in their own names need not be reviewed by or for managers. "Spot check" these for quality after mailing.

2. Review correspondence prepared for signature of a manager to ensure it is courteous, clear, concise, and is promptly handled.

3. Area directors should personally review replies to certain types of correspondence, such as congressional letters, taxpayer complaint letters, dissenting memoranda and Headquarters' inquiries.



### Note:



This guidance does not apply to the AARS ATM.


**1.4.28.8.5** **(08-15-2017)**

#### Work of Tax Computation Specialists (TCS)

1. In general, limit your review of settlement computations, notices of deficiency, and Rule 155 computations prepared by TCS to verifying correctness of legal applications. Examine statements involving unusual audit features for technical accuracy and from time to time randomly select samples for more intensive review. Unusually difficult or complicated settlement computations and notices may occasionally need comprehensive review.

2. Maintain an evaluation of TCS's work in the employee’s EPF.

3. Appeals has developed specific case grading criteria for assigning TCS work. Access this case grading guide by clicking on “Procedures and Resources” on Appeals’ SEPR TCS intranet page. The exhibit is not all inclusive:



1. "Simple" cases are typically of limited scope and complexity, requiring limited judgment and decision-making.

2. "Complex" cases typically require considerable judgment and knowledge to interpret and apply tax law and related case documents.

3. A lack of clear guidelines and precedent-setting cases often require extensive research and special knowledge.


4. The grade (case difficulty) of the case selected for these reviews should be the same as the grade level of the employee being reviewed.


**1.4.28.8.5.1** **(08-15-2017)**

##### Case Reviews of Tax Computation Specialists

01. TCS managers should conduct sufficient case reviews to provide adequate feedback to and document performance of their employees. The reviews can be in the form of:



    1. Live case review - A review conducted by a manager before the employee returns the work request to the requestor, but generally after the employee has had an opportunity to make significant progress with the work unit

    2. Closed case review - A review conducted by a manager after the employee has completed the work on the request


02. The mix of live or closed reviews conducted annually, as well as the extent of review, is at the discretion of the manager. Judgment must be exercised, however, in determining the scope of the review activity. Managers are expected to know the staff and adapt the depth of review to what is actually needed. For example, closed case review is needed for new employees, those with identified performance deficiencies, and employees going into new areas of marked increased difficulty.

03. Tailor the degree of review to the ability of the employee and the characteristics of the specific case. For example, a manager may choose to:



    1. Review the Form 3623, Statement of Account

    2. Review the Form 2285, Concurrent Determinations of Deficiencies

    3. Review the Sequa worksheet

    4. Conduct a procedural review

    5. Conduct a comprehensive review


04. The following lists the minimum number of live or closed case reviews required each rating year by employee grade level:



    1. GS 7/9/11 TCS - five cases reviewed per rating year

    2. GS 12 TCS - four cases reviewed per rating year

    3. GS 13 TCS - three cases reviewed per rating year


05. The minimum number of case reviews may be reduced further with the area director’s approval. Examples of situations where a reduced review may be warranted are when an employee is:



    1. On an extended absence, detail or special assignment, or

    2. Highly experienced and skilled, such as a Grade 13 TCS that works complex life insurance cases


06. When appropriate, such as when the manager’s workload is very heavy, selected cases may be assigned to a TCS for preliminary review. The manager remains responsible for the correctness of the conclusion.

07. Managers should use ACDS to prepare the case review. The ACDS format allows rating of individual aspects of each CJE and provides space for a narrative for each aspect.

08. The scope of these evaluative reviews will be limited to a simple affirmation next to each performance standard that it has been met. Additional supporting narrative will only be required when a standard is not met, or when it has been exceeded.



    ### Note:



    It is important that noteworthy accomplishments are documented, as well as failures to meet standards of performance.

09. Where there are observed deficiencies in case work performance, the manager will review additional cases beyond the required number noted above sufficient to impact improvements or to support rating reductions.

10. Have the employee acknowledge receipt of the memorandum or other document summarizing the results of the case review by initializing the manager’s copy. This should be done electronically if ACDS is used for the live or closed case review.



    ### Note:



    If the employee is offsite, attach the case review to an email and send it to your employee with a "read" receipt. Have the employee sign the case review electronically.

11. Include a copy of the finalized case review in the employee’s EPF.


**1.4.28.8.6** **(12-12-2024)**

#### Shared Team of Administrative & Redaction Support (STARS)

1. Shared Team of Administrative & Redaction Support (STARS) employees provide administrative and redaction support to all areas of the Appeals organization. STARS teams include case processors, administrative support assistants, administrative officers, and case redaction specialists (government information specialists). STARS team managers are first level supervisors responsible for directing and reviewing their employees’ work, planning, scheduling and coordinating work operations, planning and carrying out the training and development of employees, and evaluating employees’ work performance. STARS area managers are the second level managers, who report to the STARS director.

2. Case processors and administrative support assistants are responsible for their local office duties (for example: receiving/distributing mail, mailing correspondence and cases, photocopying/faxing documents, answering the door, greeting and escorting visitors, maintaining the office supply inventory, overnighting checks, monitoring shred/burn bins, and supporting the maintenance of office equipment. Other administrative support duties are equitably distributed among team members by STARS managers and lead case processors through a SharePoint-based assignment system.

3. Case redaction specialists are responsible for reviewing and redacting taxpayer case file documents to be released to taxpayers, as requested by the ATE.

4. Visit Appeals’ STARS intranet page for more information on the STARS employees’ duties and responsibilities, along with guidance for requesting STARS’ services.


**1.4.28.9** **(08-15-2017)**

### Guidelines for Determining the Grade Levels of Appeals Work Units

1. The grading of an Appeals work unit is based on the complexity and difficulty of the case. The manager considers criteria such as the degree of factual complexity and legal complexity of the issues, the impact/sensitivity of the case and the conference/negotiating skills required by the case. For case grading factors based on ATEs’ position descriptions, see the following:



   - _Exhibit 1.4.28-1_, Case Grading Factors to Consider for Examination Sourced Cases

   - _Exhibit 1.4.28-2_, Upgrading Examination Sourced Cases - Considerations

   - _Exhibit 1.4.28-3_, Downgrading Examination Sourced Cases - Considerations

   - _Exhibit 1.4.28-4_, Case Grading Matrix for Collection Sourced Cases

   - _Exhibit 1.4.28-5_, Case Grading Matrix for Art Appraisal Services Cases


### Note:

All work units involving Employee Plan or Exempt Organization issues are graded 13, unless application of the criteria in the appropriate exhibits warrant another grade.

2. Appeals has developed specific case grading guidance for penalty appeals and innocent spouse cases. The information is accessible under the **Guidelines** section of Appeals’ Manager Resources intranet page.



### Note:



These guidelines do not apply to cases assigned to AARS team members.


**1.4.28.9.1** **(12-12-2024)**

#### Relationship of These Guidelines to Position Management

1. These guidelines do not supersede the Office of Personnel Management (OPM) classification standards. Position classification factors such as supervision and guidance cannot be measured by these guidelines.

2. Appeals employees may be assigned some work units above their grade level for developmental purposes. Such experience is considered to be at the higher level if normal supervision is given. However, when assignments above the grade level of the employee are completed under closer than normal supervision, the assignment is considered to be consistent with the employee's grade. The assignment of higher or lower grade work units does not affect the grade level of an employee's position if it is for short periods to provide developmental opportunities or to meet specific operational needs. See IRM 6.511.1.6.4.5, Assignment of Higher Graded Work.

3. Grade levels of positions are not based solely on grade levels of work units assigned; other factors are considered, such as degree of supervision received and personal contacts.

4. Appeals managers are responsible for:



1. Assigning work consistent with an employee's grade level

2. Keeping developmental assignments within reasonable limits and

3. Informing an employee of the distinctions between the work unit grades and position grade


5. Position classifiers are responsible for:



1. Making the final determinations on the position grade levels,

2. Providing advisory services to Appeals' managers on position management and work assignment practices, and

3. Assisting Appeals management in determining that case grades accurately reflect the relevant OPM standards and that the grade structure is appropriate for the workload of the Appeals employee.


### Note:

See IRM 1.2.2.7.16, Delegation Order 6-26, Authority to Classify Positions in the Internal Revenue Service, to identify position classifiers.

6. If the ATM decides that a systemically assigned grade level should be lowered, the ATM will make an entry in the activity record and document the reasons for the lower grade level. In accordance with the National Agreement between the IRS and NTEU, the manager will also send an email to the employee assigned the case informing him/her of the reasons for the lower grade level. See Article 25 - Workload Management, Section 1, of this agreement in Document 11678.


**1.4.28.10** **(12-12-2024)**

### Referrals to Appeals Technical Guidance, International Operations, and TEGE

01. Appeals Technical Guidance and International Operations ensure nationwide uniform and consistent settlement of issues, enhances the identification and timely resolution of issues, and provides coordination for technical issues. See IRM 8.7.3 , Domestic and International Operations Programs.

02. The following issues are referred to Technical Guidance and/or International Operations. The appropriate ACDS feature code to input to ACDS is indicated after each issue. If the feature Code is not in the ACDS case record, the ATE will input the code when the referral is made for a technical guidance specialist.



    1. Appeals coordinated issues - Input feature code "AI"

    2. Appeals coordinated issues with review and concurrence - Input feature code **AI**

    3. Abusive tax avoidance transactions - Input feature code "LT" (listed transactions)


03. Appeals International Operations provides coordination and expertise to management and ATEs for international issues.



    1. Cases with these issues also need to have feature code "IC" (international case) input to ACDS.

    2. The definition of international issues (including coordinated and non-coordinated issues) can be found on Appeals’ SEPR **INTERNATIONAL OPERATIONS** intranet page. Click on What are international issues? for the definition and examples of international issues and the requirement for the referral of all cases containing international issues.


04. Appeals Technical Guidance also receives referrals regarding:



    1. Economist issues

    2. Engineering issues

    3. Financial products issues


05. The ATCL/TL must prepare the referral whether or not any of the above issues are being considered for assignment to a team member or retained by the ATCL/TL. Coordination by the Technical Specialist will continue in accordance with IRM 8.7.3, Domestic and International Operations Programs.

06. For information on requesting valuation assistance in Estate and Gift (E&G) tax cases, see IRM 8.7.4.7.1, Referrals for Art Appraisal Services, and IRM 8.7.4.7.2, Referrals for Engineering and Economist Services.



    1. The ATE **must** request valuation assistance by Art Appraisal Services (AAS) for any single work of art with a claimed value per return of **$50,000 or more** with respect to which Exam has raised a valuation issue. See IRM 4.48.2.3, Criteria for Requesting Art Appraisal Services Assistance.

    2. The ATE **must** request engineering assistance in the following circumstances:


        \- The examination report proposes any single valuation adjustments of $10 million or more; or


        \- The examination report proposes two or more valuation adjustments that, in the aggregate, amount to $20 million or more.


07. Refer all TEGE issues, including Employee Plans (EP), Exempt Organizations (EO), Tax Exempt Bonds (TEB) and Government Entities (GE), to the Appeals TEGE ATM in accordance with IRM 8.7.8 Tax Exempt and Government Entities (TE/GE) Cases. The TEGE referral procedures can be accessed from the SEPR Technical Guidance intranet page.

08. As soon as possible after assignment, ATMs will forward via email referrals (using Form 13381, Appeals Technical Guidance Referral) with any issue(s) or case assignment recommendations to the appropriate TG ATM. Enter "Referral" or "Form 13381" in the email subject line, the taxpayer's name or WUNO on the form and encrypt the email and all attached files where warranted.



    ### Note:



    Technical Guidance, International, and TEGE assistance includes team member assignment, direct case assignment or consultation. A Technical Specialist or ATE from one of these areas may be requested as a consultant when he/she is used solely to discuss issue(s). However, once the consultant is expected to negotiate, work or otherwise be responsible for an issue(s), re-designate him/her as a team member. If no assistance is needed, provide the reason(s) in the appropriate block on Form 13381.

09. Forward international referrals to the respective ATM indicated in the coverage maps. See the Team Organization Chart and Contact Information, accessible from the SEPR Area 11 International intranet page.

10. The receiving TG ATM determines the level of assistance to be provided based on all available facts including existing workload.

11. Generally within five workdays, (sooner, if required), the TG ATM will make the assignment determination.

12. The receiving TG ATM returns the completed referral as an attachment via encrypted email to the requesting ATM for association with the case file. At closing, the ATE attaches the referral to Form 3608, Request for TCS Service.


**1.4.28.11** **(12-30-2019)**

### Direct Shipment of Cases to Account and Processing Support

1. This section contains mandatory procedures for ATMs to directly-ship closed cases to APS. It establishes the responsibility for ensuring these cases properly ship from a post-of-duty to a designated APS office.

2. **Appeals Team Manager inputs ACAPDATE**


    When an ATM inputs an ACAPDATE, he/she will be asked a series of questions on the ATM closing screen including the reasons why the case is going to APS:



1. Closing

2. SND

3. STIPFF

4. Trial Prep

5. Transfer


Depending on the answers given and physical location of the ATM approving the case, ACDS will automatically populate the name and address of the PTM who should receive the case.



3. **ACAPDATE Already Present**


    If the ACAPDATE is already present on ACDS, the system automatically detects the appropriate PTM, without having to answer additional questions. In addition, the following fields populate automatically:



1. Action Code "Shipped"

2. To Date

3. POD to which case is being shipped


4. **Appeals Team Manager has Case**


    When the ATM is co-located with a case processor and has physical possession of the case, the case processor has primary responsibility for shipping it to APS. However, each POD should designate a back-up who will be responsible for shipping cases when the primary designee is out of the office or when the volume of closings is high in that POD. The only time APS has primary responsibility is when the ATM is not co-located with a case processor.



### Note:



An ATM or other responsible person (i.e. case processor, ATE, etc.) will ship the closed case to APS as soon as possible, usually on the same or next business day as the ACAPDATE. This will ensure that APS receives the case before it is considered delinquent, which requires APS to follow-up with the ATM. See IRM 8.20.10.6.3, Processing Employee Automated Systems (PEAS) Alert Form, to determine when a case with an ACAPDATE is considered delinquent.

5. **Table of Responsibility**


    The following table provides details to help determine who has responsibility for shipping the case:



**Appeals Team Manager with Physical Possession of Case**






| **ATM co-located with** | **Primary shipping responsibility** | **Secondary or backup shipping responsibility** |
| :-- | :-- | :-- |
| - Case processor<br>     <br>   - APS | Case processor | APS |
| - APS | APS |  |
| - No case processor or APS | Current procedures remain in effect |  |

6. **Appeals Team Manager _Does Not_ have Case**


    If an ATM **does not** have physical possession of the closed case at the time of approval, he/she may authorize the ATE, who does have physical possession, to facilitate shipment directly to the appropriate APS unit. The ATM will print the screen showing the PTM shipping information and provide it to the ATE or case processor responsible for shipping the case. Use the table above to determine who is responsible for shipping the case from the POD.

7. **Rules That Apply:**



1. The ATM must use this process for every type of case identified in _IRM 1.4.28.11 (2)_ above.

2. Other case processors include those assigned to Headquarters or other specialty groups within Appeals.

3. Local APS only has responsibility when there are no case processors in the POD.

4. All employees responsible for shipping cases will prepare and monitor Form 3210, Document Transmittal (For more information on Form 3210 follow-up actions, see paragraph 5 of IRM 8.20.10.6.3 , Processing Employee Automated Systems (PEAS) Alert Form.


8. **Director, APS Responsibility**


    The APS director will maintain the table used by ACDS to identify the appropriate PTM and work streams.

9. **All Managers Responsibility**


    Appeals managers, senior operations advisors, and technical advisors should work together to address shipping needs in each POD. In addition, they should ensure all remote employees are familiar with procedures pertaining to their particular location.


**1.4.28.12** **(08-15-2017)**

### Timely Processing of Remittances

1. Appeals management must ensure every office with Appeals employees has suitable procedures in place for the timely identification and processing of remittances in accordance with IRM 8.7.17, Appeals Remittance Procedures. Some considerations may include:



1. Designating specific personnel for daily mail receipt and the processing of remittances

2. A contingency plan in the event that assigned personnel are not available to open mail and process remittances

3. Processing payments received by Counsel when it is appropriate to do so, when Counsel and Appeals are located in the same POD, and Appeals has the resources to assist


**1.4.28.13** **(12-12-2024)**

### APS Processing Team Manager Duties and Responsibilities

01. Timely, ongoing, accurate review of employees’ work is one of the most important duties of a manager. The manager is responsible for engaging in the work of employees, and providing ongoing, candid, and meaningful employee feedback to obtain the highest possible level of employee satisfaction within the team. When reviews are completed timely, many potential problems can be caught and corrected before they become a significant issue for the taxpayer or for Appeals in general.

02. The PTM must make a review of sufficient depth to assure the correctness of the action proposed. Judgment must be exercised, however, in determining the scope of the review activity. The manager is expected to know the staff and adapt the depth of review to what is actually needed. For example, closed case reviews are needed for new employees, those with identified performance deficiencies, and employees going into new areas of marked increased difficulty. Some work of all employees should be comprehensively reviewed on a random basis. Tailor the degree of review to the ability of the employee and the purpose and type of review.

03. Comprehensive performance management guidance for IRS managers is available on the IRS Human Capital Office - Critical Job Elements (CJE) Resource intranet page.

04. APS PTMs perform the following types of review:




    | **Review Type** | **Review Focus** |
    | :-: | :-: |
    | Performance | On one or more aspects of the employee’s CJEs |
    | Workload | Comprehensive - based on the employee’s workload, assigned cases, and other duties as assigned. See _IRM 1.4.28.13.1_, Workload Reviews, and _IRM 1.4.28.13.2_, Workload Review Preparation, for additional information. |
    | Live Case | On a particular case that is in process and has not been finalized. See _IRM 1.4.28.13.3_, Live Case Reviews, for additional information. |
    | Closed Case | On a particular case that is completed. See _IRM 1.4.28.13.4_, Closed Case Reviews, for additional information. |
    | Performance Appraisals (mid-year and annual) | Incorporate the variety of review documentation completed during the employee’s performance period |

05. A PTM whose team includes a lead tax examiner (LTE) (including those with acting LTE designations) may delegate responsibility for initiating and completing performance reviews and preparation of performance feedback items, live case reviews, closed case reviews, and workload review documents for other team employees. The PTM is ultimately responsible for management and oversight of the performance review process, as well as approval of all performance feedback prepared by the LTE or acting LTE. The PTM is responsible for delivering the performance feedback to the employee. All formal performance feedback must be signed by the employee or, at a minimum, include the employee’s initials verifying the employee received the feedback before it is placed in the EPF. If the employee refuses to sign, the PTM must notate the document "Employee refused to sign MM-DD-YYYY" and provide a copy to the employee.

06. When an APS TE has an assigned OJI, who is not the LTE or acting LTE, the PTM may delegate to the OJI, authority to prepare case-related performance feedback.





    **OJI (non-LTE) case-related performance feedback includes:**



    - Performance feedback document

    - Live case review

    - Closed case review


**OJI (non-LTE) case-related performance feedback does not include:**

    - Workload review

    - Mid-year review

    - Annual appraisal



      ### Note:



      When preparing the mid-year review and annual appraisal, the PTM will consider the full scope of the employee’s performance feedback during the appraisal period.


| **Written Feedback Type** | **Who Can Prepare** | **Who Can Approve** |
| :-: | :-: | :-: |
| Performance feedback | - Designated OJI<br>      <br>    - LTE<br>      <br>    - Acting LTE<br>      <br>    - PTM<br>      <br>    - Acting PTM | - PTM<br>      <br>    - Acting PTM |
| Live case review | - Designated OJI<br>      <br>    - LTE<br>      <br>    - Acting LTE<br>      <br>    - PTM<br>      <br>    - Acting PTM | - PTM<br>      <br>    - Acting PTM |
| Closed case review | - Designated OJI<br>      <br>    - LTE<br>      <br>    - Acting LTE<br>      <br>    - PTM<br>      <br>    - Acting PTM | - PTM<br>      <br>    - Acting PTM |
| Workload review | - LTE<br>      <br>    - Acting LTE<br>      <br>    - PTM<br>      <br>    - Acting PTM | - PTM<br>      <br>    - Acting PTM |
| Mid-year review | - PTM<br>      <br>    - Acting PTM | - PTM<br>      <br>    - Acting PTM<br>      <br>    - APS department manager<br>      <br>    - Acting APS department manager |
| Annual review | - PTM<br>      <br>    - Acting PTM | - PTM<br>      <br>    - Acting PTM<br>      <br>    - APS department manager<br>      <br>    - Acting APS department manager |

07. The PTM is ultimately responsible for review and approval of all performance feedback prepared by the OJI, as well as delivering the performance feedback to the APS TE under OJI review. All formal performance feedback must be signed by the employee or, at a minimum, include the employee’s initials verifying the employee received the feedback before it is placed in the EPF. If the employee refuses to sign, the PTM must notate the document "Employee refused to sign MM-DD-YYYY" and provide a copy to the employee.

08. Managerial review is an integral part of a PTM's responsibilities and allows the manager to:



    1. Assess the employee’s effectiveness in meeting performance expectations of their CJEs

    2. Determine the employee’s efficiency in applying applicable laws, procedures, and policies of the IRS

    3. Identify and acknowledge exceptional work

    4. Identify and address performance problems

    5. Identify and address training needs and training strategies for individuals, specific to grade levels

    6. Evaluate the employee’s ability to effectively prioritize the employee’s inventory workload

    7. Ensure the employee is taking timely and appropriate actions required on assigned inventory

    8. Assess employee effectiveness in developmental case assignments

    9. Ensure correspondence is sent to the appropriate parties to include the power of attorney (when appropriate)


09. Meaningful review and discussion of targeted case assignments, followed with written evaluative feedback, must happen throughout the rating year for each employee. As part of this feedback, the PTM or their appropriate designee should complete both a workload review and live/closed case reviews during each employee’s performance period.

10. The PTM must meet the minimum performance management expectations described below for each employee, however, PTMs are encouraged to provide meaningful written performance feedback more frequently - when appropriate.

11. APS review and performance management expectations are as follows:



    - Minimum performance review - 1 per month for each employee - Total = 9 \[ _includes 1 workload, 1 mid-year, and 1 annual_\]

    - Minimum 50% of performance reviews must be live case or closed case review - Total = 4 to 5

    - Workload review - 1 per employee per annual performance period

    - Live case review - 2 to 3 per employee per annual performance period

    - Closed case review - 2 to 3 per employee per annual performance period

    - Mid-year performance review - 1 per employee per annual performance period

    - Annual performance appraisal - 1 per employee per annual performance period


### Example:

"Employee A’s" performance period begins on November 1st and ends on October 31st of the following year. This employee’s mid-year performance review is due by May 31st and the annual performance appraisal is due by November 30th.

| **Performance Period Milestones for **Employee A**** | **Dates** |
| :-: | :-: |
| Performance period begins | November 1, 2016 |
| Mid-year review due date | May 31, 2017 |
| Performance period ends | October 31, 2017 |
| Final appraisal due by | November 30, 2017 |

| **Performance Documentation**<br>**for **Employee A**** | **Performance Feedback Date** | **Performance Feedback Total**<br>**for "Employee A"** |
| :-: | :-: | :-: |
| Annual appraisal from prior performance period (November 2015 thru October 2016) | Before November 30, 2016 | 12 of 12 from prior performance period |
| Form 2859, Request for Quick or Prompt Assessment, and manual interest computation reviewed with written performance feedback signed and placed in EPF (counts as **live case review**) | December 15, 2016 | 1 of 1 |
| Written **performance feedback** signed and placed in EPF for protecting taxpayer PII | January 25, 2017 | 1 of 2 |
| **Live case review** with written performance feedback signed and placed in EPF | February 4, 2017 | 1 of 3 |
| Form 2859 and manual interest computation reviewed **without** written performance feedback | February 22, 2017 | N/A |
| Form 5792, Request for IDRS Generated Refund (IGR), and manual interest computation reviewed with written performance feedback signed and placed in EPF (counts as **live case review**) | March 17, 2017 | 1 of 4 |
| **Workload review** with written report signed and placed in EPF | April 27, 2017 | 1 of 5 |
| **Mid-year performance review** | May 20, 2017 | 1 of 6 |
| **Total reviews** at middle of performance period: | - Performance Feedback = 1<br>      <br>    - Live Case Review = 3<br>      <br>    - Closed case review = 0<br>      <br>    - Workload review = 1<br>      <br>    - Mid-year review = 1 | Managerial review of Employee A is timely and completed up to mid-year |
| **Closed case review** with written performance feedback signed and placed in EPF | June 20, 2017 | 1 of 7 |
| Written **performance feedback** for team meeting presentation signed and placed in EPF | July 7, 2017 | 1 of 8 |
| Form 2859 and manual interest computation reviewed **without** written performance feedback | July 29, 2017 | N/A |
| Written **performance feedback** for assisting another TE with overage cases | August 19, 2017 | 1 of 9 |
| Form 2859 and manual interest computation reviewed with written performance feedback signed and placed in EPF (counts as **live case review**) | September 6, 2017 | 1 of 10 |
| Manager notifies "Employee A" of their option to prepare and submit their self-assessment by October 31, 2017 | October 1, 2017 | N/A |
| **Closed case review** with written performance feedback signed and placed in EPF | October 16, 2017 | 1 of 11 |
| Annual performance appraisal from current performance period (November 2016 thru October 2017) | November 22, 2017 | 1 of 12 |
| **Total reviews** at end of performance period: | - Performance Feedback = 3<br>      <br>    - Live case review = 4<br>      <br>    - Closed case review = 2<br>      <br>    - Workload review = 1<br>      <br>    - Mid-year performance review = 1<br>      <br>    - Annual performance appraisal for prior year = 1 | Managerial performance review of "Employee A" is timely and completed for performance period.<br> See table below for illustration of cumulative performance feedback provided to "Employee A" |

|     |     |     |
| --- | --- | --- |
| **Written Performance Feedback to "Employee A"** | **Number of Each Performance Feedback Type** | **Performance Feedback Expectation**<br>**(Met/Not Met)** |
| Performance feedback | 3 | Met |
| Live case review | 4 | Met |
| Closed case review | 2 | Met |
| Workload review | 1 | Met |
| Mid-year review | 1 | Met |
| Annual appraisal | 1 | Met |
| Total performance feedback | 12 | Met |

12. Certain types of case-related actions have a mandatory review requirement:



    - All quick assessments

    - All manual refunds

    - All adjustments > $100K

    - All manual interest computations (see paragraph 13 "Note" below for CIT manual interest computation review criteria)


13. Responsibility for completing mandatory reviews listed above can be delegated by the PTM or acting PTM to the LTE, acting LTE, or OJI, but the PTM or acting PTM’s signature on the document serves as the manager’s verification that the review was completed by themselves or their designee and the document/computation is accurate. A mandatory review is **not** considered a live case performance review **unless performance feedback is prepared, shared with the employee, and placed in the EPF.**



    ### Note:



    APS-CIT mandatory interest review threshold is adjustments > $500,000.00 to avoid 100% review and balance the review requirement within APS.

14. Document 11678, IRS and National Agreement , Article 30 Training - Section 2 D. covers the process applicable to an employee’s CLP. When the employee prepares a CLP and submits it to their PTM for review and approval, the PTM will consider the timing to determine if the CLP discussion will be a separate meeting or if the CLP discussion will be coordinated with the workload review, mid-year review, or annual review discussion. PTMs will use their best judgement to coordinate the CLP discussion.

15. The IRS/NTEU, Article 12 Performance Appraisal System - Section 4 B. 6., covers the process applicable to employee’s self-assessments.

16. The IRS/NTEU, Article 12 Performance Appraisal System - Section 6, Receipt and Notice of Elements and Standards, covers the requirement for supervisors to meet with employees once every twelve (12) months to discuss new or revised CJEs and standards, or to communicate that the CJEs will remain the same for that rating period.


**1.4.28.13.1** **(12-12-2024)**

#### Workload Reviews

01. Workload reviews, when combined with live/closed case reviews, are the best tools available to a manager when evaluating case management practices and work habits of APS personnel.

02. A workload review does not replace the formal mid-year review requirement.

03. PTMs will do a minimum of one workload review per year; preferably at mid-year, which will focus on the following:



    01. Adherence to and application of IRM policy and procedures for performance of duties

    02. Case management issues and actions

    03. ACDS database accuracy

    04. ASED determination

    05. ASED controls

    06. ASED protection

    07. Timeliness of case related actions

    08. Accuracy of account adjustment forms prepared

    09. Adherence to mandatory review process, per IRM 8.20.7, Closing Procedures

    10. Accuracy of account adjustment input actions

    11. PEAS suspense cases and recordation of reason for PEAS suspense

    12. PEAS CAR entries sufficient to explain delays and time applied to the case

    13. Other systems used by APS to control, monitor and process Appeals cases (i.e. ISTS, AOIC, AIMS, IDRS, DIMS, etc.)


04. In addition to devoting undivided time to each employee, the workload review will help identify exemplary casework, good workload management skills, and employee strengths. The workload review can also confirm the cause for inventory management issues, identify skill gaps and training needs, and provide awareness of time management practices that are beneficial or detrimental towards accomplishment of the team’s goals and objectives.

05. More frequent reviews are necessary when serious performance deficiencies and a need for development are identified.

06. Tools for conducting a workload review are as follows:



    01. APS TE’s PEAS inventory validation listing (IVL) to identify a sample of cases for live case review

    02. APS TE’s ACDS overage report

    03. APS TE’s IDRS overage report

    04. APS TE’s PEAS suspense report

    05. APS TE’s PEAS time sheet for the applicable time frame

    06. Copy of prior workload review report for the TE (if available)

    07. Other report(s) applicable to the TE’s workload and inventory

    08. Current AIMS, IDRS, ACDS and PEAS prints for specific cases identified for live case review (request other systems’ prints, as needed)

    09. Pre-workload review discussion with employee to identify items to be provided

    10. Workload review report of your findings



        **Workload review close-out discussion with the employee**






        | **Step** | **Action** |
        | --- | --- |
        | a. | Share the review findings, in writing, with the employee |
        | b. | Encourage two-way communication related to the review findings |
        | c. | Encourage the employee to express work related concerns |
        | d. | Encourage the employee to identify training needs |
        | e. | Solicit the employee’s input and questions and then document the workload review report as appropriate |
        | f. | Clarify/update items included in the workload review report as appropriate |
        | g. | Encourage the employee to develop a CLP. Share the integrated talent management (ITM) course number and explain the IRS/NTEU guidelines for official time allowed for completing the training and preparing a draft CLP.<br> Offer to help the employee or identify someone who can |
        | h. | Encourage the employee to update the CLP, if previously developed |
        | i. | Document in the workload review report the CLP discussion |
        | j. | Include on the final page of the workload review report the following statement: _"By signing this document, you acknowledge receipt on the date specified. This document becomes an official part of your Employee Personnel File as of the date signed by the manager."_ |
        | k. | Print two copies of the final workload review report. Include the following in the report: page numbers, a line for the employee’s initials/date, and a line for the reviewer’s signature/date |
        | l. | Obtain the employee initials and dates on both copies |
        | m. | Sign, and date both copies |
        | n. | Provide the employee with one signed copy, and place the other signed copy in the EPF |







        ### Note:



        To the extent possible, use the same standard format for all workload reviews. If the PTM manages employees with different grades and duties, use the same standard format and identify as not applicable (N/A) items that do not apply to a specific employee.


07. The primary objective of a workload review is for the manager to gain a specific understanding of the status of each work unit in an employee's inventory. Workload reviews, when properly conducted, involve a substantial amount of time. This is time well spent as it gives the manager insight into each employee's work habits, inventory management practices, technical abilities and identifies areas where training and development are needed. It provides managerial insight as to the exact status of each employee's inventory as well as an opportunity to openly discuss both challenges and opportunities towards accomplishing the employee’s work-related goals. When strengths and weaknesses are clearly identified with specific examples, a workload review is beneficial to the manager, the employee and the organization because we all have the same customer. A workload review also provides the manager with an opportunity to both learn from and share with the employee while identifying potential best practices that can be shared with other team members or other APS teams.

08. A workload review enables the manager to evaluate and give feedback as to how well an employee is managing inventory and taxpayer account adjustments by appraisal of the following factors:



    1. Adequate statute procedure followed and adequate documentation

    2. Adequate prioritization of inventory to protect statutes and avoid overage cases

    3. Accurate update of systems (i.e. ACDS, AIMS, IDRS, DIMS)

    4. Accurate suspense and monitoring of cases in accordance with IRM policies and procedures

    5. Appropriate follow-up when one or more necessary forms or worksheets are either missing or incorrect

    6. Awareness of interest review requirements and requesting interest reviews when appropriate and/or mandatory

    7. Accurate interest computation and account adjustment processing

    8. Accurate preparation of account adjustment documents:


    - Form 2424, Account Adjustment Voucher

    - Form 2859, Request for Quick or Prompt Assessment

    - Form 3753, Manual Refund Posting Voucher

    - Form 3870, Request for Adjustment

    - Form 5403, Appeals Closing Record

    - Form 5792, Request for IDRS Generated Refund (IGR)

    - Form 8485, Assessment Adjustment Case Record

    - Form 12810, Account Transfer Request Checklist

    - Other account adjustment documents for the taxpayer’s case


09. A workload review helps the manager identify whether the employee:



    1. Consistently follows applicable IRM policies and procedures

    2. Effectively protects ASEDs

    3. Requests interest reviews, when mandatory or otherwise needed

    4. Efficiently manages assigned inventory


10. In addition to the above, a workload review enables the manager to make judgments concerning an employee's:



    1. Overall skill level appropriate to the position description, work assignments and training/developmental needs

    2. Application of technical and procedural guidelines

    3. Effective use of time

    4. Compatibility of work with grade

    5. Need for OJI, peer assistance, or conclusion of OJT


11. A workload review also offers an opportunity for:



    1. Identifying cases that require additional information (e.g., 6404(g) worksheet, Sequa spreadsheet, etc.)

    2. Verifying the work unit grade and reassigning the case to a higher graded TE, when appropriate

    3. Reassigning cases to balance workloads or resolve aging cases

    4. Establishing or directing case inventory priorities

    5. Reviewing the direct time applied to the case and determining if it is appropriate, based on the complexity and case actions taken

    6. Providing a forum for discussion of the employee’s career goals and CLP


12. The workload review must include specific instances where the employee’s CJEs and performance aspects are reflected in the work products reviewed and that they clearly state guidance and direction. The workload review must also set out agreements between the manager and employee with respect to specific actions, target dates and overall performance.

13. Within 15 business days of the conclusion of the workload review, the manager will provide the employee with the workload review analysis and summary. The employee will initial and date the document (as "received" ), and the manager will sign and date the document. The employee receives one copy, and the manager inserts the original into the EPF.



    ### Note:



    If the employee refuses to initial and date the workload review, the manager will make the following notation in place of the initials: "Employee refused to initial this document provided on MM-DD-YYYY" .


**1.4.28.13.2** **(04-19-2016)**

#### Workload Review Preparation

1. The initial preparation for the workload review can be done in advance. The PEAS IVL includes all cases currently assigned to the employee and can be used to identify specific cases chosen for review. Each selected case should involve the same level of review; and if one or more items do not apply, enter "not applicable" as appropriate. The workload review items must be documented in writing with page numbers included (e.g. 1 of 3, 2 of 3, etc.) An example of workload review items for each inventory case follows:



01. Taxpayer name control, partially redacted "ABXX" with **XX** replacing and obscuring the last two letters

02. Tax period(s)

03. WUNO

04. Case type (e.g., CDP notice for issuance, SND Notice for issuance, PENAP Closing, Employment Tax Closing, etc.)

05. Date assigned on PEAS

06. Statute date accurate on ACDS and AIMS? Yes, No, N/A

07. ACDS and PEAS database information accurate? Yes, No, N/A

08. Grade of the case appropriate for employee’s position description, training and skill level? Yes or No

09. PEAS CAR accurate? Yes, No, N/A

10. PEAS suspense and monitoring action(s) accurate and timely? Yes, No, N/A

11. Processing action(s) taken timely? Yes, No, N/A

12. Interest-related forms and schedules included, properly considered and applied? Yes, No, N/A

13. Mandatory _interest review_ requested and completed? Yes, No, N/A

14. Completion date or expected completion date

15. IDRS controls open or closed timely? Yes, No, N/A

16. Download of the Tax Court petition, and upload to ACDS timely? Yes, No, N/A

17. Deletion of the petition from the SharePoint site timely? Yes, No, N/A

18. Additional case related items or comments, as appropriate


2. Additional (non-case) items that may also be included in a workload review:



01. PEAS timesheet management practice and adherence to policy and procedure for current performance period

02. Direct/indirect time report

03. PEAS follow-up report use

04. PEAS suspense and monitor practices

05. Frequency of unpostables and repeat unpostables

06. Training needs and/or accomplishments

07. Special project actions and accomplishments

08. Team meeting contribution(s)

09. Performance actions of note (highlight and recognize, or improvement needed)

10. Other, as determined by management


3. The workload review document described in (1) above serves as the foundation for preparing the employee’s performance memorandum and for documenting the employee’s mid-year and annual performance appraisals.

4. Since a CLP is formatted to align goals and development opportunities with CJEs and performance aspects, the manager may also document in the workload review the invitation for the employee to prepare or update the CLP.


**1.4.28.13.3** **(04-19-2016)**

#### Live Case Reviews

1. The PTM, or designee, must review the selected case in sufficient depth to identify and document the accuracy and timeliness of the employee’s actions taken for the case. The live case review covers performance actions taken by the employee from the date assigned to the date submitted for review. Tailor the degree of review to the employee’s ability and the characteristics of the case.

2. A comprehensive review includes technical and procedural accuracy, as well as case management practice and adherence to applicable IRM procedures. Documents to be inspected in a live case review include:



01. Assessment statute, refund statute, or collection statute forms, extensions, or other items applicable to statute determination

02. Forms, documents, worksheets and reports provided for processing and/or closing action(s) by APS

03. Authorization for adjustment documents prepared and provided by the ATE \[e.g. signed waiver/agreement form, defaulted SND or determination letter with Tax Court rights, Tax Court Decision (entered or dismissed), Form 3870, Form 5402, etc.\]

04. Power of attorney, if applicable

05. ACDS case summary card

06. PEAS CAR

07. Documents prepared by the APS TE to include interest-related entries

08. Interest computations prepared by the TE, if any

09. AIMS and IDRS prints, as appropriate

10. DIMS tracking notation record

11. Other items or documents, as needed


3. A live case review can be requested by the employee, Lead TE, or PTM for a particular case.

4. Live case reviews will include performance-related documentation associated with the applicable CJE(s) and aspect(s) of the employee’s position. Upon conclusion of the review, share and discuss the performance documentation with the employee, who initials the document to verify receipt. One copy is given to the employee, and one is placed in the EPF.



### Note:



If an employee refuses to sign the performance feedback, the PTM will enter the following statement on the signature/initials line: "Employee refused to initial or sign MM-DD-YYYY" .

5. A live case review can be completed by the PTM, designated Lead TE, or employee’s OJI as appropriate. The PTM retains responsibility for the correctness of the review documentation for including it in the EPF.


**1.4.28.13.4** **(08-15-2017)**

#### Closed Case Reviews

1. The PTM, or designee, must review the selected case in sufficient depth to identify and document the accuracy and timeliness of the employee’s actions taken for the case. The closed case review covers the performance actions taken by the employee, from the date assigned to the date closed on PEAS. The manager is expected to know the staff and adapt the depth of review, as needed. For example, close review is needed for new employees, those with identified performance deficiencies, and employees going into new areas of marked increased difficulty. Some employees’ work should be comprehensively reviewed on a random basis. Tailor the degree of review to the employee’s ability and the characteristics of the specific case.

2. A comprehensive review includes technical and procedural accuracy, as well as case management practice and adherence to applicable IRM procedure(s). Documents to be inspected in a closed case review include:



01. Assessment statute, refund statute, or collection statute forms, extensions, or other items applicable to statute determination

02. Forms, documents, worksheets and reports provided for processing and/or closing action(s) by APS

03. Authorization for adjustment documents prepared and provided by the ATE \[e.g., signed waiver forms, defaulted Statutory Notice of Deficiency, Tax Court Decision (entered or dismissed), Form 3870, Form 5402, etc.\]

04. Power of attorney, if applicable

05. ACDS case summary card

06. PEAS case activity record

07. PEAS suspense and monitoring actions and documentation

08. Documents prepared by the APS TE to include interest-related entries

09. Interest computations prepared by the tax examiner

10. AIMS and IDRS prints, as appropriate

11. Correspondence with the taxpayer, if applicable

12. Accuracy of account updates and adjustments

13. Accuracy of account adjustment processing to avoid unpostables

14. Resolution of the taxpayer’s account (e.g., overpayment amount, offset or refunded as appropriate)

15. Accuracy and timeliness of DIMS tracking notation

16. Other items or documents, as needed


3. A closed case review can be requested by the employee, Lead TE, or PTM for a particular case.

4. Closed case reviews will include performance-related documentation associated with the applicable CJE(s) and aspect(s) of the employee’s position. Upon conclusion of the review, share and discuss the performance documentation with the employee, who initials the document to verify receipt. One copy is given to the employee, and one is placed in the EPF.



### Note:



If an employee refuses to sign the performance feedback, the PTM will enter the following statement on the signature/initials line: "Employee refused to initial or sign MM-DD-YYYY" .

5. A closed case review can be completed by the PTM, designated Lead TE, or employee’s OJI as appropriate. The PTM retains responsibility for the correctness of the review documentation and for including it in the EPF.


**1.4.28.13.5** **(04-19-2016)**

#### APS Inventory and Time Management Tools

1. APS leadership employs a wide variety of reports and methods for gauging inventory size, inventory management, and time management for each Appeals office, APS office, APS area, and nationally.


**1.4.28.13.5.1** **(12-12-2024)**

##### Appeals Centralized Database System (ACDS) Reports

1. The ACDS reports and procedures are provided in IRM 8.10.1, Internal Reports. ACDS report usage and report management is established by APS directors and department managers.

2. APS management, or its designated employees, have national report responsibility for reports and database maintenance.

3. The Docketed Information Management System (DIMS) team has national report responsibility for the oversight and monitoring of the electronic docket listing.

4. ACDS has interface capability with AIMS to extract and generate monthly and quarterly AMATCH reports. See IRM 8.10.1.11 , AMATCH - Audit Information Management System (AIMS). These reports provide information that alerts APS of mismatch or discrepancy data between ACDS and AIMS. AMATCH reports are assigned and worked according to discretion of the APS directors and department managers.


**1.4.28.13.5.2** **(04-19-2016)**

##### Processing Employee Automated System (PEAS) Reports

1. PEAS reports and procedures are provided in IRM 8.20.10, Appeals Processing Employee Automated System (PEAS). PEAS report management and usage is established by the:



1. APS directors for their department managers

2. APS department managers for their PTMs

3. PTMs for their team employees

4. AARS ATM for the team’s employees


2. PEAS inventory and time reports provide APS management at all levels to identify:



1. Inventory levels

2. ACDS inventory aging statistics

3. IDRS inventory aging statistics

4. Inventory suspense cases

5. APS employees’ _direct_ and _indirect_ time measurements

6. Potential overage inventory


3. PEAS reports are used to strategically maximize efficiency through inventory control and prioritization of cases.


**1.4.28.13.5.3** **(04-19-2016)**

##### PEAS Case Activity Records (CAR)

1. The APS PTM and department manager can review and add comments to the PEAS CAR for any case within their purview. This capability allows management to employ real-time inventory management involvement and case status inquiry. This tool also provides the manager with a means for establishing both case and non-case related follow-up actions for the employee.

2. The PEAS CAR is used by the APS TE or AARS employee to:



1. Identify and control cases in their inventory

2. Document case actions applicable to direct time spent on case

3. Document reason(s) for case suspense

4. Document follow-up action(s) and set a follow-up reminder

5. Respond to manager’s CAR entries, when applicable

6. Identify inventory reassignment, when applicable

7. Document actions taken as a team member on another employee’s case \[e.g., interest review and assistance, OJI assistance, or other appropriate reason\]


**Exhibit 1.4.28-1**

### Case Grading Factors to Consider for Examination Sourced Cases

See _IRM 1.4.28.9.1_, Relationship of These Guidelines to Position Management, regarding how case grading is affected by the degree of supervision, personal contacts, and the assignment of higher or lower graded work.

|  | **FACTOR** | **GS–9/11** | **GS–12** | **GS–13** | **GS–14** |
| :-: | :-: | :-: | :-: | :-: | :-: |
| A | Factual complexity of issue | Easily resolved. Facts established or easy to determine | Moderately difficult | Moderately complex factual issues in which different interpretations of fact are present or possible | Very complex or novel issues in which conflicting interpretations of facts are present |
| B | Impact of work unit | Limited to parties and tax years involved | May affect taxpayer's interest in subsequent years and/or other related taxpayers | Consists of several related work units; and/or affects a number of taxpayers; and/or has potential for adverse impact on overall voluntary compliance; and/or has high dollar impact on others and/or work units | Affects a number of unrelated taxpayers; and/or has industry-wide implications; and/or has very high dollar impact on other work units and/or has high potential for adverse impact on overall voluntary compliance |
| C | Legal complexity | No legal dispute involved; or legal dispute can be resolved with little or no research because legal principle is clear. | Some legal research required; statutes, regulations, or judicial precedents available and usually applicable to the case. | Moderately difficult. Legal research and analysis required to resolve significant legal complexities. Precedents usually available; require interpretation to apply. | Extensive legal research required. Applicable law very complex. Precedents lacking or conflicting. |
| D | Conference and negotiating skills | Normal meet-and-deal skills. | Basic negotiating and conference skills. | Issues are controversial and other aspects of the work unit require more than basic conference and negotiating skills. | Issues are controversial and other aspects of the work unit are so unique as to require exceptional conference and negotiating skills. |

**Exhibit 1.4.28-2**

### Upgrading Examination Sourced Cases - Considerations

See the following lists of issues or features frequently requiring upgrading to case grade 14, 13, or 12. The existence of one or more of these items does not trigger the automatic grade change of a work unit. A judgment as to whether to change the grade should be made after considering all factors in the work unit and relating them to the general characteristics set forth in _Exhibit 1.4.28-1_.

- **Issues or Features Frequently Requiring Upgrading to GS-14**




|  | **Issue or Feature** |
| :-: | :-- |
| 1 | Joint Committee cases |
| 2 | Appeals coordinated issues |
| 3 | Life insurance company issues |
| 4 | IRC 269 issues (acquisitions made to evade or avoid income tax) |
| 5 | IRC 482 issues (allocation of income and deductions among taxpayers) |
| 6 | IRC 531 issues (accumulated earnings tax) |
| 7 | Complex estate tax issues |
| 8 | Complex merger, reorganization, recapitalization, spin-off, and split-off issues |
| 9 | Complex foreign corporation issues |
| 10 | Mitigation of statute of limitations (IRC 1311 – IRC 1314) |
| 11 | Cases involving closing agreements |
| 12 | Cases involving tax haven issues |
| 13 | Net worth computation, bank deposit method, and other complex fraud penalty cases |
| 14 | LIFO inventory issues |
| 15 | Complex collapsible corporations |
| 16 | Issues involving related law such as Bankruptcy Act, the Securities and Exchange Commission, and complex state law |
| 17 | Railroad issues |
| 18 | Complex tax shelters |


- **Issues or Features Frequently Requiring Upgrading to GS-13**




|  | **Issue or Feature** |
| :-: | :-- |
| 1 | Estate tax issues |
| 2 | Most corporate issues |
| 3 | Most EP/EO issues |
| 4 | Most partnership issues |
| 5 | Trust fund recovery penalty (TFRP) cases |
| 6 | Foreign issues |
| 7 | Fraud cases |
| 8 | Subchapter S (S Corporation) issues |
| 9 | Moderately complex IRC 274 issues (disallowance of certain entertainment, etc., expenses) |
| 10 | Moderately complex bad debt issues |
| 11 | Tax shelters |


- **Issues or Features Frequently Requiring Upgrading to GS-12**




|  | **Issue or Feature** |
| :-: | :-- |
| 1 | Scholarship or fellowship (IRC 117) |
| 2 | Travel as a form of education |
| 3 | Alimony |
| 4 | Compensation vs. gift from employer |
| 5 | Determination of whether expense was incurred in a trade or business or is ordinary and necessary |
| 6 | Hobby loss |
| 7 | Simple penalty cases |
| 8 | Simple depreciation cases |
| 9 | Simple investment credit |


**Exhibit 1.4.28-3**

### Downgrading Examination Sourced Cases - Considerations

The existence of one or more of the following items does not trigger the automatic grade change of a work unit. Make a judgment as to whether to change the grade after considering all factors of the work unit and relating them to the general characteristics in _Exhibit 1.4.28-1_. Exercise caution in downgrading tax shelter cases when other factors indicate that downgrading would not be appropriate. Such factors might include the sensitivity of the case or its potential impact on overall voluntary compliance.

- **Downgrading Considerations**



|     |     |
| --- | --- |
| 1 | Where issue(s) in the work unit can be resolved by reference to a Tax Court, Circuit Court, or Supreme Court decision directly on point rendered after assignment of the work unit. |
| 2 | Where issues are conceded by the taxpayer before significant work is performed on the issues and the remaining contested portion of the proposed deficiency would merit a lower grade. |
| 3 | Where cases have issues identical to a key or pattern case that is a separate work unit. |
| 4 | Where Examination must transmit a work unit to Appeals and the same issues in previous years were disposed of on a hazards-of-litigation basis in Appeals. |
| 5 | Where issues in work units are identical to and totally dependent upon settlement of a related work unit in another Appeals office. |
| 6 | Where elimination of duplication of tax from the computed dollar size of a work unit would reduce proposed deficiency and merit a lower grade (e.g., Section 482 cases with correlative adjustments or transferee liability cases). |
| 7 | Where elimination of tax relating to issues not protested would reduce proposed deficiency and merit a lower grade. |
| 8 | Where the only issues are substantiation of a deduction and/or the legal dispute can be resolved with little or no research because the legal principle is clear and constitutes generally accepted basic tax knowledge routinely applied. |


**Exhibit 1.4.28-4**

### Case Grading Matrix for Collection Sourced Cases

See the following lists of issues for considering case grade assignments for collection sourced cases.

- **Other Factors Adding To Collection Case Complexity For Which Upgrade Should Be Considered**


|  | **Issue** | **Minimum Grade** |
| :-: | --- | :-: |
| 1 | Real estate valuation issues | 11 |
| 2 | Bankruptcy / receivership issues | 11 |
| 3 | Special circumstance or effective tax administration (ETA) offers | 12 |
| 4 | Fraud issues | 12 |
| 5 | IRC 6700 thru 6709 penalties | 12 |
| 6 | Combined annual wage reporting adjustment (CAWR) | 12 |
| 7 | Large dollar | 12 |
| 8 | Case sensitivity / public policy issues | 12 |
| 9 | Involved title issues, involved community property, or other state law issues; multiple owners; and complex title issues considered under specific state laws | 12 |
| 10 | Involved asset valuation issues such as corporate ownership, trust or personal service entities, and other tangible assets, complex intangibles and contingent assets | 13 |
| 11 | Individual involvement in a closely held entity with commingled income/assets and involved analysis of entity’s finances is required | 13 |
| 12 | International issues | 13 |
| 13 | Transferee, nominee, or alter ego issues | 13 |
| 14 | Fraud issues, ATAT cases only, i.e., failed to disclose offshore assets) | 14 |

- **Collection Appeal Program Installment Agreements (CAPIA)**


|  | **Issue** | **Minimum Grade** |
| :-: | --- | :-: |
| 1 | Denial of a request for a guaranteed or streamlined installment agreement | 11 |
| 2 | Proposed termination or termination of an installment agreement with an amount of $25,000 or less including any new periods | 11 |
| 3 | Proposed termination, termination, or denial of an installment agreement for other individuals | 12 |
| 4 | Proposed termination, termination, or denial of an installment agreement for sole proprietorships, partnerships, and corporations without employees or easily identified less involved issues | 12 |
| 5 | Proposed termination, termination, or denial of an installment agreement for sole proprietorships, partnerships, and corporations not qualifying in item 4 above | 13 |
| 6 | Proposed termination, termination, or denial of an installment agreement for individuals with highly complex issues such as complex intangibles, contingent assets, minority interest in personal service company, marketability discounts, pending lawsuits | 13 |
| 7 | Proposed termination, termination, or denial of an installment agreement for LLPs or LLCs | 13 |

- **Collection Appeal Program Lien (CAPLN) - Proposed Lien Issues**


|  | **Issue** | **Minimum Grade** |
| :-: | --- | :-: |
| 1 | Individual wage earners who may qualify for a streamlined or guaranteed installment agreement | 11 |
| 2 | Individual wage earners with an accepted installment agreement or an accepted offer in compromise | 11 |
| 3 | Individuals whose accounts have been placed into currently not collectible status | 11 |
| 4 | Wage earners or individuals on a fixed income | 11 |
| 5 | Sole proprietors with no employees or self employed individuals | 11 |
| 6 | Out of compliance in-business taxpayers | 11 |
| 7 | Out of business taxpayers, no trust fund taxes due | 11 |
| 8 | Lien related issues for all other entities not listed above, except LLP and LLC | 12 |
| 9 | Lien issues:<br> <br>- Bonding<br>  <br>- Factoring<br>  <br>- Other complex issues | 13 |
| 10 | LLP/LLC | 13 |

- **Collection Appeal Program Lien (CAPLN) - Filed Lien Issues**


|  | **Issue** | **Minimum Grade** |
| :-: | --- | :-: |
| 1 | Individual wage earners who may qualify for a streamlined or guaranteed installment agreement | 11 |
| 2 | Individual wage earners with an accepted installment agreement or an accepted offer in compromise | 11 |
| 3 | Individuals whose accounts have been placed into currently not collectible status | 11 |
| 4 | Wage earners or individuals on a fixed income | 11 |
| 5 | Sole proprietors with no employees or self employed individuals | 11 |
| 6 | Out of compliance in-business taxpayers | 11 |
| 7 | Out of business taxpayers, no trust fund taxes due | 11 |
| 8 | Release and withdrawal issues for all other entities | 12 |
| 9 | Lien issues:<br> <br>- Discharge<br>  <br>- Subordination<br>  <br>- Alter ego<br>  <br>- Nominee<br>  <br>- Transferee<br>  <br>- Non-attachment<br>  <br>- Title issues under community property or state laws<br>  <br>- Bonding<br>  <br>- Factoring<br>  <br>- Other complex issues | 13 |
| 10 | LLP/LLC | 13 |

- **Collection Appeal Program Levy Issue (CAPLV) - Proposed Levies**


|  | **Issue** | **Minimum Grade** |
| :-: | --- | :-: |
| 1 | Levy on wage earners and others whose income is limited to fixed income (i.e., retirement annuities and social security) | 11 |
| 2 | Levy on individuals not included in item 1, including self employed individuals and sole proprietorships without employees | 12 |
| 3 | Levy on all entities other than individuals including sole proprietorships with employees | 13 |
| 4 | Levies involving:<br> <br>- Disallowance of taxpayer’s request to return levied property under economic hardship, see IRC 6343(d)<br>  <br>- Nominees<br>  <br>- Transferees<br>  <br>- Alter ego<br>  <br>- Assets belonging to a third party<br>  <br>- Involved community property issues<br>  <br>- Disallowance of property owner’s claim to return levied property under IRC 6343 | 13 |

- **Collection Appeal Program Levy Issue (CAPLV) - Issued Levies**


|  | **Issue** | **Minimum Grade** |
| :-- | --- | :-: |
| 1 | Levy on wage earners and others whose income is limited to fixed retirement (i.e., retirement annuities and social security) | 11 |
| 2 | Levy on individuals not in item 1 and levy on sole proprietorships | 12 |
| 3 | Levy on all entities other than individuals and sole proprietorships | 13 |
| 4 | Levies involving<br> <br>- Nominees<br>  <br>- Transferees<br>  <br>- Alter ego<br>  <br>- Assets belonging to a third party<br>  <br>- Involved community property issues<br>  <br>- Disallowance of taxpayer’s request to return property under economic hardship, see IRC 6343(d)<br>  <br>- Disallowance of property owner’s claim to return levied property under IRC 6343 | 13 |

- **Collection Appeal Program - Seizure (CAPSZ)**


|  | **Issue** | **Minimum Grade** |
| :-: | --- | :-: |
| 1 | Seizure and sale | 13 |
| 2 | Seizure and sale involving significant subterfuges, tax avoidance (whipsaw assessments), abusive promoters, schemes, international issues (i.e., offshore bank accounts and foreign assets, exempt organization schemes)<br> <br>### Note:<br>These are cases that come from the Abusive Tax Avoidance Transaction (ATAT) groups | 14 |

- **Collection Due Process Levy Cases (DPLV)**



### Note:



For CDP levy and lien issues (DPL2), review both DPLV and DPLN tables and use highest appropriate grade


|  | **Issue** | **Minimum Grade** |
| :-: | :-: | :-: |
| 1 | For cases that involve penalty appeal (PENAP) only and there are no other grade increasing factors, see Penalty Appeals case grading matrix on Appeals Managers Resources intranet to determine appropriate grade level. | PENAP case grading matrix |
| 2 | Account balance previously resolved or full paid with no apparent unresolved issues | 9 |
| 3 | Premature referral preparation needed to release Appeals jurisdiction | 9 |
| 4 | Solely frivolous arguments in the file, Letter 4380 needs to be sent to clarify the taxpayer has no legitimate issues prior to closing as a premature referral. If the taxpayer raises non-frivolous issues the case may need to be regraded.<br> <br>### Note:<br>**When both frivolous and legitimate issues are raised, the case grade case should be solely based upon the legitimate issue(s).** | 9 |
| 5 | Underlying liability issue from ASFR/SFR and the taxpayer can raise the liability issue. Other issues may raise the grade level. | 9 |
| 6 | Wage earners or individuals on a fixed income that meet streamline installment agreement criteria (including non CDP periods) | 9 |
| 7 | Underlying liability issue from Form 1040 with no schedules or Schedule B only, and the taxpayer can raise the liability issue | 11 |
| 8 | Wage earners or individuals on a fixed income that do not meet streamline installment agreement criteria | 11 |
| 9 | Out of compliance in-business taxpayers that would not qualify for a collection alternative | 11 |
| 10 | Out of business taxpayers, no trust fund taxes due | 11 |
| 11 | Self employed individuals or sole proprietors with no employees | 12 |
| 12 | Underlying liability issue from Form 1040 with schedules other than Schedule B, and the taxpayer can raise the liability issue | 12 |
| 13 | Sole proprietors with employees and gross receipts of $1,000,000 or less or a balance due of $250,000 or less (including non CDP periods) | 12 |
| 14 | Out of business taxpayers, trust fund taxes due | 12 |
| 15 | Returns with underlying TEFRA, involved tax shelter, involved net operating losses, and international liability issue and the taxpayer can raise the liability issue | 13 |
| 16 | Underlying business master file (BMF) liability issue and the taxpayer can raise the liability issue | 13 |
| 17 | Underlying TFRP liability issue and the taxpayer can raise the liability issue | 13 |
| 18 | Individuals involving complex tax shelters | 13 |
| 19 | Business entities in compliance (not listed elsewhere) | 13 |
| 20 | Sole proprietors with employees and gross receipts of greater than $1,000,000 or a balance due greater than $250,000 | 13 |
| 21 | Estates and Trusts | 13 |
| 22 | LLP and LLC | 13 |
| 23 | Partners in a partnership which serves as a primary source of the partner’s income. | 13 |
| 24 | If CDP includes significant subterfuges, tax avoidance, abusive promoters, abusive schemes, organization schemes, international issues such as offshore bank accounts and foreign assets (Normally these cases come from an ATAT group) | 14 |

- **Collection Due Process Lien Cases (DPLN)**



### Note:



For CDP levy and lien issues (DPL2), review both DPLV and DPLN tables and use highest appropriate grade


|  | **Issue** | **Minimum Grade** |
| :-: | :-: | :-: |
| 1 | For cases that involve penalty appeal (PENAP) only and there are no other grade increasing factors, see Penalty Appeals case grading matrix on Appeals Managers Resources intranet page to determine appropriate grade level | PENAP case grading matrix |
| 2 | Lien issues for wage earners that have an accepted installment agreement or offer in compromise as the collection alternative or whose accounts were declared currently not collectible (lien filed because of the determination) | 9 |
| 3 | Lien issues for wage earners who qualify for a streamline or guaranteed installment agreement | 9 |
| 4 | Account balance previously resolved or full paid with no apparent unresolved issues | 9 |
| 5 | Premature referral preparation needed to release Appeals jurisdiction | 9 |
| 6 | Solely frivolous arguments in the file, Letter 4380 needs to be sent to clarify the taxpayer has no legitimate issues prior to closing as a premature referral. If the taxpayer raises non-frivolous issues the case may need to be regraded.<br> <br>### Note:<br>**When both frivolous and legitimate issues are raised, the case grade case should be solely based upon the legitimate issue(s).** | 9 |
| 7 | Underlying liability issue from ASFR/SFR and TP can raise the liability issue. Other issues may raise the grade level. | 9 |
| 8 | Wage earners or individuals on a fixed income that meet streamline installment agreement criteria (including non CDP periods) | 9 |
| 9 | Underlying BMF liability issue and the taxpayer can raise the liability issue | 11 |
| 10 | Individuals who have a rejected installment agreement or offer in compromise | 11 |
| 11 | Underlying liability issue from Form 1040 with no schedules or schedule B and the taxpayer can raise the liability issue | 11 |
| 12 | Wage earners or individuals on a fixed income that do not meet streamline installment agreement criteria | 11 |
| 13 | Sole proprietors with no employees, or self employed | 11 |
| 14 | Out of compliance in-business taxpayers | 11 |
| 15 | Out of business taxpayers, no trust fund taxes due | 11 |
| 16 | Underlying liability issue from Form 1040 with more schedules than Schedule B and the taxpayer can raise the liability | 12 |
| 17 | Out of business taxpayers, trust fund taxes due | 12 |
| 18 | Sole proprietors with employees and gross receipts of $1,000,000 or less or a balance due of $250,000 or less (including non CDP periods) | 12 |
| 19 | Underlying TFRP liability issue and the taxpayer can raise the liability issue | 13 |
| 20 | Underlying TEFRA, involved tax shelter, involved net operating losses, or international liability issue and the taxpayer can raise the liability issue | 13 |
| 21 | Individuals involving complex tax shelters | 13 |
| 22 | Corporations | 13 |
| 23 | Partnerships | 13 |
| 24 | Sole proprietors with employees and gross receipts of greater than $1,000,000 or a balance due greater than $250,000 (including non CDP periods) | 13 |
| 25 | Estates and Trusts | 13 |
| 26 | LLP and LLC | 13 |
| 27 | Partners in a partnership which serves as a primary source of income | 13 |
| 28 | Complex community property issues or complex title issues considered under specific state laws | 13 |
| 29 | Transferee, nominee, or alter ego issues | 13 |
| 30 | If CDP includes significant subterfuges, tax avoidance, abusive promoters, abusive schemes, exempt organization schemes, or international issues, such as offshore bank accounts and foreign assets. | 14 |

- **Offer in Compromise (OIC) - Basic guidelines for doubt as to collectibility (DATC) offer cases**


|  | **Issue** | **Minimum Grade** |
| :-: | :-: | :-: |
| 1 | 1\. Offers from individuals with liabilities limited to:<br> <br>- Personal income tax<br>  <br>- Penalties - all, including TFRP<br>  <br>- Employment taxes owed by sole proprietor, with no current Form 941 requirement<br>  <br>- Self employed individual with no Form 941 filing requirement<br>  <br>  <br>  <br>### Note:<br>  <br>  <br>  <br>Interest in real estate is limited to personal residence owned by the parties to the offer.<br>  <br>  <br>  <br>  <br>  <br>### Note:<br>  <br>  <br>  <br>All periods are jointly owed if a joint offer. | 11 |
| 2 | Offers with individuals with liability from:<br> <br>- Sole proprietors with employees and gross receipts of $1,000,000 or less; or $250,000 or less balance due (including non-CDP preiods)<br>  <br>- Self employed with Form 941 filing requirement<br>  <br>- Previously self employed, but currently unemployed<br>  <br>- Out of business companies<br>  <br>- Individuals not qualifying under item 1 above | 12 |
| 3 | Special circumstance or effective tax administration (ETA) offers (\*minimum grade). | 12\* |
| 4 | Offers from:<br> <br>- Individuals involving complex tax shelters<br>  <br>- Corporations<br>  <br>- Partnerships<br>  <br>- Sole proprietors with employees and gross receipts of greater than $1,000,000 or a balance due greater than $250,000<br>  <br>- Estates and trusts<br>  <br>- LLP and LLC<br>  <br>- Partners in a partnership which serves as a primary source of income | 13 |
| 5 | Offers involving pending lawsuits, assets needing expert appraisals, marketability discounts (other than personal residence) | 13 |
| 6 | Offers including:<br> <br>- Significant subterfuges<br>  <br>- Tax avoidance<br>  <br>- Abusive promoters<br>  <br>- Schemes (whipsaw assessments)<br>  <br>- International issues (i.e., offshore bank accounts and foreign assets -(Normally these are cases which come from an ATAT group) | 14 |

- **Offer in Compromise (OIC) - Basic guidelines for doubt as to liabilityy (DATCL) offer cases**


|  | ****Issue**** | ****Minimum Grade**** |
| :-: | :-: | :-: |
| 1 | Trust fund recovery penalty liability offers | 13 |

- **Miscellaneous Other Issues**


|  | **Type** | **Issue** | **Minimum Grade** |
| :-: | :-: | :-: | :-: |
| 1 | Timeliness determinations | Timeliness determinations | 9 |
| 2 | ACDS feature code JL | Jeopardy levy | 13 |
| 3 | TFRP – Timely, TBOR2 | Willfulness / responsibility | 13 |
| 4 | TFRP - claim | Willfulness / responsibility | 13 |

**Exhibit 1.4.28-5**

### Case Grading Matrix for Art Appraisal Services Cases

| **Appraisal Complexity**<br>_(as related to personal property under valuation review)_ | **GS 9-11** | **GS-12** | **GS 9-13** | **GS-14** |
| :-- | :-: | :-: | :-: | :-: |
| **Value characteristics, comparables and market** | Value characteristics easily identifiable; clear comparables readily available and most common market is straightforward; market conditions uncomplicated | Value characteristics are identifiable with research; comparables available; most common market is not difficult to determine; market conditions require analysis | Value characteristics may be identifiable with research, though obscure or nuanced; comparables available but interpretation required; most common market may not be easily identifiable; market conditions may be uneven | Value characteristics may be identifiable with research, though obscure or nuanced; comparables not readily available (market thin or seldom traded); market may be non-existent or manufactured; market conditions may be volatile |
| **Research and analysis** | Basic database research is required; minimal interpretation of data is required | Market research from multiple sources and library research is required; data must be analyzed | Significant research from multiple market sources is required; library research required; complex data analysis required | Significant research from multiple market sources and library research may be required; expert consultation may be required; complex analysis of limited data required |
| **Appraiser specialties** | Generally one specialty required | More than one specialty may be required | More than one specialty may be required; may collaborate with other team members to complete case | More than one specialty may be required; may collaborate and/or lead other team members to complete case |
| **Ownership** | Ownership is not in dispute | Ownership is not in dispute | Ownership may be in dispute or fractionalized and the value discounted | Ownership may be in dispute, fractionalized or questionable; discounts may require review |
| **Provenance** | Provenance is established or not critical to valuation | Provenance is established and complete | Provenance may be established or incomplete and require research | Provenance may be established or incomplete or in dispute |
| **Authenticity** | Authenticity is not in dispute; property is documented in recognized sources | Authenticity is not in dispute; property is documented in recognized sources | Authenticity requires verification in recognized sources; may be unverifiable | Authenticity may be in dispute and/or unverifiable |
| **Panel review** | Panel review not needed | Panel review required | Panel review may be required | Panel review may be required or appraiser may need to pursue outside experts |
| **Value** | Value of reviewed property falls below $150,000 | Value of reviewed property is at least $150,000 | Value of reviewed property is at least $150,000 | Value of reviewed property is at least $150,000 |
| **Discounts** | No discounts applied | No discounts applied or if they are, argued in a separate business valuation report | Discounts for fractional ownership or blockage may be applied and require review; property may require application of a discount | Discounts for fractional ownership or blockage may be applied and require review; property may require application of a discount |
| **Condition** | Photographs are of good quality; condition is well documented with a condition report or not in dispute | Photographs are of good quality; condition is well documented with a condition report or not in dispute | Condition may be impactful to value and may not be well described or documented | Condition affects value and may be in dispute or not well documented; may require in person inspection |
| **Factual/legal complexity** | No complex legal issues | May include legal issues requiring analysis but clear precedent exists | Includes multiple legal issues that may not have clear precedence; may require collaboration with technical analysts; may demonstrate patterns of ATAT | Includes multiple legal issues that may not have clear precedence; may require collaboration with technical analysts; may demonstrate patterns of ATAT or fraud |
| **Impact** | No impact beyond the immediate case | Appraisal result may impact subsequent taxable events, such as cap gains, or subsequent tax filings for the same taxpayer or heirs | Appraisal result may impact subsequent taxable events or related taxpayer cases with commonalities. | Appraisal result may impact subsequent taxable events or related taxpayer cases with commonalities. Appraisal may set precedent or has potential to impact or shape policy on an art valuation issue |
| **Expert witness work** | Not required | Not required | May be required | May be required |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-028#addtoany "Show all")

A2A