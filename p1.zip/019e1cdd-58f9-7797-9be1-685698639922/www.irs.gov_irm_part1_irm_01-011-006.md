---
url: "https://www.irs.gov/irm/part1/irm_01-011-006"
title: "1.11.6 Using and Researching the Internal Revenue Manual (IRM) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-006#main-content)

- 1.11.6  [Using and Researching the Internal Revenue Manual (IRM)](https://www.irs.gov/irm/part1/irm_01-011-006#id1)
  - 1.11.6.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-006#id2)
    - 1.11.6.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-006#id4)
    - 1.11.6.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-006#id5)
    - 1.11.6.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-006#id6)
    - 1.11.6.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-011-006#id7)
    - 1.11.6.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-011-006#id8)
    - 1.11.6.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-011-006#id9)
    - 1.11.6.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-011-006#id10)
  - 1.11.6.2  [IRM Purpose and Use](https://www.irs.gov/irm/part1/irm_01-011-006#id11)
  - 1.11.6.3  [Structure of the IRM](https://www.irs.gov/irm/part1/irm_01-011-006#id12)
    - 1.11.6.3.1  [IRM Numbering Scheme](https://www.irs.gov/irm/part1/irm_01-011-006#id13)
    - 1.11.6.3.2  [IRM Section Major Components](https://www.irs.gov/irm/part1/irm_01-011-006#id14)
      - 1.11.6.3.2.1  [Manual Transmittal](https://www.irs.gov/irm/part1/irm_01-011-006#id16)
      - 1.11.6.3.2.2  [IRM Part, Chapter and Section Titles](https://www.irs.gov/irm/part1/irm_01-011-006#id17)
      - 1.11.6.3.2.3  [Table of Contents](https://www.irs.gov/irm/part1/irm_01-011-006#id18)
      - 1.11.6.3.2.4  [Subsections](https://www.irs.gov/irm/part1/irm_01-011-006#id19)
      - 1.11.6.3.2.5  [Exhibits](https://www.irs.gov/irm/part1/irm_01-011-006#id20)
      - 1.11.6.3.2.6  [Index of Key Terms](https://www.irs.gov/irm/part1/irm_01-011-006#id21)
    - 1.11.6.3.3  [IRM Dates](https://www.irs.gov/irm/part1/irm_01-011-006#id22)
    - 1.11.6.3.4  [Official Use Only (OUO) Content](https://www.irs.gov/irm/part1/irm_01-011-006#id23)
  - 1.11.6.4  [IRM Formats](https://www.irs.gov/irm/part1/irm_01-011-006#id24)
    - 1.11.6.4.1  [Internal Revenue Manuals on IRS.gov](https://www.irs.gov/irm/part1/irm_01-011-006#id26)
    - 1.11.6.4.2  [IRM Online](https://www.irs.gov/irm/part1/irm_01-011-006#id27)
    - 1.11.6.4.3  [IRS Historical Research Library IRM](https://www.irs.gov/irm/part1/irm_01-011-006#id28)
    - 1.11.6.4.4  [Legal and Tax Research Services](https://www.irs.gov/irm/part1/irm_01-011-006#id29)
    - 1.11.6.4.5  [Paper IRM](https://www.irs.gov/irm/part1/irm_01-011-006#id30)
    - 1.11.6.4.6  [Publishing + Distribution Website](https://www.irs.gov/irm/part1/irm_01-011-006#id31)
    - 1.11.6.4.7  [Servicewide Electronic Research Program (SERP) IRM](https://www.irs.gov/irm/part1/irm_01-011-006#id32)
  - 1.11.6.5  [Providing Feedback About an IRM Section - Outside of Clearance](https://www.irs.gov/irm/part1/irm_01-011-006#id33)
    - 1.11.6.5.1  [How to Obtain an IRM Author's Name](https://www.irs.gov/irm/part1/irm_01-011-006#id35)
  - 1.11.6.6  [Other Documents Related to the IRM](https://www.irs.gov/irm/part1/irm_01-011-006#id36)
    - 1.11.6.6.1  [Internal Revenue Code (IRC) and United States Code (USC)](https://www.irs.gov/irm/part1/irm_01-011-006#id38)
    - 1.11.6.6.2  [Interim Guidance (IG)](https://www.irs.gov/irm/part1/irm_01-011-006#id39)
    - 1.11.6.6.3  [Chief Counsel Directives Manual (CCDM)](https://www.irs.gov/irm/part1/irm_01-011-006#id40)
    - 1.11.6.6.4  [Document 10988, Internal Revenue Manual Index](https://www.irs.gov/irm/part1/irm_01-011-006#id41)
    - 1.11.6.6.5  [IRM Supplemental Guidance](https://www.irs.gov/irm/part1/irm_01-011-006#id42)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 6. Using and Researching the Internal Revenue Manual (IRM)

* * *

## 1.11.6 Using and Researching the Internal Revenue Manual (IRM)

#### Manual Transmittal

September 02, 2025

#### Purpose

(1) This transmits revised IRM 1.11.6, Internal Management Documents System, Using and Researching the Internal Revenue Manual (IRM).

#### Material Changes

(1) _IRM 1.11.6.1_, Program Scope and Objectives: (1) Revised to reflect purpose of IRM content more precisely. IPU 23U0406 was issued on March 16, 2023.

(2) _IRM 1.11.6.1.1_, Background: (1) Updated the SPDER organization name to include “Resources” instead of “Research” and added SPDER acronym.

(3) _IRM 1.11.6.1.6_, Terms and Acronyms: Revised definition for program owner to more closely align with other IRMs in the 1.11 series. IPU 23U0406 dated March 16, 2023.

(4) _IRM 1.11.6.3.2.1_, Manual Transmittal: (2) Revised to list each type of information the manual transmittal provides more clearly.

(5) _IRM 1.11.6.3.2.2_, IRM Part, Chapter and Section Titles: (2) Added reference to IRM 1.11.4, IRM Formats.

(6) _IRM 1.11.6.4.2_, IRM Online: (4) Revised to indicate the removal of the “Subscribe to, "Favorite,” and “Contact Us” features on IRM Online and added the new “Give Feedback” option. IPU 23U0406 dated March 16, 2023. (5) Added “Interim guidance exists” and “Interim guidance note” features to the table.

(7) _IRM 1.11.6.4.6_, Publishing + Distribution Website: (1) Added a statement to indicate this platform does not contain interim guidance or other updates. (6), (7) Removed discontinued IRM subscription service.

(8) _IRM 1.11.6.4.7_, Servicewide Electronic Research Program (SERP) IRM: (3) Added information about the SERP advanced search feature.

(9) _IRM 1.11.6.5_, Providing Feedback About an IRM Section - Outside of Clearance: (1) Added the IRM "Give Feedback" button as on option.

(10) _IRM 1.11.6.5.1_, How to Obtain an IRM Author’s Name: Added resources and instructions to locate the IRM author.

(11) _IRM 1.11.6.6_, Other Documents Related to the IRM: Added a list of the documents related to the IRM.

(12) _IRM 1.11.6.6.2_, Interim Guidance: (4) Added guidance on where to find the daily listing of new IRM Procedural Updates (IPUs). IPU 23U0406 dated March 16, 2023.

(13) IRM 1.11.6-1, Previous and Current IRM 1.11.6 Subsections Crosswalk: Exhibit removed.

(14) Editorial changes throughout include:

- Added or corrected IRM and document citations

- Added or corrected website and webpage links

- Updated Wage and Investment (W&I) to Taxpayer Services (TS)

- Corrected capitalization, spelling, typos and grammar

- Updated term “organization” to “business unit”

- Updated term “compilation” to “complete inventory”

- Incorporated plain language writing techniques


#### Effect on Other Documents

This IRM supersedes IRM 1.11.6 dated March 23, 2022, and incorporates the IRM Procedural Update (IPU) 23U0406 issued March 16, 2023.

#### Audience

All IRS employees

#### Effective Date

(09-02-2025)

Holly A. Donnelly

Director, Strategy and Business Solutions

Research, Applied Analytics and Statistics

**1.11.6.1** **(03-16-2023)**

### Program Scope and Objectives

1. **Purpose:** This IRM section describes the purpose and structure of the IRM and provides guidance on the various ways to find information in the IRM.

2. **Audience:** All IRS employees.

3. **Policy Owner:** Director, Strategy and Business Solutions (SBS), Research, Applied Analytics and Statistics (RAAS).

4. **Program Owner:** Office of Servicewide Policy, Directives and Electronic Resources (SPDER).

5. **Primary Stakeholders:** Media and Publications (M&P), Servicewide Electronic Research Program (SERP), SERP Communication Program (SCP), and program offices who own and manage an IRM section(s).

6. **Contact Information:** To recommend changes or make suggestions to this IRM section, contact the SPDER office by:



   - Email: \*SPDER

   - Website: Contact SPDER


7. **Goal:** Instruct IRS employees on how to use the IRM and locate information efficiently and effectively in the performance of their duties.


**1.11.6.1.1** **(09-02-2025)**

#### Background

1. In 1999, the IRS formed the Office of Servicewide Policy, Directives and Electronic Resources (SPDER), following the enactment of the IRS Restructuring and Reform Act of 1998. One of the primary goals of IRS modernization was to restore and maintain the IRM as the official compilation of IRS policies, procedures and guidelines.

2. SPDER produces tools to assist employees in using the IRM in the performance of their duties. The core mission is to design, implement and monitor the process by which the IRS creates policy and procedure.


**1.11.6.1.2** **(04-08-2020)**

#### Authority

1. By law, federal agencies are expected to document, publish, and maintain records of policies, authorities, procedures, and organizational operations. The IRM is the source for the IRS. Refer to IRM 1.11.1.1.2, Authority, for Internal Management Documents (IMD) authorities and legal obligations.


**1.11.6.1.3** **(03-23-2022)**

#### Roles and Responsibilities

1. The SPDER program office, under RAAS, SBS, develops, oversees and executes all aspects of the IMD program which includes the IRM.

2. M&P oversees the IRM publishing process, the IRM publishing contract, and the IRM authoring software (Arbortext Editor) contract.

3. The SCP, SERP staff hosts IRMs by request based on end-user need, ensures content is current and accurate, and makes real-time updates to information ensuring content is Section 508 compliant.

4. Program directors Servicewide oversee IMD administration under their program responsibility, including approval of new or revised IMDs.

5. Program owners and the assigned authors manage and execute the IMD program including the IRM.


**1.11.6.1.4** **(03-23-2022)**

#### Program Management and Review

1. SPDER and program owners manage the IRM using the following processes and statistics:



   - Annual IRM Certification - Program owners annually certify the status of their IRM content and management and internal controls.

   - Annual SERP Certification Process - Program owners annually certify whether their SERP IRM content is accurate and current.

   - IRM Statistics - Data statistics for current IRM sections.


**1.11.6.1.5** **(03-23-2022)**

#### Program Controls

1. All IRM authors must follow the IRM 1.11 series and use the current IRM authoring software to author IRM sections.

2. During quality review, managers evaluate whether employees researched, interpreted and correctly applied IRM instructions when performing their duties.


**1.11.6.1.6** **(03-16-2023)**

#### Terms and Acronyms

1. The following table lists the terms and acronyms used throughout this IRM section and their definitions.




| Terms / Acronyms | Definitions |
| :-: | :-: |
| Electronic Freedom of Information Act (EFOIA) | A federal law requiring public availability in an electronic format of instructions to employees affecting a member of the public. |
| Freedom of Information Act (FOIA) | A federal law requiring each agency to maintain administrative staff manuals and instructions to staff that must be made available for public inspection and copying when affecting a member of the public. |
| Interim Guidance (IG) | An official communication conveyed through memoranda or IRM Procedural Updates (IPUs) used by business units or program owners to convey immediate, emergency or temporary changes to operations or procedures for a defined effective period. |
| Interim Guidance Memorandum (IGM) | A type of IG used to issue an immediate or temporary procedural change to IRM procedures or operations in a memorandum. The procedural change is effective until the expiration date, not to exceed two years. |
| Internal Management Document (IMD) | An official communication that designates policies and authorities, and delivers instructions to IRS officials and employees. |
| Internal Revenue Manual (IRM) | The official compilation of IRS policies, procedures and guidelines that employees are required to follow when administering tax laws, performing duties or executing IRS operations. |
| IRM Owner | The program office with primary responsibility for writing and maintaining IRM content. |
| IRM Procedural Update (IPU) | A type of IG used to issue an immediate or temporary procedural change to an IRM posted on SERP. The procedural change is effective for up to two years. |
| Official Use Only (OUO) | A designation placed on sensitive information requiring protection from the public due to the risk and magnitude of loss or harm to the IRS or the privacy to which individuals are entitled under 5 USC 552a. See IRM 11.3.12, Disclosure of Official Information, Designation of Documents. |
| Portable Document File (PDF) | A versatile file format created by Adobe that gives people an easy, reliable way to present and exchange documents - regardless of the software, hardware or operating systems being used by anyone who views the document. |
| Program Director | A member of the Senior Executive Service or their authorized delegate responsible for program administration including issuance and approval of IMDs. See Delegation Order 1-69, Authorization to Approve an Internal Management Document (IMD), for who can be an authorized delegate. |
| Program Owner | The office with responsibility for the administration, procedures and updates related to the program IRM. The program director over this office authorizes and approves IMDs. |
| Search Interim Guidance page | A webpage that contains active and archived IGMs, Servicewide Electronic Research Program (SERP) IPUs, and Servicewide delegation orders and policy statements on the Search Interim Guidance webpage. |
| Servicewide Electronic Research Program (SERP) | An electronic research source, maintained by Taxpayer Services (TS), designed to provide access to current procedural guidance and reference materials on the SERP website. |
| SERP Communication Program (SCP) | The program office, under the guidance of Technical Assistance & Stakeholder Communication (TASC), responsible for ensuring content hosted on the SERP site is current and accurate. |


**1.11.6.1.7** **(04-08-2020)**

#### Related Resources

1. IRM Online, Internal Revenue Manual page: IRM Online

2. Publishing + Distribution Find a Product webpage: Find a Product

3. Electronic Publishing, IRM Numerical Index webpage: IRM Numerical Index

4. Servicewide Electronic Research Program (SERP) IRMs webpage: SERP

5. IRMs on IRS.gov website: IRMs on IRS.gov

6. Integrated Talent Management (ITM) training course # 59521, _The Internal Revenue Manual: An Introduction,_ on IRS Source ITM webpage: ITM (requires login)


**1.11.6.2** **(03-23-2022)**

### IRM Purpose and Use

1. The IRM is the official compilation of IRS policies, procedures and guidelines.

2. The purpose of the IRM is to provide instructions to staff. These instructions relate to administration and operation of the IRS for all business units. The IRM ensures employees have the approved guidelines, policies and authorities they need to carry out their responsibilities in administering tax laws and other agency obligations. The IRM explains what needs to be done, how to do it and who is responsible to ensure consistent work performance.

3. IRS employees, managers and executives use the IRM in the daily performance of their duties.

4. IRM topics range from:



   - Administrative procedures and instructions, such as timekeeping and travel

   - IRS organizational structure, mission, and purpose in IRM 1.1, Organization and Staffing

   - Management practices in IRM 1.4, Resource Guide for Managers

   - Servicewide policy statements (PSs) and delegations of authority in IRM 1.2, Servicewide Policies and Authorities

   - Technical step-by-step instructions for employees throughout the IRS


5. The IRM is also used by the Government Accountability Office (GAO) and specialized groups within the IRS, such as Chief Counsel (CC), Taxpayer Advocate Service (TAS) and Treasury Inspector General for Tax Administration (TIGTA), to:



   - Confirm IRS operates effectively and efficiently and provides quality service to the public

   - Identify potential problems that may result in unnecessary taxpayer burden or present taxpayer rights violations

   - Ensure IRS complies with applicable laws and regulations

   - Reduce risk


6. Members of the public may also view the IRM to learn about IRS policy and procedures. A redacted version of each IRM section is available on IRS.gov through the [Freedom of Information Act (FOIA)](https://www.irs.gov/privacy-disclosure/foia-library) library.


**1.11.6.3** **(03-23-2022)**

### Structure of the IRM

1. The IRM is a manual with a specific structure, format and numbering scheme consistent throughout. Regardless of the type of information found in an IRM section, all sections are formatted the same and look similar.

2. The IRM is assigned, authored, and maintained at the section level. Each section is a separate published product.

3. The IRM is organized by part, chapter, and section.



1. **Part** \- Each part contains instructions for an IRS business process



      ### Note:



      See IRM 1.11.1.5, IMD Numbering by Business Process, for a description of IRS business processes by the IRM part number.

2. **Chapter** \- Each chapter contains a primary topic within the Part

3. **Section** \- Each section covers a specific topic within the Chapter


**1.11.6.3.1** **(03-23-2022)**

#### IRM Numbering Scheme

1. The IRM uses a unique numbering scheme that allows you to quickly locate and identify information needed to perform a task.

2. The IRM number is a series of numbers separated by a decimal point that indicates the location of the information within the IRM, specifically the part, chapter, section and subsection(s).



### Example:



IRM 1.11.6.4.2: The table below illustrates the nested placement of each IRM component.






| Number | IRM Component | IRM Title |
| :-: | :-: | :-: |
| 1 | Part | IRM 1, Organization, Finance, and Management |
| 11 | Chapter | IRM 1.11, Internal Management Documents System |
| 6 | Section | IRM 1.11.6, Using and Researching the Internal Revenue Manual |
| 4 | Subsection 1 | IRM 1.11.6.4, IRM Formats |
| 2 | Subsection 2 | IRM 1.11.6.4.2, IRM Online |


**1.11.6.3.2** **(03-23-2022)**

#### IRM Section Major Components

1. Each IRM section contains the following major components in the order presented:



   - Manual transmittal

   - IRM part, chapter and section titles

   - Table of contents

   - Subsections

   - Exhibits (optional)

   - Index (optional)


**1.11.6.3.2.1** **(09-02-2025)**

##### Manual Transmittal

1. Each IRM section begins with a manual transmittal.

2. The manual transmittal is a summary of the IRM section and it contains the following pertinent information:



   - New and changed content since the last IRM revision

   - The effect on other documents from this IRM section

   - Audience of the IRM section

   - Approving official name and title

   - Revision and effective dates

   - Description and purpose of the IRM section


3. Each manual transmittal includes the following mandatory elements:



1. Transmittal Date - Displays the date the IRM is published

2. Purpose - Tells if the IRM is revised, new, or obsolete

3. Material Changes - Lists all changes the author made to the IRM since the last publishing

4. Effect on Other Documents - Lists any incorporated interim guidance memorandum (IGM) or IRM procedural update (IPU), and if the current IRM supersedes a previous version

5. Audience - Identifies the end users of the IRM section

6. Effective Date - Identifies the date the IRM procedures become effective, which may differ from the transmittal date

7. Signature - Displays the name, title and program office of the approving official that owns the IRM


4. Occasionally you may see the following optional manual transmittal elements:



1. Note - Provides information to the reader to highlight an issue or describe a change

2. Background - Cites the authority for issuing the document or provides background information on the development of the material

3. Scope - Limits the applicability of the IRM, such as during a certain time of year or to employees in a specific job category or area

4. Related Resources - Lists helpful websites, references or other sources of information on the topic.


5. Historical manual transmittals are also used for research in tax court, audits and employee reviews since they record what changed, when it changed and why it changed.


**1.11.6.3.2.2** **(09-02-2025)**

##### IRM Part, Chapter and Section Titles

1. Each IRM section includes the IRM part, chapter and section titles. The location varies depending on the IRM platform.



1. IRM Online shows the IRM part, chapter and section titles at the top of the IRM.

2. The Product Catalog Results, Portable Document File (PDF) version of the IRM lists the titles between the manual transmittal and the table of contents.

3. SERP IRMs and [IRMs on IRS.gov](https://www.irs.gov/irm) list the IRM part numbers and titles as a table of contents that link to related chapters and sections.


2. Refer to the subsections in _IRM 1.11.6.4_, IRM Formats, for detailed information on the different IRM platforms available.


**1.11.6.3.2.3** **(03-23-2022)**

##### Table of Contents

1. The _table of contents_ follows the manual transmittal in each IRM section.

2. The _table of contents_ lists the IRM subsection and exhibit numbers and their titles in an outline format which helps readers easily find information.

3. View the _table of contents_ to find the number and title for each IRM subsection and exhibit.

4. The **table of contents** titles in electronic versions link to the content.


**1.11.6.3.2.4** **(03-23-2022)**

##### Subsections

1. A subsection contains the IRM content. The content conveys procedural instruction or information about the IRM topic.

2. A subsection consists of the following:



1. **Number** \- Represents the Part, Chapter, Section, and Subsection

2. **Date** \- The date the subsection content is effective

3. **Title** \- A description of the content in the subsection

4. **Paragraphs** \- Paragraphs, lists, tables and/or notes


3. Depending on the complexity of the topic, an IRM can include up to five levels of subsections (subtopics). Subsections are nested like an outline.



### Note:



See the **Table of Contents** of any IRM section for an example of the subsection structure.

4. Subsections may also contain **figures**. Figures may contain a graphic, table or caption and are numbered consecutively throughout the IRM.


**1.11.6.3.2.5** **(04-17-2014)**

##### Exhibits

1. Exhibits are illustrative text, tables or graphics placed at the end of an IRM section. Exhibits are optional.

2. Exhibits are consecutively numbered beginning with the IRM section number, followed by a hyphen and the exhibit number.



### Example:



Exhibit 1.2.3-1


**1.11.6.3.2.6** **(03-23-2022)**

##### Index of Key Terms

1. Some IRMs include an **index of key terms** to identify the content in the IRM section. This feature is optional.

2. An IRM index of key terms appears at the end of the IRM following the last subsection or the last exhibit.


**1.11.6.3.3** **(03-23-2022)**

#### IRM Dates

1. The IRM includes four date types listed and defined in the table below:




| Date Type | Definition |
| :-: | :-: |
| Manual transmittal (MT) date | Date M&P publishes the IRM section and posts it in the Core Repository of Published Products (CROPP) housed on the Publishing + Distribution website. This date appears unlabeled at the top of the IRM. |
| IRM effective date | Date the new or revised IRM section is effective. The IRM effective date can be the same as the manual transmittal date (revision date) or be a specific future date. |
| Subsection date | Date the substantially revised subsection information becomes effective. The subsection date can be the same date as the manual transmittal (revision date) or the effective date. |
| Revision date | This date matches the MT date. The revision date only appears on Publishing + Distribution Product Catalog Results page, PDF paper products and Document 10988, Internal Revenue Manual Index. |


**1.11.6.3.4** **(03-23-2022)**

#### Official Use Only (OUO) Content

1. Sensitive content is designated official use only (OUO) when disclosure of the content could adversely affect IRS programs, operations essential to administering the tax laws, or the privacy of an individual. Refer to IRM 11.3.12, Designation of Documents, for information about designating OUO content.

2. When OUO content is included in the IRM it is clearly marked at the beginning and the end with red pound or hashtag signs.

3. It is important not to release information designated OUO to the public. The content contained within the pound signs is redacted from the IRM content made available to the public.


**1.11.6.4** **(03-23-2022)**

### IRM Formats

1. The IRM is available in print and electronic format.

2. You can access the different IRM formats through several different platforms. View the following subsections for information about each IRM product.

3. The table below outlines the various IRM formats in alphabetical order and their intended audiences.




| IRM Product / Platform | OUO Redacted | Intended Audience | For more information |
| :-: | :-: | :-: | :-: |
| Internal Revenue Manuals on IRS.gov webpage at [IRMs on IRS.gov](https://www.irs.gov/irm) | Yes | Public | _IRM 1.11.6.4.1_, Internal Revenue Manuals on IRS.gov |
| IRM Online webpage at IRM Online | No | IRS employees | _IRM 1.11.6.4.2_, IRM Online |
| IRS Historical Research Library webpage at IRS Historical Research Library | No | IRS employees, federal employees, and others upon request | _IRM 1.11.6.4.3_, IRS Historical Research Library |
| Legal and Tax Research Services webpage at RNet Legal and Tax Research Services | Yes | IRS employees and the public | _IRM 1.11.6.4.4_, Legal and Tax Research Services |
| Paper IRM | No | IRS employees | _IRM 1.11.6.4.5_, Paper IRM |
| Publishing + Distribution webpage at Publishing + Distribution | No | IRS employees | _IRM 1.11.6.4.6_, Publishing + Distribution |
| Servicewide Electronic Research Program (SERP) webpage at SERP | No | IRS employees | _IRM 1.11.6.4.7_, Servicewide Electronic Research Program (SERP) |

4. IRM content may be superseded by interim guidance (IG). Refer to _IRM 1.11.6.6.2_, Interim Guidance, for instructions to locate IG updates to the IRM.


**1.11.6.4.1** **(03-23-2022)**

#### Internal Revenue Manuals on IRS.gov

1. IRS posts the IRM on the IRS.gov website in the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) to comply with FOIA legal requirements. This redacted version of the IRM does not contain any OUO content.

2. To view a section of this publicly available version of the IRM:



1. Click **Admin Manuals & Instructions** on the FOIA Library page.

2. Select**Internal Revenue Manual (IRM)**. This opens the **Internal Revenue Manuals, Table of Contents** page organized by IRM parts. Each part number is a link to its table of contents.

3. Select the IRM part that contains the IRM section you need to view to open the table of contents for that IRM part. Each IRM section and title is a link to its content.

4. Scroll to locate the IRM chapter and section you need to view.

5. Click on the IRM section link.


3. Each IRM section shows the table of contents to the left-hand side of the page. Each subsection number and title are a hyperlink to that specific content within the IRM. You may also navigate the content using the scroll feature.

4. IRM sections with images contain a link to the text description of the image.

5. The FOIA Library also houses recent delegation orders, policy statements and interim guidance to staff not yet incorporated into the publicly available IRM. Find the links,**Recent Del Orders/Policy Statements** and **Recent Interim Guidance to Staff**, under the **Admin Manuals & Instructions** heading.


**1.11.6.4.2** **(09-02-2025)**

#### IRM Online

1. IRM Online is a searchable database owned by the SPDER office.

2. It contains the most current version of every published IRM and allows you to research prior revisions.

3. IRM Online uses an advanced search feature or one of the following indexes to search and view the IRM:



   - Number

   - Audience

   - Effective Date

   - Title

   - Owner

   - Revision Date


4. Each IRM section in IRM Online contains the following options (buttons) to enhance your IRM search experience:



   - PDF/Print – Select to view or print a PDF copy of the IRM section

   - Publishing Catalog – Select to open the Product Catalog results page for this IRM section in a new tab

   - SERP/IPUs – Select to see the SERP version or the IRM Procedural Updates Listing for the IRM section, if applicable

   - Library – Use to search the IRS Historical Research Library for prior versions of the IRM section

   - IRS.gov – Select to see the public version of the IRM

   - Interim Guidance / Interim Guidance Exists – Select to see or search IG for the IRM section

   - Give Feedback – Use to send a email to \*SPDER to provide information on a specific IRM section.


5. IRM Online has several user-friendly tools and help features described in the table below.




| Tools and Help Features | Description |
| :-: | :-: |
| Embedded IRM links | Within each IRM section are links to other IRMs, IRS published products and vendor supplied legal research and reference materials. |
| Linking to IRMs tool | The **Link Creation Tool** allows you to enter an IRM number to create a properly formed link to the IRM section/subsection in IRM Online that you can use in a web page, email or other electronic product. |
| Internal Management Documents tool | Provides access to various IMD information pages on the following topics:<br> <br>   - Delegation Orders<br>     <br>   - Policy Statements<br>     <br>   - Internal Revenue Manual (IRM)<br>     <br>   - Search Interim Guidance<br>     <br>   - Chief Counsel Directives Manual (CCDM)<br>     <br>   - Other Internal Management Documents<br>     <br>   - IMD information pages |
| IRM Statistics tool | Links to the IRM Statistics webpage that allows you to view IRM statistics for the entire IRS or by business unit. |
| IRMs Not Yet Effective tool | Links to the Published But Not Yet Effective Index. |
| Obsolete IRMs tool | Links to the IRS Historical Research Library. |
| FAQs help feature | Links to the IRM Online Frequently Asked Questions (FAQs) webpage. |
| Training help feature | Links to the IRM Online Training webpage and includes a link to the Overview of the IRM Online Website Power Point file, the upcoming live TEAMS Meeting training schedule for IRM Online, and instructions on how to enroll. |
| Using Search help feature | Links to the IRM Online Search Help webpage that provides tips to efficiently search the IRM. |
| Privacy Policy help feature | Links to the SPDER - Privacy Policy webpage that includes information and links to privacy policy resources. |
| Contact Us help feature | Opens an Outlook email to \*SPDER |
| Interim guidance exists feature | When interim guidance is present within the IMD Tracking system that affects the displayed IRM section, the IRM Online will display in red text “Interim Guidance Exists” at the top of the IRM section page. The text appears as a button, and is linked to the record within the IMD Tracking system. Select this button to display the related record on the IMD tracking system website. |
| Interim guidance note feature | A note is placed in the bottom right section of the screen when interim guidance is present within the IMD Tracking system that impacts the displayed IRM section. This note advises the user to check the Interim Guidance Search page for any procedural changes. |


**1.11.6.4.3** **(03-23-2022)**

#### IRS Historical Research Library IRM

1. SPDER maintains the IRS Historical Research Library.

2. To access or research versions of the IRM prior to 1997 unavailable on the Publishing and Distribution website, visit the IRS Historical Research Library. The library houses prior revisions of the IRM dating back to 1952.

3. The IRS Historical Research Library also houses documents relating to IRS policy and organizational history including:



   - Policy memoranda prior to the official IRM

   - Treasury Orders from 1960 - 1980

   - Document clearance records (DCRs) for the IRM, delegations of authority, and policy statements from 1952 forward

   - Organizational history files from 1912 including restudies, proposals initiated to design an efficient organizational framework, final recommendations, implementation plans, descriptions of responsibilities assigned to the senior executive officers, organizational charts, and organizational relationships and processes

   - Records documenting organizational, structural, and procedural changes


4. Copies of these documents may be delivered in PDF, hardcopy or fax.

5. Members of the public may request copies of these documents through the FOIA office. Information on how to request is available at [IRS Freedom of Information Act on IRS.gov](https://www.irs.gov/privacy-disclosure/irs-freedom-of-information-act).


**1.11.6.4.4** **(03-23-2022)**

#### Legal and Tax Research Services

1. A redacted version of the IRM is available to the public through legal and tax research services. IRS employees may request access to these services for which the IRS has current contracts by following instructions at Reference Net Legal and Tax Research Services.

2. The IRM published by the legal and tax research services is limited to publicly available portions of the IRM with official use only (OUO) content redacted.


**1.11.6.4.5** **(03-23-2022)**

#### Paper IRM

1. Paper copies of the IRM, produced in PDF format, include a page number in the table of contents. Copies are available to employees but may be subject to certain limitations, such as page count (more than 100 pages) or employee access to electronic sources.

2. Employees without computer access receive print copies of the IRM section(s) they need to perform their work.

3. M&P provides information on paper IRMs on the Internal Revenue Manual (IRM) Program Paper Content page.


**1.11.6.4.6** **(09-02-2025)**

#### Publishing + Distribution Website

1. The Publishing + Distribution’s **Find a Product** website has current and previous versions of the IRM as published by the IRS. These published versions of the IRM do not have interim guidance or other updates.

2. Go to Publishing + Distribution Find a Product, commonly referred to as the **Catalog**, to search and view all current and previous IRM sections published in PDF format.

3. The Catalog provides various ways to search for the IRM and other product types:



   - Catalog Number

   - Product Number

   - Product Title



     > You may also click the IRM Numerical Index link at the bottom of the Catalog page under **Additional Information** to browse all active IRM sections.


4. To locate a specific IRM section:



1. Enter search criteria in **Catalog Number, Product Number,**or **Product Title**fields

2. Click **Find**


5. The IRM Product Catalog Results page provides the following information about each IRM section:



   - IRM section number

   - IRM section title

   - Catalog number

   - Revision date

   - Status (active, obsolete, or historical)

   - Language - the language(s) in which the product is written

   - Security Handling - indicates if an item needs to be locked in a file cabinet in using offices

   - Type of Use - internal use, tax products, tax related public use, and general admin public use

   - Related Product - used when ordering of one item implies that another item should also be ordered

   - Description - identifies who uses the product, what they use it for, when, where, why, and how they use it in a few short statements

   - Electronic PDF files - current and dating back to 1997

   - Extensible Markup Language (XML) file - current file only

   - Where to get copies - shows where users may order/obtain printed copies of the published product

   - Contacts - **Content POC**, **Publishing Specialist**, and **Inventory Management Specialist**

   - Physical Properties including total pages, width, depth, paper color and ink color, product type, unit of issue/units per construction and disposition instructions


**1.11.6.4.7** **(09-02-2025)**

#### Servicewide Electronic Research Program (SERP) IRM

1. Servicewide Electronic Research Program (SERP) is an electronic research source maintained by TS designed to provide access to IRMs, current procedural guidance, and reference materials.

2. SERP contains some but not all IRM sections. An IRM owner may elect to post an IRM section on SERP.

3. SERP IRM Advanced Search allows the user to search by IRM number, title or keyword. You can search SERP IRMs by part, chapter, then section. You may also use links in the right-hand column of SERP IRMs to search by **IPU Lookup**, **IPUs by Month**, **IRM Authors** and **IRMs Removed**.

4. Program owners with IRMs hosted on SERP use an IRM Procedural Update (IPU) to quickly update the SERP IRM and expeditiously communicate the change(s) to employees.

5. The SERP Communication Program (SCP) posts the IPU and the revised IRM to the SERP website. The changed content appears highlighted in yellow so employees can easily locate the changes. The revised subsection date reflects the IPU revision date. IPUs that meet the FOIA criteria are redacted and posted on the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) on IRS.gov.

6. Program owners either incorporate an IPU into the published IRM within a maximum of two years from the issuance date or supersede with a subsequent IPU. When the revised IRM is published, the IRM on SERP updates to the new revision.

7. You may submit feedback on SERP IRM content to the IRM author using the SERP Feedback System.


**1.11.6.5** **(09-02-2025)**

### Providing Feedback About an IRM Section - Outside of Clearance

1. You may give feedback on a specific IRM section by:



1. Emailing the originating office outlining the issue including the IRM reference(s) and the recommended change(s).

2. Clicking the IRM Online**Contact Us** link under **Help** to submit your feedback to the SPDER staff via email. SPDER directs your email to the appropriate IRM office.

3. Using the IRM Online**Give Feedback** button located at the top of a specific IRM section.

4. Contacting the business unit's IMD coordinator. Refer to **SPDER’s IMD Contacts List** on the IMD Community webpage. Select your business unit and contact the employee listed as "IMD Coordinator."

5. Clicking the **Feedback** button at the top of the page on a SERP hosted IRM to submit your feedback to SCP. SCP staff forwards your feedback to the appropriate IRM program owner for consideration and response.

6. Contacting the IRM author. Refer to _IRM 1.11.6.5.1_, How to Obtain an IRM Author's Name, for instructions.



      ### Note:



      Contact your lead or manager on the preferred method for submitting changes to the IRM since each program owner has their own procedures for handling IRM feedback.


2. IRM authors acknowledge and consider feedback regardless of how you submit the request. When a recommended change is not adopted which could adversely affect your program, process or activity, you may elevate your change request through your management chain. For guidance on this process, refer to IRM 1.11.2.5.1.3, Respond to Requested IRM Changes.


**1.11.6.5.1** **(09-02-2025)**

#### How to Obtain an IRM Author's Name

1. Use the Publishing + Distribution Find a Product, Electronic Publishing IRM Numerical Index, or SERP to locate the IRM author.

2. Follow the instructions below to locate the IRM author from Publishing + Distribution Find a Product webpage:




| **Step** | **Action** |
| :-: | :-: |
| 1 | Go to **_Publishing + Distribution Find a Product_** |
| 2 | Select the product type drop-down arrow under Product Title, and select the IRM option |
| 3 | Enter the IRM number in the Enter search word(s) box |
| 4 | Click Find |
| 5 | Click the title of the IRM in the search results page |
| 6 | Scroll down to Contacts |
| 7 | Find the Content POC (IRM author) name, telephone number and office symbols |

3. Follow the steps outlined below to locate the author from the Electronic Publishing IRM Numerical Index webpage:




| **Step** | **Action** |
| :-: | :-: |
| 1 | Go to _**Electronic Publishing IRM Numerical Index**_ |
| 2 | Expand the **IRM Part** number |
| 3 | Click on the **Cat. No.** |
| 4 | Scroll down to **Contacts** |
| 5 | Find the **Content POC** (IRM author) name, telephone number, and office symbols |

4. Follow the steps outlined below to locate the author from Servicewide Electronic Research Program (SERP) webpage:




| **Step** | **Action** |
| :-: | :-: |
| 1 | Go to **_Servicewide Electronic Research Program (SERP)_** |
| 2 | Click on the SERP IRMs menu option |
| 3 | Select IRM Authors option under the SERP IRM Menu |
| 4 | Click on the IRM Part number in the search results |
| 5 | Find the IRM author’s name in the IRM Author Listing results |


**1.11.6.6** **(09-02-2025)**

### Other Documents Related to the IRM

1. Certain documents influence or are influenced by the IRM.



   - **Internal Revenue Code (IRC)** and **United States Code (USC)**. The IRC is the comprehensive body of federal tax laws in the United States and is Title 26 of the USC. Refer to _IRM 1.11.6.6.1_, Internal Revenue Code (IRC) and United States Code (USC), for more information.

   - **Interim Guidance (IG)**. Interim guidance is issued between IRM revisions. Refer to _IRM 1.11.6.6.2_, Interim Guidance (IG), for more information.

   - **Chief Counsel Directives Manual (CCDM)**. The CCDM contains instructions and guidelines that address the processes and activities of the Office of the Chief Counsel. Refer to _IRM 1.11.6.6.3_, Chief Counsel Directives Manual (CCDM), for more information.

   - **Document 10988, Internal Revenue Manual Index**. The IRM index is a complete inventory of currently effective IRM sections published by Media and Publications. Refer to _IRM 1.11.6.6.4_, Document 10988, Internal Revenue Manual Index, for more information.

   - **IRM Supplemental Guidance**. Supplemental guidance refers to sources that supplement the IRM such as: job aids, desk guides and knowledge management materials. Refer to _IRM 1.11.6.6.5_, IRM Supplemental Guidance, for more information.


**1.11.6.6.1** **(03-23-2022)**

#### Internal Revenue Code (IRC) and United States Code (USC)

1. The U.S. Government publishes the Internal Revenue Code (IRC) as Title 26 of the United States Code (USC).

2. You can research the IRC/USC through various research services contracted by the IRS.



### Note:



You need an account to access these research services. To learn more about the research services and to find your ID administrator for access information, go to Reference Net . Locate the product you need. Click on the respective tab for assistance with obtaining an ID.

3. You can also research the IRC/USC on the [Gov Info](https://www.govinfo.gov/app/collection/uscode/) and the [U.S. House of Representatives](https://uscode.house.gov/) websites.



### Note:



The IRS does not provide these sites, so verify the accuracy and currency of the information.


**1.11.6.6.2** **(03-16-2023)**

#### Interim Guidance (IG)

1. Interim guidance (IG) may temporarily supplement or update IRM content. Business units and program owners issue IG using one of two formats:



   - Interim Guidance Memorandum (IGM)

   - IRM Procedural Update (IPU)


2. Search Interim Guidance contains active IGMs and IPUs and expired IGMs.

3. You may confirm IG for an IRM section by opening the applicable IRM section on IRM Online. If IG exists, a pop-up window appears noting there is IG.

4. SERP lists all IPUs and SERP Alerts issued for the day on the home page.

5. IG meeting conditions under FOIA is posted to the [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library) by related IRM number, under Recent IG to Staff.


**1.11.6.6.3** **(04-17-2014)**

#### Chief Counsel Directives Manual (CCDM)

1. The Chief Counsel Directives Manual (CCDM) contains instructions and guidelines that address the processes and activities of the Office of the Chief Counsel. The CCDM is available in PDF format from the Electronic Publishing catalog page and on CCDM Online.

2. The structure and numbering of the CCDM, in Parts 30 through 39, is like the IRM.


**1.11.6.6.4** **(03-23-2022)**

#### Document 10988, Internal Revenue Manual Index

1. Document 10988, Internal Revenue Manual Index, is a complete inventory of currently effective IRM sections published by Media and Publications. The index is published semi-annually and produced monthly.

2. The index sorts the IRM sections into four listings:



   - Numerical Index

   - Owner Audience Index (alphabetical order by owner, then numerical order by IRM part)

   - Alphabetical Index (by IRM section title)

   - Obsolete Index (in numerical order by IRM part)


3. The index provides the following information about each new, revised and obsolete IRM section:



   - Revision date

   - Catalog number

   - Old IRM number

   - Title

   - Organizational owners

   - User audience


4. The index identifies IRM sections containing OUO information with an asterisk following the IRM section number.


**1.11.6.6.5** **(03-23-2022)**

#### IRM Supplemental Guidance

1. An IRM section may link to supplemental guidance to assist you in performing your duties.

2. Each supplemental source of guidance must reference the applicable IRM(s).

3. These sources must support or supplement the IRM. They do not replace the IRM. Use them with the IRM. If there is a contradiction between supplemental guidance and the IRM, the IRM takes precedence.

4. Supplemental guidance includes:



   - Published products - such as Document 9669, Employee Personnel Resource Guide

   - Job aids/desk guides - provide guidance on performance of a specific task and reference the IRM

   - Local instructions/local procedures - provide instruction for a program within a particular office or geographic location that supplements or supports IRM procedures

   - Online/web-based decision tools - assist in the performance of your duties, usually through a series of questions and answers or scenarios

   - Knowledge management materials - such as standard operating procedures (SOP)

   - User guides - describe how to use and operate computer software or an application

   - Check sheets - use to ensure a process is complete and correct

   - Training materials - provide employees the program instruction they need to develop new skills to perform a task process, or enhance or improve current skills



     ### Caution:



     Although training materials are based on the IRM, you should never use them in place of the IRM.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-006#addtoany "Show all")

A2A