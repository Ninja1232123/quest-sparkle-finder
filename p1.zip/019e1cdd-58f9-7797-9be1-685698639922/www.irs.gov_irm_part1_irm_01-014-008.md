---
url: "https://www.irs.gov/irm/part1/irm_01-014-008"
title: "1.14.8 Identifying Space Efficient Buildings | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-008#main-content)

- 1.14.8  [Identifying Space Efficient Buildings](https://www.irs.gov/irm/part1/irm_01-014-008#id1)
  - 1.14.8.1  [Program Scope](https://www.irs.gov/irm/part1/irm_01-014-008#id2)
    - 1.14.8.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-014-008#id4)
    - 1.14.8.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-014-008#id5)
    - 1.14.8.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-008#id6)
    - 1.14.8.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-014-008#id7)
    - 1.14.8.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-014-008#id8)
    - 1.14.8.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-014-008#id9)
    - 1.14.8.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-008#id10)
  - 1.14.8.2  [Effectively Managing and Using Space](https://www.irs.gov/irm/part1/irm_01-014-008#id11)
  - 1.14.8.3  [Minimizing Rental Costs](https://www.irs.gov/irm/part1/irm_01-014-008#id12)
  - 1.14.8.4  [Building Conditions that Affect Space Efficiency](https://www.irs.gov/irm/part1/irm_01-014-008#id13)
  - 1.14.8.5  [Market Surveys and RLP Evaluations](https://www.irs.gov/irm/part1/irm_01-014-008#id14)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 8. Identifying Space Efficient Buildings

* * *

## 1.14.8 Identifying Space Efficient Buildings

#### Manual Transmittal

August 26, 2025

#### Purpose

(1) This transmits IRM 1.14.8, _Identifying Space Efficient Buildings_.

#### Material Changes

(1) _IRM 1.14.8.1 (1)_ \- Removed references to organizations through which space is leased. One is referenced in the relevant subsection, and the other is no longer applicable.

(2) _IRM 1.14.8.1 (2)_ \- Updated to define first instance of acronym used for Facilities Management and Security Services (FMSS).

(3) _IRM 1.14.8.1 (4)_ \- Updated title of policy owner.

(4) _IRM 1.14.8.1 (5)_ \- Updated title and department name for program owner.

(5) _IRM 1.14.8.1.2 (1)_ \- Updated reference for current policy foundation, added link to cited resource, and removed paraphrasing of what document contains.

(6) _IRM 1.14.8.1.2 (2)_ \- Updated reference to reflect current policy foundation and added link to cited resource.

(7) _IRM 1.14.8.1.3 (1)_ \- Updated to use previously defined acronym for Territory Manager (TM), define acronym for Project Managers (PM), remove title and acronym for Real Property Leasing Officer (RPLO) and replace it with Realty Specialists (RS).

(8) _IRM 1.14.8.1.3 (2)_ \- Updated acronym from RPLO to RS.

(9) _IRM 1.14.8.1.3 (3)_ \- Updated to use previously defined acronym and clarify language for time-line of review for continuing leases.

(10) _IRM 1.14.8.1.3 (4)_ \- Updated to use previously defined acronym and include the location for project files.

(11) _IRM 1.14.8.1.4_ \- Added Program Management and Review to internal controls and renumbered subsequent subsections.

(12) _IRM 1.14.8.1.5_ \- Added Program Controls to internal controls and subsequent subsections renumbered.

(13) _IRM 1.14.8.1.6_ \- Updated section number and title of section, and edited table to update for new acronyms and to remove acronyms no longer in use.

1. Added acronyms for Asset Management Plan (AMP), Computer Aided Facilities Management (CAFM), Office of Management and Budget (OMB), Project Manager (PM) and Realty Specialist (RS).

2. Removed acronyms for Real Estate and Facilities Management (REFM), and Real Property Leasing Officer (RPLO).


(14) _IRM 1.14.8.1.7_ \- Added Related Resources internal control subsection that was not included in prior IRM version.

(15) _IRM 1.14.8.2_ \- Updated title of subsection for plain language.

(16) _IRM 1.14.8.2 (1)_ \- Updated to include name of area responsible for managing resources and funds and clarify language.

(17) IRM 1.14.8.2(4) - Paragraph removed as it is no longer applicable and subsequent paragraph renumbered.

(18) _IRM 1.14.8.3 (2)_ \- Updated **_Note_** to clarify language and provide additional examples of factors to consider when reviewing space.

(19) _IRM 1.14.8.3 (3)_ \- Removed reference to delegated IRS documents as these are no longer applicable.

(20) _IRM 1.14.8.5 (3)_ \- Updated link to Request for Lease Proposal (RLP) document and updated references to individual paragraphs within the RLP.

(21) _IRM 1.14.8.5 (4)_ \- Revised to clarify language for actions to take and link to cited IRM section.

(22) _IRM 1.14.8.5 (5)_ \- Revised format to include an If/Then table that clarifies situations and actions to take if there is a question about whether space requirements can be met after a market survey is complete.

(23) _IRM 1.14.8.5 (6)_ \- Revised to clarify actions to be taken if building is not acceptable.

(24) Edited for grammar, plain language, and parallel language throughout.

#### Effect on Other Documents

This IRM supersedes IRM 1.14.8, published September 27, 2017.

#### Audience

Facilities Management and Security Services

#### Effective Date

(08-26-2025)

John Pekarik

Acting Chief

Facilities Management and Security Services

**1.14.8.1** **(08-26-2025)**

### Program Scope

1. This IRM section applies to the evaluation of all future leased office space acquisitions.

2. **Purpose**: This IRM section provides Facilities Management and Security Services (FMSS) Territory Managers (TM) and their staff with guidance to evaluate proposed leased properties for space efficiency.

3. **Audience**: FMSS.

4. **Policy Owner**: Chief, FMSS.

5. **Program Owner**: Associate Director, Project Management.

6. **Primary Stakeholders**: FMSS Employees.


**1.14.8.1.1** **(09-27-2017)**

#### Background

1. This IRM contains guidelines for identifying building conditions that affect space efficiency. Building space efficiency is essential to the goal of ensuring the most efficient utilization of space by IRS personnel.


**1.14.8.1.2** **(08-26-2025)**

#### Authority

1. [Federal Property Management Reform Act of 2016 (FPRMA)](https://www.govinfo.gov/content/pkg/PLAW-114publ318/pdf/PLAW-114publ318.pdf).

2. [Office of Management and Budget (OMB), Management Procedures Memorandum 2024-01, August 16, 2024](https://bidenwhitehouse.archives.gov/wp-content/uploads/2024/08/MPM-2024-01-Implementation-of-Occupancy-Metrics-for-Office-Space.pdf).


**1.14.8.1.3** **(08-26-2025)**

#### Responsibilities

1. FMSS TMs must ensure that their Project Managers (PM) work with GSA or the Realty Specialists (RS) to identify options that provide the best value to the IRS in terms of cost and space efficiency.

2. FMSS Territory staff will identify for GSA, or the RS, space efficiency features important for the specific lease procurement requirement.

3. FMSS TMs must ensure that the requirements for new or continuing leases are developed at least 36 months prior to lease expiration to allow evaluation for space efficiency.

4. FMSS PMs will include the evaluation for space efficiency in the project files on the Space Time and Resources (STAR) SharePoint site.


**1.14.8.1.4** **(08-26-2025)**

#### Program Management and Review

1. Real Property administers the Strategic Space Planning Program with additional procedures for In-term Space Reductions and Specialty Group Requests for Expansion Space. Strategic Space Planning is aided by using the IRS Facilities Design Standards and FMSS Office Design Handbook for architecture, engineering, and design support.

2. Realty Management maintains quarterly Asset Management Plans (AMP) to analyze the IRS real property inventory and development strategies.

3. FMSS Territory Project Managers implement space project plans and measure space efficiency throughout the iterative design process.

4. Architecture & Engineering team reviews detailed estimates and space plans prior to project funding approval. Once plans are final, Computer Aided Facilities Management (CAFM) publishes final drawings to the TRIRIGA system.


**1.14.8.1.5** **(08-26-2025)**

#### Program Controls

1. Program documentation and information is centralized and stored on a SharePoint site with access limited to authorized personnel.

2. Comprehensive documentation of each request for space and the corresponding drawings that illustrate space optimization are posted to the Territory Building and Project Page.

3. Asset Management Plans (AMP) are posted on the FMSS Asset Management Plans (AMP) SharePoint site.

4. Biannual workspace efficiency reports are submitted by FMSS through Treasury to OMB to demonstrate compliance with the minimum annual occupancy of 60% in all office space at a measure of 150 usable square feet per person (OMB 2024-01)


**1.14.8.1.6** **(08-26-2025)**

#### Terms and Acronyms

1. The following acronyms are used throughout this document:




| **Acronym** | **Definition** |
| --- | --- |
| AMP | Asset Management Plan |
| ANSI | American National Standards Institute |
| BOMA | Building Owners and Managers Association |
| BU | Business Unit |
| CAFM | Computer Aided Facilities Management |
| FMSS | Facilities Management and Security Services |
| GSA | General Services Administration |
| OMB | Office of Management and Budget |
| PM | Project Manager |
| RLP | Request for Lease Proposal |
| RS | Realty Specialist |
| R/U | Rentable/Usable |
| SFO | Solicitation for Offers |
| STAR | Space Time and Resources |
| TM | Territory Manager |


**1.14.8.1.7** **(08-26-2025)**

#### Related Resources

1. IRM 1.14.6, _Real Property Program_


**1.14.8.2** **(08-26-2025)**

### Effectively Managing and Using Space

1. A primary goal of Real Property is to manage resources in the most efficient and economic manner practicable. Stewardship funds are the majority of the FMSS budget and FMSS must manage these funds as effectively as possible. Since the stewardship budget consists mostly of rent, FMSS can best administer its rent costs through effectively acquiring, managing, and using space. This is accomplished by leasing office space that is configured to maximize the efficiency of floor plan and furniture layouts.

2. GSA is the primary service provider for the IRS and in conjunction with the Treasury Department must follow all GSA and other federal provisions for effective asset management.

3. The Treasury Department requires its agencies to develop and maintain prudent asset management practices that optimize use of space.


**1.14.8.3** **(08-26-2025)**

### Minimizing Rental Costs

1. When acquiring new space, lease only the minimal required area necessary for the IRS to accomplish its mission at the lowest possible rental rate.

2. Rental costs can be minimized by selecting the most space efficient building possible. Many factors affect the efficiency of a floor plate such that two buildings with the same amount of usable office area may yield significantly different levels of efficiency.



### Note:



For example, a building with a 20 foot by 30 foot column spacing would be much more efficient than one with a 20 foot by 15 foot column spacing due to the interruption of clear open space required for optimal space planning. A rectangular or square shaped space will always be more efficient than a triangular shape or a side wall that is not straight up and down as opposed to angled in.

3. GSA lease documents use the American National Standards Institute/Building Owners and Managers Association (ANSI/BOMA) international standard (Z-65.1-2010) definition for office area, known as "ANSI/BOMA Office Area" and previously usable square feet.

4. Other factors such as the age of the building inventory, the requirements of the Business Unit (BU) or the number of leasing opportunities in any market may influence which "space efficient" features can be best utilized.

5. FMSS Territories are obligated to evaluate potential lease sites based on conditions unique to the territory.



1. Territories should avoid sites where the building core location or other elements of the floor plan preclude IRS from releasing marketable portions of space to GSA. Additionally, space should be configured, if possible, to allow for future release of space with minimal alterations.

2. Whenever possible, space on a single, larger, and more efficient floor is preferable to space on multiple smaller floors.


**1.14.8.4** **(08-26-2025)**

### Building Conditions that Affect Space Efficiency

1. Consider the following building factors or conditions when evaluating a proposed office for space efficiency.

2. **Floor Plates**



1. Full floors measuring 20,000 - 26,000 ANSI/BOMA office area (usable) square feet with a single core are most efficient.

2. Full floors measuring 10,000 - 16,000 ANSI/BOMA office area (usable) square feet are typically inefficient.

3. Rectangular floor plates with a single center core are most efficient.

4. Buildings with curved exteriors are not efficient, especially for workstation layouts.


3. **Building Cores**



1. Split cores (e.g., stairwells are separated from the main core) may affect space layouts and will result in more circulation space.

2. A core not centered on a floor may make it difficult to release marketable space to GSA.


4. **Walls & Columns**



1. Permanent walls constructed within the interior of a floor may affect optimal open space and office layouts and result in more circulation space.

2. Extremely long, narrow runs of space can affect optimal open space and office layouts.

3. The depth of perimeter columns can affect optimal open space and office layouts since deeper columns can create unusable pockets of space between the columns.

4. Column dimensions greater than 24 inches by 24 inches will create inefficiencies.

5. Inconsistent column spacing will usually create inefficiencies.

6. Column spacing less than 20 feet by 20 feet on center of the column will affect optimal space layout. Newer steel or concrete construction buildings may have clear spans with few to no intervening columns.


5. **Ceilings**



1. A standard GSA Request for Lease Proposal (RLP), previously known as Solicitation for Offers (SFO), prescribes height minimums, but low ceiling conditions will restrict use of space.

2. Sloped ceilings will restrict use of the space.


6. **Windows**



1. ANSI/BOMA office area (usable) square feet is measured from the inside of the dominant feature of the exterior wall, which in most cases is the window glass. When window systems are situated in "deep pockets" of drywall, the result is less usable space.


7. **Mechanical and Electrical System Conditions**



1. Walker duct floor systems for electric and telecommunications receptacles will limit open space and office planning.

2. Induction units and baseboard heaters along the perimeter of the premises will affect optimal furniture layout.

3. The main air return duct for a floor usually creates a noisy condition as it enters the mechanical room. The RLP includes noise tolerances, but this specific location may still restrict use of the floor space nearby.


8. **Suite Configuration and Contiguous Space**



1. Irregular suite configurations will impact open space and office layouts.

2. Locating a requirement in the fewest number of suites within a building is the most efficient and flexible work arrangement.


9. The following building common area features will not make the tenant premises efficient. However, the existence of these features in a building may increase the Rentable/Usable (R/U) factor and may result in higher rental costs:



1. The size of the main building lobby.

2. The floor space pertinent to an atrium or light well.

3. Common service areas such as building conference facilities, fitness centers and vending areas.

4. Buildings with an R/U factor greater than 1.15 should be scrutinized especially if the ANSI/BOMA office area (usable) space is not largely efficient.


**1.14.8.5** **(08-26-2025)**

### Market Surveys and RLP Evaluations

1. The market survey of potential space is integral to ensure that not only will the IRS mission needs be met, but that the government receives maximum value and utilization of the space to be procured.

2. Territory staff participating in market surveys must ensure that any potential spaces offered to the government meet the specifications of this IRM as it pertains to space efficiency and potential for efficient layout.

3. The standard [RLP paragraphs](https://www.gsa.gov/system/files/Global%20Request%20for%20Lease%20Proposal%20%28RLP%29%20Template%20R100%20%28Mar.%202025%29%20NC%20because%20the%20Adobe%20License%20Expired%20and%20Accessibility%20Not%20Available%20031125.pdf) pertaining to a potential building’s ability to deliver effective space utilization and mandatory requirements for location and building quality, and other amenities, are:



1. 1.05 "Neighborhood, Parking, Location Amenities, and Public Transportation"

2. 2.01 "Efficiency of Layout"


4. If a potential building clearly does not meet the criteria of _IRM 1.14.8.5 (3)_, and is unacceptable due to efficiency or quality concerns, then Territory staff must not concur on the market survey that the building will be solicited. Territory staff must document that GSA was notified in writing that the unacceptable building should not be solicited.

5. Territory staff must determine whether IRS space requirements can be met within the square footage offered once the market survey of potential locations is complete and the initial offers are evaluated.




| **If** | **Then** |
| :-: | :-: |
| It is **clear** that IRS requirements cannot be met due to inefficiencies that weren’t evident during the market survey. | The offer is unacceptable. |
| It is**not clear**that IRS requirements can be accommodated. | Territory staff should make a request of the Offeror to provide a test fit layout (drawing) at the Offeror’s expense as permitted by the RLP-Efficiency of Layout, see _IRM 1.14.8.5 (3)_, and determine whether the space offered is acceptable based on the efficiency of floor plans. |

6. If the offer is not acceptable, territory staff must document that GSA was notified in writing that the building is unacceptable.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-008#addtoany "Show all")

A2A