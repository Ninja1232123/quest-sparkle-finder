---
url: "https://www.irs.gov/irm/part1/irm_01-018-005"
title: "1.18.5 National Distribution Center | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-018-005#main-content)

- 1.18.5  [National Distribution Center](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481150912)
  - 1.18.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481076256)
    - 1.18.5.1.1  [Related Resources](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481072864)
    - 1.18.5.1.2  [Acronyms](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481083264)
    - 1.18.5.1.3  [Background](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481158384)
  - 1.18.5.2  [Order Entry](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481168048)
    - 1.18.5.2.1  [Telephone Operations](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481163968)
    - 1.18.5.2.2  [Customer Types](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898481162208)
    - 1.18.5.2.3  [Mail Receipt](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898513920464)
    - 1.18.5.2.4  [Order Receipt](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898513918736)
    - 1.18.5.2.5  [Form 5753 – Action on Your Tax Form Order](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898513915648)
    - 1.18.5.2.6  [Invalid Address](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898513913792)
  - 1.18.5.3  [Order Fulfillment](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898513910224)
    - 1.18.5.3.1  [Types of Orders](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898513905792)
    - 1.18.5.3.2  [Public Order Fulfillment](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482144768)
      - 1.18.5.3.2.1  [Receiving Public Orders](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482143776)
      - 1.18.5.3.2.2  [Picking Tickets](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482141184)
        - 1.18.5.3.2.2.1  [Forms Clerk Fulfillment Responsibilities](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482135792)
      - 1.18.5.3.2.3  [Special Notices](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482133504)
    - 1.18.5.3.3  [Internal Order Fulfillment](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482130640)
    - 1.18.5.3.4  [Stocking Order Fulfillment](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482128496)
    - 1.18.5.3.5  [NDC Transportation Operations](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482126800)
  - 1.18.5.4  [Logistics](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482122816)
    - 1.18.5.4.1  [Product Maintenance](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482117696)
    - 1.18.5.4.2  [Disposals](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482115920)
    - 1.18.5.4.3  [Inventory Accuracy (Cycle Counting)](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482113968)
    - 1.18.5.4.4  [Reorder Points](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482111984)
    - 1.18.5.4.5  [Planned Shipments](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482109520)
    - 1.18.5.4.6  [Bulk Order Fulfillment](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482107152)
  - 1.18.5.5  [Specialty Programs](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482105392)
    - 1.18.5.5.1  [Tax Forms Outlet Program (TFOP)](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482099648)
    - 1.18.5.5.2  [Training Publication Distribution System (TPDS)](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482097696)
    - 1.18.5.5.3  [Security Products](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482095376)
    - 1.18.5.5.4  [Prior Year](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482093408)
    - 1.18.5.5.5  [Volunteer Income Tax Assistance (VITA) Program](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482062256)
    - 1.18.5.5.6  [Package Assembly Program](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482060336)
    - 1.18.5.5.7  [QuickReact Letters](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482058112)
    - 1.18.5.5.8  [Supply Items](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482056272)
    - 1.18.5.5.9  [Automated Data Processing Training Materials-On Demand Printing](https://www.irs.gov/irm/part1/irm_01-018-005#idm139898482054464)

# Part 1. Organization, Finance, and Management

# Chapter 18. Distribution

# Section 5. National Distribution Center

* * *

## 1.18.5 National Distribution Center

#### Manual Transmittal

June 06, 2025

#### Purpose

(1) This transmits revised IRM 1.18.5, Distribution, National Distribution Center.

#### Material Changes

(1) Updated Signature to reflect current Distribution director.

(2) IRM 1.18.5.5, Table of Contents, Specialty Programs, IRM 1.18.5.5.1, International Program dissolved, IRM 1.18.5.5.4, Internal Management Document Distribution System (IMDDS) dissolved, IRM 1.18.5.5.8, Small Business Program dissolved.

(3) IRM 1.18.5.1.2, Acronyms, Definition updated to correct TFOP to Tax Forms Outlet Program from Tax Assistance Center.

(4) IRM 1.18.5.5 Added new program, Automated Data Processing Training Material.

(5) Made editorial changes throughout. This includes updates to organizational title Wage and Investment to Taxpayer Services (TS) where applicable.

- Update organizational information

- Updated websites

- Adhere to Plain Writing requirements


#### Effect on Other Documents

IRM 1.18.5 dated February 1, 2021 is superseded.

#### Audience

IRS Employees

#### Effective Date

(06-06-2025)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.18.5.1** **(01-29-2018)**

### Program Scope and Objectives

1. Purpose: This manual describes the National Distribution Center (NDC) responsibilities in providing order fulfillment services and distribution of products to IRS customers.

2. Audience: The manual is for all IRS employees especially those who make decisions in order fulfillment.

3. Policy Owner: Administration of the National Distribution Center falls under the direction of the Chief, Taxpayer Services (TS).

4. Program Owner: Media and Publication (M&P) is the program office responsible for overseeing and providing guidance for the NDC.


**1.18.5.1.1** **(02-01-2021)**

#### Related Resources

1. The websites customers use when placing internal and external orders are:



   - website for internal orders: https://caps.enterprise.irs.gov/osms/views/homePage.xhtml

   - website for external orders: https://www.irs.gov


**1.18.5.1.2** **(06-06-2025)**

#### Acronyms

1. We use the following acronyms throughout the IRM:




| **Acronym** | **Definition** |
| --- | --- |
| ADP | Automated Data Processing |
| CAPS | Computer Assisted Publishing System |
| COTS | Commercial-off-the-shelf |
| DMS | Distribution Management System |
| ELITE | Enterprise Logistics Information Technology |
| ESN | Electronic Status Notice |
| EWCS | ELITE Warehouse Control System |
| FMS | Forecasting Management System |
| M&P | Media and Publication |
| NDC | National Distribution Center |
| OMS | Order Management System |
| OSMS | Order Subscription Management System |
| OTP | One Time Print |
| SPEC | Stakeholder Partnerships, Education and Communications |
| TAC | Taxpayer Assistance Center |
| TS | Taxpayer Services |
| TFOP | Tax Forms Outlet Program |
| TPDS | Training Publication Distribution System |
| TMS | Transportation Management System |
| VITA | Volunteer Income Tax Assistance |
| WMS | Warehouse Management System |


**1.18.5.1.3** **(02-01-2021)**

#### Background

1. The NDC provides order fulfillment services and distribution of products to IRS internal and external customers. The distribution center uses two software systems for operations:



   - Enterprise Logistics Information Technology (ELITE)

   - Computer Assisted Publishing System (CAPS)


2. The Enterprise Logistics Information Technology (ELITE) system maintains NDC inventory, controls orders, manages account information, and provides warehouse management tools. ELITE also generates picking tickets that NDC staff uses to fill orders. ELITE is a commercial-off-the shelf (COTS) application that includes the following modules:



   - Order Management System (OMS)

   - Warehouse Management System (WMS)

   - Distribution Management System (DMS)

   - ELITE Reporting Facility

   - Forecasting Management System (FMS)

   - ELITE Warehouse Control System (EWCS)

   - Transportation Management System (TMS)


3. The CAPS system maintains product specifications such as (weight, size, case quantity, page count, product availability, etc.). CAPS then downloads this information into ELITE. The Order Subscription Management System (OSMS) is an online ordering system for internal orders that operates with CAPS.


**1.18.5.2** **(02-01-2021)**

### Order Entry

1. The Processing Section at the NDC receives public and internal requests for IRS products. Customers may order by phone, or mail and through the IRS intranet and Internet websites.



   - Phone number for internal orders: 800-829-2765

   - Phone number for external orders: 800-829-3676

   - Efax number for internal orders: 855-473-2007

   - Website for internal orders: https://caps.enterprise.irs.gov/osms/views/homePage.xhtml)

   - Website for external orders: https://www.irs.gov


**1.18.5.2.1** **(01-29-2018)**

#### Telephone Operations

1. A designated employee responds to telephone messages from internal customers who place orders or request information about the status of products and orders.


**1.18.5.2.2** **(02-01-2021)**

#### Customer Types

1. Some products and quantities are restricted to particular customers or customer groups. ELITE flags orders that exceed the quantity limits and the system generates a daily report of those orders. Analysts review the report each day and decide whether to override the limitations or reject the order.

2. The quantity limitations for tax products by customer are set in ELITE.




| **Order Type** | **Description** |
| :-: | :-: |
| Bank | A financial institution ordering products to meet its tax reporting requirements. |
| Employer | A business ordering products to meet its tax-reporting requirements. |
| Library | 1. A public library acting as a third-party distributor of tax materials, usually as part of TFOP.<br>      <br>2. A library ordering products to meet its tax reporting requirements. |
| Other Government Agencies | 1. A federal, state, or local government or government-affiliated organization (such as schools, universities and military installations) acting as third-party distributor of tax materials to the public or their employees.<br>      <br>2. A federal, state, or local government or government-affiliated organization (such as schools, universities and military installations) ordering products to meet its tax reporting requirements. |
| Post Office | 1. A post office acting as a third-party distributor of tax materials, usually as part of the Tax Forms Outlet Program (TFOP).<br>      <br>2. A post office ordering products to meet its tax reporting requirements. |
| Taxpayer | An individual ordering tax related materials. |
| Tax Professional | 1. A person or firm that prepares tax returns for compensation.<br>      <br>2. A person or firm that prepares tax returns for compensation and is ordering products to meet its tax reporting requirements. |


**1.18.5.2.3** **(01-29-2018)**

#### Mail Receipt

1. NDC employees open and sort incoming mail. The employees forward misdirected mail and remittances to their correct destination.


**1.18.5.2.4** **(01-29-2018)**

#### Order Receipt

1. NDC receives orders from IRS



   - Mail from IRS offices, taxpayers, employers, tax professionals and other public customers

   - Efax

   - Email


**1.18.5.2.5** **(01-29-2018)**

#### Form 5753 – Action on Your Tax Form Order

1. NDC uses Form 5753, Action on Your Tax Form Order, to notify customers about changes in their orders. This notification includes referrals to other agencies or offices, and product information.


**1.18.5.2.6** **(01-29-2018)**

#### Invalid Address

1. All customer supplied addresses must comply with the U.S. Postal Service address requirements.

2. ELITE verifies that addresses are valid postal addresses and generates a report of all orders with unacceptable addresses.

3. NDC employees review the report and use reference materials and internet resources to attempt to correct addresses.


**1.18.5.3** **(06-06-2025)**

### Order Fulfillment

1. Employees process orders for shipment. Order fulfillment activities include:



1. Fill orders containing from one to hundreds of products

2. Print low volume products on-demand

3. Operate ink jet machines to place addresses on envelopes for automated order processing.

4. Use folder and inserter equipment to fill small envelope orders

5. Sort orders for shipment by carrier

6. Close orders in the ELITE system

7. Generate mail and shipping manifests


**1.18.5.3.1** **(01-29-2018)**

#### Types of Orders

1. The IRS has various methods of making tax forms and instructions available to the public. Processing clerks fill orders for the programs listed below.

2. The terms “order type” and “programs” are interchangeable. An order type/program indicates who is placing the order.




| **Programs** | **Users** |
| --- | --- |
| Automated Data Processing Program | Supplies Internal customers with printed on demand training products |
| Tax Forms Outlet Program (TFOP) | Supplies post offices, libraries, and other outlets with tax materials for distribution to the public |
| Prior Year Program | Supplies public and internal customers with tax products from previous years |
| Internal Program | Provides IRS employees with forms and publications |
| Taxpayer Assistance Center (TAC) | Supplies Taxpayer Assistance Centers with products for distribution to the public |
| Volunteer Income Tax Assistance (VITA) Program | Supplies customers with tax forms, instructions and publications |
| Employer Program | Supplies businesses with employment tax products for employee and company use |
| Package Assembly Program | Supplies packages of tax products for conferences and trade shows administered by IRS employees |


**1.18.5.3.2** **(02-01-2021)**

#### Public Order Fulfillment

1. A public order is a request for IRS printed product(s) from a non-IRS customer. This may include an individual taxpayer, employer, tax professional or other requestor.


**1.18.5.3.2.1** **(01-29-2018)**

##### Receiving Public Orders

1. The NDC receives initial orders by:



   - Written Correspondence

   - Internal


**1.18.5.3.2.2** **(06-06-2025)**

##### Picking Tickets

1. ELITE generates picking tickets. NDC employees fill orders from picking tickets. ELITE may generate more than one picking ticket for an order based on product availability, quantity, or fulfillment line location. Each picking ticket and its associated products ship separately.

2. A picking ticket lists the products to fill an order. It includes:



1. Name and address of the requestor/customer.

2. Shipping container for the order.

3. Products and ordered quantity.

4. Product fulfillment line location.

5. Transportation for shipping the order.

6. Messages telling the customer some items may be back ordered or shipped separately.


**1.18.5.3.2.2.1** **(06-06-2025)**

###### Forms Clerk Fulfillment Responsibilities

1. The employee checks the work station and verifies that it is stocked with the correct products and product revisions before filling orders.

2. After completing an order, the employee places the container on the appropriate conveyor for weight and postal sorting.


**1.18.5.3.2.3** **(01-29-2018)**

##### Special Notices

1. Sometimes the IRS includes in an order items the customer did not request. Examples include information about products in a shipment, such as errata notices and Form 5753, Action On Your Tax Forms Order.

2. IRS issues errata notices when printed products contain errors or late legislation minimally changes the content of the material. The IRS reprints products that contain critical errors.

3. Form 5753 informs the customer about changes in the order.


**1.18.5.3.3** **(06-06-2025)**

#### Internal Order Fulfillment

1. An internal order is a request for IRS products from an IRS employee.

2. NDC employees fill orders for most internal use products.


**1.18.5.3.4** **(01-29-2018)**

#### Stocking Order Fulfillment

1. ELITE uses demand and minimum level parameters to replenish fulfillment stock.


**1.18.5.3.5** **(01-29-2018)**

#### NDC Transportation Operations

1. NDC Transportation Personnel:



1. Provides information for shipping orders at the Distribution Center. Updates ELITE transportation tables, and maintains a system of accountability for outgoing shipments

2. Works with the Postal and Transport Policy section in M&P to ensure that policies, standards, techniques, and procedures are followed when shipping printed materials

3. Acts as the NDC’s mail Pre-sort Point of Contact (POC)


**1.18.5.4** **(01-29-2018)**

### Logistics

1. NDC Logistics personnel:



1. Maintain inventory accuracy and reorder points

2. Receive inbound product shipments and inspect them for damage

3. Transport stock from the receiving dock to warehousing locations

4. Retrieve stock from the warehouse for Order Processing use

5. Replenish stock

6. Fill bulk orders

7. Load outbound trucks


**1.18.5.4.1** **(01-29-2018)**

#### Product Maintenance

1. The NDC stores and distributes appropriate revisions of printed products. Designated M&P analysts identify current, prior year, and obsolete revisions and product disposition.


**1.18.5.4.2** **(01-29-2018)**

#### Disposals

1. Throughout the year, NDC employees must dispose of obsolete, revised, damaged, or unusable products. NDC employees identify and dispose of products as directed by designated M&P analysts.


**1.18.5.4.3** **(01-29-2018)**

#### Inventory Accuracy (Cycle Counting)

1. The NDC maintains accurate inventory records to meet customer needs, by regularly counting stock to ensure their inventory records accurately reflect what is stored in the warehouse and order fulfillment areas. Cycle counting is the process of verifying inventory accuracy by counting products in specific locations, comparing the counts to ELITE and reconciling differences.


**1.18.5.4.4** **(01-29-2018)**

#### Reorder Points

1. ELITE reorder points alert NDC and other Distribution employees that product inventory has fallen below specific quantities. A reorder point consists of a date range and quantity.

2. NDC Logistics Inventory Management Specialists establish a reorder point for all NDC products (except of On Demand and TPDS products), and update them on a monthly or annual basis to avoid stock outages and back orders, increased transportation costs, and potential work stoppages.


**1.18.5.4.5** **(01-29-2018)**

#### Planned Shipments

1. Specialty program customers place annual orders for products they will need during the filing season. The NDC ships groups of products to these customers as their orders and products are received. These shipments are called planned shipments.

2. Contractors ship some of these orders directly to the customer. These shipments are called contractor planned shipments.


**1.18.5.4.6** **(01-29-2018)**

#### Bulk Order Fulfillment

1. The NDC fills public and internal orders for full cartons of published products directly from the warehouse. Full carton orders are also called bulk orders.


**1.18.5.5** **(06-06-2025)**

### Specialty Programs

1. Specialty Programs are Distribution programs and products distributed to a specific audience with special requirements. These programs include:



   - Tax Forms Outlets Program

   - Training Publication Distribution System

   - Security Products

   - Prior Year Tax Products

   - Volunteer Income Tax Assistance (VITA) Program

   - Package Assembly Program; including New Hire Kits

   - QuickReact Letters

   - Supply items

   - Automated Data Processing


**1.18.5.5.1** **(01-29-2018)**

#### Tax Forms Outlet Program (TFOP)

1. The IRS distributes tax materials to outlets that are readily accessible to the public. The NDC distributes tax materials that are not directly shipped to outlet locations from printing contractors. Most Program participants are libraries or post offices, however, selected other organizations also distribute forms through the program.


**1.18.5.5.2** **(01-29-2018)**

#### Training Publication Distribution System (TPDS)

1. Training Publication Distribution System (TPDS) provides training materials to IRS operating divisions. And users may be at IRS offices or off-site locations. Orders for training materials originate in the field offices.

2. IRS employees use OSMS to order training material from the NDC.


**1.18.5.5.3** **(01-29-2018)**

#### Security Products

1. Some IRS published products contain protected information or are serially numbered. These security products require specific measures for receiving, storage, shipping, and disposal. Management authorizes and designates employees within certain order points to order security products. Management identifies and authorizes which products a designated employee may order.


**1.18.5.5.4** **(01-29-2018)**

#### Prior Year

1. The NDC will enter and fill orders only for current forms and publications and five-year prior forms and instructions. The NDC may elect to use on-demand printing to fill orders that extend beyond five prior years.


**1.18.5.5.5** **(01-29-2018)**

#### Volunteer Income Tax Assistance (VITA) Program

1. The VITA program uses an electronic ordering process. VITA program analysts send order information electronically to CAPS for Stakeholder Partnerships, Education, and Communications (SPEC) review and approval. following SPEC approval, the analysts download the orders into ELITE for fulfillment.


**1.18.5.5.6** **(01-29-2018)**

#### Package Assembly Program

1. The NDC assembles packages of printed products as a service to IRS employees use.

2. Package Assembly Program requests a list of cataloged products for use in workshops, conferences, trade shows, or one-time events.


**1.18.5.5.7** **(01-29-2018)**

#### QuickReact Letters

1. The NDC receives data files and correspondence files from IRS organizations to create personalized letters for taxpayers and /or IRS employees. The NDC prints, folds, and ships the correspondence.


**1.18.5.5.8** **(01-29-2018)**

#### Supply Items

1. The NDC receives and fills IRS internal customer orders for supply items such as bubble mailers, boxes, and secure shipping supplies IRS offices order through OSMS.


**1.18.5.5.9** **(06-06-2025)**

#### Automated Data Processing Training Materials-On Demand Printing

1. The NDC provides on demand printing of ADP products used at the Compliance Centers for employee training. Due to the nature of the materials, they require a quick turnaround processing time, normally 5 working days. Orders are received via email from Publishing Services Analysts. The Analysts provide:



   - the official PDF on the product

   - G 2511 - Print Order Request

   - F 2040 - Product Distribution List

   - F 6153 - Carton labels for the shipment


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-018-005#addtoany "Show all")

A2A