---
url: "https://www.irs.gov/irm/part1/irm_01-001-020"
title: "1.1.20 Office of Professional Responsibility | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-020#main-content)

- 1.1.20  [Office of Professional Responsibility](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987172222816)
  - 1.1.20.1  [Introduction to the Office of Professional Responsibility](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987172187424)
    - 1.1.20.1.1  [The Office of Professional Responsibility’s Mission](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987172245536)
  - 1.1.20.2  [Office of the Director](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987172238688)
    - 1.1.20.2.1  [Legal Analysis Branch](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987172234800)
    - 1.1.20.2.2  [Operations and Management Branch](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987138665296)
  - 1.1.20.3  [Definition of Terms](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987138653328)
  - 1.1.20.4  [Resources](https://www.irs.gov/irm/part1/irm_01-001-020#idm139987138638800)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 20. Office of Professional Responsibility

* * *

## 1.1.20 Office of Professional Responsibility

#### Manual Transmittal

July 19, 2024

#### Purpose

(1) This transmits revised IRM 1.1.20, _Organization and Staffing, Office of Professional Responsibility_.

#### Material Changes

(1) Reviewed and updated links, legal references and IRM references, as necessary.

(2) Reviewed and updated roles and responsibilities, as necessary.

(3) Made editorial changes for consistency and clarity.

#### Effect on Other Documents

IRM 1.1.20, dated November 29, 2016, is superseded.

#### Audience

All Divisions and Functions

#### Effective Date

(07-19-2024)

Timothy J. McCormally

Acting Director, Office of Professional Responsibility

**1.1.20.1** **(02-14-2023)**

### Introduction to the Office of Professional Responsibility

1. The Office of Professional Responsibility (OPR) is responsible for all matters related to practitioner misconduct, discipline and practice before the Internal Revenue Service (IRS) under 31 CFR Subtitle A, Part 10 (Treasury Department Circular No. 230, _Regulations Governing Practice before the Internal Revenue Service_) (“Regulations” or “Circular 230”). In carrying out this responsibility, the OPR administers the law and regulations governing the practice of practitioners and other individuals who interact with the tax administration system on behalf of taxpayers, including, but not limited to, attorneys, certified public accountants, enrolled agents, enrolled actuaries, enrolled retirement plan agents, tax return preparers granted limited practice rights under the IRS’s Annual Filing Season Program (AFSP) who represent clients before the IRS, and appraisers who provide valuations supporting tax positions.

2. The OPR:



01. Receives, reviews and investigates allegations of misconduct by individuals covered by the Regulations.

02. Evaluates allegations to determine whether they evidence actions that constitute disreputable or incompetent conduct, or otherwise are violations of the Regulations.

03. When warranted, proposes and negotiates a level of discipline appropriate with the misconduct.

04. In the absence of a reprimand or a voluntary settlement, initiates disciplinary proceedings before Administrative Law Judges (ALJs).

05. Initiates or responds to appeals of ALJ disciplinary decisions.

06. Receives, processes and investigates referrals of alleged misconduct under Rev. Proc. 81-38 and in the AFSP under Rev. Proc. 2014-42 (or successor guidance), and makes or assists in making final determinations of ineligibility of unenrolled tax return preparers to practice (in accordance with the applicable guidance) pursuant to Delegation Order 25-16 (Rev. 2).

07. Serves as the Appellate Authority for enrollment appeals from the Return Preparer Office (RPO), pursuant to Delegation Order 25-17 (Rev. 1).

08. Serves as the Appellate Authority for requests for independent review of the IRS’s proposed denial of certification as a certified professional employer organization (CPEO) and the IRS’s suspension and proposed revocation of a CPEO’s certification pursuant to Delegation Order 25-19 (Rev. 1).

09. Interprets the Conference and Practice Requirements contained in 26 CFR 601, Subpart E (reprinted as Pub 216).

10. Provides education and outreach regarding a tax professional’s obligations and duties as enumerated in Circular 230.

11. Acts in an advisory capacity with respect to IRS oversight and compliance initiatives and programs for tax professionals.

12. Acts in an advisory capacity to other IRS business units on issues and concerns related to the submission, acceptance and use of Form 2848, _Power of Attorney and Declaration of Representative_, appointing a representative of a taxpayer, and Form 8821, _Tax Information Authorization_, designating a practitioner or other person to receive and inspect a taxpayer’s confidential tax information.


**1.1.20.1.1** **(02-14-2023)**

#### The Office of Professional Responsibility’s Mission

1. The mission of the OPR is to interpret and apply the standards of practice for tax professionals in a fair and equitable manner. The OPR’s objective is to support effective tax administration by ensuring all tax professionals and other third parties, as defined in IRM 1.1.20.3(8), who interact with the tax administration system on behalf of taxpayers adhere to the standards of practice and ethics enumerated in Circular 230. To achieve its goals and to carry out its mission, the OPR is committed to:



1. Delivering secure and customized services to meet tax professionals’ needs.

2. Providing proactive outreach and education to improve internal and external stakeholders’ knowledge and understanding of Circular 230.

3. Enforcing Circular 230 fairly, efficiently and effectively to address practitioner misconduct.

4. Improving operations to efficiently and effectively identify and address practitioner misconduct (including non-compliance).

5. Fostering an inclusive, diverse workforce that is empowered with the proper training, tools and processes to better support tax administration.

6. Attracting and hiring a workforce that reflects our communities to meet current and future needs.

7. Transforming and realigning our operations and organizational structure to become more resilient, agile and responsive to maximize efficiencies in enforcement of Circular 230.


**1.1.20.2** **(11-29-2016)**

### Office of the Director

1. The OPR includes the Office of the Director who supervises the following offices:



   - Legal Analysis Branch and

   - Operations and Management Branch.


2. The Director oversees administration and enforcement of Circular 230 provisions governing the conduct and discipline of the nation’s tax practitioners before the IRS. The Director conducts and oversees a comprehensive outreach program to the tax professional community to educate them on Treasury/IRS rules, regulations, policies, and procedures pertaining to professional standards of conduct, integrity and ethics, in order to practice before the IRS. The Director also provides executive direction in OPR matters relating to human capital management and labor relations, the OPR budget, performance measures, operation and maintenance of the case inventory system, and strategic planning.


**1.1.20.2.1** **(11-29-2016)**

#### Legal Analysis Branch

1. The Legal Analysis Branch (LAB) receives information with respect to alleged violations of the Regulations, reviews the submission, investigates the facts, analyzes the results, and proposes appropriate dispositions, including sanctions for confirmed misconduct.

2. The LAB accomplishes the OPR mission by:



1. Receiving, reviewing and evaluating referrals alleging violations of the Regulations from IRS personnel, external federal and state agencies, and other third parties.

2. Evaluating allegations of misconduct to determine whether the allegations indicate actions which constitute disreputable or incompetent conduct, or otherwise reflect violations of the Regulations.

3. When warranted, proposing and negotiating a level of discipline appropriate with the misconduct.

4. In the absence of a voluntary settlement, initiating disciplinary proceedings before ALJs pursuant to Circular 230 Section 10.60 et seq.

5. Acting on referrals from state and federal licensing authorities and conviction information of state and federal courts, and instituting expedited suspension proceedings pursuant to Circular 230 Section 10.82.

6. Communicating with state licensing authorities, including state boards of accountancy and state bars, to seek and obtain information on state disciplinary actions with Circular 230 implications.

7. Working with IRS Business Operating Divisions and Functions to obtain information necessary to thoroughly investigate, analyze and interpret a referral of a practitioner for possible Circular 230 violations.


**1.1.20.2.2** **(11-29-2016)**

#### Operations and Management Branch

1. The Operations and Management Branch (O&M) of the OPR is responsible for providing program support to the organization’s mission through strategic planning, employee training, information technology, stakeholder outreach and communication, human capital planning and execution, and finance.

2. The strategy function within O&M ensures proper execution and coordination of the OPR’s strategy as set by the Office of the Director each year. The strategy function coordinates with the LAB to ensure the OPR’s strategy is implemented consistently across the organization and that all strategic goals and objectives are properly and timely met. The strategy function is responsible for monitoring the execution of the Operational Plan, Continuity of Operations Plan, Business Resumption Plan, and the Concept of Operations.

3. The O&M branch accomplishes the OPR mission by:



01. Packaging and disseminating strategic plan information across the OPR. Key activities associated with this function include review of the IRS strategic plan to identify and implement necessary changes.

02. Meeting with the OPR senior leadership to discuss shifts in strategic direction at the organizational level and updating the OPR’s Standard Operating Procedures and Internal Revenue Manual sections to reflect necessary changes.

03. Monitoring the OPR’s overall performance and particular accomplishments to ensure that each supports accurate and current objectives.

04. Developing employee training programs and directing the analysis, development and method of delivery necessary to achieve and maintain optimal employee knowledge, skills and job performance.

05. Ensuring processes, technology and other mechanisms are in place to effectively track referrals, investigations, Circular 230 determinations, disciplinary recommendations, and final case dispositions.

06. Analyzing and utilizing technology driven data to better inform and educate operating divisions and IRS personnel regarding referral obligations under Section 10.53 of Circular 230.

07. Developing and distributing communications to both internal and external stakeholders as well as the OPR employees.

08. Providing guidance to agency employees and members of the general public regarding the OPR's mission, vision, goals and processes, and maintaining liaison with the IRS Business Operating Divisions and Functions and with external agencies.

09. Developing and analyzing data needed to evaluate organizational efficiency and performing advanced data analysis when necessary to inform training needs, performance improvement activities and the bases for business results reporting.

10. Directing human capital planning, execution and finance by ensuring that the OPR's current staffing levels are sufficient to meet the identified workload and agency needs.

11. Responding to oversight inquiries from the Treasury Inspector General for Tax Administration and the U.S. Government Accountability Office.

12. Operationalizing a Risk Management Program.

13. Requesting contractor support, managing the contract financials and acting as a liaison between the contracting agency and the IRS for interagency contracts with other government agencies and blanket purchase agreement contracts for external parties.


**1.1.20.3** **(02-14-2023)**

### Definition of Terms

1. **Attorney:** Any person who is an active member in good standing of the bar of the highest court of any State, territory or possession of the United States, including a Commonwealth, or the District of Columbia. Attorneys may, subject to certain limitations, perform all acts the taxpayer can perform with respect to the tax matters authorized.

2. **Certified Public Accountant (CPA):** Any person who is duly qualified to practice as a CPA in any State, territory or possession of the United States, including a Commonwealth, or the District of Columbia. CPAs may, subject to certain limitations, perform all acts the taxpayer can perform with respect to the tax matters authorized.

3. **Enrolled Agent (EA):** Any individual who has demonstrated special competence in tax matters and has been issued an enrollment card by the IRS. Except for limited enrollment of certain former IRS employees based on the extent of their former work experience, EAs may, subject to some certain limitations, perform all acts the taxpayer can perform with respect to the tax matters authorized. Former IRS employees granted limited enrollment based on their work experience with the agency may represent taxpayers only in matters within the scope of the EA’s limited enrollment (e.g., collection matters).

4. **Enrolled Actuary (EAc):** Any individual who has demonstrated competence in specific matters under the internal revenue laws, as enumerated in Circular 230, has applied for enrollment and been issued an enrollment card by the Joint Board for the Enrollment of Actuaries. Practice as an EAc is limited to the specific competency areas enumerated in Circular 230.

5. **Enrolled Retirement Plan Agents (ERPA):** Any individual who has demonstrated competence in specific matters under internal revenue laws, as enumerated in Circular 230, has applied for enrollment, and has been issued an enrollment card by the IRS. Practice as an ERPA is limited to the specific competency areas enumerated in Circular 230.

6. **Tax Return Preparer:** Any individual who is compensated to prepare tax returns for others and who has applied for and maintains a valid Preparer Tax Identification Number (PTIN) issued by the IRS. Practice as a tax return preparer is limited to representing taxpayers before revenue agents, examiners, customer service representatives, and similar IRS employees, including the Taxpayer Advocate Service during an examination of tax returns or claims for refund prepared and signed by the tax return preparer. Effective for tax returns and refund claims prepared on or after January 1, 2016, only tax return preparers who also have an IRS Annual Filing Season Program Records of Completion pursuant to Rev. Proc. 2014-42 may engage in limited practice before the IRS. See Rev. Proc. 2014-42, Section 6.01; Pub 216, _Conference and Practice Requirements_, Section 601.502(b)(5)(iii); and Pub 947, _Practice Before the IRS and Power of Attorney_ (pp. 3-4, “Unenrolled return preparers”).

7. **Appraiser:** Any individual who provides valuations contained in submissions to the IRS.

8. **Others who interact with the tax administration system:** Individuals engaging in limited practice before the IRS under Section 10.7(c) of Circular 230, individuals granted special appearance authority under Section 10.7(d), and individuals granted temporary recognition as an EA under Section 10.5(e).



### Note:



Fiduciaries, including an executor or appointee of a deceased taxpayer’s estate or a court-appointed conservator or guardian of a taxpayer, do not engage in practice (representation of taxpayers) before the IRS, although they interact with the tax administration system on behalf of taxpayers. See Section 10.7(e) of Circular 230; Pub 216, Section 601.503(d); and Pub 947 for more information.


**1.1.20.4** **(02-14-2023)**

### Resources

01. Internal OPR Website: https://irssource.web.irs.gov/OPR/Pages/Home.aspx

02. External OPR Website: [https://www.irs.gov/tax-professionals/Circular-230-Tax-Professionals](https://www.irs.gov/tax-professionals/circular-230-tax-professionals)

03. Treasury Department Circular No. 230, _Regulations Governing Practice before the Internal Revenue Service_: http://publish.no.irs.gov/catp.cgi?catnum=16586

04. Disciplinary Sanctions - Internal Revenue Bulletin: [https://www.irs.gov/tax-professionals/disciplinary-sanctions-internal-revenue-bulletin](https://www.irs.gov/tax-professionals/disciplinary-sanctions-internal-revenue-bulletin%20)

05. Title 31 United States Code Section 330: [http://uscode.house.gov/search/criteria.shtml](http://uscode.house.gov/search/criteria.shtml)

06. Title 5 United States Code Section 500: [http://uscode.house.gov/search/criteria.shtml](http://uscode.house.gov/search/criteria.shtml)

07. Title 26 Code of Federal Regulations, Part 601, Subpart E: [https://www.law.cornell.edu/cfr/text/26/part-601/subpart-E](https://www.law.cornell.edu/cfr/text/26/part-601/subpart-E)

08. Publication 216, _Conference and Practice Requirements_: http://publish.no.irs.gov/cat12.cgi?request=CAT2&itemtyp=P&itemb=216&items=\*




     (See 26 CFR Sections 601.501 to 601.509 for the most recent version of the _Conference and Practice Requirements_: [https://www.ecfr.gov/cgi-bin/text-idx?SID=4a51551a6a3113c619bfcd59563cc5dc&mc=true&node=sp26.22.601.e&rgn=div6](https://www.ecfr.gov/cgi-bin/text-idx?SID=4a51551a6a3113c619bfcd59563cc5dc&mc=true&node=sp26.22.601.e&rgn=div6))

09. Publication 947, _Practice Before the IRS and Power of Attorney_: https://publish.no.irs.gov/cat12.cgi?request=CAT2&itemtyp=P&itemb=947&items=

10. Revenue Procedure 81-38, _Limited Practice Without Enrollment_: [https://www.irs.gov/pub/irs-lbi/rev\_proc\_81\_-\_38\_2.pdf](https://www.irs.gov/pub/irs-lbi/rev_proc_81_-_38_2.pdf)

11. Revenue Procedure 2014–42, _Annual Filing Season Program_: [http://www.irs.gov/irb/2014-29\_IRB/ar14.html](http://www.irs.gov/irb/2014-29_IRB/ar14.html)

12. Delegation Order 25-16 (Rev. 2), _Authority of the Office of Professional Responsibility to Perform Certain Functions Concerning Practice before the Internal Revenue Service_: https://irm.web.irs.gov/link.aspx?link=1.2.2.15.16

13. Delegation Order 25-17 (Rev. 1), _Authority to Decide Protests of Enrollment or Re-enrollment Denials Under Treasury Department Circular No. 230_: https://irm.web.irs.gov/link.aspx?link=1.2.2.15.17

14. Delegation Order 25-19 (Rev. 1), _Professional Employer Organization (PEO) Certification_: https://irm.web.irs.gov/link.aspx?link=1.2.2.15.19

15. Notice 2007-39, IRB 2007–20, _Disciplinary Actions Under Section 822 of the American Jobs Creation Act of 2004_: [http://www.irs.gov/irb/2007-20\_IRB/ar07.html](http://www.irs.gov/irb/2007-20_IRB/ar07.html)

16. Subscribe to News and Updates from OPR: [http://www.irs.gov/Tax-Professionals/Subscribe-to-News-and-Updates-from-OPR](http://www.irs.gov/Tax-Professionals/Subscribe-to-News-and-Updates-from-OPR)


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-020#addtoany "Show all")

A2A