---
url: "https://www.irs.gov/irm/part1/irm_01-022-006"
title: "1.22.6 Transportation Management | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-022-006#main-content)

- 1.22.6  [Transportation Management](https://www.irs.gov/irm/part1/irm_01-022-006#id1)
  - 1.22.6.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-022-006#id2)
    - 1.22.6.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-022-006#id4)
    - 1.22.6.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-022-006#id5)
    - 1.22.6.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-006#id6)
    - 1.22.6.1.4  [Program Management Review](https://www.irs.gov/irm/part1/irm_01-022-006#id7)
    - 1.22.6.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-022-006#id8)
    - 1.22.6.1.6  [Frequently Used Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-022-006#id9)
    - 1.22.6.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-022-006#id10)
  - 1.22.6.2  [Quality Control](https://www.irs.gov/irm/part1/irm_01-022-006#id11)
  - 1.22.6.3  [Annual Transportation Review](https://www.irs.gov/irm/part1/irm_01-022-006#id12)
  - 1.22.6.4  [IRS Bills of Lading](https://www.irs.gov/irm/part1/irm_01-022-006#id13)
    - 1.22.6.4.1  [Types of IRBLs](https://www.irs.gov/irm/part1/irm_01-022-006#id15)
    - 1.22.6.4.2  [Converting a Commercial Bill of Lading (CBL) to an Internal Revenue Service Bill of Lading (IRBL)](https://www.irs.gov/irm/part1/irm_01-022-006#id16)
    - 1.22.6.4.3  [Altering or Correcting Bills of Lading](https://www.irs.gov/irm/part1/irm_01-022-006#id17)
    - 1.22.6.4.4  [Issuance and Accountability of Internal Revenue Service Bills of Lading (IRBLs)](https://www.irs.gov/irm/part1/irm_01-022-006#id18)
  - 1.22.6.5  [Funding](https://www.irs.gov/irm/part1/irm_01-022-006#id19)
    - 1.22.6.5.1  [Accounting and Payment for Transportation](https://www.irs.gov/irm/part1/irm_01-022-006#id21)
  - 1.22.6.6  [Pricing and Routing](https://www.irs.gov/irm/part1/irm_01-022-006#id22)
  - 1.22.6.7  [Modes of Transportation and Services](https://www.irs.gov/irm/part1/irm_01-022-006#id23)
    - 1.22.6.7.1  [Freight Shipments](https://www.irs.gov/irm/part1/irm_01-022-006#id25)
  - 1.22.6.8  [Inside Delivery/Pickup Service](https://www.irs.gov/irm/part1/irm_01-022-006#id26)
    - 1.22.6.8.1  [Motor and Air Freight Carrier - Inside Delivery/Pickup](https://www.irs.gov/irm/part1/irm_01-022-006#id28)
  - 1.22.6.9  [Loss and Damage - Shipment Discrepancies and Claims](https://www.irs.gov/irm/part1/irm_01-022-006#id29)
    - 1.22.6.9.1  [Supporting Documents](https://www.irs.gov/irm/part1/irm_01-022-006#id31)
    - 1.22.6.9.2  [Tracing Lost Shipment or Verifying Delivery](https://www.irs.gov/irm/part1/irm_01-022-006#id32)
  - 1.22.6.10  [Processing for Payment](https://www.irs.gov/irm/part1/irm_01-022-006#id33)
  - 1.22.6.11  [Insurance](https://www.irs.gov/irm/part1/irm_01-022-006#id34)

# Part 1. Organization, Finance, and Management

# Chapter 22. Mail and Transportation Management

# Section 6. Transportation Management

* * *

## 1.22.6 Transportation Management

#### Manual Transmittal

August 28, 2025

#### Purpose

(1) This transmits revised IRM 1.22.6, Mail and Transportation Management, Transportation Management.

(2) This section discusses the overall management of the transportation program for the IRS.

#### Material Changes

(1) IRM 1.22.6 revised throughout to update section title from Postal Transport and Policy to Postal and Transport.

#### Effect on Other Documents

IRM 1.22.6, Transportation Management dated October 23, 2024 is superseded.

#### Audience

IRS Employees

#### Effective Date

(08-28-2025)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.22.6.1** **(10-27-2021)**

### Program Scope and Objectives

1. Purpose: This section discusses the IRS transportation management program.

2. Audience: The audience is IRS employees who make transportation management decisions on IRS shipments.

3. Policy Owner: Distribution Requirements resides within the office of Taxpayer Services(TS)/Customer Assistance Relationships and Education (CARE)/Media and Publications (M&P)/Technology and Program Support (TPS).

4. Program Owner: Technology and Program Support (TPS) is the program office responsible for overseeing and providing guidelines for Transportation Management.

5. Primary Stakeholders:



   - IRS Business Units

   - Freight Carriers

   - Pre-payment Auditor

   - Beckley Finance

   - Postal and Transport


6. Program Goals: To describe the guidelines and procedures to be used for shipments required in managing IRS programs.


**1.22.6.1.1** **(10-12-2023)**

#### Background

1. The General Services Administration (GSA) is responsible for establishing the government-wide Transportation Management policies and procedures.

2. The Transportation Management Program is a tool to fulfill the mission of the IRS. Successfully managing the movement of IRS shipments through the transportation system requires an understanding of logistics management concepts and procedures.

3. The CFO, Financial Management, Travel Management Office is the program owner for the shipment of Household Goods (HHG).

4. The IRS regularly ships items using several modes of transportation, including:



1. Tax forms, internal use forms, media and other printed matter

2. Household goods and personal effects of relocating employees

3. Electronics

4. Furniture

5. Office supplies

6. Equipment

7. Files and records

8. Urgent letters


5. The mode of transportation is determined by the lowest cost for the customer’s requirements.


**1.22.6.1.2** **(10-12-2023)**

#### Authority

1. [41 CFR Part 102-117, Transportation Management](https://www.ecfr.gov/current/title-41/subtitle-C/chapter-102/subchapter-D/part-102-117)

2. [41 CFR Part 102-118, Transportation Payment and Audit](https://www.ecfr.gov/current/title-41/subtitle-C/chapter-102/subchapter-D/part-102-118)


**1.22.6.1.3** **(10-27-2021)**

#### Roles and Responsibilities

1. The Postal and Transport (PT) section :



1. Negotiates freight rates and providing freight carrier service options to all IRS business units

2. Monitors and controls Forms 12741, Internal Revenue Service Bill of Lading (IRBL) and 13135, Internal Revenue Service Bill of Lading-Privately Owned Personal Property

3. Reviews carrier or vendor invoices for accuracy of costs

4. Reviews SF 1113, Public Voucher for Transportation Charges

5. Acts in an advisory capacity to all business units

6. Issues IRBLs to provide freight transportation services to M&P and business units Servicewide

7. Assures adequate funding is properly approved


2. All business units will request freight transportation advice from PT section or FMSS when assistance is required.


**1.22.6.1.4** **(10-12-2023)**

#### Program Management Review

1. The PT Section:



1. Provides guidelines and procedures to IRS business units for freight shipments.

2. Solicits annual bids from transportation service providers (TSP) to obtain freight services and pricing tenders.

3. Manages the Transportation Management System (TMS) for issuance of Internal Revenue Bills of Lading (IRBL) to authorize TSPs with the physical movement of commodities and other freight from one location to another.

4. Reviews and processes freight and Household Goods (HHG) invoices.


**1.22.6.1.5** **(10-12-2023)**

#### Program Controls

1. The PT Section:



1. Approves users for TMS used for creating and issuing IRBLs.

2. Assesses freight carrier performance with timely pickups, deliveries, transit time, invoice accuracy and any loss or damage of the product.

3. Certifies all freight and HHG invoices for payment.

4. Develops the Annual Transportation Review of the transportation management program.


**1.22.6.1.6** **(10-12-2023)**

#### Frequently Used Terms and Acronyms

1. The following charts contain defined terms used throughout this IRM and acronyms:



**Terms**






| **Term** | **Definition** |
| --- | --- |
| Internal Revenue Service Tender of Service (IRSTOS) | Provides the terms for freight carriers to submit their freight costs. |
| Traffic Management System (TMS) | TMS is the program to create IRBLs, maintain the freight carrier information and rates, and maintain addresses. |
| Internal Revenue Bill of Lading (IRBL) | Authorizes the freight carrier to coordinate and transport the shipments. |







**Acronyms**






| **Acronym** | **Definition** |
| --- | --- |
| BEARS | Business Entitlement Access Request System |
| CARE | Customer Assistance, Relationships and Education |
| CBL | Commercial Bill of Lading |
| CONUS | Contiguous United States |
| CFO | Chief Financial Officer |
| CFR | Code of Federal Regulations |
| D | Distribution |
| ERC | Employee Resource Center |
| FMSS | Facilities Management and Security Services |
| FOB | Free on-Board |
| GBL | Government Bill of Lading |
| GPO | Government Printing Office |
| GSA | General Services Administration |
| HHG | Household Goods |
| IRBL | Internal Revenue Bill of Lading |
| IRSTOS | Internal Revenue Service Tender of Service |
| IT | Information Technology |
| LTL | Less-than-Truckload |
| M&P | Media and Publications |
| PPS | Procurement for Public Sector |
| PT | Postal and Transport |
| SPC | Small Package Carrier |
| TFDPS | Tax Forms Distribution Programs Section |
| TM | Transportation Management |
| TMS | Transportation Management System |
| TPOC | Territory Point of Contact |
| TPS | Technology and Program Support |
| TS | Taxpayer Services |
| TSP | Transportation Service Provider |
| TL | Truckload |


**1.22.6.1.7** **(10-27-2021)**

#### Related Resources

1. Related resources include:



   - [Government Freight Handbook](https://www.gsa.gov/cdnstatic/FreightHandbook%20Final%20May%202021.pdf)

   - IRS Document 11933, Transportation Management System (TMS) User Guide

   - IRS Publication 4065, IRSTOS - Internal Revenue Service Tender of Service

   - [41 CFR 102-117(I), Transportation Service Provider (TSP) Performance](https://www.ecfr.gov/current/title-41/subtitle-C/chapter-102/subchapter-D/part-102-117/subpart-I)

   - IRM 1.32.12, Servicewide Travel Policies and Procedures, IRS Relocation Travel Guide for the HHG Program


**1.22.6.2** **(01-14-2021)**

### Quality Control

1. The PT section provides a quality control program to monitor freight carrier performance, retains the high quality service providers with the best value and removes carriers with low quality service or excess cost.

2. 41 CFR 102-117(I) allows IRS to place carriers in a temporary non-use status when evidence of deficiencies exist, such as:



1. Late pickups or deliveries, or inconsistent transit times

2. Freight bills with loss, damage, or other discrepancies

3. Frequent overcharges or incomplete invoices


3. If the PT section determines a carrier disciplinary action is necessary, IRS offices are notified.


**1.22.6.3** **(10-27-2021)**

### Annual Transportation Review

1. The PT section annually reviews the transportation management program in these areas:



   - Current Fiscal Year (FY) budget

   - Internal Revenue Bills of Lading (IRBLs)

   - Claims

   - Tenders of Solicitation

   - Budget for upcoming FY

   - Program improvements


2. The PT Staff prepares the annual TM report with the information on the above areas and provides the report to:



1. Chief, PT no later than October 31st for the preceding fiscal year

2. Chief, TS, no later than November 30th for the preceding fiscal year

3. CARE, no later than December 31st for the preceding fiscal year.


**1.22.6.4** **(10-12-2023)**

### IRS Bills of Lading

1. The IRBL is a contract which specifies the terms and conditions of carriage, the IRS rate authority and any special services.

2. The IRS (PT, FMSS or Information Technology (IT)) initiates freight transportation by issued the IRBL.

3. The IRS CFO Relocation Coordinator initiates the IRBL for transportation of HHG, personally-owned vehicles, temporary or extended storage of HHG, and unaccompanied air baggage.

4. The IRS uses the IRBL for moving HHG and freight shipments, generally over 750 pounds. Smaller shipments are handled by a Small Package Carrier (SPC) or United States Postal Service (USPS) who do not accept the IRBL. Refer to **IRM 1.22.2, Mail and Transportation Management, United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package (SPC) Services**, for information on SPC services.

5. For IRS shipping, the IRBL has replaced the Government Bill of Lading (GBL).


**1.22.6.4.1** **(10-27-2021)**

#### Types of IRBLs

1. There are two types of IRBLs:



1. Form 12741, Internal Revenue Service Bill of Lading, used for freight shipments and issued by authorized IRS users primarily in PT, FMSS and IT.

2. Form 13135, Internal Revenue Bill of Lading-Privately Owned Personal Property, used for shipments of HHG and personal effects of relocating employees. This IRBL is issued by the CFO Relocation Coordinator, Administrative Accounting Branch, Travel Management Section.


2. The purpose of the IRBL is to initiate and control individual freight or HHG shipments and to facilitate payment to the carrier.

3. The IRBL is only used for transportation of property when charges are to be paid by the IRS direct to the carrier.

4. An IRBL can be issued after the transportation services are completed:



> 1. To replace or convert a Commercial Bill of Lading (CBL)
>
> 2. To authorize payment for accessorial services billed separately

5. A duplicate IRBL may be issued if the original is lost or destroyed but not for separate shipments.

6. Any IRS office requesting an IRBL for a freight shipment must complete Form 14680, Freight Services Request, and submit by e-mail to wi.mp.traffic.management@irs.gov.


**1.22.6.4.2** **(01-14-2021)**

#### Converting a Commercial Bill of Lading (CBL) to an Internal Revenue Service Bill of Lading (IRBL)

1. When unable to create an IRBL, IRS offices are authorized to substitute a CBL to originate a shipment when:



> 1. The IRS Transportation Management System (TMS) is not accessible
>
> 2. No authorized TMS user is on duty
>
> 3. A PT section employee is unavailable for assistance
>
> 4. Emergency circumstances exist

2. When using this option, the carrier must be told no IRBL is available for the driver. The carrier can offer to prepare a CBL.

3. If the carrier does not offer to provide a CBL, the IRS shipping office can access the carrier web site and prepare the CBL online. A generic CBL can be downloaded from the web, or a blank CBL can be obtained from the carrier driver for manual preparation.

4. For the carrier to receive payment for the CBL(s), the IRS shipping office must issue an IRBL to the carrier converting the CBL to an IRBL.


**1.22.6.4.3** **(10-27-2021)**

#### Altering or Correcting Bills of Lading

1. Form 13134, IRS US Government Bill of Lading Correction Notice, is required when making changes after an IRBL is issued to the carrier. The preparer of Form 13134 must ensure funds are available to cover any additional costs. A copy of the completed form is maintained by the preparer, sent to the IRBL issuing office and the freight carrier.


**1.22.6.4.4** **(10-12-2023)**

#### Issuance and Accountability of Internal Revenue Service Bills of Lading (IRBLs)

1. An IRBL can only be issued by an authorized user on the TMS. To obtain authorization, employees must submit a request using the Business Entitlement Access Request System (BEARS). Once approved, employees will receive a user identification and password from a PT section employee.


**1.22.6.5** **(10-12-2023)**

### Funding

1. Freight shipments funded by Distribution must be shipped on an IRBL, showing the authorized appropriation codes.

2. Freight shipments funded by other business units must show the Procurement for Public Sector (PPS) number and corresponding appropriation codes on the IRBL.

3. Business units must submit a funding request as a non-procurement shopping cart with the Action Type as GBL.


**1.22.6.5.1** **(10-27-2021)**

#### Accounting and Payment for Transportation

1. M&P/Technology and Program Support is responsible for the proper commitment and obligation of funds for payment of transportation charges.

2. M&P is responsible for payment of the transportation charges on freight shipments made using an IRS SPC account (typically under 750 pounds per destination) or with an IRBL when the following conditions apply:



1. From printers on Free on Board (FOB) Origin, FOB Contractor City and Government Printing Office (GPO) contracts to destinations designated by the IRS

2. Between the IRS offices on printed product transfers directed by M&P

3. From the IRS offices on SPC or truck shipments of administrative files, tax records or Grand Jury records requiring secure transportation to an IRS storage facility or Federal Records Center; shipment must be palletized and shrink wrapped, and ready for pickup.

4. Any shipment authorized by the PT section


3. Requesting office/Business office is responsible for payment of transportation charges on freight shipments under the Home as POD (HaP) and the IRS Telework programs.

4. Freight and Household good carriers will submit all public vouchers to the designated prepayment audit contractor as shown on the IRBL. After verification of charges by the contractor, the vouchers will be forwarded to the PT section, certified for payment by the PT section and forwarded to GPFM for payment in compliance with the Prompt Payment Act.


**1.22.6.6** **(10-27-2021)**

### Pricing and Routing

1. Two important steps in traffic management are negotiation of pricing and routing.



1. Pricing is the cost of transportation services expressed by a rate, based on units of weight and/or distance. The PT section negotiates rates with various carriers to satisfy the transportation needs of the entire IRS.

2. Routing is choosing the best mode of transportation and selecting the best value carrier within that mode.


2. The PT section resolves all routing and pricing issues for freight shipments in a timely manner.

3. Motor Freight rates, Air Freight rates and terms of service are negotiated directly with carriers and administered by the IRS. Rates, rules and service options are governed by Publication 4065,IRSTOS - Internal Revenue Service Tender of Service.

4. The PT Section solicits individual carrier bids during the annual "open window" in August. Bid prices are entered into the TMS to facilitate carrier selection and cost estimates for creating IRBLs. These carriers must be used on IRS freight shipments when feasible.


**1.22.6.7** **(10-12-2023)**

### Modes of Transportation and Services

1. Motor Freight - Shipment weight is the primary criteria used to determine which mode of Motor Freight to use. On a per pound basis, the truckload mode is the least expensive. Transit time depends on the mode. Truckload shipments usually have shorter transit times than Less-Than-Truckload (LTL) shipments. The weight ranges and corresponding modes are shown in the below table.




| ****Mode**** | **Weight Ranges** |
| --- | --- |
| Truckload or TL | Approximately 10,000 - 44,000 pounds or the weight (pricing point) at which it is more cost-effective to use TL pricing. This pricing point is identified as a weight break, and results in IRS paying a lower price per unit on a higher total weight for a net savings. |
| Less-than-Truckload or LTL | Over 750 pounds up to the TL weight break |

2. Air Freight - Expedited transit time and shipment weight is the main criteria used to determine the use of Air Freight modes. To be cost-effective the PTP section requires at least 500 pounds be shipped at one time to a single consignee before selecting Air Freight. When expedited service is authorized, lesser weights will be sent via SPC air services. Air Freight is often used when shipping to Alaska, Guam, Hawaii, Puerto Rico and U.S. Virgin Islands (St. Croix and St. Thomas), but can be used within CONUS (48 states) when conditions warrant. Air Freight is much less economical than Motor Freight. Next Day is the most expensive, Second Day is less costly and 3-5 Day Deferred is the lowest priced.



### Note:



Unless a work stoppage is identified by the recipient, 3-5 Day Deferred is the preferred option.


**1.22.6.7.1** **(10-12-2023)**

#### Freight Shipments

1. When shipping one piece weighing more than 150 pounds or a consolidated shipment with a combined weight over 750 pounds to one customer, a Form 14680, Freight Services Request, must be submitted to PT at ts.mp.traffic.management@irs.gov

2. Freight shipments are a direct expense. Before shipping, a funded PPS shopping cart is required, unless the shipment is covered under **IRM 1.22.6.5.1, Accounting and Payment for Transportation** and funding is authorized by M&P.


**1.22.6.8** **(01-14-2021)**

### Inside Delivery/Pickup Service

1. Inside delivery/pickup is an additional service performed by freight carriers beyond the standard loading or unloading of the vehicle. Inside delivery/pickup costs extra but will only be done upon request when the carrier's operating conditions permit. When requested on the IRBL or authorized at the time of delivery/pickup, the carrier can move shipments from or to positions beyond the normal loading or unloading area.

2. Because of the nature of freight carrier service and the independent control drivers have over their vehicles, problems emerge regarding inside delivery. Drivers may provide only a minimum level of service, sometimes less than their agreement with what IRS requires. Unfortunately, there is no guarantee the actual service performed will be the service expected.

3. Before inside delivery/pickup is arranged, determine which offices require these services. Use the following criteria to determine inside delivery/pickup:



1. If an office lacks administrative personnel to perform internal movement of shipments from or to the point immediately adjacent to the location of the vehicle.

2. If the loading or unloading facilities are not adequate for delivery/pickup without this service.


4. When inside delivery/pickup is requested and the driver delivering the shipment is unable to perform the service, follow these procedures:



1. When the IRBL does not authorize inside delivery/pickup and the driver asks for payment, do not pay the driver. The receiver/shipper may authorize the service to be billed to the IRS by signing the driver's documents. If that fails, contact the issuing office at the number listed on the IRBL or at ts.mp.traffic.management@irs.gov. The PT employee will authorize payment of the inside/pickup charges.

2. When the IRBL authorizes the service, call the driver's supervisor to determine why inside delivery/pickup service is being withheld. As a last resort, contact PT at ts.mp.traffic.management@irs.gov


5. Any problems or instances of carrier non-performance are to be documented at the delivery location and forwarded to the PT section.

6. The PT section is responsible for ensuring IRBLs for shipments are appropriately annotated.

7. The Tax Forms Distribution Programs Section (TFDPS) is responsible for surveying offices requiring inside delivery and including information on the Internal Management Documents Distribution System address file. Those addresses become available to the PT section through the TMS for creating IRBLs.


**1.22.6.8.1** **(01-14-2021)**

#### Motor and Air Freight Carrier - Inside Delivery/Pickup

1. The delivery/pickup and unloading/loading of a shipment by the carrier includes the placing of a vehicle at the delivery/pickup site designated by the consignee/consignor.

2. The driver may unload/load when requested by the consignor or consignee. there may be an additional charge for the service.

3. Unloading/loading includes the counting and removing of the freight from the position in which it is transported in or on the carrier's vehicle. The carrier is required to furnish only one person per vehicle. If additional carrier help is required, it must be pre-arranged before delivery/pickup is attempted. Additional charges will be assessed for this service.

4. When receiving/sending a shipment, the IRS is responsible for the following:



1. Unpacking/packing, dismantling or inspecting, sorting or segregating freight

2. Furnishing equipment for palletized or containerized shipments

3. Moving the freight to/from the loading dock or receiving/shipping area



      ### Note:



      IRS failure or unwillingness to provide these services often results in added costs because the carrier is authorized to bill extra fees to cover added services.


5. Restrictions on any carrier's ability to provide inside delivery/pickup service is usually due to the IRS building security and limited access restrictions.


**1.22.6.9** **(10-27-2021)**

### Loss and Damage - Shipment Discrepancies and Claims

1. The consignee will inspect incoming shipments to determine whether any items shown on the shipping document are missing or damaged.

2. Any visible damages, shortages or overages during the unloading of the shipment will be annotated by the consignee on the carrier’s delivery receipt and on the IRBL and take photos of any damages.



### Note:



It is critical for a successful claim to discover and note loss or damage at the point of delivery. Both the consignee and the carrier's driver must sign to acknowledge the notations. Discrepancies that appear to exceed $50 should be reported to the PT section to file a claim for the IRS.

3. When a loss, damage or discrepancy is discovered after the delivery and the receipt of the shipment, the consignee is to promptly notify the nearest office of the delivering carrier and request an inspection be performed. This is classified as "concealed loss or damage." It is difficult to get full recovery in these cases.

4. PT will send Form 15327, IRS Loss/Damage Claim, to the consignee. This form is used for assisting with filing the claim with the carrier.

5. The consignee is to make every effort to resolve overages or shortages within 10 working days after the detection by immediately notifying the delivering carrier.

6. When accessorial or special services, such as inside delivery, are authorized but have not been provided, the consignee must promptly notify the PTP section so payment for the added charges is not approved.


**1.22.6.9.1** **(01-14-2021)**

#### Supporting Documents

1. The carrier will provide forms for filing of loss or damage claims, full disclosure is required detailing the extent of damage and criteria for the amount claimed. Include all supporting documents, a copy of the IRBL, delivery receipt, proof of value, carrier's inspection report and copies of correspondence with the carrier concerning the loss or damage.


**1.22.6.9.2** **(01-14-2021)**

#### Tracing Lost Shipment or Verifying Delivery

1. The carrier can trace a freight shipment when a reasonable time has been allowed for the shipment to reach its destination or to estimate the arrival date. For tracing both Motor and Air Freight shipments, the following information needs to be gathered before calling the carrier or initiating an online trace:



   - Pro number (freight bill) or air bill number

   - Pickup date and location

   - Delivery location

   - IRBL number


2. All responses to a trace are to be printed or confirmed by email.


**1.22.6.10** **(10-27-2021)**

### Processing for Payment

1. The IRS may not reduce carrier's freight invoice amount because of loss and/or damage. Each proper invoice amount will be paid in full, and a formal claim will be filed with the carrier for the amount of the loss or damage.

2. The PT section will not file a claim against a carrier for any loss or damage of less than $50. Amounts below this amount will be absorbed by the Government.


**1.22.6.11** **(01-14-2021)**

### Insurance

1. Additional insurance coverage should not be purchased for IRS shipments. 48 CFR 47.102 states the Government retains the risk of loss and damage to its property that is not the legal liability of commercial carriers and does not buy insurance for its property in the possession of commercial carriers. This means the IRS is self-insured. Depending on the mode of transportation used, some insurance is provided as part of the transportation contract. For more information contact the PT section.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-022-006#addtoany "Show all")

A2A