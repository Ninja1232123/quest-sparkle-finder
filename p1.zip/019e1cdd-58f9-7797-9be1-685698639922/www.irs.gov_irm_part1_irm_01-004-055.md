---
url: "https://www.irs.gov/irm/part1/irm_01-004-055"
title: "1.4.55 SBSE Campus Collection Support Managers’ Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-055#main-content)

- 1.4.55  [SBSE Campus Collection Support Managers’ Guide](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618330512)
  - 1.4.55.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618059152)
    - 1.4.55.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618076128)
    - 1.4.55.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618074400)
    - 1.4.55.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618118576)
    - 1.4.55.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618905584)
    - 1.4.55.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618149744)
    - 1.4.55.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619115040)
    - 1.4.55.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618107920)
  - 1.4.55.2  [Workload Management](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618180336)
    - 1.4.55.2.1  [Account Management Services (AMS)](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618177824)
    - 1.4.55.2.2  [Control-D](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619099216)
  - 1.4.55.3  [Business Measures](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619096224)
    - 1.4.55.3.1  [Monthly Monitoring Reports (MMR)](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618159888)
    - 1.4.55.3.2  [Targets At A Glance (TAAG)/Weekly at a Glance (WAAG)](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618115456)
  - 1.4.55.4  [Work Plans](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618112368)
    - 1.4.55.4.1  [Planning Periods and FTE Categories](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618165024)
    - 1.4.55.4.2  [Work Plan Changes and Monitoring](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618081840)
    - 1.4.55.4.3  [Scheduling Staff and Monitoring Correct Time Reporting](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618078640)
    - 1.4.55.4.4  [Training Plan, Travel, and Awards](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618922416)
  - 1.4.55.5  [Toll-Free Telephone Service](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618918432)
    - 1.4.55.5.1  [Virtual Call Center (Enterprise)](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618915280)
    - 1.4.55.5.2  [Managing Features](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618095200)
    - 1.4.55.5.3  [Bringing Up the Phone System](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618091504)
    - 1.4.55.5.4  [Informational Announcements on the Call Router](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618942560)
    - 1.4.55.5.5  [Availability and Efficiency](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618938704)
      - 1.4.55.5.5.1  [Idle Reason Codes](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619089872)
      - 1.4.55.5.5.2  [Average Handle Time](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619085056)
    - 1.4.55.5.6  [Real Time Reporting](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619078512)
    - 1.4.55.5.7  [Fluctuating Call Volume](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619072832)
    - 1.4.55.5.8  [Outgoing Calls](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619070272)
    - 1.4.55.5.9  [Defaulted Calls](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304619067376)
    - 1.4.55.5.10  [Toll-Free Telephone Staffing](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618146144)
    - 1.4.55.5.11  [End of Shift Activities](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618140368)
    - 1.4.55.5.12  [System Assistance](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618136816)
    - 1.4.55.5.13  [Manager Calls](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618130560)
      - 1.4.55.5.13.1  [Taking a Call](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618124080)
      - 1.4.55.5.13.2  [Emergency Situations](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618258352)
      - 1.4.55.5.13.3  [Compliments and Complaints](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618255936)
    - 1.4.55.5.14  [Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618250560)
      - 1.4.55.5.14.1  [Contact Recording](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618242192)
      - 1.4.55.5.14.2  [Feedback and Follow-up](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618235264)
    - 1.4.55.5.15  [Telephone Reports](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618230432)
  - 1.4.55.6  [Operational Reviews and Employee Engagement](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618225936)
    - 1.4.55.6.1  [Frequency and Planning](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618223168)
    - 1.4.55.6.2  [Coverage](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618219872)
    - 1.4.55.6.3  [Review Scope](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618212640)
      - 1.4.55.6.3.1  [Department Manager’s Operational Review of Frontline Manager (FLM)](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618202928)
      - 1.4.55.6.3.2  [Operations Manager’s Operational Review of Department Manager (DM)](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618286848)
      - 1.4.55.6.3.3  [Director/P&A Staff Operational Review of Operations Manager (OM)](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618442896)
    - 1.4.55.6.4  [Documentation and Follow-up](https://www.irs.gov/irm/part1/irm_01-004-055#idm140304618549200)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 55. SBSE Campus Collection Support Managers Guide

* * *

## 1.4.55 SBSE Campus Collection Support Managers’ Guide

#### Manual Transmittal

February 27, 2025

#### Purpose

(1) This transmits revised IRM 1.4.55, Resource Guide for Managers, SBSE Campus Collection Support Managers’ Guide.

#### Material Changes

(1) Editorial changes made throughout to update references and terminology; to correct formatting issues; and to revise wording for clarity, eliminate unnecessary or duplicate verbiage, update website address, IRM references and comply with current writing standards. Removed all reference to using the ASPECT throughout this IRM since the ASPECT system has been retired. Updated all references to OL5081 with BEARS. BEARS replaced OL5081.

(2) IRM 1.4.55.1: Added subsection on Program Scope and Objectives in compliance with IRM 1.11.2.

(3) IRM 1.4.55.1: Removed prior Overview section as information captured under new IRM 1.4.55.1.

(4) IRM 1.4.55.2: Removed Responsibilities section as information captured under IRM 1.4.55.1.

(5) IRM 1.4.55.3(1): Added Weekly at a Glance (WAAG) report to Business Measures.

(6) IRM 1.4.55.3.2: Re-titled to include WAAG. Added WAAG as report to review.

(7) IRM 1.4.55.5.5: Removed Managers’ Financial Responsibility Resources as information is obsolete.

(8) IRM 1.4.55.4.3: Added Mistle Report to weekly reports to review.

(9) IRM 1.4.55.4.4(1) Added Training Coordinator as reviewer.

(10) IRM 1.4.55.8: Changes made throughout to provide a breakdown of review details based on management specific roles and positions.

#### Effect on Other Documents

IRM 1.4.55, dated 06-03-2016, is superseded

#### Audience

Managers in SBSE Campus Collection Centralized Case Processing (CCP) and Centralized Lien Operation (CLO)

#### Effective Date

(02-27-2025)

Eric Slayback

Acting Director, Collection Policy

Small Business/Self-Employed

**1.4.55.1** **(02-27-2025)**

### Program Scope and Objectives

1. **Purpose**: This IRM provides managerial guidance for Small Business/Self Employed (SBSE) managers in Collection Centralized Case Processing (CCP) and Centralized Lien Operation (CLO).

2. **Audience**: Managers in SB/SE Campus Collection CCP and CLO.

3. **Policy Owner**: Director of Collection Policy, SB/SE.

4. **Program Owner**: Campus Policy is the program owner of this IRM.

5. **Primary Stakeholders**: CCP and CLO Operations and team leaders in SBSE Campus Collection.


**1.4.55.1.1** **(02-27-2025)**

#### Background

1. This IRM provides managerial guidance and processes for CCP and CLO operations and team leaders at SB/SE Compliance Service Sites.


**1.4.55.1.2** **(02-27-2025)**

#### Authority

1. The authority relating to this section is SB/SE Functional Delegation Orders-Collection SBSE 1-23-2 (Rev. 2), see IRM 1.2.65, Small Business/Self-Employed Delegations of Authority, and Policy Statement 5-2 in IRM 1.2.1, Servicewide Policy Statements.


**1.4.55.1.3** **(02-27-2025)**

#### Roles and Responsibilities

1. Managers are responsible for managing electronic, paper and/or telephone inventory. Proper workload management is essential for timely responses to customers and/or account transactions. Due to the variety and complexity of work in CCP and CLO, managers must be familiar with the many aspects to managing workloads such as:



   - Providing employee oversight and development

   - Conducting reviews

   - Providing adequate training

   - Establishing controls and priorities

   - Using available reports and management tools to monitor the operation

   - Processing work within established time frames

   - Correcting imbalances in work inventory

   - Providing adequate staffing for inventory

   - Being involved in the daily operation

   - Managing time effectively


**1.4.55.1.4** **(02-27-2025)**

#### Program Management and Review

1. Program Reports: Section 1204 reports. Managers are required to submit quarterly certifications of compliance with section 1204 of the Internal Revenue Service Restructuring and Reform Act of 1998, prohibiting the use of tax enforcement results. Daily and weekly reports are performed by management. Headquarters gathers monthly data to communicate targets and objectives.

2. Managers are required to manage work programs and perform program and employee reviews to ensure Campus Collection work is completed according to procedural guidelines contained in applicable IRMs.

3. Reports to assist with management controls are referenced throughout this IRM.


**1.4.55.1.5** **(02-27-2025)**

#### Program Controls

1. Restructuring & Reform Act of 1998 (RRA 98), Section 1204, prohibits the use of records of tax enforcement results to evaluate employees, impose or suggest production quotas or goals with respect to such employees. This applies to all employees regardless of position held or location in which the work is performed. For purpose of implementing this section, IRM 1.5.1, The IRS Balanced Measurement System, refers to employees exercising judgment in determining tax liability or ability to pay as “**Section 1204 Employees**”.

2. IRS has access control measures in place to provide protection from unauthorized alteration, loss, unavailability, or disclosure of information. These access controls are developed according to assigned user duties, i.e., telephone agents, managers, telephone system analyst, or headquarters analyst. Systems users are required to obtain On-Line Business Entitlement Access Request System (BEARS) permissions to access servers and programs, i.e., Contact Recording, Account Management Service (AMS), and Automated Lien System (ALS).

3. Managers are required to follow program management procedures and controls addressed in this IRM.


**1.4.55.1.6** **(02-27-2025)**

#### Terms and Acronyms

1. Frequently used terms used in this IRM along with their definition include:



1. **Bargaining Unit employee**: An employee who is covered by the current National Agreement with the National Treasury Employees Union.

2. **Drop File**: A file to be established for each employee. The employee drop file is for documentation not related to performance.

3. **Employee Performance File**: The Employee Performance File is a system consisting of all performance ratings and other performance-related records maintained in accordance with 5 CFR 293, Subpart D.

4. **National Agreement**: The contract between IRS and the National Treasury Employees Union which covers bargaining unit employees.


2. The following table lists commonly used acronyms and their definitions:




| **Acronym** | **Definition** |
| :-: | :-: |
| AHT | Average Handle Time |
| ALS | Automated Lien System |
| AMS | Account Management System |
| CPE | Continuing Professional Education |
| EQRS | Embedded Quality Review System |
| EPF | Employee Performance Folder |
| FTE | Full Time Equivalent |
| ICS | Integrated Collection System |
| JOC | Joint Operations Center |
| LOS | Level Of Service |
| MMR | Monthly Monitoring Report |
| NTEU | National Treasury Employees Union |
| NQRS | National Quality Review System |
| OFP | Organization/Function/Program |
| OJI | On the Job Instructor |
| RO | Revenue Officer |
| TAAG | Target at a Glance |
| WAAG | Weekly at a Glance |


**1.4.55.1.7** **(02-27-2025)**

#### Related Resources

1. Managers will refer to other guidelines outlined in other IRMs:



   - Part 1, Organization, Finance and Management

   - Part 5, Collection Process

   - Part 21, Customer Account Services

   - Part 25, Special Topics


2. Additional IRM resources:



   - IRM 1.4.1.3, Administrative Responsibilities

   - IRM 1.5.2, Managing Statistics in a Balanced Measurement System, Uses of Section 1204 Statistics

   - IRM 1.15, Records and Information Management

   - IRM 21.10.1, Quality Assurance - Embedded Quality (EQ) Program for Accounts Management, Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support

   - IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs)

   - IRM 6.751, Discipline and Disciplinary Actions: Policies, Responsibilities, Authorities and Guidance

   - IRM 6.800.2, Employee Benefits, IRS Telework Program


3. The following table lists resources from the web:




| **Web Resources** |
| --- |
| Critical Job Elements (CJE): Critical Job Elements (CJE) (sharepoint.com) |
| Embedded Quality: Embedded Quality Review System (EQRS) (sharepoint.com) |
| Human Capital Office (HCO) : Human Capital Office - Home (sharepoint.com) |
| iManage: iManage - Home (sharepoint.com) |
| Small Business Self-Employed Sharepoint: Small Business Self Employed - Home (sharepoint.com) |
| 2022 National Agreement with NTEU: 2022 National Agreement (sharepoint.com) |
| New Manager Orientation Support Center: [New Manager Orientation Support Center (sharepoint.com)](https://irsgov.sharepoint.com/sites/iManage/SitePages/New-Manager-Orientation-Support-Center.aspx) |
| Section 1203 and Non-1203 Misconduct: Section 1203 and Non- 1203 Misconduct (sharepoint.com) |
| Telework: IRS Telework Program (sharepoint.com) |
| Disclosure Knowledge Base: Disclosure (sharepoint.com) |
| Office of Professional Responsibility: Office of Professional Responsibility - Home (sharepoint.com) |


**1.4.55.2** **(06-03-2016)**

### Workload Management

1. Inventory management is a critical part of the collection process. The way inventory is managed has an effect on key business measures and targets like cycle time, closures, customer satisfaction, and overage correspondence percentage.

2. There are various report systems that are available to manage and monitor inventory. In order to properly manage your workload, as a manager, you must be familiar with available inventory reports and consistently review those pertinent to the work performed under your direction.


**1.4.55.2.1** **(06-03-2016)**

#### Account Management Services (AMS)

1. Account Management Services (AMS) provides a common user interface that allows users to update taxpayer accounts, view history and comments from other systems, and access a variety of case processing tools without leaving AMS.

2. AMS functionalities include inventory management, next case delivery, nationwide history and follow-ups, immediate print capabilities to fax to taxpayers, generation of electronic referrals and inventory management.

3. The AMS system provides managers access to many reports. The AMS Reports tool allows the manager to generate pre-defined management reports based on data available in AMS such as Inventory Reports; Case Reports such as the TIN Summary Reports; and Miscellaneous reports such as their Group Profile report.

4. For additional information regarding AMS, refer to the AMS website at: AMS End User Support - Home (sharepoint.com)


**1.4.55.2.2** **(02-27-2025)**

#### Control-D

1. Control-D WebAccess (CTDWA) is Web Access software that allows viewing of reports electronically. Control-D reduces the print output and allows faster access and greater report management for users to their respective report files. Complete BEARS to request access to the CTDWA.

2. The reports are made available to the users upon logging in to the Control-D WebAccess server. This action is necessary to ensure employees have access to the workload.

3. The most common report utilized by CCP is the CCA 4243 report from Control-D provided by the Overage Report Compiler and Sorter (ORCAS).


**1.4.55.3** **(02-27-2025)**

### Business Measures

1. Monthly Monitoring Reports (MMR), Targets at a Glance (TAAG), and Weekly at a Glance (WAAG) reports are used to monitor progress in meeting business measures.

2. Managers should be familiar with these reports and use them to communicate improvement areas to their employees. Operations Managers should be prepared to address any areas of concern with HQ.


**1.4.55.3.1** **(02-27-2025)**

#### Monthly Monitoring Reports (MMR)

1. MMR reports are used to brief the SB/SE Commissioner on a monthly basis.

2. MMR reports provide year to date information on resource usage and inventory activity for major operational program objectives.

3. MMR Reports are reviewed to determine if the Operation is on target to their Plan. If the Operation is not on target, then information should be obtained to determine what actions can be taken to meet the business measure targets.

4. There are separate MMR Reports for CCP and CLO. The information is shown for the current fiscal year cumulative data and two prior years, with percentage columns comparing the current to the prior year, the Plan to date, and the FY Work Plan. During Mid Year assessments a column is added for FY Projected Year-End Accomplishments.

5. Line items on the Collection CCP MMR:



1. Staffing - FTE (Full Time Equivalent) and Direct Time as a Percentage of Total

2. Telephones - Level of Service and Average Handle Time (Minutes)

3. Productivity - FC Processing Action Volume with the Processing Rate Per Hour and Manual Monitor & In-Business Trust Fund IA Support Actions Volume with MMIA/IBTF Support Actions per Hour

4. Inventory Age - Field Case Processing Requests Age % and Field Installment Agreements Request Age %

5. Employee Satisfaction - The results from the Employee Satisfaction Survey

6. Quality - Paper - Customer Accuracy and Timeliness

7. Quality - Phones - Customer Accuracy, Timeliness and Professionalism


6. Line items on the CLO MMR:



1. Staffing - FTE (Full Time Equivalent) and Direct Time as a Percentage of Total

2. Telephones - Level of Service and Average Handle Time (Minutes)

3. Liens - Liens Filed - ALS and Liens Released - ALS

4. Productivity - ALS Output Processing Volume with ALS Output Processing Rate Per Hour and Paper Processing Volume with Paper Processing Rate Per Hour

5. Employee Satisfaction - The results from the Employee Satisfaction Survey

6. Quality - Paper - Customer Accuracy, Timeliness and Professionalism

7. Quality - Phones - Customer Accuracy, Timeliness and Professionalism


7. MMR reports are available at: Collection Program and Campus Reports - MMR (Program Level) & TAAG - All Documents (sharepoint.com)


**1.4.55.3.2** **(02-27-2025)**

#### Targets At A Glance (TAAG)/Weekly at a Glance (WAAG)

1. SBSE and Campus Targets at a Glance (TAAG) and Weekly at a Glance (WAAG) reports summarize the monthly MMR reports for the current Fiscal Year. Measures not within +/- 3% of target are highlighted in yellow, and measures not within +/- 5% of target are highlighted in red.

2. The TAAG/WAAG is used by the SB/SE Area Directors for Campus Collection for discussions with the campus Operations Managers to address measures in red or yellow.

3. The CCP and CLO TAAG/WAAG reports are available at: Collection Program and Campus Reports - MMR (Program Level) & TAAG - All Documents (sharepoint.com)


**1.4.55.4** **(06-03-2016)**

### Work Plans

1. Work Plans are a projection of the staff hours to meet workload demands for each program for the entire fiscal year. Work Plans are determined on an annual basis in the budgeting and planning process.



1. The Office of Management and Budget (OMB) prepares the President’s Budget.

2. Congress reviews and votes on the enactment of the budget.

3. The budget is executed to determine the cost of equipment, contractors, travel, staffing, awards, etc. and funds are distributed to the Agency appropriations for labor and non-labor expenses.

4. Labor funds are converted to the number of Full-Time Equivalent (FTE), which is the total number of compensable hours in a given fiscal year.

5. FTE are broken out to Functional Area Codes (FAC). A FAC is a grouping of related work operations. Overtime FTE is also broken out to each FAC.

6. The SBSE Headquarters (HQ) staff develops the Work Plans for the individual programs within the FAC.


**1.4.55.4.1** **(06-03-2016)**

#### Planning Periods and FTE Categories

1. The Work Plan includes three Planning Periods (PP):



1. PP1 October - December

2. PP2 January - June

3. PP3 July - September


2. Work Plans are established and monitored in three FTE categories:



1. Regular

2. Training - FTE is based on the Training Needs Assessments completed by the campuses during the Work Plan development process

3. Overtime


**1.4.55.4.2** **(06-03-2016)**

#### Work Plan Changes and Monitoring

1. Work Plans change throughout the year depending on different factors, such as peak months for mail receipts, telephone calls, and inventory availability. Changes to the Work Plans are done through the Financial Review and Hiring Plan process throughout the year.

2. In order to reduce inventory, it may be necessary to request additional staffing. Sites must submit requests for additional FTE and/or hiring exceptions through PPM and F&S.

3. HQ staff monitors the use of FTE to ensure adherence to the Work Plan for each program, and coordinates with the Joint Operations Center (JOC) to ensure adherence to telephone staffing requirements, so that program goals are achieved.


**1.4.55.4.3** **(02-27-2025)**

#### Scheduling Staff and Monitoring Correct Time Reporting

1. Managers must schedule available staffing for each planning period based on the correspondence workload and telephone staffing schedules. This includes scheduling of overtime, training, and seasonal furloughs.

2. Managers are responsible for accurate reporting of Time and Attendance (T&A) in the TAPS/SETR system. This includes correct coding for new, reassigned, and detailed employees. Managers will verify and validate all T&As and will input corrected T&As and/or IPR adjustments when errors are identified. Managers will ensure the correct posting of SETR codes as follows:



1. T&A Organization Code

2. SETR Assigned Organization Code

3. Accounting Code

4. Appropriation

5. Function Area Code (FAC)

6. Cost Center

7. Employee Indicator

8. Function, Program, and Time Codes


3. Managers are expected to monitor reports weekly to ensure their employees are reporting time correctly to direct (Not Function Code 990) and overhead (Function Code 990), and OFPs (Organization/Function/Program). The following reports are available for resource monitoring:



1. Time Reports - SETR (Single Entry Time Reporting System)

2. Monthly Monitoring Reports (MMR)

3. Work Planning and Control Reports (WP&C)

4. Mistle Report

5. Other reports provided by the HQ program owners


4. Managers must be consistently aware of changes to staffing and relate that information to the Operation Technical Advisor responsible for preparing the Hiring Plans. This includes gains and losses, LWOP/AWOL/Comp/Credit, overtime, and training.


**1.4.55.4.4** **(02-27-2025)**

#### Training Plan, Travel, and Awards

1. Managers and training coordinator(s) are responsible for:



   - Following the Training Plan and advising the Technical Advisor of any changes to training needs

   - Reviewing travel authorizations and vouchers to ensure accuracy

   - Reviewing appropriate award amounts for discretionary awards


**1.4.55.5** **(06-03-2016)**

### Toll-Free Telephone Service

1. Refer to IRM 1.4.21, _Resource Guide for Managers - Accounts Management and Compliance Guide for Systems Administrators/Analysts_, for information and guidelines regarding the telephone environment.

2. JOC monitors toll-free telephone traffic using a centralized model that views all call sites virtually together, which is known as the Enterprise. JOC coordinates the operations of campuses, and it authorizes planning and scheduling for the campuses. JOC oversees the efficiency of functions and programs for each individual campus. The primary objective of JOC is ensuring the services provided to the customers are fair and consistent at all times.

3. JOC requests real-time changes in telephone staffing based on incoming call demand and overall resources. They make requests to the sites to add or reduce telephone staffing to meet call demand.


**1.4.55.5.1** **(06-03-2016)**

#### Virtual Call Center (Enterprise)

1. The Virtual Call Center (Enterprise) links through a central location and delivers the call to the longest available agent for the skill group.

2. If no agent is available, the call is queued at the Enterprise level until an agent becomes available and only then is it routed to the agent.

3. All toll-free telephone data is captured daily and stored in the web-based Enterprise Telephone Data (ETD) Warehouse. ETD stores data for historical use and also produces daily, weekly and ad hoc reports at the national (Executive Level Summary) and site level, including directorate roll-ups of remote sites. ETD raw data is available for research and troubleshooting. Site-level measures are also available on ETD when appropriate.

4. The role of a manager, in the Enterprise environment, is to ensure the right number of people with the right skills are available to answer calls.


**1.4.55.5.2** **(06-03-2016)**

#### Managing Features

1. JOC programs Intelligent Call Management (ICM) (through scripts that use business rules) for maximum call routing efficiency, based on demand and assistor availability.

2. Monitoring capabilities, data base records and management information are available on the phone system. Instructions for using features of the phone system are available through the telephone system analysts.

3. Use features such as:



   - Monitoring agents (listening in on calls in progress)

   - Notifying agents (notifying an agent whom you are monitoring to call you).


**1.4.55.5.3** **(06-03-2016)**

#### Bringing Up the Phone System

1. For managers with employees scheduled for telephone duty, open real time monitoring reports to view current phone status.

2. Review the screens for all of the following:



1. Assistors signed on the system from the day before that may have forgotten to signoff.

2. Assistors are signed on and ready to take calls when the phone lines are opened.

3. If applicable, assistors ready to cover calls for specialty and Spanish applications.

4. Employees are signed on with the correct agent group, if applicable.


**1.4.55.5.4** **(06-03-2016)**

#### Informational Announcements on the Call Router

1. JOC controls all announcements and scripts used on toll-free telephone numbers.

2. Announcements are valuable tools to:



1. Inform callers of answering delays

2. Provide basic information such as the address or phone number

3. Inform callers of the time frame before receipt of a fax can be confirmed or before correspondence is reviewed


**1.4.55.5.5** **(06-03-2016)**

#### Availability and Efficiency

1. As a manager, telephone data is available to assist you in evaluating the service being given to taxpayers and determining the efficiency and availability of site-level staff.

2. Managers and Systems Analysts (SA) must determine on a half-hourly basis by application if staff is available as scheduled. If less than the required number of agents is signed on, an explanation is required per adherence guidelines. This is normally accomplished by contacting the JOC Monitoring Room to notify JOC of the shortage and the reason (i.e., local inclement weather) the site will be understaffed.

3. Managers must ensure their employees are signed on to the telephone system and taking calls when scheduled. This reduces shrinkage, which is considered unscheduled time away from normal scheduled activities. Examples of shrinkage include:



   - Extended read and meeting times

   - Tardiness

   - Leaving early

   - Higher than expected attrition for day (e.g., sick leave)

   - Scheduled breaks not followed

   - Unauthorized breaks

   - Extended breaks or lunch periods


4. JOC, in collaboration with Compliance headquarters and site management, makes daily real-time adjustments to staffing levels based on actual demand and actual staffing.


**1.4.55.5.5.1** **(06-03-2016)**

##### Idle Reason Codes

1. Use available data to monitor and analyze efficiency. This includes:



   - Agent Idle and Sign-on times

   - Agent Average Handle Time (AHT)

   - Agent Average Wrap Time


2. **"Idle"** time consists of those times employees are signed on the telephone system, but not in the Available, Ready, Wrap, or Out Call status. Per the Customer Service Agreement, agents must use a reason code when they are assigned to answer incoming calls and they are in "Idle" status. See the CSA for "Idle" procedures in Attachment 1, Idle with Aspect Reason Code.

3. Managers should refrain from conducting meetings, informal training, group observances, etc. during peak telephone/paper periods/days.


**1.4.55.5.5.2** **(06-03-2016)**

##### Average Handle Time

1. Average Handle Time (AHT) is a data element and determines resources needed to achieve a budget-driven Level of Service (LOS) - LOS is the primary measure used by external stakeholders (Congress) to determine IRS efficiency.

2. JOC issues weekly Average Handle Time (AHT) reports to the system analysts.

3. Very long talk times affect program goals and increases the number of abandoned calls. It is usually an indicator that additional training may be needed in conversation control.

4. Managers should identify employees who may be using **excessively long or short times** in handling calls. Monitor a few of their calls to identify problems such as:



1. Training deficiency

2. Failing to keep call brief while maintaining standards of courtesy and full service

3. Placing a call on hold during the research process when it is inappropriate instead of arranging for a call back

4. Answering a large volume of unusually complex questions

5. Failing to provide a complete or accurate response


**1.4.55.5.6** **(06-03-2016)**

#### Real Time Reporting

1. The real time reporting tools can be designed to:



1. List agents and their current agent state

2. Display general call information for the application handled by the site or individual


2. The real time reports can assist managers in the following ways:



1. Choose the most convenient times to monitor or share information with an employee

2. Confirm the number of employees who are ready and/or taking calls to provide a complete picture of staff available to meet customer demand

3. Identify Emergency alerts in the event an employee presses the EMERGENCY button


3. Real time reports show the number of employees who are actually at their work stations handling incoming calls. This data, compared to the total number assigned, provides information about the realization of the scheduled staff.


**1.4.55.5.7** **(06-03-2016)**

#### Fluctuating Call Volume

1. Managers should ensure all employees assigned to answer calls are at their workstations taking calls.

2. Managers will be notified by local site System Administrators (SA) or Department Managers if changes are needed in scheduled staffing based on contacts from JOC. This could include adding staff in a specific agent group or taking employees off the telephones to do other work. It is important for managers to minimize the amount of time it takes for employees to transition to a different work assignment, i.e. to start taking calls or to start other work.


**1.4.55.5.8** **(06-03-2016)**

#### Outgoing Calls

1. Employees may need to make outgoing calls to secure additional information to resolve an inquiry.

2. Employees making outgoing calls on these phones are not counted as part of ready staffing for site level adherence to schedule, nor are they considered in routing calls. Managers should monitor the number of outgoing calls to ensure they are necessary.

3. The wrap time for an employee for outgoing calls should be appropriate to the type of call.


**1.4.55.5.9** **(06-03-2016)**

#### Defaulted Calls

1. A site may receive calls normally not handled when there is a hardware or network failure. When failures occur, calls do not route out to Intelligent Call Management (ICM) but instead queue locally. Site system administrators (SAs) are responsible for identifying calls in applications not currently staffed and contacting site management to place employees in the appropriate agent group to handle the call or write a referral if the call cannot be fully answered.


**1.4.55.5.10** **(06-03-2016)**

#### Toll-Free Telephone Staffing

1. Efficient telephone staffing is one of the keys to meeting the planned Level of Service.

2. Managers must ensure staffing is efficient. An increase to the Average Handle Time (AHT) can impact Level Of Service (LOS) and other business measures and in turn increase the need for staff. Circuit availability may also be impacted.

3. Information is available from system reports for you to monitor the efficiency of your staff. Reports available include:



1. Average Handle Time

2. Wrap Time

3. Idle Report

4. Agent Activity Report

5. Sign On/Sign Off Report

6. Ready Report


**1.4.55.5.11** **(06-03-2016)**

#### End of Shift Activities

1. End of day activities involve reviewing the real time reports for the following:



1. Assistors in wrap or idle that should be signed off the system.

2. Assistor reports showing available, wrap, idle, break and other information.


2. An end of shift review of telephone concerns and problems should be completed. These should be shared with the Manager(s) responsible for the next phone shift/rotation. This allows for a review of assistors signing on for the next shift at the start of their Tour of Duty (TOD) to help take calls when in the phone rotation.


**1.4.55.5.12** **(06-03-2016)**

#### System Assistance

1. The System Administrator/Telephone Analyst (SA/TA) is a valuable resource person for information on the call center environment.

2. Managers must coordinate with their SA/TA on any activity limiting the sites ability to deliver its commitment for scheduled staffing requirements.

3. The SA/TA provides assistance on the following:



1. Information about system operations and call routing

2. Explanation of various real time and historical reports

3. Identification of data availability and creating reports

4. Assessment of current call site performance

5. Monitoring procedures

6. Opening tickets for hardware or software issues

7. Database changes


**1.4.55.5.13** **(06-03-2016)**

#### Manager Calls

1. Manager calls should be very rare. If an assistor refers an excessive number of calls, it is likely that additional training and coaching is needed in "Effective Communication" and/or "Dealing with Difficult Taxpayers."

2. Remember everyone in the IRS is an advocate for the taxpayer. Appropriate actions should be taken to correct the taxpayer’s problem on first contact. However, if you cannot correct the problem AND the taxpayer’s issue meets Taxpayer Advocate Service (TAS) criteria, as outlined in IRM 21.1.3.18, _Taxpayer Advocate Service (TAS) Guidelines,_ refer the case to TAS using Form 911.

3. Encourage assistors to practice techniques to diffuse a taxpayer's anger, reassure taxpayers that they can assist with the issue, and make every effort to handle the call themselves. However, some taxpayers:



1. Immediately want to speak with a manager,

2. Are only satisfied by speaking with a manager even though the assistor has provided the requested assistance,

3. Want to complain about the service the IRS has provided, or

4. Want to compliment the service the IRS has provided.


**1.4.55.5.13.1** **(06-03-2016)**

##### Taking a Call

1. If the manager is available to take the call, the call can be transferred to the manager. If not available, the employee should input an action note and advise the caller the manager will return the call within twenty four hours (one business day).

2. In order to receive a manager call, ensure you are signed onto their telephone.

3. When a call is transferred to the manager, the taxpayer is already distressed. Be prepared to take the appropriate action to deal with their needs. An important goal in dealing with a distressed taxpayer is to keep potentially disruptive emotions out of the conversation. Start with controlling your own reactions and emotions.



### Note:



Even though the taxpayer is distressed, they want to believe that as a manager, you can make the situation better.

4. When you are prepared to speak with the taxpayer, take the referred call:



1. Verify with the assistor that disclosure was covered.

2. Obtain the SSN and the tax year from the assistor.

3. Connect with the taxpayer and provide your name, identification number and ask, "How may I help you?"


5. While talking with taxpayers, you represent the Internal Revenue Service and must always conduct yourself in a professional manner. Be courteous, control the direction of the conversation and give the taxpayer accurate and complete assistance.



1. Maintain a pleasant, friendly tone of voice.

2. Speak clearly, using words the taxpayer can understand.

3. Avoid using IRS jargon and acronyms.

4. Handle taxpayer’s negative reactions with patience.

5. Treat the taxpayer as a unique individual deserving respect.

6. Put yourself in the taxpayer’s place. If you received a notice and called for assistance, you would want to be treated with respect and given accurate, complete information to resolve the problem.


6. There are three steps to lessen a taxpayer's anger:



1. Listen,

2. Empathize, and

3. Assure.


7. Callbacks are used when you prefer to return the call at a later time, enabling you to research the account before talking to the taxpayer. If you prefer to return the taxpayer's call, obtain the taxpayer's name, SSN, phone number and the best time to return the call.

8. Double jacking enables the Manager to take the call along side the assistor. Using this procedure might provide some insight on how this type of call could be handled by the assistor in the future.



### Note:



SIGNOFF the telephone system when you are away from your desk.


**1.4.55.5.13.2** **(06-03-2016)**

##### Emergency Situations

1. Refer to IRM 1.4.21.1.2.14, _Employee and Building Security Responsibilities,_ for guidance on handling emergency situations.


**1.4.55.5.13.3** **(06-03-2016)**

##### Compliments and Complaints

1. Complimentary calls should be routed to a Manager. Records of complimentary calls should be included in the employee’s annual appraisal under the appropriate critical element. Be sure to thank anyone who compliments the IRS.

2. Taxpayer complaints about unresolved tax account issues should be resolved if possible. If unable to resolve, and the issue meets Taxpayer Advocate Service (TAS) criteria as outlined in IRM 13.1.7, _Taxpayer Advocate Service (TAS) Case Criteria,_ transfer to TAS. Employees may also provide the taxpayer with the TAS office contact toll-free number of 1-877-777-4778.

3. Taxpayer complaints about individual (IRS) employees are captured under the Section 1203 process. Managers consult with Workforce Relations and TIGTA to investigate the issue. See IRM 21.1.3.16, _Taxpayer Complaints/Compliments About IRS Service._



### Note:



Check for campus directions for handling taxpayer complaints and compliments.


**1.4.55.5.14** **(06-03-2016)**

#### Telephone Monitoring

1. IRM 1.2.10.1.9, _Policy Statement 1-44,_ , provides guidelines regarding "Monitoring of Employee Telephone Conversations." This Policy Statement mandates the use of monitoring employees for evaluative and training purposes.

2. Telephone monitoring allows managers to determine whether the employee:



1. Addressed disclosure issues,

2. Treated the customer with respect, courtesy and fairness,

3. Researched reference material accurately,

4. Followed IRM 5.4.13.10, _Mandated Use of Integrated Automation Technology (IAT),_

5. Resolved the case per IRM guidelines,

6. Provided an accurate answer,

7. Applied appropriate communication skills, and

8. Conducted a concise successful interview.


### Note:

All telephones subject to monitoring must be properly labeled so employees know that calls may be recorded/monitored. Calls are recorded via the Contact Recording system.

**1.4.55.5.14.1** **(06-03-2016)**

##### Contact Recording

1. Contact Recording is an automated quality monitoring system. It provides an "instant replay" of employee and taxpayer interaction.

2. The automated system captures voice and on-screen computer activity for later retrieval and review.

3. Contact recordings are used for performance/managerial monitoring purposes only and are normally erased within 45 days.

4. All calls are recorded in their entirety under contact recording.

5. Follow the timeframes in the current IRS/NTEU National Agreement for sharing performance feedback.

6. A separate sample of recorded calls is selected for quality review purposes and is not tracked to individual employees for evaluative purposes.



### Note:



Management may request that a recorded contact be downloaded. Refer to IRM 1.4.21.1.2.6, _Managerial Requests,_ for more information regarding this type of request.

7. Contact Recording is the preferred method of telephone monitoring. If this is not available, live monitoring may be conducted through the telephone. A manager signs on to their phone and follows steps for real time monitoring provided by the telephone analyst.

8. Double plugging to review telephone calls may be performed to assist in employee skill development.


**1.4.55.5.14.2** **(06-03-2016)**

##### Feedback and Follow-up

1. Determine if additional monitoring/review is necessary based on the following factors:



   - Training

   - Employee's ongoing performance

   - Quality Review feedback

   - Required minimum monitoring


### Note:

Use telephone agent performance reports such as Wrap Time and Average Handle Time (AHT) as indicators to determine when additional monitoring is appropriate.

2. On-the-Job instructors (OJIs) monitor trainees to provide constructive feedback and assist in employee development. Team leaders monitor side-by-side to improve work skills.


**1.4.55.5.15** **(06-03-2016)**

#### Telephone Reports

1. Telephone reports provide managers call activity statistics on a particular assistor/agent. The telephone systems analysts are a valuable resource for information on reports such as:



   - Number and average length of incoming/outgoing calls

   - Transfer by each agent

   - Time spent in messaging and voice mail

   - Percentage of time in Available, Idle, and Wrap


**1.4.55.6** **(02-27-2025)**

### Operational Reviews and Employee Engagement

1. An Operational Review is an in-depth review and analysis of a particular program or function or a subordinate manager and their organizational component. Reviews are opportunities to improve overall effectiveness of managers, teams, departments, and Operation. Reviews of subordinate managers are imperative for their personal growth and the efficiency of the operation.

2. These reviews may be of organizational as well as individual performance. The review should be:



   - Evaluative and direct.

   - Completed annually (unless more frequent reviews are warranted either to address inexperience or poor performance).


**1.4.55.6.1** **(02-27-2025)**

#### Frequency and Planning

1. Each operations and department manager should complete an operational review of each subordinate component every year.

2. Conduct more frequent follow-up reviews when warranted by indicators such as statistical data out of the acceptable range, lack of experience on the part of the subordinate manager, or poor results from prior reviews. These reviews should also have established follow-up review dates scheduled for any areas showing minimal/no improvement.

3. Each Operations and Department Manager will maintain an operational review schedule showing the date of the prior review and the scheduled and actual review dates for each component for which they are responsible. Prepare a schedule of planned reviews at the beginning of each fiscal year and no later than November 1st. Schedule review to ensure that all teams are addressed. Provide the schedule to the Operations Manager or Director as appropriate.


**1.4.55.6.2** **(02-27-2025)**

#### Coverage

1. Operational reviews are performed by:



   - Department Managers (DM) reviewing Frontline Teams.

   - Operations Managers (OM) reviewing Department Managers.

   - Planning & Analysis (P&A) Staff reviewing Operations.


### Note:

Information may be provided by the operations analyst or technical advisor to support the review(s) when available. As the process moves up through each component of management, the content of the review is streamlined to minimize duplication of effort and focus on the higher priorities at each level of management.

2. A Department Manager's review should cover a majority of the team's and employees’ responsibilities. Review should include but is not limited to; employee leave and attendance, workload management and inventory controls, EPF maintenance, timekeeping records, status of prior Headquarters Collection review action items and identified training needs of employees, specific feedback and action items as required.

3. An Operations Manager's review should cover a majority of all operational reviews completed by the Department Manager. The review should focus on the overall health of the Department including efficiencies and program enhancements, risk management, succession planning and staffing, special projects, best practices, status of prior Headquarters Collection review action items, operational goals and future planning, specific feedback and action items as required.

4. Director/Planning & Analysis’ staff review should cover the Operation’s internal controls, best practices, risk operationalization, staffing, succession planning, employee development, and the status of operational goals, status of prior Headquarters Collection review action items and future planning, specific feedback and action items as required.


**1.4.55.6.3** **(02-27-2025)**

#### Review Scope

1. Each Operations and Department Manager should review the manager’s Position Description and Performance Management System (PMS) expectations prior to starting the review.

2. Request the information needed from the manager in advance, generally 30 days. This will ensure all information is available at the start of the review.

3. Each Manager will set required reviews for each component. This may include the following items, but not limited to:



   - Meeting Minutes.

   - Inventory Reports.

   - Telephone contacts (where applicable).

   - Work in process.

   - Closed cases.

   - Leave tracking.

   - Review samples and schedules.

   - Evaluation/Midyear samples.

   - Quality Improvement Initiatives.

   - Management Controls Tracking.


4. A current EPF check sheet/template should be included in all EPF folders. It is recommended when EPFs are reviewed:



   - Department Managers should include a review of EPFs for each team in the frontline operational review

   - Operations Managers should review a sampling of EPFs from the various teams in each Department. Include a variety of skills (Manager, work leader, secretary, clerk, tax examiner) and employees with different levels of experience.


5. The scope of the Operational Review should include a majority of the listed issues as applicable, but others may be added at the discretion of the reviewer.


**1.4.55.6.3.1** **(02-27-2025)**

##### Department Manager’s Operational Review of Frontline Manager (FLM)

1. **Leadership & Human Capital:** Evaluating Leadership involves review of actions taken toward FLM Commitments:




| **Leadership Attribute** | **Activities** |
| :-: | :-: |
| Leadership Development | - Developing Career Learning Plans (CLP), Leadership Succession Review (LSR).<br>     <br>   - Scheduling meeting with CLP/LSR participants.<br>     <br>   - Providing development opportunities |
| Adaptability | Adapting to and promoting organization change. |
| Networking | Networking with peers and stakeholders. |
| Communication | - Sharing knowledge with employees, peers and beyond the work unit.<br>     <br>   - Maintaining meeting minutes.<br>     <br>   - Maintaing visibility to the team.<br>     <br>   - Listening.<br>     <br>   - Communicating through e-mail.<br>     <br>   - Encouraging a positive work environment.<br>     <br>   - Sharing Team and Operational Goals.<br>     <br>   - Sharing expectations. |
| Use of Time | - Time management - effectiveness of method for managing tasks or assignments.<br>     <br>   - Workload processing and handling of backlogs.<br>     <br>   - Organization effectiveness.<br>     <br>   - Identification of problems and implementation of solutions.<br>     <br>   - Timeliness of controlled responses. |
| Employee Personnel Folders (EPF) Maintenance | - Review a random sample of employee EPFs in each team. (Director discretion on sample volume requirements).<br>     <br>   - Review current EPF checklist.<br>     <br>   - Ensure outdated material is purged.<br>     <br>   - Review quality of supporting narratives for annual ratings.<br>     <br>   - Evaluate whether ratings are supported by reviews.<br>     <br>   - Evaluate whether reviews are in compliance with IRS documentation rule for Section 1204 and Disclosure. |
| Timekeeping Record/Controls | Review:<br> <br>   - WebSETR.<br>     <br>   - Leave Records.<br>     <br>   - FMLA tracking/documentation.<br>     <br>   - Credit requests and approvals.<br>     <br>   - Overtime (OT)/Credit sign-in sheets.<br>     <br>   - Telephone reports.<br>     <br>   - Employee time reporting. |

2. **Customer Service & Collaboration - Customer Satisfaction:** Evaluate quality aspects as follows:



   - Use of EQRS Reports.

   - EQRS Quality results/goals shared with employees.

   - Number of EQ reviews conducted.

   - Error trends identified.

   - Quality improvement actions taken.

   - Workshops provided.

   - Employee input requested and utilized.


3. **Employee Engagement:** Evaluate aspects of employee engagement as follows:




| **Employee Engagement Components** | **Review Description** |
| :-: | :-: |
| Team Meeting Minutes | - Review frequency of meetings, content, employee engagement.<br>     <br>   - Solicit agenda items from the team.<br>     <br>   - Share agendas.<br>     <br>   - Ensure meeting minutes are available for employees to review. |
| Performance Feedback | Evaluate:<br> <br>   - Methods of feedback.<br>     <br>   - Schedule in place for Annual and Mid-Year reviews.<br>     <br>   - Timeliness of Annual and Mid-Year reviews presented.<br>     <br>   - Schedule of work reviews; such as EQ, paper and telephone monitoring.<br>     <br>   - Sample reviews for narratives including both negative and positive feedback.<br>     <br>   - Timeliness of employee feedback and follow-up.<br>     <br>   - Actions taken to improve employees performing below the acceptable level.<br>     <br>   - Contract requirements are covered if the performance has decreased. |
| Employee Engagement | - Solicits employee perspectives in achieving team or operational goals.<br>     <br>   - Addresses issues raised by employees, follow-up and feedback.<br>     <br>   - Uses management information reports to improve employee performance and overall team (inventory reports, Employee Survey, EQRS, phone reports, etc.).<br>     <br>   - Uses survey results to enhance Employee Satisfaction, Customer Satisfaction and Business Results. |
| Staff Utilization | - Identifies and eliminates single points of failure, ensuring back-ups are in place for all responsibilities.<br>     <br>   - Provides cross training.<br>     <br>   - Utilizes clerical support effectively to ensure all work is logged in, batched and assigned per the IRM requirements timely.<br>     <br>   - Work leader accessibility. |
| Best Practices & Program Enhancements | - Involvement in special projects.<br>     <br>   - Identifies and implements efficiencies.<br>     <br>   - Identifies best practices.<br>     <br>   - Engages the staff in Leading Improvement and Leading Others. |

4. **Program Management - Business Results:** Evaluate aspects of program management as follows:




| **Program Management Attribute** | **Activities** |
| :-: | :-: |
| Leave Usage | - Review Leave Usage Report for leave balances/patterns.<br>     <br>   - Review leave counseling documentation. |
| Time Utilization | - Identifies/elevates/resolves scheduling issues.<br>     <br>   - Reviews status of inventory.<br>     <br>   - Initiatives/challenges.<br>     <br>   - Response to dues/controls. |
| Strategic Plan | - Actions taken to achieve operational goals.<br>     <br>   - Maintains technical abilities by keeping abreast of procedural changes, reviews SERP Alerts, attends annual Continuing Professional Education (CPE) or technical training when available. |
| Risk Management | Process to operationalize risk awareness within and outside of team. |
| Statute Protection | Takes actions to protect statutes. |


**1.4.55.6.3.2** **(02-27-2025)**

##### Operations Manager’s Operational Review of Department Manager (DM)

1. **Leadership & Human Capital:** Evaluating Leadership involves review of actions taken toward DM commitments:




| **Leadership Attribute** | **Activities** |
| :-: | :-: |
| Leadership Development | - Developing Career Learning Plans (CLP), Leadership Succession Review (LSR).<br>     <br>   - Scheduling meeting with LSR participants.<br>     <br>   - Providing development opportunities |
| Adaptability | Adapting to and promoting organization change. |
| Networking | Networking with peers, stakeholders, internal and external contacts. |
| Communication | - Knowledge sharing with direct and indirect staff, peers and beyond the department.<br>     <br>   - Visibility to staff.<br>     <br>   - E-mail communication.<br>     <br>   - Operational Goals are shared. |
| Use of Time | - Time management - effectiveness of method for managing tasks or assignments.<br>     <br>   - Workload processing and handling of backlogs.<br>     <br>   - Organization effectiveness.<br>     <br>   - Identification of problems and implementation of solutions.<br>     <br>   - Timeliness of controlled responses. |
| Employee Personnel Folders (EPF) Maintenance | - Review a random sample of employee EPFs in each team. (Director discretion on sample volume requirements).<br>     <br>   - Current EPF checklist provided.<br>     <br>   - Outdated material purged. |

2. **Customer Service & Collaboration - Customer Satisfaction:** Evaluate quality aspects as follows:



   - Compare EQRS results among all teams in department.

   - Share EQ Quality results/goals with departments.

   - Number of EQ reviews conducted.

   - Error Trends identified.

   - Quality Improvement actions taken.


3. **Employee Engagement:** Evaluate aspects of employee engagement as follows:




| **Employee Engagement Component** | **Review Description** |
| :-: | :-: |
| Staff Meeting Minutes | Review frequency of meetings, content and appropriate agenda items are filtered from DM to teams. |
| Performance Feedback | - Methods of feedback used.<br>     <br>   - Review schedule in place for Annual and Mid-Years.<br>     <br>   - Annual and Mid-Years are presented timely. |
| Employee Engagement | - Solicits employee perspectives in achieving team or operational goals.<br>     <br>   - Addresses issues raised by employees, follow-up and feedback.<br>     <br>   - Holds Focus Group Meetings.<br>     <br>   - Uses survey results to enhance Employee Satisfaction, Customer Satisfaction and Business Results. |
| Staff Utilization | - Promotes succession planning.<br>     <br>   - Acts to minimize effects of projected attrition.<br>     <br>   - Addresses staffing concerns.<br>     <br>   - Ensures inventory management controls are in place. |
| Best Practices & Program Enhancements | - Involvement in Special Projects.<br>     <br>   - Identifies and implements efficiencies.<br>     <br>   - Identifies Best Practices.<br>     <br>   - Engages staff in Leading Improvement and Leading Others. |

4. Program Management - Business Results: Evaluate aspects of program management as follows:




| **Program Management Attribute** | **Activities** |
| :-: | :-: |
| Leave Usage | - Oversee resources.<br>     <br>   - Review Leave Usage Report for leave balances/patterns.<br>     <br>   - Review leave counseling documentation. |
| Time Utilization | - Response to dues/controls.<br>     <br>   - Addresses/resolves program challenges and/or scheduling issues. |
| Strategic Plan | - Actions taken to achieve operational goals.<br>     <br>   - Manager maintains technical abilities by keeping abreast of procedural changes, reviews SERP Alerts, attends annual Continuing Professional Education (CPE) or technical training when available. |
| Risk Management | Process to operationalize risk awareness within and outside of team. |
| Statute Protection | Takes actions to protect statutes. |


**1.4.55.6.3.3** **(02-27-2025)**

##### Director/P&A Staff Operational Review of Operations Manager (OM)

1. Leadership & Human Capital: Evaluating Leadership involves review of actions toward OM Commitments:




| **Leadership Attribute** | **Activities** |
| :-: | :-: |
| Leadership Development | - Schedule meetings with LSR participants.<br>     <br>   - Provides developmental opportunities. |
| Adaptability | Adapting to and promoting organization change. |
| Networking | Networking with internal and external stakeholders. |
| Communication | - Knowledge sharing with direct and indirect staff and beyond the operation.<br>     <br>   - Visibility to staff.<br>     <br>   - Status of operational goals are shared. |
| Employee Personnel Folders (EPF) Maintenance | - Random sampling from various teams in each department: (2) DM, (2) FLM and (1) tax examiner or collection representative, clerk, and team lead from each department.<br>     <br>   - Current EPF checklist provided.<br>     <br>   - Outdated material purged. |

2. **Customer Service & Collaboration - Customer Satisfaction:** Evaluate quality aspects by review of NQRS/EQRS reports:



   - Compare NQRS to EQRS cumulative results to identify opportunities for improvement in each measure.

   - Compare Quality Goals to Quality achievements.

   - Evaluate Quality improvement actions.


3. **Employee Engagement:** Evaluate aspects of employee engagement as follows:




| **Employee Engagement Component** | **Review Description** |
| :-: | :-: |
| Operation Meeting Minutes | Review frequency of meetings, content and appropriate agenda items are filtered through operation. |
| Performance Feedback | Ensures annual Continuing Professional Education (CPE) is provided to all employees. |
| Employee Engagement | - Solicits employee perspectives in achieving team or operational goals.<br>     <br>   - Holds Town Hall Meetings.<br>     <br>   - Conducts Focus Group Meetings.<br>     <br>   - Employs other engagement activities.<br>     <br>   - Use of survey results to enhance Employee Satisfaction, Customer Satisfaction and Business Results. |
| Staff Utilization | - Promotes succession planning.<br>     <br>   - Acts to minimize effects of projected attrition.<br>     <br>   - Addresses staffing concerns.<br>     <br>   - Ensures inventory management controls are in place. |
| Best Practices & Program Enhancements | - Involvement in special projects.<br>     <br>   - Identifies and implements efficiencies.<br>     <br>   - Identifies Best Practices.<br>     <br>   - Engages the staff in Leading Improvement and Leading Others. |

4. Program Management - Business Results: Evaluate aspects of program management as follows:




| **Program Management Attribute** | **Activities** |
| :-: | :-: |
| Time Utilization | - Response to dues/controls.<br>     <br>   - Addresses/resolves program challenges and/or scheduling issues.<br>     <br>   - Monitors program targets.<br>     <br>   - Delivery of the business plan. |
| Strategic Plan | Actions taken to achieve operational goals. |
| Risk Management | Process to operationalize risk awareness within and outside of team. |
| Statute Protection | Takes actions to protect statutes. |


**1.4.55.6.4** **(02-27-2025)**

#### Documentation and Follow-up

1. Each operational review must be documented in a memorandum from the reviewer to the manager of the component reviewed. The memorandum must be issued promptly upon completion of the review. For purposes of assessing the timeliness of the review, the memorandum date will be the same as the review completion date.

2. It is not intended that the review be completed all at once. Any item reviewed before the scheduled operational review should not be repeated. However, the results of such reviews must be included in the documented annual review.

3. To provide continuity and a record of the problems and progress of each organizational component, review memorandums and all follow-up action items should be maintained in file folders or binders by organizational component. A signed and dated copy of the initialed memorandum(s) and all follow-up documentation must be placed in the EPF of the appropriate manager for future use in the evaluation process.

4. Managers must follow up to ensure accomplishment of action items identified in their reviews. Whenever an action item is documented, give a date for completion; use a desk calendar or other device to trigger the follow-up. One method to document the follow-up is to leave a few blank lines below each action item in the review memorandum. The reviewer then documents follow-up results directly on the file copy of the review memo and will not have to initiate another memorandum describing the follow-up.

5. The follow-up must be performed timely and include actions taken on problems identified, updated progress actions taken towards completion and any further actions identified. All actions requiring additional follow-up must be documented with a second date for completion.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-055#addtoany "Show all")

A2A