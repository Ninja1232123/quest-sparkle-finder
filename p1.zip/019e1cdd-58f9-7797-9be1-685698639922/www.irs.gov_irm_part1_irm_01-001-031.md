---
url: "https://www.irs.gov/irm/part1/irm_01-001-031"
title: "1.1.31 Office of the Chief Risk Officer | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-031#main-content)

- 1.1.31  [Office of the Chief Risk Officer](https://www.irs.gov/irm/part1/irm_01-001-031#idm140082119734880)
  - 1.1.31.1  [Introduction to the Office of the Chief Risk Officer](https://www.irs.gov/irm/part1/irm_01-001-031#idm140082119689232)
  - 1.1.31.2  [Organizational Goals](https://www.irs.gov/irm/part1/irm_01-001-031#idm140082119752832)
  - 1.1.31.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-001-031#idm140082119746640)
  - 1.1.31.4  [Office of the Chief Risk Officer](https://www.irs.gov/irm/part1/irm_01-001-031#idm140082119686688)
  - 1.1.31.5  [Definition of Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-001-031#idm140082119682816)
  - 1.1.31.6  [Resources](https://www.irs.gov/irm/part1/irm_01-001-031#idm140082119679504)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 31. Office of the Chief Risk Officer

* * *

## 1.1.31 Office of the Chief Risk Officer

#### Manual Transmittal

March 03, 2021

#### Purpose

(1) This transmits new IRM 1.1.31, _Organization and Staffing, Office of the Chief Risk Officer_.

#### Material Changes

(1) 1.1.31.1(1)(b), Introduction to the Office of the Chief Risk Officer. Added information about the Enterprise Audit Management (EAM) office.

(2) 1.1.31.2 (5), Organizational Goals. Added a goal of the EAM office.

(3) 1.1.31.2 (6), Organizational Goals. Added a goal of the EAM office.

(4) 1.1.31.2 (7), Organizational Goals. Added a goal of the EAM office.

(5) 1.1.31.2 (8), Organizational Goals. Added a goal of the EAM office.

(6) 1.1.31.2 (9), Organizational Goals. Added a goal of the EAM office.

(7) 1.1.31.3(1), Responsibilities. Expanded the list of responsibilities to include those related to the EAM office.

(8) 1.1.31.4(2), Office of the Chief Risk Officer. Added information on the realignment of EAM into the Office of the CRO.

(9) 1.1.31.5(3), Definition of Terms and Acronyms. Added references to sections specific sections in IRM 1.29.1, Audit Coordination Process – Authorities and Responsibilities.

(10) 1.1.31.5(4), Definition of Terms and Acronyms. Added references to sections specific sections in IRM 1.29.1, Audit Coordination Process – Authorities and Responsibilities.

(11) 1.1.31.6(3), Resources. Added reference to IRM 1.29.1, Audit Coordination Process – Authorities and Responsibilities.

#### Effect on Other Documents

This IRM supersedes IRM 1.1.31 dated May 8, 2019.

#### Audience

Servicewide

#### Effective Date

(03-03-2021)

Thomas A. Brandt

Chief Risk Officer

**1.1.31.1** **(03-03-2021)**

### Introduction to the Office of the Chief Risk Officer

1. The Office of the Chief Risk Officer (CRO) oversees the Enterprise Risk Management (ERM) program, and the Enterprise Audit Management (EAM) program.



1. The ERM program provides an agency-wide approach to risk management to foster a risk-aware culture through education, awareness, and mitigation approaches and helps IRS units incorporate risk management principles into strategies and daily operations.

2. The EAM program provides an agency-wide approach to audit management providing oversight and policy related to handling TIGTA and GAO audits and audit responses, as well as post-audit tracking and monitoring of corrective action implementation. EAM serves as the single point of contact for GAO and TIGTA audits and TIGTA Inspections and Evaluations, promoting and supporting a collaborative, professional, and positive partnership with IRS oversight entities.


.



**1.1.31.2** **(03-03-2021)**

### Organizational Goals

1. Enhance ERM Capabilities: Continue to evolve and strengthen the structure, processes and policies needed to support an effective enterprise risk management program at the IRS.

2. Facilitate ERM Activities: Help leadership and management identify, assess and address potential areas of risk that could negatively impact the achievement of IRS goals and objective.

3. Provide ERM Outreach, Communications and Training: Development risk management training and communications to enhance understanding, awareness and utilization of effective risk management practices at all levels of the organization.

4. Support Business Unit Executives and ERM Liaisons in Operationalizing Risk Management: Provide tools, guidance and support to help IRS business unit executives and ERM Liaisons with operationalization of risk management practices within their units.

5. Enhance Service-wide understanding of audit and risk information by viewing the two through an integrated lens.

6. Facilitate the audit process, ensuring auditors have access to the people and information they need to conduct each audit, while at the same time resolving any issues that arise during the audit.

7. Ensure a consistent and repeatable process within the IRS and between the IRS and oversight entities.

8. Prioritize corrective actions that address the highest risk and deliver the most value.

9. Cultivate a collaborative partnership between oversight entities and IRS officials built on trust and confidence.


**1.1.31.3** **(03-03-2021)**

### Responsibilities

1. The Office of the CRO:



01. Communicates and continues to evolve and mature ERM pursuant to the IRS’s enterprise risk management vision.

02. Participates in IRS’s strategy and objective setting discussions, including strategic planning and decision-making forums and provides risk perspective.

03. Establishes ERM framework, structure and process, including defining roles and responsibilities.

04. Ensures proper risk management ownership by the business units.

05. Guides integration of ERM with other IRS planning and management activities.

06. Promotes risk awareness at the IRS.

07. Partners with the business and functional units on their most important risks.

08. Reports to the IRS Commissioner on the progress of the ERM program, status of enterprise risks and recommended actions.

09. Represents the IRS in the Treasury ERM Council, the Federal Interagency ERM Council and other forums.

10. Ensures appropriate IRS officials are informed of audit issues or findings that negatively impact IRS.

11. Coordinates the IRS response according to policies established under Treasury.

12. Represents the IRS in the audit resolution process when there is significant disagreement with an audit recommendation, in an attempt to negotiate and resolve differences before referral to Treasury.

13. Advises and consults with Treasury whenever a matter will be referred for resolution.

14. Provides program oversight to the business units tasked with completion of corrective action plans related to TIGTA and GAO recommendations, including review, validation, and approval of supporting documentation.

15. Oversees the post audit tracking via Treasury’s JAMES system.


**1.1.31.4** **(03-03-2021)**

### Office of the Chief Risk Officer

1. In 2013 the Commissioner established the CRO and responsibility for ERM. The ERM program is a process authorized by the Commissioner and effectuated by management and other personnel, applied in strategy setting and across the enterprise, designed to identify potential events that may affect the IRS, to manage risk to be within its risk appetite and to provide reasonable assurance regarding the achievement of the IRS objectives.

2. In 2019, the Commissioner moved the existing Office of Audit Coordination function and team from the CFO to the CRO, due to the natural alignment between risks and audit findings. The Audit Coordination function and team was renamed Enterprise Audit Management.

3. The CRO is the policy owner of the ERM and EAM programs and is responsible for oversight of both programs.

4. The CRO reports to the Deputy Commissioner for Operations Support (DCOS), and is also a dotted-line report to the Commissioner. The EAM and ERM teams are each led by Senior Managers who report directly to the CRO.


**1.1.31.5** **(03-03-2021)**

### Definition of Terms and Acronyms

1. For a list of terms used throughout the Office of the CRO and ERM program see IRM 1.4.60.1.3, Definition of Terms.

2. For a list of acronyms used throughout the Office of the CRO and ERM program see IRM 1.4.60.1.4, Acronyms.

3. For a list of terms used throughout the Office of the CRO and EAM program see IRM 1.29.1.1.6, Terms/Definitions.

4. For a list of acronyms used throughout the Office of the CRO and EAM program seeIRM 1.29.1.1.7, Acronyms.


**1.1.31.6** **(03-03-2021)**

### Resources

1. OMB Circular No. A-123, Management Responsibility for Enterprise Risk Management and Internal Control

2. IRM 1.4.60, Enterprise Risk Management Program

3. IRM 1.29.1, Audit Coordination Process – Authorities and Responsibilities

4. Internal Office of the CRO Website: https://irssource.web.irs.gov/CRO/Pages/Home.aspx


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-031#addtoany "Show all")

A2A