---
url: "https://www.irs.gov/irm/part1/irm_01-004-052"
title: "1.4.52 Offer in Compromise Manager's Resource Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-052#main-content)

- 1.4.52  [Offer in Compromise Manager's Resource Guide](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381851520)
  - 1.4.52.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381832448)
    - 1.4.52.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381822288)
    - 1.4.52.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381820480)
    - 1.4.52.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381810704)
    - 1.4.52.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381807376)
    - 1.4.52.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381803120)
    - 1.4.52.1.6  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381798272)
    - 1.4.52.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381765696)
  - 1.4.52.2  [Responsibilities of an Offer in Compromise Manager](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955381721280)
    - 1.4.52.2.1  [Acting Manager Assignments and Designations](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380763344)
  - 1.4.52.3  [Security Access Validation Frequency](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380754048)
    - 1.4.52.3.1  [Compliance Data Warehouse Knowledge Graph Environment (CKGE) Monitoring](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380749392)
    - 1.4.52.3.2  [Bank Secrecy Act Portal Query Monitoring](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380738656)
  - 1.4.52.4  [Communication of Expectations](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380734656)
  - 1.4.52.5  [Time Reporting in the Offer in Compromise Program](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380710704)
    - 1.4.52.5.1  [Time Reporting for COIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380707104)
      - 1.4.52.5.1.1  [Clerical Time Reporting in the COIC Program](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380705408)
      - 1.4.52.5.1.2  [Process Examiner Time Reporting in the COIC Program](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380700384)
      - 1.4.52.5.1.3  [Tax Examiner Time Reporting in the COIC Program](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380692416)
      - 1.4.52.5.1.4  [Offer Examiner Time Reporting in the COIC Program](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380690560)
    - 1.4.52.5.2  [Time Reporting for FOIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380686192)
      - 1.4.52.5.2.1  [Time Reporting for Offer Specialists](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380680256)
      - 1.4.52.5.2.2  [Time Reporting for Paraprofessionals (FOIC Tax Examiners)](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380668128)
      - 1.4.52.5.2.3  [Time Reporting for Clerical (FOIC Secretaries/Management Assistants)](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380665248)
    - 1.4.52.5.3  [Time Reporting for Monitoring Offer in Compromise](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380652864)
  - 1.4.52.6  [Workload Management](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380639968)
    - 1.4.52.6.1  [Use of Suspense/Hold Files in COIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380635296)
    - 1.4.52.6.2  [FOIC Case Grading](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380630480)
    - 1.4.52.6.3  [Assigning Work](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380612688)
      - 1.4.52.6.3.1  [Assigning Work for Offer Examiners](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380601120)
      - 1.4.52.6.3.2  [Assigning Work for Offer Specialists](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380598384)
      - 1.4.52.6.3.3  [Assigning Work for MOIC Tax Examiners](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380591440)
    - 1.4.52.6.4  [COIC Responsibility for Cases Transferred to FOIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380588704)
    - 1.4.52.6.5  [Closing and Review Actions](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380580288)
      - 1.4.52.6.5.1  [COIC and Field Closing and Review Actions](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380571808)
      - 1.4.52.6.5.2  [MOIC Closing and Review Actions](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380555280)
    - 1.4.52.6.6  [Maintaining Employee Inventory Levels and New Case Hold Files](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380550512)
      - 1.4.52.6.6.1  [Maintaining Employee Inventory Levels and New Case Hold Files for Offer Examiners](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380548064)
      - 1.4.52.6.6.2  [Maintaining Employee Inventory Levels and New Case Hold Files for Offer Specialists](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380543008)
    - 1.4.52.6.7  [Timeliness of Case Actions](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380538992)
    - 1.4.52.6.8  [Workload Management](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380533008)
      - 1.4.52.6.8.1  [Workload Management for COIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380531072)
      - 1.4.52.6.8.2  [Workload Management Using Integrated Collection System, ENTITY and AOIC for FOIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380512368)
      - 1.4.52.6.8.3  [Workload Management for MOIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380490128)
    - 1.4.52.6.9  [AOIC and Business Objects Reports](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380485232)
    - 1.4.52.6.10  [Semi-Annual Inventory Matches and Inventory Matches](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380448224)
      - 1.4.52.6.10.1  [Semi-Annual Inventory Matches and Inventory Matches for COIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380444336)
      - 1.4.52.6.10.2  [Semi-Annual Inventory Matches and Inventory Matches for FOIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380439920)
      - 1.4.52.6.10.3  [Semi-Annual Inventory Matches and Inventory Matches for MOIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380434400)
    - 1.4.52.6.11  [AOIC Clean Up](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380431232)
    - 1.4.52.6.12  [Quality and Inventory Controls](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380418768)
    - 1.4.52.6.13  [Quality and Inventory Controls for COIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380410000)
    - 1.4.52.6.14  [Quality and Inventory Controls for FOIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380391808)
    - 1.4.52.6.15  [Monitoring Offer in Compromise Quality and Inventory Controls](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380371712)
  - 1.4.52.7  [Employee Performance Analysis](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380350720)
    - 1.4.52.7.1  [Case Reviews and Performance Discussions](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380349760)
    - 1.4.52.7.2  [Reviews and Employee Performance Discussions for OIC](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380336160)
    - 1.4.52.7.3  [Review Documentation](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380330784)
    - 1.4.52.7.4  [Mandatory Reviews (COIC, DATL, FOIC, and MOIC)](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380317824)
      - 1.4.52.7.4.1  [After-Hours Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380242896)
    - 1.4.52.7.5  [Additional Optional Reviews for Managers](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380231040)
      - 1.4.52.7.5.1  [Review of Taxpayer and/or Representative Interviews](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380229280)
    - 1.4.52.7.6  [OIC Department Manager, Operations Manager/Field Compliance Manager, and Director, Specialty Collection Offer in Compromise Annual Operational Review Overview](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380215088)
      - 1.4.52.7.6.1  [Operational Reviews and Employee Engagement](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380203152)
      - 1.4.52.7.6.2  [OIC Operational Review Frequency and Planning](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380200368)
      - 1.4.52.7.6.3  [Documentation](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380194944)
      - 1.4.52.7.6.4  [COIC Department Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380186544)
        - 1.4.52.7.6.4.1  [Leadership & Human Capital Employee Satisfaction COIC Department Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380184240)
        - 1.4.52.7.6.4.2  [Employee Engagement COIC Department Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380164976)
        - 1.4.52.7.6.4.3  [Customer Service and Collaboration-Customer Satisfaction COIC Department Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380149600)
        - 1.4.52.7.6.4.4  [Program Management Business Results COIC Department Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380133248)
        - 1.4.52.7.6.4.5  [Administrative/Compliance Review COIC Department Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380117408)
      - 1.4.52.7.6.5  [Field Compliance Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380104528)
        - 1.4.52.7.6.5.1  [Leadership & Human Capital Employee Satisfaction Field Compliance Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380101200)
        - 1.4.52.7.6.5.2  [Employee Engagement Field Compliance Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380081952)
        - 1.4.52.7.6.5.3  [Customer Service and Collaboration-Customer Satisfaction Field Compliance Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380067040)
        - 1.4.52.7.6.5.4  [Program Management Business Results Field Compliance Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380050384)
        - 1.4.52.7.6.5.5  [Administrative/Compliance Review Field Compliance Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380034592)
      - 1.4.52.7.6.6  [Operations Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380021760)
        - 1.4.52.7.6.6.1  [Leadership & Human Capital Employee Satisfaction Operations Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380018736)
        - 1.4.52.7.6.6.2  [Employee Engagement Operations Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955380000080)
        - 1.4.52.7.6.6.3  [Customer Service and Collaboration-Customer Satisfaction Operations Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379984192)
        - 1.4.52.7.6.6.4  [Program Management Business Results Operations Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379967952)
        - 1.4.52.7.6.6.5  [Administrative/Compliance Review Operations Manager Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379952272)
      - 1.4.52.7.6.7  [Director, Specialty Collection Offer in Compromise Annual Operational Review](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379940512)
  - 1.4.52.8  [Telework](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379918880)
    - 1.4.52.8.1  [Managing in a Telework Environment](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379914064)
  - 1.4.52.9  [Case Documentation, Protecting Taxpayer Rights, and Use of Statistical Data](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379904016)
    - 1.4.52.9.1  [Case Documentation](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379902864)
    - 1.4.52.9.2  [Protecting Taxpayer Rights](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379898272)
      - 1.4.52.9.2.1  [Fair Tax Collection Practices](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379884880)
    - 1.4.52.9.3  [Use of Statistical Data](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379866528)
  - 1.4.52.10  [Tax Examiners in the OIC Program](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379858016)
    - 1.4.52.10.1  [OIC Field Group Responsibilities for the Tax Examiner](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379856160)
    - 1.4.52.10.2  [MOIC Tax Examiner Duties](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379789216)
  - 1.4.52.11  [Group Secretaries/Administrative Assistants in the OIC Program](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379783024)
  - 1.4.52.12  [Shipment of Closed Cases to Federal Records Center (FRC)](https://www.irs.gov/irm/part1/irm_01-004-052#idm139955379765888)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 52. Offer in Compromise Manager's Resource Guide

* * *

## 1.4.52 Offer in Compromise Manager's Resource Guide

#### Manual Transmittal

April 09, 2025

#### Purpose

(1) This transmits a revision to IRM 1.4.52, Resource Guide for Managers, Offer in Compromise Manager's Resource Guide.

#### Material Changes

(1) This IRM was reorganized and updated to incorporate the following changes.

| **Number** | **Subsection** | **Change** |
| :-: | :-: | :-: |
| 1. | Effect on other documents | Incorporated IGM SBSE-01-0324-0007, Interim Guidance on Reporting Potential Violations of IRC 6304 Fair Tax Collection Practices in Specialty Collection Offer in Compromise, dated 03/04/2024 to IRM 1.4.52.9.2.1. |
| 2. | Throughout | Made various editorial changes throughout the IRM, e.g., correcting spelling or grammatical errors; updating website addresses/links; adding or correcting IRM references; formatting, etc. |
| 3. | 1.4.52.1.6 | Added definitions including the field compliance manager. |
| 4. | 1.4.52.3 | Added: In addition, you should forward the employee’s electronic fax number to your email until the number is deleted. |
| 5. | 1.4.52.3.1 | Added subsection for CKGE monitoring and manager review requirement. |
| 6. | 1.4.52.3.2 | Added subsection for BSA Portal and manager responsibilities. |
| 7. | 1.4.52.4 | Updated expectation topics for manager to discuss with employee. |
| 8. | 1.4.52.5.3 | Removed MOIC time reporting count requirements. |
| 9. | 1.4.52.6.5 | Added that electronic approval systems should be incorporated in approvals when appropriate. |
| 10. | 1.4.52.7.3 | Added language for managers to review Fair Tax Collection and states managers must report violations. |
| 11. | 1.4.52.7.4 | When writing review mid-year and annual narratives be concise, but descriptive enough to provide an accurate picture of the strengths, development needs, and accomplishments of the employee in each CJE. See IRM 6.430.2.4.6, Completing Appraisal Narratives. Note: Employees may submit a self-assessment, limited to four pages in length, no later than the last workday of the employee’s annual appraisal rating period. See IRM 6.430.2.4.5, Self-Assessments and IRM 6.430.2.6, Conducting the Performance Appraisal Meeting. Added item to MOIC Tax Examiner review: Takes appropriate and timely actions listed on RPA output logs |
| 12. | 1.4.52.7.4.1 | Revised this subsection to provide specifics for annual after-hour review security requirements since IRM 1.4.6 is now obsolete. |
| 13. | 1.4.52.7.6 | Revised explanation of who conducts Operational reviews and the requirements for each. |
| 14. | 1.4.52.7.6.1 | Included subsection on Employee Engagement and Operational reviews. |
| 15 | 1.4.52.7.6.2 | Added subsection for Operational review frequency which includes providing the Operational review schedule to the manager/director by November 1. |
| 16 | 1.4.52.7.6.3 | Added subsection on Operational review documentation and listed format for the operational review to be shared within 30 days of the review completion. |
| 17. | 1.4.52.7.6.4 | Rewrote the procedures needed for the COIC department manager to conduct the Operational review and clarified that the review report must be shared with the manager within 30 days of the completion of the actual review. |
| 18. | 1.4.52.7.6.4.1- 1.4.52.7.6.5 | Added new subsections for department manager Operational review criteria. |
| 19. | 1.4.52.7.6.5 | Rewrote the procedures needed for the FCM to conduct the Operational review and clarified that the review report must be shared with the manager within 30 days of the completion of the actual review. |
| 20. | 1.4.52.7.6.5.1-1.4.52.7.6.5.5 | Added new subsections for FCM Operational review criteria. |
| 21. | 1.4.52.7.6.6 | Rewrote the procedures needed for the operations manager to conduct the Operational review and clarified that the review report must be shared with the manager within 30 days of the completion of the actual review. |
| 22. | 1.4.52.7.6.6.1-1.4.52.7.6.6.5 | Added new subsections for operations manager Operational review criteria. |
| 23. | 1.4.52.7.6.7 | Rewrote the procedures needed for the SCOIC Director to conduct the Operational review and clarified that the review report must be shared with the manager within 30 days of the completion of the actual review. |
| 24. | 1.4.52.9.2.1 | Added Fair Tax Collection Practices subsection. |
| 25. | 1.4.52.10.2 | Added to MOIC Tax Examiner duties: Timely response to TAS OAR requests. |

#### Effect on Other Documents

This material supersedes IRM 1.4.52, dated 10/16/2023 and incorporates Interim Guidance Memorandum SBSE-01-0324-0007 dated 03/04/2024.

#### Audience

Small Business/Self-Employed, Centralized OIC team managers, Collection Field function OIC group managers, department managers, MOIC team managers, field compliance managers (FKA territory managers) and operations managers with Offer in Compromise oversight, and Director Specialty Collection Offer in Compromise (SCOIC).

#### Effective Date

(04-09-2025)

Eric Slayback

Acting Director, Collection Policy

Small Business/Self-Employed

**1.4.52.1** **(04-09-2025)**

### Program Scope and Objectives

1. **Purpose**: This chapter discusses the responsibilities of managers in Centralized Offer in Compromise (COIC), including Doubt as to Liability (DATL), Offer in Compromise (OIC) field (FOIC) groups, and Monitoring Offer in Compromise (MOIC) teams and should be used in conjunction with IRM 1.4.50, Collection Group Manager, Field Compliance Manager, and Area Director Operational Aid, all sections of IRM 5.8, Offer in Compromise, IRM 5.19.7, Monitoring Offer in Compromise, and IRM 5.19.24, Doubt as to Liability Offer in Compromise. Assignment of work must align with Policy Statement 1-236, _Fairness and Integrity in Enforcement Selection_. Adherence to the principles in this policy statement ensure the IRS is meeting its commitment in the IRS Mission Statement by “enforcing the tax law with integrity and fairness to all.” This section also provides guidance for operational reviews by department managers (DM)s, operations managers (OM)s, field compliance managers (FCM)s \[formerly known as territory managers (TM)s\], and director.

2. **Audience:** These procedures apply to IRS (Internal Revenue Service) employees who are responsible for managing COIC, FOIC, and MOIC employees.

3. **Policy Owner:** Director, Collection Policy.

4. **Program Owner:** SBSE Collection Policy, Offer in Compromise (OIC) Program.

5. **Primary Stakeholders:** The primary stakeholders are COIC managers (including DATL managers), DMs, OMs, FOIC group managers (GM)s, FCMs, MOIC managers and SCOIC directors.

6. **Program Goals:** Since managing employees who are engaged in evaluating and monitoring offers in compromise presents certain issues unique to OICs, this IRM provides the fundamental knowledge and procedural guidance for COIC, FOIC, and MOIC managers to appropriately manage their employees \[offer examiner (OE), process examiner (PE), offer specialist (OS), tax examiner (TE) and secretary/administrative assistant\] including performance management, work assignment, approval of work, promoting quality casework, and internal team/group controls. Guidance for the team managers, GMs, DMs, OMs, FCMs, and the director is present as well.


**1.4.52.1.1** **(04-09-2025)**

#### Background

1. This subsection provides direction for COIC team managers, DMs, OMs, FOIC GMs, FCMs, and MOIC managers. Additional guidance is provided for the director of SCOIC for the operational review of the OIC program.


**1.4.52.1.2** **(04-09-2025)**

#### Authority

1. Authorities relating to this subsection include:




| **Authorities** |
| :-: |
| IRC 7122, Compromises |
| IRC 6304, Fair tax collection practices |
| IRC 6702(b), Civil penalty for specified frivolous submissions |
| Policy Statement P-5-89 |
| Policy Statement P-5-100 |
| Policy Statement 1-236 |
| Rev. Proc. 2003-71 |
| IRM 1.2.1, Servicewide Policy Statements |
| IRM 1.2.2.6.1, Delegation Order 5-1, To Accept, Reject, Return, Terminate or Acknowledge Withdrawals of Offers in Compromise |
| Internal Revenue Service Restructuring and Reform Act of 1998, Section 1203 |


**1.4.52.1.3** **(04-09-2025)**

#### Roles and Responsibilities

1. The Director, Collection Policy, is responsible for all policies and procedures within the Offer in Compromise program.

2. The National Program manager, OIC Policy, is responsible for development and delivery of policies and procedures within the program.

3. The Director, SCOIC, is responsible for the performance of the OIC program and ensuring IRM policies and procedures are followed.

4. OMs, DMs, team managers, FCMs, and GMs in OIC are responsible for ensuring the procedures are followed and employee actions are timely and accurate.


**1.4.52.1.4** **(04-09-2025)**

#### Program Management and Review

1. Operational and program reviews are conducted on a yearly basis by the director of SCOIC and OIC Collection Policy respectively, with the use of data and reports from the Automated Offer in Compromise (AOIC) system, ENTITY case management system, and Integrated Collection System (ICS). Additional ad hoc reports which provide information on the inventory levels, hours per case, and age of offers in open or closed inventory are also used.

2. For additional information on managing an FOIC group, see IRM 1.4.50, Collection Group Manager, Field Compliance Manager, and Area Director Operational Aid.

3. Managerial case reviews are completed and controls followed as defined in this IRM. These reviews are a method to determine if the offer amount accurately reflects the reasonable collection potential (RCP) as defined in Policy Statement P-5-100 and if timely and appropriate actions have been taken. MOIC managers review to determine if timely and appropriate actions have been addressed during the OIC monitoring process as defined in this IRM and IRM 5.19.7, Monitoring Offer in Compromise. DATL COIC managers review to determine if timely and appropriate actions have been addressed per IRM 5.19.24, Doubt as to Liability Offer in Compromise.

4. National quality reviews and consistency reviews are routinely conducted to ensure program consistency and effectiveness in case processing.


**1.4.52.1.5** **(04-09-2025)**

#### Program Controls

1. AOIC is used to track offers submitted by taxpayers and record case actions and history. Ability to take action on AOIC is limited to specific offer employees. Additional permissions are provided based on an employee’s duties and responsibilities.

2. ICS is used by FOIC employees as a method for inventory control and history documentation.

3. Managerial requirements for case approval are defined in Delegation Order 5-1.

4. ENTITY and ICS are utilized by FOIC managers and AOIC is utilized by COIC (including DATL), FOIC, and MOIC managers as a method for inventory control and appropriate time utilization.

5. Managers are required to follow program management procedures and controls addressed in this IRM. Additionally, FOIC managers are required to follow IRM 1.4.50, Collection Group Manager, Field Compliance Manager, and Area Director Operational Aid, when applicable.

6. Case reviews are conducted by the Office of Chief Counsel on certain offers in accordance with Internal Revenue Code 7122(b) and Treasury Regulations 301.7122-1 - Compromises.


**1.4.52.1.6** **(04-09-2025)**

#### Terms/Definitions/Acronyms

1. The following table defines acronyms frequently used throughout this IRM subsection:




| **Acronym** | **Name** | **Definition** |
| :-: | :-: | :-: |
| AOIC | Automated Offer in Compromise | Computer application where offers in compromise are recorded and monitored from receipt to closure. History of the offer investigations conducted by COIC employees and of actions taken by Monitoring OIC (MOIC) units are also maintained on this system. |
| BSA Portal | Bank Secrecy Act Portal | The BSA Portal provides authorized users access to BSA data via the BSA Search application. In addition, the Portal offers users secure mail, reports, a knowledge library, training and help resources, critical announcements, statistics and information, helpful links, and news. |
| COIC | Centralized Offer in Compromise | Taxpayers send Form 656, Offer in Compromise, to one of the two COIC sites; located at the Brookhaven or Memphis sites. Units located in Brookhaven and Memphis complete initial processing and forward processable offers to offer examiners at the sites or to FOIC for investigation. |
| CKGE | Compliance Data Warehouse Knowledge Graph Environment | An interactive software tool that provides linked data and graph analytics for a range of a taxpayer’s related entities. CKGE was developed by Research, Applied Analytics & Statistics (RAAS) and is a graph database. CKGE performs data analytics from information in the Compliance Data Warehouse (CDW) and provides a graphic representation of a taxpayer’s relationship to other entities. |
| CSED | Collection Statute Expiration Date | The date the statutory period for collecting the tax expires. |
| DATL | Doubt as to Liability | The Centralized DATL processing unit located at the Brookhaven site receives all Forms 656-L submitted on the basis of DATL. COIC will process Trust Fund Recovery Penalty (TFRP) and Personal Liability for Excise Tax (PLET) offers and forward them to FOIC offices for investigation. |
| DM | Department Manager | Manager of a department in the campus. |
| ENTITY | ENTITY Case Management System | ENTITY is a current database displaying FOIC inventory and time applied on a case. |
| EPF | Employee Performance File | An Employee Performance File is maintained by the employee’s immediate supervisor consisting only of performance related documents in compliance with 5 CFR 293, Subpart D, and Document 1289, The General Records Schedule (GRS), 2.2 Item 070-Employee Management Records, Employee Performance File System Records. |
| FCM | Field Compliance Manager | These managers were formerly known as Territory managers (TM)s. The Field Compliance Manager is a second level supervisory position responsible for planning, organizing, coordinating, monitoring, and directing the programs responsible for the collection activities of the Small Business/Self-Employed taxpayers through subordinate FOIC group managers. |
| FCQ | Financial Crimes Enforcement Network Query | FCQ is a web-based application owned by the Financial Crimes Enforcement Network (FinCEN), a bureau within the Department of the Treasury. FCQ is a powerful and versatile tool to query and analyze Bank Secrecy Act (BSA) data, which is accessible through the FinCEN portal. FCQ stores information reported by financial institutions. |
| FOIC | Field Offer in Compromise | Field offices where offer specialists investigate offers. |
| FTCP | Fair Tax Collection Practices | IRC 6304 addresses appropriate practices for fair tax collection. |
| GM | Group Manager | Manager of an FOIC group. |
| ICS | Integrated Collection System | Computer application used by Compliance employees to monitor inventory. Histories of OIC investigations conducted by FOIC employees are maintained on this system. |
| MOIC | Monitoring Offer in Compromise | Teams located in Brookhaven and Memphis that monitor accepted offers for compliance with all terms, complete the default of accepted offers when applicable and are responsible for the 4710 account. Accepted offers are sent to one of the two sites (Brookhaven and Memphis) based on whether they were accepted in COIC or FOIC. |
| OE | Offer Examiner | An offer investigator located in one of the two COIC sites; located at the Brookhaven or Memphis site. |
| OS | Offer Specialist | A revenue officer appointed as an offer investigator, generally located in FOIC. |
| TIPRA | Tax Increase Prevention and Reconciliation Act of 2005 – Section 509 | Legislation enacted in May, 2006 which made major changes to the OIC program. |

2. Additional acceptable acronyms and abbreviations are found in the ReferenceNet Acronym Database.


**1.4.52.1.7** **(04-09-2025)**

#### Related Resources

1. Additional resources can be found in:




| **Resource Name** | **Title** | **Guidance On** |
| :-: | :-: | :-: |
| IRM 1.2.1 | Servicewide Policy Statements | Provides guidance on the policy statements relating to Organization, Finance, and Management activities. |
| IRM 1.2.2 | Servicewide Delegations of Authority | Provides delegations of authority that relate to Organization, Finance, and Management activities. |
| IRM 1.4.1 | Management Roles and Responsibilities | Provides fundamental responsibilities of management positions and also serves as a useful reference for all IRS Divisions and Functions' managers and employees. |
| IRM 1.4.1.3 | Administrative Responsibilities | Provides guidance on the administrative actions managers perform. |
| IRM 1.4.50 | Collection Group Manager, Field Compliance Manager, and Director Operational Aid | Provides guidance on Inventory Levels, maintaining EPFs and various other managerial responsibilities. |
| IRM 1.5.2 | Uses of Section 1204 Statistics | Provides guidance to prevent use of statistics to evaluate employees. |
| IRM 1.15 | Records and Information Management | Provides guidance on records management including the entire life cycle of records from creation to disposition, regardless of format. |
| IRM 1.15.5 | Relocating/Removing Records | Provides guidance on relocating/removing records and appropriately securing records in advance of employee separation. |
| IRM 5.1.23 | Taxpayer Representation | Provides procedural guidance and instructions to handle taxpayer representation issues when working offer cases. |
| IRM 5.3.1 | ENTITY Case Management System (ENTITY) | Workload management tool. |
| IRM 5.8 | Offer in Compromise | Provides procedures for collection employees to follow when considering a taxpayer’s proposal to compromise. |
| IRM 5.13.1 | Embedded Quality Collection Field Organizations Administrative Guidelines | Provides guidance on Embedded Quality Review System (EQRS). |
| IRM 5.19.7 | Monitoring Offer in Compromise | Provides the fundamental knowledge and procedural guidance for the tax examiners engaged in the monitoring of offers. |
| IRM 5.19.24 | Doubt as to Liability Offer in Compromise | Provides SBSE site employees procedures for processing Doubt as to Liability Offer in Compromise cases. |
| IRM 6.430.2 | Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs) | Provides guidance on evaluating employees with critical job elements CJEs. |
| IRM 6.751.1 | Discipline and Disciplinary Actions: Policies, Responsibilities, Authorities, and Guidance | Provides managerial guidance regarding disciplinary action whenever it is warranted by employee misconduct or delinquency. |
| IRM 6.800.2 | IRS Telework Program | Provides guidance regarding telework agreements. |
| IRM 10.2.5 | Identification Media | Provides guidance for ensuring the return of ID media items to local FMSS Security offices on an employee's last day of work. |
| IRM 10.8.34 | IDRS Security Controls | Procedures for the administration of the security program for the Integrated Data Retrieval System (IDRS). |
| Document 11678 | National Agreement - Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU) | Provides notification for meetings as well as employee rights and benefits. |
| Document 12803 | AOIC-SC User Guide for MOIC Campus Tax Technicians | AOIC User guide for MOIC |
| Document 12360 | Embedded Quality Job Aid (Offer in Compromise) | Case reviews |
| Document 12990 | IRS Records Control Schedules (RCS). | IRS records retention and disposition requirements approved by the National Archives and Records Administration (NARA). |
| Training 28206-001 | Automated Offers In Compromise (AOIC) Application | AOIC User guide |

2. Web resources include:




| **Web Resources** |
| :-: |
| Collection Virtual Library |
| Critical Job Elements |
| Embedded Quality |
| [FinCEN](https://bsa.fincen.gov/) |
| Human Capital Office |
| IManage |
| IMD Site |
| IRS Telework Portal |
| My SBSE |
| New Manager Orientation Support Center |
| SERP |
| UNAX |


**1.4.52.2** **(04-09-2025)**

### Responsibilities of an Offer in Compromise Manager

1. In accomplishing the mission of the Internal Revenue Service, it is your responsibility to provide oversight and direction in several areas. Your oversight responsibilities include but are not limited to below.




| **Manager Oversight Responsibilities** |
| :-: |
| Ensure case actions are timely and in accordance with current law, policies, and procedures. |
| Ensuring high standards of professionalism are maintained in all correspondence and telephone contact, with both internal and external customers. |
| Ensuring employees observe taxpayer rights and advise taxpayers and/or their representatives of those rights and how to exercise them. |
| Ensuring employees are aware of the role of the Taxpayer Advocate Service and the Low Income Tax Clinics (refer to Pub 4134, Low income Taxpayer Clinic List), and the service these functions provide is properly communicated with taxpayers and/or their representative. |
| Ensuring employees are aware of and comply with ongoing changes to the law, policies and procedures that relate to their responsibilities. |
| Addressing system issues that impact either internal or external customer needs. |
| Ensuring cases are assigned timely and appropriate inventory levels are maintained. |
| Ensuring workloads reflect employee experience and skills, address Service-Wide objectives, and protect public interest. |
| Helping employees make the right next case decision. |
| Ensuring employees are accountable for the appropriateness of their actions. |
| Providing ongoing feedback that is candid, meaningful, and will establish a basis for determining an accurate assessment of performance and development needs. |
| Issuing Critical Job Elements (CJE)s timely and timely evaluating employee performance against their CJEs. |
| Creating and maintaining a work environment that will promote teamwork, positive working relationships and increased employee satisfaction. |
| Providing technical guidance on the OIC program to other Collection employees, and other functions as necessary. |

2. You are responsible for oversight of certain administrative functions for your employees including, but not limited to the list below.




| **Manager Administrative Oversight Functions** |
| :-: |
| Overseeing the time reporting process |
| Maintenance of time and attendance records |
| Certifying overtime records |
| Approving scheduled and unscheduled leave |
| Controlling and approving travel |
| Maintaining safe working conditions |
| Completing quarterly 1204 self certifications |
| Oversight of supply procurement |
| Ensuring employees have necessary equipment and supplies |
| Maintaining EPF and drop files for each employee |
| Ensuring group ENTITY End of Month reports are completed correctly (verified, generated, and approved) by the due date (FOIC only)<br> <br>### Note:<br>You may delegate certain administrative duties to a secretary/administrative assistant; however, you retain oversight responsibility for those tasks. |
| Reviewing appropriate system reports. |
| Overseeing group remittance processing activities, including monitoring Form 5919, Teller’s Error Advice, sent to your team/group. See procedures in IRM 5.1.2.5.6, Responding to Form 5919. |
| Reviewing necessary electronic messaging reports such as the Document Upload Tool (DUT), Secure Messaging eGain system (SM), etc. |

3. Items that you must update individually with each employee annually include, but are not limited to the list below.



1. Form 6774, Receipt of Critical Job Elements and Retention Standard

2. Form 11386, IRS Telework Agreement for Bargaining Unit (BU)



      ### Note:



      Per IRM 6.800.2.1.3.2. Manager Responsibilities, while managers must review all Telework Agreements every year, if there are no changes to the existing Telework Agreement, there is no need to take any action to have the employee update it annually.

3. Form 7995, Outside Employment or Business Activity Request

4. Form 10094, Career Learning Plan-Employee

5. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request


4. In addition, your responsibilities include the following list.



1. Developing employees

2. Addressing employee conduct issues

3. Defining goals and course of action

4. Instructing employees in the application of procedures and guidelines

5. Displaying integrity in all actions

6. Sharing expectations with new employees and reviewing those expectations annually with all employees


5. As a manager you are accountable to address performance deficiencies within your team/group. This may be accomplished through reviews, providing employee feedback, and/or by requiring your concurrence with performing specific actions.

6. You are responsible for ensuring your employees have access to the IDRS command codes necessary to perform their assigned tasks and required research. When an employee is expected to be away from their terminal for more than two weeks or longer, the employee should lock their profile to avoid being locked out by Data Security. The CC LOKME is used to lock IDRS. Please refer to IRM 10.8.34.10.2.2.4.2, Employee Self-Profile Locking (LOKME), for additional information.

7. Managers coordinate IDRS security with their assigned Unit Security Representative (USR), otherwise known by their organizational title: Data Security Analyst (DSA). See IRM 5.1.25.2.1, Managers of IDRS Users, for additional information.



### Note:



Managers are responsible for addressing the Unit Security Representatives (USR)/ Data Security Analysts (DSA) e-mails regarding IDRS related inquires within five business days.


**1.4.52.2.1** **(04-09-2025)**

#### **Acting Manager Assignments and Designations**

1. You must designate with a formal delegation an acting manager during your periods of absence.



1. Use Form 10247, Designation to Act to appoint an acting team/group manager for a period of one full day or longer. The form must identify the person appointed, the period of the appointment and a general description of the tasks the acting manager is authorized to perform.

2. For acting manager appointments of less than one business day, an email may be substituted for the Form 10247. The email must contain the same information as the Form 10247 described above. The email or Form 10247 must be distributed to the appointed employee, the other employees in the team/group, and the manager’s next level manager (DM, OM, or FCM).

3. Place a copy of the Form 10247 or email (if appropriate) in the appointed employee’s drop file.


2. Managerial tasks to be performed and those to be deferred may depend on the duration of the assignment. Refer to the National Agreement (Document 11678) for certain restrictions on performance evaluations (i.e. The employee’s performance must have been observed under a signed performance plan for at least 60 days to be ratable under Article 12.) Assignments should be agreed on between you and the acting manager in advance. Specific expectations should be given at the beginning of each assignment. This will form the basis for your feedback on performance of the acting assignment.

3. For a delegated acting manager, utilize discretion to determine whether inventory level needs to be adjusted for the actor. Discuss any cases which may need to be re-assigned during the designation period to ensure timely actions are taken on cases which involve issues that could cause permanent loss to the government. Factors to consider are:



1. length of acting assignment and

2. duties to be performed during this assignment.


4. Do not designate an acting manager if you are not absent. You may choose to designate specific tasks for employee developmental purposes to those employees aspiring to the next level to gain useful managerial experience. In this situation, no acting assignment or delegation exists; therefore you may not designate tasks reserved to managers, (i.e., case related managerial approvals, callbacks requested by the taxpayer that involve a CAP appeal, leave approval for group members, and travel approval).


**1.4.52.3** **(04-09-2025)**

### Security Access Validation Frequency

1. Managers are responsible for ensuring that required security duties, including reviews, are completed in a timely manner.

2. Service officials and managers must communicate security standards including those in IRM 10.8.1, Policy and Guidance, to subordinate employees and establish methods to enforce them. Employees are responsible for taking required precautions in providing security for the documents, information and property that they handle in performing official duties.

3. An annual review must be conducted to certify that employees have the appropriate level of access to each application used. Submit an online Business Entitlement Access Request System (BEARS) request to delete access to any application that is no longer required for the performance of an employee’s duties.



### Note:



Remember to submit a request 30 days before employee separation to delete an employee’s electronic fax number. In addition, you should forward the employee’s electronic fax number to your email until the number is deleted.


**1.4.52.3.1** **(04-09-2025)**

#### Compliance Data Warehouse Knowledge Graph Environment (CKGE) Monitoring

1. Compliance Data Warehouse Knowledge Graph Environment (CKGE) is an interactive software tool that provides linked data and graph analytics for a range of a taxpayer’s related entities. CKGE was developed by Research, Applied Analytics & Statistics (RAAS) and is a graph database. CKGE performs data analytics from information in the Compliance Data Warehouse (CDW) and provides a graphic representation of a taxpayer’s relationship to other entities.

2. CKGE research user audit logs are systemically shared with Cyber IT and are analyzed for potential UNAX violations. In addition to this capability, RAAS developed the CKGE Manager Audit Module (CMAM) for additional management controls of the use of CKGE.

3. Managers will automatically gain access to CMAM when an employee granted CKGE access is aligned to them in the Discovery Directory. Managers will only have access to the CKGE research conducted by employees aligned to them on the Discovery Directory.

4. Managers must complete one review of each employee (verifying the initial search term is associated with an account currently or previously assigned to the employee) with CKGE access using CMAM during the employee’s rating period.

5. Take the following steps to perform your review:



1. Log into CKGE and select “CKGE Manager Audit Module (CMAM).” Click the “Go to Activity Viewer” button on the CMAM landing page.

2. Select an employee from the “User” list at the upper left side of the response screen.

3. If the employee did not conduct CKGE research during the rating period, the review is complete by documenting the review record that no research was conducted by the employee. If the employee did perform CKGE research during the review period, select a search session made by the employee starting with the initial query located in the “Searched using term” box.

4. The item in the “Searched using term” is usually the tax identification number of the taxpayer assigned to the employee. In some instances, the search term may be another available data point associated with the taxpayer. Further, the search term may be an entity or individual related to the assigned taxpayer account.

5. Confirm the initial search term is associated with an account currently or previously assigned to the employee. If the search term is for an individual or entity related to the assigned account, confirm whether the employee documented the nexus between the assigned account and search term. Confirm whether the expanded nodes related to the initial search term are related to the case currently or previously assigned to the employee.

6. If the employee’s research indicates inspection of return information not related to the assigned investigation, see IRM 10.5.5.3.2, Privacy and Information Protection - IRS Unauthorized Access, Manager UNAX Responsibilities, for guidance on suspected UNAX violations.

7. Document your review and place in the appropriate Employee's Performance File (EPF).


**1.4.52.3.2** **(04-09-2025)**

#### Bank Secrecy Act Portal Query Monitoring

1. The Bank Secrecy Act (BSA) Portal provides authorized users access to BSA data via the BSA Search application. In addition, the portal offers users secure mail, reports (containing 31 U.S.C. Title 31 financial taxpayer information), a knowledge library, training and help resources, critical announcements, statistics and information, helpful links, and news.



### Note:



In June 2024 Financial Crimes Enforcement Network (FinCEN) Query System was changed to the Bank Secrecy Act Portal.

2. Verify employees requests are for active and assigned cases before approving.



### Note:



Managers of employees who make these requests must certify annually that the requests were for assigned active case investigations.


**1.4.52.4** **(04-09-2025)**

### Communication of Expectations

1. When a new team/group is established or you as a new manager are assigned to an existing team/group, a meeting with the employees must be held within the first 30 days. At this meeting communicate expectations about the following suggested topics below.




| **Expectations Topics** |
| :-: |
| Case work |
| Case review schedule |
| Maintain and supply upon request a calendar of scheduled work |
| Reasonable timeframes for case actions |
| Responsiveness to taxpayer or representative inquiries |
| Returning calls, updating voicemail and out of office messages |
| Safety and security |
| Team/group procedures |
| Timeliness of case activity |
| Time frames for case actions |
| Use of time in the office and telework |

2. Also review these expectations at the beginning of each fiscal year.

3. When a new employee is assigned to an existing team/group, you must meet with them to discuss managerial expectations and ensure the appropriate BEARS requests are completed and processed.



### Note:



These meetings are considered 7114 meetings, and the local National Treasury Employees Union (NTEU) chapter(s) must be notified of the meeting in accordance with Article 8, Union Rights, of the National Agreement (IRS/NTEU National Agreement.).

4. Hold regular team/group meetings as necessary to review and discuss items such as the listing below.




| **Team/Group Meeting Items** |
| :-: |
| Directives from Headquarters, director SCOIC (Director), and/or the program manager (PM)/ FCM, and OM |
| Procedural memoranda |
| Changes to the IRM |
| Changes in condition of employment |
| Automation issues |
| Mandated topics (e.g., Ethics, etc.) |
| Annual IRS Employee Survey results |
| IRS employee engagement issues and general team/group concerns |
| Complex cases to brainstorm ideas to assist in taking appropriate closing actions |
| Case resolution techniques in order to share best practices |
| Collection Policy Technical topics and Quarterly Conference Call Minutes |





### Note:



Some of these meetings are considered 7114 meetings (e.g., changes in condition of employment and certain mandated topics) and the local National Treasury Employees Union (NTEU) chapter(s) must be notified of the meeting in accordance with Article 8, _Union Rights_, of the National Agreement. For a regularly scheduled meeting the notification and agenda will be provided no less than five workdays in advance. Seek guidance and advice from your servicing Labor Relations Section if you are unsure whether an agenda item for a team/group meeting constitutes a 7114 issue. Article 8 Section 1 of the National Agreement also provides guidance on 7114 Meetings.


**1.4.52.5** **(11-17-2021)**

### Time Reporting in the Offer in Compromise Program

1. In accordance with IRS policy found in IRM 6.630.1.1.2, Administration of the Federal Leave System – Manager Responsibilities, as a manager you have a fundamental responsibility to verify the individual Time Entry record in SETR for each of your employees prior to certifying (signing off) the accuracy of the information in SETR at the end of the pay period. Ensure direct and indirect time is reported using the appropriate time, function and program codes \[Organization, Function and Program Code (OFP)\] and discrepancies are addressed as needed.

2. Conduct leave audits on an as needed basis.



### Note:



Employees and managers have the capability of generating Employee Work/Leave Audit reports from SETR, using an option under the Standard Reports menu. This report shows all hours an employee has either worked or taken as leave for the past 25 pay periods and may be extremely helpful when performing leave audits.

3. Be alert for reporting that could be considered excessive administrative or miscellaneous direct time.


**1.4.52.5.1** **(10-16-2023)**

#### Time Reporting for COIC

1. Utilize SETR bi-weekly to ensure accurate time reporting. Address discrepancies as needed.


**1.4.52.5.1.1** **(10-16-2023)**

##### Clerical Time Reporting in the COIC Program

1. OFP time code 790–0000X covers time spent by clerical employees related to time spent in support of COIC including, but not limited to the following below.



   - Maintaining filing systems

   - Filing documents or cases

   - Processing closed files

   - Inputting hardcopy or electronic information

   - Processing and routing mail

   - Conducting research

   - Processing remittances


**1.4.52.5.1.2** **(03-22-2019)**

##### Process Examiner Time Reporting in the COIC Program

1. OFP time code 700-60000 covers all actions related to the time spent by PEs on telephone contact, including requests received on Form 4442.

2. OFP time code 810–6603X covers all actions related to the time spent by PEs working on a newly receipted Form 656, Offer in Compromise. This includes the following below.



   - Loading offers to AOIC

   - Researching to make a processability determination

   - Processing application fees and deposits


3. OFP time code 810–66025 covers all actions related to the time spent by PEs correcting input problems that have generated on the IDRS transaction error listings.

4. OFP time code 810–6602X covers the following below.



   - Case building for additional financial documentation

   - Generating the appropriate correspondence

   - Reviewing the taxpayer's response to the request for additional financial verification

   - Alternative Resolutions

   - Liens and credit transfers


5. OFP time code 810-66040 covers all actions related to the time spent by PEs processing subsequent payments.


**1.4.52.5.1.3** **(04-09-2025)**

##### Tax Examiner Time Reporting in the COIC Program

1. OFP time code 810–61970 covers most actions related to the time spent by the TEs in the DATL COIC program.


**1.4.52.5.1.4** **(11-17-2021)**

##### Offer Examiner Time Reporting in the COIC Program

1. OFP time code 810–6601X covers all actions related to the time spent by OEs working on an assigned OIC submitted on Form 656, Offer in Compromise. This list includes, but is not limited to the following below.



   - Receiving and analyzing the Form 656, Offer in Compromise and all required documentation

   - Determining Reasonable Collection Potential (RCP)

   - Making disposition recommendations and reviewing requests for Appeal consideration

   - Working CDP offers

   - Working modification of an accepted compromise


**1.4.52.5.2** **(04-09-2025)**

#### Time Reporting for FOIC

1. You are responsible for reviewing time reported by your employees to ensure accuracy. Using ICS and ENTITY, verify time prior to End of Month (EOM) processing (i.e., no later than COB on the last Friday of the monthly reporting period). Updates/corrections to End of Day (EOD) data occur overnight. Thus, if all EOD activity is not completed and verified by the Friday prior to EOM, delays in processing EOM reports will result. Exhibit 10 in IRM 5.2.1, Collection Time Reporting, provides information about the last Friday of each reporting period and number of expected hours in each period. Consider the following:



1. You can use ENTITY to verify the accuracy of time charges. There is a “View” titled “Weekly Time Verification” and a “Report” titled “Hours Verification Report,” both can be used to validate time. For more information go to the ENTITY website and IRM 5.2.1, Collection Time Reporting.

2. Be alert for, and address as appropriate, issues such as potentially excessive administrative or non-direct time, discrepancies related to credit/ comp/ holiday/ training time, etc.

3. Ensure that the group secretary/management assistant or designee performs weekly time verification and checks for daily EOD for all employees.

4. Monitor case sub codes and consider requesting that employees validate sub codes monthly to avoid inaccurate time reporting. See IRM 5.3.1.3.2, ICS / ENTITY Case Codes, Subcodes and Collection Time Reporting System (CTRS).

5. Refer to IRM 5.2.1.4.1, Field Collection and Field OIC Specialist Responsibilities, for specific information about GM responsibilities related to time reporting.


**1.4.52.5.2.1** **(04-09-2025)**

##### Time Reporting for Offer Specialists

1. Review employee ENTITY Time Reports monthly to:



   - Monitor the accuracy of reporting direct time on case assignments.

   - Monitor the percentage of direct time to ensure the OS is not working over 25 percent direct time above grade.

   - Make sure the proper amount of administrative time and other non-direct case time is accurately reported.


2. You are responsible for reviewing proper time reporting by your employees. Using ENTITY, you should be alert for reporting excessive administrative or non-direct case time which is reported under **ICS Code 106.**

3. Non-direct case time is work consisting of less than 15 minutes on an individual case including time spent discussing cases during the case review discussions.

4. OS report non-case direct time under _**ICS Code 106**_. Time Code 106 has Non-Case Direct and Direct-Case time designations which are captured and reported separately on ENTITY.



### Caution:



OS must not charge any of their time to _**ICS Code 809**_ because time reported to Code 809 rolls into 101 TDA Direct and 201 TDI Direct time.

5. Direct case time (106) covers all actions relating to the time spent working an assigned OIC submitted on Form 656. This includes receiving and analyzing the form, all required documentation, conducting required interviews, determining reasonable collection potential, making disposition recommendations, reviewing requests for Appeal consideration, time spent of more than 15 minutes discussing a case during inventory management reviews, etc.

6. OS must report any time worked on offers with an open CDP to **ICS Code 120**.

7. The OS must report any clerical or administrative duties such as mailing or scanning cases not as case time but under **_ICS Code 611_**.


**1.4.52.5.2.2** **(04-09-2025)**

##### Time Reporting for Paraprofessionals (FOIC Tax Examiners)

1. OIC support work that is performed by paraprofessionals (TEs, etc.) must be reported under **_ICS Code 106 — Non-Case Direct_**.


**1.4.52.5.2.3** **(04-09-2025)**

##### Time Reporting for Clerical (FOIC Secretaries/Management Assistants)

1. Clerical personnel in the FOIC program (e.g., secretaries/management assistants) must report their case related work under**_ICS Codes 502, 504, and 505_**. Listed below is an explanation of these codes.

2. _502 Analysis/Perfection_ — Time spent by FOIC clerical employees in performance of their duties including, but not limited to, the following below.



   - Analyzing and perfecting of input documents, excluding payment input documents

   - Coding and editing of adjustment documents, such as Form 3870, Request for Adjustment, etc.

   - Performing research necessary to complete payment and credit transfer requests

   - Reviewing and perfecting information or certified transcript requests and performing all necessary follow-up actions

   - Performing miscellaneous duties as assigned


### Note:

Refer to IRM 1.4.52.10, Tax Examiners in the OIC Program and IRM 1.4.52.11, Group Secretaries in the OIC Program, for a full description of support duties within the OIC program.

3. _504 Clerical_ – Time spent by clerical employees maintaining filing systems (hardcopy files and/or electronic files), filing other documents, inputting accession numbers on Automated OIC (AOIC) on cases forwarded to FRC, and processing closed file requests.

4. _505 Clerical_ – Time spent by clerical employees in support of all Collection programs including, but not limited to, the following below.



   - Preparing/printing letters, forms, etc.

   - Processing and routing mail

   - Conducting research to assist OS' with assigned cases, other than payment/credit transfer research

   - Processing Form 795, Daily Report of Collection Activity, without returns and/or remittances, including such items as: (1) reviewing documents for accuracy and completeness; and returning incomplete or inaccurate documents to the initiator; (2) routing documents to the appropriate function; (3) determining the appropriate assignment number; (4) preparing sample selection for post reviews; (5) performing miscellaneous duties, as assigned.


**1.4.52.5.3** **(04-09-2025)**

#### Time Reporting for Monitoring Offer in Compromise

1. Utilize SETR bi-weekly to ensure accurate time reporting. Discrepancies should be addressed, as needed. Time reporting should be recorded in accordance with the appropriate OFP time codes. For a list of MOIC TE time codes see the table below. This list is not all inclusive.




| **OFP Code** | **Action Performed** |
| :-: | :-: |
| 61900 | Perfection |
| 61910 | Monitoring |
| 61920 | Potential Default |
| 61930 | Phone Calls |
| 61940 | Correspondence |
| 61950 | 4710 Deposit Actions |
| 61960 | Closed Case Actions |


**1.4.52.6** **(11-17-2021)**

### Workload Management

1. You are responsible for effectively managing the team’s/group’s workload. To accomplish this:



   - Ensure hold files are held to a minimum or eliminated by making assignments to active inventory as expeditiously as possible.



     ### Note:



     Alert the OM/FCM to situations where inventory backlogs may delay timely assignment of cases.

   - Ensure cases are assigned promptly.

   - Maintain appropriate inventory levels at appropriate grade levels and make adjustments as necessary.

   - Ensure case activity is progressing toward resolution by (1) timely conducting the required Embedded Quality Review System (EQRS) case reviews and required reviews along with any other reviews deemed appropriate, (2) monitoring group controls, and (3) monitoring inventory and having ongoing dialogue with each employee to adequately assess the individual progress of each case assignment.

   - Ensure that the cases submitted for approval have been assigned to the AOIC GM approval assignment number by the OE/OS.


**1.4.52.6.1** **(10-16-2023)**

#### Use of Suspense/Hold Files in COIC

1. Cases suspended in a 51xx file awaiting taxpayer response should remain there no longer than 60 days.

2. Cases in the COIC OE hold files, 60xx, should only be used as a temporary control point for new assignments. OIC cases should not remain in these files for more than 90 days prior to assignment to an OE.

3. Cases should be assigned from the hold file to an OE based on first-in- first-out (FIFO) by IRS received date. The exception is if the case qualifies for emergency processing and is approved by the manager.



### Note:



Inventory should be monitored for any anomalies regarding case assignment time frames.

4. Monitor hold files on a weekly basis to ensure these expectations are met and OIC cases are routinely assigned for investigation without delay.

5. Close rejected offers pending in the 45-day hold file immediately after the 45th day if no timely appeal is received. Unless there are unusual circumstances, rejected offers appealed by the taxpayer should be processed and forwarded to Appeals within 30 days of receipt.


**1.4.52.6.2** **(10-16-2023)**

#### FOIC Case Grading

1. You are responsible for reviewing all case receipts and ensuring each assignment has been correctly graded prior to assignment to an OS. Case grading should be based on the criteria defined in the employee’s current Position Description (PD) for the GS-1169-12 (PD 97019) and GS-1169-11 (PD 97018), Offer in Compromise Specialist, which specifies that Grade 11 OSs are generally assigned OIC cases that involve moderate issues, and Grade 12 OSs generally are assigned inventory that involve more complex issues.

2. Because OICs assigned to the OS generally contain financial statements submitted by taxpayers, as well as information obtained by the COIC sites through internal case-building, you should also take into consideration additional issues when determining the initial case grade of a new assignment. Generally, the below issues/processes could warrant a GS-12 designation.




| **Grade 12 Case Factors** |
| :-: |
| Liabilities that cover a diversified spectrum of individual and business taxpayers (e.g. multiple and/or consecutive years of non-compliance requiring more analysis and evaluation to ascertain issues such as commingling of assets, income, expenses, etc.). |
| Entity consists of complex trusts, large municipalities, and/or educational institutions all of which require more specialized knowledge of tax laws. |
| Valuation of on-going businesses; income determination when excessive accumulation of retained earnings is identified; closely held entities; consideration whether compromise would impact overall compliance; public policy impact if collection were to be pursued; and the related valuation in making a final compromise decision. |
| Presence of transferees, nominees, and/or alter egos requiring identification, research and valuation in making a final compromise decision. |
| Presence of complex accounting practices, tax law, or investigative issues of more than usual difficulty or complexity. |
| OICs filed by individuals and business taxpayers (e.g. partnerships, corporations) involved in complex activities or transactions designed or structured to hide or conceal income requiring a thorough knowledge of the different fraud indicators, as well as working knowledge on a wide range of financial and investigative skills, such as offshore activities; multiple related entities. |
| Involvement of numerous creditors requiring a working knowledge of lien law in order to determine appropriate lien priority. |
| Need for comprehensive reviews to determine that other required returns such as individual income tax, excise, or specialty returns are filed, and an analysis of these returns is required to identify omitted assets, and/or improper transfers. |
| Case complexity requires the involvement of specialists such as Examination, Office of Professional Responsibility, Evaluation Engineers, Criminal Investigation, Counsel, Fraud Enforcement Advisor (FEA), and/or Field Compliance. |
| Comprehensive and complex financial statements requiring knowledge of accounting and business principles. |
| Need to gather, research, inspect, and validate data from a variety of sources including internal sources and personal contacts. The data may, in some instances, be unique to a particular trade or industry. |
| Potential for media scrutiny due to the type of taxpayer. |
| Non-economic hardship-effective tax administration (NEH-ETA) issues in accordance with IRM 5.8.11.3.2. |
| Cases involved in the Offshore Voluntary Disclosure Program (OVDP). |
| Cases involving international assets. |
| Presence of significant digital assets in financial statements, bank records, and/or business reports that require involvement of specialists like Collection Digital Asset SMEs and/or Office of Fraud Enforcement. |

3. Case grade levels can be increased or decreased at any time. The case grade must be changed if receipt of additional information or case circumstances warrant the change. Case grades must be verified and changed on ICS. Encourage OSs to bring any issues to your attention. If you decide a case should be downgraded, notate the reasons in the case history. You must also notify the OS via e-mail of the reasons for downgrading the case. If the OS disagrees, the employee and/or the Union may file a written challenge to the decision. See the Article 25 Section 1 A of the National Agreement.

4. Consider a reassignment of the case if a grade level change is made.


**1.4.52.6.3** **(04-09-2025)**

#### Assigning Work

1. Assignment of work must align with Policy Statement 1-236, Fairness and Integrity in Enforcement Selection. Adherence to the principles in this policy statement ensures the IRS is meeting its commitment in the IRS Mission Statement by **enforcing the tax law with integrity and fairness to all.** An important component of fairness and integrity in enforcement selection includes the assignment of work by the team/group manager. The purpose of this subsection is to provide a framework for the assignment of work to ensure case assignments are consistent with the goals and objectives of the IRS and are free from personal bias.

2. Assign inventory in the following order below.



1. Offers with less than six months remaining on the TIPRA statute

2. Offers expedited per IRM 5.8.4.27, Expedite Handling

3. Form 2209, Courtesy Investigation- Modification of an accepted compromise investigations for assignment. All cases in the team/group manager’s hold file are displayed on AOIC. Form 2209s will be on ICS only and not AOIC in FOIC. Be mindful of the actual number of cases in the OS inventory.

4. The Form 2209 ARI requests from Appeals



      ### Note:



      If possible, close ARIs within 45 days of receipt.

5. Assign cases not meeting the criteria defined in a-d above on a FIFO basis as determined by the IRS received date.



      ### Note:



      Assign related taxpayer entities to the same OE/OS as appropriate.


3. Do not assign new cases to employees on weekends, holidays, or when an employee is on extended leave.



### Note:



Repeatedly assigning cases when employees are on extended leave may put the IRS in jeopardy of litigation.

4. Assign inventory to employees regularly based on the workload as scheduled on their calendars, the AOIC Follow-Up screen/ICS Notifications and as cases are closed.

5. Per Article 16 of the National Agreement, an employee may spend up to 25 percent of their direct time during any four-month period working higher graded cases for developmental purposes.

6. If you allow the employee to work higher graded cases it is essential that you track the percentage of direct time spent on higher graded work to ensure the 25 percent threshold is not exceeded. Employees who exceed the 25 percent level for any four-month period may be entitled to a temporary promotion.


**1.4.52.6.3.1** **(03-22-2019)**

##### Assigning Work for Offer Examiners

1. Assignments must be made on the AOIC system.

2. Utilize weekly reviews of AOIC Inventory Listings, Follow-up Listings, etc. to determine the appropriate work assignment.

3. Assign inventory to employees regularly based on the workload as scheduled on their calendars, the AOIC Follow-Up screen, and as cases are closed.


**1.4.52.6.3.2** **(11-17-2021)**

##### Assigning Work for Offer Specialists

1. You are responsible for ensuring cases are assigned at the proper grade based on the criteria outlined in _IRM 1.4.52.6.2_ and must be made on both the AOIC and ICS systems.

2. Utilize weekly reviews of AOIC/ICS Inventory Listings to determine the appropriate work assignment.

3. Assign inventory to employees regularly based on the workload as scheduled on their calendars, ICS Notifications, and as cases are closed.

4. Perform monthly reviews of ENTITY reports to make sure employees are not working over 25 percent of direct time on cases above their grade level. This can be accomplished by reviewing the hours on the **Time on Above Graded Cases** report. You must also look at the percent of direct time on each employee's summary screen. To view this screen, select the employee's record from the **Employment Management** option in the ENTITY Main Menu. You may elect to let the employee retain higher grade cases in inventory when the below issues are present.



   - There would be an unacceptable delay in working the case if it was reassigned.

   - There is a need to maintain continuity of contact with the taxpayer.

   - The OS needs or requests a higher-level case for developmental purposes.


**1.4.52.6.3.3** **(04-09-2025)**

##### Assigning Work for MOIC Tax Examiners

1. Assignments must be made on the AOIC system.

2. Utilize weekly reviews of AOIC Listings, Follow-up Listings, BOE, and RPA Listings etc. to determine the appropriate work assignment.

3. Assign inventory to employees regularly based on the workload as scheduled on their calendars, the AOIC Follow-Up screen, and as cases are closed.


**1.4.52.6.4** **(04-09-2025)**

#### COIC Responsibility for Cases Transferred to FOIC

1. Managers are responsible for reviewing cases prior to transfer to FOIC to ensure transfer criteria is met. Ensure the appropriate transfer letter is completed and the AOIC follow-up date reflects the date of the letter.

2. Offers that are transferred to FOIC contain financial statement documents submitted by taxpayers, as well as information obtained through internal case building. Team managers should ensure all internal case building documents have been included prior to transfer.

3. Managers should ensure cases are transferred timely. Cases should be sent no longer than three days after transfer on AOIC.

4. Managers must ensure related offers received from FOIC and Appeals are loaded to AOIC. If the original offer was worked in FOIC, the related offer will be transferred on AOIC to the AO where the original offer was worked. An e-mail must be sent to the FOIC group manager so they can accept the transfer and assign the case for action. If the offer was received from Appeals an e-mail must also be sent to the Appeals Officer with the offer number, and the related offer must be returned directly to the Appeals Officer.

5. The COIC employee's responsibilities will consist of the following:



1. Review all transfer forms to ensure transfer is appropriate.

2. If electronic transfer on AOIC is incorrect, accept transfers back on the AOIC system and re-transfer to the correct area.

3. Interact with FOIC site personnel to check on the status of transfers, as needed.

4. Follow-up on Form 3210, Document Transmittal, to ensure transfers were received and acknowledged.

5. Refer to **Document 12990**, IRS Records Control Schedules (RCS) 28, Item 26 for the National Archives and Records Administration (NARA) approved Form 3210, Document Transmittal retention and disposition requirement.


6. DATL COIC employees should follow IRM 5.19.24.12, Offer Assigned to Specialty Groups.


**1.4.52.6.5** **(04-09-2025)**

#### Closing and Review Actions

1. Managers are responsible for all cases in their team’s/group’s control. Careful review of cases should occur in order to provide a quality product and excellent taxpayer customer service. The following list, although not all-inclusive, are tasks to perform to ensure a quality product prior to taking closing actions.



1. Ensure CSEDs are addressed and are correct.

2. Ensure accepted terms do not extend beyond the CSED by verifying the accuracy of the CSED.



      ### Note:



      Actions to verify the accuracy of the CSED may include review of IDRS, AOIC, and ICS. Case histories may provide additional explanation when the CSED calculation is complex. See IRM 5.1.19.1.1 for more information about what to be aware of when reviewing the CSED.

3. Ensure all necessary closing AOIC letters and forms are sent to taxpayer/practitioner.

4. Ensure a condition is not present (such as Department of Justice module, bankruptcy, etc.) which would preclude acceptance of the offer. The OIC IAT tool may be utilized for this verification.

5. Ensure all taxpayer/practitioner inquiries that might be generated as a result of OIC correspondence are addressed.

6. Ensure (COIC and FOIC) on acceptances and rejections that the appropriate verification of the RCP is present (such as bank statement evaluation, internal and external research etc.)

7. Ensure a telephone call is made if a request to speak to a manager is made by the taxpayer/practitioner.



      ### Note:



      All requests for manager callbacks should be completed within two business days. Details of the conversation must be annotated in the case history on ICS/AOIC.

8. Close accounts on AOIC. Ensure all necessary electronic approval systems are updated with the case.


**1.4.52.6.5.1** **(10-16-2023)**

##### COIC and Field Closing and Review Actions

1. When work is submitted to you for approval, you have an opportunity to evaluate your employees’ performance and prevent deficiencies. The quality of the work that leaves your group is a reflection on you as a group manager.



### Note:



For COIC managers, tasks may be assigned to specific managers at local discretion.

2. The following list, although not all-inclusive, are tasks to perform to ensure a quality product prior to taking closing actions. Always refer to the specific topical IRM section if you have questions.




| **Managerial Review Items** |
| :-: |
| Managers are to review all acceptance, rejection, appropriate return, transfer and withdrawal case files to ensure all letters/forms are correct and have appropriate signatures and appropriate codes i.e. final disposition codes, and offer case codes. |
| Ensure the Notice of Federal Tax Lien (NFTL) is filed as appropriate.<br> <br>### Note:<br>COIC managers will review and forward the (NFTL) for processing. |
| On rejection recommendations, review case files prior to assigning to Independent Administrative Reviewer (IAR) inventory. Monitor to ensure IAR returns the case. |
| For acceptance recommendations requiring review by Counsel, the manager must review the case for appropriateness and completeness prior to assigning to Counsel. |
| Review taxpayer/practitioner's written request for appeal. Upon timely request, forward case to Appeals for review. Reassign case to Appeals systemically on AOIC |
| When it is determined a CDP offer should be rejected, ensure the offer type is updated to "Collection Due Process" which will generate offer type "P" . |
| Input appropriate disposition code on AOIC. |
| If clerical staff is available, verify clerical staff closes applicable offers on AOIC as TP "did not exercise appeal rights" , when applicable. |
| Upon receipt of case from Appeals, review case file to ensure all necessary documentation, closing reports, and correspondence is contained in the case file. |
| Monitor the rejection 45-day hold file and cases sent to Counsel for review. |
| Monitor AOIC Quality Review Listing on a weekly basis. |
| Prepare closed case files per established guidelines and transmit selected offer cases for Quality review or retention files. |
| Based on established procedures, initiate AOIC Closed Case Validation Process. This might be delegated to one manager to perform for the Operation. |
| Send closed accepted offers to MOIC at the Memphis site or Brookhaven site, as appropriate. |
| According to procedure, timely ship/send closed cases to Federal Records Center. |
| Ensure the case is routed for mirroring, when appropriate. |
| Ensure employees identify and address active levies; levies are released with acceptances. |


**1.4.52.6.5.2** **(04-09-2025)**

##### MOIC Closing and Review Actions

1. Managers are responsible for cases in their team’s control.

2. Refunds have been recouped on OICs accepted prior to November 1, 2021, when appropriate.

3. Appropriate mirroring has been completed.

4. Terms of any collateral agreements have been met.

5. NFTLs have been released as appropriate.

6. Ensure when the OIC payment terms are complete and applicable collateral terms are fulfilled the case is transferred to the compliance monitoring status. See IRM 5.19.7.13.1, Compliance Monitoring Status, for additional information.

7. Ensure offers are closed out of MOIC inventory timely, this includes offers being defaulted and when a taxpayer fulfills all terms of their offer.


**1.4.52.6.6** **(10-16-2023)**

#### Maintaining Employee Inventory Levels and New Case Hold Files

1. OIC is a high-profile program in which the timeliness of case processing and resolution have a significant impact on the overall program, including significant impact to customer service.

2. It is your responsibility to make sure all cases are assigned upon receipt, or as soon as reasonably possible. Do not assign new cases to employees on weekends, holidays, or when an employee is on extended leave.


**1.4.52.6.6.1** **(04-09-2025)**

##### Maintaining Employee Inventory Levels and New Case Hold Files for Offer Examiners

1. Barring unforeseen circumstances, such as significant reductions in workforce, realignment of groups/territories, etc., cases should not remain in a hold file for more than 60 to 90 days prior to assignment.

2. If the case remains in the hold file and is not assigned by the expiration date of the interim letter it is your responsibility to ensure the appropriate letter is sent advising the taxpayer of the status of the offer. This can be accomplished by establishing a follow-up date on AOIC for an interim letter. An automated process has been established for mailing the letters.



### Note:



The automated process only works for cases assigned to a hold file. It does not work for cases assigned to an employee. As such, if the interim contact date expires before contact is made with the employee, then the contact time frame will be considered as not met.

3. Target levels have not been determined for the inventories of cases assigned to OEs. Monitor OE inventory levels at a minimum, on a weekly basis and ensure OE inventories are maintained at levels that ensure timely contact and efficient casework, while maintaining high levels of quality and customer service in the work performed by these employees.

4. If adjustments to inventory levels must be made base it on an evaluation of time spent on activities other than on assigned work (direct case time) and normal overhead. Examples of situations where you may consider an adjustment are collateral assignments (e.g., NTEU Representative, EEO Counselor/Investigator, details out of office, coaching, etc.). Inventory levels may be re-adjusted as warranted.


**1.4.52.6.6.2** **(10-16-2023)**

##### Maintaining Employee Inventory Levels and New Case Hold Files for Offer Specialists

1. If the case was in the FOIC hold file (located at BCOIC or MCOIC) and was not assigned to FOIC within 90 days it is your responsibility to ensure the appropriate letter is sent advising the taxpayer of the status of the offer. This can be accomplished by establishing a follow-up date on AOIC for an interim letter.

2. Monitor OS inventory levels at a minimum, on a weekly basis to make sure they are maintained within the levels defined in IRM 1.4.50.10.2, Maintaining Targeted Inventories.

3. If adjustments to inventory levels must be made it should be based on an evaluation of time spent on activities other than on assigned work (direct case time) and normal overhead. Examples of situations where you may consider an adjustment are collateral assignments (e.g., NTEU Representative, EEO Counselor/Investigator, details out of office, coaching, etc.). Inventory levels may be re-adjusted as warranted.

4. FOIC should not use hold files as a method of controlling inventory levels. They are only to be used as a central control point for new assignments. To ensure customer casework is addressed by FIFO you must ensure that OIC receipts and aged cases are evenly distributed to minimize the length of time cases are maintained in the hold files.


**1.4.52.6.7** **(10-16-2023)**

#### Timeliness of Case Actions

1. The timeliness of case actions in an OIC investigation is important not only to ensure the efficiency of the process but also is a key component of taxpayer satisfaction.

2. The guidelines for timely case actions defined in IRM 5.8 (COIC and FOIC), IRM 5.19.7 (MOIC), and IRM 5.19.24 (DATL) are intended to provide structure for the overall OIC process and to ensure investigations and monitoring are completed in a responsive and efficient manner.

3. Managers and employees must make sure communications from taxpayers are addressed in a timely manner. Timeliness of case actions ensures the length of the offer investigation process is appropriate given the taxpayer's specific set of facts and circumstances.

4. These guidelines are not intended as absolute measures of performance for individual employees. Performance evaluations of an individual employee must be based on reviews of actual work produced by the employee and must take into account any special circumstances that may have impacted the ability of the employee to meet the specified guidelines.

5. In general, unwarranted activity gaps in an OIC investigation and monitoring of accepted OICs should be avoided and offer managers should establish controls to ensure that cases with unwarranted inactivity gaps are identified and addressed appropriately.

6. When necessary, based on case reviews, other forms of review, observation, etc., you have the authority to require your employee to obtain your approval before taking subsequent case actions.



### Example:



Employees who inappropriately extend deadlines or delay case actions can be required to obtain your approval of their extensions in the future so as not to delay timely case.


**1.4.52.6.8** **(03-22-2019)**

#### Workload Management

1. You, as a manager, are responsible for effectively managing the employee’s workload in order to encourage positive workflow and case movement.


**1.4.52.6.8.1** **(10-16-2023)**

##### Workload Management for COIC

1. To effectively monitor your group’s workload, perform the following activities:



1. Ensure cases and Appeals Referral Investigations (ARI)s are assigned promptly.

2. Maintain appropriate inventory levels and make adjustments as necessary.

3. Ensure case activity is progressing toward resolution by timely conducting required case reviews, monitoring group controls, as well as having ongoing dialogue with each employee to adequately assess the individual progress of each case assignment.

4. Ensure suspense files are monitored for timely actions with no unwarranted inactivity gaps to ensure casework progression moves expeditiously. Alert upper management to situations where inventory backlogs may delay the timely assignment of, or progression of cases.


2. AOIC is the Management Information System for COIC managers. Managers should be proficient with the AOIC system since it is the official system of records for COIC's offer program.

3. The AOIC system performs the functions below.



1. Produces taxpayer letters/forms

2. Provides inventory control

3. Uploads/downloads transactions to/from IDRS

4. Produces numerous management reports

5. Records and tracks taxpayer payments (Application Fee, Deposits, payments on accepted offers, recoupments)

6. Allows for automated monitoring of the taxpayer's offer status


4. Team managers will use the AOIC system to perform the following below.




| **AOIC Items** |
| :-: |
| Assign work. |
| Monitor inventory. |
| Conduct case reviews. |
| Assist employees in managing their inventories. |
| Identify cases or types of cases where it appears the employee needs assistance. |
| Determine the age of inventory assigned to Examiners, Counsel, Appeals, and other inventories. |
| Examine historical inventory levels to support a request for additional staffing or grade structure change. (OM) |
| Quickly identify inventory levels for any assignment number. |
| Conduct on-line case reviews. |
| Generate IDRS transaction listings to correct input problems. |
| Monitor aging on open assigned and Rejected with Appeal Rights cases. |
| Manage address and signature information for correspondence.<br> <br>### Note:<br>You must contact OIC Collection Policy before creating or reassigning an AOIC number. |


**1.4.52.6.8.2** **(04-09-2025)**

##### Workload Management Using Integrated Collection System, ENTITY and AOIC for FOIC

1. ICS and AOIC are the primary Management Information Systems. Managers must become very familiar with IRM 5.3.1, ENTITY Case Management System (ENTITY) as well as be proficient with the AOIC system and all available reports.

2. ICS contains time and activity information and must be used to track time and record case history entries.



### Note:



The ENTITY User Guide is available at :ENTITY Case Management System .

3. All OIC casework, as well as the management of inventory, must be completed through AOIC _and_ ICS.

4. The AOIC application is the official system of records for the OIC program and must be used to complete the following tasks.




| **AOIC Items** |
| :-: |
| Produce taxpayer correspondence and forms. |
| Provide inventory control. |
| Upload/download transactions to/from IDRS. |
| Produce numerous management reports. |
| Record and track taxpayer payments (application fee, TIPRA payments, deposits, payments on accepted OICs, and recoupments). |
| Monitor the taxpayer's OIC status. |
| Assist employees in managing their inventories. |
| Identify cases or types of cases where it appears the employee needs assistance. |
| Determine age of inventory assigned to the OS, Counsel, Appeals, and other inventories. |
| Examine historical inventory levels for any assignment number. |
| Generate IDRS transaction error listings to correct input problems. |
| Monitor aging on open assigned and Rejected with Appeal Rights cases. |
| Monitor the status of closed OICs. |
| Manage address and signature information for correspondence.<br> <br>### Note:<br>You must contact OIC Collection Policy before creating or reassigning an AOIC number. |
| Systemically download tax period information and automatically load that information to the MFT screen. |
| Input OIC closing summary history statement as required by IRM 5.8.4.12, Documentation, IRM 5.8.7, Offer in Compromise, Return, Terminate, Withdraw, and Reject Processing, and IRM 5.8.8.7, Required Actions Prior to Closing an Offer as an Acceptance. |
| Monitor taxpayer contact has been made every 90 days (in the AOIC group hold file) or 120 days (when transferred from COIC) respectively. |
| Validate and release closed offers to MOIC. |

5. Use ICS to perform the following below.



   - Confirm the correct sub-codes are in place to track time appropriately.

   - Create a CIP, OI, and monitor controls.

   - Check for timely follow-ups.

   - Review case actions.


6. Use ENTITY to perform the following below.



   - Check hours spent on a case.

   - Check the number of case touches.

   - Select random cases for review.

   - Review percentage of direct time spent on higher graded work.


**1.4.52.6.8.3** **(10-16-2023)**

##### Workload Management for MOIC

1. To effectively monitor each group's workload perform the following activities:



1. Ensure cases are assigned promptly.

2. Ensure case activity is progressing with appropriate actions in AOIC. Ensure employees are taking appropriate steps towards case resolution by timely conducting required case reviews, monitoring appropriate statuses, as well as having ongoing conversations with each employee to adequately assess the individual progress of each case assignment.

3. Ensure files and 2209s are monitored for timely actions with no unwarranted inactivity gaps to ensure casework progression moves expeditiously. See IRM 5.19.7. Other Investigation (OI) inventory must be verified for accuracy. Ensure the liaison is generating a report quarterly on Form 2209, Other Investigations, with a beginning date 90 days prior to the run date to determine overdue responses. Instruct tax examiners to follow up with the liaison to ensure COIC or FOIC OIs are being addressed and responded to appropriately.


2. Since AOIC and Business Objects are good tools to assist in managing inventory at the department and team levels, managers should be proficient in both systems. Various Business Objects reports are available for use and employees secure access through a BEARS request. Managers should be proficient with the AOIC system since it is the official system of records for MOIC's offer program.


**1.4.52.6.9** **(04-09-2025)**

#### AOIC and Business Objects Reports

1. From the Main AOIC Menu, the majority of the AOIC reports and workload management features are accessed by selecting the "Reports & Listings" under the "Reports & Correspondence" heading.

2. Typically, reports have to be (G)enerated first (one of the various commands available), then once generated they can be (V)iewed on-line and/or (P)rinted.

3. Multiple reports and listings can be (G)enerated at the same time, then (V)iewed and/or (P)rinted when ready.

4. The "Area Office Menu" under "Reports & Correspondence" contains the following reports and listings:




| **Report Name** | **Report Summary and Usage** |
| :-: | :-: |
| Inventory Listing | This report includes Offer Number, Assignment Number, Assignment Date, Name Control, Offer TIN, IRS Received Date, Processability Code, and Age Code. This report can be produced for an entire Territory, Group, or Individual Employee depending on the selection criteria used for the Assignment Number when creating the report. It can be sorted by Assignment Date, Name Control, IRS Received Date, and Total Liability. Use this to quickly check inventory levels and potential overage and overage cases within a particular inventory assignment number. |
| Inventory Management Listing | This report provides an easy to read list, by assignment number, of the total OICs assigned to a specific office, how many are processable or not, and the number of potential overage and overage cases in that inventory. This snapshot view of assigned inventory levels and overage is a useful tool for managers. For COIC cases, this may be used in conjunction with the Inventory Management Report, to assist in identifying overage and potential overage cases for review to recognize potential gaps. |
| Closed Offers | This report provides a listing by Name, IDRS and Offer TIN, AO Closed Date and Final Disposition of OICs closed for your Area/Territory, for a specified time frame, with a specified disposition, and may be sorted by name control or TIN. |
| Follow-Up Listing | AOIC allows the user to input follow-ups which are used in assisting the case worker with inventory management. This report provides a quick and complete method for tracking the follow-ups so that timely actions can be taken. When used in conjunction with the Inventory Management Report and time utilization reviews, the follow-up listings can assist in identifying gaps in case processing that lead to overage. (MOIC) ensure actions are taken within 14 days of receipt of the RPA Payment Process team run. |
| Rejected with Appeal Rights Listing | This report tracks aged cases that have been proposed for rejection and appeal rights have been exercised. The report lists the proposed rejection date, Offer Number, Age, Offer TIN, and Owner Code (AOIC assignment number). A useful tool to ensure cases in the 45-day hold file are timely closed. |
| Transfers Not Accepted Listing | This report shows cases sent from another Area/Territory that have not yet been accepted into inventory and transfers from COIC. The report includes: Sent From AO Number, Offer Number, Offer TIN, Name Control, Transfer Date, and NW Sub Code. The NW Sub Code is used by the Service Centers. Use this report to ensure that you are timely receiving and assigning work transferred into your function. Work the report on a weekly basis.<br> <br>### Note:<br>Timely and proper actions must be taken on any cases showing as transferred for 30 days or more from the date of the report run date. |
| Total Liabilities Listing | This report shows, broken out by range of the offer liability, giving case count and percentage for all processable offers received during a time frame specified by the user. |
| Assignment Records | This report shows a complete listing of an Area’s/Territory’s assignment numbers showing Assignment Number, Badge Number, Name, Phone Number, and Stop Number. |
| Transaction Listing | This report shows the error register for transactions sent from AOIC to IDRS where there was a posting error. This report identifies transactions that need correcting so that they can properly post. This report can be printed daily but minimally requires weekly reconciliation to ensure IDRS modules and respective notice/collection status codes match AOIC. |
| Area and Territory Listing | This report shows a list of the Area offices and their Territory offices by number. This report is useful in determining where an offer is assigned. |
| Case History (Remarks) | This report provides the entire case history for an OIC. This report lists the Offer Number. It can be useful when conducting reviews to ensure the appropriate actions were taken on the case. |
| 4196 Report | This report allows you to generate a summary report or a detail report. The summary report is a two page summary version of the much longer Detail 4196 Report. The report shows a brief inventory analysis for beginning inventory, receipts, dispositions (including dollar amounts), ending inventory, and age (open and disposed cases). The Detail report is the most comprehensive report produced for analysis of inventory receipt and disposition patterns. The report shows a similar inventory analysis as the 4196 Summary page (beginning inventory, receipts, dispositions \[including dollar amounts\], ending inventory, and age of open and disposed cases), but greatly expands on the level of detail provided. The Detail 4196 report additionally provides a breakout of various dollar ranges for the accepted, rejected, returned, and withdrawn closures. It also provides a detailed listing of the reasons for returns (both processable and non-processable). Age of inventory is similar to that found in the 4196 Summary Page, but includes a separate breakout for offers in Appeals. |
| Letter Signatures | This provides a complete listing (by Signature, Assignment Number, Title, and Name) of all employees assigned to an Area/Campus/Territory Office that are set up on AOIC and systemically prints their information on AOIC generated letters. Signature information can be added and deleted using the Maintenance function. |
| Letter Addresses | This provides a complete listing of all of the IRS addresses used on AOIC correspondence when transferring case work from one IRS location to another. |
| Standard Paragraphs | This provides a pre-written paragraph text that can be selected by letter for AOIC generated letters. This can be useful in determining the appropriate text to use for specific situations, if the user is not familiar with the AOIC letters. |
| Disposition Codes | This provides a complete listing of the disposition codes along with a complete listing of the various status codes used to control inventory in the sites. |
| Validate and Release | This provides a listing of accepted offers ready to be transferred to MOIC for monitoring. |

5. Form/Letters Menu provides access to Letters, Forms, and Maintenance. The following applications can be accessed by utilizing the “Maintenance” listing.



   - Signature Maintenance

   - Return Address Maintenance

   - Transfer Address Maintenance


6. In addition, COIC managers may utilize the following reports below.



1. **Fee Refund/Apply Listing**\- This listing is used to track the application fees that were applied and/or refunded. If an offer with a posted TIPRA and application fee is changed from processable to not processable, AOIC will detect this mismatch and the offer will appear on the Fee Refund/Apply Listing report. Managers should ensure this report is checked every two weeks to identify cases with fee mismatches. Check the AOIC offer information to determine the reason for the not processable criteria. If the offer was deemed not processable due to bankruptcy, verify the fee was posted to the taxpayer’s account and ensure the history reflects actions were taken to manually refund the money. As a general rule bankruptcy is the only criteria monies are returned when the offer is changed from processable to not processable based on Section 300.3(b)(2). In the Payment screen, click the Clear Refund Indicator to remove the case from the report.



      ### Note:



      For any not processable criteria, other than bankruptcy, click the Clear Refund Indicator to remove the case from the report.

2. **Application Fee Analysis Report**\- This report provides a means of tracking offer receipts during a specified period, then broken out by processable versus non- processable, undetermined, with application fee, without application fee, and the reason (doubt as to liability only, low income, master offer referenced, or master offer closed in error). This report also provides a breakout of the number of days we take to make our receipts either processable or non-processable. The COIC sites and Headquarters principally use this report.


7. Business Objects is a good tool to help manage inventory at the territory/manager level. Various Business Objects reports are available for use. Access may be requested by submitting a BEARS request for Business Objects. Some of the reports are:



1. Cases sent to IAR and

2. Cases sent to Counsel.


**1.4.52.6.10** **(04-09-2025)**

#### Semi-Annual Inventory Matches and Inventory Matches

1. To maintain a valid inventory count you must perform an inventory match on a semi-annual basis and resolve any discrepancies.

2. Complete these matches on March 31st and September 30th of each fiscal year.

3. Documentation must be retained in a folder or binder and available for review for three years.

4. When an employee leaves a group complete an inventory match prior to departure.

5. When a face-to-face review cannot be performed, the manager must print the employee’s inventory and follow-up listing, and the employee must verbally announce each offer that is in their physical possession.


**1.4.52.6.10.1** **(04-09-2025)**

##### Semi-Annual Inventory Matches and Inventory Matches for COIC

1. A 100 percent inventory match utilizing AOIC and OIC files must include: all of the group's assigned offer cases (including those in suspense assigned to the OE/TE), offers assigned to Appeals over 270 days, and site revenue officer's assignment numbers. When matching cases assigned to Appeals (90xx) inventories ensure the proposed disposition is reflected on AOIC and that ACDS shows a corresponding open offer.

2. When matching cases assigned to DATL Exam (60XX) inventories ensure the disposition is reflected on AOIC and corresponding Exam repository (currently on SharePoint).

3. A reconciliation and acknowledgment match of Form 3210 for transferred and closed offers in transit over 30 days must also be performed. This includes cases on electronic platforms such as Appeal cases in the electronic case receipt (ECR).

4. Documentation of the completion of the AOIC semi-annual match consisting of all case listings and the correction/resolution of all discrepancies must be maintained by the DM.

5. Operation will ensure that suspense files (i.e. 60XX, 55XX, 51XX, 3000) are reconciled on a quarterly basis. Operation will ensure that the AOIC record is closed when applicable.


**1.4.52.6.10.2** **(04-09-2025)**

##### Semi-Annual Inventory Matches and Inventory Matches for FOIC

1. You must perform a physical inventory match against records on AOIC and ICS on a semi-annual basis and it must contain the following:



   - A 100 percent inventory match utilizing AOIC, ICS, and OIC files. This includes all of the group's assigned OIC cases, including cases in hold files, pending approval files, assigned to Appeals, Counsel and the Independent Administrative Reviewer (IAR).

   - Reconciliation and acknowledgement of Forms 3210 for all closed or transferred OICs that are in transit status for more than 30 days.



     ### Note:



     Cases that are in transit status for less than 30 days should not be part of the match process.


2. Documentation of the completion of the AOIC/ICS semi-annual match and the correction of all discrepancies must be maintained by the FCM. Documentation must consist of a case listing indicating all cases have been matched and discrepancies resolved.

3. Inventory listing cases in Appeals (90XX) must be matched and indicate the proposed disposition is reflected on AOIC and ACDS shows a corresponding open offer.


**1.4.52.6.10.3** **(11-17-2021)**

##### Semi-Annual Inventory Matches and Inventory Matches for MOIC

1. A 100 percent inventory match utilizing AOIC and OIC files must include: all of the assigned offer cases and any OIs.

2. A reconciliation and acknowledgment match of Form 3210 for closed offers in transit over 30 days must also be performed.

3. Documentation of the completion of the AOIC semi-annual match and the correction of all discrepancies must be maintained by the DM.

4. Annually the manager must review the collateral listing.


**1.4.52.6.11** **(04-09-2025)**

#### AOIC Clean Up

1. Each COIC site (including DATL COIC), MOIC site, and FOIC territory has a responsibility to perform general clean up actions on AOIC. The following is provided to assist in performing routine maintenance of user records.

2. _AOIC Letter /Form Clean Up-_ AOIC records the issuance of a letter in Remarks when the letter is cleared. Ensure AOIC generated letters and forms are cleared timely.



### Note:



Ensure when an employee leaves the unit/group to have them clear their letters and forms as this cannot be done once their AOIC user number is deleted.

3. _AOIC Signature Maintenance_\- It is the responsibility of each COIC site, MOIC site, and FOIC territory to maintain the AOIC signature information for the employees in their assigned area. Semi-annually review the AOIC information to ensure it is current by deleting obsolete signatures.



### Note:



The Signature Maintenance listing may be found in AOIC under Forms/Letters.





1. To update a signature, select the signature number that precedes the signature name. Input the necessary changes and press submit.

2. To delete a signature, select the signature number that precedes the signature name. Select the delete button and then press OK.


4. _AOIC Address Clean Up_\- It is the responsibility of each COIC site, MOIC site, and FOIC territory to maintain the AOIC address information for the addresses in their assigned area. Semi-annually review the AOIC information to ensure it is current by deleting obsolete addresses.



### Note:



The AOIC Return Address Maintenance listing may be found in AOIC under Forms/Letters.





1. To update an address, select the address number that precedes the address. Input the necessary changes and press submit.

2. To delete an address, select the address number that precedes the address. Select the delete button and then press OK.


5. _AOIC Assignment Maintenance_\- Verify AOIC assignment numbers/names are correct. If the assignment number is no longer being utilized update the name to "vacant" .



### Note:



Prior to creating a new assignment number on AOIC notify Collection Policy so that all applicable assignment numbers are included in required reports for the National Office.


**1.4.52.6.12** **(10-16-2023)**

#### Quality and Inventory Controls

1. The IRS vision focuses on three high level goals — service to each taxpayer, service to all taxpayers, and productivity through a quality work environment. The IRS has developed a set of Balanced Measures in three major areas: customer satisfaction, employee satisfaction, and business results, with business results comprised of measures of quality and quantity. In reaching our goals, we consider our impact on customer and employee satisfaction while we strive to improve quality and achieve quantifiable results.

2. To assist in customer satisfaction, ensure that employees respond promptly to customer requests or concerns. Employees should return calls as soon as practical after receiving a message. When out of office for extended periods of time ensure employees update their systems, such as voicemail, (and email for IRS personnel only) to direct the caller to an alternate person for assistance. Voice greetings should contain a secure fax number where taxpayers/practitioners can send requested information.



### Note:



COIC PEs do not need to provide an alternate IRS person for their voicemail in these situations but should list their SCOIC toll free number.

3. You are responsible for the quality of all work assigned to the group and for all work that leaves the group. At a minimum:



   - Solicit suggestions from the group to address ways that can improve the quality of the work.

   - Develop a plan to ensure a high level of quality in the group.

   - Use EQRS/NQRS results as a diagnostic tool to focus attention on specific quality issues and identify training needs.

   - Ensure appropriate time is devoted to coaching and mentoring employees, as well as providing guidance that will assist in resolving their most difficult assignments.

   - Ensure all cases are brought to a resolution within a reasonable amount of time. Generally, this should be within six months of assignment to the employee.

   - Approval work should be done routinely and held in the managerial approval hold file no longer than five business days plus five business days for mail time if the manager and employee are not collocated and manager needs to review the paper file.


**1.4.52.6.13** **(04-09-2025)**

#### Quality and Inventory Controls for COIC

1. An important area of workload management and quality control for COIC managers is the establishment of inventory controls. It is recommended that the OM designate staff to retrieve and distribute controls for the offer groups. The following controls should be retrieved from the appropriate AOIC database on a weekly basis unless specified as a monthly report. For a complete list of available AOIC reports see _IRM 1.4.52.6.9_, AOIC and Business Objects Reports.




| **Report Name** | **Usage** |
| :-: | :-: |
| Cases assigned to COIC, but not received or not accepted on AOIC (Source: AOIC) | Review and work this Transfers Not Accepted inventory report on a weekly basis by either you or a designee to ensure regular control. Timely and proper actions must be taken on any cases showing as transferred 30 days or more from the date of the report run date. |
| Hold File Case Listing (Source: AOIC) | COIC OMs should use the _corporate inventory_ approach when addressing hold file situations in their respective groups, and consider reassignment of work from one group to another, whenever necessary. |
| Validate and Release (Source: AOIC Office Menu - AOIC Offers - Validate & Release) | Accepted offers that are not validated and/or released by the group. Complete this action weekly after quality review cases are selected. |
| Assessment Statute Expiration Date (ASED) Report (Source: IDRS and ICS) | This report is generated from IDRS downloads; however, this type of download information does not reach OIC CIPs if in ST 71 or AOIC. Because of this factor, a designated employee should manually review all incoming BMF cases (not sole proprietorships) for potential ASEDs. Once identified, the manager or designee should monitor monthly to identify accounts where the ASED will expire within the next 12 months. Since any potential ASED changes will not download on accounts in Status 71, you or your designee must revisit these cases to check for any changes. Follow procedures outlined in IRM 5.8.4.22.1, Trust Fund Liabilities, for handling potential ASED modules. |
| Form 2209 Courtesy Investigation and Time Sensitive Work | Review to ensure employees timely address. Time sensitive work can include offers with aged IRS received date or taxpayer imminent hardship |
| Appeal 30–Day Hold File (Source: AOIC and Business Objects) | Centralization for this type of inventory is recommended. In addition, the use of a designated PE to monitor the progress of these cases is also recommended. |
| Rejected with Appeal Rights Listing | This report should be used to identify offers for which rejected letters have been generated yet the offer has not been closed |
| AOIC Transaction Listing (Source: AOIC Area Office Menu - Reports & Correspondence - Reports & Listings - Area Office - Transaction Listing) | This report can be printed daily but minimally requires weekly reconciliation to ensure IDRS modules and respective notice/collection status codes match AOIC. It is suggested that this reconciliation be performed by designated PEs. |
| Unpostable Transactions | Refer to IRM 21.5.5, Account Resolution-Unpostables, when unpostable issues are identified. Per IRM 21.5.5.4.2.2, Unpostables Created by Your Own Adjustments, specifically makes it clear that it is the originator’s responsibility to resolve unpostables they create, and that it is critical that all unpostable cases are worked within seven business days of receipt. |
| Cases sent to Counsel and IAR (Source: Business Objects and AOIC) | Review these inventories to ensure these functions timely review cases and return to SCOIC. |


**1.4.52.6.14** **(04-09-2025)**

#### Quality and Inventory Controls for FOIC

1. An important area of workload management and quality control for you as the OIC manager is to establish group inventory controls. It is recommended that the FOIC territory designate a TE to retrieve and distribute these controls for all OIC groups within the territory. Retrieve the following controls from the appropriate databases (e.g., AOIC, ENTITY, and/or ICS) on a weekly basis unless specified as a monthly report to ensure regular control and prompt resolution of any identified problem.




| **Report Name** | **Usage** |
| :-: | :-: |
| Cases assigned to FOIC, but not received or not accepted on AOIC (Source: AOIC) | Review and work this Transfers not Accepted inventory report on a weekly basis by either you or a designee to ensure regular control. Timely and proper actions must be taken on any cases showing as transferred 30 days or more from the date of the report run date. |
| Hold File Case Listing (Source: AOIC) | OIC FCMs should use the _corporate inventory_ approach when addressing hold file situations in their respective groups, and consider reassignment of work from one group to another, or between territories, whenever necessary. |
| Validate and Release (Source: AOIC Office Menu - AOIC Offers - Validate & Release) | Accepted offers that are not validated and/or released by the group. Complete this action weekly after quality review cases are selected. |
| Assessment Statute Expiration Date (ASED) Report (Source: IDRS and ICS) | This report is generated from IDRS downloads; however, this type of download information does not reach OIC CIPs in Status 71. Because of this factor, a designated TE should manually review all incoming cases for potential ASEDs. Once identified, the group secretary/administrative assistant/TE should input the case/modules, containing the ASEDs, on ICS in order to generate the ASED Indicator Report. Generate a report monthly to identify accounts where the ASED will expire within the next 12 months. Since any potential ASED changes will not download on accounts in Status 71, you or your designee must revisit these cases to check for any changes. Follow procedures outlined in IRM 5.8.4.22.1, Trust Fund Liabilities, for handling potential ASED modules. |
| Form 2209 Courtesy Investigation and Time Sensitive Work | Review to ensure employees timely address. Time sensitive work can include offers with aged IRS received date or taxpayer imminent hardship |
| Appeal 30–Day Hold File (Source: AOIC and Business Objects) | Centralization for this type of inventory is recommended. In addition, the use of a designated TE to monitor the progress of these cases is also recommended. |
| Rejected with Appeal Rights Listing | This report should be used to identify offers for which rejected letters have been generated yet the offer has not been closed |
| AOIC Transaction Listing (Source: AOIC Area Office Menu - Reports & Correspondence - Reports & Listings - Area Office - Transaction Listing) | This report can be printed daily but minimally requires weekly reconciliation to ensure IDRS modules and respective notice/collection status codes match AOIC. It is suggested that this reconciliation be performed by a designated TE. |
| Diagnostic-Q Transcript (also known as DIAG-Q transcript and Unreversed TC470 Unreversed TC 480 and transcripts | Occasionally DIAG-Q and AMO6 W transcripts will be sent to FOIC for resolution. Resolve cases listed on these reports per instructions in IRM 5.19.7.2.24.2. |
| Unpostable Transactions | Refer to IRM 21.5.5, Account Resolution-Unpostables, when unpostable issues are identified. Per IRM 21.5.5.4.2.2, Unpostables Created by Your Own Adjustments, specifically makes it clear that it is the originator’s responsibility to resolve unpostables they create, and that it is critical that all unpostable cases are worked within seven business days of receipt. |
| Time Management Reports (Source: ENTITY) | Review these reports monthly to monitor several issues: correct application of direct time on case assignments; track the percentage of direct time spent on higher graded work to ensure the 25 percent threshold is not being exceeded; proper use of administrative time and other non-direct case time usage. |
| Cases sent to Counsel and IAR (Source: Business Objects and AOIC) | Review these inventories to ensure these functions timely review cases and return to SCOIC. |


**1.4.52.6.15** **(04-09-2025)**

#### Monitoring Offer in Compromise Quality and Inventory Controls

1. The establishment of quality and inventory controls assists MOIC managers in their overall workload management and the general team operation. The DM may delegate unless otherwise stated the review of the following below.




| **Report Name** | **Report Summary, Due Date, and Usage** |
| :-: | :-: |
| New Work (NW) Listing | This report will show new incoming cases from the territory and COIC offices; these cases have not been accepted into the campus inventory. Generate a NW list every 30 days to validate receipt of case files and required documentation. Case files not received as listed and those received with incomplete or missing required documentation should be resolved within 15 days. These cases will be placed in NW sub code MC for missing case and IC for incomplete case. Those not resolved in the 15-day time frame will be returned to originator with an AOIC history note. DMs must review weekly for accuracy. |
| Journal Payment Due Date Report | Use this report to determine taxpayers compliance with their payment terms. Generate bi-monthly via AOIC using the following date parameters: 01-01-1995 to 45 days prior to the run date. Review to identify missed payments to ensure contact is made before the payment is 45 days overdue.<br> <br>### Note:<br>If the RPA (Robotics Process Automation) is not available, managers must review every month to ensure MOIC employees are working payment due listings timely. |
| AOIC Follow-up Listing | Review this report bimonthly using the following date parameters: query the AOIC system with a beginning date of 01-01-1995 to the current date. Ensure adequate AOIC remarks are left to document the next action taken by the TE and the scheduled follow- up was addressed. Ensure any action taken to update or delete the follow-up was appropriate for the complexity of the issue.<br> <br>### Note:<br>If there is a Notice of Federal Tax Lien (NFTL) on the account, a follow-up must be set every 25 days to monitor for full payment. |
| Aged 5M Inventory Listing | As of July 2023, Aged 5M inventory is processed weekly through RPA rather than quarterly through the DAE run. RPA takes action to close cases found to be clear, leaving a smaller volume of offers requiring employee review. See IRM 5.19.7.6 . |
| Compliance DAE Run | Generate and submit to the DAE Team annually on or around November 15th. The compliance run is for IMF cases with no open business filing requirements. Offers with business filing requirements should be monitored in 5B status rather than 5M. Once MOIC receives the report back from DAE, MOIC Campus employees have 60 days to work that listing. Within 90 days from the DAE response, verify this listing was worked timely. |
| Employee Inventory Report | This report is known as Service Center Inventory Report on AOIC. Generate OA status monthly for cases assigned to each employee to ensure timely intake and appropriateness of actions. |
| Closed Offer Deposit Disposition Report | Generate monthly to ensure that deposits have been disposed of for rejected/withdrawn or terminated offers. |
| Deposit Transactions Report | Generate and review at the beginning of each month using a date range that covers the preceding month to ensure actions taken from the AOIC Deposit screen are timely and accurate. This will assist with the 4710 account reconciliation. |
| BOE Collateral Report | Run annually in February so that packages are mailed to taxpayer 45 days before the current year tax return due date. Verify by March 31 that all packages were mailed timely. |
| BOE Reports | Monthly use BOE to identify offers without follow-ups and ensure a correct follow-up is established. Note: MP, MR, and 5M are excluded from this review. |

2. Review electronic mailboxes monthly to verify employees completed timely action and responses.

3. Other Investigation (OI) inventory must be verified for accuracy. The DM must ensure the liaison is generating a report quarterly on Form 2209, Other Investigations, with a beginning date 90 days prior to the run date to determine overdue responses. Instruct tax examiners to follow up with the COIC or FOIC to ensure employees are addressing OIs and responding appropriately.


**1.4.52.7** **(10-16-2023)**

### Employee Performance Analysis

1. This subsection discusses the purpose and guidelines for managers performing case reviews and analyzing an employee's job performance.


**1.4.52.7.1** **(11-17-2021)**

#### Case Reviews and Performance Discussions

1. All case reviews and performance discussions should focus on providing the OIC employee with proper guidance and case direction, while conveying the importance of timely and effective case actions and any performance related issue. The review must also clearly emphasize your expectations concerning required case actions and completion time frames.

2. Reviews are an integral part of your responsibilities. At the beginning of an employee's annual rating period, develop and implement a review plan. The review plan should provide for a fair and accurate assessment of the employee's overall performance throughout the rating period.

3. All technical case reviews must be conducted utilizing the EQRS regardless of whether they are evaluative or non-evaluative. Use of EQRS will enable you to:



   - Assess the employee's effectiveness in meeting the expectation established in the CJEs.



     ### Note:



     Reviews prepared on EQRS will link employee performance to both the review attributes and the CJEs.

   - Assess the employee's efficiency in carrying out the laws, procedures, and policies of the IRS.

   - Identify and address performance strengths and weaknesses.

   - Assess the employee's ability to properly plan and schedule office and telework activities.

   - Ensure the employee is taking timely and appropriate actions to bring cases to prompt and proper resolution.

   - Assess employee effectiveness in developmental case assignments.

   - Assess the employee's effectiveness in meeting the IRS Retention Standard for the Fair and Equitable Treatment of Taxpayers.

   - Assess the employee's performance in relation to customer satisfaction and the protection of taxpayer rights in an investigation.


4. For FOIC case reviews, determine if the assigned grade level is still accurate, and make the necessary adjustments on ICS.

5. Targeted reviews can help you identify an employee's need for training and development. In turn, case reviews will also help you ascertain how much time to devote to each employee, as well as design an individual review plan to assist the employee's identified needs. You may choose from the following optional review categories below in designing an employee's review plan.



   - Office observations

   - Announced telephone conference monitoring

   - Spot reviews of open and closed cases

   - Formal inventory analysis



     ### Note:



     Formal inventory analysis is defined as a review of the inventory to identify trends and issues that may be present in cases after identification in a specific case. e.g., providing unwarranted extensions, not submitting cases for approval timely, or requesting unnecessary information. The review is to determine if the issue is a trend or a one-time occurrence in a specific case.

   - Reviews of work submitted for approval

   - Initial contact reviews

   - High priority case reviews (overage, potentially overage, gaps in activity of 45 days or more, and large dollar)


**1.4.52.7.2** **(10-16-2023)**

#### **Reviews and Employee Performance Discussions for OIC**

1. In addition to the reviews in _IRM 1.4.52.7.1_, Case Reviews, as an OIC manager you may select from the list below in designing an employee’s performance plan.



   - Technical Case reviews

   - Clerical review

   - Data Security review

   - Time Input review on SETR


2. All performance discussions should be held within the guidelines of the current National Agreement, http://hco.web.irs.gov/lrer/negotiations/natagree/, and focus on providing the employee with proper guidance and case direction, while conveying the importance of timely and effective case actions and any performance related issue. They must also clearly emphasize the manager's expectations concerning required case actions and completion time frames.


**1.4.52.7.3** **(04-09-2025)**

#### Review Documentation

1. Become familiar with and use the below references for selection and review of cases.



   - Document 12360, _Embedded Quality Job Aid (Offers in Compromise)_


2. In addition, FOIC managers should familiarize themselves with IRM 5.3.1.3.3, Field Collection Time Reporting and _IRM 1.4.52.5.2_, Time Reporting for FOIC.

3. The EQRS Individual Feedback Report links the review attributes to performance standards of an OE’/OS' critical job elements. In general, deficiencies relating to a CJE should be noted as an area of special concern if found in 25 percent or more of the cases reviewed. However, there may be instances where a single deficiency (e.g., expired statute) is critical. EQRS allows you to generate reports of review data at both the group and individual level. It also allows you to consider program effectiveness and to properly evaluate the performance of employees in relation to their CJEs based on statistical data over a period of time. These reports can show trends and assist in identifying if employees need training.



### Note:



For reviews that consider OE/OS activity across multiple cases (e.g., time utilization and office observation) a summary narrative, such as a memorandum, may be substituted.

4. Utilize the EQRS Data Collection Instrument (DCI) to summarize observations derived from a case review. EQRS provides reason codes which correspond to each attribute of the case review. Select the reason codes that relate to the performance observed. The Attribute Narrative field may be used to document the specifics of the employee performance. Each attribute links to a specific CJE aspect. If additional feedback to the employee is needed, prepare a memorandum to express commendation or concerns. If the memorandum (e.g., managerial case summary), is utilized it should:



   - Outline the performance in relation to the employee's CJEs and address positive as well as negative aspects of an employee's performance.

   - Provide clear managerial guidance on those cases requiring actions including expectations, deadlines and required actions to expedite case disposition.


5. For each FOIC case reviewed, document the ICS history using the ICS History pick list. Begin with using the term **Case Reviewed**, include the date reviewed and the type of review completed.



### Note:



Documentation of an evaluative nature must not be included in the ICS case history or AOIC Remarks.

6. The DCI and managerial case summary, if applicable, should be prepared in duplicate and reflect all case data, including employee feedback. Both you and the employee must sign the DCI. Securing the signature of the employee does not necessarily reflect agreement, but merely acknowledges receipt of the document(s).

7. The original documents (e.g., DCI and managerial case summary) must be issued to the employee within 15 days after completion of the review in order for the employee to follow through on case recommendations and deadlines. Retain a duplicate in the EPF for follow-up, and promptly discuss all recommended actions entered on the review document with the employee to ensure that there is a complete understanding about how, what, when, and why to take specific actions.

8. In addition to case quality and timeliness metrics, taxpayer rights are evaluated in EQRS attribute 607. If you rate attribute 607 “No” with reason code 2, Right to Representation not Observed, you should enter a narrative detailing the circumstances supporting the “No” rating. You must report potential violations of IRC 6304, Fair Tax Collection Practices to your local Labor Relations specialist by the end of the next business day following discovery, see IRM 1.4.52.9.2.1, Fair Tax Collection Practices.


**1.4.52.7.4** **(04-09-2025)**

#### Mandatory Reviews (COIC, DATL, FOIC, and MOIC)

01. This subsection discusses mandatory reviews. Additional reviews may be required by the SCOIC director.

02. Conduct a timely mid-year and annual review on each of your employees. See Document 11678 , Section 4.



    1. Managers conduct mid-year reviews between the fifth and seventh month of the rating cycle.

    2. The due date of an annual appraisal for an employee who is rated using Form 6850 is based on the last digit of the employee’s Social Security Number. The supervisor must complete the employee’s annual appraisal for both bargaining unit and non-bargaining unit employees within the scheduled time limits shown in the National Agreement (Document 11678), provided the manager has observed the employee for 60 days or more against their signed performance plan during the appraisal period.



       ### Note:



       For employees with performance problems, the manager must provide the employee a minimum of 60 days during which to raise their work performance to an acceptable level. See IRM 6.430.2.3.4, Marginal and Unacceptable Performance.





       ### Note:



       Manager annual appraisals are based on the fiscal year cycle. See IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs), and IRM 6.430.3, Performance Management Program for Evaluating Managers, Management Officials, and Confidential Management/Program Analysts for additional information.

    3. When writing mid-year and annual narratives, be concise, but descriptive enough to provide an accurate picture of the strengths, development needs, and accomplishments of the employee in each CJE. See IRM 6.430.2.4.6, Completing Appraisal Narratives.

    4. Employees may submit a self-assessment, limited to four pages in length, no later than the last workday of the employee’s annual appraisal rating period. See IRM 6.430.2.4.5, Self-Assessments and IRM 6.430.2.6, Conducting the Performance Appraisal Meeting.


03. Choose a sufficient number of cases to review to ensure a thorough evaluation of each employee’s performance. Document case reviews using EQRS.

04. Scheduling of the reviews may be announced or unannounced.

05. Frontline managers are responsible to conduct the following mandatory reviews unless otherwise delegated.




    | **Employee** | **Mandatory Review** | **Remarks** |
    | :-: | :-: | :-: |
    | Offer Examiner/Offer Specialist | 1. Technical Case Review<br>       <br>    2. Time Utilization Review | 1. Complete a minimum of one EQRS case review per employee per month within the employee’s annual rating period, for a total of ten months. The manager's review should focus on financial analysis, accurate RCP, appropriate case decision, appropriate request for additional financial information, timely POA/taxpayer contact, timely follow-up, inactivity gaps, etc. Include a mixture of review types. Cases should include an equal amount from open inventory and closed cases submitted for approval.<br>       <br>    2. Complete two time utilization reviews per the employee’s annual rating period with one being completed prior to the midyear review. |
    | Process Examiner | 1. Technical Case Review<br>       <br>    2. Process Examiner Telephone Monitoring Review<br>       <br>    3. Time Utilization Review | 1. Complete a minimum of one case review per employee per month for a total of ten months.<br>       <br>    2. PE phone reviews should constitute one half of the EQRS case reviews completed in the rating period. Managers responsible for phone groups must perform and document monthly mass monitoring sessions in conjunction with EQRS reviews. The manager's review should focus on following disclosure guidelines, providing the correct answer, documentation, etc.<br>       <br>    3. Complete two time utilization reviews per the employee’s annual rating period with one being completed prior to the midyear review. |
    | DATL Tax Examiner | 1. Technical Case Review<br>       <br>    2. Time Utilization Review | 1. Complete a minimum of one EQRS case review per employee per month within the employee’s annual rating period for a total of ten months. The manager's review should focus on appropriate case decision, appropriate request for additional financial information, timely POA/taxpayer contact, timely follow-up, inactivity gaps, transfer completed correctly, appropriate Form 3210 acknowledgement, etc.<br>       <br>    2. Complete two time utilization reviews per the employee’s annual rating period with one being completed prior to the midyear review. |
    | FOIC Tax Examiner | 1. Monthly Review<br>       <br>    2. Time Utilization Review | 1. Complete a minimum of one review per employee per month within the employee’s annual rating period for a total of ten months. You may select but are not limited to the following reviews:<br>       <br>       <br>       <br>       - Announced telephone conference monitoring<br>         <br>       - Monitoring effective closures for the IAR and 45 day rejection hold file<br>         <br>       - Effectiveness of uploading and managing Counsel approval sites (such as SharePoint)<br>         <br>       - Effectiveness of working the Transfer Not Accepted (TNA) listing<br>         <br>       - Monitoring Form 3210 Acknowledgments<br>         <br>    2. See _IRM 1.4.52.10.1_ for TE responsibilities for additional reviews/observations.<br>       <br>    3. Complete two time utilization reviews per the employee’s annual rating period with one being completed prior to the midyear review. |
    | MOIC Tax Examiner | 1. Technical Case Review<br>       <br>    2. Time Utilization Review | 1. Complete a minimum of one EQRS case review per employee per month within the employee’s annual rating period for a total of ten months.<br>       <br>    2. Complete two time utilization reviews per the employee’s annual rating period with one being completed prior to the midyear review. |
    | Clerk | Clerical Review | Monthly review of assigned duties to ensure accuracy and timeliness of the employee's work. |
    | COIC Lead/DATL COIC | Work Leader Review | Performed quarterly by the frontline manager (who has a lead), work leader reviews can include inventory management and monitoring, completion of work assignments, the ability to identify training needs, the ability to perform accurate EQRS reviews, and technical accuracy of reviews. |

06. If the results of the review include directed actions, conduct a follow-up review within 60 days (within 30 days for time utilization review) after the original review to ensure that all instructions have been followed and the case is moving toward resolution.

07. On a monthly basis, conduct a workload management review and discussion with each OE/OS/MOIC TE; however more frequent consultations may be necessary, depending on the performance of the employee. These reviews will be filed in the EPF and may include the following below. This list is not all inclusive.




    | **Employee** | **Workload Management Review Criteria** |
    | :-: | :-: |
    | Offer Examiner | - Cases assigned over 90 days.<br>      <br>    - Potential Overage and Overage Cases.<br>      <br>    - Timely initial analysis.<br>      <br>    - Unwarranted or undocumented activity gaps.<br>      <br>    - Status of the case, plan of action, and proposed disposition.<br>      <br>    - Large dollar cases.<br>      <br>    - Scheduling of work<br>      <br>### Note:<br>The OM must be notified and a proposed case disposition and date provided if the same case is on two consecutive reviews. |
    | Offer Specialist | - Cases on the _ENTITY – No Touch Report_ or ICS Report showing no case touches for over 30 days since assignment and/or showing no case touches within the last 45 days.<br>      <br>    - Assigned cases over 120 days.<br>      <br>    - Timely initial analysis, including cases with no touch within 30 days of assignment.<br>      <br>    - Unwarranted or undocumented activity gaps.<br>      <br>    - Status of the case, plan of action, and proposed disposition.<br>      <br>    - Large dollar cases.<br>      <br>    - Scheduling of work<br>      <br>### Note:<br>The FCM must be notified and a proposed case disposition and date provided if the same case is on two consecutive reviews. |
    | MOIC Tax Examiner | - Timely OA processing.<br>      <br>    - Unwarranted or undocumented activity gaps.<br>      <br>    - Timely release of NFTL.<br>      <br>    - Case went to next status in a timely manner.<br>      <br>    - Prioritized cases accordingly.<br>      <br>    - Takes appropriate and timely actions listed on RPA output logs.<br>      <br>### Note:<br>The OM must be notified if inappropriate workload management actions are found in two consecutive reviews. |

08. Using the above referenced reports, you must:



    - Hold discussions with the employee and evaluate the progress of the specific case.

    - Ascertain how an employee is performing in relation to the employee's CJEs.

    - Document your observations and target dates for the next case action and case resolution (if appropriate) in a memorandum.

    - Utilize this opportunity to recognize positive performance, as well as provide constructive feedback regarding needs for improvement.

    - Ensure follow-up actions are taken.


09. Documentation must be shared with the employee within 15 calendar days after the discussion is held and once acknowledged, retain in the EPF in accordance with current PII guidelines.

10. When necessary, based on case reviews or other forms of review such as telephone or office observation, etc., you have the authority to require your employee to obtain your approval before taking subsequent case actions. For example, employees who inappropriately extend deadlines or delay case actions can be required to obtain your approval of their extensions in the future so as not to delay timely case resolution.



    ### Note:



    The ICS Calendar is an excellent tool that can assist the GM and OS when workload management issues are found in FOIC cases.

11. A time utilization review, sometimes called a morning after review, is performed to verify that the time reporting is commensurate with the case actions for that day and is performed with the following criteria listed below.



    1. Scheduling of the reviews must be unannounced.

    2. Perform two reviews per the employee’s annual rating period.

    3. Conduct the time utilization review within 15 workdays of the day selected.

    4. Evaluate whether time spent on case actions during the day matches the time charged as well as the nature and complexity of what is required in each case.

    5. Evaluate whether the case actions taken are likely to move the case toward resolution.

    6. Identify unproductive/inefficient activity and make recommendations for improvement.

    7. If the results of the review include directed actions, you must conduct a follow-up within 30 calendar days after the original review to ensure that all instructions have been followed and the case is moving towards resolution.


12. Documents should be shared with the OE/OS and maintained as part of the EPF to be used in preparation of the mid-year and annual appraisal.


**1.4.52.7.4.1** **(04-09-2025)**

##### After-Hours Review

1. An after-hours review allows managers to determine whether employees are adequately protecting documents, property and monies. Managers can accomplish this by being the last to leave a work area and checking the area after the close of the business day or by arriving early. Conduct one or more after-hours security reviews per fiscal year for the post of duty locations of your direct reports.

2. Per IRM 10.5.1.5.1, Clean Desk Policy, all employees must secure sensitive but unclassified (SBU) materials. SBU materials include personally identifiable information (PII) and federal tax information (FTI). Managers periodically must review functional areas after-hours to determine if sensitive information is appropriately containerized and properly disposed. Inspect the following areas/items to determine if sensitive information is properly contained or disposed of:



1. Employee desktops should be free of any personally identifiable information, tax return information or systems passwords.

2. Confirm employees’ cabinets containing sensitive information are locked.

3. Inspect wastebaskets and unsecured recycling bins for sensitive material.

4. Shred bins should be properly secured.

5. Check for sensitive information left in printers or copiers.

6. Inspect mail rooms to confirm sensitive information is secured and the mail receptacle is locked.

7. Inspect interview rooms used by your employees for the presence of unsecured sensitive information.


3. Perform the following inspection of the physical space and equipment:



1. Do exterior doors have adequate locks to prevent easy access?

2. Do cipher lock combinations utilize at least four digits?

3. Are employees’ computers logged off?

4. Are cable locks in place and locked for computer laptops?


4. If weaknesses are identified, managers must take immediate action to safeguard information, property or rooms/facility, counsel employees as appropriate, and/or request assistance from appropriate local FMSS Physical Security staff in developing corrective measures.

5. While the after-hours review may be completed by a designee (e.g. the Commissioner’s Representative) of the group manager in posts of duty where the manager is not located, the complete functional reviews must be conducted by the group manager or acting group manager. Document the items in (2) and (3) above in a memorandum format. Include the printed name, title and signature of the reviewer. Provide a copy of the memorandum to the next level of management.

6. If your reviews reflect that employees repeatedly fail to observe security protocols, contact your Labor Relations specialist to determine the next appropriate action.


**1.4.52.7.5** **(03-22-2019)**

#### Additional Optional Reviews for Managers

1. The optional review below will provide managers with the opportunity to review and provide feedback to employees as necessary.


**1.4.52.7.5.1** **(04-09-2025)**

##### Review of Taxpayer and/or Representative Interviews

1. The taxpayer and/or representative review is performed either in the office or on a monitored and announced telephone conversation.

2. Observing the employee during face-to-face contacts and/or monitoring a pre-scheduled telephone conversation between the employee and the taxpayer and/or representative provides an excellent opportunity for you to assess the employee on the items below.




| **Interview Review Items** |
| :-: |
| Ability to conduct interviews. |
| Ability to communicate and interact with taxpayers and/or representatives. |
| Knowledge of policies and procedures. |
| Ability to secure necessary information/documentation and determine appropriate case direction. |
| Delivery of fair and courteous treatment of taxpayers and/or representatives. |
| Ability to address the various taxpayer rights (Publication 1, Your Rights as a Taxpayer; Publication 594, The IRS Collection Process; and IRC 6320 and 6330, Collection Appeals Program). |
| Use of Interest Based Negotiating techniques. |
| Ability to recognize and respond to taxpayer concerns, issues and interests. |
| Pre-contact preparation. |
| Effective use of time. |
| Ability to manage difficult, unexpected, complex or unusual circumstances. |
| Ability to appropriately recognize and address third party contact situations. |
| Observation of proper disclosure requirements. |





### Note:



It may be necessary to increase the number of reviews for those employees who have exhibited issues communicating with taxpayers and/or their representatives. The frequency will be your decision.

3. Documents should be shared with the OE/OS and maintained as part of the EPF to be used in preparation of the mid-year and annual appraisal.


**1.4.52.7.6** **(04-09-2025)**

#### OIC Department Manager, Operations Manager/Field Compliance Manager, and Director, Specialty Collection Offer in Compromise Annual Operational Review Overview

1. An operational review is an in-depth review and analysis of a particular program, function, or a subordinate manager and their organizational component. Reviews are opportunities to improve overall effectiveness of managers, teams/groups, departments, and the operation by evaluating the business unit’s performance toward achieving organizational goals and compliance with administrative requirements. Reviews of subordinate managers are imperative for their personal growth and the efficiency of the operation and serve as a component of the manager’s performance evaluation.

2. Conduct operational reviews in the following manner.



1. DMs review their frontline team managers.

2. OMs review their DMs.

3. FCMs review their GMs.

4. The SCOIC director and their staff review the OMs and FCMs.


3. An operational review must evaluate and assess, identify areas to improve, establish target dates for improvement, recognize and identify accomplishments, and provide follow up actions. The various areas to address are as follows.



1. Leadership and Human Capital Management-Employee Satisfaction: Ensure managers are providing timely and appropriate feedback.

2. Employee Engagement: Ensure employees are engaged/involved in decision making, and their concerns are being addressed to facilitate effective and appropriate casework.

3. Customer Service and Collaboration: Customer Satisfaction- Ensure customers are receiving timely and appropriate actions and receiving fair and equitable treatment to assist in resolving their offer submission(s).

4. Program Management and Business Results: Ensure the operation is on target for their plan and if not then determine what actions can be taken to meet those business targets.

5. Administrative Compliance: Ensure management is providing an internal control to ensure certain processes or safeguards are performed.


4. Compare items in (3) above with the following below.



1. Mission statement

2. Policies and regulations

3. National Agreement

4. IRM and Interim Guidance Procedures

5. Program letter

6. Business Measures and Goals


**1.4.52.7.6.1** **(04-09-2025)**

##### Operational Reviews and Employee Engagement

1. Operational reviews are a participative process involving each level of management and employees in SCOIC.

2. They also provide an opportunity for engagement to address business priorities and objectives and to implement timely actions to accomplish these objectives.

3. Incorporate focus groups and town halls (when appropriate) into the operational review.


**1.4.52.7.6.2** **(04-09-2025)**

##### OIC Operational Review Frequency and Planning

1. Operational and/or administrative compliance reviews may be conducted during the fiscal year as a single-phase comprehensive review or may take the form of an on-going series of multi-phased reviews that focus on specific aspects of performance.

2. Prepare a schedule of planned reviews at the beginning of each fiscal year. Schedule reviews to ensure you address all teams/groups. Provide the schedule to the OM or SCOIC Director by October 15.

3. Feedback about operational review findings is expected to occur continuously throughout the review cycle.

4. Conduct more frequent follow-up reviews when warranted by indicators such as statistical data out of the acceptable range, lack of experience on the part of the subordinate manager, or poor results from prior reviews. These reviews should also have established follow-up review dates scheduled for any areas showing minimal/no improvement.

5. Take into consideration the known strengths and opportunities for improvement for the group/team/operation/territory being reviewed when planning how to maximize the benefits of the operational review. In addition to the mandatory review elements exercise professional judgment when selecting the supplemental review elements that support the strategic plan for SCOIC Collection by providing managers with actionable guidance and measurable goals.

6. Several review elements can be performed remotely using the appropriate computer applications. Examples of review items which may be performed remotely include but are not limited to case reviews, performance appraisals, Leadership Succession Review plans, EQRS, inventory reports and 1204 certifications. Other review elements can be reviewed by requesting the documentation from the manager, examples include the after-hours security review and group meeting minutes.


**1.4.52.7.6.3** **(04-09-2025)**

##### Documentation

1. Document the operational review in a memorandum for the manager and share within 30 days of completion of the review.

2. Action items communicated to the manager must include a description of the action to be performed and include a timeline for completion.

3. The format of an operational review should begin with identifying the group/team/operation/territory reviewed, the evaluative period, summarize the review process and communicate response requirements. The body of the review should address each of the Responsibilities in the Management Performance Agreement for the manager (Leadership and Human Capital Management-Employee Satisfaction, Customer Service and Collaboration-Customer Satisfaction, and Program Management-Business Results) as well as the administrative compliance requirements. In addition to the Responsibilities, the operational review must include a section on employee engagement. The review should also include engagement between the management chain as well as engagement between the manager and their employees. The closing section of the review should summarize the overall performance of the group/team/operation/territory, articulate corrective actions to be taken and communicate any follow-up actions to be performed by the reviewer. The following represents an outline which may be used to format the operational review:



   - Introduction

   - Leadership and Human Capital Management-Employee Satisfaction

   - Employment Engagement

   - Customer Service and Collaboration-Customer Satisfaction

   - Program Management-Business Results

   - Administrative Compliance

   - Conclusion


4. Each responsibility is supported by review components. The narrative for each responsibility should address whether the responsibility is being met and provide instruction on the actions the manager must take to ensure the responsibility is met (if necessary). The recommendations should align to the appropriate review component to improve the team/group/operation/territory performance, rather than one-time corrective actions.

5. Request the manager to describe their processes related to the elements reviewed to address the effectiveness of those processes and make recommendations where necessary. Consider focus groups for this as well as one-on-one conversations.


**1.4.52.7.6.4** **(04-09-2025)**

##### **COIC Department Manager Annual Operational Review**

1. DMs must conduct a minimum of one annual operational review on each of their teams with follow-ups conducted as needed and appropriate. Document the review observations in a memorandum and share with the team manager within 30 days of the completion of the actual review.


**1.4.52.7.6.4.1** **(04-09-2025)**

###### Leadership & Human Capital Employee Satisfaction COIC Department Manager Annual Operational Review

1. Team managers are responsible for creating a workplace culture of professionalism where employees are treated with dignity and respect. Assess the manager's performance management in providing meaningful feedback to employees by completing performance reviews which encourage employee engagement and the timely completion of mid-year and annual performance evaluations. When reviewing this responsibility, determine if the manager is completing the required performance reviews timely.




| **Employee Satisfaction Components** | **Review Description** |
| :-: | :-: |
| Manager Feedback from Case Reviews | 1. Assess the accuracy of the manager's evaluative reviews, including content, scope, and amounts conducted monthly by frontline team manager.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Verify the manager is performing the mandatory performance reviews for their employees in a timely manner. DMs will also ensure documentation of these reviews is sufficient to effectively evaluate employees' performance and provide employee direction. Include any mandatory research and documentation (e.g. OIC IAT). This can be accomplished throughout the rating period while reviewing monthly review schedules, performance ratings, and EQRS reports. |
| Employee Performance File (EPF) | The EPF is a system consisting of all performance ratings and other performance-related records maintained on an employee in accordance with 5 CFR Part 293, Subpart D. The following documents must be maintained for four years<br> <br>1. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition, Critical Job Elements (CJEs), and Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard (annually).<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Form 6774 may cover more than four periods.<br>      <br>2. Training and On the Job Instructor (OJI) documentation<br>      <br>3. Workload management reviews<br>      <br>4. Mid-year progress reviews conducted annually by frontline team manager<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Ensure managers have conducted midyear evaluations between the fifth and seventh month of the employee’s rating period.<br>      <br>5. Annual evaluations<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Review performance appraisals performed by the managers to ensure they are timely. Confirm employee annual performance evaluations are free of ROTERS.<br>      <br>6. Employee self-assessments |
| Addressing Employee Concerns | Address employee satisfaction by ensuring employees’ concerns are being addressed to facilitate effective and appropriate casework. Managers must be adhering to all areas of this handbook; addressing employee survey issues, reviewing team action plans and results; supporting employee recognition and taking appropriate actions when performance issues arise; employing appropriate EEO and Diversity practices; and adhering to employee development and training guidelines. |
| Communications | Review communications and team meeting minutes to ensure managers are effectively communicating the goals of the IRS, OM, and Director. The manager should also be effectively communicating procedural and policy changes, casework techniques, and other issues that affect the overall quality of casework. |


**1.4.52.7.6.4.2** **(04-09-2025)**

###### Employee Engagement COIC Department Manager Annual Operational Review

1. Each management responsibility includes a component of employee engagement. High levels of employee engagement directly correlate to the achievement of the SCOIC goals and objectives. The elements of employee engagement are communication, leadership, recognition, and professional growth. This component of the operational review assesses the manager’s actions which promote and enhance employee engagement. Evaluate if the manager is communicating performance expectations through regular meetings and written communications. Does the manager's communication process promote employee engagement and are issues raised by employees acted upon? Address the manager's employee development program within the team, identifying training needs, employee development opportunities and employee training. Developmental leadership opportunities should be made available to all members of the team.




| **Employee Engagement Components** | **Review Description** |
| :-: | :-: |
| Communications and Recognition | 1. Confirm the manager is conducting regular meetings to communicate performance expectations by reviewing meeting minutes and other OIC CP and SCOIC communications issued. See if the meetings include roundtable discussions, and employees are given the opportunity to present issues or lead group meetings. Research the results of some of the recommendations.<br>      <br>2. Assess the manager’s employee recognition processes. The use of manager’s awards, time-off awards, e-cards, Form 6067, and Employee Performance Folder Record (letters from internal and external customers). |
| Leadership Opportunities | 1. Evaluate the use of Individual Development Plans (IDPs) in the group. Address whether the plans include actionable items and address if the items have been achieved.<br>      <br>2. Verify correct utilization of lead employee.<br>      <br>3. Assess the effectiveness of how the manager supports the Frontline Manager Readiness Program (FLRP) and Frontline Manager Cadre program (if available). |
| Professional Growth | 1. Assess the training plans and training completion for each employee in the team.<br>      <br>2. Address the manager’s processes of affording OJI, classroom instructor details or acting manager opportunities. |


**1.4.52.7.6.4.3** **(04-09-2025)**

###### Customer Service and Collaboration-Customer Satisfaction COIC Department Manager Annual Operational Review

1. Customer satisfaction is measured by the customer’s perception and level of overall satisfaction with their interaction experience. Customers are both internal and external to the IRS. High customer satisfaction translates into work group efficiencies and improving the public’s trust in the tax system. Customer satisfaction is the cornerstone to the mission of the IRS to provide top quality service to taxpayers by helping them understand their tax responsibilities with integrity and fairness to all. Metrics used to measure customer satisfaction include quality, regulatory compliance, and customer feedback. Both managers and employees have opportunities to improve customer satisfaction by identifying issues or risks for resolution.




| **Customer Satisfaction Components** | **Review Description** |
| :-: | :-: |
| EQRS Analysis | 1. Review cumulative quality attribute ratings cumulative reports from EQRS. Use the reports to identify the group strengths and opportunities for improvement.<br>      <br>2. Identify best practices and opportunities for improvement by reviewing the Top Ten Successes and Defects Report which identifies which attributes have the highest success and/or defect rates. OMs/DMs use this report at the department level to identify trends. Remember that quality information is only statistically valid at the operation level. These reports are only a starting point for drawing conclusions about operation and team performance. |
| 1204 Certification | Section 1204 of the Restructuring and Reform Act of 1998 prohibits the IRS from using any ROTER to evaluate employees or to impose or suggest production quotas or goals, requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard and requires each appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner.<br> <br>1. Confirm the manager timely completed quarterly 1204 certifications. |
| Collection Due Process and Fair Tax Collection Practices | 1. Address the timeliness of transferring taxpayer’s CDP and OIC appeal requests to Appeals. Also address the timeliness of reassignment of cases returned by Appeals.<br>      <br>2. Assess the manager’s processes for addressing potential violations of Fair Tax Collection Practices. |
| Employee Case Documentation | Review case histories to determine documentation is appropriate and accurately describes identified issues, case progression, and supports the case decision. Include any mandatory research and documentation (e.g. OIC IAT). Ensure employees are not violating taxpayer rights and they are performing timely and appropriate actions. |


**1.4.52.7.6.4.4** **(04-09-2025)**

###### Program Management Business Results COIC Department Manager Annual Operational Review

1. The IRS assesses operational level business results through output or quantity measures and quality measures The IRS uses organizational measures as an analytical reference to determine whether the actions taken achieved the desired performance result. The focus of the evaluation of the business results responsibility is based on the actions taken and related accomplishments toward meeting the SCOIC goals. Communicate the areas of emphasis with your managers at the beginning of the fiscal year and monitor the team’s performance at reasonable intervals throughout the rating period.

2. The operational review should speak to the manager's effectiveness in managing the performance components. The narrative should address whether performance components have been met or not met. In instances where a performance component is not met, document recommended actions to the manager in that component. Align action items to the manager to improve the team’s performance in a specific component rather than action items for specific cases.




| **Business Results Components** | **Review Description** |
| :-: | :-: |
| Age of Inventory | Ensure managers are monitoring cases, approving inventory timely, and employees are taking timely actions to move inventory toward appropriate resolution. |
| Manager's Organizational Effectiveness | 1. Timeliness of controlled responses<br>      <br>2. Effectiveness of method for managing tasks or assignments<br>      <br>3. Completeness, thoroughness, timeliness of reviews, projects, etc. |
| Quality of Work Performed \[Paper and Phones (if applicable)\] | DMs may utilize EQRS reports to identify error trends and ensure consistency among teams. The review of individual teams is intended to evaluate the effectiveness of the manager, assess the team’s performance and to provide guidance and direction intended to improve business results, foster effective casework and managerial engagement. |
| Timeliness of Work Performed | 1. Ensure customers are receiving timely and appropriate actions and receiving fair and equitable treatment to assist in resolving their offer submission(s). The manager should be addressing timely actions and follow-up contacts scheduled; ensuring case actions are appropriate and effective; ensuring timely responsiveness to taxpayer requests, as appropriate; and requests for supporting documentation are appropriate. |


**1.4.52.7.6.4.5** **(04-09-2025)**

###### Administrative/Compliance Review COIC Department Manager Annual Operational Review

1. The Administrative/Compliance portion of the operational review provides an internal control for ensure certain processes or safeguards are performed. Similar to the components of the other operational review, the reviewer can perform this oversight at any time during the rating period. This documentation should include the action performed and address findings of non-compliance and/or need for improvement.




| **Administrative/Compliance Components** | **Review Description** |
| :-: | :-: |
| AOIC Maintenance | Ensure AOIC signatures and assignment are being properly monitored and purged as appropriate by the managers. |
| Acknowledgement and Follow-up of Form 3210 | Document the process for performing quarterly reviews of Form 3210 control copies and reconciliation of acknowledgment copies. |
| CKGE Audits | For employees who have CKGE access, document your review of the manager’s required annual usage audit of the system. |
| Employee Inventories | Ensure inventories are being maintained within the SCOIC director’s / or the senior manager’s targeted range that ensure timely contact and efficient casework, while maintaining high levels of quality and customer service in the work performed by these employees. |
| Leave Administration | Ensure managers are approving leave and SETR appropriately and addressing leave issues when necessary. |
| Security Reviews | Review and document the manager’s performance of at least one after-hours security review. |


**1.4.52.7.6.5** **(04-09-2025)**

##### Field Compliance Manager Annual Operational Review

1. FCMs must conduct a minimum of one annual operational review on each of their groups with follow-ups conducted as needed and appropriate. Document the review observations in a memorandum and share with the manager within 30 days of the completion of the actual review. See _IRM 1.4.52.7.6.3_.

2. Listed below are suggested focus areas to incorporate in the review:

3. Include employee engagement activities in your review by conducting town halls and focus groups.


**1.4.52.7.6.5.1** **(04-09-2025)**

###### Leadership & Human Capital Employee Satisfaction Field Compliance Manager Annual Operational Review

1. FCMs are responsible for creating a workplace culture of professionalism where employees are treated with dignity and respect. Assess the manager's performance management in providing meaningful feedback to employees by completing performance reviews which encourage employee engagement and the timely completion of mid-year and annual performance evaluations. When reviewing this responsibility, determine if the manager is completing the required performance reviews timely.




| **Employee Satisfaction Components** | **Review Description** |
| :-: | :-: |
| Manager Feedback from Case Reviews | 1. Assess the accuracy of the manager's evaluative reviews, including content, scope, and amounts conducted monthly by frontline manager.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Verify the manager is performing the mandatory performance reviews for their employees in a timely manner. FCMs will also ensure documentation of these reviews is sufficient to effectively evaluate employees' performance and provide employee direction. Include any mandatory research and documentation (e.g. OIC IAT). This can be accomplished throughout the rating period while reviewing monthly review schedules, performance ratings, and EQRS reports. |
| Employee Performance File (EPF) | The EPF is a system consisting of all performance ratings and other performance-related records maintained on an employee in accordance with 5 CFR Part 293, Subpart D. The following documents must be maintained for four years.<br> <br>1. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition, Critical Job Elements (CJEs), and Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard (annually).<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Form 6774 may cover more than four periods.<br>      <br>2. Training and On the Job Instructor (OJI) documentation<br>      <br>3. Workload management reviews<br>      <br>4. Mid-year progress reviews conducted annually by the group manager<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Ensure managers have conducted midyear evaluations between the fifth and seventh month of the employee’s rating period.<br>      <br>5. Annual evaluations<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Review performance appraisals performed by the managers to ensure they are timely. Confirm employee annual performance evaluations are free of ROTERS.<br>      <br>6. Employee self-assessments |
| Addressing Employee Concerns | Address employee satisfaction by ensuring employees’ concerns are being addressed to facilitate effective and appropriate casework. Managers must be adhering to all areas of this handbook; addressing employee survey issues, reviewing team action plans and results; supporting employee recognition and taking appropriate actions when performance issues arise; employing appropriate EEO and Diversity practices; and adhering to employee development and training guidelines. |
| Communications | Review communications and group meeting minutes to ensure managers are effectively communicating the goals of the IRS, and Director. The manager should also be effectively communicating procedural and policy changes, casework techniques, and other issues that affect the overall quality of casework. |


**1.4.52.7.6.5.2** **(04-09-2025)**

###### Employee Engagement Field Compliance Manager Annual Operational Review

1. Each management responsibility includes a component of employee engagement. High levels of employee engagement directly correlate to the achievement of the SCOIC goals and objectives. The elements of employee engagement are communication, leadership, recognition, and professional growth. This component of the operational review assesses the manager’s actions which promote and enhance employee engagement. Evaluate if the manager is communicating performance expectations through regular meetings and written communications. Does the manager's communication process promote employee engagement and are issues raised by employees acted upon. Address the manager's employee development program within the group, identifying training needs, employee development opportunities and employee training. Developmental leadership opportunities should be made available to all group members.




| **Employee Engagement Components** | **Review Description** |
| :-: | :-: |
| Communications and Recognition | 1. Confirm managers are conducting regular meetings to communicate performance expectations by reviewing meeting minutes and other OIC CP and SCOIC communications issued. See if the meetings include roundtable discussions, and employees are given the opportunity to present issues or lead group meetings. Research the results of some of the recommendations.<br>      <br>2. Assess the manager’s employee recognition processes. The use of manager’s awards, time-off awards, e-cards, Form 6067, and Employee Performance Folder Record (letters from internal and external customers). |
| Leadership Opportunities | 1. Evaluate the use of Individual Development Plans (IDPs) in the group. Address whether the plans include actionable items and address if the items have been achieved.<br>      <br>2. Assess the effectiveness of how the manager supports the Frontline Manager Readiness Program (FLRP) and Frontline Manager Cadre program (if available). |
| Professional Growth | 1. Assess the training plans and training completion for each employee in the group.<br>      <br>2. Address the manager’s processes of affording OJI, classroom instructor detail assignments, or acting manager opportunities. |


**1.4.52.7.6.5.3** **(04-09-2025)**

###### **Customer Service and Collaboration-Customer Satisfaction Field Compliance Manager Annual Operational Review**

1. Customer satisfaction is measured by the customer’s perception and level of overall satisfaction with their interaction experience. Customers are both internal and external to the IRS. High customer satisfaction translates into work group efficiencies and improving the public’s trust in the tax system. Customer satisfaction is the cornerstone to the mission of the IRS to provide top quality service to taxpayer by helping them understand their tax responsibilities with integrity and fairness to all. Metrics used to measure customer satisfaction include quality, regulatory compliance, and customer feedback. Both managers and employees have opportunities to improve customer satisfaction by identifying issues or risks for resolution.




| **Customer Satisfaction Components** | **Review Description** |
| :-: | :-: |
| EQRS Analysis | 1. Compare cumulative quality attribute ratings cumulative reports from EQRS. Use the reports to identify the group strengths and opportunities for improvement.<br>      <br>2. Identify best practices and opportunities for improvement by reviewing the Top Ten Successes and Defects Report which identifies which attributes have the highest success and/or defect rates. FCMs use this report at the department level to identify trends. Remember that quality information is only statistically valid at the operation level. These reports are only a starting point for drawing conclusions about operation and team performance. |
| 1204 Certification | Section 1204 of the Restructuring and Reform Act of 1998 prohibits the IRS from using any ROTER to evaluate employees or to impose or suggest production quotas or goals, requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard and requires each appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner.<br> <br>1. Confirm the manager timely completed quarterly 1204 certifications. |
| Collection Due Process and Fair Tax Collection Practices | 1. Address the timeliness of transferring taxpayer’s CDP and OIC appeal requests to Appeals. Also address the timeliness of reassignment of cases returned by Appeals.<br>      <br>2. Assess the manager’s processes for addressing potential violations of Fair Tax Collection Practices. |
| Employee Case Documentation | Review case histories to determine documentation is appropriate and accurately describes identified issues, case progression, and supports the case decision. Include any mandatory research and documentation (e.g. OIC IAT). Ensuring employees are not violating taxpayer rights and they are performing timely and appropriate actions. |


**1.4.52.7.6.5.4** **(04-09-2025)**

###### Program Management Business Results Field Compliance Manager Annual Operational Review

1. The IRS assesses operational level business results through output or quantity measures and quality measures The IRS uses organizational measures as an analytical reference to determine whether the actions taken achieved the desired performance result. The focus of the evaluation of the business results responsibility is based on the actions taken and related accomplishments toward meeting the SCOIC goals. Communicate the areas of emphasis with your teams at the beginning of the fiscal year and monitor the team’s performance at reasonable intervals throughout the rating period.

2. The operational review should speak to the manager's effectiveness in managing the performance components. The narrative should address whether performance components have been met or not met. In instances where a performance component is not met, document recommended actions to the manager in that component. Align action items to the manager to improve the group’s performance in a specific component rather than action items for specific cases.




| **Business Results Components** | **Review Description** |
| :-: | :-: |
| Age of Inventory | Ensure managers are monitoring cases, approving inventory timely, and employees are taking timely actions to move inventory toward appropriate resolution. |
| Manager's Organizational Effectiveness | 1. Timeliness of controlled responses<br>      <br>2. Effectiveness of method for managing tasks or assignments<br>      <br>3. Completeness, thoroughness, timeliness of reviews, projects, etc. |
| Quality of Work Performed \[Paper and Phones (if applicable)\] | FCMs may utilize EQRS reports to identify error trends and ensure consistency among teams. The review of individual teams is intended to evaluate the effectiveness of the manager, assess the team’s performance and to provide guidance and direction intended to improve business results, foster effective casework and managerial engagement. |
| Timeliness of Work Performed | 1. Ensure customers are receiving timely and appropriate actions and receiving fair and equitable treatment to assist in resolving their offer submission(s). The manager should be addressing timely actions and follow-up contacts scheduled; ensuring case actions are appropriate and effective; ensuring timely responsiveness to taxpayer requests, as appropriate; and requests for supporting documentation are appropriate. |


**1.4.52.7.6.5.5** **(04-09-2025)**

###### Administrative/Compliance Review Field Compliance Manager Annual Operational Review

1. The Administrative/Compliance portion of the operational review provides an internal control for ensure certain processes or safeguards are performed. Similar to the components of the other operational review, the reviewer can perform this oversight at any time during the rating period. This documentation should include the action performed and address findings of non-compliance and/or need for improvement.




| **Administrative/Compliance Components** | **Review Description** |
| :-: | :-: |
| AOIC Maintenance | Ensure AOIC signatures and assignment numbers are being properly monitored and purged as appropriate by the managers. |
| Acknowledgement and Follow-up of Form 3210 | Document the process for performing quarterly reviews of Form 3210 control copies and reconciliation of acknowledgment copies. |
| CKGE Audits | For employees who have CKGE access, document your review of the manager’s required annual usage audit of the system. |
| Employee Inventories | Ensure inventories are being maintained within the SCOIC director’s / or the senior manager’s targeted range that ensure timely contact and efficient casework, while maintaining high levels of quality and customer service in the work performed by these employees, |
| Leave Administration | Ensure managers are approving leave and SETR appropriately and addressing leave issues when necessary. |
| Security Reviews | Review and document the manager’s performance of at least one after-hours security review. |


**1.4.52.7.6.6** **(04-09-2025)**

##### Operations Manager Annual Operational Review

1. OMs must conduct a minimum of one annual operational review on each of their DMs with follow-ups conducted as needed and appropriate. Document the review observations in a memorandum and share with the DMs within 30 days of the completion of the actual review.

2. Direct the operational review to current issues and goals for the program and provide meaningful feedback. The OM may incorporate some of the categories listed and may tailor the review(s) to the needs and issues of each department.

3. Include employee engagement activities in your review by conducting town halls and focus groups.


**1.4.52.7.6.6.1** **(04-09-2025)**

###### Leadership & Human Capital Employee Satisfaction Operations Manager Annual Operational Review

1. Operations managers are responsible for creating a workplace culture of professionalism where employees are treated with dignity and respect. Assess the manager's performance management in providing meaningful feedback to employees by completing performance reviews which encourage employee engagement and the timely completion of mid-year and annual performance evaluations. When reviewing this responsibility, determine if the manager is completing the required performance reviews timely.




| **Employee Satisfaction Components** | **Review Description** |
| :-: | :-: |
| Manager Feedback from Case Reviews | 1. Confirm the DM addressed the accuracy of the team manager’s evaluative reviews, including content, scope, and amounts conducted monthly by frontline team manager.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Verify the DM is monitoring to ensure the team managers are completing mandatory performance reviews for their employees in a timely manner. OMs will also confirm documentation of these reviews is sufficient to effectively evaluate employees' performance and provide employee direction. This can be accomplished throughout the rating period while reviewing monthly review schedules, performance ratings, and EQRS reports. |
| Employee Performance File (EPF) | Review a sampling of EPFs from teams and departments. The EPF is a system consisting of all performance ratings and other performance-related records maintained on an employee in accordance with 5 CFR Part 293, Subpart D. The following documents must be maintained for four years.<br> <br>1. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition/12450-A IRS Performance Management System - Manager Performance Agreement (whichever is applicable), Critical Job Elements (CJEs), and Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard (annually).<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Form 6774 may cover more than four periods.<br>      <br>2. Training and On the Job Instructor (OJI) documentation<br>      <br>3. Workload management reviews<br>      <br>4. Mid-year progress reviews conducted annually by the group manager<br>      <br>5. Annual evaluations<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Review performance appraisals performed by the DMs to ensure the midyear and annual evaluations are timely.<br>      <br>6. Employee self-assessments |
| Communication Including Department Meetings | Review communications and department meeting minutes to ensure managers are effectively communicating the goals of the IRS, OM, and Director. The manager should also be effectively communicating procedural and policy changes, casework techniques, and other issues that affect the overall quality of casework. |
| Addressing Employee Concerns | Address employee satisfaction by ensuring employees’ concerns are being addressed to facilitate effective and appropriate casework. Managers must be adhering to all areas of this handbook; addressing employee survey issues, reviewing group action plans and results; supporting employee recognition and taking appropriate actions when performance issues arise; employing appropriate EEO and Diversity practices; and adhering to employee development and training guidelines. |


**1.4.52.7.6.6.2** **(04-09-2025)**

###### Employee Engagement Operations Manager Annual Operational Review

1. Each management responsibility includes a component of employee engagement. High levels of employee engagement directly correlate to the achievement of the SCOIC goals and objectives. The elements of employee engagement are communication, leadership, recognition, and professional growth. This component of the operational review assesses the manager’s actions which promote and enhance employee engagement. Evaluate if the manager is communicating performance expectations through regular meetings and written communications. Does the manager's communication process promote employee engagement and are issues raised by employees acted upon? Address the manager's employee development program within the department, identifying training needs, employee development opportunities and employee training. Developmental leadership opportunities should be made available to all employees.




| **Employee Engagement Components** | **Review Description** |
| :-: | :-: |
| Communications and Recognition | 1. Review the operational reviews completed by the DMs.<br>      <br>2. Confirm all levels of managers are conducting regular meetings to communicate performance expectations by reviewing meeting minutes and other OIC CP and SCOIC communications issued. See if the meetings include roundtable discussions, and employees are given the opportunity to present issues or lead group meetings. Research the results of some of the recommendations.<br>      <br>3. Assess the manager’s employee recognition processes. The use of manager’s awards, time-off awards, e-cards, Form 6067, and Employee Performance Folder Record (letters from internal and external customers). |
| Leadership Opportunities | 1. Evaluate the use of Career Learning Plan (CLP)s in the group. Address whether the plans include actionable items and address if the items have been achieved.<br>      <br>2. Assess the effectiveness of how the manager supports the Frontline Manager Readiness Program (FLRP) and Frontline Manager Cadre program (if available), and Department Manager Readiness Program (DMRP). |
| Professional Growth | 1. Assess the training plans and training completion for each employee.<br>      <br>2. Address the manager’s processes of affording OJI, classroom instructor details or acting manager opportunities. |

2. Include employee engagement activities in your review by providing focus groups and a town hall.


**1.4.52.7.6.6.3** **(04-09-2025)**

###### Customer Service and Collaboration-Customer Satisfaction Operations Manager Annual Operational Review

1. Customer satisfaction is measured by the customer’s perception and level of overall satisfaction with their interaction experience. Customers are both internal and external to the IRS. High customer satisfaction translates into work group efficiencies and improving the public’s trust in the tax system. Customer satisfaction is the cornerstone to the mission of the IRS to provide top quality service to taxpayer by helping them understand their tax responsibilities with integrity and fairness to all. Metrics used to measure customer satisfaction include quality, regulatory compliance, and customer feedback. Both managers and employees have opportunities to improve customer satisfaction by identifying issues or risks for resolution.




| **Customer Satisfaction Components** | **Review Description** |
| :-: | :-: |
| EQRS Analysis | 1. Compare cumulative quality attribute ratings cumulative reports from EQRS. Use the reports to identify team and department strengths and opportunities for improvement.<br>      <br>2. Identify best practices and opportunities for improvement by reviewing the Top Ten Successes and Defects Report which identifies which attributes have the highest success and/or defect rates. DMs/OMs use this report at the department level to identify trends. Remember that quality information is only statistically valid at the operation level. These reports are only a starting point for drawing conclusions about operation and team performance. |
| 1204 Certification | Section 1204 of the Restructuring and Reform Act of 1998 prohibits the IRS from using any ROTER to evaluate employees or to impose or suggest production quotas or goals, requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard and requires each appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner.<br> <br>1. Confirm all managers timely completed quarterly 1204 certifications. |
| Collection Due Process and Fair Tax Collection Practices | 1. Address the timeliness of transferring taxpayer’s CDP and OIC appeal requests to Appeals. Also address the timeliness of reassignment of cases returned by Appeals.<br>      <br>2. Assess the DM’s processes for addressing potential violations of Fair Tax Collection Practices. |
| Employee Case Documentation | Confirm DM reviewed case histories to determine documentation is appropriate and accurately describes identified issues, case progression, and supports the case decision. Include any mandatory research and documentation (e.g. OIC IAT.) Ensuring employees are not violating taxpayer rights and they are performing timely and appropriate actions. |


**1.4.52.7.6.6.4** **(04-09-2025)**

###### Program Management Business Results Operations Manager Annual Operational Review

1. The IRS assesses operational level business results through output or quantity measures and quality measures The IRS uses organizational measures as an analytical reference to determine whether the actions taken achieved the desired performance result. The focus of the evaluation of the business results responsibility is based on the actions taken and related accomplishments toward meeting the SCOIC goals. Communicate the areas of emphasis with your departments at the beginning of the fiscal year and monitor the department’s performance at reasonable intervals throughout the rating period.

2. The operational review should speak to the DM’s effectiveness in managing the performance components. The narrative should address whether performance components have been met or not met. In instances where a performance component is not met, document recommended actions to the manager in that component. Align action items to the manager to improve the team’s performance in a specific component rather than action items for specific cases.




| **Business Results Components** | **Review Description** |
| :-: | :-: |
| Age of Inventory | Ensure DMs are utilizing inventory reports to monitor aged inventory. |
| Manager's Organizational Effectiveness | Record DMs status in items below.<br> <br>1. Timeliness of controlled responses<br>      <br>2. Effectiveness of method for managing tasks or assignments<br>      <br>3. Completeness, thoroughness, timeliness of reviews, projects, etc. |
| Quality of Work Performed \[Paper and Phones (if applicable)\] | OMs may utilize EQRS reports to identify error trends and ensure consistency among teams. The review of individual teams is intended to evaluate the effectiveness of the manager, assess the team’s performance and to provide guidance and direction intended to improve business results, foster effective casework and managerial engagement. |
| Timeliness of Work Performed | 1. Ensure customers are receiving timely and appropriate actions and receiving fair and equitable treatment to assist in resolving their offer submission(s). The DM should be addressing timely actions and follow-up contacts scheduled; ensuring case actions are appropriate and effective; ensuring timely responsiveness to taxpayer requests, as appropriate; and requests for supporting documentation are appropriate. |


**1.4.52.7.6.6.5** **(04-09-2025)**

###### Administrative/Compliance Review Operations Manager Annual Operational Review

1. The Administrative/Compliance portion of the operational review provides an internal control for ensure certain processes or safeguards are performed. Similar to the components of the other operational review, the reviewer can perform this oversight at any time during the rating period. This documentation should include the action performed and address findings of non-compliance and/or need for improvement.




| **Administrative/Compliance Components** | **Review Description** |
| :-: | :-: |
| AOIC Maintenance | Ensure AOIC signatures and assignment numbers are being properly monitored and purged as appropriate by all managers. |
| Acknowledgement and Follow-up of Form 3210 | Document the process for performing quarterly reviews of Form 3210 control copies and reconciliation of acknowledgment copies. |
| Employee Inventories | Ensure inventories are being maintained within the SCOIC director’s / or the senior manager’s targeted range that ensure timely contact and efficient casework, while maintaining high levels of quality and customer service in the work performed by these employees, |
| Leave Administration | Ensure DMs are addressing leave issues when necessary. |
| Security Reviews | Review and document the completion of at least one after-hours security review per team. |


**1.4.52.7.6.7** **(04-09-2025)**

##### Director, Specialty Collection Offer in Compromise Annual Operational Review

1. The Director should conduct an operational review of the OIC program at least once each fiscal year with timely follow-up reviews when appropriate to ensure that the management is contributing to employee satisfaction, customer satisfaction, and meeting business results.

2. Document the review findings in memorandum format and share with the appropriate OM/FCM within 30 days after the completion of the review. Provide a response timeframe for action items needing operation/territory completion.

3. The performance review should address the responsibilities of the OM/FCM as they relate to the achievement of the SCOIC program goals. The table below provides an optional outline for the review.




| **Review Component** | **Elements** |
| :-: | :-: |
| Leadership | 1. Review the operational reviews completed by the OMs and FCMs.<br>      <br>2. Include other engagement activities in your review such as side-by sides and a town hall.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Use the optional telephone jack (double plugging) on the employee's teleset for side-by-sides to shadow the employee and observe.<br>      <br>3. Address personnel actions to ensure proper processing and Labor Relations involvement where necessary. |
| Employee Satisfaction | 1. Review a sampling of EPFs from DMs and the FCMs for their group managers to ensure OM/FCM are providing appropriate feedback and maintaining the files in accordance with 5 CFR Part 293, Subpart D.<br>      <br>2. Assess whether FCMs and OMs address issues raised in the employee viewpoint survey.<br>      <br>3. Evaluate the Leadership Succession Review (LSR) status report for the operation/territory and assess developmental opportunities provided to LSR participants.<br>      <br>4. Evaluate presence of CLPs for employees and assess developmental opportunities provided to these employees based on the CLP. |
| Employee Engagement | 1. Confirm town hall meetings were held by OM/FCM. Review town hall and OM/FCM attended team/group meeting minutes.<br>      <br>2. Address the OM’s/FCM’s efforts to support the Frontline Manager Cadre (FCM), Frontline Manager Readiness program (FLRP) and Senior Manager Readiness Program (SMRP). |
| Customer Satisfaction | 1. Taxpayer Rights. Trends and analysis of EQRS Attribute 607, Taxpayer Rights and IRC Section 6304, Fair Tax Collection Practices.<br>      <br>2. 1204 Certifications on OMs/FCMs.<br>      <br>3. Compare National Quality (NQ) to EQRS cumulative results to identify opportunities for improvement in each measurement. |
| Business Results | 1. Progress with the business plan.<br>      <br>2. Statute controls and protecting the TIPRA statute.<br>      <br>3. Inventory assignment practices and inventory levels. |


**1.4.52.8** **(10-16-2023)**

### Telework

1. Telework is a program that permits your employees to work at home or at other approved locations other than the assigned post of duty.

2. There are three (3) forms of telework:



1. Frequent

2. Recurring

3. Ad Hoc


3. See Article 50, Section 1B of the National Agreement for more information about types of telework.

4. Ensure your employees have a signed and approved telework agreement in place before they begin to telework.


**1.4.52.8.1** **(04-09-2025)**

#### Managing in a Telework Environment

1. Managers are responsible for knowing the IRS telework policy. Below are some reminders to ensure compliance with IRM 6.800.2, IRS Telework Program, and the National Agreement. Managing an employee participating in telework is essentially no different than managing an employee in the office. Ensure that your actions are in compliance with any applicable local telework agreement (if one exists) as well as the National Agreement. The employee on telework is still held accountable for the rules of conduct, critical job elements, time and attendance, ethics, and all other regulations applicable to their position.

2. Telework is not a replacement for dependent/family care. Employees with a Telework Agreement are permitted to telework even if there are dependents/family at the telework site. However, any interruptions or time spent giving care to such individuals during the employee's tour of duty will not be considered hours of work. The employee is expected to account for such non-work hours as soon as practicable with appropriate leave (paid or unpaid) or other paid time off.

3. For an employee to remain on the telework program, they must:



1. Remain fully successful or above

2. Not be subject to a conduct investigation in which management has sufficient evidence of serious wrongdoing that would impact the integrity and efficiency of the IRS

3. Continue to stay in compliance with Article 50, Section 2 of the National Agreement.


4. If you determine that an employee's work appears to be degrading from fully successful or is below a fully successful rating, you should review Article 50 Section 2 of the National Agreement to determine whether the employee's continuation on telework is appropriate. This occurs when any CJE rating equals "2" or below. Ensure that your reasons for removal are well documented. This documentation may include but is not limited to EQRS Individual and/or cumulative feedback reports , Form 6850, or memoranda. You must ensure that the employee is aware of the situation and you should then monitor their work product closely and develop a plan for improving that employee’s work, just as you would for an employee not on telework. There is no prohibition per the National Agreement on any type of performance review following a period in which an employee has worked at their telework site. Reviews may include "time utilization" , or other performance based review. Ensure this also conforms with any applicable local area agreement as well. The types and amount of time expended on telework should be comparable to time in the office. For example, there should not be increased amounts of administrative or miscellaneous time, or increased time charged to cases with minimal actions taken.

5. You have the right to direct a telework employee to report to the office when necessary. For example, when having meetings, which include group meetings, case reviews, training, etc. This should be planned so that the employee has ample time to report to the office during their regular commute time. This is referenced under Article 50, Section 5A of the National Agreement.

6. Ensure that employees are responsive to all customers. They must check voicemail and email (when accessible) daily to ensure external as well as internal customers (including managers) receive responses timely. When on extended leave employees are expected to update their voicemail and out of office on applicable systems.


**1.4.52.9** **(04-09-2025)**

### Case Documentation, Protecting Taxpayer Rights, and Use of Statistical Data

1. This subsection discusses the proper guidelines managers and employees must follow when documenting case files, and the importance of observing the rights of the taxpayer at all times. It also covers your appropriate use of statistical data when conducting a review.


**1.4.52.9.1** **(11-17-2021)**

#### Case Documentation

1. Case documentation is a critical part of the offer process and must support the case decision. Specific guidance is discussed throughout all sections of IRM 5.8 but is specifically outlined in IRM 5.8.4.12, Documentation, IRM 5.8.11.6, Documentation and Verification, and IRM 5.19.24.26, Documentation.

2. Managers must document and ensure employees document conversations with taxpayers and representatives.

3. The need for accurate, complete, and high-quality case documentation is extremely important in the OIC program. Incomplete documentation will negatively affect subsequent case actions, the ability to review and evaluate case activity, actions by other employees, and Quality results.

4. All cases requiring managerial approval must include a manual or systemic ICS or AOIC history entry noting the manager approval. Managerial approvals of currently not collectible (see IRM 1.4.50 Exhibit 2) and Installment Agreement/Payroll Deductions must also be documented via a history entry in ICS or AOIC.



### Note:



Comments that could be considered "evaluative" in nature must not be entered in the ICS case history.


**1.4.52.9.2** **(04-09-2025)**

#### Protecting Taxpayer Rights

1. One of your primary responsibilities is to monitor employee practices and actions to make sure taxpayer rights are always observed during the offer investigation. Case reviews, as well as observations of interactions with taxpayers and/or their representatives should be used to assess the employee's performance in this area. The reasons of the proposed decision must be clearly documented and supported to make sure the taxpayer has been afforded all rights in accordance with the Taxpayer Bill of Rights (TBOR) as defined in paragraph (2) below. If taxpayer rights were violated or not afforded, document and share the case.

2. The Taxpayer Bill of Rights (TBOR), as listed below, is contained in IRC 7803(a)(3). Many taxpayers are often not aware of their rights and all the tools available to help them resolve issues. Each employee must be aware of those rights and adhere to affording those rights to all taxpayers. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see [Taxpayer Bill of Rights \| Internal Revenue Service](https://www.irs.gov/taxpayer-bill-of-rights).

3. Ensure that all employees are aware of the role of the Taxpayer Advocate Service (TAS), and that this information is properly communicated to taxpayers and representatives, as appropriate. TAS is an independent organization within the IRS that ensures tax problems, which have not been resolved through normal channels are promptly and fairly handled. There is at least one local Taxpayer Advocate in each state, the District of Columbia, and Puerto Rico, who is independent of the local IRS office. To determine if a case meets TAS criteria, see IRM 13.1.7.2.



### Note:



Access to TAS can be obtained by calling their toll-free number 877–777–4778, TTY/TTD 1–800–829–4059; calling or writing to the local Taxpayer Advocate whose address and phone number is listed in local telephone directories; researching Pub 1546, How to Get Help With Unresolved Tax Problems or visiting the [Taxpayer Advocate website](https://www.irs.gov/taxpayer-advocate).

4. Section 1203 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA '98) calls for the termination of any employee of the Internal Revenue Service if there is a final administrative or judicial determination that the employee willfully committed any act of omission described below:



1. Providing a sworn false statement in a "material matter" concerning a taxpayer.

2. Violating the constitutional rights of, or discriminating against, taxpayers or employees.

3. Falsifying or destroying documents to cover a mistake concerning a taxpayer.

4. Receiving a criminal conviction or civil judgment for assault or battery on a taxpayer or employee.

5. Violating the Internal Revenue Code, IRS regulations or policies to retaliate against or harass taxpayers or employees.

6. Misusing Internal Revenue Code section 6103 to conceal information from Congressional inquiry.

7. Failing to file a federal tax return on or before its due date, unless it is due to reasonable cause.

8. Understating federal tax liability, unless it is due to reasonable cause.

9. Threatening an audit for personal gain. See Document 11043, _RRA '98 Section 1203 All Employee Guide_, for more information on identifying and reporting possible violations of Section 1203.


**1.4.52.9.2.1** **(04-09-2025)**

##### Fair Tax Collection Practices

1. Internal Revenue Code (IRC) 6304, Fair Tax Collection Practices, imposes certain restrictions with respect to tax collection. During a case review or upon receiving a complaint from a taxpayer, you may identify a potential violation of those restrictions. Potential employee violations of the IRC 6304 must be reported to the local Labor Relations specialist by the close of the next business day following notification of the alleged violation.

2. To ensure collected data is complete and accurate, use the following issue codes when reporting the potential violation. Labor Relations uses these codes for tracking on the Automated Labor and Employee Relations Tracking System (ALERTS). These codes are valid for Collection employees **alleged**Fair Tax Collection Practices violations only.




| ALERTS | Alert Definition |
| :-: | :-: |
| 141- 6304 | CONTACT TP UNUSUAL TIME/PLACE -Contacting a taxpayer before 8:00 am or after 9:00 pm, or at an unusual location or time, or location known, or which should be known to be inconvenient to the taxpayer. |
| 142- 6304 | CONTACT TP W/O REPRESENTATIVE -Contacting a taxpayer directly without the consent of the taxpayer’s power of attorney. |
| 143- 6304 | CONTACT AT TP EMPLOYER; PROHIBITED - Contacting a taxpayer at their place of employment when it is known or should be known that the taxpayer’s employer prohibits the taxpayer from receiving such communication. |
| 144- 6304 | TAXPAYER HARASSMENT IN A TAX COLLECTION MATTER - Any allegation of taxpayer harassment should be reviewed along with IRC 6304 because the provision is intended to be applied in a general manner when evaluating the alleged employee misconduct. Conduct which is intended to harass a taxpayer or conduct which uses or threatens to use violence or harm is an absolute violation of the IRC. |
| 145- 6304 | TAXPAYER ABUSE IN A TAX COLLECTION MATTER - Any allegation of taxpayer abuse should be reviewed along with IRC 6304 because the provision is intended to be applied in a general manner when evaluating the alleged employee misconduct. The use of obscene or profane language towards a taxpayer is an absolute violation of the IRC. |
| 146- 6304 | CONTINUOUS PH / HARASSMENT -Causing a taxpayer’s telephone to ring continuously with harassing intent. |
| 147- 6304 | PH CALL W/O ID DISCLOSURE -Contacting a taxpayer by telephone without providing a meaningful disclosure of the IRS employee’s identity. |

3. You are not required to report instances to Labor Relations where you have determined the employee’s conduct is not a potential violation of IRC 6304, Fair Tax Collection Practices. Document the history with your discussions or correspondence associated with the complainant in the history. Example: You receive an allegation of employee misconduct from a taxpayer’s authorized representative. The representative asserts the employee’s warning of a potential return of the OIC if a deadline to submit documentation is missed constitutes harassing behavior. You contact the representative and explain the employee’s warning of consequences is intended to advise of possible actions if the representative is unresponsive to the employee’s request and is not considered harassing behavior. Document this contact in the history. This alleged violation of FTCP is not required to be reported to Labor Relations.

4. If a potential violation is confirmed, do not document the case history with your decision to forward the complaint to Labor Relations.

5. Work with your LR specialist to determine the next appropriate action.


**1.4.52.9.3** **(11-17-2021)**

#### Use of Statistical Data

1. IRM 1.5.2, Uses of Section 1204 Statistics, provides guidance to prevent use of statistics to evaluate employees, or impose or suggest production quotas or goals with respect to such employees.

2. You are prohibited from using Records of Tax Enforcement Results (ROTERs) to evaluate any employee who exercises appropriate judgment with regard to determining tax liability or ability to pay. ROTERs are defined as a figure resulting from the recordation, accumulation, tabulation, or mathematical analysis that is directly related to producing a tax enforcement result. This prohibition includes:



   - Self-assessments

   - Awards narratives

   - Case and/or workload reviews

   - Performance plans

   - Narrative feedback to evaluations


3. You are also prohibited from using ROTERs to impose or suggest production goals or quotas for employees or groups of employees. Examples of prohibited ROTERs for OIC collection employees include:



   - Number of OICs recommended for acceptance or rejection

   - Dollars compromised

   - Number of closed OICs


4. For more specific information see IRM 1.5.1, The IRS Balanced Performance Measurement System, and IRM 1.5.2, Uses of Section 1204 Statistics.

5. A tax enforcement result (TER) is the outcome produced by an employee’s exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws. Each appropriate supervisor will certify quarterly by letter to the Commissioner of Internal Revenue whether or not TERs were being used in a manner prohibited by Section 1204(a). See IRM 1.5.2.10, Tax Enforcement Results, for additional information.


**1.4.52.10** **(03-22-2019)**

### Tax Examiners in the OIC Program

1. Based on the OIC program's continued priority, reenergized focus on case cycle time, and the continued need for managerial-specialist interaction to ensure proper and effective case progression, a TE plays a very special role in the program.


**1.4.52.10.1** **(04-09-2025)**

#### OIC Field Group Responsibilities for the Tax Examiner

1. The group TE’s responsibilities may consist of the following:




| **Potential Group TE Responsibilities** |
| :-: |
| Analyze all OIC receipts to ensure transfer is appropriate. |
| Accept transfers on the AOIC system and make appropriate group assignments on AOIC and ICS inventory systems based on established procedures and corporate inventory approach. |
| Interact with COIC site personnel to check on the status of transfers. |
| Monitor transfers in transit status. |
| Initiate transfer of offer cases to other office(s), when appropriate. |
| Review IDRS transcripts to ensure that the delinquent modules on IDRS match the compromise periods listed on Form 656, Offer in Compromise. |
| Contact taxpayers and/or their representative to correct mismatches, when necessary. |
| Input appropriate modules on AOIC for systemic generation of Status 71 on corresponding IDRS modules. |
| Analyze all corresponding taxpayer IDRS transcripts, determine assessment dates for each applicable module, and input information on the AOIC MFT screen. |
| Generate AOIC Transaction Error Listing. This report can be printed daily but minimally requires weekly reconciliation to ensure IDRS modules and respective notice/collection status codes match AOIC. |
| Determine when manual input is required on accounts and perform action to input TC 480, 482, 483, and Status 71, when applicable. |
| Generate and mail return letters. |
| Screen all incoming cases for imminent ASED and TIPRA statutes. |
| Screen all incoming cases for filing and payment compliance. |
| Screen all incoming cases for compliance with periodic payment requirements. |
| Input all corresponding modules on ICS and establish CIPs to generate ASED Inventory Listings. |
| Create and monitor Other Investigation (OI) controls to ensure timely actions are taken to protect imminent statute. |
| Handle all incoming taxpayer/practitioner phone calls regarding the status of their OIC, as well as any other issues that require knowledge of Service-wide policy and thorough familiarity with OIC program guidelines. |
| Monitor casework for timely disposition based on established CDP procedural guidelines. |
| Review cases to ensure they meet the appropriate criteria for transfer to Field Collection. |
| Ship closed cases to the Federal Records Center (FRC). See _IRM 1.4.52.12_. |

2. Form 2209, _(Courtesy Investigation)_



1. Contact taxpayers and/or their representative and takes the appropriate action to resolve any issues.

2. Determine any necessary financial information needed and/or delinquent returns and makes the appropriate taxpayer demand.

3. Establish proper group controls to monitor taxpayer responses and issues default recommendations, when appropriate.

4. Analyze financial documents and information and processes delinquent returns.

5. Complete OI and issues appropriate disposition recommendation for managerial approval.


3. Reconcile and monitor group controls as listed below:



1. Cases assigned to the FOIC territory, but not received or not accepted (Source: _Area Office Menu, AOIC Offers, Accept Transfer_)

2. Closed, accepted cases not validated or released (Source: _AOIC Office Menu, AOIC Offers, Validate & Release)_

3. ASED controls

4. CDP assignments

5. Appeal 30-day rejection hold file

6. AOIC Transaction Listing

7. Courtesy Investigations (OIs)


4. Perform quality reviews case closure actions as listed below:




| **Quality Review Case Closure Actions** |
| :-: |
| Complete installment agreements, currently non-collectible, and adjustment forms, as requested by the GM and/or OS. |
| Process closed cases in accordance with procedures defined in IRM 5.8.7.10, Alternative Resolutions and Collection Assignment. |
| Monitor appeals process, if applicable, before requesting reversal of TC 480 and processing of corresponding form (e.g., Form 433-D, 53, 3870, etc.). |
| Quality review all accepted, rejected, returned, and withdrawn case files to ensure all letters and forms have appropriate signatures, and inputs appropriate disposition codes on AOIC and ICS systems. |
| Analyze Form 656, Offer in Compromise, to determine if all periods have been listed appropriately for all dispositions (except acceptances). |
| Process requests for NFTL when requested by the manager or OS. |
| Analyze case files to ensure the IAR has completed mandatory review on rejections. |
| Mail the Rejection Letter to the taxpayer and/or practitioner and monitors Rejection 30-Day Appeal files. |
| Review taxpayer and/or practitioner's written request for appeal for perfection issues and reassigns to the OS for review. |
| Upon request, forward cases to Appeals for review, reassign cases to Appeals on AOIC, and monitor Form 2515, Record of Offer in Compromise, until the OIC case is returned from Appeals. |
| Input the appropriate disposition code on AOIC and ICS, including those cases where the taxpayer does not exercise their right to appeal. |
| Upon receipt of a case from Appeals, analyze the case file to ensure all necessary correspondence is contained and verify the case is closed on AOIC with appropriate closing letter dates. |
| Mail all necessary closing AOIC letters and forms to taxpayers and/or practitioners, as appropriate. |
| Handle all taxpayer and/or practitioner inquiries that may be generated as a result of correspondence. |
| Monitor AOIC NQRS Sample Reports on a weekly basis. |
| Strip closed case files as defined in IRM 5.8.7.12, Closed File Retention, and IRM 5.8.8.10, Processing the Closed Offer File, and transmit selected offer cases for NQRS review.<br> <br>### Note:<br>See IRM 5.13.1.9.2, OIC Case Selection, for additional information. |
| Timely close accounts on AOIC and ICS databases. |
| Initiate AOIC Closed Case Validation Process. |
| Determine, the appropriate MOIC location that will monitor offer acceptance terms and mails required documents based procedures in IRM 5.8.8, Acceptance Processing. |
| Timely analyze and work all taxpayer lien release requests and escrow demands. |
| Receive and timely resolve all taxpayer and/or practitioner inquiries regarding the status of offer deposits that have not been refunded. |
| Review all rejections, returns, and withdrawn offers for completion and ships the closed cases to FRC, including loading FRC information on the AOIC database. |

5. Perform post-closure case action activities as listed below:



1. Receive and resolve all taxpayer and/or practitioner telephone inquiries involving OICs and/or non-OIC related calls by checking applicable systems (e.g., IDRS, AOIC, etc.) and/or redirects the call to the appropriate Service personnel.

2. Analyze accounts on AOIC and IDRS systems to resolve issues involving misapplied payments.

3. Communicate directly with MOIC campuses to resolve problems involving misapplied payments, late payments, changes in taxpayer financial conditions, etc.

4. Request manual refunds from MOIC when contacted by the taxpayer and/or practitioner, when appropriate.

5. Analyze and resolve M-Y freeze issues on accepted offers when contacted by the taxpayer and/or practitioner.

6. Review closed, rejected, and withdrawn offers from Appeals to determine if an OI should be issued to Field Collection in accordance with current field transfer procedures.


**1.4.52.10.2** **(04-09-2025)**

#### MOIC Tax Examiner Duties

01. Process accepted offers with the case file on AOIC by reviewing and comparing Form 656 /(Amended) Form 656 and AOIC to ensure all tax modules are included. If the offer case file is not provided see IRM 5.19.7.3.

02. Initial case review and documentation are required as each case is received into the tax examiner inventory and/or re-assigned to another tax examiner’s inventory.

03. Incoming OICs must be accepted and updated on AOIC within 25 days of MOIC receipt (NW status) when NFTLs are present to ensure timely release of liens on all full paid offers. On offers where no NFTLs are present, the OIC should be accepted and updated on AOIC within 30 days.

04. Review incoming offers to determine if manual monitoring or special handling is required.

05. Review AOIC Transaction Listing for errors and resolve.

06. Review and resolve any errors on the AOIC Daily Transaction Listing.

07. Address the application fee.

08. Perform mirroring actions when required.

09. Timely release NFTLs when applicable.

10. Timely response to TAS OAR requests.


**1.4.52.11** **(04-09-2025)**

### Group Secretaries/Administrative Assistants in the OIC Program

1. A group secretary/administrative assistant plays a key role in an OIC group. As a support clerical employee, they assist the GM in all administrative assignments, and also handle the numerous clerical processes that are involved in managing an OIC group operation. Below are their tasks (not all inclusive).




| **List of Tasks** |
| :-: |
| Schedule meetings and coordinate travel plans. |
| Handle budget issues. |
| Handle all issues involving time and/or leave. |
| Verify employee time on ICS ENTITY on a weekly basis. |
| File all documents per established group policies. |
| Handle all incoming calls for the GM and direct appropriately. |
| Order team/group supplies. |
| Assign casework to employees upon the request of the manager. |
| Reassign OICs from hold files to employees upon the request of the manager. |
| Control and respond to Form 3210, Document Transmittal, on all incoming work. |
| Forward rejected OIC case files to the IAR and change assignment on AOIC to the IAR. |
| Make appropriate copies of casework for NQRS review.<br> <br>### Note:<br>See IRM 5.13.1.9.2 for additional information on OIC case selection. |
| Mail taxpayer correspondence, and provide assistance to the TE, as needed. |
| Process CDP requests to the appropriate function for TC 520 input. See IRM 5.1.9.3.3, Processing CDP and EH Requests or IRM 5.8.4, Investigation. |
| Retrieve the ICS/ENTITY Report on a monthly basis. |
| Retrieve the OS Inventory Report from AOIC and ICS on a weekly basis. |
| Match ICS and AOIC inventory for each OS on a monthly basis. |
| Process all Form 795, Daily Report of Collection Activity. |
| Correct correspondence, as required by the GM. |
| Take and distribute all group meeting minutes. |
| Schedule and reserve conference rooms for group meetings, upon request. |
| Provide receptionist assistance, upon request. |

2. In some situations, due to employee location the manager may delegate appropriate tasks from the above list from the secretary/administrative assistant to the tax examiner.


**1.4.52.12** **(04-09-2025)**

### Shipment of Closed Cases to Federal Records Center (FRC)

1. The PE/clerk/TE must follow procedures in IRM 5.8.7.12.1, Shipment of Closed Cases to Federal Records Center, and IRM 5.8.8.16, Forwarding Case Files to the Federal Record Center (FRC), depending on the type of closure.



### Note:



Managers must ensure closed case retention and FRC guidelines are followed.

2. Procedures in IRM 1.15.4, Retiring and Requesting Records, must be followed when mailing closed cases to the FRC. Document 12990, Records Control Schedule (RCS) 28, Tax Administration - Collection, Item 50, allows retention of closed files until there is no longer a business need to retain them at the local level.

3. Based on the “business need” provision, and as a general rule, closed COIC and FOIC files (other than acceptances) are to be retained in a local office for a period of no less than six months, or for a longer period, should there be a business need. After this time period case files should be retired to the Federal Records Center (FRC).

4. All FRC information must be loaded on the AOIC Tracking screen for each case. This screen includes the OIC number, accession number, box number, FRC date and location. Refer to the AOIC Course User's Guide for instructions on loading information on the AOIC FRC Tracking screen. If the FRC AOIC Tracking system is not functioning then input the accession number, box number, date sent to FRC, and FRC location into AOIC Remarks.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-052#addtoany "Show all")

A2A