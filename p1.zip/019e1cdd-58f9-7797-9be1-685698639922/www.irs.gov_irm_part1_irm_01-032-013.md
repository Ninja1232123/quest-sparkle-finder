---
url: "https://www.irs.gov/irm/part1/irm_01-032-013"
title: "1.32.13 Relocation Services Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-013#main-content)

- 1.32.13  [Relocation Services Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963549248)
  - 1.32.13.1  [Program Scope and Objective](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963658608)
    - 1.32.13.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963673664)
    - 1.32.13.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963669424)
    - 1.32.13.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963666112)
      - 1.32.13.1.3.1  [CFO](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963731728)
      - 1.32.13.1.3.2  [Senior Associate CFO for Financial Management](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963729984)
      - 1.32.13.1.3.3  [Travel Management](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963727648)
      - 1.32.13.1.3.4  [Travel Operations](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963725952)
      - 1.32.13.1.3.5  [Travel Review](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963722368)
      - 1.32.13.1.3.6  [Relocating Employee](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963718336)
      - 1.32.13.1.3.7  [Business Unit](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963540784)
      - 1.32.13.1.3.8  [CFO Relocation Coordinator](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963536992)
      - 1.32.13.1.3.9  [CFO Relocation Technician](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963532336)
    - 1.32.13.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963529312)
    - 1.32.13.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963521936)
    - 1.32.13.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963508096)
    - 1.32.13.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963462032)
    - 1.32.13.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963446624)
  - 1.32.13.2  [General Rules](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963444864)
  - 1.32.13.3  [Eligibility](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963431888)
  - 1.32.13.4  [Requesting Use of the Relocation Services Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963237072)
  - 1.32.13.5  [Residence Eligibility and Title Requirements](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963218192)
  - 1.32.13.6  [Exclusion Clause](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963203232)
  - 1.32.13.7  [Pre-Counseling Services](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963194032)
  - 1.32.13.8  [Broker's Market Analysis](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963189664)
  - 1.32.13.9  [Home Marketing Assistance](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963186272)
  - 1.32.13.10  [Home Sale Assistance Services](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963180592)
  - 1.32.13.11  [Guaranteed Home Sale Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963169552)
    - 1.32.13.11.1  [Choosing an Appraiser](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963167312)
    - 1.32.13.11.2  [Appraisal Process](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963159872)
    - 1.32.13.11.3  [Relocation Services Contractor's Appraisal Review](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963146240)
    - 1.32.13.11.4  [Guaranteed Home Sale Offer](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963143728)
    - 1.32.13.11.5  [Inspection and Repairs](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963135232)
    - 1.32.13.11.6  [Request for Reconsideration](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963126080)
    - 1.32.13.11.7  [Vacating the Property](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963117920)
    - 1.32.13.11.8  [Responsibility for Mortgage](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963111808)
    - 1.32.13.11.9  [Disbursement of Equity](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963107488)
    - 1.32.13.11.10  [Equity Advance](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963100368)
    - 1.32.13.11.11  [Equity Deficit](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963098384)
  - 1.32.13.12  [Options with an Independent Offer](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963095216)
    - 1.32.13.12.1  [Amend from Zero Sale Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963085648)
    - 1.32.13.12.2  [Amended Value Sale Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963082864)
  - 1.32.13.13  [Closing Assistance Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963075680)
  - 1.32.13.14  [Rental Property Management Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963072208)
    - 1.32.13.14.1  [Determining the Market Rental Value for Your Home](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963052784)
    - 1.32.13.14.2  [Property Insurance](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963050672)
    - 1.32.13.14.3  [Securing and Screening Tenants](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963048640)
    - 1.32.13.14.4  [Negotiating and Managing the Lease](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963046256)
    - 1.32.13.14.5  [Account Reconciliation](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963041072)
    - 1.32.13.14.6  [Property Inspections](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963038336)
  - 1.32.13.15  [Destination Services Program](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963030992)
    - 1.32.13.15.1  [Home Renters Assistance](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963024224)
    - 1.32.13.15.2  [Home Buyers Assistance](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963021712)
    - 1.32.13.15.3  [Mortgage Counseling](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963019136)
  - 1.32.13.16  [Mortgage Pre-Qualification](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963016128)
  - 1.32.13.17  [Exhibit I, Summary of Services](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112963010800)
  - 1.32.13.18  [Exhibit II, Timeline of Key Relocation Actions](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112962977248)
  - 1.32.13.19  [Exhibit III, Difference Between a Mortgage Appraisal and a Relocation Appraisal](https://www.irs.gov/irm/part1/irm_01-032-013#idm140112962955376)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 13. Relocation Services Program

* * *

## 1.32.13 Relocation Services Program

#### Manual Transmittal

January 15, 2025

#### Purpose

(1) This transmits revised IRM 1.32.13, Servicewide Travel Policies and Procedures, Relocation Services Program.

#### Material Changes

(1) IRM 1.32.13.1.3(1)(b), Responsibilities, updated title to Senior Associate CFO for Financial Management due to CFO reorganization. Updated title throughout the IRM.

(2) IRM 1.32.13.1.3(1)(d), Responsibilities, updated title to Travel Operations due to CFO reorganization.

(3) IRM 1.32.13.1.3(1)(e), Responsibilities, updated title to Travel Review due to CFO reorganization.

(4) IRM 1.32.13.1.3.4(1), Travel Operations, added to add duties of Travel Operations.

(5) IRM 1.32.13.1.3.5, Travel Policy and Review, updated to Travel Review due to CFO reorganization.

(6) IRM 1.32.13.1.7, Acronyms, updated acronyms.

(7) IRM 1.32.13.2(10), General Rules, updated section to state that requests and memorandums with the concurrence of the business unit Head of Office must be submitted to all Relocation Coordinators for review. Final review will be by the Deputy Commissioner for approval or disapproval.

(8) IRM 1.32.13.4(2), Requesting Use of the Relocations Services Program, updated section to state the routing review and approval process of basic plus relocation allowance program requests. Final review will be by the Senior Associate CFO for Financial Management for approval or disapproval.

(9) IRM 1.32.13.14(6), Rental Property Management Program, updated section to state the routing review and approval process for approved basic plus Relocation allowance program requests. Final approval will be by the Senior Associate CFO for Financial Management.

(10) IRM 1.32.13.14(7), Rental Property Management Program, Added note from Information Technology (IT), referencing their IRMs 10.8.1 and IRM 10.8.26 for relocating IT equipment outside of the Continental United States.

(11) Replaced the Basic Plus mailbox \*CFO Relocation Basic Plus Request with the relocation coordinator throughout the IRM.

(12) This revision includes changes throughout the document updating minor editorial changes to include grammar, spelling and updated broken links.

#### Effect on Other Documents

IRM 1.32.13, dated April 27, 2022, is superseded.

#### Audience

All business units

#### Effective Date

(01-15-2025)

Teresa R. Hunter

Chief Financial Officer

**1.32.13.1** **(04-14-2020)**

### Program Scope and Objective

1. Purpose: This IRM provides guidance for ensuring employees meet the criteria when using the Relocation Services Program and helps them identify the resources available to assist them with their home sale. Employees should use this IRM as a reference when reviewing their options under the relocation services contract with the CFO relocation coordinator.

2. Audience: Business units

3. Policy Owner: CFO, Financial Management

4. Program Owner: Financial Management, Travel Management office develops and maintains this IRM.

5. Primary Stakeholders: The primary stakeholders are employees relocating domestically and internationally who have been authorized relocation allowances in the interest of the government.

6. Program Goals: The goals of this IRM are to ensure that IRS employees receive clear guidance on allowances under the Relocation Services Program and comply with the policies.


**1.32.13.1.1** **(01-15-2025)**

#### Background

1. The IRS provides relocation services through a contract under the government's Relocation Services Program. Using home sale assistance services, such as rental property management, pre-counseling services, and home marketing assistance, offered by the relocation services contractor is not an entitlement and must be approved by the Senior Associate CFO for Financial Management.

2. Under the Relocation Services Program, the government pays a fee for services provided by the relocation contract. The type of service used and the property selling price determine the amount of the fee the IRS pays.

3. See IRM 1.32.13, Exhibit I, Summary of Services, for a list of services available through the relocation services contractor.

4. See IRM 1.32.13, Exhibit II, Timeline for Key Relocation Actions, for a list of actions that occur during the sale of an employee’s home.

5. See IRM 1.32.13, Exhibit III, Difference Between a Mortgage Appraisal and a Relocation Appraisal, for a list of differences in the two types of appraisals.


**1.32.13.1.2** **(04-14-2020)**

#### Authorities

1. 5 U.S. Code (USC) Section 5724(c), [Relocation Services](https://uscode.house.gov/browse/prelim@title5/part3/subpartD/chapter57/subchapter2&edition=prelim)

2. Title 41, Code of Federal Regulations (CFR), Chapters 300-304, [Federal Travel Regulation (FTR)](https://www.ecfr.gov/current/title-41/subtitle-F)


**1.32.13.1.3** **(01-15-2025)**

#### Responsibilities

1. This section provides responsibilities for the following:



1. CFO

2. Senior Associate CFO for Financial Management

3. Travel Management

4. Travel Operations

5. Travel Review

6. Relocating employee

7. Business unit

8. CFO relocation coordinator

9. CFO relocation technician


**1.32.13.1.3.1** **(04-14-2020)**

##### CFO

1. The CFO is responsible for overseeing policies and procedures for, and employee compliance with, using the Relocation Services Program and ensuring employees meet the criteria.


**1.32.13.1.3.2** **(01-15-2025)**

##### Senior Associate CFO for Financial Management

1. The Senior Associate CFO for Financial Management is responsible for establishing and maintaining policies and controls to ensure compliance in the Relocation Services Program.

2. The Senior Associate CFO for Financial Management is responsible for approving requests to use the Relocation Services Program.


**1.32.13.1.3.3** **(04-14-2020)**

##### Travel Management

1. Travel Management is responsible for developing and issuing Relocation Services Program policy.


**1.32.13.1.3.4** **(01-15-2025)**

##### Travel Operations

1. Travel Operations is responsible for:



1. Coordinating contractual services for allowances under the Relocation Services Program.

2. Providing guidance on elevated issues to CFO relocation coordinators, relocating employees and business units on allowances under the Relocation Services Program.

3. Ensuring requests for using the Relocation Services Program are compliant with the IRM’s policies.


**1.32.13.1.3.5** **(01-15-2025)**

##### Travel Review

1. Travel Review is responsible for:



1. Authoring IRM 1.32.13, Relocation Services Program.

2. Coordinating contractual services for allowances under the Relocation Services Program.

3. Providing guidance on elevated issues to CFO relocation coordinators, relocating employees and business units on allowances under the Relocation Services Program.

4. Ensuring requests for using the Relocation Services Program are compliant with the IRM’s policies.


**1.32.13.1.3.6** **(04-14-2020)**

##### Relocating Employee

1. The relocating employee is responsible for:



1. Meeting the prerequisite for the guaranteed home sale marketing period.

2. Following this IRM’s policy for using the Relocation Services Program.

3. Completing Form 8518, Request for Use of the Relocation Services Contract.

4. Receiving approval for using the Relocation Services Program prior to incurring expenses.

5. Paying the tax withholding on property management reimbursements in accordance with IRM 1.32.12, IRS Relocation Travel Guide, Relocation Debts.


**1.32.13.1.3.7** **(01-15-2025)**

##### Business Unit

1. The business unit is responsible for:



1. Following this IRM’s policies for using the Relocation Services Program.

2. Submitting the approved relocation authorization amendment for basic plus moving expenses and approved Form 8518, Request for Use of the Relocation Services Contract, to the CFO relocation coordinator.

3. Ensuring the requests for basic plus relocation allowances include all the required documentation prior to submitting to the relocation coordinator for approval.


**1.32.13.1.3.8** **(04-14-2020)**

##### CFO Relocation Coordinator

1. The CFO relocation coordinator is responsible for:



1. Counseling and assisting relocating employees with allowances under the Relocation Services Program.

2. Assisting the business unit with preparing the relocation authorization amendment for basic plus moving expenses allowed under the relocation services contract and completing Form 8518, Request for Use of the Relocation Services Contract.

3. Initiating the approved use of the relocation services allowance with the provider.

4. Reviewing and signing receipt and acceptance on the vendor invoice for allowances under the Relocation Services Program and providing the invoice to the CFO relocation technician.

5. Establishing employee billing documents in accordance with IRM 1.32.12, IRS Relocation Travel Guide, Relocation Debts.


**1.32.13.1.3.9** **(04-14-2020)**

##### CFO Relocation Technician

1. The CFO relocation technician is responsible for:



1. Reviewing and paying relocation services invoices.

2. Processing W-2s for taxable property management reimbursements.


**1.32.13.1.4** **(04-14-2020)**

#### Program Management and Review

1. Internal controls are established to ensure the use of the Relocation Services Program is managed effectively.

2. Program reports: The IRS completes the following reports:



1. Aging unliquidated relocation obligations incurred under the Relocation Services Program.

2. Open relocation voucher and invoice report.

3. General Services Administration (GSA) Relocation Data Call Report.


3. In accordance with 5 USC 5707 (c), [Regulations and Reports](https://www.govinfo.gov/app/details/USCODE-2011-title5/USCODE-2011-title5-partIII-subpartD-chap57-subchapI-sec5707), all agencies that spend more than $5 million on travel and relocation must provide an annual report to GSA by November 30. The GSA provides the required data and report format including data elements for using the Relocation Services Program.

4. Program effectiveness: This IRM provides policy guidance on using the Relocation Services Program. The CFO Travel Operations office completes the following to ensure the program is managed effectively:



1. Reviews 100% of invoices for accuracy and compliance with prompt pay guidelines.

2. Surveys customers quarterly, soliciting feedback from relocating employees on the relocation services contract.


**1.32.13.1.5** **(04-14-2020)**

#### Program Controls

1. Travel Operations reviews for effectiveness by:



1. Conducting a weekly review of all Relocation Services Program invoices to ensure compliance with prompt payment processing guidelines.

2. Performing a quarterly review of relocation services invoices for timely receipt, processing and de-obligating excess amounts.

3. Reviewing relocation reimbursements and reconciling payments annually to ensure tax withholding and taxable income are recorded properly.


2. The chart below describes the internal controls in place for using the Relocation Services Program:




| **Control** | **Control Description** |
| --- | --- |
| Delegation of Authority | Delegation Order 1-3, Authorization of Employee Relocation Allowances and Approval of Relocation Reimbursements. |
| Funding requirements | Relocation authorization amendments for basic plus moving expenses must be approved for using the Relocation Services Program. |
| Manual quality invoice | Each Relocation Services Program invoice is reviewed with the approved relocation authorization amendment for basic plus moving expenses for accuracy and compliance. |
| moveLINQ access | User profiles for moveLINQ access are appropriate for job duties. |
| Separation of duties | Approving officials are responsible for following the delegation order when approving basic plus moving expenses. CFO relocation coordinators counsel employees and establish relocation authorizations and authorization amendments. The CFO analysts review and approve relocation documents in moveLINQ and the Integrated Financial System (IFS). The CFO relocation technicians review relocation documents for accuracy, input data into moveLINQ and IFS, and provide reports of tax withholding to relocating employees. |


**1.32.13.1.6** **(04-14-2020)**

#### Terms/Definitions

1. The following terms and definitions apply to this program.



01. **Acceptance period** \- A fixed time period an employee has to accept an offer, beginning when the employee verbally receives the Guaranteed Home Sale (GHS) offer and lasting until the date the employee accepts the offer or until it expires, whichever is sooner. This is typically 60 days from the date the employee received the GHS offer.

02. **Adjusted sales price** \- The indicated price of a comparable property after adjustments have been made to account for differences between comparable and subject properties.

03. **Amend from zero sale** \- A sale that occurs when the employee receives an acceptable bona fide offer from a qualified buyer prior to completion of the appraisal process by the relocation services contractor.

04. **Amended value sale** \- A sale that occurs when the employee receives an acceptable bona fide offer from a qualified buyer after the relocation services contractor has completed the appraisal process. The contractor amends its offer to match the qualified buyer's offer. If the sale to the outside buyer falls through, the GHS offer to the employee remains valid.

05. **Anticipated sales price** \- The price at which a property would likely sell, if exposed to the market for a reasonable period of time in _as is_ condition, where there is cash payment or its equivalent and where both parties are well informed and acting in what they consider their best interests.

06. **Appraisal** \- An estimate (opinion) of value prepared by an independent professional who is familiar with all the factors that may affect the sale.

07. **Appraisal specialist** \- A relocation services contract employee who is responsible for ordering and reviewing the property’s appraisals.

08. **Appraised value** \- A sales contract extended to an employee to buy the employee's property based on the average of a specific number of appraisals.

09. **As is condition** \- The condition of the property at the time of the Broker’s Market Analysis (BMA) and/or appraisal.

10. **CFO relocation coordinator** \- The primary employee that provides relocation benefit counseling to relocating employees.

11. **Bona fide offer** \- An offer that is not contingent upon the sale of the potential buyer’s home and that can reasonably be expected to go to settlement at its original terms and conditions from an able and willing buyer within 60 days of executing the offer agreement. The offer will not contain any contingencies except those providing that the purchaser must qualify for financing under terms or conditions generally prevailing in the marketplace at the time the offer is made and those providing that the seller must convey a marketable and insurable title.

12. **Broker’s Market Analysis (BMA)** \- A real estate broker’s written market analysis of recent comparable sales and listings with suggestions for marketing strategies.

13. **Carrying costs** \- Recurring costs applicable to the property including, but not limited to, mortgage interest, property taxes and any outstanding liens or encumbrances.

14. **Comparable** \- A property, which is equivalent to the subject property, which is used as the basis to establish appraisal value. Recent sales and competitive listings are two examples.

15. **Contracting Officer's Representative (COR)** \- An individual designated and authorized in writing by the contracting officer to perform specific technical or administrative functions.

16. **Equity** \- The value of ownership built up in the employee’s residence or property that represents the current market value of the residence less any remaining mortgage payments. The equity reflects any other deductions that are applicable, such as non-reimbursable items under the Federal Travel Regulations (FTR).

17. **Equity advance** \- When the relocation services contractor provides the equity due in advance of closing, usually for the purpose of closing on another home. Equity is calculated by subtracting the balance due on the mortgage and/or other liens from the appraised value of the home and prorating mortgage interest and taxes to the expected acceptance date or vacate date, whichever is later.

18. **Exclusion clause** \- A provision placed in a listing agreement in which the broker acknowledges that they do not earn a commission if the home is sold to the relocation company.

19. **Guaranteed Home Sale (GHS)** \- The offer by the relocation services contractor to purchase an employee's principal residence. The offer amount is typically based on the average of two or more appraisals with a fixed acceptance period.

20. **Home that cannot be financed** \- A home that does not meet applicable industry criteria for a mortgage loan, as determined by a reputable institutional lender, such as a bank, savings and loan, or mortgage company authorized to conduct business in the area. Criteria for mortgage loans are not limited to particular types of loans, such as Federal Housing Administration, Veterans Administration or loans eligible for repurchase under guidelines established by other organizations.

21. **Home that is not insurable** \- A home that does not meet applicable industry criteria for the issuance of a standard homeowners’ insurance policy as determined by a reputable insurance company authorized to conduct business in the area or a home in which the employee does not hold insurable title, as determined by a reputable abstract or title company authorized to conduct business in the area.

22. **Inspection** \- A professional examination of a home’s major components which may include, but are not limited to, exterior, foundation, framing, plumbing, septic, electrical system, heating, air conditioning, fireplace, kitchen, bathroom, roofing and interior.

23. **Legal description** \- A description of land recognized by law; a description by which property can be definitively located by reference to government surveys or approved recorded maps.

24. **Listing agreement** \- A contract between a seller and broker authorizing the broker to perform services involving the seller’s property or to secure persons to buy, lease or rent property.

25. **Marketing time** \- The average list-to-sell time for residential property in the area, calculated according to industry standards as published by the applicable Multiple Listing Service (MLS) or other appropriate organization.

26. **Multiple Listing Service (MLS)** \- A marketing database set up by a group of cooperating real estate brokers to provide accurate and structured data about properties for sale and for rent.

27. **Property management** \- Services provided by the relocation services contractor that cover renting and maintaining property at the old post of duty.

28. **Property management counselor** \- The individual assigned by the relocation services contractor who works with the employee and the rental agent throughout the term that the home is in the program.

29. **Re-evaluation process** \- An opportunity afforded to the employee to contest the GHS offer by providing additional objective information. The additional information will be evaluated by the original appraisers that could result in a higher, equal or lower GHS offer.

30. **Relocation appraisal** \- The established process by which the anticipated sale price of a residential housing unit, using the market data approach to value, for a relocating employee’s residence. The purpose of this appraisal is to establish the anticipated sales price for a transferee's residence.

31. **Relocation services contractor** \- A third-party supplier under contract with an agency to assist a transferred employee in relocating to the new official station.

32. **Relocation services counselor** \- The individual designated by the relocation services contractor to serve as the primary liaison between the relocation services contractor and the relocating employee.

33. **Sales comparison analysis** \- An assessment that compares a property's characteristics with those of comparable properties that have recently sold in similar transactions.

34. **Title** \- All interest held by the employee in the home. For purposes of the home sale portion of the relocation services contract, title means interest in real estate that is marketable and insurable under applicable state law.

35. **Worldwide Employee Relocation Council (WERC)** \- Trade association representing the relocation industry. The Worldwide Employee Relocation Council (WERC) creates policy guidelines and provides a forum for continuing education on all aspects of relocation.


**1.32.13.1.7** **(01-15-2025)**

#### Acronyms

1. The following acronyms apply to the Relocation Services Program.




| **ACRONYMS** | **DESCRIPTION** |
| :-: | :-: |
| AV | Amended Value Sales |
| AZ | Amended from Zero |
| BMA | Broker’s Market Analysis |
| CFR | Code of Federal Regulations |
| COR | Contracting Officer Representative |
| FTR | Federal Travel Regulations |
| GHS | Guaranteed Home Sale |
| GSA | General Service Administration |
| IFS | Integrated Financial System |
| MLS | Multiple Listing Service |
| USC | U.S. Code |
| WERC | Worldwide Employee Relocation Council |


**1.32.13.1.8** **(04-14-2020)**

#### Related Resources

1. IRM 1.32.12, IRS Relocation Travel Guide, provides information on the policies and procedures for employees who relocate in the interest of the government.


**1.32.13.2** **(01-15-2025)**

### General Rules

01. The Relocation Services Program is designed to assist an employee with relocating from one duty station to another. The primary benefit is known as the Guaranteed Home Sale (GHS) service and is offered to employees who must sell their primary residence. It also offers other valuable services that can help employees with their relocation. Some of these services are at no cost to both the government and to the transferring employee. Employees are not required to use the Relocation Services Program. Using the IRS Relocation Services Program requires the approval of the Senior Associate CFO for Financial Management. Employees interested in using the program should read and understand this IRM.

02. The employee has the option of selling their residence independently for direct reimbursement. If the employee uses direct reimbursement, the IRS does not guarantee a sale at an appraised value nor does it purchase the property from the employee, but it may reimburse some or all direct selling costs.

03. An employee may use the Relocation Services Program only for eligible properties that are properly titled. See IRM 1.32.13, Residence Eligibility and Title Requirements, for additional information.

04. If there are any problems relating to using the program, the employee should contact the CFO relocation coordinator.

05. The IRS suggests that any house-hunting trips to the new duty station be delayed until the employee receives a realistic assessment of the value of their residence at the old duty station. A Broker’s Market Analysis (BMA) appraisal, or an offer for the residence, will provide such an assessment.

06. If the employee’s residence is listed on the market as a mortgage short sale, they should let the CFO relocation coordinator know before requesting to use the Relocation Services Program.

07. Generally, settlement must occur no later than one year after the day that an employee reports for duty at the new official station unless the employee timely submitted and was granted an extension as provided under 41 CFR Subpart A, [General Rules](https://ecfr.io/Title-41/Part-302), section 302-11.22 and 302-11.23. An employee is ineligible to continue to use the Relocation Services Program when the one-year period expires unless the employee has requested an extension and has obtained approval. An employee may use the Relocation Services Program if sufficient time remains for the home sale settlement to be completed required under 41 CFR Section 302-11-21.

08. If the employee is selling their home as part of the relocation process, the IRS requires that they include an exclusion clause in the listing agreement with a real estate broker. See IRM 1.32.13, Exclusion Clause, for additional information.

09. The relocation services contract covers the residence that the employee regularly commuted to and from work daily at the time the employee was notified of the transfer. The Relocation Services Program may not be used to sell any residence that would not be entitled to reimbursement for home sale expenses if the employee sold the residence without using the program.

10. The maximum home value for which the IRS will pay is $1 million. Any amount over $1 million will be the employee's responsibility. If extenuating circumstances exist, the employee may request an exception by submitting a memorandum with a justification through the CFO. The request and memorandum with the concurrence of the business unit Head of Office must be submitted the relocation coordinators for review. The relocation coordinator will review and submit the package to the Director, Travel Management, who will review and forward to the Deputy Commissioner for approval or disapproval. A copy of the justification and the Deputy Commissioner's approval must accompany the relocation claim.

11. Employees must request to have the initial one-year relocation time period extended no later than 60 days prior to the expiration date. The Director, Travel Management, may approve an additional one-year extension to complete the home sale.

12. If the employee cannot sell the home, the relocation services contractor may offer to purchase the employee's home as a GHS offer. The contractor bases the offer amount on the appraisals it has received, so there is no guaranteed amount. There is no assurance that the contractor's offer amount will cover the employee's outstanding mortgage balance or be equal to or more than the amount that the employee originally paid for the home.

13. If the employee rejects the GHS offer, they may sell the residence on their own and claim the allowable costs under the direct reimbursement method.

14. An employee can only re-enter the Relocation Services Program after rejecting the GHS offer if there are extenuating circumstances. If approved, the employee will be required to reimburse the IRS for all direct costs, such as appraisals and inspection fees, paid to the relocation services contractor before they are allowed to re-enter the program. The CFO relocation coordinator should be contacted for assistance.


**1.32.13.3** **(04-14-2020)**

### Eligibility

1. The following employees are eligible to use the Relocation Services Program:



1. Executive employees relocating to positions covered by either the IRS or the Chief Counsel Executive Resources Board.

2. Employees relocating to management, management official and other professional positions, when the move is in the best interest of the government and not primarily for the benefit of the employee.

3. Employees relocating to non-professional positions when the move is involuntary.


**1.32.13.4** **(01-15-2025)**

### Requesting Use of the Relocation Services Program

1. Before employees can use the Relocation Services Program, they must complete Form 8518, Request for the Use of Relocation Services Contract, and forward it to the CFO relocation coordinator. The CFO relocation coordinator will forward the completed Form 8518, Request for the Use of Relocation Services Contract, and relocation authorization amendment for basic plus moving expenses, to the appropriate budget office for approval. The budget office will route the request for basic plus relocation allowances through the head of office or director of finance for approval by the Senior Associate CFO for Financial Management. The Senior Associate CFO for Financial Management must approve the request to use the Relocation Services Program.

2. The business unit must submit the request for using the basic plus relocation allowance program to the relocation coordinator for review and submission to the Director, Travel Management, who will review and forward to the Senior Associate CFO for Financial Management for approval or disapproval. The Senior Associate CFO for Financial Management office will return the package back to the relocation coordinator.

3. Employees may use the relocation services if they:



1. Signed a service agreement and disclosure statement.

2. Obtained approval of the Senior Associate CFO for Financial Management.

3. Marketed the home with a qualified broker for the required amount of time.


4. Employees must market their home for the specified time based on the report date shown on the approved relocation authorization for basic moving expenses:




| **Written Notification of Reporting Date** | **Requirement for Marketing Home** |
| --- | --- |
| 30 days | 15 days |
| 60 days | 45 days |
| 90 days | 75 days |
| 120 days | 105 days |

5. Using the Relocation Services Program is made on a case-by-case determination in the best interest of the IRS. Employees may submit their request to use the Relocation Services Program once they have received an approved relocation authorization for basic moving expenses and have listed their home for sale for the required time period with a qualified realtor.

6. Employees may contact the contractor directly to obtain no-fee services as soon as they have an approved relocation authorization for basic moving expenses.

7. Employees should provide additional information in their justification to use the Relocation Services Program, including:



1. Original listing price.

2. Current listing price.

3. Number of times the price was reduced.

4. The methods of advertisement, such as the number of open houses listed in local publications and newspapers, Multiple Listing Service (MLS) listings and virtual tours.

5. A description of current market conditions such as the number of homes currently on the market within the same price range as the employee’s residence.

6. Length of time on the market.


**1.32.13.5** **(04-14-2020)**

### Residence Eligibility and Title Requirements

1. Relocating employees may use the Relocation Services Program for the home that serves as their principal residence only. For example, the following properties are not considered eligible residences for purposes of using the contract unless the property serves as the employee’s primary residence:



1. Mobile/Manufactured homes

2. Cooperatives

3. Houseboats

4. Homes that are uninsurable

5. Homes that cannot be financed by Federal Housing Administration, Veterans Administration, or other conventional financing programs.

6. Homes on which construction has not been completed.

7. Homes that do not comply with state and local codes.


2. The FTR requires that the title to the home be held in one of the following manners:



1. Employee’s name alone.

2. Jointly in employee’s name and one or more members of the immediate family.

3. Solely in the name of one or more members of the immediate family.


3. For titling purposes, immediate family members include:



1. Spouse, excluding divorced or legally separated spouses. Changes in marital status may affect the employee’s eligibility.

2. Domestic partner,

3. Children of the employee, of the employee’s spouse, or of the employee’s domestic partner, who are unmarried and under 21 years of age, or who, regardless of age, are physically or mentally incapable of self-support. The term children include natural offspring, stepchildren, adopted children, grandchildren, legal minor wards or other dependent children who are under legal guardianship of the employee, the spouse, or domestic partner, and unborn children born and moved after the employee’s effective date of transfer.

4. Dependent parents (including step and legally adoptive parents) of the employee, of the employee’s spouse, or of the employee’s domestic partner.

5. Dependent brothers and sisters (including step and legally adoptive brothers and sisters) of the employee, of the employee’s spouse, or of the employee’s domestic partner, who are unmarried and under 21 years of age or who, regardless of age, are physically or mentally incapable of self-support.


4. The FTR also stipulates certain eligible title circumstances. If the title search ordered by the relocation services contractor for the property shows someone who appears to be non-eligible based on the regulations, the relocation services contractor will seek clarification.

5. On the initial call with the relocation services counselor, the employee must advise the relocation services counselor who holds the title to the home. The FTR stipulates if a title condition exists, whereby a non-eligible person owns an interest in the residence, the employee will not be able to continue in the program.

6. If an employee’s home has land in excess of that which reasonably relates to the residence site, the IRS will pay the relocation services contractor the proportional share of the contract fees which relate to the residence site.


**1.32.13.6** **(04-14-2020)**

### Exclusion Clause

1. The purpose of the exclusion clause is to preserve the right to sell the home to the relocation services contractor, if necessary, without incurring a real estate commission. However, if the employee sells the home through the home sale program, there is no requirement to pay closing costs. If the relocation services contractor acquires the property, the relocation services contractor will pay the real estate closing costs. This is a tax advantage to the employee per the amended value sale process. Agents who work with relocating employees are familiar with this type of clause:




| **Exclusion Clause** |
| :-: |
| It is understood and agreed that regardless of whether or not an offer is presented by a ready, willing and able buyer, changes in marital status may affect the employee’s eligibility.<br> (1) No commission or compensation shall be earned by, or due and payable to broker(s) until sale of the property has been consummated between seller(s) and a buyer, the deed delivered to the buyer and the purchase price delivered to the seller(s) and<br> (2) The seller(s) reserve the right to sell the property to\_\_\_\_\_\_\_\_\_ (name of contractor) or (name of any other party to be covered by this exclusion clause) (individually or collectively a "named prospective purchaser" ) at any time. Upon execution of a name prospective purchaser and me (us) of an agreement of sale with respect to the property, the listing agreement shall immediately terminate without obligation on my (our) part of any named prospective purchaser to either pay a commission or to continue this listing. |





### Note:



Without the clause, the employee will not be able to enroll in the program.


**1.32.13.7** **(04-14-2020)**

### Pre-Counseling Services

1. Pre-counseling services are available at no-cost to employees who have already decided to take a transfer and employees who are still in the decision-making process.

2. Pre-counseling services can assist with:



1. Reviewing property and employee eligibility requirements.

2. Explaining the program services available.

3. Providing information that may help avoid decisions that result in out-of-pocket expenses.

4. Exploring both rental and purchase options at the new duty station.


**1.32.13.8** **(04-14-2020)**

### Broker's Market Analysis

1. The BMA is a method of evaluating recent comparable sales and listings and helps assess the value of a property. It also provides the relocation services contractor with information regarding the local market conditions.

2. The relocation services contractor contacts a reputable local real estate professional and requests a BMA. This is completed on a Worldwide Employee Relocation Council (WERC) BMA and Strategy Form.

3. The BMA is not an appraisal, nor is it used to determine the GHS offer.

4. The relocation services contractor will provide two BMAs at no cost to the employee or to the IRS.


**1.32.13.9** **(04-14-2020)**

### Home Marketing Assistance

1. Under this program, the relocation services contractor assists relocating employees in finding a buyer for the property while in the relocation program.

2. To be eligible for home marketing assistance, the employee must list the home with a real estate broker. The percent of real estate commission in the listing agreement should equal the standard rate charged for the area. The employee is responsible for the cost of any commission above the standard rate.

3. The relocation services contractor will work with the employee and the agent to generate an offer for the home. Relocation services counselors are available to help with the process of:



1. Selecting a qualified real estate agent.

2. Setting a list price.

3. Promoting and advertising the home.

4. Handling the offer negotiation process.

5. Recommending repairs or improvements to enhance salability.


**1.32.13.10** **(04-14-2020)**

### Home Sale Assistance Services

1. The home sale assistance services include the following programs:



1. GHS

2. Amended value

3. Amended from zero sale

4. Closing assistance only


2. The IRS expects an employee to market their home until they:



1. Receive an independent offer.

2. Accept a GHS offer from the relocation services contractor.

3. Decide to take the home off the market and not sell it at the present time.


3. Once the IRS notifies the employee that the request has been approved to use the home sale assistance program, a relocation services counselor will contact the employee to explain the program. After this initial contact, the employee will receive an introductory packet containing forms, documents and instructions on the relocation program. The employee will be asked to provide the property's legal description, as well as other specific property information.

4. Under the home sale assistance program, the employee is required to sign and return a homeowner's property disclosure and lead paint disclosure statement. If there is no state disclosure form where the employee lives, the employee and any co-owners must complete and sign the relocation services contractor property disclosure statement.

5. When an employee is in the home sale assistance program, the employee can:



1. Obtain an outside buyer, sell the home, close on their own, and file for direct reimbursement.

2. Obtain an outside buyer and use other services provided by the relocation services contractor prior to accepting a GHS offer. The degree of assistance for the sale that the employee may receive from the relocation services contractor depends upon when this occurs. See IRM 1.32.13, Options with an Independent Offer, for additional information.

3. Accept the GHS offer from the relocation services contractor.

4. Allow the GHS offer to expire at the end of the 60 calendar day offer acceptance period.

5. Cancel out of the program. The IRS will require the employee to repay the IRS for all relocation-related costs, such as for appraisals or inspection fees before the employee can reenter the program.


**1.32.13.11** **(04-14-2020)**

### Guaranteed Home Sale Program

1. The GHS program is the sale of the employee’s residence to the relocation services contractor with the guaranteed offer price based on appraisals by independent certified appraisers. If the employee does not independently obtain an outside buyer, the sale to the contractor is referred to as a regular sale.


**1.32.13.11.1** **(04-14-2020)**

#### Choosing an Appraiser

1. Within one business day of referral by the CFO relocation coordinator, the relocation services contractor will provide the employee with a list of qualified independent appraisers with whom the relocation services contractor regularly does business in the area of the old residence. The employee must select three appraisers in order of preference. The relocation services contractor will order two independent appraisals based on the selection. The employee may choose from the relocation services contractor’s list, or the employee may choose appraisers who are not on the list. If the employee selects an appraiser that is not on the list, the relocation services contractor will verify the appraiser’s experience, qualifications and availability to complete the appraisals with the required time limits.

2. Appraisers on the list are qualified local appraisers who have demonstrated a high degree of professionalism in researching and evaluating information to determine the most probable sales price.

3. All appraisers must have a professional designation or certification through nationally recognized organizations such as the American Institute of Real Estate Appraisers or the Society of Real Estate Appraisers. The appraisers follow the guidelines of the WERC to assure independence and impartiality. The following requirements for an appraiser are:



1. The appraiser has no financial interest in the property.

2. The appraiser has not appraised the property within the previous six months.

3. The appraiser derives their primary source of income from the appraisal of single-family homes rather than brokerage or commercial appraising.

4. The appraiser is not designated as the listing real estate broker.


4. All contact with an appraiser must be in writing and transmitted via fax, e-mail or U.S. mail. The appraiser provides copies of all correspondence to the relocation services contractor and, upon request, to Travel Operations.


**1.32.13.11.2** **(04-14-2020)**

#### Appraisal Process

1. The relocation services contractor orders appraisals with the first two selected appraisers. These appraisers will call the employee to schedule appointments, which will be executed within 10 business days, if possible.

2. The relocation services contractor provides the appraisers with written instructions regarding the appraisal assignment. These instructions cover time frames for a verbal and written report, parameters for the appraisal based on the IRS contract and billing information. In addition to the contract parameters, the appraisers follow the WERC guidelines, as outlined on page one of each appraiser’s report.

3. The appraiser is responsible for estimating the anticipated sales price for a relocating employee’s residence. The anticipated sales price may or may not be the same as the market value of a property. See IRM 1.32.13, Exhibit III, Differences Between Mortgage and Relocation Appraisals, for a chart which outlines the distinctions between these types of appraisals. The appraiser is not evaluating what it would cost to construct the residence (cost approach) or for what it would rent (income approach).

4. The appraiser considers the following factors when preparing the report:



1. Overall market conditions, including economic

2. Supply and demand of available housing

3. Available financing and terms

4. Property assessments

5. Zoning

6. School district


5. More specific to the home, the independent appraiser takes into consideration the following:



1. Neighborhood

2. Proximity to services and schools

3. Location

4. Interior and exterior condition

5. Decorating

6. Functional appeal and other factors listed in the WERC appraisal guidelines

7. Home size


6. The appraiser uses comparable sales data that is contiguous to the property. The comparable selected by the appraiser must be in the same neighborhood, development, subdivision or complex. If an appraiser, in their opinion, cannot identify an acceptable comparable within those parameters, they are required to notify the relocation services contractor prior to completing the appraisal. The relocation services counselor will discuss this with the employee.

7. The appraiser can use foreclosures, distress sales or auctions as comparables should this situation arise.

8. The appraiser compares the home and features to recently sold comparable homes. Starting with the sales price of each comparable, the appraiser adjusts up or down on each applicable factor and then arrives at an adjusted sales price for each comparable. Using this data, as well as considering the listing data, the appraiser uses their judgment to determine the value that reflects the price upon which a typical seller and buyer are most likely to agree.


**1.32.13.11.3** **(04-14-2020)**

#### Relocation Services Contractor's Appraisal Review

1. The relocation services contractor property specialist reviews the completed appraisal reports for mathematical errors or errors of fact. Errors of fact include material mistakes regarding items such as dates and prices of comparable sales, measurements of properties, and other objective data.

2. If the two appraisals differ by more than 5%, the relocation services contractor arranges for a third appraisal. See IRM 1.32.13, Guaranteed Home Sale Offer, for additional information.


**1.32.13.11.4** **(04-14-2020)**

#### Guaranteed Home Sale Offer

1. Upon completion of the appraisal process, the relocation services contractor may or may not make a GHS offer to purchase the property. The relocation services contractor must make every effort to make the offer within 30 days from date of the selection of appraisers. There are reasons why this time-period is not always sufficient (for example, if a third appraisal is required).

2. The relocation services contractor calculates the offer amount by averaging the two appraisals. If the relocation services contractor obtains a third appraisal, the contractor calculates the offer amount by averaging the two closest appraisals.

3. The relocation services contractor delivers the GHS offer by phone and email within two business days. The written offer includes copies of all appraisal and inspection documents. The employee must continue to market the residence until the relocation services contractor acquires the home.

4. The employee has 60 days from the telephone offer to accept or reject the GHS offer. The relocation services contractor and the Contracting Officer’s Representative can mutually agree to extend the acceptance period for an additional 15 calendar days.

5. If the employee is currently renting the home, the tenant must vacate the property prior to the acceptance of the offer.

6. If the employee rejects the offer, the employee may be able to reenter the home sale assistance program. However, the IRS requires the employee to repay the IRS for all relocation-related costs, such as for appraisals or inspection fees, before the employee can reenter the program.

7. If an employee cancels services or allows the offer to expire, the IRS pays the relocation services contractor for any justifiable direct costs incurred, such as for appraisals and inspection fees. If the employee decides to sell the residence independently for direct reimbursement, copies of the appraisal and inspection documents will be provided to the employee from the relocation services contractor. The employee may use the documents to complete the independent sale of the property, providing that the time for using the documents has not expired. If an employee elects not to use the documents and incurs additional expenses for the same or similar services, this will be at the employee’s expense. If the time for using the documents has expired, the employee may claim reimbursement for these or similar expenses through the direct reimbursement method.

8. If the GHS offer is contingent on repairs, the employee has 30 days from the receipt of the offer to have the repairs completed by a qualified contractor. The relocation services contractor will inform the employee of the required repairs. The employee is solely responsible for ensuring that the home is brought up to standards set by the applicable law, ordinance or code and providing all repair receipts to the relocation services contractor. See IRM 1.32.13, Inspection and Repairs, for additional information.


**1.32.13.11.5** **(01-15-2025)**

#### Inspection and Repairs

1. The relocation services contractor may order an inspection of the property even before the appraisal process begins and later if recommended by the appraisers.

2. The IRS is not liable for any part of the cost of the repairs or re-inspection and may not be billed for such, either directly or indirectly.

3. The inspections are primarily to determine if the property meets eligibility requirements of the contract and if the property is in conformity with federal, state, county, or local customs and/or laws.

4. Depending on the circumstances, some examples of inspections ordered for the property include, but are not limited to, a structural inspection, a roof inspection, a well inspection, inspections of the property's various systems such as heating, electrical, plumbing and septic. Some inspections are to detect the presence of various substances including, but not limited to, termites, radon gas, urea formaldehyde foam insulation, asbestos insulation and fire-retardant treated plywood.

5. As the property owner, if the township or municipality requires an occupancy inspection, the employee must arrange with the appropriate local agency to inspect the property for any repairs and re-inspections to pass title.

6. If an inspection report reveals that repairs are necessary, the relocation services contractor will contact the employee directly to discuss which repairs the employee must complete.

7. The relocation services contractor can obtain estimates of costs from established, reputable repair service firms or the employee can obtain repair estimates on their own and bear all costs associated with the repairs and re-inspection.

8. The relocation services counselor will contact the employee if an inspection reveals a condition that makes the home no longer eligible for the GHS program. The employee will be given the opportunity to correct the condition. The employee has five calendar days to elect one of the following:



1. Delay receipt of the GHS offer for up to 30 days of receiving verbal notice from the relocation services contractor of the ineligible condition and correct the condition within this 30-day period. The relocation services contractor will provide the employee with estimated repair costs.

2. Receive the GHS offer contingent upon completion of the repairs by a qualified repair contractor. The contingency requires the completion of repairs within 30 days of receipt of the GHS offer.


9. The employee may personally complete the repairs or hire someone else to complete them. Repairs completed by the employee, or by someone else on the employee’s behalf, are subject to re-inspection to determine if they have been satisfactorily completed. The employee must provide the relocation services contractor with copies of all paid receipts for completed repairs.


**1.32.13.11.6** **(01-15-2025)**

#### Request for Reconsideration

01. If an employee disagrees with the amount offered by the relocation services contractor for purchase of the residence, the employee may request in writing that the relocation services contractor reconsider the offer.

02. The employee should file the written request for reconsideration as soon as possible after carefully reviewing the written appraisal reports, but no later than 30 days after the relocation services contractor made the offer.

03. The relocation services contractor will provide the employee with written instructions for submitting a reconsideration request with the GHS offer.

04. The CFO relocation coordinator or Travel Operations cannot adjust an appraisal value or a GHS offer. The CFO relocation coordinator or Travel Operations cannot initiate the reconsideration process on the employee’s behalf.

05. Since the relocation services contractor must make an offer based solely on appraisals by independent appraisers, the success of a request for reconsideration depends on whether or not the employee’s request convinces the appraisers to change the appraised value.

06. The employee should focus on identifying any factual errors in the appraisal reports by identifying each specific error, with an explanation why the item is in error. The appraisers will reconsider the value based on the correct information.

07. The employee may also submit information on additional comparable properties that have sold within the last six months or as recently as those sales used by the appraiser.

08. The employee should never contact the appraiser directly to try to obtain a change in value or answers to questions regarding the appraisal.

09. The relocation services counselor explains the appraisers' decisions to the employee and then sends the employee a copy of the written appraisers' explanations. If one or both appraisers agree with the reconsideration and increase the appraised value(s), the employee will receive a new contract of sale reflecting the higher offer. If, upon review, one or both appraisers determine a lower appraisal value or that no change in value is warranted, the GHS offer and contract of sale will not change.

10. The reconsideration process is completed prior to the expiration of the 60-day acceptance period. An extension of the acceptance period of up to 15 calendar days may be granted to complete the reconsideration process; however, the employee must have complied with the time-period for submission of the request for reconsideration.


**1.32.13.11.7** **(04-14-2020)**

#### Vacating the Property

1. The vacate date is established when the employee accepts the GHS offer and is no later than 45 days from the date of acceptance.

2. After accepting the relocation services contractor's offer, the employee is responsible for:



1. Maintaining the property in substantially the same condition as at the time of appraisal.

2. Paying all maintenance, utility, insurance, mortgage and related costs for the property until the employee vacates.

3. Leaving the property in broom-clean condition when they vacate. A representative of the contractor may inspect the property within three calendar days of vacating to identify damage. All costs incurred by the relocation services contractor in connection with removing debris will be billed back to the employee.


3. Upon vacating, employees are relieved of all further maintenance and carrying costs on the property. If, after vacating the residence, they receive a bill for taxes or any other expenses for which they are no longer responsible, they should notify the relocation services contractor immediately.

4. The employee is responsible for canceling the homeowners' insurance and all utility services as of the vacate date or acquisition date, whichever is later.

5. When the relocation services contractor acquires the property, a deed transferring the title to the contractor is completed.


**1.32.13.11.8** **(04-14-2020)**

#### Responsibility for Mortgage

1. Upon acquiring the property, the relocation services contractor pays off the mortgage within 31 days of acquisition. In most cases, the relocation services contractor pays off all mortgages or other obligations secured by the residence, except as required by a higher offer transaction. The relocation services contractor reserves the right to review this provision in the event interest rates rise substantially and result in an adverse cost effect for the relocation services contractor and the IRS. If this should occur, the relocation services contractor will notify the employee in advance.

2. The relocation services contractor will protect the employee’s credit rating through its prompt payment of the mortgage. If the relocation services contractor makes a delinquent mortgage payment, the relocation services contractor bears the cost of any late charges. In addition, the relocation services contractor promptly responds to any adverse credit reports with written mortgage payment indemnification notices. If the employee makes any delinquent mortgage payments, then the employee must bear the cost of any late charges.

3. Should the offer involve the assumption of the existing mortgage on the property, the employee must sign a written release of liability that protects the relocation services contractor, should the purchaser of the property default in any way on the assumption loan at any time in the future. The relocation services contractor will not indemnify the employee if the purchaser defaults. The ultimate responsibility for the assumption loan lies with the employee. The employee remains responsible for the mortgage (in the event of default by the outside buyer) as with any other assumption.


**1.32.13.11.9** **(04-14-2020)**

#### Disbursement of Equity

1. Upon the employee’s acceptance of the GHS offer, the relocation services contractor prepares a statement of equity, prorating all debits and credits applicable to the property through the vacating date.

2. When the relocation services contractor calculates the equity in the home, it uses the FTR to determine reimbursable expenses and does not reduce the employee’s equity in the home by the amount of any items reimbursable under the FTR.

3. The relocation services contractor disburses up to 100% of the equity in the home, normally within five business days after the relocation services contractor receives and signs the employee’s contract of sale (the acquisition date) if the employee has vacated the property. If the employee has not vacated the property, the employee receives 90% of the equity.

4. The relocation services contractor sends the equity payment via electronic funds transfer or wire transfer, whichever method the employee prefers.

5. Final equity is reduced if any trash, debris, firewood, paint or chemicals remain in the house after the employee vacates the premises.

6. If the outstanding mortgage balance and any other encumbrances on the property exceed the GHS offer, the employee must remit the difference to the relocation services contractor via electronic funds transfer or wire transfer at the time the employee accepts the GHS offer. The relocation services contractor estimates the deficit at the time it makes the purchase offer. The relocation services contractor sends any refund upon final computation of the equity within five business days of the acquisition.

7. The relocation services contractor will send the employee’s Form 1099-S, Proceeds from Real Estate Transactions, for the calendar year that includes the date of closing for a real estate transaction, as required by the Internal Revenue Code, Return Required in the Case of Real Estate Transactions, section 6045(e). If the employee receives Form 1099-S, Proceeds from Real Estate Transactions, for any other reason, the employee should contact the CFO relocation coordinator immediately.


**1.32.13.11.10** **(01-15-2025)**

#### Equity Advance

1. During the 60-day GHS offer period, the relocation services contractor may advance up to 100% of the available equity in the home (as established by the GHS), for the purpose of closing on a residence at the new location. The relocation services counselor confirms the signed purchase agreement on the new home by either requesting a copy of it or by contacting the real estate agent.


**1.32.13.11.11** **(04-14-2020)**

#### Equity Deficit

1. An equity deficit occurs when the total amount of the outstanding mortgage balance, property taxes and homeowner’s association dues exceed the offer amount.

2. In order to process acquisition of the property, a relocation services counselor will request a certified check for the equity deficit to accompany the acceptance paperwork.

3. The employee must remit any deficit amount to the relocation services contractor within five business days of the acquisition of the property. The relocation services contractor will not complete the acquisition of the property until it receives the deficit funds owed.


**1.32.13.12** **(04-14-2020)**

### Options with an Independent Offer

1. If the employee obtains an independent offer after the acceptance into the home sale assistance program, the employee may take advantage of the following services:



1. Amend from zero (AZ) sale program

2. Amended value (AV) sale program


2. Under the AZ and AV programs, the employee sells the home to the relocation services contractor who then sells the property to the outside buyer. The difference between these programs is based on where the employee is in the appraisal and offer process. The benefit to the employee is receiving the equity in the property within five business days after completing the sale with the relocation services contractor if the home is vacant. This will occur once the buyer has removed any non-allowable contingencies and the relocation services contractor has received all required paperwork.

3. Additional benefits include:



1. The relocation services contractor completely handles the sale to the outside buyer, so the employee does not have to be present at settlement.

2. The employee does not have to use their own funds for settlement expenses and then be reimbursed.

3. The relocation services contractor pays the real estate agent on behalf of the employee.


4. The relocation services contractor reduces the equity for:



1. Real estate commissions in excess of the standard for the area.

2. Non-reimbursable seller concessions to which the employee has agreed.


5. The employee should contact the relocation services contractor as soon as possible after they find a prospective buyer so that the relocation services contractor can review the offer terms and counsel the employee with negotiations. The employee should not sign any outside sales contract before notifying the relocation services contractor and discussing the possibility that the outside offer might qualify for one of the programs under the contract.

6. Prior to acceptance for any of the higher offer programs, the relocation services contractor reviews all outside offers in detail.


**1.32.13.12.1** **(04-14-2020)**

#### Amend from Zero Sale Program

1. This sale may occur when the employee receives an acceptable bona fide offer from an outside buyer prior to the completion of the appraisal process conducted through the relocation services contractor.

2. Since the relocation services contractor has not received the appraisals, it obtains a broker’s market analysis to benchmark the reasonableness of the outside offer. At this point, the employee cannot enter into a contract or sign any agreement document with the outside buyer.


**1.32.13.12.2** **(01-15-2025)**

#### Amended Value Sale Program

1. This sale may occur when the employee receives an acceptable bona fide offer from an outside buyer after the relocation services contractor has completed the appraisal process. The relocation services contractor may have also tendered the employee a GHS offer.

2. If the employee is successful in finding an independent buyer willing to pay a net purchase price equal to or greater than the GHS offer, then the employee should not sign any documents (including counteroffers) or accept earnest money. The relocation services contractor cannot work with the sale if the employee has done either.

3. The relocation services contractor will ask the employee and their agent to submit information relative to the purchase offer and the buyer's qualifications.

4. The relocation services counselor reviews the offer:



1. To determine if it is bona fide and if the buyer is qualified based on the written information submitted. The counselor uses the GHS offer as a benchmark to evaluate the reasonableness of the outside offer price.

2. For any expenses or concessions that are deemed non-reimbursable under the Federal Travel Regulation. A few examples of non-reimbursable items include repairs as a result of a buyer’s inspection, points, homeowner’s warranty, real estate commission in excess of the standard for the area, decorating allowance and buyer closing cost allowance.


5. If the offer involves the assumption of the existing mortgage on the property, the employee is required to sign a release of liability that protects the relocation services contractor should the purchaser of the property default in any way on the assumption loan at any time in the future. The ultimate responsibility of the assumption loan would lie with the employee.

6. Once the relocation services contractor receives and reviews all the required documents and any non-allowable contingencies have been removed, the relocation services counselor will instruct the employee to amend the GHS offer to the value of the independent offer and complete acquisition of the property.


**1.32.13.13** **(04-14-2020)**

### Closing Assistance Program

1. If an employee signs an outside sale contract prior to entering the home sale assistance program or prior to the completion of the appraisal process under the program, the employee may be eligible to use the relocation contractor for closing assistance.

2. Under the closing assistance program, the relocation services contractor manages the sale process and closing with the outside buyer, including disbursing the equity to the employee.

3. The advantage of this program is that it allows the employee to focus on the move itself and relocating to the new post of duty.

4. The employee remains the seller of record and is responsible for all decisions related to the property.


**1.32.13.14** **(01-15-2025)**

### Rental Property Management Program

01. Property management services are programs provided by private companies for a fee that help an employee to manage their residence at the old official station as a rental property. These services include, but are not limited to, obtaining a tenant, negotiating the lease, inspecting the property regularly, managing repairs and maintenance, enforcing lease terms, collecting the rent, paying the mortgage and other carrying expenses from rental proceeds and/or funds of the employee, and accounting for the transactions and providing periodic reports to the employee.

02. The service is available through the relocation services contractor and real estate brokers.

03. The service assists employees who are relocating but have decided to maintain their homes at the old post of duty.

04. Employees may submit their request to use the relocation services contract for property management once they have received an approved relocation authorization for basic moving expenses.

05. Before employees can use the relocation services contract for property management, they must complete Form 8518, Request for the Use of Relocation Services Contract, and forward it to the CFO relocation coordinator. The CFO relocation coordinator will complete and forward the relocation authorization amendment for basic plus moving expenses to the appropriate budget office for approval. The business unit’s budget office will route the request for basic plus relocation allowances through the head of office or director of finance for approval.

06. Upon approval, the business unit must submit the approved request for using the basic plus Relocation Allowance Program to the relocation coordinator for review and submission to the Director, Travel Management, who will review and forward to the Senior Associate CFO for Financial Management for approval. The Senior Associate CFO for Financial Management office will return the package back to the relocation coordinator.

07. Property management services may be requested when transferring to a post of duty Outside the Continental United States, performing a temporary change of station, or when transferring to a new official station within the Continental United States. Refer to IRM 10.8.1, Policy and Guidance, and IRM 10.8.26, Wireless and Mobile Device Security Policy, for relocating IT equipment outside of the Continental United States. IRM 10.8.26.3.1.12.1 contains travel requirements, IRM 10.8.26.3.11.1 includes PE-3 Physical Access Control requirements, and IRM 10.8.1.4.1.18 references AC-19 Access Control and Mobile Devices requirements. See the chart below for the timeframe for using property management services:




    | **Domestic Relocation:** | **Foreign Transfer:** | **Temporary Change of Station:** |
    | :-: | :-: | :-: |
    | IRS will pay for property management services for no more than one year (no extensions). | IRS will pay property management services for two years. In order to continue the service after two years, employees must sign a new tour renewal agreement. | IRS will pay for property management services while employees are under Temporary Change of Station assignment, not to exceed 30 months (no extensions). |

08. The IRS may pay for property management services outside the contract if employees cannot sell their home at the old official station. The amount the IRS will reimburse the employee for property management services cannot exceed the monthly fee that the IRS would pay under the contract. Employees are responsible for any additional expenses. Employees must complete Form 14565, Property Management Reimbursement Request, for reimbursement of property management service fees paid to a certified property manager that is not part of the relocation services company. The employee must attach copies of paid property management service invoices to their voucher.

09. If the IRS pays for property management services on an employee's residence at the old official station and if they decide to sell the residence at government expense under the same relocation, the employee will owe the IRS for the property management paid on their behalf. To recover the property management fee, the IRS will reduce the amount paid to the employee for reimbursable home sale expenses.

10. Reimbursement of property management services, whether paid to the employee or the vendor, is taxable income to the employee. The IRS will pay the employee a Relocation Income Tax Allowance for the additional federal, state and local income taxes as a result of property management expenses incurred.


**1.32.13.14.1** **(04-14-2020)**

#### Determining the Market Rental Value for Your Home

1. The relocation services contractor contacts a local agent to meet with the employee at the property to evaluate the rental value. The local agent determines rental value by reviewing recent rentals and current available listings along with the property and general market conditions. These factors, viewed together, allow the agent to formulate an estimated rental value. The local agent assists with the rental marketing of the home through the applicable MLS or local newspapers.


**1.32.13.14.2** **(04-14-2020)**

#### Property Insurance

1. An employee’s homeowner's insurance policy may not allow for vacancy periods greater than 30 or 60 days. The relocation services contractor offers owner/landlord/tenant coverage that would cover any vacancy period.


**1.32.13.14.3** **(04-14-2020)**

#### Securing and Screening Tenants

1. The relocation services contractor works to secure a qualified tenant and runs a credit check on each prospective tenant to ensure that the tenant is credit worthy and can make the monthly payments.

2. If the relocation services contractor cannot find suitable tenants within a reasonable period (usually within two months), the employee may withdraw from the agreement.


**1.32.13.14.4** **(04-14-2020)**

#### Negotiating and Managing the Lease

1. The relocation services contractor negotiates the lease on the employee’s behalf. The contractor provides a copy of the standard lease to the employee in advance to review. Both the employee and the relocation services contractor approve any major changes to the lease. Once the terms of the lease have been agreed upon and the lease signed, the relocation services contractor’s property management counselor forwards a copy to the employee. Please note that state and local regulations may require modification or provisions to be added to some aspects of the lease.

2. The relocation services contractor then administers the lease on the employee’s behalf, including:



1. Collecting rent

2. Communicating with the tenant

3. Notifying the employee of any delinquency problems


3. The relocation services contractor acts as a single point of contact for repairs, maintenance or requests by the tenant.


**1.32.13.14.5** **(04-14-2020)**

#### Account Reconciliation

1. The property management counselor provides the employee with a quarterly statement of receipts and disbursements that reflect the rental income received and any mortgage, insurance, utility, tax or repair payments the relocation services contractor makes on the employee’s behalf. The statement reflects income received and expenses incurred and paid for the period, as well as any credit or deficit balance (the amount owed to the employee by relocation services or the amount, if any, owed by the employee to the relocation services contractor). If a balance is due to the employee, the property management counselor will deposit it in the employee’s account. If a balance is due from the employee, the relocation services contractor expects prompt payment.


**1.32.13.14.6** **(04-14-2020)**

#### Property Inspections

1. Before the tenants move in, the property management counselor contacts the employee to arrange the first property inspection. After the employee’s belongings have been removed, the inspector will photograph the home and complete a room-by-room report of the property’s condition. During this first inspection, the inspector records the:



1. Condition of the home before it is occupied by tenants.

2. Inventory of items the employee will leave in the property such as appliances and window treatments.

3. Need for further repairs, cleaning, or cosmetic work to improve the home's marketability.


2. The property management counselor coordinates four property inspections per year to ensure that the home is in good condition. These inspections alternate between complete (interior and exterior) and exterior-only. During an inspection, the property management counselor and/or broker record the condition of the property in detail, using written reports and photographs as necessary. If needed, the property management counselor and/or broker conduct additional inspections to determine if major repairs are required or to check completed repairs.

3. In an emergency, the property management counselor and broker immediately inspect the home and contact the employee as soon as an assessment of the condition is prepared. The property management counselor forwards to the employee a full report of all inspections, along with the recommendations, comments and photographs.

4. When a lease ends, the property management counselor and broker arrange for an inspection at the time the tenant vacates to determine if a full or partial return of the tenant’s security deposit is appropriate.

5. Upon the employee’s request, the property management counselor and inspector can coordinate repairs and cleaning, and issue a final statement to the employee.


**1.32.13.15** **(04-14-2020)**

### Destination Services Program

1. The relocation services contractor provides destination services at the new location. The employee may contact the relocation services contractor directly to obtain these free services:



1. Home renter’s assistance

2. Home buyer’s assistance

3. Mortgage counseling

4. Mortgage pre-qualification


2. A destination specialist meets with the employee to discuss:



1. Relocation timeframe

2. Specific preferences

3. Any special needs the employee and members of the family may have


3. This information is used to build a profile to identify potential homes for sale and/or rent based on the employee’s preference.


**1.32.13.15.1** **(04-14-2020)**

#### Home Renters Assistance

1. The relocation services contractor provides the employee a home finding kit and refers the employee to a rental agency.

2. Depending on the locale, the rental agent or real estate agent showing rental properties may charge the employee a fee. The relocation services contractor notifies the employee if there is a charge, prior to placing the employee with that agency. This fee is a non-reimbursable item, which means the employee is responsible for the payment directly to the rental agency should they use the service.


**1.32.13.15.2** **(04-14-2020)**

#### Home Buyers Assistance

1. As with the home renters’ assistance program, the relocation services contractor provides the employee a home finding kit along with a list of homes in the new area.

2. The relocation services contractor identifies a qualified real estate agent to provide the employee with an orientation to the area and help the employee locate communities and neighborhoods for the employee to visit during the house-hunting trip.


**1.32.13.15.3** **(04-14-2020)**

#### Mortgage Counseling

1. The relocation services contractor assigns a loan specialist to assist the employee in understanding the types and amounts of loans available in the new area, as well as referring the employee to local sources.

2. A national mortgage lender in the new area will assist the employee in the search of market rate financing.

3. The relocation services contractor provides general information regarding the real estate market, advice on planning a home search, referral to national mortgage lenders and research on family requirements (including schools, childcare, community life) for major cities when available.


**1.32.13.16** **(04-14-2020)**

### Mortgage Pre-Qualification

1. The relocation services contractor refers the employee to national mortgage lenders who are available to work with the employee to determine the mortgage amount the employee can afford and to arrange to have a mortgage pre-approved for the employee. This service is provided at no cost to the employee or the agency.

2. Advantages of pre-qualification include:



1. Understanding mortgage products that suit the employee’s financial objectives

2. Knowing how much mortgage the employee qualifies for and the amount of the employee’s monthly payment

3. Arranging pre-approval for a given mortgage amount so the employee’s home purchase can be expedited


**1.32.13.17** **(04-14-2020)**

### Exhibit I, Summary of Services

1. The following provides a summary of services:




| **Exhibit 1, Summary of Services** |
| :-: |
| **Service** | **IRM Reference Section** | **Approvals Required** | **Forms Required** | **Fees** |
| 1. | Pre- Counseling Services | 1.32.13.7 | No - Employee can contact contractor directly | None | No |
| 2. | Broker's Market Analysis | 1.32.13.8 | No - Employee can contact contractor directly | None | No |
| 3. | Home Marketing Assistance | 1.32.13.9 | No - Employee can contact contractor directly | None | No |
| 4\. Home sale assistance |
| a. | Guaranteed Home Sale | 1.32.13.11.4 | Yes | Yes | Yes - % based on accepted offer |
| b. | Amend From Zero Sale | 1.32.13.12.1 | Yes | Yes | Yes - % based on accepted offer |
| c. | Amended Value Sale | 1.32.13.12.2 | Yes | Yes | Yes - % based on accepted offer |
| d. | Closing Assistance Only | 1.32.13.13 | Yes | Yes | Yes - % based on accepted offer |
| 5. | Rental Property Management | 1.32.13.14 | Yes | Yes | Initiation fee and monthly flat rate |


**1.32.13.18** **(04-14-2020)**

### Exhibit II, Timeline of Key Relocation Actions

1. If employees have questions concerning Relocation Services, they should contact the CFO relocation coordinator.

2. The chart below describes the actions that occur during the sale of an employee's home.




| **Exhibit II, Timeline for Key Relocation Actions** |
| :-: |
| **Action** | **Due Date** |
| Relocation Services initiates contact with employee | One business day after Relocation Services receipt of the IRS written order of request |
| Relocation Services provides the employee with a list of at least six qualified appraisers and recommends that the employee selects three appraisers | Two business days after receipt of the written order of services |
| Employee designates three appraisers, in order of preference, to Relocation Services | Within five business days of the employee’s receipt of the Relocation Services-provided list of qualified appraisers<br> <br>### Note:<br>If the employee does not provide their selections within this time period, Relocation Services suspends the relocation process until it receives the list from the employee |
| Relocation Services places order for appraisals | Within one business day after the employee provides their list of selected appraisers |
| Appraisers submit reports to Relocation Services | Within seven business days from the date of the appraisal |
| Relocation Services orders any inspections requested by an appraiser | Within one business day of the request from the appraiser |
| All appraisal and inspection reports must be completed | Within 30 days of the date of the employee’s selection of the appraiser or the date of Relocation Services receipt of the IRS written order for services, whichever is later. |
| Relocation Services makes a verbal offer to the employee | Within two business days of the completion of the written appraisal process |
| Relocation Services mails the written offer to the employee | Within two business days of the date that Relocation Services makes the employee a verbal offer |
| If desired, employee corrects all repairs identified in inspection | Within 30 days from the date of the verbal offer |
| Employee accepts/rejects offer | Within 60 days from date of the verbal offer |
| Employee vacates home | Within 45 days from the date the employee accepts the offer |
| Relocation Services disburses equity | (a) For non-vacated properties, 90% within five business days of receipt of acceptance and execution of the contract sale, with the balance paid within five business days of the date the property is vacated<br> (b) For vacated properties, 100% within five business days of receipt of acceptance and execution of the contract sale |
| Relocation Services assumes mortgage | Within 31 days after purchasing the property |


**1.32.13.19** **(04-14-2020)**

### Exhibit III, Difference Between a Mortgage Appraisal and a Relocation Appraisal

1. The chart below outlines some of the differences between mortgage and relocation appraisals.




| **Exhibit III, Differences Between Mortgage and Relocation Appraisals** |
| :-: |
| **Mortgage Appraisal** | **Relocation Appraisal** |
| **Reporting format:** Completed on Uniform Residential Appraisal Report, a two-page report that is a comprehensive analysis and includes physical characteristics of the property. | **Reporting format:** Completed on WERC Summary Appraisal Report, a six-page report that uses techniques similar to those used for the mortgage appraisal. |
| **Intended use:** Facilitate mortgage lending. | **Intended use:** Facilitate corporate relocation. |
| **Purpose:** Develop an opinion of the market value of a property. | **Purpose:** Develop an opinion of the anticipated sales price of a relocating employee’s home. |
| **Market value:**The probable price which a property should bring in a competitive and open market. Exposure time precedes date of appraisal. | **Anticipated sales price:** The price at which a property is anticipated to sell in a competitive and open market. Marketing time occurs after date of appraisal. |
| **Marketing period:** Reasonable time that allows for exposure in the open market without limit, could be over two years. | **Marketing period:** Reasonable time that allows for exposure in the open market, not to exceed 120 days. |
| **Financing considerations:** Cash equivalency, no adjustments for normal seller costs which are normally paid by sellers. | **Financing considerations:** Cash equivalency, adjustments to the sales price of the comparable and financing concessions such as seller points or buyer’s closing costs. |
| ****Type of analysis**:** Retrospective analysis: looking at historical data as of the date of sale and no forecasting. | **Type of analysis:** Prospective analysis and forecasting adjustment. |
| **Decision-making:** Uses a long-term analysis for the life of the mortgage loan (up to 30 years); lower risk. | **Decision making:** Provides a short-term investment for the home entered in the Relocation Services Program (up to 120 days); higher risk. |
| **Items for consideration:** Identifies condition, design and appeal. | **Items for consideration:** Emphasizes condition, design, appeal, interior décor, repairs and improvements. |
| **Comparables:** Requires three closed sales to compare the subject property. | **Comparables:** Requires closed sales without limitation, competing properties, and encourages using pending sales if the information can be verified. |
| **Photographs:** Front, rear and street scene of the subject property of comparable sales. | **Photographs:** Front, rear, street scene and interior views of the subject property; any adverse conditions and inspection concerns; factors within view from the subject property that significantly affect marketability either favorably or unfavorably; comparable sales; and competitive listings. |


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-013#addtoany "Show all")

A2A