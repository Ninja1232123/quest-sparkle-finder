---
url: "https://www.irs.gov/irm/part1/irm_01-053-001"
title: "1.53.1 Managing Organizational Change | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-053-001#main-content)

- 1.53.1  [Managing Organizational Change](https://www.irs.gov/irm/part1/irm_01-053-001#id1)
  - 1.53.1.1  [Program Scope and Objective](https://www.irs.gov/irm/part1/irm_01-053-001#id2)
    - 1.53.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-053-001#id4)
    - 1.53.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-053-001#id5)
    - 1.53.1.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-053-001#id6)
    - 1.53.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-053-001#id7)
    - 1.53.1.1.5  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-053-001#id8)
    - 1.53.1.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-053-001#id9)
  - 1.53.1.2  [Policy](https://www.irs.gov/irm/part1/irm_01-053-001#id10)
  - 1.53.1.3  [Documents Required for SROC Submission](https://www.irs.gov/irm/part1/irm_01-053-001#id11)
  - 1.53.1.4  [Implementation](https://www.irs.gov/irm/part1/irm_01-053-001#id12)

# Part 1. Organization, Finance, and Management

# Chapter 53. Small Business/Self-Employed

# Section 1. Managing Organizational Change

* * *

## 1.53.1 Managing Organizational Change

#### Manual Transmittal

July 17, 2025

#### Purpose

(1) This transmits a revised IRM 1.53.1, Managing Organizational Change, Small Business and Self-Employed Division.

#### Material Changes

(1) This IRM section has been updated to comply with January 2025 Executive Orders and OPM guidance.

#### Effect on Other Documents

This IRM supersedes IRM 1.53.1 dated October 08, 2024.

#### Audience

SB/SE Division

#### Effective Date

(07-17-2025)

Michelle Haines

Director, Human Capital Office

Small Business/Self-Employed Division

**1.53.1.1** **(07-17-2025)**

### Program Scope and Objective

1. **Purpose:** This IRM Section is to establish standardized policies and procedures to govern the review and approval of proposed organizational changes within the SB/SE Division. The review, concurrence and approval process for the request will depend on the scope and magnitude of the requested changes.

2. **Audience:** Employees and managers in the SB/SE Division preparing requests for organizational change:



   - Collection

   - Examination

   - Operations Support

   - Office of Fraud Enforcement (OFE)

   - Office of Promoter Investigations (OPI)


3. **Policy Owner:** Director, SB/SE Human Capital Office (SHCO)

4. **Program Owner:** Leadership Development and Support Office (LDSO) located within SHCO

5. **Primary Stakeholders:** CHCO, CFO, SB/SE operating units, LRS&N

6. **Program Office Contact Information:** SROC Mailbox: \*SBSE ROC


**1.53.1.1.1** **(10-08-2024)**

#### Background

1. On October 1, 2000, Small Business/Self-Employed (SB/SE) officially stood-up as part of the new, modernized IRS. As the second largest Business Operating Division (BOD), SB/SE has approximately 23,000 IRS employees engaged in the full range of programs associated with tax administration.

2. The SB/SE Request for Organizational Change (SROC) process has been in place since February 2001 and is administered by the SB/SE Human Capital Office (SHCO). A review of this IRM was initiated to identify areas for improvement and incorporate revisions to the organizational change process. Accordingly, the SB/SE organizational change policy and procedures have been refined to align the current business needs with customer demands.

3. The SROC program serves as the method for documenting approval of SB/SE organizational design changes. The SROC process is the first step that should be taken to obtain final approval of the request for organizational change. The SROC process is not intended as a replacement for the routine processes which are already in place to secure funding of additional positions, upgrades, etc.

4. The objective of this process is to provide consistency and ensure that every proposal to reorganize the current structure of SB/SE is properly evaluated, approved and implemented.

5. The SROC program ensures all proposed changes adhere to current position management and classification guidelines and proper notification has been provided to National Treasury Employees Union (NTEU).

6. The SROC program is required to request new organizational codes, rename or deactivate organizational codes.

7. The guidance is intended to serve as a framework for managing the organizational change process. It outlines the responsibilities of key officials and provides procedures for processing and evaluating proposals. The processing will differ depending upon the type of organizational change request.


**1.53.1.1.2** **(10-08-2024)**

#### Authority

1. IRM 1.1.4, Organization and Staffing - Organizational Planning

2. [Treasury Directive 21-01](https://home.treasury.gov/about/general-information/orders-and-directives/td21-01)

3. [Treasury Order 102-01](https://home.treasury.gov/about/general-information/orders-and-directives/treasury-order-102-01)

4. IRM 1.2.2.7.1, Delegation Order 6-1, Authority to Create and Abolish Positions


**1.53.1.1.3** **(10-08-2024)**

#### Roles and Responsibilities

1. The Division Commissioner, SB/SE has designated the Director, SHCO, as the responsible Executive for overseeing the governing policy for SB/SE organizational change proposals to meet these objectives and ensure full and open communication at all levels. Within SHCO, the Chief, LDSO will serve as the focal point for controlling and coordinating organizational change proposals. In addition, LDSO will serve as the official repository of all documentation associated with organizational change proposals and decisions.

2. SB/SE Executives are responsible for ensuring sound organizational structures by continually evaluating the effectiveness and efficiency of their business units.

3. The SROC process only approves the organizational design change. Once the SROC has been approved, the implementation of the new design (e.g., filling positions) must be done in accordance with current Finance and Position Management Guidelines. Furthermore, after a change has been approved, it is the responsibility of the initiating SB/SE Executive to ensure that the change is properly implemented, all applicable systems have been updated and any Labor Relations issues have been resolved prior to implementation.


**1.53.1.1.4** **(07-17-2025)**

#### Program Management and Review

1. The SROC package will be reviewed for completeness and to ensure:



   - SROC Template and Business Case Memo clearly define the purpose and justification of the proposed changes

   - Span of Control (SOC) guidelines are met

   - Position Descriptions (PDs) are valid and current

   - Organizational charts accurately reflect proposed changes

   - All impacted employees are shown on the Impacted Employee Listing

   - Form 14036 is included when BU employees are impacted

   - Employees are not adversely affected

   - Current vacant positions are identified on both the current and proposed organizational charts

   - New vacant positions are identified on the proposed organizational charts

   - All name changes are labeled on the proposed organizational charts


2. After the review process has been completed, the SROC package is submitted to internal and external stakeholders for approval, based upon the type of request. Approvals may include:



   - SB/SE Leadership

   - Chief Financial Officer (CFO)

   - Corporate Human Capital Office (CHCO)

   - Chief Tax Compliance Officer

   - Deputy Commissioner, IRS

   - Commissioner, IRS


**1.53.1.1.5** **(10-08-2024)**

#### Terms and Acronyms

01. **Approval Authority & Limitations:** The levels of review and approval for SROCs will vary due to the nature of the request. Once the SROC has been approved, the implementation of the new design (e.g., filling positions) must be done in accordance with current Finance and Human Capital guidelines.

02. **Approving SB/SE Executive:** The next level SB/SE Executive above the Originating SB/SE Executive.

03. **Business Case Memo:** Memorandum prepared by the originating office and included in the SROC package outlining the justification for the organizational change as required by Corporate Human Capital Office (CHCO). The business case includes the desired outcome, and other facts (e.g., workforce plan) essential for the approving official to make a well-informed decision.

04. **Classification:** The analysis and evaluation of a position to include pay category, title, series and grade level.

05. **Directed Reassignment:** An involuntary action initiated by the agency to direct the movement of an employee from one position to another without promotion or change to lower grade (CLG) (e.g., movement to a new occupational series, or to another position in the same series and grade level), where an employee and their position is realigned to a location outside of the commuting area.

06. **Functional Statements:** Statements that clearly define the purpose and responsibilities of each segment of the organization. Current SB/SE Functional Statements are located in IRM 1.1.16 Small Business/Self-Employed Division.

07. **Job Abolishment:** The termination of a position where the duties are eliminated entirely or combined with duties of another position(s). Job abolishment does not involve situations where:



    - There is no material change in official job duties and responsibilities

    - The position is re-described

    - A paperwork transaction eliminates one position and creates another

    - There is a change in title and/or series only


08. **Mass Update Module (MUM):** An application in HR Connect that HR specialists use to process a large volume of the same type of personnel actions.

09. **Operating Units:** The internal business units that comprise SB/SE (Exam, Collection, Operations Support, OFE and OPI).

10. **Organizational Change:** Any change to an organization’s structure, geographic boundaries, management structure, organizational mission or function, or business processes that may or may not result in a change in the workforce. The change may involve realignment, reorganization, or restructuring. Changes may result in abolishment of current positions, creation of new positions that did not previously exist in SB/SE, changes to position titles, series and grades, and/or excess employees.

11. **Organizational Charts:** A diagram of boxes that shows the structure of an organization and the reporting hierarchy. Each box should contain:



    - Name of group, team, department, etc, and number of positions

    - Position title/pay plan/series/grade/PD number, BU Status (e.g., Internal Revenue Agent, GS-0512-12, 23406, BU)

    - Employee name, POD and building code

    - Vacant positions


12. **Organizational Codes:** Any location within SB/SE that has a manager position is assigned its own unique set of organizational codes (e.g., groups, territories, teams or departments, etc.). The set of codes consists of Treasury Integrated Management Information System (TIMIS) codes, title, SETR, cost centers and Department ID organizational codes.



    ### Note:



    The current list of SB/SE organizational codes are located at the following link:



     Organizational Code Spreadsheets



13. **Originating SB/SE Executive:** The SB/SE Executive who promotes the organizational change and ensures that it is properly implemented subsequent to approval.

14. **Point of Contact (POC):** The individual employee who is assigned primary responsibility for development and coordination of the SROC. The individual should have complete knowledge and understanding of the proposal and direct access to the Originating Executive.

15. **Position Description (PD):** An official written statement of the major duties, responsibilities and supervisory relationships of a position.



    ### Note:



    The IRS PD library is located at the following link:



     PD\_Library - Home



16. **Position Management:** The structuring of positions into the most efficient and effective organization to accomplish the mission. Position Management is concerned with such issues as job design, career ladder development, ratio of supervisors to subordinates (span of control), appropriate use of assistants, types of positions, and cost/benefit analysis.

17. **Realignment:** The movement of an employee from one organization to another. A realignment does not result in any impact to an employee’s current position or status (e.g., series or grade, work schedule, and/or pay (including locality pay)).

18. **Reassignment:** The movement of an employee from their current position to another vacant approved position, without promotion or change to lower grade, level or pay band.

19. **Span of Control (SOC):** Ratio of supervisor to direct reports.


**1.53.1.1.6** **(10-08-2024)**

#### Related Resources

1. List of Related Resources:



   - Corporate Human Capital Office IRM 1.1.4, Organization and Staffing - Organizational Planning

   - SB/SE Functional Statements IRM 1.1.16, Organization and Staffing - Small Business / Self Employed Division

   - SROC (SB/SE Request for Organizational Change) - Home


**1.53.1.2** **(10-08-2024)**

### Policy

1. Organizational changes should improve the effectiveness and/or efficiency of an organization through the optimum use of staff and resources, while accomplishing organizational goals and objectives.

2. The following principles govern organizational design within the SB/SE Division. Organizational structures should be designed to:



   - Establish business practices which provide the highest level of customer service at the lowest possible cost

   - Eliminate unnecessary supervisory positions and organizational levels

   - Utilize the talents and capabilities of all employees


3. Once a decision is made to modify any current structure, it should be communicated and implemented in a manner that:



   - Supports the Strategic Plan

   - Minimizes disruption to business operations

   - Ensures the continuity of essential employee services

   - Promotes efficiency within SB/SE


4. The following organizational changes require approval through the SROC process prior to implementation:




| **ORGANIZATIONAL CHANGES REQUIRING SROC APPROVAL** |
| :-: |
| Create new groups, teams, territories, departments, etc. |
| Collapse groups, teams, territories, departments, etc. |
| Rename groups, teams, territories, departments, etc. |
| Realign employees |
| Eliminate vacant positions that are no longer needed |
| Increase number of analyst or overhead positions (e.g., 343’s, 301’s, etc.) |
| Increase the number of grade 14 or 15 positions |
| Change the title, series, or grade of a position |
| Increase/decrease span of control for an occupational series |
| Transfer management and program responsibility from one SB/SE Operating Unit (OU) to another |
| Create new positions that did not previously exist in the OU |
| Create/abolish/merge Areas and Divisions |
| Substantially modify the employment base in any state |
| Close/move Posts of Duty |
| Close/build/move an IRS facility |
| Create occupation upgrades |
| Changes that impact National Labor Agreements |
| Transfer management and program responsibility from one operating division to another |
| Create new positions that did not previously exist in the IRS |
| IRS Servicewide changes in authority, function or scope of activities |
| Directed reassignment |
| Create/abolish/promote Executive level positions |





### Note:



All new Executive positions require approval from the Corporate Human Capital Office (CHCO) and the Executive Resources Board (ERB).

5. A six-month rule exists that freezes subsequent transitions affecting the same employees. Business units are not permitted to submit an SROC when there are changes in the employees’ work, organizational structure, or transition efforts for six months from approval of the prior SROC.




| **Exceptions to the Six-Month Rule:** |
| :-: |
| When there is no change in organizational codes |
| When there is only a change in the organizational name |
| Movement of an employee or group of employees corrects a staffing imbalance or Span of Control (SOC) issue, where the resources did not materialize as originally planned by the SROC and there is no change in working conditions to the employees being realigned/reassigned (e.g., series, grade or work) |


**1.53.1.3** **(07-17-2025)**

### Documents Required for SROC Submission

1. **SROC Template**



   - Document is used to describe and justify the organizational change request

   - Originating Executive signature is required on this form


2. **Business Case Memo**



   - Document required by CHCO to process an organizational change request

   - Memo is written from the Originating Executive to the second level Executive

   - Memo details proposed changes, purpose and justification


3. **Current Organizational Chart** shows the current structure of the organization with existing employees and vacant positions.



### Note:



The SROC Team will provide the most recent organizational chart from the HR Reporting Center after the initial consultation meeting.

4. **Proposed Organizational Chart** shows the future structure of the organization with proposed changes and realignments.

5. **Impacted Employee Listing** is a spreadsheet containing all impacted employees (BU and NBU).

6. **Form 14036, Notice to National Treasury Employees Union (NTEU)** is used to notify NTEU when BU employees are impacted in an organizational change.



### Note:



For additional information, refer to the SROC Desk Guide on the SROC SharePoint. SROC (SB/SE Request for Organizational Change) - Home


**1.53.1.4** **(10-08-2024)**

### Implementation

1. Upon completion of the SROC, the Originating Executive is responsible for ensuring:



   - Personnel Action Requests (PARs) and system changes (e.g., ICS, Concur, RGS, etc.) are initiated and completed timely

   - NTEU notification process has been completed

   - Labor Relations issues are resolved prior to implementation

   - Implementation of the new design (e.g., filling positions) is completed in accordance with current Finance and Human Capital guidelines


2. New organizational codes will be provided with the approved SROC package.

3. When an SROC Package includes realigning 75 or more employees, it is recommended to request a MUM instead of initiating your own realignment PARs. To reserve a MUM date, contact the SB/SE MUM Team at \*SBSE Reorganization after SROC submission.

4. If your organizational changes impact less than 75 employees, please email \*SBSE Reorganization for procedural guidance on inputting PARs. The guidance will help mitigate any potential risks.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-053-001#addtoany "Show all")

A2A