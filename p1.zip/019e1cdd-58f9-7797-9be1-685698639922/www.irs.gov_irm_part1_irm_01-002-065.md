---
url: "https://www.irs.gov/irm/part1/irm_01-002-065"
title: "1.2.65 Small Business/Self-Employed Division Delegations of Authority | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-002-065#main-content)

- 1.2.65  [Small Business/Self-Employed Division Delegations of Authority](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138848080)
  - 1.2.65.1  [Overview](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138841184)
  - 1.2.65.2  [SB/SE Functional Delegation Orders - Commissioner’s Office](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111826592)
    - 1.2.65.2.1  [SB/SE 1-23-1 (Rev. 2), Authority to Act in the Absence of the Commissioner, Small Business/Self-Employed Division and Other Top-Level Headquarters Executives](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111824816)
    - 1.2.65.2.2  [SB/SE 1-23-10, Authority to Sign Memoranda of Understanding](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110765392)
  - 1.2.65.3  [SB/SE Functional Delegation Orders - Collection](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138922768)
    - 1.2.65.3.1  [SB/SE 1-23-2 (Rev. 2), Authority to Sign and Issue Levy and Related Documents](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138921184)
    - 1.2.65.3.2  [SB/SE 1-23-9, Approval of Form 4477, Civil Suit Recommendation](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138694688)
    - 1.2.65.3.3  [SB/SE 1-23-11, Authority to Sign Memoranda of Understanding (MOUs) for Local Collection Locator Services](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138847472)
    - 1.2.65.3.4  [SB/SE 1-23-15, (Rev. 1), Error Tolerance Levels](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985139245728)
    - 1.2.65.3.5  [SB/SE 1-23-16, Authority to Sign Form 23C, Assessment Certificate](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110911392)
    - 1.2.65.3.6  [SB/SE 1-23-21, Authority to Sign Notices of Disallowance of Claim for Refund and Agreements to Final Determination of Liability Related to Assessments Made Under IRC 6672](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111020464)
    - 1.2.65.3.7  [SB/SE 1-23-22, Authority to Sign Letter 1153, Notification Letter Regarding Form 2751, Proposed Assessment of Trust Fund Recovery Penalty](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110753088)
    - 1.2.65.3.8  [SB/SE 1-23-23, Commercial Title Searches](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110923600)
    - 1.2.65.3.9  [SB/SE 1-23-24, Authority to Sign Agreements to Extend the Running of the Period of Time to Bring Suit](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138855312)
    - 1.2.65.3.10  [SB/SE 1-23-25, Authority to Accept Legal Process Service](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138686496)
    - 1.2.65.3.11  [SB/SE 1-23-26, Authority to Sign Form 792](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985139233856)
    - 1.2.65.3.12  [SB/SE 1-23-27, Authority to Approve, Sign and Accept Bonds and Collateral Agreements](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985139174880)
    - 1.2.65.3.13  [SB/SE 1-23-28, Authority to Refuse to Accept Payment by Personal Check](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138681008)
    - 1.2.65.3.14  [SB/SE 25-6-1, Authority to Obligate Funds for Payment to Third Parties Who Request Reimbursement for Cost of Complying with a Summons (Form 6863)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138672960)
  - 1.2.65.4  [SB/SE Functional Delegation Orders - Examination](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138790816)
    - 1.2.65.4.1  [SB/SE 1-23-4, Authority to Issue Notices for Termination and Jeopardy Assessments](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110830736)
    - 1.2.65.4.2  [SB/SE 1-23-5, Determination Letters Relating to Income, Estate & Gift, Excise and Employment Taxes](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110846096)
    - 1.2.65.4.3  [SB/SE 1-23-7, Approval, Denial, Suspension or Revocation of Form 637, Application for Registration (for Certain Excise Tax Activities)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110836128)
    - 1.2.65.4.4  [SB/SE 1-23-13, Authority to Sign Claim Disallowance Notices](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111008976)
    - 1.2.65.4.5  [SB/SE 1-23-14, Authority to Sign Requests for Technical Advice (Form 4463)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110949104)
    - 1.2.65.4.6  [SB/SE 1-23-17, Authority to Request and Inspect Preparer Records](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110941232)
    - 1.2.65.4.7  [SB/SE 1-23-18, Letters Requesting Permission for a Blanket Exemption on Form 1363, Export Exemption Certificate](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111811520)
    - 1.2.65.4.8  [SB/SE 1-23-19, Authority to Waive Personal Inspection of Decedent's Household or Personal Effects and/or Distribute Personalty](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111177728)
    - 1.2.65.4.9  [SB/SE 1-23-20, Authority to Approve a Tip Reporting Alternative Commitment (TRAC) or a Tip Rate Determination Agreement (TRDA)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111169584)
    - 1.2.65.4.10  [SB/SE 1-23-29, Relief of a Corporation from the Necessity of Making a Return](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138713648)
    - 1.2.65.4.11  [SB/SE 1-23-30, Authority to Sign Form 1254, Examination Suspense Report](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138705008)
    - 1.2.65.4.12  [SB/SE 1-23-31, Authority to Sign Letters Acknowledging Receipt of an IRC Section 897(i) Election by a Foreign Corporation to be Treated as a Domestic Corporation Pursuant to Treasury Regulation Section 1.897-3](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138734336)
    - 1.2.65.4.13  [SB/SE 1-23-32, Signature Authority Under Treasury Regulations 1.1445-3 and 1.1445-6 Foreign Investment in Real Property Tax Act (FIRPTA)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138726064)
    - 1.2.65.4.14  [SB/SE 1-23-33, Authority to Grant Extensions of Time to Replace Involuntarily Converted Property Under Section 1033 of the Internal Revenue Code](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110686032)
    - 1.2.65.4.15  [SB/SE 1-23-34, Authority to Grant an Extension of Time for S-Corporation Elections](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110677104)
    - 1.2.65.4.16  [SB/SE 1-23-35, Authority to Grant or Deny Extensions of Time with Respect to Foreclosure Property Held by a Real Estate Investment Trust (REIT) or Real Estate Mortgage Investment Conduit (REMIC)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138626672)
    - 1.2.65.4.17  [SB/SE 1-23-36, Requests for Prompt Assessment Under IRC Section 6501(d)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138618320)
    - 1.2.65.4.18  [SB/SE 1-23-37, Authority to Issue Objection or Non-Objection Letters to Taxpayers Requesting Approval to File Form 3115](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138610304)
    - 1.2.65.4.19  [SB/SE 1-23-38, Request for Approval to Use IDRS Command Code ESTAB](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138908096)
    - 1.2.65.4.20  [SB/SE 1-23-39, Authority to Sign Pattern Letter P-450 Advising Fiduciary of Acceptance of Returns or that Examination is Warranted](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138899232)
    - 1.2.65.4.21  [SB/SE 1-23-40, Authority to Sign a Claim Invitation Letter](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138889760)
    - 1.2.65.4.22  [SB/SE 1-23-41, Authority to Approve Agreement as to Useful Life, Method, and Rate of Depreciation of Property](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111253040)
    - 1.2.65.4.23  [SB/SE 1-23-42, Request to Use Estimated Costs of Future Improvements in Basis in Determining Gain or Loss on the Sale of Lots](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111244992)
    - 1.2.65.4.24  [SB/SE 1-23-43, Revocation of Election to Adjust Basis of Partnership Property Under IRC Section 754](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111236896)
    - 1.2.65.4.25  [SB/SE 1-23-44, Authority to Approve Adoption of the Method of Deducting Soil and Water Conservation Expenditures Covered Under IRC Section 175](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138885824)
    - 1.2.65.4.26  [SB/SE 1-23-45, Authority to Abate Failure to File Penalty With Respect to Foreign Corporations or Foreign Partnerships](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138877584)
    - 1.2.65.4.27  [SB/SE 1-23-47, Approval or Denial / Revocation of Secure Airport Terminal (SAT) Designations](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138869536)
    - 1.2.65.4.28  [SB/SE 1-23-48, Authority to Sign Notice and Demand Letters for Tip Employer and Employee Taxes Under IRC Section 3121(q)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138829872)
    - 1.2.65.4.29  [SB/SE 1-23-49, Authority to Issue, Modify and Sign Determination Letters Under IRC Section 6053 (c)(3)(C)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138821696)
    - 1.2.65.4.30  [SB/SE 1-23-50, Functions Related to Potential Preparer, Promoter and Tax Shelter Cases](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138813472)
    - 1.2.65.4.31  [SB/SE 1-23-51, Responsibilities in Grand Jury Investigations Affecting Non-Grand Jury Cases](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111294176)
    - 1.2.65.4.32  [SB/SE 1-23-52, Authority to Issue Notice of Determination of Liability Letter in Bankruptcy and Receivership Cases](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111286064)
    - 1.2.65.4.33  [SB/SE 1-23-53, Review of Unenrolled Preparers’ Authority to Act Before the Service](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111278032)
    - 1.2.65.4.34  [SB/SE 1-23-54, Authority to Sign Information Letters](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111269952)
    - 1.2.65.4.35  [SB/SE 1-23-55, Authority to Sign Thirty Day Letters](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111882176)
    - 1.2.65.4.36  [SB/SE 1-23-56, Authority to Sign and Issue Notice of Proposed Penalty for Non-Filing of Forms 3520 and 3520A](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111872544)
    - 1.2.65.4.37  [SB/SE 1-23-57, Determination of Reasonable Cause for Failure to File Dual Consolidated Loss Documents](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111863904)
    - 1.2.65.4.38  [SB/SE 1-23-58, Authority to Issue Innocent Spouse Final Determination Notices](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111854192)
    - 1.2.65.4.39  [SB/SE 1-23-59, Uncollected Tax Report Acknowledgment Signature Authority](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110885184)
    - 1.2.65.4.40  [SB/SE 4-1-1, Authority to Sign Agreements for Personal Holding Company Tax](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110872720)
    - 1.2.65.4.41  [SB/SE 4-2-1, Extension of Time for Filing Statement of Grounds for Earnings and Profits Accumulation](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110864672)
    - 1.2.65.4.42  [SB/SE 4-32-1, Authority to Execute Closing Agreements Subject to IRS and Resolution Trust Corporation (RTC) Inter-Agency Agreement Dated December 10, 1992 ("Agreement" )](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110856544)
    - 1.2.65.4.43  [SB/SE 4-5-1 (Rev. 1), Agreements Treated as Determinations under IRC Section 1313(a)(4)](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110848304)
    - 1.2.65.4.44  [SB/SE 8-3-1, Closing Agreements Concerning Internal Revenue Tax Liability](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138662448)
    - 1.2.65.4.45  [SB/SE 25-5-1, Authority to Disseminate Bank Secrecy Act (BSA) Examination Information to State Regulatory Agencies](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138653184)
  - 1.2.65.5  [SB/SE Functional Delegation Orders - Operations Support](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111158448)
    - 1.2.65.5.1  [SB/SE 1-7-1, Authority to Approve Attendance at Meetings at Government Expense](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111156688)
    - 1.2.65.5.2  [SB/SE 6-3-1, Delegation of Authority in Labor-Management Relations Matters](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111148464)
    - 1.2.65.5.3  [SB/SE 1-66-1, Authorization to Execute Settlement Agreements in Equal Employment Opportunity Matters](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111132592)
  - 1.2.65.6  [SB/SE Functional Delegation Orders - Emergency Orders of Succession](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138771088)
    - 1.2.65.6.1  [SB/SE 1-23-98, Emergency Order of Succession - Deputy Commissioner, Collection and Operations Support, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138768416)
    - 1.2.65.6.2  [SB/SE 1-23-99, Emergency Order of Succession - Deputy Commissioner, Examination, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138758224)
    - 1.2.65.6.3  [SB/SE 1-23-100 (Rev. 1), Emergency Order of Succession - Commissioner, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985138747568)
    - 1.2.65.6.4  [SB/SE 1-23-102, Emergency Order of Succession - Director Collection, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985111003888)
    - 1.2.65.6.5  [SB/SE 1-23-103 (Rev. 1), Emergency Order of Succession - Director Examination, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110993296)
    - 1.2.65.6.6  [SB/SE 1-23-104 (Rev. 1), Emergency Order of Succession - Director Operations Support, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110982240)
    - 1.2.65.6.7  [SB/SE 1-23-105, Emergency Order of Succession - Director Field Collection, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110971152)
    - 1.2.65.6.8  [SB/SE 1-23-106, Emergency Order of Succession - Director Examination-Campus, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110960512)
    - 1.2.65.6.9  [SB/SE 1-23-107, Emergency Order of Succession - Director Examination-Field, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985143279968)
    - 1.2.65.6.10  [SB/SE 1-23-108, Emergency Order of Succession - Director Collection-Campus, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985143269376)
    - 1.2.65.6.11  [SB/SE 1-23-109, Emergency Order of Succession - Deputy Director, Examination, Small Business/Self-Employed Division](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985143258736)
  - Exhibit  1.2.65-1  [SB/SE Delegation Orders by Old Number, New Number, and Title](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985143249072)
  - Exhibit  1.2.65-2  [SB/SE 1-23-2 (Rev. 2), Authority to Sign and Issue Levy and Related Documents](https://www.irs.gov/irm/part1/irm_01-002-065#idm139985110709632)

# Part 1. Organization, Finance, and Management

# Chapter 2. Servicewide Policies and Authorities

# Section 65. Small Business/Self-Employed Division Delegations of Authority

* * *

## 1.2.65 Small Business/Self-Employed Division Delegations of Authority

#### Manual Transmittal

August 31, 2023

#### Purpose

(1) This transmits revised IRM 1.2.65, Servicewide Policies and Authorities - Small Business/Self-Employed Division Delegations of Authority.

#### Material Changes

(1) The following changes were made to IRM 1.2.65:

- IRM 1.2.65.3.4- Updated subsection to reflect revisions made to Delegation Order 1-23-15 (Rev. 1), Error Tolerance Levels.

- IRM 1.2.65.4.6 - Added new subsection to include Delegation Order 1-23-17, Authority to Request and Inspect Preparer Records.

- IRM 1.2.65.5.3 - Added new subsection to include Delegation Order 1-66-1, SB/SE Authority to Execute Settlement Agreements in Equal Employment Opportunity Matters.


(2) Exhibit 1.2.65-1, SB/SE Delegation Orders by Old Number, New Number, and Title, was updated to include new delegation orders.

(3) Throughout this IRM section, editorial and formatting corrections were made. Links and references were updated.

#### Effect on Other Documents

IRM 1.2.65, dated 10-11-2022, is superseded.

#### Audience

SB/SE - All functions

#### Effective Date

(08-31-2023)

Rashaunda Simmons

Director, Human Capital Office

Small Business/Self-Employed (SB/SE)

**1.2.65.1** **(08-31-2023)**

### Overview

1. This IRM contains the delegation orders (DO) for the Small Business/Self-Employed (SB/SE) Division. Distribution of this IRM should include all persons with a need for any of the authorities or information in this section. SB/SE delegation orders that have been rescinded or revoked are _not_ retained in this IRM.

2. Delegation orders are the published documents that record official delegations of authority. Delegations of authority:



   - Place authority in the position(s) where actual operational responsibility resides;

   - Free officials from having to consider issues which can be handled at lower levels; and

   - Reduce the time and resources spent when matters are forwarded to commissioners for action, by allowing designated offices to handle the matters directly.


3. There are two levels of delegation orders:



   - Servicewide Delegation Orders - commissioner level

   - Division/Function Delegation Orders - division commissioner level


4. SB/SE has established two types of division/function delegation orders:



   - Functional delegation orders

   - Functional delegation orders - Emergency Orders of Succession


### Note:

These are the two types of delegation orders discussed in this IRM, organized by business process, and listed in numerical sequence. The subsection date appearing above each title is the effective date of that delegation order.

5. Each SB/SE delegation order is based on a servicewide delegation order. General information on the servicewide DO process can be found in IRM 1.11.4, Delegation Orders. Specific servicewide delegations of authority can be found in IRM 1.2.2, Servicewide Delegations of Authority.

6. SB/SE functional delegation orders that are approved or revised after the publication of this IRM can be found at: https://www.irs.gov/uac/recently-approved-delegation-orders-and-policy-statements. They remain on the web until the next revision is made to this IRM section. Questions about current delegation orders, including revisions or issuance of a new DO, may be directed to the SB/SE Internal Management Document (IMD) Team at: sbse.imd@irs.gov.


**1.2.65.2** **(10-07-2019)**

### SB/SE Functional Delegation Orders - Commissioner’s Office

1. The following delegation orders pertain to the direct reports of the SB/SE Commissioner.


**1.2.65.2.1** **(06-23-2020)**

#### SB/SE 1-23-1 (Rev. 2), Authority to Act in the Absence of the Commissioner, Small Business/Self-Employed Division and Other Top-Level Headquarters Executives

01. **Authority to Act in the Absence of the Commissioner, Small Business/Self-Employed Division and Other Top-Level Headquarters Executives**

02. **Authority:** To act in the absence of the Commissioner, Small Business/Self-Employed Division (SB/SE).



    > The management officials who occupy the positions listed below are authorized in order of succession to the position of Commissioner, Small Business/Self-Employed Division.





    > The official named as successor will be vested with all of the authority given the Commissioner, Small Business/Self-Employed Division until relieved of the responsibility.

03. **Delegated to:**



    - Deputy Commissioner, Collection and Operations Support (SB/SE)

    - Deputy Commissioner, Examination (SB/SE)

    - Director, Operations Support (SB/SE)

    - Director, Examination (SB/SE)

    - Director, Collection (SB/SE)


04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To act in the absence of the **Director, Operations Support**, Small Business/Self-Employed Division.



    > The management officials who occupy the positions listed below are authorized in order of succession to the position of Director, Operations Support, Small Business/Self-Employed Division.





    > The official named as successor will be vested with all of the authority given the Director, Operations Support, Small Business/Self-Employed Division until relieved of the responsibility.

06. **Delegated to:**



    - Director, Business Support (SB/SE)

    - Director, Business Development (SB/SE)

    - Director, Human Capital (SB/SE)

    - Director, Technology Solutions (SB/SE)


07. **Redelegation:** This authority may not be redelegated.

08. **Authority:** To act in the absence of the Director, Examination, Small Business/Self-Employed Division.



    > The management officials who occupy the positions listed below are authorized in order of succession to the position of Director, Examination, Small Business/Self-Employed Division.





    > The official named as successor will be vested with all of the authority given the Director, Examination, Small Business/Self-Employed Division until relieved of the responsibility.

09. **Delegated to:**



    - Deputy Director, Examination (SB/SE)

    - Director, Headquarters Examination (SB/SE)

    - Director, Campus Examination (SB/SE)

    - Director, Field Examination (SB/SE)


10. **Redelegation:** This authority may not be redelegated.

11. **Authority**: To act in the absence of the Director, Collection, Small Business/Self-Employed Division.



    > The management officials who occupy the positions listed below are authorized in order of succession to the position of Director, Collection, Small Business/Self-Employed Division.





    > The official named as successor will be vested with all of the authority given the Director, Collection, Small Business/Self-Employed Division until relieved of the responsibility.

12. **Delegated to:**



    - Director, Headquarters Collection (SB/SE)

    - Director, Campus Collection (SB/SE)

    - Director, Field Collection (SB/SE)


13. **Redelegation:** This authority may not be redelegated.

14. **Source of Authority:**Servicewide Delegation Order 1-23

15. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes Delegation Order SB/SE-1-23-1, Rev. 1.

16. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.2.2** **(04-01-2003)**

#### SB/SE 1-23-10, Authority to Sign Memoranda of Understanding

1. **Authority to Sign Memoranda of Understanding (MOUs)** (formerly SB/SE DO 1.24)

2. **Authority:** To sign Intradivisional and External Memoranda of Understanding (MOUs) including those with states, federal agencies and other stakeholders in agreements that involve no additional resources and are consistent with the SB/SE Strategic Plan.

3. **Delegated to:** Operating Unit Executives (Direct Reports)

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** John E. Binnion, for Commissioner, Small Business/Self-Employed Division.


**1.2.65.3** **(05-21-2020)**

### SB/SE Functional Delegation Orders - Collection

1. The following delegation orders pertain to the Collection business process.


**1.2.65.3.1** **(09-09-2016)**

#### SB/SE 1-23-2 (Rev. 2), Authority to Sign and Issue Levy and Related Documents

1. **Authority to Sign and Issue Levy and Related Documents**

2. **Authority**: To sign and issue levies and related documents in accordance with Sections 6331 through 6344 and Section 7429 of the Internal Revenue Code and regulations.

3. **Delegated to:** Refer to the chart in _Exhibit 1.2.65-2_

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE DO 1-23-2 (Rev. 1).

7. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.2** **(12-22-2016)**

#### SB/SE 1-23-9, Approval of Form 4477, Civil Suit Recommendation

01. **Approval of Form 4477, Civil Suit Recommendation** (formerly SB/SE DO 145.2, Rev. 3)

02. **Authority:** To approve any Form 4477, Civil Suit Recommendation.

03. **Delegated to:**



    - Directors, Field Area Collection

    - Director, Specialty Collection - Offers, Liens, & Advisory

    - Director, Specialty Collection - Insolvency


04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To approve Form 4477, Civil Suit Recommendation, other than for a suit to obtain judicial approval to seize an IRC 6334(e)(1) defined principal residence, or a lien foreclosure suit involving property used as a principal residence by any individual.

06. **Delegated to:**



    - Collection Territory Managers

    - Collection Advisory Territory Managers


07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:**Servicewide Delegation Order 1-23

09. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes Delegation Order SB/SE 145.2, Rev. 2.

10. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.3** **(03-16-2016)**

#### SB/SE 1-23-11, Authority to Sign Memoranda of Understanding (MOUs) for Local Collection Locator Services

1. **Authority to Sign Memoranda of Understanding (MOUs) for Local Collection Locator Services**

2. **Authority:** To sign Intradivisional and External Memoranda of Understanding (MOUs) for Local Collection Locator Services including those with states, federal agencies and other stakeholders in agreements that involve no additional resources and are consistent with the SB/SE Strategic Plan.

3. **Delegated to:** Director, Quality and Technical Support

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.4** **(01-30-2023)**

#### SB/SE 1-23-15, (Rev. 1), Error Tolerance Levels

1. **Error Tolerance Levels** (formerly SB/SE DO 4.41, rev. 3)

2. **Authority:** To accept and process cases with errors if the correction would be unfavorable to the taxpayer (more tax due or less refund). Employee Audit cases are excluded from this authority.

3. **Delegated to:**




| Delegated Amount | Official |
| --- | --- |
| Errors less than $500 per tax year | Reviewers in Technical Services; Team Managers in Centralized Case Processing (CCP), each based on the facts and circumstances of the case. |
| Errors less than $5,000 per tax year | Managers in Technical Services; Managers in Field Examination; Managers in Specialty Examination; Field Office Resource Team (FORT) Managers and Department Level Managers in CCP, each based on the facts and circumstances of the case. |
| Errors less than $10,000 per tax year | Territory Managers in Technical Services; Territory Managers in Field Examination; Territory Managers in Specialty Examination; Operations Managers in CCP, each based on the facts and circumstances of the case. |
| Errors more than $10,000 per tax year | Directors in Field Examination; Director, Specialty Examination; Directors in Campus Examination, each based on the facts and circumstances of the case. |

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Amalia C. Colbert, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.5** **(10-01-2000)**

#### SB/SE 1-23-16, Authority to Sign Form 23C, Assessment Certificate

1. **Authority to Sign Form 23C, Assessment Certificate** (formerly SB/SE DO 145.17)

2. **Authority:** To sign Form 23C, Assessment Certificate, on behalf of the Area Director.

3. **Delegated to:**



   - Revenue Officers, GS-9 and above

   - Revenue Agents, GS-11 and above


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.6** **(12-22-2016)**

#### SB/SE 1-23-21, Authority to Sign Notices of Disallowance of Claim for Refund and Agreements to Final Determination of Liability Related to Assessments Made Under IRC 6672

1. **Authority to Sign Notices of Disallowance of Claim for Refund and Agreements to Final Determination of Liability Related to Assessments Made Under IRC 6672** (formerly SB/SE DO 5.7, Rev. 3)

2. **Authority:** To sign Notices of Disallowance of Claim for Refund of erroneously, illegally, or excessively collected taxes and agreements to final determination of liability related to assessments made under IRC 6672, Trust Fund Recovery Cases.

3. **Delegated to:** Collection Advisory Group Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 5.7 (Rev. 2).

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.7** **(12-22-2016)**

#### SB/SE 1-23-22, Authority to Sign Letter 1153, Notification Letter Regarding Form 2751, Proposed Assessment of Trust Fund Recovery Penalty

1. **Authority to Sign Letter 1153, Notification Letter Regarding Form 2751, Proposed Assessment of Trust Fund Recovery Penalty** (formerly SB/SE DO 5.16, Rev. 1)

2. **Authority:** To sign Letter 1153, Notification Letter Regarding Form 2751, Proposed Assessment of Trust Fund Recovery Penalty, related to assessments made under IRC 6672.

3. **Delegated to:**



   - Revenue Officers

   - Bankruptcy Specialists


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 5.16.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.8** **(12-22-2016)**

#### SB/SE 1-23-23, Commercial Title Searches

1. **Commercial Title Searches** (formerly SB/SE DO 5.6, Rev. 1)

2. **Authority:** To authorize the purchase of commercial title searches for use in the preparation for seizure and sale of real property under authority of Sections 6331 and 6335 of the Internal Revenue Code and for use in civil litigation by or against the United States.

3. **Delegated to:**



   - Revenue Officer Group Managers

   - Collection Advisory Group Managers

   - Property Acquisition and Liquidation Specialist (PALS) Group Managers


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 5.6.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.9** **(01-02-2022)**

#### SB/SE 1-23-24, Authority to Sign Agreements to Extend the Running of the Period of Time to Bring Suit

1. **Authority to Sign Agreements to Extend the Running of the Period of Time to Bring Suit**

2. **Authority:** To sign agreements under Treasury Regulation Section 301.6532-1(b) extending the period of time for filing suit.

3. **Delegated to:**



   - Revenue Officers

   - Revenue Agents Grade GS-11 in Technical Services and Planning and Special Programs (PSP)

   - Program Managers in Campus Examination

   - Department Managers in Campus Examination

   - Revenue Agent Pas-Through Coordinators assigned to the Campus Pas-Through Function (CPF), Grade GS-12


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes Delegation Order 1-23-24.

7. **Signed:** De Lon Harris, Examination Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.10** **(01-18-2017)**

#### SB/SE 1-23-25, Authority to Accept Legal Process Service

1. **Authority to Accept Legal Process Service** (formerly SB/SE DO 145.4, Rev. 1)

2. **Authority:** To accept services for legal processes directed at the Area Director.

3. **Delegated to:**



   - Collection Territory Managers

   - Examination Territory Managers

   - Collection Advisory Group Managers

   - Examination Technical Services Managers


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 145.4.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.11** **(02-20-2017)**

#### SB/SE 1-23-26, Authority to Sign Form 792

1. **Authority to Sign Form 792** (formerly SB/SE DO 145.12, Rev. 1)

2. **Authority:** To sign Form 792 (United States Certificate Discharging Property Subject to Estate Tax Lien).

3. **Delegated to:**



   - Collection Advisory Group Managers

   - Collection Advisory Estate Tax Lien Group Managers


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 145.12.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.12** **(07-01-2017)**

#### SB/SE 1-23-27, Authority to Approve, Sign and Accept Bonds and Collateral Agreements

1. **Authority to Approve, Sign and Accept Bonds and Collateral Agreements** (formerly SB/SE DO 5.3, Rev. 2)

2. **Authority:** To sign documents required in approving, signing and accepting bonds and/or collateral agreements for: Stay of Collection under IRC 6165 and IRC 6672(b), Extension of Time to Pay Estate Tax under IRC 6166, Extension of Time to Pay Estate Tax Under IRC 6161, Substitution of Security for Lien under IRC 6324B or under IRC 2032A, Form of Bonds or Other Security under IRC 7101, Stay of Assessment and Collection under IRC 7485, and Release of Lien or Discharge of Property under IRC 6325(c).

3. **Delegated to:**



   - Collection Territory Managers

   - Collection Advisory Group Managers


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 5.3, Rev. 1.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.13** **(05-25-2017)**

#### SB/SE 1-23-28, Authority to Refuse to Accept Payment by Personal Check

1. **Authority to Refuse to Accept Payment by Personal Check** (formerly DO 145.6, Rev. 2)

2. **Authority:** The authority under Treasury Regulation 301.6311-1(a)(1) to refuse to accept any personal check in payment of federal taxes whenever good reason exists to believe that such check will not be honored upon presentment.

3. **Delegated to:** Group Managers and Department Managers who have responsibility with remittance receipts

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 145.6, Rev. 1.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.3.14** **(12-15-2010)**

#### SB/SE 25-6-1, Authority to Obligate Funds for Payment to Third Parties Who Request Reimbursement for Cost of Complying with a Summons (Form 6863)

1. **Authority to Obligate Funds for Payment to Third Parties Who Request Reimbursement for Cost of Complying with a Summons (Form 6863)** (formerly SB/SE DO 178-1)

2. **Authority:** The authority to obligate appropriated funds for payment of search costs, reproduction costs and transportation costs in connection with third party summonses issued under the Internal Revenue laws.

3. **Delegated to:**




| Obligated Amount | Official |
| --- | --- |
| To obligate up to $10,000 for payment of such costs associated with any one summons | Area Directors |
| To obligate up to $5,000 for payment of such costs associated with any one summons | Territory Managers |
| To obligate up to $2,500 for payment of such costs associated with any one summons | Revenue Officers Grade GS-9, Revenue Agents, Tax Auditors, Tax Compliance Officers, Estate Tax Attorneys and Estate Tax Examiners |

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Delegation Order 25-6.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 178-1 (formerly SB/SE DO 145.9).

7. **Signed:** Christopher Wagner, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4** **(05-21-2020)**

### SB/SE Functional Delegation Orders - Examination

1. The following delegation orders pertain to the Examination business process.


**1.2.65.4.1** **(12-02-2014)**

#### SB/SE 1-23-4, Authority to Issue Notices for Termination and Jeopardy Assessments

01. **Authority to Issue Notices for Termination and Jeopardy Assessments** (formerly SB/SE DO 145-15, Rev. 1)

02. **Authority:** To sign the Notice of Termination of Taxable Period, after the Area Director determines the period of such taxpayer immediately terminated under Treasury Regulation Section 1.6851-1.

03. **Delegated to:** Technical Services Group Managers

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To sign the Notice of Jeopardy Assessment and Right of Appeal after Chief Counsel for the Internal Revenue Service (or such Counsel’s delegate) personally approves (in writing) such assessment recommendation pursuant to IRC 7429(a)(1).

06. Delegated to: Technical Services Group Managers

07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:**Servicewide Delegation Order 1-23

09. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

10. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.2** **(03-25-2019)**

#### SB/SE 1-23-5, Determination Letters Relating to Income, Estate & Gift, Excise and Employment Taxes

1. **Determination Letters Relating to Income, Estate & Gift, Excise and Employment Taxes** (formerly SB/SE DO 4.54, Rev. 3)

2. **Authority:** To sign determination letters relating to income, estate and gift, excise and employment taxes as described in First Revenue Procedures of each calendar year.

3. **Delegated to:**



   - Technical Services Examination Group Managers (Income Tax)

   - Program Manager, Estate & Gift Tax Policy (Estate & Gift Tax)

   - Program Manager, Excise Tax Policy and Fuel Tax Policy (Excise Tax)

   - Program Manager, Employment Tax Policy (Employment Tax)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.54 (Rev. 2).

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.3** **(05-21-2018)**

#### SB/SE 1-23-7, Approval, Denial, Suspension or Revocation of Form 637, Application for Registration (for Certain Excise Tax Activities)

01. **Approval, Denial, Suspension or Revocation of Form 637, Application for Registration (for Certain Excise Tax Activities)** (formerly SB/SE DO 4.36, Rev. 3)

02. **Authority:** To approve applications for Form 637, Application for Registration (for Certain Excise Tax Activities)

03. **Delegated to:**



    - Field Group Managers, Excise Group Managers

    - Group Manager, 637 Registration Group

    - Lead Technicians, 637 Registration Group



      ### Note:



      The authority delegated to lead technicians is to the extent the Form 637 application or existing registration is a designated 637 Registration Group case.


04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To deny a 637 application or to suspend or revoke an existing 637 registration. The authority to approve the denial, suspension or revocation letter applies if:



    - An applicant or registrant does not meet all the applicable registration tests,

    - An applicant or registrant has not responded within 30 days to a request for additional information relating to its application or existing registration, or

    - An existing registrant has used its registration to evade, or attempt to evade, the payment of any tax imposed by IRC 4041(a)(1) or IRC 4081; or to postpone, or in any manner to interfere with collection of any such tax; or to make a fraudulent claim for a credit or payment; or has aided or abetted another person in evading, or attempting to evade, payment of any tax imposed by 4041(a)(1) or 4081; or in making a fraudulent claim for a credit or payment; or has, at any time, failed to comply with the terms and conditions of registration.


06. **Delegated to:**



    - Field Group Managers, Excise Tax Examination

    - Group Manager, 637 Registration Group


07. **Redelegation:** This authority may not be redelegated.

08. **Authority:** To deny a 637 application or to suspend or revoke an existing 637 registration. Uncontested denials, suspensions, or revocations. These are denials, suspensions, or revocations where the applicant or existing registrant does not object to our determination. The authority to approve the denial, suspension or revocation letter is

09. **Delegated to:**



    - Field Group Managers, Excise Tax Examination

    - Group Manager, 637 Registration Group


10. **Redelegation:** This authority may not be redelegated.

11. **Authority:** To deny a 637 application or to suspend or revoke an existing 637 registration. Contested denials, suspensions, or revocations. These are denials, suspensions, or revocations where the applicant or existing registrant objects to our determination in writing. In these instances, the authority to approve the denial, suspension or revocation is

12. **Delegated to:** Chief, Estate and Gift and Excise Tax Exam

13. **Redelegation:** This authority may not be redelegated.

14. **Source of Authority:**Servicewide Delegation Order 1-23



    - Form 637 Registration: IRC Sections 4101, 4222 and 4682; Treas. Regs 48.4101-1


15. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes Delegation Order 4.36 (Rev. 2).

16. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.4** **(10-01-2005)**

#### SB/SE 1-23-13, Authority to Sign Claim Disallowance Notices

1. **Authority to Sign Claim Disallowance Notices** (formerly SB/SE DO 4.1, Rev. 1)

2. **Authority:** To sign and to send to taxpayers, by registered or certified mail, notices of disallowance of refund cases.

3. **Delegated to:** Technical Services Examination Reviewers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Kevin M. Brown, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.5** **(10-01-2000)**

#### SB/SE 1-23-14, Authority to Sign Requests for Technical Advice (Form 4463)

1. **Authority to Sign Requests for Technical Advice (Form 4463)** (formerly SB/SE DO 4-15)

2. **Authority:** To review and approve requests for Technical Advice (Form 4463)

3. **Delegated to:** Revenue Agent Reviewers Grade GS-13

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.6** **(04-18-2017)**

#### SB/SE 1-23-17, Authority to Request and Inspect Preparer Records

1. **Authority to Request and Inspect Preparer Records** (formerly DO SB/SE-145.7, rev.1)

2. **Authority:** To request an inspect the following records pursuant to Treasury Regulation Section 1.6107-1(b), which requires return preparers to make a copy available for inspection upon the request of the Area Director: (1) returns or claims for refund, or (2) records of returns and claims for refund, and (3) records of the individual preparer required to sign the returns or claim for refund pursuant to Treasury Regulation Section 1.6695-1.

3. **Delegated to:**



   - Revenue Officers

   - Revenue Agents

   - Tax Compliance Officers

   - Tax Auditors

   - Estate and Gift Tax Attorneys and Paralegals


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 145.7

7. **Signed:** Mary Beth Murphy, Commissioner Small Business/Self-Employed


**1.2.65.4.7** **(10-01-2000)**

#### SB/SE 1-23-18, Letters Requesting Permission for a Blanket Exemption on Form 1363, Export Exemption Certificate

1. **Letters Requesting Permission for a Blanket Exemption on Form 1363, Export Exemption Certificate** (formerly SB/SE DO 4.38)

2. **Authority:** To grant or deny permission to execute a blanket export certificate on Form 1363.

3. **Delegated to:** Managers with responsibility for excise tax matters

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.8** **(04-01-2001)**

#### SB/SE 1-23-19, Authority to Waive Personal Inspection of Decedent's Household or Personal Effects and/or Distribute Personalty

1. **Authority to Waive Personal Inspection of Decedent's Household or Personal Effects and/or Distribute Personalty** (formerly SB/SE DO 4.45, Rev. 1)

2. **Authority:** To sign letters waving personal inspection of decedent's household or personal effects and/or to sign authorizations for the distribution of personal property with or without inspection, in estate tax cases.

3. **Delegated to:** Group managers with responsibility for estate and gift tax matters

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.9** **(07-11-2012)**

#### SB/SE 1-23-20, Authority to Approve a Tip Reporting Alternative Commitment (TRAC) or a Tip Rate Determination Agreement (TRDA)

1. **Authority to Approve a Tip Reporting Alternative Commitment (TRAC) or a Tip Rate Determination Agreement (TRDA)**

2. **Authority:** To approve TRAC or TRDA non-gaming agreements with business employers for employment tax issues.

3. **Delegated to:**



   - SB/SE Program Manager, National Tip Reporting Compliance Program

   - SB/SE Employment Tax Territory Managers


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.29, Rev. 1.

7. **Signed:** Faris R. Fink, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.10** **(10-01-2000)**

#### SB/SE 1-23-29, Relief of a Corporation from the Necessity of Making a Return

1. **Relief of a Corporation from the Necessity of Making a Return** (formerly SB/SE DO 4.46)

2. **Authority:** To relieve a corporation from the necessity of making a return.

3. **Delegated to:**



   - Compliance Territory Managers

   - Technical Support Managers (second level)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.11** **(03-13-2017)**

#### SB/SE 1-23-30, Authority to Sign Form 1254, Examination Suspense Report

1. **Authority to Sign Form 1254, Examination Suspense Report** (formerly SB/SE DO 4.19, Rev. 1)

2. **Authority:** To Sign Forms 1254, Examination Suspense Report

3. **Delegated to:** Technical Services Group Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.19.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.12** **(03-08-2017)**

#### SB/SE 1-23-31, Authority to Sign Letters Acknowledging Receipt of an IRC Section 897(i) Election by a Foreign Corporation to be Treated as a Domestic Corporation Pursuant to Treasury Regulation Section 1.897-3

1. **Authority to Sign Letters Acknowledging Receipt of an IRC Section 897(i) Election by a Foreign Corporation to be Treated as a Domestic Corporation Pursuant to Treasury Regulation Section 1.897-3** (formerly SB/SE DO 4.22, Rev. 1)

2. **Authority:** To sign all letters acknowledging receipt as prescribed under Treasury Regulation 1.897-3(d)(4) for elections made under Section 897(i) of the Internal Revenue Code.

3. **Delegated to:** Technical Services Territory Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.22.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.13** **(05-17-2017)**

#### SB/SE 1-23-32, Signature Authority Under Treasury Regulations 1.1445-3 and 1.1445-6 Foreign Investment in Real Property Tax Act (FIRPTA)

1. **Signature Authority Under Treasury Regulations 1.1445-3 and 1.1445-6 Foreign Investment in Real Property Tax Act (FIRPTA)** (formerly SB/SE DO 4.23, Rev. 1)

2. **Authority:** To sign all letters, certificates, and qualifying statements prescribed under Treasury Regulations 1.1445-3 and 1.1445-6 relating to withholding.

3. **Delegated to:** Technical Support Managers

4. **Authority:** To sign all security agreements and releases of security prescribed under Treasury Regulations 1.1445-3 and 1.1445-6 relating to withholding.

5. **Delegated to:**



   - Technical Support Managers


6. **Redelegation:** This authority may not be redelegated.

7. **Source of Authority:**Servicewide Delegation Order 1-23

8. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.23.

9. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.14** **(05-17-2017)**

#### SB/SE 1-23-33, Authority to Grant Extensions of Time to Replace Involuntarily Converted Property Under Section 1033 of the Internal Revenue Code

1. **Authority to Grant Extensions of Time to Replace Involuntarily Converted Property Under Section 1033 of the Internal Revenue Code** (formerly SB/SE DO 4.24, Rev. 1)

2. **Authority:** To issue letters granting or rejecting extensions of time for the replacement of property involuntarily converted without recognition of gain.

3. **Delegated to:**



   - Technical Services Group Managers in the Examination function

   - Revenue Agent Reviewers with responsibility for involuntary conversion matters


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.24, Rev. 1.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.15** **(10-02-2017)**

#### SB/SE 1-23-34, Authority to Grant an Extension of Time for S-Corporation Elections

1. **Authority to Grant an Extension of Time for S-Corporation Elections** (formerly SB/SE DO 4.25, Rev. 1)

2. **Authority:** To grant an extension of time to file S-Corporation elections on Form 2553 in the limited instances specified in 26 CFR 1.1362-6(b)(3)(iii) (relating to situations where all of the required shareholder consents on Form 2553 were not obtained.)

3. **Delegated to:**



   - Revenue Agent Group Manager in the Examination function

   - Revenue Agent Reviewers in Technical Services


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.25.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.16** **(05-17-2017)**

#### SB/SE 1-23-35, Authority to Grant or Deny Extensions of Time with Respect to Foreclosure Property Held by a Real Estate Investment Trust (REIT) or Real Estate Mortgage Investment Conduit (REMIC)

1. **Authority to Grant or Deny Extensions of Time with Respect to Foreclosure Property Held by a Real Estate Investment Trust (REIT) or Real Estate Mortgage Investment Conduit (REMIC)** (formerly SB/SE DO 4.27, Rev. 2)

2. **Authority:** To sign letters granting or denying taxpayer requests for extensions of the grace period with respect to foreclosure property held by a REIT or REMIC under IRC 856(e)(3) and Regulation Section 1.856-6(g) (including extensions of time in which to file such requests).

3. **Delegated to:** Technical Services Group Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.27, Rev. 1.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.17** **(08-18-2017)**

#### SB/SE 1-23-36, Requests for Prompt Assessment Under IRC Section 6501(d)

1. **Requests for Prompt Assessment Under IRC Section 6501(d)** (formerly SB/SE DO 4.39, Rev. 1)

2. **Authority:** To sign letters sent in response to requests for prompt assessment under Section 6501(d) of the Internal Revenue Code, advising requestors that the returns are accepted as filed.

3. **Delegated to:** Group Managers or Section Chiefs in Planning and Special Programs (PSP)

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.39.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.18** **(08-28-2017)**

#### SB/SE 1-23-37, Authority to Issue Objection or Non-Objection Letters to Taxpayers Requesting Approval to File Form 3115

1. **Authority to Issue Objection or Non-Objection Letters to Taxpayers Requesting Approval to File Form 3115** (formerly SB/SE DO 4.40, Rev. 1)

2. **Authority:** To issue letters in response to a taxpayer’s request for an Area Director’s consent to file Form 3115, in accordance with the provisions of either Section 6.01(4) of Rev. Proc. 97-27 or Section 6.03(4) of Rev. Proc. 97-37 (or any successor revenue procedures).

3. **Delegated to:**



   - Revenue Agent Group Managers

   - Technical Services Group Managers


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.40.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.19** **(08-28-2017)**

#### SB/SE 1-23-38, Request for Approval to Use IDRS Command Code ESTAB

1. **Request for Approval to Use IDRS Command Code ESTAB** (formerly SB/SE DO 4.42, Rev. 4)

2. **Authority:** To approve the use of IDRS Command Code ESTAB in documented emergencies by employees in examination matters.

3. **Delegated to:**



   - Technical Support Group Managers

   - Planning & Special Programs (PSP) Group Managers or Section Chiefs


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.42, Rev. 3.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.20** **(08-18-2017)**

#### SB/SE 1-23-39, Authority to Sign Pattern Letter P-450 Advising Fiduciary of Acceptance of Returns or that Examination is Warranted

1. **Authority to Sign Pattern Letter P-450 Advising Fiduciary of Acceptance of Returns or that Examination is Warranted** (formerly SB/SE DO 4.16, Rev. 1)

2. **Authority:** To sign letter advising a fiduciary that returns filed during the administration of a bankrupt estate are either accepted as filed or warrant audit.

3. **Delegated to:**



   - Planning & Special Programs (PSP) Group Managers or Section Chiefs

   - Technical Services Group Managers


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.16.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.21** **(08-18-2017)**

#### SB/SE 1-23-40, Authority to Sign a Claim Invitation Letter

1. **Authority to Sign a Claim Invitation Letter** (formerly SB/SE DO 4.17, Rev. 1)

2. **Authority:** To sign a Claim Invitation Letter.

3. **Delegated to:**



   - Group Managers responsible for the examination of the return

   - Revenue Agents, Tax Auditors, and Tax Compliance Officers Reviewers in Technical Services


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.17.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.22** **(08-28-2017)**

#### SB/SE 1-23-41, Authority to Approve Agreement as to Useful Life, Method, and Rate of Depreciation of Property

1. **Authority to Approve Agreement as to Useful Life, Method, and Rate of Depreciation of Property** (formerly SB/SE DO 4.43, Rev. 1)

2. **Authority:** To review, approve, disapprove, and sign Form 2271, Agreement as to Useful Life, Method, and Rate of Depreciation of Property.

3. **Delegated to:** Technical Services Group Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.43.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.23** **(08-18-2017)**

#### SB/SE 1-23-42, Request to Use Estimated Costs of Future Improvements in Basis in Determining Gain or Loss on the Sale of Lots

1. **Request to Use Estimated Costs of Future Improvements in Basis in Determining Gain or Loss on the Sale of Lots** (formerly SB/SE DO 4.44, Rev. 1)

2. **Authority:** The authority to sign letters relating to taxpayer requests under Revenue Procedures 75-25 and 92-29, or their equivalent.

3. **Delegated to:** Revenue Agent Reviewers in Technical Services

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.44.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.24** **(07-21-2017)**

#### SB/SE 1-23-43, Revocation of Election to Adjust Basis of Partnership Property Under IRC Section 754

1. **Revocation of Election to Adjust Basis of Partnership Property Under IRC Section 754** (formerly SB/SE DO 4.48, Rev. 1)

2. **Authority:** To sign revocation of elections made to adjust basis of partnership property under Section 754 of the Internal Revenue Code.

3. **Delegated to:** Group Managers in Technical Services

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.48.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.25** **(08-18-2017)**

#### SB/SE 1-23-44, Authority to Approve Adoption of the Method of Deducting Soil and Water Conservation Expenditures Covered Under IRC Section 175

1. **Authority to Approve Adoption of the Method of Deducting Soil and Water Conservation Expenditures Covered Under IRC Section 175** (formerly SB/SE DO 4.49, Rev. 1)

2. **Authority:** To sign letters of consent allowing taxpayers the method of deducting soil and water conservation expenditures described in Section 175 of the Internal Revenue Code and Treasury Regulation Section 1.175-6.

3. **Delegated to:** Technical Services Territory Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.49.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.26** **(07-21-2017)**

#### SB/SE 1-23-45, Authority to Abate Failure to File Penalty With Respect to Foreign Corporations or Foreign Partnerships

1. **Authority to Abate Failure to File Penalty With Respect to Foreign Corporations or Foreign Partnerships**(formerly SB/SE DO 4.51, Rev. 1)

2. **Authority:** To abate the penalty imposed by Section 6679(a) of the Internal Revenue Code when reasonable cause is established.

3. **Delegated to:** Technical Services Territory Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.51.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.27** **(12-14-2017)**

#### SB/SE 1-23-47, Approval or Denial / Revocation of Secure Airport Terminal (SAT) Designations

01. **Approval or Denial / Revocation of Secure Airport Terminal (SAT) Designations**

02. **Authority:** To approve SAT designation requests.

03. **Delegated to:** Field Group Manager, Excise Tax Examination

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To deny a SAT designation request or to revoke an existing SAT designation. Denial or revocation based on the following considerations:



    - SAT requester/designee does not meet the designation criteria,

    - Requester or designee has not responded to a request for additional information relating to its request or existing designation,

    - Existing designee has used its SAT designation to evade, or attempt to evade, the payment of any tax imposed by IRC 4041(c)(1) or IRC 4081; or to postpone, or in any manner to interfere with the collection of any such tax; or to make a fraudulent claim for a credit or payment; or has aided or abetted another person in evading, or attempting to evade, payment of any tax imposed by 4041(c)(1) or 4081; or in making a fraudulent claim for a credit or payment; or has, at any time, failed to comply with the terms and conditions of SAT designation as outlined in Notice 2016-15.


06. **Delegated to:** Field Group Manager, Excise Tax Examination

07. **Redelegation:** This authority may not be redelegated.

08. **Authority:** To deny a SAT designation request or to revoke an existing SAT designation.



    - Uncontested denial or revocations are those where the requester or designee agrees with an IRS designation determination. The authority to approve the denial or revocation letter.


09. **Delegated to:** Field Group Manager, Excise Tax Examination

10. **Redelegation:** This authority may not be redelegated.

11. **Authority:** To deny a SAT designation request or to revoke an existing SAT designation.



    - Contested denial or revocations are those where the requester or designee agrees with an IRS designation determination. The authority to approve the denial or revocation letter.


12. **Delegated to:** Chief, Excise Tax Examination

13. **Redelegation:** This authority may not be redelegated.

14. **Source of Authority:**Servicewide Delegation Order 1-23



    - SAT Designation Determinations: Notice 2016-15 and CFR 48.4101-1(c)(1)(vi) of the Manufacturers and Excise Tax regulations. IRC 4081 (a)(3)(B) and (C).


15. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

16. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.28** **(10-01-2010)**

#### SB/SE 1-23-48, Authority to Sign Notice and Demand Letters for Tip Employer and Employee Taxes Under IRC Section 3121(q)

1. **Authority to Sign Notice and Demand Letters for Tip Employer and Employee Taxes Under IRC Section 3121(q)** (formerly SB/SE DO 193-11)

2. **Authority:** To sign notice and demand letters to employers for unreported tips received by employees subject to Social Security and Medicare tax.

3. **Delegated to:** Employment Tax Specialists responsible for employment tax matters

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.32 (Rev. 1).

7. **Signed:** Christopher Wagner, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.29** **(10-01-2010)**

#### SB/SE 1-23-49, Authority to Issue, Modify and Sign Determination Letters Under IRC Section 6053 (c)(3)(C)

1. **Authority to Issue, Modify and Sign Determination Letters Under IRC Section 6053 (c)(3)(C)** (formerly SB/SE DO 193-14)

2. **Authority:** To issue, modify, and sign determination letters pertaining to employer or employee requests to reduce their tip allocation under Section 6053 (c)(3)(C) of the Internal Revenue Code and Treasury Regulation 31.6053-3(h).

3. **Delegated to:** Program Manager, National Tip Reporting Compliance Program responsible for employment tax matters

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.21.

7. **Signed:** Christopher Wagner, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.30** **(04-24-2018)**

#### SB/SE 1-23-50, Functions Related to Potential Preparer, Promoter and Tax Shelter Cases

1. **Functions Related to Potential Preparer, Promoter and Tax Shelter Cases** (formerly SB/SE DO 4.60, Rev. 1)

2. **Authority:** To authorize investigations of promoters; and to perform, or to direct others under his or her supervision and control to perform, the following activities:



   - conducting initial research and classification of potential preparer, promoter, and abusive tax scheme cases;

   - requesting Compliance Data Environment (CDE) or other related research;

   - building preparer, promoter investigation and client cases; and

   - forwarding such cases to Planning and Special Programs (PSP)


3. **Delegated to:** Program Manager, SB/SE Examination Lead Development Center

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.60.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.31** **(10-01-2000)**

#### SB/SE 1-23-51, Responsibilities in Grand Jury Investigations Affecting Non-Grand Jury Cases

1. **Responsibilities in Grand Jury Investigations Affecting Non-Grand Jury Cases** (formerly SB/SE DO 4.47)

2. **Authority:**Where the Area Director has received grand jury information that is subject to the secrecy provisions of Rule 6(e), the Area Director must be excluded from personal involvement concerning such matters in non-grand jury civil and criminal cases. Investigative and management responsibilities of the Area Director in such non-grand jury civil and criminal cases are

3. **Delegated to:** Compliance Territory Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.32** **(10-01-2000)**

#### SB/SE 1-23-52, Authority to Issue Notice of Determination of Liability Letter in Bankruptcy and Receivership Cases

1. **Authority to Issue Notice of Determination of Liability Letter in Bankruptcy and Receivership Cases** (formerly SB/SE DO 4.53)

2. **Authority:** To issue and sign bankruptcy and receivership letters required by 26 CFR 301.6871(b)-1(c).

3. **Delegated to:** Revenue Agent Reviewers Grade GS-11 or higher

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.33** **(08-01-2001)**

#### SB/SE 1-23-53, Review of Unenrolled Preparers’ Authority to Act Before the Service

1. **Review of Unenrolled Preparers’ Authority to Act Before the Service** (formerly SB/SE DO 4.59)

2. **Authority:** To revoke eligibility of unenrolled preparers to act on behalf of taxpayers before the Service.

3. **Delegated to:** Compliance Area Directors

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Dale F. Hart, for Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.34** **(02-03-2020)**

#### SB/SE 1-23-54, Authority to Sign Information Letters

1. **Authority to Sign Information Letters** (formerly SB/SE DO 4.18, Rev. 1)

2. **Authority:** To sign information letters, as described in the first revenue procedure of each calendar year.

3. **Delegated to:**



   - Managers in Technical Services

   - Managers with responsibility for estate and gift tax matters

   - Managers with responsibility for excise tax matters

   - Managers with responsibility for employment tax matters


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.18.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.35** **(01-15-2020)**

#### SB/SE 1-23-55, Authority to Sign Thirty Day Letters

1. **Authority to Sign Thirty Day Letters** (formerly SB/SE DO 4.55, Rev. 1)

2. **Authority:** To sign and send to the taxpayer preliminary or 30-day letters with respect to matters under their jurisdiction .

3. **Delegated to:**



   - Managers of Revenue Agents, Tax Auditors, or Tax Compliance Officers

   - Managers of Tax Examiners in Specialty Examination

   - Managers of Estate and Gift Tax

   - Revenue Agent Reviewers in Technical Services


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.55.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.36** **(02-04-2020)**

#### SB/SE 1-23-56, Authority to Sign and Issue Notice of Proposed Penalty for Non-Filing of Forms 3520 and 3520A

1. **Authority to Sign and Issue Notice of Proposed Penalty for Non-Filing of Forms 3520 and 3520A**(formerly SB/SE DO 4.63, Rev. 1)

2. **Authority:** To sign and issue to the U.S. person responsible for filing the Form 3520 and/or Form 3520A (information returns) a notice stating that additional penalties will be assessed if complete and accurate returns are not filed within 90 days of the date of the notice of filing requirement.

3. **Delegated to:**



   - Group Managers in Field Examination


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.63.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.37** **(06-26-2019)**

#### SB/SE 1-23-57, Determination of Reasonable Cause for Failure to File Dual Consolidated Loss Documents

1. **Determination of Reasonable Cause for Failure to File Dual Consolidated Loss Documents** (formerly SB/SE DO 4.64, Rev. 1)

2. **Authority:** To determine whether a taxpayer’s failure to timely file an election, agreement, statement, rebuttal, computation, or other information pursuant to IRC section 1503(d) and 26 CFR 1.1503(d)-1 et seq. was due to reasonable cause and not willful neglect.

3. **Delegated to:**



   - Managers of revenue agents

   - Managers in Technical Services

   - Managers in Planning and Special Programs (PSP)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.64.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.38** **(01-07-2020)**

#### SB/SE 1-23-58, Authority to Issue Innocent Spouse Final Determination Notices

1. **Authority to Issue Innocent Spouse Final Determination Notices** (formerly SB/SE DO 4.57, Rev. 1)

2. **Authority:** To sign and send final determination notices for innocent spouse claims issued under Section 6105 of the Internal Revenue code.

3. **Delegated to:**



   - Territory Managers in Technical Services

   - Director, Campus Examination-Cincinnati


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.57.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.39** **(11-18-2020)**

#### SB/SE 1-23-59, Uncollected Tax Report Acknowledgment Signature Authority

01. **Uncollected Tax Report Acknowledgment Signature Authority** (formerly SB/SE DO 1-23-91, Rev. 1)

02. **Authority:** To sign an acknowledgement to an "Uncollected Tax Report" submitted by persons receiving payment for facilities and service under which a tax is imposed under Chapter 33, of Subtitle D, Miscellaneous excise taxes, as required by Internal Revenue section 49.4291-1.



    - Payments that do not exceed $10,000


03. **Delegated to:** Chief, Estate and Gift/Excise Exam

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:**To sign an acknowledgement to an "Uncollected Tax Report" submitted by persons receiving payment for facilities and service under which a tax is imposed under Chapter 33, of Subtitle D, Miscellaneous excise taxes, as required by Internal Revenue section 49.4291-1.



    - Payments that exceed $10,000


06. **Delegated to:** Director, Specialty Tax

07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:**Servicewide Delegation Order 1-23

09. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes Delegation Order SB/SE-1-23-91.

10. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.40** **(04-09-2018)**

#### SB/SE 4-1-1, Authority to Sign Agreements for Personal Holding Company Tax

1. **Authority to Sign Agreements for Personal Holding Company Tax** (formerly SB/SE DO 4.2, Rev. 1)

2. **Authority:** To sign agreements related to a taxpayer’s liability for personal holding company tax.

3. **Delegated to:** Revenue Agent Reviewers in Technical Services

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 4-1

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.2.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.41** **(04-17-2018)**

#### SB/SE 4-2-1, Extension of Time for Filing Statement of Grounds for Earnings and Profits Accumulation

1. **Extension of Time for Filing Statement of Grounds for Earnings and Profits Accumulation** (formerly SB/SE DO 4.3, Rev. 2)

2. **Authority:** To grant taxpayers an extension of time not to exceed 30 additional days for the purpose of filing the statement of grounds called for in registered or certified mail notification under Regulation 1.534-2.

3. **Delegated to:** Revenue Agent Reviewers Grade GS-13 in Technical Services.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 4-2

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.3, Rev. 1.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.42** **(04-17-2018)**

#### SB/SE 4-32-1, Authority to Execute Closing Agreements Subject to IRS and Resolution Trust Corporation (RTC) Inter-Agency Agreement Dated December 10, 1992 ("Agreement" )

1. **Authority to Execute Closing Agreements Subject to IRS and Resolution Trust Corporation (RTC) Inter-Agency Agreement Dated December 10, 1992 ("Agreement" )** (formerly SB/SE DO 4.13, Rev. 2)

2. **Authority:** To enter into and approve written agreements with any person relating to federal tax years resolved pursuant to the Agreement, including any future tax years to which the Agreement applies.

3. **Delegated to:** Group Managers in Technical Services

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 4-32.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4.13, Rev. 1.

7. **Signed:** Mary Beth Murphy, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.43** **(10-15-2020)**

#### SB/SE 4-5-1 (Rev. 1), Agreements Treated as Determinations under IRC Section 1313(a)(4)

1. **Agreements Treated as Determinations under IRC Section 1313(a)(4)**

2. **Authority:** To enter into agreements treated as determinations under IRC Section 1313(a)(4).

3. **Delegated to:**



   - Revenue Agent Reviewers in Technical Services

   - Tax Compliance Officer Reviewers in Technical Services for Office Examination cases


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 4-5.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 4-5-1.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.44** **(06-08-2020)**

#### SB/SE 8-3-1, Closing Agreements Concerning Internal Revenue Tax Liability

1. **Closing Agreements Concerning Internal Revenue Tax Liability** (formerly SB/SE DO 4.9, Rev. 3)

2. **Authority:** To enter into and approve a written agreement with any person relating to the internal revenue tax liability of such person (or of the person or estate for whom he or she acts), for a taxable period or periods ended prior to the date of the agreement and related specific items affecting other taxable periods, but excluding cases docketed in United States Tax Court.

3. **Delegated to:**



   - Managers in Technical Services

   - Group managers or section chiefs in Planning and Special Programs (PSP) delegated authority with respect to agreements concerning the administrative disposition of certain tax shelter cases


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 8-3.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 4.9, rev. 2.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.4.45** **(06-29-2021)**

#### SB/SE 25-5-1, Authority to Disseminate Bank Secrecy Act (BSA) Examination Information to State Regulatory Agencies

01. **Authority to Disseminate Bank Secrecy Act (BSA) Examination Information to State Regulatory Agencies** (formerly SB/SE DO 1.32 and SB/SE DO 4.11)

02. **Authority:** Except as otherwise set forth in this order, to take any action the Commissioner, SB/SE Division, is authorized to take, in accordance with Delegation Order 25-5 and under the Delegation of Authority for Dissemination of BSA Examination Information, dated November 28, 2007, from the Director of Financial Crimes Enforcement Network (FinCEN), with respect to the dissemination of Bank Secrecy Act examination information to appropriate state regulatory agencies.

03. **Delegated to:**



    - Director Examination, SB/SE


04. **Redelegation:** These authorities may not be redelegated.

05. **Authority:** To enter into agreements with state regulatory agencies that are:



    - In accordance with the terms and restrictions of the Delegation of Authority for Dissemination of BSA Examination Information, dated November 28, 2007, and

    - Subject to the final approval of the Director Examination, SB/SE.


06. **Delegated to:**



    - The Governmental Liaison and Disclosure Area Managers, SB/SE


07. **Redelegation:** These authorities may not be redelegated.

08. **Authority:** To disseminate Bank Secrecy Act examination information, under the terms and subject to the restrictions of the Delegation of Authority for Dissemination of BSA Examination Information, dated November 28, 2007, to employees or officials of state regulatory agencies for which a written agreement, entered into pursuant to the Delegation of Authority for Dissemination of BSA Examination Information, dated November 28, 2007, is in effect.

09. **Delegated to:**



    - SB/SE Bank Secrecy Act Program Manager, Examination Specialty Policy


10. **Redelegation:** These authorities may not be redelegated.

11. **Authority:** To give and receive reports and other information with FinCEN employees and officials as necessary to carry out the terms of the Delegation of Authority for Dissemination of BSA Examination Information, dated November 28, 2007.

12. **Delegated to:**



    - The IRS SB/SE Bank Secrecy Act Policy Liaison to FinCEN


13. **Redelegation:** These authorities may not be redelegated.

14. **Authority:**To enforce compliance aspects of 31 CFR 1010.311, 1010.313, and 1020.315; to assure compliance with the requirements of 31 CFR Chapter X by all banks not currently examined by Federal supervisory agencies for safety and soundness; to assure compliance with the requirements of 31 CFR Chapter X by the financial institutions not referenced in 31 CFR 1010.810(b)(1) through (b)(6).

15. **Delegated to:**



    - SB/SE Bank Secrecy Act Policy Compliance Territory Managers


16. **Redelegation:**This authority may not be redelegated.

17. **Source of Authority:**Servicewide Delegation Order 25-5

18. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order 1.32 and SB/SE Delegation Order 4.11.

19. **Signed:** De Lon Harris, Commissioner Examination, Small Business/Self-Employed Division.


**1.2.65.5** **(05-21-2020)**

### SB/SE Functional Delegation Orders - Operations Support

1. The following delegation orders pertain to the Business Support Office (formerly known as Strategy and Finance) business process.


**1.2.65.5.1** **(02-02-2001)**

#### SB/SE 1-7-1, Authority to Approve Attendance at Meetings at Government Expense

1. **Authority to Approve Attendance at Meetings at Government Expense** (formerly SB/SE DO 1.14)

2. **Authority:** To authorize or approve the attendance of employees performing functions under their general supervision, at government expense, within the geographic limits authorized by the General Travel Order, at meetings of scientific or professional societies, municipal, state, federal, or international organizations, congresses and law enforcement or other groups for the purpose of receiving or transmitting information or knowledge relating to the substantive or administrative activities of the Internal Revenue Service.

3. **Delegated to:** All Directors

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-7

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.5.2** **(02-02-2001)**

#### SB/SE 6-3-1, Delegation of Authority in Labor-Management Relations Matters

01. **Delegation of Authority in Labor-Management Relations Matters** (formerly SB/SE DO 1.9)

02. **Authority:** To negotiate basic agreements after prior consultation with the Director, Human Resources Division, and/or Director/Strategic Human Resources or his/her designee.

03. **Delegated to:**



    - SB/SE Division Deputy Commissioners

    - Executive direct reports

    - Director, Human Resources


04. **Authority:** To negotiate division-wide and other supplemental agreements, as appropriate, in accordance with the guidelines outlined in Article 47 of the National Agreement.

05. **Delegated to:**



    - SB/SE Division Deputy Commissioner

    - Executive direct reports

    - Director, Human Resources


06. **Authority:** To consult with the Union, as appropriate, regarding issues affecting the SB/SE division.

07. **Delegated to:**



    - SB/SE Division Deputy Commissioner

    - Executive direct reports

    - Director, Human Resources


08. **Redelegation:** This authority may not be redelegated.

09. **Source of Authority:**Servicewide Delegation Order 6-3

10. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

11. **Signed:** Joseph G. Kehoe, Commissioner, Small Business/Self-Employed Division.


**1.2.65.5.3** **(12-02-2022)**

#### SB/SE 1-66-1, Authorization to Execute Settlement Agreements in Equal Employment Opportunity Matters

01. **Title:** SB/SE Authorization to Execute Settlement Agreements in Equal Employment Opportunity Matters

02. **Background:** Pursuant to Servicewide Delegation Order 1-66, the SB/SE Division Commissioner has the authority to on behalf of the Internal Revenue Service agree to take or refrain from taking actions including but not limited to personnel actions resulting in backpay or other equitable relief attendant to such actions, as well as the payment of compensatory damages and attorney’s fees, for the purpose of settling claims of violations of Equal Employment Opportunity (EEO) laws or regulations applicable to the IRS as described in 29 CFR Part 1614 with respect to claims which arise out of, related to, or concern the respective activities or functions administered by the Division Commissioner, after consultation with a Deputy Commissioner in any case involving (i) a class, (ii) a potentially precedent-setting issue, (iii) the payment of monies in excess of $100,000, or (iv) any other circumstance that, in the judgement of the Division Commissioner, warrants referral to a Deputy Commissioner. The authority of the Division Commissioner is redelegated as specified in this order.

03. **Authority:** Settlements resulting in the payment of money to the complainant where the total value of the agreed upon payment exceeds **$75,000** but does not exceed **$100,000**.

04. **Delegated to:** Deputy Division Commissioners

05. **Redelegation:** This authority may not be redelegated.

06. **Authority:**Settlements resulting in the payment of money to the complainant where the total value of the agreed upon payments exceeds **$50,000** but does not exceed **$75,000**.

07. **Delegated to:** OU Directors: Director, Collection; Director, Examination; Director, Operations Support.

08. **Redelegation:** This authority may not be redelegated.

09. Authority: Settlements resulting in the payment of money to the complainant where the total value of the agreed upon payments exceeds **$25,000** but does not exceed **$50,000**.

10. **Delegated to:** Functional Unit Directors: Director, Campus Collection/Examination; Director, Field Collection/Examination; Director, HQ Collection/Examination

11. **Redelegation:** This authority may not be redelegated.

12. Authority: Settlements resulting in the payment of money to the complainant where the total value of the agreed upon payments exceeds **$10,000**but does not exceed **$25,000**.

13. **Delegated to:** Campus Directors/Area Directors/First Level Executives

14. **Redelegation:** This authority may not be redelegated.

15. **Authority:** Settlements resulting in the payment of money to the complainant where the total value of the agreed upon payments does not exceed **$10,000**.

16. **Delegated to:** Territory/Operations/ and Senior Managers

17. **Redelegation:** This authority may not be redelegated.

18. **Authority:** To execute settlements that do not involve the payment of any money to the complainant.

19. **Delegated to:** Department and Front-Line Managers

20. **Redelegation:** This authority may not be redelegated.

21. **Source(s) of Authority:**Servicewide Delegation Order 1-66

22. To the extent that any action previously exercised consistent with this order may require ratification, it is hereby approved and ratified

23. **Signed:** Amalia C. Colbert, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6** **(07-16-2021)**

### SB/SE Functional Delegation Orders - Emergency Orders of Succession

1. Emergency Orders of Succession are specific delegations of authority, issued by the SB/SE Division Commissioner to his/her subordinate officers. These orders are provisions for the assumption of senior IRS leadership positions during an emergency, when the incumbents are unable or unavailable to perform their authorized duties, roles and responsibilities. Orders of succession allow for an orderly and predefined transition of leadership.

2. Current SB/SE emergency orders of succession are listed in numerical sequence. The subsection date appearing above each title is the effective date of that delegation order.


**1.2.65.6.1** **(01-31-2020)**

#### SB/SE 1-23-98, Emergency Order of Succession - Deputy Commissioner, Collection and Operations Support, Small Business/Self-Employed Division

1. Emergency Order of Succession - Deputy Commissioner, Collection and Operations Support, Small Business/Self-Employed Division

2. **Authority:** In the event of an emergency, Continuity of Operations (COOP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed the position of Deputy Commissioner, Collection and Operations Support, Small Business/Self-Employed (SB/SE) Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Deputy Commissioner, Collection and Operations Support, Small Business/Self-Employed Division until relieved of the responsibility.

3. **Delegated to:**



   - Deputy Commissioner, Examination

   - Director, Collection (SB/SE)

   - Director, Operations Support (SB/SE)

   - Director, Headquarters Collection (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. Signed: Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.2** **(02-03-2020)**

#### SB/SE 1-23-99, Emergency Order of Succession - Deputy Commissioner, Examination, Small Business/Self-Employed Division

1. Emergency Order of Succession - Deputy Commissioner, Examination, Small Business/Self-Employed Division

2. **Authority:** In the event of an emergency, Continuity of Operations (COOP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed the position of Deputy Commissioner, Examination, Small Business/Self-Employed (SB/SE) Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Deputy Commissioner, Examination, Small Business/Self-Employed Division until relieved of the responsibility.

3. **Delegated to:**



   - Deputy Commissioner, Collection and Operations Support (SB/SE)

   - Director, Examination (SB/SE)

   - Deputy Director, Examination (SB/SE)

   - Director, Operations Support (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.3** **(02-04-2020)**

#### SB/SE 1-23-100 (Rev. 1), Emergency Order of Succession - Commissioner, Small Business/Self-Employed Division

1. **Emergency Order of Succession - Commissioner, Small Business/Self-Employed Division** (formerly SB/SE DO 1-23-100)

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Commissioner, Small Business/Self-Employed (SB/SE) Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Commissioner, Small Business/Self-Employed Division until relieved of the responsibility.

3. **Delegated to:**



   - Deputy Commissioner, Collection and Operations Support (SB/SE)

   - Deputy Commissioner, Examination (SB/SE)

   - Director, Operations Support (SB/SE)

   - Director, Examination (SB/SE)

   - Director, Collection (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes SB/SE Delegation Order SB/SE 1-23-100.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.4** **(09-23-2015)**

#### SB/SE 1-23-102, Emergency Order of Succession - Director Collection, Small Business/Self-Employed Division

1. **Emergency Order of Succession - Director Collection, Small Business/Self-Employed Division**

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Director, Collection, Small Business/Self-Employed Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Director, Collection, Small Business/Self-Employed Division until relieved of the responsibility.

3. **Delegated to:**



   - Director, Headquarters Collection (SB/SE)

   - Director, Campus Collection (SB/SE)

   - Director, Field Collection (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.5** **(02-03-2020)**

#### SB/SE 1-23-103 (Rev. 1), Emergency Order of Succession - Director Examination, Small Business/Self-Employed Division

1. **Emergency Order of Succession, Director Examination, Small Business/Self-Employed Division**

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Director, Examination, Small Business/Self-Employed Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Director, Examination, Small Business/Self-Employed Division, until relieved of the responsibility.

3. **Delegated to:**



   - Deputy Director, Examination (SB/SE)

   - Director, Headquarters Examination (SB/SE)

   - Director, Campus Examination (SB/SE)

   - Director, Field Examination (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This supersedes SB/SE Delegation Order 1-23-103.

7. **Signed:** Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.6** **(03-23-2022)**

#### SB/SE 1-23-104 (Rev. 1), Emergency Order of Succession - Director Operations Support, Small Business/Self-Employed Division

1. **Emergency Order of Succession- Director Operations Support, Small Business/Self-Employed Division**

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Director, Operations Support, Small Business/Self-Employed Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Director, Operations Support, Small Business/Self-Employed Division until relieved of the responsibility.

3. **Delegated to:**



   - Director, Business Support Office (SB/SE)

   - Director, Human Capital (SB/SE)

   - Director, Business Development (SB/SE)

   - Director, Technology Solutions (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Darren John Guillot, Commissioner, Collection and Operations Support, Small Business/Self-Employed Division.


**1.2.65.6.7** **(02-12-2016)**

#### SB/SE 1-23-105, Emergency Order of Succession - Director Field Collection, Small Business/Self-Employed Division

1. **Emergency Order of Succession - Director Field Collection, Small Business/Self-Employed Division**

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Director, Field Collection, Small Business/Self-Employed Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Director, Field Collection, Small Business/Self-Employed Division, until relieved of the responsibility.

3. **Delegated to:**



   - Director, Field Collection Central Area (SB/SE)

   - Director, Field Collection Gulf States Area (SB/SE)

   - Director, Field Collection Southwest Area (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.8** **(02-12-2016)**

#### SB/SE 1-23-106, Emergency Order of Succession - Director Examination-Campus, Small Business/Self-Employed Division

1. **Emergency Order of Succession - Director Examination-Campus, Small Business/Self-Employed Division**

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Director, Examination-Campus, Small Business/Self-Employed Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Director Examination-Campus, Small Business/Self-Employed Division until relieved of the responsibility.

3. **Delegated to:**



   - Director, Examination-Ogden (SB/SE)

   - Director, Examination-Cincinnati (SB/SE)

   - Director, Examination-Memphis (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.9** **(02-12-2016)**

#### SB/SE 1-23-107, Emergency Order of Succession - Director Examination-Field, Small Business/Self-Employed Division

1. **Emergency Order of Succession - Director Examination-Field, Small Business/Self-Employed Division**

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Director, Examination-Field, Small Business/Self-Employed Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Director, Examination-Field, Small Business/Self-Employed Division, until relieved of the responsibility.

3. **Delegated to:**



   - Director, Gulf States Area (SB/SE)

   - Director, Central Area (SB/SE)

   - Director, Midwest (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.10** **(03-21-2016)**

#### SB/SE 1-23-108, Emergency Order of Succession - Director Collection-Campus, Small Business/Self-Employed Division

1. **Emergency Order of Succession - Director Collection-Campus, Small Business/Self-Employed Division**

2. **Authority:** In the event of an emergency, Continuity of Operations (COP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed to the position of Director, Collection-Campus, Small Business/Self-Employed Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Director, Collection-Campus, Small Business/Self-Employed Division, until relieved of the responsibility.

3. **Delegated to:**



   - Director, Campus Collection - Philadelphia (SB/SE)

   - Director, Campus Collection - Kansas City (SB/SE)

   - Director, Campus Collection - Atlanta (SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Karen M. Schiller, Commissioner, Small Business/Self-Employed Division.


**1.2.65.6.11** **(02-04-2020)**

#### SB/SE 1-23-109, Emergency Order of Succession - Deputy Director, Examination, Small Business/Self-Employed Division

1. Emergency Order of Succession - Deputy Director, Examination, Small Business/Self-Employed Division

2. **Authority:** In the event of an emergency, Continuity of Operations (COOP) procedures will take effect. The management officials who occupy the positions listed below are authorized in order of succession to succeed the position of Deputy Director, Examination, Small Business/Self-Employed (SB/SE) Division.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all of the authority given the Deputy Director, Examination, Small Business/Self-Employed Division until relieved of the responsibility.

3. **Delegated to:**



   - Director, Headquarters Examination (SB/SE)

   - Director, Campus Examination (SB/SE)

   - Director, Field Examination(SB/SE)


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-23

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. Signed: Eric C. Hylton, Commissioner, Small Business/Self-Employed Division.


**Exhibit 1.2.65-1**

### SB/SE Delegation Orders by Old Number, New Number, and Title

| Old Number | New Number | Title |
| :-: | :-: | :-: |
| SB/SE DO 1.9 | SB/SE 6-3-1 (_IRM 1.2.65.5.2_) | Delegation of Authority in Labor-Management Relations Matters |
| SB/SE DO 1-14 | SB/SE 1-7-1 (_IRM 1.2.65.5.1_) | Authority to Approve Attendance at Meetings at Government Expense |
| SB/SE DO 1-23-40, updated by SB/SE 1-23-100, and currently updated by | SB/SE 1-23-100 (Rev. 1)(_IRM 1.2.65.6.3_) | Emergency Order of Succession - Commissioner, Small Business/Self-Employed Division |
| SB/SE DO 1-23-91, Rev. 1 | SB/SE 1-23-59 (_IRM 1.2.65.4.39_) | Uncollected Tax Report Acknowledgment Signature Authority |
| SB/SE DO 1.32 and DO 4.11 | SB/SE 25-5-1 (_IRM 1.2.65.4.45_) | Authority to Disseminate Bank Secrecy Act (BSA) Examination Information to State Regulatory Agencies |
| SB/SE DO 1-24 | SB/SE 1-23-10 (_IRM 1.2.65.2.2_) | Authority to Sign Memoranda of Understanding (MOUs) |
| SB/SE DO 4.1 | SB/SE 1-23-13 (_IRM 1.2.65.4.4_) | Authority to Sign Claim Disallowance Notices |
| SB/SE DO 4.9, Rev. 3 | SB/SE 8-3-1 (_IRM 1.2.65.4.44_) | Closing Agreements Concerning Internal Revenue Tax Liability |
| SB/SE DO 4.13 | SB/SE 4-32-1 (_IRM 1.2.65.4.42_) | Authority to Execute Closing Agreements Subject to IRS and Resolution Trust Corporation (RTC) Inter-Agency Agreement Dated December 10, 1992 ("Agreement" ) |
| SB/SE DO 4.15 | SB/SE 1-23-14 (_IRM 1.2.65.4.5_) | Authority to Sign Requests for Technical Advice (Form 4463) |
| SB/SE DO 4.16 | SB/SE 1-23-39 (_IRM 1.2.65.4.20_) | Authority to Sign Pattern Letter P-450 Advising Fiduciary of Acceptance of Returns or that Examination is Warranted |
| SB/SE DO 4.17 | SB/SE 1-23-40 (_IRM 1.2.65.4.21_) | Authority to Sign a Claim Invitation Letter |
| SB/SE DO 4.18 Rev. 1 | SB/SE 1-23-54 (_IRM 1.2.65.4.34_) | Authority to Sign Information Letters |
| SB/SE DO 4.19 | SB/SE 1-23-30 (_IRM 1.2.65.4.11_) | Authority to Sign Form 1254, Examination Suspense Report |
| SB/SE DO 4.2 | SB/SE 4-1-1 (_IRM 1.2.65.4.40_) | Authority to Sign Agreements for Personal Holding Company Tax |
| SB/SE DO 4.22 | SB/SE 1-23-31 (_IRM 1.2.65.4.12_) | Authority to Sign Letters Acknowledging Receipt of an IRC Section 897(i) Election by a Foreign Corporation to be Treated as a Domestic Corporation Pursuant to Treasury Regulation Section 1.897-3 |
| SB/SE DO 4.23 | SB/SE 1-23-32 (_IRM 1.2.65.4.13_) | Signature Authority Under Treasury Regulations 1.1445-3 and 1.1445-6 Foreign Investment in Real Property Tax Act (FIRPTA) |
| SB/SE DO 4.24 | SB/SE 1-23-33 (_IRM 1.2.65.4.14_) | Authority to Grant Extensions of Time to Replace Involuntarily Converted Property Under Section 1033 of the Internal Revenue Code |
| SB/SE DO 4.27 | SB/SE 1-23-35 (_IRM 1.2.65.4.16_) | Authority to Grant or Deny Extensions of Time with Respect to Foreclosure Property Held by a Real Estate Investment Trust (REIT) or Real Estate Mortgage Investment Conduit (REMIC) |
| SB/SE DO 4.3 | SB/SE 4-2-1 (_IRM 1.2.65.4.41_) | Extension of Time for Filing Statement of Grounds for Earnings and Profits Accumulation |
| SB/SE DO 4.36, Rev. 3 | SB/SE 1-23-7 (_IRM 1.2.65.4.3_) | Approval, Denial, Suspension or Revocation of Form 637, Application for Registration (for Certain Excise Tax Activities) |
| SB/SE DO 4.38 | SB/SE 1-23-18 (_IRM 1.2.65.4.7_) | Letters Requesting Permission for a Blanket Exemption of Form 1363 |
| SB/SE DO 4.39 | SB/SE 1-23-36 (_IRM 1.2.65.4.17_) | Requests for Prompt Assessment Under IRC Section 6501(d) |
| SB/SE DO 4.40 | SB/SE 1-23-37 (_IRM 1.2.65.4.18_) | Authority to Issue Objection or Non-Objection Letters to Taxpayers Requesting Approval to File Form 3115 |
| SB/SE DO 4.41, Rev. 3 | SB/SE 1-23-15 (Rev. 1)(_IRM 1.2.65.3.4_) | Error Tolerance Levels |
| SB/SE DO 4.42, Rev. 3 | SB/SE 1-23-38 (_IRM 1.2.65.4.19_) | Request for Approval to Use IDRS Command Code ESTAB |
| SB/SE DO 4.43 | SB/SE 1-23-41 (_IRM 1.2.65.4.22_) | Agreement as to Useful Life, Method, and Rate of Depreciation of Property |
| SB/SE DO 4.44 | SB/SE 1-23-42 (_IRM 1.2.65.4.23_) | Request to Use Estimated Costs of Future Improvements in Basis in Determining Gain or Loss on the Sale of Lots |
| SB/SE DO 4.45 | SB/SE 1-23-19 (_IRM 1.2.65.4.8_ | Authority to Waive Personal Inspection of Decedent’s Household or Personal Effects and/or Distribute Personalty |
| SB/SE DO 4.46 | SB/SE 1-23-29 (_IRM 1.2.65.4.10_) | Relief of a Corporation from the Necessity of Making a Return |
| SB/SE DO 4.47 | SB/SE 1-23-51(_IRM 1.2.65.4.31_) | Responsibilities in Grand Jury Cases Affecting Non-Grand Jury Cases |
| SB/SE DO 4.48 | SB/SE 1-23-43 (_IRM 1.2.65.4.24_) | Revocation of Election to Adjust Basis of Partnership Property Under IRC Section 754 |
| SB/SE DO 4.49 | SB/SE 1-23-44 (_IRM 1.2.65.4.25_) | Authority to Approve Adoption of the Method of Deducting Soil and Water Conservation Expenditures Covered Under IRC Section 175 |
| SB/SE 4.5, Rev. 2 | SB/SE 4-5-1 (_IRM 1.2.65.4.43_) | Agreements Treated as Determinations under IRC Section 1313(a)(4) |
| SB/SE DO 4.51 | SB/SE 1-23-45 (_IRM 1.2.65.4.26_) | Authority to Abate Failure to File Penalty With Respect to Foreign Corporations or Foreign Partnerships |
| SB/SE DO 4.53 | SB/SE 1-23-52 (_IRM 1.2.65.4.32_) | Authority to Issue Notice of Determination of Liability Letter in Bankruptcy and Receivership Cases |
| SB/SE DO 4.54 | SB/SE 1-23-5 (_IRM 1.2.65.4.2_) | Determination Letters Relating to Income, Estate & Gift, Excise and Employment Taxes |
| SB/SE DO 4.55, Rev. 1 | SB/SE 1-23-55 (_IRM 1.2.65.4.35_) | Authority to Sign Thirty Day Letters |
| SB/SE DO 4.57, Rev. 1 | SB/SE 1-23-58 (_IRM 1.2.65.4.38_) | Authority to Issue Innocent Spouse Final Determination Notices |
| SB/SE DO 4.59 | SB/SE 1-23-53 (_IRM 1.2.65.4.33_) | Review of Unenrolled Preparers - Authority to Act Before the Service |
| SB/SE DO 4.60 | SB/SE 1-23-50 (_IRM 1.2.65.4.30_) | Functions Related to Potential Preparer, Promoter and Tax Shelter Cases |
| SB/SE DO 4.63, Rev. 1 | SB/SE 1-23-56 (_IRM 1.2.65.4.36_) | Authority to Sign and Issue Notice of Proposed Penalty for Non-Filing of Forms 3520 and 3520A |
| SB/SE DO 4.64 | SB/SE 1-23-57(_IRM 1.2.65.4.37_) | Determination of Reasonable Cause for Failure to File Dual Consolidated Loss Documents |
| SB/SE DO 5.1 | SB/SE 1-23-2 (_IRM 1.2.65.3.1_) | Authority to Sign and Issue Levy and Related Documents |
| SB/SE DO 5.16 | SB/SE 1-23-22 (_IRM 1.2.65.3.7_) | Authority to Sign Letter 1153, Notification Letter Regarding Form 2751, Proposed Assessment of Trust Fund Recovery Penalty |
| SB/SE DO 5.3, Rev. 2 | SB/SE 1-23-27 (_IRM 1.2.65.3.12_) | Authority to Approve, Sign and Accept Bonds and Collateral Agreements |
| SB/SE DO 5.6 | SB/SE 1-23-23 (_IRM 1.2.65.3.8_) | Commercial Title Searches |
| SB/SE DO 5.7, Rev. 3 | SB/SE 1-23-21 (_IRM 1.2.65.3.6_) | Authority to Sign Notices of Disallowance of Claim for Refund and Agreements to Final Determination of Liability Related to Assessments Made Under IRC 6672 |
| SB/SE DO 145.2, Rev. 3 | SB/SE 1-23-9 (_IRM 1.2.65.3.2_) | Approval of Form 4477, Civil Suit Recommendation |
| SB/SE DO 145.4 | SB/SE 1-23-25 (_IRM 1.2.65.3.10_) | Authority to Accept Legal Process Service |
| SB/SE DO 145.6 | SB/SE 1-23-28 (_IRM 1.2.65.3.13_) | Authority to Refuse to Accept Payment by Personal Check |
| SB/SE DO 145.7, Rev 1 | SB/SE 1-23-17 ( _IRM 1.2.65.4.6_ | Authority to Request and Inspect Preparer Records |
| SB/SE DO 145.12 | SB/SE 1-23-26 (_IRM 1.2.65.3.11_) | Authority to Sign Form 792 |
| SB/SE DO 145.13 | SB/SE 1-23-24 (_IRM 1.2.65.3.9_) | Authority to Sign Agreements to Extend the Running of the Period of Time to Bring Suit |
| SB/SE DO 145.15 | SB/SE 1-23-4 (_IRM 1.2.65.4.1_) | Authority to Issue Notices for Termination and Jeopardy Assessments |
| SB/SE DO 145.17 | SB/SE 1-23-16 (_IRM 1.2.65.3.5_) | Authority to Sign Form 23C, Assessment Certificate |
| SB/SE DO 178-1 | SB/SE 25-6-1 (_IRM 1.2.65.3.14_) | Authority to Obligate Funds for Payment to Third Parties Who Request Reimbursement for Cost of Complying with a Summons (Form 6863) |
| SB/SE DO 193.11 | SB/SE 1-23-48 (_IRM 1.2.65.4.28_) | Authority to Sign Notice and Demand Letters for Tip Employer and Employee Taxes Under IRC Section 3121(q) |
| SB/SE DO 193.14 | SB/SE 1-23-49 (_IRM 1.2.65.4.29_) | Authority to Issue, Modify and Sign Determination Letters Under IRC Section 6053 (c)(3)(C) |

**Exhibit 1.2.65-2**

### SB/SE 1-23-2 (Rev. 2), Authority to Sign and Issue Levy and Related Documents

See _IRM 1.2.65.3.1_ for the complete delegation order.

| Authorized in Levy Matters | Area Directors and Advisory Directors | Compliance Territory Managers | Revenue Officer Group Managers | Advisory Managers (2nd Level) | Advisory Group Managers | Advisory Reviewers | Revenue Officers GS 9 and Above | Property Appraisal and Liquidation Specialist | Compliance Territory Managers or Advisory Managers (2nd Level) with Assoc. Area Counsels Review and concurrence |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Levy (Form 668-B), except as further qualified below | X | X | X | - | - | - | - | - | - |
| Levy on Principal Residence of Taxpayer, Taxpayer’s spouse or former spouse, taxpayer’s minor children (with U.S. District Court Approval-IRM 6334(e)(1)) | X | - | - | - | - | - | - | - | - |
| Levy on contents of Principal Residence of Taxpayer, Taxpayer’s spouse or former spouse, taxpayer’s minor children | X | - | - | - | - | - | - | - | - |
| Levy on Tangible (Real or Personal) Property used in the Business of an Individual IRC 6334 (e)(2) | X | - | - | - | - | - | - | - | - |
| Levy on Principal Residence of anyone other than Taxpayer, Taxpayer’s spouse or former spouse, taxpayer’s minor children | X | X | X | - | - | - | - | - | - |
| Levy on contents of Principal Residence of anyone other than Taxpayer, Taxpayer’s spouse or former spouse, taxpayer’s minor children | X | X | X | - | - | - | - | - | - |
| Levy on Assets in a retirement plan or account | X | - | - | - | - | - | - | - | - |
| Levy on Firearms included as a Business Asset | X | X | - | - | - | - | - | - | - |
| Levy on Controlled Substances or Drug Paraphernalia | X | X | - | - | - | - | - | - | - |
| Levy on Obscene or Pornographic Material | X | X | - | - | - | - | - | - | - |
| Levy in connection with Jeopardy or Termination Assessments where a taxpayer is suspected of criminal activity. Ex. narcotics | X | X | - | - | - | - | - | - | - |
| Levy on assets with environmental Considerations | X | X | - | - | - | - | - | - | - |
| Levy on Cleared Contractor Facility | X | X | - | - | - | - | - | - | - |
| Levies in Alter Ego, Nominee, and Transferee | - | - | - | - | - | - | - | - | X |
| Levy for Taxes in Refund Litigation Regardless of Tax Period | - | - | - | - | - | - | - | - | X |
| Jeopardy Levy without Jeopardy Assessment if Notice Requirements have not been Satisfied | - | - | - | - | - | - | - | - | X |
| Jeopardy Levy without Jeopardy Assessment if Notice Requirements have been Satisfied | X | X | - | - | - | - | - | - | - |
| Levy on Appearance Date of Summons (Jeopardy) | X | X | - | - | - | - | - | - | - |
| Levy When Offer of an IA or OIC is Made Merely to Delay Collection | X | X | - | - | - | - | - | - | - |
| Make Determination on Wrongful Levy Claims | X | X | - | X | - | - | - | - | - |
| Final Demand Form 668-C | X | X | X | X | X | X | X | - | - |
| Release of Levy Form 668-E | X | X | X | X | X | X | X | X | - |
| Determine that Property is Perishable/Levy on Perishables | X | - | - | - | - | - | - | - | - |
| Determine that Sale of Perishable Property is Warranted | X | - | - | - | - | - | - | - | - |
| Notice of Sale (Form 2434 & 2434-A) | X | - | - | X | - | - | - | X | - |
| Notice of Sale (Forms 2434 & 2434-A) of Perishables and Acquired Properties | X | X | X | X | X | X | X | X | - |
| Notice of Sale Held Outside County Where Property is Located | X | X | - | X | - | - | - | - | - |
| Advertise Sale | X | - | - | X | - | - | - | X | - |
| Advertise Sale of Perishable and Acquired Properties | X | X | X | X | X | X | X | X | - |
| Sale and Administration of Property Acquired by US | X | X | X | X | X | X | X | X | - |
| Appraise and Dispose of Property Under IRC 6336(1) and 6336 (2) | X | X | X | X | X | X | X | X | - |
| Certificate of Sale Form 2435 | X | - | - | X | - | - | - | X | - |
| Certificate of Sale of Perishable and Acquired Properties | X | X | X | X | X | X | X | X | - |
| Authority to Sign Deeds | X | X | - | X | X | - | - | - | - |
| Disposition of Surplus Proceeds | X | X | - | X | X | - | - | - | - |
| Authority to Return Levy Payments | X | X | - | X | - | - | - | - | - |
| Record 21 - Record of Seizure and Sale of Real Estate | X | X | - | X | - | - | - | - | - |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-002-065#addtoany "Show all")

A2A