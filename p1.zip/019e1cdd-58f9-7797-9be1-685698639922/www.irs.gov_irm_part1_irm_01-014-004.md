---
url: "https://www.irs.gov/irm/part1/irm_01-014-004"
title: "1.14.4 Personal Property Management | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-004#main-content)

- 1.14.4  [Personal Property Management](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053664144)
  - 1.14.4.1  [Program Scope](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053742608)
    - 1.14.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024806688)
    - 1.14.4.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053808800)
    - 1.14.4.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686026035504)
    - 1.14.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025200272)
    - 1.14.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024718624)
    - 1.14.4.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024803120)
    - 1.14.4.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053703488)
  - 1.14.4.2  [Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager (IRWorks HAM) General Provisions - System Description](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025207232)
  - 1.14.4.3  [Separation of Duties](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025153696)
  - 1.14.4.4  [Management and Utilization of Personal Property](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686057457760)
  - 1.14.4.5  [Acquisition of Non-IT Personal Property](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024681936)
    - 1.14.4.5.1  [Rented or Leased Non-IT Property](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053171728)
    - 1.14.4.5.2  [Seized/Forfeited Assets – General](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053167472)
    - 1.14.4.5.3  [Telework and Home as POD (HaP) Assets](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053186608)
  - 1.14.4.6  [Accountability and Control Records](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686026048768)
    - 1.14.4.6.1  [Control Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024796832)
    - 1.14.4.6.2  [Records](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025077760)
  - 1.14.4.7  [Reports](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025073648)
    - 1.14.4.7.1  [Property Furnished to Non-Federal Recipients](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024786560)
    - 1.14.4.7.2  [Exchange/Sale Transactions](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024783824)
    - 1.14.4.7.3  [Acceptance of Unconditional (In-Kind) Gifts](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053009168)
    - 1.14.4.7.4  [Acceptance, Retention, and Disposition of Gifts under the Foreign Gifts and Decorations Act](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053006240)
    - 1.14.4.7.5  [Disposition of Gifts](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686052553840)
    - 1.14.4.7.6  [Gifts Given to Foreign Individuals](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024692848)
  - 1.14.4.8  [Temporary and/or Internal Transfers of Non-IT Property](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024690208)
  - 1.14.4.9  [Maintenance and Repair](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024687648)
  - 1.14.4.10  [Photography Prohibition in IRS Space](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025150928)
  - 1.14.4.11  [Disposition of Personal Property](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025148624)
    - 1.14.4.11.1  [Disposition of Property - Excess](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025146064)
    - 1.14.4.11.2  [Disposal of Items Requiring Special Handling](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053802992)
  - 1.14.4.12  [Authorizations for Abandonment or Destruction of Personal Property](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686053796928)
    - 1.14.4.12.1  [Abandoned/Lost Non-IRS Personal Property Found on IRS Premises](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024698704)
  - 1.14.4.13  [CI Property](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024696816)
    - 1.14.4.13.1  [FMSS Assistance to CI](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686024694848)
    - 1.14.4.13.2  [Disposition of Firearms/Ammunition](https://www.irs.gov/irm/part1/irm_01-014-004#idm140686025608928)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 4. Personal Property Management

* * *

## 1.14.4 Personal Property Management

#### Manual Transmittal

July 01, 2025

#### Purpose

(1) This transmits revised IRM 1.14.4, Personal Property Management.

#### Material Changes

(1) _IRM 1.14.4.1 (6)_ \- Edited to update and define acronym for hardware asset management system to Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager (IRWorks HAM).

(2) _IRM 1.14.4.1.1_ \- Updated to correct IRM citations and referenced IRM titles in (3) and (4), and to correct grammar.

(3) _IRM 1.14.4.1.2 (1)_ \- Edited to correct links to citations, acronyms, spelling, and to remove incorrect citation.

(4) _IRM 1.14.4.1.3 (2)_ \- Edited field names within asset management program to reflect updated field names in new system.

(5) _IRM 1.14.4.1.3 (2)_ \- Replaced full system name with previously defined acronym and updated to reflect new hardware asset management system name.

(6) _IRM 1.14.4.1.3 (3)_ \- Updated name of hardware asset management system.

(7) _IRM 1.14.4.1.3 (5)_ \- Updated name of hardware asset management system.

(8) _IRM 1.14.4.1.4_ \- Updated title of subsection and edited to include name of new hardware asset management program.

(9) _IRM 1.14.4.1.5_ \- Added Program Controls Subsection. Later subsections renumbered.

(10) _IRM 1.14.4.1.6_ \- Subsection renumbered and title updated. Updated table to remove or add acronyms based on changes to the names of systems or business operating divisions. Editorial changes made for grammar, spelling, and clarity. Edited to include name of new hardware asset management program.

(11) _IRM 1.14.4.1.6 (2)_ \- Updated definition of the useful life of Accountable Property from "more than one year" to "two years or longer" .

(12) _IRM 1.14.4.1.6 (18)_ \- Added content to the paragraph to describe the table.

(13) _IRM 1.14.4.1.7_ \- Subsection renumbered. Removed citation of IRM that no longer exists and updated remaining citations.

(14) _IRM 1.14.4.2_ \- Updated the title of subsection to include new asset management system name and acronym, Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager (IRWorks HAM), and updated references within the section to the new system name.

(15) _IRM 1.14.4.3_ \- Updated name of asset management system.

(16) _IRM 1.14.4.4 (2)_ \- Added title of IRM subsection to reference.

(17) _IRM 1.14.4.4 (4)_ \- Edited to update ticketing system name.

(18) _IRM 1.14.4.5_ \- Edited to update ticketing system name.

(19) _IRM 1.14.4.5.1_ \- Edited to change emphasis type based on style guide and organize examples as a list.

(20) _IRM 1.14.4.5.2 (1)_ \- Added information to specify actions required when seized or forfeited property is to be placed in official use. Updated reference source in Note.

(21) _IRM 1.14.4.5.2 (2)_ \- Added list of parameters required when recording that a seized or forfeited non-IT asset that was placed in IRS use and specified when an asset is considered to be placed in official use. Corrected Exception to state that property used for investigative purposes is not tracked. Updated name of asset management system.

(22) _IRM 1.14.4.5.3 (1)_ \- Update for name of ticketing system to request/order telework furniture and correct link in Note.

(23) _IRM 1.14.4.5.3 (2)_ \- Updated to outline disposition process of telework/HaP furniture.

(24) _IRM 1.14.4.6 (2)_ \- Updated to show name of new asset management system.

(25) _IRM 1.14.4.6.1_ \- Edits made to update ticketing system name and correct grammar for additional clarity.

(26) _IRM 1.14.4.6.2_ \- Edited to define acronym, for use of plain language, and to update _Note_ in (2) for link to Treasury Directive (TD) reference.

(27) _IRM 1.14.4.7.1 (1)_ \- Edited to add link to code reference.

(28) _IRM 1.14.4.7.2 (1)_\- Edited to add links to code references and for grammar.

(29) _IRM 1.14.4.7.3 (1)_ \- Edited to add links to code reference and email.

(30) _IRM 1.14.4.7.4 (1)_ \- Edited to add links to code references and email address, to add emphasis using bold lettering, and to clarify intent by changing the word reiterate to dismiss.

(31) _IRM 1.14.4.7.5 (1)_ \- Edited to include links for cited resources and for use of active voice and plain language.

(32) _IRM 1.14.4.7.6 (1)_ \- Edited for title of IRM reference in Note, use of active voice, and plain language.

(33) _IRM 1.14.4.8 (2)_ \- Edited for current ticketing system name and for clarity of action to take.

(34) _IRM 1.14.4.10 (1)_ \- Edited to update IRM reference and include title of cited IRM section.

(35) _IRM 1.14.4.10 (2)_ \- Edited for plain language.

(36) _IRM 1.14.4.11 (1)_ \- Edited to add link to code reference.

(37) _IRM 1.14.4.11.1 (1)_ Edited for clarity, to correct and link cited resource, and to update the name of the asset management system.

(38) _IRM 1.14.4.11.1 (4)_ \- Edited for current ticketing system name.

(39) _IRM 1.14.4.11.1 (8)_ \- Updated citation and added link to cited reference.

(40) _IRM 1.14.4.11.2 (1)_ \- Added link to cited reference.

(41) _IRM 1.14.4.12 (1)_ \- Added links to cited references and updated name of the asset management system.

(42) _IRM 1.14.4.12.1 (1)_ \- Edited to include link to reference.

(43) _IRM 1.14.4.11.2 (2)_ \- Edited list item (h) for clarity.

(44) _IRM 1.14.4.13 (1)_ \- Corrected title of cited IRM reference.

(45) _IRM 1.14.4.13.1 (1)_ \- Edited for current ticketing system name.

(46) Throughout:

1. Replaced references to Wage and Investment (W&I) with Taxpayer Services (TS).

2. Replaced references to the Knowledge Incident/Problem Service Asset Management Asset Manager (KISAM-AM) and replaced with Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager (IRWorks HAM).

3. Replaced references to GSA’s website for reporting, searching and selecting excess personal property (GSAXcess®) with Personal Property Management System (PPMS).

4. Replaced references to prior ticketing system, OS GetServices, with new ticketing system name IRS Service Central (IRWorks).


#### Effect on Other Documents

This supersedes IRM 1.14.4 dated October 7, 2022.

#### Audience

All IRS Organizations

#### Effective Date

(07-01-2025)

Julia W. Caldwell

Acting Chief

Facilities Management and Security Services

**1.14.4.1** **(07-01-2025)**

### Program Scope

1. **Purpose**: Property and Asset Management (P&AM) is the ongoing process and function of maintaining physical accountability of IRS assets throughout their lifecycle. The process uses various property management tools for tracking, value reporting, and chain of custody of IRS non-Information Technology (IT) assets through acquisition to final disposal. These tools help to mitigate vulnerability to theft, waste, fraud, or abuse.

2. **Audience**: This policy applies to IRS employees who are responsible and accountable for acquiring, bar coding, maintaining, inventorying and controlling non-IT assets.

3. **Policy Owner**: Facilities Management and Security Services (FMSS) is the program office responsible for overseeing the P&AM Program and providing guidance to each IRS business unit.

4. **Program Owner**: FMSS, Business Solutions, Logistics.

5. **Primary Stakeholders**: Each IRS business unit is a partner of the P&AM Program. FMSS, IT, Criminal Investigation (CI) and the Chief Financial Officer (CFO) are primarily impacted by the changes to the policies and procedures. IT/User & Network Services (UNS) is the business process owner of enterprise asset inventory data. IT/UNS partners with FMSS, CI, Chief Counsel (CC) and the other IT component organizations who are accountable and responsible for verifying and certifying hardware assets under their respective control and stewardship.

6. **Program Goals**: The P&AM Program serves as the IRS lead in the lifecycle management of non-IT accountable assets tracked in the Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager (IRWorks HAM) system and in the disposal of IT assets. The program supports IRS goals and objectives in sustainability and recycling/reuse efforts.



### Note:



P&AM program disposes of most assets, not all.


**1.14.4.1.1** **(07-01-2025)**

#### Background

1. This IRM provides purpose, authorities, directives, and responsibilities for the P&AM Program.

2. P&AM includes the process, people, and systems that provide effective accounting and internal controls of personal property throughout its lifecycle (e.g., acquisition through final disposal).

3. FMSS Headquarters (HQ) P&AM Program has oversight for the management of non-IT IRS assets and administers the program in compliance with IRM 1.14.4.1.2, Authority, and as revised.



### Exception:



Disposal of IRS investigative assets listed in Criminal Investigation Management Information System (CIMIS). FMSS Territory Property staff can assist in the disposal process, except for CI firearms and/or ammunition.





### Note:



Any additional exceptions will be listed in IRM 9.9.1, Employee Criminal Investigation Management Information System Responsibilities and Procedures, IRM 9.9.4, Criminal Investigation Management Information System Data Fields, and IRM 9.10.1, Criminal Investigation Management Information System Equipment Inventory.

4. IT assets are managed by IT until the assets are no longer required by IRS and reported to FMSS for final disposition. The IT program requirements and processes are addressed in IRM 2.149, IT Asset Management.

5. The CI investigative asset requirements and processes are addressed in IRM 9.10.1, Criminal Investigation Management Information System Equipment Inventory. CI IT and non-IT assets, not recorded in CIMIS, are governed under IRM 2.149, IT Asset Management and IRM 1.14.4, Personal Property Management.

6. Asset management places a significant importance and effort into certifying that accountable IRS assets are maintained in agency asset management systems. Accountability is the obligation imposed by law, lawful order, or regulation:



1. Federal Management Regulation (FMR) Chapter 102 published in Title 41 of the Code of Federal Regulations (CFR) provides for the maximum utilization of IRS assets.


**1.14.4.1.2** **(07-01-2025)**

#### Authority

1. The IRS P&AM Program is based primarily on:



1. [41 CFR, Subchapter B](https://www.ecfr.gov/current/title-41/subtitle-C/chapter-102/subchapter-B), Personal Property Part 102

2. General Services Administration (GSA) Bulletins 26, 27, 34, 40, 48

3. Treasury Directives (TD) 61-04, 61-09 and 73-01

4. Executive Order (EO) 12999



      ### Note:



      Additional guidance can be found on the P&AM SharePoint site.


**1.14.4.1.3** **(07-01-2025)**

#### Responsibilities

1. The P&AM Program requires the participation of FMSS Territory Managers (TM) and employees to ensure separation of duties and adherence to regulations; support internal controls and Quality Assurance (QA) program reviews; and protect employees from any appearance of favoritism or misappropriation of government assets.

2. The FMSS designated HQ Program Manager is responsible for:



1. Conducting regular reviews of FMSS Territory P&AM Program activities utilizing data from IRWorks HAM fields: State (In Use, In Stock), Asset Tag (Barcode), Serial Number, Location (Building Code), Managed by (Contact), Assigned to (User).

2. Providing guidance and policy clarification to FMSS Territory Property staff regarding FMSS P&AM program guides or answering concerns.

3. Coordinating with each business unit and external stakeholders on P&AM policy and guidance.

4. Providing completed HQ reviews with corrective requirements and directions to the FMSS Territory Property staff and their managers.

5. Acting as a FMSS Approving Authority for IRS disposal documents.

6. Conducting internal control reviews (timeliness and accuracy of data) regarding the P&AM Program processes within their territory.


3. The FMSS TM and/or Section Chiefs are responsible for:



1. Verifying that the Territory P&AM Program has committed resources to support the program responsibilities.

2. Reviewing the P&AM dashboard measures to monitor territory program health.

3. Verifying that IRS acquisition documents are reviewed and that assets required to be accounted for in IRWorks HAM are added within 10 business days.

4. Reviewing and signing IRS disposal documents timely (prior to the actual physical disposal action) as the approving authority for both IT and non-IT personal property, whether tracked in IRWorks HAM or not.

5. Validating territory program review corrections are completed timely and accurately.

6. Validating the accuracy of the Territory IRWorks HAM annual inventory by signing the annual Territory Inventory Certification Memo.

7. Correcting anomalies identified in the Territory IRWorks HAM annual inventory reconciliation plan on or before the annual September due date and validating corrections were completed by signing the Territory Reconciliation Memo.

8. Verifying excess non-IT personal property follows all regulatory requirements and documentation is available for reviews and audits.


4. The FMSS Territory Property Officer is accountable and responsible for the life-cycle management of IRS personal property, which includes following P&AM program processes and procedures within their territory. Other FMSS territory employees may assist with the responsibilities as assigned by the TM or the Section Chief.

5. The FMSS Territory IRWorks HAM Coordinator is the territory employee who is accountable and responsible for maintaining non-IT asset records and disposal activities in IRWorks HAM. This employee may be the same employee(s) as the FMSS Territory Property Officer.


**1.14.4.1.4** **(07-01-2025)**

#### Program Management and Review

1. **Program Reports**: The IRWorks HAM system is the central repository used for processing all basic accountability actions related to the entire lifecycle of IRS non-IT assets, IRWorks HAM records, and tracks accountable non-IT asset acquisitions, transfers, moves, and disposals.



1. _**Acquisition Reports**_ are stored in Procurement for Public Sector (PPS) (or its successor program). The purchase information for non-IT assets is reviewed by the FMSS Territory Property staff for non-IT asset purchases with Material Group Code - codes 3122A, 3126, 3192A and 3193. The non-IT asset purchases that meet the accountable threshold or sensitive threshold are added into IRWorks HAM. The acquisition information (PPS or Purchase Order (PO)) is a mandatory data field in the IRWorks HAM asset record. Non-IT personal property assets meeting the threshold requirements in IRWorks HAM are added after receipt and acceptance is completed in PPS.

2. _**IRWorks HAM Reports**_ show the lifecycle management of personal property from acquisition to final disposal. These reports support accuracy, timeliness, accountability, chain of custody, and auditability.

3. _**Disposal Reports**_ document the final disposal action where IRS no longer has ownership or title of an asset.

4. _**Personal Property Management System (PPMS)**_ provide data of IRS excess property reported to GSA for transfer, donation, or sale.

5. _**STAR Project Reports**_ provide data on the timely reuse, exchange, or excess of IRS property related to real estate projects (e.g., rent reductions, relocations).


2. **Program Effectiveness**: Success of the P&AM Program is measured by verifying:



1. Deficiencies/problems are corrected timely and accurately as identified by Program Reviews’ instructions.

2. New non-IT assets are added to IRWorks HAM after receipt and acceptance in PPS.

3. Non-IT annual inventory certification and validation by June 30.

4. Non-IT assets, including furniture in a real estate project, are identified for reuse.



      ### Note:



      If assets cannot be reused, they should be exchanged. If assets cannot be reused or exchanged, they must be excessed.

5. IT asset disposal cycle time is 60 days or less with a 90% timeliness score excluding extenuating circumstances.



      ### Example:



      Extenuating circumstances such as, epidemics, weather disasters, etc.

6. Dedicated resources to support the program are expended. This is measured by reviewing time recorded in the IRS timekeeping system, Single Entry Time Reporting (SETR), using the P&AM Program code (800-55121).

7. Audit recommendations and Planned Corrective Actions (PCA) are timely executed in the territories as prescribed in the recommendations or PCAs.


**1.14.4.1.5** **(07-01-2025)**

#### Program Controls

1. **Quality Assurance Reviews** \- FMSS HQ P&AM Program Staff is responsible for conducting scheduled Quality Assurance (QA) Reviews. The QA reviews are to reasonably assure that:



1. Key data elements of assets in IRWorks HAM are correct and updated.

2. Disposal actions are approved by those authorized to do so and that approval is obtained prior to the disposal of assets.

3. Disposal documents are accurate and complete.


2. **Access Limitations** \- Access to General Services Administration (GSA) Personal Property Management System (PPMS) and IRWorks HAM non-IT inventory data base requires initial approval from FMSS HQ P&AM Program Staff.


**1.14.4.1.6** **(07-01-2025)**

#### Terms and Acronyms

01. **Abandoned or Unclaimed Property** \- Personal property found on IRS premises owned or leased by the government and subject to the filing of claims by former owner(s) within three years from the vesting of title in the United States.

02. **Accountable Property** \- All non-expendable property for which accountability is established in the perpetual inventory accounts (IRWorks HAM) and the general ledger. It is property of durable nature with an expected useful life of two years or longer, has sufficient value to justify maintaining and continuing financial property records, is of a nature that moderate damage results in repair rather than replacement, and generally costs $5,000 or more.

03. **Asset** \- Any property other than real estate. The distinguishing factor between personal property and real property is that personal property is movable and not fixed permanently to one location, such as land or buildings. Term is interchangeable with personal property.

04. **Capitalized Property** \- An accounting/finance term used on the agency financial statement. This property has different dollar threshold requirements controlled by the CFO Office. Not to be confused with Accountable Property that requires tracking in IRWorks HAM.

05. **Condition Codes** \- An alpha or numeric code that describes the physical condition and serviceability of personal property as prescribed by the Federal Management Regulations (FMR).

06. **Excess Personal Property** \- Any property under the control of any federal agency not required for its needs and the discharge of its responsibilities, as determined by the agency head.

07. **Executive Agency** \- An executive department, military department, or any independent establishment, within the meaning of 5 USC 101, 102, and 104 (1), respectively, or wholly owned government corporation within the meaning of 31 USC 9101(3).

08. **Expendable/Consumable Property** \- All property that is used up beyond recovery, loses its identity, or becomes a component part of other equipment or fixed property. Usually is an item of supply (except explosive ordnance, major end items of equipment, and repairable items) (e.g., non-repairable items or repair parts that can be discarded more economically than they can be repaired, pencils, pens, paper, dried up markers, batteries, and similar items).

09. **Federal Agency** \- An executive agency or any independent establishment in the legislative or judicial branch of the Government (except the Senate, the House of Representatives, or the Architect of the Capitol, and any activities under the Architect's direction).

10. **Forfeited Property** \- Personal property acquired by a federal agency either by a summary process or by order of a court of competent jurisdiction pursuant to any law of the United States.

11. **High Risk or Sensitive** \- A unique classification given to assets, that require special control and accountability due to unusual rates of loss, theft, misuse, ability to store IRS data, ease of removal, and the risk of impacting the IRS mission. These assets are recorded and tracked in IRWorks HAM if their acquisition is $2,500 or greater.

12. **Investigative Equipment** \- CI equipment required by CI for carrying out its investigative and enforcement functions. See IRM 9.10.1, Criminal Investigation Management Information System Equipment Inventory.

13. **Maintenance** \- The scheduled cleaning, servicing, and adjustment of an asset to keep it in satisfactory operating condition.

14. **Personal Property** \- Any property other than real estate. The distinguishing factor between personal property and real property is that personal property is movable and not fixed permanently to one location, such as land or buildings. Term is interchangeable with asset.

15. **Repair** \- The restoration of an asset to a serviceable or operable condition from an unserviceable or inoperable condition, which resulted from wear, breakage, or partial destruction. The overall objective is to restore or renovate assets to a near-new condition.

16. **Unconditional (in-kind) Gifts** \- Gifts of more than minimal value (minimal value is defined by GSA) received by federal employees, their spouses, or dependents from a foreign government are deemed to have been accepted on behalf of the United States and, upon acceptance, become the property of the United States.

17. **Utilization** \- Identification, reporting, and transfer of excess personal property within IRS or federal agencies to fill current or future authorized requirements in lieu of new procurement.

18. The following table provides acronyms that are used throughout this IRM section:




    | **Acronym** | **Definition** |
    | --- | --- |
    | CC | Chief Counsel |
    | CI | Criminal Investigation |
    | CIMIS | Criminal Investigation Management Information System |
    | CFO | Chief Financial Officer |
    | CFR | Code of Federal Regulations |
    | CSIRC | Computer Security Incident Reporting Center |
    | EHS | Environment, Health and Safety |
    | FAR | Federal Acquisition Regulations |
    | FEA | Federal Electronic Assets |
    | FMR | Federal Management Regulation |
    | FMSS | Facilities Management and Security Services |
    | FPMR | Federal Property Management Regulation |
    | GAO | Government Accountability Office |
    | GRS | General Record Schedule |
    | GSA | General Services Administration |
    | HaP | Home as POD |
    | HQ | Headquarters |
    | IT | Information Technology |
    | IRC | Internal Revenue Code |
    | IRWorks | Internal Revenue Workflow Optimization, Request and Knowledge System |
    | IRWorks HAM | Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager |
    | LB&I | Large Business and International |
    | P&AM | Property & Asset Management |
    | PCA | Planned Corrective Action |
    | PPMS | Personal Property Management System |
    | PPS | Procurement for Public Sector |
    | QA | Quality Assurance |
    | SAMC | Situational Awareness Management Center |
    | SB/SE | Small Business/Self-Employed |
    | SOP | Standard Operating Procedures |
    | TD | Treasury Directive |
    | TIGTA | Treasury Inspector General for Tax Administration |
    | TM | Territory Manager |
    | TS | Taxpayer Services |
    | UNS | User Network Services |
    | USC | United States Code |


**1.14.4.1.7** **(07-01-2025)**

#### Related Resources

01. Asset Management Hardware User Guide.

02. FMSS Property and Asset Management Resource Guide.

03. Property and Asset Management User Guide.

04. IRM 1.2.2.2.21, Delegation Order 1-24 (Rev. 1) (formerly DO-202, Rev. 3), Acceptance, Retention, and Disposition of Gifts under the Foreign Gifts and Decorations Act.

05. IRM 1.14.3, Furniture and Equipment Standards.

06. IRM 2.149, IT Asset Management.

07. IRM 4.62.3, Requests for Representation Funds and Gifts for Foreign Officials.

08. IRM 6.800.2, IRS Telework Program.

09. IRM 9.7, Asset Seizure and Forfeiture.

10. IRM 9.10.1, Criminal Investigation Management Information System Equipment Inventory.

11. IRM 9.11.3, Investigative Property.

12. IRM 10.5.4, Incident Management Program.


**1.14.4.2** **(07-01-2025)**

### Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager (IRWorks HAM) General Provisions - System Description

1. Internal Revenue Workflow Optimization, Request and Knowledge System Hardware Asset Manager (IRWorks HAM) is the authoritative source for all hardware asset management and inventory information within IRS and supersedes other inventory data sources. IRWorks HAM is the official IRS centralized asset management inventory database of all IT and non-IT personal property that meets the specified threshold/reportable criteria. It is a subsidiary account to the general ledger for managing personal property. IRWorks HAM tracks each item of accountable property through the asset’s lifecycle (acquisition through final disposal).



1. Non-IT assets accountable and inventoried on IRWorks HAM are those individual assets with an acquisition cost of $5,000 or more and all designated "high-risk" non-IT assets with an acquisition cost of $2,500 or more.



      ### Exception:



      Investigative equipment and CI investigative/surveillance motor vehicles are controlled by CI on the CIMIS. IRS leased vehicles are maintained by the HQ Motor Vehicle Fleet Program Manager.


2. Each fiscal year, all FMSS territory offices are required to conduct a physical inventory of all non-IT assets meeting IRS specified criteria. The HQ P&AM Program Manager will issue an annual control to notify the territory offices of the timeline and due date. As part of the inventory, offices are required to reconcile all missing assets using the Non-IT Missing Asset Checklist with the IRWorks HAM system and address any assets awaiting disposal longer than 60 calendar days.


**1.14.4.3** **(07-01-2025)**

### Separation of Duties

1. FMSS management strives to ensure no employee is responsible for more than two of the following duties and functions.



1. Acquiring property (using their government credit card or the Point(s) of Contact (POC) for a procurement action above the designated threshold).

2. Receiving property.

3. Inventorying property into IRWorks HAM.

4. Signing disposal documents as the reviewer/submitter.

5. Acting as a Project Manager on a real estate project (cannot prepare or sign IRS disposal documents).



      ### Note:



      A Project Manager cannot "act" as an FMSS Territory Property Officer on their own project.


**1.14.4.4** **(07-01-2025)**

### Management and Utilization of Personal Property

1. All IRS employees are responsible for the proper care and protection of government property they use or have in their possession. Any employee witnessing a violation of this responsibility must report it to his/her immediate supervisor.

2. All IRS employees must promptly report the loss of any IRS asset within one hour of discovery of the loss following the directions in IRM 1.14.4.11.2, Disposal of Items Requiring Special Handling.

3. All IRS employees are responsible for promptly requesting needed repairs to property.

4. All IRS managers are responsible for:



1. Determining that furniture and equipment is in good working order.

2. Confirming employees assigned to use IRS assets maintain and protect them.

3. Ensuring that IRS assets are only used for official requirements.

4. Determining if property is in good condition after repairs are made.

5. Obtaining their direct managerial approval before property is removed from the premises for any reason.

6. Obtaining all equipment, furniture, and keys from retiring, separating, and/or transferring employees.

7. Submitting a Property Consultation ticket through IRS Service Central (IRWorks) when property is no longer needed.


**1.14.4.5** **(07-01-2025)**

### Acquisition of Non-IT Personal Property

1. A business unit must contact FMSS using an IRS Service Central (IRWorks) ticket for Property Consultation or Property Acquisition when planning the purchase (either through procurement or by credit card) of office equipment and furniture $2,500 or greater to meet their specific business unit or program requirements.


**1.14.4.5.1** **(07-01-2025)**

#### Rented or Leased Non-IT Property

1. **Reserved for HQ** (P&AM determines if an asset that is rented or leased must be tracked). Examples:



   - Postage Meters are tracked multiple ways by the HQ Mail Program Manager and contractor, therefore, we will not duplicate efforts.

   - Leased GSA Motor Vehicles are tracked by the HQ Motor Vehicle Program Manager and GSA, therefore, will not be tracked by P&AM.

   - Safes or other type of equipment/property that is not tracked via any other means will be tracked by P&AM.


**1.14.4.5.2** **(07-01-2025)**

#### Seized/Forfeited Assets – General

1. Duly authorized IRS employees may seize property for forfeiture to the United States when the property is used, or intended for use, in violation of the Internal Revenue Code (IRC) and certain other federal statutes. Under some circumstances, this property may be assigned to IRS if it is suitable for government use and a legitimate need exists. Forfeiture of seized property is reported on Form 1570, Declaration of Forfeiture. A copy of the Form 1570 and a memorandum, advising the placement of the seized property into official use, is provided to the FMSS HQ P&AM Staff for non-IT property and IT Office for IT property.



### Note:



For additional information, see Asset Management - UNS Hardware Asset Management User Guide V2.0 9/27/2019 - 4.6.2 Criminal Investigation (CI) Special Task Force and Undercover, or Seized Assets.

2. Seized/forfeited non-IT property placed into official IRS use must be reported to FMSS for entry into IRWorks HAM. The following data must be included on/with the Form 1570.



1. Acquisition date (The date signed on the Form 1570 is the acquisition date that is recorded in IRWorks HAM, and is the date that the IRS can officially use the property).

2. Acquisition cost (The acquisition cost of seized asset must be based on the current market value of the asset).

3. Brief description of asset.

4. Location of asset.


### Exception:

Seized/forfeited property used for investigative purposes is not tracked.

**1.14.4.5.3** **(07-01-2025)**

#### Telework and Home as POD (HaP) Assets

1. Property is provided to approved frequent telework and HaP employees when an approved request is submitted.



1. To request/order telework furniture, the employee submits an IRS Service Central (IRWorks) ticket.

2. Furniture allowed for approved HaP employees is provided for use while the employee maintains a HaP approval.



      ### Note:



      For additional guidance, see Home as POD (HaP) Program Website, Home as POD Program - Overview (sharepoint.com).


2. Telework/HaP furniture, consisting of property named in provisions of the NTEU Agreement covering non-IT property available to employees on a frequent telework agreement, that is delivered to an employee's Telework/HaP site will be considered Abandoned in Place upon receipt by the employee. Abandoned in Place means the furniture is no longer the property of the IRS and the employee assumes responsibility for disposal at the appropriate time. This is only applicable to items listed in the relevant portion of the NTEU Agreement which have already undergone the specific cost-analysis determination described in 41 CFR 102-36.35(d) .


**1.14.4.6** **(07-01-2025)**

### Accountability and Control Records

1. Under federal regulations, each agency must establish quantitative and monetary controls over its personal property.

2. IRWorks HAM provides IRS with the official complete record of perpetual inventory accounts for IT and non-IT assets, which meets the control criteria for the IRS general ledger accounts. Accountability in the fiscal context includes reporting on the use of funds and recording the events and transactions involving an IRS asset. This process provides historical information about the asset’s value throughout its lifecycle.


**1.14.4.6.1** **(07-01-2025)**

#### Control Responsibilities

1. IRS managers are responsible for safeguarding all property within their span of control from loss, breakage, or undue deterioration until the FMSS Territory Property Officer authorizes its removal through a submitted IRS Service Central (IRWorks) ticket under Non-IT Property Disposal.



1. With approval, employees can remove property from IRS offices to an offsite location to conduct official business. Approval must be given by the employee’s manager and the FMSS Territory Property Officer through an IRS Service Central (IRWorks) ticket under Property Consultation. The property must be returned to the office as soon as it is practical.

2. The employee is responsible for safeguarding the property while it is offsite.


2. IRS employees may only use personally owned property for official use if authorized by IRS or Treasury regulations. Requests to use personally owned property for official use must be submitted to the FMSS Territory Property Officer through an IRS Service Central (IRWorks) ticket under Property Consultation.


**1.14.4.6.2** **(07-01-2025)**

#### Records

1. Asset Management records are established and maintained in accordance with Privacy, Governmental Liaison and Disclosure (PGLD) Guidance. Each FMSS territory maintains their own official property record files (electronic or hard copy).

2. General Record Schedule (GRS) 4 used for Property Disposal Records and GRS 5 used for Budget Preparation, Presentation, and Apportionment Records are both found in Document 12829, General Records Schedule.



### Note:



Territory Disposal Records are maintained for three years, and disposition follows the records schedule requirements. Territory acquisition documents are maintained until the asset is excessed/disposed ( [TD 73-01](https://home.treasury.gov/about/general-information/orders-and-directives/td73-01)).


**1.14.4.7** **(09-28-2017)**

### Reports

1. Annual reports must be filed to comply with federal requirements. These include reports to GSA, Treasury, and the FMSS HQ P&AM Program Manager.

2. Reports are compiled by each of the FMSS territories and submitted to the FMSS HQ P&AM Program Manager for consolidation and upward reporting. These reports include:



1. Property Furnished to Non-Federal Recipients

2. Exchange/Sale Transactions

3. Acceptance of Unconditional (In-Kind) Gifts

4. Acceptance, Retention, and Disposition of Gifts under the Foreign Gifts and Decorations Act

5. Disposition of Gifts

6. Gifts Given to Foreign Individuals


**1.14.4.7.1** **(07-01-2025)**

#### Property Furnished to Non-Federal Recipients

1. Pursuant to [40 USC 529, Annual executive agency reports on excess personal property](https://www.govinfo.gov/content/pkg/USCODE-2023-title40/html/USCODE-2023-title40-subtitleI-chap5-subchapII-sec529.htm), following the close of each fiscal year, executive agencies must submit an annual report of personal property furnished to any non-federal recipient during the previous fiscal year to GSA. This includes all personal property assets, such as IT equipment transferred to schools and educational non-profits and recyclers.


**1.14.4.7.2** **(07-01-2025)**

#### Exchange/Sale Transactions

1. 41 CFR 102-39.85 requires each executive agency to submit to GSA a summary report on transactions made under the exchange/sale authority of [40 USC 503](https://www.govinfo.gov/content/pkg/USCODE-2023-title40/html/USCODE-2023-title40-subtitleI-chap5-subchapI-sec503.htm), during the preceding fiscal year. If no exchange/sale transactions are conducted, a negative report is required.


**1.14.4.7.3** **(07-01-2025)**

#### Acceptance of Unconditional (In-Kind) Gifts

1. In accordance with 41 CFR 102-36.415(c) , government employees are responsible for following guidelines for the acceptance of unconditional (in-kind) gifts and bequests, which aid and facilitate the work of the Treasury and the IRS. Contact the FMSS HQ P&AM Program Manager at \*FMSS HQ Property Staff Mailbox for instructions on reporting a gift received.



### Note:



Refer to Office of Counsel, General Legal Services (GLS) website for Gifts from Outside Sources.


**1.14.4.7.4** **(07-01-2025)**

#### Acceptance, Retention, and Disposition of Gifts under the Foreign Gifts and Decorations Act

1. In accordance with 41 CFR 102-42 , [TD 61-04](https://home.treasury.gov/about/general-information/orders-and-directives/td61-04), and [TD 61-09](https://home.treasury.gov/about/general-information/orders-and-directives/td61-09) government employees are responsible for following guidelines established for the acceptance of gifts offered by foreign governments. This does not dismiss the restrictions in the regulations cited in 41 CFR 102-36.415(c) . Contact the FMSS HQ P&AM Program Manager at \*FMSS HQ Property Staff Mailbox for instructions on reporting a gift received **within 14 business days of receipt of gift**.



### Note:



Refer to Office of Counsel, General Legal Services (GLS) website.


**1.14.4.7.5** **(07-01-2025)**

#### Disposition of Gifts

1. In accordance with [TD 61-04](https://home.treasury.gov/about/general-information/orders-and-directives/td61-04) and [TD 61-09](https://home.treasury.gov/about/general-information/orders-and-directives/td61-09), gift acceptance authority is not delegated to the Service, a gift to the Service must be accepted at the Departmental level. When foreign gifts are received, the FMSS HQ P&AM Program Manager coordinates with GLS and Treasury before an IRS employee can keep the gift.



### Note:



Refer to Office of Counsel, General Legal Services (GLS) website for instructions on reporting Gifts from Foreign Sources and Gifts to the Department.


**1.14.4.7.6** **(07-01-2025)**

#### Gifts Given to Foreign Individuals

1. The IRS must report to GSA the foreign gifts given by IRS employees to foreign officials annually. The FMSS HQ P&AM Program Manager must contact the business unit to request the dollar amount of gifts given the previous year.



### Note:



For additional guidance, see IRM 4.62.3, Requests for Representation Funds and Gifts for Foreign Officials.


**1.14.4.8** **(07-01-2025)**

### Temporary and/or Internal Transfers of Non-IT Property

1. The FMSS Territory Property Officer is responsible for the transfer of all non-IT property temporarily loaned to or from another government agency and maintains the official documentation.

2. Transfers of IRS non-IT property between IRS offices or business units must be approved in advance by the FMSS Territory Property Officer by the requestor submitting an IRS Service Central (IRWorks) ticket under Property Consultation. The receiving party is responsible for transportation costs.


**1.14.4.9** **(04-30-2018)**

### Maintenance and Repair

1. FMSS territory offices provide adequate care and preventive maintenance of property. This includes maintaining purchase and warranty records necessary to obtain vendor support to repair or replace property.


**1.14.4.10** **(07-01-2025)**

### Photography Prohibition in IRS Space

1. Taking photographs within IRS space is prohibited except when specifically authorized by FMSS Security, see IRM 10.2.14.6, Photography and Video Recordings Prohibition

2. The FMSS Territory Property Officer uses pictures for reporting excess, documenting the condition of property, and for audit purposes.


**1.14.4.11** **(07-01-2025)**

### Disposition of Personal Property

1. _The Federal Property and Administrative Services Act of 1949_ delegated authority to GSA to prescribe regulations governing the management of property in the federal government. One aspect of this property management relates to the disposition of property no longer required by an agency. 41 CFR 102-35 sets forth procedures, and is supplemented by IRM 1.14.4, which must be followed by all FMSS Territory Property Officers.


**1.14.4.11.1** **(07-01-2025)**

#### Disposition of Property - Excess

1. All property declared excess to the needs of a business unit is disposed according to the instructions outlined in this IRM and 41 CFR 102-36, even if the assets are not inventoried on IRWorks HAM.

2. IRS non-IT personal property cannot be given as a gift to anyone.

3. The FMSS Territory Property Officer is the only IRS employee who can make the determination and administer within their territory the disposal of any IRS personal property.



### Exception:



Firearms and/or ammunition excess requires special handling. Contact the HQ P&AM staff.

4. Excess property is reported to FMSS Territory Property Officers through an IRS Service Central (IRWorks) non-IT property disposal ticket.



### Exception:



IRS real estate project furniture and equipment disposal determination is addressed by the FMSS Project Manager and the FMSS Territory Property Officer when submitting real estate projects for approval and funding to HQ Project Management.

5. All non-IT property declared excess to IRS needs must be reported on a Form 120, Report of Excess Personal Property, by the FMSS Territory Property staff to begin the final disposal process. IRS excess in condition codes 1 (new) and 4 (usable) is screened within IRS. IRS excess property with a condition code of 1, 4, and 7 (repairable) must be reported to GSA through Personal Property Management System (PPMS).



### Exception:



IRS property exchanged under the FMSS Exchange/Trade-In Contract will be reported on Form MI, Miscellaneous Disposal (no Form 120 is necessary).

6. A Form 122, Transfer Order Excess Personal Property, will be completed for transfers of IRS personal property outside of IRS.

7. The final disposal date is the date the asset was physically picked up from an IRS location and ownership transferred to the recipient. The recipient or their agent signs the final disposal document at the time of pick up.



1. The final disposal date for Form 1933, Report of Survey, is the date the FMSS Approving Authority signs the form.



      ### Note:



      If property is disposed into a UNICOR trailer, the day the asset is placed in the trailer is the disposal date.


8. All IT equipment excess to IRS needs will be reported to FMSS by IT/UNS and/or CI on a Form 120, Report of Excess Personal Property. The FMSS Territory Property Officers have responsibility for determining final disposition action in accordance with 41 CFR 102-36.

9. FMSS Territory Property Officer and FMSS Approving Authority signatures on disposal documents must be electronic.


**1.14.4.11.2** **(07-01-2025)**

#### Disposal of Items Requiring Special Handling

1. FMSS Territory Property Officers coordinate with their territory Environmental, Health and Safety (EHS) staff regarding the disposal of items requiring special handling and follow the guidance in 41 CFR 102-40 .

2. Items requiring special handling include, but are not limited to:



1. Ammunition

2. Biologicals

3. Controlled substances as classified by the Food and Drug Administration in Schedules I, II, III, IV or V

4. Electronic assets (e.g., TV, calculators, VCR, LED flashlights)

5. Hazardous materials

6. Hazardous waste

7. Perishable items

8. Universal waste (e.g., batteries, pesticides, and equipment containing mercury)


**1.14.4.12** **(07-01-2025)**

### Authorizations for Abandonment or Destruction of Personal Property

1. After receiving advanced written approval from the designated FMSS Approving Authority, FMSS Territory Property Officers:



1. Are the only employees authorized to make a determination to abandon or destroy personal property.

2. Must follow the requirements in 41 CFR 102-36, even if the assets are not inventoried on IRWorks HAM.



      ### Note:



      Form 122, Transfer of Excess Personal Property, is used for Abandonment or Destruction only after the assets are reported through PPMS.

3. May donate property in lieu of abandonment to organizations according to 41 CFR 102-37.



      ### Note:



      Form 123, Donation Order of Surplus Personal Property, is used for these donations.


**1.14.4.12.1** **(07-01-2025)**

#### Abandoned/Lost Non-IRS Personal Property Found on IRS Premises

1. Lost or abandoned property not belonging to the IRS and found on IRS property must be turned in to the FMSS Territory Property Officer. The FMSS Territory Property Officer must follow the procedures in 41 CFR 102-41 for disposition.


**1.14.4.13** **(07-01-2025)**

### CI Property

1. CI is responsible for control of investigative equipment. IRM 9.10.1, Criminal Investigation Management Information System Equipment Inventory identifies investigative equipment, defines responsibilities, and sets forth procedures for the investigative equipment program. CI non-IT property that is not investigative equipment must be managed in accordance with IRM 1.14.4.


**1.14.4.13.1** **(07-01-2025)**

#### FMSS Assistance to CI

1. FMSS Territory Property staff must assist CI by providing guidance on disposal of:



1. Investigative property when reported by CI on an IRS Service Central (IRWorks) non-IT property disposal ticket.

2. CI seized, forfeited, or abandoned property when reported by CI on an IRS Service Central (IRWorks) non-IT property disposal ticket.


**1.14.4.13.2** **(04-30-2018)**

#### Disposition of Firearms/Ammunition

1. CI handles the disposition of their firearms, ammunition, and firearm training equipment.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-004#addtoany "Show all")

A2A