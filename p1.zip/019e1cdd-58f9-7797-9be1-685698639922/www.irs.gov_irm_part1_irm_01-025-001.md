---
url: "https://www.irs.gov/irm/part1/irm_01-025-001"
title: "1.25.1 Rules Governing Practice Before the IRS | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-025-001#main-content)

- 1.25.1  [Rules Governing Practice Before the IRS](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987167427904)
  - 1.25.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987140379936)
    - 1.25.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987167423472)
    - 1.25.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987167459568)
    - 1.25.1.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987167456816)
    - 1.25.1.1.4  [Acronyms](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987140514544)
  - 1.25.1.2  [Practice before the IRS Overview](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987140528992)
  - 1.25.1.3  [Authorities Relating to Practice](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987167451888)
    - 1.25.1.3.1  [Power of Attorney and Form 2848](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987167504704)
    - 1.25.1.3.2  [Limited Practice Based on Relationship to the Taxpayer Under Circular 230 Section 10.7](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987140366000)
  - 1.25.1.4  [Referral to the Office of Professional Responsibility](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987140355072)
  - Exhibit  1.25.1-1  [How to Make a Referral to the Office of Professional Responsibility](https://www.irs.gov/irm/part1/irm_01-025-001#idm139987172200448)

# Part 1. Organization, Finance, and Management

# Chapter 25. Practice Before the Service

# Section 1. Rules Governing Practice Before the IRS

* * *

## 1.25.1 Rules Governing Practice Before the IRS

#### Manual Transmittal

July 22, 2024

#### Purpose

(1) This transmits revised IRM 1.25.1, _Practice Before the IRS, Rules Governing Practice Before the IRS_.

#### Material Changes

(1) Added new IRM Subsection 1.25.1.1, _Program Scope and Objectives_.

(2) Reviewed and updated links, legal references and IRM references, as necessary.

(3) Made editorial changes for consistency and clarity.

(4) Removed IRM Subsection, _Resources_.

#### Effect on Other Documents

IRM 1.25.1, dated November 30, 2016, is superseded.

#### Audience

IRS employees and Chief Counsel attorneys who interact with tax professionals.

#### Effective Date

(07-22-2024)

Timothy J. McCormally

Acting Director, Office of Professional Responsibility

**1.25.1.1** **(01-12-2023)**

### Program Scope and Objectives

1. **Purpose:** This section describes the laws and regulations governing the practice of tax professionals before the IRS. This section also describes the Office of Professional Responsibility (OPR), its delegated authority to administer and enforce the rules governing practice and the office’s activities in carrying out its authority and associated responsibilities.

2. **Audience:**This section applies to IRS employees and Chief Counsel attorneys who interact with tax professionals.

3. **Policy Owner:**The Director, OPR, is primarily responsible for administering and enforcing Treasury Department Circular No. 230, _Regulations Governing Practice before the Internal Revenue Service_ (“Regulations” or “Circular 230”). The Director, Return Preparer Office (RPO), is responsible under Circular 230 for the policies and administration of the enrolled practitioner program. See IRM 1.25.2, _Practitioner Enrollment_, for more information.

4. **Program Owner:** The Director, OPR, is responsible for overseeing matters related to the conduct of practitioners and others before the IRS and for discipline, including disciplinary proceedings and sanctions.


**1.25.1.1.1** **(01-12-2023)**

#### Background

1. The OPR undertakes investigations and institutes proceedings pursuant to Title 31, United States Code section 330 and the implementing regulations in Treasury Department Circular No. 230. The OPR remains independent from the Title 26-based enforcement components of the IRS. The main objective of the OPR’s activities is to ensure that those who practice before the IRS on behalf of taxpayers have good character and reputation and the necessary qualifications and competency to provide valuable service to clients and assist them in presenting their cases or other matters to the IRS. The underlying issue in Circular 230 investigations and proceedings is the individual’s “fitness to practice” before the IRS.

2. Since 2012, the RPO, rather than the OPR, has operated the IRS program for the enrollment of individuals as enrolled agents, enrolled retirement plan agents and enrolled actuaries. The RPO processes applications for enrollment or reenrollment, administers the Special Enrollment Examination for enrolled agents, oversees compliance with continuing education requirements, and approves applications to become an IRS recognized continuing education provider.


**1.25.1.1.2** **(01-12-2023)**

#### Authority

1. The OPR’s Authority is listed in _IRM 1.25.1.3_, _Authorities Relating to Practice_.


**1.25.1.1.3** **(01-12-2023)**

#### Roles and Responsibilities

1. The Director, OPR, is the executive responsible for this program.


**1.25.1.1.4** **(01-12-2023)**

#### Acronyms

1. The following table lists the acronyms used throughout this IRM section.



|     |     |
| --- | --- |
| **Acronym** | **Definition** |
| AFSP | Annual Filing Season Program |
| CAF | Centralized Authorization File |
| CFR | Code of Federal Regulations |
| IRC | Internal Revenue Code |
| IRM | Internal Revenue Manual |
| IRS | Internal Revenue Service |
| OPR | Office of Professional Responsibility |
| POA | Power of Attorney |
| RPO | Return Preparer Office |
| TIGTA | Treasury Inspector General for Tax Administration |
| USC | United States Code |


**1.25.1.2** **(06-01-2010)**

### Practice before the IRS Overview

1. The OPR supports the IRS’s strategy to enhance enforcement of the tax laws by ensuring that tax professionals adhere to practice standards and follow the Internal Revenue Code, Treasury regulations and other laws as they apply to an individual’s qualifications, competency and ethical and professional fitness to practice before the IRS. The OPR is the office primarily responsible for interpreting and applying Circular 230, _Regulations Governing Practice before the Internal Revenue Service_ (“Regulations” or “Circular 230”). The OPR has exclusive responsibility for practitioner conduct and discipline, including instituting disciplinary proceedings and pursuing sanctions. It functions independently of the Title 26 enforcement components of the IRS.

2. Practice before the IRS comprehends all matters connected with a presentation to the IRS, or any of its officers or employees, relating to a taxpayer’s rights, privileges or liabilities under laws or regulations administered by the IRS. Such presentations include, but are not limited to:



1. Corresponding and communicating with the IRS.

2. Representing a taxpayer at conferences, hearings or meetings with the IRS.

3. Preparing and filing documents with the IRS on behalf of a taxpayer.

4. Rendering written advice with respect to any entity, transaction, plan or arrangement, or other plan or arrangement having a potential for tax avoidance or evasion.



      ### Note:



      Individuals who are not practitioners may appear as a witness for the taxpayer before the IRS or furnish information at the request of the IRS; however, they may not advocate for the taxpayer or dispute proposed adjustments. In general terms, these individuals are merely assisting with the exchange or communication of information, not practicing before the IRS. An example of an individual assisting with information exchange but not practicing before the IRS would be a taxpayer’s friend serving as a translator when the taxpayer does not speak English.


3. The OPR is responsible for interpreting and applying the standards of practice before the IRS in a fair and equitable manner. This includes communicating and enforcing standards of competence, integrity and conduct among:



   - Attorneys

   - Certified Public Accountants

   - Enrolled Agents

   - Enrolled Retirement Plan Agents

   - Enrolled Actuaries

   - Appraisers

   - Tax Return Preparers and other individuals who engage in limited practice before the IRS


### Note:

Circular 230 contains the regulations governing practice before the IRS and should be consulted for the rules governing authority to practice. The regulations also apply to persons who have limited practice privileges, including tax return preparers who are eligible for limited practice in accordance with Rev. Proc. 2014-42 (or successor guidance) (Rev. Proc. 81-38 applies for tax returns prepared before 2016).

**1.25.1.3** **(11-30-2016)**

### Authorities Relating to Practice

1. 31 USC 330 provides the statutory basis for the regulation of practice before the Department of the Treasury, including the IRS which is a bureau within Treasury.

2. Title 3 CFR Subtitle A, Part 10 contains the regulations governing practice, including the representation of taxpayers, before the IRS. These regulations are republished in digital form as Treasury Department Circular No. 230, _Regulations Governing Practice before the Internal Revenue Service_.

3. Circular 230 details a tax professional’s duties and obligations while representing taxpayers or otherwise practicing before the IRS. It authorizes specific sanctions for violations of any of the Circular’s requirements and restrictions and describes the procedures that apply to administrative disciplinary proceedings.

4. The statute (31 USC 330) and the regulations are the source of the OPR’s authority. Circular 230 seeks to ensure tax professionals possess the requisite character, reputation, qualifications, and competency to provide valuable service to clients in presenting their cases to the IRS. In short, Circular 230 consists of the “rules of engagement” for tax practice. The fundamental issue in all Circular 230 disciplinary cases is the tax professional’s fitness to practice before the IRS.

5. The provisions in Circular 230 set forth who may practice before the IRS, the process for becoming enrolled to practice, the duties and restrictions relating to practice, the process for resolving allegations of violations of those duties and restrictions or for disreputable conduct, and the sanctions available for confirmed violations.



> **Exception:** Provisions added to Circular 230 in 2011 for “registered tax return preparers,” including sections 10.0(a), 10.3(f) and 10.4(c), were invalidated by the decision of the U.S. Court of Appeals for the District of Colombia Circuit in Loving v. IRS, 742 F.3d 1013 (D.C. Cir. 2014). As a result, the registered tax return preparer (RTRP) provisions are not operative or enforceable.

6. Rev. Proc. 2014-42, which put in place the voluntary Annual Filing Season Program (AFSP), prescribes the standards of conduct, the scope of authority and the conditions under which an individual preparer of tax returns may exercise, without enrollment, the privilege of limited practice as a taxpayer’s representative before the IRS. Rev. Proc. 2014-42 explains that because “the RTRP program is no longer in effect” and pending any change in the law to authorize the regulation of tax return preparers, the Treasury Department and the IRS established the AFSP.



### Note:



Rev. Proc. 2014-42 modifies and supersedes Rev. Proc. 81-38 for tax returns and claims for refund prepared and signed (or prepared if there is no signature space on the form) after December 31, 2015.





### Note:



The D.C. Circuit Court of Appeals upheld the validity of the AFSP in AICPA v. IRS, 746 F. App'x 1 (D.C. Cir. 2018).


**1.25.1.3.1** **(01-12-2023)**

#### Power of Attorney and Form 2848

1. A power of attorney is a taxpayer's written authorization for an individual to act on the taxpayers' behalf in specific tax matters. A power of attorney is submitted when a taxpayer wants to authorize an individual, usually a Circular 230 practitioner, to advocate or otherwise represent the taxpayer before the IRS. For example, a power of attorney will be submitted when a taxpayer wants to be represented at a conference with the IRS or to have a written response prepared and submitted to the IRS, advocating for, or asserting any position of, the taxpayer.

2. Form 2848, _Power of Attorney and Declaration of Representative_, is used most often by a taxpayer to appoint an eligible person to represent the taxpayer before the IRS during inquiries and disputes in connection with tax obligations, in connection with requests for Letter Rulings and for any other purpose constituting advocacy of the taxpayer’s position. By signing the Form 2848, the taxpayer authorizes the eligible representative to receive confidential tax information from the IRS and to perform the acts specified on the form, subject to any modifications made by the taxpayer, for the types of tax, tax forms, tax periods, and tax matters specified by the taxpayer on the form. See IRM 21.3.7.5.1, _Essential Elements for Form 2848 and Form 8821_, for the elements of a valid Form 2848.



### Note:



Taxpayers should use Form 8821, _Tax Information Authorization_, only to authorize an individual or organization to receive or inspect confidential tax return information and not for purposes of authorizing representation of the taxpayer before the IRS. Taxpayers should use Form 4506, _Request for Copy of Tax Return_, if the taxpayer wants to authorize disclosure of a tax return to a third party, but the taxpayer does not want to authorize the third party to represent the taxpayer before the IRS.

3. Form 2848 is also used to authorize limited taxpayer representation by individuals who are not Circular 230 practitioners, including:



1. Unenrolled tax return preparers, whose authority to represent cannot exceed that allowed under the special rules of limited practice in Rev. Proc. 2014-42.

2. Individuals who have been given a special appearance authorization pursuant to section 10.7(d) of Circular 230 - for example, students and law graduates of a Low Income Taxpayer Clinic (see IRC 7526) or Student Tax Clinic Program may represent taxpayers before the IRS if authorized pursuant to section 10.7(d) of Circular 230 (see IRM 1.2.2.15.18, _Delegation Order 25-18 (Rev. 5), Authority to Authorize Students and Law Graduates at Low Income Taxpayer Clinics (LITCs) and Student Tax Clinic Programs (STCPs) to Practice Before the Internal Revenue Service (IRS)_).

3. Other individuals who, under Circular 230 section 10.7(c), have a special relationship with the represented taxpayer, such as a bona fide officer or full-time employee of a taxpayer. See IRM 1.25.1.3.2, _Limited Practice Based on Relationship to the Taxpayer Under Circular 230 Section 10.7_.


4. Form 2848 (Part II) contains a number of designations (**a** – **h**, **k**, and **r**) under which individuals are authorized to practice before the IRS. In general, if an individual does not qualify under one of those designations, an individual cannot represent taxpayers before the IRS. For example, a tax return preparer who is not an attorney, certified public accountant, enrolled agent, or who has not obtained the necessary Annual Filing Season Program - Records of Completion cannot represent taxpayers before the IRS in connection with tax returns prepared after 2015. Similarly, certain individuals such as tribal court advocates and Social Security disability advocates should not declare themselves as attorneys on Forms 2848 unless they have been admitted to a bar of any state, territory or possession of the United States (or the District of Columbia). These individuals, because they are not attorneys, cannot practice before the IRS unless they fall within one of the remaining designations.



### Note:



Although Part II of Form 2848 does not include lettered designations specifically for general partners of partnerships and international representatives, they are eligible to practice before the IRS. See IRM 1.25.1.3.2(2) and IRM 1.25.1.3.2(3)for more information.

5. A valid appointment of a taxpayer’s representative has two requirements: (1) the taxpayer’s written authorization of an individual to act as the taxpayer’s representative before the IRS with respect to specified federal tax matters, and (2) the appointed individual’s written declaration that the individual is authorized to represent the taxpayer. Form 2848 includes both requirements (Parts I and II of the form) and should normally be used. The IRS will nevertheless accept a power of attorney other than a Form 2848 if the document contains all the information needed to satisfy the requirements for a power of attorney. See Pub 216, _Conference and Practice Requirements_, section 601.503(a).

6. These alternative powers of attorney cannot, however, be recorded on the Centralized Authorization File (CAF) System unless a completed Form 2848 is attached. Taxpayers are not required to sign Form 2848 when it is attached to an alternative power of attorney that they have signed, but their representative must sign the Form 2848, Part II - Declaration of Representative for the authorization to be recorded on the CAF. See Pub. 216, section 601.503(b)(2). To be recognized as the appointing taxpayer’s representative in the CAF system, the representative must complete and sign Part II of Form 2848.

7. The CAF is a computerized system of records that maintains authorization information from both powers of attorney and tax information authorizations. See IRM 21.3.7, _Processing Third-Party Authorizations onto the Centralized Authorization File (CAF)_.

8. If a non-IRS document is used as a power of attorney, it must contain the following information:



1. Name and mailing address of the taxpayer.

2. Taxpayer identification number (i.e., social security number, individual Taxpayer identification number or employer identification number).

3. Employee plan number, if applicable.

4. Name and mailing address of the representative(s).

5. The description of the matter(s) for which representation is authorized which, if applicable, must include the type of tax involved; the federal tax form number; the specific year(s)/period(s) involved; and in estate matters, decedent's date of death.

6. The taxpayer's signature and date.



      ### Note:



      Powers of attorney executed pursuant to state law may, or may not, be sufficient for IRS purposes, depending upon whether items (a) through (f) above are included in the non-IRS document.





      ### Note:



      Even if a durable or other power of attorney executed under state law does not contain all necessary information listed above, the agent or attorney-in-fact appointed in the POA can cure the problem, if certain conditions are present, as specified in Pub. 216, section 601.503(b)(3).


9. A signed and dated statement made by the representative should be attached to the non-IRS POA (or a Form 2848 with Part II completed and signed (Part I can be blank when the non-IRS POA contains the information listed in paragraph (8)(a) – (f)). The statement must contain the same declarations contained in Part II of Form 2848. If a statement is used in lieu of Form 2848, the status of the representative will not be reflected in the CAF system.



### Note:



The issuance of a CAF number is an administrative act for internal recordkeeping and to facilitate practitioners’ representation of taxpayers and the authorized disclosure of confidential tax information to practitioners or other third-party designees. A CAF number does not itself, however, confer any rights to represent taxpayers upon an individual who is not otherwise eligible to do so.


**1.25.1.3.2** **(06-01-2010)**

#### Limited Practice Based on Relationship to the Taxpayer Under Circular 230 Section 10.7

1. Individuals may represent themselves before the IRS by presenting satisfactory identification. The individual does not need to file a written declaration of qualification and authority.

2. Because of their special relationship with a taxpayer, the following individuals can represent the specified taxpayers before the IRS, if they present satisfactory identification and a fully executed Form 2848, or valid substitute, as proof of authority to represent the taxpayer:



1. **A family member** \- An individual may represent members of their immediate family. Immediate family means a spouse, child, parent, brother, sister, grandparent, grandchild, step-parent, step-child, step-brother, or step-sister of the individual.

2. **A corporate officer** \- A bona fide officer of a corporation (including a parent, subsidiary or other affiliated corporation), or an officer of an association or organized group, may represent the corporation, association or organized group. An officer of a governmental unit, agency or authority, in the course of their official duties, may represent the entity before the IRS.

3. **A partner** \- A general partner may represent the partnership before the IRS.

4. **An employee**\- A regular full-time employee may represent their employer. An employer may be, but is not limited to, an individual, partnership, corporation (including a parent, subsidiary or other affiliated corporation), association, trust, receivership, guardianship, estate, organized group, governmental unit, agency, or authority.



      ### Note:



      An individual acting in the capacity of a fiduciary (trustee, executor, personal representative, administrator, receiver, or guardian) stands in the position of a taxpayer and acts as the taxpayer, not as a representative. Therefore, no Form 2848 is required. Fiduciaries should file Form 56, _Notice Concerning Fiduciary Relationship_.


3. An individual may represent another individual or an entity, who is outside the United States, before IRS personnel, when the representation occurs outside the United States. See Circular 230, section 10.7(c)(1)(vii) and the Instructions for Form 2848. Representation in a teleconference or videoconference with IRS personnel located in the United States does not qualify as representation outside the United States, even though the representative may be in a foreign country.



### Note:



Individuals who are suspended or disbarred from practice before the IRS may not engage in limited practice.


**1.25.1.4** **(06-01-2010)**

### Referral to the Office of Professional Responsibility

01. If practitioner misconduct is suspected, IRS personnel are required to make a referral to the OPR (see section 10.53 of Circular 230). IRS employees should use Form 8484, _Suspected Practitioner Misconduct Report for the Office of Professional Responsibility_, for this purpose (see _Exhibit 1.25.1-1_, _How to Make a Referral to the Office of Professional Responsibility_).

02. The OPR exercises oversight responsibility for practitioner conduct and maintains exclusive responsibility with respect to practitioner discipline, including disciplinary proceedings and sanctions. Through Delegation Orders and Memoranda of Understanding, the OPR also shares responsibility and assists the RPO with respect to the limited practice rights of unenrolled return preparers who participate in the AFSP.

03. The OPR may, after providing a practitioner with notice and an opportunity to respond and an opportunity for a conference, negotiate an appropriate level of discipline with the practitioner or initiate an administrative proceeding to sanction the practitioner with:



    - A censure (a public reprimand), suspension from practice (one to fifty-nine months) or disbarment (minimum five years).

    - A monetary penalty. The monetary penalty may be imposed against the individual or a firm, or both, and can be in addition to any censure, suspension or disbarment imposed on the practitioner. The monetary penalty may be up to 100% of the gross income derived or to be derived from the conduct giving rise to the penalty.


The OPR may also, after notice and an opportunity to be heard, institute a proceeding to disqualify an appraiser from presenting testimony or evidence in any proceeding before the IRS, whether or not the underlying appraisal was made before or after the disqualification. Further, any appraisal done after disqualification has no probative effect in an administrative proceeding.



04. Finally, the OPR may seek Department of Justice action to obtain an injunction when a practitioner continues to violate the regulations.

05. Examples of practitioner misconduct include:



    1. Inaccurate or unreasonable entries or omissions on tax returns, financial statements and other documents for submission to the IRS.

    2. Failing to ascertain all relevant facts and applicable law before preparing documents prior to filing, making submissions on behalf of clients or giving oral or written opinions or other advice in connection with a Federal tax matter.

    3. Reckless disregard for the law and regulations administered by the IRS when advising a client to take a position on a tax return, or giving advice when incompetent to do so.

    4. Any willful attempt to evade either the payment or the assessment of any Federal tax, or aiding/abetting another in doing so.

    5. Cashing, diverting or splitting a taxpayer’s tax refund by any means, electronic or otherwise.

    6. Patterns of behavior in violation of the regulations that govern practice involving multiple years or multiple clients or committed before multiple IRS employees.

    7. Continuing to represent a taxpayer in the context of an unresolved conflict of interest, such as representation of separated or divorcing spouses during a tax examination of a jointly filed tax return, or when representation is hampered by practitioner self-interest.


06. Potential criminal violations, such as threats against IRS personnel or willful evasion of taxes, should also be referred to the Treasury Inspector General for Tax Administration (TIGTA) or Criminal Investigation.

07. Each referral to the OPR should describe and fully document the practitioner's actions in order to provide support for the violations reasonably believed to have been committed. Employees should include a summary of the suspected misconduct that provides as much detail as practicable regarding the matter referred, supported with underlying documentation. _Exhibit 1.25.1-1_, _How to Make a Referral to the Office of Professional Responsibility_, provides instructions on how to make a referral that is “actionable," i.e., a referral that is complete and provides enough information to begin an investigation or inquiry.

08. The OPR mailing address and fax number are:



    > - Office of Professional Responsibility
    >
    >
    >        Internal Revenue Service
    >
    >
    >        SE:OPR Room 7238
    >
    >
    >        1111 Constitution Ave NW
    >
    >
    >        Washington, DC 20224
    >
    >     - EFax: 855-814-1722

09. Once a referral is made, the OPR will acknowledge the referral within 30 days and may follow up with a request for additional information, if necessary. As the case progresses, the OPR may need additional information and cooperation from the referent or other field offices or IRS business units.

10. The OPR’s processing of the referral will correspond to the seriousness of the alleged misconduct. For example, under certain circumstances, the OPR may simply contact a tax practitioner to discuss the matter informally. Such an informal contact may stop the offending behavior. In other cases, the OPR will investigate the matter further, issue a more formal communication to the practitioner, attempt to negotiate a mutually satisfactory settlement, and, when necessary, initiate an action for the practitioner’s censure or suspension/disbarment from practice before the IRS. Most cases are resolved at a point between the extremes of closure without further action and a disciplinary proceeding brought before an Administrative Law Judge. To proceed in any case, the OPR must have enough specific, detailed information to clearly frame the allegations, understand the severity of any misbehavior, prove the elements of each alleged violation, and place the conduct within the framework of Treasury Department Circular No. 230.

11. You may contact your Area Return Preparer Coordinators to assist you with the OPR referral issues since they may be aware of other issues involving the same practitioner. See Return Preparer Coordinators.

12. Announcements of censures, disbarments or suspensions from practice, and monetary penalties are published in the Internal Revenue Bulletin, as are appraiser disqualifications.

13. A practitioner who has been disbarred or suspended is not permitted to appear before any IRS employee as a representative, with or without the taxpayer present. A suspended/disbarred practitioner may attend IRS meetings with the taxpayer but is not allowed to dispute issues or otherwise advocate for the taxpayer’s position. A suspended or disbarred practitioner may prepare tax returns and may appear as a fact witness for the taxpayer under Rev. Proc. 68-29, 1968-2 CB 913 and Circular 230 section 10.8. An individual who is disbarred, suspended or disqualified from practice before the IRS is ineligible to participate in the AFSP during the period of disbarment, suspension or disqualification.


**Exhibit 1.25.1-1**

### How to Make a Referral to the Office of Professional Responsibility

(1) To make a referral to OPR, complete Form 8484, _Suspected Practitioner Misconduct Report for the Office of Professional Responsibility_. Send your referral and supporting documentation to:

- Office of Professional Responsibility


Internal Revenue Service


SE:OPR Room 7238


1111 Constitution Ave NW


Washington, DC 20224;

- EFax: 855-814-1722; or

- Email: \*OPR Referrals.


Additional information on how to make a referral can be found on the OPR’s webpage.

(2) For purposes of determining whether a practitioner before the IRS may have violated the regulations in Circular 230 or for how to describe on Form 8484 conduct believed to be in violation of Circular 230, you can review the various sections of the Circular that are listed below for information on the standards to which tax professionals are held. Use the following questions and suggestions to help guide you:

|  | **Did the Practitioner--** | **For Example--** | **Your referral _should_ include--** |
| --- | --- | --- | --- |
| 1. | Fail to exercise due diligence? | Making a factual statement in a written response to an IRS notice sent to a client without regard to whether the statement is accurate or otherwise not verifying the accuracy of submitted information. | All relevant information and explain why you believe the practitioner’s submission was below the expected standard, such as because the information in the submission was put into doubt or contradicted by other information the practitioner knew or should have known. See Circular 230 section 10.22(a). |
| 2. | Have a conflict of interest? | A practitioner is representing a business taxpayer in an examination that involves the proper tax treatment of a transaction with another company that is a former client of the practitioner. The practitioner prepared the former client’s tax returns in past tax years, including the year of the transaction. There is a likelihood that the practitioner has information from the tax return preparation that would benefit the current client in the examination. The practitioner, however, owes a duty of confidentiality to the former client. As a result, a conflict of interest is present, under section 10.29(a)(2), because there is a significant risk that the practitioner’s representation of the current client will be materially limited by the practitioner’s responsibilities to the former client.**Exception**(consult with the OPR as to whether it applies) -Representation is not prohibited, notwithstanding a conflict, if: (1) the representation is not prohibited by other law; (2) the practitioner reasonably believes that each affected client can be diligently and competently represented (the current client in the example); and (3) each affected client (both in the example) waives the conflict and gives informed consent, confirmed in writing. See section 10.29(b). | A detailed description of the conflict of interest and information as to whether (and when) IRS personnel informed the practitioner of the apparent conflict, what steps were taken by the practitioner to address the conflict, and whether the practitioner resolved (or failed to resolve) the conflict. Include information about resolution or purported resolution of the conflict; the practitioner may have provided written assurance that the affected clients executed waivers/consents or provided copies, and claimed the other elements of the exception were satisfied. If the practitioner’s response was not credible, explain why. |
| 3. | Divert payments intended for the IRS or a refund due the taxpayer? This must also be reported to TIGTA. | Tax refund electronically split deposited into taxpayer account and practitioner account. Tax refund deposited into a practitioner’s “trust account.” Client funds delivered to a practitioner to pay to the IRS as part of an installment agreement were, instead, converted to the practitioner’s own use. | Documentation to support diversion of funds, such as cancelled checks and tax account transcripts. See Circular 230 section 10.31. |
| 4. | Fail to comply with standards for tax returns or other submissions to the IRS? | Preparing or signing a tax return that contains a position, or advising a taxpayer to take a position on a return, that lacks a reasonable basis or is an unreasonable position (as described in IRC 6694(a)(2)), or reflects an understatement of tax or disregard of rules and regulations (as described in IRC 6694(b)(2)). Advising a client to take a position in any other document submitted to the IRS that is a frivolous position, is one intended to delay or impede tax administration, or is an intentional disregard of a rule or regulation (and not a good-faith challenge to the rule or regulation). | All information relevant to the preparation or submission of, or the position claimed on, the tax return, including the status of any IRC 6694(a) or (b) penalty (asserted or assessed). The referral should also include a copy of the return or other submission containing the position at issue. See Circular 230 section 10.34. |
| 5. | Lack the basic competence necessary to practice before the IRS? | The practitioner’s representation of a taxpayer was adversely affected by the practitioner’s deficient knowledge or skill level, or as a result of inadequate preparation. | Information explaining how and in what manner the practitioner did not have the competence necessary to handle the client’s tax matter(s) before the IRS. See Circular 230 section 10.35. |
| 6. | Give written tax advice that was materially incomplete or involved unreasonable assumptions or reliance on unrealistic representations of the taxpayer or a third party? | A practitioner violates the requirements that pertain to written advice on a federal tax matter if the advice:<br> <br>- Was based on unreasonable factual or legal assumptions;<br>  <br>- Omitted relevant facts that the drafter knew or reasonably should have known;<br>  <br>- Neglected to relate applicable law to facts;<br>  <br>- Relied upon representations or other information from a client or another person when it was unreasonable to rely on their statements; or<br>  <br>- Accounted for the chance that a tax return will not be audited, or an issue will not be raised on audit.<br>  <br> When rendering written advice, a practitioner may rely upon the advice of another professional (such as an appraiser), as long as the reliance is reasonable and in good faith. | The written advice that is the subject of the referral and information explaining why the advice is contrary to the applicable standards. See Circular 230 section 10.37. |
| 7. | Demonstrate incompetence and disreputable conduct? | Giving knowingly false or misleading information or participate in any way in the giving of false or misleading information in connection with any matter pending or likely to be pending before the IRS. Encouraging clients to violate the tax laws, such as marketing an abusive tax avoidance scheme. | False information can be contained on tax returns, in financial statements, affidavits, declarations, summoned testimony, or any other document or written or oral statement. Similarly, encouraging or assisting a client to violate the tax laws, including suggesting a plan or transaction to evade tax, can occur in numerous varied scenarios. See Circular 230 section 10.51(a)(4) and (7).<br> The information that should accompany the referral will depend on the situation. In general, provide information pointing out where or how there was a clear misstatement of fact or law made to IRS personnel. Demonstrate why statements are false. In the case of promotional materials, identify the legal claim(s) the practitioner put forth that are patently false. |
| 8. | Did the practitioner fail to file a Federal tax return or evade the payment or assessment of any Federal tax or assist clients in doing so, which is another, separate type of disreputable conduct? | Omitting income from the practitioner’s own or a client’s Federal income tax return. Appearing to disguise unallowable deductions by using inappropriate forms and characterizations. | All related information for the subject tax accounts, highlighting the relevant portions (such as items of income omitted, unallowable deductions or credits, penalties imposed, and ultimate outcome). See Circular 230 section 10.51(a)(6)&(7).<br> Also, consider notifying Criminal Investigation (contact your area Fraud Referral Specialist to assist you in evaluating and developing your case). |
| 9. | Did the practitioner engage in contemptuous conduct? | Willful use of abusive language or other inappropriate conduct, such as demeaning or sexually suggestive gestures or actions. Making false accusations and statements knowing them to be false. Circulating or publishing malicious or libelous matter about an IRS employee.<br> Ordinarily, this conduct will require a pattern before being actionable by the OPR. | All information surrounding the instances of contemptuous conduct and a complete narrative account of the conduct. Actual language used, copies of any correspondence employed to falsely accuse an employee of misconduct and a thorough recitation of the facts leading up to the situation(s) of the contemptuous behavior. (It is important that the practitioner’s exact language be reported, if possible.) See Circular 230 section 10.51(a)(12). |
| 10. | Directly or indirectly attempt to influence the official action of any officer or employee of the IRS? | Use of threats, false accusations, duress, or coercion. Offers of a gift, favor or thing of value to influence the outcome of a case. | First, report these cases to TIGTA. Among its investigative activities, TIGTA investigates “external attempts to corrupt or threaten IRS employees.” See [https://www.tigta.gov/about-tigta](https://www.tigta.gov/about-tigta).<br> Once the TIGTA investigation is completed, TIGTA should make a referral to the OPR. You can assist both offices by ensuring your referral includes: a complete narrative account of the improper or wrongful conduct, and all documentary information directly related to the conduct. A report of the practitioner’s exact language should be provided, when possible. See Circular 230 section 10.51(a)(9). |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-025-001#addtoany "Show all")

A2A