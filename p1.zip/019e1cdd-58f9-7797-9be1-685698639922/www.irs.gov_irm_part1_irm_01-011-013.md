---
url: "https://www.irs.gov/irm/part1/irm_01-011-013"
title: "1.11.13 Taxpayer Advocate Service Internal Management Document and Single Point of Contact (TAS IMD/SPOC) Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-011-013#main-content)

- 1.11.13  [Taxpayer Advocate Service Internal Management Document and Single Point of Contact (TAS IMD/SPOC) Program](https://www.irs.gov/irm/part1/irm_01-011-013#id1)
  - 1.11.13.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-011-013#id2)
    - 1.11.13.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-011-013#id4)
    - 1.11.13.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-011-013#id5)
    - 1.11.13.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-011-013#id6)
    - 1.11.13.1.4  [Terms](https://www.irs.gov/irm/part1/irm_01-011-013#id7)
    - 1.11.13.1.5  [Acronyms](https://www.irs.gov/irm/part1/irm_01-011-013#id8)
  - 1.11.13.2  [TAS IMD Guidelines and Applicable Law](https://www.irs.gov/irm/part1/irm_01-011-013#id9)
    - 1.11.13.2.1  [TAS IMDs](https://www.irs.gov/irm/part1/irm_01-011-013#id10)
      - 1.11.13.2.1.1  [TAS Internal Revenue Manual](https://www.irs.gov/irm/part1/irm_01-011-013#id11)
        - 1.11.13.2.1.1.1  [Authoring, Clearing, and Publishing an IRM](https://www.irs.gov/irm/part1/irm_01-011-013#id13)
      - 1.11.13.2.1.2  [Delegation Orders](https://www.irs.gov/irm/part1/irm_01-011-013#id14)
      - 1.11.13.2.1.3  [Policy Statements](https://www.irs.gov/irm/part1/irm_01-011-013#id15)
      - 1.11.13.2.1.4  [Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-013#id16)
        - 1.11.13.2.1.4.1  [Interim Guidance Creation](https://www.irs.gov/irm/part1/irm_01-011-013#id18)
        - 1.11.13.2.1.4.2  [Reissuance of an Interim Guidance (IGM)](https://www.irs.gov/irm/part1/irm_01-011-013#id19)
      - 1.11.13.2.1.5  [SERP IRM Procedural Update](https://www.irs.gov/irm/part1/irm_01-011-013#id20)
    - 1.11.13.2.2  [Record Documentation and Retention](https://www.irs.gov/irm/part1/irm_01-011-013#id21)
    - 1.11.13.2.3  [E-FOIA Law and Compliance](https://www.irs.gov/irm/part1/irm_01-011-013#id22)
  - 1.11.13.3  [TAS Interim Guidance Internal Clearance Process](https://www.irs.gov/irm/part1/irm_01-011-013#id23)
    - 1.11.13.3.1  [TAS External Clearance Process](https://www.irs.gov/irm/part1/irm_01-011-013#id25)
  - 1.11.13.4  [Pre-Publishing Process](https://www.irs.gov/irm/part1/irm_01-011-013#id26)
  - 1.11.13.5  [TAS IMD Publishing & Distribution](https://www.irs.gov/irm/part1/irm_01-011-013#id27)
    - 1.11.13.5.1  [TAS Interim Guidance Distribution](https://www.irs.gov/irm/part1/irm_01-011-013#id29)
  - 1.11.13.6  [Monitoring](https://www.irs.gov/irm/part1/irm_01-011-013#id30)
  - 1.11.13.7  [When and How to Archive TAS Interim Guidance](https://www.irs.gov/irm/part1/irm_01-011-013#id31)
  - 1.11.13.8  [Reviewing Internal Management Documents (IMDs) For Systemic Issues](https://www.irs.gov/irm/part1/irm_01-011-013#id32)
    - 1.11.13.8.1  [Receipt of IMD Review](https://www.irs.gov/irm/part1/irm_01-011-013#id33)
    - 1.11.13.8.2  [Abbreviated/Comprehensive IMD Review](https://www.irs.gov/irm/part1/irm_01-011-013#id34)
    - 1.11.13.8.3  [Assigning an IMD](https://www.irs.gov/irm/part1/irm_01-011-013#id35)
    - 1.11.13.8.4  [Comprehensive Review Determination](https://www.irs.gov/irm/part1/irm_01-011-013#id36)
    - 1.11.13.8.5  [Working the IMD/SPOC Review](https://www.irs.gov/irm/part1/irm_01-011-013#id37)
      - 1.11.13.8.5.1  [Response from Operating Division](https://www.irs.gov/irm/part1/irm_01-011-013#id39)
      - 1.11.13.8.5.2  [TAS Subject Matter Expert Rebuttal](https://www.irs.gov/irm/part1/irm_01-011-013#id40)
    - 1.11.13.8.6  [Completing the IMD Review](https://www.irs.gov/irm/part1/irm_01-011-013#id41)
    - 1.11.13.8.7  [Finalizing, Elevating, and Evaluating the IMD Review](https://www.irs.gov/irm/part1/irm_01-011-013#id42)
  - 1.11.13.9  [Single Point of Contact Process](https://www.irs.gov/irm/part1/irm_01-011-013#id43)
  - 1.11.13.10  [Methods of Submitting Changes to IRMs, Forms, Publications, Notices, Letters and Systems](https://www.irs.gov/irm/part1/irm_01-011-013#id44)
  - 1.11.13.11  [Service Level Agreements (SLA)](https://www.irs.gov/irm/part1/irm_01-011-013#id45)
  - Exhibit  1.11.13-1  [TAS Interim Guidance Memoranda Process](https://www.irs.gov/irm/part1/irm_01-011-013#id46)
  - Exhibit  1.11.13-2  [TAS IRMs Listing](https://www.irs.gov/irm/part1/irm_01-011-013#id47)

# Part 1. Organization, Finance, and Management

# Chapter 11. Internal Management Documents System

# Section 13. Taxpayer Advocate Service Internal Management Document and Single Point of Contact (TAS IMD/SPOC) Program

* * *

## 1.11.13 Taxpayer Advocate Service Internal Management Document and Single Point of Contact (TAS IMD/SPOC) Program

#### Manual Transmittal

August 22, 2025

#### Purpose

(1) This transmits the revised IRM 1.11.13, Taxpayer Advocate Service Internal Management Document and Single Point of Contact (TAS IMD/SPOC) Program.

#### Material Changes

(1) IRM 1.11.13.1.1 Updated to comply with the January 2025 Executive Orders and OPM guidance.

(2) IRM 1.11.13.1.4 Added new terms to the table.

(3) IRM 1.11.13.1.5 Removed terms that are no longer used from the table.

(4) Exhibit 1.11.13-2 Updated table to include new IRMs and titles.

(5) IRM 1.11.13.2.1.1.1, Updated content and added table to reflect IMD/SPOC current procedures for clearing/approving TAS IRMs within TAS and by other BODs. IPU 23U1163 issued 12-11-2023.

(6) IRM 1.11.13.5, Updated the language to reflect the IMD responsibilities. IPU 23U1163 issued 12-11-2023.

(7) Replaced throughout the IRM SharePoint and IMD Center references with IMD Application to reflect IMD/SPOC current process. IPU 23U1163 issued 12-11-2023

(8) Updated links throughout the IRM. IPU 23U1163 issued 12-11-2023

(9) Editorial changes made throughout the IRM

#### Effect on Other Documents

IRM 1.11.13 dated August 1, 2022, is superseded. This IRM incorporates IPU 23U1163, issued on December 11, 2023.

#### Audience

The TAS IMD/SPOC community: IMD/SPOC authors, IMD/SPOC reviewers, their manager, and those responsible for the clearance, review and approval of IMD material.

#### Effective Date

(08-22-2025)

Andrew Beckwith

Acting Executive Director Systemic Advocacy

**1.11.13.1** **(08-01-2022)**

### Program Scope and Objectives

1. **Purpose.** IRM 1.11 series provides guidance for the IMD process to manage, author, clear, and publish IRMs and interim guidance (IG).



1. This IRM section describes the Taxpayer Advocate Service Internal Management Document (TAS IMD) clearance process and supplements the guidance contained in:


   - IRM 1.11.1, IMD Program and Responsibilities;

   - IRM 1.11.2, Internal Revenue Manual (IRM) Process;

   - IRM 1.11.3, Servicewide Policy Statement Process;

   - IRM 1.11.4, Servicewide Delegation Order Process;

   - IRM 1.11.5, Publishing the Internal Revenue Manual (IRM);

   - IRM 1.11.6, Using and Researching the Internal Revenue Manual (IRM);

   - IRM 1.11.8, Servicewide Electronic Research Program (SERP),

   - IRM 1.11.9, Clearing and Approving IMDs;

   - IRM 1.11.10, Interim Guidance Process;

   - IRM 13.2.1, Systemic Advocacy Overview; and

   - IRM 13.2.2, Phoenix Administration.


1. This IRM section includes specific procedures and processes for Taxpayer Advocate Service (TAS) employees in creating TAS IMDs.

2. This IRM provides TAS procedures for review of IMDs generating from internal operations and functions outside of TAS.


2. **Audience.** This IRM section is for program directors, managers, analysts, and other employees who are responsible for issuing, authoring, reviewing, approving, and managing TAS IMDs, which includes authors of TAS IRMs, reviewers of TAS IRMs, TAS IMD/IRM coordinators, and managers with TAS IMD program responsibilities.

3. **Policy Owner.** TAS Internal Management Document and Single Point of Contact (TAS IMD/SPOC).

4. **Program Owner.** TAS IMD/SPOC is the program office responsible for overseeing the TAS IMD program and providing policy and guidance including the TAS IMD clearance process to TAS staff involved in the clearance process.

5. **Contact Information.** Contact TAS IMD/SPOC, via email at \*TAS IMD SPOC.


**1.11.13.1.1** **(08-22-2025)**

#### Background

1. In TAS, the IMD and SPOC are two individual programs managed by separate Systemic Advocacy analysts. The National Taxpayer Advocate's 2007 Objectives Report to Congress explained these programs as follows:



> The Commissioner of the Internal Revenue Service must provide subordinates certain authorities to act on his behalf. This is accomplished through the issuance of IMDs, which are also referred to as directives, internal directives and/or instructions to staff, and include the IRM, Policy Statements (PS), Delegation Orders (DOs), and IMDs. IRMs require TAS clearance when the rights or duties of taxpayers are impacted, or taxpayers are affected in some way. Additionally, the Tax Administration Council approved the creation of a SPOC in each of the Operating Divisions (OD) and TAS. The SPOC is responsible for managing customer communications (e.g., notices, letters, and inserts/stuffers).
>
> ### Note:
>
> TAS continues to maintain a SPOC program, while Taxpayer Correspondence Services (TCS) was created to manage and oversee taxpayer correspondence products, both electronic and paper. The Office of Tax Form and Publication (TF&P) was also created to manage and oversee forms and publications Servicewide.

2. The **Executive Director Systemic Advocacy (EDSA)**, who reports directly to the National Taxpayer Advocate (NTA), is the responsible program owner of the TAS IMD/SPOC Programs. This is due to the emphasis TAS places on the review of external IMD products for systemic issues impacting [taxpayer rights or taxpayer burden](https://www.irs.gov/taxpayer-bill-of-rights). The TAS IMD analyst (also referred to as **TAS IMD coordinator**) and the TAS SPOC analyst (also referred to as **TAS SPOC coordinator**) and the support staff report to the **TAS IMD/SPOC Chief** who reports to the **Director of Advocacy Implementation & Evaluation (DAIE)** under the **Deputy Executive Director Systemic Advocacy (DEDSA)** of Proactive Advocacy who reports to the _EDSA_.

3. The TAS IMD/SPOC staff provides coordination and guidance to TAS IRM authors, reviewers, responsible managers, and directors regarding both the IMD and the SPOC process. TAS IMD/SPOC also assist all TAS business units, including Executive Director of Case Advocacy (EDCA), EDCA Intake and Technical Support (EDCA-ITS), EDSA, Communications, Stakeholder Liaison & Online Services (CSO), Low Income Taxpayer Clinic Program, Taxpayer Advocacy Panel, Business Modernization, Attorney Advisors, , Research and Analysis, and Financial Operations with their TAS IMD/SPOC needs.

4. The TAS IMD coordinator and TAS SPOC coordinator provides oversight to the TAS IMD program and is a member of the IMD Oversight Council. The TAS IMD coordinator also coordinates with Servicewide Policy, Directives, and Electronic Research (SPDER). For more information regarding the TAS IMD coordinator see _IRM 1.11.13.1.2, Authority_.


**1.11.13.1.2** **(08-01-2022)**

#### Authority

1. By law, federal agencies document, publish, and maintain records of policies, authorities, procedures, and organizational operations. The IRM is the source of IRS operational guidance and information. See IRM 1.11.1.1.2, Authority, for the authorities and legal obligations of IMDs.

2. Clearance documents are official records and there is a requirement to maintain them in the IRS Historical Research Library. Clearance documents are subject to federal records management requirements and National Archives and Records Administration (NARA) as provided in the IRS Records Control Schedules. See IRM 1.11.1.1.2(2), Table for legal references.


**1.11.13.1.3** **(08-01-2022)**

#### Roles and Responsibilities

1. The TAS IMD/SPOC Chief oversee the daily operations of the program. The TAS IMD/SPOC Chief is responsible for establishing the program policy, process, and procedures. Other responsibilities consist of:



   - Reviewing IRM content annually for accuracy and completeness;

   - Analyzing issues that may provoke a change to the IRM, such as new or revised legislation, court opinions, issuance of regulations, changes in procedure that results from other factors (organizational, operational, technology, etc.);

   - Determining and prioritizing changes to the IRM;

   - Approving the issuance of instructions to staff, such as in IRMs, IG, and local procedures;

   - Participating in decisions related to publishing IMD materials;

   - Ensuring IRM authors and/or coordinators have proper training;

   - Ensuring internal control information is included in each IRM section;

   - Devoting adequate resources to support the IMD program;

   - Developing, as needed, internal procedures on managing instructions and communicating them to staff; and

   - Evaluating employees with collateral duties in support of the IMD program, including IRM authors, IMD/IRM coordinators, IG coordinators and other management officials, on their performance of these duties.


2. The TAS IMD coordinator is responsible for directing and controlling the internal clearance of all TAS IMDs ensuring all internal clearance levels have been completed (e.g., IRM updates, IG, etc.). The TAS SPOC coordinator has the responsibility for managing and coordinating TAS reviews of SPOC products that impact taxpayer rights or taxpayer burdens, whether the products originated from within TAS or from other IRS operational or functional units. As such, TAS SA is responsible for representing the NTA in reviewing changes being made to IRS policies, authorities, and procedures.

3. The responsibilities of the TAS IMD/SPOC staff include, but are not limited to:



   - Performing abbreviated reviews;

   - Making comprehensive determination for IMD/SPOC products;

   - Monitoring the progress of reviews to ensure reviews are done properly;

   - Ensuring high profile reviews are properly elevated, when appropriate;

   - Facilitating negotiations with the OD for acceptance of TAS recommendations;

   - Monitors and assists in the clearance process of products originated within TAS;

   - Maintaining a record of all IMD review recommendations;

   - Assist with monitoring implementation of recommendations accepted by the IRS;

   - Completing tasks by the established deadlines, including extensions;

   - Communicating with reviewers, and the OD or function on progress of the work and issues that arise;

   - Manage and controls TAS internal/external products; and

   - Coordinate daily activities with staff.


**1.11.13.1.4** **(08-22-2025)**

#### Terms

1. The table below contains definitions of terms used in this IRM section.



|     |     |
| --- | --- |
| **Term** | **Definition** |
| Clearance | Review and approval of an IMD prior to issuance. |
| Clearance Process | An established, formal process that provides affected organizations and program offices the opportunity to review and comment on changes to information in the IMD to ensure it is complete, accurate, and does not conflict with another policy, procedure, or process. The clearance process also documents the approval of IRS procedural changes by the program owner and responsible program director. |
| IMD Electronic Clearance | A website that automates and centralizes the complete IRM process, also known as “e-Clearance”. It documents the review, comment and approval of the IRM. This is the required method of IRM clearance. |
| Editorial Change | A non-substantive revision to correct minor errors and typographical changes. See IRM 1.11.2.8, Editorial Update Process. |
| External Reviewer | Affected organizations/program offices outside of the originating organization. |
| Internal Management Document (IMD) | Official communication which designates policies, authorities, and instructions to IRS officials and employees. IMDs include the IRM, IG, policy statements and delegation orders. |
| Internal Reviewer | Affected organizations/program offices within the originating organization. |
| Originating Organization | Also known as a business unit (BU), who owns the respective IRM section. |
| Phoenix | System used to receive, control, document, and monitor systemic issues and advocacy projects. |
| Program Director | Member of the Senior Executive Service (SES) responsible for program administration including issuance and approval of IMDs. To identify a member of the SES, see IRM 1.11.9.10.1 (1), Approval by Program Director. |
| Program Owner | The office which has responsibility for establishing the policy, process, and procedures necessary to implement and manage an IRS program. The program owner owns all IRMs for the program. |
| Reviewer | A subject matter (SME) expert responsible for reviewing an IMD on behalf of their program office, area or organization. |
| Specialized Reviewer | Specific and identified program offices (identified in IRM 1.11.9.4, Specialized Reviewers) with oversight in a particular area affecting Servicewide IRS operations. |
| Substantive Change | A revision is substantive if the change involves a procedural or operational matter. |
| TAS Single Point of Contact (SPOC) | A designated contact within TAS responsible for managing, coordinating and/or forwarding IMDs received for review and clearance for assignment to reviewers in affected office. |


**1.11.13.1.5** **(08-01-2022)**

#### Acronyms

1. The table below contains a list of acronyms within the IRM section 1.11.13.



|     |     |
| --- | --- |
| **Acronym** | **Definition** |
| BU | Business Unit |
| CSO | Communications, Stakeholder Liaison & Online Services |
| DCR | Document Clearance Record |
| EDCA | Executive Director Case Advocacy |
| EDCA-ITS | Executive Director Case Advocacy, Intake and Technical Support |
| EDSA | Executive Director Systemic Advocacy |
| ERR | Electronic Reading Room |
| FOIA | Freedom of Information Act |
| IG | Interim Guidance (either an interim guidance memorandum or SERP IRM Procedural Update) |
| IGM | Interim Guidance Memorandum |
| IMD | Internal Management Document |
| IPU | IRM Procedural Update |
| IRM | Internal Revenue Manual |
| LR | Labor Relations |
| M&P | Media and Publications |
| MT | Manual Transmittal |
| NARA | National Archives and Records Administration |
| NTA | National Taxpayer Advocate |
| OD | Operating Division |
| OUO | Official Use Only |
|  |  |
| PII | Personally Identifiable Information |
| QRIS | Question Resolution Information System |
|  |  |
| SBU | Sensitive But Unclassified |
| SERP | Servicewide Electronic Research Program |
| SES | Senior Executive Service |
| SME | Subject Matter Expert |
| SPDER | Servicewide Policy, Directives and Electronic Resources |
| SPOC | Single Point of Contact |
| TAS | Taxpayer Advocate Service |
| TCS | Taxpayer Correspondence Services |
| TF&P | Office of Tax Forms and Publications |
| WR | Workforce Relations |
| XML | Extensible Markup Language |


**1.11.13.2** **(08-01-2022)**

### TAS IMD Guidelines and Applicable Law

1. This section covers IMD guidelines and applicable law regarding:



   - Types of TAS IMDs

   - Record Documentation and Retention

   - Electronic Freedom of Information Act (E-FOIA)

   - TAS IMD Clearance Process


**1.11.13.2.1** **(08-01-2022)**

#### TAS IMDs

1. This subsection provides guidance on the following types of TAS IMDs:



   - Internal Revenue Manual (IRM)

   - Delegation Orders (DO)

   - Policy Statements (PS)

   - Interim Guidance (IG)


### Note:

For general information on IRMs, see IRM 1.11.2, IRM Process.

2. TAS authors should coordinate with the TAS IMD coordinator if clarification is needed to determine the appropriate type of IMD for their guidance.



### Caution:



IMDs are the official communications that constitute "instructions to staff." Communications in the form of "Question Resolution Information System" (QRIS) are not IMDs, as they do not constitute official guidance or address issues that are not already addressed in the IRM. Thus, if a TAS employee submits a question through QRIS on a topic not already addressed in the IRM, a QRIS response is not appropriate. The TAS employee question should be addressed by issuing an (Interim Guidance Memorandum (IGM) if new procedures are determined. See _IRM 1.11.13.2.1.4_, Interim Guidance and QRIS.


**1.11.13.2.1.1** **(08-01-2022)**

##### TAS Internal Revenue Manual

1. TAS is responsible for writing and maintaining IRMs pertaining to TAS policies and procedures. This includes all Part 13 IRMs and some in Part 1 IRMs. A current version of the list of TAS IRMs is shown at _Exhibit 1.11.13-2_, TAS IRM Listing.

2. Within TAS, the TAS IMD coordinator provides oversight for the IRM process for all TAS business units and acts as the TAS Liaison to Servicewide Policy, Directives and Electronic Resources (SPDER) and other ODs and functions during the creation, revision, or obsolescence of a TAS IRM. They also maintain a detailed record of the TAS IRMs, including last published date, currency certification, business unit owner, author, manager, upcoming revision comments, and production status of each IRM.

3. Additionally, the TAS IMD coordinator coordinates IRM authoring training. This training includes:



   - Classroom training, Authoring the IRM with Arbortext Editor, course number 15770-002. Arbortext Editor is the publishing software used in creating the IRM; and

   - ITM classes in authoring skills provided in a conference or virtual setting sponsored by SPDER.


4. Management is responsible for ensuring that all IRM sections under their purview are reviewed annually, or more frequently for organizational or process changes that impact the accuracy of the IRM. Authors should issue either an IGM or IRM Procedural Update (IPU) if an immediate change to guidance is needed prior to the next revision of the IRM. For more information see IRM 1.11.10, Interim Guidance Process.

5. IRMs posted on the Servicewide Electronic Research Program (SERP) website must follow an annual content certification process to ensure content is accurate or risk removal from the website. For additional information on SERP requirements, see IRM 1.11.8, Servicewide Electronic Research Program (SERP).


**1.11.13.2.1.1.1** **(08-22-2025)**

###### Authoring, Clearing, and Publishing an IRM

01. TAS IRMs must be written in plain language per [Plain Writing Act of 2010](https://www.irs.gov/irm/part1/www.plainlanguage.gov/law/) and accurately portray the current operating procedures of the TAS business units. Timely incorporation of IG into the IRM is necessary for transparency to IRM users. IRS employees, practitioners, and taxpayers are users that depend on a current IRM to fully comply with IRS procedures.

02. Follow IRM 1.11.2 , Internal Revenue Manual (IRM) Process, when creating an IRM. When developing an IRM, the author must first obtain a catalog number and receive initial guidance from the TAS IMD coordinator. SPDER controls the catalog number and the title. To request a change to an IRM title or new IRM catalog number, the author must first contact the TAS IMD coordinator who will coordinate the request with SPDER.

03. When the author completes the draft of the new or revised IRM, the author may contact the TAS IMD coordinator for guidance on the clearance process or for an initial review of the IRM in the Extensible Markup Language (XML) format.

04. The TAS IMD coordinator will assist the author and their manager to identify the affected BODs, TAS Headquarters Directors and Guidance Advisory Board (GAB) teams who will review for the TAS IRM.

05. The TAS IMD coordinator is responsible for both the internal and external clearance review process. The steps for the pre-clearance and clearance process vary when TAS Program offices or other BODs are affected by the changes in the IRM:




    | Step | If only TAS Program Offices are affected by the changes in the IRM, then the author and IMD staff will complete the following reviews: | If another BOD is affected by the changes in the IRM, the author and IMD staff will complete the following reviews: |
    | --- | --- | --- |
    | Pre-Clearance | 1. Review 1 - Management TAS Program Offices<br>       <br>    2. Review 2 - GAB, if applicable<br>       <br>    3. Review 3 - CSO and Labor Relations (LR)<br>       <br>    4. Review 4 - Division Counsel/ Associate Chief Counsel (National Taxpayer Advocate Program) | 1. Review 1 - Management TAS Program Offices<br>       <br>    2. Review 2 - GAB, if applicable<br>       <br>    3. Review 3 - CSO and Labor Relations (LR)<br>       <br>    4. Review 4 - Division Counsel/ Associate Chief Counsel (National Taxpayer Advocate Program) |
    | Clearance | The TAS IMD coordinator will send the **official** clearance request to the TAS Management Officials (or their representative) identified in Review 1 using SPDER’s e-Clearance. | The TAS IMD coordinator will send the **official**clearance request to the external BOD(s) affected by the IRM changes and the TAS Management Officials (or their representative) identified in Review 1 using SPDER’s e-Clearance. |
    | Approval (Final Package) | E-Clearance will notify the Program Owner and Executive Director when the IRM is ready for their review of the IRM and provide feedback. Author will update the files with the Directors feedback. Once the Executive Director’s requested edits are fulfilled, the Executive Director approves the IRM within e-Clearance. | E-Clearance will notify the Program Owner and Program Director when the IRM is ready for their review of the IRM and provide feedback. Author will update the files with the Directors feedback. Once the Director’s requested edits are fulfilled, the Director approves the IRM within e-Clearance. |





    ### Note:






    If the IRM will not go out for formal clearance, advise the Division Counsel/Associate Chief Counsel of this and request that any coordination with other Counsel offices occur now during the informal clearance process.


    All clearance assessments must be received within the standard clearance timeframe. See IRM 1.11.9.5.4, Standard Clearance Time Frame. If a reviewer does not agree with the IRM changes, they must provide their assessment and the TAS IMD coordinator will coordinate a meeting with the reviewer and author to reach an agreement, before proceeding to the approval phase.





    - Once the reviews are complete, IMD/SPOC will compile and forward all comments received from the internal reviewers to the author for consideration or notify the author in the event the reviewer(s) do not have a response or have waived their review.

    - IMD/SPOC will verify all responses have been addressed at each step in the TAS IRM clearance review process, see _IRM 1.11.13.5_, TAS IMD Publishing & Distribution.

    - IMD/SPOC will coordinate with the author for the submission of the final approval package for the Program Owner and Program Director approval.



      ### Note:



      The Program Owner can only approve IRMs that only pertain to editorial updates. See IRM 1.11.2.8, Editorial Update Process.


06. If external clearance is necessary, the TAS IMD coordinator and author will work together using e-Clearance to submit the IRM for formal clearance.

07. If the package is not able to be forwarded through e-Clearance, the author sends the final XML version of the IRM, responses to the reviewer comments, Form(s) 2061, Form 1767, Publishing Services Requisition, and any other pertinent background information to the TAS .



    1. Once the package is received, the IMD coordinator will:


    - Verify the IRM was cleared through all internal reviewers

    - Review the Form(s) 2061 to ensure they contain the appropriate signatures and concurrence

    - Review for accuracy the Form 1767, Publishing Services Requisition.

    - Ensure the author addressed all reviewer comments.

    - Coordinate with the author and Program Owner for submission of IRM for final approval by the Program Director.



      ### Note:



      The Program Owner can only approve editorial updates to IRMs. See IRM 1.11.2.8, Editorial Update Process.


08. The TAS IMD coordinator reviews the XML file for structural accuracy and compliance with Section 508 of the Rehabilitation Act (29 U.S.C. 794d) as amended by the Workforce Investment Act of 1998 (P.L. 105-220), August 7, 1998. Form 1767 is also reviewed for accuracy. If there are errors, the TAS IMD coordinator returns the files to the author for correction.

09. The TAS IMD coordinator uploads the files to the Media and Publications (M&P) publishing site. The M&P staff processes and updates the IRM in the repository, and IRM Online website.



    ### Note:



    M&P will send the file to SERP to post the IRM to their website.

10. Once the IRM is published the author must submit all completed Form(s) 2061 and related review comments to the TAS IMD coordinator for submission to the IRS Historical Library. See IRM 1.11.9.10.3, Archiving Clearance Documents.


**1.11.13.2.1.2** **(08-01-2022)**

##### Delegation Orders

1. TAS Delegation Orders (DOs) are created, revised or obsoleted by EDCA-ITS and coordinated through the TAS IMD coordinator. These are considered Division DOs and are usually derived from the Commissioner or their delegates. For more information on this process, see IRM 1.11.4, Servicewide Delegation Order Process. Key points are as follows:



   - A TAS DO must be created when litigation over the activity can reasonably be expected. See IRM 1.11.4.5, Purpose and Contents of Delegation Orders.

   - When authority is placed at the lowest level, all intervening grades of the position and series up to and including the senior level position have the same authority. See IRM 1.11.4.4, Types of Delegations of Authority.


2. DOs issued by the Commissioner that are specific to TAS are contained in IRM 1.2.2.12, Delegations of Authority for Taxpayer Advocate Service Activities.

3. EDCA-ITS is responsible for the content and accuracy of TAS DO.


**1.11.13.2.1.3** **(08-01-2022)**

##### Policy Statements

1. IRM 1.11.3, Servicewide Policy Statement Process, defines the policies of the IRS. It contains instructions on preparing, clearing, and publishing Policy Statements (PS) within the framework of the IRM process.



### Note:



EDCA-ITS is responsible for the content and accuracy of TAS PSs.


**1.11.13.2.1.4** **(08-01-2022)**

##### Interim Guidance

1. An IGM and/or SERP IPU is used when it is critical to quickly communicate changes to TAS procedures. This includes communicating a change to procedures already in the IRM, or new procedures that TAS will later incorporate into the IRM, or providing a temporary procedure required to support a one-time modification or occurrence in a program or process. See IRM 1.11.10.5, Interim Guidance (IG) Memoranda.

2. Informal communication vehicles such as TAS Welcome Screen/Message Center, SERP Alerts, or training materials may be used to publicize the official guidance provided in the IGM and/or SERP IPU.



### Caution:



A SERP Alert, TAS Welcome Screen/Message Center or QRIS response can not be used for distributing new procedures not published in an IRM or IGM.

3. The TAS IMD coordinator will assist the author in identifying IGMs and/or IPUs that are required to be made public. See Search Interim Guidance website for current interim guidance available to the public and the EFOIA Decision Tool.

4. Guidance contained in an IGM and/or IPU is valid until the lesser of:



   - **Two years** from the date of issuance ( _e.g_., an IGM signed January 1, 2022 automatically expires on January 1, 2024), or

   - The expiration date stated on the IGM.


5. The information is generally incorporated into the IRM by the **lesser of** the expiration date or **two years** from the memo issuance. Otherwise the information is no longer valid and the memo will expire. It is imperative that the author take the necessary steps to incorporate procedures **immediately** into the IRM.



### Note:



IG may be reissued in limited circumstances when the related IRM cannot be updated within the effective period. See _IRM 1.11.13.2.1.4.2_ for reissuance instructions.

6. The author of the impacted IRM is responsible for drafting, clearing, issuing, superseding or reissuing, obsoleting and incorporating IGMs into the related IRMs.

7. If the IGM/IPU author is not the IRM author, then the IGM/IPU author should seek consent from the applicable IRM/IPU author. The author of the impacted IRM must incorporate the approved IGM/IPU procedures into the affected IRM/IPU within **two years** of issuance unless the guidance is temporary.


**1.11.13.2.1.4.1** **(08-01-2022)**

###### Interim Guidance Creation

1. Authors are required to use TAS letterhead with the Office of the Taxpayer Advocate at the top and incorporate the information found on the IGM template into the TAS letterhead. Always check for the most recent version of the _IGM template_ to ensure the IGM is formatted correctly.

2. The author will determine if the E-FOIA applies. See the E-FOIA Decision Tool, on the SPDER website.

3. The author of the IGM prepares the memo ensuring that all the required elements are included. See IRM 1.11.10.5.1, Authoring Interim Guidance Memoranda, for required elements.

4. The author of the IGM must ensure that the IGM is 508 compliant and contains the proper metadata. See Section 508 Tools for Authors on the SPDER website for guidance on 508 compliance.



### Note:



See IRM 11.3.13.5.1, Approach to Exemptions, for information on FOIA exemptions.

5. The author will forward the IGM to the Program Owner and Program Director for initial concurrence along with Form 2061.

6. Once Program Owner and Program Director approve the draft IGM the author of the IGM will contact the TAS IMD coordinator for assistance and guidance in preparing, routing/clearing, and obtaining a control number for the IGM. See _Exhibit 1.11.13-1_, TAS IGM Process.

7. The TAS IMD coordinator will:



   - Determine if guidance is new, an update, or reissuance

   - Verify all components of IGM are present (affected IRM section, function symbols, etc)

   - Discuss impacted organizations, including external functions

   - Assign an IGM control number.



     ### Note:



     The control number will be issued in the following format: TAS-XX.X.XX-MMYY-NNN


8. After guidance is received from TAS IMD coordinator, the author will:



1. Add the Control number to the IGM.



      ### Note:



      MMYY format must be updated once IGM is signed to match the month and year of actual signature date.

2. The control number must be included in the upper right-hand corner of all TAS IGMs, along with identification of any impacted IRMs.



      ### Caution:



      The expiration date generally should be left blank until IGM is approved. Once the IGM is approved the author will update the expiration date accordingly.


9. The author will coordinate internal review of IGM with the TAS IMD coordinator. See _IRM 1.11.13.3_, TAS IMD Clearance Process.


**1.11.13.2.1.4.2** **(08-01-2022)**

###### Reissuance of an Interim Guidance (IGM)

1. In the rare circumstance that the IGM is not incorporated into the IRM within the required timeframes and the procedures are still applicable, the author must reissue the IGM. The author must obtain approval from the Program Owner, then request reissuance of the IGM and a new control number for the IGM by providing the TAS IMD coordinator with:



1. Written justification to warrant reissuance, and

2. A copy of the expired IGM as background documentation


2. The TAS IMD coordinator will provide justification to the Director of SPDER for approval per IRM 1.11.10.5.6, Reissuing Interim Guidance Memoranda.


**1.11.13.2.1.5** **(08-01-2022)**

##### SERP IRM Procedural Update

1. A SERP IPU (Interim Procedural Update) is a form of Interim guidance. See IRM 1.11.10.6, SERP IRM Procedural Updates (IPUs).

2. A SERP IPU generally posts within 24 hours of the submission using the SERP Submission Form. This provides updated guidance for IRMs when it is critical to quickly communicate changes to TAS procedures and processes. See IRM 1.11.8, Servicewide Electronic Research Program (SERP).

3. Use the SERP E-FOIA Decision Tool located within the SERP Submission Form, New Update. If the IPU meets the E-FOIA requirement, SERP will contact the TAS IMD coordinator to post the information in IG format for posting to the ERR, see IRM 1.11.8.7.1.1(2), Issuing an IPU (Interim Guidance), and address E-FOIA requirements.

4. For steps to prepare the IPU for posting to SERP, see IRM 1.11.8.7.1.3, IRM Authoring Tool – Updating Your IRM XML File for IPU Submission.



### Note:



If an IRM requires an update and listed on the SERP site, you must submit an IPU.


**1.11.13.2.2** **(08-01-2022)**

#### Record Documentation and Retention

1. After the Program Director approves and signs the Form 2061 for the IGM/IRM, the author will forward the package to the IMD TAS mailbox for publishing. See IRM 1.11.9.10.2, Final Review by IMD coordinator.

2. Within 30 calendar days after publication of the IRM, IMD/SPOC will forward the records documenting the review and approval of IRM changes including new or obsoleted IRMs to the IRS Historical Library for record retention. See IRM 1.11.9.10.3, Archiving Clearance Documents.

3. After the IGM has posted, IMD/SPOC will obtain the final IGM and approval package within TAS record retention, within **five calendar days**.

4. IGMs are maintained/controlled by the author within their program office.


**1.11.13.2.3** **(08-01-2022)**

#### E-FOIA Law and Compliance

1. By law, federal agencies must document, publish, and maintain records of policies, authorities, procedures, and organizational operations. See IRM 1.11.2.1.2 , Authority.


**1.11.13.3** **(08-01-2022)**

### TAS Interim Guidance Internal Clearance Process

1. The author will coordinate internal review of the IGM with the TAS IMD coordinator by:



1. Sending the draft IGM to TAS IMD coordinator who will send the IG, for review by all impacted internal departments.



      ### Caution:



      If external review is necessary, be sure to coordinate with TAS IMD coordinator, who will initiate external review once internal review concludes. See _IRM 1.11.13.3.1_ for external review guidance.

2. Once the internal clearance review concludes, all comments will be forwarded to the author for consideration. If corrections are warranted, the author will update and immediately resubmit the IGM to the Program Owner for review, within **seven business days**.

3. The Program Owner will review the IGM within **two days**, sign the Form 2061 and if approved, send the IGM to the Program Director for approval and signature on the IGM and Form 2061.



      ### Reminder:



      If external review is necessary, the author will request preliminary approval from the Program Director. See _IRM 1.11.13.3.1_, for external review guidance.

4. Once the applicable internal and external clearance is complete, the author may request assistance from the TAS IMD coordinator to obtain the final approval signatures on the Form 2061.

5. Once the IGM is approved, the TAS IMD coordinator will follow additional steps per _IRM 1.11.13.4_, Pre-Publishing Process.


**1.11.13.3.1** **(08-01-2022)**

#### TAS External Clearance Process

1. The author in consultation with the TAS IMD coordinator, must determine the effect the IMD (IRM/IGM) has on IRS programs outside of TAS (see IRM 1.11.9.3 , Identifying Reviewers) or if the IRM requires a specialized review (see IRM 1.11.9.4 , Specialized Reviewers) to determine if the IRM/IGM requires external clearance and if the IMD requires expedited clearance, see IRM 1.11.9.5.4.1 . The author should consult the TAS IMD coordinator if assistance is needed with this determination.

2. IMDs are not subject to external clearance when the Program Owner determines the guidance does not affect IRS programs outside of TAS or require a specialized review.

3. The TAS author must forward the IMD, (including attachments, if any) to the TAS IMD coordinator once internal clearance concludes to begin the external clearance process. See IRM 1.11.9.5.2 , Documents Sent for Clearance – Clearance Package.

4. The TAS IMD coordinator will prepare the Form(s) 2061 to document the review, concurrence, and approval of the IMD changes by the external reviewers.



### Note:



If the IMD requires expedite clearance, the Program Director must sign Form 2061 box six to approve the use of expedite clearance.

5. The TAS IMD coordinator will compile and forward all comments received from external reviewers to the TAS author for consideration. The TAS author must address all external reviewer feedback and update the external feedback spreadsheet with a justified response to each comment. To address external comments, the TAS author will:



1. Review external comments and provide an explanation for rejecting or accepting all substantive content changes using the external feedback spreadsheet under the appropriate column designated for “TAS Response.” See IRM 1.11.9.8, Responding to Reviewers’ Comments.

2. Return the spreadsheet to the TAS IMD coordinator within 15 business days. The TAS IMD coordinator will provide the response to the external function. If disagreements still exist, the Program Director and TAS IMD coordinator will consider whether to exercise procedures set forth in IRM 1.11.9.9.1, Issuing IMD While Disagreements are Discussed.


6. The TAS author will update the IMD accordingly and include the external feedback spreadsheet in the IMD approval package.



### Note:



Substantive external comments must be shared with the Program Director for acceptance and final approval. Additional updates may be required prior to final approval.

7. The TAS author will resubmit the IMD package to the Program Director for review and signature.


**1.11.13.4** **(08-01-2022)**

### Pre-Publishing Process

1. Prior to publishing, the Program Director must approve all IGs and substantive IRM updates.



### Note:



Editorial updates may be approved by the Program Director.

2. For IRMs, the TAS author will:



1. Complete Form 1767, Publishing Services Requisition, to request publishing services for all IRMs. Instructions for completing Form 1767 can be found on the back of the form. The TAS IMD coordinator should be consulted when assistance is needed to prepare this form. Also See IRM 1.11.5, Publishing the IRM.

2. Forward the IMD, Form(s) 2061, Form 1767 Publishing Services Requisition, and reviewer comments via the TAS IMD/SPOC organizational mailbox to the TAS IMD coordinator for approval and verification.


### Note:

The TAS IMD coordinator will review the approval package and the Arbortext Editor file for format and structure accuracy.

3. For Interim Guidance, the TAS author will:



1. Update the IGM with the signature date.

2. Update the Control number MMYY to match the signature month and year.

3. Convert to a 508 compliant Word document. Be sure to include /s/ next to the Program Director’s name.

4. Add metadata (keywords, file name, descriptors, etc.) to the Word document properties.

5. Use the E-FOIA decision tool to determine if the IGM should be made available to the public.

6. Email the IGM, Form(s) 2061, and reviewer comments to the TAS IMD coordinator for approval. The TAS author should verify it contains all necessary components (control number, expiration date, impacted IRM, contact point, etc.).

7. Provide the IGM Word document for internal posting to the TAS IG site and for external posting (if applicable) to IRS.gov.


### Note:

All Form(s) 2061 related to IGMs must be included in the package to post in the historical library after the IRM is published.

**1.11.13.5** **(12-11-2023)**

### TAS IMD Publishing & Distribution

1. The TAS IMD coordinator is the approving TAS official for Form 1767 and the TAS IMD staff is responsible for sending the form with the IMD package to M&P on behalf of TAS.



### Note:



Note: All TAS employees can access the IRM electronically. TAS authors should only request print distribution when there is a business need.


**1.11.13.5.1** **(08-01-2022)**

#### TAS Interim Guidance Distribution

1. Once the IGM is approved, the TAS author will submit the approved IGM to the TAS IMD coordinator.

2. The TAS IMD coordinator will:



1. Confirm the document is 508 compliant and in PDF format.

2. Post the IGM to the TAS internal IG website located at TAS Internal IG website.

3. Post the IGM to the SPDER IMD Tracking System.


3. The SPDER staff forwards the IGM to post to IRS.gov, if it meets E-FOIA criteria. The SPDER staff will confirm the posting via email to the TAS IMD coordinator, who will then forward the posting confirmation to the TAS author.



### Note:



All TAS procedural and guidance memos can be found on the internal website at IMD/SPOC Document Library.

4. Once the IGM is published, the TAS author will draft and submit for approval a Welcome Screen article to communicate the IGM to TAS employees using the Communications Assistance Request (CAR) system.


**1.11.13.6** **(08-01-2022)**

### Monitoring

1. For IRMs:



1. The TAS author must perform an annual review to verify the content is accurate. See Exhibit 1.11.2-2, Most Common Reasons to Review the IRM. The TAS author is responsible for reviewing each IRM section to ensure the IRM:



      > - Includes procedural, organizational, or operational changes.
      >
      >       - Is accurate, accessible, and easy to follow instruction.
      >
      >       - Does not contradict with any existing guidance.
      >
      >
      > ### Note:
      >
      > At a minimum, hyperlinks, telephone numbers, and the contact information should be verified for accuracy.





      > ### Reminder:
      >
      > Always incorporate IG (e.g., IGMs or SERP IPUs) into the applicable IRM(s) within **two years** from issuance or the stated memo expiration date, whichever is earlier. See IRM 1.11.10, Interim Guidance Process.

2. If content is no longer current or correct, TAS authors are required to update their IRMs as soon as possible with the revised guidance.



      ### Note:



      IRMs can be republished every **seven calendar days** depending on the number of pages and graphics.


2. For IGMs:



1. The TAS IMD coordinator and IG author will monitor procedural memos and solicit assistance from TAS authors or content owners to ensure the information is promptly incorporated into the IRM within **two years** from issuance or the stated memo expiration date, whichever is earlier.



      ### Caution:



      If reissuance is necessary, clearance timeframes should be considered well in advance of the IGM expiration date.

2. The IGM author will also obsolete the IGM when appropriate. See _IRM 1.11.13.7_ for procedures for archiving TAS IG.


**1.11.13.7** **(08-01-2022)**

### When and How to Archive TAS Interim Guidance

1. All IGMs expire **two years** from the issue date. However, when the guidance needs to be removed or archived earlier than the expiration date, the TAS author and the IMD coordinator will determine whether the guidance should be removed from the website on the IMD Tracking System when:



1. The IRM has been updated and published with the new procedures and the IGM is no longer needed.

2. Procedures have changed and the guidance is invalid or superseded.


2. It is the responsibility of the IG author to ensure that guidance contained within the IG is promptly incorporated into the relevant IRM based on the required guidelines.

3. The IRM author should notate on the Manual Transmittal of the impacted IRM in the "Effect On Other Documents," that the IRM incorporates interim guidance from the IGM control number, title, and the date it was issued. Below is an example of such a Manual Transmittal notation.



### Example:



This IRM supersedes and incorporates this IRM incorporates Interim Guidance Memorandum SBSE-05-0508-XXXX, \[Title of interim guidance\] dated Month DD, YYYY.





### Example:



This IRM supersedes and incorporates this IRM incorporates the following IRM Procedural Updates (IPUs): IPU 11U162X and 11U163X issued MM-DD-YYYY through MM-DD-YYYY.

4. The IRM author must also ensure expired guidance is timely removed from the TAS internal IG website and www.irs.gov (if applicable). See _Exhibit 1.11.13-1_, TAS Interim Guidance (IG) Memoranda Process, steps 7-10, for additional information.


**1.11.13.8** **(08-01-2022)**

### Reviewing Internal Management Documents (IMDs) For Systemic Issues

1. TAS employees will review IMDs for systemic issues (i.e., taxpayer burden, omission or infringement of taxpayer rights, etc.). This process primarily takes place while the OD/Function is clearing its IMD product before the new or revised process becomes official guidance and creates a systemic issue for taxpayers. Systemic Issue identified within an IMD/SPOC should be identified and addressed during revision and clearance of IRMs or other IMD products. The TAS IMD review process is extremely important and due diligence should be taken to ensure changes in IRS policy, authority, and procedures do not cause adverse impact on taxpayers.



### Note:



Recommendations identified outside of the clearance review period should be forwarded to the \*TAS IMD SPOC mailbox. The TAS IMD/SPOC staff will load the recommendations to the TAS IMD Application and forward them to the OD for immediate action. See _IRM 1.11.13.10_, Methods of Submitting Changes to IRMs, Forms, Publications, Notices, Letters, and Systems for further information.


**1.11.13.8.1** **(08-01-2022)**

#### Receipt of IMD Review

1. All IMD product reviews will come into TAS through the TAS IMD/SPOC mailbox \*TAS IMD SPOC for control and distribution of the review request in TAS, based upon subject matter expertise.



### Note:



TAS is considered a specialized reviewer, see IRM 1.11.9.4, Specialized Reviewers.

2. Recommendations identified for an IMD/SPOC outside of the clearance review period should be forwarded to the \*TAS IMD SPOC mailbox. The TAS IMD/SPOC staff will then load it to the TAS IMD Application and forward to the OD for immediate action.

3. Upon receipt of a new review request, the TAS IMD/SPOC staff will create and name a folder for the review under the \*TAS IMD SPOC mailbox "External Review" folder and enter the new IMD review on TAS IMD Application within **two business days** from the email received date, or "**actual start date**" . For a SPOC or "Other" product, a comprehensive determination generally should be made within 20 calendar days from the actual receipt date; unless an “expedite” review was requested.



### Note:



The IMD Review title and folder name should carry a similar name as the incoming IMD title.

4. The TAS IMD SPOC Staff is normally allowed **30 calendar days** to complete each review. However, a review may be shortened or lengthened with the originator's consent.


**1.11.13.8.2** **(08-01-2022)**

#### Abbreviated/Comprehensive IMD Review

1. The TAS IMD/SPOC staff will determine if an IMD review should be abbreviated or comprehensive. Criteria for abbreviating an IMD review will be based on the following criteria:



1. Does the IMD product contain processes that directly impact the taxpayer?

2. Does the process create any apparent taxpayer burden?

3. Does there appear to be any opportunity that the process might infringe upon taxpayers' rights?

4. Does the content relate to an Objectives Report or Annual Report to Congress (ARC) issue, past or present? If so, contact the SME or lead for the issue to determine TAS’s position.

5. Does the content relate to any "special projects" (Taxpayer Advocacy Panel (TAP), cross-functional teams and task forces, etc.)? Check the IMD Application for any related entries. If so, contact the project lead to determine TAS’s position.

6. Does the content relate to any emerging issue, IG ,or other update to hot topics, etc.?


2. If the IMD review meets any of the criteria above, it will be assigned for a comprehensive review, see _IRM 1.11.13.8.3_, Assigning an IMD. If the reviewer has no comment, they must input "No Comment" into TAS IMD Application.


**1.11.13.8.3** **(08-01-2022)**

#### Assigning an IMD

1. Once the IMD is loaded to the IMD Application, the TAS IMD/SPOC staff will assign it to the appropriate SME within the TAS organization (e.g., technical liaison, attorney advisor, Internal Technical Advisory Program, Technical Analysis and Guidance, or Local Taxpayer Advocates (LTA)).



### Reminder:



TAS SMEs are required to update their profile to include applicable items of interest or assignment. Profiles can be currently found on the TAS SME Specialization in the IMD Application.: .





### Exception:



Assignments are not necessary for abbreviated reviews.

2. The TAS IMD/SPOC staff will notify the assignees of the timeframe to conduct the review.



### Caution:



If reviews cannot be completed timely, the reviewer's manager should notify the TAS IMD/SPOC staff so that an extended response date can be requested from the originating office.

3. The designated managers from the ITAP employees should assign reviewers to the IMD review by forwarding the email to their employee.



### Note:



Assigned SME may coordinate the IMD review with other assigned SME(s) to ensure consistency on **high profile** issues.


**1.11.13.8.4** **(08-01-2022)**

#### Comprehensive Review Determination

1. The TAS IMD/SPOC staff will determine if an IMD review should be assigned for review and comments by TAS SMEs. Criteria for determining whether to assign the IMD review for a comprehensive review is based on IRM 1.11.13.8.2, Abbreviated/Comprehensive IMD Review.

2. If it is determined that the IMD product should have a comprehensive review, then the TAS IMD/SPOC Staff will update the review on the IMD Applicationwithin **four business days** from the "actual start date."

3. The TAS IMD/SPOC staff will issue an automated email to the SMEs with a link to review the product, timeframe to conduct the review, and the ability to add comments to the IMD Application site.

4. The response date for the TAS IMD reviewers to complete their reviews will typically be **two weeks**, unless it is an expedited request. The timeframe is based upon the due date indicated on the originator's Form 2061 (**normally 30 days**), reduced by the time needed (typically 7-10 calendar days) to allow the TAS IMD/SPOC coordinator or staff analyst time to compile, edit, and elevate the review for management consideration, as necessary.

5. The TAS IMD/SPOC staff uploads the final compiled response on the IMD Application under the "Files" tab, and updates the "Notes" tab (if necessary). The TAS IMD/SPOC staff uses the following data to track IMD reviews for statistical purposes:



1. Date received.

2. Date the response is due.

3. Originating division or function.

4. Product/issue under review.

5. Status of the review (pending, in process, forward for review, closed, etc.).

6. TAS reviewers.

7. The results of the review, including recommendations made and implemented.


### Note:

TAS review of forms, letters, notices, publications, etc., will be handled by the TAS SPOC coordinator following these procedures.

**1.11.13.8.5** **(08-01-2022)**

#### Working the IMD/SPOC Review

1. TAS SMEs conducting IMD/SPOC reviews will consider the following:



1. Protection of taxpayer rights.

2. Whether changes negatively impact taxpayers (these should be elevated along with recommendations for change).

3. If language regarding TAS is accurate, especially TAS Standard Language.

4. Are TAS references mentioned where appropriate?

5. Is associated guidance or references correct and in the proper location?

6. Will changes negatively impact the taxpayer?

7. Is there taxpayer burden related to the new/updated changes or processes?



      ### Note:



      This list is not all inclusive, so be sure to check the TAS IG website and other updates on hot topics, etc. See IRM 1.11.1, IMD Program and Responsibilities and IRM 1.11.2, IRM Process.





      ### Note:



      Although editorial comments are welcomed, you are not required to be a proofreader. Therefore, comments on spelling, punctuation, grammar, formatting, etc. are **not**required.





      ### Note:



      Ensure comments are professional and have proper tone. Use TAS Writing and Style Guide for IRMs, notices, publications, and forms.


2. SMEs will ensure justification for recommendations are thoroughly explained and suggest language to update the IMD. SMEs will elevate content related to emerging issues, IG or other hot topics.




| **IMD Reviewer Guidelines** |
| :-: |
| **Issue Concerns:**<br>   - Does the IMD product contain processes that directly impact the taxpayer?<br>     <br>   - Does the process create any apparent taxpayer burden?<br>     <br>   - Does there appear to be any opportunity that the process might infringe upon taxpayers' rights?<br>     <br>   - Does the content relate to an Objectives Report or ARC issue, past or present? If so, contact the SME or lead for the issue to determine TAS’s position.<br>     <br>   - Does the content relate to any special projects (TAP, cross-functional teams and task forces, etc.)? If so, contact the project lead to determine the TAS position.<br>     <br>   - Do the procedures accurately follow the law (IRC, Treas. Reg., etc.) without diminishing taxpayer benefits and without placing undue requirements on the taxpayer?<br>     <br>   - To what extent does the issue impact balanced measures (customer service, employee satisfaction and business results)?<br>     <br>   - To what extent is the issue impacting taxpayers or, if new, what is the probability of impact?<br>     <br>   - To what extent is there public interest in the issue?<br>     <br>   - To what extent is immediacy of resolution required?<br>     <br>     <br>     <br>     ### Note:<br>     <br>     <br>     <br>     This list is not all inclusive, so be sure to check the TAS website for interim guidance and other updates on hot topics, etc.<br>     <br>     <br>     <br>     <br>     <br>     ### Caution:<br>     <br>     <br>     <br>     Although editorial comments are welcomed, you are not required to be a proofreader. Therefore, comments on spelling, punctuation, grammar, formatting, etc. are **not** required.<br>     <br>### Reminder:<br>Ensure comments are professional and have proper tone. Use TAS standard language for IRMs, notices, publications, and forms. |

3. Using the IMD Application, SMEs will fill out the following fields under “Submit a new recommendation”:



1. **Subsection/Page/Paragraph**: For IRMs, identify the IRM subsection, title, and page number; for delegation orders, forms, letters, and documents identify the paragraph number, page number, etc.

2. **Title:** Title

3. **Impact Type:** Select Taxpayer Rights/Taxpayer Burden (TPR/TPB) or Non TPR/TPB.

4. **Current Text:**The **current language**, word, sentence, etc., to be addressed in the review.

5. **Recommendation with Justifications**: Specify any concerns for that subsection or paragraph of the manual, order, or guidance, as well as the reviewer's comments and/or recommended language changes.



      ### Reminder:



      If a reviewer does not agree with the language in a document, rather than just indicating non-agreement, the reviewer should provide suggested language for how best to revise the document, whenever possible.

6. **Reviewer Name:** Name of TAS SME providing the recommendation.


**1.11.13.8.5.1** **(08-01-2022)**

##### Response from Operating Division

1. When the OD responds to the corresponding TAS recommendation, the TAS IMD/SPOC staff will enter the response in the IMD Application . The OD SME will indicate whether they will implement the recommendation.

2. In cases where the OD disagrees with the recommendation, to the OD SME will explain why they are not able to implement the recommendation. The TAS SME will have the opportunity to rebut the OD’s non-adopted recommendations.


**1.11.13.8.5.2** **(08-01-2022)**

##### TAS Subject Matter Expert Rebuttal

1. When a TAS recommendation is not accepted, the TAS SME will receive a notification from the IMD Application with a link to the review, and will select the Recommendation ID, Response option (Accept, Reject, Concede), and Response Text.

2. If the TAS SME accepts or concedes to the OD response, the TAS IMD/SPOC staff will close the review on the IMD Application.

3. If the TAS SME rejects the OD response, the TAS IMD/SPOC staff will forward the rebuttal response to the OD and update the status on the IMD Application.

4. The TAS IMD/SPOC staff will continue to monitor the rebuttal until a response is received and the OD and TAS reach consensus.


**1.11.13.8.6** **(08-01-2022)**

#### Completing the IMD Review

1. The review should be completed on or before the due date.

2. If the reviewer has no comment, they will update the IMD Application, selecting "No Comments" , check the box “I have no comments for this review” which auto populates their name, and select save.

3. Time spent performing IMD reviews should be charged on Single Entry Time Reporting (SETR) as follows:



|     |     |
| --- | --- |
| OPF Code | Used by |
| 36762 – Proactive Advocacy | IMD Reviewer (SME) |
| 36765 – TAS Advocacy Issue Teams | TAS Advocacy Issue Teams |
| 36766 – Internal Management Documents | TAS IMD/SPOC staff |

4. The reviewer will raise concerning issues to their manager and to the TAS IMD coordinator.

5. If the reviewer is unable to complete the review by the prescribed due date, the reviewer should contact their manager and the TAS IMD/SPOC staff to determine if the due date can be extended.


**1.11.13.8.7** **(08-01-2022)**

#### Finalizing, Elevating, and Evaluating the IMD Review

01. Once all TAS reviewer responses are received; the TAS IMD/SPOC Staff will:



    1. Review and consolidate the responses **within seven business days** of due date of the individual reviews, and contact the reviewers for clarity, **as necessary**;

    2. Ensure comments are professional in nature and have proper tone;

    3. Raise significant concerns that seriously impact taxpayer rights or taxpayer burden to TAS leadership, including those that relate to the Reports to Congress. See IRM 13.2.1.7, National Taxpayer Advocate's Annual Reports to Congress; and

    4. Forward the consolidated response to the OD/function and monitor it for a response.


02. The TAS IMD/SPOC staff will review all responses for OD/Function for acceptance and rejection of TAS’s proposed recommendations. See IRM 1.11.9.11.3, Resolving Disagreements.

03. For non-adopted significant proposed recommendations, the TAS IMD/SPOC Staff will:



    1. Forward the non-adopted recommendation to the originating TAS IMD reviewer;

    2. Request the TAS reviewer to either concur, concede, or provide a rebuttal response along with any additional supporting information.


04. The TAS IMD/SPOC coordinators will evaluate and elevate any remaining unresolved issues fitting the criteria in the table below **within nine business days of the receipt** of the OD/Function’s response to the appropriate TAS technical liaisons or attorney advisors.



    ### Caution:



    Elevation through attorney advisors will be identified based on individual attorney advisor subject-matter-expertise, applicability to tax law, at the direction of the technical liaison, or through the specific direction or guidance of TAS management.



     The TAS IMD/SPOC coordinators will request extensions from the OD/Function, as needed, to ensure there is sufficient time (**5-10 business days**) to consider unresolved issues prior to publishing.





    | **IMD Review Elevation Criteria** |
    | :-: |
    | "Yes" to any one of the following questions for unresolved issues after evaluating the OD's response will be elevated to the appropriate TAS technical liaison: |
    | - Does the issue impact one or more taxpayer rights?<br>      <br>    - Does the issue relate to a current or ongoing Reports to Congress?<br>      <br>    - Does the issue relate to an emerging issue or a special project (Advocacy Project, Task Force, TAP issue, etc.)?<br>      <br>    - Does the issue impact balanced measures (customer service, employee satisfaction and business results)?<br>      <br>    - Does the issue relate to public interest? Explain. |

05. The TAS technical liaison and/or attorney advisor will review the unresolved issues to determine if negotiation is warranted with the OD program manager.



    ### Note:



    If a discussion is not necessary, the TAS technical liaison and/or attorney advisor will provide the rationale and document the reason for not pursuing a non-adopted issue.

06. If a determination is made to negotiate the issue, the TAS IMD/SPOC staff will set up a meeting between the TAS technical liaison or attorney advisor and OD author and/or program manager. TAS IMD/SPOC staff will facilitate the call, if necessary.

07. The TAS technical liaison or attorney advisor will provide status updates to the TAS IMD/SPOC coordinator on all elevated issues until resolved. The TAS IMD/SPOC coordinator may notify the TAS IMD/SPOC Chief for informational purposes.

08. If issues remain unresolved after negotiations, the TAS technical liaison and/or attorney advisor will prepare a memo summarizing the issue(s) and notify the EDSA, who will then review earlier comments and consult with the attorney advisor or designee, prior to elevation to the NTA. However, efforts should be made to resolve the issue at the lowest level possible.

09. Responses received from the originating OD/Function regarding TAS review comments must be entered on the IMD Application, along with any information concerning the status and/or implementation of TAS suggestions, as events occur.



    ### Note:



    In cases where the implementation is for a future date, a follow-up may be done to determine if the suggestions were correctly implemented. In situations where agreement was not reached with the OD/Function, and the issue is elevated, the TAS technical liaison should consider including the issue in the Emerging Issues quarterly report prepared for the EDSA. The attorney advisor should consider reporting the issue to DNTA/NTA as an emerging issue.

10. The TAS IMD/SPOC coordinator will prepare, sign, and send Form 2061 to the OD/Function after addressing all recommendations.


**1.11.13.9** **(08-01-2022)**

### Single Point of Contact Process

1. The TAS SPOC coordinator oversees reviews involving new material or changes to existing customer (public) communications (e.g., notices, letters, inserts, etc.). A designated TAS SPOC coordinator works directly with TAS IMD coordinator to ensure SPOC reviews (IMDs) are completed timely and efficiently.

2. The TAS SPOC coordinator:



   - Coordinates with TAS business units to revise TAS forms and publications.

   - Works referrals from the Phoenix program that cannot be incorporated as an ongoing advocacy initiative (project, task force, etc.).

   - Works with ODs and multi-divisional groups and task forces to change forms, notices, letters, and publications owned by other OD/Functions.

   - Ensures the appropriate TAS Standard Language is included, as applicable, in all IMDs that require a response from the taxpayer. The language consists of three levels of script (long, medium, and small) that have been approved by the NTA for inclusion in IRMs, notices, letters, publications, etc.

   - Communicates regularly with the Tax Forms and Publications business unit, regarding TAS comments on new or revised tax forms and publications. These reviews are managed through the IMD review process as previously described in this IRM.

   - Involved in TCS Data Gathering calls. See OTC Correspondence site, specifically Correspondence Toolkit.


**1.11.13.10** **(08-01-2022)**

### Methods of Submitting Changes to IRMs, Forms, Publications, Notices, Letters and Systems

1. This section describes different ways to proactively make corrections, submit suggestions, or raise issues and concerns to the appropriate process owner.

2. **All TAS employees** should coordinate change requests for any IMD (forms/letters/notices/publications or IRM) through TAS IMD/SPOC.



### Caution:



Request for Services (Green Button) must be coordinated with the TAS IMD/SPOC Staff for **all TAS employees** prior to submission.

3. If you have an IMD or SPOC product that requires a change but has not been received for a formal clearance review from that specific OD then consider submitting an Outside of Clearance (OCP) submission. Contact the IMD SPOC staff for assistance. The staff will require you to complete the OCP request with the following information:



   - State the topic (explain whether the current process infringes on taxpayers’ rights or unnecessarily burdens taxpayers).

   - State the current published section you are addressing.

   - State the reason you identified this section (explain the negative impact, include supporting research).

   - State the change you’d like the author to consider.


### Note:

Use of the IMD Review template is **highly** recommended to submit changes for IMD issues.

4. When Systemic Advocacy receives issue submissions related to form and publication revisions, the Phoenix program manager will coordinate these issues with the TAS SPOC coordinator. The TAS SPOC coordinator will review the issue and decide whether to gather additional feedback from TAS SMEs or forward to the responsible OD for action.



### Note:



Internal requests for TAS review of these documents will be handled by the TAS SPOC coordinator using procedures outlined in _IRM 1.11.13.8_, Reviewing IMDs For Systemic Issues.

5. TAS employees will use Phoenix to report systemic programming and operational problems that result in systemic problems for taxpayers.

6. Forward suggestions for changes or improvements to internal TAS procedures or policies to the \*TAS IMDSPOC mailbox. Any suggestions to IRM 13 or IRM 25.30, should be sent through the SERP Feedback Portal. If the IRM subsection is not on SERP, the recommendation should be forwarded to the \*TAS IMDSPOC mailbox.


**1.11.13.11** **(08-22-2025)**

### Service Level Agreements (SLA)

1. The NTA has reached agreements with the Commissioners of the Taxpayer Services (TS) Division, Small Business & Self-Employed (SB/SE) Division, Tax Exempt & Government Entities (TE/GE) Division, Criminal Investigation (CI), Appeals, and Chief Financial Officer (CFO) Division, and Large Business, International (LB&I) Division, that outline the procedures and responsibilities for the processing of TAS cases when either the statutory or delegated authority to complete case transactions rests outside of TAS. These agreements are known as SLAs.

2. Each SLA, when signed, will be posted to the E-FOIA website.


**Exhibit 1.11.13-1**

### TAS Interim Guidance Memoranda Process

The table below outlines the IGM process, including E -FOIA considerations.

| STEP | RESPONSIBLE PARTY | ACTION |
| :-: | :-: | :-: |
| 1. | TAS Author | 1) Prepare draft IGM (must be 508 compliant)<br> 2) Coordinate with IMD coordinator to identify it as IG.<br> 3) Request a control number from the TAS IMD coordinator by providing the following:<br> • a copy of the draft IGM,<br> • a tentative issuance date,<br> • the identified impacted IRMs, if applicable, and<br> • a point of contact for the IGM, including office symbols and phone number.<br> 4) Determine if the memo meets E-FOIA criteria. |
| 2. | TAS IMD coordinator | 1) Assign a control number. Start with -0001 at the beginning of each calendar year.<br> 2) Coordinate with the TAS Author.<br> 3) Explain the **two-year rule** and the need to monitor the IGM for expiration.<br> 4) Review for 508 compliance.<br> 5) Check for proper IGM format (including the letter head).<br> 6) Author to notify TAS IMD coordinator if the IGM is obsoleted early through an IRM update or a changed process. |
| 3. | TAS Author/Analyst | 1) Prepare the IGM in accordance with E-FOIA guidelines.<br> 2) Clear IGM package, including attachments, using Form 2061.<br> 3) Forward the signed final IGM package electronically to TAS IMD coordinator. |
| 4. | TAS IMD coordinator | 1) Review the final IGM package for compliance with E-FOIA guidelines and proper clearance approvals.<br> 2) Forward the IGM package to the TAS CSO Staff for posting on the TAS website and www.irs.gov.<br> 3) Email the completed PDF to the designated SPDER staff. |
| 5. | SPDER Staff | 1) Link the IGM to the Instructions to Staff ERR site on [www.irs.gov](https://www.irs.gov/irm/part1/www.irs.gov).<br> 2) Send confirmation to the TAS IMD coordinator that the IGM is posted to the site, for the IMD coordinator to notify the initiator. |
| 6. | IRM Author | 1) Create/update the IRM in accordance with established procedure, not to exceed **two years**.<br> 2) Notify the IMD coordinator when the IGM is no longer needed.<br> 3) Ensure the IRM has been updated and incorporates the IGM, if applicable. \[Note: If the IRM is not updated, consider reissuance of the IGM, but remember that the reissued memo must be approved by the Director of SPDER and the Program Director responsible for the IGM.\]<br> 4) Ensure expired memos are removed from [www.irs.gov](https://www.irs.gov/irm/part1/www.irs.gov). (Expired IGMs are those that are either incorporated into an IRM or post- expiration date.)<br> 5) Prepare an email to the TAS IMD coordinator requesting removal of the expired IGM. |
| 7. | TAS IMD coordinator | 1) Will initiate the request through the IMD Tracking System requesting removal of the subject IGM documentation from [www.irs.gov](https://www.irs.gov/irm/part1/www.irs.gov).<br> 2) Will remove the subject from the internal site. |
| 8. | SPDER | Send confirmation to the TAS IMD coordinator that the IGM has been removed from www.irs.gov. |

**Exhibit 1.11.13-2**

### TAS IRMs Listing

The table below contains a listing of all IRMs where TAS is the owner or co-owner. The list contains the IRM number, the catalog number, and the official title.

### Caution:

Some IRMs below may not be published to the repository and still in development.

|     |     |     |
| --- | --- | --- |
| **IRM #** | **Catalog #** | **Title** |
| 1.1.8 | 30382H | National Taxpayer Advocate |
| 1.4.13 | 49230M | TAS Guide for Managers |
| 1.5.8 | 30338P | Section 1204/Regulation 801 Guidance for Taxpayer Advocate Service (TAS) |
| 1.11.13 | 49558R | Internal Management Documents System - Taxpayer Advocate Service (TAS) Internal Management Document Program |
| 13.1.1 | 30650A | Taxpayer Advocate Guiding Principles of the Office of the Taxpayer Advocate |
| 13.1.2 | 30652W | Internal Revenue Service Restructuring and Reform Act of 1998 (RRA98) |
| 13.1.4 | 35723S | TAS Authorities |
| 13.1.5 | 30655D | Taxpayer Advocate Service (TAS) Confidentiality |
| 13.1.6 | 30657Z | Casework Communications |
| 13.1.7 | 30658K | Taxpayer Advocate Service (TAS) Case Criteria |
| 13.1.8 | 30659V | Congressional Affairs Program |
| 13.1.9 | 30660W | Executive Correspondence Case Procedures |
| 13.10.1 | 94837Z | Taxpayer Advocate Guiding Principles of the Office of the Taxpayer Advocate |
| 13.10.5 | 94841H | TAS Security & Continuity of Operations |
| 13.1.10 | 30661H | Special Processes |
| 13.1.11 | 30662S | Case and Inventory Management |
| 13.1.12 | 30663D | Internal Technical Advisor Program |
| 13.1.14 | 35726Z | Suspension of the Statutes of Limitation under IRC 7811(d) |
| 13.1.15 | 35727K | Customer Complaints/RRA98§ 1203 Procedures |
| 13.1.16 | 35728V | Receipt and Intake of TAS Cases |
| 13.1.17 | 47430U | Transferring TAS Cases |
| 13.1.18 | 47431F | Resolving TAS Cases |
| 13.1.19 | 47432Q | Advocating With Operations Assistance Requests (OARs) |
| 13.1.20 | 47433B | TAS Taxpayer Assistance Order (TAO) Process |
| 13.1.21 | 47434M | Closing TAS Cases |
| 13.1.22 | 49944H | Manual Inventory Balancing Procedures |
| 13.1.23 | 52344F | Taxpayer Representation |
| 13.1.24 | 58009D | Advocating for Case Resolution |
| 13.2.1 | 30665Z | Systemic Advocacy Overview |
| 13.2.2 | 30666K | Phoenix Administration |
| 13.2.3 | 32654M | Evaluating and Reviewing Systemic Issues |
| 13.2.4 | 58125E | Information Gathering Projects (IGP) |
| 13.2.5 | 73767K | Advocacy Projects |
| 13.2.6 | 73768V | Immediate Interventions |
| 13.2.7 | 73769G | Collaborative Efforts |
| 13.2.8 | 73770H | National Taxpayer Advocate’s Annual Reports to Congress (ARC) |
| 13.3.1 | 30667V | NTA Toll-Free Procedures |
| 13.4.2 | 35620K | Administration and Security |
| 13.5.1 | 32657T | TAS Balanced Performance Measurement System |
| 13.6.1 | 35731S | Internal and External Communications |
| 13.7.1 | 47230S | Taxpayer Advocacy Panel Operating Procedures |
| 13.8.1 | 47233Z | Low Income Taxpayer Clinic Program Operating Procedures |
| 13.9.1 | 47234K | Procedures for Taxpayer Advocate Directives |
| 13.9.2 | 92853F | TAS Audit Coordination |
| 25.30.1 | 39379W | Creating and Modifying Service Level Agreements with TAS |
| 25.30.2 | 65379W | Service Level Agreement between the IRS Independent Office of Appeals and the Taxpayer Advocate Service |
| 25.30.3 | 65380X | Service Level Agreement between the Chief Financial Officer Division and the Taxpayer Advocate Service |
| 25.30.4 | 65384P | Service Level Agreement between the Criminal Investigation Division and the Taxpayer Advocate Service |
| 25.30.5 | 65991K | Service Level Agreement between the Large Business and International Division and the Taxpayer Advocate Service |
| 25.30.6 | 66008U | Service Level Agreement between the Small Business/Self Employed Division and the Taxpayer Advocate Service |
| 25.30.7 | 66032U | Service Level Agreement between the Tax Exempt & Government Entities Division and the Taxpayer Advocate Service |
| 25.30.8 | 66196P | Service Level Agreement between the Taxpayer Services Division and the Taxpayer Advocate Service |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-011-013#addtoany "Show all")

A2A