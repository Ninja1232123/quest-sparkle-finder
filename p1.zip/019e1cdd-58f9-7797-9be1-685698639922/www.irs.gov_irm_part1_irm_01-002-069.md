---
url: "https://www.irs.gov/irm/part1/irm_01-002-069"
title: "1.2.69 Business Unit Delegations of Authority for Chief Financial Officer | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-002-069#main-content)

- 1.2.69  [Business Unit Delegations of Authority for Chief Financial Officer](https://www.irs.gov/irm/part1/irm_01-002-069#idm139798982952960)
  - 1.2.69.1  [Introduction](https://www.irs.gov/irm/part1/irm_01-002-069#idm139798982934128)
  - 1.2.69.2  [Current CFO Business Unit Delegation of Authority](https://www.irs.gov/irm/part1/irm_01-002-069#idm139798981952560)
    - 1.2.69.2.1  [CFO Delegation Order CFO 1-2-1 (New)](https://www.irs.gov/irm/part1/irm_01-002-069#idm139798981949920)

# Part 1. Organization, Finance, and Management

# Chapter 2. Servicewide Policies and Authorities

# Section 69. Business Unit Delegations of Authority for Chief Financial Officer

* * *

## 1.2.69 Business Unit Delegations of Authority for Chief Financial Officer

#### Manual Transmittal

August 08, 2024

#### Purpose

(1) This transmits new IRM 1.2.69, Servicewide Policies and Authorities, Business Unit Delegations of Authority for Chief Financial Officer.

#### Material Changes

(1) New IRM 1.2.69, Business Unit Delegations of Authority for Chief Financial Officer, has been established to document content appropriate for the first issuance of this IRM.

(2) IRM 1.2.69.2, Current CFO Business Unit Delegation of Authority, documents new CFO business unit delegation order.

#### Effect on Other Documents

None.

#### Audience

All CFO organizations

#### Effective Date

(08-08-2024)

Teresa R. Hunter

Chief Financial Officer

**1.2.69.1** **(08-08-2024)**

### Introduction

1. This IRM contains the new delegation order for the CFO business unit. All approved CFO business unit delegation orders are listed in numerical order.

2. Each CFO delegation order is based on a Servicewide delegation order. Servicewide delegations of authority can be found in IRM 1.2.2, Servicewide Delegations of Authority. Additional information on the delegation order process can be found in IRM 1.11.4, Servicewide Delegation Order Process.


**1.2.69.2** **(08-08-2024)**

### Current CFO Business Unit Delegation of Authority

1. Current CFO business unit delegation orders are listed in numerical sequence. CFO Business Unit Delegation Orders approved after this IRM revision can be found at [https://www.irs.gov/privacy-disclosure/recently-approved-division-function-delegation-orders;](https://www.irs.gov/privacy-disclosure/recently-approved-division-function-delegation-orders) all documents are maintained on the website until the next IRM revision.


**1.2.69.2.1** **(08-08-2024)**

#### CFO Delegation Order CFO 1-2-1 (New)

1. **Order of Succession and Designation to Act as Chief Financial Officer**

2. **Authority:** To act and perform the functions of the Chief Financial Officer of office of the Chief Financial Officer of the Internal Revenue Service in the absence of the Chief Financial Officer due to an enemy attack on the United States, disability, or other emergency, which will ensure continuity of CFO operations.



### Note:



This authority only applies to officials in permanent positions.





> The official named as successor will be vested with all the authority given the Chief Financial Officer until relieved of the responsibility.





> In the event that emergency incident management procedures are activated, the Senior Commissioner’s Representative, Continuity Operations, would reach out to the Chief Financial Officer’s Headquarters Continuity of Operations Team (HQ COOP), starting with the CFO and continuing with those listed below, until a response is received.

3. **Delegated to:**



   - Deputy Chief Financial Officer

   - Senior Associate CFO for Financial Management

   - Associate CFO for Corporate Budget

   - Director, Financial Modernization and Technology

   - Director, National HQ Budget Office

   - Director, Credit Card Services


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority**: Servicewide Delegation Order 1-2, Servicewide Delegation Order 1-23, IRM 10.6.2.3.2.2 and IRM 10.6.2.3.2.3.

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. **Signed:** Teresa R. Hunter, Chief Financial Officer


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-002-069#addtoany "Show all")

A2A