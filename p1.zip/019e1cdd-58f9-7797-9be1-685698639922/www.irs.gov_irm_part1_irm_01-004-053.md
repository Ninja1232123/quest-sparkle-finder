---
url: "https://www.irs.gov/irm/part1/irm_01-004-053"
title: "1.4.53 Advisory and Property Appraisal and Liquidation Specialist Group Manager, Civil Enforcement Advice and Support Operations Territory Manager and Director Operational Aid | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-053#main-content)

- 1.4.53  [Advisory and Property Appraisal and Liquidation Specialist Group Manager, Civil Enforcement Advice and Support Operations Territory Manager and Director Operational Aid](https://www.irs.gov/irm/part1/irm_01-004-053#id1)
  - 1.4.53.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-053#id2)
    - 1.4.53.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-053#id4)
    - 1.4.53.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-053#id5)
    - 1.4.53.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-053#id6)
    - 1.4.53.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-053#id7)
    - 1.4.53.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-053#id8)
    - 1.4.53.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-053#id9)
    - 1.4.53.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-053#id10)
  - 1.4.53.2  [Administrative Guidelines for Managers](https://www.irs.gov/irm/part1/irm_01-004-053#id11)
  - 1.4.53.3  [General Managerial Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-053#id12)
    - 1.4.53.3.1  [IDRS and ICS Security](https://www.irs.gov/irm/part1/irm_01-004-053#id13)
    - 1.4.53.3.2  [Managing Employees using Telework, in Remote Locations, and/or Multiple Posts of Duty](https://www.irs.gov/irm/part1/irm_01-004-053#id14)
      - 1.4.53.3.2.1  [Customer Service and/or Remote Employees](https://www.irs.gov/irm/part1/irm_01-004-053#id16)
    - 1.4.53.3.3  [Outreach](https://www.irs.gov/irm/part1/irm_01-004-053#id17)
    - 1.4.53.3.4  [Advisory Review and Trend Analysis](https://www.irs.gov/irm/part1/irm_01-004-053#id18)
    - 1.4.53.3.5  [Direct Contact With Taxpayers With Or Requesting Representation](https://www.irs.gov/irm/part1/irm_01-004-053#id19)
    - 1.4.53.3.6  [Time Reporting and Case Matrix](https://www.irs.gov/irm/part1/irm_01-004-053#id20)
    - 1.4.53.3.7  [Integrated Data Retrieval System (IDRS)](https://www.irs.gov/irm/part1/irm_01-004-053#id21)
  - 1.4.53.4  [Role of the CEASO Group Manager](https://www.irs.gov/irm/part1/irm_01-004-053#id22)
    - 1.4.53.4.1  [Performance Evaluations](https://www.irs.gov/irm/part1/irm_01-004-053#id23)
    - 1.4.53.4.2  [Discipline and Disciplinary Actions](https://www.irs.gov/irm/part1/irm_01-004-053#id24)
    - 1.4.53.4.3  [Recognitions and Awards](https://www.irs.gov/irm/part1/irm_01-004-053#id25)
    - 1.4.53.4.4  [Employee Performance File (EPF) and Drop File](https://www.irs.gov/irm/part1/irm_01-004-053#id26)
      - 1.4.53.4.4.1  [Employee Development/Training](https://www.irs.gov/irm/part1/irm_01-004-053#id28)
      - 1.4.53.4.4.2  [Group Manager Development](https://www.irs.gov/irm/part1/irm_01-004-053#id29)
      - 1.4.53.4.4.3  [Group Manager With Approved Pseudonym](https://www.irs.gov/irm/part1/irm_01-004-053#id30)
      - 1.4.53.4.4.4  [Acting Group Manager Assignments and Designations](https://www.irs.gov/irm/part1/irm_01-004-053#id31)
    - 1.4.53.4.5  [Working with NTEU](https://www.irs.gov/irm/part1/irm_01-004-053#id32)
    - 1.4.53.4.6  [CEASO Advisory Workload Management](https://www.irs.gov/irm/part1/irm_01-004-053#id33)
      - 1.4.53.4.6.1  [CEASO Advisory Inventory Assignment](https://www.irs.gov/irm/part1/irm_01-004-053#id34)
      - 1.4.53.4.6.2  [Case/Program Rotation](https://www.irs.gov/irm/part1/irm_01-004-053#id35)
      - 1.4.53.4.6.3  [Assigning Work](https://www.irs.gov/irm/part1/irm_01-004-053#id36)
      - 1.4.53.4.6.4  [Reassignment of Departing Employee Inventory](https://www.irs.gov/irm/part1/irm_01-004-053#id37)
      - 1.4.53.4.6.5  [CEASO Advisory Case Assignment Guide](https://www.irs.gov/irm/part1/irm_01-004-053#id38)
      - 1.4.53.4.6.6  [CEASO Advisory Managerial Reports](https://www.irs.gov/irm/part1/irm_01-004-053#id39)
        - 1.4.53.4.6.6.1  [ICS Reports](https://www.irs.gov/irm/part1/irm_01-004-053#id41)
        - 1.4.53.4.6.6.2  [ENTITY Reports](https://www.irs.gov/irm/part1/irm_01-004-053#id42)
        - 1.4.53.4.6.6.3  [Automated Trust Fund Recovery Program Reports (ATFR)](https://www.irs.gov/irm/part1/irm_01-004-053#id43)
        - 1.4.53.4.6.6.4  [Collection Time Reporting System (CTRS) Monthly Reports](https://www.irs.gov/irm/part1/irm_01-004-053#id44)
      - 1.4.53.4.6.7  [Seizure, Sale and Acquired Property Reports](https://www.irs.gov/irm/part1/irm_01-004-053#id45)
        - 1.4.53.4.6.7.1  [Permanent Record Files](https://www.irs.gov/irm/part1/irm_01-004-053#id47)
        - 1.4.53.4.6.7.2  [Record 21, Record of Seizure and Sale of Real Estate](https://www.irs.gov/irm/part1/irm_01-004-053#id48)
        - 1.4.53.4.6.7.3  [Seizure Logs and RACS Accounting](https://www.irs.gov/irm/part1/irm_01-004-053#id49)
        - 1.4.53.4.6.7.4  [Seizure and Sale Reports and Memoranda](https://www.irs.gov/irm/part1/irm_01-004-053#id50)
      - 1.4.53.4.6.8  [Quality and Controls](https://www.irs.gov/irm/part1/irm_01-004-053#id51)
        - 1.4.53.4.6.8.1  [CSED Accounts](https://www.irs.gov/irm/part1/irm_01-004-053#id53)
        - 1.4.53.4.6.8.2  [ASED Accounts](https://www.irs.gov/irm/part1/irm_01-004-053#id54)
        - 1.4.53.4.6.8.3  [RSED Issues on Claims for Refund](https://www.irs.gov/irm/part1/irm_01-004-053#id55)
        - 1.4.53.4.6.8.4  [Monitoring Trust Fund Recovery Penalty (TFRP) Investigations](https://www.irs.gov/irm/part1/irm_01-004-053#id56)
        - 1.4.53.4.6.8.5  [Remittance Control Reviews](https://www.irs.gov/irm/part1/irm_01-004-053#id57)
    - 1.4.53.4.7  [Reviews](https://www.irs.gov/irm/part1/irm_01-004-053#id58)
      - 1.4.53.4.7.1  [Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-053#id60)
    - 1.4.53.4.8  [Embedded Quality (EQ)](https://www.irs.gov/irm/part1/irm_01-004-053#id61)
    - 1.4.53.4.9  [Functional Security Reviews](https://www.irs.gov/irm/part1/irm_01-004-053#id62)
    - 1.4.53.4.10  [Case Documentation](https://www.irs.gov/irm/part1/irm_01-004-053#id63)
  - 1.4.53.5  [Protecting Taxpayer Rights](https://www.irs.gov/irm/part1/irm_01-004-053#id64)
    - 1.4.53.5.1  [Fair Debt Collection Practices](https://www.irs.gov/irm/part1/irm_01-004-053#id66)
  - 1.4.53.6  [CEASO Groups and Workload](https://www.irs.gov/irm/part1/irm_01-004-053#id67)
    - 1.4.53.6.1  [Traditional Advisory Group Workload](https://www.irs.gov/irm/part1/irm_01-004-053#id68)
    - 1.4.53.6.2  [Estate Tax Group](https://www.irs.gov/irm/part1/irm_01-004-053#id69)
      - 1.4.53.6.2.1  [Estate Tax Liens](https://www.irs.gov/irm/part1/irm_01-004-053#id71)
      - 1.4.53.6.2.2  [Extensions of Time to Pay Estate Taxes](https://www.irs.gov/irm/part1/irm_01-004-053#id72)
    - 1.4.53.6.3  [Independent Administrative Reviewer (IAR) Group](https://www.irs.gov/irm/part1/irm_01-004-053#id73)
      - 1.4.53.6.3.1  [IAR Workload](https://www.irs.gov/irm/part1/irm_01-004-053#id74)
        - 1.4.53.6.3.1.1  [Review of Rejection of OIC Proposals](https://www.irs.gov/irm/part1/irm_01-004-053#id76)
        - 1.4.53.6.3.1.2  [Review of Rejection of Installment Agreement Proposals](https://www.irs.gov/irm/part1/irm_01-004-053#id77)
    - 1.4.53.6.4  [Property Appraisal and Liquidation Specialist(PALS) Group](https://www.irs.gov/irm/part1/irm_01-004-053#id78)
    - 1.4.53.6.5  [Restitution-Based Assessment (RBA) Group](https://www.irs.gov/irm/part1/irm_01-004-053#id79)
  - Exhibit  1.4.53-1  [CEASO Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide](https://www.irs.gov/irm/part1/irm_01-004-053#id80)
  - Exhibit  1.4.53-2  [CEASO Territory Manager Operational Aid](https://www.irs.gov/irm/part1/irm_01-004-053#id81)
  - Exhibit  1.4.53-3  [CEASO Director Operational Aid](https://www.irs.gov/irm/part1/irm_01-004-053#id82)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 53. Advisory and Property Appraisal and Liquidation Specialist Group Manager, Civil Enforcement Advice and Support Operations Territory Manager and Director Operational Aid

* * *

## 1.4.53 Advisory and Property Appraisal and Liquidation Specialist Group Manager, Civil Enforcement Advice and Support Operations Territory Manager and Director Operational Aid

#### Manual Transmittal

July 17, 2025

#### Purpose

(1) This transmits IRM 1.4.53, Advisory and Property Appraisal and Liquidation Specialist Group Manager, Civil Enforcement Advice and Support Operations Territory Manager and Director Operational Aid.

#### Material Changes

(1) Title changed to add Civil Enforcement Advice and Support Operations (CEASO) Territory Manager and Director.

(2) IRM 1.4.53.1(1)(e): Purpose, adds CEASO territory managers and director to this section and throughout this IRM.

(3) IRM 1.4.53.1(2): Audience, adds CEASO territory managers and director.

(4) IRM 1.4.53.1.1(4): Background, updated Wage & Investment (W&I) to Taxpayer Services.

(5) IRM 1.4.53.1.3(3): Responsibilities, updated TBOR reference.

(6) IRM 1.4.53.3.3: Managing Employees using Telework, in Remote Locations, and/or Multiple Posts of Duty, updated telework resources link.

(7) IRM 1.4.53.3.4(2): CEASO Advisory Review and Trend Analysis, updated process to submit Form 5942 trend analysis reports and memorandums.

(8) IRM 1.4.53.4(2): Role of CEASO Group Manager, updated guidance language.

(9) IRM 1.4.53.4.4.3: Group Manager With Approved Pseudonym, added new subsection to provide guidance when sworn or notarized document needed. Document may only be signed using the approved IRS pseudonym if the document states that it is "signed using IRS pseudonym" .

(10) IRM 1.4.53.4.4.4: Acting Group Manager Assignments and Designations, added new subsection to provide detailed guidance when an acting group manager is assigned or designated.

(11) IRM 1.4.53.4.7.(3): Reviews, added new Document 14510, Advisory Independent Administrative Review (IAR) Embedded Quality Job Aid

(12) IRM 1.4.53.4.9.(6): Functional Security Reviews, removed obsoleted Form 12149 and IRM 1.4.6 references.

(13) IRM 1.4.53.6(2): CEASO Groups and Workload, added Advisory Consolidated Receipts (ACR) and Control Point Monitoring (CPM) groups.

(14) IRM 1.4.53.6.1(6): Traditional CEASO Advisory Group Workload, added language specifying TFRP support work is performed by CPM tax examiners, and note that payment application and refund claims require an advisor to resolve.

(15) IRM 1.4.53-2: adds new Operational Review Plan Guide for CEASO Territory Managers

(16) IRM 1.4.53-3: adds new CEASO Director Operational Aid

(17) Editorial changes made throughout to update text, references, links, and to conform with current IMD requirements.

#### Effect on Other Documents

This material supersedes IRM 1.4.53 dated October 4, 2019.

#### Audience

Small Business/Self-Employed, Field Collection, Advisory and Property Appraisal and Liquidation Specialist Group Managers, Civil Enforcement Advice and Support Operations Territory Managers and Director

#### Effective Date

(07-17-2025)

Thomas Kramer

Director, Collection Policy

Small Business/Self Employed

**1.4.53.1** **(07-17-2025)**

### Program Scope and Objectives

1. Purpose- This section discusses operational and administrative responsibilities of managers in the Advisory and Property Appraisal Liquidation Specialist (PALS) functions within Civil Enforcement Advice and Support Operations (CEASO). The primary focus of this section is guidance related to CEASO case work. While many topics are touched upon in this section, comprehensive guidance about all of them cannot be included here. As you use this section, remain alert for references to other resources, such as related IRMs and websites, and access that guidance as needed to ensure a thorough understanding of topics. Specifically, this section::



1. Describes general administrative responsibilities required of CEASO group managers.

2. Describes employee performance and development procedures.

3. Prescribes internal control requirements.

4. Provides guidance to CEASO group managers on the assignment and approval of work.

5. Provides guidance for operational reviews by CEASO territory managers and director.


2. Audience- These procedures and guidance apply to all CEASO group managers, territory managers and director.

3. Policy Owner- SB/SE Director, Collection Policy.

4. Program Owner- SB/SE Collection Policy, Enforcement, is the program owner of this IRM.

5. Primary Stakeholders- Civil Enforcement Advice and Support Operations and Labor Relations.

6. Program Goals- This guidance is provided to communicate the managerial responsibilities of CEASO group managers, including performance management, assignment of work, approval of work, promoting quality casework and internal group controls.

7. Contact Information- Recommendations and suggested changes to this IRM should be emailed to the Content Product Owner. The owner is indicated on the Product Catalog Information page which is found in the Forms and Publications, IRM Numerical Index of the Media and Publications Electronic Publishing website.


**1.4.53.1.1** **(10-04-2019)**

#### Background

1. This section contains procedures, guidance and information for CEASO group managers, territory managers and director. The content includes general administrative responsibilities, performance management, internal controls, assignment of work, approval of work, quality and program reviews.

2. CEASO employees work in conjunction with Field Collection to ensure that all legal and procedural requirements are met in actions taken to collect delinquent liabilities and returns. These collection actions include determinations regarding notices of federal tax liens, levy, seizure and sale, trust fund recovery penalty, litigation, collateral agreements, and other activities.

3. CEASO employees also work with taxpayers to resolve lien priority issues and claims against the government.

4. In general, CEASO employees work with other functions and divisions outside Field Collection such as Taxpayer Advocate Service (TAS), Examination, Taxpayer Services (formerly Wage & Investment), Counsel, Criminal Investigation, and Appeals. This cooperation ensures that legal requirements are met, appropriate actions are taken, and correct information is provided to both internal and external customers. Where present, service level agreements between SB/SE and the respective business or functional unit provide mutual guidelines on time frames and actions to be taken in this coordinated effort.


**1.4.53.1.2** **(10-04-2019)**

#### Authority

01. 5 USC, Government Organizations, Part III, Employees.

02. Section 1203 of the Internal Revenue Service Restructuring & Reform Act of 1998.

03. Section 1204 of the Internal Revenue Service Restructuring & Reform Act of 1998.

04. IRC 6304, Fair tax collection practices.

05. IRC 6320, Notice and opportunity for hearing upon filing of notice of lien.

06. IRC 6330, Notice and opportunity for hearing before levy.

07. IRC 6331, Levy and distraint.

08. IRC 6672, Failure to collect and pay over tax, or attempt to evade or defeat tax.

09. IRC 7122, Compromises.

10. IRC 7213, Unauthorized inspection of returns or return information.

11. IRC 7521, Procedures involving taxpayer interviews.

12. 26 CFR 601.106, Ex Parte Communications Between Appeals and Other Internal Revenue Service Employees.

13. 31 USC Section 3302, Custodians of money.

14. 31 USC Chapter 53, Monetary Transactions.

15. Equal Employment Opportunity Commission (EEOC) Management Directive 715 (MD-715).

16. SB/SE Collection Functional Delegation Orders.


**1.4.53.1.3** **(07-17-2025)**

#### Roles and Responsibilities

1. The Director, Collection Policy, is the executive responsible for the policies to be employed by collection personnel.

2. CEASO group managers, territory managers and director are responsible for ensuring compliance with the guidance and procedures described in this IRM.

3. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see https://www.irs.gov/taxpayer-bill-of-rights, Taxpayer Bill of Rights (TBOR).


**1.4.53.1.4** **(07-17-2025)**

#### Program Management and Review

1. In order to properly manage CEASO workload, a manager must be familiar with, and use, productivity, inventory control, quality and customer satisfaction reports to monitor the quality and timeliness of case processing. This IRM provides information on many of those reports in _IRM 1.4.53.4_, Role of the CEASO Manager and _IRM 1.4.53.6_, CEASO Groups and Workload. It is the manager’s responsibility to ensure that data reflected in the group reports is accurate.



### Note:



For additional information on managing a group see IRM 1.4.50, Collection Group Manager, Field Compliance Manager and Area Director Operational Aid.

2. Program effectiveness - Operational and program reviews are conducted to ensure that program delivery and case actions are in accordance with administrative and compliance requirements. National quality and consistency reviews are routinely conducted to ensure program consistency and effectiveness in case processing.


**1.4.53.1.5** **(07-17-2025)**

#### Program Controls

1. Managerial approval of certain case actions by group managers, territory managers and directors ensure compliance with the procedural requirements.

2. ICS is used by Field Collection employees as a method for inventory control and history documentation.

3. ENTITY, ICS and ATFR are utilized by managers for inventory control and appropriate time utilization. Establish appropriate controls for non-IDRS cases (other investigations). Any negative trends should be addressed on an employee-by-employee basis.

4. Managers are required to follow program management and procedures addressed in this IRM. Additionally, managers are required to follow IRM 1.4.50, Collection Group Manager, Field Compliance Manager and Area Director Operational Aid.


**1.4.53.1.6** **(07-17-2025)**

#### Terms and Acronyms

1. This table shows the commonly used acronyms listed in this IRM and their definition:




| Acronym | Definition |
| :-: | :-: |
| AO | Area Office |
| ACR | Advisory Consolidated Receipts |
| AGM | Acting Group Manager |
| ASED | Assessment Statute Expiration Date |
| ATFR | Automated Trust Fund Recovery |
| BU | Bargaining Unit |
| CJE | Critical Job Element |
| CLP | Career Learning Plan |
| CPM | Control Point Monitoring |
| CSED | Collection Statute Expiration Date |
| CTRS | Collection Time Reporting System |
| DOJ | Department of Justice |
| EOM | End of Month |
| EPF | Employee Personnel File |
| EQ | Embedded Quality |
| EQRS | Embedded Quality Review System |
| FCM | Field Compliance Manager |
| FDCPA | Fair Debt Collection Practices Act |
| FOIA | Freedom of Information Act |
| GM | Group Manager |
| ICS | Integrated Collection System |
| IAR | Independent Administrative Reviewer |
| IDRS | Integrated Data Retrieval System |
| LAMS | Litigation Account Management System |
| LR | Labor Relations |
| MAAG | Month At A Glance |
| NFOI | Non-Field Other Investigation |
| NBU | Non-Bargaining Unit |
| NQRS | National Quality Review System |



|     |     |
| --- | --- |
| NTEU | National Treasury Employees Union |
| OAR | Operations Assistance Request |
| OI | Other Investigation |
| OIC | Offer in Compromise |
| PALS | Property Appraisal Liquidation Specialist |
| PII | Personally Identifiable Information |
| POD | Post of Duty |
| RACS | Revenue Accounting Control System |
| TAS | Taxpayer Advocate Service |
| TFRP | Trust Fund Recovery Penalty |
| TM | Territory Manager (CEASO) |
| UNAX | Unauthorized Access |
| USR | Unit Security Representative |


**1.4.53.1.7** **(07-17-2025)**

#### Related Resources

1. Additional resources can be found in:




| Additional Resources |
| --- |
| IRM 1.4.1, Management Roles and Responsibilities |
| IRM 1.4.50, Collection Group Manager, Field Compliance Manager and Area Director Operational Aid |
| IRM 1.5.2, Remittances, Form 809, and Designated Payments |
| IRM 5.1.3, Safety, Security and Control |
| IRM 5.1.10, Taxpayer Contacts |
| IRM 5.1.12, Cases requiring Special Handling |
| IRM 5.1.23, Taxpayer Representation |
| IRM 5.2.1, Collection Time Reporting |
| IRM 5.2.4, Collection Reports |
| IRM 5.3.1, ENTITY Case Management System |
| IRM 5.13.1, Embedded Quality Collection Field Organizations Administrative Guidelines |
| IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non-Bargaining Unit Employees Assigned to Critical Job Elements (CJEs) |
| IRM 6.432.1, Addressing Poor Performance |
| IRM 6.451.1, Policies, Authorities, Categories, and Approvals |
| IRM 6.751, Discipline and Disciplinary Actions |
| IRM 6.800.2, Employee Benefits, IRS Telework Program |
| IRM 10.8.34, IDRS Security Controls |
| IRM 25.1.8, Fraud Handbook, Field Collection |
| Document 11678, National Agreement - Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU) |
| Document 12990, Records Control Schedules |
| Document 11043, RRA ‘98 Section 1203 All Employee Guide |
| Document 11678, National Agreement with NTEU |
| Document 12739, Embedded Quality Advisory - Lien and Core Job Aid |
| Document 12741, Embedded Quality Advisory Function Estates Job Aid |
| Document 12744, Embedded Quality PALS - Property Appraisal & Liquidation Specialists Job Aid |
| Document 12746, Embedded Quality Advisory - Litigation Job Aid |
| Document 13136, Embedded Quality Advisory Tax Examiner Job Aid |
| Document 14510, Advisory Independent Administrative Review (IAR) Embedded Quality Job Aid |

2. Helpful information can be found on the following websites:




| Web Resources |
| --- |
| SERP |
| Interim Guidances |
| Critical Job Elements |
| Embedded Quality |
| UNAX |
| Delegation Orders |
| Human Capital Office |
| Telework |
| Section 1203 and Non-1203 Misconduct |
| Managing Employees |


**1.4.53.2** **(07-17-2025)**

### Administrative Guidelines for Managers

1. General administrative guidelines for all IRS managers are found in IRM 1.4.1, Resource Guide for Managers, Manager Roles and Responsibilities.

2. Keep in mind that internet and intranet websites contain the most up-to-date information. IRM 1.4.1.14, Quick Links to Useful Web Pages for Managers, is especially helpful. It provides links to useful websites where managers can find guidelines and instructions to do their jobs. A few of the many helpful sites are shown below:



1. The IRS Source home page provides the starting point of research: IRS Source.

2. The iManage website contains targeted information, advice and interactive features to help the manager work more efficiently: iManage.

3. Mandatory briefings provide information on the delivery of mandatory employee briefings: Integrated Talent Management (ITM).



      ### Note:



      Encourage employees to utilize the Integrated Talent Management (ITM) site to take the briefings. ITM automatically updates their learning history as they finish each briefing and you can track their progress.


3. Group managers are responsible for the oversight of certain administrative functions for their employees including but not limited to:



1. Maintenance of time and attendance records,

2. Certifying overtime records,

3. Approving scheduled and unscheduled leave,

4. Controlling and approving travel,

5. Maintaining safe working conditions,

6. Holding group meetings on a regular basis,

7. Keeping employees current on all applicable policies and procedures.


4. For additional information, see IRM 1.4.1.3, Administrative Responsibilities and all sections in IRM 1.4.50.3, General Managerial Responsibilities.


**1.4.53.3** **(07-17-2025)**

### General Managerial Responsibilities

1. Managers are responsible for ensuring that their personnel comply with IRS privacy and security policies and procedures to protect the confidentiality of sensitive but unclassified (SBU) data, including personally identifiable information (PII) and tax information to prevent the unauthorized access to, or destruction of, IRS files and ensure that any customer comments/complaints are properly recorded and addressed. See IRM 10.5.1, Privacy Policy for more information.


**1.4.53.3.1** **(07-17-2025)**

#### IDRS and ICS Security

1. Group managers are responsible for ensuring their employees have access to the IDRS command codes necessary to perform their assigned tasks and required research. Managers coordinate IDRS security with their assigned Unit Security Representative (USR), otherwise known by their organizational title: Data Security Analyst (DSA). See IRM 5.1.25.2, IDRS Security Personnel, for more information.

2. IDRS security should be reinforced through discussions at group meetings.

3. Employees should be encouraged to complete Form 11377, Taxpayer Data Access, when access to taxpayer data is not supported by direct case assignments, when access is performed in error or may otherwise raise a suspicion of an unauthorized access.

4. IRM 10.8.34, IDRS Security Controls, states the manager of IDRS users shall be responsible for day-to-day implementation and administration of IDRS Security. In SB/SE Collection Operations, primary responsibility for IDRS security, rests with Collection Automation Support and Security (CASS) and the IDRS Data Security Group.



1. Managers must approve all requests to add command codes to the unit or user’s profile.

2. Managers may be contacted by a CASS representative if they are unable to resolve a potentially questionable access made by their employee.

3. When contacted by CASS, the manager should take appropriate action to determine the business reason for the access. Actions may include: conversations with the employee, review of inventory records, review of IDRS case controls, review of IDRS Online Reports Services (IORS) queries, review of IDRS audit trails, etc.

4. The manager should then provide feedback to CASS within five business date of their request.


5. Resources:



   - IRM 10.8.34, IDRS Security Controls.

   - IRM 5.1.25, IDRS and Data Security for Collection.

   - Form 11377-E, Taxpayer Data Access.

   - UNAX.


6. Managers may review the ICS report of acting group manager activity to screen for inappropriate accesses.


**1.4.53.3.2** **(07-17-2025)**

#### Managing Employees using Telework, in Remote Locations, and/or Multiple Posts of Duty

1. Telework is a program that permits your employees to work at home or at other approved locations remote to the assigned post-of-duty (POD) in limited circumstances. See iManage Telework Program for telework guidance and resources.

2. Remote/Multiple POD Groups:



1. Some groups have employees in remote PODs in the same commuting area. Other groups consist of PODs in several states. While each present unique challenges, both are similar to managing employees on telework.

2. The needs of remotely managed employees are the same as those working on telework. In addition to telework needs, the manager should have a basic understanding of each POD. This includes security, travel, mail, other personnel and available equipment. Support for supplies may or may not be an issue.

3. Set up systems to ensure the employee can effectively and timely process case work. Some methods include: approvals done via email or fax, use of electronic signatures where appropriate, virtual meetings for training and assistance, and conference calls or virtual meetings to include employees in group decisions.

4. Team building is especially important to create a cohesive working unit.


3. Resources:



   - IRM 6.800.2, Employee Benefits, IRS Telework Program.

   - IRS Telework Portal.

   - IRM 1.4.50.6.1, Managing in a Telework Environment.

   - IRM 10.5.1.6.12, Telework

   - Privacy, Governmental Liaison and Disclosure.


**1.4.53.3.2.1** **(10-04-2019)**

##### Customer Service and/or Remote Employees

1. The manager is responsible for ensuring employees in the office, on telework, or in remote PODs should all maintain the same level of service regardless of location.

2. This includes guidance concerning timely responses to telephone calls, emails, and mail.

3. Managers and employees should check voice mail, and email several times a day to ensure timely responsiveness. Managers should periodically check the outgoing voice mail messages of their employees to ensure they are correct.

4. The group manager has the right to direct a telework employee to report to their assigned POD when necessary.

5. Timely processing of remittances and mail should be considered in planning with off-site staff.

6. Other areas of consideration:



   - back-up for absences to ensure that time sensitive items such as remittances are timely processed,

   - out-going message language,

   - local support for supplies and mail,

   - information exchange.


**1.4.53.3.3** **(10-04-2019)**

#### Outreach

1. CEASO Advisory provides technical and educational support to other IRS functions through its internal outreach programs. This support enables all IRS caseworkers to make appropriate collection or assessment determinations on a wide variety of collection work.

2. CEASO Advisory managers and staff can maintain an effective dialogue with stakeholders such as Area Counsel, TAS, Governmental Liaison, and US/DOJ attorneys, by attending forums, conferences, and workshops on advisory related issues.

3. Managers and their employees may impact tax law compliance if they attend various types of practitioner association meetings or trade associations (title companies, accounting organizations etc.). These venues can be used to acquaint practitioners with Advisory’s policies and procedures, particularly issues regarding lien certificates.


**1.4.53.3.4** **(07-17-2025)**

#### Advisory Review and Trend Analysis

1. Form 5942, Reviewer’s Report, is an important tool in the Advisory review process. Form 5942 is used to provide commendatory comments, request additional information to clarify case issues or provide guidance, request corrective action by the originator, make casework quality observations to management, and to furnish information for field collection trend analysis.

2. CEASO Advisory group managers will submit Form 5942 issued during each quarter to their territory manager. The CEASO Advisory territory managers will submit an analysis of trends identified to the CEASO Director. The CEASO Director then issues a trend analysis memorandum(s) to the appropriate Field Collection Area Director(s).


**1.4.53.3.5** **(07-17-2025)**

#### Direct Contact With Taxpayers With Or Requesting Representation

1. You are reminded to take steps to ensure that your group is in conformance with IRC 7521, Procedures Involving Taxpayer Interviews. Specifically, your employees are required to:



1. Stop the interview with a taxpayer (unless required by court order) whenever a taxpayer requests to consult with a representative (e.g. certified public accountant, attorney or enrolled agent, who is permitted to represent taxpayers before the IRS),

2. Obtain your approval to contact the taxpayer instead of the representative, if the representative is responsible for unreasonably delaying the completion of a collection action. See IRM 5.1.23.6, By-Passing a Taxpayer’s Authorized Representative, for a more detailed discussion of bypass criteria and procedures.


2. Vehicles that you can use to communicate your expectation for compliance by your employees are:



   - Group meetings,

   - Case reviews,

   - Workload reviews,

   - Office visitations with remote employees,

   - Taxpayer/representative inquiries (if necessary).


3. A taxpayer or representative may request to use audio or video equipment to record an in-person interview. See IRM 5.1.12.3, Recording Taxpayer Interviews, for information on responding to such requests.


**1.4.53.3.6** **(10-04-2019)**

#### Time Reporting and Case Matrix

1. Managers and employes should use Time Reporting Codes as shown in IRM 5.2.1-6, Time Code Matrix for CEASO and PALS.


**1.4.53.3.7** **(10-04-2019)**

#### Integrated Data Retrieval System (IDRS)

1. Resources include Document 6209 , _IRS Processing Codes and Information_; IRM 2.3, IDRS Terminal Responses; IRM 2.4, IDRS Terminal Input and IRM 5.1.25, IDRS and Data Security for Collection.

2. IDRS Units:



1. CEASO IDRS units are kept separate from other work groups, such as Insolvency or Field Collection groups.

2. To consolidate groups, or move employees between groups, the assigned Data Security Analyst (DSA) must be contacted in advance of the effective date.


3. Sensitive Command Codes:



1. A command code is considered sensitive if it can be used to adjust account balances, change the status of a tax module or account, or affect the tax liability.

2. Sensitive command code combinations give an employee the ability to perform more than one type of transaction where the intentional mishandling of a taxpayer’s account may occur (e.g., change the entity or address information of an account and transfer payments).

3. Where sensitive command codes are required to perform assigned duties, the group manager is responsible for ensuring sufficient internal controls are in place to minimize risk of inappropriate actions.


**1.4.53.4** **(07-17-2025)**

### Role of the CEASO Group Manager

01. CEASO is comprised of Advisory, Independent Administrative Reviewer (IAR), Property Appraisal and Liquidation Specialist (PALS), and Estate Tax Liens.

02. As a group manager, you are charged with training, evaluating, and counseling your employees to produce consistent quality work. To ensure consistent quality, you must provide oversight and direction in a number of areas, which will result in accomplishing the mission of the Internal Revenue Service. Your oversight responsibilities include, but are not limited to:




    | CEASO Group Manager Responsibilities |
    | --- |
    | Creating and maintaining a work environment that will promote teamwork, positive working relationships, and increased employee satisfaction |
    | Issuing the Critical Job Elements (CJE) timely in accordance with the current National Agreement and evaluating employees’ performance against their CJEs<br> <br>### Note:<br>Use Form 6774, Receipt of Critical Jobs Elements and Retention Standard, to document review annually or when CJEs change. |
    | Ensuring cases are assigned timely and employee workload:<br> <br>    - Reflects current priorities,<br>      <br>    - Reflects employee experience and skill level,<br>      <br>    - Addresses Servicewide objectives,<br>      <br>    - Protects public interest, and<br>      <br>    - Allows for effective case processing. |
    | Ensuring employees maintain high standards of professionalism in all their contacts with the public, internal customers, and coworkers |
    | Ensuring employees observe taxpayer rights |
    | Ensuring employee case actions are timely and in accordance with current law, policies, and procedures |
    | Ensuring employees are accountable for the appropriateness of their actions |
    | Providing ongoing employee feedback that is candid and meaningful and will establish a basis for determining an accurate assessment of performance and developmental needs |
    | Ensuring employees have necessary functioning equipment and supplies |
    | Ensuring employees are aware of ongoing changes to the laws, policies, and procedures that relate to their responsibilities (in a way that ensures understanding-group meetings, emails, conference calls etc.) |
    | Addressing systems issues that impact either internal or external customer needs |
    | Taking a proactive role in the time and inventory reporting process by overseeing and ensuring that the group's monthly time and inventory data is accurate and timely. A weekly review of employee end of day (EOD) requirements in ICS is imperative to ensure month-end processing is accurate |

03. You are an advocate for your employees. Help them to achieve their career objectives by remembering:



    - Clearly shared objectives, expectations, and standards are a must.

    - Intermediate goals must be set, shared, and monitored.

    - Small successes build confidence.

    - Identifying, planning, and monitoring of employee needs and their development requires open communication.

    - Your direct involvement and ongoing attention are essential to the enhancement of your employees’ skills and career advancement.


04. Remember, a group manager is only as effective as the employees in the group. It stands to reason, you need to assist in your employee’s development by:



    - encouraging and appreciating excellence;

    - creating a climate of support, encouragement, recognition, and team spirit;

    - remaining flexible and resourceful.


05. As a manager, you are empowered and expected to address performance concerns within your group. This may be accomplished through reviews and/or by requiring your concurrence with performing specific actions. Prompt corrective action may be necessary.



    ### Note:



    For additional direction regarding performance issues see IRM 1.4.50-5, Suggested Action Steps For Unacceptable Performance.

06. When a new group is established, or a new manager is assigned to an existing group, a meeting with the employees must be held within the first 30 days. At this meeting, the manager will communicate expectations about the following suggested topics:



    - Group procedures - leave approvals, credit hours, reports, and related topics,

    - Case work,

    - Use of time - office/telework,

    - Timeliness of case activity,

    - Timeliness of phone response to internal and external customers,

    - Reasonable time frames for case actions (See IRM 5.1.10.3.1 and IRM 5.1.10.9 for Initial Contact Time Frames and Timely Follow-Ups),

    - Case review schedule.


### Note:

These expectations should also be reviewed at the beginning of each fiscal year. This meeting is considered a 7114 meeting. See the Federal Service Labor-Management Relations Statute, 5 U.S.C. Section 7114. Local National Treasury Employees Union (NTEU) chapter(s) must be notified of the meeting in accordance with Article 8, Union Rights, of the current National Agreement.

07. When a new employee is assigned to an existing group, the group manager must meet with the new employee to discuss managerial expectations (see (6) above) and ensure appropriate BEARS requests are completed and processed.



    ### Note:



    This meeting is considered a 7114 meeting. See the Federal Service Labor-Management Relations Statute, 5 U.S.C. Section 7114. Local National Treasury Employees Union (NTEU) chapter(s) must be notified of the meeting in accordance with Article 8, Union Rights, of the current National Agreement.

08. Regular group meetings will be held as necessary to review items such as the following:



    - Directives from the territory manager, Director of CEASO,

    - Procedural memoranda,

    - IRM changes,

    - Case resolution techniques,

    - Changes in condition of employment,

    - Automation issues,

    - Certain mandated topics not available on other media,

    - General group (employee) concerns.


### Note:

Regular group meetings are not ordinarily considered 7114 meetings. The union entitlement arises when there is a discussion of a personnel policy, practice or other general condition of employment. For example, a discussion at a group meeting on the need to make timely Trust Fund Recovery Penalty (TFRP) determinations or how to handle a particular type of case would not ordinarily be considered 7114 issues. Managers should seek guidance and advice from their servicing Labor Relations Specialist if they are unsure whether an agenda item for a group meeting constitutes a 7114 issue. Article 8 Section 1 of the current National Agreement also provides guidance on 7114 Meetings.

09. You are responsible to review time reporting by your employees to ensure accuracy. A technique in accomplishing this task is to ensure timely and accurate monthly reporting. Refer to IRM 5.2.1, Collection Time Reporting, for more information. Also, be alert for excessive administrative or inappropriate direct time.

10. You must also oversee group remittance processing activities, including monitoring Form 5919, Teller’s Error Advice, sent to your group. See IRM 5.1.2.5.6, Responding to Form 5919, and IRM 1.4.50.11.1, Financial Controls, Remittance Control Reviews.


**1.4.53.4.1** **(10-04-2019)**

#### Performance Evaluations

01. Preparing performance evaluations is one of your most important responsibilities. In carrying out this duty, you will observe how the employees are performing their duties and responsibilities to ensure that they are working efficiently and effectively to accomplish assigned tasks.

02. Because you are responsible for implementing the policies and directives relative to performance evaluations, you should thoroughly familiarize yourself with all facets of performance appraisal/evaluation information such as:



    1. Performance expectations,

    2. Mid-year and periodic performance reviews,

    3. Annual ratings,

    4. Acceptable level of competence,

    5. Unacceptable/minimally successful performance,

    6. Competitive promotion appraisals,

    7. Employee performance files (EPFs),

    8. Performance and recognition awards.


03. Embedded Quality (EQ) is the primary tool for recording case reviews. See _IRM 1.4.53.4.8_. Follow the procedures outlined in the EQ job aids for the particular program areas to be reviewed. The summary entries from the EQ reviews may serve as a basis for the employee performance reviews.

04. See IRM 6.430, Performance Management Program, for additional information.

05. A formal performance evaluation serves:



    1. As a record of performance to support, recommend, and initiate actions such as, but not limited to, within-in grade increases, promotion/merit promotion, award recommendations, reassignments, details, and various adverse actions such as demotion or separation;

    2. To provide an employee with a basis for additional training and development;

    3. To improve the performance of individual employees.


06. For employees new to the government, the first year of employment is a probationary period during which every new employee must demonstrate successful performance and the capability to be promoted to the next grade level (if applicable). See IRM 6.430.2.4.3, Employees Serving Probationary Periods.

07. Documentation of Performance:



    1. Providing positive and constructive feedback to the employee is essential to maintaining and improving the performance of each and every employee.

    2. Keep an employee's overall performance in mind when you discuss work and other activities. Let them know when some aspect of performance may influence their performance rating, a promotional opportunity, or other personnel action.

    3. Recordation serves as a snapshot of employee performance. Adequate documentation will remind you of changes in performance over the rating period.


08. Performance evaluations provide a uniform means for a written evaluation and rating of each employee's proficiency. IRM 1.5, Managing Statistics in a Balanced Measurement System and IRM 6.430.2, Performance Management, provide specific guidance.

09. Formal employee evaluations represent the sum of what you have observed in each employee's work, using feedback, reviews, visitations to POD and other techniques discussed in this manual.

10. Each employee will receive an annual performance evaluation. See appropriate sections in current National Agreement, Article 12.

11. Employees may submit a self-assessment limited to four (4) pages in length no later than the last workday of his or her annual appraisal rating period. See IRM 6.430.2.4.5, Self Assessments and IRM 6.430.2.6(3), Conducting the Performance Appraisal Meeting.

12. For information on the suggested steps to follow to make unacceptable performance determinations, see IRM 1.4.50-5.

13. Resources:



    1. The Performance Management website provides the CJE Resource Center, Manager’s Guide for Employee Performance, Performance Awards Information, forms, etc.

    2. National Agreement with NTEU: Document 11678, Articles 7, 12, 17,18 and 40.

    3. IRM 1.4.1, Resource Guide for Managers, Management Roles and Responsibilities.

    4. IRM 6.430.2.3.3, Acknowledging Decreased Work Performance.

    5. IRM 6.451, Employee Recognition.

    6. IRM 6.432.1, Addressing Poor Performance.

    7. Other portions of IRM Part 6, Human Resources Management.

    8. The Labor Relations Specialist.


**1.4.53.4.2** **(10-04-2019)**

#### Discipline and Disciplinary Actions

1. Discipline is defined as measures taken by management that are intended to correct employee misconduct, and encourage employee conduct in compliance with standards of conduct, policies, goals, work procedures, and office practices of the IRS and the Federal Service. Employees must adhere to all known conditions and standards of conduct established to provide for the orderly and efficient administration of the Internal Revenue Service.

2. Employees who fail to comply with standards of conduct, work procedures, and/or office practices may be subject to disciplinary action designed to correct the violation and motivate the employee to become a productive member of the Internal Revenue Service.

3. You are responsible for establishing and maintaining effective discipline within your work group. You must explain the work requirements and other standards your employees are expected to meet.

4. When disciplinary action is required, it must be fair, equitable, impartial and as timely as possible.

5. Ensure that you discuss and coordinate all proposed disciplinary actions with your Labor Relations Specialist.

6. You may also refer to: IRM 6.751, Discipline and Disciplinary Actions and IRM 6.752, Disciplinary Suspensions and Adverse Actions. A guide to assist you in determining appropriate penalties to correct improper conduct can be found in IRM 6.751.1-1, Internal Revenue Service Guide to Penalty Determinations.

7. Information is also available from the National Agreement, Articles 38 and 39.


**1.4.53.4.3** **(07-17-2025)**

#### Recognitions and Awards

1. Awards are opportunities for group managers to recognize and reinforce positive performance and behavior.

2. You are responsible for maintaining a working knowledge of the awards process.

3. Complete information regarding awards is found on the iManage website at: iManage Awards and Recognition Programs.

4. Resources:



1. IRM 1.4.1.8.3, Recognition and Awards.

2. IRM 6.451.1, Policies, Authorities, Categories and Approvals.

3. National Agreement, Article 18.


**1.4.53.4.4** **(10-04-2019)**

#### Employee Performance File (EPF) and Drop File

1. An EPF is a required file for each of your employees.

2. You are responsible for assuring the effective use of the EPF by:



1. Ensuring that the proper documents are included in each EPF. See IRM 6.430.2.3.5, Employee Performance File.

2. Ensuring that filing and purging of performance related documents and records are in compliance with requirements, see (7) below.

3. Keeping all performance records and documents secured.

4. Forwarding EPF records of employees transferring to other Treasury Bureaus or to a different post of duty or manager within the IRS.


3. Form 6774, Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayer Retention Standard, is maintained in EPF. You must update the form annually and ensure it is signed and dated. See IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers.

4. Recordation is defined as a manager's written record evaluating an employee in a positive or negative manner. For Bargaining Unit (BU) employees, a recordation must be furnished to an employee within fifteen (15) workdays of the time the manager becomes aware, or should have been aware of the event that it addresses. If it is not furnished within fifteen (15) workdays it cannot become part of the EPF.

5. Electronic signatures may be used on Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request, processed through HR Connect; however, paper copies of the form must be maintained in the EPF.

6. The EPF is maintained in addition to, and separate from, the Employee Drop File. The Employee Drop File is a second file for other documentation not related to performance including training records, completion of briefings, telework agreements, and other documents that should be kept regarding the employee. For more information refer to: IRM 1.4.1.8.5, Employee Performance File.

7. For additional information regarding the specific items to be placed in the EPF and the retention period, you can refer to:



1. Human Capital Office website at: Human Capital Office,

2. National Agreement, Article 12.

3. IRM 6.430.2.3.5, Employee Performance File (EPF).

4. HR Connect.

5. The Labor Relations Specialist at: Labor/Employee Relations & Negotiations Contacts.

6. Refer to Document 12829, General Records Schedule (GRS) 2.2, item 70 for the National Archives and Records Administration (NARA)-issued guidance on the EPF must be maintained for four (4) years, but longer retention is authorized if required for business use.


**1.4.53.4.4.1** **(07-17-2025)**

##### Employee Development/Training

1. See IRM 1.4.1.6, Employee Development, for a full discussion of your responsibilities.

2. Group manager roles and responsibilities in the area of employee development and training include but are not limited to:



1. Overseeing orientation of new employees.

2. Overseeing training for new employees (formal and on-the-job).

3. Training and developing other employees including professional/technical and clerical staff.

4. Assisting and advising employees preparing a Career Learning Plan (CLP).

5. Delegating acting managerial assignments.

6. Continuing education for employees to maintain and update knowledge and proficiency in technical areas.

7. Providing opportunities such as details to facilitate career development.

8. Ensuring employees having a working knowledge of tools to perform their duties (e.g., ICS, ATFR, ALS, etc.)


3. You can find more information at the iManage website, which includes information on:



   - Servicewide training and briefing programs,

   - Policy and procedural guidance,

   - Other employee development resources.


4. For your BU employees, you can find more information in the National Agreement and iManage website.


**1.4.53.4.4.2** **(07-17-2025)**

##### Group Manager Development

1. Attainment of your career objectives is a shared responsibility between you and your territory manager. Look for guidance in developing your own goals and direction.

2. Increased responsibility, advancement, and job enrichment should continue throughout your career. The support of your territory manager is vital to your career development and advancement. You should develop and fully utilize a Career Learning Plan (CLP). Managerial career planning requires goals, actions, and commitment.

3. The following presents an overview of some collateral duties which you may be called upon to handle:



   - Classroom Instructor,

   - Commissioner's Representative,

   - Recruiter,

   - Task forces,

   - Continuing Professional Education (CPE) committee,

   - Program Review or Implementation.


4. For more information on establishing a Career Learning Plan, see the Career Management Resource Center.


**1.4.53.4.4.3** **(07-17-2025)**

##### Group Manager With Approved Pseudonym

1. Group managers with an approved IRS pseudonym may have a need to sign sworn or notarized documents.

2. Sworn documents and/or any other document filed with any court, including, but not limited to, notarized documents or affidavits used in connection with enforcing summonses and obtaining writs of entry, may only be signed with the approved IRS pseudonym if the document states that it is "signed using an IRS pseudonym" . Absent such a statement, the document must be signed using the declarant's legal name and must be filed with the court as a sealed document.

3. The signing of sworn documents or any other document filed with any court using an IRS pseudonym will require close coordination with the appropriate Chief Counsel office. See IRM 10.5.7.9, IRS Pseudonym Holders, the Courts and Legal Matters.


**1.4.53.4.4.4** **(07-17-2025)**

##### Acting Group Manager Assignments and Designations

1. You must formally designate an acting group manager (AGM) during your periods of absence. Use must Form 10247, Designation to Act to appoint an acting group manager for a period of one full day or longer. The form must identify the person appointed, the period of the appointment and a general description of the tasks the AGM is authorized to perform. For AGM appointments of less than one business day, an email may be substituted for the Form 10247. The email must contain the same information as the Form 10247 described above. The email or Form 10247 must be distributed to the appointed employee, the other employees in the group, and the GM’s territory manager. Place a copy of the Form 10247 or email (if appropriate) in the appointed employee’s drop file.

2. A general description of the tasks the AGM is authorized to perform assignments should be agreed on between you and the acting manager in advance. Specific expectations should be given at the beginning of each assignment.

3. Utilize discretion to determine if it will be necessary to adjust the AGM’s inventory during extended designation periods. You should also discuss any cases which may need to be re-assigned during the designation period to ensure timely actions are taken on cases which involve issues which could cause permanent loss to the government.

4. Determine which managerial tasks are to be performed by the AGM and which tasks will be deferred until your return. Refer to the National Agreement (Document 11678) for certain restrictions on performance evaluations ( i.e. The employee’s performance must have been observed under a signed performance plan for at least 60 days to be ratable under Article 12.)

5. You may designate certain tasks when you are not absent as a developmental assignment to employees who indicate managerial aspirations. In these instances, no formal designation exists, therefore, tasks reserved to managers **cannot** be delegated. These tasks include but are not limited to:



   - Case related managerial approvals

   - Supervisory conferences related to an appeal filed by the taxpayer or taxpayer’s authorized representative

   - Approval of leave for other members of the group

   - Approval of travel authorizations or vouchers


**1.4.53.4.5** **(07-17-2025)**

#### Working with NTEU

1. Group Managers who supervise bargaining unit (BU) employees must:



1. Notify the requisite NTEU chapter(s) regarding 7114 meetings when you plan to discuss with your employees changes in personnel policies, practices, and working conditions. Generally, no less than five workdays advance notice is provided. See Article 8 of the National Agreement for more information about how to identify 7114 meetings. Remember that employees in differing PODs may be represented by different NTEU chapters.

2. Make sure employees have the opportunity to be represented at formal discussions regarding employee grievances, other personnel matters, and conduct issues.


2. For additional information, see IRM 1.4.1.4, Agreements with NTEU, or contact your Labor Relations Specialist at: Labor/Employee Relations & Negotiations Contacts.


**1.4.53.4.6** **(10-04-2019)**

#### CEASO Advisory Workload Management

1. You are responsible for effectively managing the group's workload. To accomplish this you must:



1. Assign cases based on the type of work,

2. Ensure priority cases are worked in a timely manner,

3. Ensure case activity is progressing toward resolution, including fraud identification,

4. Maintain inventory levels and make adjustments as appropriate,

5. Balance inventories within your group.


**1.4.53.4.6.1** **(10-04-2019)**

##### CEASO Advisory Inventory Assignment

1. Cases are assigned as Non Field Other Investigations (NFOIs) on ICS and the case grade is entered on the ICS record for each case. Generally, cases are graded GS-12, but can vary for Tax Examiners 5/6/7 and GS-13 Advisors.

2. CEASO Advisory Non Field Other Investigations (NFOI) cases are assigned. These case grade levels reflect the probable level of difficulty of the entity.

3. At this time there is no systemic means to deliver GS-13 CEASO Advisory work. All GS-13 case work will need to be identified.

4. You are responsible for reviewing and maintaining the levels of work.

5. If the case meets the criteria for a GS-13 case grade designation, the group manager will input a "13" in the first two positions of the LOCATION field on ICS. The group manager will document the case history with the basis for change in case grade.

6. Case grades are normally designated in the field. CEASO Advisory will generally follow these designations depending on the issue at hand. Seizure processing, TFRP processing, and Lien Certificates on non-complex property transactions are examples of when the field grade level may be different from that of the NFOI assignment.


**1.4.53.4.6.2** **(10-04-2019)**

##### Case/Program Rotation

1. Where feasible, give CEASO advisors and CEASO tax examiners additional experience by rotating program assignments or backing up other programs.


**1.4.53.4.6.3** **(10-04-2019)**

##### Assigning Work

1. You are responsible for ensuring that cases are assigned. An appropriate mix of cases (NFOIs) should be assigned to employees. Groups can use many ways to determine program splits. Assignments should be made from inventory received in the group.

2. Review your employee inventory reports monthly to ensure balance is kept between advisors and the programs they work. Some factors to consider in this review:



1. High priority cases had to be assigned to an employee below his/her grade level,

2. There would be an unacceptable delay in working the cases if you reassigned them to other employees,

3. There is a need to maintain continuity of contact with the taxpayer,

4. The employee is in a one-person post of duty,

5. The employee needs or requests a higher-level case for developmental purposes.


**1.4.53.4.6.4** **(08-20-2010)**

##### Reassignment of Departing Employee Inventory

1. Where inventory will be abandoned for periods of 90 days or more (an employee is reassigned, on extended leave, or long term detail) the group manager is responsible for taking case management actions as follows:



1. High profile or short time frame cases that can't be concluded timely should be reassigned.

2. The group manager will review with the departing employee all inventory and determine, (1) those cases which can be resolved prior to the employee leaving, (2) inventory that should be reassigned to the remaining employees in the group. The transfer of these cases should be completed within a reasonable period of time, normally within 45 days.


**1.4.53.4.6.5** **(10-04-2019)**

##### CEASO Advisory Case Assignment Guide

1. Group managers are responsible for monitoring the assignment of case work to ensure cases are assigned to the appropriate employee.

2. An assignment guide establishes advisor program duties by the parameters established within the group. The format may be determined by the manager or territory and generally contains contact information as well as a listing of programs by assigned advisor.

3. The assignment guide should be updated as changes occur and made available to the group and to internal customers including Field Collection, TAS, Insolvency, Area Counsel, etc. on a regular basis.

4. This assignment guide will be used to update various IRS Source references.

5. The CEASO Advisory case types and the geographical area covered should be listed as well as the mailing address, phone, and fax of the employees in the group.


**1.4.53.4.6.6** **(10-04-2019)**

##### CEASO Advisory Managerial Reports

1. In order to properly manage your workload, a CEASO Advisory group manager must be familiar with, and use, productivity, inventory control, quality, and customer satisfaction reports to monitor the quality and timeliness of case processing.

2. Additional information on reports can be found in IRM 5.2, Collection Reports, ICS User Guide, ENTITY User Guide, ATFR User Guide, Document 6209, IRS Processing Codes and Information and web pages on IRS Source.

3. It is your responsibility to ensure that data reflected in the group reports is accurate. Timely review the reports at month end or as required to ensure corrective actions are properly addressed.

4. There are several reports that you are required to utilize that are discussed elsewhere. Some of these reports are:



1. Time and Attendance (SETR),

2. Embedded Quality (EQ),

3. Litigation Account Management System (LAMS),

4. Integrated Data Retrieval System (IDRS) Access,

5. Month at a Glance (MAAG),

6. Customer Satisfaction Survey,

7. Seizure Controls & RACS 135 Report,

8. Overage Unpostable Control Base Report.


**1.4.53.4.6.6.1** **(07-17-2025)**

###### ICS Reports

01. ICS reports are useful to employees and managers to control inventory.

02. Managers should ensure that employees understand these reports and review reports at least monthly.

03. Open Inventory by Case Type (by employee or by group)



    1. This report lists open NFOI cases assigned in the group.

    2. The type of NFOI case is identified and each open case is listed.


04. Current Inventory Report by Case Type (available to employees only)



    1. This report lists open NFOI cases assigned in the group.

    2. This report is helpful for employees to identify NFOI cases that are assigned to them on ICS.

    3. Employees need to monitor their assignments to resolve any cases assigned that should not be retained in inventory.


05. ASED Report (available to employees only)



    1. This inventory report secures information from entries on the NFOI screen.

    2. The ASED field is used to manually enter the earliest ASED on some types of cases especially TFRP cases.

    3. The ASED report will list taxpayer cases by earliest ASED but will not capture this information if the ASED field on the NFOI screen is left blank.


06. CSED Report (available to employees only)



    1. This inventory report secures information from entries on the NFOI screen.

    2. The CSED field is used to manually enter the earliest CSED on cases.

    3. The CSED report will list taxpayer cases by earliest CSED but will not capture this information if the CSED field on the NFOI screen is left blank.


07. Closure Due Date Report (available to employees only)



    1. This inventory report secures information from entries on the NFOI screen.

    2. ICS automatically sets the closure due date to 45 days when opening an NFOI, unless the employee enters a different date.

    3. Advisory employees should use this field to assist in controlling inventory.


08. Notifications

09. Follow-ups

10. Monthly Inventory Report (by employee or by group)



    1. This report is available to each employee for their own inventory and to managers and secretaries for the group report.

    2. The group report is a feeder for the CTRS Monthly report.

    3. At the end of each reporting month, ICS generates a report of the prior month inventory by NFOI case type.




       | ICS Monthly Report includes: |
       | --- |
       | Opening Inventory |
       | Receipts |
       | Dispositions |
       | Ending Inventory |


**1.4.53.4.6.6.2** **(10-04-2019)**

###### ENTITY Reports

1. ENTITY is the workload management system for collection managers. ENTITY extracts and organizes information about case activity and casework quality from the Integrated Collection System (ICS).

2. CEASO Advisory managers do not have the full ENTITY Report menu available for Field Collection (FC) managers and time reporting by case is not active.

3. Advisory managers have a version of ENTITY that allows a manager to secure inventory information on open and closed NFOIs.

4. CEASO Advisory managers should familiarize themselves with IRM 5.3.1, ENTITY Case Management System.

5. Use ENTITY to:



1. Assist employees in managing their inventories,

2. Identify cases or types of cases where it appears the employee needs assistance.


6. You can use the automated features of ENTITY to select categories of cases for review, such as lien certificates, trust funds, statutes, time utilization reviews, etc. This will help you assist your employees to resolve their cases.

7. You can also use ENTITY to:



1. Generate a group inventory report,

2. Generate ad-hoc reports as necessary.


**1.4.53.4.6.6.3** **(10-04-2019)**

###### Automated Trust Fund Recovery Program Reports (ATFR)

1. CEASO Advisory managers have a number of screen sorts online to take a view of case status and to monitor ASEDs.

2. Control Point Monitoring (CPM) reports include pending Form 2749, Trust Fund Recovery Penalty Assessment, accepted Form 2749, Form 2749 to SC, and Appeals inventory sorts. See _IRM 1.4.53.4.6.8.3_, Monitoring Trust Fund Recovery Penalty (TFRP) for additional information.


**1.4.53.4.6.6.4** **(10-04-2019)**

###### Collection Time Reporting System (CTRS) Monthly Reports

1. CTRS software is available on the CTRS website at: CTRS Website.

2. Employees are responsible for inputting their time daily using the EOD function on ICS.

3. CEASO Wide Area Specialist (WAS) will upload all group files into CTRS for area consolidation.

4. The ICS Monthly Inventory Report is used to input group inventory receipts and dispositions by case type to CTRS.

5. Managers should review the report before final transmission.

6. See IRM 5.2.1, Reports, Collection Time Reporting, and CTRS website for additional information.


**1.4.53.4.6.7** **(10-04-2019)**

##### Seizure, Sale and Acquired Property Reports

1. Advisory is responsible for reports and records retention related to Collection actions taken on property.


**1.4.53.4.6.7.1** **(10-04-2019)**

###### Permanent Record Files

1. For all seizures conducted after July 22,1998, IRC 6340 requires each area director to maintain a permanent record of all sales conducted under IRC 6335 of real and personal property situated within his/her area and of all redemptions of such property. The PALS and the revenue officer will forward all appropriate records to Advisory for the seizure file and for the permanent record.

2. Original records should be maintained in the permanent record. For more information see IRM 5.10.6.12, Permanent Record of Sales

3. The permanent record files will be permanently retained by CEASO Advisory. For more information see IRM 5.10.6.13, Revenue Officer Transfer of Closed Case Files to Advisory and Advisory Records Retention.


**1.4.53.4.6.7.2** **(10-04-2019)**

###### Record 21, Record of Seizure and Sale of Real Estate

1. CEASO Advisory is responsible for preparing deeds and maintaining Records 21, Record of Seizure and Sale of Real Estate.

2. CEASO Advisory is also responsible for the public inspection files for Record 21. See IRM 5.10.6.13, Revenue Officer Transfer of Closed Case Files to Advisory and Advisory Records Retention.


**1.4.53.4.6.7.3** **(10-04-2019)**

###### Seizure Logs and RACS Accounting

1. One CEASO Advisory group in each territory will maintain the seizure log.

2. A seizure number will be assigned immediately after the seizure is made and the log will be used to track the entire seizure and sale process until the seizure is closed.

3. Advisory will notify Ogden Accounting Branch of each new seizure by processing Form 2433, Notice of Seizure, Part 7a. An entry will be established on the RACS 135 Report to monitor the receipt, disposition, and application of sale proceeds for assets under seizure.

4. Advisory will process Form 2433, Notice of Seizure, Part 7b or Form 2436, Seized Property Sale Report to close the RACS account.

5. There is a semi-annual physical inventory verification and reporting process. Additionally, there is a monthly report due for sale proceeds that remain unresolved after 90 days (see IRM 5.10.6.14, Seizures Open for Over 90 Days and Semi-Annual Verification of Form 2433).

6. The Chief Financial Office (CFO) requires that Collection provide a year-end balance of seized assets, acquired property, collateral property, and other property for inclusion in IRS’s fiscal year-end financial statements. Since this balance must be validated, the reconciliation serves to:



   - verify and correct asset information,

   - ensure that Advisory’s recorded asset amounts are current and supportable (property and documentation exist),

   - resolve discrepancies between Advisory’s records and RACS during this process,


7. Each Advisory territory appointed an Area Coordinator to be the contact point for the Campus Accounting Branch. The function of the Area Coordinator is to receive the RACS report and handle it according to the above instructions. If all discrepancies are resolved, then adjusted Advisory recorded asset information will match adjusted RACS. The reconciliation process ensures that the most current and supportable information is provided.


**1.4.53.4.6.7.4** **(10-04-2019)**

###### Seizure and Sale Reports and Memoranda

1. Advisory is responsible for a number of seizure and sale reports:



   - Form 13464, 90 Day Open Seizure and Semi-Annual Verification Report.

   - Semi-annual Verification of Property, Form 6670, Seizure Disposition Report.

   - Semi-annual consolidation report of Forms 6670 by area.

   - Monthly report to the RACS Unit on sale proceeds that remain unresolved after 90 days.


**1.4.53.4.6.8** **(10-04-2019)**

##### Quality and Controls

1. The IRS’s vision focuses on three high level goals: Service to each taxpayer, service to all taxpayers and productivity through a quality work environment. The IRS has developed a set of Balanced Performance Measures in three major areas: Customer Satisfaction, Employee Satisfaction and Business Results, with Business Results comprised of measures of quality and quantity. In reaching our goals we consider our impact on customer and employee satisfaction while we strive to improve quality and achieve quantifiable results. See IRM 1.5.1, The IRS Balanced Performance Measurement System.

2. Specific guidance for employee case documentation is provided in various sections of Part 5 and partially summarized in IRM 1.4.50-2, Criteria for Review of Completed Work. Specific guidelines are found in the appropriate IRM's and programs.

3. The need for clear, accurate, complete, and high-quality documentation is extremely important. Incomplete documentation will negatively affect:



1. Subsequent employee case actions,

2. Ability to review and evaluate case activity,

3. Actions by other employees,

4. Quality Review System results,

5. Cases presented in legal proceedings.


### Note:

Ensure that employees clearly document the reason(s) why they have made a recommendation for approval of a lien certificate.

**1.4.53.4.6.8.1** **(10-04-2019)**

###### CSED Accounts

1. Use ENTITY and ICS to identify accounts on which the Collection Statute Expiration Date (CSED) is within 52 weeks. Generate a report to identify accounts where the CSED will expire within the next 12 months. Review those NFOIs to:



1. Verify the accuracy of the CSED, and take corrective action if needed (see below),

2. Ensure that timely and effective action is taken.


2. The CSED may be invalid. The CSED shown is manually entered on the NFOI for the earliest assessment on the module. Update the CSED date on ICS as appropriate or instruct the employee to take that action

3. If a statute expires, see IRM 5.16.1.2.2.5, Report of Statute Expiration and IRM 5.1.19.5.4, Expiration of a Collection Statute.


**1.4.53.4.6.8.2** **(07-17-2025)**

###### ASED Accounts

1. Use ENTITY, ICS, and ATFR to identify the Assessment Statute Expiration Date (ASED) for accounts assigned to Advisory. Generate a report to identify accounts where the ASED will expire within the next 12 months. These cases are loaded on the ATFR System and are an important function of Advisory CPM responsibilities.

2. Review potential ASED modules where the case is in CPM inventory.

3. When appropriate instruct employees to:



1. Proceed with processing,

2. Resolve processing problems.


4. Check to ensure the employees have resolved the ASED case properly.

5. Report the expiration of any ASED per instructions in IRM 5.7.3.9, Reporting Expiration of the TFRP Statute and IRM 5.1.19.5.4, Expiration of a Collection Statute.


**1.4.53.4.6.8.3** **(07-17-2025)**

###### RSED Issues on Claims for Refund

1. Managers should ensure that Refund Statute Expiration Date (RSED) issues are addressed on claims for refund submitted for Advisory review and action. The RSED to claim a credit or refund is generally three years from the date of filing the tax return or two years from the date the tax was paid, whichever is later. See IRM 5.7.7.5.1, CEASO Actions, for more information.


**1.4.53.4.6.8.4** **(10-04-2019)**

###### Monitoring Trust Fund Recovery Penalty (TFRP) Investigations

1. The Automated Trust Fund Recovery (ATFR) application provides several reports to facilitate monitoring of TFRP assessment actions. These ATFR reports include:



   - Pending F2749- Identify cases in inventory longer than 30 days which may require managerial intervention.

   - Accepted F2749- Cases should not remain in this inventory. If not transmitted to campus or Appeals upon receipt, cases should be rejected to RO.

   - F2749 to SC- Displays responsible parties updated to the campus for assessment.

   - Appeals- Displays responsible parties updated from Accepted inventory to Appeals.


2. Monitor ATFR inventories and reports at least monthly to identify any aging cases requiring attention. Use these reports to:



   - Match the ATFR Appeals inventory with ICS inventory assigned to the group and resolve any discrepancies.

   - Re-sync the employee control structure on a regular basis to account for any changes to the T-signs within your assigned range.

   - Identify any potential ASED issues to address imminent statute cases.

   - Monitor the CPM inventory to identify older cases that may require managerial intervention. ATFR inventory screens can be sorted by "2749 to CPM" , "To Appeals," or "2749 to SC" dates to identify aging cases.


3. Conduct quarterly reconciliations to reconcile the "Appeals" inventory with the Appeals Centralized Database System (ACDS) to ensure that cases are still open in Appeals.

4. For additional information on the use of the ATFR application see the ATFR User Guides.


**1.4.53.4.6.8.5** **(07-17-2025)**

###### Remittance Control Reviews

1. You are required to maintain control procedures per IRM 5.1.2.5.5, Remittance/Document Transmittal Controls (Form 3210 and Form 795/795A), to ensure delivery and acknowledgement of remittance packages to Submission Processing. Periodically (at least once annually) conduct a review of control procedures established to ensure staff is complying with the procedures in IRM 5.1.2.5, Daily Report of Collection Activity - Form 795/795A. This control review should include the procedures for remittance packages prepared by revenue officers working away from the POD on extended field calls or telework. This control review should include reviewing procedures for remittance packages prepared by revenue officers within the group but located in satellite/remote PODs.



### Note:



This control review is not a review of Form 5919, Teller’s Error Advice. This control review is not a periodic check to ensure remittances/posting documents match the Form 795/795A being transmitted to Submission Processing.

2. At a minimum your control review should confirm and document there is a process for, and the group is complying with the following review points:



   - Form 3210, Document Transmittal is used to transmit multiple Forms 795/795A to Submission Processing per IRM 5.1.2.5, Daily Report of Collection Activity - Form 795/795A. This may be done by looking at both the Form 3210 control copies and the acknowledged Form 3210.



     ### Note:



     Per IRM 5.1.2.5.4(2), Form 3210 must be completed and two copies included when sending more than one employee sealed envelope to Submission Processing.

   - Form 3210 lists only documents transmitted, does not list any documents that were not transmitted, and is not missing transmitted documents.



     ### Note:



     When the Form 3210 is missing transmitted documents (i.e. documents are transmitted with the form but not listed on the form), Submission Processing is required to annotate the acknowledgement copy with documents received but not listed.

   - Form 795/795As are prepared timely according to IRM 5.1.2.5. This may be done by comparing the Form 795/795A dates with the remittance received dates for remittances listed on the Form 795/795A.

   - Form 795/795As and envelopes are prepared properly per IRM 5.1.2.5.3, Procedures for Preparing and Processing Form 795/795A. This may be done by comparing prepared Form 795/795As and envelopes with the requirements listed in IRM 5.1.2.5.3.

   - Control copies of Form 3210 are maintained per IRM 5.1.2.5.4, Procedures for Mailing Form 795/795A to Submission Processing. This may be done by looking at the location/file containing the Form 3210 control copies.

   - Control copies of Form 795/795A are maintained per IRM 5.1.2.5.4(2). This may be done by looking at location/file containing the Form 795/795As control copies.

   - A procedure is established to handle processing of remittances and returns for those employees away from the office per IRM 5.1.2.5(3). This may be done by verifying with employees the process used to ensure payments are processed the same day or no later than the next business day for those employees away from the office.

   - All document transmittal forms are reconciled on a biweekly basis to ensure that all transmittals were received per IRM 5.1.2.5.4(2). This may be done by looking at the location/file of the Form 3210 control copies for copies older than two weeks.

   - The actions in IRM 5.1.2.5.5.1, Form 3210 and Form 795/795A Follow up, have been taken for document transmittals (Form 3210, or in the case of one envelope, Form 795/795A) without an acknowledgement and 14 days have passed since transmission. This may be done by reviewing the control documents, verifying they were all acknowledged and any that were not acknowledged were followed up on within 14 days. Verify the designated clerical contact knows the follow-up requirements contained in IRM 5.1.2.5.5.1, Form 3210 and Form 795/795A Follow Up.

   - Verify that your employees in each post of duty have access to a **United States Treasury** stamp to meet the requirements of IRM 5.1.2.7.3.1, Overstamping or Endorsing.



     ### Note:



     To verify remittance packages prepared by employees working away from the POD on extended field calls or telework, the ENTITY query system may be used to select payments secured on days the employee were working away from the POD on extended field calls or Telework.


3. You must document your review. An optional template containing the minimum documentation is contained in Exhibit 1.4.50-9, Remittance Processing Transmission Control Review Template. If the template is not used, the review documentation must, at a minimum, notate the date the review was completed, the name of the reviewer, each of the review points listed in the template, whether the review point's IRM requirement was met or not met, and any corrections/comments for each review point.

4. The documented review must be retained for the appropriate period required under the records management guidelines per IRM 1.15, Records and Information Management. A copy of the documented review may be forwarded to the territory manager for review.


**1.4.53.4.7** **(07-17-2025)**

#### Reviews

1. The case review process provides the manager the opportunity to take a critical look at both individual program health and individual employee performance. Providing ongoing, candid, and meaningful employee feedback is essential to employee satisfaction and performance improvement. Reviews are an integral part of the group manager responsibilities. Reviews of employee work should seek to:



1. Assess the employee’s effectiveness in meeting the expectations established in their Critical Job Elements,

2. Assess the employee’s efficiency in carrying out the laws, procedures, and policies of the IRS,

3. Assess the employee's ability to properly plan and schedule field, office, and telework activity,

4. Ensure the employee is taking timely and appropriate actions to bring the case to a prompt and proper resolution,

5. Assess employee effectiveness in developmental case assignments,

6. Identify and address performance problems,

7. Determine the employee's effectiveness in meeting the IRS Retention Standard for the Fair and Equitable Treatment of Taxpayers.


2. All reviews relating to an employee's case work must be in writing. Use of the Embedded Quality Review System (EQRS) described in IRM 1.4.50-6, is required when reviewing case actions. The EQRS Individual Feedback Report provides a record of your ratings and the narrative comments on the employee's performance in relation to specific EQRS attributes. Group managers must become familiar with attribute definitions on the Quality Knowledge Base at: Quality Knowledge Base.

3. Additional guidance on functional Embedded Quality attributes can be found in the following documents:



   - Document 12739, Embedded Quality Advisory Lien Core Job Aid,

   - Document 12741, Embedded Quality Advisory Estates Job Aid,

   - Document 12744, Embedded Quality Advisory PALS Job Aid,

   - Document 12746, Embedded Quality Advisory Litigation Job Aid,

   - Document 13136, Embedded Quality Advisory Tax Examiner Job Aid,

   - Document 14510, Advisory Independent Administrative Review (IAR )Embedded Quality Job Aid.


4. Territory managers will schedule and conduct EQRS consistency reviews with group managers annually. Consistency reviews require all managers within a territory to review the same case to compare attribute results and discuss how rating guidelines can be applied to achieve consistency. Refer to IRM 1.4.50.12.3, EQ Consistency Reviews and IRM 5.13.1.1.3, Roles and Responsibilities for guidelines and procedures.

5. At the beginning of the fiscal year, the manager will develop a review schedule for the group that includes all mandatory reviews and other optional reviews. Optional reviews may include additional remote office visitations, time and workload reviews, etc. The review schedule should provide for a fair and accurate assessment of the employee's overall performance throughout the rating period.

6. Mandatory reviews represent the minimum review requirements that must be completed for each employee. It is intended that the minimum requirements will provide managers with the opportunity to spend more time reviewing and developing employees that need additional feedback and assistance. Mandatory reviews include:



1. Sufficient cases per quarter/year to establish the technical skill set, customer service abilities, accuracy and efficiency of each employee based on program requirements,

2. Mid-year Progress Review: Review a sufficient number of cases prior to the mid-year progress review The mid-year progress review should occur at the mid-point of the employee's appraisal period and must include a discussion on progress in meeting expectations (CJEs and the Retention Standard). For more information see IRM 6.430.2.3.2(2), Conducting Progress Reviews. When necessary, based on case reviews, other forms of review, office observation, field observations, etc., you have the authority to require your employee to obtain your approval before taking subsequent case actions.

3. Annual Case Review: Follow the guidelines in IRM 1.4.50.5.2.2, Requirements for Annual Performance Case Reviews. Remember to review at least half of the cases prior to the mid-year progress review.


### Note:

Employees who inappropriately extend deadlines or delay case actions can be required to obtain your approval of their extensions in the future so as not to deter or delay timely case resolution. The ICS Calendar is an excellent tool that can assist the manager and the employee when Workload Management issues are found.

7. Group managers will continually review information gathering activities by their employees. See IRM 5.1.3.7.1, Information Gathering Guidelines for additional guidance.

8. For additional guidance on preparing reviews, narratives and appraisals see IRM 1.4.50-6, Collection Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide.


**1.4.53.4.7.1** **(10-04-2019)**

##### Case Reviews

01. Choose a sufficient number of cases to review to ensure a thorough evaluation of each employee’s performance. Reviews should be tailored to individual needs. Scheduling of the review may be announced or unannounced at the option of local management.

02. You must use the Embedded Quality Review System (EQRS) for case reviews in program areas covered under EQRS.

03. Use case specific EQRS attributes, EQ case summary narratives, and performance summaries for all reviews conducted during the rating period to create performance feedback. Feedback must indicate to the employee how they are meeting or not meeting the EQRS attributes and aspects of the critical job elements.

04. If you have requested the employee take specific actions, a follow-up review should be scheduled 60-90 days after the initial review to ensure your direction is being followed and the case is moving toward resolution. The follow-up review will generally be limited to the cases previously reviewed that required follow-up unless you need to see other cases to document a performance trend. Using EQRS, prepare a narrative conveying the results of the follow-up review.

05. When making evaluative determinations concerning the timeliness of employee initial contacts, follow-up, or closing actions, you should be alert for, and consider, employee factors including illness, extended leave, approved collateral duties, and/or teaching assignments.

06. You must also summarize the employee's overall performance on all cases reviewed, including the results of time utilization reviews, remote office visitations, etc., as part of your mid-year and/or annual performance assessment. Narrative feedback should provide positive aspects as well as constructive comments on an employee's performance. See IRM 1.4.50-6, Collection Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide.

07. Prepare the EQRS Individual Feedback Report in duplicate and include all applicable case data. Both you and the employee must sign it. Give the original Individual Feedback Report to the employee for action on case recommendations with a due date. Retain the duplicate in the EPF for follow-up. Discuss all recommended actions entered on the Individual Feedback Report with the employee to ensure that there is a complete understanding regarding your observations and directions.

08. Written performance feedback (Individual Feedback Report, Form 6067, Employee Performance Folder Record, memorandum, etc.,) must be provided to the employee within 15 work days. The 15 day time frame starts from the time the supervisor becomes aware of, or should have been aware of, the event addressed in the recordation/feedback item.

09. Select the ICS picklist "Case Reviewed" to document the date of the review in the ICS case history. Although you may suggest or request specific actions in the case history, you should avoid making numerous case decisions for the employee. Documentation of an evaluative nature should not be entered in the case history.



    ### Note:



    A systemically generated history entry will appear in ICS based on the date shown in the "Shared with Employee Date" section of the EQ review. The EQ review system provides weekly (not daily) inputs to ICS, thus there may be a delay in the appearance of the history entry.

10. The primary purpose of a non-evaluative review is to help the employee develop and enhance their job skills. Effective non-evaluative reviews foster open lines of communication between the employee and the manager. This enables the manager to receive employee feedback and transfer operational goals informally.

11. Non-evaluative reviews do not contain a written recordation of performance and should not be used as a source for annual rating. If some documentation is appropriate have the employee initial and date. Provide one copy for the employee and retain the other copy in the employee's drop file.

12. Observing the employee during office telephone contacts provides an excellent opportunity for you to assess his/her abilities to conduct interviews, deliver fair and courteous treatment to all taxpayers, and knowledge of policies and procedures.

13. The Time Utilization Reviews are a multi-case review intended to document the effectiveness of time utilization and evaluation of determinations made and/or actions taken in the field, or at a telework site, or in the office on a specific day(s). This process can be used to measure the overall effectiveness of the employee case actions.

14. When approving work, you have an opportunity and obligation to evaluate employee performance, as well as the quality of their work, including appropriate use of ICS with all supporting information.

15. Closed cases also provide an opportunity to evaluate individual performance as well as the overall quality of your group's product.


**1.4.53.4.8** **(07-17-2025)**

#### Embedded Quality (EQ)

1. The Embedded Quality (EQ) process was developed as a practical method of supporting Balanced Measures objectives and is comprised of two distinct systems: Embedded Quality Review System (EQRS) and National Quality Review System (NQRS). See IRM 5.13.1, Embedded Quality Collection Field Organizations Administrative Guidelines, for a more in-depth discussion of these distinct systems. Visit the Quality Knowledge Base for additional useful tools at: Quality Knowledge Base

2. EQRS is the review tool designed to assist managers in identifying areas of strength and need in their employees’ individual performance as it relates to case activities.



1. The focus of EQRS is on improving performance while the performance occurs. The attributes can be measured on an open or a closed case.

2. EQRS is designed to identify gaps in quality case work, as defined by the attributes, at the earliest point in activity.

3. EQRS also provides you with tools to capture and share review feedback to show employees how they performed in relation to both the attributes and their CJEs.


3. National quality reviewers use a similar web-based system called the National Quality Review System (NQRS). NQRS reviewers provide independent collection review information from which management may draw inferences regarding overall case quality for a given operational segment.

4. A cornerstone of EQ is that NQRS reviewers and managers use the same attributes. This should minimize the concern that national reviewers are looking at different criteria than managers when reviewing cases.

5. The NQRS reviews will not be used to evaluate individual employee performance. Rather than being linked to employee CJEs, NQRS attributes are linked to the five Quality Measurement Categories: Timeliness, Professionalism, Procedural Accuracy, Regulatory Accuracy, and Customer Accuracy.

6. Consistency Reviews will be conducted to assist users in rating EQ attributes consistently by using the Attribute Job Aids, EQ website guidance, employee Critical Job Elements, and IRMs. The goal of Consistency Reviews is to improve the understanding and application of the EQ rating guidelines.


**1.4.53.4.9** **(07-17-2025)**

#### Functional Security Reviews

1. Complete a Functional Security Review at least once a year. See IRM 1.4.50.3.6, After Hours Security Reviews.

2. The After-Hour review may be completed by a designee (e.g. the Commissioner’s Representative) of the group manager in post of duty where the manager is not located. The complete functional security reviews must be conducted by the group manager or acting group manager.

3. If your reviews reflect that the employee repeatedly fails to observe security protocols, contact your Labor Relations Specialist to determine the next appropriate action.


**1.4.53.4.10** **(10-04-2019)**

#### Case Documentation

1. Collection will use the Integrated Collection System (ICS) history functionality to record actions and decisions taken on cases. Specific guidance for employee case documentation is provided in various sections of IRM Part 5. Additional guidelines may be found in individual program IRM's.

2. The need for clear, accurate, concise, complete, timely, and high-quality documentation is extremely important. Entries should be made in chronological order and should be recorded the day the action occurs or as soon as practical thereafter. Incomplete documentation will negatively affect:



1. Subsequent employee case actions,

2. Ability to review and evaluate case activity,

3. Actions by other employees,

4. Quality Review System results,

5. Cases presented in legal proceedings.


**1.4.53.5** **(10-04-2019)**

### Protecting Taxpayer Rights

1. A primary responsibility of managers must be to monitor employee practices and actions to ensure that taxpayer rights are always observed during our efforts to bring taxpayers into compliance.

2. The IRS formally adopted a Taxpayer Bill of Rights in June 2014, which provides the nation’s taxpayers with a better understanding of their rights and helps reinforce the fairness of the tax system. In 2015, Congress charged the Commissioner with ensuring IRS employees are familiar with and act in accord with the taxpayer rights as afforded by IRC 7803(a)(3). IRS employees must be informed about taxpayer rights and be conscientious in the performance of their duties to honor, respect and effectively communicate those rights which may aid in reducing taxpayer burden. See Pub 1, Your Rights As A Taxpayer, and Taxpayer Bill of Rights website at: [Taxpayer Bill of Rights](https://www.irs.gov/taxpayer-bill-of-rights).

3. Taxpayer rights include, but are not limited to, the following:



01. The right to be informed.

02. The right to quality service.

03. The right to pay no more than the correct amount of tax.

04. The right to privacy.

05. The right to confidentiality.

06. The right to challenge the IRS’s position and be heard.

07. The right to appeal an IRS decision in an independent forum.

08. The right to finality.

09. The right to retain representation.

10. The right to a fair and just system.


4. Section 1203 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA ‘98) calls for the termination of any employee of the Internal Revenue Service if there is a final administrative or judicial determination that the employee willfully committed any covered act or omission. For additional information see Document 11043, RRA ‘98 Section 1203 All Employee Guide.

5. For additional resources see: IRM 1.4.50.3.2, Protecting Taxpayer Rights.


**1.4.53.5.1** **(07-17-2025)**

#### Fair Debt Collection Practices

1. IRC 6304, Fair Tax Collection Practices (FTCP), imposes certain restrictions with respect to tax collection. During a case review or upon receiving a complaint from a taxpayer, you may identify a potential violation of those restrictions. Potential employee violations of the Fair Debt Collection Practices Act (FDCPA) (see IRM 5.1.10.6, Fair Tax Collection Practices) must be reported to Labor Relations by the close of the next business day following notification of the alleged violation.

2. To ensure collected data is complete and accurate, use the FTCP issue codes, listed on IRM 1.4.50.3.2.3, Fair Tax Collection Practices, when reporting the potential violation. Labor Relations uses these codes for tracking in their case tracking system). If violations are confirmed, work with the assigned Labor Relations Specialist to determine the next appropriate action.

3. Additional resources:



   - IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers.

   - IRM 6.430.2.4.7, Rating Performance Against the Retention Standard for the Fair and Equitable Treatment of Taxpayers.

   - Labor/Employee Relations & Negotiations (LERN).


**1.4.53.6** **(07-17-2025)**

### CEASO Groups and Workload

1. There are several types of groups in CEASO and this section of the handbook will provide some information about the work that each perform.

2. CEASO groups are comprised of:



   - Traditional CEASO Advisory groups,

   - Estate Tax group,

   - Independent Administrative Reviewer (IAR) group,

   - Property Appraisal and Liquidation Specialist (PALS) group,

   - Restitution-Based Assessment (RBA) group,

   - Advisory Consolidated Receipts (ACR),

   - Control Point Monitoring (CPM).


**1.4.53.6.1** **(07-17-2025)**

#### Traditional Advisory Group Workload

01. CEASO Advisory contains a broad range of program areas to support Field Collection (FC), assist taxpayers, and provide assistance to various other IRS functions. Some, but not all, of the program areas are mentioned below. These citations note the presence of the program but do not substitute for the technical and/or procedural guidance in other portions of the IRM.

02. An important component of the CEASO Advisory manager's workload is ensuring that program area support and technical guidance is being provided to FC in an effective and timely manner; that CEASO Advisory is effectively serving as liaison for FC in resolving policy and technical issues raised to Counsel and/or Headquarters; and that Advisory is providing assistance to the field in resolving technical issues prior to a determination that Counsel and/or Headquarters involvement is warranted.

03. The enforcement of a summons served by FC ROs is processed through CEASO Advisory prior to being forwarded to Counsel. See IRM 25.5.10, Enforcement of Summons, for the technical issues associated with summons enforcement.

04. Lien certificates (release, discharge, subordination, withdrawal, non-attachment), and miscellaneous lien issues are handled by Advisory as one of the major program areas in which it has contact with taxpayers. See IRM 5.12, Federal Tax Liens, for procedural and technical requirements of these certificates.



    1. Since these lien certificates are usually associated with pending transactions by the taxpayers, these cases necessitate prompt processing.

    2. There are also lien issues including Notice of Federal Tax Lien (NFTL) refiles, revocations of releases of lien, special condition nominee, alter ego, transferee, successor in interest NFTLs which are worked in Advisory to protect the government’s interest in property.

    3. Many of the external questions involving NFTLs and processing of lien documents may be handled by referral to the Centralized Lien Operation, but technical questions are handled by Advisory.


05. Another program area that has direct involvement with external taxpayers and third parties is foreclosures and redemptions. Most work in this area is procedural and performed by tax examiners, but the technical issues normally require an advisor to resolve. These technical issues may include judicial foreclosures, redemption investigations, releases of right of redemption, and surplus proceeds from foreclosure sales. See IRM 5.12.4, Judicial/Non-Judicial Foreclosure and IRM 5.12.5, Redemptions, for technical and procedural specifics.

06. The Trust Fund Recovery Penalty (TFRP) program provides support to FC ROs who propose these assessments and also deals with issues that arise subsequent to assessment. These include TFRP case processing, claims for refund, TFRP appeals and control of TFRP files. This support work is performed by Control Point Monitoring (CPM) tax examiners. See IRM 5.7.6, Trust Fund Penalty Assessment Action..



    ### Note:



    TFRP payment application and refund claims require an advisor to review and resolve. See IRM 5.7.7, Payment Application and Refund Claims.

07. Collection litigation involving suits for and against the U.S. are controlled by CEASO Advisory. Specific issues include:



    1. Suits by the U.S. (reduce tax liability to judgment, foreclose on the tax lien, principal residence seizure, among others),

    2. Suits against the U.S. (28 USC 2410 suits, suits for wrongful levy, suits for wrongful collection actions are some of these),

    3. Suits against employees – specifically suits against collection employees involving their actions in the course of their duties,

    4. TFRP refund litigation – usually in association with a denied TFRP claim,

    5. Judgments – control of judgments secured from collection litigation,

    6. Appeals/Counsel liaison on various legal and procedural issues,

    7. Litigation Account Management System (LAMS) reconciliation reports,

    8. Miscellaneous other suits and legal opinions.



       ### Note:



       See IRM 25.3, Litigation and Judgments Handbook and IRM 5.17, Legal Reference Guide for Revenue Officers, for particulars on these issues.


08. Seizure review and asset management are the responsibility of the CEASO Advisory group. CEASO Advisory is responsible for providing technical advice, conducting pre-seizure reviews, monitoring open seizures, handling post-seizure reviews and the processing of closed seizure paperwork. Advisory must review the seizure recommendation prior to submitting it to the corresponding approving official. See IRM 5.10, Seizure and Sale, for current procedures.



    1. Seizure and sale documents are reviewed in CEASO Advisory to ensure Field Collection and PALS adherence to legal and procedural requirements found in the IRM and other Policy guidance. Form 13719, Pre-seizure Checklist and Approval Request, is completed by the field revenue officer and group manager and forwarded to Advisory.

    2. Follow-ups should be made on all outstanding seizures in accordance with IRM procedures.

    3. Form 13360, Seizure and Sale Checklist, and Form 13361, Post-Seizure Review Checksheet, must be maintained in the seizure file to document receipt and review of seizure and sale documents. Form 13360, is a living document and the advisor must keep it updated throughout the seizure and sale or disposition.

    4. CEASO Advisory will standardize the seizure files by using Document 12474, Seizure File Tabs.

    5. CEASO Advisory maintains records of all seizures. One CEASO Advisory group in each CEASO Advisory territory will maintain the seizure log. A seizure number will be assigned immediately after the seizure is made and the log will be used to track the seizure through all activity until the seizure is closed. Advisory will notify Ogden Accounting Branch of each new seizure by processing Form 2433, Part 7a. An entry will be established on the RACS 135 Report to monitor the receipt, disposition, and application of sale proceeds for assets under seizure.

    6. CEASO Advisory is also responsible for preparing deeds, maintaining Record 21, Record of Seizure and Sale.

    7. CEASO Advisory is responsible for notifying intervening creditors of the proceeds of sale that they would be entitled. CEASO Advisory is responsible for notifying taxpayers and other claimants of surplus sale proceeds.

    8. CEASO Advisory maintains the permanent record of sales. See IRM 5.10.6.12, Permanent Record of Sales.

    9. The public inspection files for Records 21 are maintained by CEASO Advisory. See IRM 5.10.6.13, Revenue Officer Transfer of Closed Case Files to Advisory Records Retention.


09. Another program area is Oral Opinions – giving advice on technical and procedural issues to internal and external customers even though there may not be an open case under Advisory control. Normally, these consist of short contacts from Advisory customers who seek clarification or guidance on a particular issue. These contacts are manually counted to reflect the time spent and number of contacts.

10. Decedent estate proofs of claims are prepared by CEASO Advisory on taxes owed by deceased taxpayers. CEASO Advisory receives referrals from various customers and determines if it is in the interest of the government to file a proof of claim where equity exists in the probate proceedings. See IRM 5.5.3, Working Decedent Cases and IRM 5.5.4, Proof of Claim Procedures on Decedent Cases, for these procedures.

11. CEASO Advisory actively participates in both internal and external outreach activities on the program areas for which it is responsible. CEASO Advisory managers are encouraged to make themselves and their employees available in this manner to educate stakeholders on the correct procedures and technical issues involved with the many CEASO Advisory programs.

12. Other programs include levy issues, non-TFRP claims, Form 4768 and Form 1127, extensions of time to pay, some international issues, collaterals, jeopardy, Disclosure/FOIA/Taxpayer Advocate, and transferee assessments.

13. These groups are staffed with professional, paraprofessional and secretarial employees and are located locally providing service within a geographically defined area.

14. Some workload may be centralized or specialized within one CEASO Advisory group within a CEASO Advisory territory.

15. Review the applicable IRM chapters for each program. Be aware that some programs have several IRM components (Litigation and Seizures are examples).

16. CEASO Advisory personnel are responsible for receipt and review of all notices of forfeiture and is responsible for filing a timely Petition for Remission (PFR). The PFR is a tool available to the IRS to recover fraudulent refund amounts that have been seized by a federal law enforcement agency and subsequently forfeited using Title 18 seizure/forfeiture authority. This PFR process will allow the IRS to exercise its claim against these monies if it can be proven the assets are linked to a scheme. See IRM 5.1.29, Petition for Remission Program, for procedural guidelines.


**1.4.53.6.2** **(10-04-2019)**

#### Estate Tax Group

1. The Estate Tax group is responsible for:



   - Securing, filing, monitoring and releasing estate tax liens related to Form 668-H, Notice of Federal Estate Tax Lien Under Internal Revenue Code Section 6324B, and Form 668-J, Notice of Federal Estate Tax Lien Under Internal Revenue Code Section 6324A, lien agreements, escrow agreements and/or bonds;

   - Evaluating and making a determination to approve requests for extensions to pay under IRC 6161;

   - Discharges and subordinations related to all estate tax liens. Including discharges of the IRC 6321 lien for related decedent accounts when there is an associated liability or filing requirement for the Form 706, U.S. U.S. Estate Tax Return or Form 709, U.S. Gift Return, see chart below. Additional guidance in IRM 5.5.8, Advisory Responsibilities for Processing Estate Tax Returns.

   - Securing and processing of recapture tax returns, Form 706-A and Form 706-D.


2. The following table provides guidance as to which advisory group is responsible:




| If: | Then the request is reviewed by: |
| --- | --- |
| There is a Form 706 or Form 709 tax liability or filing requirement | Advisory Estate Tax Lien group |
| Only Form 1040, TFRP, Form 941 for business taxes, etc. are owed by a decedent | Advisory group |

3. This group is staffed with professional, paraprofessional and secretarial employees and is a national group with advisors located across the country.

4. The Estate Tax group is responsible for notifying the Cincinnati Campus Estate Tax Unit of their actions that affect billing or acceleration of estate tax accounts.


**1.4.53.6.2.1** **(10-04-2019)**

##### Estate Tax Liens

1. The Estate Tax Group is responsible for Form 668-H and Form 668-J, lien releases, along with all related files, in association with collection on liabilities due from Form 706, U.S. Estate Tax Return. See IRM 5.5.6, Collection on Accounts with Special Estate Tax Elections and IRM 5.5.8, Advisory Responsibilities for Processing Estate Tax Returns.

2. The Estate Tax group is also responsible for monitoring liens filed on special elections which are not self-releasing, review of value or collateral pledged on liens, and preparation of timely and accurate lien releases.


**1.4.53.6.2.2** **(10-04-2019)**

##### Extensions of Time to Pay Estate Taxes

1. The Estate Tax group has responsibility for evaluating and granting or denying certain requests for extension of time to pay estate tax. Refer to IRM 5.5.5, Processing Estate and Gift Tax Extensions. Specifically, Form 4768, Application for Extension of Time to File a Return and/or Pay U.S. Estate (and Generation Skipping Transfer) Taxes and Form 1127, Application for Extension of Time for Payment of Tax Due to Undue Hardship.

2. Any extension request denied by Advisory, in which the taxpayer requests an appeals hearing, will be addressed and processed by the Advisory Estate Tax group.


**1.4.53.6.3** **(10-04-2019)**

#### Independent Administrative Reviewer (IAR) Group

1. Under IRC 7122(e), taxpayers are entitled to independent administrative reviews of rejected requests for installment agreements and proposed rejections of Offers in Compromise. The independent administrative reviewer (IAR) is responsible for conducting this review. The IAR is responsible for reviewing each case to determine if the proposed rejection is reasonable based on the taxpayer's facts and circumstances. The IAR is not responsible for conducting a quality analysis of completeness, and accuracy of the documents used to support the case.

2. This group is staffed with a manager, a secretary, and IARs located across the country in separate PODs.

3. The manager may work with local managers to provide space and support to IARs.


**1.4.53.6.3.1** **(08-20-2010)**

##### IAR Workload

1. The manager is responsible for determining the appropriate assignment of work.


**1.4.53.6.3.1.1** **(10-04-2019)**

###### Review of Rejection of OIC Proposals

1. See IRM 5.8.12, Offer in Compromise, Independent Administrative Review.

2. In accordance with IRC 7122(e)(1), before an OIC can be rejected by the IRS, the proposal must be reviewed by an IAR.

3. The IAR is responsible for ensuring that all IRM and IRC requirements have been met before the taxpayer is notified of the rejection.

4. Automated Offer In Compromise (AOIC) is used to control IAR OIC Review inventory.

5. Once the approving official signs Form 1271, Rejection Memorandum, the offer is reassigned to the IAR pool on AOIC.

6. The IAR should create an OI on ICS within seven (7) calendar days of receipt.

7. If the rejection is not sustained by the IAR Form 5942, Advisory Reviewer’s Report, should be generated.

8. IAR reviews are completed and are returned to the originator on AOIC.


**1.4.53.6.3.1.2** **(10-04-2019)**

###### Review of Rejection of Installment Agreement Proposals

1. See IRM 5.14.9.7, Independent Administrative Review after Recommended Rejection of Installment Agreement Requests.

2. In accordance with IRC 7122(e)(1), before an IA proposal can be rejected by IRS, the proposal must be reviewed by an IAR. (Exception: IAs to delay collection).

3. The IAR is responsible for ensuring that all IRM and IRC requirements have been met before the taxpayer is notified of the rejection.

4. IAR reviews are documented on Form 12233, Request for Installment Agreement - Independent Review Prior to Rejection.

5. Form 12233 originate with a FC employee and are referred to the IAR group via eApproval.

6. The IAR must add the case to ICS within seven (7) calendar days.

7. The IAR documents review in Form 12233 and returns the case to the originator via eApproval.


**1.4.53.6.4** **(10-04-2019)**

#### Property Appraisal and Liquidation Specialist(PALS) Group

01. The Property Acquisition and Liquidation Specialist (PALS) position and the PALS program was created after the Internal Revenue Restructuring and Reform Act of 1998 (RRA 98). The PALS' primary function is to sell property that has been seized by revenue officers, redeemed for the government, acquired for payment of taxes, or acquired by order of a court. PALS also provide appraisal assistance and advice on seizure expenses to revenue officers considering seizure action. PALS are situated throughout the country. The PALS assignment grid is maintained on the PALS website: PALS Contact List. Because of the variance in number and complexity of receipts PALS assignments are sometimes transferred amongst groups to balance workload.

02. PALS managers need to be very organized as their programs have short and critical time frames. The PALS managers travel occasionally and must be able to carry out a multitude of managerial responsibilities while in travel status. This requires a familiarity with automation tools, flexible scheduling, and effective time management. PALS managers are provided cell phones, laptop computers, and wireless internet cards so they may maintain communications with their groups and customers while working outside their office.

03. Cases are assigned as Non Field Other Investigations (NFOIs) on ICS by selecting the appropriate item from the "Requested Action" menu that corresponds to the related time code. Case assignment is time sensitive and must be completed within seven (7) calendar days of receipt in the group.




    | PALS NFOI Code | Case Type |
    | --- | --- |
    | 151 | PALS Appraisals |
    | 152 | PALS Seized Asset Control and Sales |
    | 153 | PALS Acquired Property Sales |
    | 154 | PALS Redemption Sales |
    | 155 | PALS Redemption Investigations |
    | 156 | PALS Judicial Sales |
    | 157 | PALS Judicial Appraisals |
    | 158 | PALS Pre-Seizure Planning |

04. In addition to the above time codes, PALS will charge time to Time Code 122 when they are providing oral advice on sale issues or asset valuations.

05. All case assignments are to be made through the PALS manager. PALS need to forward requests for actions to managers for assignment. Managers need to ensure work requested of the PALS is appropriate. For example, revenue officers are expected to determine the value of assets. They may seek PALS input as to value or sources to use to establish value, but the revenue officers are expected to determine whether there is equity prior to contacting the PALS. Formal appraisals are to be completed only when the PALS manager agrees they are necessary.

06. Time Code 158 - Pre-Seizure Planning is only for complex cases where the PALS manager or PALS need up to 30 days to resolve complex case issues. Typically the case will be assigned to PALS under this time code while a title report is secured and title verified. Once this is accomplished the 158 NFOI is closed and 152 NFOI is opened. Managers need to monitor the 158 inventory list carefully to ensure cases are not maintained in that code for more than 30 days.

07. PALS managers are responsible for ensuring that the workload is being managed in a timely and efficient manner. ICS inventory reports will be reviewed on a monthly basis to ensure PALS cases are being effectively worked. Managers are to ensure custody is promptly accepted and the assets are timely moved to sale. Real property custody transfer should be immediate or as soon as possible. Personal property custody transfer should be as soon as possible but no more than 30 days.

08. PALS managers should consider attending auctions when large sums of cash are anticipated, on cases requiring sensitive case reports, and judgment should be used when cases involve the need for an armed escort. When PALS managers attend auctions written feedback will be provided to the PALS employee in a timely manner based on observations from the field visit.

09. Managers will review closed cases using Form 6067. Three EQ reviews per PALS per quarter are required as a minimum for performance documentation. Sale reports are required to be submitted to Advisory within 14 days after the sale or as soon as all receipts and invoices have been received. The money secured at the sale is held by RACS until the sale report is submitted. If the PALS does not timely submit his/her reports, or does so with errors, it delays the posting of the sale proceeds to the taxpayer's account. Managers will ensure timeliness and completeness of closing reports prior to forwarding to Advisory.

10. Form 5942 is issued to the PALS managers when errors are made or critical documents have not been received. These need to be controlled by the manager to ensure they are resolved by the due date. The manager should focus on ensuring the errors are corrected and any systems problems are resolved. The manager should be concerned if a PALS is repeatedly getting Forms 5942 for the same issue. If that occurs the manager needs to address it with the PALS and provide additional training if necessary.

11. PALS managers will use an informational Form 5942 to return custody of seized assets to the field when appropriate. At times additional work may be required to further develop the case or the revenue officer may explore alternate case resolutions and custody should be returned to the field through the Collection group manager via the Form 5942 and a Form 3210 transmittal. Once custody is returned to the field, the PALS OI should be closed.

12. At the end of each quarterly period Seizure Advisory groups must initiate a Form 13464, 90-Day Open Seizure and Semi-Annual Asset Verification Report for any seizure file that has been open beyond 90 days and still has at least one asset that has not been disposed of. The completed forms must be returned to Advisory by the PALS manager within 60 days of the end of the quarter. For the quarterly periods ending March 31 and September 30, Section III (Physical Inventory Verification) must also be completed. Generally, the employee who has custody of the asset will complete the verification of the inventory and return the completed report to Advisory through the PALS manager. Managers will use this opportunity to ensure the case is being worked effectively.

13. PALS managers are responsible for overseeing the PALS purchase of a broad range of items needed in the performance of their official duties. This is a sensitive area and needs strict adherence to the applicable policies and procedures. PALS managers must ensure they are knowledgeable about the various procurement regulations and secure additional guidance from the Supervisory Budget Analyst in Finance when necessary.


**1.4.53.6.5** **(10-04-2019)**

#### Restitution-Based Assessment (RBA) Group

1. Advisory is responsible for monitoring and coordinating actions on Probation and Restitution-Based Assessment (RBA) cases. Advisory's responsibilities include:



   - Monitoring all cases with IRS-related conditions of Probation and/or RBA and following up on any Other Investigations (OI) issued to the field.

   - Reporting noncompliance with conditions of probation to Criminal Investigation, with recommendations for revocation of probation by Department of Justice.

   - Coordinating with Department of Justice when the IRS takes civil enforcement actions to collect RBA cases and providing advice and guidance to field revenue officers.

   - Coordinating civil enforcement actions with Exam Technical Services (TS) and revenue agents assigned to the case.

   - Exchanging information with CI and TS to reconcile the status and actions pending in all probation cases on a semi annual-basis.

   - Maintaining cases files and inventory for post-probation and non-probation RBA cases and providing guidance regarding collection of RBAs and restitution judgments.



     ### Note:



     See IRM 5.1.5.16, Advisory Responsibilities - Probation and Restitution Cases, for further procedural guidelines.


**Exhibit 1.4.53-1**

### CEASO Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide

EQRS, Form 6850, Performance Appraisal and narratives are important in all actions regarding an employee’s performance. The review documents should justify the numerical ratings and average indicated on Form 6850.

These documents will assist you in substantiating your decision to take any action involving the performance of an employee. Therefore, these documents should be clear and concise. They should provide the employee with a clear understanding of their level of performance.

EQRS review of documents, narratives, and other evaluative documents should provide positive feedback and specific strategies for improvement as applicable. The narrative should be specifically written to enhance performance, identify weaknesses, and explain potential consequences when warranted.

_Ensure that your reviews are written and encompass a sufficient range of cases from the employee’s inventory._

When performing case reviews utilize the Embedded Quality Review System and:

1. Review actual hard copy case file(s) whenever possible to ensure documents that will expedite case resolution are included, i.e. lien certificate applications, suit recommendations, seizure recommendations, TFRP recommendations, etc., and that an appropriate evaluation of case direction has been made.

2. Ensure clear comments are included, for each case reviewed. If the employee is performing well, document it in the comments.

3. If case direction is needed, ensure your directions are specific. If warranted, reference specific documents reviewed in the case file.


When preparing the review documentation you should:

1. Ensure the employee’s actions were appropriately documented on each case.

2. Base your comments on actions pertaining to the applicable CJE and sub-element.

3. Ensure conformity with the employee’s CJEs by utilizing the applicable employee’s performance plan.

4. When appropriate, reference relevant IRM sections, subsections, and case file documents.

5. Document strategies for improvement.

6. Be realistic in expectations.

7. Prepare a narrative of your overall findings.


Meet with the employee and engage in an open dialogue. Be sure to discuss the positive as well as the negative aspects of the employee’s performance. Discuss the comments on the EQRS Feedback Report given on each case and ensure the employee understands.

1. Ask for their input regarding your interpretation of their actions.

2. If warranted, discuss the documents included in the case file, and address any that are missing.

3. If appropriate add their proposed actions to your comments as additional action items.

4. Ensure that time lines are realistic.

5. Ensure their case direction is clear.


Discuss the EQRS Feedback Report narrative with the employee, to ensure they understand the document and its possible impact on their annual appraisal/evaluation (positive or negative). You should have the employee sign for "receipt" of both the Individual Feedback Report and any accompanying documents. Document and date the Individual Feedback Report and narrative if the employee refuses to sign.

Form 6850, Performance Appraisal:

The Form 6850 is the numerical representation of the employee’s performance during the course of the evaluation period. It must be consistent with the employee’s casework and evaluative documents prepared during the course of the evaluative period. You should ensure that the preparation of Form 6850 is in accordance with Article 12 of the National Agreement. Base your appraisal of the employee on documented materials such as the following:

1. Evaluative documents retained in the employee’s EPF, such as EQRS Individual Feedback and/or Cumulative Feedback Reports. Also see IRM 1.4.50.5, Performance Management, and IRM 1.4.50.5.2, Reviews, for other considerations.

2. Taxpayer and/or internal customer correspondence.

3. All awards received during the period.


**Performance and Evaluative Narratives:**

Narratives are one the most effective tools in documenting and informing employees of their performance. They should be used to emphasize the positive as well as the negative aspects of their performance. They can be used as either stand alone documentation (EQRS Individual and/or Cumulative Feedback Reports) and/or with the Form 6850 (when appropriate). See Article 12, Section 4N, of the current National Agreement, regarding Form 6850 narratives. Effective narratives:

01. Are clear and concise.

02. Address each Critical Element and its accompanying sub-element for Form 6850.

03. Reference prior reviews and other evaluative documents completed during the course of the evaluation period and the dates completed or received.

04. Are of sufficient length for the employee to have a clear understanding of their current level of performance and what is expected from them in the future.

05. Summarize your findings during the course of a review or the overall performance during an evaluative period. You may choose to use specific examples or sanitized case references.

06. Refer to specific Critical Job Elements and sub-elements.

07. Describe strengths and weaknesses found within specific element(s).

08. Describe strategies for improvement.

09. Identify the level of performance (overall and within a specific CJE).

10. Describe potential consequences, if performance is at an unacceptable level or regressing.

11. Note that you are available for assistance.


In conjunction with the steps to address employee performance as outlined in IRM 1.4.50-5, ensure that:

- Your prescribed action is specifically documented and appropriately worded. Consult with your territory manager or labor relations specialist as appropriate.

- Your documentation includes a description of any problems and documentation of the discussion with the employee involved. Inform the employee of possible consequences if the issue is not resolved. You may inform the employee verbally, but confirm the discussion via memorandum. The proposed resolution of the issue should include a specific time period for completion. The resolution may include actions the employee must take and meetings between yourself and the employee to resolve the problem.


### Reminder:

The employee is entitled to request representation by NTEU, when the employee and supervisor or other management official meet to discuss action or _potential_ action, based on unacceptable performance.

### Note:

When taking any performance action, contact your servicing labor relations representative and your direct supervisor.

**Exhibit 1.4.53-2**

### CEASO Territory Manager Operational Aid

The following table includes commonly selected components of the Program review portion of the operational review. All items are mandatory except those noted as optional.

| Component | Description |
| --- | --- |
| Employee Satisfaction | Group Operational Reviews:<br> <br>- Provide copies of completed operational reviews for all groups.<br>  <br>- EQRS - Sufficient number of reviews.<br>  <br>- EQRS - One mirror case review per employee in the group for consistency (optional).<br>  <br>- EPF - Form 6850 Narratives including timely appraisals and ongoing/consistent feedback.<br>  <br>- EPF - Inventory assignment practice/balancing. |
| Employee Satisfaction | Employee Engagement:<br> <br>- Group meetings<br>  <br>- Award recognition<br>  <br>- One town hall per group<br>  <br>- POD visits<br>  <br>- Leadership opportunities<br>  <br>- Training plans |
| Employee Satisfaction | Leadership development activities within the territory and succession plan. |
| Employee Satisfaction | Provide status of all POD visits for TMs and GMs. |
| Employee Satisfaction | Provide territory staff meeting and town hall minutes. |
| Customer Satisfaction | Provide the quality review for the territory including:<br> <br>- EQRS<br>  <br>- 1204 review of Form 6850 narrative<br>  <br>- CDP/Appeals<br>  <br>- Sensitive case reports |
| Business Results | Describe territory controls to balance territory inventory including controls for:<br> <br>- Statutes<br>  <br>- NFTL refiles |
| Business Results | Provide the timeliness review of the inventory within the territory including:<br> <br>- Timely actions<br>  <br>- Time application (Form 4872 reviews and hours per disposition).<br>  <br>- Inventory balancing |
| Administrative Reviews | Actions taken on federal employee survey throughout the territory. |
| Administrative Reviews | Remittance |
| Administrative Reviews | Security |
| Administrative Reviews | Records Retention |
| Administrative Reviews | Audit of access to FinCen/CKGE/BEARS |
| Town Halls/Focus Groups | List including:<br> <br>- Advisors for focus group - 1 per group<br>  <br>- TEs for focus groups -1 per group (unless 8 or less in Territory, then all TEs)<br>  <br>- NTEU Presidents for each employee in focus group<br>  <br>- Every Group Manager/Acting Group Manager in the Territory<br>  <br>- Every Counsel Attorney represented by the Territory<br>  <br>- Field AD, FCM, and GMs in the POD(s) |

**Exhibit 1.4.53-3**

### CEASO Director Operational Aid

The table below contains common CEASO Director Operational Review components.

| Component | Description |
| --- | --- |
| Employee Satisfaction | Review the employee engagement operational reviews of the Group Managers completed by the Territory Manager. |
| Employee Satisfaction | Address personnel actions to ensure proper processing and Labor Relations involvement where necessary. |
| Employee Satisfaction | Assess whether TMs and GMs address issues raised in the federal employee survey. |
| Employee Satisfaction | Evaluate the Leadership Succession Review (LSR) status report for the territory and assess developmental opportunities provided to LSR participants. |
| Employee Satisfaction | Town hall meetings organized by the TM with each group in their territory. |
| Employee Satisfaction | Address the TM’s efforts to support the frontline manager cadre, frontline manager readiness program (FLRP) and senior manager readiness program (SMRP). |
| Customer Satisfaction | Taxpayer Rights:<br> <br>- Trends and analysis of EQRS Attribute 607<br>  <br>- Taxpayer Rights and IRC 6304<br>  <br>- Fair tax collection practices |
| Customer Satisfaction | 1204 Certifications |
| Business Results | Inventory assignment practices and inventory levels. |
| Business Results | Statute controls |
| Administrative Review | Address additional programs and initiatives that support the goals and objectives of Field Collection. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-053#addtoany "Show all")

A2A