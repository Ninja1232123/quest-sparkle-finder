---
url: "https://www.irs.gov/irm/part1/irm_01-022-004"
title: "1.22.4 Postage Accountability and Reporting Requirements | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-022-004#main-content)

- 1.22.4  [Postage Accountability and Reporting Requirements](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507673168)
  - 1.22.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507731424)
    - 1.22.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271541813296)
    - 1.22.4.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271508885600)
    - 1.22.4.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271508883968)
      - 1.22.4.1.3.1  [Chief Financial Officer (CFO)/Financial Management (FM)/Corporate Accounting /Financial Reporting and Analysis Office](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271508882288)
      - 1.22.4.1.3.2  [Chief Financial Officer/Financial Management/Government Payables & Funds Management (GPFM)](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507874384)
      - 1.22.4.1.3.3  [Taxpayer Services (TS)/Capital Management and Oversight (CMO)](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507870176)
      - 1.22.4.1.3.4  [Taxpayer Services (TS)/Media and Publications (M&P)/Technology and Program Support (TPS)](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507795088)
      - 1.22.4.1.3.5  [Correspondence Production Services (CPS) Sites](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271541287616)
      - 1.22.4.1.3.6  [Campus Locations and National Distribution Center (NDC)](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271513672240)
      - 1.22.4.1.3.7  [Media & Publications (M&P)](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507785728)
    - 1.22.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507618032)
    - 1.22.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271513700224)
    - 1.22.4.1.6  [Frequently used Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271513737840)
    - 1.22.4.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507533056)
  - 1.22.4.2  [Funding and Budget Administration](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271545529008)
  - 1.22.4.3  [Postage Cost Accountability Reporting Requirements for IRS Offices](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271541659056)
    - 1.22.4.3.1  [Postage Stamps](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271545485872)
    - 1.22.4.3.2  [Postage Meter Refill/Reset](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271540711600)
  - 1.22.4.4  [Permit Imprint](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271540707568)
  - 1.22.4.5  [Business Reply Mail (BRM)](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271540704496)
  - 1.22.4.6  [USPS Express Mail](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507719488)
  - 1.22.4.7  [Credits for Spoiled Postage](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507716016)
  - 1.22.4.8  [Records Disposition](https://www.irs.gov/irm/part1/irm_01-022-004#idm140271507866880)

# Part 1. Organization, Finance, and Management

# Chapter 22. Mail and Transportation Management

# Section 4. Postage Accountability and Reporting Requirements

* * *

## 1.22.4 Postage Accountability and Reporting Requirements

#### Manual Transmittal

December 06, 2024

#### Purpose

(1) This transmits revised IRM 1.22.4, Mail and Transportation Management, Postage Accountability and Reporting Requirements.

#### Material Changes

(1) IRM 1.22.4 revised throughout to update organizational title Wage and Investment to Taxpayers Services.

#### Effect on Other Documents

IRM 1.22.4, Postage Accountability and Reporting Requirements, dated October 13, 2023 is superseded.

#### Audience

IRS Employees

#### Effective Date

(12-06-2024)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.22.4.1** **(10-13-2023)**

### Program Scope and Objectives

1. Purpose: This IRM provides guidance for the IRS personnel responsible for purchasing and managing postage procured from the United States Postal Service (USPS). It also provides guidance for mailing operations responsible for reporting postal expenses through the Integrated Financial System (IFS). This guidance addresses specific types of postage and how two IRS offices (major cost center and non-major cost center) must report each postage type.

2. Audience: All IRS employees responsible for purchasing and managing postage from the USPS.

3. Policy Owner: Distribution Requirements resides within the office of Taxpayer Services (TS)/Customer Assistance Relationships and Education (CARE)/Media and Publications (M&P)/Technology and Program Support (TPS).

4. Program Owner: Technology and Program Support (TPS) is the program office responsible for overseeing and providing guidance for Postage Accountability and Reporting Requirements.

5. Primary Stakeholders:



   - IRS Business Units

   - Technology and Program Support

   - Postal and Transport Policy

   - All employees who use mailing and shipping services


6. Program Goals: To provide IRS USPS guidance to properly obtain postage and reconciliation of the postage budget.


**1.22.4.1.1** **(09-11-2018)**

#### Background

1. Proper postage accountability is an IRS priority and an area of focus by the Government Accountability Office (GAO) and the Treasury Inspector General for Tax Administration (TIGTA). Accurate postage expenditure information is critical to identifying opportunities for cost containment and developing future postal budget options.

2. The IRS annual USPS expenditures exceed $160 Million which is divided among 14 major costs centers and IRS administrative office locations. The two Correspondence Production Service Sites (CPS) are part of the 14 major cost centers and are responsible for approximately 88% of the annual USPS spend.


**1.22.4.1.2** **(01-14-2021)**

#### Authority

1. 41 CFR 102-192, Mail Management


**1.22.4.1.3** **(01-14-2021)**

#### Roles and Responsibilities

1. Responsibilities for the program are detailed in this subsection.


**1.22.4.1.3.1** **(01-14-2021)**

##### Chief Financial Officer (CFO)   /Financial Management (FM)/Corporate Accounting /Financial Reporting and Analysis Office

1. The CFO/FM/Corporate Accounting /Financial Reporting Analysis office is responsible for providing overall financial guidance for postage expenses.


**1.22.4.1.3.2** **(09-11-2018)**

##### Chief Financial Officer/Financial Management/   Government Payables & Funds Management (GPFM)

1. CFO/FM/GPFM staff:



   - Enters the obligation into IFS

   - Enters the advance into IFS

   - Enters Postage expenses and refunds into IFS

   - Compares expenses monthly for the 14 major cost centers to the OMAS spreadsheet and reports discrepancies to W&I/Capital Management and Oversight (CMO) Point of Contact (POC)


**1.22.4.1.3.3** **(09-11-2018)**

##### Taxpayer Services (TS)/Capital Management and Oversight (CMO)

1. TS/CMO staff:



   - Provides accounting string and Agency Cost Code information to M&P/Technology and Program Support (TPS)

   - Receives Notice correspondence volume and costing information from the M&P/Distribution Office of Taxpayer Correspondence (OTC) and the Correspondence Publishing Services (CPS) branch

   - Formulates annual postage estimates with commitment item (e.g., USPS, Transportation and Presort) in consultation with TPS

   - Provides the major cost centers estimates based on spending trends to formulate postal budgets

   - Notifies the TPS and the USPS by completing Form 1952, Annual Estimate of Anticipated Penalty Mail Usage, of any adjustments to amount of advance payments

   - Commits, obligates and monitors transportation funds and works with TPS on an ongoing basis

   - Provides GPFM the estimated obligation of funds using Form 2785, Requisition/Obligation Estimate Adjustment Notice

   - Reviews the advance backup documentation and completes the certification form for posting provided by the GPFM to determine adequacy of funds provided

   - Obtains receipt and acceptance certification from the Postal and Transport Policy section and TPS

   - Downloads monthly USPS expenditure report, converts it to Excel and adds the headers

   - Divides the report into 14 sections, prepares 14 corresponding reconciliation files and distributes the monthly USPS expenditure report to the major cost centers for reconciliation

   - Follows up with the reporting offices to determine proper disposition of discrepancies in transaction information

   - Notifies the GPFM of any changes needed in IFS and provides appropriate supporting documentation from the affected reporting offices


**1.22.4.1.3.4** **(09-11-2018)**

##### Taxpayer Services (TS)/Media and Publications (M&P)   /Technology and Program Support (TPS)

1. TS/M&P/TPS has the overall leadership of the Mail Management Program and is responsible for the following duties:



   - Provides guidance and support to the affected stakeholders, including expense verification, adjustments and reconciliation

   - Signs Advance Processing Form indicating receipt and acceptance

   - Disseminates accounting string information to all IRS offices along with Agency cost codes

   - Performs monthly postage expenditure reconciliation based on OMAS data of non-major cost centers


**1.22.4.1.3.5** **(01-14-2021)**

##### Correspondence Production Services (CPS) Sites

1. Correspondence Production Services (CPS) Sites will have a Point of Contact (POC) and an alternate who will account for the respective postage expense transactions, summaries and reconciliations.

2. The CPS major cost centers will be responsible for compiling and transmitting a weekly summary of transactions to the GPFM. This weekly summary is maintained to foster budget planning, verification and reconciliations of USPS billings.

3. The 5-digit Agency Cost Code must be recorded on all postal documents in the appropriate fields.

4. The date on the form must represent the week ending date.

5. CPS POCs maintain the Form 13490, Daily Transaction Record of IRS Postage, used to record daily transactions for postage expenses. The header information for the daily transaction record is derived from the Office Location/Cost Accounting Codes that includes:



   - Office Location

   - Office Location Code

   - Date on (mm/dd/yyyy) format

   - Sequence; this is the particular transaction sequence of the day showing first transaction as 1, second transaction as 2 and so on

   - Mail classification category as it appears on the USPS postage statement

   - Mail type - N for notices

   - Amount of transaction


6. Complete the Weekly Summary Report - The week's accumulation of Daily Transaction Records are compiled and summarized on Form 13491, Postage Weekly Summary Report.

7. The Weekly Summary Report must be prepared within 5 business days after the week ending date and sent to the GPFM for verification and entry into the IFS. The report can either be emailed to cfo.bfc.postage.expense.submission@irs.gov or faxed to 855-780-9044.

8. TS/CMO will breakout the Official Mail Accounting System (OMAS) bill by major cost center within 10 business days of the preceding months end and distribute to the POC. Within 10 business days after receipt, the POC will complete reconciliation of the OMAS bill and return to TS/CMO. If there are any discrepancies, the cost centers will document and research the discrepancies to completion and submit them to TS/CMO. TS/CMO will follow-up with the cost centers of any unresolved discrepancies the following month. If needed, the POC will submit all adjustments separately to the GPFM.


**1.22.4.1.3.6** **(01-14-2021)**

##### Campus Locations and National Distribution Center (NDC)

1. Campus locations and the National Distribution Center (NDC) major cost centers will establish a POC and an alternate who will be responsible for reconciling their respective postage expense transactions, summaries and reconciliations.

2. Monthly, the POC will submit a Form 10580-A, Postage Purchase/Expenditure Report for each postage meter refill. Any supporting documentation such as an email from the mailroom or a meter machine receipt that shows the amount added to that particular meter should be retained.

3. If there are no postage transactions for the previous month, a zero-dollar Form 10580-A must be completed.



1. The Form 10580-A, Postage Purchase/Expenditure Report must be prepared within 5 business days after the postage meter refill and sent to the GPFM for verification and entry into the IFS

2. Email the form to cfo.bfc.postage.expense.submission@irs.gov or fax to 855-780-9044.


4. TS/CMO will breakout the OMAS bill by major cost center within 10 business days of the preceding months end and distribute to the POC for reconciliation. If there are any discrepancies between the OMAS bill and monthly expenditures, the cost centers will research and document the findings. Within 10 business days after receipt, the POC will complete reconciliation of the OMAS bill and return to TS/CMO. TS /CMO will follow-up with the cost centers on any unresolved discrepancies the following month. If needed, the POC will submit all adjustments separately to GPFM.


**1.22.4.1.3.7** **(01-14-2021)**

##### Media & Publications (M&P)

1. Media & Publications (M&P) major cost center will establish a POC and an alternate who will account for the respective postage expense transactions, summaries and reconciliations.

2. M&P POC is responsible for tracking the postage usage contracted through the Government Publishing Office (GPO) and are monitored by the Publishing Division (PD) with M&P.

3. By the second business day of the month, PD submits several postage activity spreadsheets to TPS.

4. TPS will prepare a summary of the postage activity spreadsheet within 5 business days after the month ending date and send to the GPFM for verification and entry into the IFS. The spreadsheet can either be emailed to: cfo.bfc.postage.expense.submissions@irs.gov or faxed to 855-780-9044.

5. The 5-digit Agency Cost Code must be recorded on all postal documents in the appropriate fields.

6. TS/CMO will breakout the OMAS bill by major cost center within 10 business days of the preceding months end and distribute to the POC. Within 10 business days after receipt, the POC will complete reconciliation of the OMAS bill and return to TS/CMO. The POC will send it to the PD to reconcile their postage activity spreadsheets. If there are any discrepancies the POC will document and research the discrepancies to completion and submit them to TS/CMO. TS/CMO will follow-up with the POC of any unresolved discrepancies the following month. If needed, the POC will submit all adjustments separately to GPFM.


**1.22.4.1.4** **(01-14-2021)**

#### Program Management and Review

1. PTP reconciles the USPS postage expenditures monthly for M&P and the IRS Postage Meter refill charges by:



   - coordinating with Publishing to validate M&P postage expenses

   - finalizing the OMAS report and submitting to TS Finance and CFO for payment

   - reconciling monthly postage meter refill charges by comparing the OMAS Postage report data to the postage meter company usage report and the Forms 10580-A, Postage Purchase Expenditure Report, that the local offices submit

   - finalizing and submitting the report to TS Finance and CFO for payment.


**1.22.4.1.5** **(01-14-2021)**

#### Program Controls

1. Weekly Summary Report - The week's accumulation of Daily Transaction Records are compiled and summarized on Form 13491, Postage Weekly Summary Report. The header information for the weekly report is contained in the Office Location/Cost Accounting Codes. The information includes:



   - Office Location

   - Office Location Code

   - Week ending date (mm/dd/yyyy) format

   - Agency Cost Code

   - Accounting String

   - Mail Classification Category as it appears on the USPS postage statement

   - Mail type - N for notices

   - Total transaction for each Mail classification category

   - Total amount of transactions for the week


2. OMAS report - submitted by the United States Postal Service (USPS) which lists monthly postage expense.

3. Vendor Meter Reset Report - Distribution provides a monthly report to be used as a postage aid to complete reconciliation.

4. Form 10580-A, Postage Purchase/Expenditure Report, is used to reconcile postage meters and postage stamp expense. IRS employees who expend funds on postage meters or to procure postage stamps must submit a signed Form 10580-A within 5 days of expense of postal meter funds, or receipt of postage stamps.


**1.22.4.1.6** **(10-13-2023)**

#### Frequently used Terms and Acronyms

1. The following charts contain defined terms and acronyms used throughout this IRM:



**Terms**






| **Term** | **Definition** |
| --- | --- |
| Cost Center (formerly Cost Office) | The office benefiting from the goods or services being acquired. The cost cent captures and analyzes cost information for internal management purposes. |
| Intra-governmental Payment and Collection System (IPAC) | A standardized interagency fund transfer mechanism for Federal Program Agencies (FPA). IPAC facilitates the intra-governmental transfer of funds with descriptive data from one FPA to another. |
| Official Mail Accounting Systems (OMAS) | The postage accounting system USPS for federal government agencies. |
| Prepaid Expenses | Payments made by the IRS to vendors or other federal agencies to cover certain periodic expenses before those expenses are incurred. |







**Acronyms**






| **Acronym** | **Definition** |
| --- | --- |
| ADM | Administrative Mail |
| CFO | Chief Financial Officer |
| CMO | Capital Management and Oversight |
| FM | Financial Management |
| GAO | Government Accountability Office |
| GPFM | Government Payables & Funds Management |
| GPO | Government Publishing Office |
| IFS | Integrated Financial System |
| IPAC | Intra-governmental Payment and Collection |
| LPOC | Local Point of Contact |
| M&P | Media and Publications |
| NDC | National Distribution Center |
| OMAS | Official Mail Accounting System |
| OPN | Order Point Number |
| OSMS | Order and Management Subscription System |
| OTC | Office of Taxpayer Correspondence |
| POC | Point of Contact |
| TS | Taxpayer Services |
| TPS | Technology and Program Support |
| TIGTA | Treasury Inspector General for Tax Administration |
| TPOC | Territory Point of Contact |
| USPS | United States Postal Service |


**1.22.4.1.7** **(01-14-2021)**

#### Related Resources

1. All procedures and reporting requirements are applicable to 14 major cost centers:




| **Office** | **Location** |
| --- | --- |
| Campus Locations | - Andover<br>     <br>   - Atlanta<br>     <br>   - Austin<br>     <br>   - Brookhaven<br>     <br>   - Cincinnati<br>     <br>   - Fresno<br>     <br>   - Kansas City<br>     <br>   - Memphis<br>     <br>   - Ogden<br>     <br>   - Philadelphia |
| Correspondence Production Services (CPS) Sites | - Detroit<br>     <br>   - Ogden |
| National Distribution Center (NDC) | - Bloomington |
| M&P | - Washington |

2. Form 10580-A, Postage Purchase/Expenditure Report, is available on Media and Publications web site at: href=http://core.publish.no.irs.gov/forms/internal/pdf/f10580-a--2020-10-00.pdf and is 508 compliant.

3. Form 13490, Daily Transaction Record of IRS Postage, is available on Media and Publications web site at: href=http://core.publish.no.irs.gov/forms/internal/pdf/f13490--2009-11-00.pdf and is 508 compliant.

4. Form 13491, Postage Weekly Summary Report, is available on Media and Publications web site at: href=http://core.publish.no.irs.gov/forms/internal/pdf/f13491--2009-11-00.pdf and is 508 compliant.

5. Document 12829, General Records Schedule 12, Communication Records

6. All IRS forms identified in these instructions and procedures can be obtained electronically from M&P intranet website at: href=http://publish.no.irs.gov/catlg.html.

7. The USPS forms and publications are available through your servicing Postal Business Center, USPS National Customer support Center, USPS website at:href=https://about.usps.com/resources


**1.22.4.2** **(01-14-2021)**

### Funding and Budget Administration

1. Funding for the purchase of postage resides in the Taxpayer Services (TS) financial plan. Processing the funding activities resides in TS/Capital Management Oversight (CMO). Reconciliation of the USPS expenditure report and the transactions in Integrated Financial System (IFS) are a joint responsibility of the cost centers and TS/CMO with collaborative support of Government Payables & Funds Management (GPFM) as needed.

2. The USPS bills the IRS monthly via the Intra-governmental Payment and Collection (IPAC) system for one-twelfth of the yearly postage estimate. The USPS provides TS, Media and Publications (M&P) and CMO a record of the Service's postage expenditures reported through the USPS Official Mail Accounting System (OMAS). In October of the following fiscal year, USPS will send a 13th IPAC for the previous fiscal year which includes the difference between the annual estimate and the actual annual usage.

3. When operating under a continuing resolution (CR) postage obligations will be committed and posted in accordance with CR guidance. Upon passage of an appropriation bill, postage obligations will be committed and posted quarterly; advances will be approved by TS/CMO Finance and posted monthly by GPFM. Expenditures will be posted weekly for the two CPS major cost centers, monthly for M&P and the remaining 11 major cost centers. The postage expense for the non-major cost centers will be posted within 10 business days of receipt in the Government Payables and Funds Management Office.

4. The following material group codes, general ledger accounts and internal order codes will be used to report postage commitments, obligations and expenses:



   - R2207 6100.2381 4KPNO - Notices

   - R2207 6100.2382 4KPTP - Tax Products

   - R2207 6100.2385 4KPAD - Administrative Mail


**1.22.4.3** **(01-14-2021)**

### Postage Cost Accountability Reporting Requirements for IRS Offices

1. All IRS Offices (except the major cost centers) expending postage funds are required to report postage purchases and expenses on a transactional basis.

2. The Form 10580-A, Postage Purchase/Expenditure Report must be prepared and submitted within 5 business days of purchase to M&P, TPS and GPFM for verification and entry into the IFS. The form can either be emailed to cfo.bfc.postage.expense.submissions@irs.gov or faxed to 855-780-9044.

3. All IRS offices must report all types of postage purchase transactions.

4. TS/CMO will provide the monthly OMAS files to M&P TPS to reconcile Form 10580-A expenditures.

5. TS/CMO will separate the OMAS bill by major cost center within 10 business days of the preceding months end and distribute to the POC within three days of download and distribute to the POC. Within five business days after receipt, the POC will complete reconciliation of the OMAS bill and return to TS/CMO. If there is a total fiscal year cumulative variance over 5% between the expenditures and the OMAS report, M&P TPS will document, research and resolve the discrepancies to bring the non-major cost centers within a 5% total fiscal year cumulative tolerance.

6. TS/CMO will receive the completed monthly reconciliation and follow-up with M&P TPS or USPS if discrepancies are not resolved within the 5% total fiscal year cumulative tolerance. If needed, the non-major cost centers will submit all adjustments to M&P TPS and GPFM via Form 10580-A.


**1.22.4.3.1** **(10-13-2023)**

#### Postage Stamps

01. Employees can order postage stamps using Order and Subscription Management System (OSMS) for fulfillment by the National Distribution Center (NDC).

02. The process for ordering stamps using OSMS:



    - Provides a more robust ordering process

    - Improves postage accountability

    - Increases cost savings

    - Reduces paperwork for the customer

    - Reduces delivery time for the customer


03. When using OSMS to order stamps, employees must:



    - Access OSMS

    - Enter OPN (Order Point Number)

    - Enter the catalog number for the desired postage stamp


04. When ordering Postage Stamps from USPS, the current USPS PS Form 17-G, Federal Agency Stamp Requisition, must be used.



    - Employees must submit a completed PS Form 17-G to the USPS by either fax, email or mail as indicated on the form.



      ### Note:



      Penalty Mail Stamps are no longer issued by the USPS; commercial Forever stamps are now distributed. Offices may use any remaining Penalty Mail stamps until the supply is exhausted.


05. Individual offices are now limited to $600 of commercial postage stamps per order and a maximum of two orders per month.

06. The requestor must email a copy of the PS Form 17-G to ts.mp.postal.mail.services@irs.gov.

07. All exceptions must be approved by contacting DRB at ts.mp.postal.mail.services@irs.gov. Please include the following in your email request:



    - Copy of PS Form 17-G, Federal Agency Stamp Requisition

    - Justification/explanation of need

    - Whether the stamps will be used by the entire group, a portion of the group or an individual

    - How long will this stamp supply last


08. In the event a supply of stamps is needed due to a natural disaster contact DRB at ts.mp.postal.mail.services@irs.gov for guidance.

09. Within 5 days of receipt of the postage stamps, the employee must prepare and submit the following to GPFM and DRB:



    - Form 10580-A, Postage Purchase/Expenditure Report

    - PS-17G, Federal Agency Stamp Requisition

    - USPS Stamp Fulfillment packing slip


10. Submit via email to: cfo.bfc.postage.expense.submissions@irs.gov and ts.mp.postal.mail.services@irs.gov, Subject: Postage Stamp Order.

11. A copy of the Form 10580-A, PS Form 17-G and the USPS packing slip must be retained by the reporting office.

12. Ordering offices must monitor and ensure all commercial stamps are being used for Official Government Use only.


**1.22.4.3.2** **(01-14-2021)**

#### Postage Meter Refill/Reset

1. To refill/reset a postage meter, the initiating office must follow the refill/reset procedures as required by the postage meter manufacturer.

2. Upon successful completion of the postage meter refill, the initiating office must prepare and submit Form 10580-A, Postage Purchase/Expenditure Report, to the GPFM and TPS within 5 business days of the postage transaction.

3. Submit via email to: cfo.bfc.postage.expense.submissions@irs.gov and ts.mp.postal.mail.services@irs.gov, Subject: Postage Meter Refill.

4. A copy of Form 10580-A must be retained by the reporting office along with any USPS certified postal documents.

5. For locations using the National Mail contract, the Territory Point of Contact (TPOC), or the mail program office responsible for administering and monitoring the contract must follow the same procedures.


**1.22.4.4** **(01-14-2021)**

### Permit Imprint

1. Permit Imprint mailing is an economical method of postage payment for bulk mail such as letters to tax return preparers and other mass mail outs. Minimum volume requirements are 500 pieces for First-Class Mail and 200 pieces or 50 pounds for Marketing Mail, previously known as Standard Mail.

2. All Permit Imprint mailings shall be coordinated through the M&P organization.

3. The initiating office must prepare and submit Form 10580-A, Postage Purchase/Expenditure Report, to the GPFM within 5 business days of the postage transaction. The form can either be emailed to cfo.bfc.postage.expense.submissions@irs.gov or faxed to 855-780-9044.


**1.22.4.5** **(09-11-2018)**

### Business Reply Mail (BRM)

1. Individual field offices are not required to track and/or report BRM volumes and/or costs. The BRM postage is monitored monthly by the TS/CMO organization.


**1.22.4.6** **(01-14-2021)**

### USPS Express Mail

1. The LPOC must report to the GPFM all USPS Express Mail labels charged to the IRS Federal Agency Code (218), using Form 10580-A, Postage Purchase/Expenditure Report.

2. The LPOC must prepare and submit Form 10580-A, Postage Purchase/Expenditure Report, to the GPFM within 5 business days of the postage transaction. The form can either be emailed to cfo.bfc.postage.expense.submission@irs.gov or faxed to 855-780-9044.

3. A copy of Form 10580-A and the certified copy of the USPS Express Mail labels must be retained by the reporting office.

4. If the postage of the USPS Express Mail package is added using a postage meter, this expense will be included in the postage meter usage report.


**1.22.4.7** **(01-14-2021)**

### Credits for Spoiled Postage

1. Any office claiming credits for spoiled postage must complete PS Form 3533, Application for Refund of Fees, Products, and Withdrawal of Customer Accounts, to receive a refund from the USPS. The completed form must accompany the spoiled stamps, meter strips, or envelopes when presented to the local Post Office that licensed the meter. Unused or spoiled stamps are considered for refund only if submitted within 60 calendar days of the postage meter date. The Post Office will issue a refund check or Postal Money Order.

2. The LPOC must prepare and submit the following to the GPFM within 5 business days of the transaction:



   - Form 10580-A, Postage Purchase/Expenditure Report

   - Other documentation that lists the dollar amount of the refund check for Postal Money Order

   - Original PS Form 3533, and

   - Refund check or Postal Money Order


> IRS/Government Payables and Funds Management
>
> 110 North Heber Street
>
> Beckley, WV 25801-4501

3. Copies must be retained by the reporting office.

4. All postal refund checks or money orders submitted to TPS will be returned to the originating office.


**1.22.4.8** **(09-11-2018)**

### Records Disposition

1. The disposition of all postal records, consisting of Post Office forms, supporting documentation, mail control records and agency copies of penalty mail reports will be handled in accordance with Document 12829, General Records Schedule 12; Communication Records. Document 12829 is available at: href=http://publish.no.irs.gov/getpdf.cgi?catnum=54713


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-022-004#addtoany "Show all")

A2A