---
url: "https://www.irs.gov/irm/part1/irm_01-029-001"
title: "1.29.1 Authorities and Responsibilities | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-029-001#main-content)

- 1.29.1  [Authorities and Responsibilities](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743880320)
  - 1.29.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743568096)
    - 1.29.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131776423296)
    - 1.29.1.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131776419968)
    - 1.29.1.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131771328528)
      - 1.29.1.1.3.1  [Chief Risk Officer](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131771323472)
      - 1.29.1.1.3.2  [Enterprise Audit Management](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743820512)
      - 1.29.1.1.3.3  [Lead Stakeholder Executive](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743897616)
      - 1.29.1.1.3.4  [Business Unit Program Managers and Subject Matter Experts (SME)](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743891152)
      - 1.29.1.1.3.5  [Primary Business Unit Audit Liaison and Staff](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743679632)
      - 1.29.1.1.3.6  [JAMES Audit Coordinators (JACs)](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743671872)
      - 1.29.1.1.3.7  [Legislative Affairs](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743470528)
    - 1.29.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743466368)
    - 1.29.1.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743463040)
    - 1.29.1.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743559344)
    - 1.29.1.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131771449872)
    - 1.29.1.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743749600)
  - 1.29.1.2  [Introduction to Audit Program](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743740304)
    - 1.29.1.2.1  [External Entities with Audit Authorities](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743734224)
    - 1.29.1.2.2  [Specific Statute Authorities](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743725664)
    - 1.29.1.2.3  [The Audit Process](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131776382384)
    - 1.29.1.2.4  [Audit Preparation Strategies](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131776379488)
    - 1.29.1.2.5  [Audit Initiation and Notification](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131776376944)
    - 1.29.1.2.6  [The Opening/Entrance Conference](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743321440)
    - 1.29.1.2.7  [Information Document Requests](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743315504)
    - 1.29.1.2.8  [Site Visits](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743307152)
    - 1.29.1.2.9  [TIGTA Site Visits](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743304736)
    - 1.29.1.2.10  [GAO Site Visits](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743302256)
    - 1.29.1.2.11  [Site Visit Close Out Meeting](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743295104)
    - 1.29.1.2.12  [The Mid-Point Conference](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743290240)
    - 1.29.1.2.13  [The Exit/Closing Conference](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743285200)
    - 1.29.1.2.14  [Statement of Facts or Agreement to Facts](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743280944)
    - 1.29.1.2.15  [Discussion Draft Report (TIGTA Only)](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743275504)
    - 1.29.1.2.16  [Draft Report](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743267760)
    - 1.29.1.2.17  [Preparing a Management Response](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743255536)
    - 1.29.1.2.18  [The Response Letter](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743252832)
    - 1.29.1.2.19  [Strategies for Preparing a Timely Response](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743248192)
    - 1.29.1.2.20  [Response Content and Structure](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743241776)
    - 1.29.1.2.21  [Responding to Recommendations](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743235440)
    - 1.29.1.2.22  [Planned Corrective Actions](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743228432)
    - 1.29.1.2.23  [Developing A Planned Corrective Action](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743453552)
    - 1.29.1.2.24  [Signatory Authority](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743444832)
    - 1.29.1.2.25  [Signature Process](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743441456)
    - 1.29.1.2.26  [Distribution Restrictions](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743429936)
    - 1.29.1.2.27  [Publication of Auditor’s Report](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743426704)
    - 1.29.1.2.28  [Limited Official Use and Sensitive But Unclassified Reports](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743422864)
  - 1.29.1.3  [Monitoring Planned Corrective Actions](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743415472)
    - 1.29.1.3.1  [Closing Planned Corrective Actions](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743410704)
    - 1.29.1.3.2  [Extending Planned Corrective Actions](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743396512)
    - 1.29.1.3.3  [Requirements for Form 13872 and Supporting Documentation](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743389472)
    - 1.29.1.3.4  [Retention Period for Documentation](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743374768)
    - 1.29.1.3.5  [Background – Monthly Closed Sample Review](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743372000)
      - 1.29.1.3.5.1  [Research, Applied Analytics and Statistics (RAAS) - Statistics of Income (SOI) Team Partnership](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743368448)
      - 1.29.1.3.5.2  [Monthly Closed Sample Quality Review Controls](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743363136)
      - 1.29.1.3.5.3  [Addressing Insufficient Closures](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743356320)
      - 1.29.1.3.5.4  [Monthly Sample Reviews Associated with Financial Statement Audit](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743342592)
    - 1.29.1.3.6  [Joint Audit Management Enterprise System](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743339392)
      - 1.29.1.3.6.1  [JAMES User Account Access and Recertification](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131743331904)
      - 1.29.1.3.6.2  [JAMES User Roles](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742358208)
      - 1.29.1.3.6.3  [JAMES Numbering - Audit Reports](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742350192)
      - 1.29.1.3.6.4  [JAMES Numbering - Findings, Recommendations, and PCAs](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742344096)
      - 1.29.1.3.6.5  [Important JAMES Data and Fields](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742328544)
      - 1.29.1.3.6.6  [JAMES Due Date Guidance and Requirements](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742287232)
      - 1.29.1.3.6.7  [Entering New Audit Reports into JAMES](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742265120)
    - 1.29.1.3.7  [Root Cause](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742256080)
    - 1.29.1.3.8  [Guidance for Recommendations on Hold](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742251536)
    - 1.29.1.3.9  [Managing Unique PCA Activities](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742244592)
    - 1.29.1.3.10  [EAM Reporting](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742213232)
    - 1.29.1.3.11  [Tracking and Reporting Outcome Measures](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742205024)
    - 1.29.1.3.12  [Guidance for Tracking Time Spent on Audit Activities](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742191648)
  - Exhibit  1.29.1-1  [Audit Life Cycle](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742186144)
  - Exhibit  1.29.1-2  [180-Day Letter Response](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742183152)
  - Exhibit  1.29.1-3  [Categories for Delays/Extensions in JAMES](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742169904)
  - Exhibit  1.29.1-4  [Evidentiary Documentation Examples](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742157280)
  - Exhibit  1.29.1-5  [Audit Outcome Measures](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742053680)
  - Exhibit  1.29.1-6  [Root Cause for Findings – Definitions & Examples](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131742015328)
  - Exhibit  1.29.1-7  [Authority to Disclose Memorandum](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131741992192)
  - Exhibit  1.29.1-8  [Timekeeping Definitions and Examples](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131741973632)
  - Exhibit  1.29.1-9  [Record Retention Schedule and Interim File Plan](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131741959872)
  - Exhibit  1.29.1-10  [Form 13782 Closure Checklist](https://www.irs.gov/irm/part1/irm_01-029-001#idm140131741948128)

# Part 1. Organization, Finance, and Management

# Chapter 29. Audit Coordination Process

# Section 1. Authorities and Responsibilities

* * *

## 1.29.1 Authorities and Responsibilities

#### Manual Transmittal

October 21, 2024

#### Purpose

(1) This transmits revised IRM 1.29.1, Audit Coordination, Process, Authorities and Responsibilities.

#### Material Changes

(1) _IRM 1.29.1.3.1(1)d,_ Incorporated Interim Guidance Memorandum, Control # OCRO-01-0822-0003. Technical Correction to July 2022 IRM 1.29.1 Revision. Closing Planned Corrective Actions revised to “A significant time gap is more than 60 days”.

(2) _IRM 1.29.1.3.8(1)b,_ Incorporated Interim Guidance Memorandum, Control # OCRO-01-0822-0003, Technical Correction to July 2022 IRM 1.29.1 Revision. Clarifying requirements for recommendations that remain in hold status.

(3) IRM 1.29.1.2.16(3) corrected wording for link from “See Audit Report Redaction Request document” to “See Audit Redaction Guide”.

#### Effect on Other Documents

IRM 1.29.1, dated 07-15-2022, is superseded.

#### Audience

All IRS Executives, Managers, Audit Liaisons, and JAMES Audit Coordinators.

#### Effective Date

(10-21-2024)

Michael Wetklow

Chief Risk Officer

**1.29.1.1** **(07-15-2022)**

### **Program Scope and Objectives**

1. Purpose



1. This IRM provides information and guidance on the audit process and responsibilities for all stakeholders throughout the audit lifecycle from the planning phase through the closure of planned corrective actions for recommendations. Enterprise Audit Management (EAM) ensures sensitive, significant, or controversial issues are elevated internally so senior leadership is aware and corrective actions plans can be put in place as soon as possible.

2. This IRM also provides guidance on promoting and maintaining a collaborative, professional, and positive partnership with IRS oversight entities that supports our respective roles throughout the lifecycle of each audit while working to achieve program and performance improvements across the IRS enterprise. For further guidance related to the management of the financial statement audit or the annual management report, contact the CFO-FM audit team.

3. This IRM does not address investigation inquiries conducted by the TIGTA Office of Investigations.

4. Business units may have a local IRM. Standard Operating Procedures (SOPs) or documented process guidelines. However, the business unit specific guidance must conform to IRM to IRM 1.29.1. If there are any conflicts between IRM 1.29.1 and the business unit guidance, including IRMs or (SOPs). IRM 1.29.1 has precedence and should be followed by the business units as IRM 1.29.1 has Servicewide coverage.


.



2. Audience: All IRS Executives, Managers, Audit Liaisons, Audit Coordinators, and JAMES Audit Coordinators.

3. Policy Owner: Chief Risk Officer (CRO).

4. Program Owner: Enterprise Audit Management (EAM) (an organization within CRO).

5. Primary Stakeholders: All IRS Business Units are affected by these procedures or have input to the procedures. The effects may include a change in workflow, additional duties, change in established time frames, and similar issues.

6. Program Goals:



1. Cultivate a collaborative partnership between external oversight and IRS officials to establish trust and confidence.

2. Facilitate the audit process, ensuring auditors have access to the people and information they need to conduct each audit, while at the same time resolving any issues that arise during the audit.

3. Prioritize corrective actions that address the highest risk and deliver the most value.

4. Ensure a consistent and repeatable audit process within the IRS and between the IRS and oversight entities.


**1.29.1.1.1** **(07-15-2022)**

#### Background

1. The IRS is subject to audits conducted by the Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) to ensure its programs and activities operate efficiently, effectively, and according to established policies and procedures. Tracking issues, findings, recommendations, and the current status of Planned Corrective Actions (PCA) resulting from audits is mandatory to comply with the intent of the GAO standards for internal control. Treasury implemented the Joint Audit Management Enterprise System (JAMES) audit tracking system for use by all bureaus to track, monitor, and report the status of audit results.

2. Most audit reports contain recommendations for improving internal controls or taking other steps to reduce opportunities for waste, mismanagement or misuse of resources, abuse, and fraud. The IRS is required to respond to these recommendations by stating whether or not the IRS agrees and, if so, what actions the IRS intends to take in order to implement a business solution in response to the recommendation. The steps the IRS intends to take are documented as a PCA and are discussed in attachments to the management response to the TIGTA report and to the 180-Day Letter response to Congress. They are also uploaded into JAMES for tracking and monitoring purposes.


**1.29.1.1.2** **(07-15-2022)**

#### Authorities

1. The authorities for the policies and procedures discussed in this IRM include:



1. [Inspector General Act of 1978, as amended, 5 U.S.C. app. (2012 & Supp. IV 2017)](https://uscode.house.gov/view.xhtml?path=/prelim@title5/title5a/node20&edition=prelim).

2. [Federal Managers Financial Integrity Act of 1982 (FMFIA) (31 U.S.C. 3512(c),(d)](https://www.law.cornell.edu/uscode/text/31/3512).

3. Federal Financial Management Improvement Act of 1996, (FFMIA, Pub. L. No. 104- 208, 110 Stat. 3009.

4. Chief Financial Officers (CFO) Act of 1990, Pub. L. No. 101-576, 104 Stat. 2838 (Nov. 15, 1990), as amended by the Government Management Reform Act of 1994.

5. Pub. L. No. 103-356, 108 Stat. 3410 (Oct. 13, 1994).

6. [Title 26 authority for IRC for disclosure i.e., 26 U.S.C. 6103 and Delegation Order 11-2](https://www.law.cornell.edu/uscode/text/26/6103).

7. [Good Accounting Obligation in Government Act of 2019](https://home.treasury.gov/about/budget-financial-reporting-planning-and-performance/good-accounting-obligation-in-government-act-gao-ig-act-reports#:~:text=The%20Good%20Accounting%20Obligation%20in,has%20remained%20unimplemented%20for%20one).

8. [OMB Circular A-50 Audit Follow-up.](https://obamawhitehouse.archives.gov/omb/circulars_a050/).

9. [Inspector General Empowerment Act of 2016.](https://www.ssa.gov/legislation/legis_bulletin_011117.html#:~:text=On%20December%2016%2C%202016%2C%20the,performance%20of%20their%20investigative%20duties.)


2. Treasury Policy Statements provide authority for the work being done over the audit lifecycle which include:



1. Treasury Directive 40-02, Government Accountability Office (GAO) Audits.

2. Treasury Directive 40-03, Treasury Audit Resolution, Follow-up, and Closure.

3. Office of Management and Budget Circular A-123, Management's Responsibility for Enterprise Risk Management and Internal Control.

4. Treasury Order 115-01.


**1.29.1.1.3** **(02-03-2021)**

#### Responsibilities

1. This section list responsibilities for:



1. Chief Risk Officer

2. Enterprise Audit Management

3. Lead Stakeholder Executive

4. Business Unit Program Managers and Subject Matter Experts (SMEs)

5. Business Unit GAO/TIGTA Audit Liaison

6. JAMES Audit Coordinators (JACs)

7. Legislative Affairs


**1.29.1.1.3.1** **(02-03-2021)**

##### Chief Risk Officer

1. The Chief Risk Officer is responsible for:



1. Overseeing the IRS enterprise risk management program.

2. Providing program oversight to the business units tasked with the completion of corrective action plans related to recommendations arising from TIGTA and GAO audits, including review, validation, and approval of the supporting documentation.

3. Ensuring that appropriate IRS officials are informed of issues or findings that negatively impact IRS.

4. Overseeing the IRS JAMES post audit tracking program.

5. Representing the IRS in the audit resolution process when there is disagreement with an audit recommendation to attempt to negotiate and resolve differences before referral to the Deputy Secretary of the Treasury.

6. Advising and consulting with the Treasury Deputy Chief Financial Officer whenever a matter will be referred to the Deputy Secretary for resolution.

7. Coordinating the IRS response according to policies established under Treasury.


**1.29.1.1.3.2** **(07-15-2022)**

##### Enterprise Audit Management

1. Enterprise Audit Management is responsible for:



01. Serving as the single point of contact (SPOC) for GAO and TIGTA audits and TIGTA Inspections and Evaluation events.

02. Liaising between the IRS and GAO/TIGTA when addressing significant issues that arise during an audit.

03. Providing guidance and support to business units on the audit process, including post audit tracking and monitoring of corrective actions.

04. Identifying audit stakeholders and assigning audit ownership, based on input from the business units.

05. Transmitting audit notifications, engagement letters, draft and final audit reports, or other audit-related documents to the appropriate offices.

06. Providing input to the business units as they develop responses to audit reports.

07. Monitoring the timeliness of IRS responses to ensure due dates are met.

08. Updating and maintaining the Enterprise Audit Database.

09. Elevating significant issues, concerns, audit findings, or related matters through the management chain to appropriate IRS leadership for information and action.

10. Validating that the audit information entered by TIGTA into JAMES is correct, including findings, recommendations, PCAs, Responsible Officials and Due Dates.

11. Ensuring appropriate IRS officials, including the Management Controls Executive Steering Committee, are informed of situations for elevation.

12. Approving planned corrective actions for closure after reviewing documentation provided by the business units and approving business unit requests for extension of PCA due dates.

13. Ensuring audit-related records, including communications, materials provided to auditors, and documentation for planned corrective actions are maintained and properly stored for future reference.

14. Providing monthly documentation to GAO for all PCAs closed the previous month for their evaluation. EAM does not provide TIGTA with equivalent data as TIGTA has access to JAMES and monitors PCA closures in that manner.

15. Conducting the Closed Sample Quality Review to validate evidentiary documentation provided by the business units meets closure requirements.

16. Conducting statistical analysis on open audits, closed audits and PCAs.

17. Monitoring priority recommendations in collaboration with the business units and providing data and/or information to TIGTA or GAO and to senior leadership.

18. Collaborating with Treasury on matters related to JAMES, including system updates and enhancements.

19. Coordinate with GAO to secure updates on open corrective actions from the BUs.

20. Generation of weekly and bi-weekly reports highlighting audit activity, such as the _Reports Awaiting Publication, TIGTA/GAO Weekly Report, Redaction Pending Report, and Draft Response Due Report._

21. Retaining audit records in accordance with appropriate records retention requirements issued by the National Archives and Records Administration (NARA). See _Exhibit 1.29.1-9_ for the Record Retention Schedule pertaining to audit records and the Interim File Plan.


**1.29.1.1.3.3** **(02-03-2021)**

##### Lead Stakeholder Executive

1. The Lead Stakeholder Executive is responsible for:



1. Leading all engagements with auditors, including opening conferences, mid-point conferences, agreement to facts discussions, closing conferences, and any discussions of findings.

2. Setting the appropriate tone for the audit.

3. Identifying internal IRS stakeholders who need to be involved in the audit and ensuring their participation.

4. Leading the development of the IRS’s response to audit reports and recommendations.

5. Leading the timely implementation of corrective actions designed as a result of audit findings or recommendations.

6. Ensuring the deadlines for completing corrective actions are met, and that documentation supporting closure of a corrective action is comprehensive and accurate.

7. Reviewing and approving Form 13872, Planned Corrective Action (PCA) Status Update for TIGTA/GAO/MW/SD/TAS/REM Reports. The Lead Stakeholder Executive’s signature on the form indicates review, approval and certification of the actions taken.

8. Ensuring implemented corrective actions resolve the issues identified by TIGTA/GAO.


**1.29.1.1.3.4** **(02-03-2021)**

##### Business Unit Program Managers and Subject Matter Experts (SME)

1. Business Unit Program Managers and subject matter experts are responsible for:



01. Understanding the audit process.

02. Actively participating in any audits under their purview or requiring their expertise.

03. Providing accurate and up-to-date information to auditors and internal IRS stakeholders.

04. Responding timely and completely to requests for information.

05. Maintaining open lines of communication.

06. Elevating significant audit risks and findings to Enterprise Audit Management and business unit leadership.

07. Ensuring the IRS’s position is supported by facts, data and appropriate documentation.

08. Drafting the management response to the Draft Report and the 180-Day Letter (for GAO audits) and collaborate with business unit liaisons for routing the package through the approval process for their organizational segment.

09. Preparing detailed and achievable corrective actions that fully address the findings and recommendations in the report, have realistic implementation dates and are accurately assigned to the appropriate business owner.

10. Providing Form 13872 and all supporting documentation to the business unit Liaison or JAMES Audit Coordinators to request closure or extension of a corrective action.

11. Ensuring requests for closures are completed and entered into JAMES on or before the PCA due date to allow timely review by EAM.

12. Ensuring status updates and requests for extensions are entered into JAMES on or before the due date of the PCA.


**1.29.1.1.3.5** **(07-15-2022)**

##### Primary Business Unit Audit Liaison and Staff

1. The primary Business Unit Audit Liaison is responsible for:



01. Serving as the primary point of contact for their business unit for the open audit process (or evaluation process).

02. Ensuring the timely and appropriate dissemination of information, audit materials and responses to relevant stakeholders.

03. Coordinating the engagement of relevant business unit personnel in the audit process.

04. Advising business unit subject matter experts, managers, and executives on the audit process. Monitoring business unit work on corrective actions and updating the Enterprise Audit Database and JAMES, as appropriate.

05. Monitoring business unit work throughout the audit and during post-audit tracking, updating the Enterprise Audit Database or JAMES as appropriate.

06. Reviewing new GAO and TIGTA audits entered into JAMES to ensure the accuracy of the findings and related root causes, recommendations, PCAs, due dates, potential and actual monetary benefits, and assignments of responsibility.

07. Ensuring that Form 13872 status updates, requests for closure or requests for extension are concise, clear and comply with reporting requirements.

08. Ensuring requests for closures are entered into JAMES on or before the PCA due date to allow timely review by EAM.

09. Retaining audit records in accordance with appropriate records retention requirements issued by the National Archives and Records Administration (NARA). See IRM 1.15, Records and Information Management, and Document 1299.

10. Ensuring all individuals or organizations identified as support are invited to discussions from the opening conference to the closing conference, including internal preparation meetings. For Counsel, individual attorneys identified as Counsel points of contact for a specific audit are identified in the Significant Contacts portion of the GAO/TIGTA audit database.


**1.29.1.1.3.6** **(02-03-2021)**

##### JAMES Audit Coordinators (JACs)

1. The JAMES audit coordinators (JACs) are responsible for:



1. Monitoring business unit work on corrective actions and updating JAMES as necessary.

2. Monitoring requests for closure, requests for extensions and requests for status updates to ensure the Form 13872 provide appropriate data and comply with reporting requirements.

3. Providing PCA analysis to their business unit audit liaisons.

4. Serving as the JAMES expert for their business unit.

5. Providing any additional information or documentation requested by EAM as part of the review process.

6. Resolving deficiencies and communicating results of the sample reviews, including copies of Form 14668, IRS Quality Assurance Review of Closed Planned Corrective Action (PCA) Notification with the appropriate business unit management.

7. Updating JAMES routinely on the status of open PCAs.

8. Retaining audit records in accordance with appropriate records retention requirements issued by the National Archives and Record Administration (NARA). See IRM 1.15 series, Records and Information Management.


**1.29.1.1.3.7** **(02-03-2021)**

##### Legislative Affairs

1. Legislative Affairs is responsible for:



1. Facilitating the 180-Day Letter approval process with the business units, including routing the 180-Day Letter package to the Deputy Commissioners or Commissioner for signature and mailing the 180-Day Letter responses to Congress.

2. Establishing the e-Trak control for 180-Day Letters upon the issuance of the final report by GAO and providing it to EAM for tracking.


### Note:

The 180-Day Letter process was formerly referred to as the 60 Day Letter process. However, the Good Accounting Obligation in Government Act (P.L. 115-414; January 3, 2019) amended 31 USC 720(b) to increase the timeframe to 180 days.

**1.29.1.1.4** **(02-03-2021)**

#### Program Management and Review

1. Program Monitoring: EAM participates in all stages of a GAO or TIGTA audit, supporting the affected business unit(s) and monitoring timeliness. EAM ensures that requested information is provided to the auditor on a timely basis, that management responses and planned corrective actions are effectively articulated, and that PCAs are executed and properly documented upon completion and closure.

2. Program Effectiveness: EAM monitors business unit progress toward completing and closing PCA. EAM provides status and progress reports to IRS leadership on a regular, recurring basis.

3. JAMES is the system of records used to monitor audit related recommendations and corrective actions taken by each bureau within the Department of Treasury. Access to JAMES is requested by EAM and controlled by Treasury through defined user roles. EAM owns relationship management responsibilities with Treasury for JAMES.


**1.29.1.1.5** **(02-03-2021)**

#### Program Controls

1. Enterprise Audit Management maintains the Enterprise GAO/TIGTA Audit Database that employs access profiles (read only and read only/update) and specific data field lock down procedures to control access and information updates. Access is requested and granted through Online 5081.

2. JAMES users are assigned specific privileges based upon their program role. The three main profiles are JAMES Editor (JE), JAMES PO (JPO), for the Bureau Program Office users (referred as JACs), and JAMES User (JU) for Bureau Program Office Read Only. Only the JAMES Editor can approve and validate PCAs for implementation in the JAMES database. JAMES Users must ensure that documentation uploaded into JAMES to support completion of a Planned Corrective Action (PCA) does not include any taxpayer data or Personally Identifiable Information (PII).


**1.29.1.1.6** **(07-15-2022)**

#### Terms/Definitions

1. The following table provides a list of terms and definitions.




| Terms | Definitions |
| --- | --- |
| **180-Day Letter** | The 180-Day Letter is an updated response to a GAO final report with recommendations sent to Congress. The IRS has 180 days from the issuance of the final audit report to respond to Congress with the detailed corrective actions to be taken and time frames within which they will be implemented to carry out the recommendation(s).<br> <br>### Note:<br>The 180-Day Letter process was formerly referred to as the 60 Day Letter process. However, the Good Accounting Obligation in Government Act (P.L. 115-414; January 3, 2019) amended 31 USC 720(b) to increase the timeframe to 180 days. |
| **A6 Audit Summary Report** | A report generated from JAMES is used to verify information entered into JAMES. The report contains a summary of findings, recommendations and PCAs, including the amount of any potential monetary benefits and root cause. Generally, the information in this report, for TIGTA audits, is entered into JAMES by TIGTA. EAM enters relevant data from the GAO final reports for GAO recommendations and their corresponding corrective actions. |
| **Agreement to Facts (ATF)** | A document issued by TIGTA after fieldwork has been conducted but before any report drafts have been produced. This document represents statements about IRS programs or processes that TIGTA audited and believes to be factually accurate based on their fieldwork and research. The IRS has the opportunity to review this document and provide corrections. |
| **Audit** | An examination of government programs, operations, and/or financial records. Audit is interchangeable or synonymous with review. |
| **Audit Liaison** | Business unit single point of contact responsible for audit activity within that particular business unit. |
| **Corrective Action** | A detailed description of how management will implement a recommendation to address the audit finding(s). |
| **Defense Contract Audit Agency (DCAA)** | The Defense Contract Audit Agency is the primary contract audit agency for the Department of Defense, which also services Federal civilian agencies. DCAA audit services are intended to be a key control to help assure that prices paid by the Federal Government for goods and services are fair and reasonable and that contractors bill the Federal Government in accordance with applicable laws, cost accounting standards, and contract terms. |
| **Discussion Draft Report (DDR)** | Issued by TIGTA at the conclusion of fieldwork. Provides IRS management an opportunity to review the report for accuracy and discuss findings presented in the report, before issuance of a formal draft report. |
| **Draft Report** | A formal report of audit findings and recommendations prepared after completion of an audit. The IRS is given a specified time by GAO and TIGTA to respond to the draft report, typically 30 days. EAM receives this report from GAO or TIGTA and sends an e-mail transmitting the draft report to the business units and provides guidance for developing and routing management’s response. |
| **Engagement Letter/Notification Letter** | A letter sent to the IRS from GAO or TIGTA notifying IRS of a new audit. TIGTA typically uses the term Engagement letter, while GAO uses Notification letter. |
| **Exit/Closing Conference** | Meeting to discuss GAO's or TIGTA's preliminary findings and recommendations with business unit executives. IRS provides TIGTA/GAO with their perspective/position on the audit findings and shares draft proposed corrective actions. Discussions during the exit/closing conference often forms the basis for management’s response. |
| **Extended/Delayed** | An option in JAMES used to extend a PCA due date, which requires the selection of a reason code from a drop-down listing. |
| **Final Report** | The final report is the final version of the GAO or TIGTA draft report that may or may not contain modifications to the findings and recommendations identified in the draft report. The final report contains the IRS management response to the draft report. Final reports are released to the public, unless designated as Sensitive But Unclassified (SBU) or Limited Official Use (LOU). |
| **Findings** | Describes the deficiency or opportunity for improvement in the audit report or remediation plan. |
| **Form 13872, Planned Corrective Action (PCA) Status Update for TIGTA/GAO/MW/SD/REM Reports** | The form is used by all business units to upload PCAs into JAMES, such as closing, extending the due date, and/or making status updates for audits, material weaknesses and significant deficiencies. |
| **Form 14668, IRS Quality Assurance Review of Closed Planned Corrective Action (PCA) Notification** | The form used by EAM to conduct the review of PCA closures as part of the Closed Sample Quality Review. |
| **Functional Coordinator** | An individual responsible for coordinating TIGTA/GAO activity within a sub section of a business unit’s organization. Generally, the functional coordinators liaise with the primary audit liaison within their business unit for any business unit-wide efforts. |
| **GAO Status Checkbox** | Records an update in JAMES to validate the closure of the recommendation by GAO. While JAMES notates that the IRS has closed a GAO recommendation, the recommendation is not completely closed until GAO validates the closure. |
| **HOLD** | The status of the PCA in JAMES when the business unit agrees with the GAO/TIGTA recommendation, deems the PCA to be mission critical but no budget funding is available for its execution and, therefore, will be placed on hold. See _IRM 1.29.1.3.8_, Guidance for Placing Recommendation on Hold. |
| **Inspection & Evaluation (I&E)** | TIGTA I&E provides a range of specialized services and products, including inspections of IRS programs compliance with laws, regulations, policies and procedures and more in-depth evaluations. In addition, I&E performs reviews of internal TIGTA programs and controls. The process for I&E audits is the same as any TIGTA audit. |
| **Internal Control** | An integral component of an organization’s management that ensures processes work as intended and promotes integrity, accountability, and efficiency in IRS’s efforts to serve taxpayers. |
| **JAMES Editor** | JAMES role with access to all JAMES capabilities used by EAM and CFO-FM (for financial statement audit) to perform the following actions:<br> <br>   - Enter GAO/TIGTA audit report findings, recommendations, and PCAs into JAMES.<br>     <br>   - Approve/validate status updates entered by program users.<br>     <br>   - Reject status updates if they do not meet all reporting requirements and notify the JAMES Program Office (JAMES PO) user that the status was rejected and the reason for the rejection.<br>     <br>   - FM Audit Team Editors are responsible for entering and validating GAO financial statement related audits. |
| **JAMES Program Office (JAMES PO)** | The JAMES role used primarily by the business units to read and update PCAs and to upload supporting documentation. The JAMES PO can view LOU and SBU audit reports as long as the PCA is assigned to their organization. |
| **JAMES Recertification** | Annual verification of each JAMES user account to confirm that the account is still necessary or should be removed. |
| **JAMES User (JAMES USER)** | The JAMES role that provides read-only access to the JAMES database for non-SBU reports and support documentation for all business units. This role also has the capability to view LOU and SBU audit reports or use the supporting documentation feature for their assigned business units only. |
| **Job Code** | Job code is the six-digit audit engagement number employed by the GAO auditors to keep track of the time spent on the actual audit. |
| **Joint Audit Management Enterprise System (JAMES)** | Treasury’s web-based audit tracking system used for tracking audits, findings, recommendations, and PCAs from TIGTA and GAO audit reports. |
| **Lead or Lead Stakeholder** | Business unit with primary responsibility for the subject matter of the audit and for specific audit process actions/tasks. |
| **Liaison/Representative/Coordinator** | Business unit single point of contact responsible for audit activity within that particular business unit. |
| **Limited Official Use (LOU) Reports/Sensitive But Unclassified (SBU) Report** | A draft or final GAO or TIGTA report limited to internal distribution because of its sensitivity. These reports are not released to the public. GAO LOU reports are limited to certain internal IRS audiences and Congress. |
| **Management Controls Executive Steering Committee (MC ESC)** | Oversight body with responsibility over the Financial Statement audit remediations and corrective actions. |
| **Mid-Point Conference** | Interim meeting to discuss GAO’s or TIGTA’s audit and findings to date. It gives IRS an early look at audit issues, potential findings, and recommendations, and allows IRS to provide further clarification or documentation related to information shared during audit field work. EAM recommends the Lead Stakeholder Executive attends this session. |
| **Opening/Entrance Conference** | At the opening conference, GAO or TIGTA outlines the scope of their audit, its objectives, locations to be visited, anticipated date of completion, the names of auditors working on the job, and background information. GAO typically uses the term Entrance Conference while TIGTA uses the term Opening Conference. The Opening Conference sets the stage for the audit so expectations about recurring meetings, points of contacts, expectation of a mid-point conference, etc. should be discussed. |
| **Planned Corrective Action (PCA)** | Contains a detailed description of how management will implement a recommendation to address the audit finding(s). The PCA also includes due date(s) and the responsible official(s). |
| **Primary Audit Liaison** | The business unit leader for all activities pertaining to TIGTA/GAO audits, who is responsible for coordinating across their business unit as needed. |
| **Recommendation** | Issued by the GOA/TIGTA auditors, at the conclusion of the audit that addresses the audit findings which will correct the issue. |
| **Redaction** | To redact language contained within a formal audit report means to “edit text for publication, censor or obscure part of the text for legal or security purposes, or to remove text from a document prior to publication or release.” This step in the review process is essential for the protection of sensitive information that could be used to circumvent the law. It is also used to withhold from the public information the disclosure of which is controlled by statute, such as IRC 6103, the Freedom of Information Act, and the Privacy Act. The redaction request is submitted to GAO/TIGTA with the management response to the draft report and should demonstrate the text to be redacted and justification for the redaction. |
| **Significant Deficiency** | A deficiency, or a combination of deficiencies, in internal controls that is less severe than a material weakness, yet important enough to merit the attention of those charged with governance. A deficiency in internal control exists when the design or operation of a control does not allow management or employees, in the normal course of performing their assigned functions, to prevent, detect and correct misstatements on a timely basis. |
| **Stakeholder** | An organization or person with responsibility or a vested interest in the subject matter of an audit. |
| **Statement of Facts** | Issued by GAO, similar to the Agreement to the Facts Report issued by TIGTA. Provides IRS management and stakeholders an opportunity to review audit findings in writing for accuracy and discuss findings presented in the report. The Statement of Facts does not typically include recommendations so IRS staff should inquire if GAO will be proposing any. |
| **Status Update** | Provides actions taken by the business unit that correct identified deficiencies, produce recommended improvements, and/or demonstrate progress made. For a PCA with an initial due date more than 24 months from the date of the final report (long-term PCA), a status update is required every 12 months. |
| **Supporting Business Unit** | A business unit that shares some responsibility for programs or processes being audited but is not the audit’s lead stakeholder. A supporting business unit may have a small or large share of the work associated with the process under audit or may indirectly support the process itself through separate work. |
| **Unified Work Request (UWR)** | Indicates whether Information Technology services are involved in the completion of a PCA. The UWR must be implemented before EAM or CFO-FM will close a related PCA. Submission of the UWR does not constitute closure but should be notated in JAMES. Examples of corrective actions required UWR submissions are forms or system updates, new systems and system enhancements. |


**1.29.1.1.7** **(02-03-2021)**

#### Acronyms

1. The following chart contains acronyms that are used throughout this IRM.




| Acronym | Meaning |
| --- | --- |
| ACE | Audit Community Expertise |
| ADP | Automated Data Processing |
| ATF | Agreement to Facts |
| BMF | Business Master File |
| BPR | Business Performance Review |
| BU | Business Unit |
| CFO | Chief Financial Officer |
| CFO-FM | Chief Financial Officer, Financial Management Division |
| CIR | Commissioner, Internal Revenue |
| COP | Community of Practice |
| CRO | Chief Risk Officer |
| DCAA | Defense Contract Audit Agency |
| DDR | Discussion Draft Report |
| DR | Draft Report |
| DCOS | Deputy Commissioner for Operations Support |
| DCSE | Deputy Commissioner for Services and Enforcement |
| EAM | Enterprise Audit Management |
| ESC | Executive Steering Committee |
| e-Trak | Electronic Information Tracking |
| FARS | Financial Analysis and Reporting System |
| FFMIA | Federal Financial Management Improvement Act of 1996 |
| GAO | Government Accountability Office |
| GRS | General Records Schedule |
| I&E | Inspection & Evaluation (TIGTA) |
| IC | Internal Control |
| IDR | Information Document Request |
| IDS | Intrusion Detection System |
| IMF | Individual Master File |
| IPU | Internal Procedural Update |
| IRC | Internal Revenue Code |
| IRM | Internal Revenue Manual |
| JAC | JAMES Audit Coordinator |
| JAMES | Joint Audit Management Enterprise System |
| JPO | JAMES PO |
| LOU | Limited Official Use |
| MC ESC | Management Controls Executive Steering Committee |
| MOU | Memo of Understanding |
| MW | Material Weakness |
| NARA | National Archives and Records Administration |
| OIG | Office of the Inspector General, Treasury |
| PCA | Planned Corrective Action |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| PII | Personally Identifiable Information |
| PPKM | Privacy Policy & Knowledge Management |
| RAAS | Research Applied Analytics and Statistics |
| Responsible Officials | Usually refers to staff in EAM or CFO-FM |
| ReM | Remediation Plan |
| SBU | Sensitive But Unclassified |
| SD | Significant Deficiency |
| SERP | Servicewide Electronic Research Program |
| SETR | Single Entry Time Reporting |
| SME | Subject Matter Expert |
| SOF | Statement of Facts |
| SOI | Statistics of Income |
| SOP | Standard Operating Procedures |
| TAS | Taxpayer Advocate Service |
| TBO | To Be Determined |
| TIGTA | Treasury Inspector General for Tax Administration |
| TOM | TIGTA Operating Manual |
| UWR | Unified Work Request |


**1.29.1.1.8** **(02-03-2021)**

#### Related Resources

1. Related resources for this IRM include:



1. Office of Management and Budget [website](https://www.whitehouse.gov/omb) at _https://www.whitehouse.gov/omb._

2. Government Accountability Office [website](https://www.gao.gov/) at _https://www.gao.gov._

3. Treasury Inspector General for Tax Administration [website](https://www.treasury.gov/tigta/) at _https://www.treasury.gov/tigta._


2. Treasury Directive 40-02, Government Accountability Office (GAO) Audits.

3. Treasury Directive 40-03, Treasury Audit Resolution, Follow-Up, and Closure.

4. Treasury Directive 40-04, Treasury Internal (Management) Control Program.

5. GAO Green Book.

6. TIGTA Operating Manual (TOM).


**1.29.1.2** **(02-03-2021)**

### Introduction to Audit Program

1. EAM is responsible for coordinating internal IRS support for audit activities conducted by external entities possessing the statutory and regulatory authority to review, evaluate, and report on IRS business processes, outputs, and outcomes.

2. EAM acts as the primary IRS liaison to these external entities, and additionally maintains key relationships with business units through embedded audit liaisons (alternatively referred to a business unit audit liaison or JAMES Audit Coordinators – JACs).

3. EAM facilitates audits throughout the audit lifecycle, from audit initiation through the reporting phases and post-audit monitoring. Important information about each audit is documented and available via the Enterprise Audit Database. The Enterprise Audit Database is the official system of records for all official documents associated with GAO/TIGTA audits.

4. Once final audit reports are issued, EAM is responsible for monitoring the status of PCAs, validating the documentation submitted by business units to close PCAs, and ensuring record keeping via JAMES.

5. EAM, through the \*Audit Coordination mailbox _(Audit.Coordination@IRS.gov)_ is the single point of contact for all official correspondence pertaining to all GAO and TIGTA audits, including all audit and post-audit activity.

6. EAM is responsible for oversight of the entire audit lifecycle, including audit and corrective action inventory resolution, analysis and reporting to the Senior Leadership Team, and providing support to the business units.


**1.29.1.2.1** **(02-03-2021)**

#### External Entities with Audit Authorities

1. Government Accountability Office (GAO) is an independent nonpartisan agency that works for Congress. GAO supports Congress in meeting its constitutional responsibilities and helping to improve the performance and ensure the accountability of the federal government for the benefit of the American people.



1. GAO gathers information to help Congress determine how well executive branch agencies are performing. GAO routinely answers such basic questions as whether government programs are meeting their objectives or providing good service to the public. Ultimately, GAO ensures that the government is accountable to the American citizens. To that end, GAO provides Congress with the best information available to help them arrive at informed policy decisions – information that is accurate, timely, and balanced.

2. GAO has several audit teams dedicated to IRS activities. This workforce is comprised almost exclusively of career employees who have a strong knowledge of IRS programs and policies.


2. The Treasury Inspector General for Tax Administration (TIGTA) is organizationally placed within the Department of the Treasury but is independent of the Department of the Treasury and all other Treasury offices, including the Treasury Office of the Inspector General. TIGTA focuses entirely on tax administration, while the Treasury Office of the Inspector General is responsible for overseeing the other Treasury bureaus.



1. TIGTA’s Office of Audit identifies opportunities to improve the administration of the nation’s tax laws by conducting comprehensive, independent performance and financial audits of IRS programs, operations, and activities to: assess efficiency, economy, effectiveness, and program accomplishment; ensure compliance with laws and regulations; prevent, detect, and deter fraud, waste, and abuse.

2. TIGTA’s Office of Audit program consists of reviews mandated by statute or regulation and sometimes at the request of Congress or IRS management, as well as reviews identified through the Office of Audit’s planning and evaluation process. TIGTA publishes an Annual Audit Plan at the beginning of each fiscal year.

3. TIGTA’s Office of Inspections and Evaluations provides a range of specialized services and products, including quick reaction reviews, on-site inspections of an office, and in-depth evaluations of a major departmental function, activity or program. Evaluations often result in recommendations to streamline operations, enhance data quality, and minimize inefficient and ineffective procedures. The Office of Inspections and Evaluations also publishes an annual audit plan.


**1.29.1.2.2** **(02-03-2021)**

#### Specific Statute Authorities

1. GAO auditors are authorized access to returns and return information pursuant to 26 U.S.C. § 6103(f)(4)(A) and 26 U.S.C. § 6103(i)(8). GAO must notify the Congressional Joint Committee on Taxation when seeking access to returns or return information requested under 26 U.S.C. § 6103(i)(8). The basis for GAO’s authority to access tax returns and return information must be cited in GAO’s notification letter for the audit, if such access is required for the purposes of the audit. If GAO is not granted this access by Congress, then they are not authorized to receive any returns or return information during the audit. See IRM 11.3.23, Disclosure to the Government Accountability Office (GAO). GAO's access to return information is subject to the safeguarding requirements of 26 U.S.C. 6103(p)(4) and adherence with IRS Publication 1075, Tax Information Security Guidelines for Federal State and Local Agencies. See IRM 11.3.36, Disclosure of Official Information, Safeguards Review Program.



### Note:



GAO has two types of access, IRS site access and taxpayer information access. In some instances, a GAO auditor may have been cleared for IRS site access but not cleared for taxpayer information access. It is critical to know if GAO auditors have been authorized access to returns and return information.





### Note:



GAO auditors may require an IRS escort for a site visit. The GAO Auditor Access List on the Audit Community Expertise (ACE) SharePoint site contains a column for both site and taxpayer info. The access list is updated monthly and should be checked to ensure that the auditors have proper authorization for the visit.





### Note:



Business Units are required to prepare the disclosure accounting statutorily required by 26 U.S.C. 6103(p)(3)(A) when GAO has authorized access to tax records. See IRM 11.3.37, Disclosure of Official Information, Record keeping and Accounting for Disclosures. Disclosures of Privacy Act protected records (for example: personnel records, travel vouchers, timekeeping records) also require an accounting of Disclosure by the custodian of the record. See IRM 10.5.6.7, Privacy Act Accounting for Disclosures (formerly IRM 11.3.19).

2. TIGTA auditors have authorized access to returns and return information pursuant to 26 U.S.C. § 6103(h)(1). See IRM 11.3.22.7, The Treasury Inspector General for Tax Administration. TIGTA personnel are authorized access to all facilities, the Oversight Board, and the Office of Chief Counsel (including computer facilities, computer rooms, electronic databases and files, electronic and paper records, reports and records, as well as other material that pertains to the IRS programs and operations). See Treasury Order 115-01 on the Treasury [website](https://www.treasury.gov/) at https://www.treasury.gov.



1. The Treasury order covers all pre-audit activity and formal audits initiated by an engagement letter.

2. EAM, business unit audit liaisons, and appropriate IRS officials are required to cooperate with TIGTA once the TIGTA auditor shows proper identification. If the business unit audit liaison has questions regarding TIGTA’s presence, the liaison should consult with EAM.

3. TIGTA maintains their procedural guidance for conducting audits in the TIGTA Operating Manual, Chapters 300-900, on their [website](https://www.treasury.gov/tigta/) at https://www.treasury.gov/tigta.


**1.29.1.2.3** **(02-03-2021)**

#### The Audit Process

1. GAO and TIGTA audit processes are similar. The overall process is described in this IRM in general terms. Where there are significant distinctions between GAO and TIGTA processes, they are specifically noted. See_Exhibit 1.29.1-1_, Audit Life Cycle.

2. The term “auditor” will generally be used to describe both GAO and TIGTA unless there is a specific notation otherwise.


**1.29.1.2.4** **(02-03-2021)**

#### Audit Preparation Strategies

1. Using the Pre-Audit Readiness Tool fosters discussion about programs and/or processes subject to audit and identify opportunities for improvement before an audit begins. The use of the PART can assist management in fulfilling its responsibility for monitoring their internal controls and evaluating the results to ensure they are operating effectively.

2. Conducting a more limited Environmental Scan allows the business unit to identify the program challenges and the potential issues that may arise during the coming audit.


**1.29.1.2.5** **(07-15-2022)**

#### Audit Initiation and Notification

01. Audit agencies will notify the IRS of a new audit by issuing a notification (GAO terminology) or engagement (TIGTA terminology) letter. This letter may be addressed to the responsible program executive, business unit head of office, Chief Risk Officer, one of the Deputy Commissioners, or the Commissioner depending on the scope and nature of the audit. GAO/TIGTA electronically transmits the letter to EAM via the EAM mailbox at Audit.Coordination@IRS.gov. EAM is responsible for processing the notification or engagement letter.



    ### Note:



    Audit.Coordination@IRS.gov is the familiar e-mail address used for the mailbox inside the IRS network. The actual email address is Audit.Coordination@IRS.gov



     .



02. EAM will review the letter and identify the appropriate internal stakeholders, delineating the lead stakeholders as well as supporting business units. If the audit’s scope is too broad to clearly identify a lead stakeholder, EAM will engage with the business units who share responsibility for the program(s) being audited to obtain consensus on audit ownership.

03. EAM will retransmit the letter internally to lead stakeholder(s) and supporting business units and identify individual points of contact within those business units in the event they differ from the designated business unit audit liaisons.

04. If the auditor provided any additional documentation with the letter, such as Congressional authorization to access tax information or a request for information, it will also be provided to the business units. If the auditor provided any additional documentation with the letter, such as Congressional authorization to access tax information or a request for information, it will also be provided to the business units.

05. EAM will confirm receipt of the letter with the auditor and provide appropriate contact information for the audit.

06. EAM will update the Enterprise Audit Database with pertinent information related to the audit.

07. Auditors will sometimes directly contact business units with notification letters or requests for information related to audits that have not yet been formally initiated. If this happens, then business units should comply with the auditor’s request. However, the business unit must also immediately notify EAM and their embedded audit liaison of the information request. EAM may need to provide special instructions or engage with the auditor, particularly if the information request is from GAO and involves providing protected tax, taxpayer, or other personally identifiable information.

08. While Congress has the authority to grant GAO the authority to receive federal tax information protected by IRC 6103, only the IRS may authorize IRS employees to disclose employees to disclose the federal tax information to GAO. IRS provides protected federal tax information to GAO under either the authority of IRC 6103(f)(4) or 6103(i)(8). Under IRS Delegation Order 11-2, IRM 1.2.2.11.2, the Director, Enterprise Audit Management (EAM) has delegated authority to authorize the disclosure of federal tax information.



    1. EAM will provide the business unit head of office with the authority to disclose memorandum upon notification from GAO that either 1) a new audit with Congressional IRC 6103 authority to receive federal tax information is being initiated; or 2) an ongoing GAO audit which previously did not include the authority to receive federal tax information has subsequently been authorized to receive federal tax information.

    2. Upon receipt of the authority to disclose memorandum from EAM, the business unit head of office should immediately provide the authority to disclose memorandum to the lead audit liaisons for that business unit. In addition, the head of office should establish local controls to ensure that their business unit completes the statutorily required accounting for disclosures in a timely and accurate manner.

    3. EAM will also establish an internal control to prompt follow-up with the business unit at the time of the Statement of Fact issuance since most data should be provided to GAO for an audit by the time the Statement of Fact is received from GAO.

    4. In addition to other recommended additions to this section, if the GAO audit involves returns or return information, the “special instructions” EAM provides to the business unit should include specific guidance for accounting for the disclosures under IRC 6103(p)(3)(A) and IRM 11.3.37.



       ### Note:



       Neither the Office of Disclosure or EAM are responsible for preparing or submitting the accountings for disclosure. The business unit employee responsible for disclosing returns or return information to the GAO auditors is responsible. If the disclosures to GAO include Privacy Act protected information (example: personnel records, travel vouchers, timekeeping records), 5 U.S.C. 552a(c) also requires an accounting of disclosure. See IRM 11.3.23, Disclosure of Official Information, Disclosure to the Government Accountability Office (GAO).


09. Auditors will provide notification to the IRS regarding any significant changes in the audit plan during the audit process, in the event the auditor deems such changes necessary. These may include scope changes, adjusted site visit plans, access to taxpayer information, audit closings or cancellations, temporary suspensions of audit activities, or other changes. If such notification is received, EAM will notify the appropriate IRS stakeholders of the change(s) as soon as possible. If the notification is provided directly to the business unit, they will forward it to EAM.

10. TIGTA will publish or otherwise make available an annual audit plan describing audits that are scheduled to be conducted during the plan’s fiscal year. This list should not be considered definitive as audits may be cancelled or added during the year, but it is a useful planning tool for the IRS to ensure resources are available to support the audit when the time comes. The IRS is given the opportunity to suggest audits for upcoming fiscal years during an annual TIGTA data call.

11. TIGTA sometimes engages in pre-audit activities that do not warrant or result in a formal audit notification letter. These situations can include audit planning and research activities (surveys, information gathering, etc.), and integrity projects. These activities may also be focused on a specific audit that they intend to conduct in the future. In these instances, TIGTA sends an email notification to Audit.Coordination@IRS.gov mailbox. The e-mail indicates the audit number, if known, the scope of the work and the anticipated time frames. EAM will provide a copy of this electronically to the lead stakeholder. The IRS must provide TIGTA with requested information during pre-audit activities in the same manner as in a formal audit. This includes data as well as access to the appropriate IRS subject matter experts and/or points of contacts.

12. If TIGTA or the Treasury OIG do not provide an audit or engagement number for the pre-audit activities, EAM will assign an internal control number. For TIGTA, the audit number is FYTRESXXX; for OIG the audit number is FYORESXXX, where FY is the fiscal year and XXX is sequential numbering; and for GAO, the audit number is FYGRESXXX, where FY is the fiscal year and XXX is sequential numbering.


**1.29.1.2.6** **(02-03-2021)**

#### The Opening/Entrance Conference

1. The IRS and auditors will generally convene an entrance (GAO terminology) or opening (TIGTA terminology) conference prior to the start of the audit. The auditor will identify their staff working on the audit, outline the scope of the audit, any locations to be visited, information that is to be requested, provide additional background, and answer questions for the IRS.

2. The entrance/opening conference is a critical, initial opportunity for the lead IRS executive to discuss background information, provide a perspective on the program or process being audited, set expectations for the audit, including agreeing on a mid-point or other periodic briefings, and establish a positive rapport with the audit team.

3. The business unit audit liaison for the lead stakeholder is responsible for coordinating and scheduling opening conferences with GAO/TIGTA and appropriate IRS personnel (to include EAM staff via the \*Audit.Coordination@IRS.gov mailbox). EAM records the entrance/opening conference in the Enterprise Audit Database.

4. Business units involved in the audit are responsible for identifying key staff and subject matter experts, and ensuring they participate in the entrance/opening conference and all subsequent meetings. The business unit audit liaison for the lead stakeholder must also ensure the appropriate executive is available to lead the discussion during the entrance/opening conference and is engaged in other critical audit phase milestones.

5. Entrance conferences with GAO should be scheduled within 14 calendar days following the request for a meeting. GAO generally will not begin work until the entrance conference has occurred. TIGTA scheduling is more fluid; auditors may begin work prior to an opening conference. It is imperative that business units schedule opening conferences with TIGTA shortly after receipt of the engagement letter; especially when TIGTA has already sent an email notification of planning/research.

6. The business unit audit liaison for the lead stakeholder is responsible for identifying and coordinating across all supporting business units, including but not limited to, meeting invites, documents and internal coordination discussions. There may be limited circumstances when EAM will serve as the coordinating organization when no one business unit owns more than half of the program or process under audit.


**1.29.1.2.7** **(02-03-2021)**

#### Information Document Requests

1. Some auditors will use a document request log, known as an Information Document Request (IDR), for monitoring and tracking. While not a requirement, use of an IDR is mutually beneficial in tracking requests made during an audit. The audit number and title should be listed on the log and the IDR items numbered sequentially. If the auditor does not use an IDR, the business unit audit liaison may wish to create one for their own tracking purposes.



### Note:



When the IDR includes requests for returns, return information or records subject to the Privacy Act, a tracking log is required to ensure proper recordation and accounting of disclosures to the GAO and tracking of original documents if applicable.

2. Information requested by auditors should be provided as soon as possible, typically within two weeks. When a response cannot be provided within this time frame, business unit audit liaisons, in conjunction with EAM, should work with the auditor to determine an achievable timeframe.

3. If returns, return information, Privacy Act protected information and/or PII is requested by an auditor, the IRS program owner of the information is responsible for ensuring:



1. The auditor’s authorization to receive that information is properly documented.

2. The information is transmitted or otherwise provided in a confidential and secure manner (with appropriate encryptions, if transmitted electronically).

3. Extraneous private information is not inadvertently or unnecessarily released.

4. Accountings for disclosure (GAO only) are prepared and processed. Business units may contact EAM for additional guidance, if needed.



      ### Note:



      GAO's security policy prohibits accepting emails containing return information from IRS employees, even in encrypted attachments. Transmission of SBU information to GAO should be coordinated with EAM.


4. The audit number (and IDR number, if used) should be included in the email subject line when requested information is provided to an auditor. The business unit audit liaison is responsible for ensuring that the appropriate and correct documentation is provided and for ensuring that the documentation is maintained in accordance with record retention requirements.


**1.29.1.2.8** **(02-03-2021)**

#### Site Visits

1. Auditors may choose to conduct site visits during the course of an audit. Specific sites may be identified by the auditor at the time of initial engagement, and additional sites may be added during the audit.

2. The business unit liaison for IRS staff designated by the business unit liaison should be available in the site to ensure auditors have access to the people and information they need to conduct their audit.


**1.29.1.2.9** **(02-03-2021)**

#### TIGTA Site Visits

1. TIGTA is organizationally placed within the Department of the Treasury, and part of the Executive Branch of government. TIGTA auditors are authorized access to IRS offices and sites during their audit, following IRS security protocols (such as those applicable to IRS employees.).

2. The business unit audit liaison for the lead stakeholder is responsible for coordinating site visit activities between TIGTA and the on-site personnel.


**1.29.1.2.10** **(02-03-2021)**

#### GAO Site Visits

1. GAO is part of the Legislative Branch of government; thus, site visit procedures are more complex.

2. Site visits take place after the opening conference. GAO auditors who have been authorized to have access to IRS sites and/or tax information are listed on one of two authorization lists:



1. List of GAO personnel designated to have access to returns and return information.

2. List of GAO employees designated as agents of the Joint Committee on Taxation, Senate Committee on Finance and/or the House Committee on Ways and Means authorized to have access to tax return and return information.


3. These lists are provided to the IRS semiannually, with monthly updates, and are stored on the Audit Community Expertise (ACE) SharePoint site.

4. If the auditor is not on the list, and/or the business unit liaison cannot verify the job code number, then the business unit liaison will notify EAM immediately and must not allow access to information. If the audit is not tax return or return information-related, the auditor may proceed with the audit with proper government identification.

5. The business unit audit liaison for the lead stakeholder is responsible for coordinating site visit activities between GAO and the on-site personnel. In addition, the area Senior Commissioner’s Representative should also be notified of the GAO site visit.

6. GAO sometimes contracts out audit services, and their contractors accompany them at local sites. In this instance, an IRS employee must accompany the group during the entire visit to ensure that the contractor is not allowed access to tax information.

7. If GAO arrives without prior notice, on-site personnel and the business unit liaison should request the audit job code number and reason for the visit and contact EAM as well as the appropriate business unit leadership.


**1.29.1.2.11** **(02-03-2021)**

#### Site Visit Close Out Meeting

1. At the conclusion of local site work, the auditor may hold a closeout meeting with business unit officials responsible for operations at the local site. The purpose of the closeout meeting is to:



1. Obtain local management input about observations made while at the site and provide additional information or obtain clarification.

2. Discuss the implications of the information gathered at the site.

3. Identify additional relevant information, potentially leading to further data gathering.


2. The business unit audit liaison for the lead stakeholder is responsible for coordinating site visit closeout meeting between the auditor and IRS management.

3. The business unit audit liaison for the lead stakeholder is responsible for notifying EAM of the meetings and elevating to EAM any significant or potentially significant issues that arose from the site visit.


**1.29.1.2.12** **(02-03-2021)**

#### The Mid-Point Conference

1. A mid-point conference is an interim meeting to discuss any issues, concerns, or findings the auditor has identified and may wish to share.

2. Mid-point conferences are not mandatory, but they are good business practice because they allow the IRS an opportunity to hear early issues or preliminary findings identified by TIGTA or GAO and provide clarification, perspective or additional documentation related to the program area being audited. Mid-point conferences are critical opportunities to begin framing management’s response, remediate findings that warrant immediate action, and discern potential corrective actions. For priority or elevated audits, conducting a mid-point conference is strongly recommended.

3. Mid-point conferences are also good opportunities to review the audit’s timetable and the projected dates for the end of field work and the issuance of reports. This will give business unit staff the opportunity to begin to prepare for the final stages of the audit process.

4. The business unit audit liaison for the lead stakeholder is responsible for coordinating the mid-point conference and for notifying EAM of the meeting itself, and/or of any significant issues or concerns that may arise from the meeting. EAM records the date of the mid-point conference in the Enterprise Audit Database.


**1.29.1.2.13** **(02-03-2021)**

#### The Exit/Closing Conference

1. An exit (GAO terminology) or closing (TIGTA terminology) conference is held at the conclusion of an audit to verify that all information, as presented is accurate. This ends the information gathering phase. This is also an opportunity for both sides to review the findings, discuss and clarify issues, and reach consensus, if possible. After the exit conference is completed, the auditor uses the additional information gathered to prepare the draft report. EAM records the date of the exit conference in the Enterprise Audit Database.

2. The business unit audit liaison for the lead stakeholder should schedule an internal meeting to include EAM and all IRS stakeholders prior to the exit/closing conference. The purpose of this internal meeting is to discuss the IRS’s position on the facts, findings and potential recommendations.

3. The auditor may share a Statement of or Agreement to Facts document with the IRS prior to or for use during the exit/closing conference. This document may not contain recommendations, but the business unit audit liaison for the lead stakeholder should inquire about prospective recommendations. GAO does not typically provide recommendations in writing in advance of their draft report, whereas TIGTA will. However, GAO often verbally communicates planned recommendations during exit conferences. If there are any disagreements or concerns about the proposed recommendations or other aspects of the audit, discuss the disagreement and propose alternatives if possible.


**1.29.1.2.14** **(02-03-2021)**

#### Statement of Facts or Agreement to Facts

1. Auditors may provide a Statement of (GAO terminology) or Agreement to (TIGTA terminology) Facts document in the latter stages of an audit. This document will discuss the facts of the program or process under audit, as the auditor understands them, and may provide some insight into the auditor’s pending conclusions.

2. If the Statement of or Agreement to Facts document is provided directly to the lead stakeholder or business unit audit liaison, it should be retransmitted to EAM via the EAM mailbox at Audit.Coordination@IRS.gov. If the document is provided directly to EAM, EAM will retransmit it to the appropriate stakeholders and business unit audit liaisons. In either case, EAM will update the Enterprise Audit Database accordingly.

3. EAM and the business unit audit liaison for the lead stakeholder must ensure all internal IRS stakeholders review and comment on the Statement of or Agreement to Facts document. The business unit audit liaison for the lead stakeholder may distribute an IRS Comments Matrix to capture comments, corrections, and other information by report section and page number. The matrix is typically emailed to GAO/TIGTA to facilitate discussions.

4. The business unit audit liaison for the lead stakeholder should arrange an internal IRS stakeholder meeting to discuss comments on the Statement of or Agreement to Facts document prior to the conference with the auditors to discuss the documents to coordinate the lead stakeholder and supporting stakeholder(s) perspective and input.

5. If a discussion of the Statement of or Agreement to Facts document is not already planned as part of the exit conference, then the business unit audit liaison for the lead stakeholder should schedule a meeting (including EAM and all other appropriate IRS internal stakeholders) with the auditor to discuss the document. EAM will record the date of a Statement of or Agreement to Facts meeting with GAO/TIGTA in the Enterprise Audit Database.


**1.29.1.2.15** **(07-15-2022)**

#### Discussion Draft Report (TIGTA Only)

1. After issuing an Agreement to Facts document, TIGTA will prepare and send a Discussion Draft Report to the IRS. The IRS has five business days to provide responsive comments. A Discussion Draft Report (DDR) is an informal version of an audit report and follows the same format of a Draft Report. It will generally describe the audit background, the auditor’s process, findings, general conclusions, and may include preliminary recommendations. The DDR will be shared with the IRS for review and comment.



1. Recommendations contained in a DDR are subject to change; they may be added, modified, or deleted after the DDR is shared with the IRS.

2. GAO does not issue DDRs; this process is unique to TIGTA.


2. The Information Technology Division has an approved IRM deviation whereby TIGTA provides a Midpoint Briefing in lieu of the ATF. TIGTA will provide the IRS with a briefing document 3-5 days before the Midpoint Briefing and the IRS has 10 days after the Midpoint Briefing to provide technical comments.

3. In some cases, TIGTA does not follow the established process and prepares the Discussion Draft Report instead of issuing an Agreement to the Facts document. TIGTA will share the Discussion Draft Report with EAM through the EAM mailbox at \*Audit.Coordination@IRS.gov. EAM will retransmit the Discussion Draft Report to the appropriate business unit audit liaisons for review and will request comments be sent directly to TIGTA (with a copy to EAM) by the designated due date.

4. The business unit audit liaison for the lead stakeholder may distribute an IRS Comments Matrix to facilitate IRS internal review and feedback on the Discussion Draft Report. The matrix is typically emailed to TIGTA so they can review and respond to IRS comments. Preparation of an IRS Comments Matrix is a helpful tool in guiding the discussion. The matrix is a good starting point for formulating the management response to the Draft Report and identifying appropriate corrective actions.

5. The business unit audit liaison for the lead stakeholder is responsible for scheduling, coordinating, and leading the DDR meeting to discuss IRS feedback, comments, and concerns with TIGTA. An internal, IRS-only DDR pre-meeting may also be scheduled and conducted to discuss the IRS viewpoint prior to meeting with TIGTA.

6. Some business units hold the closing conference after receipt of the Discussion Draft Report, not the Agreement to the Facts.


**1.29.1.2.16** **(10-21-2024)**

#### Draft Report

1. At the conclusion of the audit process, the auditor issues a formal draft report containing the auditor’s conclusions and any applicable recommendations. The draft report requests a formal agency response from the IRS addressing the report’s conclusions, stating agreement or disagreement with the recommendations, and describing corrective actions the IRS plans to take in response to recommendations with which the IRS agrees.



1. A formal written response from the IRS is not required if the report does not contain any recommendations. In this instance, business unit audit liaisons should engage with all stakeholders’ leadership to determine whether a response will be developed and delivered. If the business unit decides not to provide a written response on a draft report not containing any recommendations, the business unit should notify EAM via email.

2. IRS leadership may choose to provide a formal response even if the report does not contain any recommendations.

3. EAM will initiate an e-Trak control for the management response to the Draft Report upon receipt of the Draft Report and transmit this information and associated timeframes for the timely response to the lead business unit.


2. TIGTA may include Email Alerts in the Draft Report. These are notifications provided to IRS management during the course of the audit that generally require immediate remediation. TIGTA **must**include an Email Alert as a finding and recommendation in the Draft and Final reports if they are claiming reportable outcome measures for that finding.

3. If the report includes returns, return information, Privacy Act protected information, or PII, the lead business unit is responsible for making a request for appropriate redactions. If they have questions or would like Disclosure to review their recommendations, they (or EAM) should request a review by Disclosure, Policy & Program Operations (D-PPO) or Privacy Policy & Knowledge Management (PPKM), respectively. Counsel is also another avenue for technical support for pending redaction requests. Guidance on redactions is available on the ACE SharePoint site. See Audit Redaction Guide. EAM is responsible for updating the database for the redaction request.

4. If a business unit requests redactions, they must review the final report referenced in the Notification of Release received three days before publication (TIGTA) to ensure the redactions were completed. If they were not completed, the business unit should contact EAM and their Lead Auditor from TIGTA immediately. GAO normally does not accept redaction requests; instead, they will reword the report.

5. Auditors generally allocate 30 calendar days for the IRS to prepare and send a formal response. Under certain circumstances the response period may be considerably shorter. This is often the case near the end of the fiscal year, or when auditors are facing publishing or statutory deadlines, or when other stakeholders (such as Congress) have requested the auditor develop a report by a certain deadline.



1. EAM, business unit audit liaisons and lead stakeholders should be aware of factors that could result in the auditor requesting a short-turnaround response, including a statutory requirement that the audit be completed by a certain date (especially in the case of annual audits) or significant delays that occur during the course of the audit that may put the auditor behind schedule.

2. EAM will record and monitor the due date of the IRS formal response in the Enterprise Audit Database.


**1.29.1.2.17** **(02-03-2021)**

#### Preparing a Management Response

1. The IRS’s response to an audit report generally consists of two parts – the management response (also referred to as cover letter) and the planned corrective actions. The management response is an opportunity for the IRS to address the auditor’s conclusions, provide an enterprise perspective and respond to the audit report. The auditor will publish the IRS’s management response in the final report.


**1.29.1.2.18** **(02-03-2021)**

#### The Response Letter

1. Responses should be developed, cleared for approval, and delivered to TIGTA or GAO within the established timeframe to minimize the need for extensions. Excessive extension requests erode our relationship with auditors, inhibit the auditors’ ability to complete reports by statutory deadlines or the deadlines set by their stakeholders, and create the risk that an auditor will publish a report without IRS input.

2. If an extension is necessary, the lead stakeholder should:



1. Work with EAM to request the extension as early in the audit response process as possible. If the business unit secures the extension independently, the business unit must inform EAM of the granted extension immediately.

2. Justify the extension, with the reason for the delay described for the auditor.

3. Stipulate a new delivery date for the audit response.


**1.29.1.2.19** **(02-03-2021)**

#### Strategies for Preparing a Timely Response

1. Strategies for preparing a timely response include:



1. Involve the appropriate stakeholders throughout the audit process.

2. Prepare draft response letters/memoranda and planned corrective actions as soon as possible — including before receipt of the draft report —using information from mid-point meetings, discussion draft reports, closing conferences and other audit milestones.

3. Brief the appropriate executives throughout the audit lifecycle to expedite the formal review of the IRS’s response to the draft report.

4. Ensure the executive's perspective and position is known. Ensure the response comprehensively addresses the issues and recommendations in the draft report and that it is correctly addressed, professionally written, properly formatted, and uses an appropriate tone and style to facilitate executive review.

5. Complete the signature package by including an Attachment (TIGTA memorandum) or Enclosure (GAO letter) describing the IRS’s comments in response to the audit recommendations, an Action Routing Sheet (Form 14074), Note to Reviewer For a Signature Package (Form 13839-A) and appropriate source documents.

6. Leverage templates and take advantage of additional guidance from the Audit Community Expertise (ACE) SharePoint site.


**1.29.1.2.20** **(02-03-2021)**

#### Response Content and Structure

1. The response to TIGTA will be a memorandum with an attachment to address the planned corrective actions. The response to GAO is a letter with an enclosure.

2. Authors and reviewers should understand that the tone, content, and construction of the IRS’s response must be appropriate for a public document which may be seen by taxpayers, the media, other auditors and oversight organizations, Executive Branch leadership, Congress, and others. In other words, the audience of the response is not limited to TIGTA or GAO.

3. The content of the response should relate directly to the auditor’s process, findings, and conclusions as stated in the draft report. The response should clearly and articulately communicate the IRS’s response and policy, if appropriate, and should make fact-based statements in support of the IRS’s position. The response should provide an enterprise perspective on the program being audited and not represent only the position of one or more business units.

4. The audit response should clearly and specifically state the IRS’s position on each of the recommendations. If the IRS disagrees with a recommendation, then clearly and unambiguously describe the rationale for the disagreement in the response. If a partial agreement is necessary, be sure an independent reviewer would understand what the IRS is agreeing to do and what it disagreed with and why.

5. Authors and reviewers should ensure that the response is properly addressed, i.e., the name and title of the recipient should be correct and accurately spelled.

6. The response should be prepared to ensure the final version can be placed on the appropriate IRS letterhead and should be formatted according to the IRS Style Guide.


**1.29.1.2.21** **(07-15-2022)**

#### Responding to Recommendations

1. The IRS must address the auditor’s recommendations in the formal response. In addition to discussing the IRS’s general agreement/disagreement in the management response letter, each specific recommendation is addressed in an itemized attachment to the management response letter.



1. For a TIGTA report, if the IRS agrees with a recommendation, the audit response should be clear to indicate the IRS agreement or partial agreement, or disagreement, and articulate the actions the IRS plans to take in response to the recommendation. These actions should be specific, focused on the issue(s) identified in the recommendation, and capable of producing a measurable, attainable and realistic outcome.

2. For a GAO report, if the IRS agrees with a recommendation, the audit response should state so and provide an overview of the actions IRS plans to take. More granular actions will be provided in the 180-Day Letter response to Congress.

3. If the IRS disagrees with a TIGTA or GAO recommendation, the audit response should describe why the IRS does not intend to pursue the matter and what other actions the IRS intends to take, if applicable. This may include changes to business processes, alternative internal controls, or other strategies for mitigating the issue. It may also include a determination by the IRS that no action will be taken because the level of risk is acceptable, or because the IRS disagrees with the auditor’s conclusions about the program and the deficiency in internal controls.


2. Providing clear responses to recommendations allows the auditors to provide better feedback and fosters transparency as well as improved communication with our external stakeholders.

3. If there is disagreement between IRS and TIGTA pertaining to an audit recommendation either party may elevate the disagreement to the Deputy Secretary of the Treasury after advising and consulting with the Treasury Deputy Chief Financial Officer. The business unit would contact EAM to initiate internal discussions as part of requesting elevation to Treasury. The Chief Risk Officer will represent the IRS and attempt to negotiate and resolve differences.


**1.29.1.2.22** **(02-03-2021)**

#### Planned Corrective Actions

1. PCAs are the specific actions the IRS will undertake in order to address the root cause identified in the auditor’s recommendation. In other words, the PCA should fix the problem or weakness highlighted by the auditors.

2. PCAs are described in an attachment to the management response letter to TIGTA and to Congress (via the 180-Day Letter response). Generally, the attachment is formatted so each recommendation appears separately, followed by the detailed PCA(s) associated with that recommendation.

3. Each Recommendation may have one or more associated PCA, unless IRS disagrees with the recommendation.

4. Each PCA must describe specific steps the IRS is taking to resolve the issue, the responsible IRS official (at an Executive level); and the target implementation date. Business units may develop more detailed corrective actions to facilitate the implementation of a PCA, particularly one that is complex, multi-faceted or impacts multiple business units.

5. Detailed PCAs are typically not provided in the management response to the GAO Draft Report. The management response should identify if the IRS agrees or disagrees with each recommendation. The 180-Day Letter response to Congress must include a detailed description of the PCA along with a discussion of the recent planning and/or accomplishments and an outline for the next steps for implementation of the recommendation. _Exhibit 1.29.1-2._, 180-Day Letter Response.


**1.29.1.2.23** **(02-03-2021)**

#### Developing A Planned Corrective Action

1. When developing a PCA for an audit response, business units should ensure that:



1. The PCA describes the specific, implementable actions that the IRS intends to take to address the recommendation and resolve the control issue.

2. The actions described in the PCA can realistically be accomplished within a set period of time.

3. There is a demonstrable connection between the actions to be taken and the weakness, gap or control issue described in the recommendation. In other words, a non-subject matter expert reading the recommendation and response should be able to clearly understand how the planned actions will mitigate the finding and address the recommendation, if they are properly executed.

4. The PCA strikes an appropriate balance between risk acceptance and mitigation, cost effectiveness and resource utilization, and timeliness and need.


2. It may not be possible to comprehensively describe all planned corrective actions in the management response due to the limited amount of time afforded to the IRS to prepare and deliver it. This is acceptable; however, as additional actions are identified during the implementation process, they should be documented as part of the PCA in JAMES so that a full record of all remediation activities is created and maintained.

3. Auditors will sometimes stipulate specific actions they believe should be taken by the IRS to resolve the issue. However, the IRS has discretion to design and implement its own set of actions as long as those actions effectively address the root cause of the finding.

4. Each PCA should identify (by title, business unit) a responsible official who will oversee and ensure implementation of the PCA.

5. Each PCA should specify a target date for implementation. Target dates for the implementation of planned corrective actions should be reasonable and achievable. Business units should consider factors that could influence whether the IRS can meet target dates, including coincidence with holiday seasons or high-workload periods of the year, and the planned implementation timing of corrective actions from other audits.



### Note:



To facilitate tracking and monitoring, particularly in business units with a high volume of open PCAs, business units are encouraged to set the 15th of the month as a target date for implementation of a planned corrective action.

6. Once the management response is delivered, PCAs must be uploaded to JAMES for tracking and monitoring. TIGTA inputs the data from their final reports into JAMES. EAM inputs the data from the GAO final reports into JAMES.


**1.29.1.2.24** **(02-03-2021)**

#### Signatory Authority

1. Audit responses should be prepared under the leadership of the executive with direct authority over the program under audit. In most cases this will be the same executive listed as the primary point of contact for the auditor at the end of the response memorandum/letter.

2. For TIGTA audits, the executive with comprehensive oversight of the program under audit generally should sign the audit response memorandum or letter. In most cases, this will be the head of a business unit or their deputy. There may be circumstances, such as if the report addresses findings within a specific program that are cross-functional in nature, where it is appropriate for one of the Deputy Commissioners to sign the response.

3. For GAO audits, the appropriate Deputy Commissioner should sign the audit response letter. The Commissioner should sign if the audit report findings are enterprise or strategic in nature and/or includes recommendations aimed at organizations under both the DCOS and DCSE.


**1.29.1.2.25** **(07-15-2022)**

#### Signature Process

1. For TIGTA response memoranda, the lead business unit will submit the signed response directly to TIGTA and include EAM in the response email. The transmission email should be directed to \*TIGTA Audit IRS Responses and should also copy the audit liaisons for any supporting organizations.



1. All draft management responses to both TIGTA and GAO draft reports as well as the 180-Day Letters must be reviewed by EAM before the business unit audit liaison finalizes the response and routes it for business unit approval.

2. The draft management response package should be provided directly to the EAM Director with a copy to the Audit.Coordination@IRS.gov mailbox at the same time that the package is provided to the business unit’s first level executive for review. EAM will review the package for enterprise perspective and provide feedback within 2 business days.


2. For IRS management responses to GAO draft reports, EAM will coordinate clearance of the signature package through the appropriate signatory executive (Deputy Commissioners or Commissioner), including creating the e-Trak control when the draft report is received. For 180-Day Letters, Legislative Affairs will coordinate clearance of the signature package through the appropriate signatory executive (Deputy Commissioners or Commissioner).

3. For signature packages going to Deputy Commissioner for Operations Support, the package needs five (5) business days for review. For signature packages going to the Deputy Commissioner for Services and Enforcement, the package needs seven (7) business days for review. For signature packages going to both Deputy Commissioners, the signature package requires fourteen (14) business days. For signature packages going to the Commissioner, both Deputy Commissioners must review before it is provided to the Chief of Staff for the Commissioner’s signature, so the signature package requests nineteen (19) business days.

4. A pen-and-ink signature is preferred but an electronic signature is acceptable.



1. If a pen-and-ink signature is used, after the signature is applied, the signed document should be scanned for electronic transmittal to the auditor. When scanning, ensure that the scanner is set to the highest possible scan resolution (usually expressed as the largest DPI – or Dots Per Inch – number in the scanner’s settings). A high-quality scan is important because the electronic file will be used in the publication of the audit report, and the IRS’s response must be crisp and easy for a reader to see.

2. Once the package is signed, the final version needs to be returned to either EAM or Legislative Affairs (depending upon the package) so that the electronic version may be transmitted to TIGTA or GAO or the appropriate Congressional members (for 180-Day Letters).

3. Once the management response is transmitted, EAM will update the database and ensure that the final version has been uploaded to e-Trak and the e-Trak control closed, which includes the management response and other documents such as the Note to Reviewer and Action Routing Sheet. EAM will also send the final version of the management response to all business units (lead and supporting).

4. For responses to GAO draft reports, EAM will provide a copy of the final version to Legislative Affairs, who will open an e-Trak control for the 180-Day Letter. EAM will use the information from the e-Trak control to update the database pertaining to the due date of the 180-Day Letter.


5. If the response contains personally identifiable information (PII) or other data that should remain confidential, follow all appropriate procedures to securely transmit the response to the auditor while minimizing the risk of inadvertent disclosure.


**1.29.1.2.26** **(02-03-2021)**

#### Distribution Restrictions

1. Any draft audit report provided to the IRS by any auditor, at any stage of the process prior to publication of the final, public report, is considered privileged information and must not be distributed beyond those with a “need to know.” Draft audit reports may not be shared with entities outside of the IRS. TIGTA and GAO have a separate, independent mechanism for sharing information with one another. The auditors must engage with each other directly; the IRS may not act as a middleman.

2. If a non-IRS entity, including the Treasury Department or other auditors, asks an IRS stakeholder or business unit audit liaison to share a draft audit report, they must decline to share the document and refer the requestor to EAM.


**1.29.1.2.27** **(02-03-2021)**

#### Publication of Auditor’s Report

1. Auditors will issue the final report to the IRS via the EAM mailbox at Audit.Coordination@IRS.gov. EAM will retransmit the final report to appropriate IRS stakeholders.

2. If a GAO audit contains recommendations, the publication of the final report starts a 180-day period during which the IRS is required to prepare and submit to Congress an update on PCAs. This response is referred to as the “180-Day Letter”. If GAO provides the final report to their Congressional client, at the request of the Congressional client, the report may be held for up to 30 days before the final report is released to the IRS or the public.

3. In accordance with the Inspector General Empowerment Act of 2016, TIGTA will publicly release an audit report within three calendar days of issuing the final report to the IRS. If TIGTA prepares a press release, TIGTA notifies IRS and shares a copy.


**1.29.1.2.28** **(02-03-2021)**

#### Limited Official Use and Sensitive But Unclassified Reports

1. Final audit reports may be classified as Limited Official Use (LOU) or Sensitive But Unclassified (SBU) because the information they contain is sensitive or could compromise IRS operations if widely known. Examples include reports on computer system security, physical security, and compliance activities involving the Law Enforcement Manual. When a report receives an LOU or SBU designation, its distribution will be limited to key IRS offices and personnel, and possibly certain external stakeholders (such as Congressional oversight committees). Auditors may publicly release redacted or otherwise sanitized versions of LOU or SBU reports.

2. Information in LOU or SBU reports must be safeguarded in accordance with IRM 10.2.15, Minimum Protection Standards and IRM 10.5.1.2.2, Sensitive But Unclassified (SBU) Data. EAM and other IRS offices who receive copies of LOU or SBU reports must ensure that only individuals with a business need to know are privy to the contents of the report.

3. LOU and SBU reports are not uploaded to the Enterprise Audit Database; they will be stored separately on a restricted-access section of the EAM Shared Drive.



1. If TIGTA disagreed with any portion of the IRS response – particularly the IRS’s response to TIGTA’s recommendations – the audit report will include additional narrative under the heading of “Office of Audit Comments.”

2. TIGTA may also issue a memorandum to the Commissioner requesting a written reply to the Treasury Deputy Secretary if TIGTA considers the disagreement to be significant. If this happens, EAM will provide situation-specific guidance.


4. Once the final report is received, EAM will update the Enterprise Audit Database.

5. An audit report with recommendations and associated PCAs requires additional processes and actions on the part of EAM, IRS stakeholders and business unit audit liaisons including validating JAMES input of data from the final report and monitoring the completion of corrective actions.


**1.29.1.3** **(02-03-2021)**

### Monitoring Planned Corrective Actions

1. Business units are responsible for monitoring the status of their PCAs in order to ensure they are being executed timely and effectively. This includes:



1. Maintaining awareness of the inventory of open PCAs and their due dates.

2. Inputting regular status updates and progress actions in JAMES for each open PCA.

3. Expanding or further developing PCAs, if additional action items must be documented to show how the internal control issue is being evaluated and addressed.


2. Business units are also responsible for timely engaging with the appropriate stakeholders if PCA implementation is resource-dependent or requires the support of other business units. Proactive engagement is necessary to ensure that support can be secured and the PCA implemented on time.

3. Business units may be required to report on the implementation status of certain PCAs to IRS leadership, the Department of the Treasury, the Office of Management and Budget, and/or TIGTA/GAO.

4. EAM will also regularly monitor the status and due dates of open PCAs and will address any issues or concerns with the appropriate business unit owner. EAM will also report on the Service-wide status of PCA implementation at various times and in various forums and may request business unit participation if a specific and/or high-profile PCA is to be discussed.


**1.29.1.3.1** **(10-21-2024)**

#### Closing Planned Corrective Actions

1. PCAs are completed timely when the following occurs:



1. The PCA was implemented on or before the assigned due date in JAMES.

2. The complete description of the action taken addresses each specific issue set out in the PCA.

3. The action(s) taken agrees with the stated PCA and is fully implemented.

4. Form 13872 with the official signature of the executive, and the manager responsible for the PCA, or their designee and supporting documentation is uploaded into JAMES for each implemented PCA. The program manager and executive signatures for approval should be after the effective date. There should not be a significant time gap between the effective date and the executive approval date. A significant time gap is more than 60 days.

5. Sufficient supporting documentation substantiating completion of the closed PCA is approved by the responsible official and uploaded into JAMES. If an “acting designation” is listed as a signor, provide proof of the acting assignment using the appropriate designation document (e.g., Designation Authority F10427; email; or screen print from the IRS Executive Directory).

6. The Form 13872 Closure Checklist is a tool available to help business units identify the appropriate information to include on the F13872 when requesting closure. _See Exhibit 1.29.1-10_.


2. Business units may submit PCAs for closure once the business unit has completed the actions required to address the recommendation and mitigate the control issue. The PCA closure documentation should be sent to EAM for closure no later than two months from the executive approval date as evidenced by the official signature of the executive. Submission delays should be explained in detail in Box 7 on the form.



### Exception:



For GAO reports – since the report is not entered in JAMES until after 180-Day Letter is issued, the business units will have 30 days from entered date plus the roll to the 15th of the next month to submit the PCA closure documentation.

3. In order to close a PCA, the business unit must upload to JAMES the following:



1. A completed Form 13872.

2. Documentation supporting the business unit’s efforts to develop and implement a corrective action plan.


4. EAM requests a lead time of five business days to evaluate documentation provided by the business unit to support a request to close a PCA. Submitting a PCA for closure to EAM with less than five business days remaining before the due date may result in a missed deadline if EAM is unable to complete an evaluation in time, or if the documentation is deemed insufficient for closure. EAM performs a 100 percent pre-closure review of the documentation submitted to close a PCA.

5. All material associated with the request to close a PCA must be uploaded to JAMES. The only exception is material that contains PII or other sensitive data that should not be uploaded to a non-IRS information technology system. Material that cannot be stored in JAMES must be stored on EAM's secure Shared Drive and maintained with the same retention standards as material in JAMES.

6. All PCAs and related materials, including Form 13782 and all supporting documentation, are potentially subject to post-closure evaluation. This includes:



1. Audit activity conducted by GAO or TIGTA.

2. Internal Control Reviews conducted by the CFO, Internal Controls, Internal Reviews organization.

3. Quality Assurance Review of Closed PCAs conducted by EAM.


**1.29.1.3.2** **(07-15-2022)**

#### Extending Planned Corrective Actions

1. An extension to a PCA due date may be requested when management has determined that the PCA cannot be completed by the scheduled due date. To request an extension, a JAC should:



1. Utilize Form 13872 to select the reason for the delay from the drop-down list (Question 4c Reason for delay) and describe the reasons for the delay under Question 7 Specific action taken.) This form requires the official signature of the executive and the manager response for the PCA. See _Exhibit 1.29.1-3_, Categories for Delays/Extensions in JAMES which provides brief definitions of the various reasons for delay.

2. Enters the specific action taken narrative information from the documentation into JAMES, as entered on Form 13872 into JAMES.

3. Upload the documentation into JAMES and select the reason for the extension using the reasons listed in _Exhibit 1.29.1-3_, Categories for Delays/Extensions in JAMES.

4. The JAC must have the PCA extension request with required official signatures in JAMES on or before the PCA due date otherwise the PCA will be recorded as a “Missed”.

5. Once the Responsible Official(s) in EAM approve/disapprove the extended due date, the action is updated in JAMES as well.


### Note:

An extension of a PCA due date does not negate a "Missed" due date for tracking purposes on the Servicewide PCA Landscape Closed Audit Indicators.

**1.29.1.3.3** **(02-03-2021)**

#### Requirements for Form 13872 and Supporting Documentation

1. GAO and TIGTA expect the IRS to develop and maintain strong evidentiary documentation demonstrating that appropriate corrective actions were taken. The IRS’s supporting documentation is subject to internal review by Program Managers and follow-up audits by TIGTA or GAO. The IRS must maintain thorough documentation in support of its efforts to address control issues (which are revealed through audit findings and addressed by auditor recommendations).

2. The Form 13872 will be considered complete if:



1. All applicable fields are completed.

2. Complete descriptions of the specific actions taken to close PCAs are provided on the form.

3. Details on the steps taken to develop and execute the corrective actions are recorded.

4. Appropriate business unit responsible officials have signed the form. This includes both the manager responsible for implementing the PCA and the executive responsible for the PCA. (If this happens to be the same person, the next highest level of executive should sign as the “executive responsible” in order to ensure that a separation of duties exists and a distinct review and approval of the PCA has taken place.).


3. EAM will consider the following when evaluating whether the supporting documentation is sufficient to justify closure of the PCA, and/or when conducting a closed PCA quality review:



1. Supporting evidentiary documentation accompanying a request to close a PCA should describe the work that the business unit performed to plan and execute corrective actions. For example, it is insufficient to state that a system upgrade was completed; the documentation should show how and when it was completed, and what actions were performed (e.g., migrate to new servers, purchase additional software, etc.) to complete the PCA.

2. PCA outputs should be available as supporting documentation, e.g., if a PCA specifies that a training plan will be completed, the final training plan should be provided as documentation.

3. Business units should also provide materials that support the process used to complete a PCA. Continuing the training plan example, if a business unit used a survey or other tool to evaluate training needs, a copy of that survey or tool may be included as supporting documentation.

4. The results of objective, data-driven analyses used in the creation and execution of a PCA may be included as supporting documentation.

5. Proof that required actions were taken should be included. For example, if a population of employees was supposed to complete a training course, evidence that they all completed the course by a certain date should be included. Similarly, if organizations had to review and certify that security requirements are in place, documentation of that self-certification should be provided.

6. Documentation of purchases, resource reallocations, or other required financial activities should be provided. Examples may include completed purchase orders, funding realignment reports from the Integrated Financial System, or proof of receipt and acceptance.

7. If new controls have been implemented as a result of the corrective action, and if the controls have been tested to demonstrate they are effective, documentation such as test plans and/or results of that testing may be provided as supporting material as well.

8. EAM will consider other potential criteria and sources of documentation not listed here if appropriate to the situation. See _Exhibit 1.29.1-4_, Evidentiary Documentation Examples for other examples of appropriate documentation.


4. If EAM deems the supporting documentation to be insufficient when the PCA is submitted for closure, the PCA will not be closed, and the business unit will be asked to provide additional and/or stronger supporting documentation before resubmitting the PCA for closure.

5. If EAM deems the supporting documentation to be insufficient during a closed PCA quality review, EAM will contact the business unit responsible for the PCA and require it to identify and provide additional and/or stronger supporting documentation.

6. PCA documentation must be stored on JAMES unless it contains PII, in which case it may be stored on the EAM secure internal Shared Drive. In these cases, however, the retention period will still apply to the Shared Drive, and the Shared Drive data must remain accessible to both auditors and appropriately authorized IRS personnel until the retention period expires.


**1.29.1.3.4** **(02-03-2021)**

#### Retention Period for Documentation

1. PCA documentation must be properly maintained by the responsible business unit as well as other entities with reason to possess or access this information. This includes both EAM and the Department of the Treasury.

2. PCA documentation must be retained for a period of time consistent with internal IRS guidance and with Treasury’s JAMES data retention requirements. In the event the length of the required retention periods varies, the longest of the retention periods should be used.


**1.29.1.3.5** **(02-03-2021)**

#### Background – Monthly Closed Sample Review

1. Recognizing the importance of evidence that planned corrective actions were taken in response to TIGTA and GAO findings and recommendations, EAM, in consultation with RAAS, established a process requiring a monthly quality review of closed planned corrective actions. Adequate documentation also provides assurance to our auditors and other external stakeholders that the IRS effectively addressed audit recommendations by designing and implementing appropriate solutions.

2. PCAs are approved for closure in the JAMES by staff from EAM. The quality review process involves a careful review of the documentation provided by the business unit, including the Form 13872 and any evidentiary documentation provided to support the PCA closure. The reviewer pays careful attention to the quality and completeness of the documentation provided and whether or not the PCA, as outlined in the management response or 180-Day Letter, was fully implemented.

3. The quality review is performed by a different EAM staff member than the one who originally approved closure, thus ensuring separation of duties.


**1.29.1.3.5.1** **(02-03-2021)**

##### Research, Applied Analytics and Statistics (RAAS) - Statistics of Income (SOI) Team Partnership

1. As EAM’s partner in identifying the random sample data sets for the monthly closed sample review, Research, Applied Analytics and Statistics (RAAS) - Statistics of Income (SOI) Team is responsible for providing assistance in determining the sample selection by:



1. Developing the sample selection methodology.

2. After the close of each fiscal year, analyzing a listing of the number of PCAs to be closed within each fiscal year, as received from EAM, to determine the projected volume of PCAs to review for each fiscal year.

3. Analyzing a listing of PCA’s closed during the previous month, as received from EAM, to determine the appropriate sample number to review.

4. Working with EAM to interpret the sample results and update procedures outlined in the sampling methodology if needed.

5. Providing statistical subject matter expertise.


**1.29.1.3.5.2** **(07-15-2022)**

##### Monthly Closed Sample Quality Review Controls

1. The following activities should take place monthly:



1. The responsible EAM analyst compiles and sends a listing of the previous month’s closed PCAs to SOI. This listing is generally sent within the first few workdays after the current month ends.

2. SOI determines the appropriate sample for the month and returns the list of PCAs selected to EAM for review.

3. The responsible EAM reviewer conducts an in-depth review of the samples selected to determine if the actions taken and the supporting documentation provided to close the PCA are sufficient. If the EAM reviewer determines that the actions taken and or the documentation provided for closure is not sufficient, the EAM reviewer will request the business unit to take additional action(s) which may include providing additional supporting materials, clarifying the reported actions taken, or requesting additional action(s) be taken. The EAM reviewer will record review findings and qualitative improvement comments, as appropriate, on Form 14668, IRS Quality Assurance Review of Closed Planned Corrective Action (PCA) Notification.

4. The EAM reviewer will meet with the JAMES staff who initially validated the closure to discuss the results and obtain additional information that may possibly affect the comments or requested actions sent to the BU.

5. The EAM reviewer then sends the completed Form 14668 to the Director, EAM for review and final approval before sending to the specific business organization assigned to the PCA.

6. The Director, EAM approves completed Forms 14668 by the end of the current month.

7. For "pass with rework" or "fail" reviews, the Form 14668 is provided to the BU and given 30 days to respond. The business units fix the documentation and advises EAM. If the closure pertains to a Financial Statement audit PCA, coordination with CFO FM is required by the BU before uploading revised documents into JAMES.


**1.29.1.3.5.3** **(02-03-2021)**

##### Addressing Insufficient Closures

1. EAM may determine that the documentation provided by the BU to support closing the PCA is insufficient. Insufficient supporting documentation may include, but is not limited to:



1. An incomplete Form 13872.

2. Missing or in appropriate manager or executive signatures.

3. Documentation contains sensitive data and is not properly presented.

4. Documentation to support a specific action or actions was not submitted.


### Note:

See _Exhibit 1.29.1-4_, Evidentiary Documentation Examples for examples of sufficient documentation.

2. EAM may determine that the PCA has not been fully implemented. Incomplete actions may be, but is not limited to:



1. Actions IRS agreed to take are not completed; no explanation is provided as to why.

2. Policy or procedures have not been established, updated, or made available (i.e. IRM sections are unpublished).

3. Programming has not been implemented.


3. If additional documentation or actions are requested from the business unit, it will be detailed on the Form 14668 in the appropriate section indicating the specific deficiency found, and proposing recommended actions that the business unit should take to correct the finding.

4. Review results are categorized as:



1. Pass - All actions appear to have been completed and all documentation to support action(s) taken was submitted. Documentation was either uploaded in the JAMES and or filed securely with EAM as PII.

2. Pass With Re-work - Request to provide additional documentation, clarify information provided, address documentation containing information prohibited in the JAMES, etc.

3. Fail - PCA was determined to not be implemented or only partially implemented.


### Note:

Any request to remove documentation from the JAMES is coordinated with Treasury through the EAM reviewer.

5. After the Director, EAM approves the Form 14668 it is sent, via email, to the point of contact within the BU to coordinate the return of the follow-up response actions, the submission of additional documentation.

6. If the business unit does not address the requested follow-up actions within the initial timeframe, which is generally 30 days, an extension can be granted. The initial response due date is indicated on the Form 14668 in the appropriate section by the EAM reviewer. Responses not received from the BU within 60 days should be brought to the attention of the Director, EAM for resolution and to determine the follow-up actions.

7. EAM files the completed Form 14668, and any email correspondence communicating follow-up actions in a Closed PCA Review subfolder under the appropriate audit report by PCA number (e.g., 20XX- XX-XXX\_X-X-X).

8. EAM keeps a summary of results for each BU with the month of review identified. This is generally a spreadsheet filed within EAM.


**1.29.1.3.5.4** **(07-15-2022)**

##### Monthly Sample Reviews Associated with Financial Statement Audit

1. If a corrective action selected for the random sample is one that originated from the GAO annual Financial Statement Audit, there are several process steps that are different than if the corrective action arose from any other GAO or TIGTA performance or program audit.

2. Any rework associated with the Financial Statement Audit corrective action should be worked through and in conjunction with the CFO Financial Management (FM) audit team prior to loading additional documents or replying to EAM.

3. EAM will send the Form 14668 to the CFO-FM team with a copy to the business unit based upon the closed PCA evaluation. EAM will add language to the transmittal email of the Form 14668 to remind the business unit in this situation to partner with CFO-FM.


**1.29.1.3.6** **(02-03-2021)**

#### Joint Audit Management Enterprise System

1. The Joint Audit Management Enterprise System (JAMES) is the system of record used to monitor audit related recommendations and corrective actions taken by each bureau within the Department of the Treasury. Findings and recommendations extracted from the GAO and TIGTA audit reports are tracked in JAMES. The current status of PCAs for related recommendations, material weaknesses, significant deficiencies, and remediation plans are also tracked. In order to comply with the intent of FMFIA, OMB Circulars, and Treasury Directives, tracking these audits and PCAs is mandatory.

2. The information contained in JAMES is used by Treasury to assess the effectiveness and progress of bureaus in correcting their internal control deficiencies and implementing audit recommendations. PCAs are entered into JAMES and must be updated on or before their scheduled due date to reflect their current status.

3. JAMES allows bureau users to run reports to assess the effectiveness of programs, query by topic, and create reports.

4. JAMES tracks status updates to support timely completion of PCAs for:



1. Audit Reports (GAO and TIGTA).

2. Inspection & Evaluation reports (TIGTA).

3. Material Weaknesses.

4. Significant Deficiencies and existing Reportable Conditions.

5. FMFIA Remediation Plan Actions.


5. Treasury upgrades the disaster recovery servers annually. This requires EAM to test and verify access to JAMES before and after Treasury has completed the server upgrade to ensure that all JAMES users can access the new URL without interruptions. This also requires that all user identifications and passwords are active while in the disaster recovery environment. EAM works with the Treasury Financial Analysis and Reporting System (FARS) help desk to resolve any discrepancies. This exercise usually lasts about two weeks.


**1.29.1.3.6.1** **(02-03-2021)**

##### JAMES User Account Access and Recertification

1. Treasury’s automated (FARS) e-Form, is required to obtain JAMES access. The FARS e-Form is integrated within the FARS application and is only accessible to the FARS designated responsible officials and the FARS help desk team. This form allows designated responsible officials to electronically submit and track all new and modified requests for JAMES access and allows Treasury to improve the cycle time for completing requests.

2. To request access to JAMES, the JACs are responsible for providing the following user information via e-mail to the designated IRS Responsible Official in EAM:



1. Name.

2. Email Address.

3. Telephone Number.

4. Level of Access/User Role: mainly JAMES PO User (update PCA) or JAMES User Read-only (read and run reports).

5. Account Type: New Account or Modify Account.

6. Office Organizational Symbols.


3. The IRS Responsible Official (EAM) will complete the FARS e-Form and submit to Treasury. The Treasury FARS help desk will establish the user account and notify the user by e-mail, providing a user ID and temporary password. When new users log into JAMES for the first time, they will be prompted to read and acknowledge the FARS Rules of Behavior document before gaining access to the application.

4. To remove or modify JAMES accounts, the designated JAC must send an e-mail to the designated IRS Responsible Official in EAM, providing the name of the user to be removed and/or the requested account modification.

5. JAMES training material and on-line help information is located on the Treasury JAMES Home Page.



### Note:



You must have a JAMES account to access this page

6. Treasury requires JAMES users to recertify their access annually, which is initiated by the IRS Responsible Official in EAM. During this time, users may also inform the IRS Responsible Official in EAM that they no longer need their account or if any modifications are needed to their profile. EAM will notify Treasury of the results of the recertification by the response due date.


**1.29.1.3.6.2** **(02-03-2021)**

##### JAMES User Roles

1. JAMES employs specific profile settings to control access and information update privileges to its database. The three main profiles and privileges are presented below.

2. JAMES Editor (JAMES EDITOR): This is the role most commonly assigned to EAM staff. IRS staff assigned the JAMES Editor role can read all data for the bureau and perform the following actions:



1. Enter GAO/TIGTA audit reports findings, recommendations, and PCAs into JAMES.

2. Validate status updates entered by program users.

3. Reject status updates if they do not meet all reporting and documentation requirements and notify the JAMES Program Office user that the status was rejected and the reason for the rejection.


3. JAMES Program Office (JAMES PO): This is the role most commonly assigned to business unit JAMES Audit Coordinators (JACs). IRS staff assigned the JAMES PO role can review new reports entered into the system, update PCAs and upload supporting documentation. Validation of updates to a PCA is performed by a separate user with the JAMES Editor role.



1. Entry of status updates by the JAMES PO is mandatory. JAMES is programmed to send an automated e-mail notification to inform the JAMES Editor that a status update is available for review in JAMES.



      ### Note:



      JAMES Editors will only enter a status update under extraordinary circumstances and will require approval from their supervisor.

2. IRS staff assigned the JAMES PO can view LOU and SBU audit reports as long as the PCA is assigned to their organization.


4. JAMES User (JAMES USER): This role provides read-only access to the JAMES database for non-LOU and non-SBU reports and support documentation for all business units. IRS staff assigned this role have the capability to view LOU and SBU audit reports or use the supporting documentation feature for their assigned business units only.


**1.29.1.3.6.3** **(07-15-2022)**

##### JAMES Numbering - Audit Reports

1. Each TIGTA and GAO audit report is assigned a unique report number. This is the number assigned to the final report and is the number entered in JAMES for tracking and reporting purposes.



1. TIGTA Audit Report Number – Each report number begins with the complete fiscal year and is followed by subject (two middle digits) and audit identifying numbers (last three digits) assigned by TIGTA.



      ### Example:



      2019-40-006

2. GAO Audit Report Number - Through FY 2021, each report is assigned an identification number. The two middle digits represent the fiscal year which is followed by the report number assigned by GAO.



      ### Example:



      GAO-19-88

3. Beginning in FY 2022, the final report number changed to GAO-FY-Audit # (6 digits).



      ### Example:



      GAO-22-104938


**1.29.1.3.6.4** **(02-03-2021)**

##### JAMES Numbering - Findings, Recommendations, and PCAs

1. For each audit report, material weakness, significant deficiency or reportable condition, JAMES tracks the findings, the recommendations for each finding, and the PCA(s). The numbering in JAMES is displayed as follows (which may not match the numbering in the audit report.)



1. **Finding –**The first number in a three-digit series describes the deficiency, weakness or gap reported by the auditor in the audit report. **_Example:_****2**-2-1. This is interpreted as: **Finding 2**, Recommendation 2, Corrective Action 1.

2. **Recommendation –**The second number in the three-digit series following the Finding number refers to the recommendation. A finding may have more than one Recommendation. **_Example:_**1-**3**-1\. This is interpreted as: Finding 1, **Recommendation****3**, Planned Corrective Action 1.

3. **Planned Corrective Action (PCA) –**The third number in the three-digit series. The PCA description contains the details of the management corrective action or how management will implement a recommendation to address the issue and to correct the weakness. The description also shows measures taken to address audit findings and recommendations, including due dates and responsible officials **_Example:_**1-1-**2**. These are interpreted as: Finding 1**,**Recommendation 1,**Planned Corrective Action 2.**


### Note:

A Recommendation may have more than one PCA as noted in the example above.

**1.29.1.3.6.5** **(07-15-2022)**

##### Important JAMES Data and Fields

01. **Actual Better Used Funds**\- Funds actually resulting in revenue enhancements rounded to the nearest dollar.



    ### Note:



    Refer to Funds Put to Better Use - see below for clarification.

02. **Actual Revenue Funds**\- Funds to the nearest dollar actually resulting from revenue enhancements due to implementation of an audit recommendation. (Refer to Funds Put to Better Use - see below for clarification).

03. **Description**\- A detailed description of Finding, Recommendation, PCA Material Weakness or Significant deficiency.

04. **Disallowed Cost**– Refers to a questioned cost identified by the auditors that management has agreed should not be charged to the government. This cost needs to be reimbursed by repayment, reduction of costs, or offset.

05. **Entry Date**–The date the report was entered into JAMES.

06. **Finding**– A written explanation in the audit report which describes the deficiency or issue in the audit report or opportunity for improvement in the remediation plan.

07. **Funds Put to Better Use**– This field is completed when closing a PCA and should contain the actual savings or revenue amount expected to be realized by the business unit once the PCA is implemented. This only appears in audit recommendations indicating that funds could be used more efficiently if management took steps to implement and complete the recommendations. Examples include:



    1. Reducing outlays.

    2. De-obligating funds from programs or operations.

    3. Implementing recommendations for improvements to operations resulting in cost savings.

    4. Avoiding unnecessary expenditures noted in pre-award reviews of contract agreements.

    5. Preventing erroneous payment.

    6. Identifying savings.


08. **GAO Status Checkbox**\- Records the status of a recommendation from GAO’s perspective in JAMES. If the checkbox is empty, GAO does not consider the recommendation/PCA the IRS previously closed as adequate for closure of the recommendation in their records.

09. **Hold**\- The action recorded in JAMES when management agrees with a mission critical audit recommendation but currently does not have funding available to take corrective action. A PCA may be in hold status for three years with a one-year automatic extension.

10. **Hold Status Internal Date**\- Records the date a status update is required for a recommendation on Hold.

11. **Hold Until Date**\- Records the three-year period for Hold recommendation.

12. **Milestone Date**\- Records the date a status update is required for a long-term PCA.

13. **Monetary Benefits**\- PCAs containing monetary benefits must include the dollar amount and an explanation of what management did to realize the savings. If only a portion of the monetary benefits was realized, indicate the amount that was not realized in the status update along with a thorough explanation as to how the monetary benefits calculation was obtained. Stating the monetary benefit amount without a justification is not acceptable. See _Exhibit 1.29.1-5_, Audit Outcome Measures.

14. **Planned Corrective Action (PCA**) \- An action IRS management agreed to take to address the audit finding and recommendation.



    ### Note:



    This field contains a concise description of each management corrective action taken to address audit findings and recommendations, including due dates and responsible officials.

15. **Potential and/or Realized Monetary Benefits**\- Reflects the potential monetary benefits identified by TIGTA and the amount that could be realized when the recommendation is implemented.

16. **Potential Better Used Funds**\- Assertion by TIGTA that funds could be more efficiently used if management took actions to implement and complete the recommendation. This will be specified as a dollar amount. Some specific types of actions are:



    1. Reduction in outlays.

    2. De-obligation of funds from programs or operations.

    3. Withdrawal of interest subsidy costs on loans, or loan guarantees, insurance, or bonds.

    4. Not incurring costs by implementing recommended improvements related to the operations of the IRS, a contractor or grantee.

    5. Any other savings that are specifically identified.


17. **Questioned Costs**\- Costs identified in the audit report that are in question due to:



    1. An alleged violation of a provision of a law, regulation, contract, or other requirement governing the expenditure of funds.

    2. An audit finding where the cost is not supported by adequate documentation (an unsupported cost). Unsupported costs are recorded and rounded to the nearest dollar.

    3. An audit finding that expenditure of funds for the intended purpose is unnecessary or unreasonable.



       ### Note:



       The phrase “disallowed cost” is sometimes used in audit reports to refer to a questioned cost that management has sustained or agreed should not be charged to the government.


18. **Recommendation**\- The suggested course of action for remediating a finding Recommendations are usually generalized and describe what the IRS should do but not necessarily how the IRS should do it.



    ### Note:



    A Finding may have more than one Recommendation.

19. **Report Title**\- The title of the audit report, material weakness, significant deficiency, or remediation plan.

20. **Responsible Employee**\- The name and organizational symbols of the person responsible for managing and updating the PCA.

21. **Responsible Organization**\- The organization(s) responsible for receiving and analyzing audit reports, providing timely responses to the auditor, and taking corrective action, when appropriate. The IRS organizational symbols for the responsible organization are listed at the level of the responsible program executive.

22. **Root Cause**\- The primary reason for an audit finding resulting in a recommendation. This field is populated by selecting from a pre-defined set of causes. See _Exhibit 1.29.1-6_, Root Cause for Findings - Definitions & Examples.

23. **Status Date**\- The date that the PCA was last updated. The status date is the closure date for actions shown as implemented or cancelled in JAMES. The status date does not necessarily reflect the actual date the action was completed. The actual completion date should be entered on Form 13872 in Box 4b, Effective Date, and in the text of the PCA narrative in JAMES.

24. **Status/Comment Log**\- Contains a complete description of the action taken and its actual completion date, a reason for delaying completion of an action (when appropriate), and a current status update. The written narrative in the Status/Comment Log should be the same wording used on Form 13872 in Box 7, Specific Action Taken.


**1.29.1.3.6.6** **(02-03-2021)**

##### JAMES Due Date Guidance and Requirements

1. **Original Due Date**\- Defined as the initial due date that management expects to implement the action, which is taken from the corrective action plan and is the due date agreed upon by IRS management in the “Management Response to Draft Report” or the 180-Day Letter. If management does not provide a specific proposed implementation date for a PCA, EAM will assign an original due date. Due dates should be realistic and allow sufficient time for implementation, review, verification of status, and timely submission into JAMES for validation.



### Note:



Material weaknesses, significant deficiencies, reportable conditions, and remediation plans are the responsibility of CFO-FM, who should be consulted on these type actions.

2. **JAMES Due Date**– A corrective action must have an original due date when loaded into the JAMES tracking system. JAMES will not accept:



1. Corrective action(s) without an original due date.

2. Proposed implementation dates with "To Be Determined" (TBD).


3. **Status Updates**\- For reporting to be reviewed timely by EAM, all status updates to implement and extend PCAs should be completed and reported in JAMES five (5) business days before the PCA due date. Form 13872, along with any supporting documentation, must be uploaded into JAMES during the same period.



### Note:



CFO-FM may require different review timeframes and guidelines for PCAs arising from the GAO financial statement audit.

4. **Assignment of a Due Date by EAM Responsible Official(s)**– When warranted, EAM Responsible Official(s) will assign an original due date to the PCA that is different from the date provided by management when the due date:



1. Is prior to the issue date of the audit report.

2. Is prior to the month the report is entered into JAMES.

3. Falls in the same month the report was entered into JAMES.

4. Falls in the month after the report was entered into JAMES.

5. Is not provided in the management response.


### Note:

When situations “a” thru “d” occur, EAM will add up to an additional two months to the original due date shown in the final audit report and that due date is then entered into JAMES. For situation “e” EAM will use a future default date. This is done for reporting purposes to ensure that the PCAs can be addressed timely. However, each business unit is responsible for implementing the PCA by the date stated in the Management’s Response to the Draft Report.

5. **Completed Planned Corrective Action (Implementation Date)**– For a PCA completed prior to an audit report issue date, PCAs reported as Implemented/Closed (Completed) in the management response or 180-Day Letter will not be recorded as Closed in JAMES at the time the final audit report is initially recorded. Rather, they are assigned a Due Date established in accordance with the reporting guidance for due date formulation outlined below.



1. All documentation supporting the closure must be uploaded to JAMES within the designated time frame by the due date by the business unit responsible for the PCA. If appropriate supporting documentation is not timely provided, the PCA’s status will remain as “Open” and the business unit must submit a request for due date extension on Form 13872 following current PCA reporting guidance.

2. JAMES Assigned Due Date Formulation.


   - TIGTA Reports - Assigned Due Date will be 15th day of the month immediately following the elapse of 60 days from the final report issue date.**Example: TIGTA:**A final audit report issued on May 25 will have a 60-day elapsed date of July 25 and the PCA will be assigned a Due Date of August 15.

   - GAO Reports - Assigned Due Date will be the 15th day of the month immediately following the elapse of 30 days from the 180-Day Letter issue date.**Example: GAO:**A final audit report issued on May 12 will have a 180-day time period in which to submit a formal management response to Congressional oversight committees. The 180-Day Letter should be dated November 12 and will have a 30-day elapsed date of December 12. The PCA will be assigned a Due Date of January 15.


6. **Rejection of PCA Status Updates** \- Responsible Officials in EAM will reject the status update of a PCA if executive certification (Form 13872. does not contain the appropriate effective date, signatures are missing or invalid, or the status does not adequately address the PCA. Insufficient supporting documentation will also cause a PCA to be rejected. EAM will immediately contact the program user of any errors found and request corrections be made promptly for the PCA to be considered as recorded timely. When corrections are not made immediately, the program user will receive an automatic e-mail notification from JAMES stating that the PCA has been rejected.


**1.29.1.3.6.7** **(07-15-2022)**

##### Entering New Audit Reports into JAMES

1. Most GAO audit reports are entered into JAMES by EAM. Financial statement audit related reports are entered into JAMES by the CFO Financial Management Audit section. TIGTA audit reports are entered into JAMES by TIGTA.

2. Review of New Data Actions in JAMES – Once the information has been entered into JAMES, the JAC from the lead business unit will be notified by e-mail and provided with an A6 Audit Summary Report. The JAC will review the data on the A6 Summary Report to ensure that the PCAs, audit report findings, recommendations, PCAs, root cause category, monetary benefits, if applicable, due dates, and the assignment of responsibility are accurate. Responsible Official(s) in EAM must be notified of any errors as soon as possible. If the information contained in JAMES is correct, the JAC will send an e-mail of concurrence by the response due date to verify information entered in JAMES.

3. **TIGTA Sensitive Audit Reports** – Redacted reports can take longer to enter into JAMES due to TIGTA’s restrictions of releasing the report to the general public. (These are reports that have sensitive and/or classified information removed or filled-in with dots/dashes etc.) These reports are often delayed anywhere from three to eight weeks or longer due to additional editing and processing before public release. Since TIGTA updates JAMES based on the final audit report, there is a time lag that could delay these actions.

4. The following should be noted:



1. JAMES requires that all the numbering sequence for PCAs for a recommendation begin with the number one (1). The recommendation number in JAMES may not match the recommendation number in the final audit report. The audit report may number recommendations in sequential order irrespective of their relationship to the findings. The same is true for PCAs.

2. A tracking method is in place to account for the realized/unrealized benefit when the recommendation is implemented. The potential monetary benefit is tracked at the recommendation level. The realized/unrealized monetary benefit is tracked at the PCA level when the PCA is implemented. Any disagreement must be addressed in the IRS official response to TIGTA. If, after the final report is issued whereby the IRS agreed with the outcome measures (or remained silent in their management response), the IRS determines that it now disagrees, the business unit should issue a memorandum to TIGTA explaining their disagreement after consulting with EAM. EAM should also be copied when the email is sent from the business unit to TIGTA.

3. If the recommendation is rejected, then the associated monetary benefit is rejected as well.

4. Corrections to typographical errors or misspellings will not be made unless the errors significantly change the intent or meaning of the finding, recommendation or PC.


**1.29.1.3.7** **(02-03-2021)**

#### Root Cause

1. Root Cause is the primary issue identified by the auditors which gave rise to their finding. Audit reports often discuss multiple findings and the process of identifying the finding is subject to interpretation. Audit reports with positive findings and no recommendations will not have a root cause recorded in JAMES. See _Exhibit 1.29.1-6_, Root Cause for Findings – Definitions & Examples.



1. TIGTA audit report findings are recorded by the TIGTA audit team responsible for producing the report, and the root cause reason code selection will reflect their evaluation.

2. GAO audit report findings are recorded by EAM. Report findings are discussed in the GAO report and the root cause determination is made by EAM based on information contained in the GAO audit report.

3. Business units will have the opportunity to review GAO root causes and request changes during the normal audit report verification process.


**1.29.1.3.8** **(10-21-2024)**

#### Guidance for Recommendations on Hold

1. Background.



1. The Hold feature was instituted in 2017 as a result of IRS senior leadership concerns about committing to corrective action(s) when budgetary or other constraints were likely to inhibit implementation. An IRS recommendation placed on Hold was recorded in JAMES without a planned corrective action or due date. However, the business unit was required to input appropriate information in the Comments section to outline the actions that would represent the PCA to document the underlying actions for which they are seeking funding. Input from management’s response outlining why the Hold is being utilized is documented in JAMES.

2. The process for placing recommendations on hold was removed. Recommendations currently in Hold status will remain until they are either implemented or aged out of the process.



      > Recommendations that remain in Hold status will continue to be required to submit an annual milestone update, highlighting efforts since the last milestone update as well as planned future actions to resolve the hold recommendation. This will be accomplished by the submission of Form 13872, similar to the long-term PCAs guidance in IRM 1.29.1.3.9.

3. For any existing Hold recommendation, should the business unit wish to close the Hold recommendation as “unimplemented”, they will partner with EAM to present the request to the Management Controls Executive Steering Committee (MC ESC) for approval to avoid any reputational or programmatic risks from not implementing Holds that had initially been deemed to be mission critical. Seeking MC ESC approval on the request to close a Hold recommendation as "unimplemented" provides a forum to discuss the request, outline the potential risk that could occur as a result, identify any monitoring or mitigation steps that would be implemented to minimize the occurrence of these risk and identify alternative actions the business unit may still be taking related to the recommendation.


2. With MC ESC concurrence on the proposed closure as "unimplemented" , the business unit should follow the process outlined in IRM 1.29.1.3.9(2) or (3) to provide notification to the external audit agency and upload documents into JAMES for recordation of the MC ESC concurrence and audit agency notification.


**1.29.1.3.9** **(07-15-2022)**

#### Managing Unique PCA Activities

1. Managing Long-term PCAs or Long-term PCA Extension.



1. The Responsible Official(s) in EAM will establish an initial milestone date for the business unit JAC to update the status of PCA with a due date greater than two years. This milestone date will be 12 months after entry of the report into the system.

2. Business unit JACs will receive a systemic notification 30 days prior to the milestone date. The business unit JAC will be required to report on the actions planned and/or taken to date. Based upon the scope of the actions to be addressed as outlined in the Comments field, a follow-up milestone date will be established by EAM. The milestone field will display the most recent date in the field. The history button (located under “Milestone Date”) will display all previous status dates.

3. Each business unit JAC will be required to place their status update comments into JAMES utilizing the “Add Status/Comment” functionality. The A6 Audit Summary report can be utilized for sharing this information.


2. Requesting Cancellation of a PCA/Rejection of a Recommendation – TIGTA: Business unit management, after consultation with and concurrence from the EAM Director, should submit requests for cancellations of PCAs or rejections of recommendations directly to TIGTA with a copy to EAM. Any related correspondence must be sent to EAM and uploaded into JAMES as documentation. Approved PCA cancellation responses from TIGTA must be entered into JAMES by EAM.



1. TIGTA written concurrence is required to reject recommendations and cancel corrective actions that were originally agreed to in the final audit report. Typically, the audit director or executive in TIGTA responsible for the related audit should be contacted. Business unit cancellation or rejection requests must identify the report, finding, recommendation, and PCA., if appropriate.

2. Requests must include the reason the corrective action or recommendation will not be implemented and the effective date for the cancellation or rejection. The JAC, along with the responsible business unit primary audit liaison, can work with TIGTA before the official memo is sent because TIGTA may require information before agreeing to the requested action.

3. If TIGTA concurrence is received, the JACs will upload the concurrence memo, and supporting documentation (if applicable) and enter comments. The JAC will send a request to EAM to enter the cancelled or rejected status into JAMES. EAM will validate the request.

4. For Hold recommendations, once MC ESC approval is secured, the business unit and EAM will partner to finalize the memorandum to TIGTA seeking "closed – unimplemented" . The memorandum will be signed by the business unit with EAM copied.


3. Requesting Cancellation of a PCA / Rejection of a Recommendation - GAO: Business unit management, after consultation with and concurrence from the EAM Director, should submit requests for cancellations of PCAs or rejections of Recommendations directly to GAO with a copy to EAM. Any related correspondence must be sent to EAM and uploaded into JAMES as documentation.



1. The business unit provides GAO a written concurrence request to reject a recommendation or cancel a corrective action that was originally agreed to in a 180-Day Letter. Typically, the executive in GAO responsible for the related audit should be the recipient.

2. The business unit written request should be presented to GAO, via a letter similar to the management response format, identifying the report, finding, recommendation, and PCA. The request must include the reason the corrective action or recommendation will not be implemented and the effective date for the cancellation or rejection. The JACs along with the responsible business unit primary liaison can work with GAO before the official memo is sent as GAO may require information before agreeing to the requested action.

3. If GAO concurrence is received, the JAC will upload the concurrence memo and, support documentation (if applicable) and enter comments. The JAC will send a request to EAM to enter the cancelled or rejected status in JAMES and EAM will validate the request.

4. For Hold recommendations, once MC ESC approval is secured, the business unit and EAM will partner to finalize the letter to GAO seeking "closed – unimplemented." The letter will be signed by the business unit with EAM copied.


4. Re-Opening a PCA.



1. To reopen a PCA, the business unit JAC must provide to EAM an email with justification for the reopen request (which usually occurs after dialogue with the auditor) along with Form 13872 with all required approvals. The form and email are stored in JAMES.

2. In most cases depending on the action taken/system limitations, the original PCA will remain closed, and the BU will request a new (replacement) PCA be added to JAMES (e.g., 1-1-1 will be replaced with 1-1-2 with a new action). Instructions for completing Form 13872:

3. Instructions for completing Form 13872.



      > i. The new PCA number should be entered into Box 1c.





      > ii. The status of progress report should be entered in Box 4a.





      > iii. The new planned implementation date should be entered into Box 4b.





      > iv. The new PCA should be entered into Box 6.





      > v. The new PCA request, justification, and responsible organization should be entered into Box 7.

4. After the request is received from the business unit JAC, EAM works with Treasury to reopen the recommendation which allows the PCA to be reopened or new PCA added and confirms the information through the A6 review process. Each business unit will be responsible for processing the closures/delays following current JAMES/EAM documentation guidelines.


5. Revised/Cancelled - Replaced Corrective Actions.



1. Whenever business unit management requests a revision to a PCA, the following must be specified:



      > i. Reason the action is being revised.





      > ii. Description of the new action.





      > iii. Revised due date unless the original due date is still applicable.

2. If the PCA is being cancelled and replaced with another action, EAM will cancel the original PCA and replace it with a new PCA in JAMES. The new PCA will be linked to the original PCA for tracking purposes. (e.g., 1-1-1 will be cancelled and replaced with 1-1-2 with a new action).

3. Instructions for completing Form 13872.


> i. The new PCA number should be entered into Box 1c.

> ii. The status of progress report should be entered in Box 4a.

> iii. The new planned implementation date should be entered into Box 4b.

> iv. The new PCA should be entered into Box 6. The new PCA request, justification, and responsible organization should be entered into Box 7.

> v. The Form 13872 and concurrence memo (email) are stored in JAMES.

### Note:

TIGTA Audit Reports: When there are significant revisions to corrective actions, the business units may request changes after consulting with EAM, the business unit should send their request to TIGTA for concurrence, with copies to EAM. The business unit should send the signed TIGTA concurrence to EAM. EAM will upload request and concurrence document along with Form 13872 into JAMES.

### Note:

GAO Audit Reports: When there are revisions to corrective actions originally agreed to in the 180-Day Letter, related correspondence must be sent to EAM and uploaded into JAMES as backup documentation. The same request and notification procedures outlined above in the Requesting Cancellation of a PCA / Rejection of Recommendation - GAO category apply to revisions.

6. Transfer of Ownership for Audit Recommendations:



1. A PCA being transferred to a different business unit must have signed concurrence from the receiving executive, accepting responsibility for the PCA. An e-mail from the accepting executive is sufficient.

2. The transferring official will provide the new responsible official with the necessary JAMES reports and any other pertinent documentation to ensure timely reporting.

3. Senior executives can make transfers of responsibility within their subordinate functional area without the required concurrence of the accepting official.

4. When this occurs, the senior executive and/or JAC will need to notify EAM of this change, so that the responsibility codes can be changed in JAMES.

5. EAM will notify either TIGTA or GAO regarding the change in PCA ownership.


**1.29.1.3.10** **(07-15-2022)**

#### EAM Reporting

1. EAM Monthly Audit Reporting - EAM prepares statistics monthly to keep management informed of the progress of PCAs. These statistics reflect current month and year-to-date performance percentages on how well the business operating divisions are doing in implementing their PCAs timely.

2. EAM provides a quarterly snapshot of the PCA inventory to the Management Controls Executive Steering Committee as well as ad hoc briefings with senior leadership.

3. Quarterly Forecast - EAM prepares a quarterly forecast of PCAs that projects whether business units plan to meet or extend any PCA due dates. In addition, the business units identify PCAs that require IT involvement, providing clarifying information (i.e., Work Request, Work Order #, and points of contact) that would allow IT staff members to research and identify the status of the action item and determine potential effect, if any, on the successful completion of the PCA. It also requires the business units to assess whether the IT action will prevent closure of the PCA. The Business Units are asked to review the Quarterly Schedule of open PCA’s and 1) Indicate whether they intend to meet “met” or “extend” the due date for each PCA; 2) Identify whether the respective PCA includes any actions that require IT involvement; and 3) If IT Involvement is indicated, describe (i.e., Work Request, Work Order #, POCs, etc.).

4. On the monthly Closed Audit Indicators Report, the following definitions are used:



1. MET - PCAs that were implemented on or before the scheduled PCA due date.

2. MET PRIOR PERIOD - PCAs that were implemented before the current PCA due date and before the timeframe of the scorecard reporting.

3. MISSED - PCAs that were never implemented or that were implemented, cancelled, or extended after the scheduled PCA due date.

4. CANCELLED - PCAs that were cancelled on or before the scheduled PCA due date.

5. EXTENDED/DELAYED - PCAs that were extended on or before the scheduled PCA due date and the final implementation was not accomplished by the due date established by the responsible organization.


**1.29.1.3.11** **(02-03-2021)**

#### Tracking and Reporting Outcome Measures

01. Only dollar-related outcome measures are tracked in JAMES. These are referred to as monetary benefits and must be addressed before a PCA can be closed. Examples include cost savings, funds better used, and revenue potential. A statement explaining actions taken to realize the amount must be included when the PCA is updated and noted on Form 13872. A thorough explanation as to how the monetary benefit calculation was obtained must be provided, even if the net results are less than what was originally agreed to and/or result in $0 dollars realized.

02. Simply indicating $0 without an explanation and/or “No Monetary Benefits Realized” is not acceptable and will not be validated EAM. If management disagrees with the TIGTA potential benefits estimate, the disagreement must be stated in the IRS’s official Management’s Response to the Draft Report. When monetary benefits are not addressed by management in the final response, it is concluded that the IRS agrees with the monetary benefits stated in the final audit report.

03. Any disagreement after the final report is issued must have a signed concurrence (either original or electronic) from TIGTA to close the recommendation/PCA without addressing the realized benefits, and a copy must be provided to EAM.

04. To document disagreement with TIGTA’s stated potential monetary benefits, $1 is entered in the PCA section of JAMES in the realized monetary benefits field as notification to the Department of the Treasury that management disagreed with TIGTA regarding the estimated monetary benefits. (No further monetary benefit action is required in JAMES).

05. If a portion of the dollar amount was realized, indicate the amount realized in the appropriate box in the PCA section of JAMES and provide an explanation/calculation in the status field that describes the basis for the amount realized and a reason for the amount not realized, if appropriate.

06. If monetary benefits have been identified and a PCA contains more than one responsible official, management should determine during the draft stage of the audit report response who will report on the potential benefits.



    1. If a recommendation contains multiple PCAs and monetary benefits have been identified for one of the PCAs, the other PCAs related to that recommendation will be affected in JAMES. The responsible official for the PCA containing the monetary benefits must address the benefits before the PCA can be closed in JAMES.

    2. The responsible official for the remaining PCAs will enter $0 in the appropriate box and report in the status field that monetary benefit has been or will be addressed in the PCA by another named official.


07. If management disagreed with the benefits, $1 will appear in JAMES for all related PCAs associated with that recommendation.

08. If TIGTA issues an audit report where the PCA has been implemented but the recommendation contains monetary benefits, EAM will notify the business operating division(s) that the recommendation is closed but management still needs to address the monetary benefits.

09. If management cannot provide the realized monetary benefits amount upon request, a due date must be provided indicating when the monetary benefit information will be provided.

10. If management cannot timely address the monetary benefits and does not provide a due date, EAM will enter a two-month due date for management to provide the necessary data, even though the PCA is considered closed.

11. Responsibility for addressing the outcome measure(s) must be assigned during the draft audit stage, not when being entered into JAMES.

12. If cost savings cannot be realized, enter $0 in the appropriate box. This indicates that management agrees with the amount of the questioned costs, but the cost cannot be reimbursed or offset. This should also be reflected on Form 13872 with an explanation stating why the cost cannot be reimbursed or offset.

13. If unique situations occur, they will be handled on a case-by-case basis and involve all parties concerned.



    ### Note:



    Refer to _Exhibit 1.29.1-5_, Audit Outcome Measures, for a complete discussion of the underlying audit terms / definitions.


**1.29.1.3.12** **(07-15-2022)**

#### Guidance for Tracking Time Spent on Audit Activities

1. All IRS employees engaged in TIGTA/GAO audit activities, including but not limited to audit liaisons, subject matter experts, managers, and executives, will code their bi-weekly time input into SETR or subsequent applications to capture the time spent during the pay period on TIGTA/GAO audit related activities.

2. IRS employees charging their time for audit related activities will use one of three codes in the timekeeping system to record their time spent. More detailed descriptions and examples of the codes can be found in _Exhibit 1.29.1-8_, Timekeeping Definitions and Examples. The codes are:



1. 800-85260 – direct time spent completing activities associated with a specific TIGTA audit.

2. 800-85270 – direct time spent completing activities associated with a specific GAO audit.

3. 800-86010 – direct time spent competing activities not associated with either a specific TIGTA or GAO audit but pertaining to the TIGTA/GAO audit program, such as training, audit or corrective action inventory management, and briefing leadership.


**Exhibit 1.29.1-1**

### Audit Life Cycle

![This is an Image: 69176001.gif](https://www.irs.gov/pub/xml_bc/69176001.gif)

> Document titled Enterprise Audit Management Audit Life Cycle. Eight blue boxes shown on three rows with arrows connecting the boxes and flowing from left to right. The next row down is connected with arrows also flowing from left to right. Each box has 4 to 6 bullets describing the events that take place at each phase of the audit cycle.The three boxes on the top row are: Box 1 – Fiscal Year Audit Plan; Box 2 Notification of Planning & Research; Box 3 Engagement/Notification Letter-Formal Opening.The next three boxes on the middle row are: Box 1 Fieldwork; Box 2 Agreement to Facts/Statement of Facts; Box 3 Discussion Draft & Draft Report.The last row has two boxes: Box 1 Final Report; Box 2 Planned Corrective Actions.

[Please click here for the text description of the image.](https://www.irs.gov/media/285051 "")

**Exhibit 1.29.1-2**

### 180-Day Letter Response

The following is an excerpt from a hypothetical 180-Day Letter response, showing the PCA for recommendation 3 of a fictional GAO final report. This example is intended to give the reader an idea of the level of discussion and detail that must be included in a 180-Day Letter response. Actual 180-Day Letter responses will include different types of information and discussion.

**Recommendation No. 3:** The ABC Business Unit should take measures to address the skill gap between the technical skills of the current ABC workforce with the technical skills necessary to meet both ABC's short-term and long-term organizational goals.

**Corrective Action:** The IRS agrees with GAO's recommendation. The ABC Business Unit will conduct a skills gap analysis comparing the technical skills of the current ABC workforce with the skills necessary to meet both ABC's short-term immediate needs and longer-term organizational goals. The skill gap analysis will be used to establish a training curriculum that will help bridge the gap between the current-state workforce and organizational needs.

**Planning and/or Recent Accomplishments:** In July 2019, the ABC Business Unit convened a study team to conduct a skill gap analysis to determine the variances between existing and required skill levels for ABC. The team assessed current skill levels through a survey that was distributed to all ABC technical employees and targeted interviews of employees within several key job classifications. The team worked with senior ABC leadership to identify short and long-term goals and the critical skills needed to be able to meet these goals. The team then compared the current skill levels with the critical skills identified by senior leadership to determine the skill gap. The outcome of this study revealed that, within the ABC Business Unit workforce, there is an inadequate number of employees designated as advanced Subject Matter Experts (SME).

**Planned Next Steps:** The ABC Business Unit will develop a training curriculum to develop employees to become advanced SMEs with the critical technical skills required to meet organizational needs. A training working group has been established. The group will meet on a biweekly basis and will lead the effort to create the training curriculum.

**The planned next steps are to:**

- Define the critical skill sets for advanced SMEs, assess whether existing training courses support the development of the identified critical skill sets and notate the training gap that exists where these skill sets are not supported by current training offerings. \[1st quarter of FY20\].

- Address training gaps through planning new training courses (including outlining the learning objectives, prerequisites, and target audiences for all new courses). Socialize the curriculum to program managers so that they are aware of potentially new and/or updated courses for their employees' development. \[3rd quarter of FY20\] Begin the update of existing and the development of new courses. \[3rd quarter of FY20 – 3rd quarter FY21\].

- Present the comprehensive training curriculum to ABC senior leadership for approval and incorporate any recommendations/suggestions in the curriculum. \[3rd quarter of FY20\].

- Socialize the curriculum to program managers so that they are aware of potentially new and/or updated courses for their employees' development. \[3rd quarter of FY20\] Begin the update of existing and the development of new courses. \[3rd quarter of FY20 – 3rd quarter FY21\].

- Deploy new training courses to ABC employees. \[4th quarter of FY21\].


**Implementation Date:**November 15, 2021

**Responsible Official:**Director, ABC Business Unit

**Exhibit 1.29.1-3**

### Categories for Delays/Extensions in JAMES

The IRS tracks extension activities in JAMES. The JAC is required to use the appropriate reason for delay when completing Form 13872 to extend PCAs in JAMES. If a JAC provides an extension request via Form 13872, the JAC must ensure that the appropriate reason is included in the documentation of select the appropriate box in JAMES. The list below provides all of the reasons with a brief definition. These reasons may also be found on Form 13872 in item 4c. and in the drop-down menu box in JAMES.

01. **Research/Analyze Data**– Delays in implementation in order to perform additional analyses or studies.

02. **Publishing**– Delays in issuing or publishing guidance or manuals.

03. **Concurrence**– Delays due to PCAs that are coordinated with other offices before the action could be implemented, closed, or cancelled.

04. **Monetary Benefits**– Delays to address associated actual monetary benefits.

05. **Legislation**– Delays due to waiting for the resolution of a legal issue and/or Congressional action.

06. **Clearance**– Routing delays for comments or reviews (supporting documentation must show that it is in the final stage of the review process).

07. **Budget**– Delays due to waiting for the approval of funding.

08. **Resources**– Delays due to the lack of sufficient resources due to budget constraints.

09. **Contracting**– Delays due to waiting for contract awards or when procurement activities are not complete.

10. **Information Technology**– Unforeseen release delays due to programming or hardware/software issues.


**Exhibit 1.29.1-4**

### Evidentiary Documentation Examples

The following Support Documentation Decision Tables below should be used to help determine the appropriate set of documents to submit in support of closing a planned corrective actions (PCAs) in the Joint Audit Management Enterprise System (JAMES). The PCA, or the response to the GAO/TIGTA audit recommendation, is often times very specific in stating the action(s) IRS agrees to implement. It is important to ensure appropriate documentation is secured and available at the time IRS reports a PCA as being fully implemented.

**Issue Guidance**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Update the Internal Revenue Manual | Issue Interim Guidance to the IRM; and then update relevant IRMs | - Interim Guidance Memo<br>  <br>- Updated Internal Revenue Manual (IRM)<br>  <br>- Internal Procedural Update (IPU) |
| Clarify IRS guidance and/or develop and implement policies in the IRM | Issue policy guidance clarifying process and/or issue an IRM interim guidance memo establishing requirements | - Updated existing IRM<br>  <br>- Copy of new IRM<br>  <br>- IPU<br>  <br>- Interim Guidance Memo<br>  <br>- Memo of Understanding (MOU)<br>  <br>- Taxonomy Report<br>  <br>- Copy of Manger Alert |

**Review/Update/Establish Procedures**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Develop processes and procedures | Issue an IRM Procedural Update | - Copy of IPU<br>  <br>- IRM<br>  <br>- Desk Guide<br>  <br>- SERP Alert<br>  <br>- Copy of Comprehensive Plan<br>  <br>- Copy of Study<br>  <br>- Copy of Analysis |
| Ensure that written guidance is issued | Issue an all-employee communication via the SERP Alert, instructing employees to follow the guidance provided by the IRM | - SERP Alert<br>  <br>- Copy of existing IRM<br>  <br>- Copy of Specific sections from IRM<br>  <br>- Desk Guide<br>  <br>- MOU<br>  <br>- Training Materials |
| Ensure IRM guidelines are followed | Ensure IRM guidelines are followed | - SERP Alert<br>  <br>- Copy of existing IRM<br>  <br>- Copy of Specific sections from IRM<br>  <br>- Desk Guide<br>  <br>- MOU<br>  <br>- Training Materials |

**Conduct Training**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Provide refresher training | Conduct refresher training | - Proof of scheduled training dates<br>  <br>- Course materials<br>  <br>- Training Materials<br>  <br>- Power Point Presentations<br>  <br>- Roster of attendees<br>  <br>- Invitation to attend training/meeting<br>  <br>- Notification to attend training |

**Review Records/Information**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Conduct periodic quality reviews | Finalize official Standard Operating Procedures (SOP) to establish a formal quality review process. | - Copy of SOPs<br>  <br>- Link to SOPs<br>  <br>- Copy of communication to require reviews<br>  <br>- Copies of dated reviews |

**Automate Process/Program Change**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Revise Computer Programming to ensure | Revise Computer Programming | - UWR (completed status<br>  <br>- UWR attachments that describe actions requested<br>  <br>- Email communications |

**Consult with an Outside Agency and Conduct a Review**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Consult with Department of the Treasury officials to | Develop requirements for modifications and consult with the Department of Treasury | - Email communications<br>  <br>- Copy of memo or letter to agency<br>  <br>- Documentation of the modification requirements<br>  <br>- Meeting notes with agenda topics<br>  <br>- Meeting notes with action /decision items |

**Perform/Conduct an Analysis, Analyze Data**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Establish processes to evaluate amended tax returns | Conduct a Study | - Copy of feasibility study<br>  <br>- White Paper Analysis Summary<br>  <br>- Risk Assessment Report |
| Establish processes to evaluate amended tax returns | Explore the feasibility of how best to process amended returns | - Copy of feasibility study<br>  <br>- White Paper Analysis Summary<br>  <br>- Risk Assessment Report |

**Update Publications**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Improve the quality of data collected | Update technical specifications and also revise guidance provided in the publications | - Documentation of the update technical specifications<br>  <br>- Copy of the revised publication with instructions<br>  <br>- Measurement data that supports improved performance |
| Revise the TY 2019 Form | Revise the 2019 Form 1040 and prepare programming requirements | - Copy of revised from<br>  <br>- Copy of revised instructions<br>  <br>- Page from Media and Publications verifying revision date<br>  <br>- Copy of notification communication confirming completed revision<br>  <br>- Copy of programming work order<br>  <br>- Copy of UWR with appropriate status |

**Install Equipment**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| The Federal Protective Services consider installing Intrusion Detection System (IDS) | Refer the recommendation to the Federal Protective Service as the official security organization for the facility | - Email communication<br>  <br>- Copy of letter or memo<br>  <br>- Copy of other form or formal communications<br>  <br>**Follow-Up Documents:**<br>- Copy of completed work order from installation<br>  <br>- Photos of installed equipment with description<br>  <br>- Other documentation that supports installation |

**Present, Distribute, Communicate Information**

| IRS is Recommended to... | And IRS Agrees to... | Then Closing Documentation Might be... |
| --- | --- | --- |
| Employees correspond with taxpayers | Issue an alert to remind employees to follow the instructions in the IRM | - Copy of SERP Alert<br>  <br>- Copy of Manager Alert<br>  <br>- Copy of News Release<br>  <br>- Copy of IRM or sections from IRM |

**Exhibit 1.29.1-5**

### Audit Outcome Measures

Audit Outcome Measures assess or quantify effect, show value, and measure performance on business operations or tax administration. “These measures should be quantifiable to the maximum extent possible, linked directly to the audit finding based on transaction or case analyses or statistical projections, and expressed in monetary or other measurable units such as hours spent in performing an activity or units of production. ("TIGTA Operational Manual, 2019, p.56" ).

An outcome measure may be potential or actual. Most outcomes will initially fall under the potential category since the corrective action would not have taken place at the time of the final audit report (if audit tests and data were compiled before the corrective action was implemented).

- Potential outcomes are based on projections of historical results to future events.

- Actual outcomes should be based on historical evidence, such as the dollar results of a recovery program.


Outcome measures, both actual and approximated/potential, can be based on actual transactions, statistical samples, estimation or judgmental samples. Actual transactions identify each transaction meeting the reported condition. Statistical samples use valid sampling techniques to project results. Estimation applies known data to the reported condition. Reported outcomes from judgmental samples are limited to actual transactions identified.

Outcome measures must be addressed in the Management’s Response to the Draft Report. _The importance of this cannot be overstated_. The Inspector General Act of 1978, as amended, requires TIGTA to prepare semiannual reports to Congress summarizing activities for the six-month periods ending March 31 and September 30. The act requires detailed tables for audit reports that identified Questioned Costs and Funds Put to Better Use.

**Definitions and Examples of Audit Outcome Measures**

1\. Cost Savings

**Definition:** Reducing the acquisition, deployment, or price of goods and services, expressed in dollars. Cost savings consist of:

Questioned Costs

1. Costs that cannot be reimbursed because they represent a violation of law, regulation, or contract. For example, a vendor charged travel above the reimbursement rate allowed by the contract and Federal travel regulations. The outcome measure is derived by computing the difference between the costs charged and the allowable amount.

2. The expenditure is not reasonable or necessary to accomplish the intended purpose. For example, the IRS reimbursed a contractor $3,000 for hardship travel pay. The Defense Contract Audit Agency found that the contractor’s travel policy was unreasonable, and the cost expense was disallowed.

3. Questioned costs have an additional sub-category called unsupported costs. Unsupported costs are costs that are appropriate but for which the vendor cannot provide proof that the cost was incurred. For example, the vendor charges for supplies as stipulated in the contract but does not produce receipts or other evidence to support the transaction.


2\. Funds Put to Better Use

**Definition:** Implementing recommendations results in a more efficient or economic program agency-wide. IRS costs are reduced; savings would be available for other purposes (budgetary effect). Funds could be used more efficiently or effectively if management took actions to implement recommendations including.

1. De-obligation and reprogramming of funds from programs or operations.

2. Costs not incurred by implementing improvements to operations.

3. Ending a program.

4. Avoidance of unnecessary expenditures identified during pre-award contract reviews.

5. Reductions in outlays.

6. Any other savings that are specifically identified. Example: Improper calculation of office space led to millions of dollars in unnecessary rental expenses.


3\. Increased Revenue Protection:

**Definition:** The value of efficiencies gained from recommendations to reduce cost while maintaining or improving the effectiveness of specific programs. These cost savings would not lower the total operational cost of the agency; rather, the resources saved will be available to other IRS programs. Example: Management agrees to automate a research function, thus making staff available for other programs. While the IRS would continue to incur the labor costs, the staff would be reassigned to another program.

4\. Inefficient Use of Resources:

**Definition:**The value of efficiencies gained from recommendations to reduce cost while maintaining or improving the effectiveness of specific programs. These cost savings would not lower the total operational cost of the agency; rather, the resources saved will be available to other IRS programs. Example: Management agrees to automate a research function, thus making staff available for other programs. While the IRS would continue to incur the labor costs, the staff would be reassigned to another program.

1. The value of internal control weaknesses that resulted in an unrecoverable expenditure of funds by the IRS with no tangible or useful benefit in return. The measure will place a monetary value on the shortcomings of past management decisions as part of TIGTA’s recommendations to correct the systemic weaknesses **Example:**The IRS spent money on a database that was not used by its employees, who relied instead on information available from other sources. While the IRS would not be able to recover the costs of the database, following TIGTA’s recommendations will help management improve its process for more precisely determining its needs in the future.


5\. Protection of Resources

**Definition:** Safeguarding human and capital (monetary) assets, used by or in the custody of the IRS, from accidental (inadvertent) or malicious injury, theft, destruction, loss, misuse, overpayment, or degradation. Example: Value of sensitive equipment vulnerable to loss or theft due to poor controls over procuring, recording, and storing assets.

6\. Reliability of Information

**Definition:** Ensuring the accuracy, validity, relevance, and integrity of data, including the sources of data and the applications and processing thereof, used by the IRS to plan, monitor, and report on its financial and operational activities. Example: The value, expressed in units or percentages, of an overstatement in the number of customer service telephone calls answered in a fiscal year, thus distorting a key performance measure that is reported to Congress. (Note: If this resulted in procuring unnecessary extra phone lines or equipment, there may also be potential cost savings.)

### Note:

Protection of Resources and Reliability of Information measures will be expressed as an absolute value (i.e., without regard to whether a number is positive or negative) of overstatements or understatements of amounts recorded on the organization’s documents or system.

7\. Taxpayer Burden

**Definition:** Lessens the burden of taxpayers who comply with the tax law and/or decreases the time and resources spent on tax-related activities such as record keeping, preparation, or compliance with tax laws, regulations, and IRS policies and procedures. Example: As a result of implementation of a new minimum threshold for foreign income, 1.7 million taxpayers no longer have to file a complex form with their tax return when claiming small amounts of foreign income tax credit on certain types of income, thus saving 10.2 million hours of burden. (Note: The IRS also saves transcription time, error correction, etc., which could also be calculated and included in cost savings.)

8\. Taxpayer Privacy and Security

1. **Privacy:** Concerning the protection of taxpayer financial and account information.

2. **Security:** Involving processes and programs designed to provide protection of tax administration infrastructure and data. Example: The number of taxpayer accounts vulnerable to unauthorized disclosure or access to account information because electronic files were left unprotected or on an unsecured personal computer.


.

9\. Taxpayer Rights and Entitlements

1. **Rights:** The protection of due process that is granted to taxpayers by law, regulation, or IRS policies and procedures. These rights most commonly arise in the performance of filing tax returns, paying delinquent taxes, and examining the accuracy of tax liabilities.

2. **Entitlements:** The acceptance of claims for issuance of refunds relating to instances when taxpayers have a legitimate assertion to overpayments of tax, expressed either in dollars or units such as the number of taxpayer account. Example: Determining the number of taxpayer accounts where notices of Federal tax liens were filed improperly (the taxpayer had already fully paid the account, the supervisor did not approve the lien filing as required, etc.). Improper lien filings can adversely affect a taxpayer’s financial profile and specifically violate a taxpayer’s rights. Example: Failing to consider whether taxpayers claimed all the withholding they were entitled to during an examination process, thus potentially denying refunds to those taxpayers.



### Note:



For Cost Savings, Funds Put to Better Use and Increased Revenue Outcome Measures, the amount realized will be determined.





### Note:



Resource Materials for this _Exhibit 1.29.1-5_, Audit Outcome Measures, include: TIGTA Operations Manual, January 1, 2019, Chapter (300)-90 – Reporting Audit Results, (300)-90.25 – Identifying and Reporting Outcome Measures; page 56.


**Exhibit 1.29.1-6**

### Root Cause for Findings – Definitions & Examples

**Internal Fraud:** Intentional acts to defraud or misappropriate property involving at least one internal party. The following two criteria must be present

- Intent

- The goal of the act is to procure a personal benefit for which they are not entitled Example: Improper revenue recognition, misrepresentation of assets, liabilities, expenses, improper financial disclosures to internal/external parties, financial asset theft, manipulation of estimates/models.


**External Fraud:** Intentional acts to defraud, misappropriate property, or circumvent the law by a third party, where the agency is used to perpetrate the fraud or is a victim of the fraud. Example: Asset theft, information theft, fraud in transactions by misrepresentation, misstatement, or omission, misrepresentation of association with Treasury to third parties or vendors.

**Employee Error:** Unintentional employee errors or omissions in process execution. Example: Miscalculations, data entry mistakes, providing inaccurate data or metadata, unintentional employee omission to execute a process step or technology job, poor judgment, being unaware of policy or procedure.

**Employee Misconduct:** Employee wrongdoing, such as violation of employment laws or regulations, violation of organizational policies and procedures; misuse of the organization’s assets (does not include fraudulent activity). Example: Using agency computers to browse unauthorized content, negligence in job performance or in safeguarding assets, Human Resources issues/discrimination, violating or not following agency policies and procedures.

**Inadequate Skillset/Training:** Lack of appropriate skill set and knowledge to execute required tasks. Example: Key person dependency, knowledge management, skill building.

**Resource Limitations:** Insufficient number of staff to adequately perform a job or execute a process or plan of action. Example: Capacity issues.

**Inadequate Workplace:** Inadequate facilities or workplace conditions that could cause harm to employees. Example: Facility maintenance issues; inadequate space/overcrowding.

**Inadequate Technology Design:** Ineffective technology asset or infrastructure design does not support current business needs. Example: Inadequate business requirements, technology scalability issues, poor network security.

**Technology Failure:** Failure of technology assets or infrastructure that leads to business disruption. Example: Interface failures, erroneous transmissions between systems, software and hardware failure, or inadequate system availability.

**Data Quality:** Unknown data quality creates uncertainty in downstream processes and/or systems failures have the potential to significantly disrupt business processes. Example: Inaccurate data released to investors in disclosures (e.g., data impacting pre- payment models).

**Insufficient Internal Controls:**Lack of formal guidance, lack of control points, or insufficient processes that lack proper design.

### Example:

No formal guidance or control points.

**Subcategories**:

- Control Environment

- Risk Assessment

- Control Activities

- Information and Communication

- Monitoring


**Failure of Internal Controls:**Failure to oversee personnel who make key decisions that affect objectives and/or control points within the material processes for the organization. Example: Breakdown or errors in internal process.

**Inadequate Vendor Management:**Inability to monitor/challenge vendor performance and mitigate efforts of terminated services. Over-reliance on a small set of external vendors and/or limited transparency/in-house expertise on vendors’ operations. Example: Incomplete contract that does not cover all the aspects of the relationship that need to be managed up front. Over-reliance on a specific vendor, especially for mission- critical tasks (e.g., lack of in-house knowledge and de-motivation of employees) and, consequently, financial risk (e.g., vendor can over-charge for its services due to the enterprise’s reliance on the vendor).

**Failure in Vendor Performance:**Ineffective vendor performance, violation of contractual agreements. Example: Unable to provide deliverables with appropriate or required content.

**Disaster**: Loss or damage to physical assets, or business disruption due to natural or non-natural disasters. Example: Natural Disasters: earthquake, flood, hurricane, tornado; non-natural disasters: terrorism, catastrophic physical infrastructure failure (e.g., building or bridge collapse).

**Exhibit 1.29.1-7**

### Authority to Disclose Memorandum

![This is an Image: 69176002.gif](https://www.irs.gov/pub/xml_bc/69176002.gif)

> This is an example of what a Disclosure Memorandum should contain.MEMORANDUM FOR \[Insert Commissioner/Chief of Lead BU\]FROM: \[name\], Director, Enterprise Audit management (EAM)SUBJECT: \[Insert Audit Name (Insert Audit Number\], Authority to Disclose Federal Tax InformationThe Government Accountability Office (GAO) informed the IRS that it has initiated the above subject audit. Because of your involvement with this audit as the Business Unit Lead, I am asking your participation in facilitating GAO's review. Enterprise Audit Management (EAM) will work with you and your staff in responding to this audit and will coordinate as needed. As EAM has the principal responsibility for oversight of the enterprise audit program and elevating potential issues to senior leadership, please keep EAM apprised of all significant issues likely to be reviewed by GAO, their potential impact on the IRS, and all review milestones via the Audit Coordination mailbox at audit.coordination@irs.gov (\*Audit Coordination in Outlook). An EAM staff member liaisons with your audit team on open audits and needs to be included in ongoing meetings with GAO during this audit. As indicated in the attached letter dated \[Insert Date from GAO Letter\], GAO has been authorized to have access to returns and return information by the \[identify whether it is the Senate Finance Committee, House Ways & Means Committee or which body authorized such as the Joint Committee on Tax\].You and your designees are authorized to provide GAO with access to any tax or nontax information, with the exception of the identity of an informant or any information which will tend to reveal the identity of an informant, grand jury information, and certain information obtained under tax treaty that falls within the scope of this review.If information exists which would identify a confidential informant, either directly or indirectly, you should partner with EAM to coordinate with the appropriate business unit for authority to withhold the information. Similarly, if it appears that disclosure of tax information to GAO would seriously impair a civil or criminal tax investigation, please coordinate with EAM to seek authorization to withhold such information.

[Please click here for the text description of the image.](https://www.irs.gov/media/333411 "")

![This is an Image: 69176003.gif](https://www.irs.gov/pub/xml_bc/69176003.gif)

> Information may be disclosed only to those representatives whose names appear on the current list of GAO personnel designated to review IRS activities pursuant to IRC 6103(f)(4).Please remember that federal tax information may not be shared between GAO audit teams with similar topics. The authority to disclose federal tax information is specific to each audit.You and your staff are responsible for accounting for the disclosures of federal tax information. Your staff should ensure that all accounting information is provided to the proper organization for processing timely. This information is mandatory as the IRS is required by IRC 6103(p)(3) to provide an annual report to Congress regarding all federal tax information disclosed. Guidance on preparing the accounting information via Form 5466-B or a Narrative is provided in Attachment 1. Disclosures of non-tax information pertaining to individuals (as that term is used in the Privacy Act of 1974 (5 USC 552a)) must be accounted for pursuant to the Privacy Act, and in accordance with the instructions contained in IRM 10.5.6. You and your staff are welcome to contact me, or the \*Audit Coordination mailbox, regarding any questions on the coordination of this audit.Thank you very much.cc: \[Primary Audit Liaison\]Attachment

[Please click here for the text description of the image.](https://www.irs.gov/media/333416 "")

![This is an Image: 69176004.gif](https://www.irs.gov/pub/xml_bc/69176004.gif)

> Attachment 1Enterprise Audit Management Disclosure Accounting procedures pursuant to:§6103(f) Disclosure to Committees of Congress§6103(i)(8) Disclosure to Comptroller General Background:IRC §6103(p)(3)(A) requires the IRS to maintain a system of accounting of all requests for inspection or disclosure of returns and return information (including the reasons for and dates of such requests) made pursuant to IRC §6103(f)(4) and (i)(8), during each calendar year.Accounting should be completed at the time of disclosure.Disclosure accounting requirement guidance is found in IRM 11.3.37.EAM Procedures:AM will inform the business units (BU) of their responsibility to complete the Form 5466-B, or narrative record, to account for the FTI disclosed pursuant to the above authorities. See procedures outlined below for business units to follow for both methods.Business Unit Accounting Procedures via Form 5466-B:Accounting should be completed at the time of disclosure.Guidance to assist in preparing F5466-B is found in IRM 11.3.37. Sample F5466-B with directions.Agency codes: Select requesting committee code per the below chart.Type of AgencyCode Sort (for 5466-B)Agency CodeAgency NameCode Authority FED345FD345Committee on Ways and Means6103(f)(1)FED346FD346Joint Committee on Taxation6103(f)(1)6103(f)(1)FED347FD347Senate Committee on Finance6103(f)(1)FED5FD005Government Accountability Office6103(f)(4)6103(f)(8)FEDCCOFDCCOCongressional Committees except FD345 and FD347 6103(f)(3)Purpose Code (authority):12 – Pursuant to IRC§6103(f) to the Committee of Congress or their agents.), or 20 – Pursuant to IRC §6103(i)(8)(A)(i) to Government Accountability Office (GAO) for audit of IRS.

[Please click here for the text description of the image.](https://www.irs.gov/media/333421 "")

![This is an Image: 69176005.gif](https://www.irs.gov/pub/xml_bc/69176005.gif)

> ADP source code:Select FTI disclosed per IRM 11.3.37-1, or IRM 11.3.37-2, or IRM 11.3.37-3E-Fax or mail completed F5466-B per below.IMFBMFEEFAX to: Kansas City Campus Receipt & Control Unit at (877) 473-7664 Should there be a problem with EEFAX, use conventional mail to ship the Form 5466-B to: Internal Revenue Service Attn: Batching M/S 6052 333. W Pershing Rd. Kansas City, MO 64108EEFAX to: Ogden Campus Receipt & Control Unit at (855) 315-3964 Should there be a problem with EEFAX, use conventional mail to ship the Form 5466-B to: Internal Revenue Service Attn: Batching M/S 6054 1973 N. Rulon White Blvd Ogden, UT 84404Accounting should be completed at the time of disclosure.Guidance to assist preparing a narrative record of accounting is found in IRM 11.3.37.Consider using a narrative record of accounting in lieu of Form 5466-B when accounting for large numbers of disclosures at one time and resource savings would result.A narrative record of accounting summarizes the disclosures of returns/ return information and should include the following items: 1) Category and number of taxpayers: a) IMF - number of IMF taxpayers whose information was disclosed.b) BMF - number of BMF taxpayers whose information was disclosed. c) Tax Periods per year - tax periods per year disclosed (e.g., form 1040 is one tax period/ disclosure per year, form 941 can be up to 4 tax periods/ disclosures per year). Provide listing separately for IMF and BMF if both are reported in the narrative accounting.d) Total number of disclosures (Total number of periods disclosed per IMF and BMF taxpayer).2) Date of disclosure3) Description of documents disclosed: Briefly describe what was disclosed (e.g., Transcripts, lack of record, copy of tax return) 4) Statutory Authority for disclosure:

[Please click here for the text description of the image.](https://www.irs.gov/media/333426 "")

![This is an Image: 69176006.gif](https://www.irs.gov/pub/xml_bc/69176006.gif)

> Business Unit Accounting Procedures via Narrative of Accounting:6103(f)(1)/ Finance, or Ways and Means, or JCT (taxation studies);6103(f)(2)/JCT (taxation studies);6103(f)(3)/ other congressional committees (taxation studies); 6103(f)(4)(A) or (B)/ GAO/ JCT (taxation studies); 6103(i)(8)(A)(i)/ GAO (non-tax audit of IRS)5) Name of agency receiving the information: Provide name and address of the agency receiving the information6) Location of IRS office retaining a copy of disclosed information: Indicate IRS office location where a record of the disclosed information is maintained. 7) Nature of documents disclosed: Describe method of disclosure (e.g., a verbal disclosure, an electronic disclosure, inspection of records, paper copy of record) Forward the completed narrative of accounting at time of disclosure, or no later than January 15 for the prior year disclosures, to \*PGLD Disclosure Accounting.Questions/ concerns can be forwarded to the Disclosure points of contact Ron Mele and Deb Middleton.

[Please click here for the text description of the image.](https://www.irs.gov/media/333431 "")

**Exhibit 1.29.1-8**

### Timekeeping Definitions and Examples

The following definitions and examples pertain to the timekeeping requirements in _IRM 1.29.1.3.12_.

SETR Code 800-85260 represents time charged for TIGTA audits, inspections and evaluations which have an audit number or EAM control number. Examples of activities that should be charged to 800-85260 include:

- Scheduling and/or attending opening and/or closing conferences and other meetings with TIGTA, including internal preparation time or meetings.

- Business unit reporting on receipt of Notification of Audit Planning, Engagement Letter, Agreement to Facts, Discussion Draft and Draft Reports.

- Responding to requests for information from the Notification of Audit Planning through the Draft Report, including scheduling or participating in interviews, handling data pulls, facilitating or participating in walkthroughs or site visits, preparing written responses.

- Providing information to/from your business unit about TIGTA questions, requests, issues or collaboration with other business units pertaining to TIGTA’s findings or recommendations or Outcome Measures.

- Review and analysis of findings and recommendations and formulation of planned corrective actions.

- Responding to email alerts or audit reports.

- Handling all phases of post-audit work such as developing and implementing corrective actions, estimating completion dates, and corrective action closure activities.


SETR Code SETR Code 800-85270 represents time charged for GAO audits, which have an audit number or EAM control number. Examples of activities that should be charged to 800-85270 include:

- Scheduling and/or attending opening and/or closing conferences and other meetings with GAO, including internal preparation time or meetings.

- Business unit reporting on receipt of the Notification Letter, Statement of Facts, and Draft Reports.

- Responding to requests for information from the Notification Letter through the Draft Report, including scheduling or participating in interviews, handling data pulls, facilitating or participating in walkthroughs or site visits, preparing written responses.

- Providing information to/from your business unit about GAO questions, requests, issues or collaboration with other business units pertaining to GAO’s findings or recommendations.

- Review and analysis of findings and recommendations and formulation of planned corrective actions.

- Responding to audit reports, including the management response to the Draft Report and the 180-Day Letter.

- Handling all phases of post-audit work such as developing and implementing corrective actions, estimating completion dates, corrective action closure activities, and responding to GAO requests for updates on the status of a corrective action.


SETR Code 800-86010 represents time charged for activities related to the TIGTA/GAO audit program but not a specific audit. Examples of activities that should be charged to 800-86010 include:

- Preparing and delivering briefings to business unit or IRS leadership pertaining to the current audit or corrective action activity.

- Inventory management for open audits or corrective actions.

- Developing, delivering, or attending training pertaining to audit and corrective actions, including formal or information training classes or workshops.

- Developing, delivering, or attending Audit Community of Practice events.


**Exhibit 1.29.1-9**

### Record Retention Schedule and Interim File Plan

![This is an Image: 69176007.gif](https://www.irs.gov/pub/xml_bc/69176007.gif)

> Enterprise (External) Audit RecordThe records contained in this Schedule are maintained by Enterprise Audit Management (EAM), Office of the Chief Risk Officer and all IRS business units with audit reporting requirements. This Schedule standardizes Service-wide disposition policies for audit records arising from Government Accountability Office (GAO), Treasury Inspector General for Tax Administration (TIGTA) and/or the Department of the Treasury’s Office of Inspector General (OIG) audits and supersedes previously approved business-level authorities cross-walked and annotated in the context of specific RCS chapters. Records covered by this Schedule support processes and activities related to EAM’s oversight of IRS audit responses to audit activities conducted by external entities possessing the statutory and regulatory authority to review, evaluate, and report on IRS business processes, outputs, and outcomes. EAM is the single point of contact for GAO and TIGTA audits and TIGTA inspections and evaluation events. EAM facilitates audits throughout the audit lifecycle, from audit initiation through the reporting phases and post-audit monitoring. EAM provides guidance and support to business units on the audit process and ensures corrective actions time lines and other due dates are met.These updated disposition requests are pending NARA approval under Job No. DAA-0058-2022-TBD. Prior to any records destruction, check with CRO’s IRC or the IRS Records Office (\*Records Management) regarding NARA approval status. Meanwhile, paper records can be retired to a Records Center under pending Job No. DAA-0058-2022-TBD.ITEM NO.DESCRIPTION OF RECORDS1Audit Program Management: Contains records created through non-audit specific actions needed to manage program/performance audit activities by IRS offices Servicewide. This is including, but not limited to: Oversight of audit activities such as inventory, tracking, general audit managementAudit agnostic correspondence with GAO, TIGTA, OMB or Treasury OIG related to external audit functionsSubject files, program reports and correspondence signed by the Commissioner, Deputy Commissioners, Division Commissioners, or equivalent to GAO, TIGTA, OMB or Treasury OIGPENDING DISPOSITION Cut off at the end of the fiscal year. Destroy 5 years after cutoff.2External Audit Reports and Actions: Includes records created by either the external or the IRS in response to GAO, TIGTA, OMB or Treasury OIG. This schedule covers audit-specific records created and/or maintained by the office responsible for overseeing external audit processes and activities Service-wide. This includes, but is not limited to: Records created during the lifecycle of externally initiated audits including planning and research, official letters, fieldwork, external information requests and internal responses, draft reports, management responses, final reports, 180-Day letters, and planned corrective actionsAudit-related work papers and correspondenceAudit-specific corrective action work papers from corrective action development through resolutionAudit and corrective action related records including project artifacts, briefings, and audit case management systemsPENDING DISPOSITION Cut off at the end of the fiscal year in which last corrective action is closed; if no corrective actions are needed, Cut off at end of fiscal year in which final report is issued. Destroy 7 years after cutoff.

[Please click here for the text description of the image.](https://www.irs.gov/media/333436 "")

![This is an Image: 69176008.gif](https://www.irs.gov/pub/xml_bc/69176008.gif)

> ITEM NO.DESCRIPTION OF RECORDS3Business Unit External Audit Support: This item covers records created and/or maintained by any business unit (BU) office or function contributing to an external audit conducted by GAO, TIGTA, OMB, or Treasury OIG. This includes, but is not limited to: BU audit response and mitigationBU documentation provided as supporting artifacts/feeder documents to external audits by all subjects of the auditExternal information requests and internal BU responses to questions from external auditorsBU management response and corrective action working papers including closure evidentiary documentationPENDING DISPOSITION Cut off at the end of the fiscal year in which last corrective action is closed; if no corrective actions are needed, cut off at end of fiscal year in which final report is issued. Destroy 7 years after cutoff.

[Please click here for the text description of the image.](https://www.irs.gov/media/333441 "")

![This is an Image: 69176009.gif](https://www.irs.gov/pub/xml_bc/69176009.gif)

> Enterprise (External) Audit Interim File PlanRecord DescriptionRCS/GRS AuthorityDisposal AuthorityReference Files. Extra copies of correspondence and reports, reference copies of computer-produced reports, directives and internal management documents or other materials retained solely for reference purposes in current operation.N/A – this information is not a federal recordDestroy when no longer neededPolicy or directive documents related to the GAO, TIGTA, and OIG audit programs, including but not limited to, Enterprise Audit Management (EAM) policy documents, IRM and associated background documents, Interim Guidance Memorandums (IGMs), EAM policy documents, or other guidance documentation.20.4.2.A Directives - Official electronic copy 20.4.2.B Directives – All other electronic copiesDestroy when 5 years old. Delete after record keeping copy and official electronic copy have been producedTraining materials. GAO, TIGTA, and OIG Audit training materials such as New Hire Training materials or continuing professional education workshop materials; and, materials utilized for quarterly Community of Practice (COP) events.GRS 2.6 010 Non-mission employee training program records GRS 2.6 030 Individual employee training recordsDestroy when 3 years old, or 3 years after superseded or obsolete, whichever is appropriate Destroy when superseded, 3 years old, or 1 year after separation, whichever comes firstProgram monitoring records. Statistical or analytic documents used for program monitoring and issue identification. Examples include but are not limited to minutes from meetings with external stakeholders, materials submitted to the management control executive steering committee, inventory reports, monthly random samples for PCA evaluations, or any other documents pertaining to studies or analysis.GRS 2.2 020 Workforce and succession planning recordsDestroy 3 years after issuing each new plan, analysis, or modelAudit Coordination mailbox. Due to the difficulty in segregating audit-specific and non-audit-specific materials, the mailbox correspondence will be treated as one entity.GRS 6.1 011/ DAA-0058-2015-0001Destroy 20 years after creation (no action needed, automatically destroyed according to Outlook policy)Administrative Files. Documents pertaining to the administrative, personnel, housekeeping, operations, including base budget, equipment, etc.GRS 1.1 Financial Management and Reporting Records GRS 1.3 Budgeting Records GRS 2.2 Employee Management Records GRS 5.1 Common Office Records GRS 5.4 Facility, Equipment, Vehicle, Property, and Supply RecordsTBD through file plan updates(IT) GAO Reports: Record copy of IS responses and copy of reports relating to tax systems modernization issues.17.4 GAO ReportsPERMANENT Cut off annually Retire to Records Center when 5 years old Transfer to NARA when 20 years old

[Please click here for the text description of the image.](https://www.irs.gov/media/333446 "")

**Exhibit 1.29.1-10**

### Form 13782 Closure Checklist

![This is an Image: 69176010.gif](https://www.irs.gov/pub/xml_bc/69176010.gif)

> Form 13872 Closure ChecklistThe purpose of this checklist is to assist JAMES Audit Coordinators (JACs) in preparing closure packages for review and implementation. This is not an all-inclusive list; therefore, please reference the current version of the Form 13872 Instructions and IRM 1.29.1, Audit Coordination Process, for additional support.Complete all necessary data fields on Form 13872:Box 1Enter Report title, Report number, Planned Corrective Action (PCA number) directly from Final Report.Ensure the Report title in box 1a matches the Report title in JAMES Note: the full title may not fully populate in Joint Audit Management Enterprise System (JAMES) due to character limitations. Enter the Report number in box 1b to match the Report number identified in JAMES.Include the audit number (or Engagement/Job Code number) from JAMES (this can be found under “Display Audit or Show Report”). Confirm the corrective action number in box 1c matches the corrective action number in JAMES.Box 4Select current PCA Status To close an open PCA, Box 4a must show Implement PCA.For extension requests, box 4a must show Delay/Extend PCA.For milestone status updates, box 4a must show Milestone PCA Status Update. Ensure the effective date accurately reflects when the specific action was completed. Does the effective date reflect when the last action was completed?Is there evidence to support the effective date?Does the effective date occur prior to the approving official signature in 10d?Reason for DelayFor PCA extensions, complete box 4c.This field should agree to the JAMES field for “Most Recent Due Date Change Reason”.This field should agree to the JAMES field for “Most Recent Due Date Change Reason”.Box 5Enter the recommendation language verbatim from the Final Report.Box 6Enter the corrective action language verbatim from the Management Response within the Final Report.

[Please click here for the text description of the image.](https://www.irs.gov/media/333451 "")

![This is an Image: 69176011.gif](https://www.irs.gov/pub/xml_bc/69176011.gif)

> Box 7Write specific action taken in correct tense (remember to consider who, what, when, where why and how).List events in chronological order.Ensure the specific action taken accurately addresses the recommendation and PCA. Do not include names of employees, use titles if necessary. Provide an explanation if the executive sign off is more than 60 days from the effective date.List documentation uploaded to JAMES using a descriptive name, using the actual title of the document and PCA number and date (for ex. F13872 PCA 2-1-1\_03282022). If a document cannot be uploaded to JAMES due to Personally Identifiable Information (PII), Sensitive But Unclassified (SBU) data or Federal Tax Information (FTI), please include the phrase Contains PII store on EAM Secured Share Drive.Indicate which document supports the effective date.For status updates: Does the BU describe the actions taken thus far to implement the PCA, what actions remain and is the BU still on track to implement by the due date?Ensure monetary benefits are addressed, if applicable. A statement explaining actions taken to realize the amount must be included when the PCA is updated and noted on Form 13872. A thorough explanation as to how the monetary benefit calculation was obtained must be provided, even if the net results are less than what was originally agreed to and/or result in $0 dollars realized.Check for spelling and grammatical errors.Box 8Double check approving manager sign off Obtain signature of manager responsible for implementing PCA (Item 8a – 8e). Please note: the approving manager must sign before the executive.All officials using an electronic signature must ensure date signed field matches signature date. Please note at this time SEIDs are currently allowed in the signature box. The responsible manager and executive cannot be the same. Duplicate signatures will not be accepted. Signoff dates should not be BEFORE the implementation date.Acting officials should include appropriate designation document with the supporting documentation such as Designation Authority, F10247, email, or a screen print from the IRS Executive Directory.Box 9Double check JAMES Coordinator (JAC) sign off Enter JAC signature, title, and date (Item 9a – 9d).All officials using an electronic signature must ensure date signed field matches signature date. Please note at this time SEIDs are currently allowed in the signature box. The responsible manager and executive cannot be the same. Duplicate signatures will not be accepted. Signoff dates should not be BEFORE the implementation date.

[Please click here for the text description of the image.](https://www.irs.gov/media/333456 "")

![This is an Image: 69176012.gif](https://www.irs.gov/pub/xml_bc/69176012.gif)

> Box 10Double check approving executive sign off Obtain executive signature, title, and date (Item 10a - 10d).All officials using an electronic signature must ensure date signed field matches signature date. Please note at this time SEIDs are currently allowed in the signature box. The responsible manager and executive cannot be the same. Duplicate signatures will not be accepted.Signoff dates should not be BEFORE the implementation date.Acting officials should include appropriate designation document with the supporting documentation such as Designation Authority, F10247, email, or a screen print from the IRS Executive Directory.Box 11Checkbox Signatories of this form should: Attest the supporting documentation does not include PII, FTI or SBU.Confirm with program owner prior to submitting to JAMES that the documentation contains none of the above sensitive information.Supporting documentationThings to Remember:Ensure evidentiary documentation supports the effective date listed on the F13872.Upload F13872 and PCA supporting documentation in JAMES. Be sure to delete any files uploaded in error.Do not include PII, SBU, and FTI in the supporting documentation.Ensure all SEIDs, are redacted from evidentiary documentation. SEIDs are allowed in the signature box.Any documentation that includes PII, SBU, and FTI should be stored outside of JAMES. Contact EAM using the \*Audit Coordination or Audit.Coordination@IRS.gov to have documentation stored on a secured shared drive. Ensure email is marked secured and include the associated PCA number in the subject line.PCA documentation: sufficient to persuade a disinterested third-party person that the corrective action was successfully implemented.PCA documentation: Relevant. Valid. Reliable. (Yellow Book GAO-12-331G). Support Documentation Decision Table. F13872 – (current version)Form 13872 (Rev. 7-2020) (irs.gov)

[Please click here for the text description of the image.](https://www.irs.gov/media/333461 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-029-001#addtoany "Show all")

A2A