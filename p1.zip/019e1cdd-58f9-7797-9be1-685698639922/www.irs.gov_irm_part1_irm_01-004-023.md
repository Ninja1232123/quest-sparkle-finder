---
url: "https://www.irs.gov/irm/part1/irm_01-004-023"
title: "1.4.23 FUTA Manager and Coordinator Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-023#main-content)

- 1.4.23  [FUTA Manager and Coordinator Guide](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055594320)
  - 1.4.23.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083727024)
    - 1.4.23.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083721792)
      - 1.4.23.1.1.1  [Authority](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083467920)
      - 1.4.23.1.1.2  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083466224)
      - 1.4.23.1.1.3  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055652672)
      - 1.4.23.1.1.4  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055650816)
      - 1.4.23.1.1.5  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055649152)
      - 1.4.23.1.1.6  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055588864)
    - 1.4.23.1.2  [Federal Unemployment Tax Act (FUTA) Research](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055585904)
    - 1.4.23.1.3  [FUTA IATS](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055579808)
    - 1.4.23.1.4  [FUTA Case Processing System (FCP)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055576864)
      - 1.4.23.1.4.1  [Contents References Introduction Objective Nightly Run Setup (CRON)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055572688)
      - 1.4.23.1.4.2  [Printing Process](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055568496)
      - 1.4.23.1.4.3  [Systemic Problem Reporting](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055634992)
      - 1.4.23.1.4.4  [System Authorization and Security](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055622784)
    - 1.4.23.1.5  [FUTA Certification Program Workflow & Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055876016)
    - 1.4.23.1.6  [Work Planning and Control](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083760032)
      - 1.4.23.1.6.1  [Program Completion Date (PCD)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083758336)
      - 1.4.23.1.6.2  [Monitoring FUTA Reports -Site Coordinator/Coordinator/Manager](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056608992)
      - 1.4.23.1.6.3  [Reviewing the CCA 42-43 - IDRS Overage Report](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056600832)
      - 1.4.23.1.6.4  [Organization, Function and Program Codes (OFP) - Site Coordinator](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056669344)
    - 1.4.23.1.7  [FCP Site Coordinator](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055540896)
      - 1.4.23.1.7.1  [EDIT Option](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056732816)
        - 1.4.23.1.7.1.1  [Application Sites](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056726768)
        - 1.4.23.1.7.1.2  [Release Variables (FUTA)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056708608)
      - 1.4.23.1.7.2  [User Profiles](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056652048)
        - 1.4.23.1.7.2.1  [Add New User](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056153200)
        - 1.4.23.1.7.2.2  [Delete User](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056142688)
        - 1.4.23.1.7.2.3  [Edit a User’s Account](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056130208)
        - 1.4.23.1.7.2.4  [Change Password](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056118144)
        - 1.4.23.1.7.2.5  [Unlock Account](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056100384)
      - 1.4.23.1.7.3  [FUTA Batching](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083710992)
        - 1.4.23.1.7.3.1  [Assign Batch(es)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083707424)
        - 1.4.23.1.7.3.2  [Reassign Batch(es)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083688944)
        - 1.4.23.1.7.3.3  [Unassign Batch(es)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083669472)
      - 1.4.23.1.7.4  [Inventory Management - Site Coordinator/Coordinator/Manager](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083649952)
        - 1.4.23.1.7.4.1  [Statute Verification](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083504720)
        - 1.4.23.1.7.4.2  [DUP DLN](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083502416)
        - 1.4.23.1.7.4.3  [DUP EIN](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083499424)
        - 1.4.23.1.7.4.4  [Zero Certification](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083496432)
        - 1.4.23.1.7.4.5  [Potential Adjustment Registers (PARS)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083628944)
        - 1.4.23.1.7.4.6  [Mass generation of 4010C and 4011C Letters](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083605248)
        - 1.4.23.1.7.4.7  [California Unity of Enterprise (CAUE) North Carolina Unity of Enterprise (NCUE) Registers](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557083585056)
    - 1.4.23.1.8  [Miscellaneous Coordinator Roles](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056038416)
      - 1.4.23.1.8.1  [Disaster Coordinator](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056035008)
        - 1.4.23.1.8.1.1  [Add New Disaster](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056023184)
        - 1.4.23.1.8.1.2  [Delete Disaster Area Information](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056012736)
        - 1.4.23.1.8.1.3  [Edit Disaster Information](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557056000624)
      - 1.4.23.1.8.2  [Form 3870 Coordinator](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055965136)
      - 1.4.23.1.8.3  [Statute of Limitations - Manager/Statute Coordinator Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055960448)
        - 1.4.23.1.8.3.1  [Confirmation of Prompt Assessments - Statute Coordinator](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055946928)
      - 1.4.23.1.8.4  [Large Corporation/Large Dollar Screening- Local Large Corporation Coordinator Instructions](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055939568)
      - 1.4.23.1.8.5  [Training Coordinator](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055926208)
      - 1.4.23.1.8.6  [Identifying Trends - Site Coordinator](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055912496)
      - 1.4.23.1.8.7  [Policy Statement P-21-3 Site Coordinator/Managers](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055910096)
      - 1.4.23.1.8.8  [Discovered Remittances](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055907264)
    - 1.4.23.1.9  [Taxpayer Advocate Service (TAS)](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055528944)
      - 1.4.23.1.9.1  [TAS Coordinator Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055521360)
    - 1.4.23.1.10  [FUTA Reviews - Overview](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055515008)
      - 1.4.23.1.10.1  [Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055507568)
      - 1.4.23.1.10.2  [Inventory Management Reviews](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055503472)
      - 1.4.23.1.10.3  [Clerical Reviews](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055494752)
      - 1.4.23.1.10.4  [On-The-Job Reviews](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055489744)
      - 1.4.23.1.10.5  [Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055484720)
    - 1.4.23.1.11  [Program Reviews](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055477424)
    - 1.4.23.1.12  [Physical Inventory Reviews](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055473280)
  - Exhibit  1.4.23-1  [Closed Status Codes](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055464240)
  - Exhibit  1.4.23-2  [Profile Descriptions](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055421520)
  - Exhibit  1.4.23-3  [Download, Inventory Reports, Output Printed and Non-Printed Registers](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055402112)
  - Exhibit  1.4.23-4  [Physical Inventory Certificate](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055841856)
  - Exhibit  1.4.23-5  [Wall Inventory Instruction and Certification](https://www.irs.gov/irm/part1/irm_01-004-023#idm140557055809840)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 23. FUTA Manager and Coordinator Guide

* * *

## 1.4.23 FUTA Manager and Coordinator Guide

#### Manual Transmittal

October 09, 2024

#### Purpose

(1) This transmits revised IRM 1.4.23, Resource Guide for Managers, Federal Unemployment Tax Act Manager and Coordinator Guide.

#### Material Changes

(1) IRM 1.4.23.1 Program Scope and Objectives: Revised section for clarity.

(2) IRM 1.4.23.1.1.3 Program Management and Review: Added a new subsection.

(3) IRM 1.4.23.1.1.5 Acronyms: Added additional acronyms to the table.

(4) IRM 1.4.23.1.2 Federal Unemployment Tax Act (FUTA) Research: Revised the subsection title. Updated the SERP link in paragraph (3). Updated the link for the BMF Doc Matching SharePoint site.

(5) IRM 1.4.23.1.3 FUTA IATS: Revised section for clarity.

(6) IRM 1.4.23.1.4 FUTA Case Processing System (FCP): Updated paragraph (1) for clarity. Updated FUTA Release Years in paragraph (2).

(7) IRM 1.4.23.1.4.2 Hot Keys: Section deleted. Hot Keys are no longer applicable due to the implementation of new FCP screens. All remaining IRM sections have been renumbered.

(8) IRM 1.4.23.1.4.5 System Authorization and Security: Revised paragraphs (2), (3) and (8) for clarity.

(9) IRM 1.4.23.1.5 FUTA Certification Program Workflow & Responsibilities: Revised paragraph (4) for clarity.

(10) IRM 1.4.23.1.6.1 Program Completion Date (PCD): Revised paragraphs (1) and (3) for clarity. Updated the table in paragraph (5).

(11) IRM 1.4.23.1.6.3 Reviewing the CCA 42-43 - IDRS Overage Report: Revised paragraphs (4) and (5) for clarity.

(12) IRM 1.4.23.1.6.4 Organization, Function and Program Codes (OFP) - Site Coordinator: Revised the Note in paragraph (3) for clarity. Revised paragraph (4) for clarity.

(13) IRM 1.4.23.1.7 FCP Site Coordinator: Revised paragraph (1) for clarity.

(14) IRM 1.4.23.1.7.1.1 Application Sites: Revised section for clarity and added a table to paragraph (4).

(15) IRM 1.4.23.1.7.2 User Profiles: Revised section for clarity and added a table in paragraph (5).

(16) IRM 1.4.23.1.7.2.4 Change Password: Created a new subsection.

(17) IRM 1.4.23.1.7.2.4 Unlock Account: Created a new subsection.

(18) IRM 1.4.23.1.7.4 Inventory Management -Site Coordinator/Coordinator/Manager: Updated paragraph (1) for clarity.

(19) IRM 1.4.23.1.7.4.2 DUP DLN: Updated IRM reference in paragraph (2).

(20) IRM 1.4.23.1.7.4.4 Zero Certification: Updated IRM reference in paragraph (5).

(21) IRM 1.4.23.1.7.4.6 Mass Generation of 4010C and 4011C Letters: Updated the IRM reference in paragraph (1).

(22) IRM 1.4.23.1.8.1 Disaster Coordinator: Added new paragraph (5).

(23) IRM 1.4.23.1.8.3 Statute of Limitations - Manager/Statute Coordinator Responsibilities: Revised the Note in paragraph (3) for clarity.

(24) IRM 1.4.23.1.8.3.1 Confirmation of Prompt Assessments - Statute Coordinator: Revised paragraph (1) for clarity.

(25) IRM 1.4.23.1.8.4 Large Corporation/Large Dollar Screening - Local Large Corporation Coordinator Instructions: Updated IRM reference and the SERP link in paragraph (2) step list. Updated IRM reference in paragraph (3), note and reminder.

(26) IRM 1.4.23.1.8.5 Training Coordinator: Revised paragraph (1) for clarity.

(27) IRM 1.4.23.1.9 Taxpayer Advocate Service (TAS): Updated IRM reference in paragraph (4).

(28) IRM 1.4.23.1.10.1 Workload Reviews: Revised paragraph (3) for clarity.

(29) IRM 1.4.23.1.11 Program Reviews: Revised paragraph (1) for clarity.

(30) IRM 1.4.23.1.12 Physical Inventory Reviews: Updated IRM reference in paragraph (1).

(31) Editorial changes (spelling, grammar, etc.) and annual updates have been made throughout the IRM.

#### Effect on Other Documents

This material supersedes IRM 1.4.23 dated October 16, 2023.

#### Audience

FUTA Managers and Coordinators at the Small Business/Self-Employed sites.

#### Effective Date

(10-09-2024)

Heather J Yocum

Director, Exam Field and Campus Policy

Small Business/Self-Employed

**1.4.23.1** **(10-09-2024)**

### Program Scope and Objectives

1. **Purpose:** This manual provides procedures for managers and coordinators in the Small Business/Self Employed (SB/SE) Document Matching Federal Unemployment Tax Act (FUTA) Operation.

2. **Audience**: The primary users of this IRM are SB/SE Managers and Coordinators in the FUTA operation.

3. **Policy Owner**: Director, Exam Field and Campus Policy.

4. **Program Owner**: SB/SE BMF Document Matching.

5. **Primary Stakeholder**: SB/SE FUTA Operation employees.


**1.4.23.1.1** **(09-28-2022)**

#### Background

1. This guide provides instructions for FUTA Managers and Coordinators to control the flow of work, perform managerial reviews, and to monitor and generate reports for inventory management.

2. The Federal Unemployment Tax Act (FUTA) provides for cooperation between state and federal governments in the establishment and administration of unemployment insurance. Under this dual system, the employer is subject to a payroll tax levied by the federal and state government. The taxpayer is allowed a maximum credit of 5.4 percent against the Federal tax of 6.0 percent, provided that all payments were made to the state by the due date. Employers whose payments are received by the state after the due date are allowed 90 percent of the credit that would have been allowed had the payments been made on time. As a result of FUTA, IRS is responsible for receiving and processing the Form 940 and/or Schedule H. All revenue that is associated with these tax returns is turned over to the Department of Labor (DOL). DOL is responsible for dispensing the revenue deposited in the FUTA Trust Fund. DOL is charged with monitoring the Unemployment Insurance Systems for each state and can withhold funds from a state if the state does not comply with Federal standards. FUTA certification is the method used to verify that Form 940 amounts were actually paid into the states’ unemployment funds. There are currently 53 participating agencies which encompass the 50 states, the District of Columbia, Puerto Rico and the U.S. Virgin Islands.

3. The case types are classified into four categories and downloaded to the FUTA Case Processing (FCP) System.



1. Letter 4010-C, _Proposed Increase to FUTA Tax_

2. Letter 4011-C, _Proposed Decrease to FUTA Tax_

3. Potential Adjustment Record (PAR)- Manual review to determine which letter to issue to the employer or closure of the case.

4. Zero Certification- Records not certified by the states because there was no match on the EIN or no state wages and/or payments were made to the states.


**1.4.23.1.1.1** **(10-11-2017)**

##### Authority

1. The authority for the procedures of FUTA can be found under Title 26, Subtitle C, Chapter 23 of the Internal Revenue Code (Section 3301 through Section 3311).


**1.4.23.1.1.2** **(10-11-2017)**

##### Roles and Responsibilities

1. The Director, Small Business/Self-Employed (SB/SE), Field Exam and Campus Policy is responsible for the FUTA program.

2. Management officials are responsible for:



   - Providing internal controls relating to the program, process and activity.

   - Ensuring the instructions are communicated to and carried out by the proper officers and employees.


**1.4.23.1.1.3** **(10-09-2024)**

##### Program Management and Review

1. Headquarters plans to conduct program reviews on an as needed basis. The reviews will target recommendations made during prior visitations, adherence to the IRM and Policy directives, movement of inventory, manager and employee reviews and feedback and any areas of concern.


**1.4.23.1.1.4** **(10-11-2017)**

##### Program Controls

1. This program is monitored through the FUTA Case Processing System (FCP).


**1.4.23.1.1.5** **(10-09-2024)**

##### Acronyms

1. The table below is a list of acronyms with definitions:




| **Term** | **Definition** |
| --- | --- |
| ACS | Automated Collection System |
| ADJ | Adjustment |
| AIMS | Audit Inventory Management System |
| AMS | Account Management Services |
| ASED | Assessment Statute Expiration Date |
| BEARS | Business Entitlement Request System |
| BMF | Business Master File |
| BMFOL | Business Master File On-Line |
| CAF | Centralized Authorization File |
| CATRS | Consolidated Annual Tax Reporting System |
| CAUE | California Unity of Enterprise |
| CAWR | Combined Annual Wage Reporting |
| CC | Closing Code |
| CCA | Case Control Activity |
| CFOL | Corporate Files On-Line |
| CMLC | Career Management and Learning Center |
| CNC | Currently Not Collectible |
| CSR | Customer Service Representative |
| DOL | Department of Labor |
| ECC-MTB | Enterprise Computing Center- Martinsburg |
| EIN | Employer Identification Number |
| FCP | FUTA Case Processing |
| FIFO | First In/First Out |
| FTD | Federal Tax Deposit |
| FUTA | Federal Unemployment Tax Act |
| IAT | Integrated Automation Technologies |
| IDRS | Integrated Data Retrieval System |
| IMF | Individual Master File |
| IMFOL | Individual Master File On-Line |
| IRC | Internal Revenue Code |
| IRM | Internal Revenue Manual |
| LCTU | Large Corporation Technical Unit |
| MFT | Master File Tax |
| NCUE | North Carolina Unity of Enterprise |
| NLUN | Nullified Unpostable |
| OFP | Organization Function Program |
| PARS | Potential Adjustment Registers |
| PCD | Program Completion Date |
| POA | Power of Attorney |
| PRP | Programming Requirements Package |
| RAA | Reporting Agent Authorization |
| RSED | Refund Statute Expiration Date |
| SBSE | Small Business Self Employed |
| SDT | Secure Data Transfer |
| SSN | Social Security Number |
| TAS | Taxpayer Advocate Service |
| TBOR | Taxpayer Bill of Rights |
| TC | Transaction Code |
| TIN | Taxpayer Identification Number |
| WDC | Western Development Center |


**1.4.23.1.1.6** **(09-28-2022)**

##### Related Resources

1. IRM 4.19.5, Certification of State Federal Unemployment Tax Act

2. IRM 4.19.9, FCP (FUTA Case Processing) Technical System Procedures

3. IRM 4.19.23, FUTA Control

4. Other resources can include IRM 20.1, Penalty Handbook, IRM 20.2, Interest, IRM 21.5.5, Unpostables and IRM 21.5.7, Payment Tracer.


**1.4.23.1.2** **(10-09-2024)**

#### Federal Unemployment Tax Act (FUTA) Research

1. This IRM is to be used in conjunction with IRM 4.19.5, Certification of State FUTA Credits, IRM 4.19.9, FCP (FUTA Case Processing) Technical System Procedures, IRM 4.23.8, Determining Employment Tax Liability and IRM 4.19.23, FUTA Control.

2. All references to Coordinator within this document will be considered as FUTA Site Coordinators.

3. Servicewide Electronic Research Program (SERP):



   - Any changes made during the processing year will be posted on SERP. The most current revision of the IRM can be found ONLY on SERP, therefore all employees are encouraged to use the SERP version of the IRM to perform research necessary to close cases.

   - Both Quality Review and FUTA unit personnel must be aware of all the alerts that are applicable to the current FUTA Release Year.

   - Campuses need to check the SERP web site daily for a list of the most current and previous alerts.

   - If a campus is missing a specific alert(s) and needs a copy of it/them, refer to the SERP website: SERP (irs.gov)


4. Pub 4485, Guide for the Certification of State FUTA Credits, provides instructions used by state agencies participating in the FUTA Certification program. Changes are made annually or as modifications warrant a revision.

5. Additional information can be found on the CAWR/FUTA SharePoint site: BMF Doc Matching (sharepoint.com)


**1.4.23.1.3** **(10-09-2024)**

#### FUTA IATS

1. IATs were developed to increase productivity and accuracy rates. It is imperative that these tools be used daily by all employees. Please ensure all tools are working properly. See IRM 1.4.23.1.4.4 Systemic Problem Reporting for more information.

2. FUTA Clerical process has access to the IAT Document Matching (DM) Batcher Tool. The use of this tool is mandatory. The tool streamlines the clerical process by batching and controlling cases directly to IDRS, inputting STAUPS and issuing interim letters as needed.

3. A Job Aid is available for the IAT SBSE DM Batcher Tool by accessing the IAT SharePoint site: IAT


**1.4.23.1.4** **(10-09-2024)**

#### FUTA Case Processing System (FCP)

1. Cases determined to have discrepancies are loaded onto the**FCP** system located on the CATRS platform. For more information on the FCP system, See IRM 4.19.9, FCP (FUTA Case Processing) Technical System Procedures.

2. Download to the FCP system will be identified by FUTA Release Year. In October 2024 the download will be identified as FUTA Release 2022



### Note:



The download can include prior tax years.

3. The FCP System is a computer application that houses the FUTA inventory, correspondence, reports and document preparation.


**1.4.23.1.4.1** **(10-01-2012)**

##### Contents References Introduction Objective Nightly Run Setup (CRON)

1. **CRON** is a process where the system automatically generates all output files during off work hours. This is referred to as the "Nightly Run Setup" . CRON Run Dates will be established by Headquarters Staff for all Campuses. CRON automatically executes programs during the dates and the time specified for each job. CRON generates reports the Coordinator can access by selecting **View** on the Menu Bar. Cases will be assigned automatically to IDRS where correspondence has been issued or the cases have been assigned on the FCP System.



### Note:



Any changes to the CRON Processing will be a Headquarters Directive.


**1.4.23.1.4.2** **(10-01-2012)**

##### Printing Process

1. There are two different print processes for the FCP System:



1. **Laser Print**: The printing and the mailing of letters will be handled by the Ogden Print Site (OPS).

2. **Manual Print**: Reports, Listings and No Reply Source Documents will be printed manually at each campus.



      ### Note:



      The Letter 4010-C and Letter 4011-C will go out with the return address of the originating campus on them. If there is a remittance with a return notice, then the notice and the remittance will be routed to the appropriate Accounting Function. There is also a Campus Code on the letters that can be used for sorting and for transshipping if the letters and envelope should become separated.


**1.4.23.1.4.3** **(10-16-2023)**

##### Systemic Problem Reporting

1. When an FCP System problem is identified during FUTA processing, the campus TE/clerk who identified the problem will issue an IT Get It ticket.

2. Before issuing a ticket, contact a Headquarters Analyst for approval.

3. To issue a "Get It ticket" , the user will do the following:



1. Access IRweb Homepage - click on **IRS Service Central**

2. Select **New Tickets**

3. Click on **Request Help**

4. Choose **All IRS APPS**

5. Click on **Submit** to create ticket

6. Complete the form, providing an explanation of the problem. Add the statement **Forward this ticket to AD-COMP-RC-CD-CAWR/FUTA**for FCP issues and **BU-WI-WIOS-MTT-IAT**for IAT issues. Attach any documentation or if you are faxing it notate in the remarks field you will be faxing supporting documentation.

7. Click on **Submit**

8. A Get It ticket number will be issued


4. Whenever a systemic problem is identified, the tax examiner/Clerk will compile documentation (description of the problem and samples) and give the information to the Site Coordinator who will inform the Headquarters FUTA analyst of the problem and forward the documentation.


**1.4.23.1.4.4** **(10-09-2024)**

##### System Authorization and Security

1. Access to FUTA on the CATRS System is restricted to _authorized users_. The FUTA Site Coordinator, appropriate management official and security personnel must authorize individual user access.

2. Access to the CATRS System requires a login and password for both Windows 11 and the CATRS System. An Automated _BEARS (Formally called Online 5081)_ Application is required to gain access to the CATRS System if they are a New User, to Set User Active, to Set User Inactive, to Delete User or to Reset User Password.

3. The Site Coordinator must have **BEARS SYSTEM ADMINISTRATOR**access to receive and process the BEARS application.

4. A security profile is established and maintained for each user.

5. User profiles are established to allow users access to the specific area/functions of the CATRS system needed to perform assigned duties. Users must inform their manager/coordinator if they are prohibited from accessing an area of the CATRS system needed to complete an assigned task. See_Exhibit 1.4.23-2_ for User Profile Descriptions.

6. The CATRS system produces audit trail information on any updates/changes to the system. Each user must ensure only authorized accesses are performed. Do not attempt unauthorized system queries.

7. To ensure the security and integrity of the CATRS system the user must:



01. Protect their password and not reveal it to anyone.

02. Never allow anyone access to the system using your login and password.

03. Alert the manager immediately if there is reason to believe the password has been compromised.

04. Lock workstation when it is not in use.

05. Log off the system at the end of your shift.

06. Never leave sensitive information on the screen when leaving your workstation.

07. Never eat or drink near computer hardware.

08. Use computers and software for official purposes only.

09. Never copy licensed or copyrighted software for private use. It is a violation of federal law with civil and criminal penalties.

10. Promptly retrieve hard copy prints from the printer. Prints remaining near or on the printer for an extended period of time should be given to managers for disposition.


8. To ensure the security and integrity of the CATRS system the coordinator must, on a quarterly basis:



1. Compare the BEARS access listing to the CATRS database to ensure they match.

2. Verify that users have the correct permission levels.

3. Make any applicable changes and send a confirmation email to the HQ policy analyst on the first Monday after the end of each quarter.


9. Once the BEARS has been approved and the Local Site Coordinator adds the user to FCP User Profile Table, the BEARS request is automatically forwarded to the network SA to add the user to the "CAWRFUTA\_USERS" DS Domain Group. Users will not have visibility to the screens until they have been added by the domain group. For further information contact HQ.


**1.4.23.1.5** **(10-09-2024)**

#### FUTA Certification Program Workflow & Responsibilities

1. The FUTA Identification data is extracted from the Business Master File (BMF) annually in September (Cycle 39). The file contains FUTA data (from Forms 940 and Schedule H) posted to the BMF and Individual Master File (IMF) subsequent to the last extract for tax year beginning 1999 through current year.

2. The FUTA Identification data for the state agencies are transmitted directly to the states in October via Secure Data Transmission (SDT). The addresses for the state agencies are shown in Exhibit 6 of Pub 4485, Guide for the Certification of State FUTA Credits.

3. State agencies are required to complete and return their FUTA Certification transmission data by January 31 of each year to the Enterprise Computing Center - Martinsburg (ECC-MTB) via SDT.

4. Enterprise Computing Center - Martinsburg (ECC-MTB) Staff-ECC-MTB will:



1. Notify SB/SE Headquarters FUTA staff of the states that have not furnished their Certification Data by the time designated in Pub 4485, Guide for the Certification of State FUTA Credits and elsewhere in this manual.

2. Provide input during the annual revision of Pub 4485.

3. Notify SB/SE Headquarters FUTA staff of the state data that cannot be processed because of incorrect format, invalid data, transmission filenames are incorrect, and etc. SB/SE Headquarters FUTA staff or IRS SDT Help Desk will provide the reason(s) to the appropriate IRS Governmental Liaison staff and state agency. The state agency will receive an e-mail verifying the receipt of the data.

4. Provide a statement or example of the problem when the data is returned to the state. Coordinate with SB/SE Headquarters FUTA staff for scheduled running times when the normal deadlines are not met.

5. Provide Headquarters FUTA staff with the reports as stated in Programming Requirements Package (PRP) 180 Section 23. The table below describes the reports and when they are generated:




      | **REPORTS** |
      | --- |
      | \*Fiscal Year Ending FUTA Case Processing report generated in October/November. |
      | \*Fiscal Year Ending FUTA Recons (previously called Late Reply) report generated in October/November. |
      | \*FUTA Late Reply report in February. |
      | \*FUTA Case Processing report in July. |

6. Coordinate with affected areas when programming changes are requested via a Work Request from Headquarters FUTA staff.

7. Notify Headquarters FUTA staff when the data is shipped to SB/SE campuses for the startup of the new processing year.

8. Provide assistance and maintain the programming to the FUTA mainframe processing.

9. Revise/update the FUTA Program Requirements Package (PRP).


5. The Headquarters FUTA Staff responsibilities are as follows:



1. Provide assistance/guidance to the SB/SE campuses.

2. Updates IRM 4.19.5, Certification of State FUTA Credits, IRM 4.19.23, FUTA Control, IRM 4.19.9, FCP (FUTA Case Processing) Technical System Procedures, FUTA Training Material and Pub 4485, Guide for the Certification of State FUTA Credits.

3. Provide the download volume information to Western Development Center (WDC) from Report 180–79–12, FCP System Reformat Controls, generated from the Enterprise Computing Center-Martinsburg (ECC-MTB).

4. Coordinate with ECC-MTB and WDC when developing a Work Request.

5. Coordinate with ECC-MTB and WDC walk through of the FUTA Program Requirements Package (PRP) and Functional Specification Package (FSP).


6. Western Development Center Staff (WDC) responsibilities:



1. Provide assistance and maintain the programming to the FUTA FCP System.

2. Provide assistance to the Headquarters FUTA staff in updating the training material, using the FCP System and addressing issues involving the FCP System.

3. Coordinate with affected areas when programming changes are requested via a Work Request from Headquarters FUTA staff.

4. Notify FUTA Headquarters staff when the new processing year data has been downloaded to the FCP System.

5. Revise/update the FUTA Function Specification Package (FSP).


7. All discrepancy cases should be completed before cases for the next processing year are received. Although a particular state may be late in transmitting their discrepancy data one year, emphasis should still be placed on completing the discrepancy cases if next year's output is expected to be timely.


**1.4.23.1.6** **(09-23-2016)**

#### Work Planning and Control

1. The following describes the steps needed to successfully manage the FUTA program.


**1.4.23.1.6.1** **(10-09-2024)**

##### Program Completion Date (PCD)

1. The FUTA program processing start up for all SB/SE campuses is scheduled for October and the PCD is the last day of September each year, unless otherwise directed by SB/SE Headquarters FUTA staff.

2. This requirement will be considered met if 95 percent of the workable download volume of cases are closed by the August 31 PCD. The remaining 5 percent of the inventory must be completed by September 30. This includes working the No Reply listings on a weekly basis and making any necessary tax adjustments.

3. If the campus is unable to complete processing by PCD, the Coordinator will notify SB/SE Headquarters FUTA staff and request an extension. The request is to be sent 60 days prior to PCD and should include the following:



1. Reason for an extension.

2. Date processing will be completed.

3. Volume of remaining cases.


4. SB/SE Headquarters Document Matching staff will issue a formal response on the request for an extension.

5. The table below provides the schedule for current and subsequent FUTA Certification program case processing.




| **Program Release Year** | **HUB Test of the New Programs at One SB/SE Campus** | **Program Start-up Date for the SB/SE CSC Campus** | **Program Completion Date** |
| :-: | :-: | :-: | :-: |
| 2022 | October 1, 2024 | October 7, 2024 | September 30, 2025 |
| 2023 | October 1, 2025 | October 6, 2025 | September 30, 2026 |


**1.4.23.1.6.2** **(10-16-2023)**

##### Monitoring FUTA Reports -Site Coordinator/Coordinator/Manager

1. The FUTA reports serve two distinct purposes:



1. Provide reports to aid in the flow of work assigned to users.

2. Provide managers, Site Coordinator and HQ with information to be used in the coordination and monitoring of the FUTA inventory.



      ### Note:



      See Exhibit 1.4.23-3 for a list of Reports and Descriptions.


2. The FUTA reports are generated weekly on the Business Objects Enterprise (BOE). Until all cases are closed, or up to one year after the PCD, the reports should reflect any changes to the volumes previously reported.



### Note:



A BEARS request is required to gain access to the BOE.

3. Managers/Coordinators at each site must monitor these reports to ensure the program is meeting the**Completion**and**Benchmark dates.**

4. The reports are generated with information for all sites. If a report or a portion of a report (information from one site) needs to be printed, the user will need to copy and paste the specific information onto a Word Document to print.

5. The FUTA Reports have a three month retention time frame. The time is determined by using the date the report was created plus two months. The Retention date is displayed on the reports main menu.


**1.4.23.1.6.3** **(10-09-2024)**

##### Reviewing the CCA 42-43 - IDRS Overage Report

1. This report contains all cases controlled to an IDRS employee number and needs to be reviewed weekly to:



   - Identify cases that require action.

   - Identify specific cases for review.

   - Monitor the size of the employees' inventories.

   - Determine if employees are working inventory in the proper order.

   - Set closure expectations.

   - Identify potential management problem cases.

   - Monitor for the prevention of premature STAUP/TC 470.


2. This report is available on Control-D every Monday morning, Report Name: "Overage Report" , Job Name: CCA 4243D

3. Items on the Report - The table below describes the item name and definition on the report:




| **Item Name** | **Definition** |
| --- | --- |
| TIN | Taxpayer Identification Number |
| IRS Rcd Date | The date IRS received the case |
| Status | Case History Status Code (A - Active, B - Background, C - Closed, M - Other long term delay, and S - Suspense) |
| BOD | Business Operating Division |
| Category | Category of the case |
| Freeze Codes | Freeze Codes that are on the IDRS account |
| MFT | Master File Tax |
| Mod Per | Tax Period on assigned account |
| Assigd Date | The date the case was assigned to a tax examiner |
| Activity Code | A 10 character field on IDRS that the tax examiner uses to enter actions taken on the case |
| Name Ctrl | Name Control on taxpayer’s account |
| Action Date | Date of last action input on the account |
| Age | Number of days the case has aged on IDRS |
| MF Mod Balance | Module Balance on IDRS |
| Stat Age | Indicates statute conditions for current and previous years returns - over, expired, or days remaining on statute |
| STAUP Cycle | Stops notices from generating until cycle listed |
| C Letter and Date | Date and type of CRX letter sent |

4. The Manager/Lead must review this report to ensure cases are being worked in **First In First Out (FIFO)** order, this can be done by sorting the report by IRS received date. Annotate cases for follow-up actions by COB Monday. The reports should be maintained for two months. Highlight the cases on the report where:



   - The TE has failed to take timely actions such as follow-up on a case when the purge date has passed.

   - The case is in Nullified Unpostable (NLUN) category over 14 days old.

   - The Statute of Limitations will expire within 180 days.

   - The STAUP has expired or there is no STAUP on a balance due account.

   - Oldest aged cases not being worked in FIFO order.


5. Manager/Lead will provide the tax examiner with either the printed or electronic pages of their weekly report containing all the cases controlled to their IDRS number. Tax examiner will notate the actions taken on each case worked. Annotations should include C - Closed, U - Update, or S - STAUP input. The report should be signed and returned to the Manager/Lead by close of business Friday. The tax examiner should work cases in the following priority order:



   - NLUN category cases.

   - The statute will expire within 180 days.

   - Taxpayer was contacted and purge date has passed.

   - Remaining cases in oldest receive date order.


**1.4.23.1.6.4** **(10-09-2024)**

##### Organization, Function and Program Codes (OFP) - Site Coordinator

1. Organization, Function and Program (OFP) codes are recorded on Form 3081, "Employee Time Report" to identify work that employees perform daily.

2. It is the responsibility of the Coordinator to provide the Reports area with the current OFP codes that will be used at the beginning of each new download. Take the following steps, **four** weeks prior to the new download to ensure the OFP codes are activated and ready to be input on the 3081. See IRM 3.30.50.3, **OFP Consistency File and Reports**for additional information.



1. Prepare a list of all of the OFP codes identifying the new tax year being worked by replacing the "X" with the tax year.

2. E-mail the list to the Reports area to update the OFP Consistency File. Ensure all prior year codes no longer needed are deleted.

3. Once the OFP codes have been established, e-mail the new OFP codes to the managers to be used with the new download processes. Ensure employees begin using the new OFPs effective October 1 after the download is received.

4. Verify all changes were made to the OFP Consistency File (including deletions of prior year codes) by reviewing the Operation WP&C Report. Take necessary actions if needed.


3. All OFP codes for FUTA TEs and Clerks are listed in the tables below:



### Note:



The "X" in the program codes 170X0 through 175X0 will reflect the current Release year being worked (i.e., 170**2**0-174**2**0). Program code 175X0 can reflect the current and prior Release years (i.e., 175**2**0 or 175**1**0 or 175**0**0) depending on the Release year of the case.





1. The table below describes FUTA OFP codes for tax examiners use:




      | **OFP** | **Definition** |
      | :-: | :-: |
      | 700 - 172X0 | FUTA Telephone Replies |
      | 700 - 175X0 | FUTA Telephone Recons (previously called Late Replies) and Prior Year |
      | 710 - 170X0 | FUTA Screening |
      | 710 - 172X0 | FUTA Replies |
      | 710 - 173X0 | FUTA Undeliverables |
      | 710 - 174X0 | FUTA No Replies |
      | 710 - 175X0 | FUTA Recons (previously called Late Replies) and Prior Years |

2. The table below describes FUTA OFP codes for Clerks use:




      | **OFP** | **Definition** |
      | --- | --- |
      | 790 - 172X0 | Screening/Replies |
      | 790 - 175X0 | Recons (previously called Late Replies) and Prior Years |


**1.4.23.1.7** **(10-09-2024)**

#### FCP Site Coordinator

1. The Small Business/Self Employed (SB/SE) campus' FUTA Site Coordinator is the liaison between SB/SE Headquarters FUTA staff, state manual certification staff and the campus FUTA staff. The Site Coordinator can be from the campus' Planning and Analysis staff or someone in the FUTA unit. The campus needs to provide Headquarter's staff with the name and phone number of who will be fulfilling these responsibilities.**The SB/SE campus' FUTA Site Coordinator's responsibilities include the following:**



01. Coordinate the bulk requests for re-certification before the original letters (4010C or 4011C) are mailed.

02. Coordinate Zero certification request mail release dates with the states. The state contact names and addresses can be found on SERP, (contact HQ analyst to update SERP immediately when a state corrects any names or addresses), click on the Who/Where tab, click on State Labor Department Form 940 Certification Contacts then follow instructions.

03. Communicate with the state agencies on any other problems which arise.



       ### Note:



       In addition, the more complex or unusual items which must be coordinated with state agencies should be resolved by the SB/SE campus' FUTA Coordinator.

04. Notify the SB/SE Headquarters FUTA staff of problems with the FUTA Certification Program. SB/SE Headquarter's FUTA staff will contact the appropriate programming staff for resolution of these problems.

05. Manage User Accounts and Profiles

06. FUTA Batching - Assign, Reassign, Unassign

07. Reports - Monitor

08. Disaster Areas

09. Monitoring Workable Inventory

10. Mass Requests (Letters, Printed Registers and Non-Printed Registers)



       ### Note:



       It is recommended keeping all "FUTA Mass Requests" for letters at or below a volume of 500 per each request because of the time it takes for generation. Multiple requests can be made as long as the generation completed successfully for each request. Example: A request of 2000 letters would be four requests of 500 each.


2. As a Site Coordinator, you may give designated employees (Manager or Lead) specific Coordinator profiles to manage and oversee Disaster Coordinator duties.

3. Manager(s) will need a Coordinator profile to access reports that are designated for a Coordinator profile only. These reports are useful for monitoring employee inventory.

4. The Site Coordinator/Coordinator responsibilities will be covered in the following sections.


**1.4.23.1.7.1** **(10-16-2023)**

##### EDIT Option

1. The Site Coordinator has the ability to edit, view, update, request, or batch cases on the CATRS system using the **Edit** option.

2. Select one of the following options:



1. Edit - Function displaying a list of options to choose from.

2. Coordinator - Access to Application Sites, Batch Management, Mass Requests and Release Variables.

3. User Profiles - Add User, Update Users, Delete Users.

4. Disaster Areas - Update Disaster information.

5. Batch Management - Assign, Reassign and Unassign batches.

6. Mass Request - Letter 4010C, Letter 4011C and ZERO Certs.


**1.4.23.1.7.1.1** **(10-09-2024)**

###### Application Sites

1. The .Application Sites option will allow a Site Coordinator to view and/or update information specific to their site. Information for all sites will also be available to view.

2. To update or view the Application Site information:



1. Select your **Active Role** as Coordinator for your site.

2. Click **Edit**from the menu bar.

3. Select **Coordinator**.

4. Select **Application Site**.

5. Verify Application Site screen.


3. The Site Coordinator for each site needs to ensure the information displayed on the Application Information Screen for their site is correct each year prior to program start up. Any updates/changes will be completed by the FCP system programmers.

4. The Application Information Screen displays the following:




| **Information Screen Column Headers** |
| --- |
| Program |
| Site Code |
| Site Abbreviation |
| Name |
| Street 1 |
| Street 2 |
| City (Replies) |
| State (Replies) |
| Zip (Replies) |
| Sig Code |
| RA Code |
| Created Date |
| Created By |
| Last Modified Date |
| Modified By |


**1.4.23.1.7.1.2** **(10-16-2023)**

###### Release Variables (FUTA)

1. The Release Variables (FUTA) screen is maintained by Headquarters. **Updates can only be done by the System Administrator located at the Tennessee Computing Center (TCC)**. Any changes will be a Headquarters Directive.

2. The Release Variables (FUTA) screen displays:



   - Program

   - Tax Year

   - Active Date

   - PCD

   - Modified By

   - Date and Time Modified


3. To view the information:



1. Select your **Active Role** as Coordinator for your site.

2. Click **Edit**

3. Select **Coordinator** from the drop down menu.

4. Select **Release Variables**

5. Verity Release Variables Screen.


**1.4.23.1.7.2** **(10-09-2024)**

##### User Profiles

1. The Site Coordinator is able to Add, Delete, Update, Unlock Users, Change Passwords, Grant Database (DB) Access, and Passwords on the FCP system.

2. The User Profile screen can be used to determine:



   - A valid user of the system at your campus and if the user is in Active or Inactive Status. (Furloughed or Terminated)

   - The Role assigned to the user.


3. Follow the table below to update user profiles through the BEARS system.:




| **REQUEST** | **REASON** | **INITIATE Action** | **COMPLETE Action** |
| :-: | :-: | :-: | :-: |
| Add New User | New employee | Manager | Site Coordinator |
| Delete User | Left FUTA Program | Manager | Site Coordinator |
| Reset User Password | Forgot Password | Manager | Site Coordinator |

4. To access the **User Profiles** screen:



1. Set your **Active Role** as Coordinator for your site.

2. Select **Edit** from the menu bar.

3. Select **User Profiles** from the drop down menu.


5. The "User Profile" screen displays the following:




| **User Profile Screen Column Headers** |
| --- |
| User ID |
| Post of Duty (POD) |
| Last Name |
| First Name |
| Status (Active or Inactive) |
| Full IDRS Number |
| Terminal Security Identification (TSID) |
| Created Date |
| Created By |
| Last Modified Date |
| User ID |


**1.4.23.1.7.2.1** **(10-16-2023)**

###### Add New User

1. The Site Coordinator adds new users to the FCP system. This process is site specific and is used for new hires into the FUTA program. Managers must submit a BEARS request to **Add a user to FCP**. Once you receive the BEARS, you can continue with the process of adding the user to the FCP system.

2. To Add a New User:.



1. Access the **User Profiles** screen.

2. Click the **New** tab. A Warning message will appear.

3. Click **OK** to continue. The **New User** window will appear.

4. Enter the user’s SEID. Once you input the SEID, the user’s First Name, Last Name and IDRS number will be systemically filled in.

5. Set the user’s role from the **"Default Role"** drop down menu.

6. After all the information is input, click **Save** to generate a password for the user.


**1.4.23.1.7.2.2** **(10-16-2023)**

###### Delete User

1. The Site Coordinator is able to delete users from FCP utilizing the User Profiles screen. This process is site specific and used when a user has left the IRS or reassigned to a position outside of FUTA.

2. Manager must submit a BEARS request to **Delete the user from FCP**. Once you have received the BEARS request you can continue the process of deleting the user.

3. To Delete a User:



1. Access the **User Profiles** screen.

2. Highlight the user’s name and select **Edit**.

3. Click the **Roles** tab.

4. Highlight the Role you want to delete and click the **Delete**button. Each Role must be deleted separately.

5. Click **Save**when finished.

6. Once the Roles are deleted, return to the User Profiles screen.

7. Ensure the user you want to delete is highlighted, then click the**Delete** button. A message will appear stating the user has been deleted.

8. Click **Close** to exit the screen.


**1.4.23.1.7.2.3** **(10-16-2023)**

###### Edit a User’s Account

1. The Site Coordinator has the ability to **Edit** the user’s account. This process is site specific and would be used to view or update the following:



   - Unlock User’s Account

   - Change Passwords

   - Add/Delete Roles

   - Grant Permissions (i.e. Disaster Coordinator)

   - See User Events (Login/Logout information)

   - View Profile Log


2. To edit a user’s account:



1. Access the**User Profiles** screen.

2. Highlight the user’s name you want to edit.

3. Click the **Edit** button. The **Manage User** window will appear.

4. Select the tab you want to view or update. The options are Unlock, Change Password, Roles, Permissions, Events and Profile Log

5. Click**Save** to save the changes or **Cancel** to return to the User Profile Screen.


**1.4.23.1.7.2.4** **(10-09-2024)**

###### Change Password

1. A user is required to create a new password when a temporary password has been granted. A user is also required to change their password every 90 days. The Site Coordinator will grant a temporary password when:



   - Adding a new user to FCP

   - User returning to duty

   - A user has forgotten their password


### Note:

Users should change their password anytime they feel it has been compromised.

2. The user will log into the FCP system using the temporary password and proceed to change their password.

3. A standard password format must be at least 12 characters with no spaces and consist of:



   - At least one Uppercase Letter

   - At least one Lowercase letter

   - At least one numerical digit

   - One of the following special characters ! $ () \* + , - /: ; < = > ? \_

   - Cannot be the same as the username

   - Cannot be the same as old password



     ### Note:



     Passwords are case sensitive.


4. If the password does not meet standard password format, the system will display the following error messages:



   - Error - "Password same as user" . The new password can not be the same as the user name

   - Error - "Password length less than 12"

   - Error - "Password should contain at least one digit, one character and one punctuation"

   - Error - "Password should differ by at least 3 characters" . The new password must differ by at least 3 alpha characters from the previous password


5. If the user encounters any error messages, they must correct the password and try again.

6. To change the password, select **Edit** from the menu bar, select **User Profiles**, then select the appropriate user, then select **Edit** and then **Change Password.**

7. The “Change Password” screen will display:



1. New Password.

2. Right click to copy the password to provide to the user.

3. Submit - Click the **Submit** button.


**1.4.23.1.7.2.5** **(10-09-2024)**

###### Unlock Account

1. If the user has three failed attempts within the same day to log into FCP, the system will automatically lock the users account preventing further attempts to log in.

2. The user will notify their manager of the problem. The manager will then notify the Site Coordinator and provide the User ID to Unlock the user.

3. To Unlock User:



1. Select your **Active Role** as the Coordinator for your site

2. Click **Edit** from the menu bar, then select **User Profiles**

3. Choose the User you need to unlock

4. Select **Edit**

5. Select the **Unlock Account** button

6. Click **OK**


**1.4.23.1.7.3** **(10-16-2023)**

##### FUTA Batching

1. The FUTA Coordinator, and Managers and Leads with site coordinator access are responsible for batching work from FCP to specific TEs.

2. The Coordinator has the ability to perform the following actions:



   - Assign batches

   - Reassign batches

   - Unassign batches


**1.4.23.1.7.3.1** **(10-16-2023)**

###### Assign Batch(es)

1. The Site Coordinators responsibility is to assign a batch(es) and each case within that batch to a TE.



### Note:



The maximum number of batches that can be assigned to a TE is 50.

2. To assign work to a TE:



01. Select your**Active Role** as the Coordinator for your site.

02. Click **Edit** from menu bar.

03. Select **Coordinator** from the drop down menu.

04. Select**Batch Management**.

05. Select **Assign.** The **Select Batch** tab will highlight. This displays all the available batches and volumes to be assigned.

06. Select the batch type you want to assign. The **Select User** tab will highlight..

07. Select the TE you want to assign batches to. The **Quantity** tab will highlight. Enter the number of batches you want to assign.

08. Click the **Back** button if you selected the wrong TE or select **Restart** to go back to the previous screen.

09. Click**Finish** when you are done assigning. The **Summary** tab will highlight. This displays the batch type, number of batches assigned and the user’s information.

10. Click **Restart** to go back to the Assign-Select batch screen to continue assigning batches to your team or select **Close** to close the screen.


**1.4.23.1.7.3.2** **(10-16-2023)**

###### Reassign Batch(es)

1. The Site Coordinator has the responsibility to reassign batch(es) and each case assigned within that batch to another TE.

2. To reassign work from one user to another:



01. Select your **Active Role** as the Coordinator for your site.

02. Click **Edit** from the menu bar. Select **Coordinator** from the drop down menu.

03. Select **Batch Management**.

04. Select **Reassign**. The **From User** tab will highlight. Select the user you want to reassign batches from.

05. The **Select Batches** tab will highlight. Select the batch you want to reassign to another TE. To select more than one batch, hold the shift key and highlight additional batches. Click **Next** to continue.

06. The **To User** tab will be highlighted. A list of users and their assigned batches will display. Select the user to receive the reassigned batch(es).

07. The**Confirm Reassignment**tab will highlight. This displays the users and the batches that were reassigned.

08. Click the **Back** button if you decide to reassign additional batches. Click **Restart** to go back to the previous screen.

09. Click**Finish** to confirm the batches. After you click **Finish**, the **Summary** tab will highlight confirming the reassignment was successful.

10. Select **Restart** to return to the Reassign From User screen to continue reassigning batches or **Close** to close the screen


**1.4.23.1.7.3.3** **(10-16-2023)**

###### Unassign Batch(es)

1. This process will unassign a batch and each case assigned within that batch from the selected tax examiner back to the batch inventory.



### Note:



Batches can only be unassigned, if correspondence has not been issued on any case within the batch.

2. To unassign batches:



01. Select your**Active Role** as the Coordinator for your site.

02. Click **Edit** from the menu bar. Select**Coordinator** from the drop down menu.

03. Select**Batch Management**.

04. Select **Uassign.** The **Select User** tab will highlight and displays users with assigned batches. Select the user who’s batches will be reassigned.

05. The **Select Batches** tab will highlight. Select the batch to be moved back into the inventory. To select more than one batch, hold down the shift key and highlight additional batches.

06. Click**Next** to continue. The **Confirm** tab will highlight.

07. Click**Back** if this was done in error or **Restart** to go back to the previous screen.

08. Click **Finish** to confirm the batches to be unassigned.

09. After you click **Finish**, the **Summary** tab will be highlighted confirming the unassignment was successful.

10. Select **Restart** to continue unassigning batches or **Close** to close the screen


**1.4.23.1.7.4** **(10-09-2024)**

##### Inventory Management - Site Coordinator/Coordinator/Manager

1. The FUTA Site Coordinator is responsible for monitoring the inventory that is Downloaded into the FCP system. The Site coordinator will use the table below to determine the priority of work and the order in which it will be assigned.

2. The following table identifies the work and its priority:




| Priority | Case Status | System Action | Reports /Listing | Site Coordinator | Exceptions |
| --- | --- | :-: | :-: | :-: | :-: |
| Number 1 | STAT | Auto Batched by the System | Generate the report listings. | Assigns batches to TE | STAT\_C must be worked due to Statute of Limitation, do not hold. |
| Number 2 | DUP DLN/EIN | Site Coord. Mass request Print Register. | Generate the Duplicate DLN and Duplicate EIN Listings | Designate TE(s) to work the listings | None |
| Number 3 | Zero Cert | Site Coord. Mass request Print Register. | Print the report and send printed registers to the designated states and wait for the response from the states. | Mass Request Printed Registers select ZERO option order by State. | ZERO Certs for California and North Carolina need to be printed and mailed as soon as possible. State account numbers will need to be input before CAUE and NCUE process can begin. |
| Number 4 | 6020b | Auto Batched by the System | Generate the report listings. | Assign batches to TE(s) to work | 6020\_C will not be worked until CAUE and NCUE has been requested. |
| Number 5 | PARS | Site Coord. Mass request Non-Printed Registers PARS. System batches after request | Generate the report listings. | Coordinator assigns batches to TE to be worked. | PARS\_C will not be worked until CAUE and NCUE has been requested. |
| Number 6 | \*4010 Letters | After steps 1-4 are completed begin the Mass Request by State | N/A | N/A | Complete the generation of the CAUE and NCUE process before mass generation of 4010C request |
| Number 7 | \*4011 Letters | After steps 1-4 are completed begin the Mass Request by State | N/A | N/A | Complete the generation of the CAUE and NCUE process before mass generation of 4011C request |
| Number 8 | CAUE and NCUE | This must be run before the mass generation of letters. | Generate the Unity of Enterprise report and give to a TE(s) for resolution. | Assign batches to TE(s) to work | Complete the Priority steps 1-3 before the CAUE and NCUE process. |





### Caution:



Any Batch Type with \_C must not be worked until the generation of CAUE and NCUE.


**1.4.23.1.7.4.1** **(04-01-2010)**

###### Statute Verification

1. The download will contain cases which have statute situations that must be addressed. Cases where the statute date expires within 120 days will be worked on a priority basis.

2. FCP will auto batch Statute cases at the time of the download and the Site coordinator will assign the cases to TE's to work.


**1.4.23.1.7.4.2** **(10-09-2024)**

###### DUP DLN

1. Some cases in the FUTA Download will reflect Duplicate Document Locator Numbers (DLNs). TEs will compare the FCP screens, and consolidate all necessary information onto one case and close the other. The open discrepancy can then be worked following normal procedures. Additional research must be performed if tax years or entities are not the same.

2. Generate the Duplicate DLN report and give to an identified TE to work the DUP DLN issue. See _IRM 1.4.23_, Monitoring FUTA Reports-Site Coordinator/Coordinator/Manager for instructions on accessing FUTA reports.


**1.4.23.1.7.4.3** **(10-16-2023)**

###### DUP EIN

1. Some cases in the FUTA Download will reflect Duplicate Employer Identification Numbers (EINs). TEs will compare the FCP screens, and consolidate all necessary information onto one case and close the other. The open discrepancy can then be worked following normal procedures. Additional research must be performed if tax years or entities are not the same.

2. Generate the Duplicate EIN report and give to an identified TE to work the DUP EIN issue. See _IRM 1.4.23.1.6.2_, Monitoring FUTA Reports-Site Coordinator/Coordinator/Manager for instructions on accessing FUTA reports.


**1.4.23.1.7.4.4** **(10-09-2024)**

###### Zero Certification

1. Zero Certifications are cases where the records were not certified by the states because there was not a match on the EIN, or no state wages and/or payments were made to the state.

2. To request Zero Certs after the Zero Certification process has been completed for CAUE and NCUE:



01. Select your **Active Role** as the Coordinator for your site.

02. Select **Edit** from the menu bar. Select **Coordinator** from the drop down menu.

03. Select **Mass Requests**. Select **Registers**. The **Request New Job** screen will appear.

04. Click the **Request New Job** tab. A **CATRS Program** window will appear with important instructions on the printed register process. Click **OK**. The **Job Runner** window will appear.



       ### Note:



       Make sure you have access to the BOE to view and print your register request.

05. In the **Request Type** box, select **ZERO (Printed)**. Select the**State** from the state box. The **ALL records meeting criteria** button will highlight automatically. Click **Run**.

06. A confirm box will appear with the register request information. Select **Yes** to generate the registers or **No** to cancel the request.

07. If you select Yes, a **CATRS Program** window will appear with the following message: _"Process has been requested. You must stay logged in until process completes. Click OK to close this prompt and monitor job runner screen for completion status. If process does not end within a reasonably expected time or if you encounter any red failures, contact HQ immediately"_. Click **OK.** The Job Runner screen will display. Monitor the screen until it completes. After completion, **log into BOE and print the records.**

08. Once you confirm the ZERO registers were printed, return to the Job Runner screen and select the**Register Menu** tab.

09. Select **Mark ALL UE/Zero register requests as PRINTED**. A Warning window will appear to remind you to confirm the registers were physically printed and verified before you continue.

10. Select **Yes**to continue. The Job Runner screen will be updated as completed and printed. Select **No** to cancel.


3. Follow the instructions in (2) until all ZERO Certs have been requested by State.



### Note:



California and North Carolina Zero Certification Registers need to be ordered, printed and shipped to the state agency as soon as possible.

4. The ZERO Cert cases will be assigned automatically to the FUTA Site Coordinator.

5. Once all of the registers have been requested and printed, ship or mail them to the State Agency. See IRM 1.4.23.1.6.2, Monitoring FUTA Reports-Site Coordinator/Coordinator/Manager for instructions on accessing FUTA reports.



### Note:



Notify the state agencies if there is an unusual amount of Zero Registers to be certified.

6. Monitor the receipts as they are returned to ensure all of the re-certifications have been received.

7. Assign the re-certifications to designated TE(s) to input the information into FCP. TE(s) will work the re-certifications following the procedures in IRM 4.19.5, Certification of State Federal Unemployment Tax Act (FUTA) Credits.



### Note:



ZERO Certs returned from California and North Carolina will be assigned to a designated individual to input **ONLY** the State Account Numbers. Once that has been completed, the CAUE NCUE process can begin. (CAUE and NCUE Registers, and PARS\_Cs, can be ordered and Mass Letter requests can begin.)



    .




**1.4.23.1.7.4.5** **(10-16-2023)**

###### Potential Adjustment Registers (PARS)

1. PARs require case review prior to letter issuance. These are cases/records that could not pass Enterprise Computing Center at Martinsburg's (ECC-MTB) calculation programs due to the rate indicator provided by the state or a freeze code posted to the Master File. The campus FCP System cannot automatically determine the tax or credit due on these cases.

2. PARS cases are records not printed as registers. The Site Coordinator will Mass request Non-Printed Registers PARS.

3. Once the PARS are requested, the FCP system will automatically batch the cases. The TE(s) will be assigned the batches and they will be worked following the procedures in IRM 4.19.5, Certification of State Federal Unemployment Tax Act (FUTA) Credits.



### Note:



PARS\_C batches will not be worked until CAUE and NCUE Register requests have been completed. The UE Indicator will update to 9 identifying UE records. Then the PARS\_C registers can be worked.

4. To request PARS :



1. Select your **Active Role** as the Coordinator for your site.

2. Select **Edit** from the menu bar. Select **Coordinator** from the drop down menu.

3. Select **Mass Requests**. Select**Registers**. The **Request New Job** screen will appear.

4. Click the **Request New Job** tab. A **CATRS Program** window will appear with important instructions on the printed register process. Click **OK**. The **Job Runner** window will appear.

5. In the **Request Type** box drop down menu, select **PARS (Non-Printed)**. Select the **State** from the state box. The **ALL records meeting criteria** button will highlight automatically. Click**Run.**

6. A confirm box will appear with the register request information. Select **Yes** to generate the registers or **No** to cancel the request.

7. If you select Yes, a **CATRS Program** window will appear with the following message: _"Process has been requested. You must stay logged in until process completes. Click OK to close this prompt and monitor job runner screen for completion status. If process does not end within a reasonably expected time or if you encounter any red failures, contact HQ immediately"_. Click **OK.** The Job Runner Screen will display. Monitor the screen until it completes.


5. Once the request has been generated the FCP system will auto batch PARS. Site Coordinator will assign the batches to the TE(s).



### Note:



PAR\_C will not be worked until CAUE and NCUE has been requested.


**1.4.23.1.7.4.6** **(10-09-2024)**

###### Mass generation of 4010C and 4011C Letters

1. Once STAT, DUP DLN/EIN, ZERO Cert and CAUE and NCUE are completed, the mass generation of Letters 4010C (Proposed Increase to FUTA Tax) and 4011C (Proposed Decrease to FUTA Tax) can begin. The site will provide a schedule for the mass generation, which should include the number of letters to be mailed weekly. If the schedule is followed, the site will be able to meet the Program Completion Dates (PCD). See IRM 1.4.23.1.6.1, Program Completion Dates (PCD) for information.

2. To request Mass Generation of 4010C and 4011C Letters:



1. Set your **Active Role** as the Coordinator for your site.

2. Select **Edit** from menu bar. Select **Coordinator** from the drop down menu.

3. Select **Mass Requests**. Then select **Letters**. This will open the **New Request** window.

4. Select the 4010C or 4011C letter you want to send from the**Request Type** drop down menu. Select the state from the **State** drop down menu.

5. Select the number of letters requested from the **Record Limit** box.



      ### Note:



      Limit each request to a maximum of 500 letters due to the amount of time it takes for generation. See IRM 1.4.23.1.7, FCP Site Coordinator for more information.

6. Click **Run**. A **New Request FUTA** box will appear displaying the information requested and a reminder of the letter request process. Click **OK**. Monitor the request until completed.



      ### Note:



      Volume of Mass Generated Letters and Manual Input letter volumes need to be monitored weekly to prepare for the Replies and No Replies that can be expected.

7. When the run is completed, return to the Letters screen and the information from the run will be listed on the log.

8. Highlight the job you ran to check for errors and the quantity of letters that actually ran. This information can be found in the **Additional Information**box below the log.



      ### Note:



      Even though you request a specific number of letters, the system will only run the amount available to be ran.

9. Click **Close** to exit the screen.


3. Follow the above process for each state until all letters have been generated. This is a daily process.


**1.4.23.1.7.4.7** **(10-16-2023)**

###### California Unity of Enterprise (CAUE) North Carolina Unity of Enterprise (NCUE) Registers

1. The States of California and North Carolina have a unique situation when matching our FUTA Identification Tape with employer account records. They have a system of assigning ONE state number to all businesses owned by that individual. This is called "Unity of Enterprise" . The IRS assigns EINs to business entity types (sole proprietor, corporation, etc.) and not individuals. Each entity type has its own Federal Employer Identification Number (FEIN). Use the following procedures when processing Unity of Enterprise cases.

2. Once the STAT, DUP DLN/EIN and Zero Cert (with the exception of California and North Carolina Zero Certs, until all the State Account Numbers have been input) are completed the Site Coordinator can begin generation of the CAUE and NCUE records.

3. To generate CAUE and NCUE Registers:



01. Select your **Active Role** as the Coordinator for your site.

02. Select **Edit** from the menu bar. Select **Coordinator** from the drop down menu.

03. Select **Mass Requests**. Then select**Registers**. The **Request New Job** screen will appear.

04. Click the **Request New Job** tab. A **CATRS Program** window will appear with important instructions on the printed register process. Click **OK** after you read the message.



       ### Note:



       Make sure you have access to the BOE to view and print your register request.

05. After you click OK, the **Job Runner** window will appear. In the **Request Type** box, select **UE (Printed)**. Select either California (CA) or North Carolina (NC) in the **State** box. Once you select the state, the **ALL records meeting criteria**button will highlight. Click **Run**.

06. A confirm box will appear with the register request information. Select **Yes** to generate the registers or **No** to cancel the request.

07. If you select Yes, a **CATRS Program** window will appear with the following message: _"Process has been requested. You must stay logged in until process completes. Click OK to close this prompt and monitor job runner screen for completion status. If process does not end within a reasonably expected time or if you encounter any red failures, contact HQ immediately"_. Click **OK.**

08. The **Job Runner** screen will appear. Monitor until your request has completed. After completion, **log into the BOE and print the records**. After confirming the registers have printed, return to the **Job Runner** screen and select the **Register Menu** tab.

09. Select **Mark ALL UE/Zero register requests as PRINTED**. A Warning window will appear to remind you to confirm the registers were physically printed and verified before you continue.

10. Select **Yes**to continue and the Job Runner screen will be updated as completed and printed. Select **No** to cancel.


4. Print the "Unity of Enterprise" report (Registers) and give to a TE(s) for resolution. See IRM 4.19.5, Certification of State FUTA Credits.



### Note:



All \_C batches will be able to be worked once CAUE or NCUE has been generated.


**1.4.23.1.8** **(10-16-2023)**

#### Miscellaneous Coordinator Roles

1. The campus may designate specific employees to perform the following roles:



1. Disaster Coordinator

2. Form 3870 Coordinator

3. Statute Coordinator

4. Large Corporation Coordinator

5. Training Coordinator


**1.4.23.1.8.1** **(10-09-2024)**

##### Disaster Coordinator

1. The Disaster Areas screen contains Disaster Area information for specific states and/or ZIP Codes. It enables the user to view and to sort information on active and inactive **O** and **S** freeze Disaster Areas. This information is used to determine whether or not a case can be updated.

2. The Disaster Coordinator is responsible for adding Disaster information and editing existing Disaster information.

3. When new disasters occur, the Disaster Coordinator will receive direction from HQ of the type of freeze (-S or -O) being issued and the actions needing to be taken. Once the directive has been received the Disaster Coordinator will search the FEMA website to identify the information that is needed to add to the FCP system.



### Note:



Access the FEMA website for Disaster information: [FEMA](https://www.fema.gov/)

4. The entering and updating of Disaster Area Information is done by specific FUTA Disaster Coordinators who have been assigned by Headquarters.**Viewing and searching of Disaster Area Information is accessible to all Coordinators.**

5. The Disaster Areas screen will display the following:



   - Status (Active or Expired)

   - FEMA Declaration ID

   - Disaster Description

   - Start Date

   - End Date

   - Created Date

   - Created By

   - Last Modified Date

   - Modified By

   - CATRS ID


**1.4.23.1.8.1.1** **(10-16-2023)**

###### Add New Disaster

1. When new disasters occur, the information can be found on the FEMA website. The website should be accessed daily to ensure that all new information is added immediately.

2. To enter New Disaster Area information:



1. Select **Edit** from the menu bar.

2. Select **Disasters** from the drop down menu.

3. Click the**New** tab on the disaster screen. This will bring up the **Manage Disaster**screen

4. Enter the FEMA Disaster ID number from the FEMA website in the **FEMA Declared ID** box. This will automatically bring up information on the disaster, (i.e. Disaster Description, Start Date, End Date, etc.).

5. All Zip Codes and freeze codes will automatically populate from the FEMA website.

6. Click **Save** to keep the record or **Cancel** to return to the main disaster screen.


**1.4.23.1.8.1.2** **(10-16-2023)**

###### Delete Disaster Area Information

1. If Disaster information was entered incorrectly you may delete the record that you created.

2. To delete a Disaster Area's record:



1. Select **Edit** from the menu bar.

2. Select **Disasters** from the drop down menu. This brings up all the FEMA disaster records.

3. Highlight the Disaster ID you want to delete from the**FEMA Dclr ID** column.

4. Click the **Delete** tab on the disaster screen. This will bring up**Delete Disaster** window. The following message will appear: _**"Deleting this disaster area will delete all associated zip codes. NOTE: This delete process may take some time to update case histories. Do you want to continue this delete?"**_

5. Select **Yes** to continue deleting or **No** to keep the record.



      ### Caution:



      **Once Disaster Area information is deleted, it CANNOT be restored. Be sure the correct disaster is being deleted before clicking on the Yes Button.**


**1.4.23.1.8.1.3** **(10-16-2023)**

###### Edit Disaster Information

1. After the original disaster is input you may receive notification that the disaster has been amended and you need to add additional zip codes. You can add single zip codes (not in numerical order) or a range of zip codes (more than one in numerical order).

2. To add a single zip code:



1. Access the Disaster screen.

2. Highlight the **Disaster ID** you want to edit from the **FEMA Dclr ID** column. The **Manage Disaster** window displays.

3. Click **Add** to add the additional zip codes. The **Manage Zip Code** box will appear.

4. Select **Single Zip**.

5. Select the disaster Freeze Code you obtained from the FEMA website.

6. Input the **Zip Code** in the Zip Code box.

7. Click **Add** to continue adding additional single zip codes.


3. To add a range of zip codes:



1. Access the Disaster screen.

2. Highlight the **Disaster ID** you want to edit from the **FEMA Dclr ID** column. The **Manage Disaster** window displays.

3. Click **Add** to add the additional zip codes. The **Manage Zip Code** box will appear.

4. Select **Zip Range**.

5. Select the Disaster**Freeze Code** you obtained from the FEMA website.

6. Enter the beginning zip code in the **Begin Zip Code** box.

7. Enter the ending zip code in the **End Zip Code** box.



      ### Note:



      The zip codes **MUST** be in numerical order to use this option.

8. Click **Add** to add the next Zip Code Range.

9. Click**Save** to update the record.


4. To edit a zip code:



1. Highlight the zip code and select **Edit**. The**Manage Zip Code** box will display.

2. The only field you can update is the**Freeze Code** box. Once you make the correction, click**Save** to update the record.


5. To delete a zip code:



1. Highlight the zip code and select **Delete**

2. A **Delete Zip Code** box will display. Click **Yes** to delete or **No** to return to the Manage Disaster window.

3. Click **Save** to update the record.


**1.4.23.1.8.2** **(10-16-2023)**

##### Form 3870 Coordinator

1. When a case is being worked by the field, the revenue officer will submit a Form 3870"Request for Adjustment" , to request an adjustment or abatement of the FUTA assessment. These requests will either be paper, FAX, or to a secure email box. The clerk or designated official will retrieve the new electronic Form 3870 daily. These cases will be controlled on IDRS using the Category Code "3870" .



### Note:



The IAT CAWR/FUTA Batcher Tool has also been updated with this Category Code.

2. These cases must be worked within 45 days of receipt into the department on a **first-in-first-out** basis while workload permits.

3. Points of Contact (POCs) were established at each campus to provide assistance for field ROs and/or managers. The POCs are expected to assist the ROs with procedural issues and routing of the cases to the appropriate campuses. POCs can be found on the SB/SE Doc Matching web site: SBSE Doc Matching


**1.4.23.1.8.3** **(10-09-2024)**

##### Statute of Limitations - Manager/Statute Coordinator Responsibilities

1. Statute Awareness - Communicating the importance of statutes to all employees is very important and the responsibility of every manager/statute coordinator. On an annual basis, management is expected to issue Statute reminders to the employees. These reminders will be procedures which include contact information (phone numbers, coordinator name, tour of duty (TOD), instructions to follow for last minute statutes discovered and the local routing procedures to the statute unit or RACS (depending on the time frame). Contact names and numbers can be located on the CAWR/FUTA Web page. It is the responsibility of the campus to alert the web master if a change in contact information is necessary.

2. Document 7368, Basic Guide for Processing Statute Cases, is available to all campuses and area offices. Management must maintain a sufficient supply of this document from the National Distribution Center using catalog number 10296C. Document 7368, contains valuable information on statute-specific topics; therefore, a copy will be given to each employee.

3. Statute Searches must be performed beginning 90 days prior to statute expiration date. All inventories (paper and electronic) must be reviewed for statute imminent criteria and documented.



### Note:



FUTA statute search begins November 1st.

4. No case is to be transshipped to a different POD if it is within 90 days of statute expiration.

5. In addition, all new receipts must be reviewed as received, prior to controlling to a tax examiner beginning with the dates above and continuing through to the statute expiration date. If the case is statute imminent, it needs to be labeled as such and expedited for processing.

6. Use the following Forms and Procedures for Statute Searches:



1. Form 11122 Employee's Statute Certification: Campuses must have all employees complete Form 11122 taking responsibility and documenting the bi-weekly statute searches beginning 90 days prior to the statute expiration date. These searches are to be increased to weekly searches 30 days prior to the statute expiration date. During the final week prior to the statute expiration date, searches increase to daily. Each search performed must be documented.

2. Form 11122-A Manager's Statute Certification: Campuses must have two levels of management complete Form 11122-A taking responsibility and documenting the bi-weekly statute searches beginning 90 days prior to the statute expiration date. These searches are to be increased to weekly searches 30 days prior to the statute expiration date. During the final week prior to the statute expiration date, increase the searches to daily. Each search performed must be documented.

3. The Operation Manager is to ensure Form 11122 and Form 11122-A are completed and maintained in the employees/managers Unofficial Personnel Folder drop file for three years. After three years, dispose of forms using classified waste procedures.


7. Utilizing Form 6759, Request Taxpayer Data, management must request running a monthly IDRS utility run for the FUTA program, beginning 90 days prior to the statute expiration date. These runs should be increased to weekly beginning 30 days prior to the Statute expiration date. Form 6759, requests an output file showing the following information:



   - TIN

   - MFT

   - Tax Period

   - ASED Date

   - DLN of Pending Adjustment Transaction

   - Dollar Amount of Transaction


8. This report is used to identify FUTA adjustments input to statute imminent accounts and will eventually become unpostables. Accounts identified must have quick assessments input to protect the statute.



### Note:



During dead cycles in January, this output file will not be available.


**1.4.23.1.8.3.1** **(10-09-2024)**

###### Confirmation of Prompt Assessments - Statute Coordinator

1. Confirmation must be made on all Form(s) 2859, Request for Quick or Prompt Assessment that are submitted for processing.

2. Once the cases have been uploaded to the share drive, it is important to follow-up timely to ensure prompt and accurate processing of statute imminent cases.

3. Within two (2) days, the Statute Coordinator will confirm the Form 2859 was received by:



1. Accessing the share drive and locating the FUTA statute folder

2. Ensuring the uploaded statute file shows **"RCVD"** following the file name


4. Within five (5) days, the Statute Coordinator should have the DLN or be able to locate the DLN of the assessment in the FUTA statute folder on the share drive. Monitor the case until the adjustment posts.



### Note:



If the 23C date was not given prior, it will also be listed on the Form 3210.

5. If the DLN is not located, the Statute Coordinator will contact the appropriate accounting site to confirm input of the assessment and request a copy of the Form 3210 and DLN.

6. FUTA Manager, Technical Advisor or Designated FUTA Employee will serve as backups in the event the Statute Coordinator is unavailable.


**1.4.23.1.8.4** **(10-09-2024)**

##### Large Corporation/Large Dollar Screening- Local Large Corporation Coordinator Instructions

1. Review the case to ensure that contact with the Large Corporation Technical Unit (LCTU) is needed.

2. For valid cases take the following action:



1. See the LCTU state mapping list to determine which LCTU needs to be contacted, IRM 21.7.1.4.11.

2. FAX the FCP MONEY AMOUNT screen to the appropriate LCTU contact. See: Large Corp Contacts for a list of LCTU contacts

3. Update the Large Corporation Referral Tracking listing notating all actions taken.


3. The LCTU has 10 business days to supply any additional information.



### Note:



If LCTU provides information after the correspondence has been issued, see IRM 4.19.5.4.8, Processing Replies





### Reminder:



When there is a 10 million dollar assessment, send copies of the case using Form 3210 Document Transmittal, to the CFO in Kansas City, MO. See IRM 4.19.5.4.7.6, Large Dollar Cases.

4. Follow the table below when a response is received from LCTU:




| **If** | **Then** |
| --- | --- |
| The information supplied by LCTU results in either a full or partial resolution to the discrepancy. | Direct the tax examiner to process the information provided by LCTU and take the appropriate action. |
| The information supplied by LCTU does not result in a full or partial resolution **OR** LCTU does not provide any additional information within the 10 business days. | Direct the tax examiner to issue the appropriate correspondence. |


**1.4.23.1.8.5** **(10-09-2024)**

##### Training Coordinator

1. The Training Coordinator will be responsible to ensure training is administered annually to all employees. New hires will receive Basic Training and all other employees will receive CPE training. The duties of the Training Coordinator are listed below:



   - Reserve Training Rooms

   - Order supplies for students and instructors

   - Supply Forms needed for ELMS/ITM credit

   - Solicit Operation for Subject Matter Experts (SMES)

   - Prepare training plans for students and instructors

   - Monitor/Evaluate Training

   - Resources


2. **Reserve Training Rooms**: Reserve training rooms sufficient for delivering FUTA training. Reserve the rooms far enough in advance to ensure they are available for your September training. These Computer Based Training rooms need to have FCP, IATS, IDRS and ORS (for the overhead) to be able to explain the different systems and use them throughout the class. Ensure you prepare for employees with disabilities accordingly.

3. **Order supplies for students and instructors**: Students will need paper, pens, highlighters, tabs and course training material.

4. **Supply Forms needed for ELM/ITM credit:** Ensure the following forms are available for class startup: Form 12466, Integrated Training Evaluation and Measurement Serves (Classroom), Form 12464, Integrated Training Evaluation and Measurement Serves (Classroom CBT), Form 10268, Training Registration Record, and Form 6554, Name Tent. These forms are to be brought to the CMLC staff upon completion of the class.

5. **Solicit Operation for SMES:** Contact the Operation for employees having received Certified Instructor Training (CIT) and are most qualified to instruct.

6. **Assist with the preparation of training plans for students and instructors:** Assist with the development of course material, handouts, disclosure. Review nature of changes listing in the most current IRM available to include in the course material. Discuss with the instructors the delivery method you will be using and what phases of the program will be covered.

7. **Monitor/Evaluate Training**: Supply the manager/instructors with OJI and OJT Guidelines. Ensure guidelines are being followed and progress can be tracked for individual employees.

8. **Training Resources**: Prepare a report for submission to your Operation detailing the number of hours used at the end of the classes. Participate in the completion of the Operation’s Training Work Plan.


**1.4.23.1.8.6** **(10-16-2023)**

##### Identifying Trends - Site Coordinator

1. Whenever a "trend" seems to be emerging for a specific type of taxpayer and/or their Payer Agent, Power of Attorney (POA) or Reporting Agent Authorization (RAA), TE's will compile documentation to show the "trend" and give the information to the Site Coordinator.

2. The Site Coordinator will inform the Headquarters FUTA analyst of the trend and forward the documentation..


**1.4.23.1.8.7** **(10-16-2023)**

##### Policy Statement P-21-3 Site Coordinator/Managers

1. Tax examiners will conform to**Policy Statement P-21-3**requirements by responding to the taxpayer within 30 days of the received date for each piece of taxpayer correspondence. Policy Statement P-21-3 requires an interim Letter 5825-C to be issued if unable to close the taxpayer's response within 30 days. FCP automatically issues a Letter 5825-C as it batches all open replies if the case reaches 25 days old as long as the IAT CAWR/FUTA Batcher Tool is used to streamline the clerical process.


**1.4.23.1.8.8** **(10-16-2023)**

##### Discovered Remittances

1. Discovered remittance is a response and/or correspondence with an original form of payment attached such as a personal check, money order or cashier’s check. Also, a loose check(s) discovered in an envelope or attached to a blank piece of paper.



### Note:



For voided or blank checks see (8) below.

2. If any of the items listed in (1) are discovered, both the Form 3244, Payment Posting Voucher and Form 4287, Record of Discovered Remittance **must** be completed.

3. Two copies of Form 3244, must be completed for each discovered remittance and contain entries in the following fields:



   - TIN

   - Form Number/MFT

   - Transaction/Received date (IRS Received date)

   - Taxpayer name, address and ZIP code

   - Transaction Data, enter remittance amount next to code 640 (Advance Payment of Deficiency)

   - Remarks (the team manager’s phone number and Mail Stop)

   - Prepared by


4. Form 4287, Record of Discovered Remittance, must be completed to log all discovered remittances. The following fields must have entries:



   - Stop Number

   - Unit

   - Telephone Number

   - Today’s Date- in MM/DD/YYYY format

   - Type of doc- (for example, Form 940, Schedule H

   - Tax Period- (entire tax period XXXX)

   - Type of remit- (total money amount including comma and decimal point)

   - Received Date- in MM/DD/YYYY format

   - Name (entire name)

   - TIN

   - Discoverer- Name of person who discovered the remittance and their supervisor’s name


5. **If remittance is found attached to a case while working in the office, take the following steps:**



1. Attach one copy (original) to the remittance and give it to the Manager/Lead Tax Examiner who will give it to the Clerical Manager/Lead Clerk to place in a **locked box** (lock box).

2. Attach a second copy of the Form 3244 to the response.


6. **If the remittance is found attached to a case while tele working, immediately take the following steps:**



1. Notify your manager immediately.

2. Email completed Form 3244 and Form 4287 to your Manager and Coordinator/Technical Advisor.

3. Place remittance in a **sealed envelope** and store in a secure place (locked desk or cabinet).

4. Document remittance details (i.e., leave a case note or history item).

5. Make an appointment to bring Discovered Remittance into the operation and deliver to the technical Manager/Lead Tax Examiner within **2 business days.**

6. Technical Manager/Lead Tax Examiner will accept the discovered remittance, print Form 4287 and Form 3244.

7. Manager/Lead Tax Examiner will deliver the discovered remittance to the Clerical Manager/Lead Clerk.


7. **IRS CHECKS**\- Returned IRS refund checks are handled differently than regular discovered remittance. If an IRS refund check is found, take it to the team Manager/Lead Tax Examiner to be routed to the Refund Inquiry Unit.

8. **Voided Checks**\- If the response has a **"VOIDED"** personal check attached, remove the check from the response and attach it to the Installment Agreement (IA) request. Route the **VOIDED** check with the IA to Collections.


**1.4.23.1.9** **(10-09-2024)**

#### Taxpayer Advocate Service (TAS)

1. The Taxpayer Advocate Service (TAS) is an independent organization within the IRS that helps taxpayers and protects taxpayer rights. TAS employees assist taxpayers who are experiencing economic harm, who are seeking help in resolving tax problems not resolved through normal channels, or who believe that an IRS system or procedure is not working as it should, Refer to IRM 13, Taxpayer Advocate Service for more information.

2. TAS independently represents taxpayer interests and concerns within the IRS by:



   - Ensuring that taxpayer problems, which have not been resolved through normal channels are handled fairly and promptly.

   - Identifying issues that increase burden or create problems for taxpayers, bringing those to the attention of IRS management and making legislative proposals where necessary.


3. Refer taxpayers to TAS when the contact meets TAS criteria (see IRM 13.1.7, Taxpayer Advocate (TAS) Case Criteria), and you can’t resolve the taxpayer’s issue the same day.

4. See IRM 13.1.7.5, Same Day Resolution by Operations, for criteria when the case can’t be resolved on the "same-day" . The definition of same day is within 24 hours.



### Note:



If the issue cannot be completely resolved within 24 hours, but steps have been taken within 24 hours to resolve the taxpayer’s issue, these cases also meet the definition of "same-day" .

5. Do not refer cases to TAS unless they meet the TAS criteria and taxpayer asks to be transferred to TAS. Refer to IRM 13.1.7, Taxpayer Advocate Service (TAS) Case Criteria.

6. When you refer cases to the local Taxpayer Advocate, use "Form 911, Request for Taxpayer Advocate Service Assistance (and Application for Taxpayer Assistance Order)" . See IRM 21.1.3.18, Taxpayer Advocate Service (TAS) Guidelines for more information.


**1.4.23.1.9.1** **(10-16-2023)**

##### TAS Coordinator Responsibilities

1. Initial Operations Assistance Request (OARS), requests are assigned to the TAS Coordinator and placed in a designated ATAO in box.

2. Log all requests to an Excel tracking document notating EIN, Program, Tax Year, Date Received, Remarks, and TE assigned.

3. Daily review OARS received for attachments that would be applicable to resolve the discrepancy i.e., Form 940B Request for Verification of Credit Information Shown on Form 940, Form 940C Employer Account Abstract or tax returns submitted, etc. If they are asking for an abatement of a FTD penalty, or FUTA adjustment, and the documentation received had no bearing to reconsider, notify TAS of the documents needed and suspend for three days. If documents are not received, then reject back to TAS, close the case and update the Excel tracking log.

4. As TAS Coordinator it is your responsibility to ensure the TAS cases are worked promptly. The cases can be assigned out to tax examiners based upon their program skill.



### Note:



Have the tax examiner re-assign the case to themselves on IDRS, take the necessary action requested, fax the OARS back to TAS, provide a copy of the OARS to the Coordinator to update the Excel tracking log with the date and action taken.

5. When TAS has requested expedite processing, the Coordinator will acknowledge receipt of the OAR to the designated TAS Liaison via Form 3210, "Document Transmittal" , secure messaging e-mail, facsimile or by telephone, within one (1) workday of receipt of the OAR. The TAS coordinator will provide his or her relief/no relief decision within three (3) workdays by telephone, facsimile, secure messaging e-mail, or hand delivery to the TAS employee. Telephone responses are acceptable if followed up, within the time agreed upon, and with the necessary documentation.

6. Update the Excel tracking log with all actions taken to the TAS case and ensure OARS assigned to tax examiners are closed within the negotiated completion date. Verify to ensure the EXCEL tracking log balances to the ATAO cases listed on your CCA42-43 weekly.


**1.4.23.1.10** **(10-16-2023)**

#### FUTA Reviews - Overview

1. All FUTA mangers are required to conduct the following reviews as applicable:



   - Workload reviews

   - Inventory management

   - Clerical reviews

   - On-the-job reviews

   - Evaluative reviews


2. Reviews are performed by the manager or lead and are performed on tax examiners assigned to their team.

3. Reviews should focus on effective case resolution according to IRM guidelines.

4. Conduct a balance of these reviews throughout the year including a variety of work types.

5. If for some reason reviews cannot be conducted on an employee (for example, extended illness, furlough, managerial absence and so forth), a review **waiver** or other documentation is placed in the Employee Performance File (EPF) explaining why the required number of reviews were not conducted.



### Note:



These waivers must be approved at the department level.


**1.4.23.1.10.1** **(10-09-2024)**

##### Workload Reviews

1. Managers are required to perform a minimum of two workload reviews per quarter for each employee.

2. For Tax Examiners (GS-0592), the workload reviews will consist of one bin review and one time utilization review per quarter per employee.

3. Managers should also review FUTA cases for proper and consistent application of reasonable cause criteria for abatements. All tax examiners should be ensuring that FUTA tax and corresponding Federal Tax Deposit (FTD) penalties are only abated if the taxpayer responds with amended /corrected information, the IRS incorrectly assessed the FUTA tax or the taxpayer meets reasonable cause criteria.

4. The number of reviews should be increased when warranted; for example, when quality results are below the target set for the year. These reviews should include open and closed case reviews.

5. These reviews, as in all case reviews should be documented.


**1.4.23.1.10.2** **(10-16-2023)**

##### Inventory Management Reviews

1. Inventory reviews are applicable for FUTA Lead Tax Examiners, Tax Examiners and Clerks. The purpose of these reviews is for the manager to determine whether the employee is:



1. Handling their work timely and according to established priorities.

2. Managing their inventory appropriately.

3. Following Policy Statement P-21-3 (previously known as Action 61 guidelines) for correspondence handled or interim letter sent within 30 days.

4. Controlling their work as required.

5. Documenting case histories.


2. Managers are responsible for routine and periodic review of each employee’s assigned inventories. This is accomplished through reviewing various types of reports and comparing the information to the employee’s physical and virtual inventory. For successfully achieving program goals and to improve employee satisfaction/engagement, it is critical each employee’s inventories are monitored and that effective performance feedback is provided on an individual case progression, as well as overall inventory management practices.

3. When completing the inventory reviews, ensure:



   - Work is being properly controlled and timely processed in accordance with established guidelines and priorities

   - Aged inventory is maintained at the lowest possible level

   - Barriers to proper case movement are identified and eliminated

   - Technical feedback of the employee’s performance is provided

   - See IRM 1.4.23.1.12, Physical Inventory Reviews, for further instructions on how physical inventory reviews should be conducted


**1.4.23.1.10.3** **(10-16-2023)**

##### Clerical Reviews

1. Clerical employees perform various administrative duties which support the FUTA program. Clerical reviews must address the clerical work processes. The reviews include the following:



   - Timekeeping

   - Mail Receipt and distribution

   - Batch building

   - FCP input

   - Maintenance of files


2. Clerical reviews should focus not only on the employee’s ability to complete their assignments, but also on their ability to set priorities and complete assignments independently and expeditiously. You must conduct Weekly/Monthly reviews to determine the accuracy and timeliness of employees’ work.


**1.4.23.1.10.4** **(10-16-2023)**

##### On-The-Job Reviews

1. Managers will conduct a yearly On-the-Job review to evaluate employees. This review will evaluate employee performance as it relates to:



   - Time Utilization

   - Efficiency

   - Utilization of the IRM

   - Utilization or mandated Integrated Automated Technology (IAT) tools


2. The review will include a time or period when the employee is assigned to work inventory. This review can be performed by directly observing the employee (side-by-side) during a defined period. Typically, this would be a block of time ranging from one to four hours or two complete cases.



### Note:



Perform a minimum of one On-the-Job review per employee each year.


**1.4.23.1.10.5** **(10-16-2023)**

##### Evaluative Reviews

1. Evaluative reviews must be recorded in accordance with the National Agreement established between National Treasury Employees Union (NTEU) and management.

2. Conduct a**_minimum of two evaluative reviews_** for each employee per month.

3. Evaluative reviews must be shared with the employee by a manager or individual in an official acting manager capacity.

4. When conducting reviews, ensure recordation is input into the Embedded Quality Review System (EQRS).

5. Use the Employee Feedback Report on EQRS for sharing evaluative monitoring results. Share results of the review within three workdays. (If incorrect information is given, the results must be shared within eight (8) business hours). Notate the reason on the review sheet if you do not meet these time frames, (i.e., due to unexpected leave, etc.).



### Note:



Provide the applicable IRM references when a defect is identified.

6. Obtain the employee’s acknowledgment on the designated form. Provide one copy to the employee and retain the other copy for the EPF.



### Note:



If the employee refused to sign the review, document that on the review and retain the copy in the EPF.


**1.4.23.1.11** **(10-09-2024)**

#### Program Reviews

1. Headquarters plans to conduct program reviews for each Campus on an as needed basis. The reviews will target recommendations made during the prior visitations, adherence to the IRM and Policy directives, movement of inventory, manager and employee reviews and feedback, and any areas of concern.

2. During the review HQ will:



   - Establish a required action item(s) due date based on recommendation(s) and notate on the final report.

   - Request a signature acknowledging receipt of the final report or retain a read receipt upon issuance of the final report. Retain this information with a copy of the report and all applicable supporting documentation.

   - Retain program review templates along with any documentation or tracking tools utilized during the Federal Unemployment Tax Act (FUTA) Program Review with a copy of the final review.


**1.4.23.1.12** **(10-09-2024)**

#### Physical Inventory Reviews

1. Management must sort the weekly CCA 42-43 report by tax examiner IDRS number. Provide a copy of each listing to the appropriate tax examiner by either printing or sending an electronic copy to them to review weekly. See IRM 1.4.23.1.6.3, Reviewing the CCA 42-43 - IDRS Overage Report. Each tax examiner is responsible to ensure the control assigned to them on IDRS is physically in their possession and can be retrieved at any time. Refer to IRM 4.19.5.4.17, Inventory Management Responsibilities for Tax Examiners

2. In addition, each manager will sign and complete a Quarterly "Physical Inventory Certification" sheet after receiving their employees inventory forms and submit to the Department Manager for consolidation. See Exhibit 1.4.23-4.

3. The clerical team manager must complete a "Wall Inventory" , by running the CCA 42-43 for FUTA, see below:



1. Sort the program listing by age beginning with the earliest received date.

2. Verify each of the cases on the wall to the cases listed on the CCA 42-43.

3. Verify the count in each open batch listed in the log book with the CCA 42-43.

4. Provide the results to the Department Manager.



      ### Note:



      The ORCAS Manager can be utilized to review the CCA report on a weekly basis.


4. The Department Manager will consolidate all tax examiner and the "Wall" physical inventory results, complete the Manager Wall Inventory Sheet(Exhibit 1.4.23-5), and submit to the Operation for signature.

5. The Operation will notify their director’s office this was completed 10 business days following the end of each quarter and provide their office documentation for review.

6. All results of the physical inventory review **must** be shared with the FUTA Coordinator to ensure all necessary actions are taken to update the WP&C.


**Exhibit 1.4.23-1**

### Closed Status Codes

The table below provides the closed status codes and their meaning:

| **CLOSING STATUS CODES** | **MEANING** |
| :-: | :-: |
| 6020b | IRC 6020(b) Secured Return |
| AADJ | Agreed Adjustment |
| BANK | Bankruptcy |
| CADJ | Closed Adjustment |
| CAFE | State Cafeteria Plan |
| CAUE | California Unity Enterprise |
| CDUP | Duplicate Record |
| CMUL | Closed Multi-State |
| CNOC | Closed No Change |
| COMM | Common Paymaster |
| CSYS | Closed by WDC Programmers per HQ Directive |
| NRPY | No Reply Closing |
| UNDL | Undelivered Letter Closing Code |
| CTOL | Closed within Tolerance |
| DFNT | Defunct (Currently Not Collectable) |
| LEAS | Leasing Employers |
| REIM | Reimbursable Employers/Exempt Wages |
| STEX | Statute Expiration |
| TRAN | Transferred |
| REOPEN | Used when a TE opens a case to input corrected information. |
| LTRP | Late Reply correspondence received |
| LTWR | Closing code for Late Reply worked |

**Exhibit 1.4.23-2**

### Profile Descriptions

The table below defines User Profiles and their descriptions:

| **USER** | **PROFILES GRANTED** | **DESCRIPTIONS/DUTIES** | **WHO GRANTS** |
| :-: | :-: | :-: | :-: |
| Site Coordinator | Administrator and Developer | Has the same privileges as the FUTA Coordinator profile and Disaster Coordinator. Additional Duties: Create New User, Set User Inactive, Reset User Password, Unlock User, Delete Users and any system updating. Request Mass 4010C, 4011C letters and Registers (Printed and non-Printed) | Requests must go through the Headquarters Analyst |
| Manager | FUTA Coordinator | Has the same privileges as the FUTA Case Updates, FUTA Clerk, FUTA Research profiles. Other duties requested by Site Coordinator. Also can access system reports. | Administrator/Developer, Coordinator, Requires a BEARS request |
| TE | FUTA Case Updates | This will allow the user to take all actions on a case. (Send letters, close the case, and update various fields). | Administrator/Developer, Coordinator, Requires a BEARS request |
| Clerks | FUTA Clerks | The user can perform clerical functions such as inputting reply dates, late reply dates, build batches, issue letters, or update other fields other than the date fields. | Administrator/Developer, Coordinator, Requires a BEARS request |
| TAS, PAS etc | FUTA Research | Access to FCP for Reports and etc., as needed for research. | Administrator/Developer, Coordinator, Requires a BEARS request |
| Disaster Coordinator | Disaster Coordinator | Has the functions as FUTA Coordinator, Case Update Access, Research, Clerk and can access reports. Inputs and monitors disaster data. | Administrator/Developer, Coordinator, Requires a BEARS request |

**Exhibit 1.4.23-3**

### Download, Inventory Reports, Output Printed and Non-Printed Registers

**Download Reports**

The table below defines the initial download reports.

| **Report** | **Available** | **Purpose** |
| --- | --- | --- |
| \*Bankrupt Report | Initial Download | This report is generated at the initial download and provides a list of cases where the closing codes for the prior Release are Bankrupt (BANK) or Multi-State (CMUL) and there is a corresponding EIN in the current Release. |
| Download Summary Report | Initial Download | This report produces a summary of the MCC download, includes the total records loaded, CAUE and NCUE total records, Audit Potential cases, total potential Statute cases, Letter 4010-C and Letter 4011-C error records and total Duplicate cases. |

### Note:

\\* Cases on these reports need to be resolved up front before work is released for Registers, Letters or Batches assigned to work.

**Inventory Reports**

The table below defines various Inventory Reports.

| **Report** | **Available** | **Purpose** |
| --- | --- | --- |
| Headquarters Inventory Report | Weekly Report generated every Monday and given to OPS and DM | Report provides a count of Letter 4010-C and Letter 4011-C , Zero Certs, PARS and Schedule H inventory. The report shows the volume of Receipts, Closures, Screening Closures and Late Reply Closures during a weekly period and cumulative count. There is also a volume amount for Unassigned, Assigned No Correspondence, Assigned Reply, Assigned Undeliverable and Assigned No Reply. |
| Correspondence Report | Weekly Report generated every Monday and given to OPS and DM. | Correspondence Report provides a count of Letter 4010-C, Letter 4011-C and Letter 380-C from a beginning and ending date. The report shows the volumes of correspondence Mailed, Replies, No Replies and Undeliverables during a weekly period and cumulative count. |
| Potential Register/Mass Inventory | Generated by CRON on Saturday and generated on Monday. | Counts by State from the initial download to the current date, the amount of records available to order and what was ordered for Printed Registers, Non-Printed Registers, Mass Letter 4010-C and Mass Letter 4011-C. Coordinator uses this report for mass generation of Correspondence and Registers. |
| Statute Report | Weekly or as needed. Generate report after initial download to work statute imminent cases expiring within 90 days. This report is critical to inventory management and should be monitored weekly. As PCD nears this report should be run every day. | This report provides a listing of all open potential Statute cases by Statute Expiration Date and show if the case is in a TE’s inventory. The report should be given to the manager for tracking statute cases to ensure adjustments are made timely to avoid any barred statutes. |
| TE Age Listing | Weekly | Provides a list of all aged cases assigned to TE(s). Site coordinator generates and distributes to the team managers for monitoring TE inventory. |
| \*Duplicate EIN List | Weekly | There are FUTA records downloaded with Duplicate DLN’s. The cases on this listing need to be resolved before Mass Generating Registers, Letters or Batches to be worked. Follow procedures in IRM 4.19.5, Certification of State FUTA Credits. |
| No Activity | Weekly or as needed. | This report is utilized to notify the manager of records with no activity. The report is sorted by State and Case ID order. The report needs to be monitored ensuring all records have been worked to avoid barred statutes. |
| Screening Closure | Daily | Provides a list of the previous day’s closures<br> <br>### Note:<br>Monday’s report will include Friday, Saturday and Sunday<br> . |
| Weekly Status Report or Closed Case Report | Weekly | Lists the number of cases closed between beginning and ending date. This report summarizes the number of records associated with each status code by State. |

### Note:

\\* Cases on these reports need to be resolved up front before work is released for Registers, Letters or Batches assigned to work.

**Output Printed Reports**

The table below defines Output Printed Reports.

| **Report** | **Available** | **Purpose** |
| --- | --- | --- |
| Form 940-B Report | Weekly-Requests are input daily, coordinator prints on Monday and then mails to the State Agencies. | User requests a Form 940-B for Verification of Credit Information. Output is sorted and printed by the TC150 State Code and a cover sheet has the State Agency address where the forms are to be mailed and the volume of requests being sent. |
| No Reply | Weekly- When the Suspense Period has expired, Reply Date not entered, the case is automatically identified as a No Reply, coordinator prints on Monday. | This process produces a Source Document for each case that goes No Reply on a weekly basis. One case is printed per page. The document is printed out as part of the No Reply and contains the money amounts for future reference in case of judicial circumstances. |
| Potential Register/Mass Inventory Order Registers Report for Zero Certs, CAUE and NCUE | Daily- Registers can be printed after the system has completed the generation of the request. | Using the Mass Inventory Report, the coordinator will request the Zero Certs for CAUE and NCUE cases after all the initial updates have been completed (Statutes, DUP DLN/EIN and Bankruptcy). Mail the Certs to California and North Carolina as soon as possible. When the Certs are returned, the state account number needs to be input on FCP before proceeding with any California or North Carolina processes.<br> <br>### Note:<br>If there are huge volumes for one state, (check a couple of records to see if there is a problem with any of the data), contact the state and let them know the volume that will be sent. |
| Potential Register/Mass Inventory-Letter 4010-C | Weekly- CRON will generate the letters on Monday and send the request to the Print site. | Using the Potential Register/Mass Inventory Report, the coordinator will order the Letter 4010-C by state and volume. The report shows inventory available to order and what amount has been requested. The volume of letters sent will also include the TE’s manual input of letters for the week.<br> <br>### Note:<br>Do not request a mass mailing of letters to California or North Carolina until the state account numbers have been input and the UE Indicator has been updated. |
| Potential Register/Mass Inventory-Letter 4011-C | Weekly- CRON will generate the letters on Monday and send the request to the Print site. | Using the Potential Register/Mass Inventory Report, the coordinator will order the Letter 4011-C by state and volume. The report shows inventory available to order and what amount has been requested. The volume of letters sent will also include the TE’s manual input of letters for the week.<br> <br>### Note:<br>Do not request a mass mailing of letters to California or North Carolina until the state account numbers have been input and the UE Indicator has been updated. |

### Note:

\\* Cases on these reports need to be resolved up front before work is released for Registers, Letters or Batches assigned to work.

**Non-Printed Registers (PARS)**

The table below defines Non-Printed Registers (PARS) Reports.

| **Report** | **Available** | **Purpose** |
| --- | --- | --- |
| Potential Registers/Mass Inventory-Order Non-Printed Register Report | Daily- Registers can be batched after the system has completed the generation of the request. | Using the Potential Register/Mass Inventory Report, the coordinator will request PARS by state and volume after which FCP will automatically batch the cases.<br> <br>### Note:<br>Do not request PARS to California or North Carolina until the state account numbers have been input and the UE Indicator has been updated. |
| Potential Registers/Mass Inventory-Order CAUE and NCUE Non-Printed Registers Report | Daily- Registers can be batched after the system has completed the generation of the request. | Using the Potential Register/Mass Inventory Report, the coordinator will request CAUE and NCUE PARS by state and volume after which FCP will automatically batch the cases.<br> <br>### Note:<br>Do not request PARS to California or North Carolina until the state account numbers have been input and the UE Indicator has been updated. |

### Note:

\\* Cases on these reports need to be resolved up front before work is released for Registers, Letters or Batches assigned to work.

**Exhibit 1.4.23-4**

### Physical Inventory Certificate

| Tax Examiner Name: |
| --- |
| IDRS Number: |
| Date of CCA 4243: |
| Number of cases listed on your CCA 4243: |

| **Action Taken** | **Yes/No** |
| :-: | :-: |
| Verify received dates are correct. | Yes/No |
| Verify case was classified as correct program. | Yes/No |
| Correct MFT Code, activity and category was input. | Yes/No |
| If case is missing, have followed the missing case procedures? | Yes/No |
| Ensured all appropriate interim letters have been issued. | Yes/No |
| Verified need for STAUPS and input if necessary. | Yes/No |
| Ensured you are working your cases in **FIFO (First In First Out) order**. | Yes/No |
| Are cases in correct status? (A-Assigned, M-Monitored, S-Suspense, etc.) | Yes/No |

| **Program (IRS-CAWR, SSA, FUTA)** | **Number of cases** |
| :-: | :-: |
| Cases listed on your CCA 4243 | Number of Cases |
| Missing | Number of Cases |
| Closed | Number of Cases |
| Added (newly controlled) | Number of Cases |
| **TOTAL** | Number of Cases |

| Number of cases currently in your possession: |
| --- |
| I certify I have taken all actions stated above: |
| Print Name: |
| Sign Name: |
| Date: |

**Exhibit 1.4.23-5**

### Wall Inventory Instruction and Certification

| Print Name: |
| --- |
| Sign Name: |
| Date: |
| **Wall Inventory Instruction and Certification** |

Run the CCA 4243 by program (IRS-CAWR/SSA/FUTA). Each of the program listings will then be sorted by age beginning with the earliest received date. This will now simplify the process to verify each of the cases on your wall to the cases listed on the CCA 4243 for the entire Operation.

By program, verify the count in each open batch listed in the log book matches with the CCA 4243.

| **Program (IRS-CAWR, SSA, FUTA)** | **Number of Cases** |
| --- | --- |
| Cases listed on your CCA 4243 | Number of Cases |
| Missing | Number of Cases |
| Closed | Number of Cases |
| Added (Newly Controlled) | Number of Cases |
| **Total** | Number of Cases |

I certify I have reviewed the process used to complete this physical inventory and am confident it reflects true volumes currently in the Operation. I certify the actions taken by the tax examiners are correct and warranted.

| Department Manager Signature: |
| --- |
| Date: |

| Operation Manager Signature: |
| --- |
| Date: |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-023#addtoany "Show all")

A2A