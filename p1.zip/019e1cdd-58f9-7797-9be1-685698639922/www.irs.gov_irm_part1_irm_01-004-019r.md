---
url: "https://www.irs.gov/irm/part1/irm_01-004-019r"
title: "1.4.19 Automated Underreporter Technical and Clerical Managers and Coordinators Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-019r#main-content)

- 1.4.19  [Automated Underreporter Technical and Clerical Managers and Coordinators Guide](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701689216)
  - 1.4.19.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734609488)
    - 1.4.19.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707765216)
    - 1.4.19.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707763312)
    - 1.4.19.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707760816)
    - 1.4.19.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701661008)
    - 1.4.19.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701658752)
    - 1.4.19.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734524224)
    - 1.4.19.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734522080)
  - 1.4.19.2  [Overview](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706381072)
    - 1.4.19.2.1  [AUR System Problem Reporting Procedures](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734601840)
    - 1.4.19.2.2  [Policy Statement P-21-3 Guidelines](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734599344)
    - 1.4.19.2.3  [Archived Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707694352)
    - 1.4.19.2.4  [Spousal Notices](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707691808)
    - 1.4.19.2.5  [Statute of Limitations](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707689296)
    - 1.4.19.2.6  [Balanced Measurement System](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734526736)
    - 1.4.19.2.7  [Maintaining Documents In AUR](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701578336)
    - 1.4.19.2.8  [Integrated Automation Technologies (IAT)](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701575664)
    - 1.4.19.2.9  [Managerial Approval for Accuracy Related Penalties](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734543296)
  - 1.4.19.3  [Controlling Work - Batch and Case Overview](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707682272)
    - 1.4.19.3.1  [Batch Types](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734650560)
      - 1.4.19.3.1.1  [Requesting Batches](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701495344)
      - 1.4.19.3.1.2  [Canceling Batches](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706498416)
      - 1.4.19.3.1.3  [Releasing Batches](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734619504)
    - 1.4.19.3.2  [Work Units - General](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734551328)
      - 1.4.19.3.2.1  [Assigning Work Units](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734549584)
      - 1.4.19.3.2.2  [Reassigning Work Units](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707700080)
      - 1.4.19.3.2.3  [Transferring Work Units](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706319536)
      - 1.4.19.3.2.4  [Releasing Work Units](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706525856)
    - 1.4.19.3.3  [Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706509056)
      - 1.4.19.3.3.1  [Assigning Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706508160)
      - 1.4.19.3.3.2  [Releasing Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053734765856)
        - 1.4.19.3.3.2.1  [Releasing Cases through Universal Work](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702215808)
      - 1.4.19.3.3.3  [Transferring Cases to Unit Suspense](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707673952)
      - 1.4.19.3.3.4  [Updating Transferred Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707663040)
      - 1.4.19.3.3.5  [Requesting Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707651376)
        - 1.4.19.3.3.5.1  [Requesting Cases through Universal Work](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702142912)
      - 1.4.19.3.3.6  [Accepting Transferred Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702133280)
      - 1.4.19.3.3.7  [Viewing Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702120656)
      - 1.4.19.3.3.8  [Reassigning Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702107744)
      - 1.4.19.3.3.9  [Restoring Work Units](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702096768)
  - 1.4.19.4  [Telephones - Toll Free](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702084736)
    - 1.4.19.4.1  [Manager Calls](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702081488)
      - 1.4.19.4.1.1  [Manager Calls - Taking a Call](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702075920)
      - 1.4.19.4.1.2  [Distressed/Angry Customers](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702058800)
      - 1.4.19.4.1.3  [Telephone Threat Procedures](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701492432)
      - 1.4.19.4.1.4  [Suicide Threats](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701481952)
      - 1.4.19.4.1.5  [Compliments and Complaints](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701460720)
    - 1.4.19.4.2  [Telephone Call Reviews](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701458304)
  - 1.4.19.5  [Taxpayer Digital Communications (TDC) in AUR](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701451888)
    - 1.4.19.5.1  [Procedures for Reviewing Outbound Messages](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701449488)
    - 1.4.19.5.2  [Manager Procedures for Reviewing Outbound Messages](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701439824)
    - 1.4.19.5.3  [Transferring eGain Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701434480)
  - 1.4.19.6  [Compliance Manager's Reviews - General](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701416192)
    - 1.4.19.6.1  [Review of Form 3210 Acknowledgement](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701410176)
    - 1.4.19.6.2  [Non-Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701408208)
    - 1.4.19.6.3  [Mandatory Reviews - AUR](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701404320)
  - 1.4.19.7  [AUR Quality Review - General](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701395184)
    - 1.4.19.7.1  [Individual Quality Review](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701389024)
      - 1.4.19.7.1.1  [Reviewing Quality Errors](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701380256)
    - 1.4.19.7.2  [Managerial Individual Review](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701377536)
    - 1.4.19.7.3  [Unit Reviews](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701368304)
    - 1.4.19.7.4  [Notice Reviews](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701361344)
  - 1.4.19.8  [Payer Agent Coordinator](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701345072)
    - 1.4.19.8.1  [Payer Agent/Fraud Coordinator Screens](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701339696)
  - 1.4.19.9  [Monitoring and Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701291056)
    - 1.4.19.9.1  [Reports - General](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701275440)
      - 1.4.19.9.1.1  [Accessing Reports, and Listings](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701261840)
    - 1.4.19.9.2  [Batch Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701245088)
      - 1.4.19.9.2.1  [Complete Batch Inventory Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701241568)
      - 1.4.19.9.2.2  [Batch Listings](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701187792)
        - 1.4.19.9.2.2.1  [Sequence Number-SSN-PC Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053701151632)
        - 1.4.19.9.2.2.2  [PC-Sequence Number-SSN Batch Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707075280)
        - 1.4.19.9.2.2.3  [Sequence Number-SSN Batch Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707068912)
      - 1.4.19.9.2.3  [Batch Released Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707064576)
    - 1.4.19.9.3  [Cases In Error Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707051664)
    - 1.4.19.9.4  [Clerical Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707021664)
      - 1.4.19.9.4.1  [Address Update Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053707009632)
      - 1.4.19.9.4.2  [Aging Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706992816)
      - 1.4.19.9.4.3  [Disassembled/Age Batch Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706975856)
      - 1.4.19.9.4.4  [Completed Case Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706957424)
      - 1.4.19.9.4.5  [Suspense Aged Batch Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706945344)
      - 1.4.19.9.4.6  [Partially Agreed Aging Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706931584)
      - 1.4.19.9.4.7  [Stat Not Generated Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706919392)
      - 1.4.19.9.4.8  [Auto Purge Pull List](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706904800)
      - 1.4.19.9.4.9  [Auto Purge Batch](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706888224)
      - 1.4.19.9.4.10  [Rb Batches](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706873728)
      - 1.4.19.9.4.11  [Auto Assessment Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706861344)
      - 1.4.19.9.4.12  [Check Notice/Letter Date Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706843264)
      - 1.4.19.9.4.13  [Closed Research Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706831312)
        - 1.4.19.9.4.13.1  [Closed Missing Data Case Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706818144)
        - 1.4.19.9.4.13.2  [Unavailable Return Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706806160)
      - 1.4.19.9.4.14  [Disaster CSN/SSN Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706792656)
      - 1.4.19.9.4.15  [Lost Case Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706777280)
      - 1.4.19.9.4.16  [Misc Letter Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706755840)
      - 1.4.19.9.4.17  [New Payer Agent Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706744928)
      - 1.4.19.9.4.18  [New Transactions Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706732080)
      - 1.4.19.9.4.19  [Pull Listings](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706720352)
      - 1.4.19.9.4.20  [Return Charge-out](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706705168)
      - 1.4.19.9.4.21  [Reworked Case Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706694624)
      - 1.4.19.9.4.22  [RLS Batch Status Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706683824)
      - 1.4.19.9.4.23  [Digital Images](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706667536)
      - 1.4.19.9.4.24  [Undeliverable Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706641776)
    - 1.4.19.9.5  [Coordinator Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706630480)
      - 1.4.19.9.5.1  [Action 61 Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706620592)
      - 1.4.19.9.5.2  [Auto Notice Results Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706607616)
      - 1.4.19.9.5.3  [Batch IRS Received Date Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706591456)
      - 1.4.19.9.5.4  [Batch Run By Site](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706578048)
      - 1.4.19.9.5.5  [Missing Assessment Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706564432)
      - 1.4.19.9.5.6  [NoticeMailout Dates Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053706549312)
      - 1.4.19.9.5.7  [Open Case Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705173632)
      - 1.4.19.9.5.8  [Re-Order Dates Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705160048)
      - 1.4.19.9.5.9  [Soft Notice Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705149680)
      - 1.4.19.9.5.10  [Statistical Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705139520)
      - 1.4.19.9.5.11  [Weekly Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705128448)
        - 1.4.19.9.5.11.1  [Non-Stat Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705113232)
        - 1.4.19.9.5.11.2  [Inventory Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705097728)
        - 1.4.19.9.5.11.3  [Weekly PC/IPC Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705080592)
        - 1.4.19.9.5.11.4  [Aged Screening Research Pull List](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705066672)
        - 1.4.19.9.5.11.5  [Open Transfer Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705052288)
        - 1.4.19.9.5.11.6  [Aged Response Batch Summary Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705036832)
        - 1.4.19.9.5.11.7  [Notice/Letter Suspense Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053705015680)
        - 1.4.19.9.5.11.8  [Extract Category Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704999760)
        - 1.4.19.9.5.11.9  [Statute Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704987328)
        - 1.4.19.9.5.11.10  [Reject Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704969968)
        - 1.4.19.9.5.11.11  [PC Status Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704947424)
        - 1.4.19.9.5.11.12  [MISTLE Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704932752)
        - 1.4.19.9.5.11.13  [MISTLE XCL Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704916352)
    - 1.4.19.9.6  [Specialized Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704902464)
      - 1.4.19.9.6.1  [Action Required](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704900896)
      - 1.4.19.9.6.2  [AN (Auto Notice) Reviewing Sampling](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704875280)
      - 1.4.19.9.6.3  [Batch Suspense Inventory Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704860688)
      - 1.4.19.9.6.4  [Bankruptcy](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704846400)
      - 1.4.19.9.6.5  [Employee Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704834128)
        - 1.4.19.9.6.5.1  [Auto Assessment Report - Employee Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704820944)
        - 1.4.19.9.6.5.2  [Closed Inventory - Employee Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704817376)
        - 1.4.19.9.6.5.3  [Employee Aging Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704814288)
        - 1.4.19.9.6.5.4  [Open Inventory Report - Employee Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704810704)
        - 1.4.19.9.6.5.5  [Open Transfers - Employee Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704807216)
      - 1.4.19.9.6.6  [IDT Suspense Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704803888)
      - 1.4.19.9.6.7  [MFT 31 Inventory Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704789376)
      - 1.4.19.9.6.8  [Payer Agent List](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704775040)
      - 1.4.19.9.6.9  [Recon Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704760944)
        - 1.4.19.9.6.9.1  [Recon - Open Inventory](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704759280)
        - 1.4.19.9.6.9.2  [Recon - Closed Inventory](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704743904)
        - 1.4.19.9.6.9.3  [Recon - Issue Listing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704730720)
      - 1.4.19.9.6.10  [Review Sampling - Product Review Sample List](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704716496)
    - 1.4.19.9.7  [Restricted Case Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704704016)
    - 1.4.19.9.8  [TDC Notice Suppression](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704688320)
    - 1.4.19.9.9  [Telephone Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704674160)
      - 1.4.19.9.9.1  [Telephone Case Callout](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704670848)
      - 1.4.19.9.9.2  [Telephone Tracking Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704657680)
    - 1.4.19.9.10  [Unit Inventory Report](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704645728)
    - 1.4.19.9.11  [Universal Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704622928)
      - 1.4.19.9.11.1  [Universal Work (UW) Suspense](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704619600)
      - 1.4.19.9.11.2  [UC Closed](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704603680)
    - 1.4.19.9.12  [Batch History](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704590784)
    - 1.4.19.9.13  [Case History](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704580544)
    - 1.4.19.9.14  [Unassociated Cases](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704556304)
  - 1.4.19.10  [Non AUR System Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704543328)
    - 1.4.19.10.1  [IDRS Case Monitoring Reports (Control D)](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704541104)
    - 1.4.19.10.2  [IDRS CCA 4243](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704535760)
    - 1.4.19.10.3  [Overage Report Compiler And Sorter (ORCAS) Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704525072)
    - 1.4.19.10.4  [Control D - Statutory Notice of Deficiency](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704514128)
  - 1.4.19.11  [Secure Messaging Taxpayer Digital Communication (TDC) Searches](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704507392)
  - 1.4.19.12  [Security](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704503904)
    - 1.4.19.12.1  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704502720)
    - 1.4.19.12.2  [Logins, Passwords and Single Employee Identification (SEID)](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704492480)
    - 1.4.19.12.3  [Unauthorized SSN Access](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704463936)
    - 1.4.19.12.4  [Locking/Unlocking SEIDs](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704460032)
      - 1.4.19.12.4.1  [AUR Inactivity Lock](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704451136)
    - 1.4.19.12.5  [Profile Codes and Limitations](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704449296)
    - 1.4.19.12.6  [Status Codes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704417264)
    - 1.4.19.12.7  [User Administration Screen Tabs](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704412816)
      - 1.4.19.12.7.1  [User Tab](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704408320)
        - 1.4.19.12.7.1.1  [Adding/Reactivating Users](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704401808)
        - 1.4.19.12.7.1.2  [Updating and Deleting Users](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704374768)
        - 1.4.19.12.7.1.3  [Changing a User’s Unit Location Number](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704359136)
      - 1.4.19.12.7.2  [History Tab – Researching User History](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704338512)
      - 1.4.19.12.7.3  [Group Tab](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704328816)
      - 1.4.19.12.7.4  [Audit Tab - Displaying Audit Trail Information](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704319952)
      - 1.4.19.12.7.5  [Unit Tab - Updating the Unit Information Table (AUR Coordinator Only)](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704285424)
      - 1.4.19.12.7.6  [New Loc Tab (AUR Coordinator Only)](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704244816)
      - 1.4.19.12.7.7  [Profile Limits Tab](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704235424)
    - 1.4.19.12.8  [Security Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704231952)
      - 1.4.19.12.8.1  [Current Access](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704228608)
      - 1.4.19.12.8.2  [Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704226112)
        - 1.4.19.12.8.2.1  [Profile Code Reports](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704222096)
        - 1.4.19.12.8.2.2  [AUR User List](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704206448)
  - 1.4.19.13  [AUR Coordinator](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704188464)
    - 1.4.19.13.1  [Coordinator Actions Needed For Tax Year Startup](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704183696)
    - 1.4.19.13.2  [Coordinator Actions Needed For Tax Year Closeout/Shutdown](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704176176)
    - 1.4.19.13.3  [AUR Coordinator Screens](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704164224)
      - 1.4.19.13.3.1  [Notice Mailout Dates](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704152752)
      - 1.4.19.13.3.2  [Batch Parameters](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704121648)
      - 1.4.19.13.3.3  [Control Parameters](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704105952)
      - 1.4.19.13.3.4  [Update Letter Parameters](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704035712)
      - 1.4.19.13.3.5  [Local Correspondex Letter Paragraphs](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053704000192)
      - 1.4.19.13.3.6  [Update Reorder Date](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703967792)
      - 1.4.19.13.3.7  [Disaster Case Processing](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703950464)
      - 1.4.19.13.3.8  [Run Controls](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703947056)
    - 1.4.19.13.4  [Delete Process Codes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703821632)
    - 1.4.19.13.5  [Message of the Day](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703808848)
    - 1.4.19.13.6  [Computer-Generated Interest for the CP 2000 Notice](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703775664)
    - 1.4.19.13.7  [Unlocated Returns or Source Documents](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703773216)
    - 1.4.19.13.8  [IDRS Case Control](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703771280)
    - 1.4.19.13.9  [Charge-outs (Form 4251, Return Charge-Out)](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703763152)
    - 1.4.19.13.10  [Suspense Files Timeframes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703759360)
      - 1.4.19.13.10.1  [CP 2501 Timeframes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703752160)
      - 1.4.19.13.10.2  [CP 2000 Timeframes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703745760)
      - 1.4.19.13.10.3  [Statutory Notice Timeframes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703739456)
    - 1.4.19.13.11  [Manual Statutory Notices](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703731744)
    - 1.4.19.13.12  [Disclosure to State Tax Agencies](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703726400)
    - 1.4.19.13.13  [Print Consolidation](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703722416)
  - Exhibit  1.4.19-1  [Glossary and Abbreviations](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703716752)
  - Exhibit  1.4.19-2  [AUR Internal Process Codes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703571216)
  - Exhibit  1.4.19-3  [AUR Process Codes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703500896)
  - Exhibit  1.4.19-4  [Error Condition-Cause-Corrective Action Chart](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703363440)
  - Exhibit  1.4.19-5  [Notice Generation Timeframe Chart](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703327680)
  - Exhibit  1.4.19-6  [AUR Reports Matrix](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703317120)
  - Exhibit  1.4.19-7  [AUR Runs](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703303344)
  - Exhibit  1.4.19-8  [AUR Task Codes](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703151888)
  - Exhibit  1.4.19-9  [AUR Category Code Descriptions/Chart](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053703049760)
  - Exhibit  1.4.19-10  [Report access for AUR Users](https://www.irs.gov/irm/part1/irm_01-004-019r#idm140053702939872)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 19. Automated Underreporter Technical and Clerical Managers and Coordinators Guide

* * *

## 1.4.19 Automated Underreporter Technical and Clerical Managers and Coordinators Guide

#### Manual Transmittal

March 04, 2025

#### Purpose

(1) This transmits revised IRM 1.4.19, Resource Guide for Managers, Automated Underreporter Technical and Clerical Managers and Coordinators Guide.

#### Material Changes

(1) Throughout the IRM underlines have been removed from AUR System hot keys and letters and are now bold

(2) Throughout the IRM Action 61 is changed to P-21-3 Policy Statement

(3) IRM 1.4.19.1.1(1) - revised Background statement

(4) IRM 1.4.19 1.3 - Title revised to Roles and Responsibility

(5) IRM 1.4.19.1.4 - new subsection for Program and Management Reviews

(6) IRM 1.4.19.1.5 - new subsection for Program controls

(7) IRM 1.4.19.1.7 - new subsection for Related Resources

(8) IRM 1.4.19.2(2) removed documents in W-2 series, removed (3) Form 1099 table, removed (4) Schedules in K-1 series, removed (5) other documents not required

(9) IRM 1.4.19.2(7) - added new c) Screening must be released by HQ, e) revised to; paper returns are uploaded using scanning

(10) IRM 1.4.19.2.1(1) - added reminder for HQ business hours and link for after hours procedures

(11) IRM 1.4.19.2.5 - revised for clarification and routing procedures of Form 3552

(12) IRM 1.4.19.3.1(1) - revised to 01-26, (20) removed BT47 and definition, (26) removed note

(13) IRM 1.4.19.3.1(45) - removed TY 2012, and BT 81 is segmented, removed a) and b) Batch Type 81001 - 81499 definition and Batch Type 81500 - 81949 definition

(14) IRM 1.4.19.3.1.2(2)8) - removed note for TY 2021 Digitized Batch Window

(15) IRM 1.4.19.3.1.3(2)8) - removed note for TY 2021 Digitized Batch Window

(16) IRM 1.4.19.3.1.3(3) - removed alpha listing and added table for error codes and definitions

(17) IRM 1.4.19.3.3.2(2) - removed table, step 6) and 7), added new (3) with steps 1-3 for system checks

(18) IRM 1.4.19.3.3.2.1(2) - removed table, step 6) and 7), added new (3) with steps 1-3 for system checks

(19) IRM 1.4.19.3.3.5.1(1) - removed BT 47, added BT 96 can be requested to work through View Case

(20) IRM 1.4.19.4.1 - removed for Aceyus Reporting subsection, renumbered remaining subsections

(21) IRM 1.4.19.4.2 - removed Bringing up the Phone System subsection, renumbered remaining subsections

(22) IRM 1.4.19.4.3 - removed End of Day/Shift Activities subsection, renumbered remaining subsections

(23) IRM 1.4.19.4.4 - removed Call Demand Forecast subsection, renumbered remaining subsections

(24) IRM 1.4.19.4.4.1 - removed Scheduling for Call Demand subsection, renumbered remaining subsections

(25) IRM 1.4.19.4.4.2 - removed Scheduling Staff subsection, renumbered remainder of subsections

(26) IRM 1.4.19.4.5 - removed Adherence to Schedule subsection, renumbered remaining subsections

(27) IRM 1.4.19.4.7 - removed Telephone Security subsection, renumbered remaining subsections

(28) IRM 1.4.19.4.9 - removed Track Telephone Time Reporting subsection, renumbered remaining subsections

(29) IRM 1.4.19.4.10 - removed Telephone Reports and Monitoring subsection, renumbered remaining subsections

(30) IRM 1.4.19.4.10.1 - removed ETD AHT Team Agent Application Report subsection, renumbered remaining subsections

(31) IRM 1.4.19.4.10.2 - removed Daily Availability/Shortage Log subsection, renumbered remaining subsections

(32) IRM 1.4.19.4.13 - removed Telephone UCCE System subsection, renumbered remaining subsections

(33) IRM 1.4.19.4.13.1 - removed Troubleshooting General Problems subsection, renumbered remaining subsections

(34) IRM 1.4.19.4.14 - removed Reporting to the Telephone System Analyst (TSA)

(35) IRM 1.4.19.5.1(3),(4),(5) and (6) - revised instructions to match the eGain system

(36) IRM 1.4.19.5.3(2) and (3),(4) - revised to match eGain system

(37) IRM 1.4.19.9.1.1- Revised title to Accessing Reports, and Listings

(38) IRM 1.4.19.9.2.1 - revised subsection to add digital response indicator and batch IRS received date

(39) IRM 1.4.19.9.2.2(1) - removed note,(10) removed Exception

(40) IRM 1.4.19.9.2.2.1(1) added note for reconsiderations (2) clarified to match AUR system

(41) IRM 1.4.19.9.2.2.2 - section clarified to match AUR system

(42) IRM 1.4.19.9.2.2.3 - (1) bullet added for Auto Notice to match the system report

(43) IRM 1.4.19.9.3(5) - revised to add table for error codes and definitions

(44) IRM 1.4.19.9.4.3(2) - added note for virtual indicator

(45) IRM 1.4.19.9.4.7(3) - revised to match system report

(46) IRM 1.4.19.9.4.9(2) - added to match the report headings

(47) IRM 1.4.19.9.4.10(1) - added listing identifies system built BT 84

(48) IRM 1.4.19.9.4.12(1) - added listing to match the AUR system report

(49) IRM 1.4.19.9.4.17(1) - added listing to match the AUR system report

(50) IRM 1.4.19.9.4.18 - revised title to New Transactions Report

(51) IRM 1.4.19.9.4.19(1) - added listing to match the AUR system report

(52) IRM 1.4.19.9.4.23 - revised subsection to clarify scanned images and listing report to match the AUR system

(53) IRM 1.4.19.9.5.2 - revised subsection to provide listing report to match the AUR system

(54) IRM 1.4.19.9.5.5 (2) - revised to clarify posted and not posted assessments.

(55) IRM 1.4.19.9.5.6(2) - added listing to match the AUR system report

(56) IRM 1.4.19.9.5.7(2) - added listing to match the AUR system report

(57) IRM 1.4.19.9.5.8(2) - added listing to match the AUR system report

(58) IRM 1.4.19.9.5.9(1) - added availability of soft notices

(59) IRM 1.4.19.9.5.11.3(2) - added listing to match the AUR system report

(60) IRM 1.4.19.9.5.11.6(1) - added note for volumes on summary page, added new (5) and (6), removed (7)

(61) IRM 1.4.19.9.5.11.7(1) and (2) - added listing to match the AUR system report, removed (4)

(62) IRM 1.4.19.9.5.11.8 - revised title to Extract Category Listing

(63) IRM 1.4.19.9.5.11.9(2) - added listing to match the AUR system report

(64) IRM 1.4.19.9.5.11.11(2) - added listing to match the AUR system report

(65) IRM 1.4.19.9.5.11.12(2) - added listing to match the AUR system report

(66) IRM 1.4.19.9.6(1)a - added Action required to match the AUR system report

(67) IRM 1.4.19.9.6.1 - new subsection for Action Required

(68) IRM 1.4.19.9.6.3 - removed MFT 31 inventory to put subsection in the order as shown on the system

(69) IRM 1.4.19.9.6.4 - removed Bankruptcy to put subsection in the order as shown on the system

(70) IRM 1.4.19.9.6.5 - Revised title to Batch Suspense Inventory Report

(71) IRM 1.4.19.9.6.6 - new subsection for Bankruptcy

(72) IRM 1.4.19.9.6.7.1 - new subsection for Auto Assessment Report - Employee Cases

(73) IRM 1.4.19.9.6.7.2 - new subsection for Closed Inventory - Employee Cases

(74) IRM 1.4.19.9.6.7.3 - new subsection for Employee Aging Report

(75) IRM 1.4.19.9.6.7.5 - new subsection for Open Transfers - Employee Cases

(76) IRM 1.4.19.9.6.7.6 - IRM 1.4.19.9.6.7.9 - removed and put in order as shown on the AUR system

(77) IRM 1.4.19.9.6.9 - new subsection for MFT 31 Inventory report

(78) IRM 1.4.19.9.11.2(1) - added clarification for Recon process code

(79) IRM 1.4.19.9.7 - added report tab titles

(80) IRM 1.4.19.9.8 - removed TY 2021 and TDC Notice suppression box

(81) IRM 1.4.19.9.10 - revised subsection to match the system report

(82) IRM 1.4.19.9.11(1) - revised to include new reports

(83) IRM 1.4.19.9.11.1 - new subsection for Universal Work(UW) Suspense

(84) IRM 1.4.19.9.11.2 - new subsection for UC Closed

(85) IRM 1.4.19.9.11.3 - removed subsection for Universal View Case Action Listing

(86) IRM 1.4.19.9.11.4 - removed subsection for UVC Activity Report

(87) IRM 1.4.19.9.14 - new subsection for Unassociated Cases

(88) IRM 1.4.19.11 - removed Work planning and control section, renumbered remaining sections

(89) IRM 1.4.19.11 - new subsection for Secure Messaging (TDC) Searches

(90) IRM 1.4.19.12.3 - removed Locking and unlocking terminals

(91) IRM 1.4.19.12.5.1 - added 30 minutes for no activity and close browser and login again

(92) IRM 1.4.19.12.7 - removed (R) reactivated and note for Status R

(93) IRM 1.4.19.12.8.1.1 - (3) - add new 19) to click on TDC field

(94) IRM 1.4.19.12.8.1.3(2)8) - added note to Use the Change to site drop-down menu

(95) IRM 1.4.19.12.8.4 - revised section to include updates to AUR system

(96) IRM 1.4.19.13.3.8 - revised title to Run Controls

(97) IRM 1.4.19.13.10(1)J) - removed note to verify age stat notices

(98) Exhibit 1.4.19-2 - remove table under Identity theft and added information to Miscellaneous - Open Case table

(99) Exhibit 1.4.19-10 - removed table for Batch Status Codes

(100) Exhibit 1.4.19.-11- removed Mandated IAT tools

(101) Exhibit 1.4.19-12 - removed Additional IAT Tools

#### Effect on Other Documents

This material supersedes IRM 1.4.19 dated November 21, 2023.

#### Audience

AUR Managers and Coordinators at the Small Business/Self-Employed AUR sites.

#### Effective Date

(03-04-2025)

Heather J. Yocum

Director, Examination Field and Campus Policy

Small Business/Self-Employed

**1.4.19.1** **(10-20-2017)**

### Program Scope and Objectives

1. Purpose - This IRM describes technical guidance for the Small Business/Self Employed (SB/SE), Individual Master File (IMF) Automated Underreporter Program (AUR). Specifically, this IRM includes guidance for technical and clerical managers and AUR Coordinators for controlling work, quality measures, monitoring, reporting, and security measures in the AUR Program.

2. Audience - The information and procedures in this IRM apply to technical and clerical Managers and Coordinators at the Small Business/Self-Employed AUR sites.

3. Policy Owner - The IMF AUR Program is under SB/SE Examination Field and Campus Policy.

4. Program Owner - IMF AUR Policy, under Exam Field and Campus Policy, is responsible for providing procedures to work the IMF AUR Program and for oversight of the AUR system.

5. Primary Stakeholders - The primary stakeholders are those in the IMF AUR Program.

6. Program Goals - Program goals for this type of work is to monitor inventory to be worked within specific time frames.


**1.4.19.1.1** **(03-04-2025)**

#### Background

1. This IRM provides instructions for Automated Underreporter (AUR) managers (Technical and Clerical) and coordinators to control the flow of work, perform managerial reviews, and generate reports to monitor inventory. Managers verify errors found by review, ensure corrective actions are taken, monitor security reports, and keep the user data updated on the AUR System, ensuring proper security procedures are followed.


**1.4.19.1.2** **(10-20-2017)**

#### Authority

1. Chapter 61 of the Internal Revenue Code (Information and Returns), Subchapter A (Records and Returns), Part III (Information Returns), sections 6031 – 6059, contain the requirements for the filing of information returns for income reporting purposes. Rev. Proc. 2005-32 identifies taxpayer contacts to verify a discrepancy between the taxpayer’s tax return and an information return, or between a tax return and information otherwise in the IRS’s possession as taxpayer contacts and other actions not considered an examination, inspection or reopening.


**1.4.19.1.3** **(03-04-2025)**

#### Roles and Responsibilities

1. The Director, Exam Field and Campus, Small Business/Self Employed, is the executive responsible for the IMF AUR Program.

2. The AUR Program Manager, Headquarters Examination Operations, Field and Campus Policy, IMF AUR Policy is the executive responsible for IMF AUR policy and the procedures in this IRM.


**1.4.19.1.4** **(03-04-2025)**

#### Program Management and Review

1. AUR inventory is monitored and managed using a series of specific, detailed reports accessed through the AUR system.

2. Managers and Coordinators use additional reports applicable to AUR cases, such as ORCAS and Control-D to maintain specific inventory.


**1.4.19.1.5** **(03-04-2025)**

#### Program Controls

1. AUR Coordinators grant AUR system access via submissions through Business Entitlement Access Request System (BEARS).

2. AUR Policy analysts perform quarterly reviews to verify the accuracy of each users system permissions.

3. Program effectiveness is measured through periodic program reviews.


**1.4.19.1.6** **(10-20-2017)**

#### Terms and Acronyms

1. For a list of Terms and Acronyms see _Exhibit 1.4.19-1_, Glossary and Abbreviations.


**1.4.19.1.7** **(03-04-2025)**

#### Related Resources

1. Internal Revenue Manuals, publications, and managerial desktop guides are used and may be helpful if in-depth research is needed.


**1.4.19.2** **(03-04-2025)**

### Overview

01. Automated Underreporter (AUR) cases are built from two primary sources: the Individual Master File (IMF) which contains information reported to IRS by taxpayers on Form 1040, U.S. Individual Income Tax Return, Form 1040-SR, U.S. Individual Income Tax Return for Seniors and the Information Returns Master File (IRMF) which contains information submitted by payers of Form W-2, Wage and Tax Statement, Form 1099-DIV, Dividends and Distributions, Form 1099-INT, Interest Income, and others. The IRMF is matched with the IMF to verify all income is reported. Underreporter cases result when computer analysis detects a discrepancy between the two data sources.

02. Discrepant cases are grouped by the following:



    - Subfile - a specific group of taxpayer returns with like issues, regardless of income type

    - Category - a specific type of discrepancy (income, adjustments to income, credits.)

    - Sub-category - range of potential tax change



      ### Note:



      For a list of Category, Subfiles and Sub-categories see _Exhibit 1.4.19-9_, AUR Category Code Description/Chart. These categories and sub-categories provided a logical system of criteria to select cases from the available inventory.


03. Cases are selected at the Headquarters level for each site utilizing the inventory selection tool. The inventory is then controlled by each AUR campus.



    1. The Computing Centers (Enterprise Computing Center at Martinsburg (ECC-MTB) and Enterprise Computing Center at Memphis (ECC-MEM)) send tape information from the IRMF, Return Transaction File (RTF), Taxpayer Information File (TIF), and Payer Agent File. This information is downloaded to the AUR system.



       ### Note:



       Data from the TIF and Payer Agent File is updated weekly.

    2. A computer tape containing Form 4251 (Return Charge-Out) data is printed on a campus printer for paper returns. Each Form 4251 contains a social security number (SSN), tax year, and other case identification information, represented on a bar code in numeric format. Returns are pulled by Federal Records Centers (FRC) and forwarded to the Campuses.

    3. Each screening extract must be released at the headquarters level before it is available to the site to work.

    4. All ELF cases are auto batched into Screening Batch Types (BTs) 01 - 26 and are identified as "Virtual batches" (no physical case). The batches are systemically closed and updated to "AB" status. Tax examiners (TEs) input the Process Codes (PCs) on the individual work unit listing and the clerks Release Batch (RB).

    5. Paper returns are uploaded using scanning software to load them into the AUR system to build systemically.


04. After cases are selected from the inventory, they are worked according to procedures in IRM 4.19.3, IMF Automated Underreporter Program.

05. Cases with paper returns are received and scanned into the AUR system by the clerical function. As paper cases are scanned and systemically built into Screening Batch Types (BTs) 01 - 26 they are controlled in the AUR system. Screening batches are requested by technical units to be worked.

06. Tax examiners perform an in-depth analysis of each case. If the identified discrepant amount is resolved, the case is closed with no taxpayer contact. If the discrepant amount was not included on the return or otherwise resolved, the taxpayer is sent one of the following:



    - Letter 2893-C - a letter generated for **confirmed and appropriate** Federal Withholding (W/H) and/or Excess Social Security Tax (SST)

    - CP 2501 - an initial contact letter (no tax calculation) requesting additional information or a

    - CP 2000 - a proposal to change tax which includes calculations and explanations

    - CP 3219A- Statutory Notice of Deficiency.


07. Process codes are codes used to provide an audit trail for AUR case processing. Integrated Data Retrieval System (IDRS) reflects AUR PCs as pending actions until they post to Master File. . PCs designated to generate notices ( CP 2000, CP 2501 and CP 3219A) transaction code (TC) 922 string listed on IDRS.

08. There are other PCs input during AUR processing that do not generate notices. These PCs may require the case to be released from the work unit prior to batch release. For a complete list of PCs see IRM 4.19.3 Exhibit 4.19.3-4, AUR Process Codes.

09. Internal Process Codes (IPCs) are used to initiate internal processes. A complete list of IPCs can be found in IRM 4.19.3, Exhibit 4.19.3-3, AUR Internal Process Codes.

10. For a list of abbreviations and definitions used in AUR processing, see IRM 4.19.3, Exhibit 4.19.3-2, Glossary and Abbreviations.


**1.4.19.2.1** **(03-04-2025)**

#### AUR System Problem Reporting Procedures

1. Refer any AUR system issue to the AUR Coordinator. If after researching , the AUR Coordinator is unable to resolve the issue is elevated to the appropriate Headquarter (HQ) Analyst(s) using the HQ Referral form.



### Reminder:



If AUR system issue happens outside of HQ Policy business hours. Refer to AUR After Hour Procedures


**1.4.19.2.2** **(11-21-2023)**

#### Policy Statement P-21-3 Guidelines

1. Policy Statement P-21-3 Guidelines are the result of a task force initiated to provide timely and quality responses to taxpayer correspondence. For general guidelines refer to IRM 4.19.3.22.1.5, Policy Statement P-21-3.


**1.4.19.2.3** **(10-26-2021)**

#### Archived Cases

1. The AUR system maintains an archived file of AUR cases for 10 years.

2. Cases from any site can be accessed using View Case in the appropriate tax year on the system.

3. For TY 2013 and prior if information on the case is needed, the case must be ordered from files.


**1.4.19.2.4** **(11-01-2013)**

#### Spousal Notices

1. A second CP 2501 or CP 2000 notice may be generated for the spouse whenever the secondary spouse's address has changed from the AUR tax year to the year of the latest filed return. The second notice is an exact duplicate of all the information contained in the original notice mailed to the primary taxpayer with the exception that the second notice contains the current address of the potential/probable ex-spouse.

2. CP 3219A notices are generated to each spouse, regardless of most recent address of record.


**1.4.19.2.5** **(03-04-2025)**

#### Statute of Limitations

1. In general, assessments must be made within three (3) years after the return due date or filing date, whichever is later. An assessment may be made within six (6) years if there is a substantial omission, 25 percent or more per IRC 6501(e), of gross income.

2. The statute can be extended where the issuance of a Statutory Notice of Deficiency time frame overlaps the original ASED, see IRM 4.19.3, Statutory Notices of Deficiency.



### Note:



Statute cases and the use of Form 872 should be kept to a minimum. However, if it is not possible to timely work and/or timely close these cases, Form 872 should be used.

3. A request for prompt assessment of tax on the estate of a deceased taxpayer limits the statute period for assessment of tax to 18 months after the written request is properly filed or to the normal statute date, whichever is earlier.

4. Statute awareness is a vital process to the performance of identifying statute cases in the Internal Revenue Service operations. The Statute Awareness Program was created to minimize barred assessments and erroneous abatements. For information on conditions which may extend the assessment statute expiration date (ASED), refund statute expiration date (RSED), or collection statute expiration date (CSED), see IRM 25.6, Statute of Limitations.

5. Employees who deal with statute related issues must be able to identify statute imminent or expired periods for assessing, refunding, and collecting tax on Individual Master File (IMF), Business Master File (BMF), and Individual Retirement Account File (IRAF) accounts.

6. If less than 90 days remain until the ASED, prepare the case for adjustment using Form 2859, Request for Quick or Prompt Assessment, and route to the Accounting Operations for assessment via Form 3552, Prompt Assessment Billing Assembly. Cases indicating a decrease in tax, previously assessed by AUR, are resolved by the AUR reconsideration function. See IRM 21.5.3, General Claims Procedures, for Category A criteria and claim disallowance procedures.


**1.4.19.2.6** **(11-01-2014)**

#### Balanced Measurement System

1. The Balanced Measurement System provides guidance for all functions of the IRS and contributes to the focus for work performed in the AUR function.

2. The Balanced Measures are described below:



1. Provide accurate and professional services to internal and external customers in a courteous, timely manner.

2. Empower employee engagement and high-quality productivity through motivational leadership, effective support services, and timely delivery of first-class training programs.

3. Generate a productive quantity of work in a quality manner and provide meaningful outreach to all customers.


**1.4.19.2.7** **(03-04-2025)**

#### Maintaining Documents In AUR

1. Form 3210 - Document Transmittal - Correspondence, teletype, transmittal letters, reports, transmittal receipt and control documents, pertaining to receiving, controlling and transmitting tax returns, taxpayer account registers, and related documents should be maintained within the Operation for one-year from the date the transmittal was prepared. After the one-year period, Form 3210 can be destroyed in accordance with Document 12990, IRS Record Control Schedule (RCS) 23, Item Number 36.

2. Certified mail listings (CMLs) are retained at the site for the current open AUR years and three years prior. Any CMLs prior to this are sent to the FRC for retention.


**1.4.19.2.8** **(11-21-2023)**

#### Integrated Automation Technologies (IAT)

1. Automated Underreporter employees are mandated to use the Integrated Automation Technologies (IAT) tools. When an action must be taken on IDRS (unable to complete the action within the AUR system) and an IAT tool is available, AUR employees with access to IAT tools are required to complete the action using the IAT tool. The IAT tools assist the tax examiner (TE) with IDRS research and input.



### Note:



If an IAT tool is not functioning properly, the case should be worked using IDRS.

2. To avoid IDRS security violations, the following command codes must be in the employee’s profile to utilize the "xMend" IAT tool: ACTON, ADJ54, AMDIS, CFINK, DDBKD, DUPOL, ENMOD, ENREQ, FRM77, IMFOL, INOLE, IRPTR, LETER, LPAGE, MFREQ, REQ77, RTVUE, STAUP, SUMRY, TXCMP, TRDBV, and TXMOD. Other command codes may be optional depending on the action being performed.

3. Ensure the IRS Command Codes are established prior to utilizing the IAT tool. To research a specific IAT function, or access IAT job aids, See, Integrated Automation Technologies.


**1.4.19.2.9** **(11-21-2023)**

#### Managerial Approval for Accuracy Related Penalties

1. If the TP response includes a request to abate an Accuracy Related penalty (either Negligence or Substantial Understatement) and the tax examiner determines the abatement will not be granted, written managerial approval is required. See IRM 4.19.3.22.1.4, Accuracy Related Penalties, for additional information. The approval **must be** done at the time the tax examiner determines to continue processing the case **AND must be** done by a manager

2. An administrative waiver for certain penalties was implemented in 2001 for tax periods with ending dates after December 31, 2000. It is referred to as First Time Abate (FTA) and is available for penalty relief the first time a taxpayer is subject to certain penalties for a single return filed by the taxpayer. The AUR program DOES NOT grant penalty relief under FTA. If the taxpayer is requesting FTA for the failure to file, failure to pay, or other penalties and submitted Form 843, Claim for Refund and Request for Abatement, the request is sent to Accounts Management for processing.

3. To document the managerial approval to assert the penalty, the manager accesses the Case Note window in AUR (see SERP - Job Aids - IMF AUR Research Portal , AUR System Guide, 9.10.2, Creating a Case Note, for additional information) and selects the standard case note. Once committed, the case note will append to the case with the approving managers SEID.


**1.4.19.3** **(11-21-2023)**

### Controlling Work - Batch and Case Overview

01. AUR cases to be analyzed by AUR Tax Examiners (TEs) are built into batches, each batch is divided into work units. It is the manager’s responsibility to monitor and control work coming through their unit.

02. After all cases in the batch have been worked, the batches are released from the technical unit to the clerical function for appropriate action.

03. Each batch is identified with a five-digit number.



    1. The first two digits of the batch number are used to describe the batch type.

    2. The next three digits are used to describe the sequential number of a regular batch (001 through 999), or the Unit Location Number of a Unit Suspense Batch (Batch Types (BT) 36, 42, 45, 62, 65, 75, 77, 82, or 92).


04. Each case is assigned a nine-digit case sequence number (CSN). The CSN corresponds to the location of a case within a batch. A CSN is composed of different elements dependent upon whether the case is in a suspense batch or a regular batch.

05. The CSN of a regular batch consists of four sections. The description of the numbers in sequence are:



    1. The first two numbers are the batch type.

    2. The next three numbers are the batch sequence number.

    3. The next two numbers are the work unit containing the case.

    4. The last two numbers are for the document number within the work unit.


### Exception:

Cases assigned to the TEs individual unit suspense do not contain a work unit number or document number as listed in steps 3 and 4 above.

06. The CSN of a suspense batch consists of three sections. The description of numbers in sequence are:



    1. The first two numbers are the batch type.

    2. The next three numbers are the batch sequence or the location of a Unit Suspense Batch.

    3. The last four numbers are the sequence number of a case within the batch. When the document number reaches 9,999 the batch sequence number increases by one and the document number within the batch starts at 0001.



       ### Note:



       Cases assigned to the TEs individual unit suspense only contain the batch number, they do not have a work unit or document number within the work unit.


07. The CSN is displayed on the Case History Screen.

08. The CSN is valid for locating a case as long as the original batch remains intact and in order during processing. If a case is removed from its original location in the batch and is not returned to it, the CSN is not valid for locating the case. A new CSN is assigned when the case is built to a new batch.

09. To view the history of a case anywhere on the AUR system:



    1. Select the tax year from the AUR Year menu.

    2. Select re**v**iew from the AUR main menu.

    3. Select **C**ase history from the drop down menu. The History/View/Request window displays.

    4. Enter the SSN.

    5. If the case is a phone case, click in the PHONE CONTACT box, otherwise press **<Enter>**.

    6. If the case is a text chat contact, click in the TEXT CHAT box, otherwise press **<Enter>**.


10. Clerical queries and searches the status of a case by taking the following action:



    1. Select the tax year from the AUR Year menu.

    2. Select **C**ontrol from the AUR main menu.

    3. Select **C**ase from the Control menu.

    4. Select **C**ase history from the drop-down menu. The History/View/Request window displays.

    5. Enter the SSN.

    6. Press **<Enter>** twice.


11. The batch status code defines the status of the batch at any time during processing. See IRM 4.19.2.5.2, Batch Status Codes, for a list of acceptable batch status codes and their meanings.


**1.4.19.3.1** **(03-04-2025)**

#### Batch Types

01. **Batch Types 01 - 26****\- Screening Association -** The AUR inventory is ordered in groups referred to as extracts. As case information for these extracts is downloaded into AUR, it is assigned a batch type number ranging sequentially from 01 through 19. These digits represent the extract number.



    1. ELF cases are identified as "VIRTUAL" (V) cases. The system auto-batches these cases into extract batches 01XXX - 19XXX. The batches are identified with a **"V"** to the left of the batch number on the Batch Inventory Report.

    2. The clerical function builds all paper returns into the initial screening batches and holds them until requested by a technical unit through the Batch Request option.


02. **Batch Types 27****\- Auto-Generated Notice -** Certain AUR inventories bypass the physical analysis/screening phase of the program and have CP 2000 systemically generated. This process is referred to as Auto-Generated Notices (AGN). These cases systemically move to BT27. No clerical action is required for these cases during analysis batch building.

03. **Batch Type 29 - Priority Screening -** Screening cases in this batch type may require expedited processing. Technical managers should follow campus direction for requesting these batches.

04. **Batch Type 30 - Missing Return Suspense -** There are two types of cases built to BT 30:



    - Cases where FRC pulled the wrong document locator number (DLN) (IPC WP).

    - Cases where the system has reordered the return automatically based on the reorder date input by the AUR Coordinator. IPC 0A is generated when the system reorders the return.


### Note:

If the returns are not built to BT 31 (Complete Screening Cases) within 60 days, the cases are systemically closed with PC 29, an Unavailable Return Report is generated.

05. **Batch Type 31 - Complete Screening Cases -** Cases previously assigned to BT 30 are built to BT 31 when the return or data is received. These batches are available for processing by technical units.

06. **Batch Type 33 - Screening Research Complete -** Cases previously assigned to BT 34 and BT 35 are built into BT 33 when the requested research is received. These batches are available for processing by technical units. The cases have IPC 0A, additional return requested.

07. **Batch Type 34 - Screening Research Suspense -** Screening Research Suspense Batch numbers are 34000 - 34599, requests for additional return (IPC 0A). The Aged Screening Research Pull List is generated weekly for cases not completed within 60 days from the request date. The cases are systemically closed with PC 29.



    ### Exception:



    Filing status 3 (married filing separate) cases do not automatically close if the research is not received. These cases are assigned to BT 33 and are available for request and processing by the technical units.

08. **Batch Type 35 - Miscellaneous Referrals -** Cases requiring additional technical assistance are built into this batch. These cases must have a current IPC 0D. These batches are available for request and processing by the technical units.

09. **Batch Type 36 - Screening Unit Suspense -** Cases which require technical determination by the manager or lead are transferred by the TE to their Screening Unit Suspense. The system automatically generates IPC 0E and moves the cases to the unit suspense batch. These cases are suspended in the unit and should be monitored by the TE and manager/lead TE to ensure timely actions are taken. Cases are held in the unit until the issue is resolved and the case is released to the unit’s designated area for clerical retrieval.

10. **Batch Type 37 - Released Unit Suspense -** Completed cases from BT 36 are released to the designated area for clerical retrieval. The clerical function builds the cases into BT 37, verifies the PC/IPC, and releases the cases to the appropriate area based on the PC/IPC.

11. **Batch Type 38 - Remail CP 2000/Recomp -** During the batch building process for BT 59, undeliverable CP 2000 and recomputation notice cases with an address update are rejected by the system. The clerical function builds these cases into BT 38. When a better address is identified the system assigns new notice dates and generates amended notices. The system moves the cases to Recomp/Amended/PC55 Suspense BT 55.

12. **Batch Type 39 - Screening Rejects -** When a notice is rejected, the clerical function pulls the case from the suspense file and builds into BT 39. These batches are available for request and processing by the technical units.

13. **Batch Type 40 - CP 2501 Suspense -** During the systemic batch disassembly process, cases with a current PC 30 are systemically assigned to BT 40 in CSN order. The cases remain in BT 40 until a response is received, the notice is returned undeliverable, or the suspense timeframe expires.

14. **Batch Type 41 - CP 2501 Identity Theft (IDT) Response -**CP 2501 responses with an indication of identity theft are built into separate BT 41 by the clerical function. These batch numbers are provided to the AUR Coordinator. BT 41 may only have one IRS received dates.

15. **Batch Type 42 - CP 2501 Unit Research Suspense -** Cases with IPC 3A are systemically assigned to the appropriate unit suspense batch based on the IPC and the TEs SEID. These cases are suspended in the unit and should be monitored by the TE and the manager/lead TE to ensure the requested research is received and timely actions are taken. Completed cases are released to the unit’s designated area for clerical retrieval.

16. **Batch Type 43 - CP 2501 Miscellaneous Referrals -**CP 2501 response cases requiring technical assistance are assigned IPC 3D. The clerical function builds the cases to BT 43. The batches are available for request and processing by the technical units.

17. **Batch Type 44 - CP 2501 Response -**CP 2501 cases receiving a taxpayer response with no indication of identity theft are built to BT 44 by the clerical function and are available for request and processing by technical units. BT 44 may have multiple IRS received dates.

18. **Batch Type 45 - CP 2501 Unit Suspense -** Cases requested by the TE and cases which require technical determination by the manager or lead (transferred by the TE to their CP 2000 Unit Suspense) are systemically assigned to BT 45. The system automatically generates IPC 3E and moves the cases to the unit suspense batch. These cases are suspended in the unit and should be monitored by the TE and manager/lead TE to ensure timely actions are taken. Cases are held in the unit until the issue is resolved and the case is released to the unit’s designated area for clerical retrieval.



    ### Note:



    Cases with a CSN of 45950 indicates the case is a Universal Work Case (UWC).

19. **Batch Type 46 - CP 2501 Response Release -** Completed cases from Unit Suspense (BT 42 and BT 45) are released to the designated area for clerical retrieval. The clerical function builds these cases into BT 46, verifies the PC/IPC and releases the cases to the appropriate area based on the PC/IPC.

20. **Batch Type 49 - CP 2501 No Response Auto Purge -** Cases not receiving a taxpayer response within the suspense timeframe and are not identified by the system as requiring a TE to review, are systemically assigned to BT 49. The system automatically updates the PC to 57 to generate a CP 2000 Notice. BT 49 is not requested or processed by the technical units.

21. **Batch Type 50 - CP 2000 Suspense -** Cases with a current PC 55 and no amended indicator are systemically assigned to BT 50. The cases are filed in CSN order based on notice date and remain in this suspense batch until a response is received, the notice is returned undeliverable, or the suspense timeframe expires.

22. **Batch Type 51 - CP 2000/Recomp Agreed Response -**CP 2000 and Recomputation notices receiving fully agreed responses are built into BT 51 by the clerical function. When clerical updates the batch to "RB" status, the system automatically changes the PC to 67, creates and posts the assessment record, and closes the IDRS control base on these cases. BT 51 may have multiple IRS received dates.

23. **Batch Type 52 - CP 2000/Recomp Disagreed Response -** Disagreed CP 2000 and recomputation notice response cases are built into BT 52 by the clerical function. The batches are available for request and processing by the technical units. Each BT 52 has one IRS Received Date.



    ### Note:



    Separate BT (52,53,58) are built for identity theft responses which require priority handling.

24. **Batch Type 53 - CP 2000/Recomp Priority Response -** Fully agreed and/or disagreed CP 2000 and Amended CP 2000 response cases may be built into BT 53 based on an IRS received date of 20 or more days old. BT 53 is available for request and processing by the technical units. BT 53 may have multiple IRS Received Dates.



    ### Note:



    Separate BT (52,53,58) are built for identity theft responses which require priority handling.





    ### Note:



    Local management has the option to batch fully agreed cases with an IRS received date of 20 days or more to BT 51.

25. **Batch Type 55 - Recomputed Amended/PC 57 CP 2000 Suspense -** During the systemic batch disassembly process, cases with the following PCs are systemically assigned to Recomputed CP 2000 Suspense (BT 55):



    - PC 55 - CP 2000 with a manual interest calculation

    - PC 55A - Amended CP 2000

    - PC 57 - CP 2000 issued after a CP 2501

    - PC 59 - Recomputed CP 2000


### Note:

Cases remain in this batch until a response is received, the notice is returned as undeliverable, or the suspense timeframe expires.

26. **Batch Type 58 - Late CP 2000 Response (CP 3219A Generated) -** Cases where a notice has been generated but has not been mailed due to receipt of a response are built into BT 58. When cases are built into BT 58 the notice is stopped. These batches are available for request and processing by the technical units. BT 58 may have multiple IRS received dates.



    - Separate BT (52,53,58) are built for identity theft responses which require priority handling.

    - If response does not build to BT 58, clerical holds the case until the notice date and then builds to the appropriate response batch.

    - Once a case has been built to BT 58, it cannot be transferred out of the batch, doing so causes issues with stopping the notice.


27. **Batch Type 59 - Aged CP 2000 Stat Preparation -**CP 2000, recomputation notice, or IPC 6L or 6S cases, which have either met the suspense timeframes or are true undeliverables, are systemically assigned to BT 59. The system automatically updates the PC to 75 to generate a notice. BT 59 is not requested or processed by the technical units.

28. **Batch Type 60 - CP 2000 Letter Suspense -** During the systemic batch disassembly process, CP 2000 cases requiring a letter are systemically assigned to BT 60 based on the assignment of IPC 6L or 6S. These cases are filed in CSN order based on the letter date and remain in BT 60 until a response is received, the letter is returned as undeliverable, or the suspense timeframe expires.

29. **Batch Type 61 - Manual Interest Rejects -** Cases previously processed and rejected are built into BT 61 and are available for request and processing by technical units. The interest computation date, determined by local management, is input by the tax examiner when the batch is updated to "AU" status.



    ### Note:



    These batches MUST be released timely to avoid missing the notice date. If the notice date is missed these cases have to be reworked.

30. **Batch Type 62 - CP 2000 Unit Research Suspense -** Cases with IPC 6A are systemically assigned to the appropriate unit suspense batch based on the IPC and the TEs SEID. These cases are suspended in the unit and should be monitored by the TE and the manager/lead TE to ensure the requested research is received and timely actions are taken. Completed cases are released to the unit’s designated area for clerical retrieval.

31. **Batch Type 63 - CP 2000 Miscellaneous Referral -**CP 2000, recomputation notice, or IPC 6L or 6S responses requiring technical assistance are built into BT 63. The current IPC must be 6D. These cases are available for request and processing by the technical units.

32. **Batch Type 65 - CP 2000 Unit Suspense -** Cases requested by the TE and cases which require technical determination by the manager or lead (transferred by the TE to their CP 2000 Unit Suspense) are systemically assigned to BT 65. The system automatically generates IPC 6E and moves the cases to the unit suspense batch. These cases are suspended in the unit and should be monitored by the TE and manager/lead TE to ensure timely actions are taken. Cases are held in the unit until the issue is resolved and the case is released to the unit’s designated area for clerical retrieval.



    ### Note:



    Cases with a CSN of 65950 indicates the case is a UWC.

33. **Batch Type 66 - CP 2000 Response Release -** Completed cases from BT 62 and/or BT 65 are released to a designated area for clerical retrieval. The clerical function builds the cases into BT 66, verifies the PC/IPC, and releases the cases to the appropriate area based on the PC/IPC.

34. **Batch Type 67 - Partially Agreed -** Cases assigned IPC RN (Partially agreed response) are built into BT 67. When the batch is updated to "AB" status, the IPC RN/CR is converted to PC 59/57. After 7 days clerical updates the batch to "RB" status, the system updates the case to PC 67 and creates and posts an automatic assessment record. If the batch has not been updated to "RB" status after two cycles the system generates a Partially Agreed Aging Report.



    ### Note:



    The auto assessment report does not generate for BT 67.

35. **Batch Type 68 - Manual Stat Prep -** Undeliverable notice cases with a post office forwarding address or a new address on the system and cases the TE has identified as requiring a manual notice (PC 77) are built into BT 68. Manual notices are prepared by the tax examiner who input the PC 77 or by the locally designated employee. BT 68 is not requested or processed by the technical units.

36. **Batch Type 70 - Statutory Notice Suspense -** During the systemic batch disassembly process, the system assigns cases with a PC/IPC 75, 77, 95, 8L, 8S, or 8M into notice Suspense (BT 70). The cases are filed in CSN order based on the notice date and remain in the suspense batch until a response is received or the suspense timeframe expires.

37. **Batch Type 71 - Statutory Notice Agreed Response -**Statutory notice cases receiving fully agreed responses are built into BT 71 by the clerical function. When the clerk updates the batch to "RB" status, the system automatically updates the PC to 87, creates and posts an automatic assessment record. BT 71 may have multiple IRS Received Dates.



    ### Note:



    The auto assessment report does not generate for BT 71.

38. **Batch Type 72 - Statutory Identity Theft (IDT) Response -**Disagreed notice responses with an indication of identity theft are built into BT 72. The batch numbers are provided to the AUR Coordinator. BT 72 may have multiple IRS received dates.

39. **Batch Type 73 - Statutory Notice Miscellaneous Referral -** notice cases requiring technical assistance are built into BT 73. The current IPC must be 8D. BTs 73 are available for request and processing by the technical units.

40. **Batch Type 74 - Statutory Notice Response -**Disagreed notice response cases can be built into BT 74. BTs 74 are available for request and processing by the technical units. BT 74 may have multiple IRS received dates.



    ### Note:



    Local management has the option to use BT 71 for fully agreed responses with a PC 75 or 77, regardless of the IRS received date.

41. **Batch Type 75 - Statutory Notice Unit Suspense -**Cases requested by the TE and cases which require technical determination by the manager or lead (transferred by the TE to their Statutory Notice Unit Suspense) are systemically assigned to BT 75. The system automatically generates IPC 8E and moves the cases to the unit suspense batch. These cases are suspended in the unit and should be monitored by the TE and manager/lead TE to ensure timely actions are taken. Completed cases are released to the unit’s designated area for clerical retrieval.



    ### Note:



    Cases with a CSN of 75950 indicate the case is a UWC.

42. **Batch Type 77 - Statutory Notice Unit Research Suspense -**Cases with IPC 8A are systemically assigned to the appropriate unit suspense batch, based on the IPC and the TE's SEID. These cases are suspended in the unit and should be monitored by the TE and manager/lead TE to ensure the requested research is received and timely actions are taken. Completed cases are released to the unit’s designated area for clerical retrieval.

43. **Batch Type 79 - Statutory Notice Defaults -** CP 3219ANotice cases (PC 75, 95, and IPC 8L, 8S) having met the suspense timeframes are systemically assigned to BT 79. When the clerk updates the batch to "RB" status, the system automatically updates the PC to 90 and creates and posts an automatic assessment record.

44. **Batch Type 81 - Reconsideration -**For any year available on the AUR system, responses received for closed cases in BT 96 can be built to BT 81. These batches are available for request and processing by the technical units. BT 81 is used to control, monitor, and track correspondence for closed cases received in AUR for reconsideration.



    ### Caution:



    **DO NOT "RB" BT 81.**

45. **Batch Type 82 Reconsideration Suspense -** Reconsideration cases in BT 81 requiring subsequent correspondence or research are systemically assigned to BT 82 upon input of IPC 9B, 9E or 9L.

46. **Batch Type 83 Employee URP Reconsideration Suspense -**Correspondence for closed Employee URP cases from BT 9600X can be built to BT 83.

47. **Batch Type 84 - Cases with New Actions -** Cases the system has identified with new actions since batches or cases were released by the tax examining units are built to BT 84 as follows:




    | Batch Segments | Definitions |
    | :-: | --- |
    | 84001-84299 | Screening Cases with New Actions |
    | 84300-84448 | CP 2501 Cases with New Actions |
    | 84449-84499 | CP 2501 IDT Cases with New Actions |
    | 84500-84748 | CP 2000 Cases with New Actions |
    | 84749-84799 | CP 2000 IDT Cases with New Actions |
    | 84800-84948 | Statutory Notice Cases with New Actions |
    | 84949-84999 | Statutory Notice IDT Cases with New Actions |





    ### Note:



    These batches are available for request and processing by the technical units.

48. **Batch Type 85 - Remail Statutory Notices -** CP 3219A Notices returned by the Post Office as undeliverable are targeted to BT 85. To be accepted in BT 85, the case must have a PC 75 and a system identified new address present since the was mailed to the taxpayer.



    1. Build undeliverable with PC 77 to BT 68. During the batch building process (BT 85), the system checks each SSN for a new address. If a new address is present, the SSN is accepted into the batch. When the batch is updated to "RB" status, the AUR system automatically generates a request for a new Notice to the new address. If there is no better address or if the case is other than PC 75, the system does not accept the SSN in BT 85.

    2. Refused or unclaimed notices are systemically marked with an undeliverable indicator "X" . The system displays the following error message: "ERROR: Stat notice was unclaimed or refused. Dispose of Stat as classified waste." These undelivered notices do not need to be interfiled and should be discarded in accordance with local classified waste procedures.


49. **Batch Type 86 - Statutory Notice Response Release -**Completed cases from BT 75 or BT 77 are released to a designated area for clerical retrieval. The clerical function builds the cases into BT 86, verifies PC/IPC, and releases the cases to the appropriate area based on the PC/IPC.

50. **Batch Type 87 - Partial Agreed Statutory Notices -**Cases assigned IPC SR/DR (Partially agreed notices) are built into BT 87. When the batch is updated to "AB" status, the IPC SR/DR is converted to PC 95. After 7 days clerical updates the batch to "RB" status, the system updates the case to PC 87/90, creates and posts an automatic assessment record. If the batch has not been updated to "RB" status after two cycles the system generates a Partially Agreed Aging Report.



    ### Note:



    The auto assessment report does not generate for BT 87.

51. **Batch Type 88****\- Reconsideration Cases with No Assessments -** Clerical builds reconsideration cases to BT88 when responses do not require examiner adjustments due to a copy of CP 2000, duplicate response, refile signature document and subsequent payment.

52. **Batch Type 89001 - Bankruptcy Suspense Cases -** Cases where a PC 98 is entered are systemically assigned to BT 89001. These cases are monitored by the bankruptcy coordinator and remain in this suspense batch until processing is completed.

53. **Batch Type 89003 - Identity Theft Suspense Cases** \- Cases where an IPC SI is entered are systemically assigned to BT 89003. These cases are monitored by the AUR IDT liaison and remain in this suspense batch until processing is complete.

54. **Batch Type 89004 - Statutory Suspense - MFJ - Only One TP Signature on Consent** \- During the systemic batch disassembly process, Statutory Notice cases where only one TP has signed the consent to tax increase are systemically assigned to BT 89004 based on the assignment of IPC **S3**.

55. **Batch Type 89005 - Suspense - MFJ - Only One TP Signature on Consent** \- During the systemic batch disassembly process, CP 2000 cases where only one TP has signed the consent to tax increase are systemically assigned to BT 89005 based on the assignment of IPC **S6**.

56. **Batch Type 89006 - Statutory Suspense MFJ - Only One TP Filed Petition** \- During the systemic batch disassembly process, Statutory Notice cases where only one TP has filed a petition with the U.S. Tax Court are systemically assigned to BT 89006 based on the assignment of IPC **S8**.

57. **Batch Type 90 - Employee Screening -** Employee cases downloaded to the AUR system are built into BT 90. The employee designated to work employee cases builds these cases to this batch type.

58. **Batch Type 91 - Employee Suspense -** Employee cases, which the designated TE has issued CP 2501, CP 2000, Recomputation Notice, CP 3219A Notice, or sent a letter to the taxpayer, are built into BT 91. The employee designated to work employee cases builds these cases to this batch type. These cases remain in this batch type until they are closed.

59. **Batch Type 92 - Employee Unit Suspense -** Employee cases the system identifies during processing which require a technical determination or additional information and employee cases with IPC LC or LR are built into BT 92. The employee designated to work employee cases builds these cases to this batch type. Cases can have notices or letters issued. These cases remain in BT 92 until they are closed.

60. **Batch Type 93 - Declared Disaster -** During processing, cases identified with a disaster zip code are built into BT 93. Disaster batches cannot be closed until after the disaster end date when the clerical function updates the batches to continue AUR case processing. BT 93 is divided as follows:



    - 93001-299 - Screening Disaster Suspense

    - 93300-399 - CP 2501 Disaster Suspense

    - 93400-699 - CP 2000 Disaster Suspense

    - 93700-799 - CP 2000 Prep Disaster Suspense

    - 93800-899 - Disaster Suspense

    - 93900-999 - Disaster Default Suspense (PC 90 input by TE)


61. **Batch Type 94 - Fraud Referral Suspense -** When the TE determines a case meets potential fraud criteria, IPC 3F, 6F or 8F is assigned. The system automatically assigns cases with these IPCs to BT 94 during systemic batch disassembly. BT 94 is made available for review by the Examination Operation.

62. **Batch Type 95 - Review -** Cases identified for review are built into this batch type as follows:



    - BT 95001-199 - Reserved

    - BT 95200-399 - CP 2000 Notice Review

    - BT 95400-499 - Reserved

    - BT 95500-599 - CP 2000 Sort Code/Override Indicator Review

    - BT 95600-799 - Pre-Stat Notice Review

    - BT 95800-999 - Stat Recomp/Sort Code Review


63. **Batch Type 96 - Closure Suspense -** Cases with a closure PC are systemically assigned to BT 96001 when the clerk updates the batch to "RB" status.



    ### Note:



    Closed Reconsideration cases are systemically assigned to BT 96002 upon assignment of IPCs 9F, 9I, 9N, 9P or 9R.

64. **Batch Type 98 - Lost Case Suspense -** SSNs where the physical case file cannot be located are systemically assigned to BT 98, when IPC "LC" is input by a TE or clerk.


**1.4.19.3.1.1** **(11-21-2023)**

##### Requesting Batches

1. The unit manager is responsible for monitoring the workload and determining the need to request additional work for their Unit.

2. To request a batch:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **B**atch from the Control menu.

04. Select **S**tatus/Location from the drop-down menu.

05. Select **S**tatus/Location from the pull right menu. The Update Batch Status/Location window displays with the cursor in the BATCH field.

06. Enter the batch number.



       ### Note:



       Use **<F6>** to list all batches in "AB" status and the scroll bar to locate a batch. Select the batch by highlighting the batch number and press **<Enter>** or double click on the batch number.





       ### Caution:



       Response batches are not listed in IRS received date order.

07. Press **<Enter>**. The cursor moves to the NEW STATUS field.

08. Enter "AU" in the NEW STATUS field.

09. Press **<Enter>**.

10. Press **<F4>** to commit.



       ### Note:



       A work unit listing report will generate in a separate window after committing. Click OK in the pop-up Forms window to proceed. View as needed or close the window to cancel.

11. Press **<F8>** to exit.


3. All batches in "AB" status display in descending order.

4. Virtual screening batches display a "V" to the right of the batch number.

5. Response batches display a "Y" when the original cases were virtual cases or an "N" if the original cases were paper.


**1.4.19.3.1.2** **(03-04-2025)**

##### Canceling Batches

1. Batches in "AU" status can be canceled. This can be done even if some of the cases have been worked. Any work units not completed need to be reworked when the batch is reassigned.



### Caution:



To avoid reworking cases, every effort should be made to complete started work units prior to canceling the batch.

2. To cancel a batch:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **B**atch from the Control menu.

04. Select **S**tatus/Location from the drop-down menu.

05. Select **S**tatus/Location from the pull right menu. The Update Batch Status/Location window displays with the cursor in the BATCH field.

06. Enter the batch number in the BATCH field. The current status and location displays. The cursor moves to the NEW STATUS field.

07. Enter "CB" in the NEW STATUS field.

08. Press **<Enter>**.

09. Press **<F4>** to commit.

10. Press **<F8>** to exit.


3. Canceling a batch automatically updates the location to "RLS" .


**1.4.19.3.1.3** **(03-04-2025)**

##### Releasing Batches

1. When a batch of work has been completed it needs to be updated to batch status "BF" .

2. To release a batch from the unit:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **B** Batch from the Control menu.

04. Select **S**tatus/Location from the drop-down menu.

05. Select **S**tatus/Location from the pull right menu. The Update Batch Status/Location window displays with the cursor in the BATCH field.

06. Enter the batch number in the BATCH field. The current status and location displays. The cursor moves to the NEW STATUS field.

07. Enter "BF" in the NEW STATUS field. The system displays the following message: "CHECKING CASES IN BATCH" . See (3) and (4) below.

08. Press **<Enter>**.

09. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

10. Press **<F8>** to exit.



       ### Note:



       Before Manual Interest batches (BT 61) can be updated to "BF" status, the system checks to see if the designated notice date has passed. If the date to generate the notice has passed, the cases need to be reworked.


3. After entering "BF" Status Code, the system checks to see if any of the following conditions apply:




| **Error Condition** | **Definition** |
| --- | --- |
| NO PC | No PC assigned to the case |
| NEW TRN | New transaction is present on the case |
| PC NOT VER | PC has not been verified (clerical) |
| PYR AGT | New payer agent information is present for the case |
| REQUEST | Case has been requested by another user |
| OVER 100K | Tax increase is over $100,000 and requires review |
| LTR PAR | Special paragraph on a correspondex letter needs review |
| ACT REQ | Action required based on universal access |
| DIS ZIP | Case is in a federally declared disaster area |
| STAT IMM | Case is statute imminent |
| PEN STATUS CDWAIV | Case with a penalty the manager has not reviewed |
| STOL ID | Case has an identity theft indicator |
| DIG RESP | Case has a new digital response that hasn’t been reviewed |





### Note:



The cases can be transferred to unit suspense for correcting, except for cases in BT 58.

4. If cases meet any of the above criteria, the SSN of each one displays with an indicator (asterisk) in the appropriate column on the Cases in Error screen. To access the Cases in Error Report see _IRM 1.4.19.9.3_, Cases in Error Report, and _IRM 1.4.19.9.1.1_, Accessing Reports and Listings. For a list of error conditions and the action required to correct each one, see _Exhibit 1.4.19-4_, Error Condition-Cause-Corrective Action Chart.

5. Take the following actions to review special paragraphs for letters:




| **Open Paragraph Review** |
| :-: |
| Select the tax year from the AUR Year menu |
| Select re**v**iew from the AUR main menu. |
| Select **M**anager from the drop-down menu. |
| Select **R**eview from the pull right menu. The Case Analysis screen displays with the cursor in the PRIMARY SSN field. |
| Enter the SSN of the case to be reviewed. The case information displays. |
| Select re**F** tools from the Case Analysis menu. |
| Select **L**etter from the drop-down menu. The Create Correspondex Letter screen displays. A **Y** displays next to the letter being sent. |
| Click on the **Y**. |
| Click on **D**isplay. |
| Review the Open Paragraph. |
| If the Open Paragraph needs to be corrected, assign/transfer the case back to the TE for correction. |

6. The **Bypass Letter** option is available on the Cases in Error screen. Follow campus direction for this option. To bypass letter paragraphs, click in the LETTER BYPASS field and press **<F8>** to exit.



### Caution:



**By using the Bypass Letter option you are releasing work without reviewing Open Paragraphs for errors in grammar and spelling or for content.**


**1.4.19.3.2** **(11-01-2012)**

#### Work Units - General

1. Batches, with the exception of suspense batches, are divided into work units. The number and volume of work units is set by the AUR Coordinator.


**1.4.19.3.2.1** **(11-01-2011)**

##### Assigning Work Units

1. Before analyzing cases within a specific work unit, the work unit must be assigned to a Standard Employee Identifier (SEID).

2. To assign a work unit the TE must:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **W**ork Unit from the Control menu.

04. Select **A**ssign from the drop-down menu. The Assign Work Unit window displays, with the cursor in the BATCH field.

05. Enter the batch number. The cursor moves to the WORK UNIT field.

06. Enter the two-digit work unit number. The cursor moves to the ACCEPT field.

07. Enter **"Y"** to accept the work unit. The SSNs of the work unit display in the SSN fields.

08. Verify these SSNs are part of the work unit.



       ### Note:



       It is not necessary to verify SSNs on virtual batches.

09. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

10. Press **<F8>** to exit.


**1.4.19.3.2.2** **(12-01-2009)**

##### Reassigning Work Units

1. Sometimes it is necessary to change the assigned SEID of a work unit to another user. When a work unit is reassigned, it updates only unworked cases in a work unit. This option should be used to reassign a work unit when the assigned user is unable to complete the work unit.



### Note:



Reassigning work units from one SEID to another does not change the batch assignment of the work unit.

2. To reassign a **specific work unit**:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **W**ork Unit from the Control menu.

04. Select **U**id update from the drop-down menu.

05. Select **S**SN from the pull right menu. The Update Work Unit UID window displays, with the cursor in the BATCH field.

06. Enter the batch number. The cursor moves to the WORK UNIT field.

07. Enter the two-digit work unit number.

08. Enter the new SEID. If any case in the work unit is being worked by another user (displayed on their terminal), the system generates an error message: "Case is being worked by (user SEID)" . Have the user clear the case from their screen. Reenter the batch number. The cursor moves to the CURRENT SEID field.



       ### Note:



       If some of the cases in the work unit have been worked (PC is on the system), an error message displays. A SEID _must_ be assigned to partially completed work units. When the work unit is completed, it is released to the original batch.

09. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

10. Press **<F8>** to exit. All the cases in the work unit are either returned to the batch or reassigned to the new SEID. Cases with a PC entered on the system retain the original TE’s SEID on the AUR history, unless the case is reworked.


3. To reassign all work units from a **specific SEID**:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **W**ork Unit from the Control menu.

4. Select **U**id update from the drop-down menu.

5. Select **U**pdate suspense from the pull right menu. The Update All SEID window displays, with the cursor in the CURRENT SEID field.

6. Enter the current user SEID. All work units assigned to the current SEID display.

7. Enter the new (reassigned) SEID in the NEW SEID field.

8. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

9. Press **<F8>** to exit.


### Note:

Using the SEID Update assigns all unworked cases to a new SEID: even those cases assigned to the TEs individual unit suspense.

**1.4.19.3.2.3** **(11-01-2010)**

##### Transferring Work Units

1. Based on the assigned profile the Transfer Work Unit option may or may not be available.

2. When a work unit is transferred, to another TE or another manager, the system moves all the cases in the work unit from the original batch to unit suspense. The cases are no longer part of the batch and cannot be returned to their original batch or within a work unit and must be released individually. Use this option to transfer a work unit from the batch when the batch needs to be released and the work unit is not complete.



### Note:



Each case from the work unit must be accepted individually. If the transferred work unit must be updated again, each case has to be updated individually. Transferred work units must have the PC on each case updated before release.

3. To transfer a work unit:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **W**ork Unit from the Control menu.

04. Select **T**ransfer from the drop-down menu.

05. Select **T**ransfer from the pull right menu. The Transfer Work Unit window displays, with the cursor in the BATCH field.

06. Enter the batch number. The cursor moves to the WORK UNIT field.

07. Enter the two-digit work unit number. The cursor moves to the TO UID NUMBER field.

08. Enter the new SEID.

09. Press **<F4>** to commit.

10. Press **<F8>** to exit.


**1.4.19.3.2.4** **(12-01-2009)**

##### Releasing Work Units

1. A work unit must be released when all the cases in the work unit are complete.

2. To release a work unit the TE must:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **W**ork Unit from the Control menu.

4. Select **R**elease from the drop-down menu. The Release Work Unit window displays with the cursor in the BATCH field.

5. Enter the batch number of the work unit to be released. The cursor moves to the WORK UNIT field.

6. Enter the two-digit work unit number. As these cases are released, the system performs validity checks for each SSN (case) in the work unit.



      ### Note:



      If there is a discrepancy, the Cases in Error window overlays the Release Work Unit window, showing the SSN(s) of the cases in error. The work unit cannot be released until all error conditions are corrected. See _Exhibit 1.4.19-4_, Error Condition-Cause-Corrective Action Chart, for error conditions and the action required to correct each one.

7. If there are no cases in error, or when all error conditions have been corrected, the cursor moves to the RELEASE field. Enter **"Y"** in the RELEASE field.

8. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

9. Press **<F8>** to exit. When the release of a work unit is complete, the SEID is removed, indicating no ownership.


### Note:

During the response phase, if research is requested on a case(s) using IPC 3A, 6A, or 8A, the Unit Research Suspense window overlays the Release Work Unit window. These cases are systemically assigned to the Unit Suspense batch and must be physically removed from the work unit.

3. The system checks to verify all cases in the work unit have been completed with a PC and there are no cases where:



1. the case has not been completed with a PC, OR

2. there are New Transactions on tax account screen, OR

3. there is new Payer Agent information, OR

4. there is New Correspondence.


**1.4.19.3.3** **(06-01-2006)**

#### Cases

1. Sometimes it is necessary to assign, reassign, transfer and release individual cases.


**1.4.19.3.3.1** **(11-01-2011)**

##### Assigning Cases

1. The Assign option is used to assign individual cases to your SEID. Cases must be assigned to a SEID before any changes can be made. Examples of when this option might be used are to:



   - correct an error

   - rework a case released either individually or in a work unit


2. To assign a case the TE must:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **A**ssign from the drop-down menu. The Assign Case window displays, with the cursor in the SSN field.

5. Enter the SSN of the case to be assigned.

6. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

7. Press **<F8>** to exit.


**1.4.19.3.3.2** **(03-04-2025)**

##### Releasing Cases

1. The Release Case option is used to release a case from an individual's suspense.

2. To release a case the TE must:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **R**elease from the drop-down menu. The Release Case window displays, with the cursor in the SSN field.

5. Enter the SSN of the case to be released.


3. The system checks to verify certain conditions. If the system identifies a discrepancy, the Error window overlays the Release Case window (an asterisk (\*) displays in the error condition column). The case can not be released until all error conditions are resolved. See _Exhibit 1.4.19-4_, Error Condition-Cause-Corrective Action Chart, for a complete list of error conditions and the action required to correct each one.



1. If the case being released belongs to a batch assigned to the unit it should be returned to the batch in CSN order. If the batch displayed is a Unit Suspense batch type, the work unit and sequence number is blank. After releasing a case in unit suspense, place the case in the designated area for clerical retrieval.

2. If there are no errors on the case, or when all error conditions have been corrected, press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

3. Press **<F8>** to exit.


**1.4.19.3.3.2.1** **(03-04-2025)**

###### Releasing Cases through Universal Work

1. The Release Case option is also used to release a Universal Work Case (UWC) assigned to a user.

2. To release a universal case the TE must:



### Note:



These cases do not appear on the unit inventory report, TEs need to use **<F6>** or access "cases assigned" to identify cases assigned to them under Universal work. Managers should monitor the employees inventory to ensure cases worked through UWC (BT XX950) are released timely.





1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **R**elease from the drop-down menu. The Release Case window displays, with the cursor in the SSN field.

5. Enter the SSN of the case to be released.


3. The system checks to verify certain conditions. If the system identifies a discrepancy, the Error window overlays the Release Case window (an asterisk (\*) displays in the error condition column). The case can not be released until all error conditions are resolved. See _Exhibit 1.4.19-4_, Error Condition-Cause-Corrective Action Chart, for a complete list of error conditions and the action required to correct each one.



1. If the case being released belongs to a batch assigned to the unit it should be returned to the batch in CSN order. If the batch displayed is a Unit Suspense batch type, the work unit and sequence number is blank. After releasing a case in unit suspense, place the case in the designated area for clerical retrieval.

2. If there are no errors on the case, or when all error conditions have been corrected, press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

3. Press **<F8>** to exit.


4. There are times when TEs forget to release cases belonging to another site (UWC). The AUR Coordinator at the originating site contacts the AUR Coordinator of the site where the case is assigned through UWC and provides an SSN. If available, notify the TE to release the case. If the TE is not available see (4) below.

5. The AUR Coordinator can release UWC cases a TE has worked and forgotten to release. To release a case the coordinator should take the following action:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **T**ransfer from the drop-down menu.

5. Select **T**ransfer from the pull right menu. The Transfer Case window displays, with the cursor in the SSN field.

6. Enter the SSN provided by the parent site. The following message appears "WARNING: WHEN YOU COMMIT, THIS UNIVERSAL WORK CASE WILL BE REFILED TO THE ORIGINAL BATCH AND LOCATION" , acknowledge the message.

7. Press **<F4>** to commit.

8. Press **<F8>** to exit.


### Caution:

When the AUR Coordinator releases the case it is **refiled to the previous suspense batch**. All PC's entered by the TE are lost.

**1.4.19.3.3.3** **(11-15-2022)**

##### Transferring Cases to Unit Suspense

1. It may be necessary to transfer a case to the unit suspense batch, such as while waiting for assistance on the case or when another user needs to work a case. The manager may also need to transfer cases to other users.

2. To transfer a case the TE must:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **T**ransfer from the drop-down menu.

5. Select **T**ransfer from the pull right menu. The Transfer Case window displays, with the cursor in the SSN field.

6. Enter the SSN of case that needs to be transferred.

7. Enter the SEID to which the case is to be transferred.

8. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

9. Press **<F8>** to exit.


**1.4.19.3.3.4** **(11-01-2010)**

##### Updating Transferred Cases

1. Based on the assigned profile the Update Transfers option may or may not be available. When using the Update Transfers function, the case must be in transfer status (for example, the case has been transferred but not accepted by the new user).

2. To update a case transfer:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **T**ransfer from the drop-down menu.

5. Select **U**pdate from the pull right menu. The Update Transfers window displays with the cursor in the SSN TO UPDATE field.

6. Enter the SSN of the case to be updated. The cursor moves to the NEW UID field.

7. Enter the new SEID.

8. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

9. Press **<F8>** to exit.



      ### Note:



      When in the Update Transfers window, multiple SSNs can be updated without exiting the screen by repeating steps 6 and 7 above.


**1.4.19.3.3.5** **(11-01-2012)**

##### Requesting Cases

1. In certain situations it may be necessary to request an individual case to work. The request case option generates a charge-out which the clerical function uses to pull, transfer, and route the case to the requester.



### Note:



This option should not be used when working virtual cases, the TEs should use the UWC option whenever possible.

2. To request a case:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select re**Q**uest case from the drop-down menu.

5. Enter the SSN. The Request Case window displays with a "W" in the REQUEST CD field, press **<Enter>**.



      ### Note:



      The system displays a message if the case is not in a Suspense Batch.

6. A **"Y"** displays in the TELEPHONE field.



      ### Caution:



      Verify the "Y" is only in the telephone field and NOT in the PRP/CNGR field unless applicable.

7. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

8. Press **<F8>** to exit.


**1.4.19.3.3.5.1** **(03-04-2025)**

###### Requesting Cases through Universal Work

1. When a TE is on the phone with a taxpayer, cases in major suspense batches (BTs 40, 50, 55, 60, 70, 93, and 96) can be requested to work through View case.



1. The system displays the following error message if the case can’t be requested using Universal Work: "Case is not in a batch allowed for universal work case."

2. If TE is unable to request a case using Universal work, see _IRM 1.4.19.12.7.1.1_, Adding/Reactivating Users.


2. To request and work a case through UWC the TE must be in the View Case Screen:



1. Select **C**ontrol from the AUR main menu.

2. Select **C**ase from the drop-down menu.

3. Select univ **W**ork from the pull right menu.

4. Click on the YES box when the following message displays: "Do you accept the case to work?" .

5. Acknowledge the message: "Warning: Case has been assigned to you. Please work case and release."


3. Once a case has been released through UWC and additional changes need to be made and the case belongs to another site, TEs should not request clerical to transfer the case. Use the action required box to notify the originating site a correction needs to be made.


**1.4.19.3.3.6** **(11-01-2010)**

##### Accepting Transferred Cases

1. A case transferred to a user must be accepted before it can be worked. Before accepting a case transfer, the paper case should be in the user's possession.

2. To accept a case transfer the TE must:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **T**ransfer from the drop-down menu.

5. Select **A**ccept from the pull right menu. The Accept Transfers window displays showing individual cases transferred to your SEID. The cursor is in the ACCEPT field.



      ### Note:



      The Accept Transfers window is the same for accepting work units and individual cases.

6. Enter **"Y"** in the ACCEPT column for each case being accepted.

7. After entering **"Y"** for all the cases you choose to accept, press **<F4>** to commit.

8. Press **<F8>** to exit.


**1.4.19.3.3.7** **(10-12-2016)**

##### Viewing Cases

1. Each user can be given a profile, which allows them to view any case on the system. For any year available on the AUR system, a user can view cases (Universal View Case (UVC)) in any of the seven AUR sites. The view case function is necessary for users who answer taxpayer telephone inquiries and for Notice reviewers.



   - The status bar on the Case Analysis screen displays the site where the case is located. The status bar indicates the user is in View Case.

   - If TE is unable to view a case using UVC, see _IRM 1.4.19.12.7.1.1_, Adding/Reactivating Users.


2. When a case is accessed as a View Only Case, only the following changes will be saved on the case:



1. Telephone number and contact hours on the Tax Account screen.

2. Case notes on the Case Note screen.

3. IR notes on the IR Note screen.

4. All update fields on the Taxpayer Information window.

5. Action required box.

6. Update Address window.


3. To view a case:



1. Select the tax year from the AUR Year menu.

2. Select re**V**iew from the AUR main menu.

3. Select **View** case from the drop-down menu. The History/View/Request Case window displays with the cursor in the ENTER SSN field.

4. Enter the SSN of the case to be viewed.

5. Enter a "Y" in the Phone Contact box if applicable. When a "Y" is entered the Disclosure Verification Screen appears, see IRM 4.19.3.22.2.2.1, Disclosure Verification Screen, for additional information. If a "Y" is not entered or the Disclosure Verification Screen is completed, the case to be viewed displays.

6. Press **<F8>** to exit.


**1.4.19.3.3.8** **(11-01-2010)**

##### Reassigning Cases

1. Based on the assigned profile, the SEID update option may or may not be available. The Case SEID Update option is used to reassign a single case to another user. This option is used when an employee is not available to work a case assigned to them or to transfer it to another user.

2. To reassign a case:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **U**id update from the drop-down menu.

5. Select **C**ase Uid from the pull right menu. The Update Case UID window displays with the cursor in the SSN field.

6. Enter the SSN of the case being reassigned. The cursor moves to the NEW UID field.

7. Enter the SEID of the TE to work the case.

8. Press **<F4>** to commit. A message displays indicating the records have been committed. Acknowledge the message.

9. Press **<F8>** to exit.


**1.4.19.3.3.9** **(11-01-2014)**

##### Restoring Work Units

1. When it is determined cases have too many errors after a review, the Restore Work Unit option can be used to refresh the data to near original data (before the TE made entries). Return value fields where changes to the original Return Transaction File (RTF) data were made cannot be restored. Caution TEs to recheck these entries for validity. The case must be reworked and the appropriate PC, other than RF, assigned. This option can only be used in the screening phase of Underreporter prior to the batch being updated to "RB" status. The AUR Coordinator and managers have access to restore options.



### Caution:



The Restore Work Unit options should **ONLY** be used when all other actions have been taken to resolve the error(s).

2. To restore a work unit:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **W**ork unit from the Control menu.

4. Select re**S**tore from the drop-down menu. The Restore Work Unit window displays.

5. Enter the batch number and work unit number to be restored.

6. Press **<F4>** to commit. Cases cannot be accessed during the restore process. A message displays indicating all cases in the work unit have been restored.

7. Press **<F8>** to exit.


**1.4.19.4** **(11-21-2023)**

### Telephones - Toll Free

1. Each AUR site is responsible for providing successful toll-free service to our taxpayers. This subsection contains information and instructions for AUR managers to resolve taxpayer telephone inquiries through the UCCE (Unified Contact Center Environment) Telephone System. This includes security measures, accessing the system and training telephone assistors. See SERP - Job Aids - IMF AUR Research Portal , IRS Cisco Finesse Supervisor Desktop User Guide.

2. Universal Work allows the TE to provide quality service to the taxpayer regardless of which site controls their case. This option is available for any year available on the AUR system. If the case requires a paper document or a fax, and is controlled at another campus, do not use the Universal Work Option. See IRM 4.19.3.22.2.6, Universal Case.



### Note:



If TE is unable to view or request a case using UWC, see _IRM 1.4.19.12.7.1.1_, Adding/Reactivating Users.


**1.4.19.4.1** **(06-01-2006)**

#### Manager Calls

1. Manager calls should be very rare. If an assistor refers an excessive number of calls, it is likely additional training and coaching is needed in "Effective Communication" and/or "Dealing with Difficult Taxpayers" .

2. Remember everyone in IRS is an advocate for the taxpayer. Appropriate actions should be taken to correct the taxpayer’s problem on first contact. However, if you cannot correct the problem AND the taxpayer’s issue meets Taxpayer Advocate Service (TAS) criteria as outlined in IRM 21.1.3.18, Taxpayer Advocate Service (TAS) Guidelines, refer the case to the TAS.

3. Encourage assistors to practice techniques to diffuse a taxpayer's anger, reassure taxpayers they can assist with the issue, and to make every effort to handle the call themselves. However, some taxpayers:



   - Immediately want to speak with a manager,

   - Are only satisfied by speaking with a manager even though the assistor has provided the requested assistance,

   - Want to complain about the service the IRS has provided, or

   - Want to compliment the service the IRS has provided.


**1.4.19.4.1.1** **(11-21-2023)**

##### Manager Calls - Taking a Call

1. To receive a manager call, ensure you are signed onto the Cisco Finesse Supervisor desktop software. For log in information, See the Cisco Finesse Supervisor Desktop User Guide.

2. When you are prepared to speak with the taxpayer, take the referred call:



1. Verify from the phone assistor disclosure was covered. If disclosure was not addressed, it’s the manager’s responsibility to cover disclosure procedures.

2. Obtain the SSN and the tax year from the assistor and ensure the assistor is no longer viewing the case.

3. Select the tax year from the AUR Year menu.

4. Select re**V**iew from the AUR main menu.

5. Select **V**iew case from the drop-down menu. The History/View/Request window displays with the cursor in the ENTER SSN field.



      ### Caution:



      Do not click on the PHONE CONTACT field, when the assistor has already taken this action.

6. Connect with the taxpayer and provide your last name (for example, **"Manager LAST name"** or **Mr, Mrs, Miss, Ms, LAST name**), unique badge identification number and ask "How may I help you?" .



      ### Caution:



      **DO NOT** provide your first and last name when identifying yourself, use one of the examples shown above.


3. While talking with taxpayers, you represent the IRS and must always conduct yourself in a professional manner. There is no excuse for treating anyone rudely. Be courteous, control the direction of the conversation and give the taxpayer accurate and complete assistance.



1. Maintain a pleasant, friendly tone of voice.

2. Speak clearly, using words the taxpayer can understand.

3. Avoid using IRS jargon and acronyms.

4. Handle taxpayer’s negative reactions with patience.

5. Treat the taxpayer as a unique individual deserving respect.

6. Put yourself in the taxpayer’s place. If you received a notice and called for assistance, you would want to be treated with respect and given accurate, complete information to resolve the problem.


4. Callbacks are used when you prefer to return the call later , enabling you to research the account before talking to the taxpayer. If you prefer to return the taxpayer's call, obtain the taxpayer's name, SSN, phone number and the best time to return the call. For more information on making an outgoing call, see the Cisco Finesse Supervisor Desktop User Guide.

5. Double jacking enables the manager to take the call along side the assistor. Using this procedure might provide some insight on how this type of call could be handled by the assistor in the future.



### Reminder:



Place yourself in IDLE or Logout of the Cisco Finesse Supervisor desktop when you are away from your desk.


**1.4.19.4.1.2** **(06-01-2006)**

##### Distressed/Angry Customers

1. When a call is transferred to the manager, the taxpayer is already distressed. Be prepared to take the appropriate action to deal with their needs. An important goal in dealing with a distressed taxpayer is to keep potentially disruptive emotions out of the conversation. Start with controlling your own reactions and emotions.



### Reminder:



Even though the taxpayer is distressed, they want to believe as a manager, you can make the situation better.

2. There are three steps to lessen a taxpayer's anger:



1. Listen.

2. Empathize.

3. Assure.


**1.4.19.4.1.3** **(11-21-2023)**

##### Telephone Threat Procedures

1. When a phone assistor clicks on the "Emergency" button, the manager will be notified. The call will automatically become a conference call to include the phone assistor, caller, and the Emergency Call Recording line.

2. The following instructions should be used when receiving a bomb or other threatening call:



1. The assistor gets the manager's attention. Managers should be available to walk the assistor through the procedures.

2. The assistor needs to be as calm as possible, following the instructions below and asking the questions as shown on Form 9166, Bomb Threat Data Collection.

3. Keep the caller on the line as long as possible. Ask them to repeat the message. Ask the questions listed on Form 9166.

4. Complete the Form 9166. Retain a copy for your records and forward a copy to Treasury Inspector General for Tax Administration (TIGTA).

5. If the caller does not indicate the location or time of possible detonation, ask them for this information. Since calls are routed between different sites, it is extremely important to try to ascertain the caller's physical location and which IRS facility (city, state, specific building/floor/function) is being threatened.

6. Inform the caller the building is occupied and detonation of a bomb could result in the death or serious injury to many innocent people.

7. Listen closely to the voice (male or female), voice quality (calm, excited), accents, and speech impediments.

8. Pay particular attention to background noises such as motors running, music playing, and any other noise which might give a clue to the caller's location.

9. **DO NOT hang-up after the caller is off the line.** This assists in tracing the call.


3. Immediately report a bomb threat to your nearest TIGTA office. If the bomb threat concerns another IRS building, the TIGTA agent(s) contact the TIGTA office having jurisdiction over the threatened IRS building. Enter the telephone numbers for contacting your **TIGTA** Office below. More related information can be found at Emergency & Safety and see IRM 21.1.3.10.7, Bomb Threats.



### Note:



It may be helpful to keep a Form 9166 with the above information readily available at your workstation.


**1.4.19.4.1.4** **(11-21-2023)**

##### Suicide Threats

1. If a taxpayer makes a suicide threat over the telephone, the assistor should:



1. Press the Emergency button located in the Finesse Agent Desktop software.

2. Stay calm.

3. Not hang up or ignore the caller.

4. Use good judgment in keeping the caller on the line.

5. **Immediately** get a manager or the acting manager to take the call - without transferring or putting the caller on hold.


2. The manager/acting manager:



1. Takes responsibility for the telephone call.

2. Asks the caller for the **location**(including phone number) from which they are calling.

3. **If the caller complies,** document the caller's address/location.

4. Use all means available at your site, including the telephone or internet access to gather the necessary information to contact the required local law enforcement or government suicide prevention authority.



      ### Note:



      Campus directions vary, ensure all managers have the appropriate instruction inserted here. All sites should cover this information with local management to ensure during a live call of this type, it is not the first time the manager has reviewed these instructions.





      ### Note:



      If either the assistor and/or manager is teleworking, see IRM 21.1.3.12.1, Suicide Threat Procedures in a Telework Environment, for more information.

5. Report the threat and the caller's location to the local authorities. When we obtain a telephone number or location from the caller, we can relay this information to the local authorities.



      ### Note:



      If the caller provides their location, this information can be given to local authorities. **This is not a disclosure of return/account information**. See IRM 11.3.34.2, Procedures for Release of Information Regarding a Nontax Crime, and IRM 11.3.34.3, Expedited Procedures in Emergency Situations, for more information.

6. When reporting a **suicide threat** to local law enforcement authorities, state only that the threat was made during a contact involving **"official business" .**

7. Before ending the call, try to resolve the tax problem and calm the caller.

8. Contact your local Disclosure Manager as soon as possible and inform them of the threat and of any information disclosed to the law enforcement or suicide prevention authority. See IRM 11.3.34.2, Procedures for Release of Information Regarding a Nontax Crime, and IRM 11.3.34.3, Expedited Procedures in Emergency Situations, for more information.

9. **If the caller refuses to give their location**, a manager/lead or TE (provided a local Disclosure delegation order granting authorization is in effect) can use IRS systems to obtain the name and address of the caller, to give the information to federal or state law enforcement agencies, in situations involving life and health of an individual. This is considered an authorized IRC Section 6103(i)(3)(B) disclosure. See IRM 11.3.28.8, Use of Returns and Return Information in Administrative and Judicial Proceedings, and IRM 21.1.3.12, Suicide Threats, for further information.


3. Calls involving threats of suicide require **all** of the following actions be taken:



   - Contact your local Disclosure Office. Disclosure will guide you through the required accounting for the disclosure.

   - Contact the local TIGTA office following established local procedures.

   - Contact Employee Protection using Form 13090, Caution Indicator Referral Report, via fax, mail or a secured e-mail message. For additional information regarding Caution Upon Contact designation and referrals see IRM 25.4.2, **Caution Upon Contact** Taxpayer.


**1.4.19.4.1.5** **(03-04-2025)**

##### Compliments and Complaints

1. Taxpayer complaints about unresolved tax account issues should be resolved if possible. If unable to resolve and the issue meets Taxpayer Advocate Service (TAS) criteria, transfer to TAS. See IRM 21.1.3.18, Taxpayer Advocate Service (TAS) Guidelines.

2. Check for campus directions for handling taxpayer complaints and compliments. See IRM 21.1.3, Taxpayer Complaints/Compliments About IRS Service.


**1.4.19.4.2** **(11-15-2022)**

#### Telephone Call Reviews

1. Managers are required to review 3 calls per month per assistor _or the number of reviews as set forth locally by either the Department or Operations Manager._

2. To review a live call see SERP - Job Aids - IMF AUR Research Portal , Cisco Finesse Supervisor Desktop User Guide, for more information.



### Note:



Review information is entered into the Embedded Quality System (EQRS); however, a monitoring sheet is usually helpful in keeping a record of the call.





### Reminder:



Managers must complete a BEARS, Automated Information System (AIS) User Registration/Change Request, to request a link to EQRS. Read the EQRS User Guide before proceeding to main menu for logon.

3. Calls can also be reviewed using Contact Recording through the Verint System. To review a call using Contact Recording, managers and reviewers requiring access to Verint must complete a BEARS request with the appropriate special instructions.

4. IRM 4.19.3.22.2, Telephone Responses, contains the requirements for assistors and should be referenced in call reviews.

5. Share the review with the assistor within 3 workdays. However, if the assistor has provided incorrect information to the taxpayer, the manager informs the assistor as soon as possible but no later than eight (8) work hours after the call has been reviewed. Keep a signed copy of the review for your records.


**1.4.19.5** **(10-26-2021)**

### Taxpayer Digital Communications (TDC) in AUR

1. AUR tax examiners can communicate with certain taxpayers via secure messaging.

2. All secure messages being sent through eGain require a Manager or Leads review to accept or reject the message before it is sent to the taxpayer/authorized representative. See the Secure Messaging Taxpayer Digital Communication User Guide, on the AUR Research Portal IMF, for more information.


**1.4.19.5.1** **(03-04-2025)**

#### Procedures for Reviewing Outbound Messages

1. Outbound messages to taxpayers/authorized representatives require managerial approval. When a TE creates a message, the system sends the message to the Lead’s inbox and places it in the Manager Approval queue. When the Lead signs into eGain, the outbound messages requiring managerial approval displays in the inbox.

2. The Manager or Lead must Accept or Reject the messages. Once the Manager or Lead accepts the message it is sent to the customer. If the message is rejected it’s sent back to the examiner for corrections.

3. To view the message needing review, take the following actions:



1. Go to the Inbox.

2. Click on the message activity needing review. The message displays in the Reply pane.


4. Review the message for the following:



   - Check the Subject Line for spelling errors and to ensure it has been updated from the initial Welcome Message subject line.

   - TP’s name is not in all capital letters or lower case in the greeting.

   - The outbound message has the correct attachments.

   - IRS Case status. If the message is a closing, ensure the IRS Case status is marked Completed.

   - The content of the message addresses the taxpayer response and meets all required correspondence criteria. See IRM 4.19.3.22.9, Correspondence.


5. If the message is acceptable, click Accept. The message automatically goes through spellcheck and then is sent to taxpayer.

6. If the message is unacceptable (i.e., spelling/grammar issues, incorrect information provided, etc.), send an encrypted email and ensure the subject line does not contain PII to the examiner, with the reason you are rejecting the message. Provide the SSN and Case ID of the message being rejected. Then click Reject, the message is sent to the tax examiner’s inbox for correction.


**1.4.19.5.2** **(11-02-2020)**

#### Manager Procedures for Reviewing Outbound Messages

1. Messages are automatically populated into the Lead's inbox when the Lead signs into eGain. When the lead is not in, the manager must manually pick the messages from the Manager Approval Queue to review. Review of the messages themselves should follow the same process outlined in IRM 1.4.19.5.1, Procedures for Reviewing Outbound Messages.

2. To manually pick the messages from the Manager Approval Queue:



1. Click on the ellipsis in the Inbox pane. A drop-down menu displays.

2. Select "Pick" from the drop-down menu. The Pick Activities Dialog Box displays.

3. Select the Queue radio button, then click the downward triangle, a drop-down menu displays.

4. Select the Manager Approval queue from the drop-down menu. The activities display in the Filter By Subject field.

5. Highlight the activities you wish to select and click "Pick" in the lower right side of the Dialog box. The activities automatically populate in the inbox.


**1.4.19.5.3** **(03-04-2025)**

#### Transferring eGain Cases

1. There may be instances where cases need to be transferred either to another employee or back into the Secure Message Queue to be put back into the round robin assignment.

2. If an employee needs to be added or removed from round robin new case assignment due to extended leave or other circumstances, contact the local AUR eGain ADMIN no later than Wednesday with the employee’s name and SEID for the change to be effective starting the following week.

3. If a case needs to be transferred from one employee to another take the following actions to the pick the case activities:



1. Perform an eGain Case ID search to populate the Inbox with all activities associated with the case.

2. Review the case to identify all currently open activities associated with the case to identify the activities assigned to the examiner in your eGain Unit.

3. Go to the Inbox and click on the ellipsis, a drop-down menu displays.

4. Select "Pick" from the drop-down menu. The Pick Activities Dialog Box displays.

5. Select the User radio button and the name of the currently assigned user from the drop-down menu. The activities display in the Filter by Subject field.

6. Sort the activities by Case ID to be sure to get all messages for same case.

7. Select the activity to transfer and click "Pick" in the lower right side of the dialog box. The activity automatically populates in the inbox. Repeat this process until all activities associated with the case have been picked.


4. To transfer the case and all associated activities, take the following actions:



1. Go to the Inbox.

2. Select an activity for the case to be transferred. The activity and case information will now display in the Reply and Information panes.

3. Select the Case icon in the Information (right-hand) pane and update the owner to the examiner that the case will be transferred to. If the examiner is outside of your unit, update the owner to the unit lead. Click Save in the Case Details pane.

4. Select the message activity in the inbox you want to transfer and click the ellipsis. A drop-down menu displays.

5. Select Transfer from the drop-down menu. The Transfer Activities Dialog box displays.



      ### Note:



      Activities must be transferred one at a time.

6. In the Transfer to drop-down menu, select User. A list of user’s displays.

7. Select the user the case is being transferred to and click the Transfer button.

8. Repeat steps 4 through 7 for all activities

9. Inform the receiving employee so they can send out the message stating they are the newly assigned examiner for the case.


5. Take the following actions if a case needs to be transferred back to the Round Robin Assignment queue:



1. Go to the Inbox and click on the ellipsis, a drop-down menu displays.

2. Select "Pick" from the drop-down menu. The Pick Activities Dialog Box displays.

3. Select the User radio button and the SEID from the dropdown menu. The activities display in the Filter By Subject field.

4. Sort the activities by Case ID to be sure to get all messages for same case. There is usually only one since this is used for transferring a new taxpayer back into the queue to be assigned round robin to the next examiner. The subject of the message is title **"No Subject (nnnnn)" .**

5. Highlight the activity you wish to select and click "Pick" in the lower right side of the Dialog box. The activity automatically populates in the inbox.


6. The unit Manager, Lead, and Clerk have the permissions to change the case owner. Only the Manager, and Lead or the assigned examiner can transfer the case.


**1.4.19.6** **(12-01-2009)**

### Compliance Manager's Reviews - General

1. All Compliance managers are required to conduct the following (where applicable) reviews:



   - Telephone monitoring

   - Workload reviews and on-line reviews

   - IDRS reviews

   - Evaluative reviews

   - Non-evaluative reviews

   - Clerical reviews


2. Reviews should focus on effective case resolution according to IRM guidelines. Emphasize the achievement of quality service.

3. Headquarters, Directors, Operations and Department Managers set review requirements for their respective operations. Conduct a balance of these reviews throughout the year and include a variety of types of reviews. When necessary, conduct side-by-side non-evaluative reviews for skill development.


**1.4.19.6.1** **(10-20-2017)**

#### Review of Form 3210 Acknowledgement

1. Managers shall perform, at a minimum, quarterly audits of the Form 3210 Acknowledgement process for packages containing PII to ensure appropriate follow-up is occurring. This procedure will allow AUR managers the opportunity to validate that PII senders are following up on Form 3210 Acknowledgments within defined timeframes so that lost shipments are identified quickly. This reduces the likelihood that the PII could be exposed to an unauthorized user.


**1.4.19.6.2** **(06-01-2006)**

#### Non-Evaluative Reviews

1. The primary purpose of a non-evaluative review is to help employees develop and enhance their job skills. Effective non-evaluative reviews foster open lines of communication between the employee, manager and the lead TE. These reviews enable the manager/lead TE to convey employee feedback and transfer operational goals in an informal manner.

2. Non-evaluative reviews do not contain a numerical rating. The results are to be shared orally. Some documentation is appropriate to establish the review actually took place (EQRS may be used to track employee development for this purpose).



1. Have the employee initial and date any documentation.

2. Provide one copy for the employee and retain the other copy.


**1.4.19.6.3** **(11-21-2023)**

#### Mandatory Reviews - AUR

1. The manager is primarily responsible for performing evaluative reviews; however, a portion may be delegated to the lead TE, with the except for IDRS Security Reviews and where only one type of review is required during the employee’s evaluative period. Although performing some of the reviews may be delegated, the manager must always present the results to the employee for the review to be used for evaluative purposes.

2. There are various types of evaluative and non-evaluative reviews used to observe and evaluate employee’s performance throughout the year. The following reviews should be performed to effectively evaluate an employee, if applicable:



   - Paper Case

   - Telephone Monitoring

   - Workload

   - Inventory Management

   - Systems Security

   - Age/Inventory

   - On-the Job

   - Employee Time Report, and other Reports

   - Suspense case reviews

   - Specialized case reviews



     ### Note:



     This list is not all inclusive.


**1.4.19.7** **(12-19-2018)**

### AUR Quality Review - General

1. There are four types of review which can be accomplished within the AUR system:



   - Individual Quality

   - Managerial Review - The manager is responsible for managerial reviews

   - Unit Review

   - Underreporter Notice Reviews


### Note:

A technical review should be performed on No Response and Undeliverable cases.

2. Current AUR system designs do not allow for two users to easily access the same case simultaneously. If the monitor/reviewer accesses the case before the assistor, it can prevent the assistor from accessing the taxpayer’s account in a timely manner. This presents a challenge when monitoring employee activity on incoming toll-free calls. The monitor can successfully review assistor calls by either:



1. Utilizing Contact Recording: This functionality records activity for randomly selected call(s) and allows the monitor to review the call(s) later .

2. Waiting until call completion to access the taxpayer information on the AUR system.


**1.4.19.7.1** **(11-21-2023)**

#### Individual Quality Review

1. Individual quality review is performed by the designated quality reviewer (manager/lead). To perform these reviews:



1. Select the tax year from the AUR Year menu.

2. Select re**V**iew from the AUR main menu.

3. Select **M**anager from the review menu.

4. Select **R**eview from the pull right menu. The Case Analysis screen displays with the cursor in the PRIMARY SSN field.

5. Enter the SSN of the case to be reviewed.

6. Press **<Enter>** the case data will display.

7. When the review is complete, press **<F8>** to exit.


**1.4.19.7.1.1** **(11-21-2023)**

##### Reviewing Quality Errors

1. Cases returned from a reviewer and identified as having errors, may be reviewed by the manager.

2. If the error is not appropriate, return the case to the review examiner for reconsideration following campus directions.

3. If the error is valid, return the case to the original TE for correction.


**1.4.19.7.2** **(06-01-2006)**

#### Managerial Individual Review

1. Managerial Individual Reviews are performed by the manager or designated examiner. This review is performed on any TE assigned to their unit.

2. To perform this review:



1. Select the tax year from the AUR Year menu.

2. Select re**V**iew from the AUR main menu.

3. Select **M**anager from the drop-down menu.

4. Select **R**eview from the pull right menu. The Case Analysis screen displays with the cursor in the PRIMARY SSN field.

5. Enter the SSN of the case to be reviewed.

6. Press **<Enter>**. The case data displays.

7. When the review is complete, press **<F8>** to exit.


**1.4.19.7.3** **(06-01-2006)**

#### Unit Reviews

1. Unit Reviews are performed by designated TEs. This review is performed on any batch assigned to a unit.

2. The review is performed by accessing the History/View/Request Case window.



1. Select the tax year from the AUR Year menu.

2. Select re**V** iew from the AUR main menu.

3. Select **V**iew case from the drop-down menu. The History/View/Request Case window displays with the cursor in the ENTER SSN field.

4. Enter the SSN of the case to be reviewed. The selected case displays.

5. When the review is complete, press **<F8>** to exit.


**1.4.19.7.4** **(03-12-2018)**

#### Notice Reviews

1. The CP 2000 Notice review is mandated, requiring review results be posted to the Notice Review Tracker on the SharePoint **Monday of each week**. The review **MUST** be completed the same week the batch is built.



### Note:



If Monday is a non-workday (holiday, inclement weather, etc) the tracker must be completed on the 1st workday of the week.

2. Notice reviews are performed by a designated group of TEs. As there is no file copy of the CP 2000 for review, the review is performed on-line by taking the following actions:



1. Select the tax year from the AUR Year menu.

2. Select re**V**iew from the AUR main menu.

3. Select **M**anager from the drop-down menu.

4. Select **R**eview from the pull right menu. The Case Analysis screen displays with the cursor in the PRIMARY SSN field.

5. Enter the SSN of the case to be reviewed. The selected case displays.

6. When the review is complete, press **<F8>** to exit.


3. The review can also be performed by:



1. Select the tax year from the AUR Year menu.

2. Selecting re**V**iew from the AUR main menu.

3. Selecting **V**iew case from the drop-down menu. The History/View/Request Case window displays with the cursor in the ENTER SSN field.

4. Enter the SSN of the case to be reviewed. The selected case displays.

5. When the review is complete, press **<F8>** to exit.


4. All notice reviews are batched by the control function into BT 95. See IRM 4.19.2.6.61, Batch Type (BT) 95 (Review), for additional information regarding BT 95.


**1.4.19.8** **(11-21-2023)**

### Payer Agent Coordinator

1. The Payer Agent window is used to input information to identify IRs where an issue with the way the payer reported the income may be present.

2. There are two types of Payer Agent Coordinators (National and AUR Site).



1. National Designated AUR Payer Agent Coordinator (currently located in Ogden) is responsible for the input of all Employer/Agent information return documents received from the Enterprise Computing Center at Martinsburg (ECC-MTB) Management and Technology Information Returns Division. See IRM 4.19.3.6.3, National Designated AUR Payer Agent/Fraud Coordinator – Instructions.

2. AUR Site Payer Agent Coordinator (located at each of the seven sites) is responsible for referrals of questionable/suspicious Payer agent data identified at their site. This includes creating a record in AUR when one does not exist or updating a record when required. See IRM 4.19.3.6.2, AUR Site Payer Agent/Fraud Coordinator – Instructions.


3. New and/or updated Payer Agent information is populated weekly for all the sites when the X007 AUR Run is processed.


**1.4.19.8.1** **(11-21-2023)**

#### Payer Agent/Fraud Coordinator Screens

1. When the **P**ayer/Fraud menu option is selected a drop-down menu displays the following:



   - Payer Agent - allows Search and New Entry for payer agent information.

   - Payer **A**gent list - shows a listing of all Payer information loaded into the AUR system.

   - Potential **F**raud - allows Search and New Entry for fraud information.

   - Potential Fraud **L**ist - shows a listing of all Fraud information loaded into the AUR system



     ### Note:



     Potential Fraud Listing opens in a BOE window.


2. When Payer Agent is selected the payer agent window displays. There are two tabs which allow the user to search or input payer agent information or standard paragraphs.

3. The Payer Agent window allows for Advanced Search and New Entry which displays the following information:



   - EIN –Employer Identification Number

   - Payer Name Lines – Identifies the Payer for which the issue was reported

   - DOC Type –Literal for the type of document received (1098,1099, W-2)

   - Income Type –Literal for the type of income reported (Wage, DCB, MED)

   - Source – How the information was reported either Paper or Magnetic Media Tape (P= Paper, T=Tape)

   - IR’s Updated – Auto populates when the information is created or updated

   - Service Center - which input the payer agent

   - Description – information or instructions pertaining to the issue reported


### Note:

The Payer Agent window can also be used to search using the EIN. Enter the EIN in the EIN field and press Enter. If no information populates after the EIN is entered, the following error message displays **No Payer Agent information is available**.

4. The Standard Paragraphs tab allows the payer agent to add, view, modify and delete paragraphs:




| If | Then |
| --- | --- |
| Adding a paragraph | 1. Select **A**DD button. The cursor moves to the next available line for entry.<br>      <br>2. Press**<CNTRL+E>**or double click. The edit paragraph window displays.<br>      <br>3. Enter paragraph information.<br>      <br>4. Select the **S**AVE button. |
| Deleting a paragraph | 1. Select the Paragraph Test line<br>      <br>2. Press the "**Delete**" button<br>      <br>3. The system will prompt to ensure this paragraph is to be deleted |
| View or Modify a paragraph | 1. Select Paragraph Text line<br>      <br>2. Press **<CNTRL+E>**or double click. The Edit Paragraph window will appear<br>      <br>3. Press **"Save"** button when finished. |





### Caution:



Once information is saved in the payer agent window it can’t be deleted.

5. Payer Agent should review the Payer Agent listing when entries have been made as described in (3) above. See _IRM 1.4.19.9.6.8_, Payer Agent List, for additional information.

6. When the potential Fraud is selected as described in (1) above, the Potential Fraud window appears. There are two options Search and New Entry:




| If accessing | Then |
| --- | --- |
| Search | 1. Select the Search Button. The Search potential Fraud window will appear.<br>      <br>2. Enter the EIN, Doc Type, Income Type and/or Money amount.<br>      <br>3. Press **<Enter> or Search button.** The Fraud information displays in the fields.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      If no information populates after the EIN, Doc Type, Income Type and or Money amount is entered, the screen remains blank if nothing was found. |
| New Entry | 01. Enter EIN<br>       <br>02. Enter Payer Name in the Payer Name Lines field.<br>       <br>03. Enter document type in the DOC Type field.<br>       <br>04. Enter Income Type, otherwise leave blank.<br>       <br>05. Enter Money Amount, otherwise leave blank.<br>       <br>06. Enter P=Paper or T=Tape (magnetic media) in the Source field.<br>       <br>07. Date - field auto populates with current date.<br>       <br>08. SC – Service Center, auto populates with Fraud coordinators service center<br>       <br>09. Fraud Description Notes - Enter specific Instructions for the tax examiner in the Text Lines field<br>       <br>10. Press the Save button or F4 to commit.<br>       <br>       <br>       <br>       ### Caution:<br>       <br>       <br>       <br>       Once information is committed in the Fraud window it cannot be deleted. |

7. Select New Entry button allows new fraud information to be entered. A Cancel New Entry button will appear in the window.


**1.4.19.9** **(11-21-2023)**

### Monitoring and Reports

1. While all the reports and listings serve a specific purpose, some have been designated as **"Most Important"** and should be monitored on a regular basis.

2. The AUR System provides numerous methods to monitor inventory through history windows and inventory reports. The following reports have been designated as:




| **"Most Important"** |
| --: |
| Unit Suspense |
| Aged Response Batch Summary |
| Inventory |
| Mistle |
| Mistle XCL |
| Notice Letter Listing |
| Non-Stat Listing |
| PC Status Listing |
| Weekly PC/IPC Listing |
| Unit Inventory |
| Lost Case Report |
| Disassemble Age Report |
| Reject Listing |
| Batch Released Report |
| Open Case Listing |
| Open Transfer Listing |
| Missing Assessment Report |
| Statute Listing |
| Stat Not Generated Report |
| Extract Cycle Category Listing |
| IDT Suspense Listing |
| Restricted Case Report |
| TDC Notice Suppression |


**1.4.19.9.1** **(10-10-2018)**

#### Reports - General

1. The reports in the AUR System serve two distinct purposes. The first is to provide listings to aid in the flow of work through the units. The second is to provide managers and the AUR Coordinator with information to be used in the coordination and monitoring of inventory.

2. The report data on the AUR System is classified as either system or user generated. There are two major groupings.

3. The first grouping is designated as Reports.



1. Reports contain data elements providing information which allows management to monitor the total inventory.

2. Reports are usually generated by the system and display all data reflecting the whole system rather than the individual batch information provided by the listings.



      ### Note:



      Both reports and listings most often reflect real time information rather than cumulative data.


4. The second grouping is designated as Listings.



1. Listings are used as transmittal sheets for specific batches of work. Listings break down batch information by Process Codes, Case Sequence Number, and/or SSN.

2. Listings do not give a comprehensive picture of the inventory and are not usually generated by the system.


### Note:

A few of the listings are system generated and provide information, which is needed to process cases requiring special handling. See _Exhibit 1.4.19-6_, AUR Report Matrix, which lists each report and listing with the report frequency, access capabilities, purpose and type of report.

5. To navigate through a report on the screen, use the mouse or the following keys on the keyboard:



   - End - Takes you to the last page of the report

   - Down Arrow - Moves the cursor down one line

   - Page Down (**<pg dn>**) \- Takes you to the next page of the report

   - Home - Takes you to the first page of the report

   - Up Arrow - Moves the cursor up one line

   - Page Up (**<pg up>**) \- Takes you to the previous page of the report


6. System generated reports are created weekly during the normal batch processing runs.


**1.4.19.9.1.1** **(03-04-2025)**

##### Accessing Reports, and Listings

1. To access a report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu. When the reports menu displays, each type of report or listing available is shown as an option.

4. Select the report or listing to view/print. The report/listing opens in a Microsoft Edge window or in a Business Object Enterprise (BOE) window.



      ### Note:



      BOE reports can also be exported to Excel, PDF, HTML, Text and CVS Archive files by using the BOE “Export” button in the BOE menu.


2. If the report opens in a Microsoft Edge window, you can view the report/listing by taking the following actions:



1. Select ellipsis options.

2. Select Print from the drop-down menu.

3. To exit the report, use the "X" in the top right-hand corner of the report.

4. Press **<F8>** to close the Control Menu.


### Note:

If a print of the entire report is not needed, press the **<print scrn>** (print screen) key to access Snag-IT to capture the portion of the report shown on the screen.

3. If the report opens in a BOE window, you can view the report/listing by taking the following actions:



1. Click on the ellipsis under File. Select the print option. Click print. The report/listing downloads to PDF for printing.

2. Click on Open file. The report/listing opens in PDF.

3. Select File from the menu or click on the printer icon.

4. If the File option is selected, select Print from the drop-down menu.

5. To exit the report, select **F**ile then **C**lose from the menu options at the top of the report or use the "X" in the top right-hand corner of the report.


**1.4.19.9.2** **(10-10-2018)**

#### Batch Reports

1. The following reports are listed under the **Control****Batch** menu option:



   - Batch Inventory

   - Batch Listings

   - Batch Released


**1.4.19.9.2.1** **(03-04-2025)**

##### Complete Batch Inventory Report

1. Batch Inventory Reports list batches by status in batch number order. These reports are generated on demand and can be viewed by the AUR Coordinator, managers or lead TEs.

2. This report option contains a menu, which allows the user to select nine data options.



1. **Association** \- displays screening batches in **AB** status.

2. **Batch Type** \- displays a specified batch type.

3. **Complete** \- displays all batches, their status, digital response indicator, whether folder exists, days in status, volume, location, and age. The batches display in numerical order for each status.



      ### Note:



      **Use the Complete Batch Report** to determine the overall batch processing within your site and to identify any work flow issues, (for example, are batches being disassembled timely, are batches aging without actions). This report has been designated as one of the **"Most Important" .**

4. **CP 2000** \- displays all CP 2000 batches, their status, digital response indicator, whether folder exists, days in status, volume, location, batch IRS received date, and age. The batches display in numerical order for each status.

5. **CP 2501** \- displays all CP 2501 batches, their status, digital response indicator, whether folder exists, days in status, volume, location, batch IRS received date, and age. The batches display in numerical order for each status.

6. **Recon** \- displays all BT 81, their status, days in status, volume, location, and age. The batches display in numerical order for each status.

7. **Screening** \- displays all screening batches, their status, days in status, volume, and location. The batches display in numerical order for each status.

8. **Statutory** \- displays all CP 3219A Notice batches, their status, digital response indicator, whether folder exists, days in status, volume, location, batch IRS received date, and age. The batches display in numerical order for each status.

9. **Unit Suspense** \- displays the total number of cases when the appropriate batch type is input that is assigned to unit suspense batches , the oldest IRS received date and age from the IRS received date. Use this report to determine if the site has excess inventory in the unit suspense.



      ### Note:



      Managers should monitor this report on a **weekly basis**. This report has been designated as one of the **"Most Important" .**


### Note:

For response batches, the FLDR EXISTS field contains a "N" when the when the cases are fully virtual or a “Y” when the there is a paper case file. The DIG field contains a “Y” for digital responses and “N” for paper responses.

3. Each data option may be detailed by choosing one or all of the Batch Status Codes or Location Numbers within the selected data option. The Status categories are further broken down by:




| **Batch Inventory Report Displays** |
| :-: |
| Dig (Digital) |
| Batch Number |
| Fldr Exists |
| Days in Status |
| Volume |
| Location |
| Batch/IRS Rcv’d Date |
| Age from IRS Rcv’d Date |
| Volume over 30 Days by Saturday |
| AB Status Date |
| Age from AB Date |

4. The Dig column will display:



1. "A" if it’s auto batched with a digital response

2. "Y" or "N" if response was built by clerical



      ### Note:



      If the column is blank that means the case was built by a systemic process other than auto batching, for example: auto purge.


5. The Batch Inventory Report also provides a summary page. This page displays:



   - Batch Status

   - Batch Volume

   - Case Volume (number of cases assigned to batches)

   - Oldest IRS Received Date

   - Age (number of days from IRS Received Date)


6. To view the Batch Inventory Report:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **R**eports from the Control menu.

04. Select **B**atch from the drop-down menu.

05. Select bath inventor**Y** from the pull right menu. A pull right menu displays with report options.

06. Select _one_ of the available options from the pull right menu. The applicable window displays.



       ### Note:



       The COMPLETE option includes **all** of the other categories except for Unit Suspense.

07. If the **B**atch Type option is selected, enter a two-digit batch type (e.g., 29 for Priority Screening, 36 for Screening Unit Suspense).

08. Default entries appear in the STATUS, LOCATION, SUMMARY ONLY and SORT ORDER fields. To change a default entry, place the cursor in the field, press **<DELETE>** or **<F5>** and enter the correct values for each field.

09. STATUS - enter the current status of the batch being requested (**AU** = Assigned Unit, **BF** = Batch Finished).

10. LOCATION - enter a three-digit location (unit) number or **ALL** for all locations.

11. SUMMARY ONLY - enter either **"N"** for Detail, which generates a report with batch number, days in status, volume, case volume, location, batch IRS received date, age from IRS received date, and the summary or **"Y"** for Summary, which generates a report with status, batch volume, case volume, oldest IRS received date and age.

12. SORT ORDER - enter default entry **"S"** for sequence order. Click to view report.



       ### Note:



       Batches containing multiple received dates do not display in date order.


### Note:

See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to print/view reports and listings.

7. This report is used to monitor the volume of work available and is continuously updated by the system.


**1.4.19.9.2.2** **(03-04-2025)**

##### Batch Listings

1. Batch Listings display all cases in a designated batch arranged in a selected sequence order.

2. As a rule, these listings are not system generated and **DO NOT** give a comprehensive picture of the total inventory. The header information for all batch listings includes:



   - Batch Number

   - Batch Status

   - Batch Date and

   - Batch Location


3. The last page of Batch Listings is a summary page which contains total volumes for each data column. Batch listings can be generated for any batch in the system and can be viewedby the user. Batch listings include the following:



   - **P**C - Sequence Number - SSN

   - Sequence **N**umber - SSN - PC

   - **S**equence Number - SSN


4. To access batch listings:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select**B** atch from the drop-down menu.

5. Select **B**atch listings from the pull right menu.

6. Select _one_ of the available options from the pull right menu. The listing options display in the order stated in (3) above.

7. Select _one_ of the available options from the pull right menu (**C**omplete or **S**ummary) for the Sequence Number - SSN - PC Listing and the PC - Sequence Number - SSN Listing. The Batch Listings window displays with the cursor in the ENTER BATCH NUMBER field.

8. Enter the batch number. The selected Batch Listing opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. These listings can also be accessed by taking the following actions:



01. Select the tax year from the AUR Year menu.

02. Select **C**ontrol from the AUR main menu.

03. Select **B**atch from the Control menu.

04. Select **S**tatus/Location from the drop-down menu.

05. Select **S**tatus/Location from the pull right menu. The Update Batch Status window displays with the cursor in the BATCH field.

06. Select **R**eports.

07. Select **B**atch listings from the drop-down menu.

08. Select _one_ of the available options from the pull right menu. The listing options display in the order stated in (3) above.

09. Select _one_ of the available options from the pull right menu ( **C**omplete or **S**ummary) for the Sequence Number - SSN - PC Listing and the PC - Sequence Number - SSN Listing. The Batch Listings window displays with the cursor in the ENTER BATCH NUMBER field.

10. Enter batch number. The selected Batch Listing opens in a Microsoft Edge window.



       ### Note:



       See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


6. Batch listings are **generally used** as:



   - Clerical transmittal documents, for each batch in "AB" status

   - Records of batch contents to verify cases within the batch

   - Records of batch contents to locate cases within the batch


**1.4.19.9.2.2.1** **(03-04-2025)**

###### Sequence Number-SSN-PC Listing

1. The primary sort of this listing is by sequence number. The Complete option displays the following data:



   - Sequence number (depends on the type of batch requested)



     ### Note:



     Reconsideration cases will be removed from the batch once the PC is committed.

   - Virtual Indicator (V), if applicable

   - SSN

   - Process Code

   - Process Code Date

   - Received Date


2. The Summary option displays the following data:



   - Process Code(s)

   - Volume for each PC

   - Total volumes of PCs


**1.4.19.9.2.2.2** **(03-04-2025)**

###### PC-Sequence Number-SSN Batch Listing

1. The primary sort of this listing is segmented by IPC/PC. The Complete option displays the following data::



   - Sequence Number (This number depends on the type of batch requested.)

   - Virtual Indicator (V), if applicable

   - SSN

   - IRS Received/Suspense Date


2. The Summary option displays the following data:



   - Process Code(s)

   - Volume for each PC

   - IRS received date for response batches or the Suspense date for suspense batches for each PC

   - Volume of cases for the IRS received date or the Suspense date and

   - Total volumes for all PCs and the dates


**1.4.19.9.2.2.3** **(03-04-2025)**

###### Sequence Number-SSN Batch Listing

1. The primary sort of this listing is by sequence number. This listing displays the following data:



   - Sequence number - depends on the type of batch requested

   - Auto notice Virtual Indicator (A), if applicable

   - Virtual Indicator (V), if applicable

   - SSN



     ### Note:



     The Total Volume of cases in the batch displays as the last line of the listing.


**1.4.19.9.2.3** **(10-10-2018)**

##### Batch Released Report

1. The Batch Released Report displays a list of each batch type updated to Batch Finished (BF) status from all locations for a specified period of time. The listing displays a summary by location and a **grand total summary** of all locations.

2. This report can be accessed by taking the following actions:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **B**atch from the drop-down menu.

5. Select batch **R**eleased from the pull right menu. The Batch Released window displays with the cursor in the ENTER BEGINNING DATE field.

6. Enter the beginning and ending dates in **MM/DD/YYYY** format. The Batch Released Volume Report opens in a BOE Window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. Use the Batch Released Report to monitor the inventory worked by location and to determine how much work is being completed by the units. This report is used to determine productivity issues.

4. This report has been designated as one of the **"Most Important" .**

5. This report is generated on demand and can be viewed by the AUR Coordinator and technical managers.


**1.4.19.9.3** **(03-04-2025)**

#### Cases In Error Report

1. The Cases In Error Report identifies cases with error conditions. This report is generated when the status of a specific batch is updated to **BF** or **RB**. Technical managers can access this report when updating a batch to **BF** status.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **C**ases in error from the drop-down menu.

5. Enter the batch number and press **<Enter>**. The Cases In Error Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. The report is used to identify and to resolve cases with error conditions (for example, new transactions, missing PCs, special paragraphs).

4. It is generated by batch number. The left side of the report shows the following case data:



   - SSN

   - Process Code

   - PC SEID

   - Sequence number within the batch

   - Owner SEID


5. The report lists the following error conditions which are marked as identified by the system:




| **Error Condition** | **Definition** |
| --- | --- |
| NO PC | No PC assigned to the case |
| NEW TRN | New transaction is present on the case |
| PC NOT VER | PC has not been verified (clerical) |
| PYR AGT | New payer agent information is present for the case |
| REQUEST | Case has been requested by another user |
| OVER 100K | Tax increase is over $100,000 and requires review |
| LTR PAR | Special paragraph on a correspondex letter needs review |
| ACT REQ | Action required based on universal access |
| DIS ZIP | Case is in a federally declared disaster area |
| STAT IMM | Case is statute imminent |
| PEN STATUS CDWAIV | Case with a penalty the manager has not reviewed |
| STOL ID | Case has an identity theft indicator |
| DIG RESP | Case has a new digital response that hasn’t been reviewed |


**1.4.19.9.4** **(02-22-2023)**

#### Clerical Reports

1. The following reports are located under the C**l**erical menu option:




| **Clerical Menu** |
| :-: |
| Address update |
| Aging |
| Auto Assess |
| Check date list |
| Closed research |
| Disaster CSN/SSN |
| Lost case |
| Misc letter |
| New payer agent |
| New transaction |
| Pull listing |
| Return chargeout |
| Reworked cases |
| Release batch |
| Scanned Images |
| Undelivered notice |


**1.4.19.9.4.1** **(10-10-2018)**

##### Address Update Report

1. The Address Update Report provides a listing of cases with a new address since the case was batched into Aged CP 2000, CP 3219A BT 59. When BT 59 is updated to **RB** status, the system searches for receipt of a new address and identifies those cases.

2. The report **must be printed before** the system allows the batch to be updated to "RB" status. This report can be generated in CSN or SSN order.

3. This report displays two sets of three columns :



   - Sequence Number

   - SSN



     ### Note:



     A Virtual Indicator (V) appears to the right of the SSN if it is a virtual case.

   - Previous CSN


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select address u**P** date from the pull right menu. The Address Update Rpt window displays with the cursor in the ENTER BATCH NUMBER field.

6. Enter the batch number. The cursor moves to the ENTER SORT ORDER field.

7. Enter "S" for SSN or "E" for sequence number. The Address Update Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. Use this report **each week** to pull the cases with updated addresses and build them to Remail CP 2000/Recomp BT 38.



### Note:



If the system prompts "IPC 6L" is on the case, build these into BT 84.

6. This report is generated on demand and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.2** **(10-10-2018)**

##### Aging Reports

1. Aging reports identify cases having met a specified number of days, either systemically set or input by the AUR Coordinator, and are considered aged.

2. The report data can be sorted and displayed by one of the following pull right menu options:



   - **A**uto purge

   - **C**omplete case

   - **D**isassem batch

   - **P**art agreed

   - stat **N**ot gen

   - **S**usp aged batch


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Then select **A**ging from the pull right menu.

6. Select _one_ of the available options from the pull right menu. The listing options display in the order stated in (1) above. The selected Aging Report opens in a Microsoft Edge window as a PDF file down-load or in the BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. These reports are updated weekly and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.3** **(03-04-2025)**

##### Disassembled/Age Batch Report

1. This report displays aged cases in batches having been through the disassembly process (DC status). Cases from batches in "DC" status display on the next week's report.



### Example:



Cases in disassembled batches with IPC MI needing to be built to BT 61 and cases with IPC-RN needing to be built to BT 67.

2. The Disassembled/Age Batch Report displays the following:



   - Virtual Indicator (V)

   - SSN



     ### Note:



     A Virtual Indicator (V) appears to the left of the SSN if it is a virtual/digital case

   - Process Code

   - Batch

   - Batch Status Date


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **A**ging from the pull right menu.

6. Select **D**isassem batch from the pull right menu. The Disassembled Age Batch Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report on a **weekly basis** to monitor disassembled batches and SSNs (cases) not built to the appropriate batch.

5. If the user is unable to locate the case to build, make a site decision to either:



   - Continue processing without the physical case file or

   - Assign the SSN to Lost Case BT 98 and closely monitor for subsequent actions.


6. This report has been designated one of the**"Most Important" .**

7. The Disassembled/Age Batch Report is generated weekly by the system and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.4** **(10-10-2018)**

##### Completed Case Report

1. The Completed Case Report identifies cases in Missing Data Suspense BT 32 when the missing data has been received.

2. The Completed Case Report displays SSNs followed by the Virtual Indicator (V) if applicable. Cases are filed in the Missing Data Suspense in SSN order.

3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical form the drop-down menu.

5. Select **A**ging from the pull right menu.

6. Select **C**omplete case from the pull right menu. The Completed Case Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This report is used **each week** to pull the cases from the suspense file and build to Completed Cases/Screening BT 31.

5. This report is system generated weekly and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.5** **(11-21-2023)**

##### Suspense Aged Batch Report

1. This report indicates which suspense batches have met the appropriate suspense timeframes. The system has checked for the required conditions (for example, foreign addresses, new transactions, and new addresses) before updating each case with a code indicating the batch number for the cases next batch assignment.

2. The Suspense Aged Batch Report displays the following:



   - Suspense Batch

   - Notice Date of the Suspense Batch

   - Count


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **A**ging from the pull right menu.

6. Select **S**uspense Aged Batch from the pull right menu. The Suspense Aged Batch Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report on a **weekly basis** to monitor suspense batches, ensuring all cases meeting the appropriate suspense timeframes continue through AUR processing. Each week, clerical builds the cases present in the suspense batches listed on the report.

5. The report is system generated weekly and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.6** **(10-10-2018)**

##### Partially Agreed Aging Report

1. This report displays Partial Agreed Batches (BT 67 and 87) in "AB" batch status for one or more processing cycles.

2. The Partially Agreed Aging Report displays the Batch Number and Status Date, the date the batch status was updated.

3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **A**ging from the pull right menu.

6. Select **P**art agreed from the pull right menu. The Partially Agreed Aging Report opens in a Microsoft Edge or Adobe window as a pdf document file.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report **each week** to determine which Partial Agreed BT 67 and 87 batches require updating to "RB" batch status, to ensure timely actions and minimal cycle time.

5. This report is generated on demand and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.7** **(03-04-2025)**

##### Stat Not Generated Report

1. This report provides a list of cases from the prior week's Statutory Notice mailout not receiving a Certified Mail Number, indicating the Statutory Notice of Deficiency was not generated and mailed. The AUR system receives this data from Correspondence Production Services (CPS) within two weeks of the CP 3219A notice date.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR Main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **A**ging from the pull right menu.

6. Select **N**ot gen from the pull-right menu. The Stat Not Generated Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. The Stat Not Generated Report displays:



   - CSN and virtual indicator

   - SSN

   - Total number of cases

   - SCRS Due Date


4. This report is used to identify and transfer cases where a Stat Notice was not generated, to the AUR Coordinator or designated SEID.



### Note:



This report has been designated as one of the **"Most Important."**

5. This report is generated weekly by the system and can be viewed for the prior week's Stat Notices.


**1.4.19.9.4.8** **(11-21-2023)**

##### Auto Purge Pull List

1. This listing identifies cases containing conditions (fallouts) requiring TE review.

2. This listing displays the following information:



   - Notice Date

   - Suspense Sequence Number

   - Virtual Indicator

   - SSN

   - Target Batch

   - Fallout Condition

   - Restricted Case Code


3. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **A**ging from the pull right menu.

6. Select **A**uto purge from the pull right menu.

7. Select **A**uto purge pull list from the pull right menu. The Auto Purge Pull List window displays with the cursor in the ENTER BATCH NUMBER field.

8. Enter the batch number. The Auto Purge Pull List opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this listing **each week** to pull and build cases containing conditions (fallouts) requiring TE review.

5. This list is generated on demand and can be viewed .


**1.4.19.9.4.9** **(03-04-2025)**

##### Auto Purge Batch

1. This listing identifies cases remaining in the 40, 50, 55, 60, 70 Suspense batches.

2. The listing displays the following:



   - Target

   - Suspense CSN

   - Virtual Indicator

   - SSN

   - Total Volume to BT


3. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **A**ging from the pull right menu.

6. Select **A**uto purge from the pull right menu.

7. Select **A**uto purge pull list from the pull right menu. The Auto Purge Target Batch listing window displays.

8. Enter suspense batch number. The Auto Purge Target Batch Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This list is generated weekly and can be viewed .


**1.4.19.9.4.10** **(03-04-2025)**

##### Rb Batches

1. This listing identities batch types 38, 49, 59, and 79 that were systemically built and ready to be updated to "RB" status. This listing also identifies systemically built BT 84 ready to be updated to **AB** status.

2. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **A**ging from the pull-right menu.

6. Select **A**uto purge from the pull-right menu.

7. Select **R**b batches from the pull-right menu. The RB Auto Purge Batches Report displays in a Microsoft Edge window as a text document file.


3. This report is generated weekly and can viewed.



### Note:



See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings,



    for information on how to view reports and listings.




**1.4.19.9.4.11** **(11-21-2023)**

##### Auto Assessment Report

1. The Auto Assessment Report provides a listing of cases in sequence number order, which have been automatically assessed in other than a Fully Agreed Response batch.



### Note:



The auto assessment report does not generate for BT 51, 67, 71, and 87.

2. This report displays the following data:



   - Process Code

   - New Files Sequence Number

   - Virtual Indicator (V)

   - SSN

   - SOURCE DOC (An asterisk (\*) displays in SOURCE DOC field when there are no attachments to associate with the CF 5147. An **N** displays in the SOURCE DOC field when there are no attachments for Files to associates.)



     ### Note:



     The SOURCE DOC field may display "N," **R,****Y**or be blank. No clerical action is required.


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select AU**T**O Assessment from the pull right menu. The Auto Assessment window displays.

6. Enter the batch number. The Auto Assessment Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. The Auto Assessment Report is for PAS sample. This report should be run after a Disagreed Response batch is completed and updated to "RB" status.

5. This report is generated after the batch is verified and **MUST** be printed prior to updating the batch status to **RB.** The report may be printed or viewed by the Clerical Managers. Clerical Leads, and the Clerks.


**1.4.19.9.4.12** **(03-04-2025)**

##### Check Notice/Letter Date Listing

1. This listing is generated by batch type and notice date. This listing displays the following:



   - Batch type

   - Notice Letter Date

   - Suspense batch

   - SSN


2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select Check Date **L**ist from the pull right menu. The Check Date Listing window displays in the cursor in the ENTER BATCH TYPE field.

6. Enter the Batch Type in the BATCH TYPE field.

7. Enter the Notice Date in the NOTICE DATE field. The Check Date Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listing, for information on how to view reports and listings.


3. This report is generated on demand and can be viewed by the AUR Coordinator or Clerical Managers.


**1.4.19.9.4.13** **(10-10-2018)**

##### Closed Research Reports

1. Closed research reports provide information on cases with no return transaction information or where the tax return cannot be obtained from the Federal Record Centers.

2. The Closed research reports drop-down menu option has a pull right menu. Select one of the following closed research reports:



   - Closed Missing Data Case Report

   - Unavailable Return Report


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select closed researc**H** from the pull right menu.

6. Select _one_ of the available options from the pull right menu. The listing options display in the order stated in (2) above. The selected Closed Research Reports opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report **weekly** to identify cases that are/can be closed.

5. These reports are generated weekly and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.13.1** **(10-10-2018)**

###### Closed Missing Data Case Report

1. This report displays information on cases in Missing Data Suspense BT 32.

2. The Closed Missing Data Case Report displays SSNs in four columns. Cases are filed in the Missing Data Suspense area in SSN order.

3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select closed researc**H** from the pull right menu.

6. Select **M**issing data from the pull right menu. The Closed Missing Data Case Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report each week to pull the cases from the suspense file to be refiled at the appropriate FRC.

5. The Closed Missing Data Report shows SSNs of cases closed since being assigned to Missing Data Suspense batch (BT 32). If data is not secured within 45 days, these cases are systemically closed with a PC 29.

6. This report is system generated weekly and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.13.2** **(10-10-2018)**

###### Unavailable Return Report

1. This report displays information on systemically closed cases in Research BT 30 and BT 34 when the research/return has not been received. The system suspends the SSNs for 60 days before systemically closing with either PC 28 or 29.

2. The system does **NOT** automatically close Married Filing Separate (filing status (FS) 3) cases. These cases display at the end of the Closed Unavailable Return Case Report and must be manually closed with a PC 29.

3. The Closed Unavailable Return Case Report displays two columns: the SSN and CSN.

4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select closed researc**h** from the pull right menu.

6. Select **U**navailable return from the pull right menu. The Unavailable Return Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. Use this report **each week** to pull the cases from the suspense file to be refiled to the appropriate Federal Record Center and to identify FS 3 cases requiring closure.

6. This report is system generated weekly and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.14** **(11-02-2020)**

##### Disaster CSN/SSN Listing

1. This listing is used to monitor cases, impacted by a declared disaster, within a batch.

2. This listing displays the following information:



   - Batch Number

   - Batch Sequence Number

   - Work Unit

   - Sequence Number

   - SSN

   - Expiration Date

   - Virtual Case

   - Zip Type

   - Fema Num


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **D**isaster csn/ssn from the pull right menu. The Disaster CSN/SSN window displays with the cursor in the FEMA NUMBER field.

6. Enter the FEMA or batch number, then press enter. If neither are input, all disaster cases for the tax year will display. The Disaster CSN/SSN Listing opens in a BOE window.



      ### Note:



      Additional entries can be made such as State Code, Disaster Type, Zip code range, and Expire date range. See _IRM 1.4.19.13.3.7_, Disaster Case Processing, for additional information.





      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This report is generated on demand and can be viewed by the AUR Coordinator.


**1.4.19.9.4.15** **(10-10-2018)**

##### Lost Case Report

1. The information displayed on this report represents all cases currently assigned an IPC LC which automatically moves the cases to Lost Case Suspense BT 98. The report data can be sorted by Batch Assigned Date, CSN or SSN.

2. The following information is displayed:




| **Report display** |
| :-: |
| SSN |
| Virtual Indicator (V |
| Previous Process Code |
| Process Code Date |
| Old Batch Number |
| Old Batch Location |
| Old CSN |
| Notice Type |
| Notice date |
| Received Date |
| Total volume |

3. To access the Lost Case Report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Then select L**O**st Case from the pull right menu.

6. Select _one_ of the available options from the pull right menu. The listing options display in the order stated in (1) above. The selected Lost Case Report opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report to determine if Lost Cases are being worked timely. Frequently, this batch and the cases assigned there, receive low priority. However, lost cases are a significant contributor to increased cycle time and impact overall program goals (for example, the screening phase is completed, but there are screening cases in the Lost Case Report; cases assigned to this batch for over a year and no action has been taken). If there are a lot of Lost Cases this is an indication the site is having a problem keeping track of their work and could also indicate training needs. Use this report to monitor volumes and as a research document for locating missing cases.

5. This report has been designated as one of the **"Most Important" .**

6. The Lost Case Report is updated continuously and is generated on demand. It may be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.16** **(10-10-2018)**

##### Misc Letter Listing

1. This is a listing of cases where a letter was issued to the taxpayer, and another action was taken on the case(s) at the same time. These cases have PCs other than 3L, 3S, 6L, 6S, or 8L.

2. The Miscellaneous Letter Listing displays the Batch, Sequence Number, Work Unit, Case Number, and SSN in five columns. The listing also displays the total volume of cases.

3. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **M**isc letter from the pull right menu. The Miscellaneous Letter window displays with the cursor in the ENTER BATCH NUMBER field.

6. Enter five-digit batch number. The Misc. Letter Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. The list is used to pull and mail the manual letters (prepared by the TE) from the identified cases.

5. Clerical generates this listing when a disagreed response batch is updated to "RB" batch status.


**1.4.19.9.4.17** **(03-04-2025)**

##### New Payer Agent Report

1. The New Payer Agent report provides a listing of cases where potential payer agent issue(s) have been identified. This listing is used to identify cases the TEs may have to rework based on new payer agent information. The listing displays the following:



   - SSN

   - CSN

   - EIN

   - Download Date

   - Total Volume


### Note:

See IRM 4.19.3.6.2, AUR Site PayerAgent/Fraud Coordinator - Instructions, and IRM 4.19.3.6.3, National Designated PayerAgent/Fraud Coordinator - Instructions, for more information about the payer agent file and AUR payer agent responsibilities.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **N**ew payer agent from the pull-right menu. The New Payer Agent window displays.

6. Enter the batch number. The New Payer Agent Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. This report can be viewed by the AUR Coordinator and Clerical managers.


**1.4.19.9.4.18** **(03-04-2025)**

##### New Transactions Report

1. The New Transactions Report provides a listing, by SSN/CSN, of all cases containing a new transaction prior to the upload for printing the notice.



### Note:



This report can be generated for BT 89001 (Bankruptcy suspense).

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select n**E**w transactions from the pull right menu. The New Transactions window displays.

6. Enter the batch number, batch type, or notice date. The New Transactions Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. Use this listing **each week** to identify cases which need to be reviewed to clear the system identified condition (new transaction).

4. This report is generated on demand and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.19** **(03-04-2025)**

##### Pull Listings

1. Pull Listings are used to identify the location of a case once correspondence has been received. Pull Listings can be sorted and generated by Sequence Number or by Notice Date. The pull listing displays a **V** to indicate a Virtual Case.

2. The report displays the following:



   - Notice Date

   - Previous Case

   - Suspense Sequence Number

   - Virtual Case field

   - Current Case

   - Sequence Number


3. To view the pull listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select pull listin**G** from the pull right menu. The Pull Listing window displays with the cursor in the ENTER BATCH NUMBER field.

6. Enter the batch number and press **<Enter>**.

7. The selected Pull Listings open in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Clerical uses this listing after received responses have been built into response batches in the system.

5. The listing can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.4.20** **(10-10-2018)**

##### Return Charge-out

1. This option allows the user to reprint Forms 4251 when the return charge-outs are not available for an individual case or cases within a batch.



### Note:



To eliminate unnecessary paper inventory, substitute charge outs should only be printed if absolutely necessary.

2. To access the Return Charge-out:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **R**eturn chargeout from the pull right menu. The Return Chargeout window displays.

6. Enter the SSN. The Return Chargeout opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. This option can be viewed by the AUR Coordinator and managers.


**1.4.19.9.4.21** **(10-10-2018)**

##### Reworked Case Listing

1. The Reworked Cases listing displays cases in Review BT 95 which have been reworked by the TE.

2. The Reworked Case Listing displays three columns; Sequence Number and SSN, and the Total Volume of cases in the batch.

3. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select rewor**k**ed cases from the pull right menu. The Reworked Cases window displays.

6. Enter the batch number. The Reworked Cases Listing opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. The listing is used to identify the cases which must go through the Batch Disassembly Process. The cases in BT 95 not appearing on the list are refiled to the appropriate suspense batch after the batch status is updated to "RB" .

5. This listing may be printed/viewed by the AUR Coordinator and managers.


**1.4.19.9.4.22** **(11-21-2023)**

##### RLS Batch Status Report

1. The RLS Batch Status Report identifies cases worked and released through the technical unit release but have not yet been processed by clerical.

2. The following information displays on the report:



   - Batch (two-digit batch number (36, 45, 65, 75) - shown only once per page)

   - SSN

   - Virtual Indicator (V)

   - PC

   - PC Date

   - SEID

   - Previous Location

   - Release Case Date

   - UWC CSN (when one is available)

   - RCC (Restricted Case Code)


3. This report should be run on a **daily basis** as there are virtual cases not physically available for the clerks to build. These cases should be built from the listing daily.

4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select Released **B**atch from the pull right menu. The RLS Batch Status Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. This report is used to monitor cases in RLS status to ensure timely clerical processing.

6. Cases released through Universal Work appear on this report as XX950.

7. This report is generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.4.23** **(03-04-2025)**

##### Digital Images

1. This report displays a listing of cases with digital images needing clerical processing. The report consists of cases sent to the AUR system digitally from scanning, the Document Upload Tool (DUT), and e-Fax uploads.

2. The report consists of two tabs, ACTION NEEDED and ALL. The ALL tab includes all digital documents. The ACTION NEEDED tab includes cases in need of additional processing by clerical.

3. Cases will remain on the ACTION NEEDED tab until clerical builds into a batch, or the examiner checks the response status box in the RESPONSES window of the Case History screen. Cases will always remain on the ALL tab.

4. The following information displays on the report:




| **Display** | **Description** |
| :-: | :-: |
| CSN | Case Sequence Number |
| SSN | Social Security Number |
| IRS RCVD DT | IRS Received Date |
| UL DATE | Uploaded date |
| RESP TYPE | Response Type |
| SP HAND CODE | Special Handling Code |
| PC | Process Code |
| VIR CASE IND | Virtual Case Indicator |
| DOC TYPE | Document Type |
| Dig ID | Digital Batch ID |
| RCC | Restricted Case Code |
| UID | Assigned SEID |

5. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **S**canned Images from the pull-right menu. The Scanned Images window display with the cursor in the ENTER BEGINNING DATE field.

6. The date defaults to the last day available (the day before the current date). The user inputs the date range in **MM/DD/YYYY** format. The Scanned Images report opens in a BOE window.



      ### Note:



      See IRM 1.4.19.9.1.1 Accessing Reports and Listings, for information on how to view reports and listings.


6. This report is generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.4.24** **(10-10-2018)**

##### Undeliverable Report

1. This report tracks the volume of undeliverables and those with updated addresses by notice type.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**l**erical from the drop-down menu.

5. Select **U**ndelivered notice from the pull right menu. The Undelivered Notice window displays with the cursor in the ENTER BEGINNING DATE field.

6. Enter a beginning date and ending date in **MM/DD/YYYY** format. The Undeliverable report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. This report is generated on demand and can be viewed by the AUR Coordinator or clerical managers.


**1.4.19.9.5** **(11-02-2020)**

#### Coordinator Reports

1. The following reports are located under the C**o**ordinator menu option:




| **Coordinator Menu** |
| :-: |
| Action 61 ltr |
| Auto notice results |
| Batch irs rcvd |
| Batch Run By Site |
| Missing Assess |
| Notice dt List |
| Open Case listing |
| Reorder dates |
| Soft notice |
| Statistical |
| Weekly reports |


**1.4.19.9.5.1** **(10-10-2018)**

##### Action 61 Report

1. The Action 61 Letter Report provides a list of batches for which the system has generated Letter 4314-C.

2. The report displays the following:



   - Batch number

   - Batch status

   - Batch volume

   - IRS Recd Date

   - Letter 4314-C Date

   - Letter 4314-C volume


3. The IRS received date displayed is the oldest received date for the letters generated. The report also displays total volumes of Letter 4314-C generated and mailed daily, weekly, with a cumulative total of letters mailed, and totals for each batch type at the end of the report.

4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator from the drop-down menu

5. Select a**C**tion 61 ltr from the pull right menu. The Action 61 (4314-C) Letter Report opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. The report is generated when AURX075 is run and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.2** **(03-04-2025)**

##### Auto Notice Results Report

1. This report is used to identify closures and fallout conditions from the Auto Notice Run.

2. The report displays three different tabs:



   - Fallout Closure Counts

   - Cases by Result

   - Volume by Notice Type


3. This report defaults to Cases by Results and displays the following information:



   - SSN

   - Result (Fallout condition closure/fallouts)

   - Type

   - Run date

   - Subfile

   - Category

   - Subcategory

   - Extract

   - Site


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu

4. Select C**o**ordinator from the drop-down menu

5. Select a**U**to notice from the pull right menu. The Auto Notice Results window displays with the cursor in the ENTER BEGINNING DATE field.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.

6. Enter a beginning date and ending date in **MM/DD/YYYY** format. The Auto Notice Results report opens in a BOE report.


**1.4.19.9.5.3** **(10-10-2018)**

##### Batch IRS Received Date Report

1. The Batch IRS Received Date Report lists SSNs, older than a specified age, in a specific batch. The cases are listed in sequence number order with SSN.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select batch irs rc**V**d from the pull right menu. The Batch IRS Rcvd window displays with the cursor in the ENTER BATCH NUMBER field.

6. Enter the batch number and press **<Enter>**. The cursor moves to the ENTER NUMBER OF DAYS field.

7. Enter the number of days and press **<Enter>**. The Batch IRS Received Date Report opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. Use this report to monitor the age of cases within a batch.



### Note:



This report can be used to monitor the date range (mixed dates) used in batch building to ensure aged inventory is not being mixed with new inventory.

4. This report is generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.4** **(10-10-2018)**

##### Batch Run By Site

1. This report is used to monitor AUR run controls to determine if they have completed.

2. The report displays the following information at the top of each page:



   - AUR Run Control Number

   - Description of Run Number

   - Frequency


3. The report also displays the following information for each run:



   - Start Dt (displays the date and time the run started)

   - End Dt (displays the date and time the run ended)

   - Run Status


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **B**atch Run by Site from the pull right menu. The Batch Run By Site window displays with the cursor in the ENTER BEGINNING DATE field.

6. Enter the "beginning" date and "ending" date in **MM/DD/YYYY** format. The Batch Run Report Site Specific opens in a BOE window.


### Note:

See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.

**1.4.19.9.5.5** **(03-04-2025)**

##### Missing Assessment Report

1. This report is used to monitor cases where an assessment sent from AUR did not post to IDRS within 10 business days.

2. AUR only receives one update, after the case has been closed, to indicate the assessment did not post. If the assessment posted after the update was received the case information remains on the report. Once the missing assessment is resolved, checking the CORRECTED UNPOSTABLE box in the Assessment window in Case History will remove the case from the Missing Assessment Report.

3. This report displays the following information:



   - SSN

   - Remark Text

   - Process code

   - Process code date

   - Assessment date

   - 290/291 amount


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **M**issing Assess from the pull right menu.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. This report has been designated as one of the **"Most Important"** and must be run **weekly** to avoid barred assessments,

6. This report is generated on demand and can be viewed by the AUR Coordinator.


**1.4.19.9.5.6** **(03-04-2025)**

##### NoticeMailout Dates Report

1. The NoticeMailout Dates Report lists the mail out dates for the various types of notices listed below:



   - CP 2501 Notice

   - CP 2000 Notice

   - Auto Notice

   - Recomp/Amended/PC57/PC95

   - CP 2057

   - Stat Notice


2. The information on this report updates at the disassembled process and displays the following columns:



   - Week Ending Date

   - Review Notice Date

   - Weekly Volume

   - Release Volume

   - Print Notice Date

   - Print Volume


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select notice dt **L**ist from the pull right menu. The Notice Mailout Dates Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This report is generated on demand and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.5.7** **(03-04-2025)**

##### Open Case Listing

1. This listing identifies all open cases in a specific tax year. This information is beneficial in identifying cases in a statute year requiring immediate attention.

2. The report displays the following information:



   - CSN

   - PC

   - SSN

   - ASSMENT EXTN DT

   - DEF AMT

   - MOD BAL AMT

   - RCC


3. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator from the drop-down menu.

5. Select **O**pen Case Listing from the pull right menu. The Open Case Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This report has been designated as one of the **"Most Important" .**

5. This report is generated on demand and can be viewed by the AUR Coordinator and clerical managers.


**1.4.19.9.5.8** **(03-04-2025)**

##### Re-Order Dates Report

1. The Re-order Dates report displays the information from the re-order date screen without being required to change or update the reorder dates already established.

2. The report displays the following information:



   - Extract

   - Reorder Date

   - -L Freeze Date


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select Reorder dates from the pull right menu. The Re-Order Dates Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Only the AUR Coordinator can view this report.


**1.4.19.9.5.9** **(03-04-2025)**

##### Soft Notice Report

1. This report is used to identify cases that fallout from the Soft Notice Run and is only available for 30 days after the soft notices have been run.

2. This report displays the following information:



   - SSN

   - Fallout condition


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu

4. Select C**O**ordinator from the drop-down menu

5. Select **soft notice** from the pull right menu. The Soft Notice Report opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


**1.4.19.9.5.10** **(10-10-2018)**

##### Statistical Reports

1. Statistical reports show statistical data by Subfile and Category where an assessment has been uploaded.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **S**tatistical from the pull right menu. The Statistical window displays with the cursor in the ENTER BEGINNING DATE field.

6. Enter the "beginning" date and "ending" date in **MM/DD/YYYY** format. The Assessment Report By Date opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. This report shows statistical data by Subfile and Income Category where an assessment or refund has been uploaded. Use this report to determine how good the inventory HQ selected for the site to work was.

4. These reports are system generated on demand and can be viewed by the AUR Coordinator.


**1.4.19.9.5.11** **(02-22-2023)**

##### Weekly Reports

1. Weekly Reports provide breakdowns of inventory and are system generated during the normal batch processing runs. Report data is maintained by the system until the next time the Report is generated. User generated information is kept for various timeframes, depending on the Report selected. If a paper record is required for **_any data_**, it should be printed **_as soon as it is available_** and the paper record maintained per campus guidelines.

2. The following reports display under the weekly reports:



### Note:



Based on your assigned profile code some of the menu options shown below may not be available.








| **Menu Options** |
| :-: |
| Non-Stat Listing |
| Aged Response Batch Summary |
| Aged Screening Research |
| Extract Category |
| Inventory |
| MISTLE |
| MISTLE XCL |
| Notice Letter |
| Open Transfers |
| PC Status |
| Reject List (this option has a pull right menu with Current and History options) |
| Statute |
| Weekly PC/IPC |

3. The following subsections provide descriptions of individual reports and more specific information.


**1.4.19.9.5.11.1** **(02-22-2023)**

###### Non-Stat Listing

1. The Non-Stat Listing provides SSNs of cases with non-statutory items. The Tax Court does not have the jurisdiction over certain underpayments and overstatements (non-statutory items). Therefore, when these non-statutory items exist in a case, an assessment or adjustment **must**be made prior to ASED expiration (IRC 31, IRC 6211 and IRC 6652(b)). See IRM 4.19.3 IMF Automated Underreporter Program.



### Note:



When a Statutory Notice is issued, and a TC 560 is input to extend the ASED, it **does not** extend the non-statutory items ASED.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **N**on Stat Listing



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. Use this listing to ensure non-statutory items cases are given priority treatment and assessed timely.

4. This report has been designated as one of the **"Most Important"**.

5. This report must be monitored on a **weekly basis**.

6. The listing is generated weekly and can be viewed by the AUR Coordinators.


**1.4.19.9.5.11.2** **(10-10-2018)**

###### Inventory Report

1. The Inventory Report provides a comprehensive breakdown of the total case inventory by tax year in the site.

2. The report displays the following information (this list is not all inclusive):



   - total volume

   - volume of cases in the screening process

   - cases screened

   - cases closed

   - cases in the CP 2501 phase

   - cases in the CP 2000 phase

   - cases in the response phase

   - cases in the Stat phase

   - cases in suspense


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **I**nventory from the pull right menu. The Inventory Report opens in a Microsoft Edge window as a text document file.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report to determine the overall status of your site's inventory.

5. This report has been designated as one of the **"Most Important"** and should be monitored on a **weekly basis**.

6. The listing is generated weekly and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.11.3** **(03-04-2025)**

###### Weekly PC/IPC Listing

1. The Weekly PC/IPC Listing provides weekly and cumulative volumes for all PCs and IPCs.

2. The report displays the following information:



   - Process Code

   - Released Weekly Count

   - Total Cumulative


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **W**eekly PC/IPC from the pull right menu and input the week ending date in MM/DD/YYY format. The AUR Weekly PC/IPC listing opens in BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this listing to monitor the use of PCs and IPCs (for example, is the site using PC RN and SR to process their partial agrees; how many letters are they issuing; how many cases are being referred to TAS).

5. This listing has been designated as one of the **"Most Important"**.

6. This listing is generated weekly and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.11.4** **(10-10-2018)**

###### Aged Screening Research Pull List

1. The Aged Screening Research Pull List displays information on cases more than 30 days old, assigned to Research Suspense (BT 34).

2. The listing displays the following:



   - Case Location

   - Assigned Date

   - Virtual Indicator (V)

   - SSN

   - Process Code

   - Freeze Code

   - Age Over 30 Days


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. C**o**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select a**G**ed scrn rsrch from the pull right menu. The Aged Screening Research Pull List opens in a Microsoft Edge window as a PDF.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Clerical uses this listing to pull the aged cases as the system automatically closes these cases with PC 29 if the case has not been built into another batch within 60 days.

5. The listing is generated weekly and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.11.5** **(10-10-2018)**

###### Open Transfer Listing

1. The Open Transfer Listing displays SSNs, by location, of cases transferred to a user and not accepted within five days. The report further identifies SSNs not accepted within 15 days. The transfer date and SEID are shown to identify the user needing to take action.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **O**pen transfers from the pull right menu. The Open Transfers window displays.

7. Enter either a specific location number or "ALL" . The Open Transfer List opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. This listing should be used **each week** to identify cases where the transfers have not been accepted and to ensure individual units are working their unit suspense cases timely, ensuring minimum cycle time.



### Note:



**Managers** should ensure cases are accepted on a **weekly basis** and worked/released as quickly as possible.

4. This listing has been designated as one of the **"Most Important"**.

5. The report is generated weekly and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.11.6** **(03-04-2025)**

###### Aged Response Batch Summary Report

1. The Aged Response Batch Summary Report displays batches older than the age set by the AUR Coordinator in the parameter table. The primary sort is batch status. The Batch Status Types are broken down by:



   - Batches Being Built (Unassociated)

   - Associated Batches

   - Assigned to Unit

   - Review Sample

   - Batch Finished

   - Unit Suspense Batches



     ### Note:



     The summary page also provides the total volume of all batches meeting the report criteria.


2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull-right menu.

6. Select Aged Response **B**atch Summary from the pull right menu. The Aged Response Batch Summary Report opens in a BOE window.



      ### Note:



      See IRM 1.4.19.9.1.1 Accessing Reports and Listings, for more information on how to view reports and listings.


3. The following information displays for each batch status:



   - Response Type

   - Oldest IRS Received Date

   - Age

   - Batch Status Date

   - Batch Status Age

   - Batch Number

   - Volume/Aged Cases

   - Batch Status

   - Batch Location


4. The Batch Number Types are broken down by:



   - CP 2501

   - CP 2000

   - Statutory Notice

   - Unit Suspense


5. This report has been designated as one of the **"Most Important"**.

6. The listing is generated weekly and can be viewed by the AUR Coordinator or managers.


**1.4.19.9.5.11.7** **(03-04-2025)**

###### Notice/Letter Suspense Listing

1. Use this report to determine response rates, to ensure the site is purging suspense batches timely and to identify problem cases that have not purged. Cases identified from this report should be monitored/reviewed to ensure they move to the next phase of the program to meet cycle times.

2. The following information displays:



   - Notice date

   - Original mail volume

   - TDC Count

   - Auto Generated Notice

   - Current Volume

   - Purge date

   - Batch Number


### Note:

The Original Mail out Volumes column may be misleading due to system parameter constraints.

3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **N**otice letter from the pull right menu. The Notice/Letter Suspense Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This report has been designated as one of the **"Most Important"**.

5. The listing is generated weekly and can be viewed by the AUR Coordinator or managers.


**1.4.19.9.5.11.8** **(03-04-2025)**

###### Extract Category Listing

1. The Extract Category Listing shows the Subfile and Category types in a specific extract . The categories are further broken down into subcategories.

2. To access and view this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**o**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **E**xtract cat from the pull right menu. The Extract Category Listing window displays.

7. Enter the six-digit cycle number (for example 202341). The Extract Category Listing opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. This report is used to monitor the inventory download for each extract.

4. This report has been designated as one of the **"Most Important" .**

5. The Extract Category listing is generated weekly when the extract is downloaded. The listing can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.11.9** **(03-04-2025)**

###### Statute Listing

1. The Statute Listing provides SSNs of cases with an imminent statute expiration of 120 days or less. The case sequence number and statute date are displayed with the SSN. The SSNs are shown with the earliest statute dates first.

2. The following information displays:



   - SSN

   - CSN

   - Statute Date


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **S**tatute from the pull right menu. The Statute Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this listing to ensure imminent statute cases are given priority treatment.

5. This report has been designated as one of the **"Most Important" .**

6. This report must be monitored on a **weekly basis**.

7. The listing is generated weekly and can be viewed by the AUR Coordinator or managers.

8. Verify, on a quarterly basis, the Operation has completed the required search for statute imminent cases and take the following actions:



1. Complete Form 11122-A, Manager’s Statute Certification.

2. Forward completed Form 11122-A to the Planning and Analysis (P&A) Staff.

3. The P&A staff forwards a consolidated Campus report to the Headquarters Statute Analyst.


**1.4.19.9.5.11.10** **(11-21-2023)**

###### Reject Listing

1. The AUR System generates a weekly Reject Listing, identifying rejected cases in CSN. These batches **must be monitored weekly** to ensure timely actions are taken.

2. There are six reject conditions for CP Notices.



   - 1 - Restricted Interest

   - 2 - Military Action

   - 4 - Invalid Interest (per SCRS)

   - 5 - Not found on TlF

   - 6 - Invalid Interest (per AUR)

   - 8 - Disaster Case Type 4


3. The listing is used by clerks to pull the cases and build as follows:



   - Reject codes 1, 2, 4, and 6 are built into BT 61 (Manual Interest)

   - Reject codes 5 and 8 are built into Reject BT 39


4. The information displayed on the list is as follows:



   - CSN

   - Virtual Indicator (V)

   - SSN

   - Reject Code

   - Total volume for each Reject Code

   - Total Reject Volume


5. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator form the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **R**eject list from the pull right menu.

7. Select **C**urrent from the pull right menu opens the most current listing . Selecting **H**istory from the pull-right menu opens a historical listing of prior weeks. The Reject Listing opens in a Microsoft Edge window as a text document file.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


6. This listing has been designated as one of the **"Most Important"** and should be monitored on a **weekly basis**.

7. The listing is generated weekly and can be viewed by the AUR Coordinator, clerical managers and the lead clerk.


**1.4.19.9.5.11.11** **(03-04-2025)**

###### PC Status Listing

1. The PC Status Listing provides a period and a cumulative count of each PC uploaded.

2. The following information displays:



   - Code Description

   - Period

   - CUM


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **P**c us from the pull right menu and input the week ending date in MM/DD/YYY format. The PC Status Listing opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this listing to see how the inventory has been closed, (for example, determine what percentage of cases were fully agreed, no change rate, screen out rate). The listing can also be used to determine if a site has obtained sufficient closures to meet closure goals.

5. This listing has been designated as one of the **"Most Important"** and should be monitored on a **weekly basis**.

6. The listing is generated weekly and can be viewed by the AUR Coordinator.


**1.4.19.9.5.11.12** **(03-04-2025)**

###### MISTLE Report

1. The MISTLE Report consists of two pages. The first page of the report provides period and cumulative totals of various PC groups. The second page provides information on in-house correspondence such as: volume of responses built, volume of aged responses, volume of cases awaiting Action 61/Policy Statement P-21-3, and volume of cases awaiting assessments for each phase of the program.

2. The following information displays:



   - URP Process Codes

   - Period

   - Cum


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select **M**istle from the pull right menu and input the week ending date in **MM/DD/YYYY** format. The MISTLE Report opens in a Microsoft Edge window as a text document file.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report **each week** to monitor the overall progress of the program, including program benchmark dates and closures. The second page of the report is used to monitor in-house correspondence inventory and provides data for the Correspondence Inventory Report (CIR) required by Headquarters.

5. This report has been designated as one of the **"Most Important"** and should be monitored on a **weekly basis**.

6. This report is generated weekly and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.5.11.13** **(02-22-2023)**

###### MISTLE XCL Report

1. The MISTLE XCL Report displays as an Excel Spreadsheet. The report provides period and cumulative totals of various PC groups, and provides information on in-house correspondence such as: volume of responses built, volume of aged responses, volume of cases awaiting Policy Statement P-21-3, and volume of cases awaiting assessments for each phase of the program.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select C**O**ordinator from the drop-down menu.

5. Select **W**eekly reports from the pull right menu.

6. Select mistle **X** cl from the pull right menu.

7. Enter the week ending date in the ENTER WEEK ENDING DATE window. The MISTLE XCL report opens in a Microsoft Edge Window as an Excel file download.


3. Headquarters (HQ) uses this report **each week** to monitor the overall progress of the program, including program benchmark dates and closures. The report is used to monitor in-house correspondence inventory and provides data for the Correspondence Inventory Report (CIR) required by HQ.

4. This report has been designated as one of the **"Most Important"** and should be monitored on a **weekly basis**.

5. This report is generated weekly and can be viewed by the AUR Coordinators.


**1.4.19.9.6** **(03-04-2025)**

#### Specialized Reports

1. The following reports are located under the **S**pecialized menu option:


**1.4.19.9.6.1** **(03-04-2025)**

##### Action Required

1. This listing identifies cases viewed by another site (per phone call) and determined to have some type of action needed on the case (Action Required box is checked) that can’t be taken through UWC.




| **Menu Options** |
| :-: |
| Action Required |
| AN (Auto Notice) review sampling |
| Batch suspense inventory |
| Bankruptcy sts |
| Employee |
| IDT suspense listing |
| MFT 31 inventory report |
| Payer agent list |
| Recon |
| Review sampling |
| Restricted case report |
| TDC notice suppression |

2. This report is used to ensure timely actions are taken on these cases.

3. The report consists of seven columns for the following:



   - CSN

   - STATUS

   - SSN



     ### Note:



     A Virtual Indicator (V) displays to the right of the SSN if it is a virtual case.

   - Contact Date

   - Age From Contact Date

   - RCC

   - UID (SEID)


4. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select Action Re**q**uired from the pull right menu.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. The telephone contact is considered a taxpayer response and cases on this listing are handled like a response.

6. The Action Required Listing requires special handling. Use this listing **each week** to build to the appropriate response batch type or transfer to a locally designated SEID.



### Note:



An SSN does not drop off the Action Required Listing until a TE takes the needed action and unchecks the box; therefore, SSNs show up on the Listing each day until a TE has worked the case.

7. This report can be generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.6.2** **(11-15-2022)**

##### AN (Auto Notice) Reviewing Sampling

1. The Auto Notice Review Sampling report identifies cases assigned to batch types 27XXX, which are cases screened through the auto notice process.

2. This report is generated and monitored by Headquarters when an auto notice batch is available for review.

3. The report provides the following information:



   - SSN

   - Name Control

   - Subfile Key

   - Category

   - Sub Category

   - Batch

   - Discrepancies

   - Result Group

   - Result Text

   - Process Code


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select **A**N Review Sampling from the pull right menu. The AN Review Sampling report opens in a BOE window



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to printview reports and listings.


5. This report is generated on demand and can be viewed by the AUR Coordinator.


**1.4.19.9.6.3** **(03-04-2025)**

##### Batch Suspense Inventory Report

1. The Specialty Batch Suspense Inventory report identifies cases assigned to batch types 89001, 89003, and 94. Cases in these batch types are either bankruptcy, identity theft, or fraud.

2. This report is used to monitor the bankruptcy, identity theft, and fraud suspense inventories.

3. The report is divided by batch number (89001, 89003, and 94) and provides the following information:



   - Virtual Indicator

   - SSN

   - SEID

   - Process Code

   - Days from Assign date

   - Days from IRS Rec’d date

   - Days from Last Letter

   - Days from Last CP Notice

   - Days from Last STAT Notice


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select **B**atch Suspense Inventory from the pull right menu. The Specialty Batch Inventory report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. The Specialty Batch Suspense Inventory report is generated weekly. The report can be viewed by the AUR Coordinator, managers, and designated users.


**1.4.19.9.6.4** **(10-10-2018)**

##### Bankruptcy

1. The Bankruptcy us Listing displays cases identified as having a **"-V"** and/or **"-W"** freeze code present. Bankruptcy cases with a "-V" freeze can be identified by the presence of a TC 520 and closing code 60 through 67, 83 or 85 through 89. Bankruptcy accounts with a "-W" freeze will have a TC 520 with a closing code of 81 or 84. This report also displays freeze code(s), CSN, Virtual indicator, and SSN of each case identified as Bankruptcy when each extract is downloaded.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select Ban**K**ruptcy sts from the pull right menu. The Bankruptcy us Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. Use this listing to identify Bankruptcy cases for pre-notice closure.

4. The listing is generated weekly, and can be viewed by the AUR Coordinator, managers, and Bankruptcy Coordinator.



### Note:



In addition to the AUR reports, bankruptcy inventory should be reviewed every month using AIS, PACER, and IDRS.


**1.4.19.9.6.5** **(11-02-2020)**

##### Employee Reports

1. The Employee reports provide information specific to employee cases.

2. This report option contains a menu, which allows the user with a specialized profile code to pull five different reports.



   - Auto Assessment

   - Closed Inventory

   - Employee Aging

   - Open Inventory

   - Open Transfers


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu

5. Select e**M**ployee from the pull right menu.

6. Select _one_ of the available options from the pull right menu. The listing options display in the order stated in (2) above. The selected Employee Report opens in either a Microsoft Edge or BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. These employee case reports can only be accessed, viewed by the manager authorized to handle employee cases, the AUR Coordinator, and designated user.


**1.4.19.9.6.5.1** **(10-10-2018)**

###### Auto Assessment Report - Employee Cases

1. The Auto Assessment Report provides a listing of SSNs, in sequence number order, of employee cases which have been automatically assessed in other than a Fully Agreed Response batch. This listing is accessed to ensure employee cases are in correct adjustment sequence series order for shipment to files. An asterisk (\*) displays in the NO SOURCE DOC field when there are no attachments to associate with the Computer Form (CF) 5147.

2. To access this report, see _IRM 1.4.19.9.6.5_, Employee Reports.

3. Generate this report after an employee batch is completed and updated to "RB" status. This report is updated daily by the system and must be printed/viewed daily. Each time the AURX060 is run, the report displays new information.


**1.4.19.9.6.5.2** **(10-10-2018)**

###### Closed Inventory - Employee Cases

1. The Closed Inventory report displays all closed employee cases. This report displays the SSN, SEID, Process Code, and Process Code date.

2. To access this report, see _IRM 1.4.19.9.6.5_, Employee Reports.

3. This report is generated weekly by the system.


**1.4.19.9.6.5.3** **(10-10-2018)**

###### Employee Aging Report

1. The Employee Aging Report indicates which employee cases have met appropriate timeframes, employee cases closed by the system and employee cases where missing data was received.

2. To access this report, see _IRM 1.4.19.9.6.5_, Employee Reports.

3. The report is updated weekly.

4. The report can be viewed by the AUR Coordinator and the manager authorized to handle employee cases.


**1.4.19.9.6.5.4** **(10-10-2018)**

###### Open Inventory Report - Employee Cases

1. The Open Inventory Report displays cases in BT 90 and 91 in CSN order and cases in BT 92 in SSN order.

2. To access this report, see _IRM 1.4.19.9.6.5_, Employee Reports.

3. Use this report to monitor open employee cases.

4. This report is generated weekly by the system.


**1.4.19.9.6.5.5** **(10-10-2018)**

###### Open Transfers - Employee Cases

1. The Open Transfer report displays the SSNs of employee inventory, by location, of cases transferred from one user to the user authorized to work employee cases and not accepted by the receiving user within five days. The report further identifies SSNs of cases not accepted within 15 days. The transfer date and receiver SEID are shown to identify the user needing to take action.

2. To access this report, see _IRM 1.4.19.9.6.5_, Employee Reports.

3. The report is updated by the system weekly.


**1.4.19.9.6.6** **(11-15-2022)**

##### IDT Suspense Listing

1. The IDT Suspense List report identifies cases assigned to batch type 89003 that have been sent to IDTVA for determination.

2. This report is generated to monitor IDT inventory to ensure timely follow up.

3. This report provides the following information:



   - Primary SSN

   - Secondary SSN

   - Process Code

   - Process Code Date

   - Days from Process Code

   - Stat Date

   - Days From Stat


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select I**D**T Suspense listing from the pull right menu. The IDT Suspense Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. This report has been designated as one of the **"Most Important"**.

6. This report is generated on demand and can be viewed by the AUR Coordinators, managers, and designated user.


**1.4.19.9.6.7** **(03-04-2025)**

##### MFT 31 Inventory Report

1. The MFT 31 Inventory Report identifies cases assigned to batch types 89004, 89005 and 89006. Cases in these batch types have either a single signature of agreement on a jointly filed return or only one spouse has petitioned the U.S. Tax Court (non-petitioning spouse (NPS)).

2. This report is used to monitor the Agree/Non-agree and NPS Suspense inventory.

3. The report is divided by batch number (89004, 89005, and 89006) and provides the following information:



   - Virtual Indicator (if applicable)

   - SSN

   - SEID

   - Process Code

   - Day from Assign Date

   - Days from IRS Rec'd Date

   - Days from Last Letter

   - Days from Last CP Notice

   - Days from Last Notice


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select M**F**T 31 Inventory Report from the pull right menu. The MFT 31 Suspense Inventory report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. The Agree/Non-agree Suspense Inventory report is generated weekly. The listing can be viewed by the AUR Coordinator, managers, designated user(s).


**1.4.19.9.6.8** **(11-02-2020)**

##### Payer Agent List

1. The Payer Agent list provides a listing of all identified payer agents.

2. To access this listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select pay**E**r agent from the pull right menu. Select one of the options from the drop-down menu. The Bad Payer List opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. This listing can also be accessed by taking the following actions:



1. Select the tax year from the AUR Year menu.

2. Select **P**ayer/Fraud from the AUR main menu.

3. Select payer **A**gent list from the drop-down menu. The Bad Payer List opens in a Microsoft Edge window as a text document file.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This listing is system generated and can be viewed by the AUR Coordinator and the Payer Agent Coordinator.


**1.4.19.9.6.9** **(10-10-2018)**

##### Recon Reports

1. The Recon reports provide information specific to recon cases.


**1.4.19.9.6.9.1** **(11-21-2023)**

###### Recon - Open Inventory

1. The information displayed on this report represents all cases currently assigned to BT 81 and BT 82.

2. The following information is displayed:



   - CSN

   - SSN

   - Current SEID

   - PC

   - PC Date

   - SEID

   - Received Date

   - ASED Date


3. To access the Recon Open Inventory Report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Then select **R**econ from the pull right menu.

6. Select **O**pen Inventory from the pull right menu. The Open Inventory Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report **every week** to determine if Recon Cases are being worked timely.

5. The Recon Open Inventory Report is updated continuously and is generated on demand. It may be viewed by the AUR Coordinator.


**1.4.19.9.6.9.2** **(03-04-2025)**

###### Recon - Closed Inventory

1. The information displayed on this report represents all cases which have been assigned a Recon process code in the specified time period.

2. The following information is displayed in two columns:



   - SSN

   - SEID

   - PC

   - PC Date


3. To access the Recon Open Inventory Report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Then select **R**econ from the pull right menu.

6. Select **C**losed Inventory from the pull right menu. The Closed Inventory Report opens in a BOE window. In the BOE Prompts window select a Start Date and End Date for the range.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this report to determine the volume of Recon Cases closed for a specific tax year.

5. The Recon Closed Inventory Report is updated continuously and is generated on demand. It may be viewed by the AUR Coordinator.


**1.4.19.9.6.9.3** **(11-21-2023)**

###### Recon - Issue Listing

1. The report displays the total volumes of Recon Codes by date range.

2. The following information is displayed:



   - Reconsideration Code

   - Reconsideration Issue


3. To access the Recon Issue Listing:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Then select **R**econ from the pull right menu.

6. Select **I**ssue from the pull right menu. The Recon Issue Report window displays with the cursor in the ENTER BEGINNING DATE field.

7. Enter the "Beginning" date and "Ending" date in **MM/DD/YYYY** format. The Recon Issue Listing opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to View reports and listings.


4. Monitor/use this report to determine the volume of Recon Issue Codes.



### Note:



Recon Issue Codes can be edited or deleted (set to "Reserved" ) by HQ Analysts.

5. The Recon Issue Listing is updated continuously and is generated on demand. It may be viewed by the AUR Coordinator.


**1.4.19.9.6.10** **(10-10-2018)**

##### Review Sampling - Product Review Sample List

1. The Product Review Sample List provides a listing of SSNs with a specified PC and in a specific batch. When generating the report, the system prompts the user for sample size.

2. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select review samplin**G** from the pull right menu.

6. Select **P**rod revw smpl from the pull right menu. The Create Product Review Sample window displays with the cursor in the BATCH NUMBER TO BE REVIEWED field.

7. Enter the batch number to be reviewed. The cursor moves to the PROCESS CODE TO BE REVIEWED field.

8. Enter the PC to be reviewed. The cursor moves to the SAMPLE PERCENT TO BE SELECTED field.

9. Enter the two-digit percent of sample size (01-50). The Product Review Sample List opens in a Microsoft Edge window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


3. Use this list to generate a random sampling of work for managerial product reviews.

4. This listing is generated on demand and is available to technical managers for their unit only.


**1.4.19.9.7** **(03-04-2025)**

#### Restricted Case Report

1. The Restricted Case Report consists of two tabs: Restricted Case (Open AUR Cases) and Restricted Case Batch 96 (Closed AUR Cases)

2. This report is generated to monitor the status of cases having a restricted case code.

3. The report provides the following information:



   - SSN

   - Old UID

   - Batch

   - Batch us

   - Process Code

   - Process Code Date

   - Restricted Case Code

   - Purge Date


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select **R**estricted case report from the pull right menu. The Restricted Case Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. This report has been designated as one of the **"Most Important"**and monitored on a daily basis.



### Caution:



Cases identified as batch status RLS need to be processed by clerical in a timely manner.

6. This report is generated on demand and can be viewed by the AUR Coordinators.


**1.4.19.9.8** **(03-04-2025)**

#### TDC Notice Suppression

1. The TDC Notice Suppression report identifies cases where the mail out of the notices have been suppressed using the TDC Notice Suppression box.

2. This report is generated to monitor TDC cases by SSN to ensure recomputed notices have been provided to the taxpayer via eGain when the user checks the TDC upload box. t.

3. The report provides the following information:



   - SSN

   - Current Batch

   - Current PC

   - Notice Date

   - TDC Upload By

   - Uploaded


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **S**pecialized from the drop-down menu.

5. Select **T**DC Notice Suppression from the pull right menu. The TDC Notice Suppression opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. This report has been designated as one of the **"Most Important"**.

6. This report is generated on demand and can be viewed by the AUR Coordinators and Manager.


**1.4.19.9.9** **(10-10-2018)**

#### Telephone Reports

1. The following reports are located under the **T**elephone menu option:



   - Telephone Case call out

   - Telephone Tracking report


**1.4.19.9.9.1** **(11-21-2023)**

##### Telephone Case Callout

1. The data for this report is pulled from cases where an outcall was indicated on the account.

2. The report displays the following information:



   - SSN

   - Category Code

   - Category Description

   - Correspondence Date


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **T**elephone from the drop-down menu.

5. Select telephone **C**ase call out from the pull right menu. The Telephone Case Outcall Report window displays with the cursor in the ENTER BEGINNING DATE field. The Telephone Case Outcall report opens in a BOE window

6. Enter the beginning and ending dates in the **MM/DD/YYYY** format.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. Use this list to generate a report of cases where an outcall was made.

5. This report is generated on demand and is available to view by the AUR Coordinator and technical managers.


**1.4.19.9.9.2** **(10-10-2018)**

##### Telephone Tracking Report

1. The data for this report is pulled from cases where the phone contact box was checked.

2. This report displays the following information:



   - Number of calls received by category

   - Number of calls received by sub-file


3. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **T**elephone from the drop-down menu.

5. Select **Telephone** tracking from the pull right menu. The Telephone Case Tracking Report window displays with the cursor in the ENTER BEGINNING DATE field.

6. Enter the beginning and ending dates in **MM/DD/YYYY** format. The Telephone Case Tracking Report opens in a BOE window.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


4. This report is generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.10** **(03-04-2025)**

#### Unit Inventory Report

1. The Unit Inventory Report identifies the cases assigned to tax examiners. It can be generated by User ID, Location or all.

2. The report displays the following information for each tax examiners assigned to the unit:



   - Tax Examiner Name

   - SEID

   - Location

   - Employee Status code


3. The report also displays the following information:



### Caution:



Cases assigned to TEs through Universal Work (location XX950) do not appear on the Unit Inventory Report. Use Universal Work Suspense Report to identify and monitor UWCs needing to be worked.








| **Case Specifics** |
| :-: |
| Site |
| Batch number |
| Work Unit (WU) |
| Sequence Number |
| SSN |
| Assigned date |
| PC |
| PC date |
| PC UID (SEID) |
| Received Date |
| New Tran |
| Payer Agent |

4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control menu.

4. Select **U**nit Inventory from the drop-down menu.

5. Enter either location number, a specific SEID, or "ALL" . The Unit Inventory Report opens in a Microsoft Edge window as a text document file.



      ### Note:



      See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to view reports and listings.


5. Use this report to monitor employee and unit inventories to determine if a unit or an employee is having difficulty working their inventory in a timely manner. As cases assigned to unit suspense are not used to determine "aged inventory" it is vital that employee unit suspense activity be closely monitored.

6. This listing has been designated as one of the **"Most Important"**.

7. This report is generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.11** **(03-04-2025)**

#### Universal Reports

1. The following reports are located under the U**n**iversal menu option.



   - Universal Work (UW) Suspense

   - Universal Case (UC) Closed


**1.4.19.9.11.1** **(03-04-2025)**

##### Universal Work (UW) Suspense

1. If the Tax Examiner determines the action needs to be taken at the initiating site, they check a box, which places the SSN on the **Universal Work (UW)** Suspense listing.

2. This listing consists of two tabs: Your Users suspense and Your cases suspended:



   - Your users suspense identifies cases controlled by local users.

   - Your cases suspended identifies local cases controlled by users from any site.


3. This report is used to ensure timely actions are taken on these cases. The report consists of 10 columns for the following



   - Batch

   - SSN

   - Assign Date

   - ASED

   - Days Controlled

   - Process Code

   - Process Code Date

   - Assigned

   - Restricted Case Code

   - Case Site/User’s site


4. To access the listings:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **R**eports from the Control Menu.

4. Select u**n**iversal from the drop-down menu.

5. Select UW **S**uspense from the pull right menu. The Universal Work Suspense opens in BOE window.



      ### Note:



      See IRM 1.4.19.9.1.1, Accessing Reports and Listings, for information on how to view reports and listings.


5. This report can be generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.11.2** **(03-04-2025)**

##### UC Closed

1. This listing consists of two tabs:



   - Users in your site closed consist of cases worked by local users.

   - Cases closed to your site consist of local cases worked by users from any site.


2. This report is used to identify the volume of worked cases by PC/ IPC.

3. The report consists of 5 columns for the following:



   - Site

   - Weekly Volume

   - Weekly TDC

   - CUM

   - TDC Accept CUM


4. To access this report:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR menu.

3. Select **R**eports from the Control menu.

4. Select u**n**iversal from the drop-down menu.

5. Select U**C** Closed from the pull right menu. The Universal Closed Case listing opens in BOE window.



      ### Note:



      See IRM 1.4.19.9.1.1, Accessing Reports and Listings, for information on how to view reports and listings.


5. This report can be generated on demand and can be viewed by the AUR Coordinator and managers.


**1.4.19.9.12** **(11-01-2011)**

#### Batch History

1. While the Batch History is not a report it provides a complete history of any action taken on the batch.

2. To view the Batch History:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **B**atch from the Control menu.

4. Select batch **H**istory from the Batch menu. The Batch History window displays with the cursor in the BATCH field.

5. Enter the batch number and press **<Enter>**. The current batch history displays.

6. Press **<F8>** to exit.


### Note:

To query another Batch History, the user can press **<F7>** to clear the screen and enter the next batch number without exiting the window.

**1.4.19.9.13** **(11-21-2023)**

#### Case History

1. While the Case History is not a report it provides a complete history of any action taken on the batch.

2. Users with a clerical profile access case history by taking the following actions:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **C**ase history from the drop-down menu. The History/View/Request window displays with the cursor in the ENTER SSN field.

5. Enter the SSN.

6. Press **<Enter>** and **<Enter>** again to bypass the PHONE CONTACT box.

7. Press **<F8>** to exit.


3. Users with a technical profile access case history by taking the following actions:



1. Select the tax year from the AUR Year menu.

2. Select re**V**iew from the AUR main menu.

3. Select **C**ase history from the drop-down menu. The History/View/Request window displays with the cursor in the ENTER SSN field.

4. Enter the SSN.

5. Press **<Enter>** and **<Enter>** again to bypass the PHONE CONTACT box.

6. Press **<F8>** to exit.


4. If a print of Case history is needed take the following actions,



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **P**rint from the Control menu.

4. Select **C**ase Contents from the drop-down menu.

5. Select case **H**istory from the pull right menu. The SSN FOR PRINT window displays with the cursor in the ENTER SSN field.

6. Enter the SSN. The Case History Transcript opens in a Microsoft Edge window as a text document file.

7. See _IRM 1.4.19.9.1.1_, Accessing Reports and Listings, for information on how to print.


**1.4.19.9.14** **(03-04-2025)**

#### Unassociated Cases

1. While the Unassociated Cases is not a report it provides a list of all digital documents which require update or correcting prior to being built into AUR. This listing is always accessed from the most current AUR tax year but includes documents for all tax years. It also shows a list of cases which have been rerouted as non-AUR documents.

2. To view the Unassociated Cases:



   - Select the current tax year from the AUR Year menu.

   - Select **C**ontrol from the AUR main menu.

   - Select **B**atch from the Control menu.

   - Select **U**nassociated Cases from the Batch menu. The Unassociated Cases window defaults when the Unassociated Documents radio button is selected.

   - Click the Reroute Documents radio button to view rerouted documents instead.

   - Click the Report button to open both listings in a BOE window.



     ### Note:



     See IRM 1.4.19.9.1.1, Accessing Reports and Listings, for information on how to view reports and listings

   - Press **<F8>**to exit the window in AUR.


3. The Unassociated Case window defaults with the Unassociated Documents radio button selected. Click the Reroute Documents radio button to view rerouted documents instead.

4. There are two non-radio buttons on the Unassociated Case window, SSN Search and Report:



   - SSN Search - opens the SSN Search window used to identify all tax years associated with the SSN.

   - Report - opens both the Unassociated case and Reroute Listings in the BOE window.



     ### Note:



     See IRM 1.4.19.9.1.1, Accessing Reports and Listings, for information on how to view reports and listings.


**1.4.19.10** **(10-12-2016)**

### Non AUR System Reports

1. There are times when it is necessary to access reports not on the AUR system (for example IDRS reports, ORCAS). For additional information on IDRS security see IRM 10.8.34, IDRS Security Controls.


**1.4.19.10.1** **(10-12-2016)**

#### IDRS Case Monitoring Reports (Control D)

1. Control-D is Web Access software which allows viewing of reports electronically. Control-D reduces the print output and allows faster access and greater report management for users to their respective report files.

2. Users are required to complete BEARS process to gain access to Control-D.

3. Reports are made available to the users upon logging in to the Control-D server. This action is necessary to ensure employees have access to the correct Organization and workload.

4. Some of the Control - reports accessed by AUR users are:



   - CCA 4243

   - AMRH transcripts

   - Statutory notice


### Note:

This list is not all inclusive.

**1.4.19.10.2** **(11-21-2023)**

#### IDRS CCA 4243

1. The IDRS CCA 4243 Report is generated weekly and is accessed using Control D. It contains all cases controlled to an IDRS employee number (in IRS received date order) and must be reviewed and monitored on a weekly basis to ensure inventory is moved according to first in/first out (FIFO) order. Managers use this report to:



   - Identify cases requiring action

   - Identify specific cases for review

   - Monitor the size of the employees' inventories

   - Determine if employees are working inventory in the proper order

   - Identify potential management problem cases

   - Monitor AMRH transcripts


2. In addition, discrepancies between the CCA report and physical inventory are identified. Timely action should be taken on the following:



   - Unpostable conditions

   - Aged correspondence

   - STAUPS

   - Statute imminent cases

   - Interim letters

   - Erroneous/multiple control bases

   - Open control bases on resolved cases

   - AMRH transcripts


3. The Manager/Lead should utilize CCA 4243 as a tool to identify weekly receipts and closures under each category and the number of cases aged upon receipt.

4. Department Managers or a delegate should review the report to monitor the number of cases and age of inventory in each category to determine if resource changes are needed. The Department Manager should maintain a copy of these reports for one year.

5. This report is generated weekly and can be accessed by anyone who has authorization to use Control D. For more information refer to your local Planning and Analysis (P&A).


**1.4.19.10.3** **(11-21-2023)**

#### Overage Report Compiler And Sorter (ORCAS) Reports

01. ORCAS is an overage report generation system that utilizes the Control D 4243 report to create a personalized listing for the user. ORCAS will present the user with data from their assigned and controlled IDRS cases.

02. ORCAS provides the same data described in _IRM 1.4.19.10.2_(4) above. The data is generated in Microsoft Excel format which allows the user to sort and filter the data as needed.

03. ORCAS is **available** to all Service Centers: and is available to anyone needing to monitor their controlled IDRS inventory.



    ### Note:



    The ORCAS Delivery System has different versions and is managed at a campus level for security purposes. To gain access, contact your Service Centers POC at the following link Welcome to the ORCAS Page.

04. Once access is granted, it is recommended the ORCAS icon be saved to the desktop and run the application from there each week.



    ### Note:



    A Team ORG must be established in Control D in order for ORCAS to generate a report.

05. The import process can take an extended amount of time. On average ORCAS delivers about 3,000 cases a minute. Once the operation has completed, ORCAS will alert you when the operation is completed/done. **Do not interrupt the process.**

06. Once the information is imported to the ORCAS database, users can then use the TE and Manager version of ORCAS to pull their data. ORCAS delivery will automatically clear out the prior week data as well as update the run date.

07. Management is able to view all the team listings for the operation from the ORCAS team selection window. Team Managers should select their team’s number from the list to view.

08. ORCAS will save your settings for the next time you pull your report. Multiple teams can be selected and viewed together on the same report by selecting multiple teams.

09. Changes to your team selection can be made using the “Options” button in the main sheet and then selecting the “Update Teams” button. ORCAS then generates your report.

10. Tax Examiners using ORCAS for the first time will be alerted their IDRS number is not in the server and needs to be input. Tax Examiners need to log into IDRS so ORCAS can locate their IDRS number and store it in the server. After the initial request their IDRS number is stored and logging into IDRS will not be required. Once completed ORCAS will generate the aged listing for the specific user.


**1.4.19.10.4** **(10-26-2021)**

#### Control D - Statutory Notice of Deficiency

1. All file copies of an AUR Statutory Notice of Deficiency are housed on Control D.

2. When a request for a copy of a statutory notice of deficiency is received (for example, Appeals), Control D must be accessed to locate the requested file copy for tax year’s not in the AUR system.

3. There are several filters available to assist in locating the file. Only the following filter option is used by AUR: Remark.

4. To filter the report take the following actions:



1. Click on Filter, a box named Filter Report List appears.

2. Enter notice date in "YYYYMMDD" format in the Remark field.

3. Click the "Migrated" check box in the Report Status box.

4. Click "Apply" . This pulls up all notices for the specified date.


5. If unable to locate the file copy, send an email via secured messaging to the designated HQ Analyst.

6. This report is generated weekly and can be accessed by anyone who has authorization to use Control D.


**1.4.19.11** **(03-04-2025)**

### Secure Messaging Taxpayer Digital Communication (TDC) Searches

1. eGain allows users to query data related to TDC cases and their associated activities through the Search and Advanced Search functions. The search functions can be used to view eGain (non-AUR) inventory and perform additional research as needed.



### Note:



For more information on using eGain and running queries, see the Secure Messaging Taxpayer Digital Communication User Guide.


**1.4.19.12** **(06-01-2006)**

### Security

1. The AUR System security is designed to protect both the taxpayers and the AUR users. It is important to protect taxpayer data from unauthorized disclosure. It is equally important to prevent unauthorized adjustments to taxpayer accounts. Designated employees are given specific security responsibilities to protect hardware, software, and taxpayer information.


**1.4.19.12.1** **(06-01-2006)**

#### Roles and Responsibilities

1. The System Security Analyst (SSA) duties are usually assigned to the AUR Coordinator. SSA responsibilities include:



1. Completing the actions necessary to add new users, delete users and/or update existing users.

2. Notifying management officials of any known or suspected security breaches.


2. AUR managers and the AUR Coordinator responsibilities include:



1. Providing for the physical and system security in their area (This includes questioning anyone attempting to use the AUR equipment if their identity and purpose is not known).

2. Initiating the addition, update and deletion of users.

3. Serving as backup, when needed, for another AUR manager to initiate adding, updating, and deleting users. Only an AUR Coordinator can add or update an AUR manager on the system.

4. Unlocking SEIDs and/or AUR terminals.

5. Assigning/updating appropriate status and profile codes for users.

6. Changing a user’s unit location number when appropriate. This function should only be used when an employee is reassigned to another unit.

7. Informing employees about their Security responsibilities.


3. AUR users are responsible for the following:



1. Using the AUR system and data only in performing their official duties.

2. Safeguarding data and equipment.

3. Reporting any infractions to the manager.

4. Protecting their passwords.


**1.4.19.12.2** **(10-26-2021)**

#### Logins, Passwords and Single Employee Identification (SEID)

1. When a user is added to the AUR system, the employee is identified by their SEID. The SEID is a combination of numeric and alpha characters.

2. New users are required to complete the BEARS process to gain access to AUR. Once the BEARS has been approved a login and temporary password will be generated by the AUR system.



### Note:



New AUR users will also need to request BOE USER PROD (AUTOMATED UNDERREPORTER-AUR) through BEARS to gain access to Business Objects (BOE) to access certain reports.

3. The first time the user logs on the AUR System using their temporary password, the system forces the user to change their password. The new password expires at a maximum of 90 days.

4. When a user forgets their password, a manager or AUR Coordinator has the ability to issue a temporary password and will take the following actions:



1. ≡ ≡ ≡ ≡ ≡ ≡ ≡**≡ ≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡

2. ≡ ≡ ≡ ≡ ≡**≡ ≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡

3. ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡

4. ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡≡ ≡



      ### Note:



      ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡






      | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
      | --- |
      | **≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
      | **≡ ≡ ≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ |
      | **≡ ≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
      | **≡ ≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
      | **≡ ≡ ≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
      | **≡ ≡ ≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
      | **≡ ≡**≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |

5. ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡



      ### Caution:



      ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡

6. ≡ ≡ ≡ ≡ ≡ ≡ ≡**≡ ≡**≡ ≡ ≡



      ### Note:



      ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡

7. ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡


5. After a temporary password is established, the user logs into the AUR System. An error message displays stating the password has expired. The user enters a new password.

6. The system requires a password change at least every 90 days. Shortly before this time expires the user is prompted to choose a new password.



### Caution:



This message should not be ignored.

7. The user is allowed to change their password once in any 24-hour period time by selecting the Change Password option on the Security menu.


**1.4.19.12.3** **(06-01-2006)**

#### Unauthorized SSN Access

1. **SSN access restriction:** The user is prevented from accessing any SSN which is not assigned to the user. This restriction, however, does not apply to View Case options or users who have Universal Access permissions.

2. **Locked SEID**: The system locks a user’s SEID after three successive unauthorized SSN access attempts and returns the user to the Login screen. The user’s status is automatically changed to "Locked" . If the user attempts to login, the system displays an error message and logs the user off the system.


**1.4.19.12.4** **(10-26-2021)**

#### Locking/Unlocking SEIDs

1. When users are in production status, they are prevented from accessing any SSN not assigned to them (except when using Universal or View Case options). After three attempts to access a case not assigned, the system locks the user’s SEID and the user cannot proceed until their account is unlocked by a lead, manager or AUR Coordinator. The user Administration screen displays **Locked** in the Account Status field.

2. To unlock a SEID:



1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Enter the locked SEID in the SEID field.

4. Click on the ACCOUNT STATUS field. The field changes to "Open" .

5. Press **<F8>** to exit.


3. When a user needs their session restarted due to a power outage, screen freeze, ungraceful logout (for example, Task Manager), the AUR System automatically resets the session upon login.


**1.4.19.12.4.1** **(03-04-2025)**

##### AUR Inactivity Lock

1. After accessing a Tax Year and there has been no activity for that TY for 30 minutes or longer, the system places an inactivity lock on AUR. An error message displays indicating inactivity. Close the browser window and login into AUR again.


**1.4.19.12.5** **(11-21-2023)**

#### Profile Codes and Limitations

1. Profile Codes are established so managers and AUR Coordinators can provide users with the appropriate access to the segments of the system (menu options) the users need to perform their responsibilities. Listed below are the different profile codes, titles, description and limitations for each site or ORG.




| **Profile Code** | **Title** | **Description** | **Limitation** |
| :-: | :-: | :-: | :-: |
| 2100 | Tax Examiner | Allows the user the ability to screen and work responses | N/A |
| 2234 | Lead Tax Examiner | A tax examiner who can assist the manager in controlling work, perform some employee reviews, and address user profile issues | 2 Per Org |
| 2230 | Back up lead | A tax examiner who can assist the lead in controlling work and some employee reviews. | 2 Per Org |
| 5200 | Technical Manager | Manager for tax examiners and can assist with screening and response work. Has access to most reports and is able to transfer cases. Access to make profile changes/verifications. Responsible for employee reviews. | 1 Per Org |
| 5834 | Employee manager | Manager for tax examiners who work the employee cases. Have access to work both screening and responses. Has access to most report and is able to transfer cases. Access to make profile changes/verification. Responsible for employee case reviews. | 2 Per site |
| 8234 | Employee Coordinator | Allows users to access employee case files. Can build and release the case work for security reasons. Has access to reports and can transfer cases when needed. | 2 Per site |
| 9899 | Employee HQ Analyst | Allows user to access employee case files. Access to reports and can transfer cases when needed | N/A |
| 4000 | Clerk | Allows the user the ability to control the AUR inventory. | N/A |
| 4004 | Clerk lead | A clerk who can assist the manager in pulling the needed reports ensuring the AUR inventory is moved and controlled timely. | 2 Per Org |
| 5400 | Clerical Manager | Manager for clerks and can assist with the clerical work. Has access to reports needed in controlling AUR inventory and is able to transfer cases. Responsible for user profile changes/verifications. Responsible for employee reviews. | 1 Per Org |
| 7234 | Special Project Coordinator | Allows user to access reports and transfer from speciality batches | 10 Per site |
| 9000 | AUR Coordinator | Coordinator who has the ability to work all phases of AUR. Can transfer cases and review them as needed. Has access to almost all report. Set up or change profiles as needed. | 2 Per site |
| 9100 | Back up coordinator | User who can aid the AUR coordinator work all phases of AUR. Can transfer cases and review them as needed. Has access to almost all reports. Set up or change profiles as needed. | 10 Per site |
| 6000 | Satellite User | Allows user view case only access. | N/A |
| 9999 | HQ Analyst | HQ Analyst who can work all phases of AUR. Can transfer cases and review them as needed. Has access to all report. User can set up or modify profiles as needed. | N/A |


**1.4.19.12.6** **(03-04-2025)**

#### Status Codes

1. Status Codes designate the working status of a user. The manager or AUR Coordinator assigns users one of the following status codes:



   - P (Production) - able to perform all assigned work

   - F (Furloughed) - unable to access the AUR system

   - I (Inactivated) - extended detail out of AUR and unable to access the AUR system

   - D (Deleted) - no longer working in AUR


**1.4.19.12.7** **(10-26-2021)**

#### User Administration Screen Tabs

1. The AUR system stores various information that can be accessed by clicking on the appropriate tab in the User Administration screen. The following tabs are available in the User Administration screen:



   - User

   - History

   - Group

   - Audit

   - Archive

   - Unit

   - New Loc

   - Profile limits


**1.4.19.12.7.1** **(10-26-2021)**

##### User Tab

1. The User tab is used to add, delete and/or change information for a specified user.

2. Data for any user can be researched by accessing the User tab as follows:



1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Enter the SEID of the user to be researched and click the Query button.

4. Press **<F8>** to exit.


**1.4.19.12.7.1.1** **(03-04-2025)**

###### Adding/Reactivating Users

1. Users**must not be added** to the AUR system until the BEARS process has been completed. Once BEARS has been approved, Managers are responsible for adding their employees to the system. If the user’s manager is not available, another manager or the AUR Coordinator can add the user. The SSA or the AUR Coordinator adds all managers to the system.



### Note:



Once a user has been placed in "D" (deleted) status they must be added to the system as a new user.

2. The employee agrees to all AUR Security rules by electronically signing BEARS which is electronically maintained at each site.

3. To add a user, take the following actions:




| **User Administration Screen Steps** |
| :-: |
| Access the User Administration Screen by selecting **S**ecurity **S**ecurity from the AUR Year menu. |
| Select **user **A**dministration** from the drop-down menu. The User Administration window displays and is defaulted to the USER tab. |
| Enter the user's SEID in the SEID field. |
| Click in the SSN field and enter the user’s SSN.<br> <br>### Note:<br>The system checks to see if the SSN is currently being used. If the information is found, the system displays the user's information in the remaining fields. If no information is found, enter the user’s last name in the LAST NAME field. |
| Enter the user’s last name in the LAST NAME field. |
| Enter the user’s first name in the FIRST NAME field. |
| Enter the user’s middle initial in the MIDDLE INITIAL field. If no middle initial, enter **X**. |
| Enter the unit phone number in the PHONE field. |
| Enter the user's start time (TOD) in the HOURS field. |
| Enter the user's ending time (TOD) in the TO field. |
| Enter the user's IDRS number (optional) in the IDRS field.<br> <br>### Note:<br>The LOCATION is system populated with the user’s site location (for example, 19 would display for users in Brookhaven). |
| Enter the user’s assigned location number in the UNIT LOCATION field. |
| Click on the RECON field if the user needs to access recon cases. |
| Click on the UNIVERSAL WORK CASE field if the user needs access to Universal case permissions. |
| Click on the BANKRUPTCY field if the user needs access to Bankruptcy case permissions. |
| Click on the INNOCENT SPOUSE field if the user needs access to Innocent Spouse permissions |
| Click on the ID THEFT field if the user needs access to identity theft work. |
| Click on the RESTRICT CASE field if user needs access to Restricted Cases. |
| Click on the TDC field if the user needs to access TDC cases. |
| Enter the appropriate profile name in the PROFILE NAME field. |
| Enter the assigned organization code in the ORG number field. |

4. The system allows only one manager per unit. If there is a manager currently in a unit and the AUR Coordinator is adding a new user to the unit with a manager profile code, or updating an existing user, the Change Unit Reference screen appears, displaying the current manager.



1. Enter the updated information in the NEW ENTRY FOR UNIT REFERENCE.

2. After clicking in the YES block of the UPDATE INFORMATION field, the Unit Reference Table updates to change the manager of record to the new manager.


### Note:

The profile code of the current manager automatically changes to 3238.

**1.4.19.12.7.1.2** **(10-26-2021)**

###### Updating and Deleting Users

1. Individual user data can be updated by accessing the User Administration screen. When this window is accessed, all existing data for a user displays. All fields can be changed by the AUR Coordinator or manager. Any field not changed remains as it appears on the screen.



### Exception:



The SSN can only be changed by the AUR Coordinator, see (2) below.

2. To update the SSN click on the Update SSN (radio button), a small window pops up with the displayed user’s SSN. To change the SSN, type in the new SSN and press ENTER.

3. To update the AUR status field of individual or multiple users in the same unit, the Update Group Status window can also be used.



### Note:



The status code and for multiple users can be done by using the Group Status Update, see _IRM 1.4.19.12.7.3_ IRM 1.4.19.12.8.3, Group Tab.





1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Enter the SEID.

4. Press **<Enter>**. The system populates the remaining information for the user.

5. Click on the AUR Status field.

6. Enter the new status code of the user.



      ### Note:



      Whenever a user is updated to, D, status, the system removes the user completely from system data base. The user or their manager must input a BEARS request to remove the AUR application from the individual.

7. Press **<F4>** to commit.

8. Press **<F8>** to exit.


4. When making multiple changes to a manager’s AUR account, changes must be made in the following sequence to ensure the system properly updates the related tables:



   - Organization Code

   - Profile Code

   - Location Code


**1.4.19.12.7.1.3** **(03-04-2025)**

###### Changing a User’s Unit Location Number

1. A user’s UNIT LOCATION number can be changed if a user needs to work in a different location.

2. To change a user’s Unit Location number:



1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Enter either the user’s SSN or SEID. The system generates the data for remaining fields.

4. Click on the UNIT LOCATION number field. The system checks for any cases assigned to or being transferred to the user for all tax years.

5. If there are outstanding cases, the system displays the message: "THERE IS STILL WORK ASSIGNED OR OUTSTANDING TRANSFERS. LOCATION CHANGE IS NOT ALLOWED."

6. The system automatically displays the list of work assigned to the user.

7. Before the Location change can be completed, all outstanding cases must be closed or reassigned.

8. Delete the current UNIT LOCATION number and enter the new one.



      ### Note:



      Use the Change to Site drop down menu to select the site the user is being updated to.

9. Update the ORG number to match the new UNIT LOCATION number.


### Note:

Changes do not take effect until the next time the user logs on.

3. The AUR Coordinator profile allows the user to be assigned two locations, primary location and unit location. The AUR Coordinator's unit location can be temporarily changed so the Coordinator can perform managerial/clerical functions for a specific unit.



01. Select **S**ecurity from the AUR Year Menu.

02. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

03. Enter the SEID of the AUR Coordinator in the SEID field.

04. Click in the UNIT LOCATION number field. The system checks for any cases assigned to or being transferred to the user for all tax years.

05. If there are outstanding cases, the system displays the message: "THERE IS STILL WORK ASSIGNED OR OUTSTANDING TRANSFERS. LOCATION CHANGE IS NOT ALLOWED."



       ### Note:



       Although the message indicates the location change is not allowed, if the user has the Coordinator profile, the system will allow the unit location to be changed.

06. The system automatically displays the list of work assigned to the user.

07. Close the report and continue with location change.

08. Change the UNIT LOCATION number field to the specified unit.

09. Press **<F4>** to commit.

10. Press **<F8>** to exit.


### Note:

When managerial/clerical functions are finished, the UNIT LOCATION number field should be changed back to the same entry as in the PRIMARY LOCATION number field. If the location is not changed back the Coordinator is not able to accept any transferred cases.

**1.4.19.12.7.2** **(11-01-2011)**

##### History Tab – Researching User History

1. Historical security data for any user can be researched by accessing the User History window as follows:



1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Click on the HISTORY tab. A message displays stating a SEID must be entered. Acknowledge the message, the User History screen displays with the cursor in the SEID field.

4. Enter the SEID of the user to be researched and click the Query button. All historical security data for the user displays.

5. Press **<F8>** to exit.


2. This screen is for information only, since no fields can be updated or changed.



1. All current data for the user appears at the top half of the screen, including the date and time of the most recent change, and the SEID of the manager who made the change to the user’s security information. The LCT field indicates the campus number.

2. The data under the heading HISTORICAL USER INFORMATION, is the prior security changes and are shown starting with the most current change, in reverse date order, and SEID of the manager who made the change. Scroll down for additional data.


3. To query data for another user, click the CLEAR PAGE button and follow the steps in (1) above.


**1.4.19.12.7.3** **(10-26-2021)**

##### Group Tab

1. User data for multiple users can be updated by accessing the Group Tab in the User Administration screen.

2. To update the status code of multiple users in the same unit, the Update Group Status window can be used.



1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Click on the GROUP tab in User Administration. The Group Status window displays with the cursor in the REVIEW/UPDATE STATUS field.



      ### Note:



      The system generates the unit number of the manager taking the action in the UNIT field. If another unit number is required, click in the UNIT field and enter the unit number.

4. Enter the status code of the user(s) whose status code is to be changed. If no status code is entered, information for every user in the unit displays.

5. To update every user on the screen to the same status code, enter the new status code in the CHANGE STATUS TO field.

6. To update the status code for only some of the users, enter the new status code for each user in the corresponding STATUS CODE field(s).



      ### Note:



      Whenever users are updated to, D status, the system removes the user completely from system data base. The user or their manager must input a BEARS request to remove the AUR application from the individual.


**1.4.19.12.7.4** **(03-04-2025)**

##### Audit Tab - Displaying Audit Trail Information

1. The Audit tab displays actions taken by the user to change taxpayer data and is recorded in an Audit Trail table. The table displays the following columns:




| **Field** | **Description** |
| :-: | :-: |
| TASK | All task codes used while working a case |
| MEANING | A description of the task code |
| TASK DATE | Date and time of access |
| ACCESS IND | The Access indicator field displays a code indicating the request for an SSN was successfully completed. |
| YEAR | Applicable AUR tax year |
| LOC, SEID | User’s SEID, and location of access |
| ORG number | User’s organization of access (can be a different location) |
| SITE | A two digit number indicating the site the case was accessed from |

2. The codes display the user’s access on the AUR system. Codes and descriptions are shown below:




| Code | Description |
| --- | --- |
| A | Own SSN Access Unsuccessful |
| B | Own SSN Access Successful |
| C | Employee SSN Access Unsuccessful |
| D | Employee SSN Access Successful |
| E | Other SSN Access Unsuccessful |
| F | Other SSN Access Successful |
| G | Spouse SSN Access Unsuccessful |
| H | Spouse SSN Access Successful |

3. To access the Audit Trail data for a user:



### Note:



The screen displays all cases worked for the current and previous day.








| **Audit trail menu options** |
| :-: |
| Select **S**ecurity from the AUR Year menu. |
| Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field. |
| Click on the AUDIT tab in the User Administration screen. The Audit Trail Information screen displays with the cursor in the SEID field. |
| Enter the user’s SEID. |
| Press **<Enter>**. The cursor moves to the TY field and is defaulted to ALL. |
| Enter the appropriate tax year or leave as ALL. |
| Enter Begin Query date and End Query Date. |
| Click on the Query button to display the records. |


**1.4.19.12.7.5** **(03-12-2018)**

##### Unit Tab - Updating the Unit Information Table (AUR Coordinator Only)

1. The AUR Coordinator can add or delete units, or change certain information for existing units by accessing the UNIT tab on the User Administration screen:




| **UNIT TAB menu options** |
| :-: |
| Select **S**ecurity from the AUR Year menu. |
| Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field. |
| Click on the UNIT tab. The Update Unit Information screen displays with the cursor in the 1st box under the UNIT number field. All existing units display. |
| Click on the ADD A UNIT button. All the information for existing units is cleared and the cursor moves to the UNIT number field. |
| Click on the USER tab in the User Administration screen. Access the new manager’s account by entering the manager’s SEID.<br> <br>### Note:<br>It is important to make changes in the sequence listed in steps 8-13 below when making manager changes to a NEW unit. |
| Click on the NEW LOC tab in the User Administration screen. Type the new location number in the **Enter a new location** field and type the name of the new location in the **Enter the name of location** field. Press **<F4>** to commit. |
| Click on the UNIT LOCATION number field and change it to the new location. Press **<Enter>** to move to the ORG number field. |
| Change the organization code of the manager to reflect the new unit number. |
| Press **<Enter>** to move to the PROFILE CODE field and change the code if necessary. |
| Press **<Enter>**. The Unit Information Table is updated with the correct information for the new unit. |
| Press **<F4>** to commit. |
| Press **<F8>** to exit. |

2. To add a new unit enter the following fields if not already populated by the system:




| In field | Enter the following: |
| --- | --- |
| UNIT | new organization code |
| MGR SEID | 0000 or the SEID of the manager |
| SHIFT | "D" for Day or "S" for Swing |
| UNIT NAME | a Unit name |
| PHONE NUMBER | the manager's telephone number |





### Note:



The current location information for the SEID entered is generated into the LOC and LOCATION fields. This must be changed to the location for the new unit, along with other changes, as explained below.

3. To delete a unit:



1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Click on the UNIT tab. The Update Unit Information screen displays with the cursor in the 1st box under the UNIT number field. All existing units display.

4. Click on the Unit Name to highlight the row.

5. Click on the DELETE A UNIT button. A window displays showing the unit to be deleted.

6. Enter "Y" in the Y/N field to acknowledge the correct unit in the window and press **<Enter>**. The message "All Records have been committed to the Data Base" displays. Acknowledge the message.

7. Press **<F8>** to exit.


4. To change information in an existing unit:



1. Click on the field to be changed.



      ### Exception:



      The LOC and LOCATION fields cannot be changed in this screen, use the User tab to change these fields.

2. Make the necessary updates.

3. Press **<F4>** to commit.

4. Press **<F8>** to exit.


**1.4.19.12.7.6** **(11-01-2011)**

##### New Loc Tab (AUR Coordinator Only)

1. The AUR Coordinator can create a New Location for new employees or to re-organize existing locations.

2. To add a New Location:



1. Select **S**ecurity from the AUR Year menu.

2. Select user **A**dministration from the drop-down menu. The User Administration window displays and is defaulted to the USER tab with the cursor in the SEID field.

3. Click on the NEW LOC tab. The Create a New Location screen displays with the cursor in the Enter a new location field.

4. Enter the new location in the ENTER A NEW LOCATION field.

5. Enter the name of the location in the ENTER THE NAME OF THE LOCATION field.



      ### Note:



      The new location is created for all AUR tax years and the corresponding suspense batches.

6. Press **<F4>** to commit.

7. Press **<F8>** to exit.


**1.4.19.12.7.7** **(10-26-2021)**

##### Profile Limits Tab

1. The Profile Limits tab displays a list of Profile Codes, User Limit and User Limit Scope.

2. Profile Codes 9000 and 9999 are able to view the information. However, only 9999 can edit information in the User Limit Field _IRM 1.4.19.12.5_, Profile Codes and Limitations.


**1.4.19.12.8** **(11-01-2014)**

#### Security Reports

1. The AUR system generates several reports designed to help managers monitor system security issues. These reports are found under the Security menu option on the AUR main menu.

2. There are two drop-down menu options found under the Security menu:



   - **current access**

   - **R**eports


**1.4.19.12.8.1** **(11-01-2011)**

##### Current Access

1. When the **current access** option is selected a message displays in the Hint Text to let the user know what tax year they are accessing and whether they are in the production or training database.


**1.4.19.12.8.2** **(10-28-2019)**

##### Reports

1. When the Reports option is selected from the Security menu (AUR main menu), a pull right menu displays with the following options:



1. **P**rofile code

2. **A**UR user list


**1.4.19.12.8.2.1** **(10-10-2018)**

###### Profile Code Reports

1. The **Profile Code** Report provides information regarding employee profile codes. There are three types of profile code reports. These reports are available to the AUR Coordinator and managers.



1. The **Unit** report lists each employee in a unit by last name, first name, SSN, status, profile code, and profile date.

2. The **Section** report lists, by profile code, the number of users in work and non-work status for a specific section.

3. The **Branch** report lists, by profile code, the number of users in work and non-work status for the entire branch.


2. To access the Profile Codes, report take the following actions:



1. Select the tax year from the AUR Year menu.

2. Select **S**ecurity from the AUR main menu.

3. Select **R**eports from the drop-down menu.

4. Select **P**rofile Code from the pull right menu.

5. Select one of the menu options listed in (1) above. The selected Profile Code Report opens in a BOE window.

6. Select File from the menu.

7. Select Print from the drop-down menu.

8. To exit the report, select **F**ile then **C**lose from the menu options at the top of the report or use the "X" in the top right-hand corner of the report.

9. Press **<F8>** to exit.


**1.4.19.12.8.2.2** **(10-28-2019)**

###### AUR User List

1. The AUR User List is a listing of users on the AUR system. There are five types of AUR User lists. The entire list can be accessed by the AUR Coordinator. Unit managers can view a list of their users.



1. The **SEID** list provides a complete list of users in numerical order.

2. The **Unit** list can be selected by either SEID (lists all the users in the unit in SEID order) or by Name (lists all the users in the unit in alphabetical order).

3. The **Name** list provides a complete list of users in alphabetical order.

4. The **By Profile Code** list user by their AUR Profile Code.

5. The **By Org Code** list provides a complete list of AUR users by their AUR Organization Code.


### Note:

The AUR User List generates in a BOE report, tabs at the bottom of the page allow the Coordinator/ Manager to view all five lists. This list can also be exported from BOE into PDF, Excel, CSV Archive and Text.

2. To access the AUR User list take the following actions:



01. Select the current tax year from the AUR Year menu.

02. Select **S**ecurity from the AUR main menu.

03. Select **R**eports from the drop-down menu.

04. Select **A**UR user list from the pull right menu. The AUR user list window displays.

05. Click in one of the report types (listed in (1) above).

06. Click on Print. The selected AUR User List opens in a BOE window.

07. Select File from the menu.

08. Select Print from the drop-down menu.

09. To exit the report use the "X" in the top right-hand corner of the report.

10. Press **<F8>** to exit.


**1.4.19.13** **(10-26-2021)**

### AUR Coordinator

1. The success of the AUR program in each center depends upon thorough coordination of all the affected functions, including Underreporter, Receipt and Control, Returns Files, Information Technology (IT), CPS, Machine Services, Planning and Analysis, and Compliance activities. Much of this is the responsibility of the AUR Coordinator. Since this program requires constant, careful monitoring, each AUR site ensures all responsible functions are aware of the processing activities and timeframes of the other affected functions. A designated individual monitors the processing to ensure it is progressing per the schedule reflected on the program planning documents. Any subsequent revisions to the schedule must be sent to the appropriate AUR Headquarters office.

2. In addition, the AUR Coordinator is responsible for:



   - Setting Notice Letter Mailout dates and volumes

   - Letter paragraphs

   - Setting Batch and Control Parameters

   - AUR Balancing and Control

   - Setting Extract Reorder Dates

   - Monitoring the runs to ensure extract accuracy


**1.4.19.13.1** **(10-10-2018)**

#### Coordinator Actions Needed For Tax Year Startup

1. At the beginning of each tax year there are certain actions the AUR Coordinator must do to ensure a smooth startup. Prior to the startup of a new tax year, AUR HQ Analyst provides an email to the Coordinators outlining specific actions the Coordinator needs to take such as:



   - CP 2000 auto assess end date.

   - Stat auto assess end date.

   - Last day to Input CP 2501.

   - Last day to Input CP 2000.

   - Initial starts.



     ### Note:



     If the volume of initial starts is not known at the time the startup information is sent, enter the volume from the previous year.


2. In addition to the above actions, additional information/reminders are provided such as:



   - Verify service center information is correct, including the address.



     ### Note:



     If your site's payments go to a different service center, include the mailing address of that service center.

   - Verify P-21-3 fields are set, per IRM 1.4.19 and local preference in both the assigned unit and batch finished fields.


**1.4.19.13.2** **(10-20-2017)**

#### Coordinator Actions Needed For Tax Year Closeout/Shutdown

1. At the end of each tax year there are certain actions the AUR Coordinator must do to ensure a clean closeout of the tax year. Prior to the closeout of a tax year, AUR HQ Analyst provides an email providing information the Coordinator need to consider.

2. The closeout email provides the target date for shutdown and reminds the AUR Coordinator, cases in special programs (bankruptcy and ID theft), will need to be closed off the AUR system and worked manually.

3. The Coordinator is responsible for reviewing the following reports/listings to identify inventory requiring attention:



   - Inventory Report, see _IRM 1.4.19.9.5.11.2_

   - RLS Batch Status Report, see _IRM 1.4.19.9.4.22_

   - Open Case Listing, see _IRM 1.4.19.9.5.7_

   - Disassembled/Age Batch Report, see _IRM 1.4.19.9.4.3_

   - Notice/Letter Suspense Listing, see _IRM 1.4.19.9.5.11.7_

   - Bankruptcy Status, see _IRM 1.4.19.9.6.4_

   - Statute Listing, see _IRM 1.4.19.9.5.11.9_

   - Open Transfer Listing, see _IRM 1.4.19.9.5.11.5_


### Note:

The above listed reports should be reviewed in accordance to the specific IRM instructions for each report.

4. In addition to the above reports the Coordinator should



   - Look at Batch history for each Extract to identify if any volume remains



     ### Note:



     If volume remains, pull a Seq-num-ssn listing to identify the specific cases remaining in the extract.

   - Check reorder dates to ensure all cases were reordered


**1.4.19.13.3** **(11-21-2023)**

#### AUR Coordinator Screens

1. Several parameters must be input by the AUR Coordinator (or rolled-over) prior to beginning each tax year. These parameters dictate several actions that take place in the system.

2. To access the AUR Coordinator window, select A**U**R Coord from the AUR main menu. A drop-down menu displays the following:



   - **N**otice dates

   - **B**atch parameter

   - **C**trl parameter

   - **L**tr parameter

   - loc le**T**ter

   - **R**eorder dates

   - **D**isaster zip cd

   - r**U**n Controls


3. The descriptions of the individual menu options in the following subsections provide more specific information.


**1.4.19.13.3.1** **(01-17-2023)**

##### Notice Mailout Dates

01. The Notice Mailout Date window is used to set volumes for mailout of AUR notices. It is the responsibility of the AUR Coordinator to ensure the correct volumes are input in the notice mailout window. It may be necessary to update or change the volumes throughout the year.

02. The AUR system assigns a mailout date to each case with a notice PC when the batch is updated to "RB" status.

03. Notice dates and Notice Upload dates are systemically assigned and cannot be changed. The mailout volume is input by the AUR Coordinator and must be maintained.

04. The windows contain the following fields for CP 2501, CP 2000, Recomputed, Stat and TDC:



    01. Notice Upload Date

    02. CP 2501 - Notice Date

    03. CP 2501 - Weekly Volume

    04. CP 2501 - Release Volume

    05. CP 2000 - Notice Date

    06. CP 2000 - Weekly Volume

    07. CP 2000 - Release Volume

    08. CP 2000 Auto Notice - Notice Date

    09. CP 2000 Auto Notice - Weekly Volume

    10. CP 2000 Auto Notice - Release Volume


05. Recomputed Note Date and weekly volumes:



    1. Recomp/Amended/PC57, 95 - Notice Date

    2. Recomp/Amended/PC57, 95 - Weekly Volume

    3. Recomp/Amended/PC57, 95 - Released Volume

    4. Recomp/Amended/PC57, 95 - BT 67 Volume

    5. Recomp/Amended/PC57, 95 - BT 87 Volume

    6. Recomp/Amended/PC57, 95 - MI Reserve


06. Stat Notice date and weekly volumes:



    1. Stat - Notice Date

    2. Stat - Weekly Volume

    3. Stat - Release Volume

    4. TDC Count


07. To access the Notice Mailout Dates window:



    1. Select the tax year from the AUR Year menu.

    2. Select A**U**R Coord from the AUR main menu.

    3. Select the **N**otice dates from the drop-down menu. The Notice Dates Mailout window displays with the cursor in the first box in the NOTICE UPLOAD DATE field.

    4. Use **<Enter>** or **<Tab>** to advance the cursor.

    5. Enter the correct volume in the appropriate field(s).

    6. Press **<F4>** to commit.

    7. Press **<F8>** to exit.


### Note:

All of the notice dates can be printed from the Notice Mailout Dates Listing available from the Reports menu.

08. Notice Upload dates are Saturdays and display in **MM/DD/YYYY** format. If the Notice upload dates have already passed they do not display.

09. Notice volumes for CP 2000 and Recomp/Amended notices cannot be changed if within two weeks of the Notice Upload Date, due to the time needed for the interest calculations.

10. CP 2000 notices cannot be generated during the Master File dead cycles (interest computations cannot be downloaded). However, CP 2501, CP 2000 Recomp/Amended and CP 3219A Notices can be generated during the dead cycles as no Master File interest computation is required.



    ### Note:



    Headquarters provides notice dates where the volume of notices should be set to zero (0) for dead cycles and End of Year (EOY) processing.





    ### Note:



    An original CP 2000 request posts a PC 09 to request an interest computation from Master File.

11. Once the notice volume for a specific notice date has been exceeded, any additional notice volume is assigned (rolled over) to the next available notice date.



    ### Note:



    When notices are rolled over to a future date, address updates are taken into consideration.

12. Mailout volumes include cases with notice PCs from Employee BTs 90 and 91.

13. Mailout volumes do not include cases from Partially Agreed BT 67 and 87.

14. The Released Volume column for Recomp/Amended/PC 57, 95 includes volumes from BT 67 and 87. The Batch Type 67 and 87 columns display the volume of notices when the batch is updated to "AB" (Associated Batch) Status.

15. TDC Count establishes the TDC indicator on notices to include the TDC invitation. The volume is input by the AUR Coordinator and must be maintained. Coordinators will have a one week window to input this volume (3 weeks prior to Notice Date). Coordinator can add to the count but can’t reduce it once committed.


**1.4.19.13.3.2** **(11-02-2020)**

##### Batch Parameters

1. The AUR Coordinator is required to establish the operating parameters used for batch building. The following is set by the Coordinator for each batch type:



   - Maximum batch count

   - Maximum work unit count

   - Default location


2. Batch types are divided into three different categories.



1. User Built (UB) - UB batches need to have the Maximum Batch Count, Maximum Work Unit Count, and Default location set.

2. System Suspense (SS) - SS batches can only have the default location changed.

3. Unit Suspense (US) - US batches are system defined and cannot be changed.


3. Maximum Batch Count for suspense batches is limited to 9,999 cases in a batch. The Maximum Batch Count for any other batch type is 999. The Maximum Work Unit count is limited to 99 cases.

4. The default location input must match a location number previously established by IT.

5. To access the Batch Parameter screen take the following actions:



1. Select the tax year from the AUR Year menu.

2. Select A**U**R Coord from the AUR main menu.

3. Select the **B**atch parameter from the drop-down menu. The Update Batch Parameter screen displays with the cursor in the first box in the MAXIMUM BATCH COUNT field.

4. Use **<Enter>** or **<Tab>** to advance the cursor.

5. Enter the correct volume in the appropriate field(s).

6. Press **<F4>** to commit.

7. Press **<F8>** to exit.


6. Minimum batch parameters are set by HQ Policy. Batch building will not allow the batch to be closed until the minimum amount has been met. An error message will display when the volume count hasn’t been met." ERROR: MINIMUM BATCH SIZE NOT REACHED" .


**1.4.19.13.3.3** **(11-21-2023)**

##### Control Parameters

01. The AUR Coordinator is responsible for ensuring control parameters are verified for the start-up of each new tax year and updated as appropriate. The fields and their descriptions are listed in (3) - (30) below.

02. To access the Control parameter screen take the following actions:



    1. Select the tax year from the AUR Year menu.

    2. Select A**U**R Coord from the AUR main menu.

    3. Select the **C**trl parameter from the drop-down menu. The Update Control Parameter screen displays with the cursor in the CONTROL RELEASE LOCATION field.

    4. Use **<Enter>** or **<Tab>** to advance the cursor.

    5. Make changes as needed to the appropriate field(s). See (3) - (30) below for description of each field.

    6. Press **<F4>** to commit.

    7. Press **<F8>** to exit.


03. The **CONTROL RELEASE LOCATION** is the location where batches and released unit suspense cases are assigned when the status is updated to "BF" .



    ### Note:



    This field should always be set to "RLS" .

04. The **RECEIVER EMPLOYEE NUMBER** is used for automated return requests, transcript requests. The number is broken down into three components.



    - The first two digits are the campus code

    - The second three digits are the location number

    - The last five digits identify a specific employee or generic unit number


05. The **NAME/ADDRESS/EMPLOYEE** field is used when the AUR System sends address updates to ECC-MTB and letters to Correspondex. The number is broken down into three components.



    - The first two digits are the campus code

    - The second three digits are the location number

    - The last five digits identify a specific employee or generic unit number


06. The **CP 2000 AUTO ASSESS END DATE** field indicates when AUR CP 2000 auto assessments are suspended for a given tax year. This date is set to ensure all auto assessments are processed in time to meet the statute expiration date. PC 67 and IPC RN cases must have a date no later than February 28, of the Statute year.

07. The **STAT AUTO ASSESS ENDING DATE** field indicates when AUR Stat auto assessments are suspended for a given tax year. This date is set to ensure all auto assessments are processed in time to meet the statute expiration date. PC 87, 90 or IPC SR must have a date no later than June 30, of the Statute year. An automatic assessment record is always created for cases closed with PC 91, 92, or 93.

08. **LAST DAY TO INPUT CP 2501** field indicates when CP 2501 notices should stop being generated for a given tax year. This date is set to ensure no CP 2501 notices are generated too late to complete processing the tax year before the statute expires.

09. **LAST DAY TO INPUT CP 2000** field indicates when CP 2000 notices should stop being generated for a given tax year. The date is set to ensure no CP 2000 notices are generated too late to complete processing before the statute expires.

10. The **EMPLOYEE CASE SEID** is used when an employee case is identified during regular processing. The system displays a message to transfer the case to the Employee Case SEID. The employee must be in "P" status.

11. The **AGE NUMBER** reflects the number of days of aging for the Aged Response Batch Summary report.

12. The **ESTAB MAXIMUM REMARKS** field is used to indicate the maximum number of characters (including spaces) the user can enter in the REMARKS field on the Research screen.

13. The **MAXIMUM CHECK DATE COUNT** field limits the number of cases displayed within a particular notice date after No Response cases have been built. This prevents the system from displaying thousands of cases on a notice date that was not purged.

14. **MAXIMUM LABEL COUNT** limits the number of labels generated by one request.

15. **MAXIMUM REPORT COUNT** limits the number of SSNs that can be viewed or printed when accessing batch listings. Recommended volume of 9,999.

16. **DUT PARAGRAPH NUMBER** is a designated paragraph sent to Taxpayers on how to respond using the Document Upload Tool (DUT).

17. **DUT START DATE**is the date the paragraph will appear on the notice.

18. **WAIVER LOCATION NAME** is the campus name displayed in the symbols box in the upper right corner of Form 5564, Notice of Deficiency-Waiver. Up to 13 characters may be entered.

19. **WAIVER STOP CODE** is the mail stop displayed in the symbols box in the upper right corner of Form 5564. Up to 13 characters may be entered.

20. **P-21-3 AGE DAYS** is the number of days after the IRS received date a Letter 4314-C is mailed to the taxpayer. The system automatically generates and processes Letter 4314-C three to five days before the letter date. The three to five day timeframe allows for processing and printing of the letters. The system default for this field is 30.



    ### Example:



    If the number of days entered is 30, the system generates and processes the letters on the 25th - 27th day after the IRS received date.

21. **P-21-3 RESPONSE DAYS** is the number of days the taxpayer will be contacted again by IRS. The system default for this field is 30. HQ suggests setting the number of days to 60 to allow ample time to work responses.

22. **P-21-3 ASSIGNED UNIT** is used to automatically generate Letter 4314-C on cases meeting ACTION 61 AGED DAYS criteria for BTs 41, 44, 52, 53, 58, 72, 74, and 99 in "AU" status.



    ### Caution:



    If this field is blank, a Letter 4314-C does NOT automatically generate.

23. **P-21-3 BATCH FINISHED** is used to automatically generate Letter 4314-C on cases meeting ACTION 61 AGED DAYS criteria for BT 41, 44, 52, 53, 58, 72, 74, 81 and 98 in "BF" status.



    ### Caution:



    If this field is blank, Letter 4314-C does NOT automatically generate.





    ### Note:



    Letter 4314-C generates with paragraphs "A" and "S"



     .



24. **CP 2005/CP 2006 ADD DAYS** is the number of days after batch disassembly date, the automated acknowledgement and/or no change letters are generated. This should be set to 7 days.

25. **PLANNED INVENTORY** is the total number of cases your campus is working for the tax year. This information is necessary for the MISTLE report to calculate correctly.



    ### Reminder:



    Changes to inventory **must** be input in order for the Mistle to reflect accurate information.

26. The following fields relate to the individual campus(es). Enter the appropriate information for your campus:



    1. **SERVICE CENTER CODE** is the two-digit code for the campus.

    2. **SERVICE CENTER NAME**

    3. **ABBR SERVICE CENTER NAME**

    4. **RETURN STREET ADDRESS**

    5. **RETURN CITY**

    6. **RETURN STATE CODE** \- Select **<F6>** for a listing of valid state codes.

    7. **RETURN ZIP CODE**


27. The following fields are only used when payments must be processed at another campus due to Submission Processing ramp-down. Enter the appropriate information for your campus, otherwise leave these fields blank:



    1. **STREET ADDR-RESP WITH PAYMENT**

    2. **CITY-RESP WITH PAYMENT**

    3. **STATE CODE-RESP WITH PAYMENT** \- Select **<F6>** for a listing of valid state codes.

    4. **ZIP CODE-RESP WITH PAYMENT**


28. **SUSPENSE INDICATOR** indicates one copy of the letter is kept in a manual suspense file. Locally defined indicators A-Z or blank are used to identify suspense files. This must be coordinated locally with the Correspondex Coordinator.

29. **SUSPENSE UNIT EMPLOYEE NAME** is the name of the employee designated to receive Form 5703, IDRS Letter Enclosure, with attachments to be associated with the outgoing Correspondence. Each campus decides whether or not to designate an employee name for this field.

30. **SUSPENSE UNIT MAIL STOP NUMBER** is the mail stop number in the campus where Form 5703 with attachments is routed.

31. The **TRS90** data fields in UPDATE CONTROL PARAMETERS represent an additional security feature for ordering various tax account transcripts and DLNs on the AUR system. Logins and passwords must be requested from the ECC-MTB using BEARS. The TRS90 data must be updated for **ALL** available tax years as the program goes to the oldest running tax year to get the TRS90 user information:



    1. **TRS90 ID** is the seven-character Site-ID and Organization combination login, provided by ECC-MTB using the BEARS process. Alpha characters must be capitalized.

    2. **TRS90 ACCESS CODE** is the eight-digit password, provided by ECC-MTB using the BEARS process. A new password must be requested every 360 days.

    3. **ACCESS CODE START DATE** is the expiration date provided by ECC-MTB in MMDDYYYY format and must be updated every 360 days.


32. **MAXIMUM SCREENING BATCH COUNT** limits the number of SSNs that can be built to a batch to 999.

33. **MAXIMUM RESPONSE BATCH COUNT** limits the number of SSNs that can be built to a batch to 999.


**1.4.19.13.3.4** **(11-21-2023)**

##### Update Letter Parameters

1. Every type of notice and letter sent must contain contact information for your site. This information is entered in the Update Letter Parameters window. All entries must be carefully reviewed as this information displays on the notices and letters exactly as input.



### Note:



Notices and letters include the CP notices (CP 2501, CP 2000, CP 2005 and CP 2006), CP 3219A notices and all correspondex letters (Letter 2626-C, Letter 4314-C, etc.).

2. To access/update the Letter Parameter Screen take the following action:




| **Steps to access the Letter Parameter** |
| :-: |
| Select the tax year from the AUR Year menu. |
| Select A**U**R Coord from the AUR main menu. |
| Select **L**tr parameter from the drop-down menu. |
| Enter the type of notice or letter |
| Enter a ****Y**** in the LTR IND - for Correspondex (CRX) letters. For CP notices, leave the field blank. |
| Enter a two-character alpha code from IDRS Correspondex if a signature applies in the SIG CD field.<br> <br>### Note:<br>If personnel changes occur verify the signature on SERP (Correspondex Signature Codes ) under the Who/Where tab, Correspondence Signature Code or using IDRS Command Code (CC) MESSG. |
| Enter the signature name corresponding to the Laser Signature Code in the SIG. LINE 1 field.<br> <br>### Note:<br>Do not use first names on the signature line. Either use "Director/Operation Manager" or Mr., Mrs., Miss, or Ms. LAST name. |
| Enter the signature title corresponding to the Laser Signature Code in the SIG. LINE 2 field. |
| Enter additional title information for the Laser Signature Code, if applicable, in the SIG. LINE 3 field. |
| Enter the designated contact person’s name in the CONTACT NAME field, otherwise leave the field blank and the system defaults to the AUR user Information. |
| Enter the designated beginning and ending hours of telephone service, including AM and PM, in the HOURS field, otherwise leave the field blank and the system defaults to the AUR User Information.<br> <br>### Note:<br>User’s cannot override the CONTACT NAME and HOURS fields when creating letters. If the contact information needs to be changed the Paragraph must be deleted and the correct contact information included in a Special Paragraph. |
| Leave the CONTACT IND field blank for the designated CONTACT NAME from Step 9 above. Enter a **"Y"** for AUR User Information.<br> <br>### Note:<br>If you want a letter to automatically fill in with the TE's name, contact hours and phone number, you must put a "**Y**" in the "CONTACT IND" field for each letter and leave the rest of the fields (contact name, phone numbers and hours) blank. |
| Enter the appropriate contact type(s) and corresponding phone number(s) in the CONTACT TYPE 1, CONTACT TYPE 2, CONTACT TYPE 3 and PHONE field(s). |

3. To enter manual letter numbers:



1. Select the tax year from the AUR Year menu.

2. Select A**U**R Coord from the AUR main menu.

3. Select **L**tr parameter from the drop-down menu. The Letter Parameter Screen displays with the cursor in the first FORM LETTER field.

4. Click in the FORM LETTER field of the Manual Letter section.

5. Enter or edit all desired manual letter numbers. Each entry can be up to six characters in length. Press **<Enter>** after each entry.

6. When all desired manual letter numbers have been entered, press **<F4>** to commit.

7. Press**<F8>** to exit.


4. To add a new letter to the Update Letter Parameter:



1. Select the tax year from the AUR Year menu.

2. Select A**U**R Coord from the AUR main menu.

3. Select **L**tr parameter from the drop-down menu.

4. Place the cursor on the letter you want the new letter to follow.

5. Press **<F2>**. A blank new letter appears on the screen and the cursor moves to the Form Letter Field.

6. Fill in the information on the required lines per (2) above.



      ### Note:



      The LTR IND box is either blank or has a "Y" in it. Enter/verify the "Y" is in the box. The "Y" must be present in order for the AUR users to be able to select the letter and for the letter to appear in the "Update Local Letter Paras" screen. The new letter appears at the very end of the list.


**1.4.19.13.3.5** **(11-01-2011)**

##### Local Correspondex Letter Paragraphs

1. The AUR Coordinator has the ability to input up to 20 local paragraphs for each Correspondex letter on the AUR system. These paragraphs are numbered 75 through 94. TEs can select paragraphs as either an "OPEN Paragraph" or a "Floating Paragraph" .

2. To create a new paragraph:



01. Select the tax year from the AUR Year menu.

02. Select A**U**R Coord from the AUR main menu.

03. Select loc le**T**ter from the drop-down menu. The Update Local Letter Paras window displays with the cursor in the NUM field.

04. Place the cursor in the LETTER field and then use the arrow keys to find the specific letter.

05. Click on the blank NUM field and press **<F2>** to access the Create/Edit Local Letter Paragraph window.

06. Type in the paragraph text.

07. Click the **Spellcheck** button and make corrections as needed.

08. Click on the OK button.

09. Type in the title of the paragraph.



       ### Note:



       The title of the paragraph automatically displays in all capital letters and is not included on the letter.

10. Press **<F4>** to commit.


3. To edit an existing paragraph:



1. Select the tax year from the AUR Year menu.

2. Select A**U**R Coord from the AUR main menu.

3. Select loc le**T**ter from the drop-down menu. The Update Local Letter Paras window displays with the cursor in the first box of the NUM field.

4. Place your cursor in the NUM field of the paragraph to be edited.

5. Press **<CTRL E>** to display the Create/ Edit Local Letter Paragraph window. The cursor appears at the beginning of the existing text.

6. Make the changes and then click the **Spellcheck** button and make corrections as needed.

7. Click on the **OK** button.

8. Press **<F4>** to commit the changes.

9. Press **<CTRL E>** again to ensure the paragraph is correctly formatted.


### Note:

Once a paragraph is created it cannot be deleted. If the paragraph is no longer needed, type "RESERVED" in the paragraph body and title.

4. Sometimes a "gap" appears in the paragraph text, after it has been committed. This "gap" is the result of the way the window reads a cut-off point on the line. To correct this, take the following steps:



1. Place the cursor at the end (extreme right) of the line immediately above the line where the "gap" starts.

2. Press **<Enter>** to create a "hard break" .

3. When the cursor goes to the next line it should have moved the first word over one space.

4. Use **<Delete>** to remove the space at the beginning of the "gap" line. Move the cursor to the end of the line and use **<Delete>** to remove the "gap" spaces.

5. Click on the **Spellcheck** button.

6. Click on the **OK** button.

7. Press **<F4>** to commit.

8. Press **<CTRL E>** again to ensure the paragraph is correctly formatted.

9. Repeat the above steps until all the "gaps" are removed.


**1.4.19.13.3.6** **(11-02-2020)**

##### Update Reorder Date

1. The Update Reorder Dates window is used to maintain the reorder dates and triggers the system to reorder returns in the extract batches and -L Freeze cases. Ensure the original reorder date allows sufficient time for the returns to be received from the Federal Records Centers.

2. AUR Coordinators should monitor the volume of cases in each extract not built to a screening batch and adjust the reorder date accordingly. When the Batch History table shows a downloaded extract of less than 10 percent in "RT" status the reorder date should be set or made earlier to allow the Charge-Outs to be reordered.



### Note:



The AUR Coordinator should ensure all Charge-Out documents received from the FRC’s are built by the clerical staff before changing the reorder date.

3. To enter/update the reorder dates:



1. Select the tax year from the AUR Year menu.

2. Select A**U**R Coord from the AUR main menu.

3. Select **R**eorder dates from the drop-down menu. The Update Reorder Dates window displays with the cursor in the first position of the REORDER DATE field.

4. Enter the applicable reorder date.

5. Press **<Enter>**. The cursor moves to the next position in the REORDER DATE field.



      ### Note:



      The reorder date for the first extract must be at least 30 days beyond the date the extract was downloaded. Each subsequent extract must have a reorder date"**greater than or equal to**" the previous extract. If an extract has been downloaded, the reorder date must be entered. The Extract 90 reorder date must be changed each time a new reorder date is input, unless the Extract 90 reorder date is **already** greater than or equal to the latest reorder date for Extracts 01-27.

6. When all reorder dates have been entered, press **<F4>** to commit, the cursor moves to the -L FREEZE DATE field.



      ### Note:



      The reorder date for -L Freeze cases must be changed each time a new reorder date is input, unless the -L Freeze reorder date is **already** greater than or equal to the latest reorder date for Extracts 01-27 or BT 90.

7. Enter or verify the reorder date for -L Freeze cases. Press **<F4>** to commit.



      ### Note:



      The charge-outs for reordered returns are generated at the campus where the original return was filed.

8. Press **<F8>** to exit.


**1.4.19.13.3.7** **(10-26-2021)**

##### Disaster Case Processing

1. The AUR system has the ability to identify cases by Disaster zip code.

2. BT 93 is designated for disaster case processing and actions.

3. The IRS may grant disaster relief based on FEMA declarations of disaster/emergency areas. IRS Disaster Relief memos are available on Servicewide Electronic Research Portal (SERP), Disaster Declarations/FEMA, and are accessed under the Who/Where option.

4. AUR HQ Policy is informed by the Disaster Assistance Emergency Relief Program of the disaster. HQ enters the FEMA number, type of disaster and zip codes into the AUR system and notifies the sites of the disaster.


**1.4.19.13.3.8** **(03-04-2025)**

##### Run Controls

1. Additional information on Run consideration is located in the current year AUR Processing Guide. This document is available through the IT staff.

2. It is important the runs are balanced timely. Balancing of runs can detect problems which are easier to correct when identified early. Early detection and correction of problems maintains the integrity of the database. To access the AUR Run Controls take the following actions:



01. Select the tax year from the AUR Year menu.

02. Select A**U**R Coord from the AUR main menu.

03. Select r**U**n controls. The AUR Run Control screen displays.

04. Select one of the following options: Daily, Weekly, Weekend, Other or All.



       ### Note:



       "Any" option selected allows you to view the current week and history information.

05. Select the run number(s) you wish to access by clicking in the Log or History boxes or both.



       ### Note:



       You can also use the "**S**" **ELECT ALL** option if you want to view all of the runs. The CLEAR ALL button can be used to deselect all the options.





       ### Note:



       If both boxes are selected, two files will open, one for the current information and one for the history. The reports display in ascending run date order.

06. Click on the "**P**" **RINT SELECTED ITEMS** option, the file(s) you requested will open in a separate window. To print these files:

07. Select File from the menu.

08. Select Print from the drop-down menu.

09. To exit the report, select **"F" ile** then **C**lose from the menu options at the top of the report or use the "X" in the top right-hand corner of the report.



       ### Note:



       Multiple reports display on separate tabs, you may want to close each tab separately.

10. Press **<F8>** to exit.


3. The AUR Coordinator should use the following instructions **each week** to balance.




| **AUR RUN** | **DESCRIPTION** | **BALANCE and CONTROL** |
| :-: | :-: | :-: |
| **AURX001** | Download IRP - The data in this run is provided from ECC-MTB via File Transfer Protocol (FTP) on the URP45 and loads the Underreporter Transcript information to the AUR database. This is run for every extract. | 1. Match the total from file “PDIAW.IURP4528.F0XXXX.U20XXXX” to Total Records Read line E.<br>      <br>2. Match the volume of PCs 03, 03K, 06 and 06K on the PC Status Report to the total Case Majors Processed.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      If the volume on AURX001 and PCs 03, 03K, 06 and 06K do not match, contact the SA.<br>      <br>3. Match (approximate) Total Records Processed on AURX033. to the total Case Majors Processed.<br>      <br>4. Match the volume scheduled for the extract to the volume on AURX001. |
| **AURX003** | Download TIF - This run accepts file WTU1015 as input and contains the Taxpayer Information File (TIF). This run contains the TIF for each extract and weekly TIF updates. | Verify all tax years are run weekly.<br> <br>### Exception:<br>The X003 is not run during dead cycles. |
| **AURX005** | Download RTF - The data is provided from ECC-MTB via FTP on the URP65 and contains the Return Transaction File (RTF) or transcription lines from the taxpayer’s return when originally processed and subsequent actions. For every AURX001 there is a corresponding AURX005. | 1. Match the total from file “PDIAW.IURP6528.F01128.U20XXXX” to Total RTF Records Read line B.<br>      <br>2. Match the Total Case Majors Processed on AURX001 to the Total RTF Cases Inserted.<br>      <br> SSNs are displayed where Major/Minor information was not downloaded into the system.<br> <br>### Note:<br>Inventory cuts may affect volume. |
| **AURX006** | Download TRDB - This is run for every extract and loads the electronic return information to the AUR database. | Ensure the run is successful - there is no balance or control for this run.<br> <br>### Note:<br>Once the virtual batches display on the Batch Inventory Report, check to see if the TRDB information is present. If the message "NO TRDB data present" displays, contact HQ to verify the AURX006 has been run for the extract. |
| **AURX007** | Download Payer Agent - This is a weekly run, which selects records from the Payer Agent table and updates the system with the new Payer Agent information. | This is run at the Ogden site for all sites. |
| **AURX013** | Download Certified Mail Number IAP file listing of CNML (from USPS). | This is run at the Ogden site for all sites. |
| **AURX015** | Download Employee Cases - This program downloads employee SSNs and spouse SSNs to the IRS EMPLOYEE table. The data is used to update previously unidentified employee cases in AURX059. The AURX015 connects to all tax years. | This is run at the Ogden site for all sites. |
| **AURX017** | Download POA - This downloads Power of Attorney addresses into the AUR database from the 16093 run. | 1. Verify the run is completed weekly for the current tax year.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Only use the latest Tax Year X017 report to balance.<br>      <br>2. Total records inserted in AURX017 should be equal to or less than the REVIEW data, line B total POA of AURX020. Also AURX021 and AURX022 XML generation, REVIEW processing, line B POAs. |
| **AURX019** | Download Interest - This program updates the CP 2000 trans and CP 2000 history tables with interest as determined by the UR SCRS runs. | 1. Match the REVIEW processing, NOTICE LETTER MAILOUT count on AURX022 to the Total Records Processed line B.<br>      <br>2. Verify clerical has printed the Reject List.<br>      <br>3. Match the volume of rejects on the AUR Reject Listing to the Total Interest Rejects line D. |
| **AURX020** | Build CP 2501 Record - This run creates the AURX02020 for input to AURX080220. This contains the data used to create the CP 2501. This run is performed on cases with a CP 2501 PC after the system has disassembled the batch and is run weekly. | 1. Match the sum of PC 30, 30K, A0 and 3AK on the PC Status Listing to the Review Notice Mailout count.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      For TY 16 and subsequent only PC 30 and A0 will be used.<br>      <br>2. Match the Notice count received and processed on the AURX080125 to the Review Notice Mailout count.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      AURX080125 only updates if notices are being generated. |
| **AURX021** | Build Stat Records - This run creates the AURX02120 for input to AURX082125 which contains Stat Notice data on cases with Stat PC 75 after the system has disassembled the batch. | 1. Match the Notice Count received and processed on the AURX081125 to the Total Notice Count (Review processing).<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      AURX081125 only updates if notices are being generated.<br>      <br>2. Match the sum of PC 75, 75K, 7A and 7AK on the PC Status Listing to the REVIEW processing, NOTICE LETTER MAILOUT count. |
| **AURX022** | Build CP 2000 Records - This run creates file AURX02220 for input to the AURX082220. This run is performed on cases with a CP 2000 PC after the system has disassembled the batch. | Match Total Records Processed on the AURX019 to the Notice Letter Mailout count. |
| **AURX023** | Upload POA Key - This program creates a file of Power of Attorney keys from the 16093 run. These keys are used to get updated POA information from Masterfile. | 1. Verify run weekly for the most current tax year.<br>      <br>2. Match AURX017 total records in "1706511" to the total records processed. |
| **AURX024** | Build AC Record (CP 2005 closure and CP 2006 transfer) | 1. Verify run weekly.<br>      <br>2. Compare total Acknowledgement Letters (CP 2006 ) processed in AURX024 to the sum of PCs: 35, 35K, 36, 36K, 38, 38K, 62, 62K, 63, 63K, 64, 64K, 82, 82K, 83, 83K, 85 and 85K from the PC Status Report.<br>      <br>3. Compare the Total Closure Letters (CP 2005) processed in AURX024 to the sum of PCs: 39, 39K, 47, 47K, 48, 48K, 51, 51K, 69, 69K, 70, 70K, 73, 73k, 74, 74K, 89, 89K, 91, 91K, 93 and 93K from the PC Status Report.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      For TY 2016 and subsequent, Process Codes with "K" have been removed. |
| **AURX025** | Check SADA - This program creates a file of Spouses at Different Address requests. These requests are input into URX34 and used to get new information about spouses with different addresses from the NAP. | Verify run weekly. |
| **AURX026** | Upload Correspondex - This program identifies new record values to request the creation of IDRS letters to be mailed. | Verify run daily.<br> This process is only run for the current tax year and merges correspondex for all tax years. |
| **AURX028** | Build Research Request - This run creates a file for input to TRS90. It contains requests for tax returns or transcripts via TE request on AUR or automatic system reorder. This run is performed daily. | Verify run daily. |
| **AURX029** | Upload Pending Interest - This is an FTP process for input into URX23. The file contains data necessary to compute CP 2000 interest. | 1. Verify run weekly.<br>      <br>2. Match Review process NOTICE LETTER MAILOUT count from the AURX022 plus total rejects from the AUR Reject Listing to the Total Records Processed.<br>      <br>3. Match the Total Records Read on the AURX019 to the Total Records Processed. |
| **AURX030** | Upload Address Change/Assessments - This daily run creates a file of assessments and address change information. It is uploaded to EOD10, which updates IDRS and Master File. | - Verify run daily.<br>     <br>   - Address changes and Assessments are uploaded on the day after batches are disassembled (for example, Monday address changes/assessments display on Tuesday’s AURX030 run. Friday's display on the following Monday or on Tuesday if Monday is a holiday).<br>     <br>   - This program is only run for the current tax year and merges address changes and assessments for all tax years.<br>     <br>### Note:<br>Assessment PCs are uploaded the previous week. |
| **AURX032** | Upload PC - This program creates a file for input to URX53. The file can contain more than one set of PC data for each SSN. The PC Status Listing and MISTLE report are created from this data. | 1. Verify run weekly for the most current tax year.<br>      <br>2. Match the Service Center Total PCs on the PC Status Listing to the Total Records Written to Output. |
| **AURX033** | Upload TRDB Request (with AURX089) ELF and MEF AURX089 currently prints charge-outs, but eventually will not. | 1. Verify run after each extract.<br>      <br>2. Verify Chargeouts were printed and sent to the FRC’s |
| **AURX034** | Upload Third-Party - The output file is transmitted to ECC-MTB via FTP. This run connects all tax years and merges all Third-Party Contacts. | This is run at the Ogden site for all sites. |
| **AURX039** | Upload State Disclosure - This run contains the state disclosure data, which is sent to the state tax agencies. The information is generated by AURX049. This upload is run monthly. At the end of each quarter, three months of data is merged before being forwarded. | Verify run monthly, normal run is the last Sunday of the month. |
| **AURX041** | Part Agreed Notices - This run provides the functions necessary to upload CP notice (IPC RN/SR) information from BT 67 and/or BT 87 in "AB" status. The notice dates are systemically uploaded to create CP notices for the Taxpayer or to only update the new CP information on the database and not generate a notice. | N/A |
| **AURX043** | Auto Notice - This run produces cases for Extracts 27 and 28. | Total Subfile J Cases Processed should approximate the sum of AGN cases. |
| **AURX044** | Auto Batching - This run batches ELF extract after AURX003 and Auto Notices after AURX043. | This program is run after every extract. |
| **AURX046** | Disassemble Batches - This run provides the functions necessary to disassemble a batch in "RB" status. Closure, Fraud, Research, Wrong Pull, Assessments, Notice/Letter cases are systemically or clerically built into a new batch, based on PC/IPC. | This program is run daily. |
| **AURX047** | Disassemble Employee Batches - This run provides the functions necessary to disassemble employee cases in BTs 91 and 92. | N/A |
| **AURX049** | Create Disclosure Trans - this process prepares disclosure data from CP 2000 notices for states with disclosure agreements. If the case state code is for a participating state and the total adjustment amount is equal to or greater than the state tolerance level, processing continues, if not, the case is bypassed. IRs from foreign income cannot be disclosed to states - these are deleted from the total adjustment amount. | N/A |
| **AURX057** | Suspense Aging - This run performs functions necessary to perform aging processing. | N/A |
| **AURX058** | Employee Suspense Aging - This run performs functions necessary to perform employee aging processing. | N/A |
| **AURX059** | Update (Employee) Case - This module checks all primary and secondary SSNs against SSNs in IRS EMPLOYEE. The data is used to update previously unidentified employee cases in AURX059. | AURX059 should be run only when AURX001 and/or AURX015 are run. |
| **AURX063** | Auto Purge - This run batches aged cases from major suspense batches. Cases not successfully aged, remain in suspense until built into the correct batch.<br> <br>### Note:<br>AURX063 is run after AURX057 is successfully run. | Batches are systemically created and systemically placed into AB status.<br> <br>   - Cases in suspense batches 40 and 47 are batched to BT49.<br>     <br>   - Cases in suspense batches 50, 55 and 60 are batched to BT59.<br>     <br>   - Cases in suspense batch 70 are batched to BT79. |
| **AURX075** | Produce Interim Response Letters - This process identifies and creates a record for cases meeting the criteria for automatic generation of a Letter 4314-C. | Verify program is run daily. |
| **AURX080120** | X-Produce CP 2501 - print - This run produces CP 2501 notices for print. | 1. Verify run weekly.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      AURX080120 only updates if notices are being generated.<br>      <br>2. Match the Number of Initial Contact Notice Majors to the prior weeks total of PCs 30, 30K, 3A, and 3AK on the PC Status Listing.<br>      <br>3. Match the volume of notices received and successfully processed to the volume of Total Notices (print section) on the AURX020. |
| **AURX081120** | X-Produce Stat - print - This run produces Stat notices for print. | 1. Verify run weekly.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      AURX081120 only updates if notices are being generated.<br>      <br>2. Match the volume of notices received and successfully processed to the volume of Total Notices (print section) on the AURX021. |
| **AURX082120** | X-Produce CP 2000 - print - This run produces CP 2000 notices for print. | 1. Verify run weekly.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      AURX082120 only updates if notices are being generated.<br>      <br>2. Match the volume of notices received and successfully processed to the volume of Total Notices (print section) on the AURX022. |
| **AURX084** | Produce Suspense Labels - This run selects SSN and label data to produce bar-coded labels/folders for association with cases.<br> <br>### Note:<br>The current AUR Tax year reflects all open tax year information. | - Provides CP 2501 Labels volume.<br>     <br>   - Provides the volume of CP 2000 Labels.<br>     <br>   - Provides the volume of Stat Labels. |
| **AURX088** | Produce Acknowledgement / Closure Letter - This run produces acknowledgement and closure letters (CP 2005 and CP 2006). | 1. Verify run weekly.<br>      <br>2. Match the volume of Notices successfully received and processed in AURX088 to AURX024 "Total" in the "Total by Recipient" section. |





### Note:



See _Exhibit 1.4.19-5_, Notice Generation Timeframe Chart, for more information on the Runs and timing for notice generation. See Exhibit 1.4.19-7Exhibit 1.4.19-7, AUR Runs, for a complete list of AUR Runs and their descriptions.


**1.4.19.13.4** **(03-04-2025)**

#### Delete Process Codes

1. Only the AUR Coordinator can delete unconfirmed PCs as appropriate. If the PC is confirmed, the system displays a **"Y"** in the CONFIRMED field and an **"N"** in the DELETE field. This indicates the PC and any preceding IPC/PC cannot be deleted.



### Exception:



A confirmed PC 34, 54, 58, 79 or 81 can be deleted.





### Caution:



Deleting process codes can interrupt the progression of the case.

2. In order for the PC to be deleted the case must be transferred to and accepted by the AUR Coordinator. To delete an IPC/PC:



1. Select the tax year from the AUR Year menu.

2. Select **C**ontrol from the AUR main menu.

3. Select **C**ase from the Control menu.

4. Select **D**elete pc from the drop-down menu. The Delete Process Code screen displays with the cursor in the SSN field.

5. Enter the SSN to display the current batch and PC information for the case. The cursor moves to the DELETE field.

6. Enter **"Y"** to delete the IPC/PC.

7. Press **<F4>** to commit.

8. Transfer the case back to the originator for continued processing.


**1.4.19.13.5** **(11-21-2023)**

#### Message of the Day

1. Any user who has the AUR Coordinator or the HQ Analyst profile codes (9000 or 9999) has the ability to create and display a Message Of The Day (MOTD) to the users of the AUR site.

2. To access MOTD screen and create an MOTD:




| **To** | **Then** |
| --- | --- |
| Create Message of the day | 1. Select **S**ecurity from the AUR Tax Year menu.<br>      <br>2. Select **C**reate msg of the day from the drop-down menu. The MOTD screen displays.<br>      <br>3. The CREATED BY field automatically populates with the creators name.<br>      <br>4. The START DATE and END DATE fields require entries. Enter a start date and an end date in **MM/DD/YYYY** format.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Messages automatically display between these dates when the user logs on.<br>      <br>5. The TITLE field requires an entry. Type in a title and press **<Enter>**. The Create/Edit Note window displays.<br>      <br>6. Type the message in the space provided, click on the Spellcheck button and make corrections as needed.<br>      <br>7. Click the Save button.<br>      <br>8. Press **<F4>** to commit.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Another MOTD may be entered by pressing **<F7>**.<br>      <br>9. To exit the MOTD screen press **<F8>**. |
| Edit a MOTD | ### Note:<br>The MOTD should only be edited by the creator. If the MOTD has expired it can’t be edited, you must create a new MOTD.<br>01. Select **S**ecurity from the AUR Tax Year menu.<br>       <br>02. Select **C**reate msg of the day from the drop-down menu. The MOTD screen displays.<br>       <br>03. Click on the History Tab.<br>       <br>04. Click on the Control Number of the message you want to edit.<br>       <br>05. Press **<CTRL E>** to display the MOTD.<br>       <br>06. Edit the message.<br>       <br>07. Click on the Spellcheck button and make corrections as needed.<br>       <br>08. Click the Save button.<br>       <br>       <br>       <br>       ### Note:<br>       <br>       <br>       <br>       The following Message is displayed: "WARNING: YOU MUST COMMIT THIS SCREEN BEFORE EXITING OR MESSAGE WILL BE LOST" . Once you acknowledge this warning the cursor returns to the History tab.<br>       <br>09. Press **<F4>** to commit.<br>       <br>10. Press **<F8>** to exit. |
| View the history of all the MOTDs input to the system | ### Note:<br>The history provides the Start date, End date, Created by, and message Title<br>1. Click on the desired MOTD title<br>      <br>2. The MOTD Message Text window displays. Press **<F8>** to exit without printing.<br>      <br>3. Click the Display/Print MOTD button to print the message text. |


**1.4.19.13.6** **(10-28-2019)**

#### Computer-Generated Interest for the CP 2000 Notice

1. AUR uploads data to request an interest computation from IDRS for all CP 2000 notices. A PC 09 posts to IDRS pending the interest computation on PC 55 only.

2. Service Center Replacement System (SCRS) downloads the interest amount or a reject code. If a valid interest amount is received by AUR, the entire CP 2000 notice information is uploaded. If a reject code is received, the case prints to the Reject Listing.


**1.4.19.13.7** **(11-01-2011)**

#### Unlocated Returns or Source Documents

1. The system automatically reorders the return or source document for all cases not built into the specified batch type for a specific extract by the date established by the AUR Coordinator. The system assigns these cases to BT 30. If the case is not built into BT 31 within 60 days, the system closes the case with PC 29.


**1.4.19.13.8** **(10-10-2018)**

#### IDRS Case Control

1. IDRS control bases are opened automatically, and initially displays as Status Code **S** when:



   - A CP 2501 PC is uploaded to IDRS.

   - A CP 2000 PC is uploaded to IDRS for an interest computation. IDRS displays a PC 09 to indicate the pending interest request prior to uploading the CP 2000 PC.


2. The IDRS control base is automatically updated each time a new notice is issued. The IDRS control number ends with:



   - 02000 for a CP 2000

   - 02501 for a CP 2501

   - 05601 for a Stat notice



     ### Note:



     The IDRS case status updates to "M" when a Stat notice is issued.

   - 00095 for a recomputed notice after a Stat notice


3. The CP 2501 IDRS control base is automatically closed when PCs 10, 15, 35-38, 44, 47, 48, and 51-53 are posted.

4. The CP 2000 and Stat Notice IDRS control base are automatically closed when PCs 10, 15, 62-74, 80, 82-94 and 96 are posted.

5. The IDRS Control base is opened and closed when a PC 20 is updated to Master File. The IDRS control number is 00020.


**1.4.19.13.9** **(10-26-2021)**

#### Charge-outs (Form 4251, Return Charge-Out)

1. Initial charge-outs (Form 4251) are produced and routed to the campus files area for paper returns and source documents.



1. If the paper return has not been retired to the FRC, the campus files area pulls the return and routes to AUR Operations.

2. If the paper return has been retired to FRC, the campus files area routes the charge-out to the appropriate FRC. The FRC pulls the return and routes to AUR Operations.


2. All ELF Returns are auto batched, charge-outs are not printed for these cases. These are referred to as Virtual Batches or Virtual cases.


**1.4.19.13.10** **(03-04-2025)**

#### Suspense Files Timeframes

1. The following timeframes are applied to the appropriate suspense file:



01. CP 2501 - ≡ ≡ ≡ ≡ ≡

02. APO/FPO/DPO or Foreign Address CP 2501 - ≡ ≡ ≡ ≡ ≡ ≡

03. CP 2501 Letters - ≡ ≡ ≡ ≡ ≡

04. CP 2000 - ≡ ≡ ≡ ≡ ≡ ≡

05. APO/FPO/DPO or Foreign Address CP 2000 - ≡ ≡ ≡ ≡ ≡

06. Recomputed or amended CP 2000 - ≡ ≡ ≡ ≡

07. CP 2000 Letters - ≡ ≡ ≡ ≡ ≡ ≡ ≡

08. APO/FPO/DPO or Foreign Address recomputed CP 2000 - ≡ ≡ ≡ ≡ ≡

09. Stat Notices (CP 3219A and Form 5564) - ≡ ≡ ≡ ≡ ≡ ≡

10. APO/FPO/DPO or Foreign Address Stat Notices (CP 3219A and Form 5564) -≡ ≡ ≡ ≡ ≡ ≡


**1.4.19.13.10.1** **(10-28-2019)**

##### CP 2501 Timeframes

1. Adhering to the following recommended timeframes ensures prompt action on all CP 2501 cases, minimizing cycle time to meet program goals.



1. Disagreed responses - work on a first in, first out basis generally within 30 calendar days of the IRS received date.

2. Agreed responses - download the PC (update batch to "RB" status) within 30 calendar days of the IRS received date.

3. Interim Letter 4314-C - when a quality response cannot be issued timely, an interim response must be issued within 30 calendar days of IRS received date. This applies to all cases where the closing action was not initiated within the 30-day timeframe established by Policy Statement P-21-3. The interim letter should include the name and phone number of a person to contact and an approximate date when the next or final letter will be issued.

4. All subsequent taxpayer correspondence not previously addressed must be issued within 30 calendar days of receipt in the campus.

5. No response - download the CP 2000 notice PC (update batch to "RB" status) within 5 calendar days of system aging.

6. Undeliverables with no better address - download the CP 2000 notice PC (update batch to "RB" status) within 30 calendar days of receipt in AUR.



      ### Note:



      Whenever the inventory (age) permits special attention should be given to CP 2501s and CP 3219A to minimize cycle time.


**1.4.19.13.10.2** **(10-28-2019)**

##### CP 2000 Timeframes

1. Adhering to the following recommended timeframes ensures prompt action on all CP 2000 cases, minimizing cycle time to meet program goals.



1. Disagreed responses - work on a first in, first out basis generally within 30 calendar days of the IRS received date

2. Agreed responses - download the PC (update batch to "RB" status) within 30 calendar days of the IRS received date.

3. Interim Letter 4314-C - when a quality response cannot be issued timely, an interim response must be issued within 30 calendar days of IRS received date. This applies to all cases where the closing action was not initiated within the 30-day timeframe established by Action 61/Policy Statement P-21-3.



      ### Note:



      The interim letter should include the name and phone number of a person to contact and an approximate date when the next or final letter will be issued.

4. All subsequent taxpayer correspondence not previously addressed must be issued within 30 calendar days of receipt in the campus.

5. No response - download the Stat notice PC (update batch to "RB" status) within 5 calendar days of system aging.

6. Undeliverables with no better address - download the Stat notice PC (update batch to "RB" status) within 30 calendar days of receipt in AUR.


**1.4.19.13.10.3** **(10-28-2019)**

##### Statutory Notice Timeframes

1. Adhering to the following recommended timeframes ensures prompt action on Stat notice cases:



1. Docketed cases - send to Appeals by the **ADMIN FILE DUE TO APPEALS** date shown on the docket list for the case.

2. Disagreed responses - work on a first in, first out basis generally within 30 calendar days of the IRS received date.

3. Agreed responses - download the PC (update batch to "RB" status) within 30 calendar days of the IRS received date.

4. Interim Letter 4314-C - when a quality response cannot be issued timely, an interim response must be issued within 30 calendar days of the IRS received date. This applies to all cases where the closing action was not initiated within the 30 - day timeframe established by Policy Statement P-21-3.



      ### Note:



      The interim letter should include a name and phone number of a person to contact and an approximate date when the next or final letter will be issued.

5. No response - download the default PC (update batch to "RB" status) within 5 calendar days of system aging.

6. Undeliverables - build to BT 85, Remail Stat Notice, within 30 calendar days of receiving the undelivered notice.



      ### Note:



      Whenever the inventory (age) permits special attention should be given to CP2501s and CP 3219As to minimize cycle time.


**1.4.19.13.11** **(11-01-2014)**

#### Manual Statutory Notices

1. Manual Stats must be created when PC 77 is used. When creating a manual Stat use the same notice date(s) as your regular Stat notices.

2. As with other CP notices and letters, the following information must be kept current for Manual Stat Notices:



   - Commissioner’s name

   - Director’s name

   - Contact time

   - Stat Notice date

   - Person to contact

   - Stop number

   - IRS telephone number


**1.4.19.13.12** **(11-01-2011)**

#### Disclosure to State Tax Agencies

1. Various states have entered into Federal/State Exchange Programs with the IRS. These formalized agreements provide for the exchange of underreporter tax information with specific state tax agency representatives.

2. The disclosure of information to state tax agencies is automated.



1. Each quarter, the CP 2000 file is compared to the case history file. If a PC on the case history file indicates a case has been closed with an AUR automatic assessment (PC 67, 87 or 90) disclosure data is generated. This data is merged, sorted at the Detroit Computing Center, and transmitted to the Federal/State Exchange Program participants.

2. Each state receives a separate file of their cases. Disclosure counts are sorted by state and used to produce a report for the Disclosure function.


**1.4.19.13.13** **(11-01-2012)**

#### Print Consolidation

1. AUR notices are printed at one of two Correspondence Production Services, the Detroit Computing Center (CPS East) and the Ogden IRS campus (CPS West).



   - Brookhaven, Philadelphia, Andover and Atlanta notices are printed in Detroit, CPS East.

   - Austin, Fresno and Ogden notices are printed in Ogden, CPS West.


2. The notices are printed (including Certified Mail Listings), stuffed and mailed from the CPS sites.

3. CPS sends each site the postmarked United States Postal Service Certified Mail Listing(s). See _IRM 1.4.19.2.7_, Maintaining Documents in AUR, for additional information on retaining certified listing.

4. If it is necessary to retrieve a certified listing once it has been shipped to the FRC, use Optional Form (OF) 11 to request the listing. The Form and instructions can be found at [FRC Reference Services \| National Archives](https://www.archives.gov/frc/reference-services.html) .


**Exhibit 1.4.19-1**

### Glossary and Abbreviations

The terms below are frequently used items used in the AUR program.

| Term | Definition |
| --- | --- |
| **Agreed Case** | A response from the taxpayer with signature(s) agreeing to our changes with no disputing comments, OR full payment of tax and penalties received before the issuance of a Statutory Notice of Deficiency, with no comments, OR a completed Installment Agreement with signature(s) and no comments. |
| **Assessments (TC 290/291)** | A change to the amount of tax on the taxpayer’s account; generates a bill or a refund, a new DLN, and/or releases payment and/or freeze code. |
| **AUR Received Date** | A system generated date reflecting when the IRS Received Date is input on the AUR case record. |
| **Auto-Generated Notice (AGN)** | Cases systemically screened and the CP 2000 Notice issued with no TE or clerical handling. |
| **Automated Underreporter (AUR)** | Inventory control system used in Underreporter. |
| **Bar Code** | Contains the SSN and the tax year and is used for scanning information into the control computer, using a laser gun. It is found on the lower right corner of the Form 4251 and on several pages of notices. |
| **Batch** | A collection of returns, correspondence, or cases that have been grouped together. |
| **Batch Number** | A five-digit number used to describe/define the type of batch and the sequential number of the batch or the physical location of the batch. |
| **Batch Runs** | Automatic updates to the entire AUR system, currently scheduled for weekends only. |
| **Batch Status Codes** | A two-digit alpha codes defining the status of a batch at any given time during AUR processing. |
| **Batch Type (BT)** | The first two-digits of a batch number describing the type of work within the batch. |
| **Case Analysis** | The technical review of computer identified discrepancies compared to the tax return. The Screening phase of the Underreporter Program is referred to as either Screening or Analyzation. |
| **Case Sequence Number (CSN)** | A nine-digit number which indicates the exact physical location of a case. |
| **Centralized Authorization File (CAF)** | Houses Power of Attorneys (POA) and other authorized disclosure contacts for taxpayer accounts. |
| **Correspondence Production Services (CPS)** | AUR notices are printed and mailed from one of two CPS. CPS-East is in Detroit and prints/mails for Andover, Atlanta, Brookhaven and Philadelphia. CPS-West is in Ogden and prints/mails for Austin, Fresno and Ogden. |
| **CP 2000** | A notice sent to the taxpayer proposing an adjustment to an item of income, deductions, and/or credit and includes an explanation of the adjustment and a tax computation reflecting the adjustment. If the taxpayer fails to respond or if the response is insufficient, the IRS sends a Statutory Notice of Deficiency. |
| **CP 2005** | Closing letter issued to taxpayer. |
| **CP 2006** | Acknowledgement letter. |
| **CP 2501** | An initial notice sent to the taxpayer requesting an explanation to resolve a discrepancy between items reported by the taxpayer on the tax return and the information provided by third parties regarding those items. If the taxpayer fails to respond or if the response is insufficient, the IRS sends a CP 2000 notice proposing an adjustment. |
| **Disagreed Case** | A response from the taxpayer that does not agree to our proposed changes OR has disputing comments attached. (Full payment received after issuance of the Stat Notice of Deficiency must be considered disagreed until signature(s) are obtained.) |
| **Document Locator Number (DLN)** | The number assigned to all returns and documents input to the IRS computer system. |
| **Employer Identification Number (EIN)** | Nine-digit number formatted XX-XXXXXXX used to identify businesses/payers. |
| **Extract** | A group of SSNs selected from the inventory of cases identified with possible discrepancies. |
| **Federal Record Center (FRC)** | A place where tax returns are stored outside the campuses. |
| **File Transfer Protocol (FTP)** | The method used to move information from AUR to Master file. |
| **Form 4251 - Return Charge-Out** | The form generated from IDRS tape, used by Files/FRC to pull the requested returns. |
| **Integrated Submission and Remittance Processing** | Automated system that converts all paper documents to electronic form, including payments. |
| **Internal Process Code (IPC)** | A two-digit numeric/alpha code used for tracking cases on the AUR system (does not upload to IDRS). |
| **IRS Received Date** | Date the IRS received the taxpayer correspondence or notice in the campus. It can usually be found on the first page of the receipt and is a stamp (round or square) containing the campus name and date the IRS received the correspondence in the campus. |
| **Location Code** | A three-digit code that can be alpha or numeric. It identifies the place, generally a unit, where batches and/or cases can be found. |
| **Lost Case (LC)** | A case that cannot be located where the system indicates it should be. |
| **Priority Responses** | Responses aged beyond recommended timeframes, also referred to as Expedites or Early Received Date Responses. |
| **Process Codes (PC)** | Two-digit numbers used to identify the action taken on a case. PCs reside in AUR and are uploaded to IDRS. When posted to IDRS, they update the TC 922 date. |
| **Recomputed Notice** | A notice in which the original CP 2000 figures were changed due to a taxpayer response. |
| **Reconsideration Cases** | Responses received after the case has been closed (assessment or no change) on the AUR system, also referred to as first read, late response or audit reconsideration cases. |
| **Referral** | Case sent to another area for technical determination (for example: Examination, Criminal Investigation). |
| **Refile Case (RF)** | Return a case to a suspense batch before further assignment. |
| **Research** | Request for additional information (returns, IDRS research, information return files) needed to continue case processing. |
| **Response** | Correspondence received from or on behalf of the taxpayer. |
| **Restricted Cases** | Cases identified with restricted cases indicators in the AUR system. A restricted indicator is used to identify cases for special monitoring. |
| **Review Sampling** | Cases to be reviewed by Management or quality reviewers. |
| **Screening** | Technical review of computer identified discrepancies compared against the tax return. The Screening phase of the Underreporter Program is also referred to as Case Analysis and Analyzation. |
| **Sequence Order** | Order in which cases are key entered or scanned into AUR. |
| **Social Security Number (SSN)** | Nine-digit number formatted XXX-XX-XXXX used to identify individual taxpayers. |
| **Statutory Notice** | Legal notification sent to taxpayers by Certified mail, which explains the taxpayers right to file a petition with Tax Court and the IRS right to change tax without taxpayer consent, if no timely petition is filed. An Underreporter Stat Notice consists of a Banner Page (if system generated), the Statutory Notice of Deficiency includes a CP 3219A, Waiver Form 5564 and reprint of the CP 2000 notice. |
| **Taxpayer Information File (TIF)** | Individual Master File data from ECC-MTB (Martinsburg Computing Center) containing tax account and tax transaction information. |
| **Taxpayer Identification Number (TIN)** | Used to identify taxpayer accounts |
| _Taxpayer Digital Communication (TDC)_ | Communication via secure messaging |
| **Undeliverable** | Correspondence returned from the Post Office that the taxpayer did not receive. |
| **Universal View Case (UVC)** | The capability to view all case data by all AUR sites (and some non-AUR functions) regardless of where the case was initiated. |
| **Universal Work Case (UWC)** | The capability to work (take all actions and assign PCs) by all AUR sites (and some non-AUR functions) regardless of where the case was initiated. |
| **Virtual Batch** | All electronically filed returns (ELF) cases are auto batched into Screening BT 01-19 and are identified as a "Virtual batch" (no physical case). A "V" displays on the Batch Inventory Report next to the appropriate batch(s). |
| **Virtual Case** | All electronically filed returns (ELF) cases are identified as a "Virtual Case" (no physical case). On system listings a "V" displays next to SSN to identify this type of case. |
| **Virtual Indicator** | A **“****V****”**displays on Case History, Listing and Reports to identify there is no physical case available. |

The abbreviations (acronym) below is a list of shortened forms of common terms used in the AUR program and their meaning.

| Acronym | Meaning |
| --- | --- |
| **AGN** | Auto-Generated Notice |
| **AIMS** | Audit Information Management System - Examination control system on IDRS |
| **APO/FPO/DPO** | Army and Air Force Post Office/Fleet Post Office/Diplomatic Post Office - used to address correspondence to overseas military and diplomatic personnel. |
| **AUR** | Automated Underreporter |
| **BMF** | Business Master File |
| **BOE** | Business Objects Enterprise |
| **BT** | Batch Type |
| **CAF** | Centralized Authorization File |
| **CC** | Command Code |
| **CCA** | Case Control Activity |
| **CII** | Correspondence Imaging Inventory |
| **CNGR** | Identifies a Congressional case |
| **CPS** | Correspondence Production Services |
| **CSN** | Case Sequence Number |
| **DLN** | Document Locator Number |
| **ECC-MEM** | Enterprise Computing Center at Memphis |
| **ECC- MTB** | Enterprise Computing Center at Martinsburg |
| **EIN** | Employer Identification Number |
| **ELF** | Electronically filed return |
| **EUR** | Employee Underreporter - IRS (government) employee cases in the Underreporter Program. |
| **FEMA** | Federal Emergency Management Agency |
| **FRC** | Federal Record Center |
| **FTP** | File Transfer Protocol |
| **IAT** | Integrated Automation Technologies |
| **IDRS** | Integrated Data Retrieval System |
| **IMF** | Individual Master File |
| **IND** | Indicator |
| **IPC** | Internal Process Code |
| **IRC** | Internal Revenue Code |
| **IRM** | Internal Revenue Manual |
| **IRMF** | Information Return Master File |
| **ISRP** | Integrated Submission and Remittance Processing |
| **KITA** | Killed In Terrorist Action |
| **LC** | Lost Case |
| **LCD** | Liquid Crystal Display |
| **LCT** | Location |
| **LOC** | Location |
| **MOTD** | Message of the Day |
| **O/D** | Over deducted |
| **PC** | Process Code |
| **POA** | Power of Attorney |
| **PRP** | Indicates a Taxpayer Advocate Case. |
| **RF** | IPC used to refile a case to a suspense batch before further assignment. |
| **RPS** | Remittance Processing System within ISRP |
| **SCRS** | Service Center Replacement System |
| **SEID** | Standard Employee Identifier |
| **SERP** | Servicewide Electronic Research Portal |
| **SSN** | Social Security Number |
| **SSO** | Systemic Screen-outs |
| **SST** | Social Security Tax |
| **TAS** | Taxpayer Advocate Service |
| **TC** | Transaction Code |
| **TDA** | Taxpayer Delinquent Account - a Collection status |
| **TE** | Tax Examiner |
| **TIF** | Taxpayer Information File |
| **TIN** | Taxpayer Identification Number |
| **TP** | Taxpayer |
| **TY** | Tax Year |
| **U/R** | Underreported |
| **UVC** | Universal View Case |
| **UWC** | Universal Work Case |

**Exhibit 1.4.19-2**

### AUR Internal Process Codes

**Pre-Notice**

| IPC | Definition |
| --- | --- |
| 0A | Screening Research Request for Tax Return |
| 0D | Miscellaneous Referral - Screening |
| 0E | Screening Technical/Manager Referral |
| 0F | Screening Fraud Referral |
| 0P | Screening Taxpayer Advocate-Area Office-Congressional Cases/Referrals |
| 0T | Screening Telephone |

**CP 2501**

| IPC | Definition |
| --- | --- |
| CR | Recomputation Notice after CP 2501 (Indicator 2 Only) |
| 3A | CP 2501 Research Request – Return and/or Transcript |
| 3D | CP 2501 Referral |
| 3E | CP 2501 Technical/Manager Referral |
| 3F | CP 2501 Fraud Referral |
| 3L | Reserved |
| 3P | CP 2501 Taxpayer Advocate-Area Office-Congressional Cases/Referrals |
| 3S | CP 2501 Phone Call/Manual Letter (Letter not on AUR) |
| 3T | CP 2501 Telephone (Request Case) |

**CP 2000**

| IPC | Definition |
| --- | --- |
| 6A | CP 2000 Research Request – Return and/or Transcript |
| 6D | CP 2000 Referral |
| 6E | CP 2000 Technical/Manager Referral |
| 6F | CP 2000 Fraud Referral |
| 6L | CP 2000 AUR Correspondex Letter |
| 6P | CP 2000 Taxpayer Advocate-Area Office-Congressional Cases/Referrals |
| 6S | CP 2000 Phone Call/Manual Letter (letter not on AUR) |
| 6T | CP 2000 Telephone (Request Case) |
| 6X | CP 2000 Extension Request |
| RN | Recomputation Notice Case (Indicators 7 and 8 Only) |
| S6 | CP 2000 Only one TP signature on consent (release AUR Correspondex letter and moves case to BT 89005 suspense) |

**Statutory Notice**

| IPC | Definition |
| --- | --- |
| DR | Recomputation Notice after Statutory Default date (Indicator 0 Only) |
| 8A | Statutory Research Request – Return and/or Transcript |
| 8D | Statutory Referral |
| 8E | Statutory Technical/Manager Referral |
| 8F | Statutory Fraud Referral |
| 8L | Statutory AUR Correspondex Letter – No Revision to Deficiency |
| 8M | Statutory AUR Correspondex Letter – Change to Deficiency |
| 8P | Statutory Taxpayer Advocate-Area Office-Congressional Cases/Referrals |
| 8S | Statutory Phone Call/Manual Letter (letter not on AUR) |
| 8T | Statutory Telephone (Request Case) |
| S3 | Statutory Notice - Only one TP signature on Consent (releases AUR Correspondex letter and moves case to BT 89004 suspense |
| S8 | Statutory Notice - Only one spouse files petition (moves case to BT 89006 suspense) |
| SR | Statutory Recomputation Notice (Indicators 7 and 8 Only) |

**Miscellaneous - Open Cases**

| IPC | Definition |
| --- | --- |
| LC | Lost Case |
| MC | Manual Case |
| MI | Manual Interest |
| RC | Restore Case |
| RF | Refile Case |
| SI | Stolen Identity |
| S9 | Reserved |
| WP | Wrong Pull |

**Reconsideration - Closed Cases**

| IPC | Definition |
| --- | --- |
| 9B | RECON Research Required - suspense |
| 9C | RECON Information Request/Misc (BT 88) - closure |
| 9E | RECON Research/Referral within AUR - suspense |
| 9F | RECON Full Abatement of AUR the assessment - closure |
| 9I | RECON Information Request/Misc - closure |
| 9L | RECON Payer Letter - suspense |
| 9N | RECON No change to AUR assessment - closure |
| 9P | RECON Partial Adjustment- closure |
| 9R | RECON Referral non-AUR issue - closure |

**Exhibit 1.4.19-3**

### AUR Process Codes

**U/R Case Selected**

| PC | Definition |
| --- | --- |
| **01** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **02** | Reserved |
| **03** | AUR selected case |
| **04** | Reserved |
| **06** | AUR Employee Cases |
| **08** | Reserved |
| **09** | Establish IDRS Control Base - CP 2000 Interest Pending |

**Pre-Notice Transfer/Referral/Closures**

| PC | Definition |
| --- | --- |
| **10** | DUP TIN closure |
| **11** | Field Audit |
| **12** | Office Audit |
| **13** | Campus Examination |
| **14** | ≡ ≡ ≡ ≡ |
| **15** | Military Action/Disaster Closures |
| **16** | HQ Identified Program Problem - Closure |
| **17** | IDTVA Closure |
| **18** | KITA/ HSTG/KIA Closures |

**Pre-Notice Closures**

| PC | Definition |
| --- | --- |
| **20** | Adjustment for withholding and/or excess SST/RRT discrepancies only |
| **21** | Discrepancy accounted for |
| **22** | Balance due/Refund below tolerance |
| **23** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **24** | Payer Agent |
| **25** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **26** | IDTVA Expired |
| **27** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **28** | Other Closure |
| **29** | Return cannot be secured |

**CP 2501 Notice - Transfer/Referral/Closure**

| PC | Definition |
| --- | --- |
| **30** | CP 2501 (establishes IDRS Control Base) |
| **31** | Auto Notice Screen-out (Case systemically closed through auto notice programming |
| **34** | CP 2000 not mailed after a CP 2501 (PC 57) |
| **35** | Case closed to Field Audit (Acknowledgement letter, CP 2006) |
| **36** | Case closed to Office Audit (Acknowledgement letter, CP 2006) |
| **37** | Agreed CP 2501 |
| **38** | Case Closed to Campus Exam (Acknowledgement letter, CP 2006) |
| **44** | ≡ ≡ ≡ ≡ |
| **46** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **47** | No change (closure letter CP 2005) |
| **48** | HQ Identified Program Problem (closure letter CP 2005) |
| **51** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **52** | No change (no closure letter) |
| **53** | Amended return closed case (no closure letter) |
| **54** | Notice CP 2501 not mailed |

**CP 2000 Notice - Transfer/Referral/Closure**

| PC | Definition |
| --- | --- |
| **55** | CP 2000 (establish IDRS Control Base) |
| **56** | Reserved |
| **57** | CP 2000 after CP 2501 |
| **58** | CP 2000 Notice not mailed |
| **59** | Recomputation (updates IDRS Control Base) |
| **60** | Amend/Recomp not mailed (PC 59 and amended PCs 55, 57 and 59) |
| **61** | Reserved |
| **63** | Case closed to Office Audit (Acknowledgement letter, CP 2006) |
| **64** | Case closed to Campus Exam (Acknowledgement letter, CP 2006) |
| **65** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ (no acknowledgement letter) |
| **66** | Disagreed - Appeals Request - to Independent office of Appeals (no acknowledgement letter) |
| **67** | Fully Agreed (no closure letter) |
| **68** | Adjustment to Prepayment Credits Only closures (no closure letter), Partial Adjustments |
| **69** | Taxpayers Agreed on Different Dates - Account Split |
| **70** | No change to original tax liability (closure letter, CP 2005) |
| **71** | No change to original tax liability closure (and HQ Identified Program Problem) (no closure letter) |
| **72** | ≡ ≡ ≡ |
| **73** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ (closure letter, CP 2005) |
| **74** | Other closure (closure letter, CP 2005) |

**Statutory Notice - Transfer/Referral/Closure**

| PC | Definition |
| --- | --- |
| **39** | Taxpayers Agreed on Different Dates - Account Split |
| **62** | Non-petitioning Spouse Agreed |
| **75** | Statutory Notice - Updates IDRS Control Base |
| **76** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ (no acknowledgement letter) |
| **77** | Statutory Notice - STN90 (computation change - not generated, input via IDRS CCSTN90) |
| **78** | Statutory Notice Rescinded |
| **79** | Statutory Notice not mailed |
| **80** | Transfer Docketed Cases to Appeals (no acknowledgement) |
| **81** | Recomp not mailed after Statutory Notice (PC 95) |
| **82** | Non-petitioning Spouse Default |
| **83** | Statutory case closed to Office Audit (Acknowledgement letter, CP 2006) |
| **84** | ≡ ≡ ≡ ≡ ≡ |
| **85** | Statutory case closed to Campus Exam (Acknowledgement letter, CP 2006) |
| **86** | Disagreed Statutory Case - Appeals Request |
| **87** | Fully Agreed (no closure letter) |
| **88** | Adjustment to Prepayment Credits Only closures (no closure letter) and Employee Case Partially Agreed |
| **89** | Taxpayers Agreed on Different Dates - Case Defaulted - Account Split |
| **90** | Assessed by default |
| **91** | No change to original tax liability (closure letter, CP 2005) |
| **92** | No change to original tax liability (no closure letter) |
| **93** | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **94** | Default assessments based on revision(s) to statutory Notice |
| **95** | Statutory Recomputation Notice |
| **96** | Other Closure **(closes AUR system control for manual monitoring of active Bankruptcy cases or referral of non-bankruptcy cases to another area)** |

**Miscellaneous**

| PC | Definition |
| --- | --- |
| **97** | Response received - Correspondence sent for additional information |
| **98** | Bankruptcy Suspense (also applicable for Employee cases) |
| **99** | Reserved |

**Exhibit 1.4.19-4**

### Error Condition-Cause-Corrective Action Chart

| **ERROR** | **CAUSE** | **CORRECTIVE ACTION** |
| :-: | :-: | :-: |
| OWNER SEID | TE who worked a case or work unit and has not released it. | Instruct TE to complete and release the case or work unit. |
| NO PC | A PC has not been assigned, or data changes require the PC be validated. | If the case has not been worked, the case must be worked and a PC assigned. If the case has been worked, update the PC. |
| DIG Response | Case has a new digital response that hasn’t been reviewed | Review response, work case using applicable procedures. |
| NEW TRN | A new transaction has posted to the account. | 1. Assign the case, if necessary.<br>   <br>2. Select the Tax Account screen, an \* displays in the NEW TRANS field, identifying the new transaction(s).<br>   <br>3. Place the cursor on each NEW TRANS field displaying an \* and press **<RETURN>** or **<F8>** to access the new transaction, which saves time. |
| PC NOT VER | Used by clerical function only. | Clerical verifies PC. |
| PYR AGT | A new payer agent has posted. | 1. Assign the case, if necessary.<br>   <br>2. View the new payer agent information to see how it impacts the case.<br>   <br>3. Rework the case.<br>   <br>4. Update the PC. |
| REQUEST | Used by clerical function only. | Clerical transfers case to the requestor. |
| NEW CORR | New correspondence from the taxpayer has been received. | 1. Contact clerical for the correspondence.<br>   <br>2. Associate with the case.<br>   <br>3. Assign the case to be reworked. |
| LTR PAR | Open paragraph present on a Correspondex letter. | 1. Select Re**V**iew.<br>   <br>2. Select **M**anager and Re**V**iew.<br>   <br>3. Enter the SSN.<br>   <br>4. Select the letter from the Reference tools.<br>   <br>5. Display the letter with the open paragraph indicator and review.<br>   <br>6. Use the edit function to make corrections or return the case to the TE for corrections.<br>   <br>7. Accept the changes.<br>   <br>8. Exit the window. |
| OVER $100K | Over $100,000 (ARDI) tax increase. | 1. Select Re**V**iew<br>   <br>2. Select **M**anager and Re**V**iew.<br>   <br>3. Select the Case Analysis screen.<br>   <br>4. Enter the SSN.<br>   <br>5. Review the case and return to the TE for corrections, if needed. |

**Exhibit 1.4.19-5**

### Notice Generation Timeframe Chart

| Day | Action |
| --- | --- |
| 1st Sunday | AURX032 is run to upload the PC 09, interest computation request. |
| 2nd Sunday | AURX084 is run to create the case labels. |
| 2nd Monday-Friday | Receive labeled folders. |
| 3rd Sunday | 1st pass of AURX082 creates: Sorts (AURX8242) Foreign Address Stats (AURX8245, Stat file copies (AURX8246), 1 copy of the Certified Mail Listing (AURX8247), Registered Mail List (AURX8248), CP long notices (AURX8249), and Long Stats (AURX8250). |
| 3rd Monday-Friday | Notice Review - pull and build cases to BT 95. Review the cases. Last week to use the Stop Notice function. |
| 4th Sunday | 2nd pass of the AURX082 creates only those notices to be mailed. |
| 4th Monday | Date used on all notices and notices mailed. |

**Exhibit 1.4.19-6**

### AUR Reports Matrix

Abbreviations Key for AUR

| Abbreviation | Meaning |
| --- | --- |
| AD | After each download |
| AN | As needed |
| D | Daily |
| W | Weekly |
| Q | Quarterly |
| OE | Ordering Extracts |
| C | AUR Coordinator |
| CK | Clerk |
| CM | Clerical Manager |
| L | Lead |
| M | Manager |
| PA | Payer Agent |

**Exhibit 1.4.19-7**

### AUR Runs

| **AUR Runs** | **Frequency of Report** | **Report Title and Description** |
| --- | :-: | --- |
| **AURX001** | Weekly | **Download IRP** \- The data in this run is provided from ECC-MTB via File Transfer Protocol (FTP) on the URP45 and loads the Underreporter Transcript information to the AUR database. This is run for every extract. |
| **AURX003** | Daily | **Download TIF** \- This run accepts file WTU1015 as input and contains the Taxpayer Information File (TIF). This run contains the TIF for each extract and weekly TIF updates. |
| **AURX005** | Weekly | **Download RTF** \- The data is provided from ECC-MTB via FTP on the URP65 and contains the Return Transaction File (RTF) or transcription lines from the taxpayer’s return when originally processed and subsequent actions. For every AURX001 there is a corresponding AURX005. |
| **AURX006** | Weekly | **Download TRDB** \- This is run for every extract and loads the electronic return information to the AUR database. |
| **AURX006B** | Weekly | **Download MTRDB** |
| **AURX006C** | Weekly | **Download MTRDB Binary** |
| **AURX007** | Weekending | **Download Payer Agent** \- This is a weekly run, which selects records from the Payer Agent table and updates the system with the new Payer Agent information. |
| **AURX012** | Weekending | **Document import** \- takes notice PDF documents and puts them into the database. |
| **AURX013** | Daily | **Download Certified Mail Number** \- IAP file listing of CNML (from USPS). |
| **AURX015** | Weekly | **Download Employee Cases** \- This program downloads employee SSNs and spouse SSNs to the IRS EMPLOYEE table. The data is used to update previously unidentified employee cases in AURX059. The AURX015 connects to all tax years. |
| **AURX017** | Weekending | **Download POA** \- This downloads Power of Attorney addresses into the AUR database from the 16093 run. |
| **AURX019** | Weekending | **Download Interest** \- This program updates the CP 2000 trans and CP 2000 history tables with interest as determined by the UR SCRS runs. |
| **AURX020** | Weekending | **Build CP 2501 Record** \- This run creates the AURX02020 for input to AURX080. This contains the data used to create the CP 2501. This run is performed on cases with a CP 2501 PC after the system has disassembled the batch and is run weekly. |
| **AURX021** | Weekending | **Build Stat Records** \- This run creates the AURX02120 for input to AURX082 which contains Stat Notice data on cases with Stat PC 75 after the system has disassembled the batch. |
| **AURX022** | Weekending | **Build CP 2000 Records** \- This run creates file AURX02220 for input to the AURX082. This run is performed on cases with a CP 2000 PC after the system has disassembled the batch. |
| **AURX023** | Weekending | **Upload POA Key** \- This program creates a file of Power of Attorney keys from the 16093 run. These keys are used to get updated POA information from Master file. |
| **AURX024** | Weekending | **Build AC Record** \- (CP 2005 closure, CP 2006 transfer) (queues AURX088). |
| **AURX025** | Weekly | **Check SADA** \- This program creates a file of Spouses at Different Address requests. These requests are input into URX34 and used to get new information about spouses with different addresses from the NAP. |
| **AURX026** | Daily | **Upload Correspondex** \- This program identifies new record values to request the creation of IDRS letters to be mailed. |
| **AURX027** | Weekending | **Build CP 2057 record**. |
| **AURX028** | Daily | **Upload Research Request** \- This run creates a file for input to TRS90. It contains requests for tax returns or transcripts via TE request on AUR or automatic system reorder. This run is performed daily. |
| **AURX029** | Weekending | **Upload Pending Interest** \- This is an FTP process for input into URX23. The file contains data necessary to compute CP 2000 interest. |
| **AURX030** | Daily | **Upload Address Change/Assessments** \- This daily run creates a file of assessments and address change information. It is uploaded to EOD10, which updates IDRS and Master File. |
| **AURX032** | Weekending | **Upload PC** \- This program creates a file for input to URX53. The file can contain more than one set of PC data for each SSN. The PC Status Listing and MISTLE report are created from this data. |
| **AURX033** | Weekly | **Upload TRDB Request**(with AURX089) - ELF & MEF AURX089 currently prints charge-outs, but eventually will not. |
| **AURX034** | Weekending | **Upload Third-Party** \- The output file is transmitted to ECC-MTB via FTP. This run connects all tax years and merges all Third-Party Contacts. |
| **AURX039** | Other | **Upload State Disclosure** \- This run contains the state disclosure data, which is sent to the state tax agencies. The information is generated by AURX049. This upload is run monthly. At the end of each quarter, three months of data is merged before being forwarded. |
| **AURX041** | Daily | **Part Agreed Notices** \- This run provides the functions necessary to upload CP notice (IPC RN/SR) information from BT 67 and/or BT 87 in "AB" status. The notice dates are systemically uploaded to create CP notices for the Taxpayer or to only update the new CP information on the database and not generate a notice. |
| **AURX043** | Other | **Auto Notice** \- This run produces cases for Extracts 27, 26, 25 with 28 Fallouts. |
| **AURX044** | Weekending | **Auto Batching -** This run auto batches ELF/ cases. |
| **AURX046** | Daily | **Disassemble Batches** \- This run provides the functions necessary to disassemble a batch in "RB" status. Closure, Fraud, Research, Wrong Pull, Assessments, Notice/Letter cases are systemically or clerically built into a new batch, based on PC/IPC. |
| **AURX047** | Daily | **Disassemble Employee Batches** \- This run provides the functions necessary to disassemble employee cases in BTs 91 and 92. |
| **AURX049** | Weekending | **Create Disclosure Trans** \- This process prepares disclosure data from CP 2000 notices for states with disclosure agreements. If the case state code is for a participating state and the total adjustment amount is equal to or greater than the state tolerance level, processing continues, if not, the case is bypassed. IRs from foreign income cannot be disclosed to states - these are deleted from the total adjustment amount. |
| **AURX057** | Weekending | **Suspense Aging** \- This run performs functions necessary to perform aging processing. |
| **AURX058** | Weekending | **Employee Suspense Aging** \- This run performs functions necessary to perform employee aging processing. |
| **AURX059** | Weekly | **Update (Employee) Case Access** \- This module checks all primary and secondary SSNs against SSNs in IRS EMPLOYEE. The data is used to update previously unidentified employee cases in AURX059. |
| **AURX060** | Daily | **Sequence Employee Auto Assessment** \- This daily run creates a file of assessments for employee cases. It is uploaded to EOD10, which updates IDRS and Master File. |
| **AURX061** | Daily | **Delete Sequence Suspense** \- This run deletes empty batches after 30 days to allow re use of batch numbers. |
| **AURX063** | Weekending | **Auto Purge** \- This run systemically batches aged cases in the major suspense batches. |
| **AURX067** | Other | **Build Suspense Batches** \- This is the initial run that builds suspense batches for each location. |
| **AURX071** | Weekending | **Process Security Data** \- This run creates a log file for processing and updating the AUDIT TRAIL Table. |
| **AURX075** | Daily | **Produce Interim Response Letters** \- This process identifies and creates a record for cases meeting the criteria for automatic generation of a Letter 4314-C. |
| **AURX084** | Weekending | **Produce Suspense Labels** \- This run selects SSN and label data to produce bar-coded labels/folders for association with cases.<br> <br>### Note:<br>The current AUR Tax year reflects all open tax year information. |
| **AURX087** | Weekending | **X-Produce CP 2057** |
| **AURX112** | Weekending | **Generate Weekly Reports** \- This run generates the various weekly reports. It determines if errors were encountered by counting the number of error files generated by the reports. |
| **AURX117** | Weekending | **Create Disposition Inventory Fl** \- This process produces an assessment report, which provides a total of closed cases with an assessment PC and the average yield per case by Subfile, Category and Sub-category. This report can be pulled by date. |
| **AURX118** | Daily | **Produce Employee AUTO Assessment Report** \- The run produces a listing of employee auto assessment cases and the order they must go to files. |
| **AURX119** | Other | **Produce Monthly Discrepancy Report (Pacific Consulting Group)** |
| **AURX08120** | Weekending | **X- Produce Stat - print** \- This run produces Stat notices for print. |
| **AURX08225** | Weekending | **X- Produce CP 2000 - review** \- This run produces CP 2000 notices for review. This run also provides the volume of CP 2000 for the On-line Notice Review Process. |
| **AURX080125** | Weekending | **X- Produce CP 2501 - review** \- This run produces CP 2501 notices for review. This run also provides the volume of CP 2501 for the On-line Notice Review Process. |
| **AURX080220** | Weekending | **X- Produce CP 2501 - print** \- This run produces CP 2501 notices for print. |
| **AURX080225** | Weekending | **X- Produce CP 2501 - review** \- This run produces CP 2501 notices for review which have**a sort code**. This run also provides the volume of CP 2501 for the On-line Notice Review Process. |
| **AURX081120** | Weekending | **X- Produce Stat - print** |
| **AURX081125** | Weekending | **X- Produce Stat - review** This run produces Stat notices for review. This run also provides the volume of Stat for the On-line Notice Review Process. |
| **AURX082120** | Weekending | **X- Produce CP 2000 - print** |
| **AURX082125** | Weekending | **X- Produce CP 2000 - review** |
| **AURX082220** | Weekending | **X - Produce CP 2000- print** \- This run produces CP 2000 notices for print. |
| **AURX082225** | Weekending | **X- Produce CP 2000 - review** sort codes |
| **AURX088120** | Weekending | **Produce Acknowledgement / Closure Letter** \- This run produces acknowledgement and closure letters **(CP 2005 and CP 2006)**. |
| **AURX089123** | Weekly | **Produce Return Charge-out** \- This run produces the initial Form 4251. The charge-out information is created from an FTP file (UR62) provided by ECC-MTB. The Form 4251, requests the controlling DLN from files. AUR creates an FTP file for ELF cases. |

**Exhibit 1.4.19-8**

### AUR Task Codes

| **AUR Task Code** | **Description** |
| --- | --- |
| **101** | LOGON |
| **102** | LOGOFF |
| **103** | UNSUCCESSFUL LOGON ATTEMPTS |
| **104** | INVALID LOGON STATUS |
| **105** | UNLOCK USER SEID |
| **123** | CHILD TAX CREDIT |
| **124** | FTHB CREDIT |
| **133** | ADDITIONAL CHILD TAX CREDIT |
| **203** | VIEW CASE |
| **212** | CASE HISTORY |
| **300** | ANALYSIS |
| **302** | IR NOTE |
| **303** | PAYER AGENT |
| **305** | CREATE IR |
| **306** | MODIFY IR |
| **307** | INCOME COMPARISON |
| **311** | CREATE GROUP |
| **318** | UNGROUP |
| **321** | CASE NOTE |
| **322** | NOTICE PARAGRAPH |
| **324** | TAX ACCOUNT |
| **325** | RESEARCH |
| **327** | LETTERS |
| **328** | ASSESSMENT |
| **329** | UPDATE ADDRESS |
| **331** | RETURN VALUE |
| **332** | IRA |
| **333** | WITHHOLDING |
| **334** | EXCESS SST/RRTA |
| **335** | SITR |
| **336** | SSA/RRB |
| **337** | LUMP SUM AVG |
| **338** | SEP KEOGH |
| **339** | DEPENDENT CARE |
| **340** | SCHEDULE D LOSS |
| **343** | SCHEDULE A |
| **344** | STANDARD DEDUCTION |
| **345** | NEW TAX - 8615 |
| **347** | CHILD CARE |
| **348** | SCHEDULE R ELDERLY/DISABLED CREDIT |
| **349** | OTHER CREDITS |
| **351** | SST TIPS |
| **352** | SCHEDULE SE |
| **353** | ALT MIN TAX |
| **354** | OTHER TAXES |
| **356** | EARNED INCOME CREDIT |
| **358** | EST TAX PENALTY |
| **359** | LIMITED PENALTIES |
| **360** | SUMMARY |
| **363** | SCHEDULE D/8814 TAX |
| **364** | SAVING BOND EXCLUSION |
| **365** | PROCESS CODE |
| **366** | MISC ADJUSTMENT/SCHEDULE C EXPENSES |
| **367** | EDUCATION CREDIT |
| **368** | SCHEDULE J |
| **369** | RETIREMENT SAVINGS CREDIT |
| **371** | CASE |
| **373** | ASSIGN CASE |
| **374** | RELEASE CASE |
| **376** | TRANSFER CASE |
| **377** | ACCEPT CASE |
| **380** | REQUEST CASE |
| **388** | LIMITED CREDIT |
| **389** | TUITION AND FEES |
| **393** | FICA TAX |
| **394** | STOP NOTICE |
| **395** | NEG/REASONABLE CAUSE STATUS |
| **396** | CHANGE TAXPAYER AGE |
| **397** | NET INVESTMENT INCOME TAX |
| **398** | PREMIUM TAX CREDIT |
| **399** | SHARED RESPONSIBILITY PAYMENT |
| **432** | CASESEID |
| **435** | RESTORE CASE |
| **501** | PASSWORD (USER CHANGES) |
| **502** | PROFILE REQUEST |
| **506** | TEMP PASSWORD |
| **507** | USER ACCOUNT HISTORY |
| **600** | REPORTS (AUR) |
| **706** | NOTICE/LETTER DATE |
| **708** | CONTROL PARAMETER |
| **710** | LOCAL CP 2000 PARA |
| **712** | REORDER DATES |
| **713** | UPDATE LETTER PARAMETERS |
| **733** | DISPLAY TAXPAYER INFORMATION |
| **801** | FRAUD |
| **802** | DISCLOSURE WINDOW |
| **803** | CASE NOTE ACTION REQUIRED |
| **804** | PROCESS CODE INDICATORS |

**Exhibit 1.4.19-9**

### AUR Category Code Descriptions/Chart

| AUR Category Code | Descriptions |
| --- | --- |
| **01** | 100 percent Mortgage and/or points paid |
| **02** | IRAs Over-deducted on Form 5498 |
| **04** | NEC |
| **05** | 50 percent Gross Receipts w/NEC/Fishing income/Bartering |
| **07** | Wages |
| **08** | SSB/RRB |
| **09** | 100 percent Interest or Dividends |
| **10** | Interest |
| **11** | Dividends |
| **12** | Pure Wages/Interest/Dividends/Combination |
| **13** | Pensions and Annuities (1099-R) Taxable |
| **14** | Pensions and Annuities (1099-R) Gross |
| **15** | Interest and/or Dividends AND Pension and Annuity Combination (10 and/or 11 with 13 and/or 14 combo) |
| **16** | Withholding (WH), over/underclaimed |
| **17** | Fishing Income, no MED and/or NEC |
| **19** | Rents and Royalties |
| **20** | Farm Income |
| **21** | Medical Payments, no Fishing and/or NEC |
| **22** | Income /Loss from Partnership and S Corps, Form 1065 and Form 1120-S |
| **23** | Income/Loss from Estates and Trusts, Form 1041 |
| **24** | Gambling |
| **25** | Taxable Grants |
| **27** | Other Income |
| **28** | Payments in Lieu of Dividends |
| **29** | Cancellation of Debt |
| **30** | Qualified Tuition Program Earnings |
| **31** | Securities Sales - 100 or fewer IRs, Form 1099-Bs, Sch D present |
| **32** | Early Withdrawal Penalty(EWPEN) |
| **33** | Unemployment Compensation |
| **34** | INT Combination with Interest $100 or more |
| **35** | State Income Tax Refund |
| **36** | Mortgage interest paid and/or points paid and/or Mort Ins Premium, Form 1098 present |
| **37** | SEP/SIMPLE Contribution |
| **38** | Reemployment Trade Adjustment Assistance (RTAA) payments |
| **39** | Securities Sales - more than 100 Form 1099-B, Schedule D present |
| **40** | Gross Capital Gain distributions from dividends |
| **41** | Combination |
| **42** | Early Distribution 10 percent Tax ($150 or more) |
| **43** | Bartering Income Discrepancy |
| **44** | Dependent Care Benefits(DCB) |
| **45** | IRA Overdeduction AGI dollar limitation |
| **46** | Excess FICA |
| **50** | Self-Employment (SE) Income Discrepancy |
| **51** | Taxable Pension and Annuity Distribution or Gross Pension and Annuity Distribution Discrepancy |
| **55** | Statutory Wages |
| **57** | NEC on Schedule F and/or Form 4835 |
| **59** | Medical Savings Account (MSA) Contribution |
| **61** | Securities Sales, 100 or fewer Form 1099-B, No/Blank Sch D |
| **62** | Overdeducted Student Loan Interest Deduction (SLID) greater than $600 |
| **63** | Health Saving Account (HSA) Distributions |
| **64** | Health Saving Account (HSA)Contributions |
| **65** | Real Estate Income Discrepancy |
| **66** | Taxable Pension and Early Distribution 10 percent Tax |
| **67** | Mortgage and/or points paid over-deduction - no Form 1098 |
| **68** | Over-deducted Tuition and Fees - no Form 1098-T |
| **69** | Education Credits (over claimed) - no Form 1098-T |
| **70** | SSB/RRB plus Taxable Pension discrepancy |
| **71** | Wages and/or Withholding discrepancy |
| **72** | Underreported Payment Card, greater than $100 U/R |
| **79** | Securities Sales, over 100 Form 1099-B, No/blank Sch D |
| **99** | When case cannot be assigned to Categories 01 - 05 or 7-79, contains IRA and another discrepancy |

**Subfile Key Descriptions**

| Subfile Key | Description |
| --- | --- |
| **1** | CTR Cases |
| **2** | IRS Employees |
| **6** | All Other Taxpayers (non-IRS), AGI per return is between $50,000 and $124,999 |
| **8** | Cases with a Form 1099-K income of $100 or more |
| **9** | Returns filed with ITIN |
| **B** | Credit Tax Change (W/H) |
| **C** | Stock, Bond and/or Real Estate Discrepancy (Form 1099) |
| **D** | UR Income Greater Than $10,000 |
| **E** | UR and EIC |
| **F** | Mortgage Interest Over-deduction |
| **G** | UR Income Greater than $10,000/Repeaters |
| **H** | 1040NR (International with ITIN) ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **I** | Potential Unproductive Repeaters ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **J** | Auto-Generated Notice |
| **K** | Discrepancy from associated EIN Document |
| **L** | Multi-year Repeater |
| **M** | Cases with Sch K-1 Discrepancy of $100 or more |
| **P** | Identity Theft cases with posted TC 971 w/AC 5XX |
| **S** | 1040NR (International with SSN) ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| **T** | AGI per return is less than $50,000 |
| **U** | AGI per return is $125,000 or more |

| Sub-Category Code | Potential Tax Change |
| --- | --- |
| ≡ ≡ ≡ | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| ≡ ≡ | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| ≡ ≡ ≡ | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| ≡ ≡ | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| ≡ ≡ ≡ | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| ≡ ≡ | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |
| ≡ ≡ ≡ ≡ | ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ |

**Exhibit 1.4.19-10**

### Report access for AUR Users

Listing of reports purpose and frequency for user’s,:

| REPORT Name | OPTION | RPT FREQ | USED BY | PURPOSE | BOE |
| --- | --- | --- | --- | --- | --- |
| BATCH LISTINGS | Seq-Num-SSN-PC | AN | C, CK, M | Used to monitor the work. | No |
| BATCH LISTINGS | PC-Seq-Num-SSN | AN | C, CK, M | Used to monitor the work. | No |
| BATCH LISTINGS | Seq-Num-SSN | AN | C, CK, M | Used to monitor the work. | No |
| BATCH INVENTORY | Batch Type | AN | C, M, L | Used to monitor specific batches. | No |
| BATCH INVENTORY | Association | AN | C, M, L | Used to monitor batches in "AB" status. | No |
| BATCH INVENTORY | Screening | AN | C, M, L | Used to monitor screening batches. | No |
| BATCH INVENTORY | CP 2501 | AN | C, M, L | Used to monitor CP 2501 batches. | No |
| BATCH INVENTORY | CP 2000 | AN | C, M, L | Used to monitor CP 2000 batches. | No |
| BATCH INVENTORY | Statutory | AN | C, M, L | Used to monitor Stat batches. | No |
| BATCH INVENTORY | Complete | AN | C, M, L | Used to monitor all batches. | No |
| BATCH INVENTORY | Unit Suspense | AN | C, M, L | Used to monitor Individual unit inventory. | No |
| BATCH INVENTORY | Recon | AN | C | Used to monitor Recon inventory. | No |
| WEEKLY REPORT | Inventory | W | C, M, L | Provides a breakdown of total inventory. | No |
| WEEKLY REPORT | Weekly PC/IPC | W | C, M, L | Lists all PC and IPCs with both weekly and CUM volumes. | Yes |
| WEEKLY REPORT | Aged Screening Research | W | C, M, L | Lists SSNs in research suspense for more than 30 days. | No |
| WEEKLY REPORT | Open Transfers | W | C, M, L | Lists transferred SSNs not accepted within 5 days. | Yes |
| WEEKLY REPORT | Aged Response Batch Summary | W | C, M, L | Used to monitor the age of response batches. | Yes |
| WEEKLY REPORT | Notice/Letter | W | C, M, L | Displays original and current notice volume and purge date. | Yes |
| WEEKLY REPORT | Extract Category | W | C, M, L | Identifies category types in a specific extract. | No |
| WEEKLY REPORT | Statute | W | C, CK, M, L | Lists all cases within 120 days of statute expiration. | Yes |
| WEEKLY REPORT | Reject Listing | W | C, CM, L | Used to pull cases from suspense files. | No |
| WEEKLY REPORT | PC Status | W | C, M, L | Used to monitor count of PCs. | No |
| WEEKLY REPORT | MISTLE | W | C, CM, M, L | Used by Headquarters. | No |
| WEEKLY REPORT | Bankruptcy Status | W | C, M, L | Used to identify and monitor Bankruptcy cases. | Yes |
| WEEKLY REPORT | UVC Summary | W | C, M | Used to monitor Universal View case activity across the sites. | Yes |
| REVIEW SAMPLING | Product Review Sample | AN | C, M, L | Used to identify product review of work in unit inventory. | No |
| Batch IRS Received Date | Batch IRS Received Date | AN | C, CM, M, L | Used to monitor the age of responses in a batch. | No |
| Unit Inventory | Unit Inventory | AN | C, CM, M, L | Used to monitor cases assigned to TEs by SEID or location. | No |
| Cases in Error | Cases in Error | When updating batches to "BF" or "RB" status | C, CK, CM, M, L | Used to identify cases with error conditions in a batch. | Yes |
| Statistical | Statistical | AN | C | Used to monitor assessments weekly, CUM or designated dates. | Yes |
| Employee | Open Inventory | D | EURT, EURM, C | Used to monitor Employee cases. | Yes |
| Employee | Closed Inventory | D | EURT, EURM, C | Used to monitor Employee cases. | Yes |
| Employee | Open Transfers | D | EURT, EURM, C | Used to monitor Employee cases. | Yes |
| Employee | Auto Assessments | D | EURT, EURM, C | Used to monitor Employee cases. | Yes |
| Employee | Employee Aging | W | EURT, EURM, C | Used to monitor Employee cases. | Yes |
| Recon | Open Inventory | D | C, M, L | Used to monitor Recon Inventory. | Yes |
| Recon | Closed Inventory | D | C, M, L | Used to monitor Recon Inventory. | Yes |
| Recon | Aging | D | C, M, L | Used to monitor Recon Inventory. | Yes |
| Recon | Issue | D | C, M, L | Used to monitor Recon Inventory. | Yes |
| Lost Case | Batch Assign Date | D | C, CK, CM, M, L | Used to research missing cases. | No |
| Lost Case | CSN | D | C, CK, CM, M, L | Used to research missing cases. | No |
| Lost Case | SSN | D | C, CK, CM, M, L | Used to research missing cases. | No |
| Aging | Disassemble Batch | W | CM, M, C | Used to monitor cases in suspense that have not been batched to no response batches from "DC" status. | Yes |
| Aging | Complete Case | W | CM, M, C | List of SSNs in Missing Data Suspense Batch where no data has been received and the appropriate suspense time has expired. | Yes |
| Aging | Suspense Aged Batch | W | C, CM | Indicates which suspense batches have met the appropriate suspense timeframes. | Yes |
| Aging | Part Agreed | AN | C, M | List of partially agreed cases (BT 67 and 87) in AB status more than 2 cycles. | No |
| Aging | Stat Not Generated | W | C, CM | Provides a list of cases from the prior weeks' Statutory Notice mailout not receiving a Certified Mail Number. | Yes |
| Auto Purge | Auto Purge Pull List | AN | C, CM | Lists cases containing conditions requiring TE review. | Yes |
| Auto Purge | Auto Purge Batch | AN | C, CM | Lists cases remaining in BT 40, 47, 50, 505, 55, 60, or 70. | Yes |
| Auto Purge | RB Batches | W | C, CM | Identifies BT 49, 59, and 79 systemically built and ready to be updated to RB status. | Yes |
| Closed Research | Missing Data | W | C, CM | Lists system closed cases when the data is not secured. | Yes |
| Closed Research | Unavailable return | W | C, CM | Lists system closed cases when the return is not secured. | Yes |
| Notice Date List | Notice Date List | D | C, CM, M, L | Displays specific notice upload dates, notice dates and volumes for each notice type. Use to monitor program progress. | Yes |
| Payer Agent List | Payer Agent List | AN | C | Lists all identified Payer Agents. | Yes |
| Action 61 List | Action 61 List | D | C | Used to monitor volume of system generated Letter 4314-C. | No |
| Pull Listings | CSN | D | C, CK, CM | Used to identify the location of cases within a response batch. | Yes |
| Pull Listings | Notice Date | D | C, CK, CM | Used to identify the location of cases within a response batch. | Yes |
| Auto-Assessment List | Auto-Assessment List | D | CK, CM, C | Used to verify cases are in the correct adjustment sequence for shipment to Document Retention. | No |
| Reworked Cases | Reworked Cases | BT 95 update to BF | C, CM, CK | Identifies cases reworked during notice review. | No |
| Miscellaneous Letter | Miscellaneous Letter | After batch update to RB | C, CM, CK | Identifies cases with manual letters. | Yes |
| Check Notice/Letter Date Listing | Check Notice/Letter Date Listing | After building BT 49, 59, 79 | CK, CM, C | Displays cases missing after no response batch cases have been built. | No |
| Undelivered New Actions | Undelivered New Actions | After BT 59 is RBd | CK, CM, C | Used to pull cases with new actions. | No |
| Undelivered Report | Undelivered Report | AN | CM, C | Tracks the volume of undeliverables and those with new addresses by notice type. | Yes |
| Address Update Report | Address Update Report | After BT 59 update | CK, CM | Displays cases with a new address received since building to BT 59. | Yes |
| New Transactions | New Transactions | W | C, CM | Displays cases with new transactions since building to no response batches. | Yes |
| New Payer Agent report | New Payer Agent report | AN | C, PA | Used to identify cases to be reworked due to new payer agent info. | Yes |
| Reorder Date | Reorder Date | AN | C | Use to review the reorder date screen and not input a reorder date. | Yes |
| Batch Released | Batch Released | AN | C, CM, M, L | Used to monitor batches BFd from units, daily, weekly, monthly. | Yes |
| Over 8 References | Over 8 References | After BT 67 and 87 are RBd | CK, CM, C | Displays cases with more than 8 credit reference numbers. | Yes |
| Suspense Summary | Suspense Summary | After batch update to RB | CK, CM, C | Aids in placing cases in the appropriate suspense file. | Yes |
| Cancel Batch/Completed Work Unit | Cancel Batch/Completed Work Unit | Batch in AU status | C, M | Displays completed work units before updating to CB and at the time batch is being updated to AU in new location. | No |
| Disaster Zip Code | Disaster Zip Code | AN | C | Used to monitor disaster zip codes in the system. | Yes |
| Message of the Day | Message of the Day | AN | C | Used to view or print prior Message of the Day. | No |
| Notice Review List | Notice Review List | W | CM, C | Provides a list of statistically valid sample of cases for notice review. | No |
| RLS Batch | RLS Batch | AN | C, M, CM, L | Identifies cases worked and released by technical units not yet processed by clerical. | Yes |
| UVC Action | UVC Action | AN | C, M, L | Identifies cases viewed by another site (per phone call) needing an action. | Yes |
| Return Chargeout | Return Chargeout | AN | C, M, L | Used to reprint Form 4251 for an individual case or batch. | Yes |
| UVC Activity | UVC Activity | AN | C, M, L | Displays a complete list of Universally accessed cases. | Yes |
| UWC Activity | UWC Activity | AN | C, M, L | Displays a complete list of Universally worked cases. | Yes |
| Disaster CSN/SSN | Disaster CSN/SSN | AN | C, M, L | Used to identify cases in designated disaster zip codes. | Yes |
| Telephone Tracking | Telephone Tracking | AN | C, M | Used to track the volume of calls per specific income types. | Yes |
| ADHOC | ADHOC | AN | C | Lists various specialized reports. | No |
| Profile Reports (under Security menu) | Unit Profile | AN | C, M | Lists Unit employees by profile code. | Yes |
| Profile Reports (under Security menu) | Section Profile | AN | C, M | Lists of Section employees by profile code. | Yes |
| Profile Reports (under Security menu) | Branch Profile | AN | C, M | Lists Operation employees by profile code. | Yes |
| AUR User List (under Security menu) | SEID List | AN | C, M | Lists all users in alphabetical order. | Yes |
| AUR User List (under Security menu) | Unit List | AN | C, M | Lists users in a Unit by either SEID or name. | Yes |
| AUR User List (under Security menu) | Name List | AN | C, M | Lists all users by Name in alphabetical order. | Yes |
| Unit Status Error (under Security menu) | Unit Status Error | Day after updating a users status | M | Identifies cases assigned to users being put in non-work status. | Yes |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-019r#addtoany "Show all")

A2A