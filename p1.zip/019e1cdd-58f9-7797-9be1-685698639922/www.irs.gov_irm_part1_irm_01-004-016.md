---
url: "https://www.irs.gov/irm/part1/irm_01-004-016"
title: "1.4.16 Accounts Management Guide for Managers | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-016#main-content)

- 1.4.16  [Accounts Management Guide for Managers](https://www.irs.gov/irm/part1/irm_01-004-016#id1)
  - 1.4.16.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-016#id2)
    - 1.4.16.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-016#id4)
    - 1.4.16.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-016#id5)
    - 1.4.16.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-016#id6)
    - 1.4.16.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-016#id7)
    - 1.4.16.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-016#id8)
    - 1.4.16.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-016#id9)
    - 1.4.16.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-016#id10)
  - 1.4.16.2  [OPERATIONAL GUIDELINES](https://www.irs.gov/irm/part1/irm_01-004-016#id11)
    - 1.4.16.2.1  [Strategic and Program Plans](https://www.irs.gov/irm/part1/irm_01-004-016#id12)
    - 1.4.16.2.2  [Work Plans](https://www.irs.gov/irm/part1/irm_01-004-016#id13)
    - 1.4.16.2.3  [Toll-Free Telephone Staffing](https://www.irs.gov/irm/part1/irm_01-004-016#id14)
    - 1.4.16.2.4  [Measures and Diagnostic Goals](https://www.irs.gov/irm/part1/irm_01-004-016#id15)
      - 1.4.16.2.4.1  [Toll-Free Measures](https://www.irs.gov/irm/part1/irm_01-004-016#id17)
      - 1.4.16.2.4.2  [Toll-Free Diagnostic Goals](https://www.irs.gov/irm/part1/irm_01-004-016#id18)
      - 1.4.16.2.4.3  [Toll-Free Diagnostic Indicator](https://www.irs.gov/irm/part1/irm_01-004-016#id19)
      - 1.4.16.2.4.4  [Adjustment Correspondence Measures](https://www.irs.gov/irm/part1/irm_01-004-016#id20)
      - 1.4.16.2.4.5  [Taxpayer Relations (TPR) Measures and Workload Indicators](https://www.irs.gov/irm/part1/irm_01-004-016#id21)
      - 1.4.16.2.4.6  [Requirements to Validate Employee Input to Single-Entry Time Reporting (SETR)](https://www.irs.gov/irm/part1/irm_01-004-016#id22)
      - 1.4.16.2.4.7  [Centralized Contact Center Forecasting and Scheduling (CCCFS)](https://www.irs.gov/irm/part1/irm_01-004-016#id23)
    - 1.4.16.2.5  [Read and Meeting Time](https://www.irs.gov/irm/part1/irm_01-004-016#id24)
    - 1.4.16.2.6  [Job Aids and Desk Guides](https://www.irs.gov/irm/part1/irm_01-004-016#id25)
    - 1.4.16.2.7  [Training for Accounts Management (AM) Assistors](https://www.irs.gov/irm/part1/irm_01-004-016#id26)
      - 1.4.16.2.7.1  [Critical Filing Season Readiness Training (CFSRT)](https://www.irs.gov/irm/part1/irm_01-004-016#id27)
      - 1.4.16.2.7.2  [Taxpayer Services (TS) Accounts Management Certification Process](https://www.irs.gov/irm/part1/irm_01-004-016#id28)
        - 1.4.16.2.7.2.1  [Taxpayer Services (TS) AM CSR Online Tool](https://www.irs.gov/irm/part1/irm_01-004-016#id30)
        - 1.4.16.2.7.2.2  [Alternate Certification](https://www.irs.gov/irm/part1/irm_01-004-016#id31)
      - 1.4.16.2.7.3  [Classroom Training Instructor Review](https://www.irs.gov/irm/part1/irm_01-004-016#id32)
  - 1.4.16.3  [TOLL-FREE TELEPHONE SERVICE](https://www.irs.gov/irm/part1/irm_01-004-016#id33)
    - 1.4.16.3.1  [Centralized Contact Center Forecasting and Scheduling (CCCFS) - Telephones](https://www.irs.gov/irm/part1/irm_01-004-016#id34)
    - 1.4.16.3.2  [Unified Contact Center Enterprise (UCCE)](https://www.irs.gov/irm/part1/irm_01-004-016#id35)
    - 1.4.16.3.3  [Managing Features](https://www.irs.gov/irm/part1/irm_01-004-016#id36)
    - 1.4.16.3.4  [Enterprise Level Call Center Announcements and Telephone Scripts](https://www.irs.gov/irm/part1/irm_01-004-016#id37)
    - 1.4.16.3.5  [Availability and Efficiency](https://www.irs.gov/irm/part1/irm_01-004-016#id38)
      - 1.4.16.3.5.1  [Bad Line/Dropped Calls](https://www.irs.gov/irm/part1/irm_01-004-016#id40)
      - 1.4.16.3.5.2  [Average Times/Values to Monitor for Efficiency](https://www.irs.gov/irm/part1/irm_01-004-016#id41)
      - 1.4.16.3.5.3  [Average Handle Time](https://www.irs.gov/irm/part1/irm_01-004-016#id42)
      - 1.4.16.3.5.4  [Average Wrap Time](https://www.irs.gov/irm/part1/irm_01-004-016#id43)
    - 1.4.16.3.6  [Unified Contact Center Enterprise (UCCE) - Real Time Reporting](https://www.irs.gov/irm/part1/irm_01-004-016#id44)
      - 1.4.16.3.6.1  [Agent Status on Unified Contact Center Enterprise (UCCE) – Real-Time Reports](https://www.irs.gov/irm/part1/irm_01-004-016#id46)
    - 1.4.16.3.7  [Fluctuating Call Volume](https://www.irs.gov/irm/part1/irm_01-004-016#id47)
    - 1.4.16.3.8  [Outgoing Calls](https://www.irs.gov/irm/part1/irm_01-004-016#id48)
    - 1.4.16.3.9  [Network Failures/Loss of Finesse Desktop Application](https://www.irs.gov/irm/part1/irm_01-004-016#id49)
    - 1.4.16.3.10  [Telephone System Assistance](https://www.irs.gov/irm/part1/irm_01-004-016#id50)
  - 1.4.16.4  [CORRESPONDENCE/PAPER WORKLOAD OPERATIONS](https://www.irs.gov/irm/part1/irm_01-004-016#id51)
    - 1.4.16.4.1  [Centralized Contact Center Forecasting and Scheduling (CCCFS) - Inventory](https://www.irs.gov/irm/part1/irm_01-004-016#id52)
    - 1.4.16.4.2  [Assigning Paper Inventory](https://www.irs.gov/irm/part1/irm_01-004-016#id53)
    - 1.4.16.4.3  [Managing Inventory](https://www.irs.gov/irm/part1/irm_01-004-016#id54)
    - 1.4.16.4.4  [Physical Inventory Counts/Reconciliation - Quarterly Requirements](https://www.irs.gov/irm/part1/irm_01-004-016#id55)
    - 1.4.16.4.5  [Quarterly Statute Reporting](https://www.irs.gov/irm/part1/irm_01-004-016#id56)
    - 1.4.16.4.6  [AMS Reporting - Accounts Maintenance Research Hold (AMRH), Refund Inquiry and Statute Programs](https://www.irs.gov/irm/part1/irm_01-004-016#id57)
    - 1.4.16.4.7  [Managing Referral Inventory](https://www.irs.gov/irm/part1/irm_01-004-016#id58)
      - 1.4.16.4.7.1  [Referral Inventory Reporting Requirements](https://www.irs.gov/irm/part1/irm_01-004-016#id60)
      - 1.4.16.4.7.2  [Referral Coordinators](https://www.irs.gov/irm/part1/irm_01-004-016#id61)
      - 1.4.16.4.7.3  [Transferring Written Referrals](https://www.irs.gov/irm/part1/irm_01-004-016#id62)
    - 1.4.16.4.8  [Managing Inventory Timeliness and Quality](https://www.irs.gov/irm/part1/irm_01-004-016#id63)
      - 1.4.16.4.8.1  [Inventory Reporting Requirements](https://www.irs.gov/irm/part1/irm_01-004-016#id65)
    - 1.4.16.4.9  [Statute Program](https://www.irs.gov/irm/part1/irm_01-004-016#id66)
    - 1.4.16.4.10  [Manual Refunds – Training and Monitoring Requirements](https://www.irs.gov/irm/part1/irm_01-004-016#id67)
    - 1.4.16.4.11  [Integrated Automation Technologies (IAT) Tools](https://www.irs.gov/irm/part1/irm_01-004-016#id68)
    - 1.4.16.4.12  [Centralized Authorization File (CAF)](https://www.irs.gov/irm/part1/irm_01-004-016#id69)
    - 1.4.16.4.13  [Campus Support](https://www.irs.gov/irm/part1/irm_01-004-016#id70)
    - 1.4.16.4.14  [Unpostable Cases](https://www.irs.gov/irm/part1/irm_01-004-016#id71)
  - 1.4.16.5  [MONITORING AND REVIEWS](https://www.irs.gov/irm/part1/irm_01-004-016#id72)
    - 1.4.16.5.1  [Tracking Monitoring and Reviews](https://www.irs.gov/irm/part1/irm_01-004-016#id73)
    - 1.4.16.5.2  [Feedback and Follow-Up](https://www.irs.gov/irm/part1/irm_01-004-016#id74)
    - 1.4.16.5.3  [Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-016#id75)
      - 1.4.16.5.3.1  [Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-016#id77)
      - 1.4.16.5.3.2  [Contact Recording](https://www.irs.gov/irm/part1/irm_01-004-016#id78)
      - 1.4.16.5.3.3  [Access to Recorded Calls](https://www.irs.gov/irm/part1/irm_01-004-016#id79)
    - 1.4.16.5.4  [Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-016#id80)
      - 1.4.16.5.4.1  [Centralized Evaluative Review (CER)](https://www.irs.gov/irm/part1/irm_01-004-016#id82)
      - 1.4.16.5.4.2  [Team Manager](https://www.irs.gov/irm/part1/irm_01-004-016#id83)
      - 1.4.16.5.4.3  [Department Manager](https://www.irs.gov/irm/part1/irm_01-004-016#id84)
      - 1.4.16.5.4.4  [Feedback and Follow-up](https://www.irs.gov/irm/part1/irm_01-004-016#id85)
    - 1.4.16.5.5  [Workload Management/Efficiency Reviews](https://www.irs.gov/irm/part1/irm_01-004-016#id86)
      - 1.4.16.5.5.1  [General Guidelines](https://www.irs.gov/irm/part1/irm_01-004-016#id88)
      - 1.4.16.5.5.2  [Sharing Results](https://www.irs.gov/irm/part1/irm_01-004-016#id89)
    - 1.4.16.5.6  [Monitoring the Automated Age Listing (AAL)](https://www.irs.gov/irm/part1/irm_01-004-016#id90)
      - 1.4.16.5.6.1  [CCA 4243 – IDRS Overage Report](https://www.irs.gov/irm/part1/irm_01-004-016#id92)
      - 1.4.16.5.6.2  [CCA 4244 – IDRS Multiple Case Control Report](https://www.irs.gov/irm/part1/irm_01-004-016#id93)
      - 1.4.16.5.6.3  [Managers Assessing Performance (MAP)](https://www.irs.gov/irm/part1/irm_01-004-016#id94)
    - 1.4.16.5.7  [Review of IDRS Adjustments](https://www.irs.gov/irm/part1/irm_01-004-016#id95)
      - 1.4.16.5.7.1  [Command Codes for Review of IDRS Adjustments](https://www.irs.gov/irm/part1/irm_01-004-016#id97)
      - 1.4.16.5.7.2  [Focus of the IDRS Adjustments Review](https://www.irs.gov/irm/part1/irm_01-004-016#id98)
      - 1.4.16.5.7.3  [Delegating Reviews of IDRS Adjustments](https://www.irs.gov/irm/part1/irm_01-004-016#id99)
    - 1.4.16.5.8  [Non-Evaluative or Coaching Reviews](https://www.irs.gov/irm/part1/irm_01-004-016#id100)
      - 1.4.16.5.8.1  [Non-Evaluative Monitoring](https://www.irs.gov/irm/part1/irm_01-004-016#id102)
      - 1.4.16.5.8.2  [Side by Side Monitoring](https://www.irs.gov/irm/part1/irm_01-004-016#id103)
      - 1.4.16.5.8.3  [Non-Evaluative Paper/Procedural Reviews](https://www.irs.gov/irm/part1/irm_01-004-016#id104)
    - 1.4.16.5.9  [Clerical Reviews](https://www.irs.gov/irm/part1/irm_01-004-016#id105)
    - 1.4.16.5.10  [Taxpayer Advocate Service (TAS)](https://www.irs.gov/irm/part1/irm_01-004-016#id106)
    - 1.4.16.5.11  [Monitoring the Outstanding Cases Listing (OCL)](https://www.irs.gov/irm/part1/irm_01-004-016#id107)
  - 1.4.16.6  [OPERATIONAL REVIEWS OVERVIEW](https://www.irs.gov/irm/part1/irm_01-004-016#id108)
    - 1.4.16.6.1  [Operational Reviews](https://www.irs.gov/irm/part1/irm_01-004-016#id110)
    - 1.4.16.6.2  [Department, Operation or Front-Line Manager](https://www.irs.gov/irm/part1/irm_01-004-016#id111)
  - 1.4.16.7  [QUALITY REVIEWS](https://www.irs.gov/irm/part1/irm_01-004-016#id112)
    - 1.4.16.7.1  [Measures](https://www.irs.gov/irm/part1/irm_01-004-016#id114)
    - 1.4.16.7.2  [Assurance Components](https://www.irs.gov/irm/part1/irm_01-004-016#id115)
    - 1.4.16.7.3  [Process](https://www.irs.gov/irm/part1/irm_01-004-016#id116)
    - 1.4.16.7.4  [Reports](https://www.irs.gov/irm/part1/irm_01-004-016#id117)
    - 1.4.16.7.5  [Process Improvement (PI) Specialist Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-016#id118)
  - 1.4.16.8  [MANAGEMENT INFORMATION REPORTS](https://www.irs.gov/irm/part1/irm_01-004-016#id119)
    - 1.4.16.8.1  [eWorkforce Management (eWFM)/Workforce Optimization (WFO) Reports](https://www.irs.gov/irm/part1/irm_01-004-016#id120)
      - 1.4.16.8.1.1  [Real Time Adherence (RTA)](https://www.irs.gov/irm/part1/irm_01-004-016#id122)
    - 1.4.16.8.2  [Unified Contact Center Enterprise (UCCE) Reports](https://www.irs.gov/irm/part1/irm_01-004-016#id123)
    - 1.4.16.8.3  [Work Planning and Control System (WP&C)](https://www.irs.gov/irm/part1/irm_01-004-016#id124)
      - 1.4.16.8.3.1  [Managers Report](https://www.irs.gov/irm/part1/irm_01-004-016#id126)
      - 1.4.16.8.3.2  [Program Analysis Report](https://www.irs.gov/irm/part1/irm_01-004-016#id127)
      - 1.4.16.8.3.3  [Abstract Report](https://www.irs.gov/irm/part1/irm_01-004-016#id128)
      - 1.4.16.8.3.4  [Employee Detail Summary Report](https://www.irs.gov/irm/part1/irm_01-004-016#id129)
      - 1.4.16.8.3.5  [Cum File Leveled Performance Report](https://www.irs.gov/irm/part1/irm_01-004-016#id130)
      - 1.4.16.8.3.6  [Accounts Management Inventory Reports (AMIR)](https://www.irs.gov/irm/part1/irm_01-004-016#id131)
      - 1.4.16.8.3.7  [Workload Inventory Tracking System (WITS)](https://www.irs.gov/irm/part1/irm_01-004-016#id132)
    - 1.4.16.8.4  [Account Management Services (AMS)](https://www.irs.gov/irm/part1/irm_01-004-016#id133)
    - 1.4.16.8.5  [Control-D](https://www.irs.gov/irm/part1/irm_01-004-016#id134)
    - 1.4.16.8.6  [Integrated Data Retrieval System (IDRS) Reports](https://www.irs.gov/irm/part1/irm_01-004-016#id135)
    - 1.4.16.8.7  [Enterprise Telephone Data (ETD) Warehouse](https://www.irs.gov/irm/part1/irm_01-004-016#id136)
  - 1.4.16.9  [EMPLOYEE AND BUILDING SECURITY RESPONSIBILITIES](https://www.irs.gov/irm/part1/irm_01-004-016#id137)
  - 1.4.16.10  [Integrated Talent Management (ITM)](https://www.irs.gov/irm/part1/irm_01-004-016#id138)
  - 1.4.16.11  [MANAGING SEASONAL EMPLOYEES: RELEASE AND RECALL](https://www.irs.gov/irm/part1/irm_01-004-016#id139)
  - 1.4.16.12  [MANAGING EMPLOYEES WITH DISABILITIES](https://www.irs.gov/irm/part1/irm_01-004-016#id140)
  - 1.4.16.13  [USEFUL WEBSITES](https://www.irs.gov/irm/part1/irm_01-004-016#id141)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 16. Accounts Management Guide for Managers

* * *

## 1.4.16 Accounts Management Guide for Managers

#### Manual Transmittal

February 26, 2026

#### Purpose

(1) This transmits revised IRM 1.4.16, Resource Guide for Managers, Accounts Management (AM) Guide for Managers.

#### Material Changes

(1) IRM 1.4.16.1 - Added **Primary Stakeholders**.

(2) IRM 1.4.16.1.2 - Added subsection **Authority**.

(3) IRM 1.4.16.1.3 - Updated title of subsection from "Responsibilities" to "Roles and Responsibilities" .

(4) IRM 1.4.16.1.6 - Updated title of subsection from "Terms/Acronyms/Definitions" to "Terms and Acronyms" .

(5) IRM 1.4.16.2.7 - Updated/clarified prerequisites for Practitioner Priority Services (PPS) training. IPU 24U0993 issued 09-25-2024.

(6) IRM 1.4.16.2.7 - Updated and re-clarified prerequisites for PPS training to be in line with the FY25 AM Program Letter. IPU 24U1207 issued 12-13-2024.

(7) IRM 1.4.16.2.7 - Updated/clarified prerequisites again for Practitioner Priority Services (PPS) with this revision.

(8) IRM 1.4.16.2.7.2 - Edited parts of the subsection for clarity and added new bullet under paragraph six (6) to ensure all required actions are taken when an employee has certified. IPU 24U1207 issued 12-13-2024.

(9) IRM 1.4.16.2.7.2.2 - Edited IF/Then Chart to include the word "accurately" for clarity. IPU 25U3336 issued 05-28-2025.

(10) IRM 1.4.16.4.4 - Subsection _Accounts Management Campus Support Review_ removed as obsolete. Review now conducted per IRM 21.10.1.5.1.6.2, _Definition of AM Campus Support Paper Product Line_. IPU 24U0993 issued 09-25-2024.

(11) IRM 1.4.16.5.2 - Edited paragraph four (4) for clarity and added Evaluative Quality Reviews to the paragraph. IPU 24U1207 issued 12-13-2024.

(12) IRM 1.4.16.5.4.1 - Added that the DCI Deletion Request form is to be used for deletion of unshared reviews in paragraph seven (7). Clarified Second Level Reconsideration form is due within seven (7) **business** days in paragraph 10. IPU 24U0993 issued 09-25-2024.

(13) IRM 1.4.16.5.4.1 - Updated some verbiage for clarity.

(14) IRM 1.4.16.12 - Editorial updates were made to this IRM subsection to comply with the January 2025 executive orders and OPM guidance. IPU 25U3336 issued 05-28-2025.

(15) Editorial and website link updates made throughout IRM 1.4.16. IPU 24U0993 issued 09-25-2024 and IPU 24U1207 issued 12-13-2024.

#### Effect on Other Documents

IRM 1.4.16 dated July 17, 2024 (effective July 17, 2024) is superseded. This IRM incorporates the following IRM Procedural Updates (IPUs): IPU 24U0993 issued 09-25-2024, 24U1207 issued 12-13-2024, and 25U3336 issued 05-28-2025.

#### Audience

Managers in Accounts Management campuses and remote call sites.

#### Effective Date

(02-26-2026)

LuCinda Comegys

Director, Accounts Management

Taxpayer Services

**1.4.16.1** **(02-26-2026)**

### Program Scope and Objectives

1. **Purpose:**To provide managers with techniques and guidelines for managing employees in AM campuses and remote sites.

2. **Audience:**Managers in Accounts Management campuses and remote call sites.

3. **Policy Owner:**The Director of Accounts Management.

4. **Program Owner:**Policy & Procedures, Accounts Management, Taxpayer Services (TS).

5. **Primary Stakeholders:**Accounts Management, Taxpayer Services.

6. AM managers will refer to guidelines outlined in other IRMs such as:



   - Part 1, _Organization, Finance, and Management_

   - Part 6, _Human Resources Management_

   - Part 21, _Customer Account Services_

   - Part 25, _Special Topics_


**1.4.16.1.1** **(12-15-2017)**

#### Background

1. Accounts Management (AM) managers must provide leadership and direction to employees responsible for tax and account related inquiries received via telephone, correspondence (paper), and e-mail.


**1.4.16.1.2** **(02-26-2026)**

#### Authority

1. Accounts Management (AM) is guided by the following legal and regulatory authorities:



   - IRC 7803(a)(3), Taxpayer Bill of Rights. Additional information can be found on the IRS.gov website at [https://www.irs.gov/taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights).

   - Policy Statements for Customer Account Services Activities. See IRM 1.2.1.13.


**1.4.16.1.3** **(02-26-2026)**

#### Roles and Responsibilities

1. Managers will refer to guidelines outlined in other IRMs such as:



   - Part 1, _Organization, Finance, and Management_

   - Part 20, _Penalty and Interest_

   - Part 21, _Customer Account Services_

   - Part 25, _Special Topics_


2. As a manager in AM, you must be knowledgeable in the use of various tools/resources used by AM employees. Examples of these tools/resources include:



   - Account Management Service (AMS)

   - Correspondence Imaging Inventory (CII) as applicable

   - Customer Account Data Engine 2 (CADE2)

   - Integrated Data Retrieval System (IDRS)

   - Integrated Automation Technologies (IAT)

   - Interactive Tax Law Assistant (ITLA)

   - Technical Communication Documents (TCD)

   - Servicewide Electronic Research Program (SERP)

   - SERP Job Aids for IRM 21

   - Unified Contact Center Enterprise (UCCE) Computer Telephony Integration Object Server Finesse Desktop Application

   - UCCE Agent Reskilling Tool (ART)


**1.4.16.1.4** **(12-15-2017)**

#### Program Management and Review

1. Managers are required to manage work programs and perform program and employee reviews to ensure Accounts Management work is completed according to procedural guidelines contained in applicable IRMs.

2. Program management and review guidelines are detailed in _.IRM 1.4.16.2_, _Operational Guidelines_.


**1.4.16.1.5** **(01-11-2024)**

#### Program Controls

1. IRS uses access control measures to provide protection from unauthorized access (UNAX), alteration, loss, unavailability, or disclosure of information. Access control will follow the principle of least privilege and separation of duties. This IRM provides guidance for managing access to protected data and for reviewing adherence to data security and procedural guidelines.

2. Managers are required to review administrative, privacy, security, and safety practices according to the responsibilities outlined in this IRM in conjunction with other applicable IRMs and IRS guidance.


**1.4.16.1.6** **(02-26-2026)**

#### Terms and Acronyms

1. Throughout this IRM, references to CSRs include terms such as **Assistors,****Telephone Assistors,****Agents,**or **Staff**. The term **telephone assistor** applies to any employee who is assigned to work the toll-free lines. The term **paper assistor** applies to any employee assigned to work paper inventory such as referrals, Adjustments, or Taxpayer Relations (TPR), etc.


**1.4.16.1.7** **(12-27-2022)**

#### Related Resources

1. The Accounts Management website is an excellent resource for AM managers. It provides vital information regarding the AM organization including various tools for the AM manager to use in performing daily managerial tasks.

2. Human Capital Office (HCO) offers a wealth of managerial tools and information via a page on their website entitled New Manager Orientation Support Center. Examples of the tools found on this resource page include:



   - **Welcome to Management**

   - **Leadership Development**

   - **Performance Mgmt**

   - **Systems Help for Managers** ("Integrated Talent Management (ITM)" , "Single Entry Time Reporting (SETR)," "Concur" , "Human Resources (HR Connect)" , etc.)

   - **Related Links**


3. Another excellent managerial tool is iManage. It is a virtual community for IRS managers. It contains targeted information, advice, and interactive features to help you work more efficiently. The iManage site automatically grants access to employees coded as managers in HRConnect. You cannot access the site if you are not coded as a manager.. If you are unable to access the iManage site, please e-mail the Managers Resource Center at MRC@irs.gov.


**1.4.16.2** **(01-11-2024)**

### OPERATIONAL GUIDELINES

01. AM managers are accountable for:



    01. Providing timely and accurate resolution of inventory.

    02. Ensuring controls are in place to prevent the unauthorized disclosure of taxpayer documents and/or information.

    03. Ensuring telephone staff is commensurate with scheduled half hour staffing requirements.

    04. Meeting telephone monitoring, and paper review and electronic case review standards, to ensure quality products.

    05. Facilitating the delivery of team performance, as related to program goals.

    06. Utilizing Federal Employee Viewpoint Survey data to enhance work environment degree of motivation, commitment to their involvement in the mission and as a basis for communicating with employees.

    07. Updating eWorkforce Management (eWFM)/Workforce Optimization (WFO) data regularly with team information.

    08. Developing and maintaining a positive relationship with National Treasury Employees Union (NTEU) organization.

    09. Listening to and informally resolving employees' concerns.

    10. Timely sharing employee performance feedback on a routine basis.

    11. Leading, mentoring, and coaching subordinate employees.

    12. Identifying process improvement opportunities.

    13. Ensuring best practices are properly documented (e.g., IRM, SERP Alert, Training Document) and shared with HQ.

    14. Ensuring appropriate training is delivered to subordinate employees, and personally participating in technical training classes with employees.



        ### Note:



        Managers must complete all technical training including Critical Filing Season Readiness Training (CFSRT). For additional information regarding CFSRT, see _IRM 1.4.16.2.7.1_, _Critical Filing Season Readiness Training_.

    15. Ensuring the maintenance of a safe and healthy work environment. See IRM 21.1.3.10, **Safety and Security Overview**.

    16. Communicating issues and concerns to superiors, subordinates, and peers.

    17. Performing conduct and/or leave counseling.


02. AM managers must:



    1. Determine the number of positions (staff hours) needed in each specific skill group to meet staffing requirements within acceptable program guidelines.

    2. Develop staffing schedules.

    3. Schedule and use the UCCE Reskilling tool to staff the resources to deliver telephone and paper requirements and scheduled inventory volumes within scheduled resources.

    4. Ensure the site meets its half-hour staffing adherence commitment.

    5. Obtain Embedded Quality, National Quality, and Centralized Quality (EQ, NQ, & CER) Review reports, interpret the data, and provide feedback (regarding mistakes, errors, defects) to each CSR.

    6. Coordinate with other site/campus managers to address programs and inventory issues as they relate to the entire business operating division.

    7. Establish team procedures requiring employees to seek managerial guidance on an issue prior to inputting a SERP Feedback. For additional information regarding this requirement, see the Note in IRM 21.1.2.2.2(1), _IRM 21 - Change Requests/SERP Feedback_.



       ### Note:



       It is not required that employees state this in their SERP feedback; however, it is very helpful information for the content owners who respond to SERP Feedback.

    8. Ensure employees follow the site downtime contingency plan when access to required systems (IDRS, CFOL, SERP, etc.) are unavailable to resolve a telephone inquiry. For employee guidelines regarding the unavailability of required systems, see IRM 21.3.5.4.2.3, _Required Systems Unavailable_, and IRM 21.2.2.4.4.12, _IDRS/CFOL Idle Time_.


03. As part of our goal to provide the best possible service, we solicit feedback from our customers to capture information about the service we provide. The Customer Satisfaction Survey allows us to systemically collect and review satisfaction data directly from our customers.

04. Surveying our customers allows us to identify what we are doing right, as well as areas for improvement to deliver the top-quality service our customers expect. Improving customer satisfaction requires the combined effort of all IRS employees. Front-line employees and managers are the primary providers of service to our customers and have a direct impact on customer perceptions of IRS courtesy, professionalism, accuracy, timeliness, and fairness.

05. The IRS contracted an outside vendor to receive, compile, analyze the results and issue reports. The reports highlight the overall customer satisfaction ratings including the areas in which to focus improvement efforts. Each Operating Unit has a Customer Satisfaction Coordinator who is familiar with the results and provides the reports for their function. For each function, Customer Satisfaction survey results are reported annually at the National level.

06. In addition to the duties listed above, AM managers must use the Customer Satisfaction Survey data to improve the quality of service delivered to our customers. Customer Satisfaction Surveys (CSS) are used to capture information about the service we provide to the taxpayers. The CSS allows us to systematically collect and review satisfaction data directly from our customers. The Customer Satisfaction Survey is part of a larger Servicewide survey effort coordinated by the Organizational Performance Division (OPD). Each operating division has responsibility for its own surveys, although OPD has oversight responsibilities. This Servicewide approach is designed to reduce duplication of effort and maximize usable data for all parts of the IRS. As part of our goal to provide the best possible service to our customers, we solicit feedback from customers on all our product lines.

07. Depending on your site and the Specialized Product Review Group it offers, QR/survey staff may be required to participate in portions of the Customer Satisfaction Survey administration. The IRS has contracted with outside vendors to receive, compile, and report data from our Customer Satisfaction Survey. QR/survey staff will not be required to directly ask the customers about the service they received; only solicit the customers’ participation in the survey.



    1. **The Automated Underreporter**(AUR) survey is administered by an outside vendor. Survey candidates are selected from a Closed Case Database provided to the vendor by The Enterprise Computing Center at Memphis (ECC-MEM). The database is provided monthly and includes cases closed at each of the AUR sites for that month. The vendor sends the survey form along with a postage-paid return envelope to each selected customer. The customer mails their response back to the vendor. The vendor then compiles the results and issues national reports and analysis quarterly. Annual reports are based on statistically valid samples.

    2. The AUR survey questionnaire includes questions specific to taxpayers' satisfaction with service received through notices/letters and on the AUR Toll Free Telephone lines. No survey feedback opportunity is offered to the taxpayer on-line prior to ending a call.

    3. Taxpayer Services (TS) Strategies and Solutions serves as a liaison between the functional units and the contractors, reviewing reports for technical accuracy and providing contracting support.

    4. An outside vendor completes this survey with no direct support necessary from field offices. The vendor selects a statistically valid random sample of closed **Correspondence Exam** cases from the AIMS database each month. The vendor sends the survey form along with a postage-paid return envelope to each selected customer. The customer mails their response back to the vendor. The vendor then compiles the results and issues national reports and analysis quarterly. All reports are based on weighted data. The quarterly reports are based on statistically valid samples.

    5. The **Telephone Customer Satisfaction Survey** has been developed to help measure and improve telephone services to customers.

    6. The survey will be administered by an outside vendor using an external survey system accessible through a toll-free 800 line. Each site has been assigned their own toll-free number.

    7. The survey will be administered during the phone hours of operation.

    8. The calls will be randomly selected before the assistor answers the line.


        The selected Customer Service Representative (CSR) or Contact Representative (CR) offers the survey when the call normally would have been concluded (the caller would have hung up at the end of the call).


        If the CSR/CR is going to transfer the caller to another number or application, (the taxpayer would not have normally hung up) do not notify the caller or offer the survey.


        One person should be designated as your site’s contact point for the Telephone Customer Satisfaction Survey.


08. "Adjustments" as defined for this survey is work processed under the following programs and reported in Accounts Management Inventory Report (AMIR) Categories 1, 2, 6, and 9:

    **Work cases reported under programs:**




    | ****Master File**** | **OFP** |
    | --- | --- |
    | BMF | 1000X, 1005X, 1006X, 1007X, 1008X |
    | EO | 1310X, 1315X, 1320X |
    | EP | 7280X |
    | IMF | 3572X,4000X, 4001X, 4005X, 4006X, 4007X, 4008X, 4009X, 8236X, 8537X, 9714X |
    | International | 3303X, 3304X, 3308X |





    ### Note:



    Programs excluded from the survey: 1542X, 3307X, and 8238X.

09. Closures to be included in the survey are any cases based on an incoming submission from the customer, meaning responses to notices and letters, unsolicited correspondence, amended returns and claims, with the exceptions listed below.


     Closures to be excluded from the survey ("Rejects") are:



    - Correspondence with attached forms or schedules (or an internal route) that simply need to be associated with a return; undelivered mail; and amended returns that are determined to be "True Dups."

    - Cases generated and closed based on internal transcripts or notices, even those that result in outgoing correspondence to the customer, when we have no customer response.

    - Form 4442 Referrals, except for referrals that result in the closure of correspondence, a claim or an amended return that would have otherwise qualified for the survey.


You must pull any case at the designated skip interval, even if it is a "Reject."


10. Pull cases for the survey daily, based on the Sample Selection Methodology procedures.

11. SharePoint data contains the requirements for entering sample case data into the database.



    1. Obtain the data required for input from the closed case file and through IDRS research.

    2. Generally, attempt to ensure that all input fields have an entry unless the instructions allow for a blank. However, if you simply cannot secure data for a field, leave it blank.



       ### Note:



       **Exception**: If it is determined that a case should be excluded from the survey, enter only the Office Identifier, BOD code, and the Reject indicator of "No" and the CII ID; leave the remaining fields blank.

    3. If the address on the customer’s correspondence/amended return/claim is different from the address on IDRS, enter the new address information onto the database.

    4. Review daily input to ensure accuracy.


12. SharePoint Definition Template - From the drop-down boxes input the following information.



    - **CII Case ID** \- Use this field to record the ten-digit CII ID. Also enter the CII ID if the case meets Reject Criteria.

    - **BOD Code** \- Enter WI, SB, LMSB, or TE/GE. Don't assume you can determine the BOD Code. Get it from a notice, from part of the case file, or from IDRS.

    - **Reject**\- Do not enter anything if the case **will**be included in the survey. Enter Yes if the case **will not** be included in the survey and the CII Case ID, do not enter any more data on the input sheet.

    - **E-File** \- Yes or No.

    - **First Name** \- Enter the first name for IMF customers. Enter the first name for any BMF customers whose names are simply an individual's first and last names. Leave blank for all other BMF, EP, and EO customers.

    - **Last Name**\- Enter the last name for IMF customers. Enter the last name for any BMF customers whose names are simply an individual's first and last names. Enter the full name of all other BMF, EP, and EO customers.

    - **Address** \- Enter the street address or Box number.

    - **City**\- Enter city name.

    - **Zip Code** \- Enter the five-digit zip code.

    - **Form**\- Enter specific form filed, e.g., 1040A, 1040, 1040X, 941, 1120, etc.

    - **Last CP Notice Sent**\- Enter the notice number of the last CP Notice issued, for example "501", if it appears to be related to this case. Assume the notice is related if it was issued within 14 to 60 days of the taxpayer's response. Leave blank if there is no record or indication of a notice being issued.

    - **Received Date**\- Enter the IRS Received date using a two-digit month, day, and four-digit year, including slashes, e.g., 01/09/2014.

    - **Closed Date**\- Enter a two-digit month, day, and four-digit year closed date, including slashes, e.g., 02/14/2014.

    - **Program Code**\- Enter:


       BMF - 10000, 10050, 10060, 10070, 10080


       EO - 13100, 13150


       EP - 72800


       IMF - 35720, 40000, 40010, 40050, 40060, 40070, 40080, 82360, 85370, 97140


       International - 33030, 33040, 33080



      ### Note:



      Do not use a specific fifth digit.

    - **Issue** \- Enter:


       Status of Refund


       Earned Income Credit


       Credits (childcare, education, etc.)


       Status of payment


       Exemptions/Dependents


       Other changes to original return


       Penalty/Interest charges


       Name/Address changes


       Other

    - **Telephone Number**\- Obtain the taxpayer’s telephone number from their submitted documents, or ENMOD. If none is present in the case file or on ENMOD, do not enter anything (numeric field only).

    - **Filing Status (IMF only)**\- Enter:


       Single


       Married filing joint


       Married filing separate


       Head of Household


       Qualifying Widow

    - **AGI (IMF Only)**\- Enter:


       $0 to $24,999


       $25,000 to $49,999


       $50,000 to $99,999


       $100,000 +

    - **Taxable Income (IMF Only)** \- Enter:


       $0 to $24,999


       $25,000 to $49,999


       $50,000 to $99,999


       $100,000 +

    - **Date of Birth (IMF Only)**\- Enter two-digit month, day, and four-digit year, including the slashes, e.g., 04/08/1967. Use the birth date of the primary taxpayer if a joint account.


13. All closures must be input by the fourth business day following the end of the month. Adjustments Customer Satisfaction Survey data will be transferred via Enterprise File TransferUtility (EFTU) by the PICA Staff.

14. Time Reporting: Clerks or CSRs working any part of this survey process should use 790-00000. Analysts or managers should include time spent on the survey under the function and program they normally use daily. In the event a lead CSR is involved, they should use the OFP they normally use when not working cases.

15. For the Adjustments survey of Correspondence customers, source case data submitted to headquarters will be retained by the PICA staff until survey results for the quarter have been generated, or for a period not to exceed six months. Sites are no longer responsible for retention of the case data.

16. **The Injured Spouse** Customer Satisfaction survey was developed to help measure and improve Form 8379, Injured Spouse Allocation services to our customers. An outside contractor administers the Injured Spouse Survey questionnaire. The survey includes specific questions to taxpayers' satisfaction with service received with preparing and filing Form 8379, communications with Customer Service Representatives when contacted for updates and the outcome of their allocation.

17. Using a data base query tool, survey candidates are selected by querying closed Injured Spouse cases in the Correspondence Imaging Inventory (CII).

18. Headquarters uses a Generalized IDRS Interface (GII) tool to build the data for transmission to the contractor. All data transmitted to the contractor for the Injured Spouse Survey is sent via the Enterprise File Transfer Utility (EFTU) to a share point site. Pull the Injured Spouse weekly data by:



    01. Access Accounts Management Services (AMS)

    02. CII Inventory

    03. CII Administration

    04. Database Query Tool

    05. Select table ARCH\_Case

    06. Remove “Count Only” & Set Limit results to 100,000

    07. CAT\_CD Select “=” Type “DMFC”

    08. CLS-TMSTMP “Between” Type “2018-08-05 01:00:00 and 2018-08-12 01:00:00” (change dates as appropriate)

    09. Click Submit

    10. Click on Copy to Clipboard button and paste into new Excel sheet

    11. Repeat Steps for DMFE

    12. Repeat Steps for DMFT

    13. Select table CASE

    14. CAT\_CD Select “=” Type “DMFC”

    15. CLS-TMSTMP “Between” Type “2018-08-05 01:00:00 and 2018-08-12 01:00:00”

    16. (change dates as appropriate)

    17. Remove “Count Only” & Set Limit results to 100,000

    18. Copy/Paste results to appropriate Excel tab

    19. Repeat Steps for DMFE


19. The contractor sends the survey form along with a postage-paid return envelope to each selected customer.

20. Upon receipt of the customer's response, the contractor enters data and transmits it to the TS Strategies and Solutions staff thru EFTU monthly.

21. TS Strategies and Solutions no longer provides quarterly, semi-annual, and annual reports and analysis to the Injured Spouse Headquarters Staff for review. An external contractor handles all analysis and reporting. TSSS reviews the report for technical accuracy and serves as liaison between the functional/business unit and the contractor.


**1.4.16.2.1** **(01-20-2023)**

#### Strategic and Program Plans

1. AM managers follow the Strategic and Program Plans outlined in the following documents:



   - IRS Strategic Plan

   - Taxpayer Services (TS) Operations Plan

   - FY25 AM Program Letter

   - Memorandum of Understanding (MOU) Covering Customer Service Operations Between Internal Revenue Service and National Treasury Employees Union (NTEU) (Also known as the Customer Service Agreement (CSA))


2. The AM Program Letter (identified above) is an annual communication from the Director, Accounts Management, and it provides the following:



   - Specific guidelines, goals, and strategies used by AM to ensure consistent telephone and inventory program delivery.

   - Offers assistance and guidance to the sites as they create their strategic and operational plans.


AM managers MUST complete the following actions:



   - Follow the requirements and expectations outlined in the Program Letter to maintain efficiency in all programs and provide optimum service to customers.

   - Share and discuss with their staff the performance goals and other guidelines outlined in the Program Letter.


### Note:

The Program Letter does not supersede or replace IRM instructions.

3. The Customer Service Agreement (CSA) (identified above) applies to all bargaining unit employees assigned to AM campus and remote sites. It is intended to enhance taxpayer service and business efficiency by taking full advantage of changes in technology, while at the same time promoting employee satisfaction.


**1.4.16.2.2** **(12-10-2020)**

#### Work Plans

1. The guidance in the Program Letter, along with budget allocations, makes up the work plan. Work plans are a projection of the staff hours needed to meet workload demands for each program for the entire fiscal year.

2. General goals based on resources are determined on an annual basis in the Planning and Budgeting process.



1. Work plans and schedules are based on projected workload, which includes anticipated growth, overage, and uncontrolled cases.

2. Quality of answers/responses is as important as the volume of calls answered and cases closed. The evaluative measure applied to the plan does not focus only on calls answered, services delivered, or the number of receipts closed.


3. The work plan includes three Planning Periods (PP):



   - PP1 October - December

   - PP2A January - March

   - PP2B April - June

   - PP3 July - September


4. Work plans change throughout the year depending on different factors, such as peak months for paper receipts and peak toll-free call demand.

5. Managers must schedule available staffing for each planning period based on the telephone staffing schedules, no attempt is or should be made to catch up on shortfalls in scheduled services within a planning period or in any other planning period.

6. AM HQ Resource, Management & Training (RMT) staff coordinate with the Joint Operations Center (JOC) to ensure adherence to telephone staffing requirements so that program goals are achieved.

7. AM sites must schedule available staffing for the Toll-Free Telephone operations using telephone requirements.

8. The following AM programs must schedule available staffing based on inventory:



   - Adjustments Correspondence (including Tax Exempt/Government Entities (TEGE))

   - Taxpayer Relations (TPR), which include:


      CAF (Centralized Authorization File)


      RAF (Reporting Agents File)


      Refund Inquiry


      AMRH (Accounts Maintenance Research)


      Statute


      Large Corporation


9. To reduce inventory, it may be necessary to request additional staffing. Sites must submit this request to the AM HQ RMT staff for coordination.


**1.4.16.2.3** **(12-06-2019)**

#### Toll-Free Telephone Staffing

1. Efficient telephone staffing is key to meeting the planned Level of Service (LOS) and Average Speed of Answer (ASA) objectives. For more information, see _IRM 1.4.16.2.4.1_, _Toll-Free Measures_.

2. Managers must ensure staffing is efficient. An increase to the Average Handle Time (AHT) can impact LOS, ASA, and other business measures and in turn increase the need for staff.

3. Information is available from system reports for you to monitor the efficiency of your staff. Reports available include:



1. Average Handle Time

2. Wrap Time

3. Idle Report

4. Agent Activity Report

5. Sign On/Sign Off Report

6. Ready Report


UCCE call center real-time, historical, or interval reports are available on Aceyus . ETD provides limited UCCE historical reporting capabilities.



| **ETD Reports** | **Aceyus Reports** |
| :-: | :-: |
| AHT\_Team\_Agent\_Application | IRS.STND.CF\_Agent \_Skill\_Group.03 |
| Agent Call Detail | IRS.STND.CF\_Agent\_Team.03 |
| Agent Events Detail | IRS.STND.DD\_Agent\_Team (Multiple Reports) |
| Call Detail Analysis | IRS.STND.HD\_Call\_Type\_Svc\_Call\_Stats |
| Excessive Reason Code | IRS.STND.HI\_Agent\_Skill\_Group (Multiple Reports) |
| Outbound Profile by Team | IRS.STND.HI\_Agent\_Team (Multiple Reports) |
| Short Call | IRS.STND.HI\_Call\_Type (Multiple Reports)<br> IRS.STND.RT\_Agent\_Skill\_Group (Multiple Reports)<br> IRS.STND.RT\_Agent\_Team (Multiple Reports)<br> IRS.STND.RT\_Call Type (Multiple Reports) |

**1.4.16.2.4** **(03-07-2023)**

#### Measures and Diagnostic Goals

1. AM measures focus on business results (including quantity and quality), customer satisfaction, and employee satisfaction.

2. Diagnostic goals are developed to determine how to manage and assess performance. Refer to _IRM 1.4.16.2.4.1_, _Toll-Free Measures_.


**1.4.16.2.4.1** **(01-01-2016)**

##### Toll-Free Measures

1. The Toll-Free measures include:



1. Average Speed of Answer

2. Assistor Services Provided

3. Level of Service (LOS)

4. Customer Satisfaction

5. Employee Satisfaction

6. Customer Accuracy

7. Timeliness

8. Professionalism


2. Customer Satisfaction results are captured by the on-line customer survey in which Toll-Free callers participate.

3. Employee Satisfaction results are captured through the Employee Survey Process.

4. See _IRM 1.4.16.7.1_, _Measures_, for information on Customer Accuracy, Timeliness, Professionalism.


**1.4.16.2.4.2** **(12-17-2018)**

##### Toll-Free Diagnostic Goals

1. The Toll-Free diagnostic goals are:



   - Assistor Utilization

   - Transfer Rate

   - Application Staffing


2. The Assistor Utilization diagnostic goal suggests unwarranted "slippage" and/or inaccurate time charged. It is a comparison of the UCCE Report to Single Entry Time Reporting System (SETR).

3. As an AM Manager, you must verify compliance with Assistor Utilization goals by using the Enterprise Telephone Data (ETD) site measure reports. Compare the AHT\_Team\_Agent\_Application Report data to the time reported by your employees to SETR. Ensure the employees’ time is charged to the correct Organization, Function and Program (OFP) and resolve any discrepancies prior to close of business each week and validating SETR. See _IRM 1.4.16.2.4.6_, _Requirements to Validate Employee Input to Single Entry Time Reporting (SETR)_.

4. The Transfer Rate compares the number of calls transferred by Customer Service Representatives to the number of calls handled. Ensure employees are following the Telephone Transfer Guide in SERP and the Taxpayer Services (TS) Transfer Policy.

5. Use the ETD Agent Transfer reports to verify compliance with the transfer policy. Calls may need to be transferred for a variety of reasons:



1. Caller has questions on more than one type of issue

2. Caller made the wrong selection when responding to script

3. Assistor may not have had training for issue(s)

4. Systemic problem caused call to be delivered to wrong application


6. The Application Staffing diagnostic goal measures the delivery of required staffing to primary applications. The goal for sites is to meet or exceed 95 percent of each half hourly staffing requirement for 85 percent or more of the total half hours of operation.


**1.4.16.2.4.3** **(12-15-2017)**

##### Toll-Free Diagnostic Indicator

1. The Diagnostic Indicator of Agent Availability indicates the percent of agent availability to total handle time delivered. This is used in conjunction with other data to give a complete picture of performance.

2. Variances from plan may indicate:



   - Forecast of workload mix or call volume is off-target

   - Skill gaps (lack of specific training)

   - Sites not delivering skill or training requirements

   - AHT lower than planned


**1.4.16.2.4.4** **(12-10-2020)**

##### Adjustment Correspondence Measures

1. Adjustment Correspondence Measures are:



1. Customer Accounts Resolved

2. Adjustments Productivity

3. Adjustments Customer Satisfaction Survey

4. Employee Satisfaction Survey

5. Quality - Customer Accuracy, Timeliness, Professionalism


2. Customer Accounts Resolved is the number of closures including Adjustments, International and Taxpayer Relations (TPR) cases.

3. Adjustments Productivity means meeting the target rate set by the AM Director. This is determined by dividing the Function 710 closures by direct staff hours.

4. Adjustments Customer Satisfaction results are captured from responses to mail surveys issued to customers whose adjustment case is closed.

5. Employee Satisfaction results are captured through the Federal Employee Viewpoint Survey (FEVS) Process.

6. Quality is measured by closed case reviews conducted at each site in accordance with the Embedded Quality guidelines.

7. The Inventory Control Manager (ICM) monitors the controlled overage and uncontrolled inventory on a weekly basis. The ICM uses the following indicators to assess the health of the site’s Adjustments inventory:



   - Inventory and overage volumes

   - Prior week's closures compared to scheduled closures

   - Actual productivity rates compared to targeted productivity rates

   - Closure to receipt ratio

   - Days in inventory


8. AM Managers **must** monitor their assigned teams’ overall inventory management practices as follows:



   - Using the CCA 4243, _IDRS Automated Age Listing (AAL)_ to ensure appropriate and timely follow-up actions are taken.

   - Using the CCA 4244, _IDRS Multiple Case Control Listing_ to ensure multiple case controls are addressed and closed as appropriate.



     ### Note:



     For additional information about utilizing the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_; _IRM 1.4.16.5.6.1_, _CCA 4243 - IDRS Overage Report_; and _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Report_


**1.4.16.2.4.5** **(12-10-2020)**

##### Taxpayer Relations (TPR) Measures and Workload Indicators

1. Taxpayer Relations (TPR) balanced measures include:



   - Customer Accounts Resolved (Includes Adjustments, International and TPR cases)

   - TPR Productivity as scheduled by program


2. TPR Workload Indicators include:



   - Overage Percentages as scheduled by program

   - Actual Productivity rates compared to targeted rates

   - Closure to receipt ratio

   - Statute Awareness


### Note:

By the 15th day of the month following the close of the quarter, each AM Planning and Analysis (P&A) staff **must** submit a quarterly Statute Awareness Program Report to the Policy & Procedures BMF (PPB) Specialty Accounts (SA).

3. Refer to the current AM Program Letter for additional information regarding the TPR programs.

4. AM Managers **must** monitor their assigned teams overall inventory management practices using:



   - Using the CCA 4243, _IDRS Automated Age Listing (AAL)_ to ensure appropriate and timely follow-up actions are taken.

   - Using the CCA 4244, _IDRS Multiple Case Control Listing_ to ensure multiple case controls are addressed and closed as appropriate.



     ### Note:



     For additional information using the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_; _IRM 1.4.16.5.6.1_, _CCA 4243 - IDRS Overage Report_; and _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Report_


**1.4.16.2.4.6** **(01-20-2023)**

##### Requirements to Validate Employee Input to Single-Entry Time Reporting (SETR)

1. AM Managers are required to ensure that employee's time is input correctly into the Single-Entry Time Reporting (SETR).

2. Ensure the employee's time is charged to the correct OFP and resolve any discrepancies prior to close of business each week and SETR validation. Managers are responsible for validating their employees’ SETR Time and Attendance records by Close of Business each Friday of the pay period if the organization has a weekly reporting requirement. SETR Alerts are sent to managers frequently; ensure that you are reviewing these alerts to assist you with time reporting. Also see the Employee Resources News, which can be found on the Employee Communication for HCO (the ECHCO) site.

3. If an error in reporting is identified, an Individual Performance Report (IPR) correction is required and must be input timely. See IRM 3.43.405.6, _Individual Performance Report (IPR) Adjustments._

4. For additional information on OFP Codes, see OFP Code Resource Center Online and IRM 3.30.20, _Organization Function and Program (OFP) Codes._


**1.4.16.2.4.7** **(12-15-2017)**

##### Centralized Contact Center Forecasting and Scheduling (CCCFS)

1. CCCFS is utilized by AM HQ staff to ensure the optimum number of assistors are available on the telephones and paper programs to enhance customer service to the taxpayers.

2. The sites classify employee skills in the e-Workforce Management (eWFM)/Workforce Optimization (WFO) application software so that the Resource Planning and Scheduling (RP&S) can appropriately assign work to match employee availability to taxpayer demand. Precise schedules are created with projected services, AHT, level of service (LOS), and hours for each planning period, which are then converted into half-hour staff group requirements by program. Sites can then plan accordingly and manage their resources to meet telephone and paper strategic goals.

3. Additional CCCFS items are referenced in _IRM 1.4.16.3.1_ , _Centralized Contact Center Forecasting and Scheduling (CCCFS) - Telephones_; and _IRM 1.4.16.4.1_, _Centralized Contact Center Forecasting and Scheduling (CCCFS) - Inventory_.


**1.4.16.2.5** **(03-07-2022)**

#### Read and Meeting Time

1. AM guidelines for Read and Meeting Time are outlined in the current Customer Service Agreement (CSA), Part 1, Section 2, _Read and Meeting Time_. The CSA web page is found at: Customer Service Agreement. This web page includes the CSA / MOU, CSA Frequently Asked Questions, and additional CSA information including a _Meet and Read Desk Guide_.

2. Managers will schedule read and meet time each week throughout the year with their employees. This includes filing season. Generally, do not schedule read and meet time during peak hours or on peak days. This exception would apply if new materials are issued and are critical to the employee’s job performance. Some examples of peak workdays are:



   - Mondays

   - Tuesdays following a Monday holiday

   - April 1 through the filing deadline

   - Extension dates for IMF and BMF returns


3. Read time is scheduled for 60 minutes each week. This time is generally spent on reading and filing activities (e.g., SERP issuances, technical or procedural information, all employee memoranda, IDRS message files, work related emails, and management directed topics) to ensure the products and services provided to customers are accurate.

4. Possible reasons for granting additional read time are outlined in the CSA.

5. Meeting time is defined as time spent in recurring meetings that primarily focus on clarifying technical or procedural items. Administrative items may also be covered during this meeting time after all technical and procedural issues have been addressed.

6. Topics which would not be covered in a team meeting include formal training, On-the-Job Instruction (OJI), Employee Engagement Survey meetings and topics covered during "formal meetings" as defined in 5 U.S.C. paragraph 7114(a)(2)(A). Managers should seek the assistance of Labor Relations to determine if a topic of discussion meets the definition of a "formal meeting." For additional information, see the 2022 NTEU Agreement, Article 8, **Union Rights**. Also see Formal Meeting (7114) Planner or 7114 Meeting Guidance for Managers..

7. The manager will schedule, on a weekly basis, 30 minutes for meeting time with an additional 30 minutes allotted as the parties may mutually agree locally.

8. If additional supplemental meet time is needed, coordinate with your department manager and schedule around the workload.

9. Ensure the correct OFP codes and time used for Read and Meet time are input into Single Entry Time Reporting (SETR). The codes to use are:



   - 990-59221 - Read Time

   - 990-59222 - Meet Time


For additional information on OFP Codes, see the OFP Code Resource Center Online and IRM 3.30.20, _Organization, Function, and Program (OFP) Codes_.



**1.4.16.2.6** **(12-10-2020)**

#### Job Aids and Desk Guides

1. A job aid or desk guide is a resource used to help improve the program quality and performance at an AM site or directorate. The following supplemental resources are examples of job aids:



   - IRM Exhibits

   - IRM 21 Job Aids (posted in SERP)

   - SERP Alerts

   - SERP Portals

   - Technical Communication Documents (TCDs)

   - AMS tools (Integrated Automation Technologies (IAT), Interactive Tax Law Assistant (ITLA), etc.)



     ### Reminder:



     For any corrections or change requests regarding the above resources, you must submit a SERP Feedback to the content owner via the SERP Feedback System.





     ### Reminder:



     SERP Feedback is for corrections or change requests. Before employees submit correction/change requests for IRM 21, _Customer Account Services_, or IRM 25.23, _Identity Protection and Victim Assistance_, via the feedback system, they must consult their manager or lead to verify if the feedback is a valid request for an IRM change/correction. For additional information, see IRM 21.1.2.2.2, _IRM 21 - Change Requests/SERP Feedback_.


2. Each directorate must maintain (review, update, etc.) and ensure the accuracy of any and all job aids, desk guides, websites, etc. created by the directorate.

3. Any and all job aids, desk guides, etc. created by a directorate must be consistent with the current applicable IRM and must include the IRM references and shared with the appropriate IRM author.


**1.4.16.2.7** **(02-26-2026)**

#### Training for Accounts Management (AM) Assistors

1. Training courses for assistors are found on Integrated Talent Management (ITM). You may also contact your Functional Training Coordinator at your AM site regarding the training curriculum found on the Training SharePoint site. You must also review the Training Assumptions, which are found on the Training SharePoint site as well as on the AM Training site.

2. The Training Assumptions include necessary information for managers to deliver proper training. Training material is updated each year and subsequent updates are posted to the Instructors Corner SharePoint site.



### Note:



Contact Resource Management and Training (RMT) regarding Training Assumptions and other training issues requiring HQ assistance.

3. Experienced employees, not new-hires, must be fully successful and proficient in their current telephone application or paper inventory skills before receiving additional training (Skill-up Training). The Department Manager and Frontline manager verify an employee is eligible for skill-up training.

4. **Practitioner Priority Services (PPS)** \- To deliver the best quality service to practitioners, CSRs staffing the _Practitioner Priority Service (PPS)_ application must be fully trained in either APP 20, _IMF Account_, or APP 30, _BMF Other_, be rated fully successful, and preferably have at least two (2) years of experience on APP 20 or APP 30 on AM Toll-Free telephone applications prior to being assigned to this application.



   - For **IMF**, assistors **must** have one (1) year of experience on APP 20.

   - For **BMF**, assistors **must** have one (1) year of experience on APP 25 and **must** also have a current APP 30 certification for at least six (6) months.


### Note:

There **must** be coordination between the Directorate, Resource Management and Training (RMT), and Policy & Procedures BMF (PPB) **prior** to skilling up employees to PPS.

### Note:

The above requirements also apply to seasonal telephone assistors staffing the PPS Application.

**1.4.16.2.7.1** **(01-02-2017)**

##### Critical Filing Season Readiness Training (CFSRT)

1. Critical Filing Season Readiness Training (CFSRT) uses a blended delivery approach with a few lessons delivered as self-study including some classroom (instructor led). A portion of the technical self-study courses will be delivered as facilitated interactive sessions with the facilitator addressing questions, key points, and quality trends.

2. The CFSRT hours listed below, according to work assignment, are the maximum hours and include time for certification and tests:




| **WORK ASSIGNMENT** | **CFSRT HOURS** |
| :-: | :-: |
| IMF (Tax Law/ Accounts/ Adjustments) | Up to 45 total |
| BMF | Up to 22.2 total |
| Bilingual (Spanish) | **Additional** 7 hours |
| TPR | Up to 14.8 total |
| Clerical | Up to 7.4 total |

3. The CFSRT on-line self-study courses allow employees to learn at their own pace and receive support from their managers and leads as needed. This process also eliminates, or significantly reduces, the need for classroom space and instructor preparation time. Additionally, it avoids one-size-fits-all training.

4. As an AM frontline manager, you play a critical role in the successful delivery of this training. You are in the best position to understand the work that your employees perform, their skill levels and their CFSRT needs.

5. Additional CFSRT self-study instructions include:



   - Managers and leads will complete their CFSRT courses before their team employees.

   - Managers will work with their employees to determine in advance which elective topics each employee will complete.

   - Managers and leads must be available to answer employee questions when the employees take their CFSRT lessons.


6. CFSRT is considered technical training, and managers must complete all technical training to address employee quality issues.


**1.4.16.2.7.2** **(12-13-2024)**

##### Taxpayer Services (TS) Accounts Management Certification Process

1. Use the certification process to verify newly trained employees are ready to independently perform the new work assignment. The certification process starts during the training curriculum and can continue beyond On-the-Job Training (OJT). Complete the certification process, including Alternate Certification, within 3-weeks from the end of OJT.



### Note:



Coordinate with the Department Manager and Resource Training Coordinator (RTC) for additional time to certify an employee, if necessary. If there is a lack of work (phone calls or inventory cases) to certify an employee, the Department Manager must coordinate with key stakeholders, e.g., Telephone System Support (TSS), Planning & Analysis, etc., to assist in resolving the issue.





### Note:



For telephone training curriculums, the employee is certified in the highest application in the curriculum. For example, an employee training in Applications 001, 005, 017, and 020 completes certification for Application 020.

2. During the certification process, all reviews of newly trained work assignment are non-evaluative. For employees subject to evaluative reviews by the AM Centralized Evaluative Review (CER) program, refer to _IRM 1.4.16.5.4.1_, _Centralized Evaluative Review (CER)_, for more information to stop evaluative reviews.

3. During training, or immediately following training, employees must use the TS AM CSR Online Tool. Refer to _IRM 1.4.16.2.7.2.1_ for more information.




| **If** | **Then** |
| :-: | :-: |
| The employee passes the first TS AM CSR Online Tool assessment, | Refer to paragraph 4 below for the next step in the certification process. |
| The employee does not pass the first TS AM CSR Online Tool assessment, | Meet with the employee to review the results and create an action plan to demonstrate the employee can independently perform the work as assigned.<br> Provide any assistance indicated in the action plan.<br> The employee must attempt the second assessment at the earliest opportunity, but no later than the end of OJT. |
| The employee passes the second TS AM CSR Online Tool assessment, | Refer to paragraph 4 below for the next step in the certification process. |
| The employee does not pass the second TS AM CSR Online Tool assessment, | The manager must take the following actions:<br> <br>1. Provide the employee with counseling documentation. In the documentation, specify the employee must pass certification to work the new work assignment.<br>      <br>2. Establish an action plan to help the employee demonstrate they can perform the work assignment.<br>      <br>3. Start the Alternate Certification process, see _IRM 1.4.16.2.7.2.2_, _Alternate Certification_.<br>      <br> Do not continue in the standard certification process. |
| The work is not covered by the TS AM CSR Online Tool<br> Or<br> The TS AM CSR Online Tool is unavailable, | Start the Alternate Certification process, see _IRM 1.4.16.2.7.2.2_, _Alternate Certification_.<br> Do not continue in the standard certification process. |

4. After an employee passes a TS AM CSR Online Tool assessment, the manager must complete two non-evaluative reviews of the new work assignment. Enter the non-evaluative reviews into Embedded Quality Review System (EQRS). Refer to IRM 21.10.1, _Embedded Quality (EQ) Program for Accounts Management, Campus Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support_. Department Managers and RTCs must use EQRS AdHoc reports to monitor non-evaluative reviews conducted for certification.




| **If** | **Then** |
| :-: | :-: |
| The new work assignment is a telephone application, | Review two calls in EQRS to verify the employee communicates technical information professionally, proficiently, and accurately to the customer. |
| The new work assignment is an inventory skill, | Review two cases in EQRS for all required actions, including responding with required correspondence and proficient written communication skills accurately addressing all issues. |





### Note:



The work reviewed must match the newly trained telephone application or inventory skill.

5. The manager must share the non-evaluative reviews with the employees:



### Note:



If a defect is identified on the review, EQRS will identify the defect accuracy type. For example, EQRS will identify an Attribute 715 defect as a Customer Accuracy defect which impacts the taxpayer.






| **If** | **Then** |
| :-: | :-: |
| The reviews are free of defects, | Give the employee positive feedback. Encourage the employee to repeat the processes which resulted in the positive results. |
| The reviews identify Customer Accuracy defects, | Explain the impact to the taxpayer and the potential impact if the review had been evaluative.<br> Address quality improvement opportunities.<br> Start the Alternate Certification process, see _IRM 1.4.16.2.7.2.2_, _Alternate Certification_.<br> Do not continue in the standard certification process. |
| The reviews identify defects other than a Customer Accuracy defect, | Explain the impact to the taxpayer and the potential impact if the review had been evaluative.<br> Address quality improvement opportunities. |



    After two non-evaluative reviews without a Customer Accuracy defect, follow the procedures in paragraph 6 below.



6. Certify the employee is eligible to independently work the assigned work.



   - Notify the RTC and Department Manager of the successful certification(s).

   - Coordinate with the RTC and Telephone Support Staff (TSS) to update employees’ skill assessments, eWorkforce Management (eWFM), and Workforce Optimization (WFO) to reflect the newly assigned work. Department Managers must retain a list of employees’ certification status for one year (e.g., passed standard certification, passed alternate certification, and unsuccessful certification attempts).

   - If the training curriculum covers multiple inventory skills, complete the certification process for each topic skill. Ensure the employee’s Correspondence Imaging Inventory (CII) profile is updated to allow receipt of evaluative reviews.

   - Add or update the CER SharePoint for the employee as needed to receive evaluative reviews from CER. See _IRM 1.4.16.5.4.1_, _Centralized Evaluative Review (CER)_.

   - Update EQRS employee maintenance screen (refer to the EQRS User Guide for additional information) or coordinate with the site System Support Coordinator (SSC) to add telephone applications or Specialized Product Review Groups (SPRG) to allow receipt of evaluative reviews.


**1.4.16.2.7.2.1** **(09-26-2023)**

###### Taxpayer Services (TS) AM CSR Online Tool

1. The TS AM CSR Online Tool is part of the certification process that utilizes topic specific assessments. The tool can be accessed under the Learning Tab in SERP.

2. Deliver the assessments according to the training curriculum or during On-the-Job Training (OJT). Charge the time used for the online assessments to function and program 990-59250.



### Exception:



New hire training assessments should be charged to function and program 990-59256.





### Note:



Managers may utilize the TS AM CSR Online Tool results to identify opportunities for improvement and to develop an improvement plan.


Do not use the function and program codes listed above when using the TS AM CSR Online Tool outside of the certification process.

3. Managers must coordinate with the Local Site Administrator (LSA) to add each employee’s Standard Employee Identifier (SEID) and badge number to the database for access to the TS AM CSR Online Tool assessments.

4. For **telephone**, and **inventory programs**, employees must pass one version of each applicable assessment. There are two versions (version A or B) of most assessments. Employees complete each telephone assessment within 60 minutes (except for Application 20 IMF Accounts) and each inventory assessment within 90 minutes. See the table below for additional times:




| **If** | **Then** |
| :-: | :-: |
| The employee takes an **Application 20 IMF Accounts** assessment, | The assessment will be completed within 90 minutes.<br> No additional actions are required for the additional time. |
| The employee takes a supplemental Spanish assessment, | The employee will have additional time, up to 50% of the normal time, for example:<br> <br>   - 90 minutes for most telephone assessments<br>     <br>   - 120 minutes for inventory assessments<br>     <br> No additional actions are required for the additional time. |
| An employee has a reasonable need for more time, including employees who are Visually Impaired (VI), | The employee will have additional time up to 50% of the normal times listed above, for example:<br> <br>   - 90 minutes for most telephone assessments<br>     <br>   - 120 minutes for most inventory assessments<br>     <br> The LSA must select the VI indicator to add additional time for any reasonable need for more time. |

5. Employees must score 80% or higher to successfully pass a telephone or inventory skill assessment. The employee can print the results immediately after taking the assessment, or the LSA can generate reports with the results for individuals or for a team.

6. Discuss the assessment results with the employee and place a copy of the results in the employee’s Employee Personnel File (EPF).

7. Refer to _IRM 1.4.16.2.7.2_ for additional steps in the certification process.


**1.4.16.2.7.2.2** **(05-28-2025)**

###### Alternate Certification

1. Alternate Certification is used when one or more of the following apply:



1. The employee did not pass the TS AM CSR Online Tool assessments.

2. The TS AM CSR Online Tool is not available or does not cover the newly trained assignment.

3. The employee’s non-evaluative reviews for the standard certification process identify a Customer Accuracy defect.


See _IRM 1.4.16.2.7.2_, _Taxpayer Services (TS) Accounts Management Certification Process_.



2. For Alternate Certification, the manager must complete non-evaluative reviews of the new work assignment. The non-evaluative reviews must be entered into Embedded Quality Review System (EQRS). See IRM 21.10.1, _Embedded Quality (EQ) Program for Accounts Management, Campus Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity, and Compliance Services (RICS), and Electronic Products and Services Support_.




| **If** | **Then** |
| :-: | :-: |
| The new work assignment is a telephone application, | Review three calls in EQRS to verify the employee communicates technical information professionally, proficiently, and accurately to the customer. |
| The new work assignment is inventory skill, | Review five cases in EQRS for all required actions, including responding with required correspondence and proficient and accurately written communication skills. |





### Note:



The work reviewed must match the newly trained telephone application or inventory skill.

3. The manager will share each the non-evaluative review with the employees:



### Note:



If a defect is identified on the review, EQRS will identify the defect accuracy type. For example, EQRS will identify an Attribute 715 defect as a Customer Accuracy defect which impacts the taxpayer.






| **If** | **Then** |
| :-: | :-: |
| The review is free of defects, | Give the employee positive feedback. |
| The review identifies Customer Accuracy defects, | Explain the impact to the taxpayer and the potential impact if the review had been evaluative.<br> Address quality improvement opportunities.<br> Perform two additional non-evaluative reviews for each call or case that identified a Customer Accuracy defect. |
| The review identifies Regulatory Accuracy defects, | Explain the impact to the taxpayer and the potential impact if the review had been evaluative.<br> Address quality improvement opportunities.<br> Perform two additional non-evaluative reviews for each call or case that identified a Regulatory Accuracy defect unless a Customer Accuracy defect already required two additional reviews for that call or case. |
| The review identifies defects other than Customer Accuracy or Regulatory Accuracy defects, | Explain the impact to the taxpayer and the potential impact if the review had been evaluative.<br> Address quality improvement opportunities. |





### Note:



Only complete additional reviews for Customer Accuracy or Regulatory Accuracy defects identified in the required reviews listed in paragraph 2 above. Do not add more additional reviews for defects identified in the additional reviews. **Additional** reviews for the entire Alternative Certification process will not exceed six for telephone applications or 10 for inventory skills.





### Reminder:



When a review identifies any defects, share the review before conducting the next non-evaluative review for certification.

4. If, at any point during the Alternate Certification process, the employee has two or more Alternate Certification reviews with Customer Accuracy or Regulatory Accuracy defect, take the following actions:



1. Provide the employee with counseling documentation. In the documentation, specify the employee must pass certification for the new work assignment.

2. Prior to completing any further reviews, establish and implement an action plan to help the employee demonstrate they can perform the work assignment.


### Note:

If the employee was previously issued counseling documentation during certification, revisit the document to determine if additional help is needed.

5. After sharing all required and applicable additional reviews, see the table below:




| **If** | **Then** |
| :-: | :-: |
| More than 60% of the employee’s Alternate Certification reviews are free of Customer Accuracy and Regulatory Accuracy defects, | The employee passed the certification process. Refer to paragraph 6 below. |
| Sixty percent (60%) or less of the employee’s Alternate Certification reviews are free of Customer Accuracy and Regulatory Accuracy defects, | The employee failed the certification process. Refer to paragraph 7 below. |





### Example:



An employee was not able to pass the standard certification process for telephone Application 020. During Alternate Certification, the CSR received Customer Accuracy defects on two of the required reviews. The manager conducted four additional reviews. All four of the additional reviews were free of defects. Five of the seven (71.43%) reviews conducted for Alternate Certification were free of Customer Accuracy and Regulatory Accuracy defects. The employee passed the certification process.

6. If the employee passed Alternate Certification, certify the employee is eligible to independently perform the assigned work.



1. Notify the RTC and Department Manager the employee passed certification.


       RTCs monitor and report completed training and certification statistics to headquarters staff.


       Following local procedures, coordinate with the RTC and Telephone Support Staff (TSS) to update Skill Assessment/eWFM/WFO to reflect the new assigned work.


       Department Managers will retain a list of employees who passed standard certification, passed alternate certification, or failed certification for one year. This list may be requested during operational reviews.

2. If the employee was trained in multiple separate telephone applications or inventory skills, complete the certification process for each telephone applications or inventory skills. See _IRM 1.4.16.2.7.2_, _Taxpayer Services (TS) Accounts Management Certification Process_.

3. Add or update the CER SharePoint for the employee to receive evaluative reviews from CER. See _IRM 1.4.16.5.4.1_, _Centralized Evaluative Review (CER)_.

4. For paper inventory skills, update the employee’s Correspondence Imaging Inventory (CII), if needed. See _IRM 1.4.16.5.4.1_, _Centralized Evaluative Review (CER)_.


7. If the employee fails the Alternate Certification process, the manager and department manager must determine the next course of action and consult with Labor Relations (LR) staff for guidance, including possible adverse action.




| **If** | **Then** |
| :-: | :-: |
| The certification process was for a newly hired employee, | Refer to Article 30, Section 1B of the National Agreement for possible courses of action.<br> For probationary employees, discuss additional options with LR. |
| The certification process was for an employee skilling up to a new work assignment, not new hire training, | Employees who fail certification **will not** work the new work application assignment.<br> The employee will need to repeat training if training is offered later. If training will not be available, the **Department Manager** must coordinate with the Resource Training Coordinator to determine alternative options.<br> <br>### Note:<br>Employees who already repeated training and failed certification for a specific topic multiple times will not repeat the same training again. |


**1.4.16.2.7.3** **(12-27-2022)**

##### Classroom Training Instructor Review

1. All AM instructors delivering classroom training or virtual training MUST be reviewed by their manager at least once a year.

2. The first line manager of the instructor is responsible for this review.


**1.4.16.3** **(01-01-2014)**

### TOLL-FREE TELEPHONE SERVICE

1. Refer to IRM 1.4.21, _Accounts Management and Compliance Guide for System Administrators/Analysts_, for information and guidelines regarding the telephone environment.

2. JOC monitors toll-free telephone traffic using a centralized model that views all call sites virtually together, which is known as the Enterprise. JOC coordinates the operations of all AM campuses, and it authorizes planning and scheduling for the campuses. JOC oversees the efficiency of all AM functions and programs for each individual campus. The primary objective of the JOC is ensuring the services provided to the customers are fair and consistent at all times.

3. JOC requests real-time changes in telephone staffing based on incoming call demand and overall AM resources. It makes the following requests to the sites:



   - Move telephone assistors from one agent group to another

   - Remove assistors from the telephone to work paper or electronic inventory

   - Assign staff to the telephone


**1.4.16.3.1** **(12-27-2022)**

#### Centralized Contact Center Forecasting and Scheduling (CCCFS) - Telephones

1. CCCFS is utilized by AM HQ staff to ensure the optimum number of staff are available on the telephones and paper programs to enhance customer service to the taxpayers.

2. It is critical that AM Management, Inventory Control Manager, and Systems Staff jointly plan the work assignments for employees based on skills and availability to maximize quantity, quality, and efficiency. The eWFM/WFO skills and work assignments are displayed by telephone application, agent group, and inventory work type.

3. The site must review and update (as needed) the telephone skills and assignments monthly to ensure the eWFM/WFO software reflects the current training and site work assignment preferences for each employee.



   - Current training is reflected in the employee record extra information fields.

   - Current possible work assignments are reflected on the employee record skills.

   - When assigning skills, a priority of 1 – 99 must be associated with each skill. Sites have the flexibility to assign the priority according to their scheduling preferences with the basic methodology that the lower the number, the sooner the employee would be assigned to this work.


4. Additional requirements:



   - Final application readiness must be completed by **December 31, prior to the Filing Season**.

   - CCCFS Skills must be updated **No Later Than (NLT) January 31, during the Filing Season**.

   - New hire employee skills must be input to CCCFS **NLT two weeks**following the conclusion of the OJI period.


### Exception:

For any employees attending application training in January (e.g., returning seasonals, new hire instructors), CCCFS must be updated NLT two weeks after the employee has been determined application ready.

5. When telephone staff group requirements are published, the Systems Staff must review the requirements to ensure they are consistent with the site's workload. The Systems Staff will communicate discrepancies or concerns through their directorate staff to the Headquarters (HQ) Resource Planning and Scheduling (RP&S) staff.

6. During the work assignment phases prior to and during execution, the site must review the current workload priorities and implement them into eWFM/WFO. The site must keep eWFM/WFO current during execution as near to real-time as possible so agent availability can be monitored.

7. Following execution, the site must reconcile tracked eWFM/WFO activities weekly with the reported official time through the use of eWFM/WFO Superstate reports.

8. In addition to the above reconciliations, the site must also ensure the eWFM/WFO data is current through the following monthly reconciliations:



   - Employee Records - Reconcile employee records with current on-roll information Human Resource Reporting.

   - Employee Login IDs - Reconcile login IDs with current assigned ACD extensions.

   - Trial Schedules - Reconcile trial schedules with current tours of duty and work assignments.


9. Additional CCCFS items are referenced in _IRM 1.4.16.4.1_, _Centralized Contact Center Forecasting and Scheduling (CCCFS) - Inventory_. The RP&S staff is committed and available to assist the site with questions or problems regarding CCCFS items.


**1.4.16.3.2** **(12-27-2022)**

#### Unified Contact Center Enterprise (UCCE)

1. UCCE is part of the call center infrastructure performing distribution of taxpayer calls between site and telephone resources (Agents and VRUs).

2. Peripheral Gateways are specialized servers that connect the call center to other call center resources.

3. The Intelligent Call Manager (ICM) routes calls based on UCCE data (specific set of characteristics) to the site with the longest available agent in the appropriate skill group. If no agent is available, the call is queued at the Enterprise level until an agent becomes available and only then is it routed to a site.

4. English Tax Law calls go to Default Screeners; however, Spanish Tax Law calls are routed to Spanish Accounts. The Spanish calls will be worked by the assistor, if skilled or transferred to other application as needed.

5. All Toll-Free telephone data is captured daily and stored in the web-based Enterprise Telephone Data (ETD) Warehouse. ETD stores data for historical use and produces daily, weekly, and ad hoc reports at the national (Executive Level Summary) and site level, including directorate roll-ups of remote sites. Site-level measures are also available on ETD when appropriate.

6. The Aceyus reporting tool provides real-time and historical data at the enterprise and site level.

7. The role of a manager, in the Enterprise environment, is to ensure the right number of people with the right skills are available to answer calls.



### Note:



A frontline manager is required to reskill their agents using the Agent Reskilling Tool (ART) to meet real-time call demand.


**1.4.16.3.3** **(09-26-2023)**

#### Managing Features

1. JOC programs Intelligent Call Manager (ICM) (through scripts that use business rules) for maximum call routing efficiency, based on demand and assistor availability.

2. The UCCE Finesse Supervisor desktop application gives managers access to features such as the ability to:



   - View team information and monitor agent activity and agent telephone states/statuses

   - Logout an agent


   - Send an employee notification/message to an agent on the team

   - Receive visual notification of an emergency event when agents press the ER toolbar button

   - Enroll and access to the Finesse voicemail system


### Note:

For additional information regarding this section, refer to the IRS Cisco Finesse Supervisor Desktop User Guide, which can be found on the Cisco Finesse End User Material page.

**1.4.16.3.4** **(12-17-2018)**

#### Enterprise Level Call Center Announcements and Telephone Scripts

1. All announcements and scripts used on toll-free telephone numbers are controlled by JOC.

2. Announcements are valuable tools to:



1. Inform callers of answering delays

2. Advise of tax law changes

3. Provide information on ordering forms or transcripts

4. Advise callers to visit IRS.gov


**1.4.16.3.5** **(12-10-2020)**

#### Availability and Efficiency

1. As an Accounts Management manager, telephone data is available to assist you in evaluating the service being given to taxpayers and determining the efficiency and availability of site-level staff.

2. Managers and Systems Analysts (SA) must determine on a half-hourly basis by application if staff is available as scheduled. If less than the required number of agents is signed on, an explanation is required per adherence guidelines. For events planned in advance, any projected deficits should be covered first within the directorate; and must be discussed with the HQ Resources, Planning and Scheduling (RP&S) team to ensure appropriate telephone coverage across the Enterprise. For unplanned events, e.g., local inclement weather or traffic issues, the site must contact the JOC Monitoring Room **and** the AM RP&S staff to notify them of the resulting loss of staff.

3. Managers must ensure their employees are signed on to the telephone system and taking calls when scheduled. This reduces shrinkage, which is considered unscheduled time away from normal scheduled activities. Examples of shrinkage include:



   - Extended read and meeting times

   - Tardiness

   - Leaving early

   - Higher than expected attrition for the day (e.g., sick leave)

   - Scheduled breaks not followed

   - Unauthorized breaks

   - Extended breaks or lunch periods

   - Details-out-scheduled at peak periods


4. Managers must perform **a weekly review** of incorrect transfers to identify errors and systemic problems. When errors are identified, the error(s) should be shared with the respective employee(s) for corrective actions. Any systemic abnormalities should be reported to the appropriate Resource, Management, and Training (RMT) staff member.

5. JOC, in collaboration with AM headquarters and site management, makes daily real-time adjustments to AM staffing levels based on actual demand and actual staffing.

6. Managers should use eWorkforce Management (eWFM)/Workforce Optimization (WFO), including Real Time Adherence (RTA), to assist in scheduling to meet staffing requirements.



### Note:



Sites follow the eWFM/WFO and RTA procedures and ensure procedures are in place for required data backups. They are available on the Joint Operations Center website. For AM sites, additional reference material and procedures are posted on the Field SharePoint site.


**1.4.16.3.5.1** **(07-17-2024)**

##### Bad Line/Dropped Calls

1. As an AM Manager, you are responsible for reporting call center telephone problems to your local Systems Analyst (SA) Staff. Telephone problems may include bad line and/or dropped calls.



   - Bad Line calls are defined as calls where the taxpayers cannot be assisted due to audio transmission difficulties in the phone line.

   - Dropped Calls are defined as calls that start normally but disconnect unexpectedly during the conversation.


2. For bad line/dropped call guidelines, see IRM 21.1.1.8.2, _Telephone Troubleshooting Reporting Procedures_. It includes the following procedures for AM telephone employees:



   - Examples/definitions of a bad line call.

   - How to record these calls using the Cisco Finesse desktop application.

   - When and how to notify the manager when receiving these calls.


3. When managers receive email notifications of bad line or dropped/disconnected calls from an employee, refer to the table below:




| **If** | **Then** |
| :-: | :-: |
| The employee sent notice of a bad line or dropped call issue, | Perform triage and assist the employee with addressing any potential system issues (volume, hardware, or microphone use, etc.). See IRM 1.4.21.2.4, _Trouble Reporting Procedures_, for some specific steps for “Bad Line” calls. |
| The manager, or designee, previously attempted to address the issue and cannot resolve it at first level triage, | Contact SA staff via email for assistance in identifying and addressing the cause. |
| The employee continues to report phone issues after the manager and SA staff previously attempted to resolve the phone issue, | Work with SA staff to determine if the employee needs to do one or more of the following until the issue is resolved:<br> <br>   - Return to the office.<br>     <br>   - Switch to a different phone application or alternative work.<br>     <br>   - Be pulled from the telephone work.<br>     <br> The manager will make the final determination. The SA staff may be able to provide information to help the manager make the determination.<br> The manager will take steps to mitigate the impact to customers when an employee is experiencing repeat bad line or dropped calls. |

4. Managers can access disconnected call reports using Aceyus reports. Using Excel filters, managers can verify:



1. How many disconnected calls employees are experiencing.

2. If employees are reporting disconnect trends timely.

3. If employees are misusing the bad line/dropped call procedures.


| **Aceyus Report** | **Purpose** |
| :-: | :-: |
| Report 5480, Bad Call Line | Interval reports |
| Report 5481, Bad Call Line | Daily reports |
| Report 5903, Dropped Call | Real-time (same day) dropped call reports |
| Report 5904, Dropped Call | Historical dropped call reports |

5. If the site receives a Centralized Quality Review System (CQRS) quality error, or an employee receives a quality error from Centralized Evaluative Review (CER), you must review the recorded call and any reported bad line or dropped call information (e.g., Aceyus reports and ETD – Agent Call Detail report) to determine if systemic problems could have contributed to the error.



### Note:



For additional information regarding the types of reports to include for Defect rebuttals, see IRM 1.4.21.2.5.1, _UCCE Call Center Reports_.

6. In the event a report is unavailable, Defect rebuttals must include written confirmation from your site system staff confirming the above reports are unable to generate for the date in question.



### Note:



The information above applies when the issue resulting in the quality error involves a single CSR/workstation **ONLY**. For situations where a site-wide or Enterprise-wide issue occurred (such as one-way audio), the JOC Operations Log for the site/day citing the issue would be sufficient proof of a systemic issue occurring.

7. If the manager or manager designee believe there may be grounds to challenge an error based on phone equipment/failure issues, review the following information before determining if a rebuttal (NQRS review) or reconsideration (CER EQRS review):review the following information before determining if a rebuttal (NQRS review) or reconsideration (CER EQRS review):



1. Listen to the call for factors to support or challenge the error(s).

2. Review ETD - Agent Call Detail report to identify who terminated the call.

3. Review Aceyus Report 5904 to determine if a dropped call report was filed for the specific call.

4. Review Aceyus report 5904 to determine if the employee had repeatedly filed multiple dropped call reports during the day.


### Note:

A rebuttal for an NQRS review is not appropriate and will be deemed frivolous if the employee continued to staff telephone applications after excessive bad line/dropped calls.

8. Refer to the table below for guidance and documentation to challenge a defect after completing the review in paragraph 7 above:




| **If** | **Then** |
| :-: | :-: |
| The review was an NQRS review conducted by CQRS, | Refer to IRM 21.10.1.9.2, _CQRS Defect Rebuttal Procedures - Accounts Management_, and Quality Gram 122 for guidance.<br> Attach following documents when filing Form 14448:<br> <br>   - ETD - Agent Call Detail showing who terminated the call.<br>     <br>   - Aceyus Report 5904 showing the employee’s dropped call reports for the day. |
| The review was an EQRS review conducted by CER, | Refer to _IRM 1.4.16.5.4.1_, _Centralized Evaluative Review (CER)_, and Quality Gram 122 for guidance.<br> If CER requires additional documentation, the CER manager or CER lead will contact the manager or designee submitting the reconsideration. |


**1.4.16.3.5.2** **(12-27-2022)**

##### Average Times/Values to Monitor for Efficiency

1. Use available data to monitor and analyze telephone assistor efficiency. This includes:



   - Agent Idle and Sign-on times

   - Agent Average Handle Time (AHT)

   - Agent Average Talk, Hold and Wrap Time



     ### Note:



     Due to inconsistencies with the VERINT/Wrap calculation, some calls will be missed by quality review coding for WRAP. Until the problem is corrected the reviewer will only review calls with screen capture.


2. "**Idle**" time consists of those times employees are signed on the telephone system, but not in the Available, Ready, Wrap, or Out Call status. Agents must use a reason code when in "Idle" status. See the CSA for "Idle" procedures in Attachment 1, _Idle with Aspect Reason Codes_.

3. The appropriate Reason Codes agents must use when in "Idle" status are as follows:



1. **Temporarily off the Telephone** \- This code indicates the employee will be available for telephone work in a period of time not specified by other reason codes. Examples include:


       \- Waiting for Local Area Network (LAN) connectivity


       \- Individual employee meetings with managers


       \- Counseling including Equal Employment Opportunity (EEO) counselor meetings


       \- NTEU official duties


       \- Form 3081 preparation


       -Single Entry Time Reporting (SETR) input

2. **Inventory, First Available** \- the employee is available for telephone work, if necessary. This means the employee’s work assignment is paper inventory, including related outgoing telephone calls.

3. **Inventory, Second Available** \- the employee will be made available for telephone work only when employees in the Inventory, First Available category, as shown in 3b above, have been utilized and call demand remains high.

4. **Training, Partly Available** \- the employee will not be available during a specified portion of the TOD because of training-related activities. Examples include partial day off-site, on-the-job training (OJT) or instructor preparation.

5. **Read Time** \- the employee will not be available during a specified portion of the Tour of Duty (TOD) because of read time.

6. **Meet Time** \- the employee will not be available during a specified portion of the TOD because of Team meeting time.

7. **Break Time** \- the employee will not be available during a specified portion of the TOD because of a scheduled rest break other than lunch.

8. **Lunch Time** \- the employee will not be available during a specified portion of the TOD because of a scheduled lunch break.

9. **Stress Break Time** \- the employee will not be available as a result of dealing with a stressful situation. Use of this code does not require pre-approval.


4. Managers should refrain from conducting meetings, informal training, group observances, etc. during peak telephone/paper periods/days. For additional information, see _IRM 1.4.16.2.5_, _Read and Meeting Time_.


**1.4.16.3.5.3** **(01-11-2024)**

##### Average Handle Time

1. Average Handle Time (AHT) is the sum of average talk, hold and wrap time and is a data element and determines resources needed in AM to achieve a budget-driven Level of Service (LOS) - LOS is the primary measure used by external stakeholders (Congress) to determine IRS efficiency.

2. Very long talk times affect program goals and increase the number of abandoned calls. It is usually an indicator that additional training may be needed in conversation control.

3. Managers should identify Customer Service Representatives (telephone assistors) who may be using **excessively long or short times** in handling calls. Monitor a few of their calls to identify problems such as:



1. Training deficiency

2. Failing to keep a call brief while maintaining standards of courtesy and full service

3. Placing a call on hold during the research process when it is inappropriate instead of arranging for a call back

4. Answering a large volume of unusually complex questions

5. Failing to provide a complete or accurate response


.



**1.4.16.3.5.4** **(12-27-2022)**

##### Average Wrap Time

1. "Wrap" is a function on the Finesse desktop application that is used by the telephone assistor to finish required work after the call is completed. Auto Available with conditional wrap is the method used by telephone assistors for answering incoming telephone calls. This method is in accordance with the current IRS-NTEU CSA, which is found on the Customer Service Agreement page.

2. An employee using auto available with conditional wrap will immediately go to available status at the end of each call with a taxpayer unless the employee selects the “Wrap” or “Idle” toolbar button prior to the conclusion of the call.

3. Conditional wrap is appropriate in situations where the taxpayer does not wish to stay on the line and case documentation is required. Other situations that may warrant the employee being in conditional wrap are if a case is complex and requires additional time to complete documentation or research, or if there is a need to prepare to take the next call. However, in most instances employees are expected to resolve telephone inquiries (including account adjustments) while the customer is still on the line.

4. Telephone assistors are expected to complete account adjustments while on-line or on-hold with the caller, so use of wrap time should be minimal except in rare instances. For additional information regarding completing on-line account inquiries, see IRM 21.1.3.20(2), _Oral Statement Authority_.



### Note:



If a call prematurely disconnects while assistors are completing account actions, assistors must wait to finish actions for this call after they complete the next incoming call. At that time, the assistors will select “wrap” to complete the account actions. See also the Training Auto Available Lesson Plans for Employee and Manager (revised 07/12/2012) on the Customer Service Agreement page.

5. Wrap Time is a measurement that allows management to determine if telephone assistors are handling calls efficiently, and it assists in determining the amount of time assistors are unavailable for calls.

6. Possible reasons for high percentages of wrap time are:



1. Level of training

2. Extensive research for call backs

3. Excessive conversation among employees

4. Excessive research

5. Completing history items on AMS/IDRS


**1.4.16.3.6** **(12-10-2020)**

#### Unified Contact Center Enterprise (UCCE) - Real Time Reporting

1. Aceyus UCCE- real time reports can be designed to:



1. Display call center activity on demand

2. List agents (telephone assistors) and their current telephone status

3. Display general call information for the application handled by the site or individual.


2. The Aceyus UCCE real time reports can assist Accounts Management managers in the following ways:



1. Gauge telephone traffic demand

2. Choose the most convenient times to monitor or share information with an employee

3. Confirm the number of agents who are ready and/or taking calls to provide a complete picture of staff available to meet customer demand

4. Identify Emergency alerts in the event a telephone assistor presses the EMERGENCY button on the Finesse desktop application.

5. Identify trends of excessive wrap


3. The Aceyus UCCE real-time reports show the number of telephone assistors who are actually at their workstations handling incoming calls. This data, compared to the total number assigned, provides information about the realization of the scheduled staff.


**1.4.16.3.6.1** **(12-06-2019)**

##### Agent Status on Unified Contact Center Enterprise (UCCE) – Real-Time Reports

1. Use Aceyus UCCE real-time reports to observe the telephone assistor's telephone status immediately after the call ends. Managers can determine the status the assistor has selected at the end of the call and the length of time spent in that status. The following configurations may apply:



1. An employee using auto available with conditional wrap will immediately go to available status at the end of each call with a taxpayer unless the employee presses the conditional wrap or idle button prior to the conclusion of the call.

2. If the employee presses the Wrap button during the call, the employee will go into wrap status at the conclusion of the call.

3. If the employee presses the Idle button during the call, the employee will go into idle status at the conclusion of the call and must enter the correct reason code for idle status.


### Note:

For additional information on _Auto Available with Conditional Wrap_, see_IRM 1.4.16.3.5.4_, _Average Wrap Time_.

2. Also, use the Aceyus UCCE real-time reports to indicate if an employee might need further monitoring or action. This may include:



1. Monitoring the end of a call exceeding 20 minutes (or locally established time frame) to determine if the issue is being resolved as expeditiously as possible.

2. Checking with employee to see what activity is creating the need to be off-line in wrap time.

3. Identifying an employee with headsets connected, etc., but not in ready mode to take the next call.


**1.4.16.3.7** **(01-01-2016)**

#### Fluctuating Call Volume

1. Managers should ensure all employees assigned to answer calls are at their workstations taking calls.

2. Managers will be notified by local site System Administrators (SA) or Department Managers if changes are needed in scheduled staffing based on contacts from JOC. This could include adding staff in a specific agent group or taking employees off the telephones to do other work. Employees will be provided a reasonable amount of transition time (e.g., between six (6) and twelve (12) minutes, to move between work assignments, (e.g., paper and telephones). For additional information, see the current IRS-NTEU CSA, which is found on the Customer Service Agreement page.


**1.4.16.3.8** **(09-26-2023)**

#### Outgoing Calls

1. Telephone assistors may need to make outgoing calls to secure additional information to resolve an inquiry.

2. Telephone assistors making outgoing calls from their Finesse desktop application are not counted as part of ready staffing for site level adherence to schedule, nor are they considered in routing calls. Managers should monitor the number of outgoing calls to ensure they are necessary.



### Note:



Cisco phones are for Official Use Only.

3. The wrap time for a telephone assistor for outgoing calls should be appropriate to the type of call.

4. If a telephone assistor needs to make outgoing calls but cannot, contact your local SA for assistance. A UCCE IRWorks ticket may need to be opened by the SA office.

5. If a telephone assistor needs to make outgoing calls on their Finesse desktop application, the telephone assistor will place themselves in the idle state and follow the steps below.



1. Click **Idle**

2. Select a reason code and click **OK**

3. Click the **Dial** pad icon at the top left of the Cisco Finesse desktop

4. Press the desired numbers on the keypad



      ### Note:



      If you are dialing an external number, ensure you enter ‘91’ followed by the number you are dialing

5. Click **Dial** to place the call


### Note:

For additional information regarding this section, refer to the Cisco Finesse Agent or Supervisor Desktop User Manual.

**1.4.16.3.9** **(09-26-2023)**

#### Network Failures/Loss of Finesse Desktop Application

1. In the event of a network failure and/or an agent loses access to their Finesse desktop application, a banner appears at the top of the desktop notifying that the desktop has lost connection to the server. When agent is on an active call during a failover, the call will NOT drop unless there was an issue with the phone connection (i.e., the agent lost internet which impacts Finesse and Jabber).



### Note:



For Additional information regarding this section, refer to the IRS Cisco Finesse Agent Desktop User Guide.


**1.4.16.3.10** **(12-10-2020)**

#### Telephone System Assistance

1. The System Administrator (SA) is a valuable resource person regarding the features of the telephone system. The SA official titles are Customer Service Systems Administrator/Program Analyst (CSSA) and Telephone System Analyst (TSA).

2. Managers must coordinate with their SA on any activity limiting the site's ability to deliver its commitment for scheduled telephone staffing.

3. The SA/TA provides assistance on the following:



01. Information about system operations and call routing

02. Explanation of various telephone reports

03. Identification of data availability and creating reports

04. Assessment of current call site performance

05. Networking information

06. Monitoring procedures

07. Assistance with Enterprise Telephone Database (ETD)

08. Telephone equipment repair

09. Database changes

10. Move employees from one agent group/skill group to another using Agent Reskilling Tool (ART) to meet planned staffing requirements and changes in current demand


**1.4.16.4** **(12-10-2020)**

### CORRESPONDENCE/PAPER WORKLOAD OPERATIONS

1. The correspondence/paper inventory in AM consists of the following case types:



   - Adjustments/Correspondence (including Employee Plans (EP) and Exempt Organization (EO)

   - Taxpayer Relations (TPRs) include:


      CAF (Centralized Authorization File)


      Refund Inquiry


      AMRH (Accounts Maintenance Transcripts)


      Statute


      Technical

   - Identity Theft/Return Preparer Misconduct

   - Large Corporation

   - Reporting Agent File (RAF)

   - Employer Identification Number (EIN) Program (paper inventory only)

   - Preparer Tax Identification Number (PTIN)

   - Special Cases


2. Proper workload management is essential for prompt and accurate account transactions to provide timely responses to customers. Due to the variety and complexity of work, managers must be familiar with the many aspects of managing workloads such as:



1. Establishing controls and priorities

2. Requesting adequate staffing and terminals

3. Conducting routine reviews of employee Automated Age & Multiple Control Listings (AAL & MCL) reviews and providing feedback to correct defects being made by assistors

4. Processing work within established time frames

5. Correcting imbalances in assigned inventory

6. Providing adequate training

7. Being involved in the daily operation of the unit

8. Managing time effectively

9. Using available reports and management tools to monitor the operation


3. There are peak and non-peak periods in each function to be aware of in planning training. They can be anticipated by doing the following:



   - Looking at current schedules and work plans

   - Checking historical data

   - Getting updated information from the department managers and the Systems Analyst staff


4. The Site Planning and Analysis Staff in conjunction with Operations at each site will plan the following based on work schedules:



1. Cross-train employees as needed (with input from the Functional Training Coordinators (FTC) and Headquarters Training and Resource Planning and Scheduling teams.)

2. Recall seasonal employees in time to provide refresher training

3. Recruit and train additional employees if necessary (with input from the FTC)

4. Survey other areas for employees available for details


**1.4.16.4.1** **(12-27-2022)**

#### Centralized Contact Center Forecasting and Scheduling (CCCFS) - Inventory

1. CCCFS is utilized by AM HQ staff to ensure the optimum number of staff are available on the telephones and paper programs to enhance customer service to the taxpayers.

2. It is critical that the Inventory Control Manager (ICM), Systems Staff, and management jointly plan the work assignments for employees based on skills and availability to maximize quantity, quality, and efficiency. The inventory skills and work assignments are displayed by program.

3. The site must review the inventory skills and assignments monthly and input all needed update(s) monthly, to ensure the eWorkforce Management (eWFM)/Workforce Optimization (WFO) software reflects the current on roll staff, tour of duty; employee Automatic Call Distribution (ACD) extensions used for direct work, training, and work assignment preferences. This includes data for the following employee types: CSR; TSR; and TLS.



   - Current training is reflected in the employee record extra information fields.

   - Current possible work assignments are reflected on the employee record skills.

   - When assigning skills, a priority of 1 – 99 must be associated with each skill. Sites have the flexibility to assign the priority according to their scheduling preferences with the basic methodology that the lower the number, the sooner the employee would be assigned to this work.


4. Additional requirements:



   - Final program readiness must be completed by **December 31, 2022**.

   - CCCFS skills must be updated No Later Than (NLT) **January 31, 2023**.

   - New hire employee skills must be input to CCCFS **NLT two weeks** following the conclusion of the On-the-Job Instruction (OJI) period.

   - Send waiver to CER for SharePoint programming.


### Exception:

For any employees attending program training in January (e.g., returning seasonals, new hire instructors), CCCFS must be updated NLT 30 days after the employee has been determined program ready.

5. During the work assignment phases prior to and during execution, the ICMs will review the current inventory workload priorities and communicate work assignment strategies to management and the Systems Staff for implementation into eWFM/WFO.

6. Following execution, the site must reconcile tracked inventory work weekly in eWFM/WFO with outside reporting and notify management of discrepancies. This reconciliation can be performed using eWFM/WFO Superstate reports.

7. Additional CCCFS items are referenced in _IRM 1.4.16.3.1_, _Centralized Contact Center Forecasting and Scheduling (CCCFS) - Telephones._ The RP&S staff is committed and available to assist the site with questions or problems regarding CCCFS issues.


**1.4.16.4.2** **(12-27-2022)**

#### Assigning Paper Inventory

1. The majority of paper inventory is sent to the Correspondence Imaging Inventory (CII), which captures images of correspondence from taxpayers. Correspondence includes letters, returned notices, notice responses, and standard forms which are scanned and electronically assigned on a daily basis by routing to a generic employee number for each site.

2. The cases are then reassigned to specific AM employees, on a daily basis, and according to the established parameters.

3. After work is completed on a case, including any quality review processes, the images are stored following retention guidelines, and are accessible by other employees with CII access should the need arise.

4. CII automatically keeps each employee's inventory in received date order. These cases can be re-assigned to other employees to ensure all old age and rollover cases are completed in a timely fashion.



### Caution:



Cases in pending or suspended status should be reviewed periodically to determine if they can be processed or need to be reassigned.

5. CII inputs Command Code (CC) STAUP on balance due accounts and sends an interim letter to the taxpayer when cases are 25 days old.


**1.4.16.4.3** **(03-17-2023)**

#### Managing Inventory

01. Correspondence received from a taxpayer or a third-party representative may be solicited or unsolicited.

02. For additional information, see IRM 21.3.3, _Incoming and Outgoing Correspondence/Letters._ A significant portion of AM inventory also includes amended returns.

03. Although reduction in incoming correspondence is an AM goal, correspondence will never be eliminated as some customers prefer this method of contact.

04. IDRS Controls are established for correspondence either by an automated or manual system, or combination thereof.

05. Sites are expected to meet scheduled closure rates and inventory levels as well as established aged case percentages for all correspondence and amended returns.

06. Accounts Management in the campus locations resolve customer inquiries such as:



    - Amended returns

    - Claims

    - Correspondence

    - Carryback claims

    - Identity Theft


07. The resolutions include analyzing, researching, and making adjustments to customer accounts in IDRS. It may include contacting the customer by telephone or through written correspondence.

08. Certain guidelines for managing inventories are provided in IRM 21.5.1, _General Adjustments_.



    ### Note:



    See IRM 21.5.1.5.1(17), _CII General Guidelines_, for inventory management guidelines regarding the "Close As MISC" button on CII, which allows the user to close secondary case(s) by not counting them as a closure in CII reporting when there are multiple open CII cases on a TIN. "Close As MISC" cases will be counted as a transfer out action instead of a closed case, which enables more accurate inventory and closure reporting. Managers **MUST**ensure employees are utilizing the "Close As MISC" button on CII when working cases. See _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Control Report_.

09. Distribute work in IRS received date order and ensure your employees are aware of aged receipts. Adhere to the 14-day IDRS control requirements, as well as Action 61/Policy Statement P-21-3, Timeliness and Quality Taxpayer Correspondence, located in IRM 1.2.1.13.3. See IRM 21.3.3.4.2, _Policy Statement P-21-3 Procedures._

10. Some indicators of potential overage problems include:



    1. Receipts exceed closures, or number of days in inventory exceeds 14 days

    2. Percentage of aged new receipts exceeds the enterprise goal of total receipts

    3. Percent of missing returns on duplicate filing cases exceeds 20 percent


### Reminder:

Each campus must track Spanish language written inquiries received and processed in Accounts Management. This includes Adjustments and Taxpayer Relations correspondence, and e–4442 _Account Referrals_. Use a 7 for the 5th digit of the Program Code. **Also**, use Category Code "**SPAC**" (Spanish Adjustments Correspondence) to control incoming Spanish language Adjustment correspondence, regardless of whether the response is in Spanish or English.

11. Re-assign an employee's inventory in CII/AMS/IDRS to another employee for the following situations:



    - Employee leaves permanently

    - Employee is placed in Non-Work Status (NWS)

    - Employee is on extended detail or special assignment or will be out of the unit 14 calendar days or more


**1.4.16.4.4** **(01-11-2024)**

#### Physical Inventory Counts/Reconciliation - Quarterly Requirements

1. Work Planning and Control (WP&C) procedures require a physical inventory count/reconciliation of all AM inventory, which must be completed prior to the end of each quarter. For additional information on this requirement, see IRM 3.30.19.2.7, _Quarter, Annual, and Basic Cut Over Procedures_.



### Note:



It is **strongly** recommended you conduct **monthly reconciliations** in addition to the quarterly physical inventory requirement to ensure AMIR and WP&C volumes match.

2. Each campus Inventory Control Manager (ICM) or the designated campus Planning and Analysis (P&A) analyst must ensure the required WP&C corrections are input and timely submitted to the campus Report Units and a confirmation e-mail is sent (by the due dates shown in paragraph (3) below) to Manager, Reports, Analysis, and Data (RAD). The e-mail **must** include the following:



   - Statement that the validation/reconciliation was performed.

   - Details of any adjustment actions.

   - Reconciliation Template provided by RAD (attached to the e-mail).


3. The validation due dates for the physical inventory counts are:



   - Early December

   - Early March

   - Early June

   - Early September


### Note:

For CII and Account Management Services (AMS) inventories, the review will be performed by reconciling current inventory with IDRS CCA reports. For Adjustments cases on CII, the CII versus AAL tool will be used.

**1.4.16.4.5** **(12-10-2020)**

#### Quarterly Statute Reporting

1. Each AM campus must submit a quarterly Statute Awareness Program Report electronically to HQ Policy & Procedures BMF (PPB) Specialty Accounts (SA) Statute Analyst by the 15th day of the month following the close of the quarter in accordance with IRM 25.6.1.4.2, _The Statute Awareness Program_.


**1.4.16.4.6** **(01-02-2013)**

#### AMS Reporting - Accounts Maintenance Research Hold (AMRH), Refund Inquiry and Statute Programs

1. AMS receipts should be validated weekly by comparing available data from the Servicewide Notice Information Program to volumes received in AMS.

2. If significant discrepancies are identified, this could be an indication of a systemic problem. Please contact the PPM Analyst responsible for the specific program (AMRH, Statute or Refund Inquiry) to report the issue.


**1.4.16.4.7** **(12-27-2022)**

#### Managing Referral Inventory

1. Distribute work by IRS received date order and ensure employees are aware of the following aging criteria:



   - Account referrals - 30 days

   - Technical referrals - 15 days


2. Ensure all employees are profiled in AMS to receive the appropriate type of referral inventory.

3. Manager or manager's designee must review the referral within 3 business days from the date the referral was initially created or resubmitted for review. Managers are also responsible to ensure the initiating employee has taken action on a rejected referral within 2 business days of the case being rejected. For additional information, see IRM 21.3.5.4.2.1.1, _Preparing an e-4442/4442_.

4. Managers must analyze new receipts to determine age, mis-routed cases, trends, etc.

5. Re-assign an employee's inventory in CII/AMS/IDRS to another employee within 14 calendar days in the following situations:



   - Employee leaves permanently

   - Employee is placed in Non-Work Status (NWS)

   - Employee is on extended detail or special assignment or will be out of the unit 14 calendar days or more


**1.4.16.4.7.1** **(01-01-2015)**

##### Referral Inventory Reporting Requirements

1. All written referral work, whether worked within your operations or transferred out, is subject to the inventory reporting requirements monitored through AMS. Use AMS reports to monitor the volume of receipts and closures, overage, and inventory of all written referral work. More information regarding AMS is on the AMS End User Support website.

2. Telephone inquiries **not resolved within the same business day** are written as referrals and worked as paper inventory.


**1.4.16.4.7.2** **(12-06-2019)**

##### Referral Coordinators

1. Although it is an important objective of Accounts Management to resolve as many issues as possible on-line, it is not always possible for an assistor to do this. Some instances include:



1. The assistor needs additional information to resolve a case

2. The training level of the employee does not permit on-line resolution

3. IDRS real time and/or Corporate Files On-Line (CFOL) Command Codes are unavailable


2. Each site must designate an Erroneous Referral Coordinator who will:



1. Report and return erroneous, incomplete, mis-routed, or late referrals and

2. Work to eliminate erroneous referrals


3. For referral and resolution procedures regarding erroneous referrals, refer to the Form 4442 Erroneous Referral Coordinators page listed in SERP under the Who/Where tab.


**1.4.16.4.7.3** **(12-27-2022)**

##### Transferring Written Referrals

1. All cases received in Accounts Management are worked in that operation unless required to be referred in a Chapter/Section of IRM 21, _Customer Account Services_ or IRM 25.23, _Identity Protection and Victim Assistance_.

2. When a telephone inquiry is referred to another site or function, the following information MUST be included on the Electronic Form 4442 (e-4442), _Inquiry Referral_:



   - Full name and ID Number

   - Team or Stop Number

   - Site Location of the assistor making the referral

   - IRM or the IRM Procedural Update (IPU) reference authorizing the referral

   - Detailed explanation of the issues involved and research results


### Note:

For additional information on completing e-4442 see IRM 21.3.5, _Taxpayer Inquiry Referrals Form 4442_.

3. Account Management Services routes all e-4442 to a managerial review queue where the referrals are held pending a 100 percent review. Managers/Referral Coordinators have access to the review queue. Referrals must be reviewed by the manager or manager's designee within 3 business days from the date the referral was initially created or resubmitted for review. See IRM 21.3.5.4.2.1.1(6), _Preparing an e-4442/4442_.



### Note:



Managers must profile users in the AMS database to receive specific types of referrals. This action is necessary to ensure employees have access to the workload. Refer to the e-4442 Manager's Guide on the AMS End User Support website.

4. Frontline Managers **must** ensure the following:



   - Referrals in their site’s queue or assigned to their employees are resolved timely in accordance with IRM 21.3.5.4.6, _Resolving Referrals._



     ### Note:



     Spanish referrals may need to be resolved in the bilingual sites.


**1.4.16.4.8** **(07-17-2024)**

#### Managing Inventory Timeliness and Quality

1. Ensure employees (when applicable) are familiar with the guidelines for all written communications in IRM 21.3.3, _Incoming and Outgoing Correspondence/Letters._ Use the following response time frame guidelines:




| IF | THEN Respond Within |
| :-: | :-: |
| Account Inquiry | 30 calendar days of the earliest "IRS received date" |
| Technical "tax law" Inquiry | 15 business days of the "IRS received date" |

2. In general, any case (inquiry) not resolved within 45 days (30 days for referrals) is considered overage.



### Note:



While the above response times are mandated for Accounts Management, encourage your employees to make every effort to provide quality responses in the following shorter time frames:






| IF | THEN |
| :-: | :-: |
| Account referral | 5 days |
| Technical referral | 2 days |
| Correspondence | 20 days |

3. A quality response is an accurate and professional communication, which, based on information provided, resolves the customer's issue(s), requests additional information from the customer, or notifies the customer that we have requested information from outside IRS. It is the responsibility of the manager to ensure the professionalism and accuracy of their employees' work.

4. Managers must carefully monitor the age of the correspondence inventory.

5. Correspondence must be controlled within 14 days (if not resolved) and management must monitor the inventory to ensure that the 14-day control requirement is met.


**1.4.16.4.8.1** **(12-10-2020)**

##### Inventory Reporting Requirements

1. Establish controls of written inventory per IRM 21.5.1, _General Adjustments_, or IRM 21.3.5, _Taxpayer Inquiry Referrals Form 4442_.

2. Site P&A Analysts must report inventories of the following case types on the Accounts Management Inventory Report (AMIR) for **both** campuses and remotes:



   - Adjustments/Correspondence (including Employee Plans (EP); Exempt Organization (EO); Affordable Care Act (ACA), etc.)

   - Taxpayer Relations

   - Refunds

   - Special Cases

   - Technical

   - Statute

   - Centralized Authorization File (CAF)

   - Large Corporation

   - Reporting Agent File (RAF)

   - Accounts Maintenance (AMRH)

   - Employer Identification Number (EIN) Program (paper inventory only)

   - Preparer Tax Identification Number (PTIN)

   - Identity Theft

   - International


3. Refer to IRM 3.30.124.6.1, _Accounts Management Inventory Report (AMIR)_, for reporting categories.

4. Use the Case Control Activity (CCA) 4242 Reports to report Referral inventory numbers.


**1.4.16.4.9** **(12-27-2022)**

#### Statute Program

1. Due to the critical nature of Barred Statutes, each AM campus must have an effective Statute Awareness Program. Briefings must be conducted by the Statute Unit throughout the year to promote actions to prevent barred assessments.

2. Weekly managerial reviews and Statute Days are required to identify Assessment Statute Expiration Dates within the Statute inventory, CII, and incoming receipts. See IRM 25.6.1.4, _Introduction Procedures_.

3. Statute cases must be reviewed and stamped by Statute employees prior to CII input to create a permanent record on claims cleared by Statute.

4. All campuses must utilize Statute approved stamps. Cases transferred to other sites based on Enterprise Management of Inventory (EMI) must be reviewed for imminent statute prior to transfer. Sites will not enter into agreements with other functions to provide Statute support inconsistent with the IRM 25.6, _Statute of Limitations_ unless given specific HQ approval. This includes, but is not limited to, the Statute Clearance/Prompt Assessment processes.

5. Whenever a barred assessment is identified, the AM Statute Function will follow the prescribed timeframes in IRM 25.6.1.13.2, _Barred Assessment Procedures for Taxpayer Services Campuses_.

6. Each AM campus must submit a quarterly Statute Awareness Program Report electronically to HQ Process and Policy & Procedures BMF (PPB) Specialty Accounts (SA) Statute Analyst by the 15th day of the month following the close of the quarter in accordance with IRM 25.6.1.4.2, _The Statute Awareness Program_.


**1.4.16.4.10** **(07-17-2024)**

#### Manual Refunds – Training and Monitoring Requirements

1. An IRS priority is completion of the Tax Refund Disbursements Corrective Action Plan pertaining to Manual Refunds. AM plays a critical role in this plan as stewards of a large percentage of manual refund adjustments.

2. Employees **MUST** complete the following manual refund courses via ITM **annually**:




| **If the employee** | **And** | **Then the employee** |
| :-: | :-: | :-: |
| Initiates, reviews, signs and/or monitors manual refunds and **HAS NOT** previously completed **ITM Course 30914,**_**Manual Refunds**_ |  | **MUST** complete **ITM Course 30914, _Manual Refunds._** |
| Initiates, reviews, and/or signs but does not monitor manual refunds | Has completed ITM Course 30914, _Manual Refunds_, previously | Must complete **ITM Course 30914a, _Manual Refunds Recertification._** |





### Note:



All campuses are required to certify with the Headquarters Manual Refund Analyst in PPM:I that the employee completed the required training.

3. Each Quarter, the Manual Refund IRM author will send out a report to the Points of Contact (POC) listing all employees who are profiled with Command Codes (CC) RFUND, REFAP, and RSTRKM. The report must be reviewed for accuracy and the POCs must ensure employees that require the CCs have completed the required Manual Refund Training in Integrated Talent Management (ITM) and remove the CCs from employees’ profiles if they are no longer needed. If an employee is listed as not having completed the proper training on the following quarter’s report, they will be highlighted in yellow and a note will be added advising the POC to either reply with a copy of the training certificate or a copy of the employee’s CC SFDISP screen showing the CC has been removed.

4. The Manual Refund tool is an Integrated Automation Technologies (IAT) tool and the use of the IAT tools is mandated by IRM 21.2.2-2, _Accounts Management Mandated IAT Tools_.

5. All manual refunds must be monitored on a daily basis by HQ Analysts utilizing the Robotics Processing Automation (RPA) bot, which incorporated the EMT/Case Monitoring IAT tool. (This is done to ensure a duplicate refund condition has not occurred.)

6. HQ Analysts are required to verify each day that all manual refunds were monitored, and to document their verification by completing the EMT RPA Reconciliation Log.


**1.4.16.4.11** **(01-02-2013)**

#### Integrated Automation Technologies (IAT) Tools

1. To improve productivity, consistency, and quality, AM managers must continue to emphasize the use of the available IAT Tools.

2. All AM employees will adhere to the mandatory use of IAT tools as defined in IRM 21.2.2-2, _Accounts Management Mandatory IAT Tools_.


**1.4.16.4.12** **(01-01-2016)**

#### Centralized Authorization File (CAF)

1. AM continues to optimize the timeframe for processing CAF submissions.

2. Inventory will be handled in accordance with IRM 21.3.7, _Processing Third Party Authorizations onto the Centralized Authorization File (CAF)_. Sites must ensure that revocations and deletions are worked timely to prevent unauthorized disclosures.


**1.4.16.4.13** **(12-10-2020)**

#### Campus Support

1. Campus support plays a key role in program delivery. Campus Support functions must adhere to the guidelines outlined in IRM 21.1.7, _Campus Support_, with special focus on payment processing. See IRM 21.1.7.9, _Payments._

2. All AM Frontline Managers or designated representatives must validate that IDRS command code profiles are restricted for Form 809, _Receipt for Payment of Taxes_, book users and employees processing payments through Remittance Strategy for Paper Check Conversion (RS-PCC) as required in IRM 21.1.7.4, _Privacy and Security Responsibilities_.

3. Campus Support began evaluative reviews effective November 2017. Managers must use the approved Embedded Quality Review System (EQRS) Data Collection Instrument (DCI) for the AM Clerical – Campus Support Specialized Product Review Group (SPRG). Managers will conduct a minimum of two evaluative reviews (live reviews)**per** month for each employee.


**1.4.16.4.14** **(12-06-2019)**

#### Unpostable Cases

1. Unpostable cases are those transactions that cannot post to the Master File and are corrections of previously processed cases. Therefore, it is critical that all Unpostable cases are worked within seven business days of receipt. See IRM 21.5.5.2, _What Is An Unpostable_, and IRM 21.3.7.8.13, _CAF Unpostables_.


**1.4.16.5** **(12-27-2022)**

### MONITORING AND REVIEWS

01. Telephone monitoring and work reviews are performed for the following reasons:



    - To make an objective assessment of an employee's performance on an ongoing basis and to ensure that adequate information is available for mid-year and annual appraisals

    - To protect the rights of customers

    - To identify error trends and training needs


02. Centralized Evaluative Review (CER) quality reviewers **must** conduct the following types of reviews:



    - Telephone monitoring through Verint

    - Correspondence reviews through Correspondence Imaging Inventory (CII)


03. All Accounts Management site managers **must** conduct the following types of reviews:



    - Inventory Management using the CCA 4243, _IDRS Automated Age Listing (AAL)_ and CCA 4244, _IDRS Multiple Case Control Listing_.



      ### Note:



      For additional information, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_; _IRM 1.4.16.5.6.1_, _CCA 4243 - IDRS Overage Report_; and _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Report_.





      ### Note:



      Managers **MUST**ensure employees are utilizing the "Close As MISC" button on CII when working cases. For additional information regarding the use of this button on CII, see _IRM 1.4.16.5.6.2_(5), _CCA 4244 - IDRS Multiple Case Control Report,_ and IRM 21.5.1.5.1(17), _CII General Guidelines_.

    - IDRS (Inventory and Security Reviews).



      ### Note:



      **IDRS Online Reports Services (IORS)** \- Managers must access the IDRS Online Reports Services (IORS) system at IORS on a weekly and monthly basis to perform required electronic security reviews for employees with access to the IDRS system.

    - Non-evaluative reviews.

    - Clerical reviews (i.e., Form 3210, _Document Transmittal_, acknowledgement and follow-up, mail receipt and distribution, etc.).


04. During the Campus Support CII scanning reviews, managers **must** review the CII scanning activities to ensure quality control alerts are not being overridden and scanned document images are clear and legible.



    - **Quality Control Alerts** \- The CII scanners provide a quality control alert to Campus Support employees when the number of cases identified on the batch sheet does not equal the number of cases identified during scanning. Further analysis maybe necessary if the scanner operator cannot readily identify the problem. It is crucial that these quality control alerts are not overridden without effectively resolving the error identified. Managers **must** ensure these quality control alerts are not overridden without effectively resolving the error identified by routinely conducting reviews of the scanning activities. Refer to IRM 3.13.6, **Submission Processing Image Control Team (ICT) Correspondence Imaging Scanning** for complete ICT instructions.

    - **Scanned Document Images** \- Campus Support employees are required to review the scanned images of each document to verify proper scanning. If the document is difficult to read and illegible, **"ODU" (Original Document Unreadable)** is notated on the document. Managers **MUST** also perform monthly reviews to verify the quality of the scanned images. This verification should include comparing the original document to the scanned image to ensure legibility and the presence of "ODU" if documents are not clear and legible.


05. The case reviews that AM managers must conduct involve the following:



    - Reviews of closed cases for both accuracy and productivity to determine if work is being closed in an efficient and effective manner. Managers must conduct reviews to ensure timely follow up and IDRS activity code update on cases.

    - Workload reviews to assess whether the amount of time being spent is commensurate with the complexity and type of work.

    - Reviews of cases currently in process to ensure that inventory is being closed according to received date and that cases are not unnecessarily suspended.


06. Managers are required to conduct periodic, random sample reviews of outgoing Forms 3210 to:



    1. Ensure the contents of the outgoing document package are accurately recorded.

    2. Ensure no unauthorized disclosure of documents and information.


07. Refund Inquiry Unit /Clerical Unit managers must conduct periodic, random reviews of incoming/outgoing Form 3210 to ensure checks are accurately added to the Returned Refund Check System (RRCS) and reconciled when returned to Bureau of Fiscal Services (BFS). Managers are also required to store all unprocessed returned refund checks in a locked cabinet/drawer at the end of each day. Managers are required to conduct a monthly review of incoming and outgoing Forms 3210 as follows:




    | **Incoming/Outgoing Form 3210** | **Number of Reviews** |
    | --- | --- |
    | Incoming from Receipt and Control or other area | Review 5-10 refunds on one Form 3210 per month |
    | Outgoing to BFS or other area | Review 5 – 10 refunds on 1-2 Form 3210 per month |
    | Incoming from BFS | Review 5-10 refunds on 1-2 Form 3210 per month to confirm credit posted to IDRS. (Credit can take up to 2 weeks to post.) |





    ### Note:



    Managers are required to complete Form 3210 Managerial Review Requirements Refund Inquiry Team monthly. Managers must highlight reviewed refunds, initial, and date in the bottom left corner of form(s) reviewed. Once a review is completed, attach a copy of the reviewed Form 3210 to the Form 3210 Managerial Review Requirements Refund Inquiry Team and maintain it in the Form 3210 record book or in a separate file.





    ### Note:



    Refer to Document 12990, IRS Records Control Schedules (RCS) 29, Item 91 for Form 3210, Document Transmittal, 1-year retention and disposition requirements.

08. All required management reviews must be documented in writing and readily accessible.

09. Focus performance reviews on effective case and call resolution according to IRM guidelines. Emphasize the importance of quality service as well as the efficiency of case work and telephone calls. For telephone calls, managers should determine whether the handle time is appropriate to the call reviewed, considering hold time, wrap time, and talk time. Calls should also be reviewed to assess professionalism.



    ### Note:



    The CER quality reviewers are not required to sign CER reviews, but reviews are required to be signed by managers and employees.

10. Whenever possible, include a specific reference to the lowest level, (e.g., IRM subsection number, Transfer Guide code number) for performance feedback/documentation to ensure employees are aware of the procedure not being followed.



    ### Note:



    This identifies areas that may need further IRM clarification and training deficiencies.

11. Set the allocation in the CER SharePoint so the employee receives a balance of phone and paper reviews relative to an employee's work assignments. When necessary, conduct side-by-side non-evaluative reviews for skill development.

12. CER quality reviewers must perform four (4) evaluative reviews monthly for each employee who is certified on CII correspondence and toll-free phones. Reviews are prorated for employees on extended leave, special projects, etc. The manager must determine the monthly allocation of review per program for each employee based on the programs they will be working. The CER review team will also be responsible to complete additional reviews for employees on Performance Improvement Plans or Action Plans.

13. All performance recording described in the following subsections must meet the criteria for evaluative material. The criteria were established by the 2022 National Agreement between National Treasury Employees Union (NTEU) and management.


**1.4.16.5.1** **(05-26-2023)**

#### Tracking Monitoring and Reviews

1. Managers must maintain a flexible schedule listing all employees in the work group and show the completed evaluative reviews (including CER reviews), telephone monitoring, inventory monitoring, and other review activities each month. Use the following guidelines:



1. Indicate which sessions are evaluative and non-evaluative.

2. Notate sessions reviewed through Verint.

3. Notate feedback or follow-up actions discussed with the employee.

4. Do not schedule the employee's review the same time/day of each month.

5. If the required number of monitored calls or inventory are not completed, notate the reason why. This is a separate action from submitting/filing any required evaluative review waivers.


2. Managers must retain and share the schedules with their department managers. The schedules are retained until completion of operational reviews.


**1.4.16.5.2** **(12-13-2024)**

#### Feedback and Follow-Up

1. Monitoring and review results reveal employees’ strengths and weaknesses. Managers provide feedback to reinforce positive aspects and address quality improvement opportunities. Managers will provide feedback on every review, including non-evaluative reviews and National Quality Reviews.

2. Managers will provide feedback to help the employee improve quality during the monitoring/review process. Feedback steps include, but are not limited to:



   - Identify the incorrect action or behavior the employee demonstrated.

   - Identify the correct action or behavior the employee should have demonstrated.

   - Identify the resources available to the employee to improve future performance.


3. Do not use National Quality Reviews from the National Quality Review System (NQRS) to evaluate an employee’s performance. National Quality Review data identifies trends, problem areas, and a site’s overall quality. However, NQRS reviews may identify feedback opportunities.

4. Managers are responsible for ensuring that corrective action is taken on National Quality Reviews and Evaluative Quality Reviews identified with the word “Flash” or “Corrective Action Required” in the Feedback Summary Remarks section of EQRS or NQRS DCIs. For additional information, see IRM 21.10.1.8.7.1, _EQRS Remarks Fields_, or IRM 21.10.1.8.7.2, **NQRS Remarks Fields**.

5. Additional resources for providing feedback and follow-up:



   - _IRM 1.4.16.5.4.4_, _Feedback and Follow-up_.

   - _IRM 1.4.16.5.8_, _Non-Evaluative or Coaching Reviews_.


**1.4.16.5.3** **(03-17-2023)**

#### Telephone Monitoring

1. Telephone monitoring is the most important review of a telephone call site. When monitoring telephone calls, managers and CER quality reviewers can determine whether the employee:



1. Addressed disclosure issues.

2. Treated the customer with courtesy, fairness, and respect.

3. Followed the Interactive Tax Law Assistant (ITLA). See paragraph (3) below.

4. Researched reference material accurately.

5. Followed AMS; Integrated Automation Technologies Tools (IAT); Technical Communication Documents (TCD); or IRM 21 Job Aids.

6. Resolved the case per IRM guidelines.

7. Provided an accurate answer.

8. Applied appropriate communication skills.



      ### Note:



      Communication skills and use of hold guidelines are outlined in IRM 21.1.1.4, _Communication Skills_, and IRM 21 Job Aids.





      ### Note:



      See Paragraph (3), below regarding use of inappropriate language by employees.

9. Conducted a concise successful interview.


2. Rude remarks or disrespectful behavior cannot be tolerated when communicating with the taxpayer or in the workplace. Recorded conversations of inappropriate language by telephone employees may be available to the public under the Freedom of Information Act (FOIA). Recorded instances of rude, inappropriate language or disrespectful behavior **during the conversation with taxpayer or while taxpayer is on hold** will be handled as follows:



   - The CQRS reviewer will review the recorded contact and code the DCI by applying the appropriate 800 series attributes under the Professionalism Measure. The DCI is not coded under the Customer Accuracy Measure; therefore, Attribute 715 does not apply.

   - The reviewer will notify the Process Improvement/Customer Accuracy (PICA) Manager of the issue via e-mail with a courtesy copy to the Chief, AM Operations Support (AMOS). The PICA Manager will contact the appropriate site Planning and Analysis Chief.



     ### Note:



     Managers should see the following references, which include guidelines that officially support their conversation with employees:


     IRM 21.1.1.7, _Contact Recording_, paragraph (2) states: "Incoming calls are answered with an additional announcement that states: Your call may be monitored or recorded for quality purposes."




     Document 7017, _Label for Telephones Subject to Monitoring/Recording._ This document (label on the CISCO Phone X) states: "This telephone is subject to monitoring/recording for the purpose of spot-checking employee courtesy and accuracy of information."


3. The use of the ITLA is mandatory by AM telephone assistors when responding to a taxpayer's question on any of the technical tax law topics identified to be "in-scope" topics. The tax law topics considered "in-scope" require the use of ITLA.

4. All telephones subject to monitoring must be properly labeled so employees know that calls may be recorded/monitored. Calls are recorded via the Verint system.


**1.4.16.5.3.1** **(12-17-2018)**

##### Telephone Monitoring

1. Contact Recording is the preferred method of telephone monitoring.

2. Managers should contact their system administrator for the appropriate telephone number and passwords or if they have difficulty monitoring remotely.

3. Double plugging to review telephone calls may be performed for training purposes only and is non-evaluative.


**1.4.16.5.3.2** **(12-27-2022)**

##### Contact Recording

1. Verint is an automated quality monitoring system. It provides an "instant replay" of employee and taxpayer interaction. Recordings are stored by employee Agent number.

2. The automated system captures voice and in a certain sample of cases, on-screen computer activity for later retrieval and review.

3. Verint recordings are used for performance/managerial monitoring purposes only and are normally erased within 60 days.



### Note:



Management may use the Selective Retention feature within Verint to retain a recorded contact longer than the default 60 days. Refer to IRM 1.4.21.2.1.10, _Selective Retention in Verint 15.1_, for more information regarding this type of request.

4. All calls are recorded in their entirety within Verint. Continue to use monitoring sheets for your written record for evaluative purposes.

5. Follow the time frames in the 2022 IRS/NTEU National Agreement for sharing performance feedback.

6. A separate sample of recorded calls is selected for quality review purposes and is not tracked to individual employees for evaluative purposes.



### Note:



Management may request that a recorded contact be downloaded. Refer to IRM 1.4.21.2.1.5, _Managerial Requests_, for more information regarding this type of request.

7. For additional information regarding Verint, see IRM 21.1.1.8, _Contact Recording._


**1.4.16.5.3.3** **(12-06-2019)**

##### Access to Recorded Calls

1. Employees may request access to a recorded call used for evaluative purposes and may listen to the call on official time.

2. At an employee's request, the employee and/or employee's representative and the manager will meet within two (2) business days to listen to and discuss a recorded call together. The employee's representative; however, must request and receive permission under (IRC 6103(I)(4)(A)) to listen to calls involving return information.


**1.4.16.5.4** **(05-26-2023)**

#### Evaluative Reviews

1. Documented monitoring is a part of the evaluation process. The 2022 National Agreement governs such recordings. When completing reviews, ensure they are:



   - Conducted according to department or other requirements.

   - Completed by a manager, an individual in an official acting manager capacity, or a Centralized Evaluative Review (CER) quality reviewer.

   - Input to the Embedded Quality Review System (EQRS) using the approved Data Collection Instrument (DCI) for each applicable Specialized Product Review Group (SPRG).

   - Shared in a timely manner as required by the 2022 National Agreement.


### Note:

EQRS is a standardized data repository with trend analysis capabilities and reporting capabilities to use for employee evaluations.

### Note:

Technical Leads may complete supplemental evaluative reviews using EQRS; however, managers must share the review. The lead must sign the documentation as the reviewer and the manager must sign the document prior to sharing the review.

2. Manager review narratives must include the following:



   - Details of the employee’s actions taken, or not taken, to support the assessment.

   - Identify how the actions relate to the employee’s Critical Job Elements (CJE). EQRS automatically identifies the CJE for each attribute coded for the review.

   - Examples of the actions the employee could have taken to improve performance.

   - See IRM 21.10.1.8.7, _EQRS/NQRS Remarks Section_, and IRM 21.10.1.8.7.1, _EQRS Remarks Fields_, for additional guidance for narratives entered in EQRS.


3. When conducting a live review, do not interrupt a call unless the employee is:



   - Advising the taxpayer/caller incorrectly.

   - Providing discourteous service.

   - Unable to answer the question.

   - Threatened by a caller.


**1.4.16.5.4.1** **(02-26-2026)**

##### Centralized Evaluative Review (CER)

01. Centralized Evaluative Review (CER) is staffed with quality reviewers on the Planning and Analysis staff at Accounts Management Campus and remote sites. CER supports team managers by conducting evaluative reviews and Quality analysis of employees’ work outlined in the CER MOU between the National Treasury Employees Union and the Internal Revenue Service and _IRM 1.4.16.5_, **Monitoring and Reviews**.

02. CER completes at least four (4) reviews each month for CSRs who are trained and certified as outlined in the CER MOU and _IRM 1.4.16.2.7_, **Training for Accounts Management (AM) Assistors**.

03. Reviews completed by CER satisfy the manager’s requirements outlined in _IRM 1.4.16.5.4.2_, _Team Manager._



    ### Note:



    CER does not review AM Leads or temporary CSRs. Managers must complete evaluative reviews for employees not eligible for the CER process. Refer to _IRM 1.4.16.5.4.2_, _Team Manager_, for more information.

04. Managers must verify and/or update the following information for each of their employees in the CER database by the 25th of the current month for the following month:



    - SEID

    - PBX ID number

    - Name

    - Last digit of Employees’ Social Security Number (SSN)

    - Team Assignment

    - Review allocations

    - Phone application(s) in training

    - Grade

    - Work Status



      ### Note:



      It is critical to keep the employees’ information current in CER SharePoint to ensure work is properly assigned for review and CSRs receive the appropriate number of monthly reviews.


05. Managers must update the CII Profile of each of their employees working CII cases as applicable to allow them to be reviewed by CER.

06. Managers must submit the following forms as applicable:




    | **Form** | **Use To** |
    | :-: | :-: |
    | Add/Update employees on SharePoint | - Add new hire employees to the CER database after they are certified for the assigned work.<br>      <br>    - Update CSR data, including review allocations after the 25th of the previous month. |
    | CER Evaluative Review Waiver | Reduce the number of CER reviews for a specific period, up to a month. |
    | CER Approval Form – Additional Evaluative Review Request | Increase the number of evaluative views as part of a performance counseling or Performance Improvement Plan (PIP). |
    | Seasonal Employee Release Form | Submit a mass request to remove seasonal employees from the CER process. |
    | Seasonal Employee Recall Form | Submit a mass request to restore seasonal employees to the CER process. |

07. Evaluative reviews must be shared with employees at the first available opportunity.



    - Reviews must be shared as required by Article 12, Section 9A of the 2022 National Agreement.

    - The dates the reviews are shared with employees must be entered into CER SharePoint.

    - Submit a DCI Deletion Request form to request unshared reviews be deleted after 15 business days from the date of the call, or from the date of review for paper.


08. Managers must ensure each employee receives the required number of CER reviews each month. Take the following steps if an employee is not receiving reviews:



    - Confirm the employee has closed cases of the applicable case type needing review.

    - Verify the employee’s CER SharePoint profile is correct.

    - (Paper reviews) Verify the Correspondence Imaging Inventory (CII) Review % is set to 0% and the Volume Per Day is set to five (5).

    - (Phone reviews) Verify the CSR’s Finesse phone system is correct. Contact local system SA staff for assistance.

    - After verifying the CSR’s closings, profiles and systems are correct, email the local CER Mailbox to request additional support.


09. Managers must address any decrease in an employee’s performance. A decrease in performance is defined as a drop in the average Critical Job Element (CJE) score. Refer to Article 12 Section 9 of the National Agreement and the if/then chart below.

    **Monitoring Performance**


     Performance Counseling




    | If | Then |
    | :-: | :-: |
    | An employee has shown a decrease in one or more CJEs but is still fully successful overall. | - Counsel the employee in relation to their overall performance rating.<br>      <br>    - Provide additional coaching, monitoring, mentoring and other developmental activities, as appropriate, to help improve employee performance.<br>      <br>    - Consult with your Department Manager.<br>      <br>    - Request up to 8 additional reviews per month for up to 60 days, **only** if more opportunities to improve are needed. Not every employee will need extra reviews to improve. |







     Performance Improvement Plan (PIP)




    | If | Then |
    | :-: | :-: |
    | An employee has shown a decrease in performance in one or more CJEs and is no longer fully successful overall. | - Counsel the employee in relation to their overall performance rating.<br>      <br>    - Provide additional coaching, monitoring, mentoring and other developmental activities, as appropriate, to help improve employee performance.<br>      <br>    - Consult with your Department Manager.<br>      <br>    - Consult with your local Labor Relations for formal PIP guidance.<br>      <br>    - Request up to 12 additional reviews per month for up to 60 days, **only** if more opportunities to improve are needed. Not every employee will need extra reviews to improve. |





    ### Note:



    **Do not** submit CER Approval Form - Additional Evaluative Review Request to make up for missing reviews. Refer to _IRM 1.4.16.5.4.2_, _Team Manager_, for more information.

10. CER uses a two-level reconsideration process for questionable defects. If the manager does not agree with a defect coded by CER, the manager must follow the reconsideration process. Refer to the if/then chart below.



    ### Note:



    Defects cannot be added to a DCI once it is completed; however, if a defect was coded under the incorrect attribute, it may be corrected. Use the reconsideration process for defects coded in error requiring removal.




    **Two-Level Reconsideration Process**


     First Level




    | If | Then |
    | :-: | :-: |
    | The manager disagrees with a defect before the review is shared with the employee, | - The manager may submit a first level reconsideration form with supporting documentation and IRM references. Emails and SERP Feedback responses are not acceptable.<br>      <br>    - Send reconsiderations to CER within five (5) business days from the date of the call or the paper closed date. |
    | The employee disagrees with the defect(s), | The manager must review the case with the employee:<br> <br>    - If the manager agrees with the employee, the manager must submit a reconsideration within 40 calendar days from the date of the call or from the review date of the paper case.<br>      <br>    - If the manager agrees with the defect(s) coded, the employee may attach a written statement concerning the disagreement to the EQRS review as outlined in the 2022 National Agreement.<br>      <br>    - CER will respond to the manager within five (5) business days. |







     Second Level




    | If | Then |
    | :-: | :-: |
    | The manager disagrees with the reconsideration response, | - The manager must coordinate with the department manager.<br>      <br>    - The department manager may complete a Second Level Reconsideration form within seven (7) business days from the date of the response date of the first level reconsideration, if they agree with the manager.<br>      <br>    - The CER manager will respond to the department manager within three (3) business days. |

11. The manager must update SharePoint with the date each first level reconsideration response is shared with the employee. The manager must notify the department manager of the date each second level reconsideration response is shared with the employee. The department manager must update SharePoint with the date shared.

12. The CER DCI Feedback Form should be submitted when:



    - The DCI Header information needs to be corrected, or

    - Useful and constructive information is provided regarding the DCI, such as:


       Correction of grammatical and spelling errors


       Unclear explanation(s) or inappropriate content (e.g., reviewer’s opinion(s) or unprofessional tone)


       Coding of one attribute should be changed to a different attribute


       An attribute that **positively** affects the employee was not coded and should be added.


### Note:

The feedback review process cannot add new defects. Use the reconsideration process for incorrectly coded defects.

**1.4.16.5.4.2** **(05-26-2023)**

##### Team Manager

1. Managers/CER quality reviewers must use the approved EQRS DCI for each applicable SPRG.

2. For telephone monitoring, develop a method for recording the pertinent facts of the call. Ensure all information needed to determine if a call is correct or incorrect is captured.

3. **Conduct a minimum of two evaluative reviews per month** (phone or paper) for each employee. Managers must ensure each employee receives the required number of CER reviews each month. Sites utilizing Centralized Evaluative Review (CER) must follow CER guidelines. See _IRM 1.4.16.5.1_, _Tracking Monitoring and Reviews_, for additional information.



### Note:



When an employee works in a blended environment (phones and paper), strive to review a proportionate combination throughout the rating period. The manager will set or verify the allocation between phones and CII correspondence on a monthly basis for CER review.

4. Complete a review waiver if an employee does not receive the required number of reviews (e.g., due to extended absences, furlough, etc.). The review waiver must explain the reason for the missing reviews. File the review waiver in the Employee Performance File (EPF).



### Note:



At the site’s discretion, provide the waivers to the department level.


**1.4.16.5.4.3** **(05-26-2023)**

##### Department Manager

1. Department managers must ensure team managers conduct or receive the required number of telephone monitoring and case reviews to provide employees with a well-documented evaluation. EQRS and Quality Review reports are available for tracking purposes. See _IRM 1.4.16.5.1_, _Tracking Monitoring and Reviews_, for resources the manager can provide for tracking.

2. Department managers must provide monthly feedback to front line managers regarding adherence to the review requirement. This feedback addresses the following:



   - The number of reviews conducted for each employee

   - The type of review (paper, phones, targeted)

   - The types of errors identified

   - Follow-up actions or discussions to improve quality


**1.4.16.5.4.4** **(05-26-2023)**

##### Feedback and Follow-up

1. Sharing monitoring results is a two-way communication. For reviews completed in EQRS, managers must use the employee reports to share results. After sharing the review, managers must determine if the employee agrees with their assessment.




| **If an employee** | **Then** |
| :-: | :-: |
| Agrees | 1. Commend the positive aspects of the performance.<br>      <br>2. Discuss areas for improvement as appropriate, see _IRM 1.4.16.5.2_(2), _Feedback and Follow-up_, for more information.<br>      <br>3. Develop plan to improve performance as appropriate. |
| Disagrees | 1. Obtain the cause of the disagreement.<br>      <br>2. Commend the positive aspects of the performance.<br>      <br>3. Discuss openly to resolve disputed issues.<br>      <br>4. Determine if a CER First Level Reconsideration is needed.<br>      <br>5. Discuss areas for improvement as appropriate, see _IRM 1.4.16.5.2_(2), _Feedback and Follow-up_, for more information.<br>      <br>6. Develop plan to improve performance as appropriate. |





### Note:



Always ensure the employee understands the Accounts Management measures and goals and how they relate to the critical job elements of their position description. Emphasize the employee’s responsibility of being open to, and applying, feedback to improve quality and performance.

2. Managers must follow the time frames for sharing performance feedback outlined in the 2022 IRS/NTEU National Agreement, which states the following:



   - If the employee has provided incorrect information to a taxpayer, the manager will inform the employee as soon as possible. In all other instances, share the evaluative review with the employee within 15 workdays from the call date or the IRS contact date.

   - Access the 2022 National Agreement via the 2022 National Agreement page.


3. Obtain the employee's acknowledgment on the designated form. Provide one copy to the employee and retain the other copy for the EPF. Sanitize all employee data containing a Social Security Number or name. See _IRM 1.4.16.5.4.1_, _Centralized Evaluative Review (CER)_, for additional requirements for CER reviews.

4. Determine if additional monitoring/review is necessary based on the following factors:



   - Training

   - Employee's ongoing performance

   - Quality Review feedback

   - Required minimum monitoring


### Note:

Use ETD and Aceyus reports such as Wrap Time and Average Handle Time (AHT) as indicators to determine when additional monitoring is appropriate.

5. Additional feedback and follow-up options may include:



   - On-the-Job instructors (OJIs) monitoring employees to provide constructive feedback and assist in employee development. This monitoring is non-evaluative and not formally documented.

   - Team leaders monitoring side-by-side to improve work skills. This monitoring is non-evaluative and not formally documented.


**1.4.16.5.5** **(12-27-2022)**

#### Workload Management/Efficiency Reviews

1. Critical Job Element (CJE) 5, Business Results - Efficiency, provides the performance expectations for Timeliness, Time Utilization and Workload Management. This involves the following:



   - Inventory time is appropriately used to work cases

   - Casework is completed in an efficient manner

   - Inventory is appropriately managed


2. Managers will conduct a quarterly Workload Management/Efficiency review to evaluate employees when they are assigned to work paper inventory programs. This review will evaluate employee performance as it relates to Time Utilization, Timeliness and Workload Management. Paper Inventory includes:



   - Adjustments Correspondence

   - Identity Theft Paper (IDTVA)

   - Taxpayer Relations (TPR)

   - Inquiry Referrals (AMS e-4442)

   - International


3. The quarterly review will include the time or period the employee was assigned to work inventory programs. This review can be performed by directly observing the employee (side by side) or reconstructing the actions taken by the employee during the defined period. Typically, this would be a block of time ranging from one to four hours or two complete cases and will include, but is not limited to, the following:



   - Open Cases - including overage cases, uncontrolled cases, open controls, and suspense cases

   - Closed Cases/Completed Cases


### Note:

All reviews **MUST** be documented.

4. Conducting the review using the side-by-side approach (as discussed above), will allow the manager to complete the reviews timely and improve the quality of the feedback.

5. Inventory reviews will be documented by completing the Data Collection Instrument (DCI) on the EQ system. The recent EQ system update enables the multi-case review process. Workload Management/Efficiency Reviews can now be completed using the EQ system for all Paper SPRGs. Job Aid and instructions are located on the EQ Website.



### Note:



For all inventory reviews, managers **must** use the AAL that includes the CCA 4243 (IDRS Automated Age Listing) and CCA 4244 (IDRS Multiple Case Control Listing). The AAL must become a part of the documentation.





### Note:



For additional information using the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_; _IRM 1.4.16.5.6.1_, _CCA 4243 - IDRS Overage Report_; and _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Report_.

6. Workload Management/Efficiency reviews determine if an employee is:



   - Completing casework in an efficient manner (time spent commensurate with complexity and training level)

   - Appropriately managing their inventory

   - Following procedural guidelines

   - Completing efficient research

   - Accessing available electronic research tools

   - Using applicable IDRS Accessory Manager Tools, i.e., IAT

   - Transferring cases appropriately

   - Monitoring and closing necessary case controls

   - Transcribing pertinent data accurately

   - Analyzing data correctly

   - Making correct decisions

   - Initiating timely and effective follow up actions including updating CII/AMS/IDRS



     ### Note:



     Managers **MUST** ensure employees are utilizing the **‘Close As MISC’** button on CII when working cases. For additional information regarding the use of this button on CII, see _IRM 1.4.16.5.6.2_, **CCA 4244 - IDRS Multiple Case Control Report**, and IRM 21.5.1.5.1(16), **CII General Guidelines**.

   - Working cases according to aged order or other priorities as established by management directives

   - Reporting time accurately using the proper Organization Function Program (OFP) codes for working paper inventory programs


**1.4.16.5.5.1** **(12-27-2022)**

##### General Guidelines

1. Consider the following factors when performing a Workload Management/Efficiency review:



   - Level of training and experience of the employee

   - Specialization of work


2. For inventory reviews, prior to selecting a closed case for input to the EQ system, the evaluative reviewer will select a period of time when the employee was assigned the work; and perform a Workload Management/Efficiency review of closed and in-process cases using the following procedures (as applicable):



   - Use CII real time data to identify closed cases and other account actions taken during a specific period of time when the employee was assigned to the work.

   - Use Transcript Inventory (AMRH and Statute) data in AMS to review work processes.

   - Select cases closed within a shorter rather than longer time block to limit the number of cases included in the review.

   - Identify the specific cases closed during the identified time frame. These will be used to complete the Workload Efficiency Review.

   - Select one of the closed/completed cases for the regular accuracy EQRS review.

   - Use the IDRS command code QRIND to review on-line adjustments.

   - Use CCA 4243 reports (Automated Age Listing) and CCA 4244 (Multiple Case Control Listing) to ensure that timely actions are being taken and cases are being worked in priority order.

   - Use AMS Taxpayer Identification Number (TIN) listing for TINs accessed by the employee during the specific period of time in question.



     ### Note:



     If the employee selects the “Bypass Disclosure” the TIN(s) will not be recorded.

   - Select "in process" cases (e.g., suspense; RTW (Return to Worker); check marked cases) to ensure correct actions are taken at first touch or when the case is workable.


3. To ensure work is resolved timely and inventory reports reflect the correct data, each AM campus MUST download the Case Control Activity (CCA) 4243, _IDRS Automated Age Listing,_ and CCA 4244, _IDRS Multiple Case Control Listing_, from Control- D WebAccess (CTDWA). These reports are downloaded weekly to an Excel file, which becomes the Automated Age Listing (AAL). The report allows the Inventory Control Manager (ICM), P&A Analysts, and management to sort assigned cases by relevant criteria (e.g., age, category, last action date) to identify and prioritize workable overage cases or cases requiring follow-up actions.



### Note:



For additional information using the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_; _IRM 1.4.16.5.6.1_, _CCA 4243 - IDRS Overage Report_; and _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Report_.

4. Managers of all inventory teams (Adjustments, Statutes, Refund Inquiry, and Accounts Maintenance Research (AMRH)) must use the AAL to perform weekly reviews of employees' assigned cases to ensure established case priorities are followed per the AM Program Letter, which is found on the AM website. Managers of teams with uncontrolled inventory e.g., Centralized Authorization File (CAF) and/or Reporting Agent File (RAF), must perform reviews of employees' work (desk reviews). All required management reviews must be documented.

5. Management is responsible for communicating expectations and evaluating employee performance relative to CJE 5, Business Results-Efficiency, pertaining to Timeliness, Time Utilization and Workload Management.

6. Follow guidance in the 2022 National Agreement regarding the rating of work performance.


**1.4.16.5.5.2** **(01-02-2012)**

##### Sharing Results

1. Share a Workload Management/Efficiency review with the employee as soon as possible and in the same manner as EQRS evaluative reviews. If employee performance indicates a need for improvement, discussions should reference the current review and prior reviews to identify the observed progress.

2. If the employee's performance requires improvement, identify and complete actions to assist the employee such as additional training or coaching.

3. Managers must share reviews within 15 workdays.


**1.4.16.5.6** **(12-17-2018)**

#### Monitoring the Automated Age Listing (AAL)

01. To ensure work is resolved timely and inventory reports reflect the correct data, each AM campus **MUST** download the Case Control Activity (CCA) 4243, IDRS Overage Report, and CCA 4244, IDRS Multiple Case Control Report, from Control- D WebAccess (CTDWA). These reports are downloaded **weekly** to an Excel file, which becomes the Automated Age Listing (AAL). For additional information regarding these reports, see_IRM 1.4.16.5.6.1_, _CCA 4243 – IDRS Overage Report,_ and _IRM 1.4.16.5.6.2_, _CCA 4244 – IDRS Multiple Case Control Report_.

02. The AAL allows the Inventory Control Manager (ICM), Planning and Analysis (P&A) analysts, and management to sort assigned cases by relevant criteria (e.g., age, category, last action date) to identify and prioritize workable overage cases or cases requiring follow-up actions.

03. AM Campus and Remote site Managers **must monitor** overage inventory for their assigned teams using the AAL and share feedback with each employee weekly to ensure the employee is working inventory in accordance with established guidelines.

04. Managers of all teams with inventory will use the AAL to perform weekly reviews of employees’ assigned cases to ensure employees are closing cases according to established program priority. Inventory should include:



    - Adjustments

    - Statutes

    - Refund Inquiry

    - Accounts Maintenance Research Hold (AMRH)

    - Unpostables

    - Operation Assistance Requests (OARs)

    - Identity Theft


05. Managers of teams with uncontrolled inventory, e.g., Centralized Authorization File (CAF) and/or Reporting Agent File (RAF), must perform reviews of employee’s work (desk reviews) to ensure established priorities are followed.

06. Age list reviews are performed for the following reasons:



    - Identify specific cases for review

    - Monitor the volume of the employee’s inventory

    - Set overage closure expectations

    - Identify potential problem cases


07. Some important items to watch in any age list review include:



    - Cases over the aging criteria

    - Inappropriate activity code

    - Expired purge/action dates

    - Excessive time elapsed since last action

    - Expired Statute

    - Inappropriate suspense cases


08. There are several methods available to conduct an age list review. Two methods are shown below.



    - Print the entire list for each employee and use color-coded highlighters or other notations to point out priority issues on the hard copy.

    - Use the AAL filters to reduce the overall list and display only priority cases. Add emphasis with color-coded cell highlights within Excel. If the data is stored on a shared drive, ensure PII information is protected in compliance with Data Security requirements. Share each employee’s list with an added column for follow-up comments. Print the reduced list if sharing files is difficult.


09. The AAL review is a required management review and **must** be documented and filed in the employee’s EPF per IRM 6.430.2.3.5(4), **Employee Performance File**.

10. ITM Course 34765, _Inventory Management for AM Managers,_ includes guidance regarding the AAL and other inventory management topics.


**1.4.16.5.6.1** **(01-20-2021)**

##### CCA 4243 – IDRS Overage Report

1. This report contains all cases controlled to an IDRS employee number (in IRS received date order) and managers use this report to:



   - Identify cases that require action

   - Identify specific cases for review

   - Monitor the size of the employees' inventories

   - Determine if employees are working inventory in the proper order

   - Set closure expectations

   - Identify potential management problem cases

   - Monitor for the prevention of premature STAUP/TC 470


2. This reports below are available in Control-D every **Monday** morning:



   - **Report Name: "OVERAGE REPORT"**

   - **Job Name: "CCA 4243x" (x = the alpha character assigned to the campus)**


3. The information in the AAL data fields provides proper case management. The following data fields are shown for each case on the report:



   - **TEAM** \- Team IDRS number for employee

   - **EMP#** \- IDRS number of the employee case is assigned.

   - **TIN** \- Taxpayer Identification Number (SSN, EIN, ATIN, or ITIN)

   - **MFT** \- Master File Tax Transaction Code

   - **TXPD** \- Tax period of the case

   - **NAME** \- Name Control

   - **FRZ CODE** \- Freeze codes on the account

   - **AGE** \- Number of days aged from the IRS received date.



     ### Exception:



     For CONTROL-CATEGORIES 1081, 1184, 3858, 3859, 3864, 3911, 841P, ACKN, RCTF, RECL, ST32, TOAD, OOPS, PAID, UPP, URP1, or URPS use the ACTION-DT instead of the IRS-RCVD-DT to compute CASE-AGE when the CASE-STATUS-CD is **background**.

   - **IRS RECD DATE** \- The date the case was received by the IRS

   - **ASSIGN DATE** \- The date the case was assigned to the current employee

   - **ACTIVITY CODE** \- The last action taken on the case

   - **ST** \- The Status Code of the case


      A - Active case under control. Includes cases awaiting MFTRA, documents, or action by the employee


      M - A controlled case that cannot be resolved due to long term delay (internal information, out-of-region document request, etc.)


      B - Background status used to monitor case


      S - When sending letters to the taxpayer and waiting for a response from the taxpayer (External Information)

   - **CATE** \- The Category code of the case

   - **ACTION DATE** – The date of last IDRS action

   - **HM** \- (H)ave (M)et - Overage indicator. All taxpayer-initiated cases begin to age at 45 days. When the case reaches aged criteria for the first time an **\*** will be displayed, the case will display a 2 through 9 for each week the case is on the aged list. After 9 weeks a **>** is displayed

   - **(-)** \- Debit or credit indicator

   - **MOD BAL** \-\- Module balance of the case

   - **STAT AGE** \- Statute age of the case. Indicates statute conditions for current and prior year returns - over, expired, or days remaining on statute

   - **STAUP CYC** \- Indicates the number of posting cycles before a STAUP expires. Value of "S" is shown if a STAUP is active along with the number of cycles remaining when three or less follows "S"



     ### Note:



     Example: "S-2" indicates 2 cycles remain on the STAUP. Value of "D" is shown if a STAUP is active for TISGND (TDI), and a value of "T" is shown if a STAUP is active for a TC470 account. The applicable posting cycles also appear after the values of "D" and "T" .

   - **C LETR**\- Indicates the letter number of the last C letter issued

   - **LETR DATE** -Date the last letter was issued

   - **BOD** \- Business Operating Division

   - **CLC** \- BOD Client Code. This is a code to indicate the particular group of the BOD

   - **PLAN** \- Plan number. Always "0" on BMF cases. Plan number indicated for various TE/GE cases

   - **ASED** Assessment Statute Expiration Date - 3 years from the due date or received date, whichever is later


4. The **Activity Code** data field on the report is important to monitor. Activity codes should be up to date, consist of appropriate timeframes, and reflect current activity. Check activity codes to ensure:



   - They are updated timely and are appropriate for each case.

   - Cases in "Monitor" status have a follow-up date identified.

   - Any cases previously worked, but not closed in IDRS reflect the appropriate activity code. Activity codes such as 34-CR-TRAN; 54-TAX-ADJ; ADJ54; CRED-TRANS; RLSE-FRZ; TRUE-DUP; X-Claim; etc. may indicate the case was worked but not closed properly on IDRS.

   - Document requests have a pending date for follow-up and are followed up timely. Prior to ordering a document ensure the case is not workable without the document and perform a TIN search in CII.

   - Check for activity codes "ACTV" and "REASSIGN" , which have an older action date, generally those 14 days or older, as this can be an indicator the case may not have been reviewed yet for proper action and/or may be workable.


5. The Manager/Lead **must** review this report to ensure cases are being worked in priority order according to IRS received dates **(FIFO – First-In, First-Out)**.

6. Manager/Lead **must** provide employee with the page(s) (either electronically or by paper) of the report where the cases are controlled to their IDRS number. Annotate cases for follow-up actions by COB Monday or Tuesday. Highlight the cases on the report where:



   - The employee may have failed to initiate action on a priority program case such as identity theft or injured spouse, etc.

   - The employee may have failed to take timely actions such as follow-up on a case when the purge date has passed.

   - The case is in Nullified Unpostable (NLUN) category over 14 days old.

   - The Statute of Limitations on assessment of tax will expire within 90 days.

   - The STAUP has expired or there is no STAUP on a balance due account.


7. The employee will notate, on the bottom of the page, the actions taken on each case worked. Annotations should include C - Closed; U - Update; or S - STAUP input. The report should be returned to the Manager/Lead by close of business Thursday. The employee should work cases in the following priority order:



   - NLUN category cases.

   - The statute on assessment will expire within 90 days.

   - Taxpayer was contacted and purge date has passed.

   - Remaining cases by case type/priority in oldest date received order (FIFO).


8. The reports should be maintained for three months in the Employee Performance File (EPF).


**1.4.16.5.6.2** **(12-27-2022)**

##### CCA 4244 – IDRS Multiple Case Control Report

1. This report identifies cases when two or more employees have an open control base on the same TIN. It identifies the employee's IDRS numbers, tax year, and category for the duplicate controls.

2. This report is available in Control-D every **Monday morning**:



   - **Report Name: "MULTI CASE RE"**

   - **Job Name**: **CCA 4244x**

   - Multiple case reports that contain only Accounts Management data can be accessed using **Report Name: "MULTICASE-AM\*"**.


3. Managers **must** use this report to identify when there are multiple control bases on the same account. Identify the following:



   - Cases where the same employee has more than one control base open

   - Cases that can be rerouted to another area and closed

   - Cases where a different employee has an open control

   - Cases that can be closed due to previous actions



     ### Note:



     There will be times when more than one control base open on the same account is appropriate. Each case must be reviewed to determine if a multiple control base should remain open. Multiples with other service centers can be viewed and displayed in the report.


4. The information in the Multiple Case Listing data fields provides for proper case management. The report will show up to nine (9) multiple case controls. The following data fields are shown for each case on the report:



   - **TIN**\- Taxpayer Identification Number

   - **BOD** \- Business Operating Division

   - **BOD CLC** \- Business Operating Division Client Code

   - **F/S** \- File Source

   - **MFT** \- Master File Tax Account Code

   - **Tax Period** \- Identifies the tax period that was controlled

   - **PLN** \- Plan number, if applicable

   - **N/C>** \- Name Ctrl

   - **C#** \- Control Base Number

   - **Employee #** \- Employee number for employee assigned

   - **Status** \- Case History Status Code

   - **Category** \- Category of first case

   - **IRS Rcd Date** \- The first IRS received date

   - **C#** \- Second Control Base Number

   - **Employee #** \- Second employee number for employee assigned

   - **Status** \- Second Case History Status Code

   - **Category** \- Category of second case

   - **IRS Rcd Date** \- The second IRS received date


5. The Manager/Lead **MUST**:



   - Provide the report (either electronically or by paper) by **COB Monday** to the employee identified as having controls on the case. For cases assigned to Central Distribution numbers or queues, the listings will be worked by the designated team lead/manager.

   - Instruct the employee to annotate the actions taken on the case on the report and return the annotated report to the Manager/Lead **no later than close of business on Thursday**.



     ### Note:



     When there are multiple open CII cases on a TIN, **ensure** the employee uses the "Close As MISC" button (on the CII case page). This button closes the CII case and updates the category code to "MISC" (in IDRS only), while closing the IDRS control base. For additional information using the "Close As MISC" button on CII, see IRM 21.5.1.5.1(16), _CII General Guidelines_, and IRM 21.2.1.9(4), _Correspondence Imaging Inventory (CII)._





     ### Note:



     For units with identity theft multiple controls, **ensure** the employees follow guidelines in IRM 25.23.3.2, _Identity Theft Paper Overview_, and Exhibit 25.23.4-7, _Identity Theft Multiple Control Decision Document._

   - After it is returned by the employee, review the report to determine if the correct actions were taken or return to the employee with feedback on the actions that need to be taken.

   - Maintain these reports for three months in the Employee Performance File (EPF).


**1.4.16.5.6.3** **(01-01-2015)**

##### Managers Assessing Performance (MAP)

1. The Managers Assessing Performance (MAP) tool is a guide to assist Accounts Management managers with program management and leadership responsibilities. Managers are responsible for communicating organizational goals and achieving business priorities and objectives.

2. The MAP tool provides a consolidated list of numerous management information and real-time data reports available for monitoring performance. These reports are indicators that lead to identifying opportunities to increase efficiency and effectiveness for employees, teams, departments, operations, and directorates.

3. Access permissions to this tool follow HR Connect PAR actions and is available to all AM management officials. If a manager returns or moves to a non-management position, access to the MAP will be removed.


**1.4.16.5.7** **(01-01-2014)**

#### Review of IDRS Adjustments

1. Ensure the integrity and accuracy of adjustments made to taxpayer accounts. Review 100 percent of on-line transactions for each newly trained assistor until the employee's performance is satisfactory (the employee consistently inputs correct adjustments). Follow up with ongoing sample reviews. If performance problem exists, reinstate 100 percent reviews.


**1.4.16.5.7.1** **(01-01-2014)**

##### Command Codes for Review of IDRS Adjustments

1. Use the following IDRS Command Codes (CC) to review on-line adjustments:



   - QRADD

   - QRIND

   - RVIEW

   - QRACN


> The above command codes are found in IRM 2.4.5, _Command Codes QRADD, QRADDO, QRNCH, QRNCHG, RVIEW, QRACN, and QRIND for the Quality Review System._

2. Use CC QRADD to enter the employee numbers of employees you plan to review. Suspend all transactions input by your employee or group using CC QRADD or CC QRADDG for the same day. Transactions remain suspended for review for two days. After two days, all transactions not reviewed are released systemically for processing to the Master File.

3. Use CC QRIND with CC RVIEW to control workloads. CC QRIND requests a summary of an assistor's transactions available for review for a specific day. Evaluate adherence to IDRS security and procedures. It is useful to keep a control log of the CC QRIND reviews.

4. Use CC RVIEW to review all transactions or selected transactions input by individual assistors. Input CC RVIEW within two days after a CC QRADD or a CC QRADDG request to review an adjustment.

5. Use CC QRACN to accept, reject, or review your employee's transaction input screens, displayed by using CC RVIEW. Review the displayed transaction for quality and appropriate documentation requirements before using CC QRACN.



1. Accepted transactions release to the Master Files for processing after the standard two-day hold.

2. Rejected transactions change from IDRS status "AP" to "DQ" the following work day. The reviewer/manager must print the action after rejecting the transaction. Send these prints back to the employee for corrective action.


**1.4.16.5.7.2** **(01-01-2014)**

##### Focus of the IDRS Adjustments Review

1. IDRS adjustment reviews help do the following:



   - Prevent unpostables

   - Ensure prompt correction of errors


2. Determine if employees use appropriate IRM procedures to input adjustments. To ensure overall quality of the work, if a performance problem exists, consider requiring review/approval of any or all IDRS adjustments.

3. Review a sample of IDRS adjustments with source documents, focusing on the following areas:



01. Appropriate source documents

02. Accurate and complete input data

03. Proper hold codes

04. Correct priority codes

05. Accurate source codes

06. Appropriate blocking series

07. Appropriate reason codes

08. Complete remarks section

09. Ensure use of mandated Integrated Automation Technologies (IAT) Tools

10. Appropriate monitoring for transaction posting (when applicable e.g., TC 841)


### Note:

When an inappropriate or incorrect adjustment identified by CQRS needs immediate corrective action, input Command Code TERUP in IDRS. The reviewer then enters "Flash" in the NQRS remarks section to alert the site of this case.

**1.4.16.5.7.3** **(01-01-2014)**

##### Delegating Reviews of IDRS Adjustments

1. A manager may delegate the IDRS reviews, but an employee may not conduct a review of their own cases.

2. If a manager delegates the review, the employee conducting the review briefs the manager and the employee involved.


**1.4.16.5.8** **(12-17-2018)**

#### Non-Evaluative or Coaching Reviews

1. Managers and/or their lead technical employees can perform non-evaluative monitoring on the following:



   - Telephone calls

   - Paper Inventory reviews

   - Certain issues (e.g., Disclosure)


2. The primary purpose of a non-evaluative review is to help the employee develop and enhance their job skills. Effective non-evaluative reviews foster open lines of communication between the employee, the manager, and the lead technical employee. This enables the manager and lead to receive employee feedback and transfer operational goals informally.

3. Non-evaluative or coaching reviews do not contain a written rating. Share the results orally. Some documentation is appropriate to establish it actually occurred. EQRS may be used to track employee development for this purpose. Have the employee initial and date. Provide one copy for the employee and retain the other copy in the employee's drop file.

4. The manager or the lead should conduct the review; however, occasionally delegating these duties to a skilled journey level employee, for training purposes, may be appropriate.

5. Conduct a minimum of two non-evaluative targeted reviews per employee per month **if** customer accuracy errors are identified on use of ITLA. This applies only to employees staffing tax law applications.



### Note:



A non-evaluative targeted review is one in which the entire call is not reviewed. These reviews may serve as indicators for areas where additional evaluative monitoring should be conducted.





### Example:



An example of non-evaluative targeted monitoring is to listen to the call to determine if the employee has accurately identified the customer's issue, determined that use of ITLA is required, and followed the guide to respond to the caller.





### Reminder:



It is not necessary to listen to the entire call once it is determined the correct procedures from ITLA are being followed.

6. If it is determined during the targeted review the employee is not following ITLA, use your discretion whether to listen to the entire call and document as an evaluative review.



### Note:



For additional information on the use of ITLA, see paragraph (3) in _IRM 1.4.16.5.3_, _Telephone Monitoring_.


**1.4.16.5.8.1** **(01-01-2014)**

##### Non-Evaluative Monitoring

1. Non-evaluative reviews are conducted for a several reasons (e.g., disclosure, history items, etc.).

2. Non-evaluative target reviews help focus on issues causing high error rates.

3. When implementing major procedural revisions, non-evaluative reviews can help managers determine if additional discussion and procedural reviews during group meetings may be needed.

4. Non-evaluative reviews can help the manager and employee determine progress as a result of training and coaching conducted as part of a performance improvement plan.

5. When an employee is having difficulty dealing with a caller, non-evaluative monitoring allows the manager to assist the employee, if needed.


**1.4.16.5.8.2** **(01-01-2014)**

##### Side by Side Monitoring

1. You can accomplish non-evaluative monitoring by utilizing periodic side-by-side reviews, _when deemed appropriate,_ or requested by an employee. Use the optional telephone jack (double plugging) on the employee's teleset. Apply this technique when circumstances merit an in-depth discussion for training purposes.

2. You may delegate this non-evaluative review to your lead or an OJI. Periodically, delegate this non-evaluative review to experienced telephone assistors to foster the team approach to improve your group's performance. This approach will ultimately improve the work process.



### Note:



Double plugging, as an introduction to the job by new telephone assistors with experienced employees, is a good training tool.


**1.4.16.5.8.3** **(01-01-2014)**

##### Non-Evaluative Paper/Procedural Reviews

1. Accomplish non-evaluative paper or procedural reviews using the same guidelines as provided in workload reviews.

2. Clearly explain any problems you identify and provide guidance for the employee to improve performance.


**1.4.16.5.9** **(01-01-2014)**

#### Clerical Reviews

1. Clerical employees perform various administrative duties which support the IRS's ability to provide customer service. They may include the following:



1. Timekeeping

2. Mail receipt and distribution

3. Typing

4. Log or lists of controls and information

5. Maintenance of files

6. Receiving telephone calls

7. Other duties as assigned


2. You should focus not only on the employee's ability to complete their assignments, but also on their ability to set priorities and complete assignments independently and expeditiously. You must conduct monthly reviews to determine the accuracy and timeliness of employees' work.

3. Clerical reviews should also address the clerical work process (i.e., Form 3210 acknowledgement and follow-up).


**1.4.16.5.10** **(12-17-2018)**

#### Taxpayer Advocate Service (TAS)

1. The Taxpayer Advocate Service (TAS) is an independent organization within IRS whose employees assist taxpayers who are experiencing economic harm, who are seeking help in resolving tax problems that have not been resolved through normal channels, or who believe that an IRS system or procedure is not working as it should.

2. A referral to a TAS office should be made if the IRS employee receives a taxpayer contact, and the employee cannot initiate action to resolve the taxpayer's inquiry or provide the relief requested by the taxpayer. A taxpayer does not have to specifically request TAS assistance to be referred to TAS.

3. AM assistors use IRM 21.1.3.18, _Taxpayer Advocate Service (TAS) Guidelines_, to determine if a taxpayer's case meets any of the TAS Case Criteria, 1 through 9, found in IRM 13.1.7.2, _TAS Case Criteria_.

4. Effective March 30, 2015, all e-911s, systemically route directly to TAS. AM Managers no longer review the e-911.

5. For additional information regarding TAS guidelines within AM, see IRM 21.1.3.18, _Taxpayer Advocate Service (TAS) Guidelines_.


**1.4.16.5.11** **(08-23-2021)**

#### Monitoring the Outstanding Cases Listing (OCL)

1. The United States Residency Certification (USC) program’s inventory and reports are only found on the United States Residency Certification (USRC) Database through the Reports Console. The report that is used to monitor the aged inventory is the Outstanding Cases Listing (OCL).

2. All managers, leads, tax examiners, and clerks are responsible for reviewing the OCL weekly.

3. Leads, tax examiners, and clerks must review their OCLs every Monday and return to their manager by close of business every Friday notating the following information:



   - Actions taken of the aged cases

   - Date and reason for cases being closed

   - Letters issued


4. Managers are responsible for reviewing each employee’s OCL, verifying proper actions have been taken. Managers must ensure:



   - Clerks have performed the Inventory Control Process (ICP) (630 status)

   - Inventory is worked first-in-first-out (FIFO) order.



     ### Note:



     Cases in 099 status (ready for printing/mailing) must be elevated to the manager for printing and notated on the OCL the action taken.

   - Inventory is transferred from clerks and recontrolled to tax examiners or leads when the processing date has been reached.



     ### Note:



     Managers will locate cases not recontrolled and ensure the cases are recontrolled to the appropriate lead or tax examiner.


**1.4.16.6** **(01-02-2012)**

### OPERATIONAL REVIEWS OVERVIEW

1. An Operational Review is an in-depth review and analysis of a particular program or function.

2. Operational Reviews are conducted in the following manner:



   - Department Managers (DM) review Frontline Teams

   - Operation Managers (OM) review DMs

   - Planning & Analysis (P&A) Staff review Operations


**1.4.16.6.1** **(12-27-2022)**

#### Operational Reviews

01. Operational Reviews must:



    - Evaluate and assess

    - Identify areas to improve

    - Establish target dates for improvement

    - Identify and praise accomplishments

    - Provide a follow-up on action items


02. The review should address:



    - Workload management practices

    - Personnel management practices

    - Administrative practices


03. Compare the above practices to the following:



    1. Mission statement

    2. Policies and regulations

    3. 2022 National Agreement

    4. Memorandums of Understanding (MOUs)

    5. Program Letter

    6. Business measures and goals


04. Prepare a schedule of planned reviews at the beginning of each fiscal year and no later than November 1st. Schedule reviews to ensure that all teams, including expansion teams, are addressed. Provide the schedule to the Operation Manager, or Director, as appropriate.

05. Request the information needed from the manager 30 days in advance. This will ensure all information is available at the start of the review. This may include the following items:



    01. Employee Performance Files (EPF)

    02. Personnel files

    03. Drop Files (including meeting minutes)

    04. Managers Monitoring Confirmation Logs for manual refunds

    05. Training files (access employee ITM reports)

    06. Employee Survey Satisfaction results

    07. WP&C data

    08. AMS data

    09. Local inventory reports

    10. Automated Age Listing (AAL)

    11. Sample of closed cases

    12. Sample of open cases

    13. Average handle time reports

    14. Adherence reports

    15. Transfer reports

    16. Aceyus reports

    17. Security reviews

    18. Totally Automated Personnel System (TAPS) data

    19. Leave tracking

    20. Evaluation/Midyear tracking

    21. Quality/Productivity/Improvement Initiatives

    22. Engagement Plans/Activities

    23. Updates on Engagement Strategy (ES) Tracker data


06. It is recommended when the Department Manager (DM) reviews a Team Manager (TM) that you review a minimum of six EPFs; including a work leader, one team clerk/secretary (if one is assigned) and four telephone/paper assistors, Tax Examiners (TEs), or other applicable team employee. Also, try to review EPFs of employees with different levels of experience.



    ### Note:



    Generally, department managers schedule one or two team reviews a month.

07. It is recommended that when the OP Manager reviews a DM, the OP Manager reviews at least half of all EPFs of those who directly report to the DM, plus samples of employees' EPFs from teams within that department.



    ### Note:



    A review of a DM may take about two weeks.

08. Obtain assistance, as needed, on completing technical portions of the review such as the closed case reviews from the Quality or PAS Units. Operations Managers may also obtain assistance from the P&A staff to assist with department reviews.

09. Allow sufficient time for performing the review, writing the report, and providing feedback from the final report to the manager or director as appropriate.



    ### Note:



    The feedback should follow the critical elements (i.e., leadership, employee satisfaction, customer satisfaction, business results) and specify items reviewed. It should also follow the responsibilities outlined in the managerial performance plans (Leadership & Human Capital Management; Customer Service & Collaboration; and Program Management).

10. Promptly document the operation review in a memorandum to the appropriate manager or department head. Include the following in the memorandum:



    - Summary of the observations (positive and negative)

    - Recommendations and action items

    - Follow-up dates


11. Maintain a copy of the memorandum in the office files and one in the manager's EPF. Be sure to follow-up timely with the manager on action items. Document all follow-up actions.


**1.4.16.6.2** **(01-11-2024)**

#### Department, Operation or Front-Line Manager

1. The Operational Review should cover the following:



1. Personnel management practices

2. Workload management practices

3. Administrative, security, safety practices

4. Manager's organization


2. Review personnel management practices of maintaining Employee Personnel Files (EPF), Drop files and Personal/Training files for the following:



01. Critical Job Elements (CJEs) and Form 6774, _Receipt of Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard_ (annually)

02. Seasonal agreements (if applicable) (annually)

03. Training and OJT documentation

04. Evaluative reviews, including content, scope, and amounts (Front line manager) (monthly)

05. Mid-year progress reviews (Front line manager) (annually)

06. Performance reviews (Department manager)

07. Operation reviews (Department and Operations manager)

08. Evaluations (annually)

09. Poor performance

10. Awards

11. Non-evaluative reviews and coaching

12. Position management

13. Leave administration

14. Employee development

15. Communication including team meetings

16. Employee satisfaction


### Note:

Refer to Document 12829, General Records Schedules (GRS) 2.2, Item 080 for Employee Personnel Files (EPFs) retention and disposition requirements.

3. Review Workload Management Practices for the following:



### Note:



All reviews must be documented in writing.





1. Quality of work performed in function (phones and paper)

2. Acknowledgement and follow-up of Form 3210

3. Timeliness of work performed in function (paper) (use the AAL)

4. Expectations for phone functions

5. Utilization of lead employee


4. Review Administrative, Privacy, Security, and Safety Practices, including the following:



1. Time reporting including timeliness of any needed IPR corrections

2. UNAX Training and Certification completed and scheduled for all employees



      ### Note:



      Unauthorized Access (UNAX) is now administered by the Office of Privacy and Information Protection. For details, see IRM 10.5.5, **Privacy and Information, IRS Unauthorized Access, Attempted Access or Inspection of Taxpayer Records (UNAX) Program Policy, Guidance and Requirements.**

3. Prevention of Sexual Harassment (POSH) completed or scheduled for all employees

4. Release/Recall correctly updated

5. Rules of Conduct meetings held

6. Security reviews

7. eWFM/WFO information input timely

8. Correctness of TAPS information


5. Review Manager's organization effectiveness:



   - Timeliness of controlled responses

   - Effectiveness of method for managing tasks or assignments

   - Completeness, thoroughness, timeliness of reviews, projects, etc.


**1.4.16.7** **(01-02-2012)**

### QUALITY REVIEWS

1. Quality Review is an integral part of the Quality Assurance Program within AM. Quality measurements are used to evaluate specific site performance in the Annual Performance Plan (APP).

2. The Quality Review process provides a method to monitor, measure, and improve the quality of work throughout Accounts Management.

3. Embedded Quality (EQ) is defined as the system that is used by AM for their Embedded Quality Review Program. It is a way of doing business that builds commitment and capability among all individuals to continually improve customer service, employee satisfaction, and business results. IRM 21.10, _Quality Assurance_, outlines additional information regarding the EQ process.


**1.4.16.7.1** **(01-02-2012)**

#### Measures

1. The EQ process resulted in changes to the measurement of quality in Accounts Management. The AM Quality process is based on **five** measures:



1. **Professionalism:**


       Promoting a positive image of the IRS by using effective communication techniques.

2. **Customer Accuracy:**


       Giving the correct answer with the correct resolution. "Correct" is measured based upon the customer receiving a correct response or resolution to the case or issue, and if appropriate, taking the necessary case actions or disposition to provide this response or resolution and does not take into consideration any additional IRS issues or procedures that do not directly impact the taxpayer's issue or case.

3. **Procedural Accuracy:**


       Adhering to statutory/regulatory process requirements when making determinations on taxpayer accounts/cases.

4. **Regulatory Accuracy:**


       Adhering to non-statutory/non-regulatory internal process requirements when making determinations on taxpayer accounts/cases.

5. **Timeliness:**


       Resolving an issue in the most efficient manner through the use of proper workload management and time utilization techniques.


2. The Customer Accuracy, Professionalism, and Timeliness measures are reported to the Commissioner as Quality measures. The Customer Accuracy measure is also reported externally to our stakeholders (Congress, GAO, etc.). The Regulatory Accuracy and Procedural Accuracy measures are internally reported process measures - reported to Site Directors and other levels of management along with the other three measures.


**1.4.16.7.2** **(01-27-2022)**

#### Assurance Components

1. The EQ Improvement Plan (Quality Action Plan) is the road map used by the sites to ensure EQ objectives are met or exceeded. This plan outlines key actions in support of fiscal year EQ goals.

2. Recommended Plan Content:



   - Distinct sections for each Specialized Product Review Group (SPRG)

   - Improvement actions based on specific (e.g., attributes and case types) Customer Accuracy trends

   - Employee engagement activities to foster accountability

   - Communication Strategy to share information on objectives and performance including improvement opportunities and related corrective actions

   - Periodic analysis of top accuracy drivers to determine specific causes


3. Quality Review Components:



   - National reviews - Centralized Quality Review System (CQRS)

   - National reviews - Program Analysis System (PAS) (Only Paper Specialized Review Services)

   - Managerial and Centralized Evaluative Reviews

   - Local reviews performed by the site for quality improvement


4. National Reviews are performed to measure the quality of service to our customers on all our staffed programs (product lines). Reviews are entered into the National Quality Review System (NQRS) and the data is rolled up, providing the quality results for the Balanced Measures. Weighted quality results are available monthly for the Customer Accuracy, Professionalism, and Timeliness business measures.

5. Data from local reviews performed for quality improvement is entered into NQRS as a Local Review and is not rolled up into the national quality and accuracy rates.

6. Managerial and Centralized Evaluative Review (CER) reviews creates accountability by connecting employee evaluations to the quality measurement and calculation process. Managers will use this process for planning purposes, and to track employee performance and training needs.

7. Data from the managerial/CER reviews is entered into the Embedded Quality Review System (EQRS), which maps to an employee's critical job elements and aspects and the data is rolled up to identify overall employee, team, department and site scores for the Customer Accuracy, Professionalism, and Timeliness business measures. It is not combined in any way with national or local quality and accuracy rates.

8. Managers should:



   - Use Quality View reports for an overview of quality statistics

   - Use EQRS reports to focus on employee specific opportunities

   - Use the Quality View SharePoint site to access Quality View training material or contact the site Quality View POC for help with Quality View reports

   - Contact the local Quality Manager for help in creating EQRS Ad-Hoc reports and using EQRS Organization reports


9. Centralized Quality Review System (CQRS) generates monthly quality trend reports on all Product Lines throughout the year and are made available on their website. The reports identify error trends and improvement opportunities. The reports contain helpful analysis and recommendations to assist in meeting the quality goals. Sites are encouraged to review these reports as they may be helpful when performing review and analysis of your local results.



### Reminder:



For more information on Embedded Quality (EQ) refer to IRM 21.10.1, _Embedded Quality (EQ) Program for Accounts Management, Compliance Services, Field Assistance, Tax Exempt/Government Entities, and Electronic Products and Services Support_. Additional pertinent quality information may also be obtained from the EQ Website and the AM Quality View Report sites.


**1.4.16.7.3** **(12-10-2020)**

#### Process

1. Statistical sampling is the basis of the Quality Review process. Sample plans are designed on the laws of probability using mathematical procedures. The advantages are their reliability, objectivity, and consistency. The quality review system uses systematic random sampling to verify the quality and productivity within Accounts Management without reviewing each piece of work.

2. The quality reviewer reviews work following the sample plan. Results of the reviews are analyzed to identify trends and training needs and to establish accuracy, timeliness, and professionalism measures. Reviewers must strictly follow sampling procedures to ensure valid accuracy rates.

3. The quality reviewer must understand the following:



   - Operational definitions and criteria for casework

   - Consistent reviewing techniques

   - Equipment used in reviewing

   - How to record complete review results

   - How to report any problems to management, along with suggested solutions


**1.4.16.7.4** **(12-06-2019)**

#### Reports

1. Monthly reports are produced from the NQRS system. These reports provide information on Customer Accuracy, Procedural Accuracy and Regulatory Accuracy, Timeliness and Professionalism. Sites may also produce ad-hoc reports for their site. Samples of issued reports are as follows:



1. Weighted Report - A monthly report showing the accuracy rate, sample size, total volume, and precision rate

2. Unweighted Report - A daily real-time report showing the accuracy rate and sample size (does not include total volume or precision rate). All EQRS reports are unweighted


**1.4.16.7.5** **(07-17-2024)**

#### Process Improvement (PI) Specialist Roles and Responsibilities

1. A Process Improvement (PI) Specialist is on staff at all AM campuses. The PI Specialist reports to the PI Manager at each campus. The PI Manager reports to the campus P&A Chief.



### Note:



PI Specialists and PI Managers are not on staff at the AM Remote sites. A Quality Assurance Coordinator (QAC) is on staff at these sites. See IRM 21.10.1.2.6.8, _Accounts Management Local Quality Analyst/PAS Analyst_, for roles and responsibilities of the QAC at AM Remote site locations.

2. The campus PI Specialist duties are to:



01. Identify potential new processes and procedural changes that will improve work processes, quality, and level of service for the taxpayers.

02. Ensure feasible recommendations are presented to enhance procedural, policy, and systemic work practices.

03. Recommend changes to provide consistency, enhance productivity and efficiency.

04. Elevate improvement process recommendations to Process Improvement (PI) Manager and Process Improvement Customer Accuracy (PICA) Tax Analysts.

05. Attend and assist with Training on improvement methods, including the Define, Measure, Analyze, Improve Control (DMAIC) process.

06. Work with PICA to gather facts/data to justify procedural, systemic, and program changes to improve work practices, policies, and procedures.

07. Share sound recommendations with solid facts and figures to justify changes to appropriate stakeholders such as Policy & Procedures (PPM); Identity Protection Strategy and Oversight (IPSO); and Return Integrity and Compliance Services (RICS) – i.e., Taxpayer Protection Program (TPP).

08. Ensure approved recommendations are implemented in a timely manner.

09. Identify and elevate IPUs and/or Alerts needing clarification with appropriate internal stakeholders such as PPM; PSO and RIVO - i.e., on TPP issues) and Field Assistance. Refer to IRM 21.10.1.2.7.1 _, AM IRM Procedural Update/SERP Alert/News Release Filtering and Distribution_ for additional guidance.

10. Lead cross-functional improvement discussions and teams at the site.

11. Develop and share **_Monthly Quality Review Talking Points_** with the site Field Director, P&A Chief, Operations Managers, and Frontline Managers. Talking points should cover quality data, error trends, site actions to address defects, and other improvement actions. A courtesy copy of the talking points should be shared with your PICA Point of Contact (POC).

12. Request action plans (from program owner) when appropriate.

13. Participate in a least two (2) projects (per person) per year (HQ and/or campus) including working with PICA.

14. Report project status monthly (weekly when appropriate) to PICA and appropriate stakeholders such as PPM while gathering information.

15. Manage the improvement project when additional information must be gathered.

16. Allocate your time appropriately:


        Use at least half of your time (during the year) providing "expert" assistance to Campus P&A staff and Operations Chiefs and the other half of your time (during the year) working with PICA.

17. Perform review of CQRS reviewer DCI coding within two-day consistency timeframe to help reduce the number of incorrect defects being charged and the number of rebuttals being processed.

18. Communicate results, recommendations, and related improvement procedures to other sites.

19. Conduct calibration and consistency analysis, when appropriate.

20. Establish improvement team to address hot topics during the filing season.

21. Identify local procedures, job aids, and check sheet and ensure they are approved by Headquarters and used by each site for consistency.


3. PI Specialists are to ensure changes are based on the following quality principles:



   - **Professionalism**

   - **Customer Accuracy**

   - **Procedural Accuracy**

   - **Regulatory Accuracy**

   - **Timeliness**


4. PI Specialists are to use the following reports when analyzing quality issues:



   - **NQRS Weighted Reports**


      Customer Accuracy Report

   - **NQRS Unweighted Reports**


      Customer Accuracy Driver Report


      Top Defect/Successes by Site Report


      Ad Hoc Reports

   - **EQRS Reports**


      EQRS / NQRS Comparison Report


      Ad Hoc Report

   - **Site Level Indicators & Measure (SLIM) Report**

   - **ETD Report**

   - **Spot-Checking Work Spreadsheet**


5. PI Specialists and QACs are responsible for the AM IRM Procedural Update/SERP Alert Filtering and Distribution process. This includes the filtering of News Release information available on IRS.gov. For additional information regarding this process see IRM 21.10.1.2.7.1, _AM IRM Procedural Update/SERP Alert Filtering and Distribution_.

6. Embedded Quality is responsible for forwarding the Adjustment Spot Checking Spreadsheet to PICA Wednesday of the following week. The spreadsheet is used for non-evaluative purposes to identify the work that is stopped for managers to have corrected immediately.


**1.4.16.8** **(01-01-2015)**

### MANAGEMENT INFORMATION REPORTS

1. This subsection provides the Accounts Management manager with abridged information on the many reports generated from various systems.

2. Reports are prohibited from being used for evaluative purposes. Use reports to determine indicators of behavior, and the need for further monitoring and/or assistance. Reports can also be used to assist in determining when increased managerial involvement is warranted.

3. The Managers Assessing Performance (MAP) tool provides a consolidated listing of numerous management information and real-time data reports available for monitoring performance. See _IRM 1.4.16.5.6.3_, _Managers Assessing Performance (MAP)_, for additional information.


**1.4.16.8.1** **(12-27-2022)**

#### eWorkforce Management (eWFM)/Workforce Optimization (WFO) Reports

01. The eWorkforce Management (eWFM)/Workforce Optimization (WFO) software is a comprehensive resource planning and workforce management application that provides automated tools to forecast, schedule, and track call center workload and staffing requirements.

02. The major benefit of eWFM/WFO is to provide centralized scheduling of customer workload accessible by campuses/sites, AM headquarters, and JOC.

03. Site management is responsible for the accuracy of information in the eWFM/WFO database. It is crucial that management ensure eWFM/WFO data is accurate and current for each employee. The site must keep eWFM/WFO current during execution as near to real-time as possible so agent availability can be monitored. This involves general information contained in the employee records as well as scheduling information contained in trial and official schedules. Accurate eWFM/WFO data provides the site, directorate staff, and headquarters a clearer picture of how well AM will meet the forecasted customer workload.

04. eWFM/WFO has two levels of security permissions, which must be requested by submitting a BEARS request:



    - Level One grants direct access to employee records, trial schedules and official schedules. It is generally set for the Telephone Systems staff.

    - Level Two grants direct access only to the official schedules. It is generally set for managers and clerks.


### Note:

Site management will decide security level permissions for each eWFM/WFO user based on the user's assigned duties. Depending on the nature of the changes, updates to eWFM/WFO may be entered directly into eWFM/WFO or provided to the responsible party.

### Note:

Management must provide the Telephone Systems staff with a list of planned training and meetings to determine the impact on meeting the customer workload.

05. eWFM/WFO provides managers with many reports covering virtually all aspects of their call center operations.

06. Most reports give managers flexibility in specifying what information to include and how they want it to appear.

07. Managers can utilize reports to identify trends, review agent statistics and to ensure the accuracy of the eWFM/WFO scheduling data.

08. Some recommended reports are:



    - Agent Productivity Report

    - Agent Check-in Report

    - Agent Schedule Report

    - Weekly Schedule Report


09. The Agent Productivity contains two reports: the **Agent Activity Report,** which shows call statistics for calls handled; and, the **Agent Availability Report,** which shows adherence to schedule. Both reports are available the next business day and are printed daily to see calls handled statistics and to check employee adherence to schedule for the prior day.

10. The Agent Check-in Report can be printed daily or weekly to show employees' schedules for day/week.

11. The Agent Schedule Report shows daily staffing by half hour for each application for day and extended hours.

12. The Weekly Schedule Report shows employees' schedules for the entire week, including scheduled times off the telephone.

13. Additional eWFM/WFO resources and specific AM procedures are posted on this JOC web page.

14. Please refer to IRM 1.4.21.4, _eWorkforce Management eWFM_, for more information.


**1.4.16.8.1.1** **(12-15-2017)**

##### Real Time Adherence (RTA)

1. Real-Time Adherence (RTA) is a companion software to eWFM/WFO. It interfaces with the eWFM/WFO database and Automated Call Distributor (ACD) agent activity. The RTA tool assesses real-time schedule adherence at the agent level. Site management will use RTA to monitor employees' adherence to schedule and take appropriate actions when variances are noted. RTA is a view-only tool and schedule changes must be entered in eWFM/WFO.

2. RTA uses visual alarms based on the user's set thresholds. The alarms fall into two main categories:



   - Activity - Alarms display the telephone state and duration the employee is currently in on the ACD. For example, AVAIL or TALKIN.

   - Schedule - Alarms display variances of the current telephone state as compared to the eWFM/WFO schedule. For example, BSL (begin shift late) or EBL (end break late).


3. RTA captures the visual alarms while the user is logged into RTA and stores the data on the user's computer for a set period (generally 7 days).



### Note:



It is recommended a dedicated computer is running RTA for all employees during all hours of operation to capture alarms in case specific data is needed during times users were not logged in RTA.

4. Users can run the RTA Alarm Summary report to view the stored activity and schedule alarms from the computer where this information is saved.

5. The activity alarms report can be useful to analyze employees' telephone activity for a given call or day or to analyze patterns over several calls or days.

6. The schedule alarms report can be useful to analyze schedule adherence for a given day or range of days.

7. RTA also provides an Employee Detail module to give more details about a given employee. These include:



   - Employee Name

   - Team assignment

   - ACD agent group

   - Current and prior ACD state

   - Last sign on and sign off

   - Current eWFM/WFO schedule for prior, current, and next day


**1.4.16.8.2** **(12-06-2019)**

#### Unified Contact Center Enterprise (UCCE) Reports

1. Aceyus UCCE and/or ETD Reports provide managers call activity statistics on a particular assistor/agent. Some reports are:



   - AHT\_Team\_Agent\_Application Report

   - Agent Call Detail Report


2. The AHT\_Team\_Agent\_Application Report summarizes data for all agents by application and team over a specified period of time. Managers can see:



   - Number and average length of incoming/outgoing calls

   - Total time and percentage of time spent in Talk, Hold, Available, Idle, and Wrap-Up

   - Total Handle Time, Average Handle Time, and Phone Ready Duration


3. Use this report to analyze past and current performance indicators.

4. Use a weekly report for a good indicator to identify trends.

5. The Agent Call Detail Report gives the following information:



1. Each call an agent received by application

2. How call was terminated (caller or agent)

3. Router Call Key (RCK)

4. Talk Time, Queue Time, and Wrap Time durations

5. Whether the call was transferred or terminated


6. UCCE call center historical reports available on ETD and Aceyus are:




| **ETD Reports** | **Aceyus Reports** |
| :-: | :-: |
| AHT\_Team\_Agent\_Application | IRS.STND.CF\_Agent\_Skill\_Group.03 |
| Agent Call Detail | IRS.STND.CF\_Agent\_Team.03 |
| Agent Events Detail | IRS.STND.DD\_Agent\_Team (Multiple Reports) |
| Call Detail Analysis | IRS.STND.HD\_Call\_Type\_Svc\_Call\_Stats |
| Excessive Reason Code | IRS.STND.HI\_Agent\_Skill\_Group (Multiple Reports) |
| Outbound Profile By Team | IRS.STND.HI\_Agent\_Team.(Multiple Reports) |
| Short Call | IRS.STND.HI\_Call\_Type (Multiple Reports)<br> IRS.STND.RT\_Agent\_Skill\_Group (Multiple Reports)<br> IRS.STND.RT\_Agent\_Team (Multiple Reports<br> IRS.STND.RT\_Call Type (Multiple Reports) |


**1.4.16.8.3** **(12-06-2019)**

#### Work Planning and Control System (WP&C)

1. The Work Planning and Control System (WP&C) is one of the major component-systems contained within Integrated Management Planning Information System (IMPIS). It is not designed for daily production control or individual performance evaluation. Additional information regarding IMPIS is found in IRM 3.30.19, _Production Control and Performance Reporting._ A basic feature of the IMPIS system is to set out methods and management tools used for planning, scheduling, controlling, and measuring workloads and resources.

2. The WP&C system generates the following four weekly performance and cost reports to assist in monitoring resources:



   - Managers Report

   - Program Analysis Report

   - Abstract Report

   - Employee Detail Report


3. The Managers Report and the Program Analysis Report use a combination of schedule and actual production and time reporting data to monitor receipts; production volumes; inventory production rates; and staff hour usage. The Abstract Report and the Employee Detail Summary Report provide fiscal type data by organization. Additional information regarding these reports are outlined in the subsections below.

4. An important part in the IMPIS / WP&C processing is the Organization Function Program (OFP) Code. This code is used to identify the:



   - Organization - where work is performed, or hours expended

   - Function - the work action performed

   - Program(s) - to facilitate a pyramid concept of summarizing information


5. One of the driving forces behind the correct posting of performance data is the OFP code. Without correct and timely updates, the WP&C and other systems within IMPIS will not post or will post incorrectly. The data for the WP&C system is received from various sources and includes the volume of work and hours spent for each OFP.

6. The input source of the WP&C data is Form 3081, Employee Time Report. This form is completed by each employee and manager. Managers must ensure the accuracy of the data their employees report on Form 3081, and ensure this data is consistent with other reports, such as the Aspect Agent Utilization Report.



### Note:



If data is incorrectly input in the Single-Entry Time Reporting (SETR) system and posted to WP&C, complete Form 6489, _IPR Adjustments_, and submit to the Reports Unit. A correction to SETR must be made if the error involves an OFP for leave, for example, Annual Leave (AL), Sick Leave (SL), Leave Without Pay (LWOP), Credit Hours, etc.

7. Detailed information on the OFP list structure can be found in IRM 3.30.20, _Organization Function and Program (OFP) Codes._ This IRM contains a list of all currently approved OFP Codes. It also contains specific steps necessary to change and/or modify existing codes and to request new codes.

8. For additional information on the OFPs used in AM, refer to AM OFP Time Reporting on the AM website.


**1.4.16.8.3.1** **(12-17-2018)**

##### Managers Report

1. The Managers Report (PCC 6040) is designed to provide an evaluative tool for managers and analysts to monitor current program receipt patterns, production volumes and rates, inventories, and staff hour usage. This report compares scheduled or projected data with actual production.

2. This report is generated weekly and provides weekly cumulative data. The "period" figures on the report represent information for the week ending date on the report. The "cum" figures represent the total of the weekly data from the beginning of the planning period up to the period ending date of the report.

3. The Managers Report consists of two major sections:



   - **Performance** \- This section includes data from the approved work schedules, various volume reports, and the actual staff hours taken from Form 3081.

   - **Evaluation** \- This section provides analysis of the data presented in the Performance section of the report. It pinpoints and analyzes the differences between the schedule rate and hours. It also gives an indication of what the results will be if current conditions continue. The analysis of this information may be used to determine whether to alter existing conditions to change future results.


4. The report data is provided in OFP sequence. Summaries are provided at program function and department level. For additional information on the OFPs used in AM, see the AM website for OFP Time Reporting (select **"Time Reporting"**) on the AM Technical Tools page.

5. Additional information regarding the Managers Report can be found in IRM 3.30.19.2.6.2, _Managers Report_.


**1.4.16.8.3.2** **(01-01-2015)**

##### Program Analysis Report

1. The Program Analysis Report (PCC 6240) is a weekly report which provides managers with an evaluative tool to manage their operations. It contains basically the same data elements as the Managers Report, but differs in that it is printed in Program, Organization, and Function code sequence.

2. Additional information regarding the Program Analysis Report can be found in IRM 3.30.19.2.6.3, _Program Analysis Report_.


**1.4.16.8.3.3** **(12-06-2019)**

##### Abstract Report

1. The Abstract Report (PCC 4640) is a weekly report used to track hours and costs by fiscal activity and employment category. Period and cumulative information is provided by Department for each week of the quarter.

2. Four reports printed for each Department include:



1. Permanent Employment Category—Hours and cost for all permanent employees within a management activity

2. Seasonal Employment Category—Hours and cost of all seasonal employees within a management activity

3. Management Activity Summary—Total of the Permanent and WAE / Seasonal Category hours within a management activity



      ### Example:



      The permanent hours of 75,083 added to the WAE hours of 78,386 equals the total hours of 153,469 for Management Activity 21

4. Operation Summary—Total hours in the Operation. This includes all management activities within the Operation



      ### Example:



      Organization Code 31000 can be funded by Management Activity 38, 21 and 22


3. Other pages may be included in reports at site option by using the Temporary Category Code. This code is used to obtain a more detailed breakdown of the above categories.



### Example:



The Temporary Career/Career-Conditional Category could be separated by new and returning WAEs.

4. Additional information regarding the Abstract Report can be found in IRM 3.30.19.2.6.4, _Abstract Report_.


**1.4.16.8.3.4** **(01-01-2015)**

##### Employee Detail Summary Report

1. The Employee Detail Summary Report (PCC 4240) is a weekly report which provides managers with data for tracking detailed employees between operations/departments and fiscal activities.

2. The report is printed in organization sequence. A page is generated for period and cumulative data, as well as pages for campus summaries. Each page lists the hours and costs (regular and overtime) for employees (permanent and temporary) detailed "To" and "From" an organization by operation/department and Program Activity Code. This report is used to track hours and costs when employees charge hours (detail their time) either to a different operation/department or to OFPs with a different Program Activity Code (PAC) than their home organization and home PAC.

3. Additional information regarding the Employee Detail Summary Report can be found in IRM 3.30.19.2.6.6, _Employee Detail Summary Report_.


**1.4.16.8.3.5** **(01-02-2012)**

##### Cum File Leveled Performance Report

1. The Cum File Leveled Performance Report (PCA 0743) is a useful tool for front line managers. This shows the weekly Form 3081 data for each campus that carries a period (weekly) and cumulative (plan period) figure for each 5th digit organization.

2. The following information is provided on the report:



   - Volume

   - Hours

   - Prod Rate

   - Documents Reviewed

   - Documents in Error

   - Error Rate


### Note:

Performance adjustment corrections are not reflected in this report.

**1.4.16.8.3.6** **(12-17-2018)**

##### Accounts Management Inventory Reports (AMIR)

1. Accounts Management Inventory Reports (AMIR) is a massive reporting effort that is substantially manual. Information from Case Control Activity System (CCA) inventory reports are keyed into Excel spreadsheets and rolled up by business analysts. The results are sent each Monday (via e-mail) to a central point where national reports are prepared for display on the Intranet.

2. Reporting requirements are owned by the Headquarters Performance Tracking in JOC. The inventory data will be entered in each AM campus' AMIR in Excel format as provided by the National AMIR Coordinator. This data, which encompasses several organizational areas within the AM campus, is input based upon organizational code responsibility. Additional information on the AMIR can be found in IRM 3.30.124.6, _Accounts Management Inventory Report (AMIR) - General._

3. The AM inventories to be reported on the AMIR are found in IRM 3.30.124.6.1, _Accounts Management Inventory Report (AMIR)_.


**1.4.16.8.3.7** **(04-19-2022)**

##### Workload Inventory Tracking System (WITS)

1. Update the site Referral Report in the Joint Operations Center (JOC) Workload Inventory Tracking System (WITS) folder by COB Monday or Tuesday if Monday is a holiday. Use the CCA 4242, IDRS Inventory Control Report to gather referral data (category codes PPCO, TWRA, TWRC, TWRO, and TWRR) to post into the Workload Inventory Tracking System (WITS) folder located on Control-D or Business Objects.

2. The data needed for the sites’ WITS template is located WITS template. Each folder includes Fiscal Year (FY) folders containing site templates. Open the template for the current year and update it with the Control-D or Business Objects data.

3. The Receipts, Closures, Transfers-Out, and Ending Inv come directly from the CCA 4242, Inventory Control Report. Ensure the current week’s beginning inventory matches the prior week’s ending inventory. The Phys. Count ADJ. column is a calculated field equal to: Ending Inv - Beginning INV - Receipts + Closures + Transfers Out. Overage cases are from the CCA 4242 and are cases 30 days and older.



### Note:



The beginning inventory formula will not populate until the Week Ending Date is less than the date in cell A2. In the scenario below, the current date is 02/11/2022. The template should be completed up to the most current week ending date, 02/05/2022. The Ending Inventory of 1,500 will carry over to the beginning inventory column for week ending 02/12/2022 on the following Monday. **Do not change the site template name or file extension. All templates are linked to a master file.**





**Figure 1.4.16-1**

![This is an Image: 35344001.gif](https://www.irs.gov/pub/xml_bc/35344001.gif)





> CCA 4242, Inventory Control ReportThis is a screen shot of a CCA 4242 Inventory Control Report.







[Please click here for the text description of the image.](https://www.irs.gov/media/129251 "")


**1.4.16.8.4** **(01-02-2012)**

#### Account Management Services (AMS)

1. Account Management Services (AMS) provides a common user interface that allows users to update taxpayer accounts, view history and comments from other systems and access a variety of case processing tools without leaving AMS.

2. AMS functionalities include inventory management, next case delivery, nationwide history and follow-ups, immediate print capabilities to fax to taxpayer, generation of electronic referrals and inventory management.

3. AMS provides several online forms for referring cases to other areas as prescribed by the IRM. The most commonly used form in AM for routing these cases is the on-line e-4442, _Inquiry Referral_.

4. The AMS system provides AM managers with access to many reports. The AMS Reports tool allows the manager to generate pre-defined management reports based on data (e.g., e-4442 inventory) available in AMS such as Inventory Reports (e.g., e-4442, AMRH, Entity, and Statute); Case Reports such as the TIN Summary Reports; and Miscellaneous reports such as their Group Profile report.

5. For additional information regarding AMS, refer to the AMS End User Support website.


**1.4.16.8.5** **(04-19-2022)**

#### Control-D

1. Control-D WebAccess (CTDWA) is Web Access software that allows viewing of reports electronically. Control-D reduces the print output currently being produced at the ten AM campuses and allows faster access and greater report management for users to their respective report files.

2. The reports are made available to the users upon logging in to the Control-D WebAccess server. This action is necessary to ensure employees have access to the workload.

3. To access Control-D, users must submit a BEARS request.

4. The most common reports on Control-D used by AM are the Overage Inventory Listings/Reports, which are as follows:



   - CCA 4243, IDRS Automated Age Listing/Report

   - CCA 4242, IDRS Inventory Control Report

   - CCA 4244, IDRS Multiple Case Control Listing/Report



     ### Note:



     For additional information using the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_; _IRM 1.4.16.5.6.1_, _CCA 4243 - IDRS Overage Report_; and _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Report._


Basic instructions for filtering reports on Control-D:



1. Access Control-D Web Access Server at Control-D MCC or Control-D TCC.

2. Enter in the Login window:


       Username: (Automatically generated)


       Password: Enter your password


       Host: Select SYSL, SYSK, or SYSM from the drop-down menu. For additional assistance refer to: Control-D Help



      ### Note:



      SYSL sites: Atlanta, Cincinnati, Fresno, Kansas City and Memphis





      ### Note:



      SYSM sites: Andover, Austin, Brookhaven, Ogden, and Philadelphia




      **Filter**: Click on the filter box to display the check mark. Press the Enter key or click on Login




      **Figure 1.4.16-2**

      ![This is an Image: 35344002.gif](https://www.irs.gov/pub/xml_bc/35344002.gif)





      > This is a screen shot of Control-D log on screen.







      [Please click here for the text description of the image.](https://www.irs.gov/media/129256 "")

3. Enter the following information in the Filter Report List:


       Filter Name: (No entry required.)


       Include filtered reports from: Select Current folder only from the drop-down menu

4. Enter the following under the Report Parameters tab:


       Report name: (optional) Enter the name of the report. If you enter a Report Name, then don’t enter the same name in the Job Name field below; or


       Job name: Enter CCA\* -or the CCA report number if known

5. Click one of the following In the Report Status section:


       Active for the current data; or


       Migrated for historical data (to retrieve prior report data if the report is not showing)


       Press the Enter key or click the Apply button


       Verify the Run Date before selecting your report



      **Figure 1.4.16-3**

      ![This is an Image: 35344003.gif](https://www.irs.gov/pub/xml_bc/35344003.gif)





      > This is a screen shot of the Filter Report Screen.







      [Please click here for the text description of the image.](https://www.irs.gov/media/351856 "")


5. ARS Self Service is intended so that employees can ask to be added and removed from domain groups. To request or remove access to the WITS folder, follow the instructions in the ARS Self Service User Guide. The request is now submitted. The folder owner will receive an email to approve or reject. The user will NOT receive acknowledgement of submission. Once the owner approves (or rejects), the requestor\\user will receive an automated email from “ARS@irs.gov” with information and/or instructions.


**1.4.16.8.6** **(12-06-2019)**

#### Integrated Data Retrieval System (IDRS) Reports

1. IDRS produces varied reports for purposes of audit trail information, duplicate controls, overage cases, etc. Managers must know the purpose of these reports and the necessary action to take when received. The reports identified below are some, but not all of the reports generated from IDRS.

2. Case Control Activity System (CCA) inventory reports (introduced above) are generated from IDRS. The following are the most common CCA inventory reports used by AM:



   - CCA 4243, _IDRS Automated Age Listing/Report_

   - CCA 4242, _IDRS Inventory Control Report_

   - CCA 4244, _IDRS Multiple Case Control Listing/Report_



     ### Note:



     For additional information using the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_.


3. **CCA 4243, _IDRS Automated Age Listing/Report_**


    Generated weekly on the CTDWA, this report contains all cases controlled to an IDRS employee number. Each AM campus has the capability of generating an aged list by a specific category. For example, an analyst may want to have a report that lists all cases of 180 days old or a report that lists all taxpayer inquiries assigned to a specific unit/group/team. The CCA 4243 can be used to:



   - Identify the age of IDRS cases assigned to a unit or team at an AM campus

   - Identify specific cases for review

   - Monitor the size of the employee's inventory

   - Set overage closure expectations

   - Identify potential management problem cases


### Note:

For additional information using the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_, and _IRM 1.4.16.5.6.1_, _CCA 4243 - IDRS Overage Report._

4. **CCA 4242, _IDRS Inventory Control Report_**


    This report is also generated weekly on the CTDWA. It summarizes inventory receipts, closures, and age by category. It identifies the controlled inventory in the entire operation by category. The CCA 4242 can be used to:



   - Identify the weekly receipts and closures under each category

   - Identify the number of cases aged upon receipt

   - Monitor the number of cases and age of inventory in each category to determine if resource changes required


### Note:

Additional information in the CCA 4242 report can be found in IRM 1.4.22.11.2, _CCA 42-42 - IDRS Inventory Control Report_.

5. **CCA 4244, _IDRS Multiple Case Control Listing/Report_**


    This report is generated weekly in the CTDWA and identifies cases with an open control base on the same TIN by two or more employees. The CCA 4244 identifies the employee IDRS number, tax year, and category for the duplicate controls.



### Note:



For additional information using the CCA 4243 and CCA 4244 for monitoring and reviews, see _IRM 1.4.16.5.6_, _Monitoring the Automated Age Listing (AAL)_, and _IRM 1.4.16.5.6.2_, _CCA 4244 - IDRS Multiple Case Report._


**1.4.16.8.7** **(03-17-2021)**

#### Enterprise Telephone Data (ETD) Warehouse

1. The Enterprise Telephone Data (ETD) Warehouse is a web-based data warehouse available on the Intranet. It is the official source for all data related to Toll-Free measures and indicators.

2. ETD allows managers to pull data and create reports, charts, or export to Excel.

3. Use ETD to query for current and historical data regarding:



   - Call delivery

   - Demand

   - Business measures


4. Use ETD reports to monitor and track Average Handle Time (AHT). Coordinate with System Analyst(s) to generate the reports and data needed to address opportunities for improvements. AM Center and Remote sites phone applications should focus on time and resources appropriately:



   - Identify and coach employees who require assistance

   - Improve Targeting, Research, and Communication Skills

   - Improve Talk Time, Hold Time, and Wrap Time (focus coaching on specific actions over a specific week)


### Note:

System Analysts track/archive AHT data using ETD and Aceyus reports per IRM 1.4.21.2.5 and IRM 1.4.21.2.5.1.

Use contact recordings, available in Verint to listen to calls to identify employees’ AHT skills and needs. Coordinate with System Analysts if help is needed listening to calls with Functional Training Coordinators (FTCs) to address skill-up needs. Verint can filter calls by employee, application, call length, and media (audio and/or screen capture). Focus on time and resources appropriately as listed above.


### Note:

Don’t perform evaluative performance reviews for calls selected to identify/support coaching opportunities.

**1.4.16.9** **(09-26-2023)**

### EMPLOYEE AND BUILDING SECURITY RESPONSIBILITIES

1. You must use the standard emergency closing procedures, as provided for all sites, for weather and other emergency situations, such as threats.

2. Employees in AM follow threat and other emergency procedures outlined in IRM 21.1.3.10, _Safety and Security Overview_; and on the EMERGENCY page in SERP.

3. You must ensure employees follow the procedures for threats received on the telephone (e.g., bomb threats, suicide threats, or other threats). Any threat incidents received on the telephone will involve the telephone assistor clicking the **EMERGENCY** toolbar button on the Finesse desktop application. This action records the conversation and alerts both the manager and the Systems Administrator (SA) that an emergency exists at the telephone assistor's workstation. The supervisors will receive an audible tone and a pop-up alert will appear at the bottom right of their Cisco Finesse Supervisor Desktop (or at the bottom right of their screen if the browser is minimized). It will also be listed as an Emergency Event within the Events tab.

4. Emergency call procedures are outlined in:



   - IRM 21.1.3.10.3, **Assault/Threat Incidents/Abusive Practitioners**

   - IRM 21.1.3.10.7, **Bomb Threats**

   - IRM 21.1.3.12, _Suicide Threats_


5. You **must** obtain the following information for tracing the call:



   - Name of employee

   - Name of TP or POA, if known

   - Date/start time of the call

   - Router Call Key if available from Verint or ETD


6. For applicable safety/security incidents, you will contact the Treasury Inspector General for Tax Administration (TIGTA)/Security. See the Emergency and Safety page on the Employee Resource Center (ERC).

7. Send an email to alert your local telephone systems staff of the need to identify the recorded call file for TIGTA review. Copy the TIGTA contact in on the email. TIGTA should complete the Form 13817, Request for Downloaded Contact Interaction, and provide that to the local Telephone Systems Staff, who will be able to locate and download the recording if it’s available.


**1.4.16.10** **(12-06-2019)**

### Integrated Talent Management (ITM)

1. The Integrated Talent Management (ITM) is an automated training system. It allows the employee and manager to be directly engaged in planning, communicating, and coordinating training and development activities online.

2. ITM offers on-line courses, lists all scheduled classroom-training events, identifies assigned technical and mandatory (e.g., Mandatory Briefings) curriculum requirements, and tracks completion of assigned curriculum and online courses. In addition, it maintains employee learning and teaching histories, and it is the official system of record for IRS training.

3. As a manager, you can monitor and view your employees' ITM items and curricula. The alignment of your employees shown in ITM is based on information provided weekly by HR Connect into ITM. A Personnel Action Request (PAR) aligns employees under you as their manager.



### Note:



The accuracy of this information is important because ITM sends a system-generated e-mail to your employee and you, as the manager, regarding scheduled training for the employee.


**1.4.16.11** **(03-04-2024)**

### MANAGING SEASONAL EMPLOYEES: RELEASE AND RECALL

01. Seasonal employees work during high workload volume periods as specified in their seasonal employment agreement each year. A seasonal agreement, Form 8506, _Seasonal Employment Agreement_, must be signed annually by each seasonal employee. All sites must ensure the language used in the agreements conforms to the HQ RMT guidance. See the Personnel Action Request Guide for additional information.

02. The Form 8506 is filed in the employee's Employee Drop File (EDF) within the first week of employment or return to duty. The seasonal agreement outlines the stated work season for the employee and this season must be specific on the agreement, including the specific months.

03. Seasonal Probationary periods are defined as one calendar year (12 months) beginning with the seasonal employee’s EOD. This is regardless of the amount of time worked during the 12-month period.

04. Newly Hired Seasonal employees cannot be held accountable for their performance under their critical job elements (CJE) until on their performance plan for 60 days. Managers must provide all new hires their Performance Plans and CJE document as early as possible. When providing performance feedback to newly hired employees, during the first or second feedback sessions, discuss CJEs in detail to ensure the employees' understanding.

05. Seasonal employees are subject to being periodically released from and recalled to work. All employees subject to release recall are ranked on a Release/Recall List and either released or recalled based on their position on this list. The actual determination of the release/recall roster will be made by the type of appointment, IRS Enter on Duty Date (EOD), and the employee possessing the skills needed.

06. Managers should check SETR to make sure returning seasonal employees have time posted and should also remind returning seasonal employees to make sure their direct deposit information is still current. If not, changes should be made as soon as possible to ensure employees receive their pay timely.

07. Managers should track/monitor promotions (salary grade increases) for seasonal employees to ensure promotions are processed timely.

08. When releasing and recalling Seasonal Employees, Personnel Action Requests (PARs) must be input timely and appropriately. PARS should be submitted**two weeks** prior to the effective date to ensure timely processing. Effective dates are generally the beginning of a pay period. Form 8506 must be signed annually by each seasonal employee.

09. Extending a seasonal employee in pay status is accomplished by use of Form 8506 or Form 8506-A, signed by both management and the employee, which includes the reason for extending the length of season. This agreement is voluntary on the part of the employee. They may choose to enter into non-pay status after their original seasonal employment agreement period is concluded, with no adverse action; but if work is available, this may affect any unemployment benefits.

10. For additional information regarding seasonal employees in non-pay status or return to duty, see Form 14061, _Responsibilities of Managers of Seasonal Employees,_ and Document 12686, _Responsibilities of Seasonal Employees_.

11. Prepare appraisals using Form 6850, _Bargaining Unit Performance Appraisal and Recognition Request_. Refer to the 2022 National Agreement for information on resolving tie scores and for specific details regarding the release/recall process.

12. Release/Recall must be accomplished in accordance with the 2022 National Agreement, Article 14, _Release/Recall Procedures_.


**1.4.16.12** **(05-28-2025)**

### MANAGING EMPLOYEES WITH DISABILITIES

1. As a manager, you must ensure your employees with disabilities are equipped with the tools and accommodations to perform their jobs. There are procedures in place to assist you in accomplishing this task.

2. If an employee with a disability needs an accommodation, you should contact the Reasonable Accommodation (RA) Coordinator in your area for assistance. RA Coordinators are located through the Accessibility page.:

3. Additional information regarding reasonable accommodations can be found on the Reasonable Accommodation Process page.

4. In addition, your employee may need assistance in accessibility-type issues, such as, ordering reference or training materials in alternative media. Your Local Accessibility Coordinator (LAC) serves as your main point of contact to assist managers and employees with disabilities in the day-to-day accessibility issues. The Local Accessibility Coordinators report to the Chief Accessibility Coordinator.

5. The Office of the Chief Accessibility Coordinator (CAC) was established to assist Management with inquiries concerning accessibility; adaptive equipment/software compatibility and usability issues; reasonable accommodation concerns; and employees with disabilities performance issues to name a few. The CAC has program oversight for the Lions World Services for the Blind (LWSB) and the LAC program. The CAC works in close partnership with the Equal Employment Opportunity Commission (EEOC), Reasonable Accommodation (RA) Coordinators, Alternative Media Center (AMC), and Information Resources Accessibly Program (IRAP).

6. ITM Course 33788, _Managing Employees with Disabilities_, is available to all Managers and LACs via ITM. This course offers a comprehensive overview of the various facets involved in supervising employees with disabilities such as disability etiquette guidelines, the reasonable accommodation process, hiring, and various resources available to all IRS managers. For additional information, visit the Accessibility website.

7. Other useful resources regarding managing employees with disabilities include:



   - IRM 1.4.1, _Management Roles and Responsibilities_

   - IRM 1.4.20.24.1, _Adaptive Equipment and Other Accommodations - IRAP Services_

   - IRM 1.1.13.2.5.5, _Accessibility Office_

   - IRM 6.410.1, _Learning and Education Policy_


8. In addition, the following websites provide useful information regarding managing employees with disabilities:



   - LAC Program Resource Page

   - Information Resource Accessibility Program (IRAP)

   - Alternative Media Center (AMC)

   - [Job Accommodation Network (JAN)](https://askjan.org/)


**1.4.16.13** **(09-26-2023)**

### USEFUL WEBSITES

1. The following websites are frequently used by AM managers:



   - Accounts Management

   - Organization, Function, and Program (OFP) Codes - Time Reporting

   - FY25 Program Letter and Operating Guidelines

   - Customer Service AgreementCAS AM Paper Inventory Reports

   - Embedded Quality Review System

   - CER SharePoint

   - Servicewide Electronic Research Program (SERP)

   - iManage



     ### Note:



     Must be coded as a Manager in HR Connect to access this website.

   - New Manager Orientation Support Center

   - National Treasury Employee Union (NTEU)

   - Time and Attendance Quick Reference - Memphis Payroll Center Timekeeping Branch

   - Managers Assessing Performance (MAP) Tool



     ### Note:



     Must have permissions to access this tool. Access permissions to this tool follow HR Connect par actions and is available to all AM management officials. If a manager returns or moves to a non-management position, access to the MAP will be removed.

   - Labor Relations Contact Guide:

   - SETR Alerts


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-016#addtoany "Show all")

A2A