---
url: "https://www.irs.gov/irm/part1/irm_01-001-011"
title: "1.1.11 Chief, Communications and Liaison | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-011#main-content)

- 1.1.11  [Chief, Communications and Liaison](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922624176)
  - 1.1.11.1  [Chief, Communications and Liaison](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922618064)
  - 1.1.11.2  [Office of Communications](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922060672)
    - 1.1.11.2.1  [Employee Communications Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922054320)
    - 1.1.11.2.2  [Social Media Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922634880)
    - 1.1.11.2.3  [Planning and Content Development Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922629264)
    - 1.1.11.2.4  [Media Relations Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922555600)
    - 1.1.11.2.5  [Visual Education and Communications Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922550672)
    - 1.1.11.2.6  [Intranet and Digital Services Support Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922544240)
  - 1.1.11.3  [Office of Legislative Affairs](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746949544368)
    - 1.1.11.3.1  [Legislation and Reports Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746949540896)
    - 1.1.11.3.2  [National Congressional Affairs Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746949534928)
    - 1.1.11.3.3  [District Congressional Liaison Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922571872)
  - 1.1.11.4  [National Public Liaison](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922566496)
    - 1.1.11.4.1  [Business Stakeholder Relationship Management Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922562320)
    - 1.1.11.4.2  [Liaison and Tax Forum Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922472960)
    - 1.1.11.4.3  [Professional Stakeholder Relationship Management Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922465664)
  - 1.1.11.5  [Tax Outreach, Partnership and Education Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746922458608)
  - 1.1.11.6  [Stakeholder Liaison Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746949523776)
  - 1.1.11.7  [Management and Support Services Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746949517120)
  - 1.1.11.8  [Management and Finance Branch](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746949511184)
  - Exhibit  1.1.11-1  [Office of Communications and Liaison](https://www.irs.gov/irm/part1/irm_01-001-011#idm139746949505824)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 11. Chief, Communications and Liaison

* * *

## 1.1.11 Chief, Communications and Liaison

#### Manual Transmittal

February 05, 2020

#### Purpose

(1) This transmits revised IRM 1.1.11, _Organization and Staffing, Chief, Communications and Liaison._

#### Material Changes

(1) This IRM has been revised to provide current organizational structure for the Communications and Liaison (C&L) Functional Division.

#### Effect on Other Documents

This supersedes IRM 1.1.11, Chief, Communications and Liaison, dated February 12, 2015.

#### Audience

All Operating and Functional Divisions

#### Effective Date

(02-05-2020)

Signed by Terry L. Lemons

Chief, Communications and Liaison

**1.1.11.1** **(02-05-2020)**

### Chief, Communications and Liaison

1. The mission of Communications and Liaison (C&L) is to promote an understanding of the Service's corporate mission and goals by building and maintaining strong relationships with key stakeholders. Key stakeholders include legislative, media, business, professional and internal groups. C&L also works with these stakeholder groups to ensure that taxpayers understand and meet their tax responsibilities.

2. The **Chief, Communications and Liaison** reports to the Commissioner of IRS and is responsible for the strategic planning, management, direction, and execution of the full range of activities related to the Communications and Liaison organization. This includes four key areas of focus: outreach, legislative affairs, employee communications and external communications. The Chief area is organized into seven functions:



1. Office of Communications

2. Office of Legislative Affairs

3. National Public Liaison

4. Stakeholder Liaison

5. Tax, Outreach, Partnership and Education

6. Management and Support Services

7. Management and Finance


### Note:

An organization chart is provided at the end of this IRM.

3. To accomplish the mission, the Chief, Communications and Liaison:



1. Develops and implements the servicewide strategy to communicate the IRS corporate vision, mission and goals with IRS employees and external stakeholders.

2. Serves as the central coordinating point that enables the IRS to achieve its legislative objectives.

3. Keeps the Commissioner and IRS officials apprised of significant congressional and media activities.

4. Represents the Commissioner to external organizations and other federal agencies on policy matters related to tax administration.

5. Manages relationships with national stakeholder organizations, business and professional associations with an interest in tax administration.

6. Develops and implements C&L measures that balance customer satisfaction, employee satisfaction and business results.


**1.1.11.2** **(02-05-2020)**

### Office of Communications

1. The mission of the Office of Communications is to develop professional communications services and products for our employees and external customers to support the overall IRS mission and effective tax administration.

2. The **Director, Office of Communications**, reports directly to the Chief, Communications and Liaison, and is responsible for planning, managing, directing and executing servicewide communications and all media relations. The six branches that make up the Office of Communications are:



   - Employee Communications,

   - Media Relations

   - Social Media,

   - Planning and Content Development,

   - Intranet and Digital Services Support

   - Visual Education and Communications


3. The Associate Director, Office of Communications, reports directly to the Director, Communications and Liaison, and is responsible for planning, managing, directing and executing employee communications.


**1.1.11.2.1** **(02-05-2020)**

#### Employee Communications Branch

1. The **Chief, Employee Communications Branch**, reports to the Associate Director, Office of Communications. The Branch:



1. Develops and implements the servicewide strategy to communicate the IRS corporate vision, mission and goals.

2. Manages strategic communications plans in support of servicewide strategies and Commissioner-level initiatives.

3. Develops servicewide strategies, messages, products and measurement systems.

4. Develops servicewide standards and guidelines.

5. Coordinates strategies, messages and products with the operating and functional divisions.

6. Supports communication needs of business unit executives and key agency projects.

7. Researches, identifies and disseminates the best internal communications practices throughout the IRS.


**1.1.11.2.2** **(02-05-2020)**

#### Social Media Branch

1. The **Chief, Social Media Branch**, reports to the Director, Office of Communications. The Branch:



1. Develops and coordinates a servicewide content strategy for IRS corporate social media channels.

2. Defines overall standards and policy for official social media channels.

3. Provides administrative oversight for all IRS corporate social media channels, including privacy assessments, terms of service agreements and metrics.

4. Partners with channel managers across the Service to ensure consistent content timing and branding.

5. Oversees the efforts of the Social Media Working Group in the development of new channels and policies.

6. Participates in the Customer Early Warning System (CEWS) to identify and elevate Service issues discovered through social media channels.


**1.1.11.2.3** **(02-05-2020)**

#### **Planning and Content Development** Branch

1. The **Chief, Planning and Content Development Branch**, reports to the Director, Office of Communications. The Branch:



1. Plans, develops and implements overall communications strategies in support of the key agency initiatives

2. Develops and coordinates the clearance and issuance of various key agency initiatives and programs communication products, including news releases, fact sheets, tax tips, numerous IRS.gov web pages and web texts, and outreach presentation materials.


**1.1.11.2.4** **(02-05-2020)**

#### Media Relations Branch

1. The **Chief, Media Relations Branch**, reports to the Director, Office of Communications. The Media Relations Branch serves as a single point of contact for national and local media, national stories or National Headquarters issues. The Branch:



1. Develops and implements overall media strategy in support of the IRS Commissioner, the Deputy Commissioners, and all operating and functional divisions.

2. Serves as the IRS single point of contact for all national and local media.

3. Coordinates all strategies with operating and functional divisions, and provides guidance as necessary.

4. Handles media requests by directly interacting with national and local media and coordinating responses with operating and functional divisions or senior executives.


**1.1.11.2.5** **(02-05-2020)**

#### Visual Education and Communications Branch

1. The **Chief, Visual Education and Communications Branch**, reports to the Director, Office of Communications. The Branch:



1. Develops and implements a servicewide broadcasting strategy to communicate the corporate vision, mission and goals.

2. Supports Operating and Functional Division executives in developing and implementing strategies to communicate servicewide messages and employee information.

3. Provides technical support to the operating and functional divisions in the design, development and delivery of information and training for employees and taxpayers.

4. Provides broadcast and video communications technical expertise to support external and internal communications strategies and messages.

5. Develops servicewide broadcast communications standards and guidelines.

6. Researches, identifies, and adopts best broadcast communications practices and technology.

7. Manages the servicewide Video Editorial Board approval process to ensure efficient and effective use of video.


**1.1.11.2.6** **(02-05-2020)**

#### **Intranet and Digital Services Support Branch**

1. The **Chief, Intranet and Digital Services Support Branch**, reports to the Director, Office of Communications. The Branch:



1. Oversees the IRS intranet to include developing standards and guidelines

2. Leads/manages the web content/technology governance board

3. Determines roles/responsibilities for supporting the web communication process

4. Establishes service agreements and service providers

5. Controls the portal page and posting content to the home site


**1.1.11.3** **(02-05-2020)**

### Office of Legislative Affairs

1. The Office of Legislative Affairs supports the IRS mission by overseeing IRS interactions with Congress. Its mission is to oversee IRS relationships with members of Congress and their staffs, serve as the central coordinating point that enables the IRS to achieve its legislative objectives and assist the IRS in ensuring continued congressional support of organizational programs and goals.

2. The **Director, Office of Legislative Affairs**, reports to the Chief, Communications and Liaison, and is responsible for planning, managing, directing, and executing the efforts of the Office, and for keeping the Chief, the Commissioner and other top officials apprised of significant congressional activities. The three branches that make up the Office of Legislative Affairs are Legislation and Reports, National Congressional Affairs, and District Congressional Liaison.


**1.1.11.3.1** **(02-05-2020)**

#### Legislation and Reports Branch

1. The **Chief, Legislation and Reports Branch**, reports to the Director, Office of Legislative Affairs. The Branch:



1. Tracks selected pending tax and non-tax legislation to determine administrative implications for taxpayers and the IRS, and recommends changes to reduce burden.

2. Works with operating and functional divisions to prepare complexity analyses of proposed tax legislative changes for inclusion in the congressional tax writing committees' bill reports as required under the Internal Revenue Service Restructuring and Reform Act of 1998.

3. Works with operating and functional divisions to develop agency legislative proposals that enhance tax administration.

4. Participates in Filing Season Readiness activities to provide updates on legislation that may impact the upcoming filing season.

5. Manages, coordinates and tracks the actions the IRS takes to implement legislation that impacts the IRS.

6. Manages, coordinates and tracks the annual submission of federally mandated reports to Congress.


**1.1.11.3.2** **(02-05-2020)**

#### National Congressional Affairs Branch

1. The **Chief, National Congressional Affairs Branch**, reports to the Director, Office of Legislative Affairs. The Branch:



1. Manages IRS relationships with members of Congress and staff, as well as the committees of jurisdiction.

2. Coordinates, in conjunction with the operating and functional divisions, the preparation of testimony and briefing materials for congressional hearings. Determines best strategy for witness preparation based on substance of hearing and ongoing dialogue with committee staff.

3. Manages the responses to questions submitted to the IRS witness after each hearing (Questions for the Record), which includes assigning the questions to the appropriate office, managing clearance and enforcing deadlines. In addition, this Branch posts the responses to the questions on the Legislative Affairs website once they are cleared through Treasury and OMB and returned to the committee.

4. Researches hearing issues and lines of inquiry, and performs follow-up on transcripts and questions for the record, including coordinating correction and posting materials to the Legislative Affairs website.

5. Develops outreach efforts to provide congressional offices with information and materials on tax administration issues, including the dissemination of congressionally-mandated reports.

6. Identifies the need for, and coordinates critical meetings between the Commissioner of IRS, other IRS officials, and members of Congress, for the purpose of addressing key issues and for continued positive relationship management.

7. Serves as the primary point of contact for congressional phone calls, and is responsible for the timely research and response to congressional offices.


**1.1.11.3.3** **(02-05-2020)**

#### **District Congressional Liaison Branch**

1. The **Chief, District Congressional Liaison Branch**, reports to the Director, Office of Legislative Affairs. The Branch:



1. Manages the Congressional Affairs Program, which provides oversight and direction to District Liaisons, field executives and staff in helping to establish relationships with members of Congress and the delegations they serve.

2. Develops outreach efforts to provide local congressional offices with information and materials on tax administration issues.

3. Identifies the need for, and coordinates critical meetings with local IRS officials, and members of Congress, for the purpose of addressing key issues and continued positive relationship management.

4. Serves as the primary point of contact for local congressional staff, and is responsible for the immediate research and response to congressional inquiries.


**1.1.11.4** **(02-05-2020)**

### National Public Liaison

1. The **Director, National Public Liaison (NPL),** reports to the Chief, Communications and Liaison, and serves as the Commissioner's representative in dealing with external organizations and other federal agencies on an extensive range of issues, including high level policy matters related to tax administration. NPL also serves as the primary point of contact for coordinating the Commissioner’s speaking engagement requests

2. The mission of National Public Liaison is to build and strengthen IRS stakeholder relationships that promote effective tax administration by creating opportunities for communication and addressing issues of mutual concern.

3. The three branches that make up National Public Liaison are Business Stakeholder Relationship Management, Liaison and Tax Forum, and Professional Stakeholder Relationship Management.


**1.1.11.4.1** **(02-05-2020)**

#### Business Stakeholder Relationship Management Branch

1. The **Chief, Business Stakeholder Relationship Management Branch**, reports to the Director, National Public Liaison. The Branch:



01. Develops the strategic direction of the external liaison program, which includes national tax professional, payroll, electronic commerce, volunteer taxpayer assistance and other associations/organizations.

02. Ensures all current national public liaison relationships with business-oriented stakeholders are maintained and enhanced, and pursues new relationship management initiatives as appropriate.

03. Maintains an effective communications program to keep stakeholders informed of IRS initiatives, policies, procedures and regulations.

04. Solicits input and ideas from national stakeholders to identify emerging national issues, makes internal and external customers aware of such issues and tracks follow-up on those issues.

05. Identifies, recognizes and develops new national level partnering opportunities.

06. Responds to national stakeholder requests and facilitates resolution of stakeholder issues.

07. Manages the National Public Liaison site and the Corporate Calendar on the IRS Intranet; manages the Tax Pro page on IRS.gov.

08. Identifies information sharing opportunities between Service advisory councils such as Electronic Tax Administration Advisory Committee (ETAAC) and the Taxpayer Advocacy Panel (TAP). Actively engages these groups in joint projects.

09. Participates in Filing Season Readiness Activities and servicewide communications efforts in an effort to improve partnering and enhance tax administration..

10. Creates opportunities for external stakeholders to share their vision, goals and recommendations on tax policy issues with all members of the senior leadership team.

11. Creates and produces articles of interest for IRS employee publications and external stakeholder organization newsletters.


**1.1.11.4.2** **(02-05-2020)**

#### Liaison and Tax Forum Branch

1. The **Chief, Liaison and Tax Forum Branch** reports to the Director, National Public Liaison. The Branch:



1. Plans, coordinates and manages the activities of the Internal Revenue Service Advisory Council (IRSAC).

2. Provides liaison avenues for the IRSAC to other advisory and decision making groups, such as the IRS Oversight Board.

3. Participates in cross-functional and cross-divisional councils, task forces and working groups.

4. Plans and implements the IRS Nationwide Tax Forum program. The Forums consist of several multi-day events across the nation. The primary focus is directed towards educating all types of tax practitioners.

5. Coordinates the involvement of the Commissioner of IRS, all IRS operating and functional divisions, other federal agencies, state and local agencies and national stakeholder organizations in the Forums.

6. Accredits the Forums with the National Association of State Boards of Accountancy (NASBA), the Office of Professional Responsibility (OPR) and other accounting bodies as needed.

7. Manages Nationwide Tax Forums Online.

8. Manages the Forums in a fiscally responsible manner.

9. Provides year-end review and analysis of Forum effectiveness to IRS operating and functional divisions.


**1.1.11.4.3** **(02-05-2020)**

#### **Professional Stakeholder Relationship Management Branch**

1. The **Chief, Professional Stakeholder Relationship Branch** reports to the Director, National Public Liaison. The Branch:



1. Develops and maintains relationships with national tax professional associations, such as the American Institute of CPAs, National Association of Enrolled Agents, American Bar Association Tax Section, Tax Executives Institute, and others.

2. Plans, coordinates and manages the NPL Monthly Practitioner Meeting in conjunction with the BSRM Branch.

3. Plans, coordinates and manages the activities of the Electronic Tax Administration Advisory Council (ETAAC).

4. Provides liaison avenues for the ETAAC to other advisory and decision-making groups, such as the Security Summit.

5. Provides for information sharing between advisory councils and identifies opportunities for joint projects for all advisory councils that IRS administers. These councils include the Art Advisory Council, ETAAC, the IRS Advisory Council (IRSAC), and the Taxpayer Advocacy Panel (TAP).

6. Maintains an effective communication program including the weekly e-News for Tax Professionals newsletter, the @IRSTaxPros Twitter feed and direct email to partner groups and advisory council members.

7. Participates in cross-functional and cross-divisional councils, task forces and working groups.


**1.1.11.5** **(02-05-2020)**

### **Tax Outreach, Partnership and Education Branch**

1. The **Chief, Tax Outreach, Partnership and Education**, reports directly to the Chief, Communications and Liaison, and is responsible for developing and building relationships with organizations outside of traditional tax communities. The Branch:



1. Explores partnership opportunities with a variety of groups and associations that may not ordinarily interact with the IRS on a regular basis, with a special emphasis on emerging topics and issues ranging from the sharing economy to new tax law issues.

2. Establishes and maintains partnerships to provide these stakeholders with a direct, interactive line of contact to the IRS in order to share real-time information about tax laws that affect them and their communities, and share critical information on hot topics of interest such as tax-related scams and taxpayer information that may be pertinent to their organizations and interests.

3. Looks for new ways to reach these groups as well as support and supplement existing outreach and communications channels the IRS already has in place.


**1.1.11.6** **(02-05-2020)**

### **Stakeholder Liaison Branch**

1. The **Director, Stakeholder Liaison Branch** reports directly to the Chief, Communications and Liaison. Stakeholder Liaison is responsible for local engagement of the payroll and practitioner communities and small business/industry organizations. It consists of five areas, divided by locality or region. The Branch:



1. Manages and delivers outreach messages, campaigns, and products related to improving voluntary compliance; based upon strategic priorities and initiatives.

2. Coordinates and conducts seminars and outreach sessions, both virtual and face to face, to deliver IRS messages and address customer needs.

3. Coordinates with stakeholders at the area level in order to identify, research, and monitor their IRS policy, procedural and systemic issues and provide feedback to practitioners and key stakeholder organizations using the Issue Management Resolution System (IMRS).

4. Partner with stakeholders to further improve voluntary compliance and reduce service demand by promoting the use of internet self-help options.

5. Provide guidance and support to taxpayers affected by disasters; may act as state coordinators for disaster assistance activities.

6. Identify and deliver outreach to emerging market segments that are traditionally underserved, including taxpayers with limited English proficiency.


**1.1.11.7** **(02-05-2020)**

### **Management and Support Services Branch**

1. The Chief, Management and Support Services, reports directly to the Chief, Communications and Liaison. The Branch:



1. Provides advice and liaison for a variety of areas, including: employment, pay, information systems, telework, job abolishment and associated mitigating strategies, and other related human resources issues.

2. Implements reorganization including labor relations issues, realignment of employees, establishment of organizational codes and overseeing required changes to the applicable Human Resources Systems.

3. Provides position management advisory services in the development of organizational changes.

4. Coordinates training needs with C&L leadership.

5. Manages the End of Year Performance Management process and the payment of Manager bonuses and BU/NBU Awards.

6. Provides advisory services regarding Performance Management and BU/NBU Awards and Manager Bonuses.

7. Manages and promotes all aspects of the Leadership Readiness Programs for Frontline, Department and Senior Managers.


**1.1.11.8** **(02-05-2020)**

### **Management and Finance Branch**

1. The Chief, Management and Finance Branch, reports directly to the Chief, Communications and Liaison. The Branch:



1. Provides financial oversight and management of C&L resource \[dollars and FTE (full-time equivalents)\].

2. Provides relevant, quality and timely data and services to facilitate management decisions.

3. Manages the resource distribution process, including the development of a financial plan that supports the program priorities of C&L.

4. Conducts financial reviews and develops recommendations to achieve a balanced financial plan.

5. Establishes and implements financial policies, procedures, and controls in conjunction with the overall Service's guidelines.


**Exhibit 1.1.11-1**

### Office of Communications and Liaison

![This is an Image: 30385001.gif](https://www.irs.gov/pub/xml_bc/30385001.gif)

> Organization chartThe graphic shows an organization chart graphically depicting the textual information above

[Please click here for the text description of the image.](https://www.irs.gov/media/129221 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-011#addtoany "Show all")

A2A