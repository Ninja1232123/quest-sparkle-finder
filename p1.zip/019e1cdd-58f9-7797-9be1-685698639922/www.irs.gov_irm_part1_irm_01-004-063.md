---
url: "https://www.irs.gov/irm/part1/irm_01-004-063"
title: "1.4.63 Roles and Responsibilities of Disclosure Managers | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-063#main-content)

- 1.4.63  [Roles and Responsibilities of Disclosure Managers](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097546000)
  - 1.4.63.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097554160)
    - 1.4.63.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097547472)
    - 1.4.63.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097702544)
    - 1.4.63.1.3  [Responsibilities of Disclosure Manager](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097697936)
    - 1.4.63.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097692816)
    - 1.4.63.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097690976)
    - 1.4.63.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050097689120)
    - 1.4.63.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096672832)
  - 1.4.63.2  [Program Responsibilities of Disclosure Manager](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096651584)
  - 1.4.63.3  [Disclosure Programs](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096642768)
  - 1.4.63.4  [Disclosure Awareness and Outreach](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096637200)
  - 1.4.63.5  [Disclosure Help Desk](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096624208)
  - 1.4.63.6  [Training](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096619696)
  - 1.4.63.7  [Disclosure Coordination with Governmental Liaison and Safeguards Programs](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096608480)
  - 1.4.63.8  [Coordination with Office of Governmental Liaison](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096605520)
  - 1.4.63.9  [Coordination with Office of Safeguards](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096588624)
  - 1.4.63.10  [Reporting Unauthorized Accesses or Disclosures of Returns and Return Information](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096578112)
  - 1.4.63.11  [Roles of the Area Manager](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096572496)
  - 1.4.63.12  [Disclosure Manager Supervisory Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096560352)
  - 1.4.63.13  [Report Analysis](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096548512)
  - 1.4.63.14  [Inventory Management Policies](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096545296)
  - 1.4.63.15  [Redaction Review (RR)](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096529072)
  - 1.4.63.16  [Communications](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096524624)
  - 1.4.63.17  [Employee Performance Oversight](https://www.irs.gov/irm/part1/irm_01-004-063#idm140050096518544)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 63. Roles and Responsibilities of Disclosure Managers

* * *

## 1.4.63 Roles and Responsibilities of Disclosure Managers

#### Manual Transmittal

October 18, 2024

#### Purpose

(1) This transmits the new Internal Revenue Manual (IRM) 1.4.63, Resource Guide for Managers, Roles and Responsibilities of Disclosure Managers (DM).

#### Material Changes

(1) This IRM section is newly developed to provide guidelines to assist Disclosure Managers in administering an effective and balanced Disclosure program.

#### Effect on Other Documents

This material includes guidance for Disclosure Managers responsible for planning and maintaining a balanced program consistent with operational priorities. This new IRM incorporates IRM 11.3.38, Disclosure Manager Expectations, and references existing guidance from IRM 11.3.41.18, Disclosure Manager (DM) Roles and Responsibilities. IRM 11.3.38 will be obsoleted simultaneously with the publication of IRM 1.4.63.

#### Audience

All Disclosure Managers

#### Effective Date

(10-18-2024)

#### Related Resources

The Disclosure and Privacy Virtual Library can be found at: The Disclosure and Privacy Knowledge Base.

Celia Y. Doggette

Director, Governmental Liaison, Disclosure and Safeguards

**1.4.63.1** **(10-18-2024)**

### Program Scope and Objectives

1. Purpose: This section provides guidelines to assist Disclosure Managers in administering an effective and balanced Disclosure program. The primary objectives of Disclosure offices are as follows:



1. Promoting the protection and confidentiality of tax information while ensuring the policy of openness and transparency is considered;

2. Preserving the privacy rights of taxpayers and employees;

3. Releasing all requested tax and other sensitive information as appropriate;

4. Implementing programs to ensure that IRS employees are fully aware of their disclosure responsibilities; and

5. Responding to requests for access to tax or other sensitive information from various sources.


2. Audience: These procedures apply to all Disclosure Managers.

3. Policy Owner: The Director of Governmental Liaison, Disclosure and Safeguards (GLDS) is responsible for oversight of Disclosure policy.

4. Program Owner: The Disclosure office, under GLDS, is responsible for the Disclosure program and guidance. Each IRS organization is responsible for ensuring its employees are aware of and follow Servicewide Disclosure policy.

5. Primary Stakeholders: Disclosure Managers that administer an effective and balanced Disclosure program.


**1.4.63.1.1** **(10-18-2024)**

#### Background

1. The public has the confidence in the ability of the Internal Revenue Service (IRS) to protect the confidentiality of tax information; this influences the public's willingness to opt into our voluntary tax system.

2. The Taxpayer Bill of Rights states that **taxpayers have the right to expect that any information they provide to the IRS will not be disclosed unless authorized by the taxpayer or by law.** Internal Revenue code (IRC) IRC 6103(a) provides the guidance for disclosure of taxpayer information, and the general rule is returns and return information shall be confidential. The Freedom of Information Act (FOIA) set a standard of “openness in government” that established a withholding decision based on whether the IRS reasonably foresees that disclosure would harm the IRS or its interests.

3. The privacy of employee information is also important and employee information must only be released in accordance with the Privacy Act or other applicable laws.

4. Disclosure Managers are responsible for implementing activities that promote privacy principles and/or improve the efficiency of tax administration (program management) and provide for timely and accurate responses to requests for information (casework). See IRM 10.5.1.4.2, IRS-Wide Privacy Roles and Responsibilities, Managers.


**1.4.63.1.2** **(10-18-2024)**

#### Authority

1. The following items govern the authority pertaining to Disclosure Programs and Disclosure casework:



   - IRC 6103(a)

   - Freedom of Information Act (FOIA) 5 USC 552

   - Privacy Act 5 USC 552a

   - Disclosure Delegation Orders 11-1 through 11-5, found in IRM 1.2.2

   - Policy Statement P-1-1, Mission of the IRS, found in IRM 1.2.1.2.1

   - Policy Statement P-11-90 (Formerly P-1-35), Agreements to exchange tax information with States entered into when in interests of good tax administration, found in IRM 1.2.1.11.5


**1.4.63.1.3** **(10-18-2024)**

#### Responsibilities of Disclosure Manager

1. The Disclosure Manager (DM) serves as the first line manager over a staff of employees who provide disclosure services to IRS employees and other stakeholders.

2. The DM reports directly to the Area Manager (AM).

3. The AM is responsible for evaluating and reviewing the DM’s management of the Disclosure program.

4. AMs report to the Associate Director, Disclosure, who reports to the Director, Governmental Liaison, Disclosure and Safeguards (GLDS). The Director GLDS reports to the Chief, Privacy Officer, Privacy, Governmental Liaison and Disclosure (PGLD).

5. Privacy, Governmental Liaison and Disclosure is a service-wide organization that was organized in June 2011 and includes the former Privacy, Information Protection and Data Security (PIPDS) functions as well as the GLD and Safeguards programs.

6. The Privacy and Disclosure Virtual Library provides a listing of PGLD offices and their responsibilities in the "About PGLD" link. See related resources at _IRM 1.4.63.1.7_ .


**1.4.63.1.4** **(10-18-2024)**

#### Program Management and Review

1. Program Effectiveness: Disclosure Managers participate in ongoing Operational Reviews to determine the effectiveness of the disclosure programs and implement changes identified.


**1.4.63.1.5** **(10-18-2024)**

#### Program Controls

1. Business Units are responsible for establishing and documenting the program controls developed to oversee their program as well as ensuring employee compliance with all applicable elements of this IRM.


**1.4.63.1.6** **(10-18-2024)**

#### Acronyms

1. The following table provides a list of the acronyms that are used in this section:




| **Acronym** | **Definition** |
| --- | --- |
| AM | Area Manager |
| BPRA | Business PII Risk Assessments |
| CAG | Case Assignment Guide |
| CJE | Critical Job Element |
| DA | Disclosure Analyst |
| DA | Disclosure Assistant |
| DM | Disclosure Manager |
| DS | Disclosure Specialist |
| EPF | Employee Performance Folder |
| FOIA | Freedom of Information Act |
| FX | FOIAXpress |
| FTI | Federal Tax Information |
| GAO | Government Accountability Office |
| GL | Governmental Liaison |
| GLDS | Governmental Liaison, Disclosure and Safeguards |
| GSS | GLDS Support Services |
| HQ | Headquarters |
| IRC | Internal Revenue Code |
| IRM | Internal Revenue Manual |
| MOU | Memorandum of Understanding |
| NA | National Agreement |
| OJI | On the Job Instructor |
| OJT | On the Job Training |
| PA | Privacy Act |
| PCA | Privacy Compliance and Assurance |
| PCLIA | Privacy and Civil Liberties Impact Assessments |
| PD | Position Description |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| PII | Personally Identifiable Information |
| PIPDS | Privacy, Information Protection and Data Security |
| PPO | Policy and Program Operations |
| RR | Redaction Review |
| SBU | Sensitive but Unclassified |
| SCR | Sensitive Case Report |
| SDS | Senior Disclosure Specialist |
| SDT | Secure Data Transfer |
| SME | Subject Matter Expert |
| SSN | Social Security Number |
| TIGTA | Treasury Inspector General for Tax Administration |
| TLS | Tax Law Specialist |
| UNAX | Unauthorized Access |


**1.4.63.1.7** **(10-18-2024)**

#### Related Resources

1. The following table lists other sources of guidance for Disclosure Managers:




| **Resource** | **Title** | **Guidance** |
| --- | --- | --- |
| IRM 11.3 | Disclosure of Official Information | Contains sections 11.3.1 through 11.3.40 which provide guidance on distinct disclosure programs |
| IRM 11.4.1 | Governmental Liaison Operations | Provides operating procedures, policy and guidelines for Governmental Liaison employees and managers |
| IRM 1.4.1 | Resource Guide for Managers, Management Roles and Responsibilities | Provides references and resources for IRS managers |
| IRM 1.2.2.12 | PGLD Delegation Orders | Contains all of the Servicewide Delegation Orders and Authorities for the PGLD function |
| IRM 6.410.1 | Learning and Education Policy | Provides Disclosure training requirements |
| IRM 6.430 | Performance Management | Provides a framework for supervisors and employees for improving organizational effectiveness to accomplish the IRS’ mission and goals. |
| IRM 10.5.2 | Privacy and Information Protection, Privacy Compliance and Assurance (PCA) Program. | Provides the privacy framework for privacy compliance and assurance programs and activities, including privacy risk assessments (such as Business PII Risk Assessments (BPRAs), Privacy and Civil Liberties Impact Assessments (PCLIAs), and Service-wide risk assessments), as well as various privacy reporting requirements. |
| IRM 10.5.4 | Privacy and Information Protection, Incident Management Program | Provides procedural guidance for reporting IRS data losses, thefts, and inadvertent unauthorized disclosures involving Sensitive But Unclassified (SBU) data, including Personally Identifiable Information (PII) and tax information. |

2. Additional information will also be found at these related resources:



   - [FOIA Public Liaison](https://www.irs.gov/privacy-disclosure/irs-freedom-of-information)

   - Disclosure Points of Contact

   - Disclosure and Privacy Virtual Library

   - [IRS Freedom of Information page on irs.gov](https://www.irs.gov/privacy-disclosure/irs-freedom-of-information)

   - [FOIA Library](https://www.irs.gov/privacy-disclosure/foia-library)


**1.4.63.2** **(10-18-2024)**

### Program Responsibilities of Disclosure Manager

01. The Disclosure program is divided into two categories:



    - Case management

    - Program management


### Note:

The case management responsibilities for caseworkers are described throughout various sections in IRM 11.3. This IRM section will describe specific program management and other management responsibilities and the actions necessary to carry out these responsibilities.

02. Guidelines for the Disclosure program are often provided by the Area Managers (AM).

03. The Disclosure Manager (DM) is responsible for planning and maintaining a balanced program consistent with operational priorities. A DM must be technically and administratively competent to accomplish both objectives.

04. Despite the size of the case management workload, program management responsibilities are equally important and must be met. Efficient and appropriate use of resources is the key in meeting this objective.

05. Disclosure office staff serves as the technical experts in all disclosure matters. Staff's ability to provide accurate and timely guidance is a key element of an effective program.

06. Disclosure Managers are responsible for coordinating and integrating the Disclosure program with internal and external stakeholders.

07. Most disclosures made by employees in any given IRS office are made by individuals other than Disclosure personnel. Through program management delivery, the DM imparts the knowledge necessary for IRS management and front-line personnel to make correct disclosure decisions.

08. The DM serves as liaison in disclosure matters with other governmental agencies.

09. The DM supports the Governmental Liaison (GL) by reviewing negotiated agreements to ensure appropriate provisions are included where the disclosure of federal tax information (FTI), personally identifiable information (PII) or other sensitive but unclassified (SBU) information is involved.

10. There are many aspects of the work that are also affected by privacy policies and initiatives promulgated by the Office of PGLD. The DM, because of their expertise, will be called on to assist or advise in matters that impact privacy policy for field operations or will be asked to provide resources in support of various PGLD programs or projects.


**1.4.63.3** **(10-18-2024)**

### Disclosure Programs

1. Disclosure is responsible for several programs that have a Servicewide impact:



   - **Awareness and Outreach**\- ensure that all employees understand Disclosure and Privacy principles and apply them correctly in the performance of their duties.

   - **Disclosure Help Desk** \- respond to IRS employee questions related to IRS disclosure and confidentiality statutes.

   - **Training**\- provide employee training regarding disclosure and non-disclosure of information and IRC 6103, FOIA and Privacy Act responsibilities.


2. Headquarters Disclosure Policy and Program Operations (PPO) staff (under the supervision of the HQ Disclosure Manager) or the Associate Director, Disclosure staff may also participate in Disclosure Program activities.


**1.4.63.4** **(10-18-2024)**

### Disclosure Awareness and Outreach

1. The principal objective of the Disclosure Awareness and Outreach program is to ensure, to the extent possible, that all employees know the disclosure statutes and principles and apply this knowledge correctly in the performance of their duties.

2. A successful disclosure awareness and outreach program is predicated on a multiplier effect (awareness being further shared and disseminated by recipients). This increases the likelihood of employee compliance with disclosure/privacy statutes and principles. A high degree of compliance translates into the following:



1. Taxpayer and employee confidence that confidential information is not being misused.

2. Reduced incidences of unauthorized access (UNAX) and disclosures.

3. Assurance to Congress that the IRS is providing its employees with the knowledge they need to understand and apply disclosure and privacy rules consistently and correctly.

4. Supporting open government by educating the public to use the proper procedure for obtaining records they are seeking.

5. Providing taxpayers and their representatives with direct access to records from open compliance and other administrative files upon their request, when possible, as long as that release does not create an impairment to the government's investigation.

6. Every IRS employee responding promptly and fully when contacted by Disclosure staff about a FOIA request; giving FOIA requests the high priority they deserve.


3. The Disclosure Managers are responsible for helping to identify awareness issues and support development of materials for field employee’s use and distribution. Disclosure PPO staff will also assist with identifying awareness issues and will work with field staff to develop materials. These products will be used to ensure delivery of a consistent and accurate message. Copies of various presentations and Disclosure Articles are contained on the Disclosure Share Point site as well as the Disclosure and Privacy Virtual Library.



### Note:



The Privacy and Disclosure Virtual Library provides a "Book a Disclosure Presentation" button which allows other IRS business units to request a Disclosure Awareness Presentation. The Disclosure Manager will be called upon to coordinate Awareness presentations requested through the “Book a Disclosure Presentation” button.

4. The Disclosure Managers are responsible for the following awareness program objectives:



1. Implement plans to deliver awareness activities on an on-going basis. The plans are established by PGLD management and identified in the annual GLDS Strategic Plan or in other initiatives.



      ### Note:



      Resources must be made available to provide sufficient coverage of those areas required to be addressed as identified by Director, GLDS or by the Associate Director, Disclosure.

2. Document all efforts to promote awareness. Issues covered in awareness efforts must be relevant, timely and accurate. Disclosure Managers will review outlines or notes prepared by the Disclosure employee, for technical accuracy. Disclosure PPO staff, under the direction of the HQ Disclosure Manager, will review any new awareness resources that are not already published or catalogued in the Disclosure Awareness Presentation Library.


5. HQ Disclosure PPO staff (under the supervision of the HQ Disclosure Manager) or the Associate Director, Disclosure staff will also support disclosure awareness activities such as Business PII Risk Assessment (BPRA). See IRM 10.5.2.4.3, BPRA Roles and Responsibilities.


**1.4.63.5** **(10-18-2024)**

### Disclosure Help Desk

1. The AMs, Disclosure (East and West) are required to provide resources (managers and staff) to support the Servicewide Disclosure Help Desk.

2. The Help Desk is responsible for responding to IRS employee questions and inquiries related to IRS disclosure and confidentiality statutes and the employees' responsibilities in adhering to them. Many of the questions received on the Disclosure Help Desk will be answered with resources on the Privacy and Disclosure Virtual Library. See _IRM 1.4.63.1.7_ (2).

3. The AMs ensure their DMs provide adequate staff coverage.

4. DMs also ensure their staff direct calls and emails for Disclosure Office assistance to the Help Desk and encourage all callers to use the system when questions requiring Disclosure expertise arise.

5. The Disclosure Help Desk contact information is found on the Privacy and Disclosure Virtual Library and is for IRS employees only.


**1.4.63.6** **(10-18-2024)**

### Training

1. DMs are responsible for ensuring employees receive training regarding disclosure and non-disclosure of information, IRC 6103, the FOIA and Privacy Act responsibilities.

2. The DMs use the following guidelines to carry out training responsibilities:



1. Provide technical guidance and direction to all employees.

2. Ensure the adequacy, quality and effectiveness of disclosure-related training programs by assisting in development of local training materials and attending local training classes to address employees’ concerns and answer disclosure-related questions.


3. See IRM 6.410.1.3.10, Learning and Education Policy, Disclosure Requirements, for Disclosure training requirements.

4. Additional information on Disclosure Manager Responsibilities regarding the Disclosure Training Program can be found in the Disclosure Training Guide.

5. The DM will meet each new employee and On-the-Job-Instructor (OJI) to ensure proper emphasis is placed on training guidelines and completing work assignments during On-the-Job-Training (OJT). The emphasis will include:



   - Assignment of appropriate case work

   - Use of proper procedures in working cases

   - Timely feedback to the OJI on OJT activities

   - Timely written feedback to the trainee


6. The expectations for the DM and OJI’s for training will include:



   - Stress the importance of using appropriate upfront decision-making during OJT

   - Ensure involvement in cases as needed to facilitate case closure

   - Ensure proper case file documentation by the trainee

   - Follow proper procedures as defined in the IRM and other case processing resources


7. At the beginning of the training phase, the DM will meet with the Trainee to convey expectations. Also, the DM will meet periodically throughout the training phase with the Trainee and OJI regarding the Training Program to collect feedback, concerns, etc. DMs will use the resources on the Disclosure Training SP site to ensure trainees are receiving the required orientation and pre‑classroom training and support. DMs will attend all training outlined in the Disclosure Training Plan.


**1.4.63.7** **(10-18-2024)**

### Disclosure Coordination with Governmental Liaison and Safeguards Programs

1. Disclosure coordinates certain activities with other offices within GLDS, primarily the Office of Governmental Liaison (GL) and the Office of Safeguards.

2. The GLDS Roles and Responsibilities Matrix, found on the Disclosure Share Point site is an important resource in understanding the coordination activities between Disclosure, GL and Safeguards.

3. Disclosure Managers, GLs, and Office of Safeguards personnel share responsibility for ensuring state tax agencies receive federal tax information when appropriate and that they properly safeguard federal tax information they receive.


**1.4.63.8** **(10-18-2024)**

### Coordination with Office of Governmental Liaison

1. Liaison activities with federal and state government agencies are carried out by the Office of Governmental Liaison (GL).

2. Disclosure Managers ensure compliance with law and policy such as:



   - IRC 6103(d) and IRC 6103(h)

   - Policy Statement P-1-1, Mission of the IRS, found in IRM 1.2.1.2.1

   - Policy Statement P-11-90 (Formerly P-1-35), Agreements to exchange tax information with states entered into when in interests of good tax administration, found in IRM 1.2.1.11.5

   - Policy Statement P-11-98 (Formerly P-6-14), Fed State Relations, found in IRM 1.2.1.11.13


3. The Disclosure Manager, in coordination and collaboration with the GL, has responsibility for:



1. Developing basic and implementing agreements and memorandums of understanding and ensuring compliance (e.g. need and use determinations) with the basic agreement, all supporting agreements, and all memorandums of understanding.

2. Evaluating a state tax agency’s need and use of federal tax returns or return information before information is disclosed. Making need and use determinations are limited to new or ad hoc state tax agency written requests for returns and return information, or as needed due to amended or updated State laws. For further information on defining “need and use” see IRM 11.3.32, Disclosure to States for Tax Administration Purposes.

3. Assisting and responding to inquiries from state taxing authorities for specific Federal Tax Information.

4. Ensuring preparation of disclosure accountings.

5. Preparing Disclosure Awareness and other training, including UNAX, to federal, state, and local agency employees.


4. The DM is responsible for ensuring that disclosure standards are maintained in the basic agreement, implementing agreements, or any other type of agreement or memorandum of understanding that will exist between state tax agencies and the IRS. To carry out this responsibility, DMs must:



1. Consult with the GL and state tax agency officials regarding disclosure problems involved in proposed formal agreements on coordination of tax administration. Review the execution of such agreements as necessary.

2. Assist the GL in negotiations with state tax agency officials concerning the provisions of agreements that will supplement the basic agreement. Specify the nature, quantity, and mechanics for exchange of tax information, including tolerances and criteria for selection.

3. Conduct need and use determinations prior to releasing or approving the release of new tax information or streams of tax information and ensure need and use documentation is provided for each item of tax information to be disclosed, including all items pursuant to the agreement, MOU and electronic data exchange (See IRM 11.3.32, Disclosure to States for Tax Administration Purposes).

4. Conduct ongoing need and use determinations with every specific request to ensure, particularly, where the information relates to an individual or entity that resides outside the states geographical boundaries, that the appropriate nexus has been established.


5. DMs are expected to advise the GLs on disclosure provisions.

6. All exchanges of tax information fall into one of the following categories:



1. Implementing agreements or memorandums of understanding or

2. Specific requests (made outside of the Implementing Agreement or Memorandum of Understanding) or

3. Electronic data exchanges (that can be referenced in Implementing Agreements or Memorandums of Understanding or specific requests).



      ### Note:



      Additional information on the Secure Data Transfer (SDT) data exchanges can be found on the Disclosure Share Point site.


7. DMs and staff also support efforts by GLs in exploring opportunities for exchange of tax information with other federal agencies and provide advice related to various disclosure provisions related to these exchanges.

8. For additional information on the GL program, see IRM 11.4.1, Governmental Liaison Operations .


**1.4.63.9** **(10-18-2024)**

### Coordination with Office of Safeguards

1. The Office of Safeguards within the GLDS is responsible for oversight of the protection afforded returns and return information disclosed under the specific 6103 provisions enumerated in IRC 6103(p)(4). Generally, these are federal and state government agencies subject to safeguard review and include:



   - State Tax Agencies

   - State Workforce Agencies

   - State and Federal Child Support Enforcement Agencies

   - Human Services Agencies

   - Health Insurance Marketplaces

   - Authorized contractors of state and federal agencies

   - Other Federal, State and Local Agencies receiving tax information and are subject to IRC 6103(p)(4)



     ### Note:



     These agencies may also receive returns and return information under other provisions of IRC 6103(a) that are not subject to the safeguarding requirements of IRC 6103(p)(4), for example, when disclosed under the provisions of IRC 6103(c) or (k)(6), or when tax information is obtained directly from a taxpayer or other third party not restricted by IRC 6103(a).


2. The purpose of the Safeguard review program is to ensure:



1. Disclosure of tax returns and tax return information by the IRS to external agencies, their authorized agents, and their authorized contractors is in accordance with statutory authority.

2. Tax information is used by these recipients only as authorized by the enabling legislation and/or implementing regulations.

3. Returns and return information are protected from unauthorized disclosure and inspection as specified in IRC 6103(p)(4)and supplemented by Pub 1075, Tax Information Security Guidelines for Federal, State and Local Agencies.


3. DMs and Disclosure staff assist the Office of Safeguards, and any other IRS personnel with issues related to the interpretation and application of IRC 6103(a) as they relate to information shared with or disclosed by the various Federal, State and Local agencies and contractors. For additional information, see IRM 11.3.32, Disclosures to States for Tax Administration Purposes.

4. For specific DM guidance on coordination with Safeguards see IRMs 11.3.32 and 11.3.36.

5. For additional information on the Safeguards program, see IRM 11.3.36, Safeguards Review Program.


**1.4.63.10** **(10-18-2024)**

### Reporting Unauthorized Accesses or Disclosures of Returns and Return Information

1. IRC 6103(a) prohibits the disclosure of returns and return information unless authorized by Title 26. Although a disclosure must be authorized by statute, the person making the disclosure must also have the authority and follow the proper procedures, or the disclosure is not authorized. IRS employees are required, under IRC 6103, to ensure that returns and return information are protected from unauthorized disclosure and access. The IRS employee making the disclosure is responsible for ensuring the authority of the recipient to receive it.

2. IRS employees are required to report, immediately upon discovery, any suspected willful unauthorized access/ inspection/ disclosure of returns or return information or Privacy Act violations. For service-wide manager and employee guidance/ responsibilities, see IRM 10.5.5, Privacy and Information Protection, Unauthorized Access, Attempted Access or Inspection of Taxpayer Records (UNAX) Program Policy, Guidance and Requirements.



### Note:



A willful act is one where there is an intentional violation of a known legal duty.

3. Non-willful unauthorized disclosures of tax or Privacy Act protected information are to be reported immediately upon discovery. For service-wide manager and employee guidance/responsibilities, see IRM 10.5.4, Incident Management Program.

4. IRS employees are subject to criminal penalties for the willful unauthorized disclosure of a returns or return information (IRC 7213); and for the unauthorized access to returns or return information (IRC 7213A). The IRS is subject to a civil action for damages when an IRS employee knowingly or negligently inspects or discloses a taxpayer’s return or return information in violation of IRC 6103 (IRC 7431). For further information, see IRM 11.3.1, Introduction to Disclosure.


**1.4.63.11** **(10-18-2024)**

### Roles of the Area Manager

1. The AMs, Disclosure East and Disclosure West, serve as the managers for the field DMs under their areas of responsibility and report to the Associate Director, Disclosure.

2. The Area Manager:



   - Manages the Disclosure program in their area

   - Assists the Director, GLDS, and Associate Director, Disclosure in implementing the national disclosure program

   - Ensures Disclosure employees receive training regarding disclosure of information requirements


3. To be effective, the Area Manager must:



01. Provide necessary managerial assistance and support to DMs and staff.

02. Assess the effectiveness of the Disclosure programs through visitations and reviews.

03. Perform operational reviews regularly to monitor and document progress toward achieving organizational goals and objectives. Operational reviews have two components: program reviews and administrative/compliance conformance reviews and document findings with a memorandum. Conduct follow up reviews when appropriate.

04. Conduct program reviews of individual groups to evaluate the effectiveness of the manager, assess the group’s performance and to provide guidance and direction intended to improve business results, foster effective casework and managerial engagement. The program review will assess the group’s progress in areas such as performance efficiencies and quality. Use the review to identify trends, assess skills, training needs and overall performance. DM communication and leadership of the group are addressed in this process. Program reviews must focus on assisting the group manager to improve performance and quality of case actions.

05. Prepare procedures and instructions for local offices concerning Disclosure programs.

06. Support the importance of the Disclosure program. Understand and embrace the role the Disclosure staff plays in protecting the confidentiality of tax information and sensitive non-tax information.

07. Monitor disclosure office compliance with PPO directives and guidelines and ensure that GLDS priorities are followed.

08. Conduct reviews of Disclosure casework to determine if appropriate quality standards are being met, and procedures are being followed.

09. Review and approve exchange agreements for conformity with IRC 6103(d).

10. Determine which technical issues require PPO’s action; suggest new legislation, regulations and procedures to PPO as warranted.

11. Advise PPO of procedural problems which may extend beyond Area jurisdiction, detail efforts made to resolve them, and offer suggestions to prevent recurrence.

12. Provide input as required by PPO on the status of Disclosure activities within the Area.

13. Coordinate, consolidate, and ensure that required reports are complete, timely, and accurate.


**1.4.63.12** **(10-18-2024)**

### Disclosure Manager Supervisory Responsibilities

1. In addition to program and case management responsibilities, DMs also have supervisory (i.e., front line management) responsibilities for technical and clerical personnel. As such, they must perform the full range of tasks expected of all IRS supervisors.

2. The DM will supervise a team that will consist of positions including Secretary, Tax Law Specialist (TLS), Disclosure Analyst (DA), Senior Disclosure Specialist (SDS), Disclosure Specialist (DS), Disclosure Assistant (DA), and anyone who processes casework related to IRC 6103, the Freedom of Information Act (FOIA), the Privacy Act (PA) and non-tax subpoenas in the Disclosure Program. See IRM 11.3.41, for general description of roles.

3. The supervisory responsibilities of the DM will include:



01. Ensure employee case actions are timely and in accordance with current law, policies, and procedures;

02. Ensure employees maintain high standards of professionalism in all their contacts with the public, internal customers and coworkers;

03. Ensure employees observe taxpayer rights;

04. Ensure employees are aware of ongoing changes to the laws, policies, and procedures that relate to their responsibilities (preferably during group meetings);

05. Address systems issues that impact either internal or external customer needs;

06. Ensure cases are assigned timely and employee workload do the following: reflects current priorities, reflects employee experience and skill level, addresses Service wide objectives, protects public interest, and allow for effective case processing

07. Ensure employees are accountable for their actions;

08. Provide ongoing employee feedback that is candid and meaningful and will establish a basis for determining an accurate assessment of performance and developmental needs;

09. Issue the Critical Job Elements (CJE) timely in accordance with the current National Agreement and evaluating employees performance against their CJEs;

10. Create and maintain a work environment that will promote team work, positive working relationships, and increased employee satisfaction; and

11. Ensure employees have necessary functioning equipment and supplies.


4. Additional Supervisory Responsibilities of the Disclosure Manager include:



   - Inventory Management

   - Redaction Review

   - Report Analysis

   - Communications

   - Employee Performance Oversight


**1.4.63.13** **(10-18-2024)**

### Report Analysis

1. Disclosure uses an electronic inventory management system for input, control, processing, and closing assigned case and program work. This is a helpful tool for DMs to monitor all activities of their office. It is important that the data entries made are accurate and timely. DMs must include comments in case reviews or in other observations about the accuracy and completeness of all required data entry and case history notes.

2. GLDS Data Services is responsible for the operations of the system and must be contacted in the event of any connectivity or functionality issues.

3. DMs are to use the reports generated by the system as a tool to assist in identifying trends, addressing inventory management issues and in reporting accomplishments to the Area Manager.


**1.4.63.14** **(10-18-2024)**

### Inventory Management Policies

01. Disclosure managers are responsible for monitoring inventory levels to ensure each employee has an appropriate number of cases that can be resolved most effectively and efficiently based on their grade level, experience, and expertise. An inventory adjustment is a percentage-based adjustment to the standard range. It is based on an evaluation of time spent on activities other than work on assigned cases (direct case time) and normal overhead. Examples of situations where a manager will consider an inventory adjustment are:



    - Collateral assignments (e.g., NTEU Representative, EEO Counselor/Investigator, details out of office, instructing assignments, coaching assignments, etc.).


When an adjustment to an employee’s inventory is warranted because of any of these circumstances, use the projected time expenditure by the employee to determine the appropriate adjustment. Example: A manager assigns a GS-12 employee to oversee formal on the job training for a new hire therefore an adjustment of 25% is appropriate in this case. Individual caseworker inventory levels will be re-adjusted as warranted. Managers must perform quarterly reviews of actual time their employees spend on non-case direct activities and collateral assignments and adjust as needed. Adhere to these guidelines when considering any adjustments to employee inventories.



02. When additional cases need to be assigned, managers will look to the following sources for additional work:



    - Other employees

    - Other groups (with concurrence from the Area Manager)


03. Reassignment of Departing Employee Inventory. Where inventory will be abandoned for periods of 30 days or more (for example an employee is reassigned, on extended leave, or long-term detail) the group manager will consider performing the following actions:



    1. Holding assignment of additional work (after confirmation of the employee’s effective date for detail, reassignment, retirement, etc.).

    2. Reviewing all inventory with the departing employee and identifying those which can be resolved prior to the employee leaving or reassigned to the remaining employees in the group. The transfer of these cases must be completed within a reasonable period, normally within 2 days of the departure effective date.


04. Case decisions will be reached expeditiously, focusing on case actions needed to optimize cycle time and resource utilization. The DM’s involvement in case actions must be documented in the case file in accordance with case documentation policy. Performance issues will be addressed outside the case management system.



    - See IRM 11.3.13 and IRM 11.3.41 for DMs responsibilities with administering the FOIA Program and IRM 11.3 for other case types.


05. The DM must review cases prior to assignment and determine if managerial involvement is needed up front to properly set the scope of the search. If managerial involvement is deemed necessary, it must be documented in the case notes. The DM will facilitate resolution with internal and external stakeholders like Counsel, Disclosure senior leadership, Disclosure Policy, and Program Operations (PPO), the Business Units holding the records and Functional Coordinators as needed.

06. The DM or their delegate will assign inventory generally within 24 hours, but no later than three (3) days under extraordinary circumstances. Sensitive Case determination will be made within five (5) days of case assignment (caseworkers are to complete the Sensitive Case Report (SCR) within five (5) days). DMs, Area Technical Advisors, and Disclosure Analysts can also make a Sensitive Case determination.

07. DMs will utilize reports and the inventory management system to monitor inventory, direct operations, and review trends, taking an agile approach to maximize and improve inventory management, and resolution efforts. For example, analyzing the case management application, customizing reports, and utilizing the reports scheduler. Anomalies and outliers will be identified and evaluated looking behind the numbers to ensure effective actions have been taken to move the inventory to timely quality resolution.

08. The DM will ensure the use of approved pattern letters and paragraphs. The DM will ensure that any deviation from the pattern letters and paragraphs is accurate and technically correct. Deviation approval must be documented in the case notes. The DM will review all closing letters that require their signature in accordance with Delegation Orders and IRM guidance, checking for grammatical, procedural, and technical accuracy placing special emphasis on ensuring accurate support for Exemptions 3 and description of privileges claimed for Exemption 5, if used.

09. The DM will ensure that caseworkers are contacting requesters to clarify and/or re-scope requests, discuss respond directly options and to issue interim responses and rolling productions where appropriate. DM will also ensure caseworker adherence to routine agency procedures.

10. The DM will implement procedures to ensure that extension letters are issued appropriately and timely. The DM will implement procedures to ensure that caseworkers will not input or close their own cases on the electronic inventory system. Only designated employees and the GLDS Support Services (GSS) unit will close cases for the groups. DMs will implement procedures to ensure cases are closed from the system timely in accordance with IRM 11.3.41.

11. Managers must use the automated inventory management system and it’s reports to assist in monitoring the flow of newly assigned cases and in balancing inventories. The system and its reports identify unassigned cases that must be assigned within the timeframes outlined IRM 11.3.41.

12. Managers play a pivotal role in the assignment process. They must monitor inventory receipts to ensure new cases are properly assigned. They must also verify previously assigned cases are reassigned when appropriate if complexity changes.


**1.4.63.15** **(10-18-2024)**

### Redaction Review (RR)

1. The DM will review or delegate review of responsive documents on closing FOIA full or partial denial cases and other cases requiring disclosure manager approval based on Delegation Orders. Final approval and ultimate responsibility resides with the DM. DMs must document the review in the case notes. Refer to DM Training and Area Managers for more information as it pertains to new hire DMs.

2. The RR process will include at least a sampling of all pages being released to the requester to include pages with, and pages without, redactions. DMs and their designee will review discretionary disclosures and ensure reasonable harm was addressed. DMs and their designee will ensure the recommendation of the function(s) having primary interest or issuing authority for the record(s) was secured and that application of (b)(5) and (b)(7)(A) exemption(s) were recommended by the function, not independently by the caseworker. The RR will be used for evaluative feedback if conducted by the DM and written up as a formal case review.

3. DMs may delegate RR and will validate efficiency and accuracy of RR performed by staff other than DM. The DM will perform periodic random sampling of a selection of RR performed by delegates to validate effectiveness.

4. A RR will be performed on 100% of casework performed by employees in training (OJT). The OJI or other designee may conduct this review; however, the DM will be required to perform the RR on a minimum of two cases per employee, to be spread out over each six-month period (based on the employee's mid-year and annual rating period) for a total of four cases per annual rating period.


**1.4.63.16** **(10-18-2024)**

### Communications

1. One-on-one communications with staff members are critical to facilitating managerial engagement and knowledge sharing in an informal setting. The DM is responsible for ensuring one-on-one communications occur as needed (but no less than every 30 days) with each employee to ensure that timely action is taken at the earliest opportunity on all work streams.

2. Routine communications with staff members include:



   - Reviewing priority inventory items and reports to include next steps and estimated completion dates; see criteria for identifying priority inventory as developed by DM for use in this process,

   - Discussing administrative items such as time and attendance issues, telework, and equipment issues,

   - Evaluative feedback sharing and discussion; annual and progress review discussions,

   - Any other miscellaneous issues.


3. The DM must hold monthly (at a minimum) group meetings and/or discussions to assist caseworkers with their technical development and ensure their understanding of all procedures. Disclosure technical guidance (All-Disclosure Communiques, Quality Right Quicks), Help Desk trends, national quality review results, and best practices will be included in the discussion.

4. DMs will communicate with each other and their Area Manager on procedures and practices to include sharing of Best Practices identified. The DM will keep their Area Manager aware of sensitive, high-level, or novel issues including personnel and case-related issues see IRM 11.3.13.3.3. The DM and staff will adhere to chain of command procedures and elevate issues to the appropriate subject matter expert. Refer to the guidelines outlined in the Disclosure Communication Guide.


**1.4.63.17** **(10-18-2024)**

### Employee Performance Oversight

01. The DM is required and responsible for issuing timely evaluative performance feedback to support the Midyear Progress Reviews and Annual Appraisals. A tracking mechanism will be used to commemorate the status of evaluative feedback for each rating plan and will be available to Disclosure senior leadership as requested. The following outlines minimum recordation requirements during the employee’s rating period. Any deviations from the minimum recordation requirements must be approved in writing by the Area Manager.

02. Written performance narratives/case-specific feedback will always be professional and must include review/documentation of the following:



    1. Current status and recommended actions on open case reviews providing specificity and clear direction around case development via research or necessary reach-outs to Subject Matter Expert (SME).

    2. Documented communication with the requester to: 1) clarify records requested when warranted, 2) address the direct release of records as applicable, and 3) keep requester apprised of the status of the case on an ongoing basis.

    3. Documented follow-up dates by the caseworker and action-due dates by the manager on open case reviews to ensure appropriate follow-through.

    4. Specific documented estimated closing dates.

    5. Contemporaneous case notes.

    6. That appropriate pattern letters and/or pattern letter paragraphs were used with keen eye to proper punctuation and grammar.

    7. Appropriate and timely case actions in accordance with the case processing timeliness requirements issued to all of Disclosure.

    8. Time is commensurate with the actions taken on the case, ensuring that all case actions have been completed without procrastination.


03. For GS-7, 9, 11 Disclosure Specialists, all new hire Specialists, and Specialists rated less than fully successful, a minimum of five (5) evaluative recordations must be issued to each caseworker prior to their Midyear Progress Review and a minimum of five evaluative recordations must be issued to each caseworker prior to the end of their rating period for a total of ten (10) evaluative recordations for the rating period. For GS-12 Senior Disclosure Specialists that are rated fully successful or higher, select a minimum of six (6) cases per year for review. Review at least half of the cases prior to the mid-year progress review. These recordations must consist of:



    1. Reviews of a sample of open and closed cases, with at least two (2) during each half of the rating period being substantive case reviews (cases with documents/redactions), with emphasis on backlog, overage and priority cases.

    2. Priority cases include Subpoenas, Freedom of Information Act (FOIA), Privacy Act, Court Orders, or any other work category that will be time sensitive or require higher level reporting.

    3. Targeted case reviews will be included as part of the required minimum case reviews, but not as substantive cases, and excludes evaluative feedback of time reports.


04. A minimum of four (4) evaluative multi-case targeted reviews issued to each caseworker per rating period included in the total per rating period:



    1. Disclosure Help Desk review for each Help Desk Assistor. The sample must include a minimum of three (3) calls/email responses.

    2. Correspondence prepared and issued. The sample must include a minimum of five (5) case correspondence reviews, emphasizing accuracy of grammar, layout, and professionalism.

    3. Disclosure case timeliness expectations consistent with IRM 11.3.41. The sample must include a minimum of three (3) case reviews to ensure compliance with timely actions for case processing.

    4. Time Utilization Review – this is a review of the activities recorded in no less than a single working day with no less than three (3) separate cases worked in the reviewed time period. The feedback must include whether time was input for the full Tour of Duty for the prescribed time period and whether the activities are commensurate with time charged based on the nature and complexity of the work.


05. Declining performance must be documented as soon as observed and early enough in the rating period to allow for adequate time to improve. The DM will advise the Area Manager, consult with Labor Relations, and refer to agency-wide guidance (IRM, iManage, etc.) and the National Agreement as appropriate. Minimum recordation is not sufficient when the DM has identified declining performance of an employee (see IRM 6.430.2.3.3 and IRM 6.430.2.3.4).

06. The DM will provide the employee with copies of all evaluative feedback within 15 work days and place a signed (both employee and manager) copy in the Employee’s Performance Folder (EPF) to be retained in accordance with established IRS policy (IRM 6.430.2.3.5(4)). If the employee refuses to sign, this must be notated on the evaluative feedback document with the date that the recordation was shared and placed in the EPF. The Area Manager will review employee evaluative feedback as part of Disclosure Office Operational Reviews in their Area.

07. Mid-Period Progress Review. The DM will timely prepare in writing a Midyear Progress Review for each employee at the mid-point of employee’s rating period in accordance with IRM 6.430.2.3.2 and the National Agreement (NA) Article 12, Section 2 K.

08. Clear guidance for areas of improvement must be included if the Progress Review indicates a decrease in performance from the last annual rating of record. Strong consideration must be given to the timing of the progress review to allow as much time as possible for the employee to improve. See NA Article 12, Section 4 L.

09. Numerical ratings will not be included in Midyear Progress Reviews however the narrative must be clear the performance level for each aspect using the language cited in the Critical Job Elements (CJE)’s.

10. End of Period Requirements. The DM will:



    1. Complete the annual appraisal process within 30 days from the end of the employee’s rating period as required per IRM 6.430. Follow local procedures to submit to the Area Manager for review and approval.

    2. Use e-Performance in HR Connect to input the rating.

    3. Provide copies of position description (PD) and CJE’s to each employee and secure a signed Form 6774 (IRM 6.430.2.2.4.3): 1) within the first 30 days after their reporting date and; 2) annually, at the time of the Annual Evaluation discussion.

    4. Create a new plan for the upcoming rating period, immediately after completion of the current annual evaluation discussion.

    5. Timely prepare all required departure ratings.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-063#addtoany "Show all")

A2A