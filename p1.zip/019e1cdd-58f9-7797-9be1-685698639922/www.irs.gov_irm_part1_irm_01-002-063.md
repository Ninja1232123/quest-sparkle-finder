---
url: "https://www.irs.gov/irm/part1/irm_01-002-063"
title: "1.2.63 Division Delegations of Authority for Large Business and International | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-002-063#main-content)

- 1.2.63  [Division Delegations of Authority for Large Business and International](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833528701104)
  - 1.2.63.1  [Introduction to Division Delegations of Authority for LB&I](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527925824)
    - 1.2.63.1.1  [General Principles](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555810112)
  - 1.2.63.2  [Current LB&I Division Delegations of Authority](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833526287664)
    - 1.2.63.2.1  [Delegation Order LB&I 1-13-1 (formerly DO 020-100)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527927744)
    - 1.2.63.2.2  [Delegation Order LB&I 1-23-1 (formerly LMSB 193-1)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833526193584)
    - 1.2.63.2.3  [Delegation Order LB&I 1-23-2 (formerly LMSB 193-2)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833526203488)
    - 1.2.63.2.4  [Delegation Order LB&I 1-23-3 (formerly LMSB 193-3)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833526385024)
    - 1.2.63.2.5  [Delegation Order LB&I 1-23-4 (formerly LMSB 193-4)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555773808)
    - 1.2.63.2.6  [Delegation Order LB&I 1-23-5 (formerly LMSB 193-5)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527647456)
    - 1.2.63.2.7  [Delegation Order LB&I 1-23-7 (formerly LMSB 193-7)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555792256)
    - 1.2.63.2.8  [Delegation Order LB&I 1-23-8 (formerly LMSB 193-8)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833528817056)
    - 1.2.63.2.9  [Delegation Order LB&I 1-23-9 (formerly LMSB 193-9)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555810960)
    - 1.2.63.2.10  [Delegation Order LB&I 1-23-10](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527649808)
    - 1.2.63.2.11  [Delegation Order LB&I 1-23-12 (Rev. 1)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555854384)
    - 1.2.63.2.12  [Delegation Order LB&I 1-23-13 (formerly No. 036)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833528823600)
    - 1.2.63.2.13  [Delegation Order LB&I 1-23-14 (formerly No. 012)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527713568)
    - 1.2.63.2.14  [Delegation Order LB&I 1-23-15 (formerly No. 014 (Rev. 2))](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555856144)
    - 1.2.63.2.15  [Delegation Order LB&I 1-23-16](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833526207488)
    - 1.2.63.2.16  [Delegation Order LB&I 1-23-17](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527693520)
    - 1.2.63.2.17  [Delegation Order LB&I 1-23-18 (New)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555808432)
    - 1.2.63.2.18  [Delegation Order LB&I 4-1-1 (formerly No. 016-8)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555797120)
    - 1.2.63.2.19  [Delegation Order LB&I 4-2-1 (formerly LMSB 14-1)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527999136)
    - 1.2.63.2.20  [Delegation Order LB&I 4-11-1 (formerly No. 025-107)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555815488)
    - 1.2.63.2.21  [Delegation Order LB&I 6-1-1 (formerly LMSB 6-1-1)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833555843696)
    - 1.2.63.2.22  [Delegation Order LB&I 6-10-1 (formerly LMSB 92-1)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833526272656)
    - 1.2.63.2.23  [Delegation Order No. 017-97 (Rev. 1)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833527565136)
    - 1.2.63.2.24  [Delegation Order LB&I 25-6-1 (formerly LMSB 178-1)](https://www.irs.gov/irm/part1/irm_01-002-063#idm139833560693888)

# Part 1. Organization, Finance, and Management

# Chapter 2. Servicewide Policies and Authorities

# Section 63. Division Delegations of Authority for Large Business and International

* * *

## 1.2.63 Division Delegations of Authority for Large Business and International

#### Manual Transmittal

March 19, 2025

#### Purpose

(1) This transmits revised IRM 1.2.63, Servicewide Policies and Authorities, Division Delegations of Authority for Large Business and International.

#### Material Changes

(1) IRM 1.2.63.2.17: added new Division Delegation Order LB&I 1-23-18, Authority to Sign Certain Contact Letters for International Individual Compliance (IIC) Cases in the Campus Compliance Unit (CCU). The LB&I commissioner approved this delegation order on February 15, 2024. IRM citations for subsequent delegation orders were renumbered.

(2) Editorial corrections made throughout.

#### Effect on Other Documents

IRM 1.2.63 dated July 25, 2023 is superseded.

#### Audience

All LB&I employees

#### Effective Date

(03-19-2025)

Ronald H Hodge II

Assistant Deputy Commissioner Compliance Integration

Large Business and International Division

**1.2.63.1** **(03-19-2025)**

### Introduction to Division Delegations of Authority for LB&I

1. This IRM contains delegation orders (DO) for the Large Business and International (LB&I) Division. Distribution of this IRM should include all persons with a need for any of the authorities or information in this section. All approved LB&I division delegation orders are listed in numerical order.

2. Each LB&I delegation order is based on a Servicewide delegation order. Servicewide delegations of authority and can be found in IRM 1.2.2, Servicewide Delegations of Authority. A Portable Document Format (PDF) version of this IRM can be obtained through the Electronic Publishing website. Additional information on the delegation order process can be found in IRM 1.11.4, Servicewide Delegation Order Process.

3. The format and numbering are consistent with guidance from Servicewide Policy, Directives and Electronic Resources (SPDER). For example, delegation order LB&I 1-23-10 shows:



   - LB&I: the organization issuing the redelegation order

   - 1-23: the related Servicewide delegation order

   - 10: the sequential number to indicate that more than one redelegation can be issued for each Servicewide delegation order.


**1.2.63.1.1** **(06-03-2021)**

#### General Principles

1. Division delegation orders should be issued **only**at the operating division (headquarters) level. Questions about current delegation orders, including revisions or issuance of new division delegation orders, should be directed to the LB&I Internal Management Document (IMD) coordinator at \*LB&I IMD Coordinator.

2. Authority should be delegated directly to the lowest level expected to take final action. Delegating authority to the lowest level for action means that **every intervening supervisory position above the lowest level, including the Commissioner, has the same authority**.


**1.2.63.2** **(12-16-2021)**

### Current LB&I Division Delegations of Authority

1. Current LB&I division delegation orders are listed in numerical sequence. New or revised LB&I division delegation orders approved after this IRM revision can be found at [Recently Approved Division/Function Delegation Orders](https://www.irs.gov/privacy-disclosure/recently-approved-division-function-delegation-orders); all documents are maintained on the website until the next IRM revision.


**1.2.63.2.1** **(06-03-2021)**

#### Delegation Order LB&I 1-13-1 (formerly DO 020-100)

1. **Training and Training Needs for Officials of Foreign Governments**

2. **Authority:** To admit officials of foreign governments to training courses conducted by IRS and to authorize that they be supplied with texts and other training aids.

3. **Delegated to:** Director of Resource Solutions, Programs and Business Solutions

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-13

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order 020-100, effective October 1, 2000.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.2** **(06-03-2021)**

#### Delegation Order LB&I 1-23-1 (formerly LMSB 193-1)

1. **Notification Letters under IRC 6038, IRC 6046, and IRC 6046A**

2. **Authority:** To sign Notification Letters under 26 CFR § 1.6038-2, 26 CFR § 1.6038-3, 26 CFR § 1.6046-1, 26 CFR § 1.6046A-1, and IRC 6679 penalty for failure to file information with respect to IRC 6046 and IRC 6046A.

3. **Delegated to:** Internal Revenue Agents

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-1, effective March 1, 2007.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.3** **(06-03-2021)**

#### Delegation Order LB&I 1-23-2 (formerly LMSB 193-2)

1. **Notification Letters under IRC 6038A**

2. **Authority:** To sign notification letters under 26 CFR § 1.6038A-4, 26 CFR § 1.6038A-5, 26 CFR § 1.6038A-6 and 26 CFR § 1.6038A-7.

3. **Delegated to:** Internal Revenue Agents

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-2, effective March 1, 2007.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.4** **(06-03-2021)**

#### Delegation Order LB&I 1-23-3 (formerly LMSB 193-3)

1. **Notification Letters under IRC 6038B**

2. **Authority:**To sign notification letters under 26 CFR § 1.6038B-1 and 26 CFR § 1.6038B-2.

3. **Delegated to:** Internal Revenue Agents

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-3, effective March 1, 2007.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.5** **(06-03-2021)**

#### Delegation Order LB&I 1-23-4 (formerly LMSB 193-4)

1. **Notification Letters under IRC 6048 and IRC 6677 for Failure to File Form 3520**

2. **Authority:** To sign notification letters under IRC 6048(a), IRC 6048(c), and IRC 6677(a).

3. **Delegated to:** Internal Revenue Agents

4. **Redelegation:** This authority may not be redelegated.

5. **Sources of Authority:** Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-4, effective March 1, 2007.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.6** **(06-03-2021)**

#### Delegation Order LB&I 1-23-5 (formerly LMSB 193-5)

1. **Notification Letters under IRC 6048 and IRC 6677 for Failure to File Form 3520-A**

2. **Authority:** To sign notification letters under IRC 6048(b), IRC 6677(a), IRC 6677(b), and IRC 6677(c).

3. **Delegated to:** Internal Revenue Agents

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-5, effective March 1, 2007.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.7** **(06-03-2021)**

#### Delegation Order LB&I 1-23-7 (formerly LMSB 193-7)

1. **Superior Qualifications Appointment Authority**

2. **Authority:** To approve all superior qualifications appointments above the minimum rate of grade.

3. **Delegated to:** Manager, Human Capital Office, LB&I

4. **Redelegation:** This authority may not be redelegated.

5. **Sources of Authority:** Servicewide Delegation Order 1-23; HCO Policy No. 1 (PPD-0300-00S04)

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-7, effective May 1, 2008.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.8** **(06-03-2021)**

#### Delegation Order LB&I 1-23-8 (formerly LMSB 193-8)

1. **Pocket Commissions**

2. **Authority:** To approve issuance of Pocket Commissions to those employees under their jurisdiction who are authorized to possess them. Pocket Commissions will be issued to those employees who are required to present proof of their authority in the performance of their official duties. Pocket Commissions are primarily intended to identify Service personnel to the public when dealing with tax matters.

3. **Delegated to:**



   - Assistant Deputy Commissioner Compliance Integration

   - Director, Program and Business Solutions

   - All Practice Area Directors and Directors, Field Operations


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**IRM 10.2.6, Civil Enforcement and Non-Enforcement Pocket Commissions; Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-8, effective May 1, 2008.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.9** **(06-03-2021)**

#### Delegation Order LB&I 1-23-9 (formerly LMSB 193-9)

1. **Priority Consideration**

2. **Authority:** To redelegate to certain executive levels the authority to authorize priority consideration as an appropriate remedy for a merit promotion violation. IRM 6.335.1.12.8, Priority Consideration, requires priority consideration to be ordered by the Division Commissioner or the equivalent. The Division Commissioner or the equivalent may redelegate the approval authority for priority consideration to any executive or senior manager who is a direct report to the Division Commissioner or who is a direct report to an executive.

3. **Delegated to:**



   - Assistant Deputy Commissioner Compliance Integration

   - Director, Program and Business Solutions

   - All Practice Area Directors and Directors, Field Operations


4. **Redelegation:** This authority may not be redelegated.

5. **Sources of Authority:** IRM 6.335.1.12.8; Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 193-9, effective May 1, 2008.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.10** **(06-03-2021)**

#### Delegation Order LB&I 1-23-10

01. **Authority to Grant and Withhold Exemption from Withholding on Nonresident Aliens and Issue Final Exemption Payment Letter**

02. **Authority:** To execute with an alien individual and a withholding agent on behalf of the Internal Revenue Service a Central Withholding Agreement for gross income equal to or greater than $5 million.

03. **Delegated to:** Program Manager, Central Withholding Agreement Program, Withholding, Exchange, and Individual International Compliance (WEIIC), Large Business and International (LB&I)

04. **Authority:** To execute with an alien individual and a withholding agent on behalf of the Internal Revenue Service a Central Withholding Agreement for gross income less than $5 million.

05. **Delegated to:** Team Manager, Central Withholding Agreement Program, Withholding, Exchange, and Individual International Compliance (WEIIC), Large Business and International (LB&I)

06. **Authority:** To issue on behalf of the Internal Revenue Service a letter to the withholding agent stating the amount of the final payment of compensation for personal services that is exempt from withholding.

07. **Delegated to:** Team Manager, Central Withholding Agreement Program, Withholding, Exchange, and Individual International Compliance (WEIIC), Large Business and International (LB&I)

08. **Redelegation:** This authority may not be redelegated.

09. **Sources of Authority:**Servicewide Delegation Order 1-23 (formerly DO-193 (Rev. 6))

10. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

11. This delegation order supersedes all prior delegation orders.

12. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.11** **(06-03-2021)**

#### Delegation Order LB&I 1-23-12 (Rev. 1)

01. **Authorization to Perform Functions of the Commissioner, Large Business and International Division (LB&I), in Conjunction with the LB&I Reorganization of February 8, 2016**

02. **Authority:** To take any actions previously delegated to or authorized to be performed by Industry Directors, Director of Shared Support, and Director of Pre-Filing & Technical Guidance (LB&I).

03. **Delegated to:** All Practice Area Directors, Director of Program & Business Solutions, and Assistant Deputy Commissioner Compliance Integration (LB&I) who report directly to the LB&I Deputy Commissioner.

04. **Redelegation:** This authority may be redelegated to the lowest level previously authorized.

05. **Authority:** To take any actions previously delegated to or authorized to be performed by Directors of Field Operations and Deputy Directors (LB&I).

06. **Delegated to:** Directors and Deputy Directors who report directly to the LB&I Practice Area Directors, LB&I Program & Business Solutions Director, and Assistant Deputy Commissioner Compliance Integration.

07. **Redelegation:** This authority may be redelegated to the lowest level previously authorized.

08. **Authority:** To take any actions previously delegated to or authorized to be performed by the Deputy Commissioner (International), LB&I.

09. **Delegated to:** Deputy Commissioner, LB&I. This authority may be redelegated to the Director, Cross Border Activities Practice Area; the Director, Withholding, Exchange and International Individual Compliance Practice Area; and the Director, Treaty and Transfer Pricing Operations Practice Area.

10. **Redelegation:** This authority may be redelegated to the lowest level previously authorized.

11. **Source of Authority:** Servicewide Delegation Order 1-23.

12. To the extent that any action previously taken consistent with this order may require ratification, it is hereby approved and ratified. This Delegation Order supersedes LB&I Delegation Order 1-23-12 dated February 8, 2016.

13. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.12** **(06-03-2021)**

#### Delegation Order LB&I 1-23-13 (formerly No. 036)

1. **To Approve Requests for a Substitute Agent to Act on Behalf of a Consolidated Group**

2. **Authority:** To approve requests relating to the determination of a substitute agent to act on behalf of a consolidated group.

3. **Delegated to:** Managers, Workflow Coordination and Liaison, LB&I

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Treas. Reg. 1.1502-77A(d) or 1.1502-77B(d); Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order 036, effective June 19, 2003.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.13** **(06-03-2021)**

#### Delegation Order LB&I 1-23-14 (formerly No. 012)

1. **Authority to Grant and Withhold Exemption from Withholding Under IRC Section 1441 and 1442**

2. **Authority:** To grant exemption from income tax withholding to certain foreign partnerships and foreign corporations where such withholding imposes an undue administrative burden and that the corporations and that the collection of the tax will not be jeopardized by the exemption from withholding under Treasury Regulation Section 1.1441-4(f).

3. **Delegated to:** LB&I Territory Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Treas. Reg. 301.7701-9(b)-(c); Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order 012, effective October 1, 2000.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.14** **(06-03-2021)**

#### Delegation Order LB&I 1-23-15 (formerly No. 014 (Rev. 2))

1. **Authority to Sign Qualified Intermediary Agreements**

2. **Authority:** To sign qualified intermediary withholding agreements as prescribed under §1.1441-1(e)(5) of the income tax regulations and Revenue Procedure 2014-47.

3. **Delegated to:**



   - Director, Withholding, Exchange, and Individual International Compliance (WEIIC)

   - Team Manager, Foreign Payments Practice


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Revenue Procedure 2014-47; Servicewide Delegation Order 1-23

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order 014 (Rev. 2), effective October 1, 2000.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.15** **(09-29-2020)**

#### Delegation Order LB&I 1-23-16

01. **Revocation of Election to Adjust Basis of Partnership Property Under IRC 754**

02. **Authority:** To approve revocation of elections made to adjust basis of partnership property under Section 754 of the Internal Revenue Code.

03. **Delegated to:** LB&I Team Managers

04. **Redelegation:** This authority may not be redelegated.

05. **Authority:** To deny revocation of elections made to adjust basis of partnership property under Section 754 of the Internal Revenue Code.

06. **Delegated to:** LB&I Team Managers

07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:** Servicewide Delegation Order 1-23; Treas. Reg. 1.754-1

09. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

10. **Signed:** Douglas W. O’Donnell, Commissioner, Large Business and International Division


**1.2.63.2.16** **(10-21-2022)**

#### Delegation Order LB&I 1-23-17

1. **Error Tolerance Levels for LB&I Cases**

2. **Authority:** To accept and process an LB&I case if a computation error is the only issue and if the correction would be unfavorable to the taxpayer (more tax due or less refund).

3. **Delegated to:**




| For | Management Official |
| --- | --- |
| Errors that do not exceed $5,000 per tax year | LB&I Team Managers<br> based on the facts and circumstances of the case. |
| Errors that do not exceed $10,000 per tax year | LB&I Territory Managers<br> based on the facts and circumstances of the case. |
| Errors more than $10,000 per tax year | LB&I Directors of Field Operations<br> based on the facts and circumstances of the case. |

4. **Redelegation:**This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified.

7. **Signed:** Holly O. Paz, acting Commissioner, Large Business and International Division


**1.2.63.2.17** **(02-15-2024)**

#### Delegation Order LB&I 1-23-18 (New)

1. **Authority to Sign Certain Contact Letters for International Individual Compliance (IIC) Cases in the Campus Compliance Unit (CCU)**

2. **Authority:** To sign the following contact letters:



   - Letter 915, Examination Report Transmittal

   - Letter 914 (SP), Examination Report Transmittal (Spanish Version)

   - Letter 4149, We Have Not Received Your U.S. Self-Employment Tax Return

   - Letter 4149 (SP), We Have Not Received Your U.S. Self-Employment Tax Return (Spanish)

   - Letter 923, Extending Time to File Protest

   - Letter 686 (DO), Extension of Time for Certain Actions

   - Letter 686-B, Response to Taxpayer Request for Extension of Time to Reply


3. **Delegated to:** Withholding, Exchange, and International Individual Compliance (WEIIC) Tax Examiners in the CCU.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 1-23.

6. To the extent that authority previously exercised consistent with this order may require ratification, it is herby affirmed and ratified.

7. **Signed:** Holly O. Paz, Commissioner, Large Business and International Division


**1.2.63.2.18** **(06-03-2021)**

#### Delegation Order LB&I 4-1-1 (formerly No. 016-8)

1. **Agreements as to Liability For Personal Holding Company Tax**

2. **Authority:** To enter into agreements relating to a taxpayer’s liability for personal holding company tax.

3. **Delegated to:** Territory Managers

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 4-1

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order 016-8, effective October 1, 2000.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.19** **(04-24-2018)**

#### Delegation Order LB&I 4-2-1 (formerly LMSB 14-1)

1. **Extension of Time for Filing Statement of Grounds**

2. **Authority:** To grant an extension of time not to exceed thirty additional days for filing the statement of grounds called for in registered mail notification with respect to Accumulated Earnings Tax, 26 CFR 1.534-2.

3. **Delegated to:** LB&I Revenue Agents

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 4-2 (formerly DO 14 (Rev. 5))

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This Order supersedes Delegation Order LMSB 14-1, dated June 8, 2008.

7. **Signed:** Douglas W. O’Donnell, Commissioner, Large Business and International Division


**1.2.63.2.20** **(06-03-2021)**

#### Delegation Order LB&I 4-11-1 (formerly No. 025-107)

1. **Authority to Determine that Certain "Savings Institutions" Do Not Intend to Avoid Taxes by Paying Dividends or Interest for Periods Representing More Than 12 Months**

2. **Authority:** To determine that an organization referred to therein does not intend to avoid taxes (and therefore be permitted to deduct one tenth of the amount of dividends or interest not allowed as a deduction for a taxable year under 26 CFR 1.461-1(e)(1) in each of the succeeding taxable years).

3. **Delegated to:** LB&I Revenue Agent, not lower than GS-11

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 4-11(formerly DO-107 (Rev. 8)

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order 025-107, effective October 1, 2000.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.21** **(06-03-2021)**

#### Delegation Order LB&I 6-1-1 (formerly LMSB 6-1-1)

1. **Authority to Create and Abolish Positions**

2. **Authority:** To create and abolish positions. The abolishment of a position is defined as the actual termination of the position, with the duties eliminated entirely or combined with the duties of another position or positions.

3. **Delegated to:** Director, Resource Solutions

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 6-1

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 6-1-1, effective May 1, 2008.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.22** **(06-03-2021)**

#### Delegation Order LB&I 6-10-1 (formerly LMSB 92-1)

1. **Procurement of Training Using Standard Form (SF)-182 "Request, Authorization, Agreement and Certification of Training"**

2. **Authority:** To certify that the requested training meets the guidelines in Policy and Procedures Memorandum No. 70.3, IRS Office of Procurement Policy, which provides information on when the SF-182 should be used to obtain training services as opposed to using a purchase order or contract.

3. **Delegated to:** LB&I Training Analysts

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** Servicewide Delegation Order 6-10 (Rev. 1)

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 92-1, effective May 1, 2008.

7. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


**1.2.63.2.23** **(02-18-2005)**

#### Delegation Order No. 017-97 (Rev. 1)

01. **Closing Agreements Concerning Internal Revenue Tax Liability**



    ### Note:



    This delegation order is being published as it was originally written in 2005. The position titles and content of this delegation order are under review.

02. **Authority:** Commissioner's Delegation Order 8-3 (formerly DO-97 (Rev. 34))

03. **Authorization:**



    1. To enter into and approve a written agreement with any person relating to the Internal Revenue tax liability of such person (or the person or estate for whom he/she acts) for a taxable period or periods ended prior to the date of agreement and related specific items affecting other taxable periods. This does not include the authority to set aside any closing agreement.

    2. To enter into and approve a written agreement with any person relating to the Internal Revenue tax liability of such person (or of the person or estate for whom he/she acts) with respect to the performance of his or her functions as the Competent Authority under the tax conventions of the United States. This does not include the authority to set aside any closing agreement.

    3. In cases under the jurisdiction of Director, International, to enter into and approve written agreement with any person relating to the Internal Revenue tax liability of such person (or of the person or estate for whom he/she acts) and to provide for the mitigation of economic double taxation under section 3 of Revenue Procedure 64-54, 1964-2 C.B. 1008, under Revenue Procedure 72-22, 1972-1 C.B. 747, and under Revenue Procedure 69-13, 1969-1 C.B. 402, and to enter into and approve a written agreement providing the treatment available under Revenue Procedure 65-17, 1965-1 C.B. 833. This does not include the authority to set aside any closing agreement.


04. **Delegated to:** Deputy Director, International

05. **Redelegation:** This authority may not be redelegated.

06. To enter into and approve a written agreement with any person relating to the Internal Revenue tax liability of such person (or the person or estate for whom he/she acts) for a taxable period or periods ended prior to the date of agreement and related specific items affecting other taxable periods. This does not include the authority to set aside any closing agreement.

07. **Delegated to:** Director, Field Specialists

08. **Redelegation:** LMSB Field Specialist Program Managers

09. **Effect on Other Documents:** This revises Delegation Order 017-97 dated January 29, 2001.

10. **Issued by:** Kelly Cables for Deborah M. Nolan, Commissioner, Large and Mid-Size Business Division


**1.2.63.2.24** **(06-03-2021)**

#### Delegation Order LB&I 25-6-1 (formerly LMSB 178-1)

01. **Authority to Obligate Funds for Payment to Third Parties Who Request Reimbursement for Cost of Complying with a Summons (Form 6863)**

02. **Authority:** To obligate appropriated funds for payment of search costs, reproduction costs and transportation costs on connection with third party summonses.

03. **Authority:** To obligate up to $10,000 for payment of such costs associated with any one Summons.

04. **Delegated to:** Directors Field Operations

05. **Authority:** To obligate up to $5,000 for the payment of such costs associated with any one Summons.

06. **Delegated to:** Territory Manager

07. **Authority:** To obligate up to $2,500 for the payment of such costs associated with any one Summons.

08. **Delegated to:** Team Manager

09. **Redelegation:** This authority may not be redelegated.

10. **Source of Authority:** Servicewide Delegation Order 25-6 (formerly DO -178 (Rev. 6)

11. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified. This order supersedes Delegation Order LMSB 178-1, effective May 1, 2008.

12. **Signed:** Nikole C. Flax, Commissioner, Large Business and International Division


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-002-063#addtoany "Show all")

A2A