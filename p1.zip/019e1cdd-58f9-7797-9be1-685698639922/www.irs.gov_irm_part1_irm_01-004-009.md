---
url: "https://www.irs.gov/irm/part1/irm_01-004-009"
title: "1.4.9 Resource Guide for Management Officials - Criminal Investigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-009#main-content)

- 1.4.9  [Resource Guide for Management Officials - Criminal Investigation](https://www.irs.gov/irm/part1/irm_01-004-009#id1)
  - 1.4.9.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-009#id2)
    - 1.4.9.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-009#id4)
    - 1.4.9.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-009#id5)
    - 1.4.9.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-009#id6)
    - 1.4.9.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-009#id7)
    - 1.4.9.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-009#id8)
    - 1.4.9.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-009#id9)
    - 1.4.9.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-009#id10)
  - 1.4.9.2  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-009#id11)
    - 1.4.9.2.1  [Line of Authority](https://www.irs.gov/irm/part1/irm_01-004-009#id12)
    - 1.4.9.2.2  [Duties of the Supervisory Special Agent](https://www.irs.gov/irm/part1/irm_01-004-009#id13)
      - 1.4.9.2.2.1  [Duties of the Supervisory Investigative Analyst](https://www.irs.gov/irm/part1/irm_01-004-009#id15)
    - 1.4.9.2.3  [Duties of the Special Agent in Charge and Assistant Special Agent in Charge](https://www.irs.gov/irm/part1/irm_01-004-009#id16)
    - 1.4.9.2.4  [Duties of the Director, Field Operations](https://www.irs.gov/irm/part1/irm_01-004-009#id17)
  - 1.4.9.3  [Criminal Tax Counsel, DOJ and the United States Attorney](https://www.irs.gov/irm/part1/irm_01-004-009#id18)
  - 1.4.9.4  [Development and Initiation of Investigations](https://www.irs.gov/irm/part1/irm_01-004-009#id19)
  - 1.4.9.5  [Group Workload](https://www.irs.gov/irm/part1/irm_01-004-009#id20)
  - 1.4.9.6  [Case and Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-009#id21)
    - 1.4.9.6.1  [Active Investigations Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-009#id23)
    - 1.4.9.6.2  [Pipeline Investigations Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-009#id24)
    - 1.4.9.6.3  [Investigation Information](https://www.irs.gov/irm/part1/irm_01-004-009#id25)
    - 1.4.9.6.4  [Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-009#id26)
    - 1.4.9.6.5  [SIA Case and Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-009#id27)
    - 1.4.9.6.6  [Active Tickets and Investigation Reviews](https://www.irs.gov/irm/part1/irm_01-004-009#id28)
    - 1.4.9.6.7  [Investigation Information – For active and ongoing tickets](https://www.irs.gov/irm/part1/irm_01-004-009#id29)
    - 1.4.9.6.8  [Workload Reviews – When Necessary](https://www.irs.gov/irm/part1/irm_01-004-009#id30)
  - 1.4.9.7  [Special Agent in Charge/Assistant Special Agent in Charge Reviews of Group Operations](https://www.irs.gov/irm/part1/irm_01-004-009#id31)
  - 1.4.9.8  [Review of Prosecution Recommendation Reports](https://www.irs.gov/irm/part1/irm_01-004-009#id32)
  - 1.4.9.9  [Assurance and Advisory Reviews](https://www.irs.gov/irm/part1/irm_01-004-009#id33)
    - 1.4.9.9.1  [Leadership Effectiveness](https://www.irs.gov/irm/part1/irm_01-004-009#id35)
    - 1.4.9.9.2  [Identified Agency and Investigative Priorities](https://www.irs.gov/irm/part1/irm_01-004-009#id36)
    - 1.4.9.9.3  [Program Accomplishments](https://www.irs.gov/irm/part1/irm_01-004-009#id37)
    - 1.4.9.9.4  [Investigative Selection](https://www.irs.gov/irm/part1/irm_01-004-009#id38)
    - 1.4.9.9.5  [Productivity and Efficiency](https://www.irs.gov/irm/part1/irm_01-004-009#id39)
    - 1.4.9.9.6  [Investment in Operational Capabilities](https://www.irs.gov/irm/part1/irm_01-004-009#id40)
    - 1.4.9.9.7  [Risk Assessment](https://www.irs.gov/irm/part1/irm_01-004-009#id41)
    - 1.4.9.9.8  [Best Practices](https://www.irs.gov/irm/part1/irm_01-004-009#id42)
  - 1.4.9.10  [Required Briefings and Reports](https://www.irs.gov/irm/part1/irm_01-004-009#id43)
  - 1.4.9.11  [Trauma Management for Managers](https://www.irs.gov/irm/part1/irm_01-004-009#id44)
    - 1.4.9.11.1  [Procedures and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-009#id45)
      - 1.4.9.11.1.1  [Notification](https://www.irs.gov/irm/part1/irm_01-004-009#id47)
      - 1.4.9.11.1.2  [Family Support](https://www.irs.gov/irm/part1/irm_01-004-009#id48)
      - 1.4.9.11.1.3  [Criminal Investigation Personnel Support](https://www.irs.gov/irm/part1/irm_01-004-009#id49)
      - 1.4.9.11.1.4  [Benefits](https://www.irs.gov/irm/part1/irm_01-004-009#id50)
    - 1.4.9.11.2  [Post Use of Force Procedures Checklist](https://www.irs.gov/irm/part1/irm_01-004-009#id51)
  - 1.4.9.12  [Imprest Fund](https://www.irs.gov/irm/part1/irm_01-004-009#id52)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 9. Resource Guide for Management Officials - Criminal Investigation

* * *

## 1.4.9 Resource Guide for Management Officials - Criminal Investigation

#### Manual Transmittal

August 07, 2025

#### Purpose

(1) This transmits revised IRM 1.4.9, Resource Guide for Management Officials - Criminal Investigation.

#### Material Changes

(1) IRM 1.4.9, revised to comply with Executive Orders and Office of Personnel Management (OPM) memorandums regarding diversity, equity, inclusion (DEI) gender, or related subject matter.

(2) IRM 1.4.9.9.6 (a) removed term Diversity.

#### Effect on Other Documents

This IRM supersedes IRM 1.4.9, August 05, 2024.

#### Audience

Criminal Investigation (CI)

#### Effective Date

(08-07-2025)

Guy A. Ficco

Chief, Criminal Investigation

**1.4.9.1** **(08-05-2024)**

### Program Scope and Objectives

1. Purpose: The various topics in this section include:



   - Responsibilities

   - Workload Selection and Assignments

   - Management Responsibilities When Initiating Investigations

   - Workload Reviews

   - Review of Group Operations by the Special Agent in Charge (SAC) or Assistant Special Agent in Charge (ASAC)

   - Review of Prosecution Recommendation Reports

   - Assurance and Advisory (AA)

   - Required Briefings

   - Trauma Management for Supervisory Special Agents (SSA)


2. Audience: All CI employees in management positions.

3. Policy Owner: Director, Assurance & Advisory (A&A) and Director, National Criminal Investigation Training Academy (NCITA).

4. Program Owner: Director, A&A and Director, NCITA.

5. Primary Stakeholders: All CI employees in management positions.

6. Contact Information: To make changes to this IRM section email CIHQIRM@ci.irs.gov.


**1.4.9.1.1** **(08-05-2024)**

#### Background

1. This section is intended to serve as a guide to assist Criminal Investigation (CI) management officials.


**1.4.9.1.2** **(08-05-2024)**

#### Authority

1. The authorities for this program manual can be found in:



   - IRM 9.1.2, Authority (Criminal Investigation),

   - IRM 1.2, Servicewide Policies and Authorities,

   - IRM 1.4, Resource Guide For Managers,

   - IRM 1.5, Managing Statistics in a Balanced Measurement System.


**1.4.9.1.3** **(08-05-2024)**

#### Roles and Responsibilities

1. The Director, A&A and Director, NCITA are responsible for developing, maintaining, and overseeing this IRM and ensuring compliance with current policies and procedures.


**1.4.9.1.4** **(08-05-2024)**

#### Program Management and Review

1. The Director, A&A and Director, NCITA will:



1. Review the IRM annually.

2. Update the IRM when content is no longer accurate and reliable to ensure employees correctly complete their work assignments.

3. Incorporate all permanent interim content into the next version of the IRM section prior to the expiration date.


**1.4.9.1.5** **(08-05-2024)**

#### Program Controls

1. The Director, A&A and Director, NCITA will review the instructions and guidelines relating procedural, operational, and editorial changes.


**1.4.9.1.6** **(06-22-2022)**

#### Acronyms

1. The table lists commonly used acronyms and their definitions:



|     |     |
| --- | --- |
| **Acronym** | **Definition** |
| AA | Assurance and Advisory |
| ABP | Annual Business Plan |
| ADP | Automated Data Processing |
| AFC | Asset Forfeiture Coordinator |
| AO | Administrative Officer |
| ASAC | Assistant Special Agent in Charge |
| BSA | Bank Secrecy Act |
| CFR | Code of Federal Regulations |
| CI | Criminal Investigation |
| CI | Confidential Informant |
| CIMIS | Criminal Investigation Management Information System |
| CIS | Computer Investigative Specialist |
| COPS | Concerns of Police Survivors |
| CSA | Compliance Support Assistants |
| CT | Criminal Tax |
| CW | Cooperating Witness |
| DOJ | Department of Justice |
| EAP | Employee Assistance Program |
| EEO | Equal Employment Opportunity |
| FECA | Federal Employees Compensation Act |
| FEGLI | Federal Employee Group Life Insurance |
| GI | General Investigation |
| HQ | Headquarters |
| HR | Human Resources |
| IA | Investigative Analyst |
| IDP | Individual Development Plan |
| LEAP | Law Enforcement Availability Pay |
| LEM | Law Enforcement Manual |
| NCITA | National Criminal Investigation Training Academy |
| OPM | Office of Personnel Management |
| PFP | Physical Fitness Program |
| PI | Primary Investigations |
| PIO | Public Information Officer |
| SAC | Special Agent in Charge |
| SCI | Subject Criminal Investigations |
| SIA | Supervisory Investigative Analyst |
| SSA | Supervisory Special Agents |
| SSA | Social Security Administration |
| TFIA | Tax Fraud Investigative Assistants |
| TIGTA | Treasury Inspector General for Tax Administration |
| TIMS | Total Inventory Management System |


**1.4.9.1.7** **(08-05-2024)**

#### Related Resources

1. IRM 1.2.2.15.5, Delegation Order 25-5 (formerly DO-143, Rev. 6), Authority to Perform Certain Functions to Enforce 31 CFR 103 (Bank Secrecy Act Regulations),

2. IRM 6.430.3.4.1, Monitoring Commitments or Objectives,

3. IRM 9.3.2.4.2, Role of the Supervisory Special Agent and Special Agent,

4. IRM 9.4.1, Investigation Initiation,

5. IRM 9.5.12, Processing Completed Criminal Investigation Reports,

6. IRM 9.11.4, Personnel Matters,

7. IRM 9.12.1, Miscellaneous Administrative Procedures.


**1.4.9.2** **(06-22-2022)**

### Responsibilities

1. Criminal Investigation management officials are responsible for the efficient and effective utilization of the CI workforce to accomplish the strategies and mission of IRS and CI.

2. The SSA/SIA is responsible for the efficient and effective performance of their assigned group and its assigned responsibilities. The primary responsibility of the group is to investigate significant financial crimes in accordance with established policies and programs.

3. The SAC and ASAC are responsible for the efficient and effective operation of the assigned field office.

4. The Director, Field Operations is responsible for the effective and efficient operation of their assigned area. The Director, Field Operations are members of the Chief, CI’s executive staff and assist in the development of the annual business plan.

5. Directors who report to the Chief, CI, are responsible for their assigned areas of responsibilities.

6. The Chief and Deputy Chief, CI, are responsible for leading the organization in achieving the CI mission, as well as the overall mission of the IRS.


**1.4.9.2.1** **(06-22-2022)**

#### Line of Authority

1. Criminal Investigation special agents, and CSA are under the direction of an SSA.

2. Criminal Investigation investigative professional staff (TFIAs and IAs) are under the direction of the SIA.

3. Supervisory Special Agents and Supervisory Investigative Analysts supervise employees in their assigned group and are under the direction of and report to the SAC and/or the ASAC. In field offices without an ASAC, the SSA/SIA report directly to the SAC. In field offices with an ASAC, the SSA/SIA will follow the chain of command and report first to the ASAC.

4. Assistant Special Agents in Charge supervise SSAs/SIAs and are under the direction of the SAC. The ASAC may also supervise other personnel such as the PIO, budget analyst, AO, management analyst, and intelligence analyst.

5. Special Agents in Charge, depending on the configuration of the field office supervise SSAs and/or ASACs. The SAC is under the direction of the Director, Field Operations. The SAC may also supervise other personnel such as the PIO, budget analyst, AO, and management analyst.

6. Director, Field Operations supervises SACs and area office analysts. The Director, Field Operations is under the direction of the Chief, CI.

7. The Chief and Deputy Chief, CI, are under the direction of the IRS Deputy Commissioner.


**1.4.9.2.2** **(06-22-2022)**

#### Duties of the Supervisory Special Agent

1. The SSA plans and directs the group's work by:



01. Providing leadership in carrying out CI-HQ and field office plans and programs

02. Assigning investigations and other work and reviewing and redistributing the workload as necessary

03. Directing senior employees to assist in planning and directing the work of the other group employees

04. Directing employees to plan, schedule, and perform activities within the scope of their duties

05. Keeping current with relevant legislation, court decisions, and directives

06. Advising employees on policies, procedures, and investigative techniques

07. Reviewing completed investigative reports

08. Providing training, career development opportunities, and advice for employees

09. Directing clerical employees to perform secretarial, clerical and administrative duties such as arranging appointments, monitoring and routing incoming calls and correspondence, assembling data and preparing reports, etc.

10. Evaluating employee performance (including the mandatory mid-year evaluation at the six month point)

11. If delegated by the SAC/ASAC, authorizing PI, which are not related to money laundering BSA violations

12. Maintaining good relationships with other IRS operating divisions and other law enforcement agencies, including the United States Attorney’s Office

13. Designating an acting SSA when necessary

14. Encouraging compliance through publicity of the activities that CI undertakes to enforce the laws within CI’s jurisdiction, see IRM 9.3.2 (subsection 9.3.2.4.2, Role of the Supervisory Special Agent and Special Agent)

15. Conducting joint quarterly four-way conferences for both administrative and grand jury investigations unless waived by both operating divisions


2. The SSA is responsible for a wide range of administrative and clerical matters. These include, but are not limited to:



1. Timely and accurate updating of the CIMIS database (within 5 days) and TIMS. The accuracy and completeness of these databases is critical to the proper operation of the group, field office, and HQ.

2. Ensuring the proper and timely completion, submission and filing of all monthly reports for all agents.

3. Proper and timely completion of all annual certifications by all employees.

4. Ensuring that all employee diaries are complete and up-to-date.

5. Timely completion of required tax return and equipment inventories.

6. Timely completing and documenting of all workload and case reviews (Minimum of three case reviews per year and one workload review). It is recommended that the workload review be scheduled in conjunction with the employee’s mid-year evaluation.

7. Timely and accurate submission of all ad hoc reports required by the field office.

8. Timely and accurate completion and submission of all other periodic reports pertaining to the group, such as consensual monitoring reports, and so forth, are properly completed and timely submitted.


3. The SSA will look to the SAC/ASAC for direction and guidance relative to operations. The SSA will keep the SAC/ASAC informed on all significant developments, major activities, and problems within the group which may affect upper management. It is especially important that the SAC/ASAC immediately be made aware of any issue that may come to the attention of the news media, other agencies or operating units, or anyone above the SAC in the chain of command. In particular, the SSA will advise the SAC/ASAC of any significant occurrence such as:



1. Personnel problems

2. Inquiries made by HQ or the Director, Field Operations’ staff

3. Unusual request from the attorney for the government

4. Significant and/or sensitive investigations


4. The SSA will keep Criminal Tax (CT) Counsel advised of all investigations, enforcement actions and significant investigative developments.


**1.4.9.2.2.1** **(06-22-2022)**

##### Duties of the Supervisory Investigative Analyst

1. The SIA plans and directs the group’s work by:



01. Providing leadership in carrying out CI-HQ and field office plans and programs.

02. Assigning investigations and other work and reviewing and redistributing the workload as necessary.

03. Directing senior employees to assist in planning and directing the work of the other group employees.

04. Directing employees to plan, schedule, and perform activities within the scope of their duties.

05. Keeping current with relevant legislation, court decisions, and directives.

06. Advising employees on policies, procedures, and investigative techniques.

07. Reviewing completed investigative products.

08. Providing training, career development opportunities, and advice for employees.

09. Directing clerical employees to perform secretarial, clerical and administrative duties such as arranging appointments, monitoring and routing incoming calls and correspondence; keeping a record of original tax returns charged to the group; servicing and maintaining controls and files; assembling data and preparing reports, etc.

10. Evaluating employee performance (including the mandatory mid-year evaluation at the six-month point).

11. Maintaining good relationships with other IRS operating divisions and other law enforcement agencies, including the United States Attorney’s Office.

12. Designating an acting SIA when necessary.

13. Encouraging compliance through publicity of the activities that CI undertakes to enforce the laws within CI’s jurisdiction, see IRM 9.3.2 (similar to subsection 9.3.2.4.2).

14. Conducting quarterly conferences with ASAC about case support issues as is needed as determined by the ASAC/SAC.


2. The SIA is responsible for a wide range of administrative and clerical matters.


    These include, but are not limited to:



1. Timely and accurate updating of the Footprints ticket assignment system and TIMS. The accuracy and completeness of these databases is critical to the proper operation of the group, field office, and HQ.

2. Ensuring the proper and timely completion, submission and filing of all reports for all investigative professional staff.

3. Proper and timely completion of all annual certifications by all employees.

4. Ensuring that all employee diaries are complete and up-to-date.

5. Timely completion of required tax return and equipment inventories.

6. Timely completing and documenting of all workload reviews.



      ### Note:



      Minimum of two evaluation reviews per year, and two workload reviews per year. It is recommended that the workload review be scheduled in conjunction with the employee’s mid-year evaluation.

7. Timely and accurate submission of all ad hoc reports required by the field office.

8. Timely and accurate completion and submission of all other periodic reports pertaining to the group, such as footprints updates, progress reports, support analysis, and so forth are properly completed and timely submitted.


3. The SIA will look to the SAC/ASAC for direction and guidance relative to operations. The SIA will keep the SAC/ASAC informed on all significant developments, major activities, and problems within the group which may affect upper management. It is especially important that the SAC/ASAC immediately be made aware of any issue that may come to the attention of the news media, other agencies or operating units, or anyone above the SAC in the chain of command. In particular, the SIA will advise the SAC/ASAC of any significant occurrence such as:



1. Personnel problems

2. Inquiries made by HQ or the Director, Field Operations’ staff

3. Unusual request from the attorney for the government

4. Special interest investigations


4. The SIA will keep Criminal Tax (CT) Counsel advised of all investigations, enforcement actions and significant investigative developments. (If deemed necessary by management)


**1.4.9.2.3** **(03-29-2019)**

#### Duties of the Special Agent in Charge and Assistant Special Agent in Charge

1. The SAC/ASAC plans and directs the field office by:



01. Developing operating unit practices and achieving program objectives and providing leadership in carrying out CI-HQ and field office plans and programs.

02. Finding solutions to operational problems.

03. Effectively and efficiently dealing with staffing and personnel problems.

04. Assigning investigations and other work and reviewing and redistributing the workload as necessary.

05. Authorizing investigations. Authorization of SCI and PI relative to money laundering and BSA violations generally rests exclusively with the SAC (see IRM 9.4.1, General, Primary and Subject Investigations.) Certain sensitive SCIs must be approved by the Director, Field Operations (see IRM 9.4.1, Investigation Initiation).

06. Directing employees to plan, schedule, and perform activities within the scope of their duties.

07. Keeping current with relevant legislation, court decisions, and directives.

08. Reviewing completed investigative reports.

09. Special Agents in Charge are responsible for making referrals to the DOJ.

10. Authorizing enforcement actions; confidential informant (CI), CW, and source of information.

11. Providing training and career development opportunities and advice for employees.

12. Evaluating employee performance.

13. Maintaining good relationships with the IRS operating divisions and other law enforcement agencies, as well as the United States Attorney’s Office(s).

14. Designating an Acting SAC/ASAC when necessary.

15. Encourage compliance through publicity of the activities that CI undertakes to enforce the laws within CI’s jurisdiction (see IRM 9.3.2, subsection 9.3.2.4.2, Roles of the Supervisory Special Agent and Special Agent).


2. The SAC/ASAC is responsible for a wide range of administrative and clerical matters. These include, but are not limited to:



1. Timely and accurate updating of CIMIS and TIMS. The accuracy of these databases is critical to the proper operation of the group, field office, and HQ.

2. Proper and timely completion, submission and filing of all monthly and annual reports.

3. Proper and timely completion of all annual certifications by all employees.

4. Ensuring that all employee diaries are complete and up-to-date.

5. Timely completion of required tax return and equipment inventories.

6. Timely completing and documenting of all workload reviews.

7. Timely and accurate submission of all ad hoc reports required by the area office.

8. Timely and accurate completion and submission of all other periodic reports pertaining to the field office, such as consensual monitoring reports, undercover reports, CI/CW reviews, undercover documents and so forth are properly completed and timely submitted.


**1.4.9.2.4** **(12-30-2010)**

#### Duties of the Director, Field Operations

1. The Director, Field Operations plans and directs the area office work by:



01. Providing leadership in carrying out CI-HQ plans and programs.

02. Keeping current with relevant legislation, court decisions, and directives.

03. Authorizing sensitive investigation (see IRM 9.4.1, General, Primary and Subject Investigations).

04. Reviewing completed sensitive investigation reports.

05. Providing training and career development opportunities and advice for employees.

06. Evaluating employee performance.

07. Timely completing and documenting reviews of his/her assigned field offices.

08. Proper and timely completion of all annual certifications by all employees.

09. Timely and accurate completion and submission of all periodic reports pertaining to the area office.

10. Designating an Acting Director, Field Operations when necessary.


**1.4.9.3** **(12-30-2010)**

### Criminal Tax Counsel, DOJ and the United States Attorney

1. Criminal Tax Counsel will review all Title 26 and sensitive investigation prosecution recommendations, grand jury requests, requests to use special investigative techniques (e.g., consensual monitoring and undercover operations), search warrant affidavits and related enforcement action review forms, search warrant inventories and seizure warrant affidavits, and prepare law and fact memoranda.

2. It is the SSA's responsibility to develop and maintain a good working relationship with attorneys for the government which includes the US Attorney’s Office and the DOJ. The US Attorney is the primary “customer” of CI, without which CI cannot function. The SSA, in coordination with the SAC and ASAC, will work together with the attorney for the government to determine the investigative inventory of the group. The program goals of the IRS will be taken into consideration, as well as the willingness and ability of the US Attorney's Office and DOJ to allocate resources to achieving these goals.

3. The SSA should be alert for:



1. The need for additional help in grand jury investigations, trial preparation and trial.

2. When the attorney for the government is considering not prosecuting a subject who was recommended for prosecution.

3. Investigations in which there are potential plea bargains, nolle prosequi and/or sentencing.


**1.4.9.4** **(06-22-2022)**

### Development and Initiation of Investigations

1. .It is the responsibility of the SSA/SIA to ensure that their special agents and investigative staff work at developing significant criminal investigations. Investigations come from a wide variety of sources. Investigations can be initiated from information obtained within the IRS when a revenue agent or revenue officer detects possible fraud. Information is also routinely received from the public, as well as from ongoing investigations underway by other law enforcement agencies or by the United States Attorney’s Office.

2. The SSA/SIA should encourage the special agents within the group to maintain close relationships and regular contact with the US Attorney's Office, other law enforcement agencies, and the other operating divisions to increase the potential of generating quality, high profile investigations.

3. The SSA is responsible for doing everything possible to support the compliance efforts of the other operating divisions. This is particularly important in the area of fraud referrals. This includes timely evaluation of fraud referrals received from the other operating divisions (see IRM 9.4.1, General, Primary and Subject Investigations). Criminal Investigation management will encourage fraud awareness and referrals from the other operating divisions by:



1. Speaking at group meetings and training classes.

2. Inviting managers and agents from the other operating divisions to group meetings to discuss ways of maintaining a high level of cooperation.

3. Conducting a thorough, complete and professional evaluation of fraud referrals received from the other operating divisions. This includes evaluating the totality of the referral and not just the information listed on the referral form.

4. As appropriate, preparing memoranda commending the referring agent for above average performance.

5. Identifying badges of fraud and additional actions to be taken to sustain the fraud penalty.


4. Supervisory Special Agents and Supervisory Investigative Analysts are responsible for reviewing requests to initiate criminal investigations. If delegated the authority, the SSA will initiate Title 26 PIs. All sensitive SCIs are authorized by the Director, Field Operations. If delegated the authority, the ASAC will authorize Title 26 SCIs. The SAC will authorize all other investigations.



### Note:



Investigations of banks and brokers or dealers in securities referenced in 31 CFR 103.46(a)(1) through 103.46(a)(6) for possible criminal violations of 31 CFR Part 103 (except 31 CFR 103.23 and 103.48) must be authorized by the Chief, CI. See IRM 1.2.52, Delegation Order 25-5 (formerly DO 143 (Rev. 6)) and IRM 9.4.1, General, Primary, and Subject Investigations.

5. Supervisory Special Agents are responsible for reviewing and forwarding requests to initiate investigations other than those within their authority to authorize.

6. Special agents will prepare the request to initiate an SCI according to the established policies and procedures. The SSA will review the request, and decide whether to forward the request for authorization, based on the following factors:



1. The allegation(s) and the potential for criminal prosecution.

2. The information and evidence developed by the special agent.

3. The LEM guidelines and other local prosecutorial standards.

4. Program goals and guidelines.

5. The current field office inventory.

6. Ability to prove the allegations in light of potential weaknesses.

7. Other prosecutorial considerations, such as venue, statute of limitations, age and health of subject, notoriety of subject, other agencies involved, etc.


7. If the SSA decides to forward a SCI initiation package, he/she or his/her designee, will review 100% of the CIMIS input for accuracy, which will then be entered into CIMIS as the initial accuracy review. Unified Checklist and/or workflows will be consulted for the most recent update on what documents must be included in the package that goes to the ASAC/SAC/Director, Field Operations. These documents will always include a memorandum explaining the allegations. The nature and extent of any additional documents required depends on whether the investigation is to be conducted administratively or under the auspices of a grand jury. Furthermore, it will depend upon whether it is tax/non-tax, service initiated or attorney for the government initiated, or an expansion of an existing grand jury.


**1.4.9.5** **(06-22-2022)**

### Group Workload

1. The SSA/SIA has an important responsibility in identifying, selecting, and assigning work within their assigned group. Factors to be considered:



1. Complying with IRS guidelines.

2. Identifying areas of willful noncompliance.

3. Providing coverage in areas of noncompliance identified in the ABP and IRS strategies.

4. Selecting investigations which will positively impact on compliance and in accordance with the LEM.

5. Maintaining a balanced workload within the group (assuming it is not a specialty group). Maintaining a balanced workload involves coordination with the SAC/ASAC to determine the proper proportion of group investigations involving legal source income, illegal source income, narcotics and terrorism investigations.


2. Supervisory Special Agents and Supervisory Investigative Analyst will attempt to match the type, level and complexity of the investigation with the ability of the assigned special agent. If this is not possible, the SSA/SIA will provide additional supervision or assign a senior special agent to assist with the investigative planning and implementation.

3. Supervisory Special Agents and Supervisory Investigative Analyst will closely monitor all assignments to ensure timely completion. Although deadlines often change due to a variety of circumstances, it is the responsibility of the SSA/SIA to ensure that investigations do not lie dormant or become stagnant. It is also the responsibility of the SSA /SIA to ensure that time is not wasted on unnecessary tasks. Each special agent should have an appropriate mix of investigations, information gathering and evaluative assignments.

4. Supervisory Special Agents and Supervisory Investigative Analyst must balance the importance of efficiently completing an investigation with his/her responsibility to develop employees by challenging their ability. Employees are usually best developed by providing increasingly complex assignments.


**1.4.9.6** **(06-22-2022)**

### Case and Workload Reviews

1. Three times per year the SSA will conduct case reviews of each agent’s inventory and completely and fully document them within CIMIS, utilizing the Plan of Significant Actions and SSA Case Load Review. The Plan of Significant Actions and SSA Case Load Review must show the guidance and direction provided to the special agent.

2. The annual workload review will be conducted at the mid-year of the special agent’s evaluation period . In addition to the areas covered in the case review, the workload review will cover administrative areas including the special agent’s diary, law enforcement availability pay, special agent development, government vehicle maintenance, returns inventory and controls, and investigative equipment. The workload review will address the special agent’s performance.


**1.4.9.6.1** **(03-06-2017)**

#### Active Investigations Case Reviews

1. The following areas, at a minimum, should be covered during each case review:



01. Accuracy of the CIMIS and TIMS entries relating to the special agent's investigations

02. Violations being investigated

03. Years being investigated

04. Activities accomplished since last review

05. Expectations to be accomplished before the next review

06. Potential problems with the investigation

07. CIMIS updates

08. Estimated completion dates

09. Date of last four-way conference (administrative investigations)

10. Revenue agent involvement

11. Statute of limitations, with special attention being paid to allowing enough time for the prosecution recommendation review process

12. Elapsed time and time applied to the investigation

13. Asset seizure and forfeiture potential


**1.4.9.6.2** **(03-06-2017)**

#### Pipeline Investigations Case Reviews

1. The following areas, at a minimum, should be reviewed on pipeline investigations:



1. Current location of investigations in the pipeline

2. Narrative of last contact the special agent had with the assigned attorney for the government

3. Actions on investigation since last review

4. Date anticipated for indictment, trial, sentencing, etc.


**1.4.9.6.3** **(03-29-2019)**

#### Investigation Information

1. The SSA will be able to supply the following investigation information:



1. Date the subject was first contacted and/or interviewed

2. Date the preparer and accountant was first contacted and/or interviewed

3. Summary of activity to date

4. Extent of case reviews, including inspection of documents, schedules, and other analysis prepared from obtained evidence

5. Problems encountered or anticipated

6. Status of pipeline investigations

7. Status of closed investigations with conditions of probation

8. Written feedback and follow-up action items

9. Summary of discussions with case agents and AFC regarding asset forfeiture potential in appropriate investigations


**1.4.9.6.4** **(06-22-2022)**

#### Workload Reviews

1. Workload reviews include the case review outlined above, plus a review of the following items:



01. Diary (acceptable notations), (see IRM 9.12.1, Miscellaneous Administrative Procedures)

02. LEAP status

03. Travel vouchers (timeliness and accuracy)

04. Special agent development

05. IDP to include IDP accomplishments, objectives and goals, training requested and completed

06. Usage of Group 40/41

07. Collateral assignments such as on-the-job instructor, firearms/use of force instructor, asset forfeiture coordinator, physical fitness coordinator, program coordinator, etc.

08. Miscellaneous duties

09. CI/CW log review, active/inactive

10. Security; including physical office and desk security

11. Document security (electronic and paper)

12. Computer security policy review

13. Returns inventory

14. Controls from Form 4135, Criminal Investigation Control Notice

15. Closed investigations with conditions of probation

16. Assigned government vehicle-maintenance, upkeep and anticipated problems

17. Firearm qualification status

18. ADP usage

19. Investigative equipment that is not specifically assigned to a special agent

20. Appraisal of performance since last evaluation


**1.4.9.6.5** **(06-22-2022)**

#### SIA Case and Workload Reviews

1. Per IRM 6.430.3.4.1, supervisors are responsible for monitoring employee performance, which includes a mandatory Mid-year Review and Annual Rating.

2. SIAs are not required to conduct formal Workload Reviews, except under the “circumstances” noted below. The nature of the work and workflow requires the SIA’s involvement through most phases of the IA and TFIA assignments. Every assignment flows through the SIA providing an opportunity for the SIA to assess the complexity of the work, review the final product, seek feedback, observe turn-around times, and provide meaningful guidance. The SIA can easily monitor employee performance without the additional administrative step of a formal workload review. This is also a distinction from Scheme Development Center (SDC) SIAs. SDC IAs are involved in long-term scheme support and therefore, similar to SSAs, it is necessary for the SDC SIAs to conduct Workload Reviews with SDC IAs to monitor employee performance.

3. Circumstances that necessitate a field office SIA to conduct a formal Workload Review with an IA/TFIA:



   - Long-term assignment

   - Complex or sensitive investigation

   - Performance issue


4. Informal workload discussions with employees are required to be regular and ongoing as SIAs are responsible for the overall average completion time on requests submitted to the team. It is the responsibility of the SIA to monitor the progress of requests and make adjustments in assignments, as needed, to ensure high quality products quick turn-around times, and full utilization of available resources.


**1.4.9.6.6** **(06-22-2022)**

#### Active Tickets and Investigation Reviews

1. The following areas, at a minimum, should be covered during each case review:



01. Accuracy of the responses to specific Footprint requests

02. Violations and the nature of ongoing tickets

03. Anticipated time to complete ticketed requests (may need to be reviewed frequently when connected to long term complex investigations)

04. Activities accomplished since last review

05. Expectations to be accomplished before the next review

06. Potential problems with the investigation

07. Footprints updates

08. Estimated completion dates

09. Date of last conference with agent(s) involved

10. Time required for support for specific ticketed requests


**1.4.9.6.7** **(06-22-2022)**

#### Investigation Information – For active and ongoing tickets

1. The SIA will be able to supply the following investigation information:



1. Date the investigative professional staff was first contacted for case assistance

2. Date(s) of interaction between assigned professional staff and agent(s) involved

3. Summary of activity to date

4. Extent of assistance request, including inspection of documents, schedules, and other analysis prepared from obtained evidence

5. Problems encountered or anticipated

6. Status of investigations

7. Status of closed investigations

8. Written feedback and follow-up action items


**1.4.9.6.8** **(06-22-2022)**

#### Workload Reviews – When Necessary

1. Workload reviews include the case review outlined above, plus a review of the following items:



01. Diary (acceptable notations), (see IRM 9.12.1, Miscellaneous Administrative Procedures)

02. Footprints tickets

03. Travel vouchers (timeliness and accuracy)

04. IA and TFIA development

05. IDP if requested to include IDP accomplishments, objectives and goals, training requested and completed

06. Collateral assignments such as Palantir TIS, Program/Platform SMEs, HIDTA assignments, program coordinator, etc

07. Miscellaneous duties

08. Security; including physical office and desk security

09. Document security (electronic and paper)

10. Computer security policy review

11. Returns inventory – if assigned as a duty

12. Closed investigations

13. Investigative equipment

14. Appraisal of performance since last evaluation


**1.4.9.7** **(06-22-2022)**

### Special Agent in Charge/Assistant Special Agent in Charge Reviews of Group Operations

1. The SAC/ASAC will conduct group operational reviews every six months utilizing, in part, the CIMIS SAC/ASAC Operational Review function. The reviews include in-depth discussions of:



01. The accuracy of the CIMIS and TIMS databases

02. Investigations and special agents

03. Closed investigations with conditions of probation

04. A sampling of diaries

05. Sign out logs or computer calendar entries

06. Administrative controls

07. Collaterals

08. Referrals

09. Tax returns

10. Suspense items

11. Drop files

12. IDP's

13. Investigation development

14. Undercover operations

15. Budget items

16. Workload/case reviews and planned activity

17. Group meeting minutes

18. Group staffing and resource needs

19. Quarterly joint four-way conferences

20. LEAP

21. PFP

22. EEO

23. Development of employees

24. Personnel problems

25. Other problems or concerns


2. The CI Operation Review Checklist can assist the SSA/SIA in preparing for reviews. The checklist covers:



1. Planning and implementation

2. Management controls

3. Management of resources

4. EEO and development of employees

5. Communications

6. General observations

7. Action items; follow-up


**1.4.9.8** **(12-30-2010)**

### Review of Prosecution Recommendation Reports

1. Management’s duties and responsibilities in processing and reviewing completed prosecution recommendation reports are contained in IRM 9.5.12, Processing Completed Criminal Investigation Reports.


**1.4.9.9** **(06-22-2022)**

### Assurance and Advisory Reviews

1. Assurance and Advisory will conduct operational reviews of each field office on a periodic basis as determined by ongoing analysis and risk assessment. These reviews are performed by a team of senior analysts, MPAs, and other management personnel from field offices outside the selected office under review. The areas of review include:



1. Leadership effectiveness

2. Identified agency and investigative priorities

3. Program accomplishments

4. Investigation selection

5. Productivity and efficiency

6. Investment in operational capabilities

7. Risk assessment

8. Best practices


2. An in-depth review guide is available from Assurance and Advisory.


**1.4.9.9.1** **(03-29-2019)**

#### Leadership Effectiveness

1. This portion of the operational review is to determine field office leadership involvement in the day-to-day operations. Communication and direction are key factors to leadership’s effectiveness on operations and work environment.


**1.4.9.9.2** **(06-22-2022)**

#### Identified Agency and Investigative Priorities

1. This area of the operational review is to evaluate the field office’s strategy and accomplishments in achieving national goals. Emphasis will be on how the field office is implementing the national strategies and annual business plans and the Chief’s Investigative Priorities memorandum.

2. Information from CIMIS and prior AA and Director Field Office reviews will be analyzed.


**1.4.9.9.3** **(06-22-2022)**

#### Program Accomplishments

1. The AA team evaluates the quality, impact and balance of investigations among the legal income, illegal income, narcotics and terrorism programs and the various subprograms. This portion of the review is focused on the investigative strategies and how the strategies are being implemented within the program area, in part by considering:



1. Performance indicators

2. Statute usage

3. Effectual use of investigative techniques

4. Evaluation of the CIS program

5. Financial management

6. Communications and relationships


**1.4.9.9.4** **(12-30-2010)**

#### Investigative Selection

1. The following areas are reviewed to evaluate the field office’s selection of investigations:



1. Assignments

2. Fraud referral program

3. Sources of investigations


**1.4.9.9.5** **(12-30-2010)**

#### Productivity and Efficiency

1. The field office will be evaluated on the timely and competent use of limited resources available for working, disposing, and processing investigations. The crucial indicators are elapsed time and applied time.


**1.4.9.9.6** **(08-07-2025)**

#### Investment in Operational Capabilities

1. The field office will be evaluated on some of those elements that form the infrastructure that exists to perform IRS and CI’s missions. Items that will be reviewed are:



1. Development and training

2. Ethics and integrity

3. Centralized review

4. Seized asset management

5. ADP

6. Administrative areas


**1.4.9.9.7** **(06-22-2022)**

#### Risk Assessment

1. Assurance and Advisory will utilize all known data to assess field office risk and risk awareness. This portion of the review will focus not only on identifying risk, but also identifying management’s awareness of risk and the actions taken to address and mitigate risk.


**1.4.9.9.8** **(06-22-2022)**

#### Best Practices

1. Assurance and Advisory will identify and report best practices in an effort to find more efficient and effective operational strategies and procedures.


**1.4.9.10** **(06-22-2022)**

### Required Briefings and Reports

1. Criminal Investigation managers are required to provide annual briefings to employees and credentialed task force officers. The briefings are required to be conducted in a timely manner and documented as required by established policy and procedure.

2. Supervisory Special Agents and Supervisory Investigative Analysts are required to annually provide designated briefings to special agents, support personnel and credentialed task force officers. The briefings are to be documented and certified to the Chief, CI.

3. The following are some of the briefings required to be provided to employees:



1. Vehicles

2. Surveillance and Non-Consensual Monitoring

3. Use of Force Policies, including:



      > - Employee Conduct on Being Arrested
      >
      >       - Firearms Safety
      >
      >       - TSA Regulations

4. Ethics

5. Security, including:



      > - TECS/IDRS Security
      >
      >       - Computer Security
      >
      >       - Security of Property and Documents

6. Outside Employment

7. Medical Policies


**1.4.9.11** **(03-29-2019)**

### Trauma Management for Managers

1. Criminal Investigation will provide the appropriate response and support to special agents, special agent’s families and CI personnel following the critical injury or death of a special agent while performing job related duties.

2. Criminal Investigation will provide liaison assistance to the immediate survivors of any special agent who is critically injured or dies while performing job related duties (line-of-duty). Furthermore, a critical incident stress debriefing coordinated by the EAP will be made available to all affected CI personnel (see IRM 9.11.4, Personnel Matters).

3. Criminal Investigation will provide the appropriate response and support to special agents following the use of force by the special agent while performing job related duties.


**1.4.9.11.1** **(12-30-2010)**

#### Procedures and Responsibilities

1. This subsection contains procedures and responsibilities following critical injury or death of a special agent.


**1.4.9.11.1.1** **(06-22-2022)**

##### Notification

1. In the event of a critical injury or death of a special agent while performing job related duties, CI will make notification as designated by the special agent in the Form 11208, Confidential Line of Duty Notification Information. The name of the injured or deceased special agent must never be released before this notification is made.

2. Notification will be made in a timely manner (within one hour) by the SAC. If the SAC is unable to make the notification, he/she will designate the next highest ranking CI special agent to make notification timely. If a CI special agent cannot make notification timely, a local law enforcement agency will be requested to make notification.

3. If the SAC is unable to personally make notification timely, he/she will contact the individual(s) to be notified in person, as soon as possible.

4. If there is an opportunity to get the individual(s) to be notified to the hospital prior to the death of the special agent, notification will not be delayed to assemble the appropriate delegation.



1. If the notified individual(s) requests to visit the hospital, he/she will be transported by someone from CI. Due to the possibility of shock, it is highly recommended that the notified individual(s) not drive themselves to the hospital.

2. If young children are involved, CI will provide assistance to include arrangement for supervision of the children (as required).


5. Notification must always be made in person by two CI employees (SA, SSA, ASAC or SAC) and never alone. If the individual being notified has a medical problem, medical personnel should be available at the location at the time of notification.

6. Notification must never be made on the door step. The SAC or his/her, designated representative will ask to be admitted to the residence and ask the individual(s) to be seated prior to notification.

7. Notification will be made slowly, clearly, including all information currently available, and should never convey false hope. The special agent will always be referred to by name and the words "died" and "dead" should be used rather than "passed away" or "gone" .


**1.4.9.11.1.2** **(03-29-2019)**

##### Family Support

1. In the event a special agent is hospitalized with critical injuries sustained while performing job related duties the special agent’s SSA, or designated representative, will:



1. Coordinate with hospital personnel to provide appropriate waiting facilities for family members and CI personnel (separate if possible).

2. Establish a press staging area separate from waiting facilities for family members and CI personnel.

3. Coordinate transportation for the family to and from the hospital.

4. Coordinate with the hospital and HR to ensure that the medical bills related to the injured or deceased special agent are not sent to the special agent’s residence or family.

5. Ensure the special agent’s family is promptly provided all available information relating to the special agent’s condition. This includes providing specific information on how the special agent was injured, as well as allowing the family to spend time with the special agent, if possible. The SSA should not be overly protective of the family.

6. Notify the SAC of the current condition of the injured special agent and any changes in that condition.


2. In the event of a special agent’s death while performing job related duties, the SSA, or designated representative, will:



1. Notify the surviving family of the special agent’s desire to have or not to have a law enforcement funeral as specified in the Confidential Line of Duty Notification Information form and provide all possible assistance with funeral arrangements, as requested.

2. Coordinate reimbursement of funeral and burial expenses not to exceed $800. If the special agent resides within the United States and dies away from his/her official duty station, an additional sum may be paid for transportation of the remains to the official duty station city (20 CFR 10.412, Claims for Compensation Under the FECA).

3. Issue a message to include name of deceased; date and time of death; circumstance surrounding the death; funeral arrangements (state if service will be private or a law enforcement funeral); detail regarding the family’s request, if any, for expressions of sympathy in lieu of flowers; and contact person and telephone number for additional information.

4. Obtain an American flag to be presented to the family.

5. Coordinate an escort for the surviving family to the appropriate National Law Enforcement Officers Memorial Services (if applicable) by contacting COPS at (573) 346-4911 or www.concernsofpolicesurvivors.org

6. On the following year, observe the special agent’s death date with a short note to the family and/or flowers to the grave site.

7. Coordinate with the special agent’s family to return the special agent’s personal items. These items will be neatly boxed and cleaned (if soiled).


3. If criminal violations surround the critical injury, or death, of a special agent while performing job related duties, the SSA, or designated representative, will:



1. Inform the special agent and/or the special agent’s family of all new developments prior to press release.

2. Keep the special agent and/or the special agent’s family apprised of legal and parole proceedings.

3. Introduce the special agent and/or the special agent’s family to the victim assistance specialist of the court.

4. Encourage the special agent and/or the special agent’s family, to attend the trial and accompany them whenever possible.

5. Arrange for investigators to meet with the special agent and/or the special agent’s family at the earliest opportunity following the trial to answer all their questions.


**1.4.9.11.1.3** **(12-30-2010)**

##### Criminal Investigation Personnel Support

1. Criminal Investigation personnel who were involved (as witnesses or participants) in the event(s) which lead to the critical injury or death of a special agent will be required to attend a critical incident stress debriefing conducted by a trained mental health professional (coordinated through the EAP) prior to resuming job related duties outside of the office. It is highly recommended that this debriefing occur within 72 hours of the incident.

2. A critical incident stress debriefing by a trained mental health professional (coordinated through the EAP) will be made available to any CI employee who may have been emotionally affected by the critical injury or death of a special agent while performing related duties.

3. Information concerning individuals who participated in the EAP is confidential and governed by Federal regulations which impose criminal penalties for improper disclosure. Records and EAP counselor’s notes pertaining to an individual’s participation in this program are privileged and will not be referred to or made part of an employee’s official personnel file. The confidentiality of these records/information, whether recorded or not, will be maintained in accordance with the Title 42, CFR, Part 2 (Appendix D) the Privacy Act, 5 USC §552a (1984), and all other related laws and regulations.


**1.4.9.11.1.4** **(06-22-2022)**

##### Benefits

1. In the event of critical injury or death of a special agent while performing job related duties the SSA will act as liaison between the special agent or the special agent’s beneficiary and coordinate with HR to ensure all applicable forms and reports are promptly completed and submitted to:



1. The Office of Worker’s Compensation Programs, US Department of Labor (all injuries sustained in the performance of job related duties are covered).

2. The Office of Personnel Management, Employee Service and Records Center, Boyers, Pennsylvania 16017.


2. If the special agent dies while enrolled in a self and family plan with a designated Federal government health insurance provider, any family member covered by the plan is eligible for continued coverage. The survivor’s share of the cost of the plan will be deducted from the annuity check (through the Federal Health Benefits Program). However, once the insurance coverage is canceled, the coverage cannot be reinstated. Office of Personnel Management has the responsibility of determining the survivor annuitant status.

3. If the special agent dies while enrolled in the FEGLI, OPM will provide eligible survivors with an application for benefits. A certified copy of the death certificate should be attached to the application.

4. All uncashed annuity checks made payable to the deceased special agent must be returned to OPM. Government checks made payable to a deceased annuitant cannot legally be cashed by anyone. Office of Personnel Management will not authorize survivor benefits until the Treasury Department informs them that there are no outstanding checks payable to the deceased special agent. If annuity payments are sent directly to a financial institution, promptly notify OPM and the financial institution of the special agent’s exact date of death. The Treasury Department will recover the amount from the depositor. Do not attempt to make individual repayment by personal check or money order to OPM or the Treasury Department.

5. In addition to the monthly benefits the survivors receive, the deceased special agent’s spouse is entitled to a one-time death payment of $255 from the Social Security Administration.

6. The survivors of the special agent may be entitled to benefits from state and local agencies (to be determined on a state by state basis).

7. In the event of critical injury or death of a special agent while performing job related duties, the SSA will coordinate with HR to provide the special agent or the special agent’s beneficiary(ies) a report of the various benefits available (including who to contact and when the payment can be expected). The SSA will meet with the special agent or the special agent’s beneficiary(ies) in approximately six months to ensure the benefits were, or will be received.

8. The Public Safety Officer’s Benefit Act provides a one-time tax free benefit to eligible survivors of a Federal law enforcement agent whose death is the direct and proximate result of a traumatic injury sustained in the line-of-duty. This benefit is also provided for officers that have been permanently or totally disabled in the line of duty. As of October 1, 2021, the death benefit amount was $389,825.00 [https://bja.ojp.gov/program/psob](https://bja.ojp.gov/program/psob) . If applicable, the SSA or designated representative will promptly prepare and submit a Report of Public Officer’s Death or Permanent and Total Disability to accompany the disabled special agent or survivor’s claims to the US DOJ. Due to the limitation and exclusions subject to this benefit the composition of the report will be carefully considered. To expedite initiation and payment of a claim, telephone the Public Safety Officer’s Benefits Program, Bureau of Justice Assistance at 1-888-744-6513; fax the claim packet to 202-616-0314; or mail the claim packet to 810 7th Street, NW Washington, DC 20531.

9. The EAP provides all employees and their immediate family counseling services at no cost. All the counselors are licensed professionals and all discussions are completely confidential.


**1.4.9.11.2** **(03-29-2019)**

#### Post Use of Force Procedures Checklist

1. The responding SSA will:



1. Ensure medical treatment is obtained as needed.

2. Ensure the subject and the scene are secure.

3. Contact local police, the TIGTA, and the SAC.

4. Appoint a companion special agent for each involved special agent.

5. In a shooting incident, place IRS firearms used in evidence with local police; obtain a receipt for the weapon.

6. In the case of a special agent’s death or serious injury, ensure the special agent’s spouse/family is notified; utilize Form 11208, Confidential Line of Duty Notification Information.

7. Send a copy of the Form 9776, Use of Force Incident Report to the NCITA.


2. The function of the special agent’s companion is to remain at the side of the special agent involved in a traumatic incident. The special agent involved in the incident is probably experiencing varying degrees of stress. The companion special agent probably cannot do very much in relieving the stress, but can help in handling it through the long periods of waiting and interviews that may follow. The companion special agent and the involved special agent most likely will be feeling uncomfortable at this time, so the companion special agent should relax and let conversation flow naturally.

3. The companion special agent:



1. Should not talk about specific details of the incident (i.e., when, where, why, etc.).

2. Should not make congratulatory comments.

3. Try to head off congratulatory type comments from other people.


4. It is okay for the companion special agent to:



1. Talk about unrelated subjects.

2. Empathize with the special agent and let him/her know you are trying to share what he/she is going through.

3. Talk about thoughts concerning the incident if the involved special agent wants to discuss them. The companion special agent may even encourage the special agent to talk about his/her thoughts at this time. The companion agent must remember that the special agent has a right to his/her thoughts even if they are painful or make them feel uncomfortable.


5. The companion special agent will not argue with the special agent involved in the incident.

6. The companion special agent should try to let the special agent involved in the incident do most of the talking.


**1.4.9.12** **(12-30-2010)**

### Imprest Fund

1. The Investigative imprest fund is a negotiable instrument charged against a government appropriation account and advanced to a duly authorized cashier.

2. Investigative imprest funds are set up as a vehicle for special agents of CI to make expenditures of a confidential nature. In some instances the investigative imprest fund can be used for non-confidential expenses where normal procurement procedures cannot be used.

3. The Director, Beckley Finance Center has the authority to establish the investigative imprest fund in field offices upon determining that there is no other satisfactory means of providing funds essential to the enforcement of pertinent laws and regulations. For additional information on the investigative imprest fund see the Investigative Imprest Fund Overview for SSA posted in the e-library on the CI Web.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-009#addtoany "Show all")

A2A