---
url: "https://www.irs.gov/irm/part1/irm_01-004-050"
title: "1.4.50 Collection Group Manager, Field Compliance Manager and Area Director Operational Aid | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-050#main-content)

- 1.4.50  [Collection Group Manager, Field Compliance Manager and Area Director Operational Aid](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621767480128)
  - 1.4.50.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738806320)
    - 1.4.50.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738789840)
    - 1.4.50.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738787888)
    - 1.4.50.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738776560)
    - 1.4.50.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738772832)
    - 1.4.50.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738767008)
    - 1.4.50.1.6  [Terms](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738761104)
    - 1.4.50.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738745216)
    - 1.4.50.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738697936)
  - 1.4.50.2  [Role of the Field Collection Manager](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738665248)
    - 1.4.50.2.1  [Communicating Expectations](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738646176)
    - 1.4.50.2.2  [Group Meetings](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738637536)
    - 1.4.50.2.3  [ENTITY End Of Month (EOM) Processing](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738630976)
  - 1.4.50.3  [General Managerial Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738623168)
    - 1.4.50.3.1  [Administrative](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738622144)
      - 1.4.50.3.1.1  [Employee Performance File (EPF)](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738607600)
      - 1.4.50.3.1.2  [Employee Drop File (EDF)](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738593744)
      - 1.4.50.3.1.3  [Medical Information](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738590992)
      - 1.4.50.3.1.4  [Acting Group Manager Assignments and Designations](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738588448)
    - 1.4.50.3.2  [Protecting Taxpayer Rights](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738579680)
      - 1.4.50.3.2.1  [Direct Contact For Taxpayers With/or Requesting Representation](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738550112)
      - 1.4.50.3.2.2  [Recording Taxpayer Interviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738540608)
      - 1.4.50.3.2.3  [Fair Tax Collection Practices](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738538704)
      - 1.4.50.3.2.4  [Ex Parte Communication With Appeals/GM Action Necessary](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738524768)
    - 1.4.50.3.3  [IDRS](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738509632)
      - 1.4.50.3.3.1  [IDRS Security](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738507856)
    - 1.4.50.3.4  [Employee Safety/Security](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738500768)
    - 1.4.50.3.5  [Working With NTEU](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738496000)
    - 1.4.50.3.6  [After Hours Security Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738489088)
  - 1.4.50.4  [Employee Development/Training](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738476864)
    - 1.4.50.4.1  [Consultation Process](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738465408)
      - 1.4.50.4.1.1  [Cases Included in the Consultation Process](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738455232)
      - 1.4.50.4.1.2  [Collection Consultation Exclusions](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738451968)
  - 1.4.50.5  [Performance Management](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738444768)
    - 1.4.50.5.1  [Performance Evaluation](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738443040)
    - 1.4.50.5.2  [Reviews (Overview)](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738412272)
      - 1.4.50.5.2.1  [Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738393568)
      - 1.4.50.5.2.2  [Requirements for Annual Performance Case Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738373056)
      - 1.4.50.5.2.3  [Field and Office Observations](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738363024)
        - 1.4.50.5.2.3.1  [Telephonic Observations](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738344736)
      - 1.4.50.5.2.4  [Time Utilization Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738332528)
      - 1.4.50.5.2.5  [Work Submitted for Approval/Closure](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738324304)
    - 1.4.50.5.3  [Use of Statistical Data/Section 1204 /ROTERs](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738320272)
      - 1.4.50.5.3.1  [Tax Enforcement Results (TERs)](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738305504)
      - 1.4.50.5.3.2  [Regulation 801/ Quantity & Quality Measures](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738303040)
    - 1.4.50.5.4  [Retention Standard](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738294560)
    - 1.4.50.5.5  [Within Grade Increase](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738289792)
    - 1.4.50.5.6  [Evaluation Due Dates](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738284160)
    - 1.4.50.5.7  [Discipline/Disciplinary Actions](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738281536)
  - 1.4.50.6  [Telework](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738272000)
    - 1.4.50.6.1  [Managing In a Telework Environment](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738267664)
    - 1.4.50.6.2  [Interaction With Employees On Telework](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738249808)
  - 1.4.50.7  [Recognition and Awards](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738239888)
  - 1.4.50.8  [Field Collection Workload Management](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738233664)
    - 1.4.50.8.1  [Total Inventory Management (TIM)](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738228736)
    - 1.4.50.8.2  [Using ENTITY For Workload Management](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738226496)
      - 1.4.50.8.2.1  [ENTITY Case Management System Reports](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738215984)
    - 1.4.50.8.3  [Queue](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738210368)
    - 1.4.50.8.4  [Case Priority Level](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738207840)
  - 1.4.50.9  [Hold Files](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738198640)
    - 1.4.50.9.1  [Group Designation Hold File](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738196976)
      - 1.4.50.9.1.1  [Shelving Erroneously Assigned Cases/Modules](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738183088)
      - 1.4.50.9.1.2  [Federal Agency Delinquency Cases](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738169504)
    - 1.4.50.9.2  [Group Hold Files](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738143872)
  - 1.4.50.10  [Assigning Work](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738121760)
    - 1.4.50.10.1  [Case Grade](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738043152)
    - 1.4.50.10.2  [Maintaining Targeted Inventories](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621738030960)
      - 1.4.50.10.2.1  [Inventory Adjustments](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737988800)
    - 1.4.50.10.3  [Reassignment of Departing Revenue Officer Inventory](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737967536)
    - 1.4.50.10.4  [Case Load Rotation](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737959904)
    - 1.4.50.10.5  [Tax Examiner (TE) Case Assignments](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737957008)
      - 1.4.50.10.5.1  [Cases Requiring Managerial Review Prior to Transfer to the Queue](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737947696)
    - 1.4.50.10.6  [Disaster Issues and Replacement Inventory](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737938720)
      - 1.4.50.10.6.1  [Systemic Disaster Freeze Account Indicators](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737936096)
      - 1.4.50.10.6.2  [-O Freeze Inventory](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737930832)
      - 1.4.50.10.6.3  [Replacement Inventory](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737923168)
      - 1.4.50.10.6.4  [Requesting and Assignment of Replacement Inventory](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737917680)
      - 1.4.50.10.6.5  [Impact of Replacement Inventory on Revenue Officer Inventory Levels and Employee Observations](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737911664)
      - 1.4.50.10.6.6  [Disposition of Replacement Inventory at the End of the Disaster Period](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737903904)
    - 1.4.50.10.7  [Revenue Officer Compliance Sweeps](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737898384)
      - 1.4.50.10.7.1  [Revenue Officer Compliance Sweep Locations and Participants](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737895648)
      - 1.4.50.10.7.2  [Revenue Officer Compliance Sweep Inventory Assignment](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737893216)
    - 1.4.50.10.8  [Assignment of Abusive Tax Avoidance Transactions (ATAT) Inventory](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737889616)
      - 1.4.50.10.8.1  [Collection ATAT Coordinator Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737881408)
      - 1.4.50.10.8.2  [ATAT Group Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737869408)
      - 1.4.50.10.8.3  [Sources of ATAT Inventory](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737866528)
      - 1.4.50.10.8.4  [ATAT Designated Hold Files](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737860048)
      - 1.4.50.10.8.5  [Prioritization of ATAT Work](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737849232)
  - 1.4.50.11  [Group Controls](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737830672)
    - 1.4.50.11.1  [Financial Controls, Remittance Control Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737818720)
    - 1.4.50.11.2  [Protecting the Public Interest, CSED Accounts](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737797904)
    - 1.4.50.11.3  [Protecting the Public Interest, ASED Accounts and TFRP Monitoring](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737788416)
    - 1.4.50.11.4  [Protecting the Public Interest, Notice of Federal Tax Lien Determinations](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737742016)
    - 1.4.50.11.5  [Taxpayer Rights, Timely Processing of Collection Due Process (CDP) and Equivalent Hearing (EH) Requests](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737720448)
    - 1.4.50.11.6  [Taxpayer Rights, FinCEN Query Monitoring](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737717072)
    - 1.4.50.11.7  [Taxpayer Rights, Compliance Data Warehouse Knowledge Graph Environment (CKGE) Monitoring](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737704496)
    - 1.4.50.11.8  [Records Management, Closed Case File Transmittals](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737681456)
    - 1.4.50.11.9  [Suspension of Case Aging](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737677728)
    - 1.4.50.11.10  [Taxpayer Rights, Sensitive Case Reports](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737667680)
  - 1.4.50.12  [Quality](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737662816)
    - 1.4.50.12.1  [EQRS](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737648016)
    - 1.4.50.12.2  [NQRS](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737642400)
    - 1.4.50.12.3  [EQ Consistency Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737636704)
    - 1.4.50.12.4  [Revenue Officer Case Documentation](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737632576)
  - 1.4.50.13  [Field Compliance Manager Employee Engagement Operational Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737626896)
    - 1.4.50.13.1  [Frequency and Planning](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737623552)
    - 1.4.50.13.2  [Documentation](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737615520)
    - 1.4.50.13.3  [Leadership & Human Capital-Employee Satisfaction](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737605744)
    - 1.4.50.13.4  [Employee Engagement](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737588560)
    - 1.4.50.13.5  [Customer Service and Collaboration-Customer Satisfaction](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737573056)
    - 1.4.50.13.6  [Program Management-Business Results](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737555584)
    - 1.4.50.13.7  [Administrative/Compliance Review](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737533360)
  - 1.4.50.14  [Area Director Reviews and Employee Engagement and Operational Reviews](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737520208)
    - 1.4.50.14.1  [Planning and Documentation](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737516416)
  - Exhibit  1.4.50-1  [Revenue Officer Case Assignment Guide](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737495616)
  - Exhibit  1.4.50-2  [Criteria for Review of Completed Work](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737375792)
  - Exhibit  1.4.50-3  [Target Inventory Levels and Inventory Adjustments Q&A](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737160256)
  - Exhibit  1.4.50-4  [Action Steps For Acceptable Level Of Competence Determination is an Employee Within Grade Increase (WGI) is Due.](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737122448)
  - Exhibit  1.4.50-5  [Suggested Action Steps For Unacceptable Performance](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737088816)
  - Exhibit  1.4.50-6  [Collection Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737056688)
  - Exhibit  1.4.50-7  [Remittance Processing Transmission Control Review Template](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737024400)
  - Exhibit  1.4.50-8  [CKGE Research Review Template](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621737008544)
  - Exhibit  1.4.50-9  [FinCEN Query Review Template](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621736993104)
  - Exhibit  1.4.50-10  [After hours Security Review](https://www.irs.gov/irm/part1/irm_01-004-050#idm140621736978288)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 50. Collection Group Manager, Field Compliance Manager and Area Director Operational Aid

* * *

## 1.4.50 Collection Group Manager, Field Compliance Manager and Area Director Operational Aid

#### Manual Transmittal

April 01, 2025

#### Purpose

(1) This transmits revised IRM 1.4.50, Collection Group Manager, Field Compliance Manager and Area Director Operational Aid.

#### Material Changes

(1) The following table outlines changes made to IRM 1.4.50, Collection Group Manager, Field Compliance Manager and Area Director Operational Aid. It incorporates updated procedures, editorial changes and clarifications since the revision dated October 20, 2023.

| **Number** | **IRM Subsection** | **Description** |
| :-: | :-: | :-: |
| 1 | IRM Section Title | The name of this IRM section was updated to Collection Group Manager, Field Compliance Manager and Area Director Operational Aid to reflect the change in the organizational title of Field Collection second level managers. |
| 2 | IRM 1.4.50.1, Program Scope and Objectives-Audience | Added background information for the revision of the title of second level managers in field collection from territory manager to field compliance manager. |
| 3 | IRM 1.4.50.1.6, Acronyms | Table updated to add additional acronyms used throughout this IRM. |
| 4 | IRM 1.4.50.4.1, Consultation Process | Included language that instructs managers to add business priority cases to the collection consultation plan in certain circumstances. References to Form 6456, Conference or Contact Memorandum were replaced with **Memorandum** due to the obsolescence of the Form 6456. |
| 5 | IRM 1.4.50.5.7, Discipline/Disciplinary Actions | Added a subsection to remind group managers to apply section 1204(b), the retention standard when employees intentionally disregard IRS policies or statutory requirements that result in a violation of taxpayer’s rights and to contact Labor Relations for appropriate action. |
| 6 | IRM 1.4.50.10(6), Compliance Initiative Projects | Added guidance on the assignment and identification of approved Compliance Initiative Project referral cases. |
| 7 | IRM 1.4.50.10(7) | Expanded the guidance on cases received from ACS potentially meeting mandatory assignment criteria and provides an example where expedited assignment of cases received from ACS may be appropriate. |
| 8 | IRM 1.4.50.10.2.1, Inventory Adjustments. | Added information about Special Compliance Program designations for ATAT revenue officers. |
| 9 | IRM 1.4.50.10.8, Assignment of Abusive Tax Avoidance Transaction (ATAT) Inventory | Added a new section for the assignment of ATAT inventory. |
| 10 | IRM 1.4.50.10.8.1, Collection ATAT Coordinator Responsibilities | Added a new section on the responsibilities of Area ATAT Coordinators. |
| 11 | IRM 1.4.50.10.8.2, ATAT Group Manager Responsibilities | Added a new section on the responsibilities of Collection ATAT group managers. |
| 12 | IRM 1.4.50.10.8.3, Sources of ATAT Inventory | New section describing the sources of ATAT inventory available to ATAT group managers. |
| 13 | IRM 1.4.50.10.8.4, ATAT Designated Hold Files | Added a new section on the purpose and use of the ATAT designated hold file in ICS. |
| 14 | IRM 1.4.50.10.8.5, Prioritization of ATAT Work | New section on the prioritization of inventory for assignment to ATAT revenue officers. |
| 15 | IRM 1.4.50.11, Group Controls | Updated this section to provide an overview and list of group control categories. |
| 16 | IRM 1.4.50.11.1, Remittance Control Reviews | Added instructions on how to generate Exhibit 1.4.50-7 to document remittance control reviews. |
| 17 | IRM 1.4.50.11.2, CSED Accounts | Revised the name of this subsection to reflect the category of group control to **Protecting the Public Interest, CSED Accounts.** Added a note recommending imminent CSED reports be generated more frequently during the months of January through April. |
| 18 | IRM 1.4.50.11.3, ASED Accounts | Revised the name of this subsection to reflect the category of group control to **Protecting the Public Interest, ASED accounts and TFRP Monitoring.** Combined prior subsection 1.4.4.50.11.4 into this subsection. Added instruction on how to generate the imminent ASED report in ENTITY. Added the requirement for group managers to generate ENTITY query **ASED Query 4/15/XX** to identify potential imminent ASED modules where the ASED field is blank. Added descriptions of the ATFR manager reports including the references for timely TFRP investigation actions. Added language extending the recommendation to generate imminent ASED reports to October through April. |
| 19 | IRM 1.4.50.11.4, Monitoring Trust Fund Recovery Penalty (TFRP) Accounts | Prior Material in this subsection was relocated to IRM 1.4.50.11.3. Added Content for NFTL determinations was relocated from IRM 1.4.50.11 to this section, creating a separate subsection. |
| 20 | IRM 1.4.50.11.5, Taxpayer Rights, Timely Processing of Collection Due Process and Equivalent Hearing Requests. | Subsection title renamed to identity the category of group control. |
| 21 | IRM 1.4.50.11.6, Taxpayer Rights, FinCEN Query Monitoring | Subsection title renamed to identify the category of group control. Added instructions on how to generate Exhibit 1.4.50-9 to document FinCEN queries requests by revenue officers |
| 22 | IRM 1.4.50.11.7, Taxpayer Rights, Compliance Data Warehouse Graph Environment (CKGE) Monitoring | Subsection re-numbered. Prior content for records management was relocated to IRM 1.4.50.11.8. Material from Subsection title renamed to identify the category of group control. Added instructions on how to generate the CKGE Exhibit 1.4.50-8 to document the CKGE queries performed by revenue officers. |
| 23 | IRM 1.4.50.11.8, Record Management., Closed Case File Transmittals | Prior content for this subsection for CKGE monitoring was relocated to IRM 1.4.50.11.7. Records management guidance was relocated from IRM 1.4.50.11 to this subsection and the title of subsection identifies the category of group control. |
| 24 | IRM 1.4.50.11.9, Suspension of Case Aging | Added guidance for suspension of case aging for ATAT cases and cases involving suit recommendations and fraud investigations. |
| 25 | IRM 1.4.50.11.10, Sensitive Case Reports | Added guidance defining sensitive case reports, identified issues which warrant sensitive case reports. Prescribed the requirements for initial, interim and closing sensitive case reports. |
| 26 | IRM 1.4.50.13, Field Compliance Manager Employee Engagement Operational Reviews | This section was revised to define objectives of the employee engagement operational review processes. |
| 27 | IRM 1.4.50.13.1, Frequency and Planning | This section was revised by relocating the roles and responsibilities of field compliance managers to IRM 1.40.50.13 and adding incorporating the frequency and planning of employee engagement operational reviews and added guidance on review items that may be delegated. |
| 28 | IRM 1.4.50.13.2, Documentation | Section was revised by removing content describing the objectives of employee engagement operational reviews and added guidance for documenting employee engagement operational reviews. The guidance includes a recommended report format. |
| 29 | IRM 1.4.50.13.3, Leadership & Human Capital-Employee Satisfaction | Subsection added on the managerial responsibility Leadership & Human Capital-Employee Engagement. Content includes the review components that support the responsibility and the review elements that align to each component. |
| 30 | IRM 1.4.50.13.4, Employee Engagement | Subsection added on Employee Engagement. Content and included review components that support the responsibility as well as review elements that align to each component. |
| 31 | IRM 1.4.50.13.5, Customer Satisfaction and Collaboration-Customer Satisfaction | Subsection added on the managerial responsibility Customer Satisfaction and Collaboration-Customer Satisfaction. Content includes the review components that support the responsibility and the review elements that align to each component. |
| 32 | IRM 1.4.50.13.6, Program Management-Business Results | Subsection added on the managerial responsibility Program Management-Business Results Content includes the review components that support the responsibility and the review elements that align to each component. |
| 33 | IRM 1.4.50.13.7, Administrative Compliance | Subsection added on the Administrative/Compliance review requirements. Content includes the review components that support the responsibility and the review elements that align to each component. |
| 34 | IRM 1.4.50.14, Area Director Employee Engagement and Operational Review | Revised this subsection to define the objectives of the Area Director’s employee engagement and operational review responsibilities. |
| 35 | IRM 1.4.50.14.1, Planning and Documentation | Added this subsection to provide guidance on planning and documentation requirements of the AD’s employee engagement and operational review processes. Included review components and specific review elements that support the assessment of each component. |
| 36 | Exhibit 1.4.50-7, Remittance Processing Transmission Control Review. | The current exhibit number and content is a result of renumbering. The prior exhibit at 1.4.50-7, Operational Review Plan was removed and the content was incorporated into subsections of IRM 1.4.50.13, Field Compliance Manager Operational Reviews and Employee Engagement. |
| 37 | Exhibit 1.4.50-8, Compliance Data Warehouse Environment (CKGE) Review Template. | Added prompts in the review template for managers to address instances of questionable CKGE searches. The prior exhibit at 1.45-8, Area Director Operational Aid was removed and the content was incorporated into subsections of IRM 1.4.50.14, Area Directors Operational Reviews and Employee Engagement. |
| 38 | Exhibit 1.4.50-9, FinCEN Query Review Template | Content was added to the FinCEN Query Review Template for managers to address instances of questionable searches. The prior exhibit at 1.4.50-9, Remittance Processing Transmission Control Review was relocated to 1.4.50-7. |
| 39 | Exhibit 1-4-50-10, After Hours Security Review Template. | This exhibit provides a template for group managers to document after hours security reviews required at IRM 1.4.50.3.6. The prior exhibit at 1.4.50-10, Territory Manager Operational Review-Commonly Selected Review Components was removed and the content was incorporated into subsections of IRM 1.4.50.13, Field Compliance Manager Operational Reviews and Employee Engagement. |
| 40 | Exhibit 1.4.50-11, Territory Manager Operational Review-Commonly Selected Administrative/Compliance Review Components Items | Exhibit was removed, the content was incorporated into subsections of IRM 1.4.50.13, Field Compliance Manager Operational Review and Employee Engagement. |
| 41 | Exhibit 1.4.50-12, CKGE Research Review Template | This exhibit was relocated to IRM 1.4.50-8. |
| 42 | Exhibit 1.4.50-13, FinCEN Query Review Template | This exhibit was relocated to IRM 1.4.50-9. |
| 43 | Throughout | Revised the title from Territory Manager to Field Compliance Manager based on the revision of the title in the Specific Position Description. |
| 44 | Throughout | Editorial changes made throughout the IRM including the use of italics, capitalization, correction of hyperlinks, websites and IRM references. |

#### Effect on Other Documents

This material supersedes IRM 1.4.50 dated October 20, 2023.

#### Audience

Small Business/Self-Employed Field Collection managers

#### Effective Date

(04-01-2025)

Eric Slayback,

Acting Director, Collection Policy

Small Business/Self Employed

**1.4.50.1** **(04-01-2025)**

### Program Scope and Objectives

1. **Purpose.** This section discusses responsibilities of managers in Field Collection. The primary focus of this section is guidance related to Field Collection case work. While many topics are touched upon in this section, comprehensive guidance about all of them cannot be included here. As you use this section, remain alert for references to other resources, such as related IRMs and websites and access that guidance as needed to ensure a thorough understanding of topics. Specifically, IRM 1.4.50:



1. Describes general administrative responsibilities required of field collection group managers.

2. Describes employee performance and development procedures.

3. Prescribes internal control requirements.

4. Provides guidance to group managers on the assignment and approval of work.

5. Provides guidance for operational reviews by field compliance (FCMs) managers, (formerly known as territory managers) and area directors.


2. **Audience.** These procedures and guidance apply to IRS Field Collection group managers, field compliance managers and area directors. The organizational title for second level management officials in Field Collection was changed from **Territory Manager** to **Field Compliance Manager** and is reflected as such in the Standard Position Description 99248. All references to these managers have been updated from **territory manager** or the acronym **TM** to **field compliance manger** or the acronym **FCM** throughout this IRM.

3. **Policy Owner.** Director, SB/SE Collection Policy.

4. **Program Owner.** The office of Global Strategic Compliance within SB/SE Collection Policy.

5. **Primary Stakeholders.**Field Collection, Collection Inventory Delivery, and Labor Relations.

6. **Program Goals.** This guidance is provided to communicate the managerial responsibilities to Field Collection group managers including performance management, assignment of work, approval of work, promoting quality casework and internal group controls.

7. **Contact Information.** Recommendations and suggested changes to this IRM should be emailed to the content product owner. The owner is indicated on the Product Catalog Information page which is found in the Form/Pubs/Products IRM listing of the Media and Publications web site.


**1.4.50.1.1** **(04-01-2025)**

#### Background

1. IRM 1.4.50, Collection Group Manager, Field Compliance Manager and Area Director Operational Aid contains procedures, guidance and information for Field Collection group managers. The content includes general administrative responsibilities, performance management, internal controls, assignment of work, approval of work, quality and program reviews.


**1.4.50.1.2** **(10-20-2023)**

#### Authority

1. Authority




| **Authorities** |
| :-: |
| 5 USC Part III, Employees. |
| Section 1204, Internal Revenue Service Restructuring & Reform Act of 1998. |
| Section 1203, Internal Revenue Service Restructuring & Reform Act of 1998. |
| IRC 6304, Fair tax collection practices. |
| IRC 6320, Notice and opportunity for hearing upon filing of notice of lien. |
| IRC 6330, Notice and opportunity for hearing before levy. |
| IRC 6331, Levy and distraint. |
| IRC 7213A, Unauthorized inspection of returns or return information. |
| Revenue Procedure 2012-18, Ex Parte Communications Between Appeals and Other Internal Revenue Service Employees. |
| 31 USC 3302, Custodians of money. |
| 31 USC Chapter 53, Monetary transactions. |
| Equal Employment Opportunity Commission (EEOC) Management Directive 715 (MD-715). |
| IRM 1.2.65, Servicewide Policies and Authorities-Small Business/Self-Employed Divisions Delegations of Authority. |


**1.4.50.1.3** **(04-01-2025)**

#### Roles and Responsibilities

1. The Director, Collection Policy is the executive responsible for the policies and procedures to be employed by collection personnel.

2. Field Collection group managers, field compliance managers and area directors are responsible for ensuring compliance with the guidance and procedures described in this IRM.

3. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employers are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of duties in accord with taxpayer rights. For additional information about the TBOR, see [https://www.irs.gov/taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights)


**1.4.50.1.4** **(04-01-2025)**

#### Program Management and Review

1. **Case Reviews:** Group managers are required to perform case reviews per IRM 1.4.50.5.2.1.

2. **Functional Security Reviews:** Group managers are required to perform one or more after-hours security review for each post of duty under their span of control per IRM 1.4.50.3.6.

3. **Remittance Reviews:** Group managers are required to perform remittance processing reviews annual per IRM 1.4.50.11.1.

4. **Operational Reviews** The efficacy of Field Collection groups is measured by completion of an annual operational review by the second-level of management per IRM 1.4.50.13. Field Collection Territory performance is measured in the Area Director’s operational review per IRM 1.4.50.14.


**1.4.50.1.5** **(04-01-2025)**

#### Program Controls

1. Group managers are required to use the ENTITY Case Management System (ENTITY) and the Integrated Collection System (ICS) to verify and report time charges by their employees and to generate and approve end of month reports.

2. Section 1204 reports, group managers are required to submit quarterly certifications of compliance with section 1204 of the Internal Revenue Service Restructuring and Reform Act of 1988 prohibiting the use of tax enforcement results.

3. Management is required to utilize the ENTITY case management system to establish controls for imminent collection statutes, assessment statutes and lien filing determinations.

4. Group managers are also required to perform financial controls for the group including reviews of employee remittances received from taxpayers.

5. The Automated Trust Fund Recovery Penalty (ATFR) program is to be used by managers to confirm timely trust fund recovery penalty assessment actions.

6. Group managers are required to use the Integrated Collection System application to document the approval of case actions where required.

7. Group managers are responsible for establishing and maintaining each of their employee’s Employee Performance File (EPF).

8. Systems access and usage audits are required to be performed for the Financial Crimes Enforcement Network (FinCEN) Query and Compliance Data Warehouse Knowledge Graph Environment (CKGE) applications.


**1.4.50.1.6** **(10-20-2023)**

#### Terms

1. Frequently used terms used in this IRM along with their definition include:




| **Term** | **Definition** |
| :-: | :-: |
| Bargaining Unit Employee | An employee who is covered by the National Agreement with the National Treasure Employees Union. |
| Drop File | A file to be established for each employee. The employee drop file is for documentation not related to performance. |
| Employee Performance File | The employee performance file is a system consisting of all performance ratings and other performance-related records maintained in accordance with 5 CFR 293, Subpart D |
| ENTITY | The ENTITY is a current database displaying Field Collection, Advisory and Queue inventory. |
| Ex Parte Communications | Communication between any Appeals employee and an employee of another IRS function without the taxpayer/representative being given the opportunity to participate in the communication |
| National Agreement | The contract between the IRS and the National Treasury Employees Union which covers bargaining unit employees. |
| Pyramiding | An in-business taxpayer, not current with FTDs and with two or more balance due trust fund modules assigned to Field Collection. |
| Queue | The Queue is an electronic holding bin of cases from which Field Collection group managers select cases for assignment |
| Repeater | A taxpayer that has had more than module with a TDI or TDA delinquency that first came into existence in the immediate past two years from the current processing cycle |
| Replacement Inventory | Case or cases located the geographic assignment of a revenue officer due to a disaster or state of emergency. |
| Representative | A person who is authorized to represent a taxpayer before the IRS. |


**1.4.50.1.7** **(04-01-2025)**

#### Acronyms

1. This table lists commonly used acronyms and their definitions:




| **Acronym** | **Definition** |
| :-: | :-: |
| AGM | Acting Group Manager |
| ALS | Automated Lien System |
| ATFR | Automated Trust Fund Recovery Penalty Program |
| ATAT | Abusive Tax Avoidance Transaction |
| BEARS | Business Entitlement Access Request System |
| BU | Bargaining Unit |
| CAP | Collection Appeals Process |
| CDP | Collection Due Process |
| CDW | Compliance Data Warehouse |
| CIP | Compliance Initiative Project |
| CJE | Critical Job Element |
| CMAM | CKGE Manager Audit Module |
| CMIR | Report of International Transportation of Currency or Monetary Instrument Report |
| CPM | Control Point Monitor |
| CTR | Currency Transaction Report |
| DCI | Data Collection Instrument |
| CKGE | Compliance Data Warehouse Knowledge Graph Environment |
| EOD | End of Day |
| EOM | End of Month |
| EPF | Employee Performance File |
| EQ | Embedded Quality |
| EQRS | Embedded Quality Review System |
| FAD | Federal Agency Delinquency |
| FATCA | Foreign Account Tax Compliance Act |
| FBAR | Foreign Bank and Financial Account Report |
| FCM | Field Compliance Manager |
| FCQ | FinCEN Query System |
| FEA | Fraud Enforcement Advisor |
| FRD | Fraud Develop Case Indicator |
| FTCP | Fair Tax Collection Practices |
| FTI | Federal Tax Information |
| FTL | Federal Tax Lien |
| GM | Group Manager |
| ICS | Integrated Collection System |
| LB&I | Large Business & International |
| LDC | Lead Development Center |
| LR | Labor Relations |
| NFTL | Notice of Federal Tax Lien |
| NQRS | National Quality Review System |
| NTEU | National Treasury Employees Union |
| OJI | On-the-Job Instructor |
| OVDI | Offshore Voluntary Disclosure Initiative |
| PII | Personally Identifiable Information |
| POD | Post of Duty |
| RAAS | Research, Applied Analytics and Statistics |
| RO | Revenue Officer |
| ROCS | Revenue Officer Compliance Sweeps |
| ROTER | Record of Tax Enforcement Results |
| SAR | Suspicious Activity Report |
| SBU | Sensitive But Unclassified |
| SCR | Sensitive Case Report |
| SCP | Special Compliance Program |
| TBOR | Taxpayer Bill of Rights |
| TER | Tax Enforcement Result |
| UNAX | Unauthorized Access |
| WGI | Within Grade Increase |


**1.4.50.1.8** **(04-01-2025)**

#### Related Resources

1. IRM resources include:




| IRM | TITLE |
| --- | --- |
| IRM 1.4.1 | Management Roles and Responsibilities |
| IRM 1.5.2 | Uses of Section 1204 Statistics |
| IRM 1.15 | Records and Information Management |
| IRM 5.1.2 | Remittances, Form 809 and Designated Payments |
| IRM 5.1.3 | Safety, Security and Control |
| IRM 5.1.10 | Taxpayer Contact |
| IRM 5.1.12 | Cases Requiring Special Handling |
| IRM 5.1.23 | Taxpayer Representation |
| IRM 5.2.1 | Collection Time Reporting |
| IRM 5.2.4 | Collection Reports |
| IRM 5.3.1 | ENTITY Case Management System |
| IRM 5.7.2 | Letter 903 Process |
| IRM 5.13.1 | Embedded Quality Collection Field Organization Administrative Guidelines |
| IRM 6.430.2 | Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs) |
| IRM 6.432.1 | Reduction in Grade, Band and Removal Based on Unacceptable Performance |
| IRM 6.451.1 | Policies, Authorities, Categories and Approvals |
| IRM 6.751 | Discipline and Disciplinary Actions |
| IRM 6.800.2 | IRS Telework Program |
| IRM 10.8.34 | IDRS Security Controls |
| IRM 25.1.8 | Fraud Handbook, Field Collection |

2. Web resources include:




| **Web Resources** |
| :-: |
| Automated Trust Fund Recovery Penalty (ATFR) |
| Centralized Case Processing (CCP) |
| Critical Job Elements (CJEs) |
| Embedded Quality |
| Employee Resource Center |
| ENTITY |
| Human Capital Office (HCO) website |
| Human Capital Office-Performance Awards |
| ICS User Guide |
| iManage website |
| Integrated Talent Management |
| IRS Telework Portal |
| MY SB/SE |
| New Manager Orientation (NMO) Support Center |
| NTEU/IRS National Agreement |
| Office of Professional Responsibility |
| Section 1203/RRA 98 |
| [Taxpayer Bill of Rights](https://www.irs.gov/taxpayer-bill-of-rights) |
| UNAX |


**1.4.50.2** **(10-20-2023)**

### Role of the Field Collection Manager

1. Fundamental responsibilities for all managers are discussed in IRM 1.4.1, Management Roles and Responsibilities. As a field collection group manager (GM), you must provide oversight and direction in a number of areas which will result in accomplishing the mission of the IRS. Your oversight responsibilities include, but are not limited to:




| **Manager Oversight Responsibilities** |
| :-: |
| Ensuring employee case actions are timely and in accordance with current law, policies, and procedures. |
| Ensuring employees maintain high standards of professionalism in all contacts with the public, internal customers, and coworkers. |
| Ensuring employees observe taxpayer rights. |
| Ensuring employees are aware of ongoing changes to the laws, policies, and procedures that relate to their responsibilities (preferably during group meetings). |
| Addressing systems issues that impact either internal or external customer needs. |
| Ensuring cases are assigned timely and that employee workloads reflect current priorities and objectives, align to employee’s experience level, protects the public interest and are assigned to promote effective case processing. |
| Helping revenue officers (ROs) make the appropriate next case decision when necessary. |
| Ensuring employees are accountable for the appropriateness of their actions. |
| Providing ongoing employee feedback that is candid and meaningful and will establish a basis for determining an accurate assessment of performance and developmental needs. |
| Issuing the critical job elements (CJEs) timely in accordance with the National Agreement and evaluating employees performance against their CJEs. |
| Creating and maintaining a work environment that will promote teamwork, positive working relationships, and increased employee satisfaction. |
| Ensuring employees have necessary functioning equipment and supplies. |
| Overseeing the time reporting process and ensuring that the group's end of month (EOM) time and inventory data are accurate and timely. |

2. Your responsibilities also include:



1. Developing employees.

2. Evaluating employee performance and providing counseling.

3. Addressing employee conduct issues.

4. Fostering good working relationships.

5. Defining goals and course of action.

6. Assigning and directing work.

7. Instructing employees in the application of procedures and guidelines.

8. Displaying integrity in all actions.


3. As a manager you are accountable to address performance deficiencies within your group. This may be accomplished through reviews and/or by requiring your concurrence with performing specific actions. For example, if you find that Notice of Federal Tax Lien (NFTL) determinations are not being made in accordance with IRM 5.12.2, Federal Tax Lien, Notice of Lien Determinations, you can require revenue officers to secure your written approval for all non-filing or extension decisions. For additional direction regarding performance issues see _Exhibit 1.4.50-5_, Suggested Action Steps for Unacceptable Performance.

4. You must also oversee group remittance processing activities, including monitoring Form(s) 5919, Teller's Error Advice, sent to your group. Procedures are shown in IRM 5.1.2, Remittances, Form 809 and Designated Payments. See IRM 5.1.2.5.6, Responding to Form 5919. Remittance control reviews are addressed in _IRM 1.4.50.11.1_.


**1.4.50.2.1** **(10-20-2023)**

#### Communicating Expectations

1. When a new group is established or a new manager is assigned to an existing group, a meeting with the employees must be held within the first 30 days. At this meeting the manager will communicate expectations to include the following topics:



   - Group procedures

   - Case work

   - Use of time - office/ field/ telework

   - Timeliness of case activity

   - Reasonable time frames for case actions (See IRM 5.1.10.3.1, Initial Contact Time Frames. IRM 5.1.10.8, Case Histories, and IRM 5.1.10.9, Timely Follow-ups, for timeliness and time frames).

   - Case review schedule

   - Collection Consultations - schedule and structure

   - Responsiveness to taxpayer or representative inquiries, see IRM 5.1.10.4, Responding to Taxpayers and CJE 3A, Responsive, Courteous Service.


### Note:

This meeting is considered a 7114 meeting, See the Federal Service Labor-Management Relations Statute, 5 U.S.C. 7114. Local National Treasury Employees Union (NTEU) chapter(s) must be notified of the meeting in accordance with Article 8, Union Rights, of the National Agreement.

2. These expectations should also be reviewed at the beginning of each fiscal year.

3. When a new employee is assigned to an existing group, the group manager must meet with the new employee to discuss managerial expectations (see (1) above) and ensure appropriate Business Entitlement Access Request System (BEARS) requests are completed and processed.



### Note:



This meeting is considered a 7114 meeting. Local National Treasury Employees Union (NTEU) chapter(s) must be notified of the meeting in accordance with Article 8, Union Rights, of the National Agreement.


**1.4.50.2.2** **(04-01-2025)**

#### Group Meetings

1. Regular group meetings will be held as necessary to review items such as the following:



   - Directives from the field compliance manager, area director, and Headquarters

   - Procedural memoranda

   - IRM changes

   - Case resolution techniques

   - Changes in condition of employment

   - Automation issues

   - Mandated topics not available on other media

   - General group (employee) concerns


### Note:

Regular group meetings are not ordinarily considered 7114 meetings. The Union entitlement arises where there is a discussion of a personnel policy, practice or other general condition of employment. For example, a discussion at a group meeting on the need to make timely trust fund recovery penalty (TFRP) determinations or how to handle a particular type of case would not ordinarily be considered 7114 issues. Managers should seek guidance and advice from their servicing field Labor Relations section if they are unsure whether an agenda item for a group meeting constitutes a 7114 issue. Article 8 Section 1 of the National Agreement also provides guidance on 7114 meetings.

**1.4.50.2.3** **(10-20-2023)**

#### ENTITY End Of Month (EOM) Processing

1. You are responsible for reviewing time reported by your employees to ensure accuracy. Using ICS and ENTITY, _verify time prior to end of month (EOM) processing_ (i.e., no later than COB on the last Friday of the monthly reporting period). Updates/corrections to end of day (EOD) data occur overnight. Thus, if all EOD activity is not completed and verified by the Friday prior to EOM, delays in processing EOM reports will result. Exhibit 10 in IRM 5.2.1, Collection Time Reporting, provides information about the last Friday of each reporting period and number of expected hours in each period. Consider the following:



1. You can use ENTITY to verify the accuracy of time charges. There is a “View” titled “Weekly Time Verification” and a “Report” titled “Hours Verification Report,” both can be used to validate time. For more information go to the ENTITY website located at _IRM 1.4.50.1.8_, Related Resources and IRM 5.2.1, Collection Time Reporting.

2. Be alert for, and address as appropriate, issues such as potentially excessive administrative or miscellaneous direct time, minimal field time, discrepancies related to credit/ comp/ holiday/ training time, etc.

3. Ensure that the group secretary performs weekly time verification and checks for daily EOD for all employees.

4. Monitor case sub codes and consider requesting that ROs validate sub codes monthly to avoid inaccurate time reporting. See IRM 5.3.1.3.2 , ICS / ENTITY Case Codes, Subcodes and Collection Time Reporting System.

5. Refer to IRM 5.2.1.7.1(3), Field Collection Procedures, for specific information about GM responsibilities related to time reporting.


**1.4.50.3** **(01-25-2013)**

### General Managerial Responsibilities

1. IRM 1.4.1.3, Administrative Responsibilities, contains information about general managerial responsibilities. Place special emphasis on responsibilities shown in the following subsections.


**1.4.50.3.1** **(10-20-2023)**

#### Administrative

1. Group managers are responsible for oversight of certain administrative functions for their employees including, but not limited to:



1. Maintenance of time and attendance records

2. Certifying overtime records

3. Approving scheduled and unscheduled leave

4. Controlling and approving travel

5. Maintaining safe working conditions

6. Holding group meetings

7. Keeping employees current on all applicable policies and procedures


2. Other administrative tasks include, but are not limited to:



   - Ensuring group ENTITY end of month reports are completed correctly (verified, generated, and approved) by the due date

   - Completing quarterly 1204 self certifications

   - Oversight of supply procurement

   - Maintaining EPF and drop files for each employee



     ### Caution:



     You may delegate certain duties to a secretary/ administrative assistant; however, you retain oversight responsibility for those tasks.


3. Items that you must update individually with each RO annually include, but are not limited to:



   - Form 6774, Receipt of Critical Job Elements and Retention Standard.

   - Form 11386, IRS Telework Agreement for Bargaining Unit.

   - Form 7995, Outside Employment or Business Activity Request.

   - Form 10094, Career Learning Plan-Employee.

   - Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request.


4. Resources:



   - IRM 1.4.1.3, Administrative Responsibilities.

   - Document 12990, Records Control Schedules.

   - New Manager Orientation Support Center, see _IRM 1.4.50.1.8_, Related Resources for a link to this information.

   - iManage website see _IRM 1.4.50.1.8_, Related Resources for a link to this information.


**1.4.50.3.1.1** **(10-20-2023)**

##### Employee Performance File (EPF)

1. You are responsible for establishing and maintaining an EPF for each of your employees.

2. You are responsible for ensuring the effective use of the EPF by:



1. Ensuring that the proper documents are included in each EPF.



      ### Note:



      See IRM 6.430.2.3.5, Employee Performance File (EPF).

2. Ensuring that filing and purging of performance related documents and records are in compliance with requirements, see (7) below.

3. Keeping all performance records and documents secured.

4. Forwarding EPF records of employees transferring to other Treasury bureaus or to a different post of duty or manager within the IRS.


3. Form 6774, Receipt of Critical Job Elements and Retention Standard, is maintained in the EPF. You must update the form annually and ensure it is signed and dated. See IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers.

4. Recordation is defined as a manager's written record evaluating an employee in a positive or negative manner. For BU employees, recordation must be furnished to an employee within fifteen (15) workdays of the time the manager becomes aware, or should have been aware, of the event that it addresses. If it is not furnished within fifteen (15) workdays, it cannot become part of the EPF.



### Caution:



_Documentation on ICS regarding the monthly consultation process does not qualify as a performance recordation and is not to be included in revenue officers’ EPF folders or used for evaluative purposes._

5. Electronic signatures may be used on Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition Request, processed through HR Connect; however, paper copies of the form must be maintained in the EPF.

6. The EPF is maintained in addition to and **separate** from the employee drop file. The EPF is not the same as the Official Personnel File (OPF). See IRM 1.4.1.8.4, Official Personnel File (OPF).

7. For additional information regarding the specific items to be placed in the EPF and the retention period, refer to:



   - Human Capital Office, see _IRM 1.4.50.1.8_, Related Resources for a link to this site.

   - National Agreement , Article 12, see _IRM 1.4.50.1.8_ for a link to this information.

   - IRM 6.430.2.3.5, Employee Performance File (EPF).

   - The local Labor Relations Specialist.

   - HR Connect.


**1.4.50.3.1.2** **(01-25-2013)**

##### Employee Drop File (EDF)

1. In addition to the EPF, a second file should be established for each employee. This is referred to as the drop file. The employee drop file (EDF) is for other documentation _not related to performance._

2. See IRM 1.4.1.8.5(7), Employee Performance File (EPF), for more information.


**1.4.50.3.1.3** **(10-20-2023)**

##### Medical Information

1. Employee medical information must be maintained separately from the EPF and EDF.

2. For more information see IRM 6.630.1.5.4, Safeguarding Medical Information, and the link to the HCO website at _IRM 1.4.50.1.8_, Related Resources.


**1.4.50.3.1.4** **(04-01-2025)**

##### Acting Group Manager Assignments and Designations

1. You must formally designate an acting group manager (AGM) during your periods of absence. You must use Form 10247, Designation to Act to appoint an acting group manager for a period of one full day or longer. The form must identify the person appointed, the period of the appointment and a general description of the tasks the AGM is authorized to perform. For AGM appointments of less than one business day, an email may be substituted for the Form 10247. The email must contain the same information as the Form 10247 described above. The email or Form 10247 must be distributed to the appointed employee, the other employees in the group, and the GM’s field compliance manager. Place a copy of the Form 10247 or email (if appropriate) in the appointed employee’s drop file.

2. A general description of the tasks the AGM is authorized to perform assignments should be agreed on between you and the acting manager in advance. Specific expectations should be given at the beginning of each assignment.

3. Utilize discretion to determine if it will be necessary to adjust the AGM’s inventory during extended designation periods. You should also discuss any cases which may need to be re-assigned during the designation period to ensure timely actions are taken on cases which involve issues which could cause permanent loss to the government.

4. Determine which managerial tasks are to be performed by the AGM and which tasks will be deferred until your return. Refer to the National Agreement (Document 11678) for certain restrictions on performance evaluations ( i.e. The employee’s performance must have been observed under a signed performance plan for at least 60 days to be ratable under Article 12.)

5. You may designate certain tasks when you are not absent as a developmental assignment to employees who indicate managerial aspirations. In these instances, no formal designation exists, therefore, tasks reserved to managers cannot be delegated. These tasks include but are not limited to:



   - Case-related managerial approvals

   - Supervisory conferences related to an appeal filed by the taxpayer or taxpayer’s authorized representative

   - Approval of leave for other members of the group

   - Approval of travel authorizations or vouchers


**1.4.50.3.2** **(10-20-2023)**

#### Protecting Taxpayer Rights

1. A primary responsibility of managers is to monitor employee practices and actions to ensure that taxpayer rights are always observed.

2. Taxpayer rights include, but are not limited to the following:




| **Taxpayer Bill of Rights** |
| :-: |
| The right to be informed. |
| The right to quality service. |
| The right to pay no more than the correct amount of tax. |
| Proper notification of third party contacts. |
| Protection from unauthorized disclosure. |
| The right to challenge the IRS’s position and be heard. |
| The right to appeal an IRS decision in an independent forum. |
| The right to finality. |
| The right to retain representation. |
| The right to a fair and just tax system. |

3. For additional information about the Taxpayer Bill of Rights (TBOR), see _IRM 1.4.50.1.8_ for a link to the TBOR.

4. Section 1203(b) of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA ‘98) calls for the termination of any employee of the IRS if there is a final administrative or judicial determination that the employee willfully committed any act or omission described below:




| **Section** | **Description** |
| :-: | :-: |
| Section 1203(b)1 | Failing to obtain required approval signatures when making a seizure. |
| Section 1203(b)2 | Providing a sworn, false statement in a material matter concerning a taxpayer. |
| Section 1203(b)3 | Violating the constitutional rights of or discriminating against taxpayers or employees. |
| Section 1203(b)4 | Falsifying or destroying documents to cover a mistake concerning a taxpayer. |
| Section 1203(b)5 | Receiving a criminal conviction or civil judgment for assault or battery on a taxpayer or employee. |
| Section 1203(b)6 | Violating the Internal Revenue Code, IRS regulations or policies to retaliate against or harass taxpayers or employees. |
| Section 1203(b)7 | Misusing IRC Section 6103 to conceal information from a Congressional inquiry. |
| Section 1203(b)8 | Failing to file a federal tax return on or before its due date, unless it is due to reasonable cause. |
| Section 1203(b)9 | Understating federal tax liability, unless it is due to reasonable cause. |
| Section 1203(b)10 | Threatening an audit for personal gain. |

5. There is an important distinction between evaluating performance under CJE 2, Taxpayer Rights, and evaluating compliance with the Retention Standard for the Fair and Equitable Treatment of Taxpayers. See retention standard resources for more information.

6. Resources:



   - Form 6774, Receipt of Critical Job Elements and Retention Standard

   - IRM 6.430.2.4.7, Rating Performance Against The Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRM 6.430.2.2.5, Discussing The Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - 1203 resources: See _IRM 1.4.50.1.8_, Related Resources for a link to this information.

   - IRM 5.1.23, Taxpayer Representation

   - Office of Professional Responsibility website

   - Publication 947, Practice Before the IRS and Power of Attorney


**1.4.50.3.2.1** **(01-25-2013)**

##### Direct Contact For Taxpayers With/or Requesting Representation

1. Keep in mind that IRC 6304(a)(2) precludes communicating with a represented taxpayer in connection with the collection of any unpaid tax liability where that representative is ascertainable unless the representative fails to respond within a reasonable period, or the taxpayer or the representative has given prior consent to that communication.

2. Taxpayer Interviews. Ensure that your group is in conformance with IRC 7521, Procedures involving taxpayer interviews, which codifies section 3502 of the RRA 98 and provides the following:



1. An explanation of the interview process. Taxpayers must be clearly informed of their rights to be represented at interviews and to have the interview suspended if the taxpayer wishes to consult with a person authorized to practice before the IRS.

2. The right of consultation. Your employees are required to stop the interview with a taxpayer (unless required by court order) whenever a taxpayer requests to consult with a representative (e.g. certified public accountant, attorney or enrolled agent, or who is permitted to represent taxpayers before the IRS).


3. By-pass procedures. IRC 7521(c) permits an employee to contact the taxpayer directly and to request any information necessary to complete the investigation after obtaining your approval if the representative is responsible for unreasonably delaying or hindering the completion of a collection action. See IRM 5.1.23.6, By-Passing a Taxpayer's Authorized Representative.



### Exception:



Per IRM 5.1.23.6, By-Passing a Taxpayer’s Representative, the IRS may work directly with a taxpayer to resolve an issue on the taxpayer's account if: The taxpayer initiates the contact to resolve the issue on the account and/or the taxpayer expresses a specific desire to resolve the issue without the involvement of the representative after the IRS employee has advised the taxpayer of the current representation. The taxpayer’s desire to have the IRS work directly with the taxpayer instead of the representative must be properly documented in the case file.

4. Examples of steps you can take to ensure compliance by your employees are:



   - Group meetings

   - Case reviews

   - Workload reviews

   - Field visitations

   - Office visitations

   - Taxpayer/representative inquiries (if necessary)


**1.4.50.3.2.2** **(01-25-2013)**

##### Recording Taxpayer Interviews

1. A taxpayer or representative may request to use audio or video equipment to record an in-person interview. See IRM 5.1.12.3, Recording Taxpayer Interviews, for information on responding to such requests. The right to make an audio recording does not extend to telephone interviews.


**1.4.50.3.2.3** **(04-01-2025)**

##### Fair Tax Collection Practices

1. Internal Revenue Code (IRC) 6304, Fair tax collection practices, imposes certain restrictions with respect to tax collection. During a case review or upon receiving a complaint from a taxpayer, you may identify a potential violation of those restrictions. Potential employee violations of the IRC 6304 must be reported to the local Labor Relations specialist by the close of the next business day following notification of the alleged violation.

2. To ensure collected data is complete and accurate, use the following issue codes when reporting the potential violation. Labor Relations uses these codes for tracking on the Automated Labor and Employee Relations Tracking System (ALERTS).



   - 141/ 6304: CONTACT TP UNUSUAL TIME/PLACE - Contacting a taxpayer before 8:00 am or after 9:00 pm, or at an unusual location or time, or location known or which should be known to be inconvenient to the taxpayer.

   - 142 /6304: CONTACT TP W/O REPRESENTATIVE - Contacting a taxpayer directly without the consent of the taxpayer’s power of attorney.

   - 143/ 6304: CONTACT AT TP EMPLOYER; PROHIBITED - Contacting a taxpayer at their place of employment when it is known or should be known that the taxpayer’s employer prohibits the taxpayer from receiving such communication.

   - 144/ 6304: TAXPAYER HARASSMENT IN A TAX COLLECTION MATTER - Any allegation of taxpayer harassment should be reviewed along with IRC 6304 because the provision is intended to be applied in a general manner when evaluating the alleged employee misconduct. Conduct which is intended to harass a taxpayer, or conduct which uses or threatens to use violence or harm is an absolute violation of the IRC.

   - 145/ 6304: TAXPAYER ABUSE IN A TAX COLLECTION MATTER - Any allegation of taxpayer abuse should be reviewed along with the IRC 6304 because the provision is intended to be applied in a general manner when evaluating the alleged employee misconduct. The use of obscene or profane language towards a taxpayer is an absolute violation of the IRC.

   - 146/ 6304: CONTINUOUS PH / HARASSMENT - Causing a taxpayer’s telephone to ring continuously with harassing intent.

   - 147/ 6304: PH CALL W/O ID DISCLOSURE - Contacting a taxpayer by telephone without providing a meaningful disclosure of the IRS employee’s identity.


### Note:

These codes are valid for Collection employees alleged fair tax collection practices violations only.

3. You are not required to report instances to Labor Relations where you have determined the employee’s conduct is not a potential violation of IRC 6304, Fair tax collection practices. Document the ICS history with your discussions or correspondence associated with the complainant in the ICS history.



### Example:



You receive an allegation of employee misconduct from a taxpayer’s authorized representative. The representative asserts the RO’s warning of an enforcement action if a deadline to submit documentation is missed constitutes harassing behavior. You contact the representative and explain the employee’s warning of consequences is intended to advise of possible enforcement actions if the representative is unresponsive to the RO’s request and is not considered harassing behavior. Document this contact in the ICS history. This alleged violation of FTCP is not required to be reported to Labor Relations.

4. If a potential violation is confirmed, do not document the case history with your decision to forward the complaint to Labor Relations.

5. Work with your LR specialist to determine the next appropriate action.

6. Resources:



   - IRM 5.1.10.6, Fair Tax Collection Practices

   - IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRM 6.430.2.4.7, Rating Performance Against The Retention Standard for the Fair and Equitable Treatment of Taxpayers


**1.4.50.3.2.4** **(04-01-2025)**

##### Ex Parte Communication With Appeals/GM Action Necessary

1. An “ex parte communication” is a communication that takes place between any employee from the Independent Office of Appeals (Appeals) and employees of other IRS functions, without the taxpayer/representative being given an opportunity to participate in the communication. Revenue Procedure 2012-18, Ex Parte Communications between Appeals and other Internal Revenue Service Employees, applies to communications that take place after May 15, 2012, and clarifies the rules about ex-parte communications.

2. Prior to approving Collection Due Process (CDP) cases for transmittal to Appeals, review Form 14461, Transmittal of the CDP/ Equivalent Request Hearing.



   - Ensure that narrative statements do not contain any commentary regarding the merits of the protest; e.g., do not discuss the revenue officers’s view regarding the strengths and weaknesses of the taxpayer’s appeal. See IRM 5.1.9.5, Communications with Appeals

   - Ensure that the case file does not include documents that attempt to influence Appeals’ decision-making process.


3. You must ensure that no prohibited ex parte communications are included in **TFRP** case files and ICS/ ATFR case history before approving the transmittal of the case to the control point monitor (CPM). Document your concurrence in the ICS case history. See IRM 5.7.6, Trust Fund Penalty Assessment Action, for additional guidance on manager responsibilities for TFRP protest cases.

4. If a taxpayer submits a written appeal after a (non-TFRP) **Penalty Abatement Request** is denied and Appeals consideration is necessary, ROs will forward the appeal to you for review and concurrence. Ensure that the ICS history is attached to the appeal request and that no prohibited ex parte communications are included before approving the transmittal of the case to Appeals. If the case history contains commentary that is determined to violate the ex parte communication rules, take appropriate action, which could include sharing the information with the taxpayer, or following ICS history removal procedures detailed in IRM 5.1.10.8, Case Histories.

5. If the appeal contains new information that requires additional investigation or ICS documentation, the RO must secure managerial concurrence of decision to sustain penalty abatement denial. If the RO is unable to make contact with the taxpayer within a reasonable time period, the RO will forward the case file to the GM and the GM will take the following actions:



   - Prepare a letter to the taxpayer that identifies the new information and a brief summary of the results of the additional investigation.

   - Document issuance of the letter to the taxpayer in the ICS history and attach a copy of the letter to the taxpayer appeal.

   - You must ensure that the ICS history is attached to the appeal request and that no prohibited ex parte communications are included before approving the transmittal of the case to Appeals.


6. **Fast Track Mediation-Collection (FTM-C)** can be used for certain Offer in Compromise (OIC) and TFRP cases. The prohibition against ex parte communications between Appeals employees and originating function employees does **not apply**to FTM-C because the Appeals employees are not acting in their traditional Appeals settlement role. Ex parte communications, such as a private caucus between the Appeals mediator and Collection employees during the course of the mediation session, is permissible under the ex parte communication rules.

7. Resources:



   - IRM 5.1.9.5, Communications with Appeals

   - IRM 5.1.9.3.3.2, Sending Hearing Request to Appeals

   - IRM 5.1.15.16.4, Penalty Relief Denial and Appeals

   - IRM 5.7.6, Trust Fund Penalty Assessment Action

   - IRM 8.1.10.5, Opportunity to Participate


**1.4.50.3.3** **(09-12-2014)**

#### IDRS

1. Group managers are responsible for ensuring that their employees have access to the IDRS command codes necessary to perform their assigned tasks and required research.


**1.4.50.3.3.1** **(10-20-2023)**

##### IDRS Security

1. IDRS security briefings are included in the mandatory annual online briefings. IDRS security should also be reinforced through discussions at group/unit meetings.

2. Employees should be reminded to complete Form 11377, Taxpayer Data Access, if an account is inadvertently accessed or otherwise applicable.

3. IRM 10.8.34, IDRS Security Controls, requires managers to review periodic IDRS Security reports for their groups. In Field Collection, primary responsibility for those reviews rests with Collection Automation Support and Security (CASS). You may be contacted by a CASS representative if they are unable to resolve a potentially questionable access made by one of your employees.

4. Generally, CASS will contact you via secure email. If contacted, take the following steps:



   - Take appropriate action to determine whether or not there was a business reason for the access. Actions may include conversations with the employee, review of case inventory, review of IDRS case controls, use of IDRS Online Reports Services (IORS) queries, review of audit trails, determining if access was by automated process, etc.

   - Provide feedback about your findings to CASS within five business days of their request


5. Resources:



   - IRM 10.8.34, Information Technology (IT) Security, IDRS Security Controls

   - Form 11377, Taxpayer Data Access

   - UNAX resources See_IRM 1.4.50.1.8_, Related Resources for a link to this information.


**1.4.50.3.4** **(10-20-2023)**

#### Employee Safety/Security

1. Safety and security are high priorities. You must become familiar with your responsibilities to ensure workplace safety for everyone.

2. See IRM 5.1.3, Safety, Security and Control, for information about safety and security topics including armed escorts for revenue officers.

3. Resources include:



   - See _IRM 1.4.50.1.8_, Related Resources for a link to the Employee Resource Center

   - See _IRM 1.4.50.1.8_, Related Resources for a link to the Worker’s Compensation page of the HCO website


**1.4.50.3.5** **(10-20-2023)**

#### Working With NTEU

1. Group managers who supervise bargaining unit (BU) employees must:



1. Notify the requisite chapter(s) regarding 7114 meetings when you plan to discuss changes in personnel policies, practices, and working conditions with your employees. Generally, _five workdays notice_ is provided. See Article 8 of the National Agreement. See: _IRM 1.4.50.1.8_, Related Resources for a link to the National Agreement.

2. Make sure employees have the opportunity to be represented at formal discussions regarding employee grievances, other personnel matters, and conduct issues.


2. See Article 8 of the National Agreement for more information about how to identify 7114 meetings. Contact your LR specialist if you need assistance to determine if a meeting is a 7114 meeting.

3. Resources:



   - IRM 1.4.1.4, Agreements with NTEU, or contact the local Labor Relations specialist.

   - National Agreement, see _IRM 1.4.50.1.8_, Related Resources for a link to the National Agreement.


**1.4.50.3.6** **(04-01-2025)**

#### After Hours Security Reviews

1. Per IRM 10.5.1.5.1, Clean Desk Policy, requires all employees to secure sensitive but unclassified (SBU) materials. SBU materials include personally identifiable information (PII) and federal tax information (FTI).You will conduct one or more after hours security reviews per fiscal year for the post of duty locations of your direct reports. An after hours review allows managers to determine if assets and sensitive information are properly protected. This is accomplished by a physical inspection of the work space after the close of the business day after your employees have left for the day or in the morning before employees arrive for the work day. This is a physical review to determine if sensitive information is properly secured and if the office and laptop computers are appropriately safeguarded. A template is available at _Exhibit 1.4.50-10_ to document this review. If another format is used to document this review, you must ensure all of the items on the template are addressed and must contain the printed name and title of the reviewer, date of the review and signature of the reviewer.

2. Inspect the following areas/items to determine if sensitive information is properly contained or disposed of:



1. Employee desktops should be free of any personally identifiable information, tax return information or systems passwords.

2. Confirm employees cabinets containing sensitive information are locked.

3. Inspect wastebaskets and unsecured recycling bins for sensitive material.

4. Shred bins should be properly secured.

5. Check for sensitive information left in printers or copiers

6. Inspect mail rooms to confirm sensitive information is secured and the mail receptacle is locked.

7. Inspect interview rooms used by your employees for the presence of unsecured sensitive information.


3. Perform the following inspection of the physical space and equipment:



1. Do exterior doors have adequate locks to prevent easy access?

2. Do cipher lock combinations utilize at least four digits?

3. Are employees’ computers logged off?

4. Are cable locks in place and locked for computer laptops?


4. In situations where you are not collocated in the same post of duty with all your employees, this review may be performed by another management official or the Commissioner’s Representative for those locations.

5. If your reviews reflect that employees repeatedly fail to observe security protocols, contact your LR specialist to determine the next appropriate action.


**1.4.50.4** **(10-20-2023)**

### Employee Development/Training

1. See IRM 1.4.1.6, Employee Development, for a full discussion of your responsibilities.

2. Group manager roles and responsibilities in the area of employee development and training include but are not limited to:



1. Overseeing orientation of new employees.

2. Overseeing training for new employees (formal and on-the-job).

3. Training and developing other employees including professional/technical and clerical staff.

4. Assisting and advising employees preparing a career learning plan (CLP).

5. Delegating acting managerial assignments.

6. Continuing education for employees to maintain and update knowledge and proficiency in technical areas.

7. Providing opportunities such as details to facilitate career development.

8. Ensuring employees have a working knowledge of tools to perform their duties (e.g., ICS, ATFR, ALS, etc.).


3. You can find more information at the Human Capital Office. See _IRM 1.4.50.1.8_, Related Resources for a link to the HCO website. which includes information on:



   - Servicewide training and briefing programs

   - Policy and procedural guidance

   - Other related training resource sites, IRS Learning Center etc.


4. For your BU employees, also see Article 30 of the National Agreement, see _IRM 1.4.50.1.8_, Related Resources for a link to the National Agreement or contact the local Human Resources specialist.

5. Resources:



   - Integrated Talent Management (ITM) , see _IRM 1.4.50.1.8_, Related Resources for a link to the ITM website.

   - IRM 1.4.1.6, Employee Development.

   - HCO website, see _IRM 1.4.50.1.8_, Related Resources for a link to the HCO website.


**1.4.50.4.1** **(04-01-2025)**

#### Consultation Process

1. The consultation process is designed to facilitate managerial engagement and knowledge sharing in an informal and non-evaluative setting. Unlike case reviews, which focus on the quality of the revenue officer’s casework evidenced by case documentation, the consultation process focuses on quality through a discussion and interaction between the manager and the revenue officer. Active listening is critical to the consultation process to ensure appropriate issues are raised, proper actions are identified and necessary skills are transferred.



### Caution:



There are certain situations in which cases and/or revenue officers are not to be included in the consultation process. See _IRM 1.4.50.4.1.2_, Collection Consultation Exclusions.

2. The consultation process is designed to foster a mentoring and coaching environment, that facilitates learning by the employee and manager, as well as improved case resolution.

3. At the beginning of each year, confer with your field compliance manager to develop a consultation plan for the group. The plan must include a determination of the type and frequency of consultations planned for each revenue officer. The Consultation Plan should include business priority cases where the public interest was not protected with group control processes.



### Example:



If the group experienced the expiration of an ASED without taking statue protection or reporting requirements prescribed in IRM 5.7.3, Establishing Responsibility and Willfulness for the Trust Fund Recovery Penalty, ASED accounts should be added to the consultation plan for the group.

4. Monthly consultations are expected for most revenue officers; however, less frequent consultations may be appropriate for seasoned employees who need little oversight. Consultations must occur at least quarterly to give adequate attention to all revenue officers.

5. As stated above, the discussion is the critical component of the consultation process. Documentation of consultations is minimal and is accomplished by completion of a memorandum for the revenue officer’s employee drop file. Required information contained in the memorandum is limited to the taxpayer name, the last four digits of the taxpayer’s Employer Identification Number or Social Security number and the date the consultation was held. Indicate the location where the consultation was held (i.e. office, field or telephonic) in the memorandum. If additional documentation is recorded, a copy should be provided to the revenue officer. One memorandum can be used for multiple consultations held with a revenue officer on the same date. A blank memorandum template can be found in the Miscellaneous/Publications menu under the Templates tab on the My ICS Menu.

6. Consultation documentation does not meet the requirements for evaluative documentation.

7. In addition to the documentation requirements above, consultations conducted on imminent CSED cases must also be documented in a manner consistent with IRM 5.1.19.5.3, Collection Statute Expiration-Documenting Imminent CSEDs. An imminent CSED is any CSED with less than 12 months remaining on the collection statute.

8. Case history and/or case files should be available for reference and discussion, if warranted, during the consultation process. This may prove to be very helpful when consulting with revenue officers who are newly assigned to a group. To be most effective, a face-to-face consultation is preferred, but there may be situations in which consultations are completed via the telephone.


**1.4.50.4.1.1** **(08-21-2018)**

##### Cases Included in the Consultation Process

1. Consultations are mandatory on all imminent CSED accounts. Imminent CSED accounts are defined as cases containing at least one module will less than 12 months or less remaining on the collection statute.

2. Consultations may be held at any opportunity the GM and RO have to discuss a case whether in the office, in the field or telephonically. Group managers have the discretion to select both business priority cases (e.g. IBTF, Pyramiding since RO assignment, etc) and non-business priority cases for consultation consistent with the consultation plan established for each RO.

3. Revenue officers may also select cases for consultation to ensure the revenue officer’s developmental needs are addressed.


**1.4.50.4.1.2** **(10-20-2023)**

##### Collection Consultation Exclusions

1. Generally, cases that are being actively reviewed for evaluative purposes in compliance with other subsections of this handbook are excluded from the consultation process for a period of time.

2. Cases which have been reviewed in EQRS within the past 60 days are excluded from the consultation process.

3. Cases which have been reviewed and have a follow up review scheduled in EQRS are excluded from the consultation process.

4. There are several other situations in which cases and/or revenue officers are not to be included in the consultation process:



1. Cases assigned to a probationary revenue officer because the employee has an OJI and a prescribed review process during the first year.

2. Cases assigned to a revenue officer who has been determined to be less than fully successful. Under this circumstance, cases are to be subject to full case reviews and consideration given to contacting Labor Relations for additional guidance and actions.

3. Cases assigned to non-field revenue officers. For example, a revenue officer assigned to Insolvency.

4. Cases assigned to revenue representatives and similar positions.

5. ATAT CIPs until such time as there are TDA, TDI, Combo or FTD Alert issuances on the taxpayer.


**1.4.50.5** **(01-25-2013)**

### Performance Management

1. The three balanced measures are: employee satisfaction, customer satisfaction and business results. These three balanced measures are part of every individual and organizational performance evaluation system within the IRS.

2. IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs), contains detailed guidance about evaluating performance. Refer to that IRM as well as the following information when evaluating performance.


**1.4.50.5.1** **(10-20-2023)**

#### Performance Evaluation

01. Preparing performance evaluations is one of your most important responsibilities. In carrying out this duty, you will observe how the employees are performing their duties and responsibilities to ensure that they are working efficiently and effectively to accomplish assigned tasks.

02. Because you are responsible for implementing the policies and directives relative to performance evaluations, you should thoroughly familiarize yourself with all facets of performance appraisal/evaluation information including, but not limited to:



    1. Performance expectations.

    2. Mid-year and periodic performance reviews.

    3. Annual ratings.

    4. Acceptable level of competence.

    5. Unacceptable/ minimally successful performance.

    6. Competitive promotion appraisals.

    7. Employee Performance files (EPFs).

    8. Performance and recognition awards.


03. A formal performance evaluation serves:



    1. As a record of performance to support, recommend and initiate actions such as within-grade increases, promotions, award recommendations, reassignments, details and adverse actions such as demotion or separation.

    2. To provide an employee with a basis for additional training and development.

    3. As a tool to improve the performance of individual employees.


04. For employees new to the government, the first year of employment is a probationary period during which the employee must demonstrate successful performance and the capability to be promoted to the next grade level (if applicable). See IRM 6.430.2.4.3, Employees Serving Probationary Periods.

05. Work closely with employees who are performing poorly, including probationary employees. Provide them with guidance/direction designed to assist them in improving performance. If performance improves, document the improvement accordingly. If performance fails to improve, refer to IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs), and seek appropriate advice to determine next steps.



    ### Caution:



    Seek advice from your FCM and LR specialist as soon as you recognize that the performance of an employee is unacceptable.

06. Documentation of Performance:



    1. Providing feedback to the employee (positive and constructive ) is essential to maintaining and/or improving their performance.

    2. Keep an employee's overall performance in mind when you discuss work and other activities. Let them know when some aspect of performance may influence their performance rating, a promotional opportunity or other personnel action.

    3. Recordation serves as a snapshot of employee performance. Adequate documentation will remind you of changes in performance over the rating period.


### Reminder:

Notify employees of decreased work performance per guidance in IRM 6.430.2.3.3, Acknowledging Decreased Work Performance

07. When writing review narratives be concise, but descriptive enough to provide an accurate picture of the strengths, development needs, and accomplishments of the employee in each CJE. See IRM 6.430.2.4.6, Completing Appraisal Narratives.

08. Performance evaluations provide a uniform means for a written evaluation and rating of each employee's proficiency.



    - IRM 1.5, Managing Statistics in a Balanced Measurement System, describes how balanced measures are used to support individual as well as organizational performance. The three balanced measures are : employee satisfaction, customer satisfaction, and business results. These three balanced measures are part of every individual and organizational performance evaluation system within the IRS.

    - IRM 1.5.2, Uses of Section 1204 Statistics, provides specific guidance for SB/SE use of measures. This IRM provides information about the prohibition on the use of records of tax enforcement results (ROTERs) to evaluate employees or to impose or suggest production quotas or goals.


09. Formal employee evaluations represent the sum of what you have observed in each employee's work, using feedback, reviews, visitations and other techniques discussed in this manual. Consider the following when evaluating performance for an annual appraisal:



    - Position description

    - Critical job elements (CJEs)

    - Mid-year and other progress reviews

    - Employee’s work products (management briefings, memos)

    - Employee’s self-assessment

    - Feedback from taxpayers and other customers

    - Team assignments and contributions to work group

    - Special achievements


10. Each employee will receive an annual performance evaluation. See information about Performance Appraisal Due Dates in the National Agreement, Article 12, Exhibit 12-1.

11. Employees may submit a self-assessment, limited to four pages in length, no later than the last workday of the employee’s annual appraisal rating period. See IRM 6.430.2.4.5, Self-Assessments and IRM 6.430.2.6 , Conducting the Performance Appraisal Meeting.

12. Use only the work requirements of the particular position or specific work standards established by the IRS to make Acceptable Level of Competence Determinations (i.e. determination that employee is performing at a fully successful level).

13. For information on the suggested steps to make unacceptable performance determinations, see _Exhibit 1.4.50-5_ .

14. Resources:



    1. Human Capital Office, see _IRM 1.4.50.1.8_, Related Resources for a link to this information. At this website you will find the CJE Resource Center, Manager Guide for Employee Performance, Performance Awards information, forms, etc.

    2. National Agreement see _IRM 1.4.50.1.8_, Related Resources for a link to the National Agreement.

    3. IRM 1.4.1, Resource Guide for Managers, Management Roles and Responsibilities.

    4. IRM 6.430.2.3.3, Acknowledging Decreased Work Performance.

    5. IRM 6.432.1, Reduction in Grade, Band and Removal Based on Unacceptable Performance.

    6. IRM 6.451, Employee Performance and Utilization.

    7. Other portions of IRM Part 6, Human Resources Management.

    8. The local Labor Relations specialist.


**1.4.50.5.2** **(04-01-2025)**

#### Reviews (Overview)

1. Providing ongoing employee feedback that is candid and meaningful is essential to employee satisfaction and is an integral part of the group manager’s responsibilities. Reviews of employee work should serve to:



1. Assess the employee’s effectiveness in meeting the expectations established in their Critical Job Elements.

2. Determine the employee’s efficiency in carrying out the laws, procedures, and policies of the IRS.

3. Identify and address performance problems.

4. Evaluate the employee's ability to properly plan and schedule field, office, and telework activity.

5. Ensure the employee is taking timely and appropriate actions to bring the case to a prompt and proper resolution.

6. Assess employee effectiveness in developmental case assignments.

7. Determine the employee's effectiveness in meeting the IRS Retention Standard for the Fair and Equitable Treatment of Taxpayers.


2. All reviews relating to a revenue officer's case work must be in writing. Managers must use EQRS to review individual cases, but other types of performance observation lend themselves to other methods. For reviews that consider RO activity across multiple cases (e.g., time utilization, office/field observation) a summary narrative, such as a memorandum, may be substituted.

3. The EQRS Individual Feedback Report provides a record of your ratings and the narrative comments in which the revenue officer’s performance is summarized. Become familiar with attribute definitions. Find a link to the Embedded Quality website for information about EQ attributes at _IRM 1.4.50.1.8_, Related Resources and Document 12359, Embedded Quality Job Aid (Collection) provide specific guidance related to Embedded Quality attributes and how to use them.

4. At the beginning of the fiscal year, group managers will develop a review schedule for the group that includes all mandatory reviews and optional reviews. Optional reviews may include additional office or field visitations, time and workload reviews, etc. The review schedule should provide for a fair and accurate assessment of the employee's overall performance throughout the rating period.

5. Mandatory reviews represent the minimum review requirements that must be completed for each employee. It is intended that the minimum requirements will provide managers with the opportunity to spend more time reviewing and developing revenue officers that need additional feedback and assistance.

6. Mandatory review include:



   - One or more annual field visitations, office observations or telephonic observations with each revenue officer.

   - One or more time utilization reviews with each revenue officer.

   - Mid-Year appraisals/reviews. The mid-year appraisal should occur at the mid-point (six-months) of the employee's appraisal period.

   - Annual case reviews. See _IRM 1.4.50.5.2.2_.


7. When necessary, based on case reviews, other forms of review, the consultation process, field or office observation, etc., you have the authority to require your employee to obtain your approval before taking subsequent case actions.



### Example:



Employees who inappropriately extend deadlines or delay case actions can be required to obtain your approval of their extensions in the future so as not to delay timely case resolution. The ICS calendar is an excellent tool that can assist the GM and RO when workload management issues are found.

8. Group managers will continually review information gathering activities by their employees. See IRM 5.1.3.7.1, Information Gathering Guidelines, for additional guidance.

9. For additional guidance on preparing reviews, narratives, and appraisals see:



   - IRM 1.4.1.8, Evaluating Performance

   - _Exhibit 1.4.50-6_, Collection Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide

   - IRM 5.1.3.7.1, Information Gathering Guidelines

   - IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non Bargaining Unit Employees Assigned to Critical Job Elements (CJEs)

   - IRM 5.13.1-3 Field EQRS Attributes, and IRM 5.13.1-4 Field NQRS Attributes.


### Note:

Operational review aids for field compliance managers and area directors are presented in _IRM 1.4.50.13_.

**1.4.50.5.2.1** **(10-20-2023)**

##### Case Reviews

01. Choose a sufficient number of cases for review to ensure a thorough evaluation of each employee’s performance. Reviews should be tailored to individual needs. Scheduling of the review may be announced or unannounced at the option of local management.



    ### Note:



    See _IRM 1.4.50.5.2.2_, Requirements for Annual Performance Case Reviews, for minimum review requirements.

02. Ensure case selection contains a mix of cases representative of the revenue officers assigned inventory. At a minimum, fifty percent of cases selected for review will be consistent with current priorities in the business plan. In addition to parameters, consider in-business trust fund, CSED/ASED, large dollar, cases with FPLP indicators, FTD Alerts and no activity cases. Emphasize cases in these categories on which there have been ten or more touches and cases that have been assigned for more than 120 calendar days. When reviewing BMF cases, the appropriateness of Letter 903 actions and timeliness of TFRP activity should be considered. See IRM 5.7.2.2, Issuance of Letter 903.

03. Work submitted for approval or closure also provides an opportunity to evaluate individual performance as well as the overall quality of your group's product. When reviewing cases submitted for approval or closure, look for performance that reflects an employee's adherence to IRM standards as well as other established policies and procedures. See _IRM 1.4.50.5.2.5_, Work Submitted for Approval/Closure.



    ### Caution:



    Confine your written review to work performed during the employees current rating period.

04. Use the Embedded Quality Review System (EQRS) for individual case reviews. A link to the EQRS system is located at _IRM 1.4.50.1.8_, Related Resources. The review items on the EQRS Individual Feedback Report correspond with the performance standards of a revenue officer’s critical job elements. In general, deficiencies relating to a critical job element should be noted as an area of special concern if found in 25 percent or more of the cases reviewed. There may be instances where a single deficiency (e.g., expired statute) is critical. The attribute narrative should summarize the revenue officer’s performance for each individual case reviewed.

05. In addition to case quality and timeliness metrics, taxpayer rights are evaluated in EQRS attribute 607. If you rate attribute 607 "No" with reason code 2, Right to Representation not Observed, you should enter a narrative detailing the circumstances supporting the "No" rating. You must report potential violations of IRC 6304, Fair tax collection practices to your local Labor Relations specialist by the end of the next business day following discovery _IRM 1.4.50.3.2.3_, Fair Tax Collection Practices.

06. You must also summarize the employee's overall performance on all cases reviewed, including the results of time utilization reviews, field/office visitations, etc., as part of your mid-year and/or annual performance assessment. Narrative feedback should address positive as well as negative aspects of an employee's performance. See _Exhibit 1.4.50-6_, Collection Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide.

07. As part of the case review, prepare the EQRS Individual Feedback Report in duplicate and include all applicable case data. Both you and the revenue officer must sign it. Give the original Individual Feedback Report to the revenue officer for action on case recommendations. Retain the duplicate in the employee's performance file (EPF) for follow-up. Discuss all recommended actions entered on the Individual Feedback Report with the revenue officer to ensure that there is a complete understanding regarding your observations and direction.

08. If you have directed specific case actions, a follow-up review should be scheduled 60-90 days after the initial review to ensure your instructions are being followed and the case is moving toward resolution. Follow-up review will generally be limited to the cases in which a follow-up review has been scheduled unless you need to see other cases to document a performance trend. Using EQRS, prepare a narrative conveying the results of the follow-up review.

09. Written performance feedback (Individual Feedback Report, Form 6067, memorandum, etc.) must be provided to the employee within 15 work days. The 15 day time frame starts from the time the supervisor becomes aware of, or should have been aware of, the event addressed in the recordation/feedback item.

10. Use the ICS History pick list to note "Case Reviewed" and the date of the review in the case history. Although you may suggest or request specific actions in the case history, you should avoid making numerous case decisions for the revenue officer. Documentation of an evaluative nature should not be entered in the case history.



    ### Note:



    A systemically generated history entry will appear in ICS based on the date shown the "Shared with Employee Date" section of the EQ review. The EQ system provides weekly (not daily) inputs to ICS, thus there may be a delay in the appearance of this history entry.

11. As part of any case review, determine if the assigned grade level is still accurate. See _IRM 1.4.50.10.1_, Case Grade.

12. During case reviews ensure that TP rights have been observed, particularly with respect to direct contact provisions. See IRM 5.1.23.4.2.3, Written Communication to a Taxpayer’s Representative and IRM 5.1.23.6, By-Passing a Taxpayer’s Authorized Representative.

13. Resources:



    - Embedded Quality, see _IRM 1.4.50.1.8_, Related Resources for a link to Embedded Quality.

    - CJE Resource Center, see _IRM 1.4.50.1.8_, Resources for a link to the CJE Resource Center

    - IRM 5.7.2.2, Issuance of Letter 903

    - IRM 5.13.1, Embedded Quality Collection Field Organizations Administrative Guidelines

    - IRM 6.430.2.4.9, Rating CJEs


**1.4.50.5.2.2** **(10-20-2023)**

##### Requirements for Annual Performance Case Reviews

1. For revenue officers GS-09 and below and all revenue officers rated less than fully successful, select a minimum of twelve (12) cases per year for review that meet the criteria in _IRM 1.4.50.5.2.1_. Review at least half of the cases prior to the mid-year progress review.

2. For revenue officers GS-11 and above that are rated fully successful or higher, select a minimum of eight (8) cases per year for review that meet the criteria in _IRM 1.4.50.5.2.1_. Review at least half of the cases prior to the mid-year progress review.

3. Review plans should be tailored to fit the needs of individual revenue officers.

4. Use EQRS attributes, case summary narratives and performance summaries for all reviews conducted during the rating period to create performance feedback. Feedback must indicate to the employee how they are meeting or not meeting the EQRS attributes and aspects of the critical job elements.

5. Provide the employee with the narrative within 15 work days and place a copy of the data collection instrument (DCI) in the employee's EPF.

6. If the review is not shared with the employee within the 15 work day period, the review must not be used for any evaluative purpose. You may be required to perform a review of another case in order to meet the minimum number of required cases reviews based on the employee’s grade as indicated above.

7. If the DCI for a review was not shared with the employee within the 15 work day period it must not be placed in the employee’s EPF and the DCI must also be removed from EQRS. The DCI may be deleted from the EQRS using the **Edit DCI** feature.

8. The mandatory field/office visitations, telephonic observations and time utilization reviews mentioned in _IRM 1.4.50.5.2.3_, Field and Office Observations, _IRM 1.4.50.5.2.3.1_, Telephonic Observations and _IRM 1.4.50.5.2.4_, Time Utilization Review are _in addition to_ the minimum case review requirement.


**1.4.50.5.2.3** **(10-20-2023)**

##### Field and Office Observations

1. Observing the revenue officer during face-to-face contacts, either in the field or office, provides an excellent opportunity for you to assess the revenue officers:



1. Ability to conduct interviews.

2. Ability to communicate and interact with taxpayers.

3. Knowledge of policies and procedures.

4. Ability to deliver fair and courteous treatment to all taxpayers.


2. Conduct one or more annual field visitations or office observations with each revenue officer. When possible, conduct the field/office observation during the initial contact with the taxpayer.

3. In situations where your group has been assigned replacement inventory due to a natural disaster, and there are no cases within the revenue officers geographic assignment area which do not contain a -O freeze, it is appropriate to observe a telephonic contact between the revenue officer and the taxpayer or the taxpayer’s representative. When you are observing a telephonic contact, advise the taxpayer or the taxpayer’s representative of your observation at the beginning of the contact.

4. During your observations evaluate the revenue officer for:




| **Observation Elements** |
| :-: |
| Ability to secure material information necessary to determine appropriate case direction. |
| Delivery of fair and courteous treatment of taxpayers. |
| Ability to address the various rights of the taxpayer (Pub. 1, Pub. 594, IRC 6320 and 6330, Collection Appeals Program). |
| Ability to recognize and respond to taxpayer concerns, issues, and interests. |
| Pre-contact preparation. |
| Itinerary planning. |
| Effective use of time. |
| Ability to manage difficult, unexpected, complex or unusual circumstances. |
| Ability to appropriately recognize and address third party contact situations. |
| Observation of proper disclosure requirements. |

5. Provide feedback based on all of your observations using a summary narrative, such as a memorandum, Form 6067, Employee Performance Folder Record, Form 10164, Manager’s Field/Office Visitation Report and Targeted EQRS Review, or a targeted EQRS review.

6. Resources:



   - CJE Resource Center, see _IRM 1.4.50.1.8_ Related Resources for a link to the CJE Resource Center.

   - IRM 5.1.1.12, Third Party Contacts

   - IRM 25.27.1, Third Party Contact Program

   - IRM 6.430.2.2.1, Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRM 11.3.1, Introduction to Disclosure


**1.4.50.5.2.3.1** **(10-20-2023)**

###### Telephonic Observations

1. In certain situations, it may be necessary for a group manager (GM) to conduct observations of revenue officer contacts with taxpayers or the taxpayer’s authorized representative telephonically. Telephonic observations are an appropriate method to evaluate a revenue officer’s contact with taxpayers when a face-to-face observation is not possible due to the location of the taxpayer/representative or in situations where the IRS has suspended face-to-face contacts in the interest of the health or safety of the employee or the public. Additionally, the use of telephonic observations is also appropriate for virtual contacts between employees and members of the public.

2. When necessary, telephonic observations are an acceptable alternative to the mandatory field visitation or office observation review requirement set forth in IRM 1.4.50.5.2(4)(a). Common situations where it may be necessary to conduct an observation of a telephonic contact between a revenue officer and member of the public include:



1. _Replacement Inventory_. In cases of federally declared disasters, the Disaster Program Office authorizes input of a -O freeze on cases in areas most seriously impacted by the disaster by ZIP code. Most compliance activities, including face-to-face contacts are suspended on accounts containing a -O freeze. In situations, where all of the inventory assigned to a RO contain a -O Freeze and the inventory available for assignment to the RO based on the parameter table contain -O freeze indicators, you may assign replacement inventory to maintain continuity of operations.

2. _Replacement Inventory_ is defined as inventory meeting criteria established by headquarters, to be assigned to field collection groups in areas affected by a declared national disaster in order to maintain continuity of Field Collection operations. These cases are located outside of the covered disaster area and are generally worked remotely without travel to the taxpayer’s location. It is appropriate for you to conduct an observation of a telephonic contact between the RO and the taxpayer/representative on replacement inventory accounts.

3. _Remote Assignments._ In situations where management has assigned inventory beyond the RO’s assignment area with the expectation the inventory will be worked remotely without travel to the taxpayer’s location, it is appropriate to observe telephonic contacts on those cases.

4. _Temporary suspensions of face-to-face contacts._ In exceptional circumstances, the IRS may temporarily suspend in-person interviews in the interest of the health or safety of the employee or the public. It is appropriate for you to perform observations of telephonic contacts in this situation.



      ### Example:



      Face to face contacts were suspended during the COVID-19 pandemic.


3. GMs will coordinate their attendance of the telephonic contact with the RO in same manner used to attend an office or field observation. GMs will be required to advise the taxpayer, or the taxpayer’s authorized representative, of their attendance and the purpose of their attendance at the beginning of the call.

4. Provide feedback based on your observations. IRM 5.13.1, Embedded Quality Collection Field Organizations Administrative Guidelines provides for documenting feedback using the EQRS system.


**1.4.50.5.2.4** **(04-01-2025)**

##### Time Utilization Reviews

1. Conduct one or more time utilization review annually with each revenue officer. Use the time utilization review to measure the overall effectiveness of the RO's office, field, and/or telework. Make observations regarding work quality as appropriate, but the purpose of this review is to evaluate employee performance in effective use of time and accuracy of documentation.

2. Conduct the time utilization review within fifteen (15) workdays of the day selected.

3. Time utilization reviews should be unannounced. Document the review with a memorandum or Form 6067, Employee Performance Folder Record or targeted EQRS review, to summarize your observations.

4. When performing the time utilization review:



   - Evaluate whether time spent on case actions matches the time charged as well as the nature and complexity of what is required in each case.

   - Evaluate whether the case actions taken are likely to move the case toward resolution.

   - Identify unproductive/inefficient activity and make recommendations for improvement.


### Example:

You notice that the RO spent several hours completing initial analysis on cases in preparation for a field day, even though some of the cases did not appear to warrant that degree of preparation. Explain that a “one size fits all” approach is not efficient. It would be reasonable to recommend that the RO consider dollar amount, complexity, grade of the case, and other readily identifiable issues to determine the scope of initial analysis needed. The objective is to conduct the amount of research and analysis necessary to formulate a resolution plan.

### Example:

You notice that RO activity on four of six delinquent return cases worked on the same day consisted of repeat phone calls to obtain delinquent Form 941 tax returns instead of using the appropriate IRC 6020(b) process. Provide your expectation that, in the future, the RO will use the IRC 6020(b) process when appropriate. When IRC 6020(b) would not be appropriate, the RO should document the case history to reflect the reason.

5. Documentation should be shared with the RO and maintained as part of the EPF to be used in preparation of the Mid-Year/Annual Appraisal.


**1.4.50.5.2.5** **(09-12-2014)**

##### Work Submitted for Approval/Closure

1. When work is submitted to you for approval, you have an opportunity to evaluate your employees' performance. This also enables you to prevent deficiencies. Check for accuracy and level of quality before approving reports of currently not collectible taxes, installment agreements, requests for adjustment, seizure documents, TFRP investigations and recommendations, fraud referrals, and any other document prior to submission to another function. The quality of the work that leaves your group is a reflection on you as a group manager.

2. For reminders about some specific items to check while reviewing work submitted for approval, refer to _Exhibit 1.4.50-2_. That exhibit is not an exhaustive list of requirements. Always refer to topical IRM sections if you have questions.

3. Approvals of case resolutions, including trust fund recovery penalty (TFRP) recommendations, and those cases requiring financial analysis/verification will be made only after review of the applicable documents from the paper case file. Ensure that the financial analysis is consistent with the proposed collection determination. Also ensure that appropriate verification of equity in assets, income and expenses is in the file.


**1.4.50.5.3** **(10-20-2023)**

#### Use of Statistical Data/Section 1204 /ROTERs

1. Section 1204 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA 98) prohibits the use of records of tax enforcement results (ROTERs) to evaluate employees or to impose/suggest production quotas/goals for any employee. See 26 CFR 801.3(e) implementing section 1204(a) of RRA 98.

2. IRM 1.5.2, Managing Statistics in a Balanced Measurement System, Uses of Section 1204 Statistics , provides guidance to prevent the use of statistics to:



1. Evaluate employees.

2. Impose or suggest production quotas or goals with respect to such employees.


3. You are prohibited from using records of tax enforcement results to evaluate any employee who exercises judgment with regard to determining tax liability or ability to pay. ROTERs are data, statistics, compilations of information or other numerical or quantitative recordations of the tax enforcement results reached in one or more cases. See IRM 1.5.2.11, Records of Tax Enforcement Results (ROTERs). This prohibition includes:



   - Self-assessments

   - Awards narratives

   - Case/workload reviews

   - Performance plans

   - Narrative feedback to evaluations


### Note:

ROTERS **do not include** tax enforcement results of individual cases when used to determine whether an employee exercised appropriate judgment in pursuing enforcement of the tax laws based upon a review of the employee’s work on that individual case.

4. You are also prohibited from using ROTERs to impose or suggest production goals or quotas for employees or groups of employees. Examples of prohibited ROTERs include:



   - Number of delinquent returns secured

   - Number of delinquent returns secured with full payment

   - Full payment rate

   - Number of seizures made

   - Number of levies issued

   - Number of OICs recommended for acceptance

   - Number of accounts reported currently not collectible


5. Resources:



   - IRM 1.5.1, Managing Statistics in a Balanced Measurement System-The IRS Balanced Performance Measurement System

   - IRM 1.5.2, Managing Statistics in a Balanced Measurement System-Uses of Section 1204 Statistics

   - IRM 1.5.3.4, Section 1204 Quarterly Certification Requirements

   - Section 1204 Resources


**1.4.50.5.3.1** **(01-25-2013)**

##### Tax Enforcement Results (TERs)

1. A tax enforcement result (TER) is the outcome produced by an IRS employee's exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of tax laws.

2. TERs may be discussed in employee reviews (but not employee evaluations) to determine if the employee exercised appropriate judgment, used time efficiently, and applied the laws in one or more cases properly. See IRM 1.5.2.10.1, Permitted Use of TERs.


**1.4.50.5.3.2** **(01-25-2013)**

##### Regulation 801/ Quantity & Quality Measures

1. Regulation 801 implements the provisions of Section 1204 of the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA 98), provides rules relating to the establishment of a balanced performance measurement system and sets forth rules governing the use of ROTERs.

2. _Quantity_ measures consist of outcome neutral production and resource data that does not contain information regarding the tax enforcement result (TER) reached in any case involving particular taxpayers. Examples of quantity measures include:



   - Cases started

   - Cases closed

   - Time per case


3. Performance measures based in whole or in part on quantity measures will not be used to evaluate the performance of any non-supervisory employee who is responsible for exercising judgment with respect to tax enforcement results.

4. The _quality_ review of the handling of collection cases focuses on such factors as whether employees devoted an appropriate amount of time to a matter, properly analyzed the facts, complied with statutory, regulatory and IRS procedures, etc.

5. Employees who are responsible for exercising judgment with respect to tax enforcement results in taxpayer cases may be evaluated on work done in such cases only in the context of their critical elements and standards.

6. Resources:



   - IRM 1.5.2.12, Quantity Measures

   - IRM 1.5.2.13, Quality Measures


**1.4.50.5.4** **(10-20-2023)**

#### Retention Standard

1. In addition to being evaluated according to the critical elements and standards or such other performance criteria as may be established for their positions all employees of the IRS will be evaluated on whether they provided fair and equitable treatment to taxpayers. See 26 CFR 801.3(b) implementing section 1204(b) of RRA 98.

2. Form 6774, Receipt of Critical Job Elements and Retention Standard, is maintained in the EPF.

3. Resources include:



   - IRM 1.5.3.3, Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - IRM 6.430.2.4.7, Rating Performance Against The Retention Standard for the Fair and Equitable Treatment of Taxpayers

   - See _IRM 1.4.50.1.8_, Related Resources for a link to Retention Standard resources


**1.4.50.5.5** **(01-25-2013)**

#### Within Grade Increase

1. An employee shall be advanced in pay to the next higher step of their grade upon meeting the following requirements:



1. Required waiting period completed.

2. No equivalent increase in pay received during the required waiting period.

3. Fully successful performance in each of the critical job elements of their position.


2. Use only the work requirements of the particular position or specific work standards established by the IRS to make Acceptable Level of Competence Determinations (i.e. determination that employee is performing at a fully successful level).



### Reminder:



See IRM 6.430.2.5.4, Within-Grade Increase (WGI) Determination.

3. For information on steps to follow when an employee is not meeting an acceptable level of competence, see _Exhibit 1.4.50-4_.


**1.4.50.5.6** **(10-20-2023)**

#### Evaluation Due Dates

1. Each employee will receive an annual performance evaluation. The due date of an evaluation for any particular employee is based upon the last digit of the employee’s Social Security Number (SSN). Refer to the National Agreement, Article 12, Exhibit 12-1. See _IRM 1.4.50.1.8_, Related Resources for a link to the National Agreement.


**1.4.50.5.7** **(04-01-2025)**

#### Discipline/Disciplinary Actions

1. Discipline is defined as measures taken by management that are intended to correct employee misconduct, and encourage employee conduct in compliance with the standards of conduct, policies, goals, work procedures, and office practices of the IRS and the federal service. Employees must adhere to all known conditions and standards of conduct established to provide for the orderly and efficient administration of the IRS.

2. Employees who fail to comply with standards of conduct, work procedures, and office practices will be subject to disciplinary action designed to correct the violation and motivate the employee to become a productive member of the IRS.

3. You are responsible for establishing _and maintaining_ effective discipline within your work group. You must explain the work requirements and other standards your employees are expected to meet.

4. Section 1204(b) of the Internal Revenue Service Restructuring and Reform Act of 1998 requires IRS employees, managers and executives to be evaluated on the fair and equitable treatment of taxpayers. The IRS has incorporated this evaluative requirement into the "Retention Standard." Instances where a taxpayer’ s rights have been violated due to intentional disregard to IRS policies or statutory requirements must be reported to your local Labor Relations servicing specialist for consideration and appropriate discipline in accordance with IRM 6.751.1, Discipline and Disciplinary Actions-Policies, Responsibilities, Authorities, and Guidance.

5. When disciplinary action is required, it must be fair, equitable, impartial and as timely as possible.

6. A guide to assist you in determining appropriate penalties to correct improper conduct can be found in Document 11500, IRS Manager's Guide to Penalty Determinations.

7. Ensure that you discuss and coordinate all proposed disciplinary actions with your Labor Relations specialist.

8. Resources:



   - IRM 6.751, Discipline and Disciplinary Actions

   - IRM 6.752, Disciplinary Suspensions and Adverse Actions

   - The National Agreement, Articles 38 and 39. See _IRM 1.4.50.1.8_, Related Resources for a link to the National Agreement.


**1.4.50.6** **(09-12-2014)**

### Telework

1. Telework (formerly known as flexiplace) is a program that permits your employees to work at home or at other approved locations other than the assigned post of duty.

2. There are three (3) forms of telework:



1. Frequent

2. Recurring

3. Ad Hoc


3. See Article 50, Section 1B of the National Agreement for more information about types of telework.


**1.4.50.6.1** **(04-01-2025)**

#### Managing In a Telework Environment

1. Managing an employee participating in telework is essentially no different than managing an employee in the office. Ensure that your actions are in compliance with any applicable local telework agreement (if one exists) as well as the National Agreement. The employee on telework is still held accountable for the rules of conduct, critical job elements, time and attendance, ethics, and all other regulations applicable to their position.

2. Per Article 50, Section 1F of the National Agreement: telework is not a replacement for dependent/family care.

3. If you determine that an employee's work appears to be degrading from "fully successful" or is below a "fully successful" rating, you should review Article 50 Section 2 of the National Agreement to determine whether the employee's continuation on telework is appropriate. This occurs when any CJE rating equals "2" or below.

4. Ensure that your reasons for removal are well documented. This documentation may include but is not limited to EQRS Individual and/or cumulative feedback reports , Form 6850, or memoranda. You must ensure that the employee is aware of the situation and you should then monitor their work product closely and develop a plan for improving that employee’s work, just as you would for an employee not on telework. There is no prohibition per the National Agreement on any type of performance review following a period in which an employee has worked at their telework site. Reviews may include **time utilization**, **time and activity**, or other performance based review. Ensure this also conforms with any applicable local area agreement as well. The types and amount of time expended on telework should be comparable to time in the office. For example, there should not be increased amounts of administrative or miscellaneous time, or increased time charged to cases with minimal actions taken.

5. You should ensure that revenue officers are responsive to all customers. They must check voice mail and email (when accessible) to ensure external as well as internal customers (including managers) receive responses timely. It is appropriate for an employee to check their VMS and email prior to going to lunch and some time prior to ending their day.

6. You have the right to direct a telework employee to report to the office when necessary. For example, when having meetings, which include group meetings, case reviews, the consultation process, training, etc. This should be planned so that the employee has ample time to report to the office during their regular commute time. When an employee plans or decides to make field calls during a telework day the manager should be informed. This is referenced under Article 50, Section 5A of the National Agreement.

7. Article 50 of the National Agreement addresses telework issues. Sections pertinent to the management of employees in a telework environment are listed below:



1. _A supervisor’s official relationship with, authority over, and accountability for an employee participating in the IRS’s telework program is no different than their relationship with, authority over, and accountability for employees who are not participating in the telework program. In this regard, the supervisor retains the authority to review, determine, and approve participation in this program (Article 50, Section 1A-5)._

2. Revenue officers may participate in "frequent" telework. Subject to approval by their supervisor, frequent telework permits the revenue officer to work at an approved location remote to the assigned post-of-duty (POD) more than eighty (80) hours monthly (Article 50, Section 1B).

3. Revenue officers approved for a recurring telework arrangement may work at the approved telework site for 80 hours or less per month (Article 50, Section 1B).

4. Participants may be permitted to work at approved telework sites for full days or a portion of a day.



      ### Reminder:



      _Unless as otherwise provided by Article 50, Section 1C of the National Agreement:_ there is no limitation on how the work schedule may be configured as long as the scheduling is not disruptive to the work that remains in the office nor causes an unreasonable burden on those who choose not to work a telework arrangement.

5. Management has the right to meet with employees to give assignments and to review work as necessary at either the official duty station, approved telework location, or a mutually agreed upon site. (Article 5, Section 4C) This does not mean that 24 hour notification or union presence is required, but 24 hour notification is suggested.

6. Employees must provide the supervisor and/or clerk in advance with all the specific information regarding their work schedule, type of work to be performed and location of the alternate work place. This includes the obligation to inform the supervisor when they are unable to perform work due to illness or other circumstances during the telework tour of duty (TOD) and requesting appropriate leave (Article 50, Section 5A-1).

7. Employees must contact the office to report time, to retrieve messages, and to notify the supervisor and/or clerk of changes in work locations (Article 50, Section 5A).

8. In order to ensure accountability, a participating employee and their supervisor must communicate at least one time during each pay period to verify the employee’s time and attendance (Article 50, Section 6E). In addition to this, the manager should ensure that the revenue officer will EOD, uploading all time and activity at least once per week. See IRM 5.2.1.7.1, Field Collection Procedures, for more information about time reporting and end of month (EOM) guidelines.


8. Resources include: IRM 6.800.2, IRS Telework Program.


**1.4.50.6.2** **(01-25-2013)**

#### Interaction With Employees On Telework

1. **Your official relationship with, authority over, and accountability for an employee participating in the IRS's telework program is no different than that for employees who are not participating in the program.**

2. Your responsibilities include:



1. Meeting with your employees at least once a year for the purpose of discussing, reviewing and updating the telework agreement.

2. Directing telework employees to report to the office due to special circumstances.

3. Meeting with employees to give assignments and review their work as necessary at the official duty station, approved work site that includes their home, or mutually agreed upon site.

4. Inspecting the employee's work site when appropriate. You may visit the telework site, with twenty- four (24) hours notice, to ensure that information systems (IS) and sensitive information procedures are in place.



      ### Reminder:



      Work site inspections are not expected to be routinely conducted. Inspect as necessary to verify IS/sensitive information procedures.

5. As with non-remote employees, be proactive in identifying opportunities to rate CJE 1, Workplace Interaction/Involvement/Enviornment.


3. For an employee to remain on the telework program, they must:



1. Remain "fully successful" or above.

2. Not be subject to a conduct investigation in which management has sufficient evidence of serious wrongdoing that would impact the integrity and efficiency of the IRS.

3. Continue to stay in compliance with Article 50, Section 2 of the National Agreement.


4. If any of the above circumstances do not apply, the employee may be suspended from telework pending resolution of the performance and/or conduct investigation situations.

5. For further information, contact the local Labor Relations specialist. You can also refer to the National Agreement , Article 50. Coordinate proposed changes to telework arrangements with your LR specialist.


**1.4.50.7** **(10-20-2023)**

### Recognition and Awards

1. Awards are opportunities for group managers to recognize and reinforce positive performance and behavior.

2. You are responsible for maintaining a working knowledge of the awards process.

3. Complete information regarding awards can be found on the Human Capital SharePoint at: Performance Awards.

4. Resources include:



   - IRM 1.4.1.8.3, Recognition and Awards

   - National Agreement , Article 18, for a link to the National Agreement see _IRM 1.4.50.1.8_, Related Resources

   - IRM 6.451.1, Employee Performance and Utilization, Policies, Authorities, Categories and Approvals

   - The local Human Resources Specialist


**1.4.50.8** **(01-25-2013)**

### Field Collection Workload Management

1. You are responsible for effectively managing the group's workload. To accomplish this you must:



1. Ensure priority cases are worked.

2. Assign cases based on grade and priority level. See _IRM 1.4.50.8.4_ and _IRM 1.4.50.10.1_.

3. Maintain targeted inventory levels and make adjustments as appropriate.

4. Balance inventories within your group.

5. Ensure case activity is progressing toward resolution.

6. Continually strive to improve production, work processes, and/or to increase the quality of the work directed.


**1.4.50.8.1** **(01-25-2013)**

#### Total Inventory Management (TIM)

1. Strive for currency of inventory by encouraging revenue officers to take the right action at the right time on each case.

2. Communicate to revenue officers that you expect them to work their inventory as a whole.


**1.4.50.8.2** **(10-20-2023)**

#### Using ENTITY For Workload Management

1. ENTITY is the primary case management system for group managers. Group managers should familiarize themselves with the user guides and resources found on the ENTITY website. See _IRM 1.4.50.1.8_, Related Resources for a link to the ENTITY website and IRM 5.3.1, ENTITY Case Management System.

2. ENTITY receives information about case and RO activity from the Integrated Collection System (ICS), and the Delinquent Investigation/Account Listing (DIAL). ENTITY includes group level inventory, and time and activity information.

3. Use ENTITY to:



1. Manage and assign revenue officer inventory.

2. Identify trends and patterns and cases where the revenue officer may need assistance, such as listed in (4) below.


4. You can use the ENTITY report “Random Case Listing” to select categories of cases for review, such as pyramiders, trust fund repeaters, statute, no activity, etc.

5. You can also use ENTITY to:



1. Review the group queue using various sort options to select cases for assignment to revenue officers.

2. Study workloads in particular zip codes.

3. Examine inventory levels to support a request for additional staffing.

4. Quickly identify inventories which deviate from targeted inventory.

5. Generate a group inventory priority level statistical report.


6. Resources include:



   - IRM 5.3.1, ENTITY Case Management System

   - ENTITY, see _IRM 1.4.50.1.8_, Related Resources for a link to the ENTITY website.


**1.4.50.8.2.1** **(04-01-2025)**

##### ENTITY Case Management System Reports

1. ENTITY serves as an integral tool in management of the entire group’s inventory. There is no expectation that every available report/query will be run. Rather, you should identify those that best reflect the individual needs of your group, and run those as needed. In general, reports should not be run merely for the purpose of requesting a “status update” from an employee. Use ENTITY queries and end of month reports to establish ASED and CSED controls necessary per _IRM 1.4.50.11_. In addition, utilize the reports and queries to:



   - Identify inventory trends

   - Identify inventory in need of additional attention

   - Monitor progress made on previously-identified trends


2. Resources include: _IRM 1.4.50.1.8_, Related Resources for a link to the ENTITY website.


**1.4.50.8.3** **(09-12-2014)**

#### Queue

1. The queue is an electronic file holding unassigned collection cases. Cases in the queue are prioritized for selection.

2. Cases can go into the queue from both ACS and Field Collection.

3. IDRS assignment number "AOTO7000" is used for cases in the queue.


**1.4.50.8.4** **(10-20-2023)**

#### Case Priority Level

1. All cases are assigned a priority level as follows:



   - 99-108 are high priority

   - 201-208 are medium priority

   - 301 & 302 are low priority

   - 399 non-IDRS case


### Exception:

Priority Level 399 is a default priority level for non-IDRS assignments _and is not associated with the priority of the case_. For example, an FTD Alert is a non-IDRS case displaying a priority level 399, but is a high priority case.

2. The prioritization process is designed to display cases in a priority hierarchy from the highest to lowest priorities. Case are prioritized weekly.



1. **High Priority 108**: "Taxpayer Contact Required" cases are driven by the TSIGN (64xx/65xx), which alerts ICS that the case originated from Compliance Services Collection Operation (CSCO) or ACS and carries an ICS sub code of 601 (IMF), 602 (BMF), 603 (other) or 604 (Large Dollar ).

2. **Priority levels 99 through 302:** various elements are included in the prioritization such as: balance due, return types, tax period, model score and selection code.


**1.4.50.9** **(10-20-2023)**

### Hold Files

1. Group designation hold files are established for every group and are sometimes referred to as ICS GM hold files. The assignment code for this required hold file is: "AOTOxx00" . ICS GM hold files (mandatory) are not the same as group hold files (optional). Group hold file assignment codes may be established to control cases meeting specific criteria. See _IRM 1.4.50.9.2_ for more information about group hold files.


**1.4.50.9.1** **(10-20-2023)**

#### Group Designation Hold File

1. Certain BAL DUE or DEL RET cases move directly from notice status to Field Collection (FC). These cases bypass both ACS and the queue and are assigned directly to ICS (cases will be sent directly to the ICS GM hold file). See IRM 5.1.20.3.1, Cases that Bypass ACS and the Queue that go Directly to ICS. Other types of cases will also arrive in your hold file, including FTD Alerts, OIs, case transfers, etc.

2. Manage your ICS GM hold file by conducting weekly reviews to determine:



1. Which cases to assign and which to send to the queue. See IRM 5.1.20.3.3, Cases that Cannot be Moved to the Queue.

2. Whether cases meet the requirements for mandatory assignment. See IRM 5.1.8.6, Mandatory Assignments, and IRM 5.7.1.4, Receipt of FTD Alerts.


### Reminder:

FTD alerts must be assigned to an RO within seven calendar days from the date the alert arrives in your GM hold file. Do not assign Federal Agency Delinquency (FAD) cases to ROs.

3. If you suspect you have received _erroneous assignments_ in your GM hold file, and you cannot transfer the case to the queue, contact your IQA and determine the appropriate resolution for such cases. See _IRM 1.4.50.9.1.1_.

4. Do not shelve any case unless authorized by a specific policy directive or memorandum issued by the Headquarters staff. See _IRM 1.4.50.9.1.1_.

5. To decrease cycle time, do not keep cases in the group designation hold file (AOTOxx00) more than 45 days after receipt. When you must keep a case in the hold file for more than 45 days, document the case history to show the reason.



### Reminder:



There should not be any cases assigned directly to your GM assignment number ending in 01. When you see cases assigned to AOTOxx01, take immediate action to move them to the appropriate assignment code (group designation hold file, RO assignment or transfer o the queue).

6. "Taxpayer Needs Assistance" (High priority 99-108 with sub code 601-604) cases must be promptly assigned to a revenue officer _unless_ it is evident that the priority level coding is erroneous. Erroneously coded cases may be returned to the queue. Because many "Taxpayer Needs Assistance" cases come from a Campus, Toll Free Operation, or ACS, they may arrive without a clear explanation. If the contact request cannot be verified, document the ICS case history and send any non-restricted case to the queue.



1. For non-ACS accounts, look for a Form 4442, Inquiry Referral, transmittal, or annotation on IDRS.

2. For ACS accounts, secure a copy of the account transmittal. It may be helpful to review the Accounts Management System AMS history.


7. When reassigning the inventory of a departing revenue officer, review all considerations in _IRM 1.4.50.10.3_, Reassignment of Departing Revenue Officer Inventory. Per guidance in that subsection, add such cases to your group designation hold file _only after_ exhausting other assignment options.


**1.4.50.9.1.1** **(10-20-2023)**

##### Shelving Erroneously Assigned Cases/Modules

1. Occasionally, you may find that your GM hold file contains erroneously assigned cases that cannot be transferred to the queue. An erroneously assigned case is one that is delivered inadvertently, i.e., the case was not routed to the intended destination. A case/module is not considered erroneously assigned solely because it is delivered to the group designation hold file with less than six months remaining on the CSED.

2. Headquarters provides guidance about erroneously assigned cases when appropriate. Do not shelve any case/module without an expressed written authorization Headquarters staff. Headquarters’ guidance to shelve may take the form of a memo, ICS Alert or email. The guidance will describe the conditions which qualify a module for shelving or provide a list cases which contain modules eligible for shelving.

3. Contact your IQA if you suspect a case has been erroneously assigned to your GM hold file or an employee in your group and you have made an assignment determination to transfer the case to queue, but the transfer is blocked or reversed due to the presence of one or more modules with less than six months remaining on the collection statute expiration date (CSED).

4. Submit an ICS Help Request at ICS Help Request on the Collection Automation Support and Security (CASS) Customer Support SharePoint Site. The ICS/ENTITY Quality Analyst (IQA) will elevate the shelving request to the CASS staff analyst who will forward the request to the appropriate Headquarters analyst. The following information is required to evaluate your request:



   - The taxpayer’s name

   - Taxpayer identification number (TIN) for the case

   - Compete TDINQ history for the account

   - The information which supports your determination the case was erroneously assigned.

   - Complete Accounts Management System (AMS) history for the case

   - Reference to the Headquarters guidance allowing use of shelving procedures


5. The CASS staff analyst will forward an encrypted email to the appropriate Headquarters analyst generally Collection Policy or Collection Case Delivery containing the items above to have the request evaluated.

6. In instances where an account was erroneously assigned from ACS the CASS staff will forward the shelving request to the ACS Headquarters analyst.



### Note:



Cases where the account has been transferred to Field Collection based on contact with the taxpayer _and_ the account balance exceeds the authority level of the transferring function are **not** considered erroneous even if the account contains a short CSED.

7. If your request is approved the IQA will shelve the short CSED module(s). The IQA staff will only shelve the specific _module(s)_ with less than six months remaining on the CSED via the input of TC530/CC39. The GM must take the assignment actions on any remaining modules.

8. The instructions above are limited to those erroneously assigned cases that cannot be normally processed to the queue and does not cover any case currently assigned to a revenue officer or any hold file case with a prior revenue officer assignment within the past 60 days.


**1.4.50.9.1.2** **(10-20-2023)**

##### Federal Agency Delinquency Cases

1. Field Collection is not to work federal agency delinquency (balance due and delinquent returns) cases, except in special circumstances. See IRM 5.1.7.7, Federal, State and Local Government Agencies.

2. Federal agency delinquency (FAD) cases are identified by the "Employment code -F." This code is located on:



   - The Integrated Collection System (ICS) on the "Other Entity Information" screen for Business Master File (BMF) taxpayers.

   - IDRS on the "ENMOD" and "SUMRY" screen.


3. Federal agency delinquency (FAD) cases receive a unique collection assignment number. The inventory delivery system (IDS) will route these cases to the FAD unit in Brookhaven and use TSIGN 21008300.

4. Situations may arise in which Field Collection receives cases through mis-routing. The FAD unit should identify these accounts, reassign them on IDRS to the FAD group assignment, and contact the assigned revenue officer or group manager and advise them of the transfer. ICS does not have the ability to reassign cases to 21008300. The FAD unit uses IDRS to complete these actions.

5. If these cases appear in your group designation assignment queue, do not assign to revenue officers. Review the entity information of cases which may appear to be federal agencies to ensure they are not assigned.

6. If a Federal Agency Delinquency case is assigned to a revenue officer in error or directly assigned to a revenue officer, you should re-assign the case to the GM hold file. If you need a case removed from your GM hold file before FAD reassigns it, you may contact the FAD unit directly at : Federal Agency Delinquency Unit.

7. As with any case that remains in the group designation hold file for more than 45 days, document the case history with the reason. See _IRM 1.4.50.9.1_.

8. Resources include:



   - IRM 5.1.7.7, Federal, State and Local Government Agencies

   - _IRM 1.4.50.9.1_, Group Designation Hold File


**1.4.50.9.2** **(08-11-2021)**

#### Group Hold Files

1. There are certain situations in which cases become inactive and warrant removal from revenue officer inventories, but must still be maintained in the collection group. In order to accommodate these situations, group hold files are authorized as specified below. Use of a group hold file is optional and is left to local management's discretion. However, **if group hold files are utilized, the following procedures must be followed.**

2. In order to maintain consistency, hold files must be designated specific assignment numbers and will be limited to the types of cases as described below:




| **Assignment Number** | **Group** | **Type of Cases** | **Explanation** |
| :-: | :-: | :-: | :-: |
| AOTOxx91 (CDP/Appeal Case Hold File) | Field revenue officer | Collection Due Process (CDP) OIs | CDP Appeals Hold File: Receipt of the CDP in Appeals is confirmed and there is no open Bal Due or Del Ret and no further collection actions are warranted. See IRM 5.1.9.3.4, Controlling and Monitoring Cases While in Appeals. |
| AOTOxx99 (Non-CDP Case Hold File) | Field revenue officer | Pending adjustments. Temporary suspension of collection action or guidance by Headquarters. | Cases in which no revenue officer action or monitoring is needed. Cases which require the completion of a collection action which has been temporarily suspended prior to closure or transfer. |

3. Cases should not be assigned to these hold files if action or monitoring is required on the part of the revenue officer or offer specialist. The revenue officer will document the case history with the specific reason the case is being reassigned to the proper hold file and submit the request to the manager for approval. The manager will determine whether the case warrants assignment to the group hold file, document approval in the case history, and reassign the case to the specified number as noted above.

4. Cases or OIs which require the completion of a collection action which has been temporarily suspended is defined as accounts where all of the investigative steps have been taken to support a case resolution alternative (e.g. IA, CNC etc) but need to remain open on ICS for completion of a collection action which has been temporarily suspended.



### Example:



TFRP assessments on certain tax periods were temporarily postponed by Headquarters in response to the COVID-19 pandemic. If all of the required investigative and administrative actions have been performed aside from the assessment on the TFRP the case may be moved from the revenue officers assignment number to the ATAOxx99.

5. A central point in the group may be established for maintaining the paper files associated with these cases, or the paper files may remain with the revenue officer as determined by the group manager.

6. You must conduct quarterly reviews of the cases in these assignment numbers to ensure timely responses to the requested actions. The review should also determine whether the case should remain assigned to the hold file or be reassigned to the revenue officer for action. Document the ICS case history as appropriate.


**1.4.50.10** **(04-01-2025)**

### Assigning Work

01. Assignment of work must align with Policy Statement 1-236, Fairness and Integrity in Enforcement Selection. Adherence to the principles in this policy statement ensures the IRS is meeting its commitment in the IRS Mission Statement by enforcing the tax law with integrity and fairness to all. An important component of fairness and integrity in enforcement selection includes the assignment of work by the group manager. The purpose of this subsection is to provide a framework for the assignment of work to ensure case assignments are free from personal bias. Case assignment decisions should also align with the program goals and objectives of Field Collection to include IMF and BMF investigations and high-priority assignments. Assignments should include a mix of delinquent return (Del Ret) and balance due (Bal Due) modules.

02. Managers are to assign cases to revenue officers in their group from cases in the ICS group manager hold file (GM hold file), or from the queue using _GM Case Assignment_ in ENTITY. The GM hold file in ICS receives cases which by-pass the queue and are directly assigned to Field Collection, and case transfers from other groups or functions such as the Automated Collection Service (ACS). Group managers may also use the GM hold file to maintain a departing revenue officer’s inventory which cannot be returned to the queue, or used to accept assignments for an initiative from Headquarters. _GM Case Assignment_ in ENTITY displays cases available for assignment. When you select a revenue officer, the available cases are displayed in descending order with the highest priority level cases displayed first.



    ### Note:



    The ICS group manager’s hold file _may_ contain cases which do not meet mandatory assignment criteria or represent high priority work. Review these cases and make an assignment determination. Cases not meeting one of these criteria may be moved to the queue if in your professional judgement, higher priority inventory is available for assignment. Some cases in the group manager’s hold file are also displayed in the GM Case Assignment section of ENTITY- as all available IDRS inventory for assignment is displayed for selection in GM Case Assignment.

03. When you assign cases from the queue to revenue officers in your group, you must use _GM Case Assignment_ in the ENTITY case management system. Unless otherwise authorized by headquarters, do not request assignment of cases from the queue to your GM hold file in ICS because cases begin to age when they are assigned whether the assignment is to the GM hold file or a revenue officer. Also, ENTITY updates the case priority levels each week, therefore, cases previously assigned to the GM hold file may not represent the highest priority level of cases available for assignment. Additionally, case assignment data from cases assigned using _GM Case Assignment_ in ENTITY rolls-up to the _GM Case Assignment Report._ The _GM Case Assignment Report_ and ENTITY MIS Business Indicators Report are reports used by field compliance managers (FCMs) as an internal control mechanism to ensure inventory assignment guidance is adhered to. FCMs should generate these and other inventory reports including _Priority Level Status Report_ on a quarterly basis for each group in their territory to evaluate and address instances where assigned inventory patterns deviate from guidance on assignment of priority inventory. Standard case assignments should be high-priority accounts unless assignments of lower priority cases are justified (e.g., related entities, TFRP, geographic considerations, trainee development needs, etc.). Generally, it is inappropriate to assign medium or low priority accounts when there are high priority accounts available for assignment for a given type of case.

04. ENTITY _GM Case Assignment_ has an indicator (IND) field in the _Inventory Assignment_ screen. There are two indicators intended to assist GMs in identifying priority accounts. IMF high-income non-filer accounts contain a "HINF" designation in the indicator field. The indicator "941" identifies employment tax accounts containing multiple balance due Form 941 periods in a current look-back timeframe. These indicators should be used by managers to identify and assign high priority accounts consistent with the objectives and priorities of Field Collection.

05. Collection inventory is divided into three major categories; mandatory, high priority cases and medium to low priority cases. Cases are assigned from the queue using ENTITY "GM Case Assignment." In general, first assign mandatory assignments in your group manager’s hold file and priority level 99 cases from the queue. Next, evaluate high priority cases in the group manager’s hold file and high priority cases in the queue for assignment. The queue inventory is stacked up in priority/ alpha order with the highest priority cases being presented for assignment first. In general, case assignment requests should start with the highest priority IMF or BMF available. Finally, evaluate remaining inventory in the queue and the group manager’s hold file for assignment.

06. Mandatory Assignment Cases in the ICS GM hold file and the Queue. Cases meeting mandatory assignment criteria in the Integrated Collection System (ICS) group manager’s hold file and the queue should be assigned prior to assigning other inventory. Mandatory assignment cases include:



    1. Mandatory FTD Alerts. FTD Alerts are generally received quarterly in the ICS group manager’s hold file. Plan for the arrival of FTD Alerts during the third month of each quarter. Inventories should be at a level that will allow for immediate assignment of these mandatory FTD Alerts without exceeding revenue officer inventory levels that you have determined is appropriate; however, in no circumstances should the assignment date exceed seven calendar days from the date the alert arrives in the group hold file.

    2. Mandatory Other Investigations. Certain Other Investigations (OIs) are mandatory and need to be assigned to the next available revenue officer. See IRM 5.1.8.6 , Mandatory Assignments, for additional information. Other Investigations initiated by CEASO that cannot be resolved without field actions are considered mandatory. Examples include restitution based assessments, redemption investigations and TFRP investigations. Upon receipt of an OI from Insolvency or OIC to investigate potential trust fund recovery penalty (TFRP) assessments, ensure that the case is created in the Automated Trust Fund Recovery (ATFR) program at the time the OI is assigned to a revenue officer. Upon receipt of an Appeals Referral Investigation (ARI), refer to IRM 5.1.9.3.8.2, Appeals Referral Investigation, for further information.

    3. Mandatory Accelerated Case in the ICS GM hold file and the Queue. Assignments should be made from the group queue using the _GM Case Assignment_ menu in ENTITY. Decision analytics have been implemented to more effectively route cases. ENTITY first identifies and presents accelerated cases for assignment. These cases are identified as Mandatory Accelerated Cases (priority 99) in the _GM Case Assignment_ view in ENTITY and should be assigned expeditiously to any grade appropriate revenue officer in the group before assigning other cases in the queue. Additional clarification can be found in IRM 5.3.1.3, Field Collection Case Assignment and Workload Management.



       ### Note:



       Many cases are routed to the ICS GM hold file, but not all of them are considered "mandatory assignments." Review each cases in the GM hold file and determine if it meets mandatory assignment criteria and assign as appropriate. If the case does not meet mandatory assignment criteria and higher priority inventory is available for assignment, consider transferring the case to the queue. Refer to IRM 5.1.20.3.3, Collection Inventory-Cases that Cannot be Moved to the Queue.

    4. IRS Employee Accounts. Accounts on IRS employees bypass the queue and are assigned to the ICS GM Hold File. These cases should be assigned expeditiously to any grade appropriate revenue officer in the group.

    5. Compliance Initiative Project (CIP) referrals. CIPs are any activities involving contact with specific taxpayers and collection of taxpayer data within a group or segment, using either internal or external data to identify potential areas of non-compliance within the group or segment, for the purpose of correcting the non-compliance. CIPs are initiated and approved at the headquarters level. A CIP must be approved before compliance contacts are made. For Field Collection, a proposed CIP is approved by the Director, Collection Inventory Delivery & Selection with the concurrence of Planning and Performance Analysis. When you receive a referral from an approved CIP, create a CIP for assignment. The CIP should be identified with the approved program name by using the **Maintain Program Names**option under the **Entity Detail**tab on the ICS case summary screen


07. High Priority cases in the ICS GM hold file, the Queue and other statuses. The group manager should evaluate high priority cases in _both_ the ICS group manager’s hold file and the queue for assignment. To decrease cycle time, do not keep cases in the ICS GM hold file(AOTOxx00) more than 45 days after receipt. When you must keep a case in the group manager’s hold file for more than 45 days, document the case history to show the reason.



    1. Related entities. Assign related taxpayer entities to the same RO as appropriate. Due to the change in treatment of limited liability companies (LLCs) after 2009, you may wish to treat certain LLCs as related entities for assignment purposes. In general, assign taxpayer cases related to a present assignment to the same RO. See _IRM 1.4.50.10.1_ , Case Grade, for case grade considerations.

    2. Taxpayer needs contact. Cases in the ICS GM hold file with a priority level 99-108 combined with sub code 601-604 must be promptly assigned to a revenue officer _unless_ it is evident that the transfer or sub-code is erroneous. See _IRM 1.4.50.9.1_ , Group Designation Hold File, for additional guidance. Large dollar accounts containing a sub-code of 604 must also be evaluated for assignment. Due to the increased authority levels for ACS, there may be instances where cases transferred from ACS to Field Collection meet the current threshold for priority level 99, requiring mandatory assignment.



       ### Note:



       Review AMS history and identify if the taxpayer needs prompt contact, such as an expedited passport decertification case. If so, GM should assign case and request the RO to work the case promptly.

    3. High priority cases in the queue. High priority cases (levels 101-108) should be evaluated for assignment in conjunction with cases in the ICS GM hold file to determine the next best cases for assignment. See additional information below regarding case priority level.

    4. Cases that cannot be moved to the queue. Cases in the ICS GM hold file which meet the criteria in IRM 5.1.20.3.3, Cases that Cannot Be Moved to the Queue, generally must be assigned.

    5. TFRP Assessments. Absent extenuating circumstances, promptly assign related TFRP assignments to the originating revenue officer unless the TFRP account has been processed as pre-assessed IA, pre-assessed CNC or is in status 63 and is associated as with a IBTF IA.


### Note:

It is appropriate to assign TFRP assessments outside the revenue officer’s geographic area to ensure continuity of collection. If personal contact was established with the taxpayer (even by telephone) to conduct a Form 4180 interview and to secure financial information as required by IRM 5.7.5.2, Collectibility Determinations, the RO can continue to work the case if it can quickly and easily be resolved; or if field contact will be required to resolve the case, the revenue officer can either issue an ICS Other Investigation (OI) or transfer the case.

08. ENTITY displays cases in the Collection queue. The inventory is prioritized by employing scoring mechanisms and data-driven algorithms so that no one individual can control the enforcement selection decision-making processes.

09. Cases available to a specific group are based on the zip code assignments of the group. The group’s queue is displayed in the _GM Case Assignment_ option of ENTITY. All cases presented in ENTITY are assigned a priority level, (see _IRM 1.4.50.8.4_ , Case Priority Level). The case priority scoring criteria were developed with an emphasis on recent business trust fund taxpayers and other selected criteria. Cases within each the priority, high, medium and low are assigned a unique “priority level” (e.g. 101, 103, 201 etc.) based on the parameters of the case such as the type of tax (IMF or BMF), age of the liability or delinquency, specific selection or project codes and other criteria. Since the priority levels represent different types of cases, it would be erroneous to assign all of the available inventory with a particular priority level before considering other high priority cases for assignment. However, the queue inventory is stacked up in priority-alpha order with the highest priority cases being presented for assignment first. Most case assignment requests should start with the highest priority cases for the type of case to be assigned. These priority levels enable the group manager to assign an appropriate mix of case (IMF/BMF, Del Ret/ Bal Due) as determined by Field Collection in order to achieve the organizational goals of the IRS.



    ### Example:



    A manager may select a large dollar IMF case from priority level 103 while there are BMF cases available in priority level 101 in order to achieve an appropriate mix of cases for the employee.

10. In addition to priority level, each case is subject to further analysis which assigns one of five predictive values (a through e). The predictive values will help the group manager identify the most predicted productive work within each priority level.

11. The selection of cases from inventory should represent highest priority level (for a particular type of case) combined with the highest predictive value. You are responsible for ensuring that cases are assigned at the proper grade level based on the all indicators of case difficulty. If two or more cases have the same priority level, but differing predictive values and you are limited by the number of cases to be assigned; the case with the highest predictive value should be assigned first.



    ### Example:



    Case A is assigned a priority level of 101 with a predictive value of "d" . Case B is assigned a priority level of 101 with a predictive value of "b" . In this example, case B should be assigned prior to case A.





    ### Note:



    It is not appropriate to assign a lower priority level case with a high predictive value over a higher priority level case with a low predictive value based solely on the comparative predictive values assuming two cases are of the same type.





    ### Example:



    It is not appropriate to assign a case with a priority level of "201" and predictive value of "a" in preference to a case with a priority level "101" and predictive value of "d" **unless** the lower priority case meets mandatory assignment criteria or is a related taxpayer assignment.

12. Professional judgment plays a limited role in case selection. Examples of exercising professional judgment in cases selection include:



    1. Assignment of cases within the geographic territory of the revenue officer, but outside the commuting area of the revenue officer. When assigning mandatory assignment or high priority cases in these areas, it is appropriate to assign additional cases in that area or en route to that area in an effort to maximize the resources of the IRS. In these instances, these case assignments should represent the highest priority cases available for assignment.

    2. Cases which present specific criteria may be assigned to address the developmental needs of the revenue officer. If selecting cases from the queue, the cases selected should be the highest priority available.



       ### Note:



       This does not preclude the reassignment of a case with a specific criteria from one revenue officer to another for developmental purposes.

    3. The current workload of the revenue officer may be taken into consideration when assigning work. However, case assignments in these situations should also represent the highest priority level of available inventory. Workload adjustments to a revenue officer’s inventory should generally be accommodated by reducing the revenue officer’s inventory _within_ the targeted inventory level (see _IRM 1.4.50.10.2_ , Maintaining Targeted Inventories), rather than assigning lower priority work.

    4. Use professional judgement when selecting cases from the queue for assignment when one or more modules has less than six months remaining on the collection statute expiration date (CSED). Normally, modules with less than six months remaining on the CSED will not be assigned. Refer to IRM 5.1.19.5, Imminent CSEDs ,for additional information.



       ### Note:



       High priority cases, High Income High Wealth, High Income Non-filers and potentially egregious in-business trust fund taxpayers (repeaters/pyramiders) with balance due or delinquent return periods within the past two years should normally be assigned despite an imminent CSED.





       ### Note:



       Potentially egregious in-business trust fund taxpayers (repeaters/pyramiders) with balance due or delinquent return periods within the past two years should normally be assigned despite an imminent CSED.

    5. Discretionary OIs may be assigned based on priority level, see IRM 5.1.8.7 , Discretionary Assignments. If the priority level of the OI is below the priority level of available inventory for assignment and the OI cannot be assigned to a revenue officer, the case may be returned to the originator by the due date of the OI. When returning an OI, you will include an explanation in the remarks section stating why the OI cannot be assigned.

    6. The ICS GM hold file _may_ contain cases which do not meet mandatory assignment criteria or represent high priority work. Review these cases and make an assignment determination. Cases not meeting one of these criteria may be moved to the queue if in your professional judgement, higher priority inventory is available for assignment.

    7. Professional judgement may also include the timing of assignment of inventory. The group manager should evaluate mandatory assignment and high priority inventory in the ICS GM hold file in conjunction with similar inventory in the queue. There may be instances where it is appropriate to assign other inventory (i.e. mandatory assignment, high priority, related assignment) from the queue prior to cases in the ICS GM hold file, keeping in mind the cases in the ICS GM hold file should generally be assigned within 45 days of receipt.


13. You may adjust future inventory assignments to ROs in your group using ICS. Select the **Assignment Table** from the **Parameter Tables** menu under the **Administrative Actions** tab at the ICS main screen. Under this action, select **Specific Zip Code** to view the current assignment rules for zip codes aligned to your group. This will align cases available for assignment by zip code and alpha split in the ENTITY GM Case Assignment application. Additionally, these group case assignment rules will be displayed for cases in the ICS GM hold file when you select the **Include Assignment Number** radio button within the **Assign/Reassign** option in the **Assignments** menu under the **Admin Actions** tab. You may find MapInfo services helpful in determining optimal alignment **within** your group.

14. Revisions to zip code assignments to your group should be coordinated with your (FCM). With your FCM’s approval, forward a completed _Mapinfo Project Request Form_ to MapInfo to schedule a work session. Impacted managers should be included in the work session and changes to the assignment rules will be input by the Territory’s ICS/ENTITY Quality Analyst, (IQA). MapInfo can help evaluate the realignment of zip codes between Areas, across territories and groups or within a territory or a group.

15. Review ENTITY reports monthly to ensure ROs are not working over 25 percent direct time above grade. This can be accomplished by reviewing the Time Report, "Above Grade Direct Time Report." You may retain cases in inventory that do not match the RO's grade, examples include:



    1. Cases assigned to a revenue officer below their grade level (e.g., a TFRP assessment originating from an in-business case currently in inventory).

    2. There would be an unacceptable delay in working the cases if you reassigned them to other revenue officers.

    3. There is a need to maintain continuity of contact with the taxpayer.

    4. The revenue officer is in a one-person post of duty.

    5. Transfer of the case would cause unreasonable travel.

    6. The revenue officer needs or requests a higher-level case for developmental purposes.

    7. Per the National Agreement , Article 16, a revenue officer may spend up to 25 percent of their **direct time** during any four month period, working higher graded cases for developmental purposes.


### Caution:

If you allow revenue officers to work higher graded cases it is essential that you track the percentage of direct time spent on higher graded work to ensure the 25 percent threshold is not being exceeded. _Employees who exceed the 25 percent level for the preceding four month period may be entitled to a temporary promotion._

16. Resources:



    - IRM 5.1.7.7, Federal, State and Local Government Agencies

    - IRM 5.1.8.8.1.3, Unassessable Erroneous Refunds Recovery Procedures

    - IRM 5.1.21, Collecting From Limited Liability Companies (LLCs)

    - IRM 5.7.1.4, Receipt of FTD Alerts


**1.4.50.10.1** **(10-20-2023)**

#### Case Grade

1. Balance Due and Delinquent Return investigations are issued with a case grade of GS 11, 12, or 13. These grade levels reflect the anticipated level of difficulty of the case. The Inventory Delivery System (IDS) is the primary system used to determine the case grade. Cases not graded by IDS will continue to receive their grade from RWMS. IRM _Exhibit 1.4.50-1_ reflects the criteria used by the Resources and Workload Management System (RWMS) to determine the case difficulty level.

2. When manual identification of cases is necessary use the Revenue Officer Case Assignment Guide, in _Exhibit 1.4.50-1_.

3. You are responsible for reviewing and maintaining the correct case grade. Case grade levels can be either increased or decreased. There are systemic processes in place to predict the grade level of a case. If, based on receipt of additional information or change in case circumstances, the predicted case grade does not appear to be accurate, you may re-grade the case. A list of criteria that should be considered in conducting case grade analysis is shown in _Exhibit 1.4.50-1_, Revenue Officer Case Assignment Guide. This can be done at any time: upon receipt, upon assignment to RO or during case reviews. Revenue officers should be encouraged to bring mis-graded cases to your attention. See _IRM 1.4.50.10.2_ , Maintaining Targeted Inventories.

4. Document the factors used in determining a new case grade in the ICS history. The ICS pick list meets this documentation requirement. The following choices, if selected from the drop down menu, are written to the case history; Nature of Entity, Range of Case Issues, Personal Contacts, and Impact of Enforcement Action. If additional explanation is needed you should write a narrative history as well. See ICS User Guide, Chapter 23, Case Maintenance for guidance on updating case grade levels for more information. For a link to the ICS User Guide, see _IRM 1.4.50.1.8_, Related Resources.

5. You will not normally change the grade of a case unless it meets at least three of the four factors at the lower or higher level. Document in the case history the reason for not using at least three of the four factors when applicable.

6. When you determine that the difficulty level of a case has changed, adjust the grade level by using the ICS Change Grade Level process. This will change the case grade level on ICS and upload the new determined grade level (DGL) to IDRS.

7. You may need to consider a reassignment of the case if a grade level change is made. See _IRM 1.4.50.10.2_.

8. In general, assign taxpayer cases related to a present assignment to the same revenue officer. If the new case is a lower grade than the original, re-grade it only if it meets the Revenue Officer Case Assignment Guide (CAG) criteria independent of the original assignment.



### Note:



Though this may result in an appearance that the RO's inventory is **under-graded**, the value of ensuring cross-compliance and effective use of RO time should outweigh this concern. See _Exhibit 1.4.50-1_.

9. If you downgrade a case with a systemically assigned grade level, notify the employee via e-mail of the reasons for downgrading the case.


**1.4.50.10.2** **(04-01-2025)**

#### Maintaining Targeted Inventories

01. You are responsible for monitoring inventory levels to ensure each revenue officer has an appropriate number of cases within the established ranges that can be resolved most effectively and efficiently based on the employee’s grade level, experience, and expertise. The guidelines below provide flexibility for group managers to adjust inventories as needed. You must monitor the effectiveness of each revenue officer to determine the optimal inventory level based on the individual facts and circumstances of each RO. Factors to consider include, but are not limited to: developmental needs, performance issues, extensive geographic territory, and complex casework.

02. Absent indications to the contrary, consider limiting new assignments to five per work week. Certain circumstances could necessitate assigning more than five cases, including, but not limited to:



    - Field RO is assigned from one group to another without their full inventory

    - Field RO returns from a temporary assignment, such as training or a detail, without an inventory

    - Field RO had previously been relieved of all or part of their inventory and needs additional inventory

    - Unforeseen circumstances in which cases must be assigned/reassigned, such as: extended absence of the RO, the need to avoid missing statute deadlines or the RO requests additional cases be assigned

    - The RO requests additional cases be assigned

    - The assignment of more than five cases per week to an RO to align with the RO’s rate of case dispositions

    - Assignment of inventory to RO trainees, including initial inventory and on-going assignments during phases of on-the-job training in order to raise the trainee’s inventory.


### Note:

Excessive simultaneous assignments could adversely impact the revenue officer’s ability to make timely initial contact and take appropriate and timely follow up actions. Regardless of what inventory level you have determined to be appropriate, avoid assigning a large number of cases at one time whenever possible.

03. The inventory levels for trainees are linked to milestones during the on-the-job training (OJT) phases of training. Case assignments to RO trainees should be timed to be available during the OJT periods of the employee’s training, and should generally be assigned weekly in order to increase the trainee’s inventory incrementally. Assignments should be timed in order to provide cases to the trainee in a manner which allows the employee to perform the pre-contact analysis and make timely initial contacts. The current revision of Document 12922, SB/SE Collection Manager and OJI Recruit Hire Guide contains case assignment guidance and inventory ranges for trainees based on the current revenue officer OJT timeline. Assign a sufficient mix of TDA and TDI investigations to provide trainees with cases where they can demonstrate proficiency in the subjects delivered in classroom training. Standard case assignments should be high priority accounts unless assignment of lower priority cases is justified.

04. You must submit a BEARS request for each trainee in your group. The trainees must be enrolled in the Employee User Portal prior to the BEARS request. Include the first six digits of the trainee’s assignment number in the BEARS request to enable the IQA to create the training record in ICS. Advance contact with the IQA is recommended if you will be submitting BEARS requests for multiple trainees. Each trainee record in ICS must have a coach associated with the record. The coach must have an assignment number in the same group as the trainee. If the coach is from another group, the coach must submit a BEARS request to create an assignment number in the trainee’s group. If a coach has not been assigned at the same time the trainee’s record is created, the trainee’s manager will be designated as the coach. At the end of the employee’s trainee period, the manager must submit an ICS Help Request to remove the trainee position type from the ICS record.

05. When a revenue officer’s position type is designated “trainee,” the employee’s inventory level is not included in the End Of Month Balanced Measures report. Therefore, an adjustment inventory adjustment should not be made for a revenue officer trainee in ENTITY.

06. When additional cases need to be assigned, you should look to the following sources for additional work:



    1. The ICS GM hold file.

    2. The highest level risk cases from the queue.

    3. Other revenue officers.

    4. Other groups (with concurrence from your field compliance manager).


07. The standard inventory ranges of taxpayer cases (a taxpayer case constitutes all accounts/investigations on a single entity) for revenue officers are:




    | **Grade** | **Standard Inventory Range** |
    | :-: | :-: |
    | 13 | 34-50 |
    | 12 | 34-50 |
    | 11 | 53-79 |
    | 09 | 59-69 |
    | 05/07 | 49-59 |

08. Inventory levels for Grade 13 revenue officers will include approximately 60 percent Grade 13 cases and approximately 40 percent cases below the Grade 13 level. Due to the complexity of the Grade 13 case work, the inventory level for a Grade 13 will be kept at or near the bottom of the standard inventory range. See _IRM 1.4.50.10.1_.

09. The standard inventory ranges apply only to revenue officers with case inventories of bal dues, del rets, OIs, FTD Alerts, and CIPs.

10. Standard inventory ranges give you flexibility to consider a variety of circumstances when monitoring individual revenue officer inventories.

11. When a revenue officer’s assigned inventory exceeds the maximum level of the standard inventory range, you should reduce it to a level within the standard range within 10 work days. If you cannot reduce the inventory within 10 days, you must relieve the revenue officer, _in writing,_ of the IRM requirements regarding prompt initial and follow-up contacts until the inventory is within range. Once the inventory level no longer exceeds the maximum level of the standard range, provide written notification to the employee. Maintain such documentation in the affected employee's EPF.



    ### Reminder:



    Encourage your revenue officers to discuss unmanageable inventory problems with you at any time. Collection Consultation sessions provide an appropriate forum for such a discussion.

12. If inventory levels in the group are above the standard inventory range, the following options should be considered:



    1. Reassigning cases to the ICS GM hold file on a temporary basis, preferably no longer than 45 days.

    2. Detailing in additional revenue officers.

    3. Adjusting group boundaries (by zip code).


13. If revenue officers are still above their standard inventory range after using the above measures, you may return cases to the queue unless they are:



    1. Accelerated issuance.

    2. Restricted from moving to the queue (see IRM 5.1.20.3.3, Cases that Cannot be Moved to the Queue).

    3. Have no NFTL determination. If not filed, confirm there is an ICS history notation that explains the reason.

    4. Cases that reflect fewer than 6.5 months (195 days) before the Collection Statute Expiration Date (CSED) expires.

    5. Awaiting pending enforcement action (outstanding levy, summons, Letter 1058, or appeals actions).

    6. In-business trust fund cases.

    7. Trust fund cases with less than one year remaining on the ASED and no trust fund determination made.

    8. Cases with taxpayer contact within the last 6 months (180 days).


**1.4.50.10.2.1** **(04-01-2025)**

##### Inventory Adjustments

1. When appropriate, you may reduce an RO's inventory to a level that is below the bottom of the standard inventory range by using an inventory adjustment. Adjustments that reduce inventory levels below the bottom of the targeted ranges should be addressed in accordance with guidance below.

2. The ENTITY Case Management System (ENTITY) requires managers to select a reason from the pick list when an inventory adjustment is made. Managers should discuss adjustments to inventory during a field compliance manager's employee engagement operational review.

3. An inventory adjustment is a percentage-based adjustment to the standard range. It is based on an evaluation of time spent on activities other than work on assigned cases (direct case time) and normal overhead. Reason codes that may be considered for an inventory adjustment are in the table below:




| ****Reason Codes**** |
| :-: |
| Acting Manager |
| Collateral Duties |
| Detailed Out |
| Disaster Area |
| EEO Counselor |
| EEO Investigator |
| Extended Leave |
| Filing Season Support |
| Group Resource Person |
| Employee Joins/Leaves Group |
| Medical reasons |
| Union Duties |
| On the Job Instructor |
| Part Time |

4. Only make an inventory adjustment when applicable, when the employee is within range an inventory adjustment code in ENTITY is not needed to support that. Do not apply inventory adjustment reason codes in ENTITY to Trainees.

5. When an adjustment to a revenue officer's inventory is warranted because of any of these circumstances, use the projected time expenditure by the revenue officer to determine the appropriate adjustment.



### Example:



You review a GS-12 revenue officer's time over the last six months and determine the employee appropriately spent 25% of their time on collateral assignments. An adjustment of 25% is indicated in this case and the new inventory range for the revenue officer is between 26-38 taxpayer cases.

6. Inventory levels may be re-adjusted as warranted. Perform quarterly reviews of actual time your employees spend on collateral assignments and make adjustments as needed. Adhere to these guidelines when considering any adjustments to revenue officer inventories.



### Note:



You may use "**Joining/Leaving**" as a reason for inventory adjustment if you need to incrementally increase or decrease the inventory level of an RO who is joining or leaving the group. In such cases, the percentage adjustment should be based on the individual circumstances of each RO.

7. Special Compliance Program (SCP) designations are available to ATAT revenue officers when 65% or more of their monthly direct time is charged to ATAT time codes for two consecutive months. The designation should be removed for any employee not meeting the 65% ATAT direct time code rule. Requests for SCP designations are made to the group’s ICS Quality Analyst (IQA). The IQA is responsible for adding or removing the SCP designation for employees in ICS. An employee with an SCP designation will be excluded from the monthly targeted inventory level report.

8. Resources:



   - ENTITY user guide, chapter 6, Employee Management, see _IRM 1.4.50.1.8_, Related Resources for a link to the ENTITY user guide.

   - Exhibit 1.4.50-3, Target Inventory Levels and Inventory Adjustments Q&A.


**1.4.50.10.3** **(04-01-2025)**

#### Reassignment of Departing Revenue Officer Inventory

1. Where inventory will be abandoned for periods of 90 days or more (for example a revenue officer is reassigned, on extended leave, or long term detail) you will consider performing the following actions:



1. Holding assignment of additional work (after confirmation of the revenue officer’s effective date for detail, reassignment, retirement, etc.).

2. Reviewing all inventory with the departing revenue officer, (including cases on the ATFR system) and identifying those cases which can be (1) resolved prior to the RO leaving, (2) returned to the queue (such as new cases, no contact, or other similar types), or (3) reassigned to the remaining revenue officers in the group. The transfer of these cases should be completed within a reasonable period of time, normally within 45 days. When appropriate, re-grade cases based on the post assignment criteria.

3. When remaining inventory cannot be returned to the queue, you must decide how to proceed with disposition/assignment of those cases. RO inventory levels may not be raised above the target range for more than 10 days without relieving the receiving employee of certain time frame constraints. If you decide to raise revenue officer inventory levels above maximum targets to accommodate the remaining inventory, you must then suspend contact and follow up time frames _in writing_ for the revenue officers affected. See _IRM 1.4.50.10.2_ for further explanation. Consider discussing with the field compliance manager other options such as having RO's detailed to the group, re-arrangement of zip code assignments by updating the Assignment Rules Table on ICS, etc.

4. When a revenue officer is reassigned between groups where the inventory remains within the commuting area, the affected group managers should consider retention of the transferring revenue officer’s inventory.

5. After all above actions have been exhausted group managers may consider assigning the cases to their ICS GM hold file (AOTOxx00). If you assign the cases to the ICS GM hold file, you should consider these cases as priority, and take appropriate action (i.e., assign these within the next 45-60 days).


**1.4.50.10.4** **(05-04-2017)**

#### Case Load Rotation

1. Where feasible, revenue officer geographic areas and/or case loads should be rotated every three years. This will give revenue officers additional experience and avoid over-familiarity with taxpayers in a particular geographic area. Rotate between revenue officers of the same grade. Do not change revenue officers’ posts of duty to meet this objective.

2. In large metropolitan areas with multiple groups and/or posts of duty (PODs), it may be possible to rotate case loads by realigning zip codes between groups and/or PODs.


**1.4.50.10.5** **(10-20-2023)**

#### Tax Examiner (TE) Case Assignments

1. Certain cases in Collection Inventory may be assigned to tax examiners (TEs).

2. Assigned cases may be located either within or outside of the area.

3. TEs will not conduct field visits. All casework will be done in the office, using the telephone, mail, and online services. TEs may also use an approved digitized format to receive documents (other than current tax returns) from taxpayers such as e-fax or the Document Upload Tool (DUT). TEs must follow existing guidance on the acceptance of delinquent tax returns containing an image of the taxpayer’s signature(s), see IRM 5.1.11.6, Secured Returns.

4. For specific guidelines on working Collection cases, TEs will refer to procedures found throughout Part 5 of the IRM. TEs should document the ICS history concerning deviations from IRM guidance for ROs. For example: Field visit to view business assets not made due to case assigned to tax examiners.

5. Cases assigned to TEs should meet the following criteria:



   - Grade 11 cases

   - Individual Master File (IMF) with an unpaid balance of assessments (UBA) below $25,000

   - Non-trust fund Business Master File (BMF) cases with an UBA below $25,000

   - BMF cases involving a sole proprietorship with an UBA below $25,000

   - Stand alone IMF DEL RETS and non-trust fund BMF DEL RETS

   - Stand alone BMF DEL RETS on sole proprietorships

   - Cases with all priority levels



     ### Caution:



     Do not assign to TEs cases involving trust fund recovery penalties (TFRPs), limited liability companies (LLCs), or those with a PDT or CAU indicator.


6. All cases assigned to TEs should be sub coded as 655 (DEL RET) or 656 (BAL DUE) on the Integrated Collection System (ICS).


**1.4.50.10.5.1** **(10-20-2023)**

##### Cases Requiring Managerial Review Prior to Transfer to the Queue

1. Field Collection corporate inventory assigned to tax examiners may be returned to the queue with managerial approval.

2. Depending on the facts of the case and the extent of taxpayer contact, the group manager covering the taxpayer’s location may be consulted to determine if the group manager wants the case assigned to a revenue officer.

3. GMs should document the ICS case history concerning managerial review/approval of return to queue.

4. The following cases may be returned to the queue:



   - Business Master File (BMF) cases that cannot be fully resolved **and** have no indications of continuing operations or employees.



     ### Note:



     If the TE has confirmed via telephone call or correspondence that the taxpayer continues to operate and has employees, and an IBTF Express installment has not been granted, the case should be transferred to the group manager covering the taxpayer’s location.

   - Collection statute expiration date (CSED) and assessment statute expiration date (ASED) cases with an imminent statute (i.e. expiring within twelve months).



     ### Note:



     Cases with less than six months remaining on the CSED cannot be transferred to the queue.

   - Seizures - any case requiring a seizure.

   - Summons - any case where a summons would be anticipated.

   - Any complex case where the group manager agrees that the resolution is outside the scope of the TE’s abilities.


**1.4.50.10.6** **(10-20-2023)**

#### **Disaster Issues and Replacement Inventory**

1. This subsection outlines inventory management issues arising from federally declared disasters or other emergency declarations under the Robert T. Stafford Act. These events pose challenges to the IRS in terms of protecting the rights of impacted taxpayers and maintaining continuity of Field Collection operations. The term "disaster" will be used generically in this section to cover all applicable federal declarations under the Robert T. Stafford Act. Procedures for working cases with disaster indicators is located at IRM 5.1.12.2, Collection Relief for Taxpayers Impacted by Disaster.


**1.4.50.10.6.1** **(08-21-2018)**

##### Systemic Disaster Freeze Account Indicators

1. The disaster program uses IDRS to ensure prescribed relief is provided to taxpayers within the identified zip codes in a disaster area.

2. Disaster freeze code indicators are posted on IDRS to taxpayer accounts in the identified zip codes via IT systemic programming, computer transaction code (TC) 971. TC 971, action code 078 will post a -O freeze to the taxpayer’s account and a TC 971 action code 688 will post a -S freeze to the taxpayer’s account.



1. The presence of a -O freeze allows the IRS to provide special processing related to filing, payment or interest relief under IRC 7805A and restricts taxpayer contact unless exigent circumstances apply, see IRM 5.1.12.2, Cases Requiring Special Handling-Disaster Assistance and Emergency Relief.

2. The presence of a -S freeze gives the IRS the flexibility to grant filing and paying relief without suspending compliance activities.


3. ICS will flag a taxpayer account containing a disaster freeze with a red box containing the abbreviation “DIS” on the ICS case summary screen whenever a disaster code (-O or -S) is posted to IDRS and extracted to ICS.


**1.4.50.10.6.2** **(08-21-2018)**

##### -O Freeze Inventory

1. When the entire or significant taxpayer population located in the geographic assignment area of a group, territory or area is designated with a -O freeze, the manager(s) must take steps to maintain continuity of Field Collection operations.

2. Master File and IDRS programing limit the transfer of cases when a -O freeze is present. Cases containing a -O freeze cannot be transferred between functions.



### Example:



A case containing a -O freeze cannot be transferred from Field Collection (status 26) to the Queue (status 24).

3. Cases containing a -O freeze may be transferred within the group.



### Example:



Cases may be transferred between revenue officers in the same group or from a revenue officer to the ICS GM hold file if appropriate.

4. Generally, cases assigned to revenue officers containing an -O freeze should not be transferred to the ICS GM hold file. Revenue officers will be unable to charge time to cases which have been transferred to the ICS GM hold file. In addition, when the cases are reassigned to a revenue officer at the end of the disaster period, the case will receive a new RO assignment date, which will affect the accuracy of various management reports.

5. It may be appropriate to return cases to the queue after the expiration of the disaster period which previously contained a -O freeze if there was no prior taxpayer contact and higher priority inventory is available for assignment in the queue or ICS GM hold file.

6. In cases where a group’s geographic area is impacted by a disaster to the extent that most or all of the taxpayer accounts currently assigned or available for assignment in the group’s queue have received a -O freeze, it may be necessary for the group manager to request _replacement inventory_.


**1.4.50.10.6.3** **(08-21-2018)**

##### Replacement Inventory

1. Replacement inventory is defined as inventory meeting criteria established by headquarters, to be assigned to field collection groups affected by a disaster in order to maintain continuity of Field Collection operations. Replacement inventory is located outside the group’s assignment parameter table. These cases are generally worked remotely without travel to the taxpayer’s location.

2. Replacement inventory is obtained from a "host" location. A host location is one which is identified as having inventory meeting the headquarter's criteria for replacement inventory which can be assigned to a group affected by a disaster. A host location can be located in the same area as the group needing replacement inventory, or the host location may be located in another area.

3. Groups assigned replacement inventory generally will not send courtesy investigations (OIs), including those for routine asset checks. In addition, do not propose transfers of cases to the host location or another location based solely on the taxpayer’s address.

4. Replacement inventory cases must be identified since the investigative requirements for replacement inventory deviate from the procedures for general inventory assignments. This identification is accomplished by updating the ICS sub code to 899 _and_ by documenting the ICS case history "Disaster replacement inventory."


**1.4.50.10.6.4** **(04-01-2025)**

##### Requesting and Assignment of Replacement Inventory

1. Group managers will initiate a request for replacement inventory by advising the field compliance manager that most or all of the cases currently assigned or available for assignment in the groups parameter table contain a -O freeze designation. The field compliance manager will notify the area director’s staff of the inventory needs who will in turn, contact the Director, Field Collection’s staff. The Director, Field Collection’s staff will coordinate requests with Collection Inventory Delivery & Selection (CIDS)-Collection Case Delivery (CCD).

2. Headquarters will establish the criteria for replacement inventory and will coordinate with CIDS-CCD to deliver the inventory to the group. Group managers shall not attempt to assign replacement Inventory other than the cases provided by CIDS/CCD.

3. Identification and assignment of replacement inventory is accomplished through a bulk Generalized IDRS Interface (GII) process. The GM will need to estimate the replacement inventory needs of the group over the anticipated term of the disaster period. Historically, the inventory needs have averaged 20 cases per employee for a three-month period. Subsequent inventory requests can me made if needed, however, the processes involved cannot accommodate weekly inventory requests.

4. The replacement inventory will be delivered to the group manager’s ICS GM hold file. Group managers will assign replacement inventory to revenue officers based on the inventory needs of each RO.

5. In order to provide employees with sufficient inventory which can be worked, assignment of replacement inventory is not limited to the recommendation in _IRM 1.4.50.10.2_, Maintaining Targeted Inventories, of five cases per week.


**1.4.50.10.6.5** **(08-21-2018)**

##### Impact of Replacement Inventory on Revenue Officer Inventory Levels and Employee Observations

1. Depending on how the group’s -O freeze inventory is assigned during the disaster period, revenue officer inventories may be above or below standard inventory ranges when the replacement inventory is assigned.

2. In order to identify revenue officers impacted by the assignment of replacement inventory for end-of-month reporting, GMs should input an inventory adjustment reason in the ENTITY case management system for each employee assigned replacement inventory. This is accomplished by selecting the “DARE” option located in the inventory adjustment reason menu located in the inventory adjustment menu for each employee.

3. In situations where a revenue officer’s assigned inventory exceeds the maximum standard inventory level due to the assignment of replacement inventory for a period exceeding 10 work days, the group manager must relieve the revenue officer _in writing_ of the IRM requirements regarding timely initial contact and timely follow-up actions until the employee’s inventory is within the standard inventory range of the grade of the employee, see _IRM 1.4.50.10.2_, Maintaining Targeted Inventories.

4. In situations the group manager must conduct a taxpayer contact observation during the disaster period and there are no cases within the revenue officers geographic assignment area which do not contain a -O freeze, it is appropriate to perform an observation on a replacement inventory case by observing a telephonic contact between the revenue officer and the taxpayer or the taxpayer’s representative, see _IRM 1.4.50.5.2.3.1_, Telephonic Observations. When you are observing a telephonic contact, advise the taxpayer or the taxpayer’s representative of your observation at the beginning of the contact.


**1.4.50.10.6.6** **(08-21-2018)**

##### Disposition of Replacement Inventory at the End of the Disaster Period

1. At the end of the disaster period, replacement inventory cases where there has been no contact from the taxpayer should be returned to the queue. This includes cases located in the ICS GM hold file which were not assigned to an employee _and_ cases which were assigned to an employee where there has been no response from the employee’s contact attempts.

2. Group managers must not transfer replacement inventory via ICS to another group affected by a disaster or significant emergency. Groups needing replacement inventory should follow the guidance set fourth above at _IRM 1.4.50.10.6.4_, Requesting and Assignment of Replacement Inventory.

3. Group managers must not transfer replacement inventory to the host location via ICS an the end of the disaster period.

4. Cases where the unpaid balance of assessments exceeds the dollar thresholds established by headquarter for replacement inventory due to an additional assessment, the group manager will discuss the case with the employee. The case may be returned to the queue if no contact attempt has been made, or if the there has been no response from the employee’s contact attempt.


**1.4.50.10.7** **(04-01-2025)**

#### Revenue Officer Compliance Sweeps

1. A revenue officer compliance sweep (ROCS) is an assignment of work strategy utilized by Field Collection to support compliance initiatives. The purpose of a ROCS is to address an increase in unassigned high priority inventory aligned to a compliance initiative (e.g. egregious employment tax cases, high income non-filers or speciality program) in a given area or program due to current field compliance staffing or to support a compliance initiative.

2. Recommendations for ROCS to address high-priority inventory assignments are generally initiated at the Territory or Area level. All ROCS must be approved by the Director, Field Collection. ROCS recommendation/approval templates may be obtained from your field compliance manager.


**1.4.50.10.7.1** **(10-20-2023)**

##### Revenue Officer Compliance Sweep Locations and Participants

1. As a group manager, you may be notified if zip-codes aligned to your group are to be included in a ROCS. You may be asked to solicit revenue officers in your group to participate in a ROCS on cases not aligned to your group.

2. Revenue officers’ participation in a ROCS is subject to group manager approval.


**1.4.50.10.7.2** **(10-20-2023)**

##### Revenue Officer Compliance Sweep Inventory Assignment

1. Inventory for a ROCS is identified at the Territory, Area or Headquarters level using ENTITY queries or other means. The cases for assignment should be "stacked" in descending priority/alpha order, similar to the manner in which cases are presented in GM Case Assignment.

2. Cases selected for assignment in a ROCS should be selected in descending order from starting with the highest priority level and predictive value for a particular type of case, see IRM 1.4.50.10(8) for additional guidance on case selection.

3. Cases approved for assignment for a ROCS may be assigned by GMs, FCMs, Area Analysts or through requests submitted to Collection Case Processing.

4. Assign cases directly to the participating revenue officers or the GM hold file for the location of the ROCS.


**1.4.50.10.8** **(04-01-2025)**

#### Assignment of Abusive Tax Avoidance Transactions (ATAT) Inventory

1. An abusive tax avoidance transaction (ATAT) includes the organization or sale of any plan or arrangement promoting false or fraudulent tax statements, gross valuation misstatements, aiding or assisting in the preparation or presentation of a return or other document to obtain tax benefits not allowed by law, and actions to impede the proper administration of Internal Revenue laws. This sub-section addresses the identification and assignment of inventory to ATAT revenue officers

2. Field Collection plays a significant role in the abusive tax avoidance transactions (ATAT) program. Each of the seven Field Collection Areas has an embedded ATAT Field Collection program.

3. The three primary sources of inventory for ATAT employees are balance due investigations resulting from Examination assessments of abusive ATAT promotion cases, approved settlement initiatives related to certain abusive transactions and erroneous refund recovery where an assessment is made to reverse false withholding or refundable credits.

4. Casework is systemically directed to ATAT by the Inventory Delivery System (IDS). Cases are routed to ICS, which directs the cases to the ATAT designated hold file established for each Area’s ATAT program when the case balance exceeds a required threshold amount. These cases include:



   - Cases that contain an ATAT project code, certain civil penalties cases,

   - MFT 52, non-masterfile MFT 53; gift tax cases MFT 51, non-masterfile MFT 54 and Forms 706-GS(D) and 706-GS(T) with MFTs 77 & 78.


5. Zip codes are not used for ATAT case routing and therefore ATAT ROs should not have any zip codes assigned to them in the ICS parameter tables. If you find an ATAT revenue officer in your group is assigned zip codes, you must reassign those zip codes to a general program revenue officer in your group where possible, or work with your ICS Quality Analyst (IQA) to reassign the zip codes to the appropriate general program group.

6. Additional cases directed to ATAT include:



   - Complex probation and restitution cases where Advisory will issue an Other Investigation (OI) to an ATAT collection group when the cases meets the criteria listed in IRM 5.1.5.16.2, Issuing Other Investigations to Abusive Tax Avoidance Transaction Collection Groups.

   - Pre-assessment preparer/promoter investigations.


**1.4.50.10.8.1** **(04-01-2025)**

##### Collection ATAT Coordinator Responsibilities

1. Each Area has at least one ATAT manager who also serves in the role of ATAT Coordinator. The primary responsibilities of the ATAT Coordinator is to serve as a point of contact with other functions, ensure ATAT cases from the Examination Division are assigned to Collection, assist in the identification of ATAT inventory. The responsibilities of the ATAT Coordinator include:



1. Act as a central point of contact for Collection and Examination employees for ATAT issues.

2. Serve as a liaison between other functions including Examination, Criminal Investigation, General Program Collection, Collection Policy ATAT Analysts and Advisory.

3. Coordinate the assignment of ATAT Examination cases to Collection.

4. Coordinate collection support for examinations involving ATAT issues.

5. Ensure the appropriate routing and assignment of ATAT cases returned by Appeals.

6. Serve as a subject matter expert on emerging trends in ATAT issues, collaborating with Collection Policy ATAT analysts and supporting ATAT training.


2. Collection Policy provides ATAT coordinators with a list of ATAT cases in the queue each month. ATAT coordinators should forward this list to ATAT managers to provide an additional source of inventory available for assignment. These cases are identified using ENTITY queries. These queries are national public queries housed under the _Module Management_ View of ENTITY and include:



   - ATAT All Codes $168K + High P, generates a report of high priority level cases with ATAT special project or civil penalty codes where the unpaid balance of assessment for the case exceeds an inflation-indexed dollar amount.

   - ATAT ESTATE & GIFT NATIONAL, lists cases with MFTs of 51, 52, 53, 77, and 78.

   - ATAT PROJECT CODES, this query displays all cases that include at least one module with an ATAT special project code. This query is used to identify balance due modules resulting from Examination ATAT assessments.

   - ATAT CIVIL PENALTY CODES, this query displays all cases with at least one module containing the following civil penalty codes; 565, 594, 595, 596, 597, 598, 628, 631, 634, 636, 648, 650, 666, and 687.

   - ATAT All Codes (Civil & Spec), lists all ATAT special project code and civil penalty code cases in one national public query.


3. The ATAT coordinator is the central point of contact for brokering ATAT cases within Field Collection. Although all revenue officers may work cases involving ATAT schemes, a general program Field Collection group manager may initiate a request to transfer ATAT cases assigned to their group to an ATAT group. This process is limited to cases assigned to a general program group which contain an ATAT special project code, ATAT civil penalty or involves a taxpayer who has employed the use of abusive trusts. Cases assigned to general program revenue officers involving special condition notices of federal tax liens, suit recommendations and seizures generally should not be referred to the ATAT coordinator.

4. If you are serving as the ATAT coordinator where a decision has been made at the Area level to have all systemically routed inventory to your ATAT designated hold file, you are responsible for reviewing this hold file on a bi-weekly basis. Transfer the ATAT cases to their respective ATAT designated hold file for the ATAT group based on the location of the taxpayer.


**1.4.50.10.8.2** **(04-01-2025)**

##### ATAT Group Manager Responsibilities

1. Conduct bi-weekly reviews of the ATAT designated hold file.

2. Confirm ATAT cases are properly identified with the appropriate ATAT sub-code in ICS at the time the cases are assigned, and verify Special Compliance Program (SPC) designations for Collection employees assigned ATAT inventory are properly applied, see IRM 5.20.2.3, Special Compliance Program Designation and _IRM 1.4.50.10.2.1_, Inventory Adjustments for the criteria and processes.


**1.4.50.10.8.3** **(04-01-2025)**

##### Sources of ATAT Inventory

1. ATAT referrals from SBSE Exam and LB&I, settlement initiatives (e.g. OVDI, abusive micro-captive insurance) and the Voluntary Disclosure Program (VDP).

2. ATAT designated hold file. The Inventory Delivery System (IDS) routes ATAT cases to ICS, which aligns the cases to each ATAT group’s ATAT designated hold file when the unpaid balance of assessments of a case exceeds $100,000 and at least one of the balance due modules contains an Examination ATAT special project code, ATAT civil penalty code or is an Estate & Gift tax case.

3. ENTITY ATAT queries. Request a list of ATAT, Estate and Gift cases available for assignment aligned to the geographic area of your group from your ATAT Coordinator.

4. Frivolous Return Program refund recovery referrals received from Collection Policy.

5. Examination Stat 90 report. The Collection Policy receives a report of recently closed cases from SB/SE Exam & Large Business & International (LB&I) each quarter. Collection Policy ATAT analysts filter this report to identify recent assessments containing an ATAT project codes and certain ATAT-related civil penalty codes. The report is forwarded by Collection Policy to each ATAT Field Collection GM. GMs can sort the list of cases for the states and zip codes aligned to their group for a source of inventory for assignment.

6. Automated Non-Master File (ANMF). ATAT group managers should submit a "BEARS" request for access to Automated Non-Master File to identify open non-masterfile estate and gift liabilities. Perform a query under "Research Open Non-Master File Account" to identify MFT 53 (estate) and 54 (gift) liabilities for assignment.


**1.4.50.10.8.4** **(04-01-2025)**

##### ATAT Designated Hold Files

1. Each ATAT group has one ICS designated hold file for the ATAT program. The ICS ATAT designated hold files use one of the assignment numbers:



   - AOTO-XX75,

   - AOTO-XX92, or

   - AOTO-XX93.


2. There is an automated process which delivers ATAT cases directly to these designated ICS hold files. The cases are routed to these hold files when the unpaid balance of assessments of the case exceeds $100,000 and at least one of the balance due modules contains an ATAT Examination special project code, ATAT civil penalty code or is an Estate & Gift tax MFT.

3. Each ATAT manager has the responsibility to monitor their group’s ATAT designated hold files. This monitoring includes:



1. Reviewing the ATAT designated hold file bi-weekly to make an assignment determination for each case received.

2. Address all imminent assessment or collection statutes (ASEDs and CSEDs).

3. Evaluate case receipts to ensure the ATAT designated hold file only contains cases meeting the above criteria. This evaluation requires the review of each module associated with the case to confirm the presence of an ATAT Exam Project code on one or more of the outstanding periods. Instances where there are no Exam ATAT project codes present on any module, contact the Collection Policy ATAT analysts for assistance. Cases not meeting ATAT criteria should be transferred to the queue.

4. When a determination has been made to assign an ATAT case received in the ATAT designated hold file the case must be assigned to a revenue officer within 120 days of receipt. If the case cannot be assigned within 120 days due to the inventory levels of revenue officers in your group, the case should be transferred to the queue.


4. The ATAT designated hold file _may_ contain cases which do not meet mandatory assignment criteria or represent the highest priority inventory available for assignment. Cases not meeting these two criteria may be transferred to the queue when there is higher priority inventory available for assignment from other sources such as ATAT referrals or inventory displayed in one of the ENTITY ATAT queries above in _IRM 1.4.50.10.8.3_ Sources of ATAT Inventory.

5. All ATAT cases pending assignment to a revenue officer are to be held in the ATAT designated hold file. ATAT cases pending initial assignment or re-assignment must not be placed in the ICS group designation hold file, AOTO-XX00, the GM’s assignment file ATAO-XX01 the or the Non-CDP hold file ATAO-XX99.


**1.4.50.10.8.5** **(04-01-2025)**

##### Prioritization of ATAT Work

1. The primary role of the Field Collection ATAT program is to support the IRS’s ATAT program. As stated above a significant portion of assignments to Field Collection ATAT are derived from SB/SE ATAT Examinations, LB&I and the Lead Development Center (LDC). Often, these referrals are in the pre-assessment stage of the case life cycle and therefore, are not assigned a priority level. These referrals represent the highest priority inventory for assignment.

2. Mandatory assignment cases. The following categories are considered mandatory assignments and should be assigned prior to the assignment of other inventory available for assignment. Mandatory ATAT inventory includes:



1. ATAT referrals from SBSE Exam and LB&I, settlement initiatives (e.g. OVDI, abusive micro-captive insurance), the Voluntary Disclosure Program (VDP) and pre-assessed promoter/preparer investigations referrals from Examination.

2. Frivolous Return Program refund recovery referrals received from Collection Policy.

3. ATAT Promoter/Preparer balance due accounts in the ICS ATAT designated hold file and the queue. These cases involve IRC §§ 6700 or 6701 assessments. These cases are identified by Examination ATAT special project code 0019 or ATAT civil penalty codes 628 or 621. Review _both_ the ICS ATAT designated hold file _and_ the in the queue available for assignment using from the ENTITY ATAT case lists provided by your ATAT Coordinator _IRM 1.4.50.10.8.3_ Sources of ATAT Inventory.

4. Mandatory assignment ATAT cases in the ICS ATAT designated hold file and queue. Mandatory cases in the queue are identified using the following "ATAT All Codes (Civil & Spec)" and "ATAT ESTATE & GIFT NATIONAL" ENTITY queries. Review _both_ the ICS ATAT designated hold file _and_ cases in the queue available for assignment from the ENTITY ATAT query case lists provided by your ATAT Coordinator _IRM 1.4.50.10.8.3_ Sources of ATAT Inventory.


3. High Priority ATAT Inventory.



1. ATAT GMs should evaluate high priority cases in both the ICS ATAT designated hold file _and_ high priority ATAT inventory available for assignment in the queue using the ENTITY ATAT query reports provided by your ATAT Coordinator _IRM 1.4.50.10.8.3_ Sources of ATAT Inventory, and assign the highest priority available for assignment. High priority inventory is defined as cases with priority levels 99-108.

2. Related entities or assessments. Assign related taxpayer entities or assessments such as civil penalty assessments to the same revenue officer assigned the primary investigation as appropriate.

3. Large dollar ATAT and Estate & Gift tax Cases. Large dollar cases, for this category of inventory is defined as Estate or Gift tax cases with an unpaid balance of assessments greater than $100,000 and cases containing an ATAT special project code, or an ATAT civil penalty with an unpaid balance of assessments greater than $100,000.


4. Remaining Inventory Assignments. While the primary role of the Field Collection ATAT program is to support the IRS’s ATAT program, the Field Collection ATAT program also supports the goals and objectives of Field Collection. Therefore, Field Collection ATAT groups will also receive high priority general program inventory for assignment to meet those goals and objectives. Other sources of ATAT inventory such as the ATAT Examination Status 90 report and ATAT inventory identified in Automated Non-Master File (ANMF) have case routing mechanisms which will ultimately prioritize and route inventory to ATAT collection groups. Remaining inventory needs for revenue officers in ATAT groups should be prioritized as follows:



1. High priority general program inventory.

2. Other Investigations (OI’s) created from the Examination ATAT Stat 90.

3. Estate and Gift assignment requests from ANMF.


**1.4.50.11** **(04-01-2025)**

### Group Controls

1. Group managers are responsible for establishing processes to support the mission of the IRS in the following areas:



1. Safeguarding taxpayer rights,

2. Protecting the public’s interest,

3. Supporting financial controls and

4. Records management compliance.


2. The requirements for performing group controls have different intervals in which they should be performed. While some controls have an annual requirement for completion, others should be performed monthly or more frequently as an on-going process. The primary systems used to generate management reports for field collection group controls are ENTITY and ATFR. However, certain controls require the use of manual processes or the use of specific systems.

3. The reports and queries available from ENTITY and ATFR can be used to establish controls for:



1. Statutes, ASEDs and CSEDs

2. Lien determinations

3. TFRP assessment processes

4. RO inventory level and higher graded duties

5. Lapses in activity

6. Pyramiding

7. Direct compliance time


4. The Embedded Quality Review System (EQRS) is used to conduct case reviews, and is the primary control used to ensure taxpayer rights are protected throughout the case life cycle.

5. Once established, these control reports can be utilized to identify cases needing regular review and follow-up by the manager. Reviews should address issues such as:



1. Are timely and effective actions being taken to appropriately resolve the case?

2. Is the accuracy of high priority cases (CSED, ASED) being verified?

3. Are taxpayer rights being observed?

4. Is the revenue officer providing good customer service?


**1.4.50.11.1** **(04-01-2025)**

#### Financial Controls, Remittance Control Reviews

1. The remittance control review is used to support financial internal controls. You are required to maintain control procedures per IRM 5.1.2.5.5.1, Form 3210 and Form 795/795A Follow Up, to ensure delivery and acknowledgement of remittance packages to Submission Processing. Periodically (at least once annually) conduct a review of control procedures established to ensure staff is complying with the procedures in IRM 5.1.2.5, Daily Report of Collection Activity-Form 795/795A. This control review should include the procedures for remittance packages prepared by revenue officers working away from the POD on extended field calls or telework. This control review should include reviewing procedures for remittance packages prepared by revenue officers within the group but located in satellite/remote PODs.



### Note:



This control review is not a review of Form 5919, Teller’s Error Advice. This control review is not a periodic check to ensure remittances/posting documents match the Form 795/795A being transmitted to Submission Processing. At a minimum your control review should confirm **and document** there is a process for and the group is complying with the following review points:






| **Review Element** |
| :-: |
| Form 3210 is used to transmit multiple Form 795/795As to Submission Processing per IRM 5.1.2.5, Daily Report of Collection Activity - Form 795/795A. This may be done by looking at both the Form 3210 control copies and the acknowledged Form 3210s.<br> <br>### Note:<br>Per IRM 5.1.2.5, Daily Report of Collection Activity - Form 795/795A, Form 3210 must be completed and two copies included when sending more than one sealed envelope to Submission Processing. |
| Form 3210 lists only documents transmitted, does not list any documents that were not transmitted, and is not missing transmitted documents.<br> <br>### Note:<br>When the Form 3210 is missing transmitted documents (i.e. documents are transmitted with the form but not listed on the form), Submission Processing is required to annotate the acknowledgement copy with documents received but not listed. |
| Form 795/795As are prepared timely according to IRM 5.1.2.5, Daily Report of Collection Activity - Form 795/795A. This may be done by comparing the Form 795/795A dates with the remittance received dates for remittances listed on the Form 795/795A. |
| Form 795/795As and envelopes are prepared properly per IRM 5.1.2.5.3, Procedures for Preparing and Processing Form 795/795A. This may be done by comparing prepared Form 795/795As and envelopes with the requirements listed in IRM 5.1.2.5.3, Procedures for Preparing and Processing Form 795/795A . |
| Control copies of Form 3210 are maintained per IRM 5.1.2.5.4, Procedures for Mailing Form 795/795A to Submission Processing. This may be done by looking at the location/file containing the Form 3210 control copies. |
| Control copies of Form 795/795A are maintained per IRM 5.1.2.5.3, Procedures for Preparing and Processing Form 795/795A. This may be done by looking at location/file containing the Form 795/795As control copies. |
| A procedure is established to handle processing of remittances and returns for those employees away from the office per IRM 5.1.2.5, Daily Report of Collection Activity - Form 795/795A. This may be done by verifying with employees the process used to ensure payments are processed the same day or no later than the next business day for those employees away from the office. |
| All document transmittal forms are reconciled on a biweekly basis to ensure that all transmittals were received per IRM 5.1.2.5(2), Procedures for Mailing Form 795/795A to Submission Processing. This may be done by looking at the location/file of the Form 3210 control copies for copies older than two weeks. |
| The actions in IRM 5.1.2.5.5.1, Form 3210 and Form 795 Follow up, have been taken for document transmittals (Form 3210, or in the case of one envelope, Form 795/795A) without an acknowledgement and 14 days have passed since transmission. This may be done by reviewing the control documents, verifying they were all acknowledged and any that were not acknowledged were followed up on within 14 days. Verify the designated clerical contact knows the follow-up requirements contained in IRM 5.1.2.5.5.1, Form 3210 and Form 795/795A Follow Up. |
| Verify revenue officers in each post of duty have access to a **United States Treasury** stamp to meet the requirements of IRM 5.1.2.7.3.1, Overstamping or Endorsing. |





### Note:



To verify remittance packages prepared by revenue officers working away from the POD on extended field calls or telework, the ENTITY query system may be used to select payments secured on days the revenue officers were working away from the POD on extended field calls or Telework.

2. You must document your review. An optional template containing the minimum documentation is contained in , Remittance Processing Transmission Control Review Template. You may print a copy of the template by accessing the Printed Products Catalog, searching for this IRM by catalog number (33258K) and printing the singular page for the exhibit. If the _Exhibit 1.4.50-7_ template is not used, the review documentation must, at a minimum, notate the date the review was completed, the name of the reviewer, each of the review points listed in the template, whether the review point's IRM requirement was met or not met, and any corrections/comments for each review point. The documented review must be retained for the appropriate period required under the records management guidelines per IRM 1.15, Records and Information Management. A copy of the documented review may be forwarded to the FCM for review.

3. The review documentation must be retained for the appropriate period under the records management guidelines per Document 12990, Records Control Schedule (RCS) Tax Administration – Compliance, Item 2 – General Administration and Housekeeping Correspondence. Destroy when 2 years old.


**1.4.50.11.2** **(04-01-2025)**

#### Protecting the Public Interest, CSED Accounts

1. Using ENTITY, generate an **Imminent Statute Report** from the **Reports** select **C** for CSEDs with a 12 month date range. Generate this report at least monthly to identify accounts for which the collection statute expiration date (CSED) will expire within the next 12 months. Review those cases to:



1. Verify the accuracy of the CSED, and ensure corrective actions are taken (see below).

2. Ensure that timely and effective action is taken.


### Note:

It is recommended the report be generated more frequently during the months of January through April since many IMF collection statues expire in the month of April.

2. The CSED displayed may be invalid in certain cases. The CSED shown is always for the earliest assessment on the module. If that assessment is paid, the true CSED is for a later assessment (for example, an adjustment or deficiency assessment). If that is the case, request command code CSEDR to eliminate erroneous CSEDs from future monthly reports. Update the CSED date on ICS or instruct the revenue officer to take that action.



### Note:



Update the ICS CSED date by selecting “New ICS CSED Date” under Module Detail, Update Module Date. Updating the IDRS CSED and requesting a TC 550 is not necessary in cases where the initial assessment has been full paid and the current CSED is based on a subsequent assessment. Review cc IMFOLT for FIRST CSED, NEXT CSED and LAST CSED and cc BMFOLT for LATEST CSED DATE, EARLIEST CSED DATE and IMMINENT CSED DATE.

3. See IRM 5.1.19.5.3(3), Documenting Imminent CSEDs, for necessary actions when the CSED will expire in 120 days or less.

4. If a statute expires, see IRM 5.16.1.2.2.5, Report of Statute Expiration. Reports are not required for statutes that expired while the case was in the queue.


**1.4.50.11.3** **(04-01-2025)**

#### Protecting the Public Interest, ASED Accounts and TFRP Monitoring

1. Each month, you must use ENTITY to monitor imminent ASEDs in your group. To properly identify potential imminent ASED issues perform the following actions:



1. Using ENTITY, generate "ASED Query 4/15/XX" under the "Module Management" menu. This query and it’s name are updated annually so the query remains current and provides a listing of all modules where the ASED will expire from the current date through May 30th of the following year, where no TFRP determination has been made, or modules assessed under IRC §6020(b) where the ASED field for the module is blank.

2. To obtain a 12 month date range for reviewing ASED dates, use ENTITY to generate an "Imminent Statute Report" from the "Reports" menu selecting "A" for ASEDs. This report identifies accounts where the assessment statute expiration date (ASED) for the trust fund recovery penalty (TFRP) will expire within the date range input. However, be aware this report does not capture modules where the ASED field is blank, in cases such as assessments made under IRC 6020(b).

3. Ensure that these cases from both the "ASED Query 4/15/XX" and "Imminent Statute Report" are loaded on the ATFR System. Review and comparison of ENTITY reports and ATFR reports should ensure accurate identification of all potential ASED issues.



      ### Note:



      It is recommend to review these reports more frequently during the period October through April since many ASED’s expire on April 15th.


2. Match the ATFR inventory with the ICS inventory assigned to the group and resolve any discrepancies semi-annually.

3. Review potential ASED modules where no penalty determination appears to have been made, and the case has been in inventory for greater than 4 months.

4. When appropriate, instruct revenue officers to:



1. Proceed with trust fund investigation.

2. Prepare Form 4183, Recommendation Re: Trust Fund Recovery Penalty Assessment, for approval.

3. Secure Form 2750, Waiver Extending Statutory Period for Assessment of Trust Fund Recovery Penalty, from all persons who appear to be responsible for the trust fund taxes, but did not collect, account for and/or pay the taxes. This consent must be completed and signed by both the taxpayer and by a IRS representative grade GS-09 or above on or before the ASED expiration to be a valid extension of the ASED see IRM 5.7.3.7.1 , Form 2750 Waiver.

4. Proceed with assessment.



      ### Caution:



      Taxpayers have the right to refuse to extend the limitations period. See IRM 5.7.3.7.1, Form 2750 Waiver.


5. Check to ensure the revenue officer made a determination on ATFR, appropriately documented the ICS case history concerning TFRP development and the ASED review indicator (ASED-R) is properly recorded on IDRS.




| **ASED-R** | **Definition** |
| :-: | :-: |
| 0 | No TFRP determination has been made |
| 1 | Penalty assessed |
| 2 | Unable to locate responsible persons |
| 3 | No collection potential for any responsible person |
| 4 | All trust fund amounts paid |
| 5 | Penalty not applicable |

6. Report the expiration of any ASED per instructions in IRM 5.7.3.9, Reporting Expiration of TFRP Statute.

7. The Automated Trust Fund Recovery (ATFR) application provides several reports to facilitate monitoring of TFRP assessments. Monitor ATFR reports at least monthly to ensure investigations are conducted and recommendations are made timely. The following reports are available in the ATFR system to monitor timely trust fund recovery penalty investigation procedures:



1. ASED report. This report is used to determine whether imminent assessment statutes (less than one year remaining on the ASED) are present, and if so confirming they have been addressed, see IRM 5.7.3.3.1, Monitoring TFRP Cases.

2. Pending determination report. This report is used to ensure revenue officers are making timely TFRP assessment determinations, generally 120 days from case assignment, see IRM 5.7.4.2, TFRP Determinations, Investigations and Interviews. The report will display the remaining number of days for a timely TFRP determination.

3. Pending Form 4183 report, the Form 4183 must be approved by the manager 120 days after the determination date to be timely, see IRM 5.7.4.5 , Form 4183 Penalty Assessment Recommendation. The report will display the remaining number of days for timely approval of the Form 4183.



      ### Note:



      Managers must document in the ICS and ATFR case histories the circumstances warranting the additional time when a Form 4183 approval is delayed.





      ### Reminder:



      Due to ex parte communication rules on documentation after receipt of a TFRP protest, ensure that the TFRP assertion recommendation is fully documented and supported prior to approving Form 4183.

4. Pending Letter 1153 report, the Letters 1153 must be issued to the potentially responsible persons within 20 days from the approval of the Form 4183, see IRM 5.7.4.7, Notification of Proposed Assessment

5. Pending Form 2749 to CPM report, see IRM 5.7.6.12 , Revenue Officer Assessment Actions. Timely release of the TFRP file to the CPM is 30 days after the expiration of the Letter 1153, typically 90 days unless the potentially responsible person is located outside the United States.


### Reminder:

Use the ATFR system reports at least monthly to promote timely TFRP investigations and actions by revenue officers. It is also recommended to generate the ASED report more frequently during the months of October through April to address imminent ASEDs.

### Note:

The ATFR application cannot be used to monitor or assess certain trust fund liabilities including collected excise taxes (MFT 03), railroad retirement tax returns (MFTs 09, 71 & 72) and certain withholding for foreign persons (MFTs 08 & 17).

8. The ATFR application is also used to approve revenue officer actions such as:



   - Delay of determination.



     ### Note:



     Managers must document the ICS and ATFR case histories with the circumstances warranting the additional time to pursue or reset the determination timeframe.

   - Reset a past due determination.

   - Nonassertion Recommendation of Uncollectible Trust Fund Recovery Penalty.

   - Recommendation of Trust Fund Recovery Penalty Assessment.

   - Cases closed to the queue or In-Business Installment Agreement.


9. Resources include:



   - IRM 5.7.4, Investigation and Recommendation of the TFRP

   - ATFR web page, see _IRM 1.4.50.1.8_ for a link to the ATFR web page


**1.4.50.11.4** **(04-01-2025)**

#### Protecting the Public Interest, Notice of Federal Tax Lien Determinations

1. ENTITY has lien reports and queries to assist group managers when monitoring the group’s notice of federal tax lien (NFTL) determinations.

2. Use the ENTITY system to monitor all cases with outstanding tax liabilities greater than $10,000 for which no NFTL has been filed or the normal NFTL determination period has been extended. If the NFTL is unfiled more than 30 days after receipt of the module, determine whether an immediate NFTL filing or non-filing determination is required see IRM 5.12.2.3.2 Determination Requirements. See IRM 5.12.2.5.2, NFTL Filing Determination Approvals, for GM approval/documentation requirements.

3. On a monthly basis, generate the "Module Lien Report." This report provides a listing of IDRS TDA modules that do not have a lien filed which meet the following criteria:



   - The case as been assigned to Field Collection for more than 55 days.

   - The balance due modules assigned in ICS have a balance greater than $10,000.

   - The case has one or more IDRS TDA module(s) without a lien according to the Automated Lien System (ALS).


4. The Module Lien report contains a lien indicator field. The values are described in the table below:




| **Indicator** | **Definition** |
| :-: | :-: |
| 0 | No Determination |
| 1 | NFTL Determination Extended |
| 2 | NFTL Requested |
| 3 | Do Not File |
| 4 | NFTL Filed |
| 5 | NFTL Determination Deferred |
| 6 | Approval Requested |
| 7 | Lien Not Required |
| 9 | N/A |

5. In addition, you must generate the "Module Lien Refile" report. This report lists all modules with a NFTL in the re-file window. The report provides the last date for re-filing the NFTL.



### Note:



Not all modules will have an extended CSED or other condition requiring the need to re-file the NFTL. A module may appear on the report if the NFTL has been re-filed, but not in the same location as the original NFTL.

6. You may, if appropriate, monitor other NFTL filing determinations as well. There are additional lien queries available in the ENTITY see the "Lien Reports and Queries" page on the ENTITY SharePoint at ENTITY Lien Reports and Queries.


**1.4.50.11.5** **(04-01-2025)**

#### Taxpayer Rights, Timely Processing of Collection Due Process (CDP) and Equivalent Hearing (EH) Requests

1. ICS provides a monthly area level report to monitor processing of CDP and EH requests. These reports are accessible by the designated CDP coordinator for the area. The CDP coordinator monitors these reports to identify hearing requests that appear to be aging in field inventory and on a quarterly basis will issue an alert to the field compliance manager and/or group manager for appropriate follow-up.

2. ICS provides a weekly group level CDP/EH Inventory Report. This report identifies CDP and EH requests in process at the group level. Use this report to identify hearing requests in the group and follow-up as appropriate on requests that appear to be aging. Refer to IRM 5.1.9.3.3, Processing CDP and EH Requests, for time frames for processing hearing requests.

3. Managers can check the receipt and status of cases in Appeals by researching the Appeals Centralized Database System (ACDS).


**1.4.50.11.6** **(04-01-2025)**

#### Taxpayer Rights, FinCEN Query Monitoring

01. The Financial Crimes Enforcement Network (FinCEN) maintains the FinCEN Query (FCQ) system, which is a database containing 31 U.S.C. Title 31 financial reports. These reports include Currency Transaction Reports (CTRs), Reports of International Transportation of Currency and Monetary Instrument Reports (CMIRs), Reports of Foreign Bank and Financial Accounts (FBARs), and Suspicious Activity Reports (SARs) and Reports of Case Received by Trades or Businesses, Form 8300.

02. By memorandum issued by commissioner, SBSE, on March 29, 2011, certain compliance employees of SBSE are now authorized electronic access to the FinCEN Query system in connection with active and assigned cases.

03. ATAT, International and all GS 13 field collection revenue officers may be authorized online access to FCQ system, but only after they and their managers have been trained in the proper handling of SAR information. Revenue officers and group managers must complete Integrated Talent Management (ITM) course 41166, Safeguarding Online Access and Using Suspicious Activity Report (SAR) Information Briefing. GMs must also complete ITM course 41667, Manager Online Suspicious Activity Report Audit Trail Reviews Briefing.

04. Managers of employees with access to FCQ system conduct reviews of query audit trails for their employees’ logons, logoffs, and records access no less than annually and for a review period of no less than 30 days of FCQ system access within the past year. The FCQ system maintains up to the past 13 months of user query information.

05. A GM may only request an audit report for an employee who is the manager’s direct report.

06. A FCQ system audit report mailbox has been established for managers to request audit trails, the mailbox address is \*SBSE FCQ AUDIT TRAIL.

07. GMs request an audit trail by forwarding the name and complete email address of the employee and the review time frame to the above address via secure email. The audit report will be returned to the requesting manager via secure email.

08. At a minimum, the review should confirm and document:



    - The review period is a minimum of 30 consecutive days

    - The review is within the user’s rating period

    - Queries performed by employees who are not a designated gatekeeper or super user match open or closed case assignments for the employee

    - When performing a review of a gatekeeper or super user, request the Forms 10509-A, FinCEN Query SAR Request received by the employee for the review period

    - Match queries performed by a gatekeeper or super user to the Form 10509-A request forms as well as the open and closed inventory assignments to the gate keeper or super user if applicable


09. If the employee’s research indicates inspection of records not related to an open or closed case assigned to the employee, or in the case of a gatekeeper/super user, if the research is not supported by an approved Form 10509-A, see IRM 10.5.5.3.2, Privacy and Information Protection - IRS Unauthorized Access, Manager UNAX Responsibilities for guidance on suspected UNAX violations.

10. If the area SAR gatekeeper is a group manager or an area analyst, the field compliance manager or area director may delegate another area management official the responsibility of completing the online review of SAR audit trails for the area gatekeeper.

11. You must document your review. An option review template is provided at _Exhibit 1.4.50-9_, FinCEN Query Review Template. You may print a copy of the template by accessing the Printed Products Catalog, searching for this IRM by catalog number (33258K) and printing the singular page for the exhibit. If the template is not used, the review documentation must notate the date of the review, and the review points listed above.


**1.4.50.11.7** **(04-01-2025)**

#### Taxpayer Rights, Compliance Data Warehouse Knowledge Graph Environment (CKGE) Monitoring

1. Compliance Data Warehouse Knowledge Graph Environment (CKGE) is an interactive software tool that provides linked data and graph analytics for a range of a taxpayer’s related entities. CKGE was developed by Research, Applied Analytics & Statistics (RAAS) and is a graph database. CKGE performs data analytics from information in the Compliance Data Warehouse (CDW) and provides a graphic representation of a taxpayer’s relationship to other entities.

2. CKGE research user audit logs are systemically shared with Cyber IT and are analyzed for potential UNAX violations. In addition to this capability RAAS developed the CKGE Manager Audit Module (CMAM) for additional management controls of the use of CKGE.

3. GMs will automatically gain access to CMAM when a revenue officer aligned to the GM in the Discovery Directory has been granted CKGE access. GMs will only have access to the CKGE research conducted by ROs aligned to them on the Discovery Directory.

4. GMs must complete one review of each employee with CKGE access using CMAM during the employee’s rating period.

5. You must document your review. Use of the template is located at _Exhibit 1.4.50-8_ is optional. You may print a copy of the template by accessing the Printed Products Catalog, searching for this IRM by catalog number (33258K) and printing the singular page for the exhibit. Take the following steps to perform your review:




| **Step** | **Review Process** |
| :-: | :-: |
| 1 | Log into CKGE. |
| 2 | Select _CKGE Manager Audit Module (CMAM)._ |
| 3 | Click the _Go to Activity Viewer_ button on the CMAM landing page. |
| 4 | Select an employee from the _User_ list at the upper left side of the response screen. |
| 5 | If the employee did not conduct CKGE research during the rating period, the review is complete by documenting the review record that no research was conducted by the employee. |
| 6 | If the employee did perform CKGE research during the review period, select a search session made by the employee starting with the initial query located in the _Searched using term_ box. |
| 7 | The item in the _Searched using term_ is usually the tax identification number of the taxpayer assigned to the RO. In some instances, the search term may be another available data point associated with the taxpayer. Further, the search term may be an entity or individual related to the assigned taxpayer account. |
| 8 | Confirm the initial search term is associated with an account currently or previously assigned to the RO. If the search term is for an individual or entity related to the assigned account, confirm whether the RO documented the nexus between the assigned account and search term. |
| 9 | Confirm whether the expanded nodes related to the initial search term are related to the case currently or previously assigned to the RO. |
| 10 | If the employee’s research indicates inspection of return information not related to the assigned investigation, see IRM 10.5.5.3.2, Privacy and Information Protection - IRS Unauthorized Access, Manager UNAX Responsibilities for guidance on suspected UNAX violations. |
| 11 | Place the documentation of your review in the employees EPF. |


**1.4.50.11.8** **(10-20-2023)**

#### Records Management, Closed Case File Transmittals

1. Form 3210, Document Transmittal, is the control document used when shipping closed cases from the group to Centralized Case Processing (CCP).

2. You must conduct quarterly reviews of Forms 3210 used to transmit closed cases. Confirm that control copies of Form 3210 are timely reconciled with acknowledgement copies. If Form 795B is associated with Form 3210, confirm that all cases listed on Form 795B are also listed on Form 3210.

3. Refer to IRM 10.5.1.6.9.3, Shipping, for further information about Form 3210 procedures including follow-up time frames/actions and loss reporting.

4. Ensure that control copies of Forms 3210 are retained in accordance with the Records and Information Management Records Control Schedule in Document 12990, Records Control Schedules, RCS 22, Tax Administration-Compliance, Item 2, General Administration and Housekeeping Correspondence. Destroy Forms 3210 when two years old.


**1.4.50.11.9** **(04-01-2025)**

#### Suspension of Case Aging

1. It may be appropriate to suspend case aging where the facts and circumstances of the case require complex investigations coupled with collaboration from other functions such as Counsel, Criminal Investigation, Advisory or the Office of Fraud Enforcement. These cases often require additional investigative processes to identify avenues of collection where the taxpayer’s property rights are inherently complex or have been obfuscated. The suspension of case aging is limited to the following case types:



   - ATAT,

   - Suit development,

   - Fraud development cases.


2. The cycle clock is suspended with the input of transaction code (TC) 971 action code (AC) 281 and removes the case from the IDRS/Entity aging reports. The cycle clock is restarted with the input of TC 972 AC 281. Only group managers, acting group managers and ICS Quality Analysts (IQAs) are profiled to request input of TC 971/972 AC 281. Input is accomplished by selecting "Generate TC 971/972 AC 281" from the Collection Activities menu on the case summary screen and selecting the "Generate TC 971 AC 281" radio button. The ICS history must be documented by the group manager or acting group manager to support the input of TC 971 AC 281. Reversal of the TC 971 AC 281 is accomplished by selecting the "Generate TC 972 AC 281" radio button. ICS can be used to input these codes only if there are open IDRS Bal Due or Del Ret modules on the case. If there are no open IDRS modules associated with the case, prepare a Form 4844, Request for Terminal Action for manual input.

3. The taxpayer location block must also be updated with an indicator on suit and fraud development cases. To accomplish this, select "Name/Address" under the Entity Detail tab on the case summary screen in ICS. Then select the taxpayer entity line, followed by the "View/Edit" tab and enter the appropriate indicator; "SUIT" or "FRD" in the "Location" box depending on the case type. These indicator must be reversed in conjunction with the input of the TC 972 AC 281.

4. ATAT Cases. Case with sub-codes 309 through 339 are eligible for suspension of the cycle clock. Request input of the TC 971 AC 281 using the instructions above. If a Form 11661-A, Fraud Development Recommendation-Collection has been approved by the FEA and group manager for an ATAT case, you must also update the taxpayer location block to "FRD" using the instructions above. The FRD indicator must be removed if the case is removed from fraud development status.

5. Suit development cases. Cases in suit development status are eligible for suspension of the cycle clock. In order to suspend the cycle clock on the case, group managers must request input of the TC 971 AC 281, and document the ICS history. You must also update the taxpayer location block with the "SUIT" indicator. A TC 972 AC 281 to restart the case cycle clock should be input and the "SUIT" indicator must be removed when the case has been referred to the Department of Justice, the suit recommendation is not longer being pursued or a different case resolution has been reached, such as reporting the case CNC.

6. Fraud development cases. After the Form 11661-A, Fraud Development Recommendation-Collection is approved by the Fraud Enforcement Advisor (FEA) and the group manager, the group manager will update the ICS sub-code to 910 FRAUD DEVELOPMENT-FEA. Updating the cases sub-code to 910 will automatically generate a request from ICS to IDRS to input a transaction code (TC) 971 action code (AC) 281. In addition to the TC 971 AC 281, the taxpayer’s location indicator must also be updated to "FRD" to ensure the case is included on the Area fraud report. When the case is removed from fraud development status, the manager will update the sub code from 910 to the appropriate sub code in ICS. When changing the sub code from 910, select "Yes" when asked "Is TC 972 AC 281 required to restart the overage clock?" This will trigger the request to input of TC 972 AC 281 to IDRS.


**1.4.50.11.10** **(04-01-2025)**

#### Taxpayer Rights, Sensitive Case Reports

1. Sensitive case reports (SCRs) are used to notify leadership of investigations of high-profile taxpayers, or instances where a planned enforcement action will have a broad impact on the welfare of third parties. The reports serve as a situational-awareness of such cases for leadership’s preparedness for potential Congressional inquiries or media attention.

2. High-profile taxpayers include well-known entertainers, national sports figures, prominent political figures and state or large municipal governments.

3. Examples of sensitive enforcement impact include but are not limited to actions which would have a pronounced community economic impact or involve entities which provide for the welfare of third parties including rural hospitals, residential care centers for the disabled or elderly and child care facilities.

4. Obtain an SCR template from your field compliance manager.

5. Complete the initial SCR upon identification of a high-profile taxpayer assigned to your group, or when an enforcement action is considered that will have broad community economic impact or affect the health or welfare of third parties. Supplemental SCRs should be prepared monthly, or more frequently as needed based on developments of the case. A final SCR is prepared when the case resolution is implemented.


**1.4.50.12** **(10-20-2023)**

### Quality

1. The IRS vision focuses on three high level goals: service to each taxpayer, service to all taxpayers and productivity through a quality work environment. The IRS has developed a set of balanced measures in three major areas: Customer satisfaction, employee satisfaction and business results, with business results comprised of measures of quality and quantity.

2. You are responsible for the quality of all work assigned to your group and for all work which leaves your group regardless of the methods you use. You must devise a system of quality control which works for you. Consider:



1. Encouraging revenue officers to work with you in your efforts to improve the quality of their work

2. Devising a plan to ensure a high level of quality in your group

3. Using reports available through the EQ system as diagnostic tools to focus attention on specific quality issues. The EQRS application used by front line managers and the NQRS application used by centralized reviewers mirror each other and feature numerous reporting capabilities that will facilitate comparison of results from both reviews at various levels of the organization. For example, if specific aspects of NQRS reports for a certain area office start to decline, area, territory and even group results for the same aspect measured under the managerial EQ review can be viewed to help isolate potential root causes.


3. **In planning your program, keep in mind that the best use of your time is coaching revenue officers and assisting them in the successful resolution of cases, especially those that are more complex.**

4. Reviews can help you determine your revenue officers’ needs for training and development. This will help you decide how much time to devote to each revenue officer.

5. You may also choose from the following reviews and controls in designing your plan:



1. Field visitations.

2. Office or telephonic observations.

3. Spot reviews of open and closed cases.

4. Formal inventory analysis.

5. Time utilization reviews.

6. Reviews of work submitted for approval.

7. Initial contact reviews.

8. TFRP cases pending determination or recommendation.

9. Regular reviews of high priority cases.


6. High priority cases include:



1. Pyramiding.

2. CSED accounts.

3. ASED accounts.

4. Large dollar accounts.

5. In-business accounts.

6. FTD Alerts.


**1.4.50.12.1** **(01-25-2013)**

#### EQRS

1. In reaching our goals we consider our impact on customer and employee satisfaction while we strive to improve quality and achieve quantifiable results. The Embedded Quality (EQ) process was developed to support balanced measures objectives.



1. EQ is a tool designed to assist managers in identifying areas of strength and need in their employees’ individual performance. Case actions are evaluated against attributes that are designed, in accordance with IRM requirements, to identify actions that move cases toward closure through appropriate and timely case activity. The attributes link individual performance to organizational goals and are used by both managers and National Quality reviewers to assess significant case actions.

2. EQ enables you to measure the quality of both individual and group performance. It allows National Quality Review to assess the quality of the function to facilitate recommendations for improvement through policy changes, training and updated procedural guidelines.

3. The focus of EQ is on improving performance while the performance occurs. The attributes can be measured on open or closed cases. EQ is designed to identify gaps in quality case work at the earliest point in activity. It assists you in targeting corrective steps that positively impact performance.

4. To conduct employee case reviews, use the Embedded Quality Review System (EQRS) to rate case actions against the attributes. EQRS also provides you with tools to capture and share review feedback to show employees how they performed in relation to both the attributes and their CJEs. This should assist managers in providing employees with specific examples of how to sustain or enhance their performance.


**1.4.50.12.2** **(01-25-2013)**

#### NQRS

1. National quality reviewers use a similar web-based system called the National Quality Review System (NQRS). A cornerstone of EQ is that quality reviewers and managers use the same basic set of attributes. This should minimize the concern that national reviewers are applying different criteria than managers when reviewing cases. However the national quality reviews will **_not_** be used to evaluate individual employee performance. NQRS attributes are not linked to employee CJEs; instead each attribute is mapped to one of five quality measurement categories:



1. Timeliness.

2. Professionalism.

3. Procedural Accuracy.

4. Regulatory Accuracy.

5. Customer Accuracy.


**1.4.50.12.3** **(04-01-2025)**

#### EQ Consistency Reviews

1. Consistency reviews will be conducted to assist users in rating EQ attributes consistently by using the attribute job aids, EQ website guidance, employee critical job elements and IRMs. You may participate in one or more EQ consistency reviews each year. The goal of consistency reviews is to improve the understanding and application of the EQ rating guidelines. Group managers and field compliance managers within a territory will review the same case, compare attribute results, and discuss how rating guidelines can be applied to achieve consistency on attributes where significant rating inconsistencies occurred.

2. Field compliance managers will schedule and conduct EQRS consistency reviews with group managers annually. Area directors may add additional reviews when consistency among managers needs improvement. Consistency reviews require all managers within a territory to review the same case to compare attribute results and discuss how rating guidelines can be applied to achieve consistency.

3. Reviews are documented by preparing a written narrative to include the date the review was completed, observations and actions taken to achieve consistent application of EQ attributes.

4. Refer to IRM 5.13.1, Embedded Quality Collection Field Organizations Administrative Guidelines, for information and guidance about EQ.


**1.4.50.12.4** **(09-12-2014)**

#### Revenue Officer Case Documentation

1. It is extremely important that case documentation is timely, clear, accurate, and complete. Specific guidance for revenue officer case documentation is provided in various sections of the IRM, including Part 5.

2. Incomplete documentation will negatively affect:



1. Subsequent revenue officer case actions.

2. Ability to review and evaluate case activity.

3. Actions by other employees.

4. Quality Review System results.

5. Cases presented in legal proceedings.



      ### Example:



      Ensure that revenue officers clearly document the reason(s) why they have determined that the filing of a NFTL is not appropriate.


**1.4.50.13** **(04-01-2025)**

### Field Compliance Manager Employee Engagement Operational Reviews

1. Employee engagement operational reviews are a participative process involving each level of management and employees in the Field Collection function. The purpose of employee engagement operational reviews is to evaluate the business unit’s performance toward achieving organizational goals and compliance with administrative or statutory requirements. Employee engagement operational reviews provide an opportunity for engagement to address business priorities and objectives and to implement timely actions to accomplish these objectives. The context of employee engagement operational reviews is to provide high-level meaningful feedback to the function reviewed. Employee engagement operational reviews also serve as a component of the manager’s performance evaluation.

2. In Field Collection, Field Compliance Managers perform employee engagement operational reviews of Field Collection groups, while Area Directors perform employee engagement operational reviews of each territory in their Area.


**1.4.50.13.1** **(04-01-2025)**

#### Frequency and Planning

1. Employee engagement operational and/or administrative/compliance reviews may be conducted during the fiscal year as a _single phase_ comprehensive review or may take the form of an on-going series of _multi-phased_ reviews that focus on specific aspects of the group’s performance.

2. Field Compliance Managers must prepare a schedule for employee engagement operational reviews in their territory at the beginning of each fiscal year and provide the schedule with their Area Director by November 1.

3. Feedback about employee engagement operational review findings is expected to occur continuously throughout the review cycle.

4. FCMs should take into consideration the known strengths and opportunities for improvement for the group being reviewed when planning how to maximize the benefits of the employee engagement operational review for the GM and the Field Collection function. In addition to the mandatory review elements in 1.4.50.13.2(5), FCMs should exercise their professional judgement when selecting the supplemental review elements that support the strategic plan for Field Collection by providing the GM with actionable guidance and measurable goals.

5. Several review elements can be performed remotely using the appropriate computer applications. Examples of review items which may be performed remotely include but are limited to: case reviews, performance appraisals, Leadership Succession Review plans, EQRS, inventory reports and 1204 certifications. Other review elements can be reviewed by requesting the documentation from the GM, examples include the after-hours security review, group meeting minutes and remittance processing reviews.

6. In addition, you may delegate some review elements to your administrative assistant, staff, SMRP candidate, Frontline Manager Cadre participant or other appropriate member of your staff as a developmental assignment.



### Example:



Review of employee personnel files (EPFs) to determine if the files contain the required documents can be performed by an FCM’s administrative assistant by designating the employee as proxy in the eEPF system.


**1.4.50.13.2** **(04-01-2025)**

#### Documentation

1. Action items communicated to the group manager must include a description of the action to be performed and include a timeline for completion.

2. The format of an employee engagement operational review begins with identifying the group reviewed, the evaluative period, summarize the review process and communicate response requirements. The body of the review must address each of the three responsibilities in the Management Performance Agreement for the manager as well as the administrative compliance requirements. The review must also include engagement between the field compliance manager (FCM) and group manager as well as engagement between the FCM and revenue officers. The closing section of the review summarizes the overall performance of the group, articulate corrective actions to be taken and communicate follow-up requirements by the reviewer. The following represents an optional outline for an employee engagement operational review:



   - Document the employee engagement operational review in a memorandum for the group manager and share this memorandum with the group manager within 30 calendar days of completion of the review.

   - Leadership and Human Capital Management-Employee Satisfaction

   - Employee Engagement

   - Customer Service and Collaboration-Customer Satisfaction

   - Program Management-Business Results

   - Administrative Compliance

   - Conclusion


3. Each responsibility is supported by review elements. The narrative for each responsibility must address whether the responsibility is being met, and provide instruction on the actions the group manager must take to ensure the objective is met. The instruction must align to a process or responsibility rather than one-time corrective action.



### Example:



A field compliance manager (FCM) is addressing Business Results in a group’s employee engagement operational review. The FCM utilized the ENTITY Module Lien Report to evaluate timely lien determinations are being made within the group. There are several cases on the report where the lien determination due date has passed. The narrative of the employee engagement operational review should instruct the group manager to review the requirements of IRM 1.4.50.11(3), Group Controls for timely lien determinations rather than provide the GM a list of cases which require the lien determination be addressed. In this example, the FCM would inform the GM that a subsequent report will be generated for the group to ensure compliance.

4. Request the GM to describe their processes related to the elements reviewed in order to address the effectiveness of those processes and make recommendations where necessary.

5. Review elements which align to a required statutory or administrative internal control process are considered mandatory review items. Additionally, there are review items which align to delivery of the goals and objectives of Field Collection which are also mandatory review elements. These review elements marked "mandatory."


**1.4.50.13.3** **(04-01-2025)**

#### Leadership & Human Capital-Employee Satisfaction

1. Group managers are responsible for creating a workplace culture of professionalism where employees are treated with dignity and respect. Assess the GM’s performance management in providing meaningful feedback to employees by completing performance reviews which encourage employee engagement and the timely completion of mid-year and annual performance evaluations. When rating this responsibility, determine if the GM is completing the required performance reviews timely, address feedback provided the GM provides employees in the reviews and whether employees are providing feedback.




| **Employee Satisfaction Components** | **Elements** |
| :-: | :-: |
| Case Reviews | 1. Perform one "mirror" case review per employee in the group. A mirror review is a case review where the GM performed a review. The purpose of the mirror review is to assess the accuracy of the GM’s EQ attribute ratings and to determine if GM provided proper direction to the RO.<br>      <br>2. Confirm if the GM timely performed the appropriate number and mix of case reviews based on the grade of each employee, see IRM 1.4.50.10.5.2.2, Requirements for Annual Performance Reviews. Also confirm if the GM performed a taxpayer contact observational review, see IRM 1.4.50.10.5.2.3, Field and Office Observations as well as a time utilization review for each employee, see IRM 1.4.50.10.5.2.4, Time Utilization Reviews. |
| Employee Performance and Drop Files | **Mandatory.** The EPF is a system consisting of all performance ratings and other performance-related records maintained on an employee in accordance with 5 CFR Part 293, Subpart D. The following documents must be maintained for four years:<br> <br>1. Form 6850-BU, Bargaining Unit Performance Appraisal and Recognition.<br>      <br>2. Form 6774, Receipt for Critical Job Elements and Fair and Equitable Treatment of Taxpayers Retention Standard.<br>      <br>3. The CJE performance plan document.<br>      <br>4. Employee self-assessments.<br>      <br>5. Documented workload reviews, case file reviews, and job visitations.<br>      <br>6. Any other documentation that supports the performance rating. |
| Performance Appraisals | **Mandatory.**Review performance appraisals performed by the GMs to ensure they are timely. Ensure GMs have conducted mid-year evaluations between the fifth and seventh month of the employee’s rating period. Annual appraisals are due to the employee by the last business day of the month following the employee’s rating period. |


**1.4.50.13.4** **(04-01-2025)**

#### Employee Engagement

1. Each management responsibility includes a component of employee engagement. High levels of employee engagement directly correlates to the achievement of the goals and objectives of Field Collection. The elements of employee engagement are communication, leadership, recognition and professional growth. This component of the employee engagement operational review assesses the GM’s actions which promote and enhance employee engagement. Evaluate if the GM is communicating performance expectations through regular group meetings and written communications. Does the GM’s communication process promote employee engagement and are issues raised by employees acted upon? Address the GM’s employee development program within the group, identifying training needs and employee development opportunities. Employee training or leadership opportunities should be made available to all members of the group.




| **Employee Engagement Components** | **Elements** |
| :-: | :-: |
| Communications and Recognition | 1. Confirm the GM is conducting regular group meetings to communicate performance expectations by reviewing group meeting minutes and other communications issued by the GM. Do the meetings include round-table discussions, are employees given the opportunity to present issues or lead group meetings? What are the results of the recommendations?<br>      <br>2. Assess the GM’s employee recognition processes. The use of manager’s awards, time-off awards, e-cards and form 6067, Employee Performance Folder Record items.<br>      <br>3. As an FCM, you should conduct one town hall meeting with each group (or post of duty when two or more groups are collocated in a POD) in your territory during the fiscal year, as appropriate, create an action plan engage employees and empower employee participation in resolving the issues raised. |
| Leadership Opportunities | 1. Evaluate the use of Individual Development Plans (IDPs) in the group. Address whether the plans include actionable items and address if the items have been achieved.<br>      <br>2. Assess the effectiveness of how the GM supports the Frontline Manager Cadre program, and the Frontline Leadership Manager Readiness Program (FLRP). |
| Professional Growth | 1. Assess the training plans and training completion for each employee in the group.<br>      <br>2. Address the GM’s processes for affording OJI or Instructor details for employees and acting manager opportunities. |


**1.4.50.13.5** **(04-01-2025)**

#### Customer Service and Collaboration-Customer Satisfaction

1. Customer satisfaction is measured by the customer’s perception and level of overall satisfaction with their interaction experience. Customers are both internal and external to the IRS. High customer satisfaction translates into work group efficiencies and improving the public’s trust in the tax system. Customer satisfaction is the cornerstone to the mission of the IRS to provide top quality service to taxpayer by helping them understand their tax responsibilities with integrity and fairness to all. Metrics used to measure customer satisfaction include quality, regulatory compliance and customer feedback. Both GMs and employees have the opportunities to improve customer satisfaction by identifying issues or risks for resolution. t




| **Customer Satisfaction Components** | **Elements** |
| :-: | --- |
| Embedded Quality (EQ)/National Quality (NQ) Analysis | Compare cumulative quality attribute ratings cumulative reports from EQ and NQ. Use the reports to identify the groups strengths and opportunities for improvement. Also, address material discrepancies between EQ and NQ cumulative ratings. |
| 1204 Certification | **Mandatory.** Section 1204 of the Restructuring and Reform Act of 1998 prohibits the IRS from using any ROTER to evaluate employees or to impose or suggest production quotas or goals, requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard and requires each appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner.<br> <br>1. Confirm the GM timely completed quarterly 1204 certifications.<br>      <br>2. Confirm employee annual performance evaluations are free of ROTERS. |
| Collection Due Process and Fair Tax Collection Practices | 1. Review the GMs ICS CDP designated hold file to confirm non-CDP cases are not assigned to this hold file. Address the timeliness of transferring taxpayer’s CDP requests to Appeals. Also address the timeliness of reassignment of CDP cases returned by Appeals.<br>      <br>2. Assess the GM’s processes for addressing potential violations of Fair Tax Collection Practices, see _IRM 1.4.50.3.2.3_, Fair Tax Collection Practices. |
| Sensitive Case Reports | Sensitive case reports (SCRs) are used to notify leadership of investigations of high-profile taxpayers, or in instances where a planned enforcement action will have a broad impact on the welfare of third parties.<br> <br>1. Review the SCRs prepared by the GM during the rating period. Confirm updated reports where prepared when necessary and final reports were issued when appropriate, see IRM 1.4.50.11.10. |


**1.4.50.13.6** **(04-01-2025)**

#### Program Management-Business Results

1. The IRS assesses operational level business results through output or quantity measures and quality measures The IRS uses organizational measures as an analytical reference to determine whether the actions taken achieved the desired performance result. The focus of the evaluation of the business results responsibility is based on the actions taken and related accomplishments toward meeting the organizational goals of Field Collection. There are several performance measures available to management to evaluate the group’s efficacy. As a field compliance manager, you should communicate the areas of emphasis with your group managers at the beginning of the fiscal year and monitor the groups performance at reasonable intervals throughout the rating period.

2. The employee engagement operational review should speak to the GMs effectiveness in managing the performance measures. The narrative should address performance measure where the GM is meeting or exceeding organizational goals as well as any areas where the GM needs to improve performance measure. The narrative should include recommendations on improvement where appropriate. Action items assigned to the GM should be aligned to processes the GM needs to implement to improve the group’s performance in a specific measure rather than action items for specific cases.




| **Business Results Components** | **Elements** |
| :-: | :-: |
| Group Controls | **Mandatory.** Address the GMs effectiveness in managing the group’s protection of statutes, guiding the timeliness of TFRP assessment processes and monitoring appropriate lien determinations.<br> <br>1. Statute protection, see IRM 1.4.50.11.2 (CSEDs) and IRM 1.4.50.11.3 (ASEDs).<br>      <br>2. ATFR measures, including timely TFRP determinations, timely approval of Form 4183, issuance of Letter 1153 and timely submission to the Control Point Monitor.<br>      <br>3. NFTL determinations, see IRM 1.4.50.11. |
| Currency of Inventory and Timely Case Actions | Evaluate the GMs approach toward achieving the timely and appropriate case actions. Measures include:<br> <br>1. Review the ENTITY Currency of Inventory (COI) report. Assess whether the GM actively working with ROs to develop action plans to resolve aged accounts<br>      <br>2. Lapse in activity. Review the group’s 60-day No-Touch report and ENTITY _MIS Time Code_ report to address excessive administrative and/or miscellaneous direct time. |
| Inventory and Case Assignments | **Mandatory.** Assess the GMs case assignment practices and inventory management for revenue officers in the group.<br> <br>1. Generate the ENTITY _GM Case Assignment,_ ENTITY _Business Indicators Report,_ or the ENTITY _Priority Level Status Report_ to determine if GM is adhering to the cases assignment objectives of Field Collection.<br>      <br>2. Generate ENTITY MIS _Revenue Officer Target Inventory Report_ to evaluate the inventory levels in the group and above graded assignment levels. |


**1.4.50.13.7** **(04-01-2025)**

#### Administrative/Compliance Review

1. The Administrative/Compliance portion of the employee engagement operational review provides an internal control to ensure certain processes or safeguards are performed. Similar to the components of the other employee engagement operational review, the FCM can perform this oversight at any time during the rating period. However, the actions taken to perform this oversight on mandatory review components must be documented in the employee engagement operational review narrative. This documentation must include the action performed and address findings of non-compliance and/or need for improvement.




| **Administrative/Compliance Review Component** | **Elements** |
| :-: | :-: |
| Remittance Processing Controls | **Mandatory.** Confirm the GM performed and documented a remittance control review for each post of duty in the GMs group, see IRM 1.4.50.11.1, Remittance Control Reviews. |
| Security Reviews | **Mandatory.** Review and document the GMs performance of at least one after-hours security review for each post of duty in the GM’s group, see IRM 1.4.50.3.6. |
| Closed Case File Transmittals | Document the GM process for performing quarterly reviews of Form 3210 control copies and reconciliation of acknowledgment copies, see IRM 1.4.50.11.7. |
| FinCEN and CKGE Audits | **Mandatory.**Address whether any revenue officers in the group have FinCEN or CKGE access. In instances where ROs have been granted access to these systems, document your review of the GM’s required annual usage audit of the system. See IRM 1.4.50.11.6 for FinCEN and IRM 1.4.50.11.8 for CKGE. |


**1.4.50.14** **(04-01-2025)**

### Area Director Reviews and Employee Engagement and Operational Reviews

1. During the fiscal year, Area Directors (AD) should perform a comprehensive employee engagement operational review for each territory in their Area. The AD’s employee engagement operational review is used to identify and effect positive change in performance as well as to evaluate the field compliance manager’s (FCM) impact on employee satisfaction, employee engagement, customer satisfaction and business results.

2. Engage the Area’s senior technical analysts to monitor performance metrics and identify trends which may require managerial involvement to achieve the goals and objectives for Field Collection.

3. Perform follow-ups as necessary based upon action items assigned to the Field Compliance Managers for completion.


**1.4.50.14.1** **(04-01-2025)**

#### Planning and Documentation

1. Provide field compliance managers assigned to your territory of your planned review schedule. Also, provide the Director, Field Collection for your territory by November 1st of each year. You may utilize a **data call** document to communicate the items necessary for the FCM to provide in advance of the review.

2. Document the employee engagement operational review in a memorandum to the FCM within 30 calendar days of completion of the review. If the review contains action items for completion by the FCM, provide a response time frame for the FCM’s response.

3. The employee engagement operational review should address the responsibilities of the field compliance manager as they relate to the achievement of the program goals for field collection. The table below provides an optional outline for the components of the area employee engagement operational review:




| **Component** | **Elements** |
| :-: | :-: |
| Leadership | 1. Review the employee engagement operational reviews of the field collection groups completed by the Field Compliance Manager.<br>      <br>2. Address personnel actions to ensure proper processing and Labor Relations involvement where necessary. |
| Employee Satisfaction | 1. Assess whether FCM’s and GM’s address issues raised in the federal employee survey.<br>      <br>2. Evaluate the Leadership Succession Review (LSR) status report for the territory and assess developmental opportunities provided to LSR participants. |
| Employee Engagement | 1. Town hall meetings organized by the FCM with each group in their territory.<br>      <br>2. Address the FCM’s efforts to support the frontline manager cadre, frontline manager readiness program (FLRP) and senior manager readiness program (SMRP). |
| Customer Satisfaction | 1. Taxpayer Rights. Trends and analysis of EQRS Attribute 607, Taxpayer Rights and IRC section 6304, Fair tax collection practices.<br>      <br>2. 1204 Certifications. |
| Business Results | 1. Currency of Inventory.<br>      <br>2. Statute controls and ATFR measures.<br>      <br>3. Inventory assignment practices and inventory levels. |

4. Address additional programs and initiatives that support the goals and objectives of Field Collection, examples include but are not limited to the Territory’s commitment to the fraud program, revenue officer compliance sweeps (ROCS), and support of the abusive tax avoidance transaction (ATAT) program.


**Exhibit 1.4.50-1**

### Revenue Officer Case Assignment Guide

Changes to the systemic grading process were made in 2012. Most cases receive their predicted grade via the Inventory Delivery System (IDS). Case grade is systemically assigned using information from one or more of the following sources:

- Tax returns

- IRP data

- Module data

- Entity level taxpayer data


Those cases not evaluated in the IDS still use the Resources and Workload Management System (RWMS) scores for case grading. The data IDRS uses to assign case grades is shown in the table below, "Manual IDRS Criteria for Grading TDAs and TDIs." IDRS sums the RWMS scores for all Taxpayer Delinquent Accounts (TDAs) on the taxpayer plus the Taxpayer Delinquency Investigation (TDI) entity score, and assigns a grade accordingly.

**IDRS Criteria for Grading TDAs and TDIs**

| **Grade** | **IDRS Criteria for Grading TDAs and TDIs** |
| :-: | :-: |
| **GS-12** | Total RWMS score for entity = 30,001 or higher |
| **GS-11** | Total RWMS score for entity = 0 to 30,000<br> <br>- Potentially dangerous taxpayers (unless they meet GS–12 criteria)<br>  <br>- TDAs for Forms 1041, 730, 706, 709 (unless they meet GS–12 criteria) |

You may consider non-IDRS work items in determining the correct grade for a case. Other investigations (OIs) and offers in compromise (OICs) generally have the same grade as the underlying accounts. Ols for routine assignments, such as serving a Notice of Levy or summons, are GS-11 work. Higher graded Ols include:

**Non-IDRS investigations, OIs**

| **Grade** | **OIs** |
| --- | :-: |
| **GS-13** | Expert witness requests and all other cases meeting grade 13 criteria in the OPM classification standards for revenue officers. |
| **GS–12** | Investigations for Department of Justice; complicated decedent cases and insolvencies; all other cases meeting grade 12 criteria in the OPM classification standards for revenue officers. |
| **GS–11** | Investigations for U.S. Attorney and area counsel; investigations requiring special handling; investigations on decedents, insolvencies, potentially dangerous taxpayers; all other cases meeting grade 11 criteria in the OPM classification standards. |

Under the title**Manual Criteria for Grading TDAs and TDIs**you will find the criteria you can use to grade cases manually. Use the following criteria for regrading cases after assignment to revenue officers.

### Caution:

You will not normally change the grade of a case unless it meets at least three of the four factors at the lower or higher level.

### Note:

Managers will document in the case history the reason for not using at least three of the four factors when applicable.

### Reminder:

When evaluating total positive income (TPI) for Factor 1, Nature of Entity, consider all applicable income fields from the income tax return. That is, the sum of all income that was (or should have been) reported on an individual's income tax return. Losses are treated as zero.

The factors are:

**Manual Criteria for Grading TDAs and TDIs-Nature of Entity**

| **Grade** | **Factor 1 - Nature of Entity** |
| --- | :-: |
| **GS-13** | 1. BMF Cases: Total gross income greater than $4M or total assets greater than $5M or revenues that are required to meet this level of assets/ expenses. For example, financials may show gross income of less than $4M, but facts reflect the business pays expenses that exceed $4.2M.<br>   <br>2. IMF Cases: Self-employed individuals with a total positive income (TPI) greater than $262K or assets/expenses that would require this level of income to maintain or obtain these assets/expenses. |
| **GS-12** | 1. BMF Cases: Total gross income $262K to $4M or total assets $1M to $5M.<br>   <br>2. IMF Cases: Self-employed individuals with a total positive income (TPI) greater than $185K. |
| **GS-11** | 1. BMF Cases: Total gross income less than $262K or total assets less than $1M.<br>   <br>2. IMF Cases: Total positive income (TPI) less than $185K. |

**Manual Criteria for Grading TDAs and TDIs-Range of Case Issues**

| **Grade** | **Factor 2 - Range of Case Issues** |
| --- | --- |
| **GS-13** | 1. Cases requiring investigation into complex subterfuges that conceal income and assets and delay collection. Examples include, wire transfers, multiple sets of books, 1040NR filing requirements, ATAT cases and cases involving extensive involvement with Counsel.<br>   <br>2. Unique or sensitive forms of assets and income that may also require coordination with Federal, State & Local Agencies. Examples include hazardous materials, gambling, hospitals, care centers, professional sports teams, large companies and estates with assets greater than $10M, counties or municipalities with a population greater than 100,000 or a budget in excess of $10M, state governmental agencies, employee leasing companies or e-commerce internet businesses.<br>   <br>3. Income reported is at least 10 percent less than required to support assets with no clear explanation or basis (e.g. minimal income with substantial assets; individuals with no assets and no income but a high standard of living).<br>   <br>4. Highly complex forms of ownership designed to shield income or assets. Examples include multi-layered entities, LLCs with one or more non-individual members, two or more asset trusts, intermediary cases or offshore entities.<br>   <br>5. Cases requiring complex investigative techniques that require methods not specifically described in relevant IRMs, such as nominee/alter ego investigations, Indian tribal issues, injunctions, repatriation investigations, jeopardy assessments/levies where the taxpayer has concealed ownership, assets in multiple states, 1099 OID income in excess of $100,000, fuel tax credits, Form 1041 filings as part of an abusive scheme or identity theft related to three or more identities resulting in loss to the government.<br>   <br>6. Entities with complex financial structure and multiple business entity relationships, including parent corporations or entities with three or more subsidiaries or large federal contractor cases.<br>   <br>7. Joint investigations with Exam, CI, and DOJ on abusive scheme promoters, settlement initiatives, parallel investigations and ATAT cases. |
| **GS-12** | 01. In depth, detailed financial investigations involving sophisticated and difficult issues (e.g. electronic funds transfers between multiple accounts) (ATAT cases included).<br>    <br>02. Income and assets that are difficult to trace, specialized, highly valuable or unique.<br>    <br>03. Imbalance between income and assets with no clear explanation (e.g. income is not enough to support existing assets).<br>    <br>04. Complex forms of ownership designed to shield income or assets (e.g. LLC’s, offshore entities, transactions, fraudulent conveyances, and family relationships).<br>    <br>05. Complex investigative techniques (e.g. nominee, alter ego, suits, jeopardy levies).<br>    <br>06. Large business entities with standard financial structure or mid-size size business with multiple entity relationships and a complex financial structure.<br>    <br>07. Regular interaction with Counsel, Exam, CID, and Appeals.<br>    <br>08. A non-U.S. citizen or non-resident alien living in a foreign country filing Form 1040NR.<br>    <br>09. A non-U.S. citizen living in a foreign country, who met the substantial presence test and has a Form 1040 filing requirement.<br>    <br>10. BMF cases, where the owner of a sole prop or officers/members of a partnership, LLC or Corporation are not U.S. citizens. |
| **GS-11** | 1. Cases may involve basic financial investigations and analysis, requiring only routine verification of income or assets (including summonses) some investigations may be moderately more complex.<br>   <br>2. Income and assets may be easily identified or may be difficult to trace and identify.<br>   <br>3. Some imbalance between income and assets, but able to identify reason.<br>   <br>4. Cases may include businesses with simple forms of ownership or may be moderately more complex (e.g. LLC’s).<br>   <br>5. Standard investigative techniques, including TFRP investigations. Assets may be subject to competing lien claims and may be difficult to determine rights (e.g. discharges, subordinations, redemptions, foreclosure, suits, etc.).<br>   <br>6. Small to mid-size business entities with standard financial structure or small business with multiple entity relationships and a complex financial structure.<br>   <br>7. Some interaction with Counsel, Exam, CID, and Appeals. |

**Manual Criteria for Grading TDAs and TDIs-Impact of Enforcement Actions**

| **Grade** | **Factor 3 - Impact of Enforcement Action** |
| --- | --- |
| **GS-13** | 1. Cases with extensive economic impact including businesses with assets over $10M or more than 60 employees. Enforcement actions which would have a ripple effect for related entities or feeder industries (e.g. a large factoring company that has multiple businesses relying on factoring funds, refer to Factor 1 criteria).<br>   <br>2. Potential for intense, recurring media scrutiny and strong public reaction that has a regional/national audience such as network television/ratio entities or national magazines/ newspapers.<br>   <br>3. Far-reaching regional or national compliance impact by initiating suits and civil injunctions both to prevent pyramiding and against promoters or entities marketing ATAT related products. Cases may be ATAT coded or involve high-profile individuals. |
| **GS-12** | 1. Pronounced community or economic impact (e.g., large to medium business: action impacting > 31 employees).<br>   <br>2. Potential for media scrutiny and public reaction.<br>   <br>3. State or local compliance impact. |
| **GS-11** | 1. Moderate community or economic impact (e.g., medium business: action impacting between >30 employees).<br>   <br>2. May involve media coverage. |

**Manual Criteria for Grading TDAs and TDIs-Personal Contacts**

| **Grade** | **Factor 4 - Personal Contacts** |
| --- | :-: |
| **GS-13** | 1. Representatives to include partners or principals from prominent accounting and/or law firms and financial institutions that command upscale fee structures. Cases that may have complex strategies, multiple representatives for the same issue or require sophisticated interview techniques and complexity awareness.<br>   <br>2. Cases involving nationally known individuals including political figures, entertainers, sports figures and influential individuals or businesses.<br>   <br>3. Business locations in multiple states with >60 employees.<br>   <br>4. Cases requiring ongoing involvement with Chief Counsel, Area Counsel, Department of Justice and the U.S. Attorney’s office. Cases requiring expert testimony.<br>   <br>5. Case requiring on-going involvement with Exam, CI or Appeals.<br>   <br>6. Multiple suit/ nominee/ transferee recommendations arising from a single case.<br>   <br>7. Owners or corporate officers of foreign entities reporting complex business transactions, or international issues including treaties. |
| **GS-12** | 1. Representatives from large state and regional accounting firms, law firms, and financial institutions.<br>   <br>2. Large business owners or corporate officers, often well known within the State. State and local political figures. High profile individuals or organizations/individuals at the state or local level.<br>   <br>3. Routine interaction with Area Counsel, Exam, CID, Appeals, and other internal stakeholders.<br>   <br>4. Owners or corporate officers of foreign entities reporting limited transactions (e.g., foreign return penalty assessments, asset ownership with no or limited financial transactions). |
| **GS-11** | 1. Representatives from moderate size local accounting firms, law firms, and financial institutions. Representatives from national tax debt collection firms.<br>   <br>2. Small to mid-size business owners, LLC members or corporate officers of mid-size companies, often well known in the immediate geographic area. Interaction with state and local taxing authorities to address competing lien interests.<br>   <br>3. Limited interaction with Area Counsel, Exam, CID, and Appeals after consultation with the group manager. |

**Exhibit 1.4.50-2**

### Criteria for Review of Completed Work

**Currently Not Collectible Accounts**

| **If** | **Then** |
| :-: | :-: |
| **Hardship** | check the Collection Information Statement (CIS)- is it less than one year old? Check Form 53 for accuracy, completeness, and correct closing code. Are all modules on IDRS SUMRY included? Were appropriate TC 130 inputs requested in accordance with IRM 5.16.1.2.1(14)<br> <br>01. Has RO analyzed CIS?<br>    <br>02. If equity in assets, should accounts be reported CNC? Was equity verified and the value either collected or accounted for?<br>    <br>03. Has information on CIS been appropriately verified?<br>    <br>04. Has an NFTL determination been made?<br>    <br>05. Does case meet criteria for installment agreement instead?<br>    <br>06. Has all pertinent information, including results of full compliance check and summarizing entry been documented in history?<br>    <br>07. Have taxpayer rights been documented?<br>    <br>08. Has an offer-in-compromise been considered?<br>    <br>09. Have allowable expenses been used accurately and any deviations documented and explained?<br>    <br>10. Have third party contacts been recorded?<br>    <br>11. Have all open filing requirements been resolved?<br>    <br>12. Has the case closing letter been issued?<br>    <br>13. Has an observational field call been performed. |
| **Hardship cases where the UBA exceeds the amount in IRM 5.16.1.2.9(8)** | confirm the following additional investigative actions were performed:<br> <br>1. Was the CIS compared to the taxpayer's total positive income on the last filed return using RTVUE/TRDBV?<br>   <br>2. Were return schedules reviewed to determine ability to pay and whether discrepancies exist between returns and CIS?<br>   <br>3. Were information sources such as IRPTR/IRPTRJ used to resolve discrepancies?<br>   <br>4. On-line locator services, such as Accurint. |
| **Hardship cases where the UBA exceeds the amount in IRM 5.16.1.2.9(8)** | confirm the following additional investigative actions were performed:<br> <br>1. Courthouse records check, on-line or in person for real property ownership.<br>   <br>2. Motor vehicle records or Accurint (if motor vehicle records are available in the state where the taxpayer is located.)<br>   <br>3. FATCA records check. |
| **Hardship cases where the UBA exceeds the amount in IRM 5.16.1.2.9(9)** | confirm the following additional investigative actions were performed:<br> <br>1. Full credit report on IMF, sole proprietor taxpayers and LLCs where an individual owner is identified as the liable taxpayer.<br>   <br>2. Did RO perform Financial Crimes Enforcement Network (FinCEN)research using FinCEN Query (FCQ) when IRPTR reflects that a taxpayer has filed a Foreign Bank Account Reporting (FBAR)?<br>   <br>3. CC AMDIS, if there is a -L freeze on the account.<br>   <br>4. Audit File or Special Agents Report if the assessment in Examination or Criminal Investigation. |
| **Unable to Contact-Unable to Locate for accounts with a UBA balance of less than the amount in IRM 5.16.1.2.1(4)** | check Form 53 for accuracy, completeness, and correct closing code. Are all modules shown on IDRS SUMRY included? Were appropriate TC 130 inputs requested in accordance with IRM 5.16.1.2.1(14) and confirm the following additional investigative actions were performed:<br> <br>1. An Appointment Letter sent to the taxpayer’s last known address.<br>   <br>2. An observational field call to the taxpayer’s (Tp’s) last known address<br>   <br>3. An attempt to contact the Tp by phone<br>   <br>4. Research of on-line services such as Accurint.<br>   <br>5. All levy sources be addressed.<br>   <br>6. Review of the Tp’s last filed return if filed within the past two years.<br>   <br>7. Has the NFTL determination been made?<br>   <br>8. Has all pertinent information been documented in history?<br>   <br>9. Have third party contacts been recorded? |
| **Unable to Contact-Unable to Locate for accounts where the UBA exceeds the amount in IRM 5.16.1.2.1(5)** | confirm the following additional investigative actions were performed:<br> <br>1. Postal tracers.<br>   <br>2. Motor vehicle records.<br>   <br>3. Real and personal property checks.<br>   <br>4. Employment commission information.<br>   <br>5. FinCEN research when IRP reflects FBAR information. |
| **Unable to Contact-Unable to Locate for accounts where the UBA exceeds the amount in IRM 5.16.1.2.1(6)** | confirm the following additional investigative actions were performed:<br> <br>1. Courthouse records check, on-line or in person for real property ownership.<br>   <br>2. Motor vehicle records or Accurint (if motor vehicle records are available in the state where the taxpayer is located.)<br>   <br>3. FATCA records check. |
| **Unable to Contact-Unable to Locate for accounts where the UBA exceeds the amount in IRM 5.16.1.2.1(7)** | confirm the following additional investigative actions were performed:<br> <br>1. Full credit bureau report on IMF, sole proprietor taxpayers and LLCs where the individual owner is identified as the liable taxpayer.<br>   <br>2. CC AMDIS if there is a -L freeze on the account. |
| _Defunct Corporations, Exempt Organizations, Limited Partnerships, and Limited Liability Companies_ | 1. Defunct corporations, exempt organizations, limited partnerships and LLCs.<br>   <br>2. Observational field call to the last known address.<br>   <br>3. Has trust fund recovery penalty been recommended if appropriate?<br>   <br>   <br>   <br>### Note:<br>   <br>   <br>   <br>If the Bal Due modules are being reported CNC prior to sending Form 2749 to CPM on ATFR, an Other Investigation (OI) will be created on ICS to control the TFRP case until the Form 2749 has been submitted to CPM. See IRM 5.16.1.2.6(6), Defunct Corporations, Exempt Organizations, Limited Partnerships and Limited Liability Companies. |
| **In-Business and Defunct Corporations, Exempt Organizations, Limited Partnerships, and Limited Liability Companies. If the entity is in-business, review for the following:** | 1. Is the taxpayer in compliance and has the taxpayer agreed to remain current?<br>   <br>2. Have trust fund compliance program procedures including issuance of Letter 903 been considered? See IRM 5.7.2, Letter 903 Process.<br>   <br>3. Does Form 53 have a mandatory follow-up scheduled in 18 to 24 months? |
| I**n-Business and Defunct Corporations, Exempt Organizations, Limited Partnerships, and Limited Liability Companies****For UBA less than the amount in IRM 5.16.1.2.6(7) require the following investigative steps:** | 1. An observational field call to the taxpayer’s last known address.<br>   <br>2. Secure a CIS if possible.<br>   <br>3. Address all levy sources. |
| **In-Business and Defunct Corporations, Exempt Organizations, Limited Partnerships, and Limited Liability Companies****Cases where the UBA exceeds the amount in IRM 5.16.1.2.6(8) require the following additional investigative steps:** | 1. Review the last filed income tax return or the return information using CC BRTVU/TRDBV if the last filed return was both due and filed within the last two years.<br>   <br>2. Review Accurint for real and personal property.<br>   <br>3. Motor vehicle records or Accurint if motor vehicle records are available on Accurint in the state where the entity is located.<br>   <br>4. Courthouse records checks, on-line or in person to verify real or personal property.<br>   <br>5. State employment records. |
| **In-Business and Defunct Corporations, Exempt Organizations, Limited Partnerships, and Limited Liability Companies****Cases where UBA exceeds the amount in IRM 5.16.1.2.6(9) require the following additional investigative steps:** | 1. Check local licensing authorities when the taxpayer operates a business that requires licensing.<br>   <br>2. Bank record analysis to confirm there is no business activity. |
| **In-Business and Defunct Corporations, Exempt Organizations, Limited Partnerships, and Limited Liability Companies****Cases where UBA exceeds the amount in IRM 5.16.1.2.6(10) require the following additional investigative steps:** | 1. Review a copy of the examination report if the assessment is the result of an examination or fraud penalty.<br>   <br>2. CC AMDIS when there is a -L freeze on the account. |

**Installment Agreements**

| **If** | **Then** |
| :-: | :-: |
| **General** | 1. Have all applicable taxpayer rights been documented?<br>   <br>2. Has full compliance been discussed, documented and totally accounted for in the agreement?<br>   <br>3. Check the CIS, is it current and complete?<br>   <br>4. Does the agreement provide for full payment prior to the CSED? If not, has it been identified as a partial pay installment agreement (PPIA)?<br>   <br>5. Have TC 971 AC 043 and AC 063 been input when appropriate?<br>   <br>6. Have prior IA proposals been sent to the Independent Reviewer prior to rejection?<br>   <br>7. Has the NFTL filing determination been made?<br>   <br>8. Has the correct ICS closing method been selected (i.e., Routine, Streamlined, etc.), as appropriate? |
| **BMF Agreements** | Has cause and cure of the delinquency been addressed?<br> <br>1. Are FTDs current?<br>   <br>2. Have trust fund compliance program procedures been considered? See IRM 5.7.2, Letter 903 Process.<br>   <br> If appropriate, has trust fund recovery penalty been recommended?<br> <br>### Note:<br>If you approve an installment agreement before sending Form 2749 to CPM on ATFR, ensure that an Other Investigation (OI) is created on ICS to control the TFRP case until the Form 2749 has been submitted to CPM. See IRM 5.14.7.4.1(12), Trust Fund Recovery Penalties and Installment Agreements.<br>### Exception:<br>If it is determined that the TFRP will not be recommended per IRM 5.7.4.8.1 no OI is necessary.<br>1. If the TFRP assessment will be suspended while the BMF taxpayer remains compliant with the installment agreement, ensure that the TFRP assessment has been added to the BMF IA to be placed in Status 63 and the TC 130 reversed.<br>   <br>2. Has RO secured a waiver from all potentially responsible persons to extend the ASED?<br>   <br> Has the correct ICS closing method been selected? For example, Routine (TP is OOB with no open employment tax filing requirements), IBTF/IBTF Express (TP is in business with employees), etc. |
| **BMF Agreements where If the entity is a disregarded LLC and owes for both pre- and post 01/01/2009 liabilities.** | Have the procedures in IRM 5.14.7.3.2, Installment Agreements When Owner (SMO) and LLC are Liable for Assessments in LLC Name, been followed for establishment of an SMO/LLC IBTFIA? |
| **Direct Debit Installment Agreements, Routine and Streamlined** | 1. Were the procedures in IRM 5.14.10.4, Direct Debit Installment Agreements-Direct Debit Installment Agreements, followed when establishing the agreement?<br>   <br>2. Was the Form 433-D containing the TP signature, bank information and GM’s signature (if applicable) scanned and e-mailed to CCP DDIA ?<br>   <br>3. Was the closed case file sent under cover of the generated Form 3210 to CCP at Mail Stop 5-E04.115? |
| **Direct Debit Installment Agreements, IBTF and IBTF Express** | 1. Was the agreement established per the guidelines in IRM 5.14.10.5 Direct Debit Installment Agreements-Direct Debit Installment Agreements for IBTF Cases.<br>   <br>2. Upon approval was the Form 433-D containing the TP signature , bank information and GM’s signature (if applicable) scanned and emailed to CCP DDIA<br>   <br>3. For IBTF-Express DDIAs, was the closed case file sent under cover of the generated Form 3210 to CCP at Mail Stop 5-E04.115.<br>   <br>4. For IBTF-IA DDIAs, was the case file sent to CCP **for monitoring** under cover of the generated Form 3210 (Mail Stop 5-E04.117). |
| **Partial Payment Installment Agreements. For accounts where the UBA exceeds the amount in IRM 5.14.2.2.1(3)** | If there is significant equity that cannot be liquidated, the following minimum verification is required:<br> <br>1. Real property records.<br>   <br>2. Motor vehicle records.<br>   <br>3. personal property records.<br>   <br>4. FATCA data research. |
| **Partial Payment Installment Agreements. For accounts where the UBA exceeds the amount in IRM 5.14.2.2.1(4)** | In addition to the above, the following additional investigative steps must be taken:<br> <br>1. A full credit report.<br>   <br>2. CC AMDIS where there is a -L freeze on the account.<br>   <br>3. RAR or SAR if the assessment originated in Examination or Criminal Investigation. |

**Trust Fund Recovery Penalty**

| **If** | **Then** |
| :-: | :-: |
| **Initial actions** | 1. Has RO taken into account all periods of liability?<br>   <br>2. Have all responsible persons been interviewed?<br>   <br>3. Have those interviewed signed Form 4180?<br>   <br>4. Have potentially responsible individuals been given their rights? Was L3164A issued prior to third party contacts such as TFRP summons?<br>   <br>5. Have third party contacts been recorded where applicable?<br>   <br>6. Has the TFRP been explained and page 4 of the Form 4183 been delivered to the potentially responsible individuals? |
| **Preparation of Form 4183, Recommendation for Assessment** | 1. Is all applicable information documented on Form 4183?<br>   <br>2. Is basis for recommendation adequately explained including the aspects of willfulness and responsibility?<br>   <br>3. Has collectibility been addressed?<br>   <br>4. Have core documentation items been secured and documented? Does core evidence cover all periods being recommended for assessment?<br>   <br>5. If a core documentation item was not secured, is the reason documented in the ICS history? IRM 5.7.4.5(6), Investigation and Recommendation of the TFRP-Form 4183 Penalty Assessment Recommendation a brief ICS history addressing missing core documentation items should be made by the RO prior to sending the TFRP file to CPM.<br>   <br>   <br>   <br>### Note:<br>   <br>   <br>   <br>Request for input of TC 130 no longer needs to be made manually. That input is now generated systemically based on ATFR inputs. |
| **Preparation of Form 4183, Recommendation for Assessment, but currently CNC** | If future collection potential exists, but account is currently not collectible, have pre-assessment procedures been considered?<br> <br>1. Has trust fund recovery penalty been recommended on Form 4183?<br>   <br>2. Has Form 53 been prepared?<br>   <br>3. Has Form 2749 been annotated to the effect that Form 53 prepared?<br>   <br>4. Has taxpayer been advised that one notice will be sent?<br>   <br>5. Has taxpayer been advised that Notice of Federal Tax Lien will be filed, if appropriate? |
| **Preparation of Form 9327, Recommendation for Non-Assessment** | 1. If individual considered not responsible, case history as well as Form 4183 should contain full explanation, including the aspects of willfulness and responsibility.<br>   <br>2. If recommendation for non-assertion is because it is not collectible, does it meet the relevant criteria? On Form 9327, Section II you must ensure all items are addressed. Action dates entered should correspond to the research or review actions in the ICS history. If an item was not completed, the RO should document ICS with the reason, such as: taxpayer would not provide a CIS and RO determined summons not appropriate. |
| **Preparation of Form 9327, Recommendation for Non-Assessment** | If future collection potential appears to be nonexistent because of advanced age and/or deteriorating health:<br> <br>1. Has taxpayer’s latest income tax return been reviewed?<br>   <br>2. Has a current CIS been secured and verified?<br>   <br>3. Has a full compliance check been conducted and fully documented? |
| **Trust Fund Recovery Penalty Dispositions-No Response, Unagreed Cases** | No Response-Unagreed Cases.<br> <br>1. For regular assessments, have the procedures in IRM 5.7.6.12, Revenue Officer Assessment Actions. and IRM 5.7.6.2.1, No Response (Unagreed) Cases, been followed?<br>   <br>2. For prompt & quick assessments, have the procedures in IRM 5.7.6.13, Quick and Prompt Assessment Actions, been followed?<br>   <br>3. Has ATFR been updated and the case correctly routed to CPM? |
| **Trust Fund Recovery Penalty Dispositions-Unagreed, Appealed** | If assessment being appealed, has taxpayer complied with requirements stated on reverse of Letter 1153?<br> <br>1. Was the appeal received timely? See IRM 5.7.6.2(1), Responsible Person’s to Letter 1153.<br>   <br>2. Does the case file and history confirm there is sufficient basis and documentation to support the assertion of the proposed assessment?<br>   <br>3. The protest letter must contain sufficient information to process the appeal. |
| **Trust Fund Recovery Penalty Dispositions-Ex Parte Considerations** | 1. Review the TFRP case file and histories to ensure no ex parte communications are included before approving transmittal of the case to the CPM.<br>   <br>2. Document ICS history with your concurrence.<br>   <br>3. Refer to guidance for manager actions in IRM 5.7.6.9, Trust Fund Penalty Assessment Action-Revenue Officer Disagrees with Protest, if the TFRP case file or history contains ex parte communications which should either be shared with the taxpayer or removed. |
| **Trust Fund Recovery Penalty Dispositions, Forwarding to Appeals** | is case file adequately prepared for transmittal to Appeals through CPM?<br> <br>1. All information and documents submitted in support of a protest should be included in the file.<br>   <br>2. Documents forming the basis of the penalty recommendation should be in the file.<br>   <br>3. All documents should be arranged in order of receipt (with the latest on top) under the appropriate case file tabs.<br>   <br>4. All duplicate items should be removed from file.<br>   <br>5. Has ATFR been updated? |
| **Trust Fund Recovery Penalty Dispositions-Agreed Cases** | 1. For regular assessments, have the procedures in IRM 5.7.6.12, Revenue Officer Assessment Actions, and IRM 5.7.6.3, Agreed Cases, been followed?<br>   <br>2. For prompt assessments, have the procedures in IRM 5.7.6.13, Quick and Prompt Assessment Actions, been followed? |
| **Trust Fund Recovery Penalty Cases-Other Dispositions** | 01. OIC Closure Approval-Obsolete.<br>    <br>02. Return Case to the queue- only used when a cases is updated to queue assignment on ICS.<br>    <br>03. IBIA- used when the requirements in IRM 5.7.4.8.1(4) , Considerations for In-Business Installment Agreements, are met.<br>    <br>04. LLC – cases determined to be treated as a disregarded entity where all assessments are for periods prior to 01/01/2009 and no trust fund potential.<br>    <br>05. Corporate Case Full Paid- TFRP amount has been calculated to be fully paid.<br>    <br>06. Below IRM Criteria- Cases meeting criteria in IRM 5.7.4.2.1 , Factors When Considering Trust Fund Balance Owed Amounts.<br>    <br>07. Created in Error/Other- case created in error or assigned after all ASEDs have expired.<br>    <br>08. Opened in Error/Partnership- cases determined to be partnership entities with no trust fund potential.<br>    <br>09. Opened in Error/Sole Prop- cases determined to be Sole Proprietorships with no trust fund potential.<br>    <br>10. All Parties Not Responsible and/or Form 9327 - manager has approved Form 4183 with the appropriate Not Responsible or Not Collectible (Form 9327) determination. See note below.<br>    <br>11. All Parties Non-Assert Form 9327 Only- manager has approved Form 4183 with the appropriate Not Collectible (Form 9327). See note below.<br>    <br>    <br>    <br>    ### Note:<br>    <br>    <br>    <br>    On Form 9327 Section II you must ensure all items are addressed. Action dates entered should correspond to the research or review actions in the ICS history. If an item was not completed, the RO should document ICS with the reason, such as: taxpayer would not provide a CIS and RO determined summons not appropriate. |

**Other Case Actions**

| **If** | **Then** |
| :-: | :-: |
| **Request for Adjustment**<br>### Note:<br>If the Form 3870 is related to Identity Theft, ensure the guidance in IRM 5.1.28, Identity Theft for Collection Employees, is followed. | Is supporting documentation attached? Has the adjustment been explained to the taxpayer, i.e., reasons for full or partial relief?<br> <br>1. Is a closing code required? When the requested action will satisfy the module, the module can be closed as Adjustment on ICS. ICS automatically uploads TC470 CC90 (on status 26 modules) upon managerial approval of these closings. If the requested action will not fully satisfy the account, the remaining balance should be full paid or resolved by installment agreement or currently not collectible determination.<br>   <br>2. Is there an entry in Items 1, 2, 3, 4, 5, 6, 7, 10, 11, 12, 13, 14, 29 and 30 of Form 3870?<br>   <br>3. Has taxpayer signed the form in Item 12 or is taxpayer’s letter or request attached?<br>   <br> If less than 12 months remain in the statutory period for collection, has the Form 3870 been flagged for expedite action? See IRM 5.1.15.5(7), Adjustments-General Procedures Form 3870.<br> <br>1. If less than 6 months remain in the statutory period for collection, the Bal Due should remain in RO’s inventory and no closing code entered on Form 3870.<br>   <br>2. If 6 to 12 months remain in the statutory period for collection the Bal Due should be closed and closing code should be entered on Form 3870. See Exhibit 1.4.50-2 (3)(a).<br>   <br> In cases involving requests for abatement of penalties, have the criteria for reasonable cause been met?<br> <br>1. Is the reason for noncompliance documented in writing by taxpayer?<br>   <br>2. Does the reason include sufficient detail to determine whether ordinary business care was exercised?<br>   <br>3. Was the penalty the result of carelessness or forgetfulness?<br>   <br>4. Does the amount of penalty justify closer scrutiny of the case?<br>   <br> If the adjustment will result in full payment and the collection investigation on the taxpayer is concluded, has the case closing letter (if appropriate) been prepared pending GM approval?<br> <br>### Note:<br>The Refund Statute Expiration (RSED) is generally three years from the Return Due Date or Extended Due Date for prepaid credits if a return was filed, or two years from the payment date for other payments, whichever is later. See IRM 26.6.1.10.3.3, Claims for Credit or Refund-General Time Period for Submitting a Claim, and the exceptions to the general period in IRM 25.6.1.10.3.7, Exceptions to the Period of Limitations.<br>### Note:<br>See IRC 6511: If the module credit created by the posting of an adjustment exceeds the amount of the credit that can be refunded or offset due to the recomputation of tax, penalties or interest, the revenue officer must transfer the barred portion of the overpayment to Excess Collections via Form 8758, Excess Collections File Addition and forward to CCP. A manual refund may be needed to allow the correct refund.<br>### Note:<br>Check to ensure the revenue officer has made an RSED determination, has documented in ICS, and has input required RSED date on applicable Form 3870. This will apply to all Forms 3870 routed to CCP except Forms 3870 for TFRP, TIN, CAWR/FUTA or SFR. |
| **Payment Tracer** | Has the request been made on Form 4159, Payment Tracer Request? If the credit transfer will result in full payment and the collection investigation on the taxpayer been concluded, has the case closing letter been issued? Has sufficient information been furnished to trace the payment including:<br> <br>1. Copy of payment, front and back?<br>   <br>2. Name, address and TIN of taxpayer?<br>   <br>3. Type and period of tax?<br>   <br>4. Amount, type and date of remittance.<br>   <br>5. Endorsing IRS office if check, money order, etc?<br>   <br>6. Date of IRS endorsement?<br>   <br>7. Date of receipt, receipt number, and type of receipt? |
| **Credit Transfer** | 1. Has the request been made on Form 2424, 3870 or 4159?<br>   <br>2. Has the module containing the credit been identified?<br>   <br>3. Has the module to receive transfer of the credit been identified?<br>   <br>   <br>   <br>### Note:<br>   <br>   <br>   <br>Check to ensure the RO has made an RSED determination, documented the ICS history and input the RSED on the applicable form.<br>   <br>4. Has the taxpayer been informed of the transfer? |
| **Seizure-Pre Seizure Considerations** | See IRM 5.10.1, Pre-Seizure Considerations- verify the following prior to seizure:<br> <br>01. No prohibited seizure proposed.<br>    <br>02. Liability verified.<br>    <br>03. Alternatives considered/risk analysis.<br>    <br>04. Net proceeds determination.<br>    <br>05. Records check <90 days before approval.<br>    <br>06. Individual Taxpayer - Exempt assets considered.<br>    <br>07. Individual Taxpayer - Business assets/other assets were considered.<br>    <br>08. NFTL filed on all modules shown on 668-B; Letter 3174 sent if appropriate. See IRM 5.10.1.5.3.3(5).<br>    <br>09. Letter 1058 sent for all modules on Form 668-B at least 30 days prior to seizure/additional warning if + 180 days and no enforcement.<br>    <br>10. Pub 1, 1660, 594 delivered. See IRM 5.10.1.6.1.<br>    <br>11. PALS contacted to discuss FMV, expenses of sale.<br>    <br>12. Attempt made to personally advise taxpayer of proposed seizure/911/TAS/GM.<br>    <br>13. Ensure the appropriate level of approval was obtained for the particular type of asset. See Exhibit 5.10.2-1. |
| **Seizure-Post Seizure Considerations** | Post-seizure Considerations.<br> <br>1. Has Form 2433, Notice of Seizure , been prepared correctly and timely?<br>   <br>2. See IRM 5.10.2.7, Contracting for Services, for procedures involving expenses associated with the seizure.<br>   <br>3. If applicable, were appropriate release documents issued?<br>   <br>4. Has the RO submitted the opening documents for transmittal to Advisory?. The opening documents need to be transmitted (through the group manager) to Advisory within 5 workdays after seizure. See IRM 5.10.3.9.2, Disposition of Notice of Seizure and Opening Documents for the Seizure. |
| **Delinquent Returns** | General<br> <br>1. Has full compliance been documented in the ICS history?<br>   <br>2. Has the appropriate ICS closing option been used and the reason for the use documented in the ICS history?<br>   <br> Reasonable cause determinations when delinquent returns secured.<br> <br>1. Has reasonable cause criteria been met?<br>   <br>2. Is a written statement from the taxpayer or a Form 4364, Delinquency Computations attached?<br>   <br> Returns without full payment.<br> <br>1. Has taxpayer been contacted and demand made for full payment of the liability?<br>   <br>2. Has pre-assessment action been taken?<br>   <br>3. Has a control (e.g., ICS-only module, request for case assignment) been established to complete the investigation if the liability is not resolved by full payment, installment agreement, or CNC, and there will be no continuing open assignment?<br>   <br> Minimal or no tax due on returns, (P-5-133).<br> <br>1. Has the anticipated tax due for each period been computed and documented in the ICS history?<br>   <br>2. Has the basis for the determination been fully documented?<br>   <br> Returns prepared under IRC 6020(b).<br> <br>1. Has Form 5604, Section 6020(b) Action Sheet, been prepared correctly?<br>   <br>2. Has liability been computed accurately?<br>   <br>3. Does documentation adequately explain the basis for requesting the assessment?<br>   <br>4. Are the returns signed and is the statement pertaining to IRC 6020(b) typed or printed at bottom of return? |
| **Collection Due Process Cases** | General Considerations.<br> <br>1. Has the type of hearing request, CDP or Equivalent, been correctly determined?<br>   <br>2. If new information or alternatives arose after the request was filed and the taxpayer was willing to work with Collection, was contact made with the taxpayer in an effort to resolve the issue?<br>   <br>3. Does the case require GM contact? |
| **Collection Due Process Cases-Ex Parte Considerations** | Ex Parte Considerations.<br> <br>1. Confirm that any narrative statement included on the Form 14461, Transmittal of the CDP/ Equivalent Request Hearing, is limited to a neutral list of documents and neutral statements regarding actions taken and documented in the case history without any further discussion regarding the strengths and weaknesses of the taxpayer’s appeal.<br>   <br>2. The manager must ensure the requirement in (1) above is met and that no prohibited ex parte communications are included before approving the transmittal of the case to Appeals. See IRM 5.1.9.5, Communications with Appeals. |
| **Offer In Compromise Cases** | 1. Is the offer package being forwarded to the correct COIC site and within 24 hours of 656 receipt?<br>   <br>2. Is Form 657 complete and attached? Have you signed the Form 657 if the RO has made a solely to delay determination?<br>   <br>3. Is the Form 656 date stamped?<br>   <br>4. Is the CIS and substantiation attached?<br>   <br>5. Are Forms 2848 and 656A included (if applicable)?<br>   <br>6. Have the applicable fees and deposits been attached?<br>   <br>7. Has the TFRP been completed or the taxpayer warned that the OIC will not be investigated until the penalty is assessed as applicable?<br>   <br>8. Is Form 3210 attached? |
| **Summons** | Is this a third-party summons (including TFRP)? See IRM 25.5.1.2.3 , Authority to Issue Summonses Requiring Approval (Except “John Doe” Summonses).<br> <br>1. If yes, GM approval is required before the summons is served. Ensure the ICS case history is documented to reflect the approval was secured. Ensure the summons is prepared correctly before approving. See IRM 25.5.2.2, Preparation and Use.<br>   <br>2. It is important the manager recognizes their approval of a third party summons serves to certify that taxpayer rights provided in IRC 7602(c) were protected by issuance of Letter 3164A. See IRM 25.27.1.3, Notification Requirements. |
| **Statutes** | 1. Has the CSED been manually recalculated? See IRM 5.1.19, Collection Statue Expiration? If yes, has the RO documented the ICS case history with the steps to manually calculate the updated CSED?<br>   <br>2. GM approval of manual CSED updates indicates the updated CSED calculation was reviewed and determined to be accurate, see IRM 5.1.19.5, Imminent CSEDs. |
| **Suits** | 1. In all cases, GM concurrence is needed before a suite package is sent to CEASO for review, see IRM 25.3, Litigation and Judgments.<br>   <br>2. If the suit development is complex or fact-intensive where additional time is needed to gather the facts necessary for develop the recommendation, the case may qualify for suspension of the overage calculation.<br>   <br>   <br>   <br>### Note:<br>   <br>   <br>   <br>You must document approval to input the TC 971 AC 281 in the ICS history. See IRM 25.3.2.6.1, Suits by the United States-Aging Suit Development Case Suspension. |
| **Identity Theft Codes** | When the taxpayer alleges identity theft, see IRM 5.1.28, Identity Theft for Collection Employees.<br> <br>1. Was CC ENMOD reviewed for already posted identity theft action codes?<br>   <br>2. Was TC 971 AC 522 PNDCLM requested if not already present on ENMOD?<br>   <br>3. When substantiation documentation was received, was the correct source code (INCOME, MULTL, INCMUL, NOFR, OTHER) used with the TC 971, AC 522 request?<br>   <br>4. If substantiation documentation (authentication of identity, evidence of identity theft) was not received, was TC 971 AC 522 reversed with a TC 972, AC 522 NORPLY?<br>   <br>5. Was TC 971, AC 522 IRSID requested for cases of IRS identified identity theft? |

**Exhibit 1.4.50-3**

### Target Inventory Levels and Inventory Adjustments Q&A

| **Question** | **Answer** |
| :-: | :-: |
| _Q1. Who determines inventory levels?_ | _A1._ The inventory levels are established for each grade and provided in IRM 1.4.50.10.2. The group manager is responsible for determining inventory level depending on the individual circumstances of the employee. |
| **Q2. If the RO is below the top of the range should I make an inventory adjustment?** | **Q2.** No, an inventory adjustment is not needed when the RO is within range according to IRM 1.4.50.10.2. An inventory adjustment in ENTITY should ONLY be made if they qualify for one of the reason codes. |
| _Q3. What documentation is required by the group manager to justify an inventory adjustment?_ | _A3._ The ENTITY Case Management System (ENTITY) requires managers to select a reason code whenever they make a percentage adjustment to inventory. You should be able to explain any adjustments to inventory when asked. |
| _Q4. Since the maintenance of appropriate inventory levels is a major concern, who should verify that appropriate decisions are being made?_ | _A4._ The SBSE area director is responsible for ensuring inventory levels are appropriate. The field compliance managers should include reviews of inventory determinations as part of normal operational reviews of their GM's activities. |
| _Q5. A revenue officer was assigned to assist with the walk in taxpayers at the customer service counter for eight hours in a month. Does this mean the RO's inventory is adjusted by 5 per cent for the month?_ | _A5._ No, inventory adjustments only apply to long-term or recurring collateral assignments. If an RO is required to assist with walk-in taxpayers for eight hours a month on a regular basis, then an inventory adjustment may be appropriate. Time is reported as detail out on ICS so that the reason for the inventory adjustment can be determined in a review. |
| **Q6. Should inventories be adjusted because of assignment as acting group manager?** | **A6.** This is a judgment area. You should use discretion when determining whether to adjust inventory within range, or if a percentage adjustment is necessary. Factors to consider include length of detail and the duties to be performed during this assignment. Certain acting assignments could be considered to be developmental and may justify a reduction within range, but not a percentage to inventory. |
| **Q7. Is this a new policy?** | **A7.** No. The original establishment of the maximum-targeted inventory levels was based on the number of cases on which a fully successful revenue officer should be able to make timely contact and follow up actions. This assumes that the revenue officer has no other duties/assignments and is working cases appropriate for their grade level. When the actual situation differs from this, it is necessary to make adjustments. |
| **Q8. Is the decision to keep an RO at a particular inventory level within the target range more subjective than the inventory adjustment determination?** | **A8.** Yes. The inventory adjustment is based on an evaluation of how time is spent on activities other than work on assigned cases (direct case time) and normal overhead; it should be a calculated number. The factors that determine assignments within range are more judgmental and more often subject to reevaluation as cases are closed and new cases selected for assignment to the employee. |
| **Q9. How should managers handle getting revenue officer trainees inventories to within target inventory ranges?** | **A9.** By using sound judgment, and evaluating each revenue officer's situation individually. They should also confer with the trainee's coach (OJI) and/or training manager in order to assess the individual trainee's performance throughout the training period, and the level of performance at the completion of the training period. While some employees will be fully capable of taking on the additional inventory with little or no impact on their performance, others may require a slightly longer transition period before they are comfortable working within the new target inventory range. Factors to be considered are as follows:<br> <br>- Inventory composition (e.g., type of cases, grade level of cases, etc.).<br>  <br>- Size of geographical area.<br>  <br>- Current assignment area of trainee (e.g., Is trainee simply going from a trainee status to regular RO status within same area, territory, group ? Will trainee be reassigned to another area, territory, group?)<br>  <br>- Will the employee be receiving an entirely new inventory? In the case of a revenue officer moving to another area, territory, group and receiving entirely new inventories, these inventories may need to be built up gradually.<br>  <br>- Employee's experience/knowledge/aptitude (i.e. ability to handle additional workload without significant impact on performance). Look to the trainee's coach (OJIs) and /or trainee's manager for feedback. |
| **Q10. A revenue officer has an inventory of taxpayers in hard to reach locations spread over an extensive area. It takes the revenue officer 4 to 5 hours driving time to reach each taxpayer. In some instances, the revenue officer must travel by airplane into a rural destination to meet with the taxpayer. Is an adjustment appropriate?** | **A10.** An Inventory Adjustment is not used to address this issue. Address such situations by determining the appropriate level of inventory within the established targeted range. The appropriate inventory level would be at your discretion after reviewing with the employee the time and distance traveled. |
| **Q11. A revenue officer is working a case where a taxpayer operates several related limited liability partnerships. Each entity continuously pyramids trust fund liabilities. The revenue officer cannot locate any assets that can be used to satisfy the tax liability. The revenue officer must determine the culpability of each partnership and is working with Advisory and Area Counsel to pursue injunctive relief to stop the taxpayer from pyramiding trust fund taxes. Should an adjustment be made to the revenue officer's inventory?** | **A11.** An inventory level near the bottom of the established target range may be appropriate after the you and the employee have discussed the facts of the case and determined that such a change is critical to their ability to meet the deadlines of this potentially complex case. |
| **Q12. How can a revenue officer manage an inventory of taxpayers who are geographically spread apart?** | **A12.** You must ensure that the revenue officers use sound workload and travel management practices to promote efficient use of resources when working inventories in geographically extended areas. When there is a need to travel to remote locations, encourage your revenue officers to schedule multiple taxpayer contacts and meetings in one area as opposed to them traveling several hours for a single contact. For example, traveling into town the night before and meeting with (5) taxpayers the following day is a more effective approach than a revenue officer making appointments on 5 different days and traveling several hours each day to meet with taxpayers. |
| **Q13. As a group manager, how do I review inventory levels to determine if they are appropriate?** | **A13.** In order to determine the appropriate inventory level you should communicate with your revenue officers to determine if there are circumstances that warrant a reduction to the lower end of the target inventory range. If there are no circumstances that warrant a reduction, and additional cases can be worked effectively, you should increase the inventory level using the GM Case Assignment feature on ENTITY. For Inventory Adjustments, you should compare the hours charged to duties other than direct and overhead time on the RO Inventory Adjustment and Time code Report from the Time Reports Section in ENTITY. The percent adjustment should be substantiated by the time reported by the revenue officer. If the percent adjustment cannot be substantiated, then the percent adjustment should be modified or removed to match the time actually spent working duties other than revenue officer duties. |

**Exhibit 1.4.50-4**

### Action Steps For Acceptable Level Of Competence Determination is an Employee Within Grade Increase (WGI) is Due.

| **Within** | **And the employee's last rating is** | **And the employee's performance is projected as** | **You must** |
| :-: | :-: | :-: | :-: |
| 90 days | Fully successful or above | Fully successful or above | Do nothing. WGI will be automatically generated. |
| 90 days | Fully successful or above | Below fully successful | Refer to WGI denial procedures in Article 17 for BU employees.<br> <br>1. Consult with Labor Relations personnel and issue letter of intent to deny WGI 60 days prior to WGI due date.<br>   <br>2. If a fully successful rating is achieved after issuing intent letter, consult with LR regarding written notification to employee that WGI will become effective on original due date. |
| 90 days | Fully successful or above | Below fully successful | If a fully successful rating is not achieved after 60 days following issuance of intent letter:<br> <br>1. Consult with LR regarding written notification to employee denying WGI<br>   <br>2. Prepare Form 6850-BU as you normally would at the end of the rating period except indicate period covered from the last annual rating to the date WGI was due and annotate that "WGI Denied"<br>   <br>3. Submit signed form to the Transactional Processing Branch (TPB) at least 15 days prior to WGI due date to ensure that the WGI is not processed. |
| 59 days or less | Fully successful or above | Below fully successful | Refer to WGI denial procedures in Article 17 for BU employees:<br> <br>1. Consult with LR and issue letter of intent to deny WGI. Letter will provide for required 60 day notice period.<br>   <br>2. As soon as possible, prepare Form 6850-BU. Complete appropriate blocks and annotate "Postpone WGI."<br>   <br>3. Submit signed form to the TPB at least 15 days prior to WGI due date to ensure the WGI does not process. |
| 59 days or less | Fully successful or above | Below fully successful | If a fully successful rating is achieved at the end of 60 day notice period:<br> <br>1. Consult with LR regarding written notification to employee that WGI will become effective retroactive to original due date<br>   <br>2. Prepare Form 6850-BU. Complete appropriate blocks and annotate "Release WGI."<br>   <br>3. Submit signed form to the TPB within 3 days of advising employee. |
| 59 days or less | Fully successful or above | Below fully successful | If a fully successful rating is not achieved at the end of the 60 day notice period:<br> <br>1. Consult with LR regarding written notification to the employee that the WGI is being denied.<br>   <br>2. Prepare Form 6850-BU as if annual rating except indicate the period covered from the last annual rating to the date of the WGI due, annotate "WGI Denied."<br>   <br>3. Submit completed form to the TPB within 3 days after the denial letter is issued to the employee.<br>   <br>4. Immediately have SF-52 prepared for denial of the WGI. |
| 59 days or less | Below fully successful and the WGI was previously denied | Fully successful or above | Prepare Form 6850-BU as if annual rating except:<br> <br>1. indicate the period covered from date WGI was last due to the date of this form being prepared and annotate _WGI Released._<br>   <br>2. Advise employee that the WGI will become effective the following pay period.<br>   <br>3. Submit completed form to the TPB within 3 days of completing form. |
| 59 days of less | Below fully Successful and WGI was not previously denied. | Fully successful or above | No action necessary. |

**Exhibit 1.4.50-5**

### Suggested Action Steps For Unacceptable Performance

**During a workload review you note a performance deficiency(ies) based on employee's critical job elements (CJE) (e.g. 2C Protection of Public Interest, issue: filing of NFTL and/or extension of NFTL filing determination).Take informal steps to correct performance deficiencies such as:**

1. Query ICS for two oldest cases in revenue officer's inventory to review whether identified deficiencies are prevalent in these two cases.

2. Go to ICS and select additional cases to determine if there is a consistent pattern for the identified deficiencies.

3. While reviewing employee documentation, see if you can determine other factors that may have caused the identified deficiencies.


Counsel employee as to what is considered appropriate action on cases reviewed. Indicate which CJE or CJE's are identified as not being met at this time. Require employee to obtain managerial approval to extend NFTL determination date (if applicable). Continue to use ENTITY to identify lien indicator cases and perform a query of the cases on ENTITY. Indicators to check are:

1. When the case is received in field.

2. When the case is assigned to the revenue officer.

3. When NFTL filed.


All discussion(s) with employee must be fully documented and a copy of the documentation is provided to employee with a copy placed their EPF. Continue to closely observe/monitor employee performance using managerial tools available to you.

**You continue to closely observe, monitor, review, and correct (if necessary) the performance deficiency(ies) and the employee’s performance improves and now meets the performance standard:**

No additional action needed.

**You continue to closely observe, monitor, review, and correct the performance deficiency(ies) and the employee's performance does not improve.**

Begin formal counseling. Consult with Labor Relations regarding the issuance of an opportunity letter to establish a formal period to show improvement to acceptable level of performance. The opportunity letter **must** include:

1. Critical elements/performance standards that are not acceptable.

2. Exact nature of deficiencies.

3. Improvement expected

4. Fact that failure to improve could result in proposal to remove employee from current grade or the IRS.

5. Specific period of time to demonstrate acceptable level of performance (usually 90 days).

6. Stated commitment to work with employee.

7. If on telework, suspension of telework until performance improves.


With the continued assistance of Labor Relations, follow procedures outlined in Article 40 of the National Agreement for BU employees. Plan a review schedule. At this planning session discuss:

1. Number of reviews planned.

2. Types of reviews.

3. Types of cases to be reviewed.

4. Number of cases at each review.

5. Time frames for review schedule (one a week, twice a month etc.)

6. In summary, tailor the planned reviews to the needs of the employee and you.


**Continue to use ENTITY to identify lien indicator cases and perform a query review of the cases on ENTITY. Indicators to continue to check are:**

1. When the case is received in field.

2. When the case is assigned to the revenue officer.

3. When NFTL filed.

4. Review, approve, or disapprove (with comments) extension of NFTL determination(s) made by employee (if applicable).

5. Document all reviews, provide copy of documentation to employee, and place in their EPF.


**You continue to closely observe, monitor, and review employee performance based on the provisions of the opportunity letter and the employee's performance becomes minimally successful or fully successful:**

1. Consult with Labor Relations personnel and issue a letter informing employee of this fact.

2. If employee's telework was suspended during this period, consider resuming the schedule.


**You continue to closely observe, monitor, and review employee performance based on provisions of the opportunity letter the employee's performance becomes minimally successful or fully successful.**

Consult with Labor Relations regarding the issuance a 30 day advance notice of reduction in grade or removal. Make sure all documentation is in order and copies provided to employee with copies filed in their EPF. Follow procedures outlined in Article 40 of the 2016 National Agreement for BU employees with the continued assistance of Labor Relations.

Provide a written decision to the employee within 30 days after the date the advance notice period expires.

1. If no written decision is made within this 30 day period, then the advance notice period may be extended for one additional 30 day period only.

2. Provide a written decision to employee within extended 30 day advance notice period.


Initiate action to reduce in grade and/or removal based on unacceptable performance once the written decision is issued.

**However, when a 30 day advance notice is being considered and reassignment, voluntary reduction in grade, retirement or disability retirement is also being considered in lieu of notice:**

1. Consult with Labor Relations personnel.

2. Exercise options under consideration.

3. All but disability retirement option may preclude or delay processing of an action to reduce in grade or remove employee.

4. An application for disability retirement will not preclude or delay processing of an action to reduce in grade or remove the employee.


**If written decision is issued to reduce in grade and/or removal based on unacceptable performance and the personnel action is effected, the employee:**

1. Consult with Labor Relations personnel and issue a letter informing employee of this fact.

2. If employee's telework was suspended during this period, consider resuming the schedule


**Exhibit 1.4.50-6**

### Collection Group Managers’ EQRS Review Documents, Form 6850, and Narrative, General Guide

EQRS, Form 6850, and narratives are important in all actions regarding revenue officer performance. The review documents should justify the numerical ratings and average indicated on the F 6850.

These documents will assist you in substantiating your decision to take any action regarding the performance of a revenue officer or other employee. These actions can include awards, reduction of a rating of record, or removal from telework. These documents should be clear and concise. They should provide the employee with a clear understanding of their level of performance.

EQRS review documents, narratives and other evaluative documents should provide positive feedback and specific strategies for improvement as applicable. The narrative should be specifically written to enhance performance, identify weaknesses, and explain potential consequences when warranted.

_Ensure that your reviews are written and encompass a wide spectrum of cases from the RO’s inventory. Include pyramiders, large dollar, IBTF, no touch, etc. If warranted, review more cases than the minimum required by _IRM 1.4.50.5.2.2_._

**When performing case reviews utilizing the Embedded Quality Review System:**

1. Review actual hard copy case file(s). This is to ensure documents that will expedite case resolution are included, (e.g., financial statements, bank records, etc.) and that an appropriate evaluation of case direction has been made.

2. Ensure clear comments are included for each case reviewed. If the revenue officer is performing well, document it in the comments.

3. If case direction is needed, ensure your directions are specific. If warranted, reference specific documents reviewed in the case file.


**When preparing the review documentation you should:**

1. Ensure the RO’s actions were appropriately documented on each case.

2. Base your comments on actions pertaining to the applicable CJE and sub-element.

3. Ensure conformity with the revenue officers’ CJE’s by utilizing the revenue officer’s Performance Plan, Document 11491.

4. When appropriate, reference relevant IRM sections, subsections, and case file documents.

5. Document strategies for improvement.

6. Be realistic in expectations.

7. Prepare a narrative of your overall findings.


Meet with the employee and engage in an open dialogue. Be sure to discuss the positive as well as the negative aspects of the employee’s performance. Discuss the comments on the EQRS Feedback Report given on each case and ensure the revenue officer understands.

1. Ask for their input regarding your interpretation of their actions.

2. If warranted, discuss the documents included in the case file, and address any that are missing.

3. If appropriate add their proposed actions to your comments as additional action items.

4. Ensure that time lines are realistic.

5. Ensure that case direction is clear.


Discuss the EQRS Feedback Report narrative with the revenue officer to ensure they understand the document and its possible impact on their annual appraisal/evaluation (positive or negative).

### Note:

You should have the employee sign for receipt of both the Individual Feedback Report and any accompanying documents. Document and date the Individual Feedback Report and narrative if the employee refuses to sign.

**Annual Appraisal Document Form 6850:**

Form 6850 is the numerical representation of the revenue officer's performance during the course of the evaluation period. It must be consistent with the revenue officer's casework and evaluative documents prepared during the course of the evaluative period. You should ensure that the preparation of Form 6850 is in accordance with Article 12 of the National Agreement. Base your appraisal of the revenue officer on documented materials such as:

1. Evaluative documents retained in the revenue officer's EPF, such as EQRS Individual Feedback and/or Cumulative Feedback Reports. Also see_IRM 1.4.50.5_, Performance Management, and _IRM 1.4.50.5.2_, Reviews, for other considerations.

2. Taxpayer correspondence. Internal customer correspondence.

3. All awards received during the period.


**Performance and Evaluative Narratives:**

Narratives are an effective tool in documenting and informing a revenue officer of their performance. They should be used to emphasize the positive as well as the negative aspects of the revenue officer's performance. They can be used as either stand alone documentation (EQRS Individual and/or Cumulative Feedback Reports) and/or with the Form 6850 (when appropriate). See Article 12, Section 4N, of the National Agreement, regarding Form 6850 narratives. Effective narratives:

1. Address each critical job element and its accompanying sub-element (for Form 6850).

2. Reference prior reviews and other evaluative documents completed during the course of the evaluation period and the dates completed or received.

3. Are of sufficient length for the employee to have a clear understanding of their current level of performance and what is expected from them in the future.

4. Summarize your findings during the course of a review or the overall performance during an evaluative period. You may choose to use specific examples or sanitized case references.

5. Describe strengths and weaknesses found within specific element(s).

6. Describe strategies for improvement (if necessary).

7. Identify the level of performance (overall and within a specific CJE).

8. Describe potential consequences if performance is at an unacceptable level or regressing.

9. Note that you are available for assistance.


In conjunction with the steps to address employee performance as outlined in Exhibit 1.4.50–5 of this handbook ensure that:

- Your prescribed action is specifically documented and appropriately worded. Consult with your field compliance manager or Labor Relations specialist as appropriate.

- Your documentation includes a description of any problems and documentation of the discussion with the employee involved. Inform the employee of possible consequences if the issue is not resolved. You may inform the employee verbally, but confirm the discussion via memorandum. The proposed resolution of the issue should include a specific time period for completion. The resolution may include actions the employee must take and meetings between yourself and the employee to resolve the problem.



### Note:



The employee is entitled to request representation by the Union when the employee and the supervisor or other management official meet to discuss action or _potential_ action, based on unacceptable performance.


### Note:

**When taking any performance action, contact your servicing Labor Relations Representative and your direct supervisor**.

**Exhibit 1.4.50-7**

### Remittance Processing Transmission Control Review Template

Remittance Processing Transmission Control Review

1. Date of review:

2. Name of reviewer

3. Group number:

4. Post of duty reviewed:


| **Review Point** | **Results** |
| :-: | :-: |
| Form 3210 used per IRM 5.1.2.5.4 and Form 3210 accurately lists only documents transmitted and includes all documents transmitted. | IRM requirement met. Y/N |
| Form 795/795As timely per IRM 5.1.2.5. | IRM requirement met. Y/N |
| Form 795/795As and envelope are prepared properly per IRM 5.1.2.5.3. | IRM requirement met. Y/N |
| Control copies of Form 3210 and 795/795A maintained per IRM 5.1.2.5.5. | IRM requirement met. Y/N |
| A procedure is established to handle processing of remittances and returns for those employees away from the office per IRM 5.1.2.5 | IRM requirement met. Y/N |
| All document transmittal forms are reconciled on a biweekly basis to ensure that all transmittals were received per IRM 5.1.2.5.5.1. | IRM requirement met. Y/N |
| Follow-up actions taken for Form 795s without acknowledgement and 14 days have passed since transmission per IRM 5.1.2.5.5.1 | IRM requirement met. Y/N |
| Revenue officers within each Post of Duty have access to a "United States Treasury" stamp to meet the requirements of IRM 5.1.2.7.3.1 , Overstamping or Endorsing. | Y/N |

**Exhibit 1.4.50-8**

### CKGE Research Review Template

Revenue Officer CKGE Research Review

1. Date of review:

2. Name of reviewer:

3. Name of employee reviewed:


| **Review Point** | **Results** |
| :-: | :-: |
| Is the employee profiled for CKGE? If "No," stop here and place this document in the employee’s EPF. | Yes/No. |
| If the employee has CKGE access, did the employee perform research with the system during the employee’s rating period? If "No" , stop here and place this document in the employee’s EPF. | Yes/No. |
| Select a search session made by the employee starting with the initial query located in the "Search using term box." | Date of Search: |
| Was the selected search term associated with a taxpayer currently, or formerly assigned to the employee? | Yes/No. If no, describe remedial actions taken. |
| Were each of the additional research steps "Expanded Nodes" associated with the initial query taxpayer? if "Yes," stop here and place this document in the employee’s EPF. | Yes/No. If no, describe remedial actions taken. |
| If the "Expanded Node(s)" reviewed for a taxpayer not currently assigned to the employee, does the ICS history support the research performed? | Yes/No. If no, describe remedial actions taken. |

**Exhibit 1.4.50-9**

### FinCEN Query Review Template

FinCEN Query Review

1. Date of review:

2. Name of reviewer:

3. Name of employee reviewed:


| **Review Point** | **Results** |
| --- | --- |
| Review Period<br> <br>### Note:<br>The review period must be a minimum of 30 consecutive days | MM/DD/YYYY to MM/DD/YYYY |
| Is the review period within the employee’s evaluative rating period? | Yes/No. |
| Is the employee reviewed a gatekeeper/super user? | Yes/No. |
| Do all of the FinCEN Query requests match the employee’s assigned inventory for period of the review?<br> <br>### Note:<br>If the employee reviewed is not a gatekeeper/ super user, stop here. | Yes/No. If No, and the employee is not a gatekeeper/superuser, explain remedial actions taken. |
| If the employee reviewed is a gatekeeper/super user, are queries which do not match the employee’s assigned inventory supported with a Form 10509-A request? | Yes/No |

**Exhibit 1.4.50-10**

### After hours Security Review

1. Name of Reviewer:

2. Date of Review:

3. Post of Duty:

4. Notes for any deficiencies identified below:


| **Review Point** | **Results** |
| :-: | :-: |
| Are all exterior doors locked? | Y/N |
| Do cipher locks contain at least four digits to avoid easy access? | Y/N |
| Are all cabinets and drawers containing SBU materials locked? | Y/N |
| Are computer work stations logged off as required? | Y/N |
| Are cable locks in place on laptop computers? | Y/N |
| Are employee workstations free of SBU materials such as case files, work papers and taxpayer documents? | Y/N |
| Are employee workstations free of telephone messages from members of the public? | Y/N |
| Are computer or system passwords secured and out of sight? | Y/N |
| Is shred material properly secured? | Y/N |
| Do wastepaper baskets free of sensitive information? | Y/N |
| Is any sensitive information left on or near copiers, printers, scanners or fax machines? | Y/N |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-050#addtoany "Show all")

A2A