---
url: "https://www.irs.gov/irm/part1/irm_01-035-003"
title: "1.35.3 Receipt and Acceptance Guidelines | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-035-003#main-content)

- 1.35.3  [Receipt and Acceptance Guidelines](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680645106368)
  - 1.35.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616768208)
    - 1.35.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616764592)
    - 1.35.3.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616762544)
    - 1.35.3.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616744352)
      - 1.35.3.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616739232)
      - 1.35.3.1.3.2  [Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616737520)
      - 1.35.3.1.3.3  [Accounts Payable Office](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616733808)
      - 1.35.3.1.3.4  [Financial Management Systems Office](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616728576)
      - 1.35.3.1.3.5  [Office of Procurement](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616725536)
      - 1.35.3.1.3.6  [Division Finance Officers](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616722384)
      - 1.35.3.1.3.7  [Business Units](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616719152)
    - 1.35.3.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616714976)
    - 1.35.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616712128)
      - 1.35.3.1.5.1  [Prompt Payment Standards](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616708288)
      - 1.35.3.1.5.2  [PPS Recording Standards](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680616704928)
      - 1.35.3.1.5.3  [Accounts Payable Reminders](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615555296)
    - 1.35.3.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615552784)
    - 1.35.3.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615533696)
    - 1.35.3.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615510688)
    - 1.35.3.1.9  [Forms](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615508096)
  - 1.35.3.2  [Overview of the Receipt and Acceptance of Goods and Services](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615487376)
    - 1.35.3.2.1  [Multiple Account Assignment](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615484576)
  - 1.35.3.3  [Receipt](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615482608)
    - 1.35.3.3.1  [Receipt Requirements](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615480880)
    - 1.35.3.3.2  [Receipt Documentation](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615478544)
    - 1.35.3.3.3  [Manual Receipt Process](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615473680)
  - 1.35.3.4  [Acceptance](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615470688)
    - 1.35.3.4.1  [Acceptance Requirements](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615468928)
    - 1.35.3.4.2  [Quality Assurance Inspection](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615465360)
    - 1.35.3.4.3  [Acceptance Documentation](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615461616)
    - 1.35.3.4.4  [Annotating Ownership of Property and Equipment](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615457472)
    - 1.35.3.4.5  [Manual Acceptance Process](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615454048)
  - 1.35.3.5  [Receipt and Acceptance by Program](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615450272)
    - 1.35.3.5.1  [Procurement Orders](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615449120)
      - 1.35.3.5.1.1  [Blanket Purchase Agreements](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615447440)
      - 1.35.3.5.1.2  [Interagency Agreements](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615425248)
      - 1.35.3.5.1.3  [Locator Services](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615409568)
      - 1.35.3.5.1.4  [Purchase Orders, Contracts and Delivery Orders](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615396928)
      - 1.35.3.5.1.5  [Relocation Services Contract](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615354960)
      - 1.35.3.5.1.6  [Subscriptions](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615341328)
      - 1.35.3.5.1.7  [Telephones (Commercial)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615337424)
    - 1.35.3.5.2  [Non-Procurement Orders](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615319120)
      - 1.35.3.5.2.1  [Administrative Summons](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615318192)
      - 1.35.3.5.2.2  [Attorney Fees](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615298448)
      - 1.35.3.5.2.3  [Child Care Subsidy](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615279552)
      - 1.35.3.5.2.4  [Commercial Bills of Lading](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615263152)
      - 1.35.3.5.2.5  [Consolidated American Payroll Processing System](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615245888)
      - 1.35.3.5.2.6  [Corporate Travel Accounts](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615227872)
      - 1.35.3.5.2.7  [Delegated Leases](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615213520)
      - 1.35.3.5.2.8  [Disclosure of Information-Administrative Claims](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615201248)
      - 1.35.3.5.2.9  [Employee Reimbursables](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615198896)
      - 1.35.3.5.2.10  [Federal Employees Compensation Act](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615181792)
      - 1.35.3.5.2.11  [Federal Telecommunication Services](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615160960)
      - 1.35.3.5.2.12  [Foreign Service Accounts](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615141888)
      - 1.35.3.5.2.13  [Fuel/Maintenance](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615124784)
      - 1.35.3.5.2.14  [Inter-governmental Personnel Act Agreements](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615108336)
      - 1.35.3.5.2.15  [Internal Revenue Bills of Lading - Commercial](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615090768)
      - 1.35.3.5.2.16  [Internal Revenue Bills of Lading - Relocation](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615073280)
      - 1.35.3.5.2.17  [Judgment Fund (Small Claims)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615054080)
        - 1.35.3.5.2.17.1  [Judgment Fund (Small Claims - Individual Taxpayer Identification Numbers)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615037968)
      - 1.35.3.5.2.18  [Lien Fees](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615025392)
      - 1.35.3.5.2.19  [Low Income Taxpayer Clinics](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680615012048)
      - 1.35.3.5.2.20  [Miscellaneous Medical Services](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614996784)
      - 1.35.3.5.2.21  [Motor Pool](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614980288)
      - 1.35.3.5.2.22  [Packers Authorizations (Relocation Transportation Invoices)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614785200)
      - 1.35.3.5.2.23  [Personal Property Claims](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614767680)
      - 1.35.3.5.2.24  [Printing](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614750768)
      - 1.35.3.5.2.25  [Reimbursable Work Authorizations/Security Work Authorizations](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614731280)
      - 1.35.3.5.2.26  [Representation Fund](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614706496)
      - 1.35.3.5.2.27  [Settlement Agreements](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614691232)
      - 1.35.3.5.2.28  [Tax Counseling for the Elderly](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614672880)
      - 1.35.3.5.2.29  [Telephones (Government)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614656288)
      - 1.35.3.5.2.30  [Torts](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614636048)
      - 1.35.3.5.2.31  [Training (Out-Service) (Non-Purchase Card)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614616608)
      - 1.35.3.5.2.32  [Unemployment Compensation for Federal Employees](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614601760)
      - 1.35.3.5.2.33  [Uniform Allowance](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614579792)
      - 1.35.3.5.2.34  [Volunteer Income Tax Assistance](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614562992)
      - 1.35.3.5.2.35  [Witness Fees](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614545312)
    - 1.35.3.5.3  [Non-Procurement or Procurement Orders](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614525616)
      - 1.35.3.5.3.1  [Ratifications (Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614524672)
        - 1.35.3.5.3.1.1  [Ratifications (Non-Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614521360)
      - 1.35.3.5.3.2  [Rent (Non-Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614519664)
        - 1.35.3.5.3.2.1  [Rent (Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614498864)
      - 1.35.3.5.3.3  [Treasury Franchise Fund/Shared Support Program (also known as Departmental Franchise Fund) (Non-Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614497168)
        - 1.35.3.5.3.3.1  [Treasury Franchise Fund/Shared Support Program (also known as Departmental Franchise Fund) (Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614478032)
      - 1.35.3.5.3.4  [Utilities (Non-Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614476176)
        - 1.35.3.5.3.4.1  [Utilities (Procurement)](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614468384)
    - 1.35.3.5.4  [Advances](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614466672)
      - 1.35.3.5.4.1  [Department of Transportation/Public Transit Subsidy Program](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614446928)
      - 1.35.3.5.4.2  [Postage](https://www.irs.gov/irm/part1/irm_01-035-003#idm139680614423696)

# Part 1. Organization, Finance, and Management

# Chapter 35. Financial Accounting

# Section 3. Receipt and Acceptance Guidelines

* * *

## 1.35.3 Receipt and Acceptance Guidelines

#### Manual Transmittal

September 09, 2024

#### Purpose

(1) This transmits revised IRM 1.35.3, Financial Accounting, Receipt and Acceptance Guidelines.

#### Material Changes

(1) IRM 1.35.3.1.5 (1)(b), Program Controls, Changed approval threshold amount from $2,500 to $10,000.

(2) IRM 1.35.3.5.2.16(3), Internal Revenue Bills of Lading - Relocation, Changed W&I to Taxpayer Services.

(3) IRM 1.35.3.5.2.22(3), Packers Authorizations (Relocation Transportation Invoices), Changed W&I to Taxpayer Services.

#### Effect on Other Documents

IRM 1.35.3, dated September 03, 2023, is superseded.

#### Audience

All business units

#### Effective Date

(09-09-2024)

Teresa R. Hunter

Chief Financial Officer

**1.35.3.1** **(08-26-2021)**

### Program Scope and Objectives

1. Purpose: This IRM provides guidance to assist the business units in recording receipt and acceptance (R&A) of goods and services.

2. Audience: All business unit personnel responsible for ensuring the IRS receives ordered goods and services and that services meet contractual requirements.

3. Policy Owner: CFO, Financial Management.

4. Program Owner: Corporate Accounting, Accounts Payable Office.

5. Primary Stakeholders: All business units.

6. Program Goals: To record R&A timely and accurately, ensuring that proper payments are made to vendors for the goods and services provided.


**1.35.3.1.1** **(10-03-2019)**

#### Background

1. This IRM describes the requirements of recording R&A. The process ensures that goods and services are received for the quantity and quality specified in the vendor contract..


**1.35.3.1.2** **(09-06-2023)**

#### Authorities

01. [Chief Financial Officers Act of 1990](https://www.congress.gov/bill/101st-congress/house-bill/5687/text), Pub. L. No. 101-576, section 902

02. [31 USC 1501](https://uscode.house.gov/browse.xhtml), Documentary Evidence Requirement for Government Obligations

03. [31 USC 3512](https://uscode.house.gov/browse.xhtml), Executive Agency Accounting and Other Financial Management Reports and Plans

04. [5 Code of Federal Regulations (CFR) 1315](https://www.ecfr.gov/current/title-5/chapter-III/subchapter-B/part-1315?toc=1): Prompt Payment

05. [41 CFR](https://www.ecfr.gov/current/title-41/subtitle-C/chapter-102/subchapter-D/part-102-118?toc=1), Public Contracts and Property Management; Chapter 102, Part 102-118

06. [41 CFR](https://www.ecfr.gov/current/title-41/subtitle-F/chapter-302), Public Contracts and Property Management; Chapter 302, Part 302-7 through Part 302-12

07. [48 CFR 53.212](https://www.ecfr.gov/current/title-48/chapter-1/subchapter-H/part-53/subpart-53.2/section-53.212), FAR, Acquisition of Commercial Items

08. [FAR Part 46.5](https://www.acquisition.gov/far/subpart-46.5) Acceptance

09. [5 U.S.C. 4107](https://uscode.house.gov/browse.xhtml): Academic Degree Training Restriction on Degree Training

10. [5 U.S.C. 5757](https://uscode.house.gov/browse.xhtml), Payment of Expenses to Obtain Professional Credentials

11. [5 U.S.C. 4109](https://uscode.house.gov/browse.xhtml), Expenses of Training


**1.35.3.1.3** **(09-06-2023)**

#### Responsibilities

1. This section provides responsibilities for:



1. CFO and Deputy CFO

2. Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

3. Accounts Payable office

4. Financial Management Systems office

5. Office of Procurement

6. Division finance officers

7. Business units


**1.35.3.1.3.1** **(10-03-2019)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for overseeing R&A policies and ensuring their compliance.


**1.35.3.1.3.2** **(09-06-2023)**

##### Senior Associate CFO for Financial Management and Associate CFO for Corporate Accounting

1. The Senior Associate CFO for Financial Management and the Associate CFO for Corporate Accounting are responsible for:



1. Ensuring compliance with R&A policy

2. Overseeing R&A processes for CFO offices

3. Providing R&A policy and guidance to offices and business units


**1.35.3.1.3.3** **(08-26-2021)**

##### Accounts Payable Office

1. The Accounts Payable office is responsible for:



1. Maintaining R&A policy

2. Reviewing R&A transaction activity

3. Processing and recording payments after R&A has been processed correctly

4. Supporting business unit reviews of R&A transactions and ensuring end users confirm receipt

5. Assisting business units with error diagnostic messages to support R&A timeliness

6. Providing R&A customer support assistance to business unit finance staff


**1.35.3.1.3.4** **(08-26-2021)**

##### Financial Management Systems Office

1. The Financial Management Systems office is responsible for:



1. Maintaining Procurement for Public Sector (PPS) user role access and profile administration

2. Assisting with trouble-shooting system issues related to R&A processing


**1.35.3.1.3.5** **(08-26-2021)**

##### Office of Procurement

1. The Office of Procurement is responsible for:



1. Providing guidance related to the Office of Procurement’s role in monitoring the R&A process for accuracy and timeliness

2. Training PPS users to properly perform R&A transactions


**1.35.3.1.3.6** **(10-03-2019)**

##### Division Finance Officers

1. The division finance officers are responsible for:



1. Attesting, in writing, that goods and services have been received and are acceptable per the terms of the contract before invoices can be processed

2. Maintaining supporting documentation for financial transactions, including entering R&A in PPS


**1.35.3.1.3.7** **(10-03-2019)**

##### Business Units

1. Business units are responsible for:



1. Recording R&A in PPS within seven calendar days of the receipt of the invoice by Accounts Payable

2. Supporting the Program & Process Review (PPR) compliance requirement to obtain documentation prior to entering R&A

3. Maintaining file copies of properly formatted R&A support documentation, including dates of performance, and forwarding to Accounts Payable when necessary


**1.35.3.1.4** **(10-03-2019)**

#### Program Management and Review

1. The R&A process is in place to ensure that goods and services are properly recorded in PPS to support payments.

2. Program Effectiveness: Program management measures trends and the timeliness of recording R&A entries in the PPS module to ensure a prompt pay percentage of 98% per Department of the Treasury guidance.


**1.35.3.1.5** **(09-09-2024)**

#### Program Controls

1. The control methods and objectives include:



1. Separation of duties: Established for obligations, recording R&A in the PPS module and accounts payable, based on role restrictions.

2. Approval Process: All payments that exceed $10,000 must go through an approval process.

3. Auditing: Regular testing of internal controls is performed during the year along with annual audits.


**1.35.3.1.5.1** **(10-03-2019)**

##### Prompt Payment Standards

1. The Prompt Payment Act, codified in 5 CFR Part 1315, Prompt Payment,requires federal agencies to pay valid invoices timely or pay interest penalties when payments are late. The IRS also must ensure that discounts are applied only when payments are made by identified discount dates.

2. Unless the contract provides a due date, the invoice payment due date is 30 days from the latter of the date Accounts Payable receives a proper invoice or that date of acceptance for goods and services.

3. The Prompt Payment Act does not apply to IPAC transactions.


**1.35.3.1.5.2** **(09-06-2023)**

##### PPS Recording Standards

1. R&A guidelines are as follows:



1. Receipt of goods and services should be entered in the PPS module once goods and services have been received, but no later than seven calendar days after a proper invoice has been received by Accounts Payable.

2. The actual day of receipt of goods and services must be used as the receipt date and supporting documentation should be maintained.

3. Acceptance of goods and services should be entered into PPS as soon as the quality assurance inspection is performed, but no later than seven calendar days after a proper invoice has been received by Accounts Payable, unless the contract allows for a longer acceptance period.

4. The actual day of acceptance must be used when recording the acceptance date in PPS and the supporting documentation should be maintained. The same documentation used for receipt can be used for acceptance if it states the goods and services are acceptable per the terms of the contract.


2. Any deviation from the IRS R&A recording standards must be annotated in the contract, clearly stating the contractual requirements for R&A standards as agreed to by the IRS and the vendor.

3. In the event of a system outage (i.e., IFS/PPS system upgrades) that prevents receipt and acceptance from being recorded timely in the financial system, written receipt and acceptance should be sent via e-mail to CFOBFC.InvoiceLink@irs.gov.



   - For Invoice Processing Platform (IPP) relevant contracts/purchase orders, written receipt and acceptance should be submitted on a copy of the IPP invoice to include receipt and acceptance dates, valid signature of the assigned goods recipient, and the following statement: “I attest that the goods/services were received and accepted according to the terms of the contract.” If the goods recipient is unable to access IPP, the goods recipient should contact Accounts Payable for a copy of the invoice.

   - For non-IPP relevant contracts, written documentation should be sent via e-mail to CFOBFC.InvoiceLink@irs.gov and reference the contract/purchase order number, invoice number, contract line and amounts being approved for payment, receipt and acceptance dates, valid signature of the assigned goods recipient, and the following statement: “I attest that the goods/services were received and accepted according to the terms of the contract.”


**1.35.3.1.5.3** **(10-03-2019)**

##### Accounts Payable Reminders

1. The Accounts Payable office will notify the business unit when an invoice is received to ensure R&A is completed no later than seven calendar days from the invoice receipt date. If goods and services have not been received or are not acceptable, the invoice is considered improper and Accounts Payable will return the invoice and notify the vendor.


**1.35.3.1.6** **(09-06-2023)**

#### Terms/Definitions

1. The following terms and definitions apply to this program.



01. **Acceptance** \- Acknowledgment by an authorized government official that goods received and services rendered conform to contract requirements.

02. **Acceptance date** \- Date the quality assurance requirements and contract compliance are met for delivered goods and completed services.

03. **Accomplished date** \- Date an IPAC transaction was successfully processed by the IPAC system.

04. **Contract** \- A mutually binding legal agreement obligating the seller to furnish the supplies or services (including construction) and the buyer to pay for them.

05. **Delivery order** \- An order for supplies placed against an established contract or with government sources.

06. **Designated agency office** \- The office designated in the purchase order, contract, delivery order or other procurement-related transaction to receive vendor invoices.

07. **Designated approving official** \- The person granted approving authority, normally in the business unit or program office.

08. **Goods Recipient** \- The person responsible for recording the receipt and acceptance entries as well as maintaining and uploading the supporting documentation for these transactions.

09. **Integrated Financial System (IFS)** \- The IRS’s official administrative financial management system.

10. **Intragovernmental Payment and Collection System (IPAC)** \- A standardized interagency fund transfer mechanism for federal program agencies. IPAC facilitates the intragovernmental transfer of funds, with descriptive data, from one federal program agency to another.

11. **Procurement for Public Sector (PPS) module** \- The automated system integrated into IFS that transfers procurement actions, including R&A.

12. **Purchase **order****\- An offer by the government to buy supplies or services, including construction and research and development, upon specified terms and conditions, using simplified acquisition procedures.

13. **Receipt** \- An acknowledgment that the government received the goods and services.

14. **Receipt date** \- The date that contracted goods and services are actually delivered.

15. **Vendor** \- Legal entity or party that provides goods and services.


**1.35.3.1.7** **(09-06-2023)**

#### Acronyms

1. The following acronyms apply to this program.




| **ACRONYM** | **DESCRIPTION** |
| :-: | :-: |
| BPA | Blanket Purchase Agreement |
| CAPPS | Consolidated American Payroll Processing System |
| CFO | Chief Financial Officer |
| CFR | Code of Federal Regulations |
| CLIN | Contract Line-Item Number |
| CO | Contracting Officer |
| DOL | Department of Labor |
| FAR | Federal Acquisition Regulation |
| FMSS | Financial Management and Security Services |
| GSA | General Services Administration |
| IFS | Integrated Financial System |
| IPAC | Intragovernmental Payment and Collection |
| IPP | Invoice Processing Platform |
| IT | Information Technology |
| LITC | Low Income Taxpayer Clinics |
| POP | Period of Performance |
| PPR | Program & Process Review |
| PPS | Procurement for Public Sector |
| R&A | Receipt and Acceptance |
| SF | Standard Form |
| TO | Travel Operations |
| USC | United States Code |


**1.35.3.1.8** **(09-06-2023)**

#### Related Resources

1. IRM 1.32.13, Relocation Services Program

2. IRM 1.33.3, Reimbursable Operating Guidelines

3. IRM 1.33.4, Financial Operating Guidelines


**1.35.3.1.9** **(09-06-2023)**

#### Forms

1. The following chart contains forms that are referred to in this IRM.




| **NUMBER** | **TITLE** |
| :-: | :-: |
| [FMS Form 197](https://search.usa.gov/search?affiliate=fiscal&sort_by=&query=Form+197) | Judgment Fund Voucher for Payment |
| [Form 6863](https://publish.no.irs.gov/cat12.cgi?request=CAT1&catnum=25140) | Invoice and Authorization for Payment of Administrative Summons Expenses |
| [Form 12741](https://publish.no.irs.gov/cat12.cgi?request=CAT1&catnum=29811) | Internal Revenue Service Bill of Lading |
| MED-254 | Voucher for Medical Services |
| [SF 182](https://www.gsa.gov/forms-library/authorization-agreement-and-certification-training) | Authorization, Agreement and Certification of Training |
| [SF 1034](https://www.gsa.gov/forms-library/public-voucher-purchases-and-services-other-personal) | Public Voucher for Purchases and Services Other Than Personal |
| [SF 1081](https://www.gsa.gov/forms-library/voucher-and-schedule-withdrawals-and-credits) | Voucher and Schedule of Withdrawals and Credits |
| [SF 1113](https://www.gsa.gov/forms-library/public-voucher-transportation-charges) | Public Voucher for Transportation Charges |
| [SF 1145](https://www.gsa.gov/forms-library/voucher-payment-under-federal-tort-claims-act) | Voucher for Payment Under Federal Tort Claims Act |
| [SF 1449](https://www.gsa.gov/forms-library/solicitationcontractorder-commercial-products-and-commercial-services) | Solicitation/Contract/Order for Commercial Products and Commercial Services |
| [Form 8546](https://publish.no.irs.gov/cat12.cgi?request=CAT1&catnum=63488) | Claim for Reimbursement of Bank Charges |
| [Form 15399](https://publish.no.irs.gov/cat12.cgi?request=CAT2&itemtyp=F&itemb=15399&items=*) | Receipt and Acceptance Documentation for Services |


**1.35.3.2** **(10-03-2019)**

### **Overview of the Receipt and Acceptance of Goods and Services**

1. The business units are responsible for ensuring that goods and services are received and meet the contractual requirements before R&A is entered into the Integrated Financial System (IFS) PPS module.

2. Acceptance includes confirming the received goods and services meet the quality assurance requirements of the contract before entering the accepted date in PPS.


**1.35.3.2.1** **(10-03-2019)**

#### Multiple Account Assignment

1. In most circumstances, receipt will occur before acceptance. However, for line items with multiple account assignments, only an acceptance entry is required to represent both R&A.


**1.35.3.3** **(10-03-2019)**

### Receipt

1. Recording receipt acknowledges that the government has received delivery of the goods and services according to the contract.


**1.35.3.3.1** **(08-26-2021)**

#### Receipt Requirements

1. Receipt should be entered into PPS once goods and services have been received, but no later than seven calendar days after a proper vendor invoice has been received by Accounts Payable.

2. Regardless of when a receipt is entered, the receipt date for when goods and services occurred should be reflected in the receipt entry.


**1.35.3.3.2** **(09-06-2023)**

#### Receipt Documentation

1. Goods recipients receiving goods and services must obtain proper supporting documentation prior to entering receipt in PPS. Examples of supporting documentation include time sheets, packing slips, delivery notifications, bills of lading, and proof of attendance for training.

2. Supporting documentation should be dated to provide evidence of receipt prior to entering receipt in PPS.

3. Receipts recorded by a third party must be verified in writing that goods and services were received and must include necessary supporting documentation. The goods recipient for the goods and services has the responsibility to maintain a copy of supporting documentation.

4. The goods recipient posting the receipt movement is required to upload supporting documentation in the designated document repository. The current designation is Folders Management via the PPS Folders Management module.

5. An invoice typically is not considered acceptable supporting documentation for recording receipt unless the invoice is the only documentation for a service; in this instance, a dated signature by the approving official is considered appropriate support.

6. Form 15399, Receipt and Acceptance Documentation for Services, is also acceptable supporting documentation for services.


**1.35.3.3.3** **(10-03-2019)**

#### Manual Receipt Process

1. Business units must perform manual R&A of goods and services for non-procurement acquisitions. The business unit must manually prepare hard copy documentation for these programs. The approving official must sign and date documents that validate that the R&A functions have been performed.

2. Manual R&A documents are acceptable with either a handwritten signature or an official time-stamp digital signature. Initials on blanket purchase agreement caller logs also are permitted.


**1.35.3.4** **(10-03-2019)**

### Acceptance

1. Recording acceptance acknowledges that the goods and services meet contractual requirements, and that the government is now obligated to pay the vendor.


**1.35.3.4.1** **(08-26-2021)**

#### Acceptance Requirements

1. Acceptance should be entered in PPS as soon as it is determined that goods and services comply with the terms of the contract, but no later than seven calendar days after a proper vendor invoice has been received by Accounts Payable. The only exception is if a longer acceptance period is identified in the contract.

2. Regardless of when the acceptance is entered into PPS, the acceptance date cannot be more than seven calendar days after the receipt date, unless the contract permits a longer acceptance period.

3. When the goods recipient accepts a complete order, it must be marked in PPS accordingly.

4. Acceptance cannot occur without receipt, except for a CLIN with multiple account assignments. See IRM 1.35.3.2.1, Multiple Account Assignment, for more information.


**1.35.3.4.2** **(10-03-2019)**

#### Quality Assurance Inspection

1. The quality assurance inspection is the most critical internal control of the R&A process. The IRS official with knowledge of the goods or services and the contract terms conducts this review to ensure goods and services received are acceptable.

2. A quality assurance inspection must be completed before acceptance.

3. The selected quality assurance method(s), and the procedures followed under each method, should be documented.

4. Documentation addresses what was inspected, the time it was completed and the results.


**1.35.3.4.3** **(09-06-2023)**

#### Acceptance Documentation

1. The goods recipient posting the acceptance movement is required to upload supporting documentation in the designated document repository. The current designation is Folders Management via the PPS Folders Management module. Once uploaded, these electronic documents represent official copies for certification and audits. Goods recipients accepting goods and services must maintain proper documentation for their records.

2. Supporting documentation should be dated to provide evidence of the quality inspection of the goods and services prior to entering acceptance in PPS.

3. Acceptance recorded by a third party must be verified in writing that goods and services were acceptable and provide supporting documentation when applicable. The goods recipient for the goods and services has the responsibility to maintain documentation. If an advance payment is authorized, the contract serves as supporting documentation for recording receipt. The acceptance date is the first day of the beginning of the Period of Performance (POP) defined in the contract. Examples of authorized advance payment orders include, but are not limited to, subscriptions, software licenses, software maintenance, parking, and mailbox rentals.

4. Form 15399, Receipt and Acceptance Documentation for Services, is also acceptable supporting documentation for services.


**1.35.3.4.4** **(10-03-2019)**

#### Annotating Ownership of Property and Equipment

1. Purchases that are classified as property and equipment for the purposes of R&A require the following:



1. Barcodes are considered proof of receipt of goods and must be entered into PPS prior to acceptance. Business units must input barcode data into PPS no later than 10 calendar days after receipt.

2. Business units are responsible for obtaining barcodes for property and equipment when applicable. See the Asset Management Hardware Guide for IT assets and IRM 1.14.4, Personal Property Management for non-IT equipment, for more information.


**1.35.3.4.5** **(10-03-2019)**

#### Manual Acceptance Process

1. Business units must perform manual R&A of goods and services for non-procurement acquisitions. Business units must prepare hard copy documentation manually for these programs. The approving official must sign and date documents that validate the R&A functions have been performed.

2. Manual R&A documents are acceptable with either a handwritten signature or an official time-stamp digital signature. Initials on blanket purchase agreement caller logs are also permitted.


**1.35.3.5** **(10-03-2019)**

### Receipt and Acceptance by Program

1. This section details the requirements of R&A by program which is divided into procurement and non-procurement orders.


**1.35.3.5.1** **(10-03-2019)**

#### Procurement Orders

1. The following is general guidance for R&A to be entered in the PPS module.


**1.35.3.5.1.1** **(08-26-2021)**

##### Blanket Purchase Agreements

1. The blanket purchase agreement (BPA) is a simplified purchase order method of filling anticipated repetitive needs for supplies and services by establishing "charge accounts" with qualified sources. Authorized callers place "calls" for delivery of products or services against the BPAs. Such agreements are appropriate when an office requires a wide variety of items in a broad class of goods and services, but the exact items, quantities and delivery requirements are not known in advance and may vary considerably. Blanket purchase agreements are normally limited to local business establishments where several individual purchases will likely be made during a specified time period.

2. The R&A dates are the "date received" referenced on the call log.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| BPA User Group | Prepare monthly BPA caller log and submit it to the designated funding official for certification of funds. The log should only list calls placed during a calendar month. For example, the December monthly log should only have calls placed during the period of December 1 through December 31. |
| The BPA authorized caller's initials on the received and accepted items on the BPA call log is appropriate for R&A. |
| ### Note:<br>_Only authorized callers can place orders against an established BPA_. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward all documents to Accounts Payable for processing. |
| Certify funds availability and forward the monthly log to Accounts Payable by the 8th day of the following month. If there is no activity during a month, the business unit must submit a log to Accounts Payable for that month with “NO ACTIVITY” listed where calls would normally be listed. |
| _**Note**: Accounts Payable uses the “No Activity” log as a form of internal control._ |
| _If all items procured during the month are not received within the same month, business units must generate supplemental BPA logs on a monthly basis, until the business unit receives all items._ |
| Accounts Payable | Process invoice for payment. |


**1.35.3.5.1.2** **(08-26-2021)**

##### Interagency Agreements

1. The IRS enters into interagency agreements to obtain miscellaneous goods and services from other federal agencies. Examples of these services include, but are not limited to, cooperative agreement service units, health service contracts, and agreements for training and drug testing. The servicing agency bills the IRS through the intragovernmental payment and collection (IPAC) system.

2. The accomplished date of the IPAC is used as the R&A dates.

3. Business units should record receipt upon receipt of goods and services, regardless of whether an IPAC charge has been received from the servicing agency.

4. In the event an IPAC charge is not received, receiving personnel are still responsible for ensuring prompt entry of both R&A in PPS for the correct amount, proper date and appropriate accounting string information. In the absence of an IPAC charge, receiving personnel may rely on alternative measures to estimate charges in advance of receiving a precise accounting from the servicing agency. Receiving personnel are responsible for reviewing contracts monthly to ensure both R&A are current and accurate, including whether they are supported by actual IPAC charges and other documentation or estimated charges. All R&A approvals are based upon the nature of what is procured and the contract terms.

5. When advance payment is required, the accomplished date of the IPAC is used as the R&A dates.

6. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing | Forward copy of IPAC charge/bill to the approving official designated in the agreement. |
| Designated Approving Official | Review the invoice to verify that all charges incurred are proper, that the correct amount has been charged, and that the accounting string is accurate. If discrepancies exist, reconcile with the agency providing the services and request any necessary adjustments. |
| Enter R&A in PPS for each month billed. |
| Intragovernmental & Funds Processing | Post the disbursements and collections after R&A have been entered into PPS. |


**1.35.3.5.1.3** **(10-03-2019)**

##### Locator Services

1. The IRS uses locator services to locate taxpayers. The locator service bears the expense for locating these taxpayers and requests payment from the IRS.

2. Both the R&A dates are the last date the services were performed.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Submit proper invoice to Accounts Payable. |
| End User | Review invoice for accuracy and verify goods and services were received and accepted. |
| Enter both R&A. |
| Accounts Payable | Process invoice for payment. |


**1.35.3.5.1.4** **(09-06-2023)**

##### Purchase Orders, Contracts and Delivery Orders

1. Purchase orders, contracts and delivery orders establish legally binding agreements, that obligate a seller to furnish goods and services and a buyer to pay for them.

2. R&A dates and amounts to be recorded for various contractual agreement methods are as follows:




| **TYPE** | **DESCRIPTION** | **RECEIPT AND ACCEPTANCE DATES** | **AMOUNT TO BE RECORDED** |
| :-: | :-: | :-: | :-: |
| Fluctuating Recurring Orders/Contracts | Contractual agreements where the charges vary for the services from month to month, such as telecommunication services, rental of copy equipment, etc. | Both the R&A dates are the actual date of R&A unless the contractual agreement stipulates a longer acceptance period. | The actual amount of goods and services received and accepted supported with the appropriate supporting documentation. |
| Non-Fluctuating Recurring Orders/Contracts | Contractual agreements where the charge for the goods and services remains the same from month to month, such as machine rentals, maintenance services, etc. | Both the R&A dates are the actual date of R&A, unless the contractual agreement stipulates a longer acceptance period. | The actual amount of goods and services received and accepted supported with appropriate supporting documentation. |
| One-time Orders/Contracts/ Delivery Orders | Contractual agreements for the purchase of goods and services that are in effect for a single transaction. | The receipt date is the date the goods and services were actually received. The acceptance date must be no later than seven calendar days of the IRS's receipt of a valid invoice, unless a longer acceptance period is stipulated in the contractual agreement. | The actual amount of goods and services received and accepted supported with appropriate supporting documentation. |
| At the time of entering receipt, please note any exceptions to the seven-calendar day acceptance period in the header or line-item comments of the receiving entry. |
| Advance Payments | Contractual agreements where the goods and services are paid for in advance of the receipt of the goods and services, such as subscriptions and post office box rentals. | Both the R&A dates are the first day of the period of performance for the item / service on the purchase order. | Business units must enter the authorized advance payment amount. |
| If an advance payment is required, the receiver will enter both R&A in PPS using the first day of the period of performance for the item/service; approve the invoice/voucher or SF 1449, Solicitation/Contract/Order for Commercial Products and Commercial Services; and complete, sign and date the invoice/voucher or SF 1449, as prescribed by GSA and 48 CFR 53.212, Federal Acquisition Regulations System, Acquisition of Commercial Items. |
| Utilities | Contractual agreements for energy costs including heat, light, power, water, sewage, gas and electricity. | Both the R&A dates are the statement closing date. | The actual amount of services received and accepted. |
| Out-Service Training | Out-service training covers training courses, seminars and conferences conducted by other government and non-government organizations. | Out-service training with no prepay - both the R&A dates are the date listed for the last day of training. | The actual amount of services received and accepted. |
| Out-service training with prepay - Both the R&A dates are the date the designated approving official signs the prepayment authorization. |

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Submit invoice to Accounts Payable. |
| End User/Contracting Officer's Representative | Enter both R&A in PPS according to the requirements identified within this IRM for the appropriate contract type. |
| Review invoice (if received) for accuracy and verify that both R&A have been recorded. |
| Accounts Payable | Review invoice for accuracy. |
| Match invoice to purchase order for both R&A and process for disbursement. |


**1.35.3.5.1.5** **(08-26-2021)**

##### Relocation Services Contract

1. Private companies provide relocation services under a contract with the federal government to assist transferring employees in relocating to their new official duty stations. See IRM 1.32.13, Relocation Services Program, for more information on relocation.

2. The Travel Operations (TO) section’s date stamp on the invoice serves as the date for both R&A.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Provide an itemized invoice to the TO relocation services coordinator. |
| Travel Operations Relocation Services Coordinator | Resolve discrepancies with the vendor. Review and forward the invoice to the TO relocation section for processing. |
|  |
| The TO relocation services coordinator's dated signature on the invoice is appropriate documentation for R&A. |
| Travel Operations | Include invoices with the employee’s relocation file and verify adequate funding to cover the expense prior to payment processing. |


**1.35.3.5.1.6** **(10-03-2019)**

##### Subscriptions

1. Business units typically subscribe for newspapers, magazines, periodicals and other publications for official use (including any publication printed, microfilmed, photocopied and magnetically or otherwise recorded for auditory or visual use) through one of two methods:



1. Purchase order with advance payment required - For advance payments, both the R&A dates are the start date of the period of performance, unless the start date was later than the beginning date of the period of performance.

2. Purchase order with no advance payment required - For orders where advance payment is not required, both the R&A dates are the actual date the goods and services were received and accepted.


**1.35.3.5.1.7** **(10-03-2019)**

##### Telephones (Commercial)

1. Commercial vendors invoice the IRS for telephone charges.

2. Both the R&A dates are the last date of the service period for prompt pay services. Business units generally fund prompt pay services (directory listings, installation and wireless services) with purchase orders.

3. Both the R&A dates are the beginning date of the service period for non-prompt pay/tariff-controlled services. Business units fund non-prompt pay/tariff-controlled services by completing Form 2785, Requisition/Obligation Estimate Adjustment Notice.

4. Responsibilities for non-prompt pay:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Forward proper invoice to designated approving official/designated agency office monthly. |
| Designated Approving Official/Designated Agency Office | Date stamp the invoice, review charges for accuracy, review for acceptance purposes and record the appropriate accounting string information on the invoice. Correct any discrepancies with the vendor. |
| The designated approving official's/designated agency office's dated signature on the invoice is appropriate for R&A. |
| Forward invoice to Accounts Payable for processing. |
| _**Note**: These payments may be subject to a tariff or prompt payment depending on the type of services rendered. Therefore, it is important that the designated approving official certify these payments in accordance with local procedures to avoid interest and penalties._ |
| Accounts Payable | Process invoice for payment. |


**1.35.3.5.2** **(10-03-2019)**

#### Non-Procurement Orders

1. The following are general guidelines that do not require R&A to be entered in the PPS module.


**1.35.3.5.2.1** **(10-03-2019)**

##### Administrative Summons

1. Authorized IRS field employees issue administrative summons to third parties (banks, insurance companies, etc.) to obtain taxpayer information. The IRS reimburses the expenses incurred by the third party, per the specifications on Form 6863, Invoice and Authorization for Payment of Administrative Summons Expenses.

2. The receipt date is the date the invoice is received by the field office. This date should be reflected on Form 6863, Section B, Block 14 or it can be date stamped. When there is a date in Section B, Block 14, and a stamped date, the receipt date is the earliest of the two dates. If both dates are missing, the technician must request clarification from the authorized field employee. The acceptance date is the "date complied with" from Form 6863, Section B.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Authorized Field Employee (Revenue Agent, Revenue Officer, Special Agent) | Provide the third party with a blank Form 6863, Invoice and Authorization for Payment of Administrative Summons Expenses, and a mailing address. It is acceptable for the third party to submit its own itemized invoice. |
| Third Party (Bank, Insurance Company) | Submit Form 6863/invoice for completed work to the authorized IRS field employee. |
| Authorized Field Employee (Revenue Agent, Revenue Officer, Special Agent) | Date stamp Form 6863/invoice and review. |
| Form 6863 is used to annotate the receipt date on line 14, "date invoice received" field. |
| Complete Form 6863, Section B, verify and approve charges and forward to the designated approving official. |
| Form 6863 serves as proper documentation of both manual R&A. |
| Designated Approving Official | Verify administrative summons obligation number. |
| Approve charges for payment and forward Form 6863/invoice to Accounts Payable for processing. |
|  |
| Accounts Payable | Process Form 6863/invoice for payment. |


**1.35.3.5.2.2** **(10-03-2019)**

##### Attorney Fees

1. An award of attorney fees is based on a court judgment, an administrative adjudicator’s decision or a settlement agreement between the IRS and the claimant.

2. Both the R&A dates are the same as the dated signature on the Chief Counsel attorney or designated approving official memorandum approving attorney fees, unless otherwise annotated in the settlement agreement.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Claimant (party claiming attorney fees) | Submit proper invoice or appropriate support documents to Chief Counsel attorney of record/designated approving official. |
| Chief Counsel Attorney/Designated Approving Official | Verify reasonableness of invoices or appropriate supporting documents, compare to settlement agreement and issue a memorandum approving amount to be paid. |
| Chief Counsel attorney's/designated approving official's dated signature on the memorandum is appropriate for R&A. |
| Memorandum of approval must contain the payee’s name, address, tax identification number and counsel attorney’s signature. |
| Forward the settlement agreement, memorandum of approval and the invoice (if available) to the designated funding official. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward documents to Accounts Payable for processing. |
| Accounts Payable | Process memorandum of approval for payment. |


**1.35.3.5.2.3** **(10-03-2019)**

##### Child Care Subsidy

1. The IRS established the child care subsidy plan to subsidize a portion of the cost of dependent care incurred by qualifying IRS employees.

2. If Accounts Payable pays in advance, both the R&A dates are the first day of the billing/service period. For payments in arrears, both the R&A dates are the last day of the service period.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Plan Administrator | Submit proper invoice to designated approving official with requisition information annotated. |
| Designated Approving Official | Verify accurate funding information is noted on documents. |
| The designated approving official's dated signature on the invoice is appropriate for R&A. |
| Forward invoice to Accounts Payable for processing. |
| Accounts Payable | Process invoice for payment. |





### Note:



_IRS makes payment to the plan administrator, not to the child care center_.


**1.35.3.5.2.4** **(10-03-2019)**

##### Commercial Bills of Lading

1. Commercial bills of lading may be used for shipment of small packages and overseas shipments.

2. Both the R&A dates are the actual delivery date for single invoices. If the vendor "bundles" invoices weekly, both the R&A dates are the last day of the week.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Submit proper invoice with carrier's shipping document attached to designated agency office per contract terms. |
| Designated Agency Office | Date stamp invoice. |
| Forward invoice to designated approving official for review. |
| Designated Approving Official | Review invoice and supporting documentation for completeness and accuracy. |
| Forward invoice and supporting documentation to Accounts Payable for processing. |
| The designated approving official's dated signature is appropriate for R&A. |
| Accounts Payable | Process invoice for payment. |


**1.35.3.5.2.5** **(08-26-2021)**

##### Consolidated American Payroll Processing System

1. The CAPPS processes the cost-of-living allowance for employees of the IRS working in foreign countries. The Department of State Consolidated American Payroll Division issues the payments to the employees.

2. The transaction date on the SF 1081, Voucher and Schedule of Withdrawals and Credits, is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Department of State Employee | Submit SF 1081, Voucher and Schedule of Withdrawals and Credits, and the payroll advice of charge to IPAC. |
| Intragovernmental & Funds Processing - IPAC unit | Retrieve CARS account statement. |
| Forward SF 1081 and Payroll Advice of Charge to designated approving official for approval. |
| Designated Approving Official | Review SF 1081 and the Payroll Advice of Charge. |
| Complete the IPAC Billing Certification/Processing form indicating the amount approved and obligation information to charge. |
| Forward the review and certification to IPAC within 10 calendar days of receiving SF 1081. |
| The designated approving official's dated signature on the IPAC Billing Certification/Processing form is appropriate for R&A. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.6** **(08-26-2021)**

##### Corporate Travel Accounts

1. IRS employees use a corporate travel card to secure transportation for business-related travel. The use of the corporate travel accounts is limited to new employees who have not yet received government-issued travel cards, invitational travelers, and employees whose government-issued travel cards have been suspended or cancelled. See IRM 1.32.4, Government Travel Card Program, for more information.

2. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Provide itemized invoice to the TO office and a statement to the designated approving official monthly. |
| Designated Approving Official | Review statement and annotate appropriate accounting string information on a reconciled spreadsheet. Resolve discrepancies with the vendor prior to forwarding to the TO office. |
| The designated approving official's dated signature on the statement is appropriate for R&A. |
| Forward the invoice/statement and report to the TO office for processing. |
| Travel Operations | Reconcile invoice/statement and process claim for payment. |


**1.35.3.5.2.7** **(10-03-2019)**

##### Delegated Leases

1. The General Services Administration (GSA) has delegated to Treasury the authority to directly enter into lease contracts. Facilities Management and Security Services (FMSS) is responsible for the day-to-day management of the leased property.

2. The FMSS budget analyst enters both R&A on or about the 25th day of the month for the current month lease charges.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| FMSS Budget Analyst | Enter R&A on or about the 25th day of the month for the current month. |
| Accounts Payable | Review R&A to ensure payments are ready to be systematically generated. |
| Review vendor record for active registration in the System for Award Management. |
| Process disbursements. |


**1.35.3.5.2.8** **(09-06-2023)**

##### Disclosure of Information-Administrative Claims

1. Taxpayers can receive a monetary judgment if the IRS has improperly disclosed their tax return information.

2. The R&A dates are the date of acknowledgement that the claim letter was accepted by the claimant.


**1.35.3.5.2.9** **(09-06-2023)**

##### Employee Reimbursables

1. Employees may be reimbursed for expenses that the agency determines are necessary to perform employment requirements and approved by management. Reimbursements may include but are not limited to textbooks, transcripts, copies, work-related phone calls, notary seal and stamp, postage, pictures, employee recognition ceremony expenses, the cost to obtain a certified public accountant license, an employee’s membership in a state bar association when membership is required to maintain a license to practice law, repairs made to a government vehicle which are paid for by an employee, etc. Employees may be reimbursed for authorized tuition when permitted by 5 U.S.C. 4107, certified public accountant review and bar review fees when permitted by 5 U.S.C. 5757, or training fees charged as permitted by 5 U.S.C. 4109 that are necessary expenses of training or enrollment in review courses that the agency determines will enhance knowledge, skill, and abilities important to an employee’s performance of official duties.

2. Both the R&A dates are the date the approving/authorizing official signs and dates the SF 1034, Public Voucher for Purchases and Services Other Than Personal. If there are two approval signatures on SF 1034, the latest approval signature date serves as both the R&A dates. If the approval signature is undated, then the date that Accounts Payable receives the SF 1034 serves as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Claimant (Employee) | Submit SF 1034, Public Voucher for Purchases and Services Other Than Personal, with backup documentation showing the item was paid (receipt). |
| Designated Approving Official | Review SF 1034 for R&A and annotate corresponding requisition information. |
| The designated approving official's dated signature on the SF 1034 is appropriate for R&A. |
| Forward SF 1034 to Accounts Payable for payment. |
| Accounts Payable | Process SF 1034 for payment. |


**1.35.3.5.2.10** **(08-26-2021)**

##### Federal Employees Compensation Act

1. The Federal Employees Compensation Act requires government agencies to pay for government workers’ compensation benefits each fiscal year. The Department of Labor (DOL) is responsible for estimating the actuarial liability for workers’ compensation benefits. The DOL provides reports on worker’s compensation charge-backs and the year-end actuarial liability balance. The DOL charges the IRS for workers’ compensation charges annually. These charges are paid two years in arrears.

2. The Corporate Budget financial plan manager provides supporting documentation for the IPAC and submits the IPAC Billing Certification/Processing Form accordingly.

3. The accomplished date of the IPAC is used as the R&A dates.

4. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Notify Financial Reports office that an IPAC has been received and the amount of IPAC. |
| Designated Funding Official | Provide supporting documentation. |
| Complete, sign and date IPAC Billing Certification/Processing form. |
| Verify accurate funding information is noted on documents. |
| Forward IPAC Billing Certification/Processing form to designated approving official. |
| Designated Approving Official | Complete, sign and date IPAC Billing Certification/Processing form. |
| The designated approving official’s dated signature on the IPAC Billing Certification/Processing form is appropriate for R&A. |
| Forward IPAC Billing Certification/Processing form to IPAC for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Post IPAC |


**1.35.3.5.2.11** **(08-26-2021)**

##### Federal Telecommunication Services

1. The GSA bills the IRS for Federal Telecommunication Services charges monthly. Intragovernmental & Funds Processing receives the charges through IPAC on or about the 25th of the month for the previous month’s charges.

2. The accomplished date of the IPAC is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Forward copy of the IPAC charge/bill, IPAC Billing Certification/Processing form and backup documentation to end user. |
| End User/Approving Official | Contact designated funding official for funding approval. |
| Retrieve additional backup documentation necessary to review and verify all invoiced charges are correct. Reconcile discrepancies with GSA. |
| Forward documentation to designated funding official. |
| The end user's dated signature on IPAC Billing Certification/Processing form is appropriate for R&A. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward all documents to IPAC for processing. |
| Review and certification must be completed timely and forwarded to IPAC to ensure charges are processed within 30 calendar days of billing. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.12** **(08-26-2021)**

##### Foreign Service Accounts

1. The Foreign Service Accounts program accounts for disbursements and collections made by the Department of State on behalf of IRS employees working in foreign countries.

2. The month-end date of the Voucher Auditor’s Detail Report (VADR) is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Reconcile SF 1221, Statement of Transactions, the list of vouchers, and the auditor's detail report against the CARS account statement. |
| Forward electronic copy of SF 1221 detail information for each financial service to financial analyst for approval. |
| Financial Analyst/Approving Official | Complete review and input obligation number, line number, dollar amount, POP and appropriation. |
| Sign and return documents to the IPAC unit for processing. |
| The financial analyst's dated signature on the approval report is appropriate for R&A. |
| Forward to the IPAC unit within 60 business days of receipt of SF1221, the list of vouchers, and the voucher auditor’s detail report. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.13** **(10-03-2019)**

##### Fuel/Maintenance

1. The government fleet card is used for the purchase of fuel and minor automotive-related items such as wiper blades, car washes and maintenance for government vehicles when not covered under the warranty or maintenance agreement plan provisions.

2. Citibank Fleet - Both the R&A dates are the date the designated approving official/designated agency office signs and dates the invoice.

3. Wright Express - Both the R&A dates are the date the designated approving official/designated agency office signs and dates the invoice.

4. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Submit by mail or electronically a monthly invoice/statement to the approving or agency office. |
| Designated Approving Official / Designated Agency Office | Review invoice/statement for approval of payment. |
| Sign, date and annotate requisition reference number for each line item on government reconciliation worksheet. |
| The approving official’s or agency office’s dated signature on the invoice is appropriate for R&A. |
| Forward signed invoice/statement and the government reconciliation worksheet to Accounts Payable for processing. |
| Accounts Payable | Process invoice/statement for payment. |


**1.35.3.5.2.14** **(10-03-2019)**

##### Inter-governmental Personnel Act Agreements

1. The IRS occasionally enters into an agreement with an organization (usually a university) to employ temporarily one or more of its employees for a specific period of time. The IRS reimburses the salary and benefits to the organization or these services.

2. Both the R&A dates are the last date of the billed service period, unless the agreement authorizes advance payment. If advance payment is authorized, both the R&A dates are the beginning date of the period of performance.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Outside Employer (university, etc.) | Submit invoice to Accounts Payable. |
| Accounts Payable | Submit proper invoice to appropriate designated approving official for approval. |
| Designated Approving Official | The designated approving official's dated signature on the OF 69, Assignment Agreement, is appropriate for R&A. |
| Forward OF 69 to Accounts Payable. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward documents to Accounts Payable for processing. |
| Accounts Payable | Process invoice for payment. |


**1.35.3.5.2.15** **(10-03-2019)**

##### Internal Revenue Bills of Lading - Commercial

1. Internal Revenue Bills of Lading (IRBLs) - Form 12741, Internal Revenue Service Bill of Lading, are for freight and other transportation-related services incurred by the IRS while transacting official government business.

2. The receipt date is the actual delivery date annotated in Block 18a on Form 12741. The acceptance date is the date the designated approving official signs the SF 1113, Public Voucher for Transportation Charges, and Form 12741.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Transportation Service Provider | Submit SF 1113, Public Voucher for Transportation Charges, and Form 12741, Internal Revenue Service Bill of Lading, to the pre-payment audit vendor for pre-audit. |
| Pre-Payment Audit Vendor | Date stamp and review the SF 1113 and Form 12741 for accuracy. |
| Conduct the pre-audit and forward documents to the designated approving official. |
| Designated Approving Official | Date stamp the SF 1113 and Form 12741 and perform a secondary review of the documents. |
| Verify IRBL obligation number on Form 12741. |
| Return documents to the Transportation Service Provider (TSP) for corrections or sign, date and forward to Accounts Payable for processing. |
| The delivery date annotated by the TSP in block 18a on Form 12741 is appropriate for receipt. The designated approving official's dated signature on the SF 1113 with attached Form 12741 is appropriate for acceptance. |
| Accounts Payable | Process the SF 1113 with attached Form 12741 for payment. |


**1.35.3.5.2.16** **(09-09-2024)**

##### Internal Revenue Bills of Lading - Relocation

1. Travel Operations uses the term IRBLs to refer to the set of documentation submitted by the TSP for payment of services performed.

2. Form 13135, Internal Revenue Service Bill of Lading - Privately Owned Personal Property, is the standardized transportation document issued by the IRS. Business units accept Form 13135 as a receipt of goods and evidence of title. Each IRBL authorizes a TSP to perform specific origin, transportation, storage and destination services. The Form 13135 must accompany the invoice and supporting documentation.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Transportation Service Provider | Submit an invoice (commonly SF 1113, Public Voucher for Transportation Charges) supported by the completed IRBL, weight certificates, additional services forms, inventories, etc. |
| Submit invoice and supporting documentation to the address noted in the "Bill Charges to" section of Form 13135, Internal Revenue Service Bill of Lading - Privately Owned Personal Property. |
| Pre-Payment Audit Contractor | Date stamp, note the auditor and certify household goods have shipped. |
|  |
| Forward documentation to the supply management specialist (Taxpayer Services), after pre-payment audit has been completed. |
| The pre-payment audit contractor's stamp on the invoice is appropriate for R&A. |
| Taxpayer Services Supply Management Specialist/Designated Approving Official | Date stamp documents as received. |
| Verify relocation obligation number supplied to the mover by the Travel Operations relocation coordinator is annotated. |
| Approve, sign and date invoice. |
| Place approved document on the pre-payment audit contractor's website for retrieval by the TO relocation technicians to process. |
| Travel Operations | Process invoice for payment. |


**1.35.3.5.2.17** **(09-06-2023)**

##### Judgment Fund (Small Claims)

1. The judgment fund is for small claims requested by taxpayers for reimbursement of expenses incurred due to erroneous levy bank charges, lost or misplaced checks, or bank fees arising from direct deposit installment agreement processing errors. Taxpayers make the small claims requests through local IRS offices.

2. The Bureau of the Fiscal Service delegated the authority to the IRS to make small claims payments under $1,000.

3. Each office provides a memorandum of approval from the campus director or his or her designee for a batch of claims.

4. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| --- | --- |
| Taxpayer | File Form 8546, Claim for Reimbursement of Bank Charges with local campus office. Provide evidence to support the claim. |
| Campus Director/Designee | Submit approval memorandum, along with Form 8546, to designated approving official. |
| Designated Approving Official | Review and complete valid cases on FMS Form 197, Judgment Fund Voucher for Payment, and forward with approval memorandum to Accounts Payable for processing. |
| The designated approving official's dated signature on FMS Form 197 is appropriate for R&A. |
| Accounts Payable | Process FMS Form 197 for payment, using the Bureau of the Fiscal Service approved accounting string. |


**1.35.3.5.2.17.1** **(10-03-2019)**

###### Judgment Fund (Small Claims - Individual Taxpayer Identification Numbers)

1. The judgment fund also represents small claims requested by taxpayers throughout the country for reimbursement of expenses incurred due to errors in processing individual tax identification applications.

2. The Bureau of the Fiscal Service delegated the authority to the IRS to make small claims payments under $1,000.

3. The claims are sent by the taxpayer to the IRS claims manager who processes each claim and provides reimbursement from the judgment fund when warranted.

4. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| --- | --- |
| Taxpayer | Complete Form 5646, Claim for Damage, Injury, or Death and forward to the IRS claims manager. |
| Designated Approving Official/IRS Claims Manager | Complete FMS Form 197, Judgment Fund Voucher for Payment and forward with the approval memorandum to Accounts Payable for processing. |
| The designated approving official’s dated signature on the FMS Form 197 is appropriate for R&A. |
| Accounts Payable | Process FMS Form 197 for payment, using the Bureau of the Fiscal Service approved accounting string. |


**1.35.3.5.2.18** **(10-03-2019)**

##### Lien Fees

1. Revenue officers incur lien fees in order to record the filing or releasing of liens placed on U.S. taxpayers’ properties in connection with tax liabilities.

2. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| --- | --- |
| Designated Agency Office | Print lien recording/release documents from ALS. |
| Submit lien recording/release documents to appropriate recording offices. |
| Designated Approving Official | Certify lien document (billing support voucher) in ALS. |
| The dated acceptance of the lien document for payment by the designated approving official in ALS is appropriate for R&A. |
| Accounts Payable | Ensure lien file interfaces properly from ALS to IFS. |


**1.35.3.5.2.19** **(08-26-2021)**

##### Low Income Taxpayer Clinics

1. The Low Income Taxpayer Clinics (LITC) program provides matching grants for organizations that provide legal assistance to low-income taxpayers in controversies with the IRS and informs individuals for whom English is a second language of their tax rights and responsibilities.

2. The payee report is downloaded twice a month; five days before the end of the month and then the first or second day of the following month. The posting date of the document in IFS is used as R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Retrieve the Central Accounting Reporting System (CARS) Account Statement. |
| Forward the CARS Account Statement to the program analyst. |
| Program Analyst | Download the payee report from the United States Department of Health and Human Services payment management system for review and approval. |
| Approve charges by recording both R&A on the Billing Certification/Processing Form. |
| Forward documents to the Intragovernmental & Funds Processing - IPAC unit for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.20** **(10-03-2019)**

##### Miscellaneous Medical Services

1. Miscellaneous medical service charges are reimbursed to IRS employees, their dependents, and the physician/clinic/hospital for medical care incurred while the employee is working in a foreign country.

2. The Department of State's claim examiner's/designated approving official’s dated signature is necessary for R&A on the MED-254, Voucher for Medical Services.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Claimant (employee, dependent(s) of employee, physician, clinic, hospital, etc.) | Submit a copy of the Department of State's MED-254, Voucher for Medical Services, to the third party vendor. |
| Third Party Vendor | Complete and submit MED-254 to the Department of State’s claims examiner/designated approving official. |
| Designated Approving Official | Date stamp MED-254 and review for accuracy. |
| Complete the review and record the corresponding requisition number on MED-254. |
| The claims examiner's/designated approving official's dated signature on the MED-254 is appropriate for R&A. |
| Forward MED-254 to Accounts Payable for processing. |
| Accounts Payable | Process MED-254 for payment. |


**1.35.3.5.2.21** **(08-26-2021)**

##### Motor Pool

1. Motor pool includes charges billed to the IRS by GSA for the rental, mileage and maintenance of government vehicles. GSA bills via IPAC monthly.

2. The accomplished date of the IPAC is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Send IPAC Billing Certification/Processing form and a copy of invoice to designated approving official. |
| Designated Approving Official | Review invoice for accuracy. Reconcile discrepancies with GSA. |
| Complete, sign and date IPAC Billing Certification/Processing form. |
| The designated approving official's dated signature on the IPAC Billing Certification/Processing form is appropriate for R&A. |
| Forward documentation to the designated funding official or return to the IPAC unit for additional processing. |
| The review and certification should be completed and sent to the IPAC unit within 10 calendar days of the IPAC billing statement. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Complete, sign and date IPAC Billing Certification/Processing form. |
| Forward documents to the IPAC unit for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.22** **(09-09-2024)**

##### Packers Authorizations (Relocation Transportation Invoices)

1. The Department of State prepares Form DS-1573, Packers Authorization, on behalf of the IRS for employees relocating overseas. The form contracts one Transportation Service Provider (TSP) for the following services:



1. Picking up household goods and personal effects

2. Preparing all or part of the shipment for overseas transportation

3. Placing any remaining part of the shipment into non-temporary/permanent storage for the duration of the overseas tour of duty

4. Delivering the household goods from storage at the conclusion of the employee's tour of duty


2. The receipt date is the date found on SF 1034, Public Voucher for Purchases and Services Other Than Personal, under the column heading "Date of Delivery or Service." The acceptance date is the end date for period of performance.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Transportation Service Provider | Review and submit Form DS-1573, Packers Authorization, with attached SF 1034, Public Voucher for Purchases and Services Other Than Personal, to the billing address found on Form DS-1573. |
| Taxpayer Services Supply Management Specialist/Designated Approving Official | Date stamp documents as received. |
| Verify relocation obligation number supplied to mover by the TO relocation coordinator annotated on the document. |
| Approve charges for payment by signing and dating appropriate section of SF 1034. |
| The designated agency office's dated signature on the SF 1034 is appropriate for R&A. |
| Forward to the TO office for processing. |
| Travel Operations | Process SF 1034 for payment. |


**1.35.3.5.2.23** **(09-06-2023)**

##### Personal Property Claims

1. Personal property claim payments are made to employees (claimants) who suffer damage or loss to their personal property incident to service. Such claims may also be submitted on behalf of the estate of a deceased employee meeting the same conditions.

2. Responsibilities




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Employee | Submit Treasury Department Form (TDF) 32-13.1, Employee Claim for Loss or Damage to Personal Property and TDF 32-13.2 Schedule of Property, with supporting documentation and appropriate signatures to the claims manager, General Legal Services, in the Office of Chief Counsel. |
| IRS Claims Manager/Designated Approving Official | Review and certify that claim meets requirements of the Military Personnel and Civilian Employees' Claims Act. |
| Issue a memorandum identifying amount to be paid. |
| The claims manager's dated signature on memorandum is appropriate for R&A. |
| Forward memorandum to appropriate designated funding official. |
| Designated Funding Official | Verify accurate funding information. |
| Forward documents to Accounts Payable for processing. |
| Accounts Payable | Process claim for payment. |


**1.35.3.5.2.24** **(08-26-2021)**

##### Printing

1. Printing includes charges billed to the IRS by the Government Printing Office (GPO) for various printing and reproduction services for IRS Media and Publications. It also includes the purchase of laser paper and roll paper for IRS print sites. The accomplished date of the IPAC is used as the R&A dates.

2. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Forward a copy of the IPAC charge/bill and IPAC Billing Certification/Processing form to the designated approving official. |
| Designated Approving Official | Review invoice to verify all charges are proper and that GPO has charged the correct amount. If discrepancies exist, reconcile with GPO. |
| For media and publications print orders, the publishing system database generates a report after the designated approving official has reviewed and verified the accuracy of all charges. Report is attached to a certification memorandum and forwarded to the IPAC unit for processing. |
| Sign and date IPAC Billing Certification/Processing form and forward to designated funding official for signature. |
| The designated approving official's dated signature on the IPAC Billing Certification/Processing form is appropriate for R&A. |
| The review and certification should be completed and forwarded to the IPAC unit within 10 calendar days. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Complete, sign and date IPAC Billing Certification/Processing form. |
| Forward documents to the IPAC unit for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.25** **(08-26-2021)**

##### Reimbursable Work Authorizations/Security Work Authorizations

1. The GSA bills the IRS for work performed against a specific Reimbursable Work Authorization (RWA), according to the provisions of the agreement. The GSA bills Intragovernmental & Funds Processing through IPAC monthly. The Department of Homeland Security (DHS) bills the IRS for work performed against a specific security work authorization, according to the provisions of the agreement. The DHS bills Intragovernmental & Funds Processing through IPAC two to three times per month.

2. The accomplished date of the IPAC is used as the R&A dates.

3. There are four types of RWAs:



1. Type A is used for large alteration projects and office moves related to lease expirations that have a five-year life span.

2. Type N is used for one-time repairs and general maintenance projects.

3. Type F is used to establish "open-ended" accounts with GSA for all general maintenance items in federal buildings that expire at the end of each fiscal year.

4. Type R is used for services that cannot be readily separated from normal operating costs, such as overtime utilities, custodial, guard services, etc. These types of services usually have a fiscal year limitation.



      ### Note:



      _Expenses must be captured in the correct month and correct fiscal year. Do not use the entire period of performance as the receipt date_.


4. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Forward copy of IPAC billing statement and IPAC Billing Certification/Processing form to designated approving official and designated funding official. |
| Designated Approving Official | Review the IPAC billing statement to verify that charges are accurate. If discrepancies exist, reconcile with GSA/DHS. |
| Complete, sign and date IPAC Billing Certification/Processing form. |
| The designated approving official's dated signature on the IPAC Billing Certification/Processing is appropriate for R&A. |
| Return documents to the designated funding official. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Complete, sign and date IPAC Billing Certification/Processing form. |
| Forward documents to the IPAC unit for processing. |
| The review and certification should be completed and forwarded to the IPAC unit within 10 calendar days of the IPAC billing statement. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.26** **(10-03-2019)**

##### Representation Fund

1. The representation fund is a budgetary allocation fund that is used to facilitate official receptions and representation activities which further the interests of the United States tax administration system in foreign countries. Such activities are intended to increase cooperation with foreign governments and with public or private organizations outside of the federal government.

2. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| IRS Official | Submit SF 1034, Public Voucher for Purchases and Services Other Than Personal, to designated business unit approving official. Voucher must provide the payee’s name, address, reason for payment and support for payment. |
| Designated Approving Official | Review SF 1034 and supporting documentation, verify billed amount and record the corresponding requisition number on the SF 1034. |
| Complete, sign and date the SF 1034. |
| The designated approving official's dated signature on the SF 1034 is appropriate for R&A. |
| Forward completed and signed SF 1034 to Accounts Payable for processing. |
| Accounts Payable | Process SF 1034 for payment. |


**1.35.3.5.2.27** **(10-03-2019)**

##### Settlement Agreements

1. A settlement agreement is a monetary award to a claimant for equal employment opportunity disputes, National Treasury Employees Union settlements, etc., generated out of the Office of Chief Counsel.

2. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Office of Chief Counsel/Designated Approving Official | Prepare a settlement agreement. |
| Issue a memorandum of approval for each settlement agreement. The memorandum of approval will contain claimant’s name, mailing address, tax identification number, purpose, amount and date payment is to be issued. |
| The Office of Chief Counsel's or designated approving official's dated signature on the memorandum is appropriate for R&A. |
| Forward settlement agreement, memorandum of approval and any other supporting documentation to designated funding official. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward documents to Accounts Payable for processing. |
| Accounts Payable | Process memorandum of approval for payment. |
| **Note**: _Settlement agreements traditionally have specific due dates stated within the agreements. These dates must be met in order to avoid additional litigation._ |


**1.35.3.5.2.28** **(08-26-2021)**

##### Tax Counseling for the Elderly

1. The Tax Counseling for the Elderly program is available to all eligible taxpayers but is generally intended for those 60 years of age or older and are disabled or who have other special needs.

2. The payee report is downloaded twice a month; five days before the end of the month and then the first or second day of the next month. The posting date of the document in IFS is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Retrieve CARS account statement. |
| Forward CARS account statement to the program analyst. |
| Program Analyst | Download payee report from the United States Department of Health and Human Services payment management system for review and approval. |
| Approve the charges by recording both R&A on the Billing Certification/Processing Form. |
| Forward documents to the IPAC unit for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Retrieve CARS account statement and confirm the entries posted from the certification. |
| Post disbursement and collections. |


**1.35.3.5.2.29** **(08-26-2021)**

##### Telephones (Government)

1. GSA bills the IRS for telephone service monthly. Intragovernmental & Funds Processing receives the charges through IPAC.

2. The accomplished date of the IPAC is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| GSA | Update the telecommunications ordering and pricing system website by the 6th calendar day of each month, with billing information from the previous month. |
| Intragovernmental & Funds Processing - IPAC unit | Notify designated approving officials that the billing information is available on telecommunications ordering and pricing system and certification is due within 10 workdays. |
| Designated Approving Official | Retrieve backup documentation from the telecommunications ordering and pricing system, review invoice to verify the telephone charges are proper, and reconcile discrepancies with GSA. |
| Complete the IPAC Billing Certification/Processing form. |
| The designated approving official's dated signature on the IPAC Billing Certification/Processing is appropriate for R&A. |
| Forward IPAC Billing Certification/Processing form to designated funding official. |
| Forward to the IPAC unit within 10 calendar days of IPAC billing statement. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward documents to the IPAC unit for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.2.30** **(10-03-2019)**

##### Torts

1. Tort claim payments are made to claimants, usually non-employees, who suffer damages due to negligent actions by IRS employees who are acting within the scope of their official duty. The Federal Tort Claims Act covers tort claims.

2. Both the R&A dates are the claims manager’s dated signature on SF 1145, Voucher For Payment Under Federal Tort Claims Act.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Claimant (non-employee) | Complete IRS Form 5646, Claim for Damage, Injury, and Death, and mail to claims manager, General Legal Services, in the Office of the Chief Counsel. |
| Claims Manager | Review and make offer of settlement. If settlement is $2,500 or less, mail SF 1145, Voucher for Payment Under Federal Tort Claims Act, to claimant. If settlement is more than $2,500, mail F 197, Judgment Fund Voucher, to claimant. |
| Claimant | Indicate acceptance of the offered settlement by signing either SF 1145 or F 197 and forwarding the signed voucher to the claims manager. |
| Claims Manager/Designated Approving Official | Certify claim for payment upon receipt of the accepted SF 1145 or F 197 and forward to designated funding official. |
| The claims manager's dated signature on the SF 1145 or the F 197 is appropriate for R&A. |
| Designated Funding Official | Verify accurate funding information is noted on vouchers. |
| Forward SF 1145 to Accounts Payable. Forward F 197 to Bureau of Fiscal Service Judgment Fund Branch. |
| Accounts Payable or Judgment Fund Branch | SF 1145 is processed by Accounts Payable through PPS. F 197 is processed by Bureau of Fiscal Service Judgment Fund Branch through JFICS. |


**1.35.3.5.2.31** **(08-26-2021)**

##### Training (Out-Service) (Non-Purchase Card)

1. Out-service training covers training courses, seminars and conferences conducted by other government or non-government organizations.

2. If the training is procured via a method other than the SF 182, Authorization Agreement and Certification of Training, the R&A criteria established for the appropriate procurement process is used.

3. The accomplished date of the IPAC is used as the R&A dates.

4. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Vendor | Submit invoice to IPAC. |
| Designated Approving Official | If after training end date, verify attendance, sign and date Block F of SF 182, Authorization Agreement and Certification of Training. The approving official’s certification signature is appropriate for R&A. If prepay is required, sign and date Block F and indicate "Prepay Authorized" . |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Intragovernmental & Funds Processing - IPAC unit | Process SF 182 for payment. |


**1.35.3.5.2.32** **(08-26-2021)**

##### Unemployment Compensation for Federal Employees

1. States report unemployment compensation claims for federal employees to TALX Corporation. TALX Corporation, in turn, bills the Department of Labor. The Department of Labor sends an invoice through IPAC to the IRS for all of the Department of Treasury's compensation charges quarterly.

2. The financial plan manager provides supporting documentation for each bureau's charges and submits the IPAC Billing Certification/Processing form accordingly. The IRS collects, from each bureau, a portion of the compensation claims through IPAC, according to the breakdown of the supporting documentation.

3. The designated funding official records the quarterly POP on the IPAC Billing Certification/Processing Form in lieu of R&A. For example, October 1, 2018 - December 31, 2018.

4. The accomplished date of the IPAC is used as the R&A dates.

5. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC | Contact the Unemployment Compensation for Federal Employees funding official after receiving IPAC from Department of Labor. |
| Designated Funding Official | Provide supporting documentation for each agency charge. |
| Complete, sign and date the IPAC Billing Certification/Processing form. |
| Verify accurate funding information is noted on documents. |
| Forward IPAC Billing Certification/Processing form to designated approving official. |
| Submit breakdown by bureau to IPAC. |
| Designated Approving Official | Complete, sign and date IPAC Billing Certification/Processing form. |
| The designated approving official's dated signature on the IPAC Billing Certification/Processing is appropriate for R&A. |
| Forward IPAC Billing Certification/Processing form to the IPAC unit for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Review breakdown of services provided by TALX Corporation. |
| Post IPAC charging each bureau for its respective portion of the services. |


**1.35.3.5.2.33** **(10-03-2019)**

##### Uniform Allowance

1. IRS offices may employ physicians and nurses as part of the operation of the health services program. Uniform allowances cover the cost of the required uniforms for these health care employees in the normal course of their duties.

2. Uniform allowances also cover steel-toe boots for warehouse, maintenance and dyed diesel inspection workers.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Employee | Submit allowance requested on SF 1034, Public Voucher for Purchases and Services Other Than Personal, to designated approving official. |
| Designated Approving Official | Review SF 1034. |
| The designated approving official's dated signature on the SF 1034 is appropriate for R&A. |
| Forward SF 1034 to designated funding official. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward documents to Accounts Payable for processing. |
| Accounts Payable | Process SF 1034 for payment. |


**1.35.3.5.2.34** **(09-06-2023)**

##### Volunteer Income Tax Assistance

1. The Volunteer Income Tax Assistance (VITA) program offers free tax assistance for low-to-moderate income individuals who cannot afford professional services. VITA volunteers prepare basic tax returns for low-to-moderate income taxpayers including persons with disabilities, non-English speaking persons and the elderly.

2. The payee report and/or the Charges by Appropriation (CBA) Report is downloaded twice a month; five days before the end of the month and then the first or second day of the next month. The posting date of the document in IFS is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Program Analyst | Download the Payee Report and/or the Charges by Appropriation (CBA) Report from the United States Department of Health and Human Services Payment Management System (PMS) to review and approval. |
| Approve the charges by recording R&A on the Billing Certification/Processing Form. |
| Forward documents to the IPAC unit for processing. |
| Stakeholder Partnerships, Education & Communication (SPEC) Finance | Review and approve the R&A on the Billing Certification/Processing Form, Payee Report and/or the Charges By Appropriation (CBA) Report from the United States Department of Health and Human Services Payment Management System submitted by the Grant Program Office (GPO). |
| Verify funding is available in IFS, the funding appropriation is correct, and the obligation number is correct. |
| Forward the approved/signed certification to the GPO. |
| Intragovernmental & Funds Processing - IPAC unit | Retrieve the CARS account statement and confirm the entries posted from the certification. |
| Post disbursements and collections. |


**1.35.3.5.2.35** **(10-03-2019)**

##### Witness Fees

1. Witness fees and travel expenses are payable on request to witnesses who are required to appear to give testimony or produce records before IRS personnel in compliance with administrative summonses. Witnesses should file claims on a Standard Form 1157, Claim for Witness Attendance Fees, Travel and Miscellaneous Expenses. Generally, advances may not be granted except under extenuating circumstances. All requests for advances must be formally submitted to Accounts Payable.

2. Both the R&A dates are the last day the witness appeared in court.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Claimant (Subpoenaed Witnesses) | Submit SF 1157, Claims for Witness Attendance Fees, Travel and Miscellaneous Expenses, (including the witness signature and social security number) with supporting documentation, to the appropriate counsel office. |
| Counsel Office | Sign and date SF 1157. |
| Forward SF 1157 to the designated approving official for review and acceptance. |
| Designated Approving Official | Review claim and apply outstanding advances against claim made by witness. |
| Determine final amount due to witness and annotate authorized payment amount either by memorandum or on the SF 1157. |
| Complete SF 1157, including the funding information. |
| The designated approving official's dated signature on SF 1157 is appropriate for R&A. |
| Forward SF 1157, memorandum (if applicable) and supporting documentation to Accounts Payable for processing. |
| Accounts Payable | Process SF 1157 for payment. |


**1.35.3.5.3** **(10-03-2019)**

#### Non-Procurement or Procurement Orders

1. The following programs are considered either non-procurement or procurement based on the business unit method used.


**1.35.3.5.3.1** **(10-03-2019)**

##### Ratifications (Procurement)

1. An unauthorized commitment is an agreement that is not binding because the government representative did not possess the authority to enter into the agreement. Ratification permits an IRS official with appropriate authority to approve non-procurement and procurement purchases.

2. The receiver must use the R&A criteria established for the appropriate procurement process when entering R&A. In the event the goods and services have been inspected and determined to be acceptable, the award date associated with the ratification is appropriate for R&A.

3. Policy and Procedures Memorandum No.1.6(A), Ratification Procedures, provides procedures for the ratification of unauthorized commitments. For additional guidance concerning ratification, the contracting officer should contact the Office of Procurement Policy, Policy and Procedures Branch or the appropriate General Legal Services office for assistance.


**1.35.3.5.3.1.1** **(10-03-2019)**

###### Ratifications (Non-Procurement)

1. For non-procurement ratifications, contact the business unit for the proper procedure.


**1.35.3.5.3.2** **(08-26-2021)**

##### Rent (Non-Procurement)

1. GSA bills the IRS for rent charges on a monthly basis. Intragovernmental & Funds Processing receives the charges through IPAC on or about the 20th day of the month for the month’s rent charges.

2. The accomplished date of the IPAC is used as the R&A dates.

3. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Notify the rent program analyst and designated approving official that the IPAC has been received and the IPAC amount. Forward the IPAC documentation to both individuals. |
| Program Analyst | Review invoice for accuracy. Reconcile invoice and data resident information in the graphic database interface system. Resolve discrepancies with GSA. |
| Forward the information to the designated approving official after review is completed. |
| Designated Approving Official | Prepare and sign IPAC Billing Certification/Processing form. |
| Forward documentation to designated funding official. |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| The designated funding official's dated signature on the IPAC Billing Certification/Processing is appropriate for R&A. |
| Forward documents to the IPAC unit timely to ensure processing within 30 calendar days of the IPAC billing statement. |
|  |
| Intragovernmental & Funds Processing - IPAC unit | Post disbursements and collections. |


**1.35.3.5.3.2.1** **(10-03-2019)**

###### Rent (Procurement)

1. See IRM 1.35.3.5.1.4, Purchase Orders, Contracts and Delivery Orders, for purchase orders.


**1.35.3.5.3.3** **(08-26-2021)**

##### Treasury Franchise Fund/Shared Support Program (also known as Departmental Franchise Fund) (Non-Procurement)

1. The Treasury Franchise Fund/Shared Support Program is an intra-departmental service operations fund administrated by the Department of the Treasury. It provides goods and services such as telecommunications, printing and reproduction, and equipment, through a centralized service fund that provides common services benefitting customers both within and outside Treasury bureaus.

2. The interagency agreement is signed by the CFO at the beginning of the fiscal year and a copy is sent to IPAC.

3. The designated funding official submits Form 2785, Requisition/Obligation Estimate Adjustment Notice, for the funds to be obligated.

4. The IPAC receives the charges around the 20th of each month.

5. The accomplished date of the IPAC is used as the R&A dates.

6. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Forward a copy of the IPAC charge/bill and IPAC Billing Certification/Processing form to end user. |
| End User/Approving Official | Review one copy of the monthly financial plan and one with IOCs to ensure invoice is accurate. Signs IPAC Billing Certification/Processing form. |
| The signed IPAC Billing Certification/Processing form is appropriate for R&A. |
| Forward documentation to the designated funding official. |
| Designated Funding Official | Review documents to verify accurate funding information and sign the IPAC Billing Certification/Processing form. |
| Forward documents to the IPAC unit for processing. |
| Intragovernmental & Funds Processing - IPAC unit | Process disbursements and collections. |


**1.35.3.5.3.3.1** **(09-06-2023)**

###### Treasury Franchise Fund/Shared Support Program (also known as Departmental Franchise Fund) (Procurement)

1. See IRM 1.35.3.5.1.4, Purchase Orders, Contracts and Delivery Orders and IRM 1.33.4.3.1.17, Treasury Franchise Fund for more purchase order information.


**1.35.3.5.3.4** **(10-03-2019)**

##### Utilities (Non-Procurement)

1. Utilities for energy costs such as heat, light, power, water, sewage, gas and electricity are usually procured by using one of two methods:



1. Reimbursable Work Agreement

2. Purchase order


2. When performing R&A for utilities, the receiver must use the R&A criteria established for the appropriate procurement process. Utilities can be either a procurement or non-procurement purchase. If procured through a RWA, the receipt date is the actual date of the services. If this information is not available, the business unit must use the accomplished date of the IPAC charge or the POP ending date, whichever is earliest, for receipt date purposes. The acceptance date is the date the certification form is received. If procured through a purchase order, both the R&A dates are the statement closing date.

3. Per Federal Acquisition Regulation (FAR) 52.241-3, Scope and Duration of Contract, “For the period **(insert period of service)**, the contractor agrees to furnish, and the government agrees to purchase **(insert type of service**) utility service in accordance with the applicable tariff(s), rules and regulations as approved by the applicable governing regulatory body and as set forth in the contract.” The R&A should be performed immediately to allow sufficient time for payment processing and to avoid late payment fees.

4. See IRM 1.35.3.5.2.25, Reimbursable Work Authorizations/Security Work Authorizations, for the action process flow when a RWA is used to procure utilities.


**1.35.3.5.3.4.1** **(10-03-2019)**

###### Utilities (Procurement)

1. See IRM 1.35.3.5.1.4, Purchase Orders, Contracts and Delivery Orders, for more purchase order information.


**1.35.3.5.4** **(09-06-2023)**

#### Advances

1. Advances, or advance payments, are made by the IRS to its employees, contractors, grantees or others prior to receiving goods and services when authorized by law. Examples of recorded advance payments include the purchase of postage and public transportation through DOT/PTSP, as detailed below. See IRM 1.33.3, Reimbursable Operating Guidelines, for more information.

2. The following chart illustrates the commitment to payment process flow for advances.




| **Action** | **Account(s) Affected** | **Action Result** |
| :-: | :-: | :-: |
| Create approved shopping cart in PPS, if required and post transaction to IFS real time. | Commitment | Reserves funds |
| Manually post order in IFS | Obligation - Undelivered Orders - Unpaid | Binds funds for future outlay and recognizes a legal requirement to purchase goods and services, and payment is made following R&A. |
| Post/record IPAC (Advance/Prepayment) | Obligation - Paid Undelivered Order, Advances to Others, and Cash | Records advance payment and reduces fund balance with Treasury. |
| Enter/record receipt | Obligation - Unpaid Delivered Order and Accounts Payable | Recognizes that the government has received delivery of the goods and services, establishes an accrual, and liquidates the obligation. |
| Enter/record acceptance |  | The government acknowledges that goods and services meet its requirements, and it is required to pay vendor. |


**1.35.3.5.4.1** **(08-26-2021)**

##### Department of Transportation/Public Transit Subsidy Program

1. The Department of Transportation (DOT) provides public transportation to IRS Employees. The DOT invoices via IPAC quarterly for a fourth of the annual estimate.

2. Receipt and acceptance dates are the accomplished date of the IPAC to record the monthly advance and last day of the month being reported on the customer statement of transit benefits to record actual expenses that decrease the advance.

3. The IPAC unit sends an Advance Processing form to the designated funding official upon receipt of the monthly IPAC charge. The IPAC records the charge to an advance account upon receipt of the approved Advance Processing form. The accomplished date of the IPAC is the date used as the document date for the advance account. The accomplished date of the IPAC is used as the R&A dates.

4. The Customer Statement of Transit Benefits report is received from the IRS customer analyst monthly. The total for the month is entered on the Public Transit Subsidy Program (PTSP) Obligation-Expense Tracker report provided from the Administrative Financial Management Reporting office annually. The report allocates the costs by percentage to various accounting strings. The IPAC enters the actual expense, which decreases the advance amount.

5. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Receive IPAC from DOT. |
| Send Advance Processing form to the Corporate Budget. |
| Designated Approving Official | Review the invoice. |
| Complete the Advance Processing form. |
| The designated approving official's dated signature on the Advance Processing form is appropriate for R&A. |
| Return documents to the designated funding official. |
|  |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward documents to the IPAC unit within 10 calendar days of the IPAC billing statement. |
| Intragovernmental & Funds Processing - IPAC unit | Post the advance. |
| Program Office | IRS customer support analyst forwards customer statement of transit benefits report each month to the IPAC unit. |
| Intragovernmental & Funds Processing - IPAC unit | Enter total from the customer statement of transit benefits report on PTSP obligation-expense tracker spreadsheet. Post expense to draw down the advance. |


**1.35.3.5.4.2** **(08-26-2021)**

##### Postage

1. Postage includes charges incurred by the IRS from the United States Postal Service (USPS) for various postal expenses, such as postal meter charges and business penalty reply mail. The USPS invoices IPAC monthly for 1/12th of the annual postal estimate. The IPAC makes final adjustments to the estimates from a thirteenth billing, generally performed in October.

2. Each program office incurring postal expenses will sign and annotate the actual date of delivery for services on the Form 10580-A, Postage Purchase/Expenditure Report, and forwarded the documentation to IPAC within five workdays of the purchase. The IPAC enters the actual expense by using the current date, which decreases the advance amount.

3. The accomplished date of the IPAC is used as the R&A dates.

4. The IPAC unit sends an Advance Processing form to the designated funding official upon receipt of the monthly charge. The IPAC unit records the charge to an advance account upon receipt of the approved Advance Processing form. The accomplished date of the IPAC is the date used as the document date for the advance account.

5. The IPAC records actual expenses as incurred based on information provided by the program offices to clear the advance account.

6. Responsibilities:




| **RESPONSIBLE PARTY** | **TASKS** |
| :-: | :-: |
| Intragovernmental & Funds Processing - IPAC unit | Receive IPAC and an invoice from the USPS. |
| Send Advance Processing form and a copy of the IPAC Billing Certification/Processing form to the designated funding official. |
| Designated Approving Official | Review the bill. |
| Complete Advance Processing form. |
| The designated approving official's dated signature on the Advance Processing form is appropriate for R&A. |
| Return documents to designated funding official. |
|  |
| Designated Funding Official | Verify accurate funding information is noted on documents. |
| Forward documents to the IPAC unit within 10 calendar days of the IPAC billing statement. |
| Intragovernmental & Funds Processing - IPAC unit | Post the advance. |
| Program Office | Sign and annotate the actual date of delivery on Form 10580-A, Postage Purchase/Expenditure Report, indicating when the business unit received the goods and services. |
| Forward the documents to the IPAC unit within five workdays of the purchase. |
|  |
| Intragovernmental & Funds Processing - IPAC unit | Process documents to draw down the advance. |


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-035-003#addtoany "Show all")

A2A