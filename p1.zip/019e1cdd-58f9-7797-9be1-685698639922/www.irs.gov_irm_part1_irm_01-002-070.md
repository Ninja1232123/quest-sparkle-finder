---
url: "https://www.irs.gov/irm/part1/irm_01-002-070"
title: "1.2.70 Business Unit Delegations of Authority for Criminal Investigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-002-070#main-content)

- 1.2.70  [Business Unit Delegations of Authority for Criminal Investigation](https://www.irs.gov/irm/part1/irm_01-002-070#id1)
  - 1.2.70.1  [Program Scope and Objective](https://www.irs.gov/irm/part1/irm_01-002-070#id2)
  - 1.2.70.2  [Introduction to Business Unit Delegations of Authority for Criminal Investigation (CI)](https://www.irs.gov/irm/part1/irm_01-002-070#id3)
  - 1.2.70.3  [Delegation Order CI 1-1-1, Order of Succession and Designation to Act as Chief of Criminal Investigation and other Top-Level Executives](https://www.irs.gov/irm/part1/irm_01-002-070#id4)
  - 1.2.70.4  [Delegation Order CI 1-30-1, Authorization and Approval of Official Travel within the United States](https://www.irs.gov/irm/part1/irm_01-002-070#id5)
  - 1.2.70.5  [Delegation Order CI 1-69-1, Authorization to Approve an Internal Management Document (IMD)](https://www.irs.gov/irm/part1/irm_01-002-070#id6)
  - 1.2.70.6  [Delegation Order CI 6-4-1, Authorization to Engage in Outside Employment, Business, and Other Activities](https://www.irs.gov/irm/part1/irm_01-002-070#id7)
  - 1.2.70.7  [Delegation Order CI 6-29-1, Authority to Address Employee Performance or Conduct Issues](https://www.irs.gov/irm/part1/irm_01-002-070#id8)
  - 1.2.70.8  [Delegation Order CI 11-2-1 Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents](https://www.irs.gov/irm/part1/irm_01-002-070#id9)
  - 1.2.70.9  [Delegation Order CI 25-6-1, Cost of Complying with a Summons](https://www.irs.gov/irm/part1/irm_01-002-070#id10)
  - Exhibit  1.2.70-1  [Crosswalk](https://www.irs.gov/irm/part1/irm_01-002-070#id11)

# Part 1. Organization, Finance, and Management

# Chapter 2. Servicewide Policies and Authorities

# Section 70. Business Unit Delegations of Authority for Criminal Investigation

* * *

## 1.2.70 Business Unit Delegations of Authority for Criminal Investigation

#### Manual Transmittal

February 05, 2026

#### Purpose

(1) This transmits new IRM 1.2.70, Servicewide Policies and Authorities, Business Unit Delegations of Authority for Criminal Investigation.

#### Material Changes

(1) This new IRM section houses Criminal Investigation (CI) business unit delegation orders, to comply with IRS Internal Management Document (IMD) procedures in IRM 1.11.4.6, Business Unit Delegation Order Standards.

(2) CI business unit delegation orders renumbered per procedures in IRM 1.11.4.6.1.1, Numbering Business Unit Delegation Orders.

(3) _Exhibit 1.2.70-1_ is a crosswalk that exhibits the name and number of a CI business unit delegation order as it was previously listed in IRM 9.1.4, Criminal Investigation Directives and Functional Delegations of Authority, dated 11-23-2020, and the name and number it was converted to when relocated IRM 1.2.70.

(4) New Delegation Order CI 1-1-1, Order of Succession and Designation to Act as Chief of Criminal Investigation and other Top-Level Executives included in IRM 1.2.70.

#### Effect on Other Documents

This new IRM supersedes CI business unit delegation orders previously contained in IRM 9.1.4, Criminal Investigation Directives and Functional Delegations of Authority, dated November 23, 2020.

#### Audience

Criminal Investigation employees and management

#### Effective Date

(02-05-2026)

Justin Campbell, Deputy Chief, Criminal Investigation

for

Guy Ficco, Chief, Criminal Investigation

**1.2.70.1** **(02-05-2026)**

### Program Scope and Objective

1. Criminal Investigation’s (CI) business unit delegation orders help accomplish the mission of both CI and the IRS, while maintaining the organizational structure.

2. Servicewide delegation orders (SDOs) are specific delegations of authority issued by the Commissioner, or Deputy Commissioner on the Commissioner’s behalf, to subordinates, with or without restrictions on redelegation. SDOs are issued when it is necessary to describe the delegation of authority for a specific action or activity based on the IRC, statute, Treasury Regulations or Treasury Decisions. SDOs are located in IRM 1.2.2, Servicewide Policies and Authorities, Servicewide Delegations of Authority.

3. CI business unit delegation orders are supported by Servicewide delegation orders (SDO). The CI business unit delegation orders redelegate authorities to the Chief of Criminal Investigation or subordinates within the Criminal Investigation business unit as allowable under the SDO. The CI business unit delegation orders provide the organization with the ability to delegate various authorities within CI management and effectively allocate management resources.


**1.2.70.2** **(02-05-2026)**

### Introduction to Business Unit Delegations of Authority for Criminal Investigation (CI)

1. This IRM contains business unit delegation orders for Criminal Investigation. Distribution of this IRM includes all persons with a need for any of the authorities or information in this section.

2. Each business unit CI delegation order is based on a Servicewide delegation order. Servicewide delegations of authority can be found in IRM 1.2.2, Servicewide Policies and Authorities, Servicewide Delegations of Authority.

3. Delegation orders are the published documents that record official delegations of authority. They:



   - Place authority in the position(s) where actual operational responsibility resides;

   - Free officials from having to consider issues which can be handled at lower levels; and

   - Reduce the time and resources a senior executive might spend on a matter that can be addressed by designated officials or employees.


4. The format and numbering of CI business unit delegation orders are consistent with guidance from Servicewide Policy, Directives and Electronic Resources (SPDER).See IRM 1.11.1.5, IMD Numbering by Business Process. For example, delegation order CI 1-69-1 shows:



   - CI: the organization issuing the redelegation order

   - 1-69: the related Servicewide delegation order

   - 1: the sequential number to indicate that more than one redelegation can be issued for each Servicewide delegation order.


5. Current CI business unit delegation orders are listed in numerical sequence. New or revised CI business unit delegation orders approved in the interim of publishing this IRM can be found in the CI Virtual Library.

6. CI business unit delegation orders are issued only at the business unit senior executive level.


**1.2.70.3** **(02-05-2026)**

### Delegation Order CI 1-1-1, Order of Succession and Designation to Act as Chief of Criminal Investigation and other Top-Level Executives

1. **Order of Succession and Designation to Act as Chief of Criminal Investigation**

2. **Authority:** To act and perform the functions of the Chief of Criminal Investigation of the Internal Revenue Service in the absence of the Chief of Criminal Investigation due to an enemy attack on the United States, disability, other emergency or vacancy/absence in the office; thus, ensuring the continuity of the functions of the office.

3. **Delegated to:**The following officials are authorized in the specific sequence listed.



   - Deputy Chief

   - Executive Director, Strategy

   - Executive Director, Global Operations


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-1 and Servicewide Delegation Order 1-2, Servicewide Delegation Order 1-23, IRM 10.6.2, **Continuity Plan Requirements.**

6. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby affirmed and ratified.

7. Signed: Guy A Ficco, Chief, Criminal Investigation.


**1.2.70.4** **(02-05-2026)**

### Delegation Order CI 1-30-1, Authorization and Approval of Official Travel within the United States

1. **Authorization and Approval of Official Travel within the United States**

2. **Authority:** To authorize and approve official travel (including travel authorizations, travel advances, travel vouchers and travel and transportation payments for emergency purposes) for travel within the United States and its territories and possessions in accordance with the Federal Travel Regulation, IRM 1.32.1, **IRS Local Travel Guide**; and IRM 1.32.11**, IRS City-to-City Travel Guide.**

3. **Delegated to:** Supervisors for employees under their supervision.

4. **Redelegation:** The authority delegated in this order may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-30 and 5 USC 5707.

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes CI Delegation Order No. 8 previously located in IRM 9.1.4.15 dated September 20, 2013.

7. Signed: Guy A. Ficco, Chief, Criminal Investigation.


**1.2.70.5** **(02-05-2026)**

### Delegation Order CI 1-69-1, Authorization to Approve an Internal Management Document (IMD)

1. **Authorization to Approve an Internal Management Document (IMD)**

2. **Authority:** On behalf of the Chief, Criminal Investigation, to approve, sign and authorize the issuance of a new, revised or obsolesced IRM section, IRM procedural update, interim guidance memorandum (IGM), or operating level directive without newly designated or changed designated sensitive content.

3. **Delegated to:** Directors reporting directly to the Chief or Deputy Chief.

4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:**Servicewide Delegation Order 1-69; [Treasury Directive 71-10](https://home.treasury.gov/about/general-information/orders-and-directives/td71-10) and [Treasury Security Manual – TD P 15-71](https://home.treasury.gov/about/general-information/orders-and-directives/treasury-directive-15-71).

6. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order modifies and supersedes CI Delegation Order No. 1, previously located in IRM 9.1.4.10 dated September 20, 2013.

7. Signed: Guy A. Ficco, Chief, Criminal Investigation.


**1.2.70.6** **(02-05-2026)**

### Delegation Order CI 6-4-1, Authorization to Engage in Outside Employment, Business, and Other Activities

01. **Authorization to Engage in Outside Employment, Business, and Other Activities**

02. **Authority 1:** To approve or disapprove requests to engage in permitted outside employment or business activities for non-1811 CI employees.

03. **Delegated to:** The employees’ first and second level manager (see _Exception_).



    1. First level manager serves as the “reviewing official” and “recommending official” for approval/disapproval.

    2. Second level manager serves as the approving/disapproving official.



       ### Exception:



       The first level manager serves as both the and the approving/disapproving official for employees who are not assigned a second level manager.


04. **Redelegation:** This authority may not be redelegated.

05. **Authority 2:** To approve or disapprove requests to engage in permitted outside employment or business activities for CI employees in the 1811 job series.

06. **Delegated to:**The employee’s third and fourth level manager.



    1. Third level manager serves as the “reviewing official” and “recommending official” for approval/disapproval.

    2. Fourth level manager serves as the approving/disapproving official.



       ### Note:



       Requests made by 1811s must be approved by their third- and fourth-level managers notwithstanding the delegation of this authority to other employees’ first- and second-level managers in Servicewide Delegation Order 6-4. IRM 1.2.2.7.4


07. **Redelegation:** This authority may not be redelegated.

08. **Source of Authority:**Delegation Order 6-4 (Rev. 1); [31 CFR 0.103](https://www.law.cornell.edu/cfr/text/31/0.103) and [Treasury Order: 102-01](https://home.treasury.gov/about/general-information/orders-and-directives/treasury-order-102-01).

09. To the extent that the authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This delegation order supersedes Criminal Investigation Delegation Order No. 9 (Rev. 3) dated September 20, 2013.

10. Signed: Guy A Ficco, Chief, Criminal Investigation.


**1.2.70.7** **(02-05-2026)**

### Delegation Order CI 6-29-1, Authority to Address Employee Performance or Conduct Issues

01. **Authority to Address Employee Performance or Conduct Issues**

02. **Authority 1:** To effect a non-disciplinary action, lesser disciplinary action, probationary termination, propose a disciplinary suspension, or propose an adverse action for cases involving:



    - Firearms

    - Use of Force

    - GOV Misuse

    - Giglio

    - Lautenberg

    - GS-15 or IR-01

    - Criminal Misconduct

    - 1203(b)(1-10)

    - Substance Abuse

    - UNAX

    - Condition of Employment

    - Cases as determined by the Criminal Investigation (CI) Human Resource Director (e.g., difference of opinion on other types of misconduct between the Employee Relations and Medical Section and proposing or deciding official, sensitive and high visibility cases, etc.).

    - Any case where the employee has two prior disciplinary actions that are a matter of record.


03. **Delegated to:** Cl Disciplinary Board Chair.

04. **Redelegation:** This authority may not be redelegated.

05. **Authority 2:** To effect a disciplinary suspension or adverse action proposed by the CI Disciplinary Board.

06. **Delegated to:** Director, Strategy.

07. **Redelegation:** This authority may not be redelegated.

08. **Authority 3:** To serve as the Oral Reply Officer.

09. **Delegated to:** The deciding official for the proposed action.

10. **Redelegation:** This authority may not be redelegated.

11. **Authority 4:** To effect a non-disciplinary action, lesser disciplinary action, or probationary termination; except for cases referred to the CI Disciplinary Board or for Special Agents attending basic training at the Federal Law Enforcement Training Center (FLETC).

12. **Delegated to:**Deputy Chief, CI; Directors, Field Operations (DFOs); Senior Executive Service (SES) Headquarters (HQ) Directors/Deputies; HQ Directors; Special Agents in Charge (SACs); and Resident Agents in Charge (RACs).



    ### Note:



    These officials will serve as the Proposing and Deciding Officials for Probationary Pre-Appointment issues.





    ### Note:



    The official effecting a non-disciplinary action, lesser disciplinary action, or probationary termination must be at least two supervisory levels above the employee, with the exception of SES, which can be effected by the first level supervisor.

13. **Redelegation:** This authority may not be redelegated.

14. **Authority 5:** To effect a non-disciplinary action or probationary termination for a Special Agent attending basic training at FLETC; except for cases referred to the CI Disciplinary Board.

15. **Delegated to:** Director, National Criminal Investigation Training Academy (NCITA).



    ### Note:



    The Proposing Official must be at least two supervisory levels above the employee, with the exception of SES, which can be proposed by the first level supervisor.

16. **Redelegation:** This authority may not be redelegated.

17. **Authority 6:** To propose a performance based action, disciplinary suspension, or adverse action, except for cases referred to the CI Disciplinary Board.

18. **Delegated to:** Deputy Chief, CI; DFOs; SES HQ Directors/Deputies; HQ Directors; SACs; and RACs.



    ### Note:



    The Proposing Official must be at least two supervisory levels above the employee, with the exception of SES, which can be proposed by the first level supervisor.

19. **Redelegation:** This authority may not be redelegated.

20. **Authority 7:** To effect a performance based action, disciplinary suspension, or adverse action, except for cases referred to the CI Disciplinary Board.

21. **Delegated to:** Deputy Chief, CI; DFOs; SES HQ Directors/Deputies in CI.



    ### Note:



    The Deciding Official must be at least three supervisory levels above the employee, with the exception of SES, which can be effected by the second level supervisor.

22. **Redelegation:** This authority may not be redelegated.

23. **Authority 8(a):** To issue a notice of opportunity to demonstrate acceptable performance.

24. **Authority 8(b):** To issue a notice of intent to deny a within grade increase.

25. **Delegated to:** The employee’s first level supervisor.

26. **Redelegation:**This authority may not be redelegated.

27. **Authority 9(a):** To issue a determination that an employee’s performance has improved as a result of the opportunity period.

28. **Authority 9(b):** To issue a determination that the within grade increase is denied.

29. **Delegated to:** The employee’s first level supervisor.

30. **Redelegation:** This authority may not be redelegated.

31. **Authority 10:** To reassign a Special Agent who does not meet the 1811 Treasury Enforcement Agent Qualification Standards and is Not Medically Qualified (NMQ) for the Special Agent position.

32. **Delegated to:** Deputy Director, Strategy, Resource Administration and Leadership.

33. **Redelegation:** This authority may not be redelegated.

34. **Authority 11:** To propose a non-cause removal of a Special Agent who does not meet the 1811 Treasury Enforcement Agent Qualification Standards and is NMQ for the Special Agent position.

35. **Delegated to:** Deputy Director, Strategy, Resource Administration and Leadership.

36. **Redelegation:** This authority may not be redelegated.

37. **Authority 12:** To effect a non-cause removal of a Special Agent who does not meet the 1811 Treasury Enforcement Agent Qualification Standards and is NMQ for the Special Agent position.

38. **Delegated to:** Deputy Chief, Criminal Investigation.

39. **Redelegation:** This authority may not be redelegated.

40. **Authority 13:** To approve a fitness for duty medical examination, independent medical examination, issue NMQ letters, and request waivers of the Treasury Enforcement Agent Qualification Standards.

41. **Delegated to:** Deputy Director, Strategy, Resource Administration and Leadership.

42. **Redelegation:** This authority may not be redelegated.

43. **Source of Authority:** Treasury Order 102-01; 5 USC 7106; 5 USC Chapters 43 and 75; Servicewide Delegation Order 6-29; IRM 1.2.2.7.18.1, Criminal Investigation Deviation from Servicewide Delegation Order 6-29, **Authority to Address Employee Performance or Conduct Issues**.

44. To the extent that authority previously exercised consistent with this order may require ratification, it is hereby approved and ratified. This order supersedes CI Delegation Order No. 21, dated January 1, 2023.

45. Signed: Guy A. Ficco, Chief, Criminal Investigation.


**1.2.70.8** **(02-05-2026)**

### Delegation Order CI 11-2-1 Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents

1. **Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents**

2. **Authority:** To disclose returns, or return information to designated state tax officials pursuant to FedState Agreements on the Coordination of Tax Administration entered into between the head of any state tax agency and the Commissioner of Internal Revenue.

3. **Delegated to:**



1. Supervisory Special Agent

2. Resident Agent in Charge

3. Supervisory Investigative Analyst; and

4. Supervisory Investigative Management Analyst


4. **Redelegation:** This authority may not be redelegated.

5. **Source of Authority:** [Treasury Order 150-10](https://home.treasury.gov/about/general-information/orders-and-directives/treasury-order-150-10); [Treasury Order 101-05](https://home.treasury.gov/about/general-information/orders-and-directives/treasury-order-101-05); General Counsel Order No 4; IRC Section 6103 and IRM 1.2.2.12.2, Delegation Order 11-2 (Rev. 6), Authority to Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents.

6. To the extent that authority previously exercised consistent with this order may require ratification; it is hereby approved and ratified. This order supersedes CI Divisional Delegation Order No. 19, dated September 20, 2013.

7. Signed: Guy A Ficco, Chief, Criminal Investigation.


**1.2.70.9** **(02-05-2026)**

### Delegation Order CI 25-6-1, Cost of Complying with a Summons

1. **Cost of Complying with a Summons**

2. **Authority:** To obligate appropriated funds for payment of search costs, reproduction costs and transportation costs in connection with third party summonses.

3. **Delegated as follows:**



1. Supervisory Special Agents - $2,500;

2. Special Agents in Charge - $10,000; and

3. Directors, Field Operations - over $10,000.


4. **Redelegation:** May not be redelegated.

5. **Source of Authority:** [Treasury Order 150-10](https://home.treasury.gov/about/general-information/orders-and-directives/treasury-order-150-10); [IRC 7610](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwjv4LWf0pGNAxXeKFkFHWONCZcQFnoECDIQAQ&url=https%3A%2F%2Fwww.govinfo.gov%2Flink%2Fuscode%2F26%2F7610&usg=AOvVaw2ogaP4599a80a0o8ht40Dn&opi=89978449), and Servicewide Delegation Order 25-6 (Rev. 1).

6. To the extent that the authority previously exercised consistent with this Order may require ratification, it is hereby affirmed and ratified. This order modifies and supersedes CI Delegation Order No. 4, previously located in IRM 9.1.4.13 dated September 20, 2013.

7. Signed: Guy A. Ficco, Chief, Criminal Investigation.


**Exhibit 1.2.70-1**

### Crosswalk

The crosswalk below exhibits the name and number of a CI business unit delegation order as previously listed in IRM 9.1.4, Criminal Investigation Directives and Functional Delegations of Authority, dated 11-23-2020. Exhibit 1.2.70-1 displays the name and number the CI business unit delegation order was converted to when relocated to IRM 1.2.70.

| Delegation Order Name and Number from IRM 9.1.4 | Now | Delegation Order Name and Number to IRM 1.2.70 |
| :-: | :-: | :-: |
| No. 1 (Rev. 3), Signing Correspondence and Certain Other Documents | → | CI 1-69-1, Authorization to Approve an Internal Management Document (IMD) |
| No. 4, Cost of Complying with a Summon | → | CI 25-6-1 Cost of Complying with a Summon |
| No. 8 (Rev. 5), Authority to Authorize or Approve Travel, Travel Advances, Transportation Services and to Approve Travel Vouchers | → | CI 1-30-1, Authorization and Approval of Official Travel within the United States. |
| No. 9 (Rev. 3), Authorization to Engage in Outside Employment, Business, and Other Activities | → | CI 6-4-1, Authorization to Engage in Outside Employment, Business, and Other Activities |
| No. 19, Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents | → | CI 11-2-1, Permit Disclosure of Tax Information and to Permit Testimony or the Production of Documents |
| No. 21, Delegation of Authority in Employee Relations Matters | → | CI 6-29-1, Authority to Address Employee Performance or Conduct. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-002-070#addtoany "Show all")

A2A