---
url: "https://www.irs.gov/irm/part1/irm_01-004-029"
title: "1.4.29 SB/SE Campus Exam/AUR, and W&I Exam Operations | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-029#main-content)

- 1.4.29  [SB/SE Campus Exam/AUR, and W&I Exam Operations](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386911120)
  - 1.4.29.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386901008)
    - 1.4.29.1.1  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386890096)
    - 1.4.29.1.2  [Background](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386886992)
    - 1.4.29.1.3  [Authority](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386885024)
    - 1.4.29.1.4  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444387529808)
      - 1.4.29.1.4.1  [Workload Management](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444387522208)
      - 1.4.29.1.4.2  [Reports Available Using Control D](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444387518864)
      - 1.4.29.1.4.3  [Reports Available Using RGS, CEAS, and Batch](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444387508144)
      - 1.4.29.1.4.4  [Ad Hoc Reports](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444387503984)
    - 1.4.29.1.5  [Terms/Definitions/Acronyms](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386199744)
  - 1.4.29.2  [Business Measures](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386162480)
    - 1.4.29.2.1  [Campus Operation Business Results (COBR)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386160000)
    - 1.4.29.2.2  [Correspondence Examination Targets At A Glance](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386136240)
    - 1.4.29.2.3  [New Start Report](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386133120)
    - 1.4.29.2.4  [Monthly Resource Report (MRR)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386125472)
    - 1.4.29.2.5  [Customer Satisfaction Surveys](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386118288)
  - 1.4.29.3  [Work Plans](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386111632)
    - 1.4.29.3.1  [SB/SE Campus Exam/AUR Functional Area Code (FAC 7F) Programs](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386106128)
    - 1.4.29.3.2  [Planning Periods and FTE Categories](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386100096)
    - 1.4.29.3.3  [Work Plan Changes and Monitoring](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386094336)
    - 1.4.29.3.4  [Scheduling Staff and Monitoring Correct Time Reporting](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386090496)
    - 1.4.29.3.5  [Training Plan, Travel, and Awards](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386078464)
  - 1.4.29.4  [Audit Reconsideration](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386075184)
    - 1.4.29.4.1  [Reporting Reconsideration Time, Receipts and Closures](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386073360)
    - 1.4.29.4.2  [Controlling Reconsideration Cases](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386068704)
  - 1.4.29.5  [Toll-Free Telephone Service](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386064864)
    - 1.4.29.5.1  [Virtual Call Center (Enterprise)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386062384)
    - 1.4.29.5.2  [Managing Features](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386058528)
    - 1.4.29.5.3  [Bringing Up the Phone System](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386054032)
    - 1.4.29.5.4  [Enterprise Level and Automated Call Distributor (ACD) Announcements](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386048640)
    - 1.4.29.5.5  [Availability and Efficiency](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386044768)
      - 1.4.29.5.5.1  [Idle Reason Codes](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386037792)
      - 1.4.29.5.5.2  [Average Handle Time](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386032336)
    - 1.4.29.5.6  [Fluctuating Call Volume](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386025696)
    - 1.4.29.5.7  [Outgoing Calls](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386023088)
    - 1.4.29.5.8  [Defaulted Calls](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386019824)
    - 1.4.29.5.9  [Toll-Free Telephone Staffing](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386017712)
    - 1.4.29.5.10  [End of Shift Activities](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386010656)
    - 1.4.29.5.11  [UCCE Assistance](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444386006160)
    - 1.4.29.5.12  [Manager Calls](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385998736)
      - 1.4.29.5.12.1  [Taxpayer Compliments](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385990512)
      - 1.4.29.5.12.2  [Taxpayer Complaints](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385988080)
      - 1.4.29.5.12.3  [Taxpayer Disagreement with Examiner’s Determination](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385984160)
      - 1.4.29.5.12.4  [Handling Managerial Taxpayer Calls](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385973504)
        - 1.4.29.5.12.4.1  [Managerial Calls-Taking a Call](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385964736)
        - 1.4.29.5.12.4.2  [Managerial Call Backs](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385953456)
      - 1.4.29.5.12.5  [Emergency Situations](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385946416)
    - 1.4.29.5.13  [Telephone Monitoring](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385944832)
      - 1.4.29.5.13.1  [Contact Recording](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385938320)
      - 1.4.29.5.13.2  [Feedback and Follow-up](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385933168)
    - 1.4.29.5.14  [UCCE Reports](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385927936)
  - 1.4.29.6  [Compliance Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385925632)
    - 1.4.29.6.1  [Workload Management/Efficiency Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385895056)
    - 1.4.29.6.2  [Compliance Mandatory Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385873696)
    - 1.4.29.6.3  [Mandatory Reviews for Form 911, Request for Taxpayer Advocate Service Assistance (And Application for Taxpayer Assistance Order (ATAO)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385858176)
    - 1.4.29.6.4  [Clerical Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385850688)
    - 1.4.29.6.5  [Documenting Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385844368)
    - 1.4.29.6.6  [Sharing Results](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385835280)
    - 1.4.29.6.7  [Non-Evaluative or Coaching Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385817200)
      - 1.4.29.6.7.1  [Side by Side Monitoring](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385805376)
    - 1.4.29.6.8  [Command Codes for Exam Reconsideration Adjustment Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385801968)
      - 1.4.29.6.8.1  [Focus of the IDRS Adjustment Review](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385793312)
      - 1.4.29.6.8.2  [Delegating Reviews of IDRS Adjustments](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385785296)
  - 1.4.29.7  [Operational Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385782288)
    - 1.4.29.7.1  [Frequency](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385778816)
    - 1.4.29.7.2  [Coverage](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385775120)
    - 1.4.29.7.3  [Review Scope](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385767776)
      - 1.4.29.7.3.1  [Department Manager’s Operational Review of Frontline Manager (FLM)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385756736)
      - 1.4.29.7.3.2  [Operation Manager’s Operational Review of Department Manager (DM)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385742992)
      - 1.4.29.7.3.3  [Director/P&A Staff Operational Review of Operation Manager (OM)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385729104)
    - 1.4.29.7.4  [Documentation](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385717936)
    - 1.4.29.7.5  [Review Follow-up](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385710752)
  - 1.4.29.8  [Monitoring the Age Listings](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385708096)
    - 1.4.29.8.1  [CCA 4243 - IDRS Overage Report](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385684144)
    - 1.4.29.8.2  [CCA 4244 - IDRS Multiple Case Control Report](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385630032)
  - 1.4.29.9  [Statute Protection](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385570144)
    - 1.4.29.9.1  [Statute Training](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385566128)
    - 1.4.29.9.2  [Statute Managerial Review](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385563008)
    - 1.4.29.9.3  [Barred Assessments](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385560976)
    - 1.4.29.9.4  [Statute Corrective Actions](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385558464)
    - 1.4.29.9.5  [Helpful Statute References](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385556416)
  - 1.4.29.10  [Document Matching Program Management](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385551872)
    - 1.4.29.10.1  [Document Matching Functional Guidelines](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385545984)
    - 1.4.29.10.2  [Document Matching Nature of Workload](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385543056)
    - 1.4.29.10.3  [Document Matching Mandatory Reviews](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385540768)
    - 1.4.29.10.4  [Document Matching Managerial Reports](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385534688)
  - 1.4.29.11  [Training and Employee Development](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385530032)
    - 1.4.29.11.1  [Exam Employee Training and Integrated Talent Management (ITM)](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385528208)
    - 1.4.29.11.2  [Training of Employees with Disabilities](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385524992)
    - 1.4.29.11.3  [On-the-Job Training](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385521456)
    - 1.4.29.11.4  [Annual Training for All Employees](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385518976)
    - 1.4.29.11.5  [Training Courses for Exam Managers](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385516608)
  - 1.4.29.12  [Useful Web Links and Sites](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385513008)
    - 1.4.29.12.1  [I Manage](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385511104)
    - 1.4.29.12.2  [Obtaining Access to SharePoint, Share Drive Folders and iManage](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385507856)
    - 1.4.29.12.3  [SB/SE Organization and Contacts](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385502976)
    - 1.4.29.12.4  [SB/SE Campus Exam/AUR Operating Guidance](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385500704)
    - 1.4.29.12.5  [Business Measures and Monitoring](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385498912)
    - 1.4.29.12.6  [Research](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385492160)
    - 1.4.29.12.7  [SB/SE Campus Exam Managers' Training](https://www.irs.gov/irm/part1/irm_01-004-029#idm140444385490080)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 29. SB/SE Campus Exam/AUR, and W&I Exam Operations

* * *

## 1.4.29 SB/SE Campus Exam/AUR, and W&I Exam Operations

#### Manual Transmittal

June 10, 2025

#### Purpose

(1) This transmits revised IRM 1.4.29, Resource Guide for Managers - SB/SE Campus Exam/AUR, and Taxpayer Services Exam Operations.

#### Material Changes

(1) Multiple edits have been made throughout updating Wage & Investment to Taxpayer Services

(2) IRM 1.4.29.7.1, Frequency - Added information for an Operational Site Review by Refundable Credits Examination Operation (RCEO).

(3) IRM 1.4.29.7.2, Coverage - Added statute review as part of the staff review.

(4) IRM 1.4.29.7.3, Review Scope - Added NOTE for SB/SE Campus Exam/AUR leadership.

(5) IRM 1.4.29.7.3.1, Department Manager’s Operational Review of Frontline Manager FLM) - Removed the table and added bullets for items to review for the FLM responsibilities.

(6) IRM 1.4.29.7.3.2, Operation Manger’s Operational Review of Department Manager (DM) - Removed the table and added bullets to review for the DM responsibilities.

(7) IRM 1.4.29.7.3.3, Director’s/P&A Staff Operational Review of Operation Manager (OM) - Removed the table and added bullets to review for the OM responsibilities.

(8) IRM 1.4.29.7.4, Documentation - Re-arranged the order of the items to improve the flow of the procedures.

(9) IRM 1.4.29.7.5, Review Follow Up - Just minor edits made.

(10) IRM 1.4.29.8, Monitoring the Age Listings - Added section on reviewing the Age Listings

(11) IRM 1.4.29.8.1, CCA4243 - IDRS Overage Report - Added section on reviewing the Overage Report.

(12) IRM 1.4.29.8.2, CCA4244 - IDRS Multiple Case Control Report - Added section on reviewing the Multiple Case Control report.

#### Effect on Other Documents

This IRM supersedes guidance previously provided in IRM 1.4.29, dated 11/06/2017.

#### Audience

Managers in SB/SE Campus Exam/AUR and Taxpayer Services Exam Operations in all campuses.

#### Effective Date

(06-10-2025)

Heather J Yocum

Director, Examination Field and Campus Policy

Small Business/Self Employed

**1.4.29.1** **(06-10-2025)**

### Program Scope and Objectives

1. **Purpose:**To provide Small Business/Self Employed (SB/SE) Campus Exam/Automated Underreporter (AUR) and Taxpayer Services Examination managers with various techniques, methods, and guidelines for managing employees and processes in campus examination operations.

2. **Audience:**Managers in SB/SE Campus Exam/AUR, and Taxpayer Services Exam Operations.

3. **Policy Owner:** SB/SE Director of Examination Campus and Field Policy.

4. **Program Owner:** Program Manager of Campus Exam and Field Support.

5. **Primary Stakeholders:** SB/SE and Taxpayer Services business divisions.

6. **Program Goals:** SB/SE Campus Examination/AUR and Taxpayer Services Examination support the mission of the IRS by maintaining an enforcement presence and encouraging the correct reporting by taxpayers of income, estate, gift, employment, and certain excise taxes. Exam Programs may include tax, penalty and interest adjustments to individual and/or business accounts. The various programs included in the operation are:



   - Correspondence Examination

   - SS-8

   - Innocent Spouse

   - Specialty (Estate and Gift Tax and Excise - CSC Only)

   - Audit Reconsiderations

   - Whistleblower/ICE

   - Exam Centralized Case Processing (CCP)

   - TEFRA

   - Classification


**1.4.29.1.1** **(02-07-2022)**

#### Related Resources

1. Managers will refer to other guidelines outlined in other IRMs.



   - Part 1, Organization, Finance, and Management

   - Part 4, Examining Process

   - Part 25, Special Topics


**1.4.29.1.2** **(06-10-2025)**

#### Background

1. This IRM section contains information for managing in the SB/SE Campus Exam/AUR and Taxpayer Services Campus environment. This IRM was created to communicate management responsibilities and provide resources for successful delivery of management related tasks. Information in this IRM is intended for use by SB/SE Campus Exam/AUR and Taxpayer Services Campus Managers.


**1.4.29.1.3** **(02-07-2022)**

#### Authority

1. The authorities of this IRM include the following:



   - IRM 1.2.1.2.1, Policy Statement 1-1, For Mission of the IRS

   - IRC 6103, Confidentiality and Disclosure of Returns and Return Information

   - IRC 6402, Authority to make Credits or Refunds

   - IRC 7801, Authority of Department of the Treasury


**1.4.29.1.4** **(06-10-2025)**

#### Roles and Responsibilities

1. This IRM was created to communicate management responsibilities and provide resources for successful delivery of management related tasks.

2. Managers in SB/SE Campus Exam/AUR (CEA) and Taxpayer Services, are responsible for managing paper and/or telephone inventory. Proper workload management is essential for timely responses to customers and/or account transactions. Due to the variety and complexity of work in Compliance Services, managers must be familiar with the many aspects to managing workloads such as:



   - Providing employee oversight and development

   - Conducting reviews

   - Providing adequate training

   - Establishing controls and priorities

   - Using available reports and management tools to monitor the operation

   - Processing work within established time frames

   - Correcting imbalances in work inventory

   - Providing adequate staffing for inventory

   - Being involved in the daily operation

   - Managing time effectively


3. SB/SE managers should adhere to the Campus Exam/AUR Operating Guidelines issued for the current fiscal year.


**1.4.29.1.4.1** **(02-07-2022)**

##### Workload Management

1. Inventory management is a critical part of the examination process. The way inventory is managed has an effect on key business measures and targets like cycle time, closures, customer satisfaction, and overage correspondence percentage.

2. There are various Audit Information Management System (AIMS) Processing reports (APR), Audit Management System reports (AMS), and report systems that are available to manage and monitor inventory. In order to properly manage your workload, as a manager, you must be familiar with available inventory reports and consistently review those pertinent to the work performed under your direction.

3. A complete list of responsibilities and how the reports should be reviewed and reconciled can be found in the Training Course 11884-102, Return Integrity and Correspondence Services (RICS) Inventory Management for Campus Managers - Student Guide, in the Publishing Catalog by entering Catalog Number 50930.


**1.4.29.1.4.2** **(02-07-2022)**

##### Reports Available Using Control D

1. AIMS Report Processing (ARP), AMS, and Integrated Data Retrieval System (IDRS) reports can be found on Control D. This system can be accessed through the Intranet at: Control-D MCC or Control-D TCC



### Note:



Control D access requires login





   - ARP 0640 – Status 10, 22, 24 Weekly Purge List: This report identifies cases in status 10, 22, and 24 for each campus employee group code that have remained in an AIMS status beyond the specified time frames.

   - ARP 0940 – Status Workload Review List: This report identifies cases in all statuses with the exception of statuses 10, 13, 22, 24, 33, 34, and 38 for each campus EGC that have remained in an AIMS status beyond the specified time frames.

   - ARP 2540 – Status 24 Weekly Overage List: This report identifies cases in status 24 for each campus EGC that has a correspondence received date that is over 30 days old.

   - ARP 2940 (Table 4.0) – Returns with Statute Date Pending: This report provides data on cases where the statute of limitations will expire in 180 days or less.

   - ARP 5443 (Table 8.1) – Aged Claim Cases List: This report provides data on the age and status code on claim cases.

   - Transaction Code (TC) 810/811 Listing – Problem Correction Reports: These reports provide data on cases with frozen refunds where the review or examination has been completed but the case has not been processed correctly or completely.

   - ARP 0340/2240 – Correspondence Audits: These reports provide weekly data with respect to examination closures and inventory by program type.

   - ARP 1640/1540 (Table 35) – Results of Examined Returns: These monthly reports provide cumulative data for the fiscal year with respect to examination closures and inventory by program type.

   - AMS 7143 – SC Non-assessed Closure Listing: This report provides data with respect to cases where the assessment has not posted, however, the case has been closed on AIMS.

   - AMS 7144 – TC 424 Overage Report: This report is generated when a TC 424 fails to post to Master File.

   - IDRS Reports CCA4243, IDRS Overage Case Report, and CCA4244, IDRS Multiple Case Control Report: These reports are used primarily by Reconsiderations and Unpostables.


**1.4.29.1.4.3** **(02-07-2022)**

##### Reports Available Using RGS, CEAS, and Batch

1. Report Generating System (RGS), Correspondence Examination Automation System (CEAS), and Batch System reports.



1. RGS has several reports that can be created through queries to assist the tax examiner and team leader in monitoring inventory that is in an individual group and/or an examiner’s RGS inventory.

2. CEAS has reports that provide data for the analysis of case inventory to assist examiners, groups, and campuses to manage their case inventory. CEAS obtains its data from RGS.

3. Batch System: Several reports can be created through queries in the Batch system to assist the Batch Coordinator in monitoring inventories. The RGS Batch process moves cases through the examination work-stream process utilizing automation.


**1.4.29.1.4.4** **(02-07-2022)**

##### Ad Hoc Reports

1. Ad hoc reports can be generated from other systems like the Statistical Sampling Inventory Validation Listing (SSIVL), AIMS Computer Information System (ACIS), and Business Performance Measurement System (BPMS) and can be used in place of the ARP reports.



1. **SSIVL**: This is a weekly database of cases open on AIMS used to generate ad hoc reports to monitor inventory.

2. **ACIS**: These are monthly databases of closed and open cases that are on AIMS used to generate reports to monitor inventory.

3. **Business Objects Enterprise (BOE)**: BOE is a suite of tools providing an intuitive interface to query and analyze data and to build ad hoc and canned reports.

4. **Status Monitoring Report**: This report identifies cases in all statuses for each campus employee group code that have remained in an AIMS status beyond the specified time frames. This report can be worked in place of the ARP0640, ARP0940, and ARP2540 reports. This report is prepared weekly by Performance Planning and Analysis (PP&A) and is available at: SBSE Combined Campus Reports- SBSE.

5. **Worked Correspondence Report**: This report identifies all the correspondence that was touched and updated during the week. This report is prepared weekly by the Planning and Performance Monitoring Staff and is available on its SharePoint site by this link: SBSE Combined Campus Reports- SBSE .


2. **Exam Mail Tool (EMT)**: This is a database containing daily mail receipt information. Historical data can be retrieved for EIC and/or Discretionary mail receipts and used for making future projections. Clerical managers with mail operation oversight have access to this database and report generation.


**1.4.29.1.5** **(02-07-2022)**

#### Terms/Definitions/Acronyms

1. Acronyms used within this IRM are shown in the table below:




| **Acronym** | **Definition** |
| --- | --- |
| ACD | Automated Call Distributor |
| ACIS or A-CIS | AIMS Computer Information System |
| AHT | Average Handle Time |
| AMS | Audit Management System |
| ARP | AIMS Processing Reports |
| AWOL | Absent Without Leave |
| BBTS | Batch Block Tracking System |
| BOE | Business Objects Enterprise |
| BPMS | Business Performance Measurement System |
| CCP | Centralized Case Processing |
| CEAS | Correspondence Examination Automation Support |
| CJE | Critical Job Elements |
| COBR | Campus Operation Business Results |
| CQRS | Centralized Quality Review System |
| CRC | Campus Reporting Compliance |
| DCI | Data Collection Instrument |
| EMT | Exam Mail Tool |
| EQRS | Embedded Quality Review System |
| ETD | Enterprise Telephone Data |
| FAC | Functional Area Codes |
| FTE | Full-Time Equivalent |
| FRP | Frivolous Return Program |
| IAT | Integrated Automation Technology |
| ICM | Intelligent Call Management |
| JOC | Joint Operations Center |
| LOS | Level of Service |
| LWOP | Leave Without Pay |
| MRR | Monthly Resource Report |
| NQRS | National Quality Review System |
| PAC | Program Activity Code |
| PMS | Performance Management System |
| PPM | Planning & Performance Monitoring |
| RAR | Resource Allocation Reports |
| RGS | Report Generating Software |
| SA | System Administrator |
| SPRG | Specialized Product Review Group |
| SSIVL | Statistical Sampling Inventory Validation Listing |
| TA | Telephone Analyst |
| TAAG | Targets at a Glance |
| TCO | Tax Compliance Officer |
| TOD | Tour of Duty |
| WP&C | Work Planning and Control Reports |
| WSD | Workload Selection & Delivery |


**1.4.29.2** **(11-12-2013)**

### Business Measures

1. Campus Operation Business Results (COBR), Targets at a Glance (TAAG), New Start Report, Monthly Resource Report (MRR), and Customer Satisfaction Survey reports are used to monitor progress in meeting business measures.

2. Managers should be familiar with these reports and use them to ensure new starts are started timely and communicate customer satisfaction improvement areas to their employees. Operation Managers should be prepared to address any areas of concern with HQ.


**1.4.29.2.1** **(03-20-2017)**

#### Campus Operation Business Results (COBR)

1. COBR reports are used to brief the SB/SE Commissioner on a monthly basis.

2. COBR reports provide year to date information on resource usage and inventory activity for major operational program objectives. There are three COBR Reports for Exam



1. EITC

2. Discretionary

3. Quality


3. COBR Reports are reviewed to determine if the Operation is on target to their Plan. If the Operation is not on target, then information should be obtained to determine what actions can be taken to meet the business measure targets.

4. COBR reports provide information for SB/SE, each campus, and Specialty. The information is shown for the current fiscal year cumulative data and two prior years, with percentage columns comparing the current to the prior year, the Plan to date, and the FY Work Plan. During Mid-Year assessments a column is added for FY Projected Year-End Accomplishments.

5. Line items on the Exam COBR:




| Item | Description |
| :-: | :-: |
| FTE (Full Time Equivalent - Staffing) | EITC, Field Support, TEFRA and Non-TEFRA (Discretionary) |
| Dollars | Recommended, per return, and revenue protected |
| Closures | Closures for Corr Exam broken down to campuses |
| TEFRA and Non-TEFRA (for Discretionary) | n/a |
| Individual Masterfile (IMF) and Business Masterfile (BMF) | n/a |
| IMF Closures | Cases greater than $200K and $1Mil |
| BMF Closures | Cases for Small Business, Specialty and Large Business |
| Schedule C Closures | Cases containing Schedule C. |
| Campus and Field Reconsiderations (Recons) and Claims | Cases worked as Recons and Claims |
| Productivity | Closures per FTE for Corr Exam |
| New Starts | Stars for Corr Exam, and Campus and Field Recons |
| Timeliness | The average number of cycle days from the Exam Start Date to Disposal Code Date. This excludes cases closed in EGC 5033 Bankruptcy and EGC 5055 Disaster |
| Correspondence | Overage percentage, and actual count of total mail and mail over 30 days old |

6. Line items on the Exam Quality COBR:



1. Employee Satisfaction – The results from the Employee Satisfaction Survey.

2. Taxpayer Satisfaction – The percent satisfied from the Customer Satisfaction Survey. This information is obtained from a third party vendor conducting mail surveys on closed correspondence cases.

3. Quality – Quality results for Paper and Telephones for Accuracy, Timeliness, and Professionalism.

4. Telephones – Level of Service and Adherence to Schedule.


7. COBR reports are available on the IRS Intranet; check with leadership for the correct URL.


**1.4.29.2.2** **(06-10-2025)**

#### Correspondence Examination Targets At A Glance

1. The Corr Exam Targets at a Glance (TAAG) report is a summary of the monthly COBR reports (Exam and Quality) for the current Fiscal Year. SB/SE and each campus have a report. For SB/SE, measures not within +/- 3 percent of target are highlighted in yellow, and measures not within +/- 5 percent of target are highlighted in red. Taxpayer Services measures not within +/- 5 percent of the target are highlighted in yellow, and measures not within +/- 7 percent of target are highlighted in red.

2. The TAAG is used by the SB/SE Campus Compliance Director for discussions with the campus Operations Managers to address measures in red or yellow. In Taxpayer Services, the TAAG is used by the Director, Refundable Credits Examination Operation for discussions with the Director, Return Integrity & Compliance Services.


**1.4.29.2.3** **(06-10-2025)**

#### New Start Report

1. The New Start Report is used to track the number of weekly and year-to-date new starts by inventory type. Each campus has its own report, with separate worksheets for Earned Income Tax Credit (EITC) and Discretionary inventory.

2. By close of each business Tuesday, the Exam Operation Inventory Control Manager (ICM) or other designated person should update the New Start Report with actual starts. The ICM pulls the data from SSIVL (or ARP 2240 and ARP 0340) weekly and reconciles to A-CIS at the end of the monthly cycle.

3. SB/SE Headquarters (HQ) Planning & Performance Monitoring (PPM), and Taxpayer Services Program Management (PM) monitors the actual starts to the planned starts.

4. SB/SE Workload Selection & Delivery (WSD) will update the planned start data on the report with delivery information. If it is determined that scheduled starts will be over or under the monthly schedule, by inventory type, 5 percent or 500 cases, the reason for the difference must be reported on the weekly report. Examples:



   - Planned monthly starts for a project code are 1,300. In week 3 of the month, the campus projects it will start 1,200 cases for the month. Although this is more than a 5 percent difference it is less than 500, so no explanation is necessary.

   - Total planned starts for the month are 12,000. In week 2 of the month, the campus projects it will start 11,250 cases. This is more than a 5 percent difference and greater than 500 cases, so an explanation would be provided when the actual starts for week 2 are reported.


5. Changes to a start plan for SB/SE will be coordinated through the HQ PPM and WSD staff. Changes to a start plan for Taxpayer Services will be coordinated through HQ Return Integrity & Compliance Services Refundable Credits Program Management (RCPM) staff.

6. Maintaining the schedule for planned starts is imperative to ensure the closure targets are met at the end of the fiscal year.

7. Managers should know the types of cases being worked and ensure that manual starts are done timely.


**1.4.29.2.4** **(03-20-2017)**

#### Monthly Resource Report (MRR)

1. The Monthly Resource Report provides detailed FTE, inventory, and productivity data for FAC 7F programs, including Correspondence Exam. This report breaks down measures reported on the COBR for each campus, while aligning the Financial Reviews with the COBR, to assist the campuses with monitoring FTE for both Finance and COBR measures.

2. Items on the MRR:



1. FTE – Cumulative Year-to-Date, Plan-to-Date, and Work Plan by program code

2. Overhead, Training, and Overtime reports

3. Reconsiderations – FTE and closures by fifth digit program code

4. Inventory – Open New Starts, Closures from New Starts, and Closures from WIP (Work in Progress) by project code

5. Productivity – Closures per FTE, hours per case, no change rates, response rates, and cycle time by inventory type

6. Ad Hoc – Identity Theft, FRP, BMF, IRDM, and BLP reports

7. Finance – Work Plan changes from the Financial Review process

8. Reconciliation – Reconciles the Finance Reports by Org Code to the COBR categories


**1.4.29.2.5** **(06-10-2025)**

#### Customer Satisfaction Surveys

1. SB/SE Campus Compliance and Taxpayer Services Compliance Examination (CCE) has two Customer Satisfaction Surveys. One is a written survey by mail, and the other is an Interactive Voice Response (IVR) by telephone. The Customer Satisfaction mail and IVR surveys are for Examination Operation customers.

2. Surveying taxpayers allows us to identify what we are doing right, as well as areas for improvement in order to deliver top quality service to America’s taxpayers. Improving customer satisfaction requires the combined efforts of all IRS employees. Front-line employees and managers are the primary providers of service to taxpayers, and can directly impact taxpayer perceptions of IRS courtesy, professionalism, accuracy, timeliness, and fairness through the actions they take (or fail to take).

3. For each function, Customer Satisfaction survey results are reported annually at the National level. Customer Satisfaction Survey Reports for Campus Reporting Compliance are located at: Customer Satisfaction Surveys Program

4. To provide taxpayers with complete anonymity when providing their responses, a private market research firm is used to survey taxpayers with whom we interact. This company compiles the raw data from taxpayer responses.

5. Each Business Operating Division (BOD) has at least one Customer Satisfaction Coordinator in HQ who is familiar with the results and reports for their function. For CCE, the BOD Coordinator is in Planning and Performance Monitoring (PPM). SB/SE Research receives the raw data and compiles the results into quarterly and annual reports.

6. PPM (for SB/SE) and PM (Program Management for W&I) staff monitors and analyzes these reports to identify improvement opportunities throughout the year. Managers should communicate improvement areas to their employees.

7. See IRM 21.10.4.5, SB/SE CCE Taxpayer Services Exam Telephone Customer Satisfaction Survey, for further information.


**1.4.29.3** **(06-10-2025)**

### Work Plans

1. Work Plans are a projection of the staff hours to meet workload demands for each program for the entire fiscal year. Work Plans are determined on an annual basis in the budgeting and planning process.



1. The Office of Management and Budget (OMB) prepares the President’s Budget.

2. Congress reviews and votes on the enactment of the budget.

3. The budget is executed to determine the cost of equipment, contractors, travel, staffing, awards, etc. and funds are distributed to the IRS appropriations for labor and non-labor expenses.

4. Labor funds are converted to the number of Full-Time Equivalent (FTE), which is the total number of compensable hours in a given fiscal year.

5. FTEs are broken out to Functional Area Codes (FAC). A FAC is a grouping of related work operations. Overtime FTE is also broken out to each FAC.

6. The SB/SE Headquarters (HQ) staff develops the Work Plans for the individual programs within the FAC, while Taxpayer Services PM staff develops the workplan for their individual programs.


**1.4.29.3.1** **(11-12-2013)**

#### SB/SE Campus Exam/AUR Functional Area Code (FAC 7F) Programs

1. Work Plans are based on projected availability of inventory, Field Work Plans, historical data, and campus staffing. SB/SE Campus Exam/AUR FAC 7F Work Plan programs include:



1. Correspondence Examination

2. Earned Income Tax Credit Compliance Initiative

3. TEFRA

4. Estate and Gift Tax

5. Excise Tax

6. Audit Reconsiderations

7. SB/SE Field Support

8. SS-8

9. Exam Centralized Case Processing (CCP)


**1.4.29.3.2** **(11-12-2013)**

#### Planning Periods and FTE Categories

1. The Work Plan includes three Planning Periods (PP):



1. PP1 October – December

2. PP2 January – June

3. PP3 July – September


2. Work Plans are established and monitored in three FTE categories:



1. Regular

2. Training – FTE is based on the Training Needs Assessments completed by the campuses during the Work Plan development process

3. Overtime


**1.4.29.3.3** **(06-10-2025)**

#### Work Plan Changes and Monitoring

1. Work Plans change throughout the year depending on different factors, such as peak months for mail receipts, telephone calls, pre-refund audits, and inventory availability. Changes to the Work Plans are done through the Financial Review and Hiring Plan process throughout the year. This is monitored by SB/SE Exam Planning and Performance Analysis (PPA), and the campus operations. In Taxpayer Services, Examination Policy & Coordination and PM HQ analysts monitor the work plan.

2. In order to reduce inventory, it may be necessary to request additional staffing. Sites must submit requests for additional FTE and/or hiring exceptions through PPM and F&S

3. HQ staff monitors the use of FTE to ensure adherence to the Work Plan for each program, and coordinates with the Joint Operations Center (JOC) to ensure adherence to telephone staffing requirements, so that program goals are achieved.


**1.4.29.3.4** **(03-20-2017)**

#### Scheduling Staff and Monitoring Correct Time Reporting

1. Managers must schedule available staffing for each planning period based on the correspondence workload and telephone staffing schedules. This includes scheduling of overtime, training, and seasonal furloughs.

2. Managers are responsible for accurate reporting of Time and Attendance (T&A) in the Totally Automated Personnel System (TAPS)/Single Entry Time Reporting (SETR) system. This includes correct coding for new, reassigned, and detailed employees. Managers will verify and validate all T&As and will input corrected T&As and/or IPR adjustments when errors are identified. Managers will ensure the correct posting of SETR codes as follows:



1. T&A Organization Code

2. 3081 Assigned Organization Code

3. Accounting Code

4. Appropriation

5. FAC

6. Cost Center

7. Employee Indicator

8. Function, Program, and Time Codes


3. Managers are expected to monitor reports weekly to ensure their employees are reporting time correctly to direct (Not Function Code 990) and overhead (Function Code 990) OFPs (Organization/Function/Program). The following reports are available for resource monitoring:



1. Time Reports – 3081s and SETR (Single Entry Time Reporting System)

2. Campus Operations Business Results Reports (COBR)

3. Work Planning and Control Reports (WP&C)

4. Resource Allocation Reports (RAR)

5. Monthly Resource Reports (MRR)

6. Other reports provided by the HQ program owners


4. HQ Planning and Performance Monitoring (PPM) staff maintains the OFP PC List available at: SBSE Combined Campus Reports- SBSE . Managers should ensure that the most current listing is being used by all employees. Requests for new program codes must be made through PPM.

5. Managers must be consistently aware of changes to staffing and relate that information to the Operation Technical Advisor responsible for preparing the Hiring Plans. This includes gains and losses, LWOP/AWOL/Comp/Credit, overtime, and training. This is important for accurate projections for the Financial Reviews and Hiring Plans, and for Work Plan development for the next Fiscal Year.


**1.4.29.3.5** **(11-12-2013)**

#### Training Plan, Travel, and Awards

1. Managers are responsible for:



   - Following the Training Plan and advising the Technical Advisor of any changes to training needs

   - Reviewing and submitting travel authorizations and vouchers to ensure staying within the Travel budget

   - Determining appropriate award amounts for discretionary awards to ensure staying within the Awards budget


**1.4.29.4** **(02-07-2022)**

### Audit Reconsideration

1. The Central Reconsideration Unit (CRU) works reconsideration cases for individual income tax returns previously worked by the Area Office or Campus Examination function. See IRM 4.13.3, Centralized Reconsideration Unit.


**1.4.29.4.1** **(02-07-2022)**

#### Reporting Reconsideration Time, Receipts and Closures

1. Hours are reported on Form 3081, Employee Time Report, by 5th digit program code.

2. Inventory volumes (inventory, receipts, production) are reported via Batch/Block Tracking System (BBTS) on the WP&C



1. See IRM 1.4.16.8.3.1, Managers Report, an evaluative tool to manage programs. Also used to compare scheduled or projected data with actual production.

2. WP&C Program Analyst Report (PCC 6240) – Provides inventory volumes for receipts, closures, and open inventory. Used for monthly COBR reports.


3. WP&C Program Analyst Report (PC6240) provides inventory volumes for receipts, closures, and open inventory. Used for monthly COBR reports.


**1.4.29.4.2** **(02-07-2022)**

#### Controlling Reconsideration Cases

1. Audit Reconsideration cases must be controlled on CEAS and/or IDRS (TXMOD) within 14 days of receipt. See IRM 4.13.3.1.7, Controlling the Case.



1. CCA/42/43 IDRS Report is used to monitor TXMOD controls.

2. RGS reports can be used also.


**1.4.29.5** **(02-07-2022)**

### Toll-Free Telephone Service

1. Refer to IRM 1.4.21.2.2, Managing the Unified Contact Center Enterprise (UCCE) Environment, for information and guidelines regarding the telephone environment.

2. Joint Operations Center (JOC) monitors toll-free telephone traffic using a centralized model that views all call sites virtually together, which is known as the Enterprise. JOC coordinates the operations of all Exam campuses, and it authorizes planning and scheduling for the campuses. JOC oversees the efficiency of all Exam functions and programs for each individual campus. The primary objective of JOC is ensuring the services provided to the customers are fair and consistent at all times.

3. JOC requests real-time changes in telephone staffing based on incoming call demand and overall resources. They make requests to the sites to add or reduce telephone staffing to meet call demand.


**1.4.29.5.1** **(02-07-2022)**

#### Virtual Call Center (Enterprise)

1. The Virtual Call Center (Enterprise) links through a central location UCCE system used in Exam sites.

2. Intelligent Call Management (ICM) routes calls based on UCCE data (specific set of characteristics) to the site with the longest available agent in the appropriate skill group. If no agent is available, the call is queued at the Enterprise level until an agent becomes available and only then is it routed to a site.

3. All Toll-Free telephone data is captured daily and stored in the web-based Enterprise Telephone Data (ETD) Warehouse. ETD stores data for historical use and also produces daily, weekly and ad hoc reports at the national (Executive Level Summary) and site level, including directorate roll-ups of remote sites. ETD also stores raw data captured from the ACDs and the data is available for research and troubleshooting. Site-level measures are also available on ETD when appropriate.

4. The role of a manager, in the Enterprise environment, is to ensure the right number of people with the right skills are available to answer calls.


**1.4.29.5.2** **(02-07-2022)**

#### Managing Features

1. JOC programs ICM (through scripts that use business rules) for maximum call routing efficiency, based on demand and assistor availability.

2. UCCE telephone system provides monitoring capabilities, data base records and management information.

3. The UCCE telephone system gives managers and Systems Analysts (SAs) access to most of the features such as:



   - Monitoring agents (listening in on calls in progress)

   - Notifying agents (notifying an agent whom you are monitoring to call you)


### Note:

Depressing the Supervisor key twice rapidly will reconnect you to the prior employee monitored.

**1.4.29.5.3** **(02-07-2022)**

#### Bringing Up the Phone System

1. Each Manager ensures all employees scheduled for telephone duty are signed into the UCCE systems and their name is displayed on Aceyus. This allows the manager to see the current phone status of each employee.

2. Review the screens for all the following:



1. Assistors signed-on the system from the day before, who may have forgotten to sign-off.

2. Assistors are signed-on and ready to take calls when the phone lines are open.

3. If applicable, English/Spanish assistors are available to cover calls.

4. Assistors are sign-on to the correct agent group, if applicable.

5. Assistors are using the appropriate idle code and time for lunch, break, temp-off, phone inventory, hold wrap, training, meeting and read time, if applicable.

6. Monitor the length of time an assistor spends on a call.


**1.4.29.5.4** **(11-12-2013)**

#### Enterprise Level and Automated Call Distributor (ACD) Announcements

1. JOC controls all announcements and scripts used on toll-free telephone numbers.

2. Announcements are valuable tools to:



1. Inform callers of answering delays

2. Provide basic information such as the address or phone number

3. Inform callers of the time frame before receipt of a fax can be confirmed or before correspondence is reviewed


**1.4.29.5.5** **(11-12-2013)**

#### Availability and Efficiency

1. As a Compliance manager, telephone data is available to assist you in evaluating the service being given to taxpayers and determining the efficiency and availability of site-level staff.

2. Managers and Systems Analysts (SA) must determine on a half-hourly basis by application if staff is available as scheduled. If less than the required number of agents is signed on, an explanation is required per adherence guidelines. This is normally accomplished by contacting the JOC Monitoring Room to notify JOC of the shortage and the reason (i.e., local inclement weather) the site will be understaffed.

3. Managers must ensure their employees are signed on to the telephone system and taking calls when scheduled. This reduces shrinkage, which is considered unscheduled time away from normal scheduled activities. Examples of shrinkage include:



   - Extended read and meeting times

   - Tardiness

   - Leaving early

   - Higher than expected attrition for day (e.g., sick leave)

   - Scheduled breaks not followed

   - Unauthorized breaks

   - Extended breaks or lunch periods


4. JOC, in collaboration with Compliance headquarters and site management, makes daily real-time adjustments to staffing levels based on actual demand and actual staffing.


**1.4.29.5.5.1** **(02-07-2022)**

##### Idle Reason Codes

1. Use available data to monitor and analyze efficiency. This includes:



   - Agent Idle and Sign-on times

   - Agent Average Handle Time (AHT)

   - Agent Average Wrap Time

   - Agent Outbound Report


2. "Idle" time consists of those times employees are signed on the telephone system, but not in the Available, Ready, Wrap, or Out Call status. Per the Customer Service Agreement, agents must use a reason code when they are assigned to answer incoming calls and they are in **Idle** status. See IRM 21.3.11.5.1.1, Reason Codes for Idle.

3. Managers should refrain from conducting meetings, informal training, group observances, etc. during peak telephone/paper periods/days.


**1.4.29.5.5.2** **(11-12-2013)**

##### Average Handle Time

1. Average Handle Time (AHT) is a data element and determines resources needed to achieve a budget-driven Level of Service (LOS) - LOS is the primary measure used by external stakeholders (Congress) to determine IRS efficiency.

2. JOC issues weekly AHT reports to the Exam system analysts.

3. Very long talk times affect program goals and increases the number of abandoned calls. It is usually an indicator that additional training may be needed in conversation control.

4. Managers should identify employees who may be using **excessively long or short times** in handling calls. Monitor a few of their calls to identify problems such as:



1. Training deficiency

2. Failing to keep call brief while maintaining standards of courtesy and full service

3. Placing a call on hold during the research process when it is inappropriate instead of arranging for a call back

4. Answering a large volume of unusually complex questions

5. Failing to provide a complete or accurate response


**1.4.29.5.6** **(11-12-2013)**

#### Fluctuating Call Volume

1. Managers should ensure all employees assigned to answer calls are at their workstations taking calls.

2. Managers will be notified by local site System Administrators (SA) or Department Managers if changes are needed in scheduled staffing based on contacts from JOC. This could include adding staff in a specific agent group or taking employees off the telephones to do other work. It is important for managers to minimize the amount of time it takes for employees to transition to a different work assignment, i.e. to start taking calls or to start other work.


**1.4.29.5.7** **(02-07-2022)**

#### Outgoing Calls

1. Employees may need to make outgoing calls to secure additional information to resolve an inquiry.

2. Employees making outgoing calls on their UCCE phones are not counted as part of ready staffing for site level adherence to schedule, nor are they considered in routing calls. Managers should monitor the number of outgoing calls to ensure adherence to IRM 4.19.13.11.1, Taxpayer Responses — Prior to Status 24.

3. The wrap time for an employee for outgoing calls should be appropriate to the type of call.


**1.4.29.5.8** **(11-12-2013)**

#### Defaulted Calls

1. A site may receive calls normally not handled when there is a hardware or network failure. When failures occur, calls do not route out to Intelligent Call Management (ICM) but instead queue locally. Site system administrators (SAs) are responsible for identifying calls in applications not currently staffed and contacting site management to place employees in the appropriate agent group to handle the call or write a referral if the call cannot be fully answered.


**1.4.29.5.9** **(02-07-2022)**

#### Toll-Free Telephone Staffing

1. Efficient telephone staffing is one of the keys to meeting the planned Level of Service (LOS).

2. Managers must ensure staffing is efficient. An increase to the AHT can impact Level Of Service (LOS) and other business measures and in turn increase the need for staff. Circuit availability may also be impacted.

3. Information is available from system reports for you to monitor the efficiency of your staff. Reports available include:



1. Average Handle Time

2. Wrap Time

3. Idle Report

4. Agent Activity Report

5. Sign On/Sign Off Report

6. Ready Report

7. Outbound Report

8. Short Call Report

9. Agent Transfer Report


**1.4.29.5.10** **(02-07-2022)**

#### End of Shift Activities

1. End of day activities involve reviewing the Aceyus screens for the following:



1. Assistors in wrap or idle that should be signed off the system.

2. Assistor reports showing available, wrap, idle, break and other information.



      ### Note:



      Call sites complete Automated Time Tracking System (ATTS) 3081 at the end of each day. ATTS is a tool designed to consolidate telephone data from UCCE and produce a time report which is used for SETR input.


2. An end of shift review of UCCE system concerns and problems should be completed. These should be shared with the manager(s) responsible for the next phone shift/rotation. This allows for a review of assistors signing-on for the next shift at the start of their Tour of Duty (TOD) to help take calls when in the phone rotation.


**1.4.29.5.11** **(02-07-2022)**

#### UCCE Assistance

1. The System Administrator/Telephone Analyst (SA/TA) is a valuable resource person regarding the features of the UCCE system.

2. Managers must coordinate with their SA/TA on any activity limiting the sites ability to deliver its commitment for scheduled Automated Call Distributor (ACD) time.

3. The SA/TA provides assistance on the following:



1. Information about system operations and call routing

2. Explanation of various UCCE reports

3. Identification of data availability and creating reports

4. Assessment of current call site performance

5. Networking information

6. Monitoring procedures

7. UCCE equipment repair

8. Database changes


**1.4.29.5.12** **(02-07-2022)**

#### Manager Calls

1. Manager calls should be very rare. While tax examiners are encouraged to make every effort to handle taxpayer assistance calls, there are instances in which managerial calls are warranted, such as,



   - Taxpayer compliments

   - Taxpayer complaints

   - Taxpayer disagreements with the tax examiner’s determination


2. If an assistor refers an excessive number of calls, it is likely that additional training and coaching is needed in **Effective Communication** and/or **Working with Difficult Taxpayers**.

3. Remember everyone in the IRS is an advocate for the taxpayer. Appropriate actions should be taken to correct the taxpayer’s problem on first contact. However, if you cannot correct the problem AND the taxpayer’s issue meets Taxpayer Advocate Service (TAS) criteria, as outlined in IRM 13.1, Taxpayer Advocate Case Procedures, refer the case to TAS using Form 911.

4. Encourage assistors to practice techniques to diffuse a taxpayer's anger, reassure taxpayers that they can assist with the issue, and make every effort to handle the call themselves. However, some taxpayers:



   - Immediately want to speak with a manager,

   - Are only satisfied by speaking with a manager even though the assistor has provided the requested assistance,

   - Want to complain about the service the IRS has provided, or

   - Want to compliment the service the IRS has provided.


**1.4.29.5.12.1** **(05-26-2017)**

##### Taxpayer Compliments

1. Taxpayer compliment calls of the IRS, or individual employees of the IRS are referred to the manager. Complimentary calls should be routed to a Manager. Records of complimentary calls should be included in the employee’s annual appraisal under appropriate critical element. Be sure to thank anyone who compliments the IRS. Make sure to express appreciation to anyone who compliments you, employees, or the IRS.


**1.4.29.5.12.2** **(02-07-2022)**

##### Taxpayer Complaints

1. As outlined in Pub 1, "Your Rights as a Taxpayer" , taxpayers have the right to speak to a supervisor about inadequate service. Remember, everyone in the IRS is an advocate for the taxpayer. Appropriate actions should be taken to correct the taxpayer’s problem on first contact. However, if you cannot correct the problem **AND** the taxpayer’s issue meets Taxpayer Advocate Service (TAS) criteria, as outlined in IRM 13.1, "Taxpayer Advocate Case Procedures" , refer case to TAS using Form 911.

2. Taxpayer complaints about individual (IRS) employees are capture under the Section 1203 process. Managers consult with Workforce Relations and TIGTA to investigate the issue. See IRM 21.1.3.16, Taxpayer Complaints/Compliments About IRS Service.


**1.4.29.5.12.3** **(02-07-2022)**

##### Taxpayer Disagreement with Examiner’s Determination

1. Pub 3498-A, The Examination Process (Audits by Mail), defines taxpayer’s options in challenging the IRS’s position. One option is speaking with the examiner’s manager when they do not agree with the examiner’s determination. In accordance, the examiner’s manager is to make the call back. In a manager’s absence, calls should only be delegated to someone officially assigned as the examiner’s acting manager.

2. The option to speak with the examiner’s manager about disagreements with the examiner’s determination should only be exercised after all available information to support issues being reviewed has been submitted to and considered by the examiner. If the taxpayer has new information to submit, the examiner should be allowed an opportunity to review and consider it prior to a manager call back.

3. Based on the need for the manager to become familiar with the issues the taxpayer is not in agreement with and prepare for a call back, calls of this type will be handled as call back requests.

4. The manager will review the case if they are proficient in the tax law involved in the disputed issues. If the issue(s) is/are outside of their expertise, they must refer it to a technical employee for a 2nd review, such as a Tax Compliance Officer (TCO), Revenue Agent (RA), or a Technical Advisor (TA). A manager does have the discretion to refer the case for a 2nd review even if they are proficient with the tax law issues.

5. The manager will meet with the tax examiner to discuss the findings. If the manager and/or 2nd level reviewer did not agree with the tax examiner’s determination, the tax examiner will take immediate corrective action on the case such as updating work papers and reports. The manager or their designee will call the taxpayer with the new determination.

6. If preferred, the technical employee (TCO, RA, or TA) can participate with the manager on the call back with the taxpayer. As a courtesy to the taxpayer, announce who is participating on the call, their title, and their role during the discussion, at the beginning of the call.

7. Decisions, based on the discussion with the taxpayer do not need to be made immediately during the call. However, if additional time is needed, the taxpayer must be advised as to the time frame for a decision, during the call. The time frame for communicating the decision should not exceed 5 business days.

8. If the taxpayer still does not agree with the issues after a managerial call back, managers are required to clearly explain the next steps in the examination process and the taxpayer’s remaining options for challenging the IRS’s position. See below, and Pub 3498-A, The Examination Process (Audits by Mail), Step 3, for more information. The taxpayer may:



   - Request an Appeals conference prior to the date given in the letter or,



     ### Note:



     If the manager determines that the taxpayer’s case is eligible to go to Appeals, the case will be documented by the manager and routed to Appeals within 30 days.

   - Petition Tax Court after they receive the Statutory Notice of Deficiency by the last day to petition given in the letter.


**1.4.29.5.12.4** **(05-26-2017)**

##### Handling Managerial Taxpayer Calls

1. If the manager is available to immediately take a taxpayer compliment or complaint call that does not require additional research and/or include a disagreement with the examiner’s determination, the call can be transferred. However, if the manager is not available, additional research is needed, and/or the call is in regard to a disagreement with the examiner’s determination, the employee will refer the call to their manager for a call back.

2. While talking with taxpayers, you represent the Internal Revenue Service and must always conduct yourself in a professional manner. Be courteous, control the direction of the conversation and give the taxpayer accurate and complete assistance.



1. Maintain a pleasant, friendly tone of voice.

2. Speak clearly, using words the taxpayer can understand.

3. Avoid using IRS jargon and acronyms.

4. Handle taxpayer’s negative reactions with patience.

5. Treat the taxpayer as a unique individual deserving respect.

6. Put yourself in the taxpayer’s place. If you received a notice and called for assistance, you would want to be treated with respect and given accurate, complete information to resolve the problem.


3. There are three steps to lessen a taxpayer's anger:



1. Listen,

2. Empathize, and

3. Assure.


**1.4.29.5.12.4.1** **(02-07-2022)**

###### Managerial Calls-Taking a Call

1. In order to receive a managerial call transfer, ensure you are signed onto an UCCE teleset:



1. Press the SIGN-ON key

2. Dial your four-digit extension (press the numbered keys on the teleset keypad)

3. Press ENTER

4. Dial your password



      ### Note:



      For security reasons, your password should not be the same as your extension. If your password and extension are the same, change the password immediately. See IRM 1.4.19.4.7, Telephone Security.

5. Press ENTER

6. Press READY


2. When a call is transferred to the manager, the taxpayer is already distressed. Be prepared to take the appropriate action to deal with their needs. An important goal in working with a distressed taxpayer is to keep potentially disruptive emotions out of the conversation. Start with controlling your own reactions and emotions.

3. When you are prepared to speak with the taxpayer, take the referral call:



1. Verify with assistor that disclosure was covered.

2. Obtain the SSN and tax year from the assistor.

3. Connect with the taxpayer and provide your name, identification number and ask, **How may I help you?**.


4. Call backs are used when you prefer to return the call at a later time, enabling you to research the account before talking to the taxpayer. If you prefer to return the taxpayer’s call, obtain the taxpayer’s name, SSN, phone number and the best time to return the call.

5. Double jacking enables the manager to take the call alongside the assistor. Using this procedure might provide some insight on how this type of call could be handled by the assistor in the future.



### Note:



SIGNOFF the UCCE system when you are away from your desk.


**1.4.29.5.12.4.2** **(05-26-2017)**

###### Managerial Call Backs

1. Managerial call backs allow time for researching and, when possible, resolving taxpayer issues prior to having a discussion with the taxpayer and/or their representative. Managerial call backs **must be made within 5 business days** of the receipt of the call back request. The request date should be noted by the examiner upon receipt as a CEAS (Correspondence Examination Automation Support) system action note. If additional time is needed, a managerial call to the taxpayer explaining the reason for the delay and establishing a new call back time must be made within the original **5 day time frame**.

2. The 5 business day period should be used to prepare for the call back.



   - Thoroughly review the case and/or issues and ensure you understand and agree with them. If not, take steps necessary to resolve discrepancies. If the case involves a taxpayer disagreement with the tax examiner’s decision, see _IRM 1.4.29.5.12.3_, Taxpayer Disagreement With Examiner’s Determination, above.

   - Seek expertise as needed.

   - Document discussion points to refer to during the call back.


3. Adhere to all telephone contact guidelines, such as authentication and case documentation, at the time of the call back. See IRM 4.19.19, Campus Examination Telephone Contacts.


**1.4.29.5.12.5** **(02-07-2022)**

##### Emergency Situations

1. Refer to IRM 4.19.19.15, Emergency, for guidance on handling emergency situations.


**1.4.29.5.13** **(02-07-2022)**

#### Telephone Monitoring

1. Telephone monitoring allows managers to determine whether the employee:



1. Addressed disclosure issues,

2. Treated the customer with respect, courtesy and fairness,

3. Researched reference material accurately,

4. Followed IRM 4.19.19, Campus Examination Telephone Contacts, and Integrated Automation Technology Tools (IAT),

5. Resolved the case per IRM guidelines,

6. Provided an accurate answer,

7. Applied appropriate communication skills, and

8. Conducted a concise successful interview.



      ### Note:



      All telephones subject to monitoring must be properly labeled so employees know that calls may be recorded/monitored. Calls are recorded via the Contact Recording system.


**1.4.29.5.13.1** **(02-07-2022)**

##### Contact Recording

1. Contact Recording is an automated quality monitoring system. It provides an instant replay of employee and taxpayer interaction. Recordings are stored by employee UCCE number.

2. The automated system captures voice and on-screen computer activity for later retrieval and review.

3. Contact recordings are used for performance/managerial monitoring purposes only and are normally erased within 45 days.

4. All calls are recorded in their entirety under contact recording.

5. Follow the time frames in the current IRS/NTEU National Agreement for sharing performance feedback.

6. A separate sample of recorded calls is selected for quality review purposes and is not tracked to individual employees for evaluative purposes.



### Note:



Management may request that a recorded contact be downloaded. Refer to IRM 1.4.21.2.1.5, Managerial Requests, for more information regarding this type of request.


**1.4.29.5.13.2** **(11-12-2013)**

##### Feedback and Follow-up

1. Determine if additional monitoring/review is necessary based on the following factors:



   - Training

   - Employee's ongoing performance

   - Quality Review feedback

   - Required minimum monitoring



     ### Note:



     Use UCCE reports such as Wrap Time and AHT as indicators to determine when additional monitoring is appropriate.


2. On-the-Job instructors (OJIs) monitor trainees to provide constructive feedback and assist in employee development. Team leaders monitor side-by-side to improve work skills.


**1.4.29.5.14** **(02-07-2022)**

#### UCCE Reports

1. See IRM 1.4.16.8.2, Unified Contact Center Enterprise (UCCE) Reports, for information.


**1.4.29.6** **(02-07-2022)**

### Compliance Reviews

01. Work reviews and telephone monitoring are performed for the following reasons:



    - To make an objective assessment of an employee’s performance on an ongoing basis and to ensure that adequate information is available for midyear and annual appraisals

    - To protect the rights of customers

    - To identify training needs



      ### Note:



      See _IRM 1.4.29.5.13_, Telephone Monitoring, for guidelines on performing a telephone monitoring review.


02. There are various types of evaluative and non-evaluative reviews used to observe and evaluate employees performance throughout the year. The following is a list of the reviews that should be performed to effectively evaluate an employee, if applicable:




    | Type of Review | Description |
    | :-: | :-: |
    | Telephone Monitoring | Review of incoming calls (where applicable) |
    | Paper Reviews | Review of paper cases |
    | Workload Reviews | Monthly Review of an employee who is assigned to work inventory programs |
    | BIN Reviews | A review of employee’s shelf to make sure inventory is arranged correctly |
    | Day after/time utilization reviews | A review of an employee’s work and time to determine if it is commensurate with work being performed |
    | On the job visits | Visiting the employees job location |
    | Clerical reviews | Reviewing the receiving and sending of mail and using proper clerical guidelines. |
    | IDRS reviews | A review of IDRS access, command codes, etc. |
    | IDRS Online Reports Services (IORS) Reports | A review of IORS reports for access and use of IDRS.IDRS Online Reports Services<br> <br>### Note:<br>Access requires login |
    | Non-evaluative reviews | Reviews that cannot be used for an evaluation |
    | Age/Inventory reviews | A review of aged cases in an employee’s inventory |
    | Systems Security | Review of accessing systems |
    | Form 3081 | A review of an employee’s time report |
    | Form 3210 | A review of Form 3210 |
    | Suspense Case reviews | Review of cases placed in suspense |
    | Security Reviews | Reviews to make sure employees are following the Clean Desk Policy<br> <br>### Note:<br>This list is not all-inclusive |

03. Reviews listed above should be completed on a Data Collection Instrument (DCI) via the Embedded Quality Review System (EQRS) when possible.

04. The manager is primarily responsible for performing evaluative reviews; however, a portion may be delegated to the Lead TE, with the exception of IDRS Security Reviews and where only one type of review is required during the employees evaluative period. Although performing some of the reviews may be delegated, the manager must always present the results to the employee in order for the review to be used for evaluative purposes.

05. All required management reviews must be documented in writing and readily accessible.

06. Focus performance reviews on effective case and call resolution according to IRM guidelines. Emphasize the importance of quality service as well as the efficiency of casework and telephone calls. For telephone calls, managers should determine whether the handle time is appropriate to the call reviewed, considering hold time, wrap time, and talk time. Calls should also be reviewed to assess professionalism.

07. Whenever possible, include a specific reference to the lowest level, (e.g., IRM subsection number) for performance feedback/documentation to ensure employees are aware of the procedure not being followed.



    ### Note:



    This identifies areas that may need further IRM clarification and training deficiencies.

08. Perform the required monitoring and paper reviews each month. Department Managers and/or Operations Managers must set review requirements for their Operation. Conduct a balance or mix of these reviews (telephone and paper reviews) throughout the year relative to an employees work assignments. When necessary, conduct side-by-side non-evaluative reviews for skill development.

09. Review results are linked, by attribute scoring, directly to the employees Critical Job Elements (CJEs). It is the managers responsibility to schedule employee reviews in a manner that will permit the employees to obtain documentation for as many aspects of their CJEs as possible.

10. A review schedule should be maintained which lists all employees in the team and the completion date of evaluative reviews. When the required number of reviews is not timely completed, notate the reason on the schedule. Since these schedules will be reviewed by Department and Operation managers during their operational reviews, retain the schedules until completion of the operational reviews.

11. Evaluative reviews/telephone monitors are completed as formal documentation of employees' performance that feed into their annual performance evaluation. The manager must sign the reviews and share the feedback with the employees in a timely fashion. In accordance with the National Agreement II guidelines, Leads may provide supplemental evaluative reviews; however, the manager must sign and share the reviews with the employees.

12. The shared signed evaluative review (DCI) must be filed in the employees EPF, and a copy provided to the employee.

13. Quality reviews completed by Central Quality Reviewers (National Quality Review System (NQRS) / Centralized Quality Review System (CQRS)) cannot be used to evaluate employees.


**1.4.29.6.1** **(11-12-2013)**

#### Workload Management/Efficiency Reviews

1. Critical Job Element (CJE) 5, Business Results - Efficiency, provides the performance expectations for Timeliness and Meeting Deadlines, Time Utilization, and Workload Management. This involves the following:



   - Inventory time is appropriately used to work cases

   - Casework is completed in an efficient manner

   - Inventory is appropriately managed

   - Closed Case Review – a review of a completed examination

   - Side by Side Review – a review of an employees work either at the desk or at the time the employee is assigned to telephone duty

   - Time on Case Review – a review to determine if the direct examination time is charged properly on each case and on Form 3081


2. Consider the following factors when performing a Workload Management/Efficiency review:



   - Level of training and experience of the employee

   - Specialization of work


3. The review can be performed by directly observing the employee (side by side) or reconstructing the actions taken by the employee during the defined period. Typically, this would be a block of time ranging from one to four hours or two complete cases and will include, but is not limited to, the following:



   - Open Cases - including overage cases, suspense cases, etc.

   - Closed Cases



     ### Note:



     All reviews **MUST** be documented.


4. Conducting the review using the side by side approach (as discussed above), will allow the manager to complete the reviews timely and improve the quality of the feedback.

5. Workload Management/Efficiency reviews determine if an employee is:




| Items to determine employee efficiency |
| --- |
| - Completing casework in an efficient manner (time spent commensurate with complexity and training level).<br>     <br>   - Appropriately managing their inventory.<br>     <br>   - Following procedural guidelines.<br>     <br>   - Completing efficient research.<br>     <br>   - Accessing available electronic research tools.<br>     <br>   - Using applicable IDRS Accessory Manager Tools, i.e. IAT.<br>     <br>   - Transferring cases appropriately.<br>     <br>   - Monitoring and closing necessary case controls.<br>     <br>   - Transcribing pertinent data accurately.<br>     <br>   - Analyzing data correctly.<br>     <br>   - Making correct decisions.<br>     <br>   - Initiating timely and effective follow up actions.<br>     <br>   - Working cases according to aged order or other priorities as established by management directives.<br>     <br>   - Reporting time accurately using the proper Organization Function Program (OFP) codes for working paper inventory programs. |

6. Management is responsible for communicating expectations and evaluating employee performance relative to CJE 5, Business Results-Efficiency, pertaining to Timeliness, Time Utilization and Workload Management.

7. Follow guidance in the National Agreement regarding the rating of work performance.


**1.4.29.6.2** **(04-13-2017)**

#### Compliance Mandatory Evaluative Reviews

01. Evaluative reviews must be recorded in accordance with the National Agreement established between National Treasury Employees Union (NTEU) and management.

02. Conduct a **minimum of two evaluative reviews** (phone or paper) for each employee per month. The number and times for monitoring will be set by the Operation or Department Manager.



    ### Note:



    When an employee works in a blended environment (phone or paper), you should strive for a proportionate mix to review throughout the rating period.

03. Managers are required to perform **a minimum of one workload review per quarter for each employee**. For Correspondence Examiner Technicians (GS-0503) and Tax Examiners (GS-0592), the **workload review will consist of one bin review, and one day after/time utilization review.** For additional information, refer to the Training Course 22394-002 “Employee Performance Feedback for Correspondence Examination Managers”.



    ### Note:



    The number of reviews should be increased when warranted (for example, when quality results are below the target set for the year). These reviews should include closed case reviews and cold calls.





    ### Note:



    Bin Review: Team Leaders should make sure the employee’s bin is organized. Employee should have cases divided by priorities and also by correspondence received date. Inventory should be checked to make sure the cases are being moved timely and anything pending is being monitored. It is recommended that when doing a bin review, Team Leaders and/or Leads compare employees RGS inventory reports to each physical case in the employee’s bin.





    ### Note:



    Day After/Time Utilization: Team Leaders should review the Tax Examiner Daily Time Record or equivalent and make sure it is consistent with the employee’s Form 3081. Team Leaders should ensure that employees are utilizing an appropriate amount of time for completion of their work. Time taken should be consistent with the complexity of work completed.

04. Evaluative reviews must be conducted by a manager or an individual in an official acting manager capacity.

05. When conducting case reviews, ensure recordation is input into the Embedded Quality Review System (EQRS).



    ### Note:



    EQRS is a standardized data repository with trend analysis capabilities and reporting capabilities to use for employee evaluations.

06. Use the Employee Feedback Report on EQRS for sharing evaluative monitoring results. Refer to Article 12 of the National Agreement II on the time frame for sharing these reviews with the employee. If you do not meet these time frames (i.e., due to unexpected leave, etc.), notate the reason on the review sheet.

07. Obtain the employees acknowledgment on the designated form. Provide one copy to the employee and retain the other copy for the Employee's Performance Folder. (EPF). Be sure to sanitize when appropriate.

08. If for some reason reviews cannot be conducted on an employee (e.g., extended illness, furlough, managerial absence, etc.), a review waiver or other documentation is placed in the Employee Performance File (EPF) explaining why the required number of reviews were not conducted.



    ### Note:



    At the discretion of the site, these waivers are approved at the department level.

09. Department managers must ensure team managers conduct sufficient evaluative reviews to provide employees with a well documented evaluation. An EQRS Report is available for this purpose.

10. Department managers must provide monthly feedback to front line managers regarding adherence to the review requirement. This feedback addresses number of reviews conducted for each employee, type of review (paper, phones, targeted) and types of errors identified.


**1.4.29.6.3** **(02-07-2022)**

#### Mandatory Reviews for Form 911, Request for Taxpayer Advocate Service Assistance (And Application for Taxpayer Assistance Order (ATAO)

1. The Taxpayer Advocate Service (TAS) is an independent organization within IRS whose employees assist taxpayers who are experiencing economic harm, who are seeking help in resolving tax problems that have not been resolved through normal channels, or who believe that an IRS system or procedure is not working as it should.

2. A referral to a TAS office should be made if the IRS employee receives a taxpayer contact, and the employee cannot initiate action to resolve the taxpayer's inquiry or provide the relief requested by the taxpayer. A taxpayer does not have to specifically request TAS assistance to be referred to TAS.

3. Exam employees use IRM 13.1.7, Taxpayer Advocate Service (TAS) Case Criteria, to determine if a taxpayer's case meets any of the TAS Case Criteria, 1 through 9, found in IRM 13.1.7.2, Introduction to TAS Case Criteria.

4. Exam Managers must approve Form 911 /Form e-911, Request for Taxpayer Advocate Service Assistance (And Application for Taxpayer Assistance Order), with Criteria Code 5 through 7. Managers may delegate this responsibility to another person.

5. E-911, criteria 1 through 4 and 8, is systemically routed directly to TAS. Upon completion of the review, select one of the following actions:



1. **Approve** \- Correctly identified and completed referrals. This action will route the e-911 to TAS and remove it from inventory.

2. **Reject** \- Return e-911 to the originator. Add a note to explain reason for rejection.


6. For additional information regarding TAS guidelines within SB/SE Exam, see IRM 4.19.13.24, Taxpayer Advocate Service (TAS) Procedures.


**1.4.29.6.4** **(11-12-2013)**

#### Clerical Reviews

1. Clerical employees perform various administrative duties which support the IRS's ability to provide customer service. They may include the following:



1. Timekeeping

2. Mail receipt and distribution

3. Typing

4. Log or lists of controls and information

5. Maintenance of files

6. Receiving telephone calls

7. Other duties as assigned


2. You should focus not only on the employees ability to complete their assignments, but also on their ability to set priorities and complete assignments independently and expeditiously. You must conduct monthly reviews to determine the accuracy and timeliness of employees' work.

3. Clerical reviews should also address the clerical work process (For example, Form 3210 acknowledgement and follow-up.).


**1.4.29.6.5** **(11-12-2013)**

#### Documenting Evaluative Reviews

1. Documented monitoring is a part of the evaluation process. The National Agreement governs such recordings. When completing reviews, ensure they are:



1. Conducted according to department or other requirements.

2. Completed by a manager or an individual in an official acting manager capacity.

3. Input to the Embedded Quality Review System (EQRS) using the approved Data Collection Instrument (DCI) for each applicable Specialized Product Review Group (SPRG).

4. Shared in a timely manner as required by the National Agreement.



      ### Note:



      Supplemental evaluative reviews may be done by technical leads using the EQRS system; however, like all evaluative information, managers must share the review. The lead must sign the documentation as the reviewer and the manager must sign prior to sharing the review.


2. A manager narrates the review using enough detail to support their assessment. Clearly identify to the employee actions taken (or not taken) to accomplish the Critical Job Elements (CJE). The EQRS automatically identifies the critical element for each action addressed. Give examples of what employee said and examples of what could have been said.

3. When conducting a live review, do not interrupt a call unless the employee is:



1. Advising the taxpayer/caller incorrectly.

2. Providing discourteous service.

3. Unable to answer the question.

4. Threatened by a caller.



      ### Note:



      EQRS is a standardized data repository with trend analysis capabilities and reporting capabilities to use for employee evaluations.


**1.4.29.6.6** **(02-07-2022)**

#### Sharing Results

1. Sharing monitoring results is a two-way communication. The Employee Feedback Report on EQRS is available for this purpose and must be used. After sharing the review, managers must determine if the employee agrees with their assessment.




| **If an employee** | **Then** |
| :-: | :-: |
| Agrees | 1. Commend the positive aspects of the performance.<br>      <br>2. Discuss areas for improvement as appropriate. |
| Disagrees | 1. Obtain the cause of the disagreement.<br>      <br>2. Commend the positive aspects of the performance.<br>      <br>3. Discuss openly to resolve disputed issues.<br>      <br>4. Discuss areas for improvement.<br>      <br>5. Develop plan to improve performance as appropriate. |

2. Managers must follow the time frames for sharing performance feedback outlined in the current IRS/NTEU National Agreement, which states the following:



1. If the employee has provided incorrect information to a taxpayer, the manager will inform the employee as soon as possible. In all other instances, the evaluative recordation will be shared with the employee within fifteen (15) workdays of when the call was received by IRS or the contact was made with the IRS.

2. Obtain the employee’s acknowledgment on the designated form. Provide one copy to the employee and retain the other copy for the EPF. Sanitize all employee data containing a social security number or name.


3. If employee performance indicates a need for improvement, discussions should reference the current review and prior reviews to identify the observed progress. Identify and complete actions to assist the employee such as additional training or coaching.

4. To ensure appropriate corrective actions are taken on errors found in case reviews, Exam employees will follow the following instructions:



   - Managers and Lead CETs as their delegates must create a log to track all errors/issues identified through resolution.

   - Managers and Lead CETs as their delegates must document all cases that go through Compliance Mandatory Evaluative Review to indicate the case was reviewed and the date.

   - When errors are identified, follow-up will be required by the reviewer to ensure that those errors have been corrected.


**1.4.29.6.7** **(11-12-2013)**

#### Non-Evaluative or Coaching Reviews

01. Determine if additional monitoring/review is necessary based on the following factors:



    - Training

    - Employee's ongoing performance

    - Quality Review feedback

    - Required minimum monitoring



      ### Note:



      Use UCCE reports such as Wrap Time and Average Handle Time (AHT) as indicators to determine when additional monitoring is appropriate.


02. Managers and/or their lead technical employees can perform non-evaluative monitoring on the following:



    - Telephone calls

    - Paper Inventory reviews

    - Certain issues (e.g. Disclosure)


03. The primary purpose of a non-evaluative review is to help the employee develop and enhance their job skills. Effective non-evaluative reviews foster open lines of communication between the employee, the manager, and the lead employee. This enables the manager and/or their lead to receive employee feedback and transfer operational goals informally.



    ### Note:



    Non-evaluative target reviews help focus on issues causing high error rates.

04. When implementing major procedural revisions, non-evaluative reviews can help managers determine if additional discussion and procedural reviews during group meetings may be needed.

05. Non-evaluative or coaching reviews do not contain a written rating. Share the results orally. Some documentation is appropriate to establish it actually occurred. EQRS may be used to track employee development for this purpose. Have the employee initial and date. Provide one copy for the employee and retain the other copy in the employees drop file.

06. Non-evaluative or coaching reviews have a significant impact on how the taxpayer is treated, since our employee can take immediate advantage of our experience. The manager or the lead employee should conduct the review; however, occasionally delegating these duties to a skilled journey level employee, for training purposes, may be appropriate.

07. Non-evaluative reviews can help the manager and employee determine progress as a result of training and coaching conducted as part of a performance improvement plan.

08. A non-evaluative targeted review is one in which an entire call or case is not reviewed. These reviews may serve as indicators for areas where additional evaluative monitoring should be conducted.

09. Accomplish non-evaluative paper or procedural reviews using the same guidelines as provided in workload reviews.

10. Clearly explain any problems you identify and provide guidance for the employee to improve performance.


**1.4.29.6.7.1** **(11-12-2013)**

##### Side by Side Monitoring

1. You can accomplish non-evaluative monitoring by utilizing periodic side-by-side reviews, when deemed appropriate, or requested by an employee. Use the optional telephone jack (double plugging) on the employee's teleset. Apply this technique when circumstances merit an in-depth discussion for training purposes.

2. You may delegate this non-evaluative review to your lead or an OJI. Periodically, delegate this non-evaluative review to experienced employees to foster the team approach to improve your group's performance. This approach will ultimately improve the work process.



### Note:



Side by side monitoring with an experienced employee is a good training tool for new Exam employees answering telephone calls.


**1.4.29.6.8** **(02-07-2022)**

#### Command Codes for Exam Reconsideration Adjustment Reviews

1. The following IDRS Command Codes (CC) are available to review on-line adjustments:



   - QRADD

   - QRIND

   - RVIEW

   - QRACN



     ### Note:



     The above CCs are found in IRM 2.4.5, Command Codes QRADD, QRADDO, QRNCH, QRNCHG, RVIEW, QRACN, and QRIND for the Quality Review System.


2. Use CC QRADD to enter the employee numbers of employees you plan to review. Suspend all transactions input by your employee or group using CC QRADD or CC QRADDG for the same day. Transactions remain suspended for review for two days. After two days, all transactions not reviewed are released systemically for processing to the Master File.

3. Use CC QRIND with CC RVIEW to control workloads. CC QRIND requests a summary of an employee’s transactions available for review for a specific day. Evaluate adherence to IDRS security and procedures. It is useful to keep a control log of the CC QRIND reviews.

4. Use CC RVIEW to review all transactions or selected transactions input by individual employees. Input CC RVIEW within two days after a CC QRADD or a CC QRADDG request to review an adjustment.

5. Use CC QRACN to accept, reject, or review your employee's transaction input screens, displayed by using CC RVIEW. Review the displayed transaction for quality and appropriate documentation requirements before using CC QRACN.



1. Accepted transactions release to the Master Files for processing after the standard two-day hold.

2. Rejected transactions change from IDRS status "AP" to "DQ" the following work day. The reviewer/manager must print the action after rejecting the transaction. Send these prints back to the employee for corrective action.


**1.4.29.6.8.1** **(11-12-2013)**

##### Focus of the IDRS Adjustment Review

1. IDRS adjustment reviews help do the following:



   - Prevent unpostables

   - Ensure prompt correction of errors


2. Determine if employees use appropriate IRM procedures to input adjustments. To ensure overall quality of the work, if a performance problem exists, consider requiring review/approval of any or all IDRS adjustments.

3. Review a sample of IDRS adjustments with source documents, focusing on the following areas:



1. Appropriate source documents

2. Accurate and complete input data

3. Proper hold codes

4. Correct priority codes

5. Accurate source codes

6. Appropriate blocking series

7. Appropriate reason codes

8. Complete remarks section

9. Ensure use of mandated Integrated Automation Technologies (IAT) Tools


**1.4.29.6.8.2** **(11-12-2013)**

##### Delegating Reviews of IDRS Adjustments

1. A manager may delegate the IDRS reviews, but an employee may not conduct a review of their own cases.

2. If a manager delegates the review, the employee conducting the review briefs the manager and the employee involved.


**1.4.29.7** **(02-07-2022)**

### Operational Reviews

1. An Operational Review is an in-depth review and analysis of a particular program or function or a subordinate manager and their organizational component. Reviews are opportunities to improve overall effectiveness of managers, teams, departments, and Operation. Reviews of subordinate managers are imperative for their personal growth and the efficiency of the operation.

2. Operational reviews are conducted in the following manner:



   - Department Managers (DM) review frontline teams

   - Operation Managers (OM) review DMs

   - Directors review Operations


3. Follow guidelines in the current NTEU National Agreement regarding the rating of work.


**1.4.29.7.1** **(06-10-2025)**

#### Frequency

1. Each director, operation and department manager should complete an operational review of each subordinate component no less than every other year Directors may increase the frequency. Refundable Credits Examination Operation (RCEO) Directors/Planning & Analysis Staff will complete an Operation Site Review on each of the five Taxpayer Service campuses every year

2. Conduct more frequent follow-up reviews when warranted by indicators such as statistical data out of the acceptable range, lack of experience on the part of the subordinate manager, or poor results from prior reviews. These reviews should also have established follow-up review dates scheduled for any areas showing minimal/no improvement.

3. Each Operation and Department Manager will maintain an operational review schedule showing the date of the prior review and the scheduled and actual review dates for each component for which they are responsible. Prepare a schedule of planned reviews at the beginning of each fiscal year and no later than November 1st. Schedule review to ensure that all teams are addressed. Provide the schedule to the Operations Manager or Director as appropriate.


**1.4.29.7.2** **(06-10-2025)**

#### Coverage

1. Operational reviews are performed by:



   - Department Managers reviewing Frontline Teams

   - Operation Managers reviewing Department Managers

   - Directors/Planning & Analysis Staff reviewing Operations


### Note:

Information may be provided by the operations analyst or technical advisor to support the review(s) when available. As the process moves up through each component of management, the content of the review is streamlined to minimize duplication of effort and focus on the higher priorities at each level of management.

2. A Department Manager's review should cover a majority of the team's and employees’ responsibilities. Review should include but is not limited to; employee leave and attendance, workload management and inventory controls, EPF maintenance, timekeeping records, status of prior Headquarter Policy review action items and identified training needs of employees, specific feedback and action items as required.

3. An Operation Manager's review should cover a majority of all operational reviews completed by the Department Manager. The review should focus on the overall health of the Department including efficiencies and program enhancements, risk management, succession planning and staffing, statute controls, special projects, best practices, status of prior Headquarter Policy review action items, operational goals and future planning, specific feedback and action items as required.

4. Director/Planning & Analysis’ staff review should cover the Operation’s internal controls, best practices, risk operationalization, statute protection, staffing, succession planning, employee development, and the status of operational goals, status of prior Headquarter Policy review action items and future planning, specific feedback and action items as required.


**1.4.29.7.3** **(06-10-2025)**

#### Review Scope

1. Each Operation and Department Manager should review the manager’s Position Description and Performance Management System (PMS) expectations prior to starting the review.

2. Request the information needed from the manager in advance, generally 30 days. This will ensure all information is available at the start of the review.

3. Each Manager will set required reviews for each component. This may include the following items, but not limited to:



   - Employee Performance Files (EPF)

   - Meeting Minutes

   - Inventory Reports

   - Telephone contacts (where applicable)

   - Work in process

   - Closed cases

   - Leave tracking

   - Review samples and schedules

   - Evaluation/Midyear samples

   - Quality/Productivity/Improvement Initiatives

   - Management Controls Tracking


4. A current EPF check sheet/template should be included in all EPF folders. It is recommended when EPFs are reviewed:



   - Department Managers should include a review of EPFs for each team in the frontline operational review.

   - Operations Managers should review a sampling of EPFs from the various teams in each Department. Include a variety of skills (Manager, work leader, secretary, clerk, tax examiner) and employees with different levels of experience.


5. The scope of the Operational Review should include the applicable review topics. Additional review topics may be added at the discretion of the reviewer.



### Note:



SB/SE Campus Exam/AUR leadership will provide managers with suggested elements to review within each review topic. The suggested review elements may be changed as appropriate at the discretion of the reviewer.


**1.4.29.7.3.1** **(06-10-2025)**

##### Department Manager’s Operational Review of Frontline Manager (FLM)

1. **Leadership:**



   - Developing Others

   - Personal Development

   - Communication/Visibility to Staff

   - Networking/Collaboration with Peers and Stakeholders

   - Best Practices, Program Enhancements, Initiatives

   - FLM’s Use of Time

   - Employee Personnel Folders (EPF) Maintenance

   - Timekeeping Records/Controls


2. **Customer Satisfaction:**



   - Quality of EQRS and Other Compliance Reviews.

   - EQ/NQ Quality Improvement Action.

   - AUR/BUR Only: Notice Review Quality Improvement Actions.


3. **Employee Satisfaction:**



   - Performance/Conduct Feedback

   - Employee Engagement

   - Staff Utilization


4. **Business Results- Program Performance and Delivery:**



   - Inventory Controls

   - Work in Process/Program Delivery

   - Phone Program Delivery

   - Risk Management

   - Statute Protection

   - Miscellaneous Internal Control Reviews


**1.4.29.7.3.2** **(06-10-2025)**

##### Operation Manager’s Operational Review of Department Manager (DM)

1. **Leadership:** Evaluating Leadership involves review of actions taken toward DM Commitments:



   - Developing Others

   - Personal Development

   - Communication/Visibility to Staff

   - Networking/Collaboration with Peers and Stakeholders

   - Best Practices, Program Enhancements, Initiatives

   - DM’s Use of Time

   - Employee Personnel Folders (EPF) Maintenance

   - Timekeeping Records/Controls


2. **Customer Satisfaction:**



   - Quality of Work Performed in the Department.

   - EQ/NQ Quality Improvement Actions.

   - AUR/BUR Only: Notice Review Quality Improvement Actions.


3. **Employee Satisfaction:**



   - Performance/Conduct Feedback

   - Employee Engagement

   - Staff Utilization


4. **Business Results - Program Performance and Delivery:**



   - Work in Process/Program Delivery

   - Phone Program Delivery

   - Risk Management

   - Statute Protection

   - Miscellaneous Internal Control Reviews

   - Implementation of Action Items


**1.4.29.7.3.3** **(06-10-2025)**

##### Director/P&A Staff Operational Review of Operation Manager (OM)

1. **Leadership:**



   - Developing Others

   - Communication/Visibility to Staff

   - Best Practices, Program Enhancements, Initiatives


2. **Customer Satisfaction:**



   - Quality of Work Performed in the Operation.

   - EQ/NQ Quality Improvement Actions.

   - AUR/BUR Only: Notice Review Quality Improvement Actions.


3. **Employee Satisfaction:**



   - Employee Engagement

   - Staff Utilization


4. **Business Results - Program Performance and Delivery:**



   - Work in Process/Program Delivery

   - Delivery of Phone Coverage

   - Risk Management

   - Statute Protection

   - Miscellaneous Internal Control Reviews

   - Implementation of Action Items


**1.4.29.7.4** **(06-10-2025)**

#### Documentation

1. Allow sufficient time for performing the review, writing the report, and providing feedback from the final report to the manager or director as appropriate.

2. It is not intended that the review be completed all at once. Any item reviewed before the scheduled operational review should not be repeated. However, the results of such reviews should be included in the documented annual review,

3. Each operational review document should be prepared by the reviewer and be addressed to the applicable manager, department manager or operation manager

4. The review document should be issued promptly upon completion of the review. For purposes of assessing the timeliness of the review, the document date will be the same as the review completion date.

5. SB/SE Campus Exam/AUR leadership will provide managers with recommended operational review documents.

6. The operational review document should address Leadership, Employee Satisfaction, Customer Satisfaction, Business Results - Program Performance and Delivery and list the applicable review topics and every element reviewed. Include the following:



1. Summary of the observations (positive or negative)

2. Recommendations and action items

3. Follow-up dates


7. To provide continuity and a record of the problems and progress of each organizational component, the operational review document and all follow-up action items should be maintained in file folders or binders by organizational component. A signed and dated copy of the initialed operational review and all follow-up documentation should be placed in the EPF of the appropriate manager for future use in the evaluation process.


**1.4.29.7.5** **(06-10-2025)**

#### Review Follow-up

1. Managers should follow up to ensure timely accomplishment of the action item(s) identified in their reviews. One method to document follow-up is to leave a few blank lines below each action item in the operational review. The reviewer can then document follow-up results directly on the file copy of the review and will not have to initiate another document describing the follow-up.

2. The follow-up should be performed timely and include actions taken on problems identified, updated progress actions taken towards completion and any further actions identified. All actions requiring additional follow-up should be documented with a second date for completion.


**1.4.29.8** **(06-10-2025)**

### Monitoring the Age Listings

01. To ensure work is resolved timely and inventory reports reflect the correct data, each campus **MUST** download the Case Control Activity (CCA) 4243, IDRS Overage Report, CCA 4244, IDRS Multiple Case Control Report, from Control- D WebAccess (CTDWA) and the SSIVL, Statistical Sampling Inventory Validation. These reports are downloaded **weekly** to an Excel file, which becomes the Automated Age Listing (AAL). For additional information regarding these reports, see _IRM 1.4.29.8.1_, _CCA 4243 – IDRS Overage Report,_ and _IRM 1.4.29.8.2_, _CCA 4244 – IDRS Multiple Case Control Report_.

02. These reports allow the Planning and Analysis (P&A) analysts, and management to sort assigned cases by relevant criteria (e.g., age, category, last action date) to identify and prioritize workable overage cases or cases requiring follow-up actions.

03. Campus and Remote site Managers **must monitor** overage inventory for their assigned teams using the reports and share feedback with each employee weekly to ensure the employee is working inventory in accordance with established guidelines.

04. Managers of all teams with inventory will use the reports to perform weekly reviews of employees’ assigned cases to ensure employees are closing cases according to established program priority. Inventory should include:



    - Adjustments

    - Statutes

    - Refund Inquiry

    - Accounts Maintenance Research Hold (AMRH)

    - Unpostables

    - Operation Assistance Requests (OARs)

    - Identity Theft


05. Managers of teams with uncontrolled inventory, e.g., Centralized Authorization File (CAF) and/or Reporting Agent File (RAF), must perform reviews of employee’s work (desk reviews) to ensure established priorities are followed.

06. Age list reviews are performed for the following reasons:



    - Identify specific cases for review

    - Monitor the volume of the employee’s inventory

    - Set overage closure expectations

    - Identify potential problem cases


07. Some important items to watch in any age list review include:



    - Cases over the aging criteria

    - Inappropriate activity code

    - Expired purge/action dates

    - Excessive time elapsed since last action

    - Expired Statute

    - Inappropriate suspense cases


08. There are several methods available to conduct an age list review. Two methods are shown below.



    - Print the entire list for each employee and use color-coded highlighters or other notations to point out priority issues on the hard copy.

    - Use the AAL filters to reduce the overall list and display only priority cases. Add emphasis with color-coded cell highlights within Excel. If the data is stored on a shared drive, ensure PII information is protected in compliance with Data Security requirements. Share each employee’s list with an added column for follow-up comments. Print the reduced list if sharing files is difficult.


09. The AAL review is a required management review and **must** be documented and filed in the employee’s EPF per IRM 6.430.2.3.5(4), **Employee Performance File**.

10. ITM Course 11884, **Inventory Management for Campus Managers.**


**1.4.29.8.1** **(06-10-2025)**

#### CCA 4243 - IDRS Overage Report

1. This report contains all cases controlled to an IDRS employee number (in IRS received date order) and managers use this report to:



   - Identify cases that require action

   - Identify specific cases for review

   - Monitor the size of the employees' inventories

   - Determine if employees are working inventory in the proper order

   - Set closure expectations

   - Identify potential management problem cases

   - Monitor for the prevention of premature STAUP/TC 470


2. This reports below are available in Control-D every **Monday** morning:

3. The information in the AAL data fields provides proper case management. The following data fields are shown for each case on the report:




| Data Field | Description |
| :-: | :-: |
| Team | Team IDRS number for employee |
| "EMP#" | IDRS number of the employee case is assigned |
| TIN | Taxpayer Identification Number (SSN, EIN, ATIN, or ITIN) |
| MFT | Master File Tax Transaction Code |
| TXPD | Tax period of the case |
| NAME | Name Control |
| FRZ CODE | Freeze codes on the account |
| AGE | Number of days aged from the IRS received date<br> <br>### Note:<br>For Control Categories 1081, 1184, 3858, 3859,3864, 3911, 841P, ACKN, RCTF, RECL, ST32, TOAD, OOPS, PAID, UPP, URP1, or URPS, use the ACTION-DT instead of the IRS-RCVD-DT to compute the CASE-AGE when the CASE-STATUS-CD is background. |
| IRS RECD DATE | The date the case was received by the IRS. |
| ASSIGN DATE | The date the case was assigned to the current employee. |
| ACTIVITY CODE | The last action taken on the case. |
| ST | The Status Code of the case.<br> <br>   - A - Active case under control. Includes cases awaiting MFTRA, documents or action by the employee.<br>     <br>   - M - A controlled case that cannot be resolved due to long term delay (internal information, out-of-region document request, etc.<br>     <br>   - B - Background status used to monitor case.<br>     <br>   - S - When ending letters to the taxpayer and waiting for a response from the taxpayer (external Information) |
| CATE | The Category code of the case. |
| ACTION DATE | The date of the last IDRS action. |
| HM | (H)ave (M)et - Overage indicator. All taxpayer-initiated cases begin to age at 45 days. When the case reaches aged criteria for the first time an **\*** will be displayed, the case will display a 2 through 9 for each week the case is on the aged list. After 9 weeks a**>** is displayed. |
| (-) | Debit or credit indicator. |
| MOD BAL | Module balance of the case. |
| STAT AGE | Statute age of the case. Indicates statute conditions for current and prior year returns - over, expired or days remaining on statute. |
| STAUP CYC | Indicates the number of posting cycles before a STAUP expires. Value of**“S”** is shown if a STAUP is active along with the number of cycles remaining when three or less follows**“S”**<br>### Note:<br>Example:**“S-2”** indicates 2 cycles remain on the STAUP. Value of **“D”** is shown if a STAUP is active for TISGND (TDI), and a value of**“T”** is shown if a STAUP is active for a TC470 account. The applicable posting cycles also appear after the values of **“D”** and **“T”**. |
| C LETR | Indicates the letter number of the last C letter issued. |
| LETR DATE | Date the last letter was issued. |
| BOD | Business Operating Division. |
| CLC | BOD Client Code. This is a code to indicate the particular group of the BOD. |
| PLAN | Plan number. Always **“0”** on BMF cases. Plan number indicated for various TE/GE cases. |
| ASED | Assessment Statute Expiration Date - 3 years from the due date or received date, whichever is later. |

4. The **Activity Code** data field on the report is important to monitor. Activity codes should be up to date, consist of appropriate timeframes, and reflect current activity. Check activity codes to ensure:



   - They are updated timely and are appropriate for each case.

   - Cases in "Monitor" status have a follow-up date identified.

   - Any cases previously worked, but not closed in IDRS reflect the appropriate activity code. Activity codes such as 34-CR-TRAN; 54-TAX-ADJ; ADJ54; CRED-TRANS; RLSE-FRZ; TRUE-DUP; X-Claim; etc. may indicate the case was worked but not closed properly on IDRS.

   - Document requests have a pending date for follow-up and are followed up timely. Prior to ordering a document ensure the case is not workable without the document and perform a TIN search in CII.

   - Check for activity codes "ACTV" and "REASSIGN" , which have an older action date, generally those 14 days or older, as this can be an indicator the case may not have been reviewed yet for proper action and/or may be workable.


5. The Manager/Lead **must** review this report to ensure cases are being worked in priority order according to IRS received dates **(FIFO – First-In, First-Out)**.

6. Manager/Lead **must** provide employee with the page(s) (either electronically or by paper) of the report where the cases are controlled to their IDRS number. Annotate cases for follow-up actions by COB Monday or Tuesday. Highlight the cases on the report where:



   - The employee may have failed to initiate action on a priority program case such as identity theft or injured spouse, etc.

   - The employee may have failed to take timely actions such as follow-up on a case when the purge date has passed.

   - The case is in Nullified Unpostable (NLUN) category over 14 days old.

   - The Statute of Limitations on assessment of tax will expire within 90 days.

   - The STAUP has expired or there is no STAUP on a balance due account.


7. The employee will notate, on the bottom of the page, the actions taken on each case worked. Annotations should include C - Closed; U - Update; or S - STAUP input. The report should be returned to the Manager/Lead by close of business Thursday. The employee should work cases in the following priority order:



   - NLUN category cases.

   - The statute on assessment will expire within 90 days.

   - Taxpayer was contacted and purge date has passed.

   - Remaining cases by case type/priority in oldest date received order (FIFO).


8. The reports should be maintained for three months in the Employee Performance File (EPF).


**1.4.29.8.2** **(06-10-2025)**

#### CCA 4244 - IDRS Multiple Case Control Report

1. This report identifies cases when two or more employees have an open control base on the same TIN. It identifies the employee's IDRS numbers, tax year, and category for the duplicate controls.

2. This report is available in Control-D every **Monday morning**:



   - **Report Name: "MULTI CASE RE"**

   - **Job Name**: **CCA 4244x**

   - Multiple case reports that contain only Accounts Management data can be accessed using **Report Name: "MULTICASE-AM\*"**.


3. Managers **must** use this report to identify when there are multiple control bases on the same account. Identify the following:



   - Cases where the same employee has more than one control base open

   - Cases that can be rerouted to another area and closed

   - Cases where a different employee has an open control

   - Cases that can be closed due to previous actions



     ### Note:



     There will be times when more than one control base open on the same account is appropriate. Each case must be reviewed to determine if a multiple control base should remain open. Multiples with other service centers can be viewed and displayed in the report.


4. The information in the Multiple Case Listing data fields provides for proper case management. The report will show up to nine (9) multiple case controls. The following data fields are shown for each case on the report:




| Data Field | Description |
| :-: | :-: |
| TIN | Taxpayer Identification Number |
| BOD | Business Operating Division |
| BOD CLC | Business Operating Division Client Code |
| F/S | File Source |
| MFT | Master File Tax Account Code |
| Tax Period | Identifies the tax period that was controlled |
| PLN | Plan number, if applicable |
| N/C | Name Control |
| "C#" | Control Base Number |
| "Employee #" | Employee number for employee assigned |
| Status | Case History Status Code |
| Category | Category of first case |
| IRS Rcd Date | The first IRS received date |
| "C#" | Second Control Base Number |
| "Employee #" | Second employee number for employee assigned |
| Status | Second Case History Status Code |
| Category | Category of second case |
| IRS Rcd Date | The second IRS received date |

5. The Manager/Lead **MUST**:



   - Provide the report (either electronically or by paper) by **COB Monday** to the employee identified as having controls on the case. For cases assigned to Central Distribution numbers or queues, the listings will be worked by the designated team lead/manager.

   - Instruct the employee to annotate the actions taken on the case on the report and return the annotated report to the Manager/Lead **no later than close of business on Thursday**.



     ### Note:



     When there are multiple open CII cases on a TIN, **ensure** the employee uses the "Close As MISC" button (on the CII case page). This button closes the CII case and updates the category code to "MISC" (in IDRS only), while closing the IDRS control base. For additional information using the "Close As MISC" button on CII, see IRM 21.5.1.5.1(16), _CII General Guidelines_, and IRM 21.2.1.9(4), _Correspondence Imaging Inventory (CII)._





     ### Note:



     For units with identity theft multiple controls, **ensure** the employees follow guidelines in IRM 25.23.3.2, _Identity Theft Paper Overview_, and Exhibit 25.23.4-7, _Identity Theft Multiple Control Decision Document._

   - After it is returned by the employee, review the report to determine if the correct actions were taken or return to the employee with feedback on the actions that need to be taken.

   - Maintain these reports for three months in the Employee Performance File (EPF).


**1.4.29.9** **(02-07-2022)**

### Statute Protection

1. Managers have primary responsibility for initiating and maintaining statute controls and ensuring that all employees within their jurisdiction:



1. Understand the law pertaining to statutes commensurate with the employees' assigned responsibilities

2. Maintain required statute controls

3. Make timely assessments of tax and penalties


2. See IRM 25.6.23, Statute of Limitations, Examination Process - Assessment Statute of Limitations Controls, for specific managerial responsibilities.


**1.4.29.9.1** **(11-12-2013)**

#### Statute Training

1. Managers are responsible for ensuring all employees within their jurisdiction are trained to identify imminent statutes and actions needed to protect statutes. Statute of Limitations is covered in Lesson 5 of training course 18664, Correspondence Examination Procedural, General Program Casework Information (Student Guide), for new hire employees in the Correspondence Examination Area.

2. A Statute Awareness Briefing and a 7114 meeting are required to be given to each employee annually. The meetings remind each employee of their responsibility to identify statutes and protect the government’s interest in all casework and re-enforce that failure to properly protect a statute could result in disciplinary actions up to and including removal from the IRS.


**1.4.29.9.2** **(02-07-2022)**

#### Statute Managerial Review

1. First line supervisors of personnel working statute cases will conduct periodic reviews of cases assigned to the employees. The purpose of the review process is to ensure that employees are processing cases properly and in a timely manner. Additional IDRS training, research guidance, or counseling may be warranted if deficiencies are noted. See IRM 25.6.1.4.4, Necessity of Managerial Review, and IRM 25.6.23.4.2, Campus Manager Responsibilities, for more details.


**1.4.29.9.3** **(02-07-2022)**

#### Barred Assessments

1. If a legal tax assessment is not made timely within the prescribed period for assessment or Assessment Statute Expiration Date (ASED), it is considered a ‘barred assessment’. Barred assessments are a revenue loss to the IRS including credits transferred to Excess Collections. See IRM 25.6.1.13.2.8.5, Statute Expiration Reporting Responsibilities and Procedures for Campus Exam/AUR, for more details on the reporting process and completion of required forms.


**1.4.29.9.4** **(11-12-2013)**

#### Statute Corrective Actions

1. Management is required to review all barred statute reports to identify trends or gaps within their Operations to prevent future occurrences. Information on completed Form 3999, Statute Expiration Report to identify appropriate measures for preventing similar problems from happening in the future. These measures may include alerts to raise awareness, training to improve skill or knowledge, or, in some instances, discipline to promote adherence to well known policies and procedures.


**1.4.29.9.5** **(02-07-2022)**

#### Helpful Statute References

1. As listed:



   - Basic Guide for Processing Statute Cases, See IRM 25.6.1.5, Basic Guide for Processing Cases with Statute of Limitations Issues

   - Form 12624, Statute Searched Card (Small).


2. Statute IRM References:



   - IRM 25.6.1, Statute of Limitations Processes and Procedures

   - IRM 25.6.22, Extension of Assessment Statute of Limitations by Consent

   - IRM 25.6.23, Examination Process-Assessment Statute of Limitations Controls


**1.4.29.10** **(03-26-2019)**

### Document Matching Program Management

1. Document matching programs are those programs where income documents such as Form W-2 (Wage and Tax Statement), Form 1098 (Mortgage Interest Statement), Form 1099-DIV (Dividends and Distributions), and other information returns are matched or cross-referenced by payer/payee to the appropriate tax returns. These programs are unique in that they each rely on a separate automated inventory control system to monitor their program.

2. The document matching programs worked in the Compliance function include:



   - SFR/ASFR - Substitute for Return/Automated Substitute for Return

   - AUR - Automated Under Reporter

   - CAWR - Combine Annual Wage Reporting

   - SSA-CAWR - Social Security Administration/Combine Annual Wage Reporting

   - FUTA - Federal Unemployment Tax Act

   - TIN Matching - Notice 972-CG Program

   - BWH A and B - Back Up Withholding Notice A and B (also a TIN matching program)

   - Return Delinquency Program - Matches Information Return Processing (IRP) documents with the Return Transaction File (RTF)


**1.4.29.10.1** **(03-26-2019)**

#### Document Matching Functional Guidelines

1. For general Compliance management responsibilities, refer to IRM 1.4.1, Resource Guide for Managers, Management Roles and Responsibilities and iManage - Home.

2. Specific program inventory guidelines are located in Part 4, Examining Process, and Part 5 Collecting Process.

3. Specific Quality Review guidelines are located in IRM 21.10.1, Embedded Quality (EQ) Program for Accounts Management, Campus Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support.


**1.4.29.10.2** **(03-26-2019)**

#### Document Matching Nature of Workload

1. Document matching programs consist of initiating outgoing correspondence (usually notices), incoming responses and/or telephone calls.

2. Depending on the campus policy, late replies to the document matching programs (replies received after the account has been adjusted) may or may not be worked in the Compliance function.


**1.4.29.10.3** **(03-26-2019)**

#### Document Matching Mandatory Reviews

1. In addition to the reviews mentioned in _IRM 1.4.29.6.1_, Workload Management/Efficiency Reviews, for all Compliance managers, the following program specific reviews are required or recommended:



   - SFR/ASFR

   - Adjustments to accounts resulting from filed returns

   - ASFR weekly error lists

   - Accounts Maintenance Research (AMRH) transcripts

   - Excess collection transfers

   - AUR - See IRM 1.4.19, Automated Underreporter Technical and Clerical Managers and Coordinators Guide

   - CAWR - Random Notice Review

   - FUTA - Random Notice Review

   - Tin Matching/BWH - Random Notice Review


**1.4.29.10.4** **(02-07-2022)**

#### Document Matching Managerial Reports

1. It is necessary for each manger to monitor the reports in IRM 1.4.29.

2. Each program generates its own set of unique reports. In addition, each program has certain reporting requirements to Headquarters. The reports and full descriptions are listed in the following IRMs:



   - SFR/ASFR - IRM 5.18.1.8, ASFR Reports

   - AUR - IRM 1.4.19, Automated Underreporter Technical and Clerical Managers and Coordinators Guide, and IRM 4.19.2.10, Reports,

   - SSA-CAWR - IRM 4.19.4, CAWR Reconciliation Balancing

   - FUTA - IRM 4.19.5.4.11, Recons (previously called Late Replies)

   - TIN Matching/BWH, IRM 5.19.3, Backup Withholding Program


**1.4.29.11** **(11-12-2013)**

### Training and Employee Development

1. Managers are responsible for the development and training of each employee working in the organization they direct. The following text outlines some of the responsibilities and provides links to helpful resources.


**1.4.29.11.1** **(02-07-2022)**

#### Exam Employee Training and Integrated Talent Management (ITM)

1. Exam employees training consist of Basic Income Tax Law, formal classroom training in procedures, and applicable computer applications. Training is enhanced annually through Continuing Professional Education (CPE). This training is directed and controlled by the Training Coordinator (TC). The TC has the responsibility to ensure accreditation is given to course participants in the Integrated Talent Management (ITM) application at: ITM.

2. For Correspondence Examination training courses, refer to Campus Exam SERP Portal at: Exam Research Portal-Training.

3. The Tax Examining Technicians required training courses are listed in this section. Applicable on-the-job (OJI) period is provided for new program training. Contact your Training Coordinator for training needs of other positions.


**1.4.29.11.2** **(02-07-2022)**

#### Training of Employees with Disabilities

1. For training information for employees with disabilities see IRM 1.4.20.24, Training of Employees with Disabilities. Internal Revenue Manual (IRM) Numerical Index, Learning and Education, provides broad policy and guidance needed to conduct and manage employee training and development. The following links provide additional information about Section 508 compliance.



   - [Section 508.gov](https://www.section508.gov/).

   - Information Resources Accessibility Program (IRAP) - Home .


**1.4.29.11.3** **(02-07-2022)**

#### On-the-Job Training

1. On-the-job training (OJT) is an integral portion of our tax technician's training. Effective OJT instructors are vital to the success of the Tax Technicians training program. As a front-line manager, you must contribute to that success by carefully selecting the best OJI (On Job Instructors) and by periodically meeting with them to review progress as well as provide feedback and support.

2. All managers should meet with their employees at least once a week to discuss their progress.


**1.4.29.11.4** **(11-12-2013)**

#### Annual Training for All Employees

1. Employees will receive annual training under the Continuing Professional Education (CPE) program, also referred to as Refresher Training. Local training needs, based on error trends and employee feedback, should be consolidated by the training coordinator. To keep employees informed of technical and procedural issues that relate to their jobs, mandatory and local training needs should always be included as part of the CPE. The timing for delivering CPE will be scheduled to ensure there is low impact to telephone and inventory schedules. In the event CPE training materials are not available for topics identified, development of new training material needs to be coordinated with the respective Headquarter analyst and Examination Training.


**1.4.29.11.5** **(02-07-2022)**

#### Training Courses for Exam Managers

1. In addition to managerial training, such as New Managers Orientation, Frontline Managers Training, and Core Leadership Training, the following list of training classes is suggested, and some required, for Exam managers. These courses will serve to enhance your ability as an IRS Manager and Team Leader to communicate with peers and subordinates. It will assist you in making decisions that are in the best interest of your employees, the customer, and the organization.



   - Training 11884, Return Integrity and Correspondence Services (RICS) Inventory Management for Campus Managers

   - Training 16662-C02, Frontline Manager Functional (Examination) Course (Participant Guide CD)

   - Training 22394, Employee Performance Feedback for Correspondence Examination Managers


**1.4.29.12** **(02-07-2022)**

### Useful Web Links and Sites

1. To help managers quickly find guidelines and instructions to do their jobs, links for useful web sites and information are listed in this section. Additional links for managers are located on the IManage site, see below, and in IRM 1.4.1.14, Quick Links to Useful Web Pages for Managers.


**1.4.29.12.1** **(02-07-2022)**

#### I Manage

1. iManage is a virtual community accessible only by IRS Managers. It provides information on the actual work you perform, advice such as performance evaluation tips and leave approval dos and don’ts. In addition, there is a monitored discussion board where you can discuss things with other managers, such as time management tips, engagement, best practices and “what if” scenarios. Access the iManage site at: iManage - Home.



### Note:



iManage access and usage is limited to managers. If you are a manager, see below for requesting access.


**1.4.29.12.2** **(11-12-2013)**

#### Obtaining Access to SharePoint, Share Drive Folders and iManage

1. Most of the links can be accessed without any special permission. However, permission to access some of the Campus Exam/AUR SharePoint sites and shared folders is required. The iManage site automatically grants access to employees coded as managers in HR Connect. Follow the steps below to obtain permissions when required:



1. **SharePoint Access**\- After attempting to access a site that you do not have the required permissions for, a box requesting a user name and password will be displayed. Click the cancel box in the lower right hand corner of the box. When the error box is displayed, complete the box with a reason access is needed and the URL you need access for. The site owner will process the request and notification will be sent to you once access is granted.

2. **iManage**-Limited access to managers only. If you are a manager and are unable to access the iManage site, please e-mail the Managers Resource Center at MRC@IRS.gov.


**1.4.29.12.3** **(02-07-2022)**

#### SB/SE Organization and Contacts

1. The My SB/SE Home Page, My SBSE is in the process of being phased out and replaced by the SB/SE Division site at Small Business Self Employed - Home , which contains links to Virtual Library - Home and other favorites.

2. SB/SE Examination, SB/SE Today .


**1.4.29.12.4** **(02-07-2022)**

#### SB/SE Campus Exam/AUR Operating Guidance

1. SB/SE Campus Exam/AUR Reporting Compliance Operating Guidelines can be found on the SB/SE Examination Knowledge Management site at Virtual Library - Home .


**1.4.29.12.5** **(02-07-2022)**

#### Business Measures and Monitoring

1. COBR Reports

2. Targets At A Glance (TAAG)

3. Planning & Performance Monitoring:



1. OFP Listing

2. Monthly Resource Reports

3. New Start Reports

4. Status Monitoring Report

5. Worked Correspondence


4. Customer Satisfaction Survey Reports: Customer Satisfaction Surveys Program.

5. Centralized Quality Review (CQRS)

6. Embedded Quality Review (EQ)

7. Control D: Control-D MCC


**1.4.29.12.6** **(11-12-2013)**

#### Research

1. Publishing Catalog: Find a Product

2. Servicewide Electronic Research Program (SERP): SERP


**1.4.29.12.7** **(03-07-2019)**

#### SB/SE Campus Exam Managers' Training

1. SB/SE Campus Exam/AUR Functional Management Training courses can be viewed by catalog number at: View by Catalog Number




| **Course Title** | **Number** | **Catalog Number** | **Title** |
| --- | --- | --- | --- |
| Frontline Manager Functional Training-Examination | 16662–102 | 50550 | Participant Guide |
| Frontline Manager Functional Training-Examination | 16662-004 | 59232 | Participant note pages |
| Frontline Manager Functional Training-Examination | 16662–C01 | 51567 | Instructor CD |
| Frontline Manager Functional Training-Examination | 16662–C02 | 51568 | Participant CD |
| Return Integrity and Correspondence Services (RICS) Inventory Management for Campus Managers | 11884–101 | 50929 | Instructor Guide |
| Return Integrity and Correspondence Services (RICS) Inventory Management for Campus Managers | 11884–102 | 50930 | Student Guide |
| Employee Performance Feedback for Correspondence Examination Managers | 22394–001 | 50041 | Instructor Guide |
| Employee Performance Feedback for Correspondence Examination Managers | 22394–002 | 50042 | Student Guide |


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-029#addtoany "Show all")

A2A