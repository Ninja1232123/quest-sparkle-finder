---
url: "https://www.irs.gov/irm/part1/irm_01-001-005"
title: "1.1.5 Office of the Commissioner | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-005#main-content)

- 1.1.5  [Office of the Commissioner](https://www.irs.gov/irm/part1/irm_01-001-005#id1)
  - 1.1.5.1  [Office of the Commissioner](https://www.irs.gov/irm/part1/irm_01-001-005#id2)
    - 1.1.5.1.1  [Senior Advisors and Special Assistants to the Commissioner](https://www.irs.gov/irm/part1/irm_01-001-005#id4)
  - 1.1.5.2  [Office of the Chief of Staff](https://www.irs.gov/irm/part1/irm_01-001-005#id5)
    - 1.1.5.2.1  [Executive Secretariat](https://www.irs.gov/irm/part1/irm_01-001-005#id7)
  - 1.1.5.3  [Office of the IRS Deputy Commissioner](https://www.irs.gov/irm/part1/irm_01-001-005#id8)
    - 1.1.5.3.1  [Chief Tax Compliance Officer](https://www.irs.gov/irm/part1/irm_01-001-005#id10)
    - 1.1.5.3.2  [Chief Operating Officer](https://www.irs.gov/irm/part1/irm_01-001-005#id11)
    - 1.1.5.3.3  [Chief Taxpayer Services](https://www.irs.gov/irm/part1/irm_01-001-005#id12)
    - 1.1.5.3.4  [Chief Information Officer](https://www.irs.gov/irm/part1/irm_01-001-005#id13)
    - 1.1.5.3.5  [Online Services](https://www.irs.gov/irm/part1/irm_01-001-005#id14)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 5. Office of the Commissioner

* * *

## 1.1.5 Office of the Commissioner

#### Manual Transmittal

August 11, 2025

#### Purpose

(1) This transmits revised IRM 1.1.5, Organization and Staffing, Office of the Commissioner.

#### Material Changes

(1) IRM 1.1.5.1 - Updated IRS structure based on April 8, 2024 reorganization, current IRS organizational reporting and operations. Simplified text and language.

1. Content updated to reflect the April 8, 2024 reorganization: A single IRS Deputy Commissioner reports to the Commissioner replacing two deputy commissioners, the Deputy Commissioner Operations (DCOS) and Deputy Commissioner Services and Enforcement (DCSE). IRS restructured to four IRS Chiefs (Chief Tax Compliance Officer, Chief Operating Officer, Taxpayer Services, and Chief Information Officer) reporting to the Deputy Commissioner. Previously business units were aligned to either the DCOS or DCSE based on their function.

2. Removed Equity, Diversity, and Inclusion (EDI) office to reflect new policy.

3. Added Taxpayer Experience Office and Direct File program office as reporting to the Office of Commissioner. Added Enterprise Case Management Office as reporting to the Chief Tax Compliance Officer.


(2) IRM 1.1.5.1.1 - Changed subsection title to “Senior Advisors and Special Assistants to the Commissioner” and rephrased text.

(3) IRM 1.1.5.3 - Updated content to reflect new organization structure of one IRS Deputy Commissioner, Chiefs, and organizations reporting to the IRS Deputy Commissioner.

(4) Throughout - Content has bee updated for plain language, links, punctuation and editorial corrections. Restructured content in outline numbering format.

#### Effect on Other Documents

This supersedes IRM 1.1.5 dated August 14, 2019.

#### Audience

IRS employees Servicewide

#### Effective Date

(08-11-2025)

Taquesha Cain

Director, Executive Secretariat

**1.1.5.1** **(08-11-2025)**

### Office of the Commissioner

1. The **Commissioner of Internal Revenue** presides over the nation’s tax system. The IRS Commissioner ensures that the agency maintains an appropriate balance between serving taxpayers and enforcing tax regulations, administering the tax code with both fairness and integrity. Nominated by the President of the United States and confirmed by the Senate for a five-year term, the IRS Commissioner holds a five-year term and is eligible for reappointment for additional terms.

2. The IRS Commissioner is tasked with establishing and interpreting policies related to tax administration, as well as developing strategic issues, goals, and objectives for the management and operation of the IRS. This role includes the overall planning, directing, controlling, and evaluation of IRS policies, programs, and performance.

3. The Office of the Commissioner consists of the Commissioner, IRS Deputy Commissioner , eight direct report offices to maintain their independence from the other business units.

4. The Commissioner directly supervises the:



1. IRS Deputy Commissioner

2. Senior Advisors and Special Assistant to the Commissioner

3. Chief of Staff

4. Chief, Communications and Liaison (C&L) - see IRM 1.1.11, Organization and Staffing, Communications and Liaison, for more information.

5. Chief, Independent Office of Appeals - see IRM 1.1.7, Organization and Staffing, Appeals, for more information.

6. National Taxpayer Advocate (NTA) - see IRM 1.1.8, Organization and Staffing, National Taxpayer Advocate, for more information.

7. Taxpayer Experience Office (TXO) - see IRM 1.1.33, Organization and Staffing, Taxpayer Experience Office, for more information.

8. Direct File - See IRM 25.32.1, Direct File, for more information.


5. **Chief Counsel** serves as the primary legal advisor to the IRS Commissioner on all matters pertaining to the interpretation, administration and enforcement of the internal revenue laws as well as all other legal matters. The Chief Counsel provides legal guidance and interpretive advice to the IRS, the Treasury Department and to taxpayers. The Chief Counsel is nominated by the President of the United States and confirmed by the US Senate. The Chief Counsel reports to the Commissioner, unless the IRS Restructuring and Reform Act of 1998 says otherwise. The Chief Counsel also reports to the Treasury General Counsel on certain matters. See IRM 1.1.6, Organization and Staffing, Chief Counsel for more information.


**1.1.5.1.1** **(08-11-2025)**

#### Senior Advisors and Special Assistants to the Commissioner

1. **Senior advisors and special assistants to the Internal Revenue Commissioner** are the Commissioner’s chief principle assistant. Senior advisors and special assistants to the Commissioner serve as key members of the immediate staff, providing advice and guidance on policy, operations, and management of the IRS. They act as facilitators, organizers, and communicators, working closely with the Commissioner, Deputy Commissioner, and other senior officials. These individuals are responsible for planning, coordinating, and performing significant assignments across all program and functional areas, including interactions with other government agencies, and non-governmental organizations.


**1.1.5.2** **(10-28-2008)**

### Office of the Chief of Staff

1. The **Chief of Staff** supervises the:



   - Deputy Chief of Staff

   - Executive Secretariat


2. The Chief of Staff and Deputy Chief of Staff reviews and appraises major policy issues and questions with implications for the IRS' position on a wide variety of issues. Responsibilities include:



1. Coordinating the review and analysis of policy proposals of direct interest to the IRS Commissioner.

2. Providing advice and evaluation of proposals, recommendations and reports requiring the IRS Commissioner’s approval.

3. Overseeing the management of the IRS Commissioner’s schedule and correspondence.

4. Managing a variety of executive oversight and decision-making processes.


**1.1.5.2.1** **(08-14-2019)**

#### Executive Secretariat

1. The **Executive Secretariat** reports to the Chief of Staff and provides financial and program support to the IRS Commissioner's staff and to component offices within the Office of the Commissioner.

2. The **Executive Secretariat Correspondence Office** (ESCO) reports to the Executive Secretariat and is responsible for assigning, monitoring and reviewing all ESCO controlled correspondence addressed to the Treasury Secretary, IRS Commissioner, Deputy Commissioners, and the Director, Legislative Affairs. See IRM 1.10.1, IRS Correspondence Manual for program office responsibilities, for more information.


**1.1.5.3** **(08-11-2025)**

### Office of the IRS Deputy Commissioner

1. The **Office of the IRS Deputy Commissioner** reports to the IRS Commissioner and oversees four primary divisions responsible for tax compliance, operations, taxpayer services and information technology.


**1.1.5.3.1** **(08-11-2025)**

#### Chief Tax Compliance Officer

1. **Chief Tax Compliance Officer (CTCO)** reports to the IRS Deputy Commissioner and is responsible for IRS compliance operations. The CTCO oversees the following operations with the heads of each operational organizations as direct reports.



1. Criminal Investigation (CI) – see IRM 1.1.19, Organization and Staffing, Criminal Investigation, for more information.

2. Enterprise Case Management Office (ECMO) – improves business, processes and modernizing systems to enhance the taxpayer and employee experience.

3. Large Business and International (LBI) – see IRM 1.1.24, Organization and Staffing, Large Business and International, for more information.

4. Office of Professional Responsibility (OPR) – see IRM 1.1.20, Organization and Staffing, Office of Professional Responsibility, for more information.

5. Return Preparer Office (RPO) – see IRM 1.1.28, Organization and Staffing, Return Preparer Office, for more information.

6. Small Business/Self-Employed (SB/SE) – see IRM 1.1.16, Small Business/Self-Employed, for more information.

7. Tax Exempt and Government Entities (TE/GE) – see IRM 1.1.23, Organization and Staffing, Tax Exempt and Government Entities Division, for more information.

8. Whistleblower Office (WO) – see IRM 1.1.26, Organization and Staffing, Whistleblower Office, for more information.


**1.1.5.3.2** **(08-11-2025)**

#### Chief Operating Officer

1. The Chief Operating Officer (COO) reports to the IRS Deputy Commissioner and oversees the IRS’s integrated support functions, facilitating economy of scale efficiencies and better business practices. The COO oversees the following operations with the heads of each operational organization as direct reports.



1. Office of the Chief Financial Officer (CFO) - see IRM 1.1.21, Organization and Staffing, Chief Financial Officer for more information.

2. Office of Chief Risk Officer (CRO) - see IRM 1.1.31, Organization and Staffing, Office of Chief Risk Officer, for more information.

3. Office of the Facilities Management and Security Services (FMSS) – see IRM 1.1.17, Organization and Staffing, Facilities Management and Security Services, for more information.

4. Office of the Chief Human Capital Officer (HCO) – see IRM 1.1.22, Organization and Staffing, Human Capital Office, for more information.

5. Office of the Privacy, Governmental Liaison and Disclosure (PGLD) – see IRM 1.1.27, Organization and Staffing, Privacy, Governmental Liaison and Disclosure, for more information.

6. Office of the Chief Procurement Officer (OCPO) – see IRM 1.1.32, Organization and Staffing, Office of the Chief Procurement Officer, for more information.

7. Office of Research, Applied Analytics and Statistics (RAAS) – see IRM 1.1.18, Organization and Staffing, Research, Applied Analytics and Statistics, for more information.


**1.1.5.3.3** **(08-11-2025)**

#### Chief Taxpayer Services

1. The Chief, Taxpayer Services reports to the IRS Deputy Commissioner. This role is responsible for all taxpayer services involving all tax return and payment receipt and processing. See IRM 1.1.13, Organization and Staffing, Wage and Investment (renamed Taxpayer Services) for more information.


**1.1.5.3.4** **(08-11-2025)**

#### Chief Information Officer

1. The Chief Information Officer (CIO) reports to the IRS Deputy Commissioner. This role is responsible for delivering information technology services and solutions that drive effective tax administration to ensure public confidence. See IRM 1.1.12, Organization and Staffing, Information Technology, for more information.


**1.1.5.3.5** **(08-11-2025)**

#### Online Services

1. The Director of Online Services (OLS) reports to the IRS Deputy Commissioner. This role is responsible for helping business units identify and deliver digital tax services. See IRM 1.1.29, Organization and Staffing, Office of Online Services, for more information.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-005#addtoany "Show all")

A2A