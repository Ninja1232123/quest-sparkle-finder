---
url: "https://www.irs.gov/irm/part1/irm_01-001-006"
title: "1.1.6 Chief Counsel | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-006#main-content)

- 1.1.6  [Chief Counsel](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253705920)
  - 1.1.6.1  [Chief Counsel for the Internal Revenue Service](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671254027632)
    - 1.1.6.1.1  [Organization of the Office of Chief Counsel](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253428576)
  - 1.1.6.2  [Deputy Chief Counsel (Technical)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253347936)
  - 1.1.6.3  [Deputy Chief Counsel (Operations)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252159840)
  - 1.1.6.4  [Executive Counsel](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252151680)
  - 1.1.6.5  [Associate Chief Counsel (Corporate)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253668528)
  - 1.1.6.6  [Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253669648)
  - 1.1.6.7  [Associate Chief Counsel (Finance & Management)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671254627152)
    - 1.1.6.7.1  [Area Manager (F&M)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252271952)
  - 1.1.6.8  [Associate Chief Counsel (Financial Institutions & Products)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253516608)
  - 1.1.6.9  [Associate Chief Counsel (General Legal Services)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252130656)
  - 1.1.6.10  [Associate Chief Counsel (Income Tax & Accounting)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252153568)
  - 1.1.6.11  [Associate Chief Counsel (International)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253402560)
  - 1.1.6.12  [Associate Chief Counsel (Passthroughs & Special Industries)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252154288)
  - 1.1.6.13  [Associate Chief Counsel (Procedure & Administration)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671250936224)
  - 1.1.6.14  [Division Counsel/Associate Chief Counsel (Criminal Tax)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671250950224)
    - 1.1.6.14.1  [Area Counsel (CT)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253732784)
  - 1.1.6.15  [Division Counsel (Large Business and International)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671254745200)
    - 1.1.6.15.1  [Area Counsel (LB&I)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252223776)
  - 1.1.6.16  [Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253386864)
  - 1.1.6.17  [Division Counsel (Small Business/Self-Employed)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253400688)
    - 1.1.6.17.1  [Area Counsel (SB/SE)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253983936)
  - 1.1.6.18  [Division Counsel (Strategic Litigation)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671252227296)
  - 1.1.6.19  [Division Counsel (Tax Exempt and Government Entities)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253590112)
  - 1.1.6.20  [Division Counsel (Wage & Investment)](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253803584)
  - 1.1.6.21  [Field Management Matrix](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253744080)
  - Exhibit  1.1.6-1  [Chief Counsel Organization](https://www.irs.gov/irm/part1/irm_01-001-006#idm139671253752336)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 6. Chief Counsel

* * *

## 1.1.6 Chief Counsel

#### Manual Transmittal

January 17, 2023

#### Purpose

(1) This transmits revised IRM 1.1.6, Organization and Staffing, Chief Counsel.

#### Material Changes

(1) Exhibit 1.1.6-1, updated with the new Chief Counsel Organization chart to reflect the addition of the Strategic Litigation Division.

(2) Minor stylistic updates throughout the document.

(3) IRM 1.1.6.15.1, National Strategic Litigation Counsel removed - some of the information from this section moved to IRM 1.1.6.18 due to establishment of Strategic Litigation as a new Division Counsel.

(4) IRM 1.1.6.18, Division Counsel (Strategic Litigation) added as a new section, reflecting information on the new Division Counsel within the Office of Chief Counsel.

#### Effect on Other Documents

IRM 1.1.6 dated October 22, 2021 is superseded.

#### Audience

All Divisions and Functions

#### Effective Date

(01-17-2023)

Thomas J. Travers

Associate Chief Counsel

(Finance and Management)

**1.1.6.1** **(06-18-2015)**

### Chief Counsel for the Internal Revenue Service

1. The Chief Counsel for the Internal Revenue Service (IRS) provides advice to the IRS Commissioner on all matters pertaining to the interpretation, administration and enforcement of the Internal Revenue laws, represents the IRS in litigation, and provides all other legal support needed by the IRS to carry out its mission of serving America’s taxpayers. In carrying out these responsibilities, Counsel must interpret the law with complete impartiality so that the American public will have confidence that the tax law is being applied with integrity and fairness.

2. The Office of Chief Counsel (Office) prepares legislative proposals, regulations, revenue rulings and procedures, actions on decisions, and other items of public guidance and legal advice. The Office coordinates these matters with other components of the Service, the Treasury Department, other government agencies, and international organizations.

3. The Office of Chief Counsel coordinates the IRS’s position in litigation with the IRS and the Department of Justice in order to ensure the Operating Divisions are taking consistent and appropriate technical positions in litigation. The Office prepares recommendations concerning defense, settlement, appeal, or certiorari; and coordinates other matters with the Department of Justice as required.

4. The Office of Chief Counsel reviews and coordinates pleadings, motions, briefs, settlement documents, notices of appeal, and any other material prepared in connection with United States Tax Court litigation. The Office processes petitions and complaints, briefs, actions on decision, and other matters.

5. The Office of Chief Counsel develops policy, procedure, directives, Chief Counsel Notices, Litigation Guideline Memorandums, and Chief Counsel Directives Manual provisions to provide uniform application of law and regulation. The Office provides support and guidance in connection with the development of Internal Revenue Manual provisions.

6. The Office of Chief Counsel issues Technical advice, and other legal advice responding to questions raised by IRS personnel. The Office reviews booklets, training materials, Audit Technique Guides, Coordinated Issue Papers, Appeals Settlement Guidelines, forms, publications and instructions to ensure technical accuracy, and upon request, assists in their preparation.

7. The Office of Chief Counsel issues letter rulings and general technical information letters in response to requests from taxpayers.

8. The Office of Chief Counsel also provides guidance on legal matters involving the IRS in the areas of claims, labor and personnel law; ethics and general government law; and public contracts and technology law.


**1.1.6.1.1** **(12-16-2020)**

#### Organization of the Office of Chief Counsel

1. The Deputy Chief Counsel (Technical) serves as the principal deputy to the Chief Counsel. The Deputy Chief Counsel (Technical) acts as the Chief Counsel when the position of Chief Counsel is vacant, and, when so acting, may perform all the functions or duties of the Chief Counsel, including any functions or duties that by law must be performed by the Chief Counsel personally. Additional information can be found in CCDM 30.3.1.7, Acting Chief Counsel under the Vacancies Reform Act and Other Matters of Succession.

2. The organization of the office is depicted in _Exhibit 1.1.6-1_. Key officials in the Office of Chief Counsel include:



   - Deputy Chief Counsel (Technical)

   - Deputy Chief Counsel (Operations)

   - Executive Counsel to the Chief Counsel

   - Associate Chief Counsel (Corporate)

   - Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes)

   - Associate Chief Counsel (Finance & Management)

   - Associate Chief Counsel (Financial Institutions & Products)

   - Associate Chief Counsel (General Legal Services)

   - Associate Chief Counsel (Income Tax & Accounting)

   - Associate Chief Counsel (International)

   - Associate Chief Counsel (Passthroughs & Special Industries)

   - Associate Chief Counsel (Procedure & Administration)

   - Division Counsel/Associate Chief Counsel (Criminal Tax)

   - Division Counsel/Associate Chief Counsel (National Taxpayer Advocate)

   - Division Counsel (Large Business & International)

   - Division Counsel (Small Business/Self-Employed)

   - Division Counsel (Strategic Litigation)

   - Division Counsel (Tax Exempt & Government Entities)

   - Division Counsel (Wage & Investment).


3. The major functions of these officials are described below. Detailed information concerning their duties is contained in CCDM 30.3.2, Delegations of Authority and Designations.


**1.1.6.2** **(12-16-2020)**

### Deputy Chief Counsel (Technical)

1. The Deputy Chief Counsel (Technical) maintains jurisdiction over legal issues arising in published guidance, letter rulings, technical advice, and other processes. The Deputy Chief Counsel (Technical) participates in the interpretation and development of internal revenue laws.

2. The Deputy Chief Counsel (Technical) supervises:



   - The Associate Chief Counsel (Corporate)

   - The Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes)

   - The Associate Chief Counsel (Financial Institutions & Products)

   - The Associate Chief Counsel (Income Tax & Accounting)

   - The Associate Chief Counsel (International)

   - The Associate Chief Counsel (Passthroughs & Special Industries).


**1.1.6.3** **(01-17-2023)**

### Deputy Chief Counsel (Operations)

1. The Deputy Chief Counsel (Operations) maintains jurisdiction over issues arising in litigation nationwide and has primary responsibility for matters involving management of the Office of Chief Counsel. The Deputy Chief Counsel (Operations) participates in the formulation of tax litigation policy.

2. The Deputy Chief Counsel (Operations) supervises:



   - The Division Counsel/Associate Chief Counsel (Criminal Tax)

   - The Associate Chief Counsel (Finance & Management)

   - The Associate Chief Counsel (General Legal Services)

   - The Division Counsel (Large Business & International)

   - The Division Counsel/Associate Chief Counsel (National Taxpayer Advocate)

   - The Associate Chief Counsel (Procedure & Administration)

   - The Division Counsel (Small Business/Self-Employed)

   - The Division Counsel (Strategic Litigation)

   - The Division Counsel (Tax Exempt & Government Entities Division Counsel)

   - The Division Counsel (Wage & Investment).


**1.1.6.4** **(12-16-2020)**

### Executive Counsel

1. The Executive Counsel to the Chief Counsel, Special Counsels and other senior advisors serve on the immediate staff of the Chief Counsel to provide advice and guidance regarding the formulation of policy; the management of the legal programs of the Office; the preparation and review of proposed legislation, implementation of complex legislation; or technical and legal issues of interest to the Chief Counsel or the IRS.


**1.1.6.5** **(12-16-2020)**

### Associate Chief Counsel (Corporate)

1. Associate Chief Counsel (Corporate) (CC:CORP) reports to the Deputy Chief Counsel (Technical). The office of the Associate Chief Counsel (Corporate) is located in Washington, D.C., consisting of:



   - A Deputy Associate Chief Counsel

   - Five technical branches

   - Technical and administrative staff.


2. The Associate Chief Counsel (Corporate) is responsible for tax matters involving:



   - Corporate organizations

   - Transfers to controlled corporations

   - Distributions to shareholders, including dividends, return-of-capital and gain-producing distributions, stock redemptions, spin-offs, split-offs, split-ups, and partial and complete liquidations

   - Acquisitive and divisive corporate reorganizations

   - Corporate debt vs. equity

   - Carryovers and carrybacks of losses, credits and other corporate tax attributes

   - Bankruptcies, insolvency proceedings, and other debt restructurings involving corporations

   - Constructive ownership of corporate stock

   - Consolidated return issues

   - Other issues affecting affiliated and controlled groups of corporations.


3. The office of the Associate Chief Counsel (Corporate) furnishes information, advice, and assistance in the development and drafting of internal revenue legislation, initiates legislative recommendations and in coordination with Legislative Affairs, advises the Associate General Counsel (Legislation, Litigation, and Regulation) regarding the views of the Office of Chief Counsel on proposed or pending legislation.

4. The office of the Associate Chief Counsel (Corporate) drafts proposed and final regulations, reviews public comments, conducts public hearings and participates in review of proposed and final regulations within the IRS and with the Department of Treasury.

5. The office of the Associate Chief Counsel (Corporate) drafts revenue rulings, revenue procedures, actions on decision, announcements, notices, news releases, and statements of the Office of Chief Counsel and participates in review of these documents within the Service and with the Department of Treasury.

6. The office of the Associate Chief Counsel (Corporate) issues private letter rulings to provide guidance for taxpayers and their advisers regarding the federal tax consequences of corporate transactions.

7. The office of the Associate Chief Counsel (Corporate) issues technical advice memoranda and other legal advice to IRS personnel.


**1.1.6.6** **(12-16-2020)**

### Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes)

1. The Associate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes) (CC:EEE) reports to the Deputy Chief Counsel (Technical). The office of Associate Chief Counsel (EEE), located in Washington, D.C. consists of:



   - A Deputy Associate Chief Counsel (Employee Benefits)

   - A Deputy Associate Chief Counsel (Exempt Organizations and Employment Taxes)

   - Special Counsels

   - Eleven branches

   - Administrative staff.


2. The office of Associate Chief Counsel (EEE) is responsible for issues pertaining to the uniform interpretation and application of federal tax laws involving:



   - Exempt organizations

   - Employee benefit plans (including employer-provided medical plans)

   - Executive compensation

   - Certain technical issues related to Indian tribal governments

   - Technical issues related to Federal, state, and local governments.


3. The office of the Associate Chief Counsel (EEE) provides legal and technical advice with respect to legislation: issues, regulations, and other guidance, letter rulings, and advisory opinions; and provides litigation support within its jurisdiction.


**1.1.6.7** **(12-16-2020)**

### Associate Chief Counsel (Finance & Management)

1. The Associate Chief Counsel (Finance & Management) (CC:FM) reports to the Deputy Chief Counsel (Operations). The office of the Associate Chief Counsel (F&M) consists of a number of divisions and technical and administrative staff in Washington, D.C., and three areas in the field.

2. The office of the Associate Chief Counsel (F&M) supports the administrative, financial and managerial programs of the Office of Chief Counsel. The office of the Associate Chief Counsel (F&M) performs all Counsel-wide finance and management activities. The office’s major functional areas include:



   - Business Systems Planning

   - Equal Employment Opportunity

   - Executive Resources

   - Field Support Operations

   - Human Resources

   - Labor and Employee Relations

   - Library Services

   - Planning and Financial Management

   - Training and Communications.


3. The office of the Associate Chief Counsel (F&M) manages Counsel’s business systems and strategic planning processes, system coordination, and organizational studies and analyses.

4. The office of the Associate Chief Counsel (F&M) directs the management of the Chief Counsel Library, a highly specialized tax law library system, which supports Chief Counsel and IRS staff in all substantive areas pertaining to tax law.


**1.1.6.7.1** **(12-16-2020)**

#### Area Manager (F&M)

1. The field support function is divided into three geographical areas with 14 to 17 posts of duty per area. The Area Managers (F&M) are responsible for managing administrative support to all field operations in the following programs:



   - Legal Services

   - Financial Management

   - Personnel Administration

   - Labor and Employee Relations

   - Library Services

   - Training.


**1.1.6.8** **(12-16-2020)**

### Associate Chief Counsel (Financial Institutions & Products)

1. The Associate Chief Counsel (Financial Institutions & Products) (CC:FIP) reports to the Deputy Chief Counsel (Technical). The office of the Associate Chief Counsel (FIP), located in Washington, D.C., consists of:



   - A Deputy Associate Chief Counsel

   - Six branches

   - Technical and planning staff

   - Administrative staff.


2. The office of the Associate Chief Counsel (FIP) provides legal advice, litigation services, and litigation support on tax matters involving financial institutions and the taxation of financial products including:



   - Insurance companies, products, and annuities

   - Commercial banks and thrift institutions

   - Regulated investment companies and real estate investment trusts

   - Equity and debt securities, including discount and premium obligations, and options, forwards, futures contracts, and other financial derivatives

   - Tax exempt bonds

   - Asset securitization, such as real estate mortgage investment conduits

   - Financial strategies, such as hedging arrangements, constructive sales, and straddles.


3. The Office of the Associate Chief Counsel (FIP) prepares legislative proposals, regulations, revenue rulings and procedures, actions on decisions, and other items of public guidance and legal advice and coordinates these matters with other components of the IRS, the Treasury Department, and other government agencies.

4. The office of the Associate Chief Counsel (FIP) issues technical advice or other legal advice responding to questions raised by IRS personnel. The Office reviews booklets, training materials, Audit Technique Guides, Coordinated Issue Papers, Appeals Settlement Guidelines, forms, publications and instructions to ensure technical accuracy, and upon request, assists in their preparation.

5. The office of the Associate Chief Counsel (FIP) issues letter rulings and general technical information letters in response to requests from taxpayers.


**1.1.6.9** **(12-16-2020)**

### Associate Chief Counsel (General Legal Services)

1. The Associate Chief Counsel (General Legal Services) (CC:GLS) reports to the Deputy Chief Counsel (Operations). The office of the Associate Chief Counsel (GLS) consists of three technical program offices in Washington, D.C. and six Area Counsel offices located in Atlanta, Chicago, Dallas, Manhattan, San Francisco, and Washington, D.C.

2. The office of the Associate Chief Counsel (GLS) represents the IRS and the Office of Chief Counsel in all proceedings not directly related to tax issues, with the exception of Freedom of Information Act (FOIA) and Privacy Act matters, including:



1. In the Area Counsel offices, legal advice and litigation in labor and personnel matters before arbitrators, the Merit Systems Protection Board (MSPB), the Federal Labor Relations Authority (FLRA), and the Equal Employment Opportunity Commission (EEOC).

2. In the Public Contracts and Technology Law (PCTL) Branch, legal advice with respect to government contracts, informant agreements, interagency agreements, laws related to information technology, and litigation before the Government Accountability Office (GAO), the General Services Administration Civilian Board of Contract Appeals (CBCA), and other government contract forums.

3. In the Claims, Labor & Personnel (CL&P) Branch, litigation, legal advice and assistance with respect to labor and employee relations matters, negotiation and collective bargaining, Section 1203 issues, and suits against government employees.

4. In the Ethics and General Government (EGG) Branch, legal advice with respect to ethics and general government issues including financial disclosure requirements, delegation orders, fiscal issues and appropriations law, advisory committees, and copyright and trademark issues.


3. The office of the Associate Chief Counsel (GLS) reviews and coordinates, as appropriate, pleadings, briefs, settlements, documents, notices of appeal and other materials prepared in connection with cases before a court, including the U.S. Tax Court, related to conflict of interest or ethical matters.

4. The Associate Chief Counsel (GLS) also has the delegated authority as the Deputy Ethics Official (DEO).


**1.1.6.10** **(12-16-2020)**

### Associate Chief Counsel (Income Tax & Accounting)

1. The Associate Chief Counsel (Income Tax & Accounting) (CC:ITA) reports to the Deputy Chief Counsel (Technical). The office of Associate Chief Counsel (ITA), located in Washington, D.C., consists of:



   - A Deputy Associate Chief Counsel

   - Seven branches

   - Technical and administrative staff.


2. The office of the Associate Chief Counsel (ITA) provides legal advice, litigation services, and litigation support on tax matters involving:



   - Recognition and timing of income and deductions

   - Sales and exchanges

   - Capital gains and losses

   - Accounting methods and periods

   - Depreciation and other cost recovery issues

   - Installment sales

   - Long-term contracts

   - Inventories

   - Alternative minimum tax

   - Certain credits

   - Opportunity Zones.


3. The office of the Associate Chief Counsel (ITA) performs the functions of the Office of Chief Counsel described in _IRM 1.1.6.1(1)-(7)_.


**1.1.6.11** **(12-16-2020)**

### Associate Chief Counsel (International)

1. The Associate Chief Counsel (International) (CC:INTL) reports to the Deputy Chief Counsel (Technical). The office of Associate Chief Counsel (International) consists of seven technical branches, and administrative staff. The office of the Associate Chief Counsel (International) is located in Washington, D.C.

2. The office of the Associate Chief Counsel (International) provides legal advice to support the uniform interpretation, application, enforcement, and litigation of all international and foreign tax matters:



   - Relating to the activities of non-U.S. persons or entities within the United States

   - Relating to the activities of U.S. persons or entities outside of the United States

   - Relating to issues regarding the U.S. Territories

   - Involving the international provisions of the Internal Revenue Code

   - Arising from bilateral and multilateral tax treaties and agreements to which the United States is a party.


3. The office of the Associate Chief Counsel (International) formulates and coordinates goals and strategies for the effective and comprehensive strategic management of international issues and assists the Treasury Department and other government agencies in tax treaty negotiations and in negotiations with respect to other international agreements.

4. The office of the Associate Chief Counsel (International) provides legal advice to LB&I and SBSE in developing and implementing campaigns involving international tax matters.

5. The office of the Associate Chief Counsel (International) provides legal advice and assistance to the U. S. Competent Authority, Treaty and Transfer Pricing Operations (TTPO), and Treaty Assistance and Interpretation Team (TAIT) on transfer pricing issues and matters of treaty interpretation and implementation, including both substantive legal issues as well as all procedural issues arising out of treaty-based processes, such as information exchange and cross-border information gathering and collection processes.


**1.1.6.12** **(12-16-2020)**

### Associate Chief Counsel (Passthroughs & Special Industries)

1. The Associate Chief Counsel (Passthroughs & Special Industries) (CC:PSI) reports to the Deputy Chief Counsel (Technical). The office of Associate Chief Counsel (PSI), located in Washington D.C., consists of:



   - A Deputy Associate Chief Counsel

   - Six branches

   - Technical and planning staff

   - Administrative staff.


2. The office of the Associate Chief Counsel (PSI) provides legal guidance, litigation services and litigation support for tax matters involving:



   - Income taxes of "S" corporations, partnerships (including limited liability companies), estates, and trusts

   - Estate, gift, and excise taxes

   - Oil, gas and other natural resources

   - Depletion

   - General business tax credits

   - Research and experimental expenditures

   - Cooperatives and homeowners associations

   - Low-income housing credit

   - Qualified business income deductions.


**1.1.6.13** **(12-16-2020)**

### Associate Chief Counsel (Procedure & Administration)

1. The Associate Chief Counsel (Procedure & Administration) (CC:PA) reports to the Deputy Chief Counsel (Operations). The office of the Associate Chief Counsel (P&A), located in Washington, D.C., consists of:



   - Three Deputy Associate Chief Counsels

   - The Legal Processing Division

   - Eight branches

   - Administrative staff.


2. The office of the Associate Chief Counsel (P&A) provides legal advice, litigation services, and litigation support on all facets of judicial and federal tax procedure and administrative practice including matters relating to:



   - Reporting and paying taxes; filing information returns

   - Assessing and collecting taxes (including interest and penalties)

   - Abating, crediting or refunding over-assessments or overpayments of tax

   - Bankruptcy; summonses and information gathering

   - Federal tax liens and levies

   - Damage claims

   - Attorney fees

   - Whistleblower awards and informant information

   - Administrative Procedure Act, 5 U.S.C. § 551 _et seq._

   - Various provisions of Title 5.

   - Privileges

   - Disclosure, Privacy Act and Freedom of Information Act issues

   - Judicial practice and judicial doctrines.


3. The office of Associate Chief Counsel (P&A) approves actions to be taken with respect to U.S. Tax Court subpoenas and disclosure of information in Tax Court litigation.

4. The office of Associate Chief Counsel (P&A) serves as the Commissioner’s delegate for assertion of claims of executive privilege involving internal or interagency records or information that are predecisional and deliberative in matters before the U.S. Tax Court, U.S. Court of Federal Claims and other federal courts.

5. The Associate Chief Counsel (P&A) serves the Office of Chief Counsel as the designated Sanctions Officer for purposes of Executive Order 12988, Civil Justice Reform.


**1.1.6.14** **(12-16-2020)**

### Division Counsel/Associate Chief Counsel (Criminal Tax)

1. The Division Counsel/Associate Chief Counsel (Criminal Tax) (CC:CT) reports to the Deputy Chief Counsel (Operations). The Office of the Division Counsel/Associate Chief Counsel (CT) consists of technical, planning, and administrative staff in Washington, D.C., and six geographic areas in the field.

2. The Division Counsel/Associate Chief Counsel (CT) provides legal advice, plans, directs, and coordinates policies and programs with respect to substantive criminal matters, criminal procedure and investigative matters, including:



   - Tax, currency, and money laundering crimes

   - Cybercrimes, including virtual currency

   - Administrative and grand jury investigations

   - Undercover operations and non-consensual electronic surveillance

   - Search warrants and forfeitures

   - Proposed Grants of Immunity under 18 U.S.C. § 6001, _et seq._

   - Referral of cases to the Department of Justice (DOJ) for prosecution or commencement of judicial forfeitures

   - Providing appellate recommendations to DOJ.


3. The Division Counsel/Associate Chief Counsel (CT) provides full time senior attorney(s) as instructors at the National Criminal Investigation Training Academy (NCITA) at the Federal Law Enforcement Training Center (FLETC) in Glynco, Georgia.


**1.1.6.14.1** **(12-16-2020)**

#### Area Counsel (CT)

1. Area Counsel (CT) are located in six geographic areas of the Division Counsel/Associate Chief Counsel (CT):



   - Atlanta

   - Baltimore

   - Chicago

   - Dallas

   - Laguna Niguel

   - Philadelphia


2. Each Area Counsel is responsible for advising and counseling the respective Directors, Field Operations in IRS Criminal Investigation’s three geographic areas and their Special Agents in Charge, located in field offices, in all legal aspects of the criminal tax investigation.


**1.1.6.15** **(01-17-2023)**

### Division Counsel (Large Business and International)

1. The Division Counsel (Large Business and International) (CC:LB&I) reports to the Deputy Chief Counsel (Operations). The office of Division Counsel (LB&I) consists of:



   - A Deputy Division Counsel (Operations)

   - A Deputy Division Counsel (International)

   - Five Area Counsels in the field arranged geographically across the country

   - Special Counsels and administrative staff in the Washington, D.C. headquarters.


2. The office of the Division Counsel (LB&I) is the principal legal advisor to the LB&I Division of the Internal Revenue Service, and a legal advisor to the IRS Independent Office of Appeals. The Division Counsel (LB&I) has primary responsibility for providing litigation services and legal advice on matters involving domestic and multinational corporations, subchapter S corporations, partnerships with substantial assets, and global high-wealth individuals.

3. The office of the Division Counsel (LB&I) handles the litigation of cases pending in the United States Tax Court, and prepares enforcement, defense, and settlement letters in summons enforcement and refund litigation cases. The Division Counsel (LB&I) makes recommendations of acquiescence and nonacquiescence in adverse decisions in litigation.


**1.1.6.15.1** **(12-16-2020)**

#### Area Counsel (LB&I)

1. The Area Counsels provide legal services to the LB&I Division of the Internal Revenue Service Compliance Practice Areas and are located within each of five geographic offices of the Division Counsel (LB&I):



   - Manhattan

   - Philadelphia

   - Downers Grove/Chicago

   - Houston/Dallas

   - Oakland/San Francisco.


2. The Area Counsels are responsible for providing legal advice and counsel relating to matters involving domestic and multinational corporations, subchapter S corporations, partnerships with substantial assets, and global high-wealth individuals.

3. The Associate Area Counsels (LB&I) are the first-line managers of LB&I attorneys. The Associate Area Counsels report to the Area Counsel in their geographic areas.

4. LB&I attorneys represent the Commissioner of the Internal Revenue Service in the United States Tax Court; prepare enforcement, defense, and settlement letters, or otherwise assist the Department of Justice, in summons enforcement and refund litigation cases; and provide legal advice and counsel during examination and administrative resolution of cases involving matters under the Area Counsel responsibility.


**1.1.6.16** **(12-16-2020)**

### Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program)

1. The Division Counsel/Associate Chief Counsel (National Taxpayer Advocate Program) (CC:NTA) provides legal advice and support directly to the National Taxpayer Advocate (NTA) and headquarters employees of the Office of the Taxpayer Advocate (commonly referred to as the Taxpayer Advocate Service (TAS)) to assist TAS in fulfilling its mission and responsibilities as set forth in the Internal Revenue Code (IRC). As CC:NTA does not have a field component, the Office of the Division Counsel (Small Business/Self-Employed) serves as legal advisor to TAS field offices.

2. CC:NTA is responsible for matters that:



   - Require interpretation of the provisions of IRC §§ 7803(a)(3) and (c), 7811 and 7526

   - Raise questions regarding the authority delegated to the National Taxpayer Advocate (NTA) and TAS

   - Relate to legislative recommendations or any other matter associated with the NTA’s Reports to Congress

   - Involve published guidance, legislative proposals, and other advice that impacts areas of interest to the NTA and TAS

   - Require advice on any other specialty related to the NTA or the TAS organization.


**1.1.6.17** **(12-16-2020)**

### Division Counsel (Small Business/Self-Employed)

1. The Division Counsel (Small Business/Self-Employed) (CC:SB) reports to the Deputy Chief Counsel (Operations). The office of Division Counsel (SB/SE) consists of technical, planning, and administrative staff in Lanham, Maryland, and nine areas in the field.

2. The Division Counsel (SB/SE) is the principal legal advisor to the Division Commissioner, SB/SE, and to the field components of the Wage & Investment Division, the Taxpayer Advocate Service, and the SB/SE function of the Independent Office of Appeals.

3. The office of the Division Counsel (SB/SE) provides legal advice, services and litigation on matters relating to:



   - All cases involving collection and bankruptcy issues, regardless of their taxpayer classification

   - Individuals who file Schedules C, E, or F, or Form 2106

   - Estate and gift tax returns

   - Fiduciary returns

   - Excise tax returns and/or forms

   - Individuals who file or work abroad or in a U.S. Territory, who hold income producing assets in a foreign country or claim the foreign earned income exclusion or foreign tax credit, or who have a U.S. filing requirement

   - Corporations, S corporations and partnerships with assets less than 10 million

   - Individuals classified as Wage & Investment taxpayers.


**1.1.6.17.1** **(12-16-2020)**

#### Area Counsel (SB/SE)

1. Area Counsel (SB/SE) are located in each of the nine geographic areas of the Office of the Division Counsel(SB/SE), coinciding with one or more IRS SB/SE compliance areas:



   - Boston

   - Philadelphia

   - Jacksonville

   - Chicago

   - Denver

   - Dallas

   - Portland

   - Los Angeles

   - Kansas City.


2. The Area Counsel are responsible for providing legal advice and assistance relating to matters within their geographical area.

3. The Associate Area Counsel (SB/SE) are the first-line managers of SB/SE attorneys and paralegals. The Associate Area Counsel report to the Area Counsel responsible for their geographic area.

4. SB/SE attorneys litigate cases in the U.S. Tax Court. They make civil suit referrals to the Department of Justice and assist the Department of Justice in handling civil litigation in other federal courts and state courts. They provide legal advice and assistance relating to matters not in litigation.


**1.1.6.18** **(01-17-2023)**

### Division Counsel (Strategic Litigation)

1. The Division Counsel (Strategic Litigation) (CC:SL) reports to the Deputy Chief Counsel (Operations). The office of the Division Counsel (SL) is a national organization with employees in various field offices across the country and consists of:



   - Two Deputy Division Counsels,

   - Senior-Level Counsels and Senior-Level Special Trial Attorneys,

   - Twelve Strategic Litigation Counsels,

   - Special Trial Attorneys, Special Counsels, Staff Attorneys, Paralegals, and Administrative Support Staff.


2. The headquarters office of the Division Counsel (SL) consists of:



   - Deputy Division Counsels: serve as primary advisors on strategic litigation matters, assist in formulating policies and programs, and oversee the cases under the responsibility of the Division Counsel (SL),

   - Senior Level Counsels: provide technical support to the Division Counsel (SL) and Deputy Division Counsels (SL), reporting to either the Division Counsel or the Deputy Division Counsel, and

   - Special Counsels, Staff Attorneys, and Administrative Support Staff.


3. The field offices of the Division Counsel (SL) consist of:



   - Senior Level Special Trial Attorneys: handle the largest and most complex cases under the responsibility of the Division Counsel (SL), reporting to the Deputy Division Counsels,

   - Strategic Litigation Counsels: serve as first-line managers of the Special Trial Attorneys and Paralegals, reporting to the Deputy Division Counsels,

   - Special Trial Attorneys: represent the Commissioner of Internal Revenue Service in cases under the responsibility of the Division Counsel (SL), reporting to the Strategic Litigation Counsels, and

   - Paralegals: provide support to trial teams under the responsibility of the Deputy Division Counsels, reporting to the Strategic Litigation Counsels.


4. The office of the Division Counsel (SL) is responsible for the most significant and complex litigation in the United States Tax Court, including cases considered "Significant" under the Chief Counsel Significant Case Coordination Program.

5. The office of the Division Counsel (SL) provides legal advice and services to the Internal Revenue Service on its most significant non-docketed cases.

6. The office of the Division Counsel (SL) makes civil suit referrals to the Department of Justice and assists the Department of Justice in handling civil litigation in other federal courts and state courts.


**1.1.6.19** **(12-16-2020)**

### Division Counsel (Tax Exempt and Government Entities)

1. The Division Counsel (Tax Exempt and Government Entities) (CC:TEGEDC) reports to the Deputy Chief Counsel (Operations). The office of Division Counsel (TEGEDC) consists of management, technical, and administrative headquarters staff, and six areas in the field.

2. The Division Counsel (Tax Exempt and Government Entities) is the principal legal advisor to the Division Commissioner, TE/GE, and to the Division Commissioner, SB/SE, on employment tax issues.

3. The office of the Division Counsel (TEGEDC) provides legal advice, services and litigation on program matters, including tax issues, relating to:



   - Employee benefit plans, including qualified retirement plans and health and welfare programs

   - Exempt organizations, including public charities and private foundations

   - Taxation of federal, state, local and Indian tribal governments

   - Tax-exempt bonds

   - Employment taxes

   - Executive compensation

   - All cases involving collection and bankruptcy issues involving any of the above described taxpayers.


4. Area Counsel offices are designed as groups of versatile specialized staff providing nationwide advisory and litigation services to the TE/GE Operating Divisions on employee benefits, exempt organizations, employment taxes, Indian Tribal Government and government entities issues. In addition, Area Counsel offices provide advisory and litigation services to the SB/SE Employment Tax Exam functions.

5. TEGEDC’s six Areas and the location of the Area Counsel:



   - Northeast (Long Island)

   - Mid-Atlantic (Washington, D.C.)

   - Great Lakes (Chicago)

   - Gulf Coast (Dallas)

   - Mountain States (Denver)

   - Pacific Coast (Los Angeles).


**1.1.6.20** **(12-16-2020)**

### Division Counsel (Wage & Investment)

1. The Division Counsel (Wage & Investment) (CC:WI) reports to the Deputy Chief Counsel (Operations). The office of Division Counsel (W&I) consists of Special Counsel and is located in Washington, D.C.

2. The Division Counsel (W&I) provides advice on the legal issues, regulations, and needs relevant to serving all taxpayers who generally have income reported only on Forms W-2 and 1099.

3. The Division Counsel works closely with and provides advice to the IRS W&I Division Commissioner, the W&I Senior Leadership team and the W&I headquarters’ staff. That work includes advancing the Division’s programs and initiatives, reviewing policies, formulating strategies, and furthering the Division’s goal of providing efficient and effective taxpayer service programs including the filing, correction, and payment of federal income taxes; fraud and identity theft detection during return processing; and assistance to taxpayers in person and others by phone.

4. The field staff of the Division Counsel (Small Business/Self Employed) provides legal services to the IRS W&I Division field organization.


**1.1.6.21** **(12-16-2020)**

### Field Management Matrix

1. The Field Management Matrix is an integrated management structure that balances geographic and functional needs at all levels but does not change the existing Divisional lines of authority or supervisory chains of command. The Field Management Matrix focuses on office-wide issues of teamwork, resource allocation, and skill development. The matrix structure requires the appointed managers to assume additional duties to support cross-Divisional coordination and communication.

2. _**Managing Counsel**_ are appointed in each of the 48 posts of duty to address issues that have an office-wide impact, such as the following:



   - Office closings

   - Office functions

   - Recruitment

   - Training

   - Local bar and taxpayer community contacts


3. _**Area Teams**_ interact with Managing Counsel, assume a leadership role that transcends existing Division management roles, ensure collaboration and cooperation across Divisions, maintain high levels of Service-wide client satisfaction, and foster an effective relationship with the National Treasury Employees Union (NTEU). The teams are comprised of appointed representatives from each business unit, one of which is selected as the Team Leader, within the following geographic areas:



   - Northeast — CT, MA, ME, NH, NY, RI, VT

   - Central — DC, DE, KY, MD, MI, NJ, OH, PA, WV

   - Southeast — AL, AR, FL, GA, MS, NC, SC, TN, VA

   - Midwest — IA, IL, IN, KS, MN, MO, ND, NE, SD, WI

   - Southwest — AZ, CO, LA, MT, NM, NV, OK, TX, UT, WY

   - West — AK, CA, HI, ID, OR, WA


**Exhibit 1.1.6-1**

### Chief Counsel Organization

![This is an Image: 30379001.gif](https://www.irs.gov/pub/xml_bc/30379001.gif)

> Pictured is the organization chart for the Office of Chief Counsel, shown reporting to the General Counsel of the Treasury, with a dotted line linking this organization to the Commissioner of Internal Revenue. Reporting to the Chief Counsel are the Deputy Chief Counsel (Technical), Deputy Chief Counsel (Operations), Equal Employment Opportunity Program Manager, Counselor to the Commissioner, and Executive Counsel.Reporting to the Deputy Chief Counsel (Operations) are the following organizations: Associate Chief Counsel (Finance and Management) CC:FM, with 1 deputyDivision Counsel/Associate Chief Counsel (Criminal Tax) CC:CT, with 1 deputyDivision Counsel/Associate Chief Counsel (National Taxpayer Advocate) CC:NTATax Exempt and Government Entities Division Counsel CC:TEGEDC, with 1 deputyDivision Counsel (Large Business and International) CC:LB&I, with 2 deputiesDivision Counsel (Wage and Investment) CC:WIAssociate Chief Counsel (General Legal Service) CC:GLS, with 2 deputiesDivision Counsel (Small Business/Self Employed) CC:SBSE, with 2 deputiesAssociate Chief Counsel (Procedure and Administration) CC:PA, with 3 deputies.Division Counsel (Strategic Litigation) CC:SL, with 2 deputies.Reporting to the Deputy Chief Counsel (Technical) are the following organizations: Associate Chief Counsel (Corporate) CC:CORP, with 1 deputyAssociate Chief Counsel (Passthroughs and Special Industries) CC:PSI, with 1 deputyAssociate Chief Counsel (Income Tax and Accounting) CC:ITA, with 1 deputyAssociate Chief Counsel (Financial Institutions and Products) CC:FIP, with 1 deputyAssociate Chief Counsel (International) CC:INTL, with 3 deputiesAssociate Chief Counsel (Employee Benefits, Exempt Organizations, and Employment Taxes) CC:EEE, with 2 deputies.The Equal Employment Opportunity Program Manager is depicted, with a dotted line linking this position to the Associate Chief Counsel (Finance and Management).

[Please click here for the text description of the image.](https://www.irs.gov/media/129211 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-006#addtoany "Show all")

A2A