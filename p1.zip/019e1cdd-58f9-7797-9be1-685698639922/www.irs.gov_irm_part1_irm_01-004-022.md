---
url: "https://www.irs.gov/irm/part1/irm_01-004-022"
title: "1.4.22 CAWR Manager and Coordinator Guide | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-022#main-content)

- 1.4.22  [CAWR Manager and Coordinator Guide](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086654016)
  - 1.4.22.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113532064)
    - 1.4.22.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113643328)
    - 1.4.22.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113641808)
    - 1.4.22.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086616144)
    - 1.4.22.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113639584)
    - 1.4.22.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113634960)
    - 1.4.22.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086057424)
    - 1.4.22.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086055424)
  - 1.4.22.2  [CAWR Case Types](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086052368)
  - 1.4.22.3  [Technical Coordinator CATRS Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085280496)
    - 1.4.22.3.1  [Edit Option - Site Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085270240)
    - 1.4.22.3.2  [Application Sites](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113661520)
    - 1.4.22.3.3  [Application Information Screen](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113655184)
    - 1.4.22.3.4  [Release Variables (CAWR)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086469968)
    - 1.4.22.3.5  [User Profiles - Coordinator/Site Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086464880)
    - 1.4.22.3.6  [Add New User](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113592336)
    - 1.4.22.3.7  [Delete User](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113581504)
    - 1.4.22.3.8  [Update User Information and/or Profiles](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113570560)
    - 1.4.22.3.9  [Change Password](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085324016)
    - 1.4.22.3.10  [Unlock Account](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085306272)
  - 1.4.22.4  [Site Coordinator /Technical Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085297152)
    - 1.4.22.4.1  [Program Responsibilities - Site Coordinator/Technical Coordinator/Manager](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085295936)
    - 1.4.22.4.2  [CAWR Mass Letter Request](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113406656)
    - 1.4.22.4.3  [Identifying Trends](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113389136)
    - 1.4.22.4.4  [CAWR Batching](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113385920)
      - 1.4.22.4.4.1  [Assign Batch(es)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113371392)
      - 1.4.22.4.4.2  [Reassign Batch(es)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085258176)
      - 1.4.22.4.4.3  [Unassign Batch(es)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085250640)
    - 1.4.22.4.5  [IRS CAWR No Reply Auto Assess](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085243184)
    - 1.4.22.4.6  [SSA CAWR No Reply Auto Assess](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085233024)
  - 1.4.22.5  [Work Planning and Control](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085222672)
    - 1.4.22.5.1  [Program Completion Dates (PCD)- Manager/Site Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085221760)
    - 1.4.22.5.2  [Organization, Function and Program Codes (OFP) - Site Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085434880)
    - 1.4.22.5.3  [CAWR Reviews - Overview](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085354656)
      - 1.4.22.5.3.1  [Workload Review](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085347152)
      - 1.4.22.5.3.2  [Inventory Management Review](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085343072)
      - 1.4.22.5.3.3  [Clerical Reviews](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085333904)
      - 1.4.22.5.3.4  [On-The-Job Reviews](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085678720)
      - 1.4.22.5.3.5  [Evaluative Reviews](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085673696)
    - 1.4.22.5.4  [Program Reviews - Managers](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085666544)
    - 1.4.22.5.5  [Physical Inventory Review - Managers](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085659456)
  - 1.4.22.6  [Servicewide Electronic Research Program (SERP)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085649680)
  - 1.4.22.7  [CAWR IATS](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085646448)
  - 1.4.22.8  [Online Retrieval System (ORS) - Overview](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085642128)
  - 1.4.22.9  [CAWR Automated Program (CATRS)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085633456)
    - 1.4.22.9.1  [Contents References Introduction Objective Nightly Run Setup (CRON)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085629888)
    - 1.4.22.9.2  [System Problem Reporting](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085625328)
    - 1.4.22.9.3  [System Authorization and Security](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086576896)
  - 1.4.22.10  [Miscellaneous Coordinator/Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086557728)
    - 1.4.22.10.1  [Statute of Limitations - Manager/ Statute Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086556720)
      - 1.4.22.10.1.1  [Statute Searches](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086552160)
      - 1.4.22.10.1.2  [Confirmation Receipt of Prompt Assessments - Statute Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086543872)
    - 1.4.22.10.2  [Taxpayer Advocate Service (TAS)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086530912)
      - 1.4.22.10.2.1  [TAS Coordinator Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086523712)
    - 1.4.22.10.3  [CAWR Appeals Coordinator Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086517488)
    - 1.4.22.10.4  [Policy Statement P-21-3 (previously known as Action 61)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086500448)
    - 1.4.22.10.5  [Reconsiderations (Recons) received from Form 3870 Request for Adjustment](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086496800)
    - 1.4.22.10.6  [Large Corporation/Large Dollar Screening - Local Large Corporation Coordinator Instructions](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086490992)
    - 1.4.22.10.7  [Loose Forms W-2 and Form 8922](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086048144)
      - 1.4.22.10.7.1  [Adding New Loose Forms W-2](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086022960)
    - 1.4.22.10.8  [Discovered Remits](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190086009184)
    - 1.4.22.10.9  [Disaster Areas- Disaster Coordinator](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085976720)
      - 1.4.22.10.9.1  [Adding New Disaster](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085544192)
      - 1.4.22.10.9.2  [Deleting Disaster Area Information](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085530672)
      - 1.4.22.10.9.3  [Editing Disaster Information](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085521584)
    - 1.4.22.10.10  [Online Retrieval System Coordinator Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085510128)
      - 1.4.22.10.10.1  [Adding a User](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085506240)
      - 1.4.22.10.10.2  [Deleting a User](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085501696)
      - 1.4.22.10.10.3  [Changing Your Password](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085499152)
      - 1.4.22.10.10.4  [Resetting Your Password](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085496960)
      - 1.4.22.10.10.5  [ORS Tracking Sheet](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085493472)
    - 1.4.22.10.11  [Training Coordinator Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085489776)
    - 1.4.22.10.12  [Update Schedule D](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190085476608)
    - 1.4.22.10.13  [Generalized IDRS Interface (GII)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113523616)
    - 1.4.22.10.14  [Supervisory Approval to Assess Penalties](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113518256)
  - 1.4.22.11  [CAWR Reports - Site Coordinator/Coordinator/Manager](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113516400)
    - 1.4.22.11.1  [Integrated Data Retrieval System Reports (IDRS)](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190113427152)
    - 1.4.22.11.2  [CCA 42-42 - IDRS Inventory Control Report](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190118503408)
    - 1.4.22.11.3  [CCA 42-43 - IDRS Overage Report](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190118484768)
    - 1.4.22.11.4  [CCA 42-44 - IDRS Multiple Case Control Report](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190118454320)
  - Exhibit  1.4.22-1  [Glossary of Acronyms and Terms](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190118431296)
  - Exhibit  1.4.22-2  [Assigned Case Status Codes](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190084798752)
  - Exhibit  1.4.22-3  [Closed Case Status Codes](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190084756000)
  - Exhibit  1.4.22-4  [Profile Descriptions](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190084708192)
  - Exhibit  1.4.22-5  [Physical Inventory Certificate](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190084671008)
  - Exhibit  1.4.22-6  [Wall Inventory Instruction and Certification](https://www.irs.gov/irm/part1/irm_01-004-022#idm140190084637552)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 22. CAWR Manager and Coordinator Guide

* * *

## 1.4.22 CAWR Manager and Coordinator Guide

#### Manual Transmittal

July 16, 2025

#### Purpose

(1) This transmits revised IRM 1.4.22, Resource Guide for Managers, CAWR Manager and Coordinator Guide.

#### Material Changes

(1) IRM 1.4.22.1 - Program and Scope: Updated the program information.

(2) IRM 1.4.22.1.4 - Program Management and Review: Updated review overview.

(3) IRM 1.4.22.3.1 - Edit Options - Site Coordinator: Added table with CATRS system information.

(4) IRM 1.4.22.4.3 - Identifying Trends: Updated information on identifying trends.

(5) IRM 1.4.22.5.1 - Program Completion Dates (PCD)- Manager/Site Coordinator: Updated the PCD dates.

(6) IRM 1.4.22.5.2 - Organization, Function and Program Codes (OFP) - Site Coordinator: Updated tax years.

(7) IRM 1.4.22.5.4 - Program Reviews - Manager: Updated review information.

(8) IRM 1.4.22.5.5 - Physical Inventory Review - Managers: Updated review information.

(9) IRM 1.4.22.8 - Online Retrieval System (ORS): Added ORS information.

(10) IRM 1.4.22.9. - CAWR Automated Program (CATRS): Updated the CATRS information.

(11) IRM 1.4.22.9.1 - Contents References Introduction Objective Nightly Run Setup (CRON): Updated IRM reference.

(12) IRM 1.4.22.10.1 - Statute of Limitations - Manager/ Statute Coordinator: Updated statute information including mandated use of the Statute Portal.

(13) IRM 1.4.22.10.1.1 - Statute Searches: Updated the Statute search dates.

(14) IRM 1.4.22.10.1.2 - Confirmation Receipt of Prompt Assessments - Statute Coordinator: Updated Statute procedures.

(15) IRM 1.4.22.10.2 - Taxpayer Advocate Service (TAS): Updated IRM references.

(16) IRM 1.4.22.10.5 - Reconsiderations (Recons) received from Form 3870 Request for Adjustment: Updated 3870 procedures.

(17) IRM 1.4.22.10.7.1 - Adding New Loose Forms W-2: Updated the IRM reference.

(18) IRM 1.4.22.10.10.5 - ORS Tracking Sheet: Updated tracking sheet information.

(19) Exhibit 1.4.22-1 - Glossary of Acronyms and Terms: Updated terms.

(20) Exhibit 1.4.22-2 -Assigned Case Status Codes: Updated table information.

(21) Exhibit 1.4.22-3 - Closed Case Status Codes: Updated table information.

(22) Exhibit 1.4.22-5 - Physical Inventory Certification: Updated table information.

(23) Updated the CAP system with CATRS (Consolidated Annual Tax Reporting System).

(24) Updated and removed (previously called Late Reply) from Recons.

(25) Updated editorial changes and replaced links and references with the updated SB/SE Document Matching web page.

#### Effect on Other Documents

This IRM supersedes IRM 1.4.22 dated April 30, 2024.

#### Audience

CAWR Managers and Coordinators in Small Business/Self-Employed.

#### Effective Date

(07-16-2025)

Heather J. Yocum

Director, Exam Field and Campus Policy

Small Business/Self-Employed

**1.4.22.1** **(07-16-2025)**

### Program Scope and Objectives

1. Purpose: To provide procedures for managers and coordinators in the CAWR Operation. This section is designed to assist the managers and coordinators in the SB/SE Document Matching Combined Annual Wage Reporting (CAWR) operations.

2. Audience: The primary users of this IRM are Small Business/Self Employed (SB/SE) managers and coordinators in the CAWR operation.

3. Policy Owner: Director, Exam Field and Campus Policy.

4. Program Owner: SB/SE BMF Document Matching.

5. Primary Stakeholder: SB/SE CAWR Operation employees.

6. Program Goals: Program goals, procedures and due dates can be found in this section. _IRM 1.4.22.5.1_, Program Completion dates.


**1.4.22.1.1** **(04-30-2024)**

#### Background

1. The Social Security Administration (SSA) and Internal Revenue Service (IRS) have an agreement to exchange employment tax data. SSA shares Form W-2 data with the IRS and the IRS shares Forms 941, 943, 944, (henceforth called Forms 94X) and Form 1040 Schedule H data with SSA. The Combined Annual Wage Reporting (CAWR) is a document matching program that compares the Federal Income Tax (FIT) withheld, Medicare wages, Social Security wages, and Social Security tips reported to the IRS on the Forms 94X and Schedule H against the amounts reported to SSA via the processed totals of the Forms W-2.

2. The CAWR program has two basic components. The two components are the **Internal Revenue Service Case-CAWR (IRS-CAWR)** program and the **Civil Penalty Program-CAWR (SSA-CAWR)**.



### Note:



When referring to IRS CAWR cases, the reference will be IRS-CAWR. When referring to SSA CAWR cases, the reference will be SSA-CAWR. When an instruction indicates CAWR, it is referring to all case types.

3. IRS matches four fields — Social Security wages, Social Security tips, Medicare wages and tips, and Federal Income Tax (FIT) withheld. When this reconciliation results in an apparent underpayment of taxes or over withholding of FIT an IRS-CAWR case is created.


**1.4.22.1.2** **(03-29-2018)**

#### Authority

1. The authority is covered under Pub. L. No. 94-202, sec. 232, 89 Stat. 1135 (1976) (codified at 42 U.S.C. Sec. 432).


**1.4.22.1.3** **(03-29-2018)**

#### Roles and Responsibilities

1. The Director, SB/SE, Exam Field and Campus Policy is responsible for the CAWR program.

2. Management officials are responsible for:



   - Providing internal controls relating to the program, process and activity.

   - Ensuring the instructions are communicated to and carried out by the proper officers and employees.


**1.4.22.1.4** **(07-16-2025)**

#### Program Management and Review

1. If requested Headquarters may conduct a program review. The reviews will target recommendations made by the campus, including but not limited to adherence to the IRM and Policy directives, movement of inventory, manager and employee reviews, trends, and any areas of concern. Program Reports: The following reports are generated to assist with monitoring the performance of the CAWR program:



   - Consolidated Annual Tax Reporting System (CATRS) Reports

   - Overage Report Compiler and Sorter (ORCAS) Manager Reports also known as CCA 42-43 reports

   - Embedded Quality Review System (EQRS) Reports

   - National Quality Review System (NQRS) Reports


2. Program Effectiveness: The programs goals are measured by the inventory Status Report prepared by the Workload Planning and Analysis staff.


**1.4.22.1.5** **(07-16-2025)**

#### Program Controls

1. This program is monitored through the CATRS (Consolidated Annual Tax Reporting System).


**1.4.22.1.6** **(04-30-2024)**

#### Terms and Acronyms

1. See _Exhibit 1.4.22-1_, Glossary of Acronym and Terms for a list of acronyms used in this IRM.


**1.4.22.1.7** **(04-30-2024)**

#### Related Resources

1. IRM 4.19.4, CAWR Reconciliation Balancing.

2. IRM 4.19.22, CAWR Control.

3. IRM 4.19.8, CAWR (Combined Annual Wage Reporting) and CAP (CAWR Automated Program) Technical System Procedures.

4. Additional resources can be found on the CAWR/FUTA web site at CAWR Home page.


**1.4.22.2** **(04-30-2024)**

### CAWR Case Types

1. The purpose of the **IRS CAWR** program is to ensure employers paid and reported the proper amount of taxes, and federal withholding. This is done by comparing the Forms W-3/ W-2/ W-3C/ W-2C totals and the Forms 1099-R and W-2G withholding amounts to the amounts reported on the Forms 94X (Forms 941, 943, 944,) and Schedule H (Forms 1040/1041) employment tax returns.

2. IRS matches four fields:



   - Social Security Wages

   - Social Security Tips

   - Medicare Wages

   - Federal Tax Withheld (FIT)


3. IRS CAWR case types are 01, 02, 04A, 04B, 04C, 04D, 06A, 06B, 06C, 06D, 10A,10B, 10C, 10D, 11, 13.

4. Currently only mass generated cases are being worked.

5. **If Headquarters directs you to manually screen case work, the case types are to be worked in the following priority order:**



1. 04A, 06A, 10A

2. 04B, 06B, 10B

3. 04C, 06C, 10C

4. 04D, 06D, 10D

5. All other case types are to be worked at Headquarters direction only.


6. The purpose of the **SSA-CAWR** program is to:



   - Obtain Forms W-2 from the employer.

   - Forward Forms W-3/ W-2 to SSA to ensure employees receive proper credit for their earnings.

   - Assess employers applicable penalties for not following the established rules of filing Forms W-3/ W-2.


7. SSA-CAWR Cases (case types 03, 05, 07, 08, and 12) are SSA case types referred by SSA to IRS. The majority of the SSA-CAWR cases are non-tax cases (i.e., the Forms 94X have been filed and taxes paid) and are SSA case types.

8. SSA has performed their own up-front matching of the Forms 94X data to the Forms W-2 data. When there has been no response to SSA's letters attempting to secure the Forms W-2, the cases are forwarded to IRS to obtain the Forms W-3/ W-2 from the employer.



### Note:



Some of the cases referred to IRS have previously been identified as other IRS case types and updated to "SSA Indicator 2 or 1" .

9. Beginning with 2016 returns, the due date for filing Forms W-2 is January 31st of the year following the reporting year, or the following Monday if the date falls on a Saturday on Sunday. The due date is January 31st for both paper and electronically filed returns.



### Note:



For 2015 and prior returns, the due date for filing paper returns was the last day of February and the due date for filing electronic returns was the last day of March. If the due date fell on a Saturday or Sunday then the new due date was the following Monday.


**1.4.22.3** **(04-30-2024)**

### Technical Coordinator CATRS Responsibilities

1. The Small Business/Self Employed (SB/SE) campus' CAWR Site Coordinator is the liaison between SB/SE Headquarters CAWR staff and the campus CAWR staff. The Site Coordinator can be from the campus' Planning and Analysis staff or someone in the CAWR unit. The campus needs to provide Headquarter's staff with the name and phone number of who will be fulfilling these responsibilities.

2. There are a large number of responsibilities for the Site Coordinator, therefore as a Site Coordinator your Operation may designate employees (Managers or Leads) specific Coordinator profiles to manage and oversee some of the following responsibilities:



   - Program Settings

   - User Profiles

   - Disaster Areas

   - Manage User Accounts

   - CAWR Batching - Assign, Reassign, Unassign

   - CAWR Loose W-2

   - Schedules D

   - IRS- CAWR Mass Request 99-C CAWR Letters

   - SSA-CAWR Mass Request 98-C SSA Letters

   - Reports - Monitor Once the CAWR reports are moved to Business Objects Enterprise (BOE) coordinators and manager will access that system to view the reports.

   - Monitoring Workable Inventory


3. Coordinators will need a BEARS request to gain BOE access once the reports are moved to that application. These reports are useful for monitoring employee inventory.

4. An E-mail notification is issued by Headquarters to SB/SE Field Operations and SB/SE Service Campus Management Staffs prior to the beginning of program processing outlining the year’s startup instructions.

5. A list of program changes must be given to CATRS Coordinator for any of the following Items:



   - Signature and correspondence

   - List of all employee Identification Numbers, unit numbers and work phone numbers


**1.4.22.3.1** **(07-16-2025)**

#### Edit Option - Site Coordinator

1. The Site Coordinator has the ability to update information on the CATRS system under the **Edit** option.

2. Select one of the following options to view, update or edit:




| Edit - Function displaying a list of Edit Options |
| --- |
| Application Sites- To view and /or request update to information specific to your site |
| Users Profile - Add User, Update Users or Delete Users |
| Release Variables |
| Disaster Areas |
| Change Passwords |
| Manage User Account |
| CAWR Batching |
| CAWR Loose W-2s |
| CAWR Schedule D |
| xRef EIN |
| CAWR Mass Request - Auto Letters and Auto Assess |


**1.4.22.3.2** **(04-30-2024)**

#### Application Sites

1. The Application Sites option will allow a Site Coordinator to view and /or request update to information specific to your site. Information for all sites will also be available to view.

2. To access the Program Settings screens:



1. Log on to the "CATRS" System, IRM 4.19.8, CAP (CAWR Automated Program) Technical System Procedures, for instructions on logging into the CATRS system.

2. Click on **Edit** from the Menu Bar.

3. Select **Coordinator.**

4. Select and click on **Application Sites**.

5. This will bring up the "Application Information (CAWR)" screen.


**1.4.22.3.3** **(04-30-2024)**

#### Application Information Screen

1. The Site Coordinator for each site needs to ensure the information displayed in the Application Information Screen for their site is correct each year prior to program start up.

2. Verify the following values from the Application Information screen. Any updates/changes to the information below will be completed by the CATRS system programmers.




| **Information Screen Names** |
| --- |
| Program |
| Site Code |
| Site Abbreviation |
| Name |
| Street 1 |
| Street 2 |
| City (Replies) |
| State (Replies) |
| ZIP (Replies) |
| Sig Code |
| RA Code |
| Created By |
| Created (Date) |
| Modified By |
| Modified (Date) |


**1.4.22.3.4** **(04-30-2024)**

#### Release Variables (CAWR)

1. The Release Variables screen displays the current contact name and information for each site. This screen is site specific and updates can only be made by the Site Coordinator.

2. The "Releases" screen displays:



1. Release

2. Tax Year

3. Active Date

4. PCD

5. Created By

6. Last Modified Date


**1.4.22.3.5** **(04-30-2024)**

#### User Profiles - Coordinator/Site Coordinator

1. The Site Coordinator is able to add, delete, update, set users active or inactive on the CATRS system. Profiles are assigned to the user and can be updated as needed.

2. The User Profile screen can be used to determine:



   - A valid user of the system at your campus or if the user is in Active or Inactive Status. (Furloughed or Terminated).

   - The Unit Number assigned to the users.

   - The profile assigned to the user.

   - To Add a user.

   - Delete a user.

   - Modify a user.

   - Change Password.

   - Unlock account.


3. An online BEARS is required for the following:




| **Request** | **Reason** | **Initiate Action** | **Complete Action** |
| :-: | :-: | :-: | :-: |
| Add New User | New employee | Manager | Site Coordinator |
| Delete User | Left CAWR Program | Manager | Site Coordinator |
| Set User Inactive | Furlough Status | Manager | Site Coordinator |
| Return User to duty | Return to Duty | Manager | Site Coordinator |
| Reset User Password | Forgot Password | Manager | Site Coordinator |

4. To access the **User Profiles** screen:



1. From the Menu Bar click on **Edit**.

2. Select and click on **User Profiles**.


5. The "User Profile" screen displays:




| **User Screen Display Name** | **Definition** |
| --- | --- |
| User SEID | Displays users SEID |
| POD | Displays users POD |
| Last Name | Displays users last name |
| First Name | Displays users first name |
| Status | Displays user status |
| Full IDRS number | Displays the users IDRS number |
| TSID | Displays the TSID for the user |
| Created Date | Displays the date profile was created |
| Created By | Displays the user who created the profile |
| Last Modified Date | Displays the last modified date |
| User ID | Displays user IDs |
| New | Add new users |
| View | View the users profile |
| Edit | Edit the users profile |
| Delete | Delete users |
| Change Password | Change User passwords |
| Unlock Account | Unlock the users accounts |
| Close | Close the User Profile screen |
| Save | Save the new information or updates |


**1.4.22.3.6** **(04-30-2024)**

#### Add New User

1. The Site Coordinator adds new users to the CATRS system. This procedure **is site specific** and is used for new hires into the CAWR program. Once you have received the BEARS you can continue the process of adding the user to the CATRS System.

2. **Step 1** \- Access the User Profiles screen.



1. In the "User Profiles" screen click on the**New**button.

2. This will bring up the **New Record** screen.


3. In the "New Record" screen enter the following information:



1. SEID

2. Last Name - The Last Name of the user

3. First Name - The First Name of the user

4. Full IDRS number

5. TSID (only applies to Coordinator profiles)


4. **Step 2 - Once the new user has been established click save and a password will be generated for you to provide to the user.**

5. Once the BEARS has been approved and the Local Site Coordinator adds the user to the CATRS User Profile Table, the BEARS request is automatically forwarded to the network SA to add the user to the "CAWRFUTA\_USERS" DS Domain Group. Users will not have visibility to the screens until they have been added by the domain group. For further information contact HQ.


**1.4.22.3.7** **(04-30-2024)**

#### Delete User

1. The Site Coordinator is able to delete users from CATRS utilizing the User Profiles screen. This process **is site specific** and used when a user has left the IRS, retired or reassigned to a position outside of CAWR.

2. Manager must submit a BEARS requesting to **Delete the user from CATRS.** Once you have received the BEARS, you can continue the process of deleting the user.

3. Deleting a user from CATRS, access the "User Profiles" screen:



1. In the User Profiles screen locate the employee you want to delete. Type in the users first/last name or you can click on the **Lastname** field and the system will display all the users by their last name. Click on the user to be deleted and the name will be highlighted.

2. Click on the **Edit** button in the upper portion of the screen. This will open the selected users profile. The users roles need to be deleted before the entire profile can be deleted. Once all the roles are deleted click the save button.

3. In the User Profiles screen, click on the **Delete** button in the upper left section of the screen to complete the deletion of the user profile.

4. A Confirm box will appear and the system will ask you if you want to continue. When you click on the **Yes** box, the user will be deleted.

5. If you change your mind click on the **No** box.


**1.4.22.3.8** **(04-30-2024)**

#### Update User Information and/or Profiles

1. The Coordinator or Site Coordinator has the ability to update information on any established CATRS users.

2. The following fields can be updated:



   - Last Name

   - First Name

   - Full IDRS Number

   - TSID


3. To update user information, access the "User Profiles" screen:



1. In the User Profiles screen locate the employee you want to update using the **Search String**box. Type in the users first/last name or click on the **Last name** field and the system will display all the users by their last name. Click on the user to be updated and the name will be highlighted. To access the fields that can be updated select the **Edit** button in the upper left section.

2. Last Name - If the users last name has changed, or a change has been made to any of the last four alphas in CATRS Login Name then you **must** update the Last Name to reflect the change.

3. First Name - If the users first name has changed, or the CATRS Login Name first initial has changed then you **must** update the First Name to reflect the change.

4. Full IDRS number - If the employee changes units you can change the IDRS number here.

5. Profiles Granted - Only the Site Coordinator can change a profile. To request a profile change, the manager must provide in writing (E-mail) to the Site Coordinator the CATRS Login Name, First Name and Last Name of the user to be updated and also the profile change that is being requested.

6. TSID - The TSID is for Coordinators that perform auto assessments and mass letter only.

7. Apply - After all of the changes have been input, select the **Save** button to update the information.



      ### Note:



      Ensure the information is correct before you click the Save button. If you have updated the incorrect information, click on the **Undo** button to remove the change(s) before you click on the Save button.

8. Close - When you have finished updating the user information, click the **Close** button to exit the User Profiles screen.


**1.4.22.3.9** **(04-30-2024)**

#### Change Password

1. A user is required to create a new password when a temporary password has been granted. A user is also required to change their password every 90 days. The Site coordinator will grant a temporary password when:



   - Adding a new user to CATRS

   - User returning to duty

   - A user has forgotten their password


### Note:

Users should change their password anytime they feel it has been compromised.

2. The user will Log into the CATRS system using the temporary password and proceed to change their password.

3. **A standard password format** must be at least 12 characters with no spaces and consist of:



   - At least one Uppercase Letter

   - A least one Lowercase Letter

   - At least one numerical digit

   - One of the following special characters: ! $ () \* + , - / : ; < = >?\_

   - Cannot be the same as the username

   - Cannot be the same as old password



     ### Note:



     Passwords are case sensitive.


4. If the password does not meet the standard password format the system will display the following error messages:



   - Error - "Password same as user" , The new password can not be the same as the user name

   - Error - "Password length less than 12"

   - Error - "Password should contain at least one digit, one character and one punctuation"

   - Error - "Password should differ by at least 3 characters" , The new password must differ by at least 3 alphas characters from the previous password


5. If the user encounters any error messages, they must correct the password and try again.

6. To change a password, select **Edit** in the main Menu Bar, select the User Profiles, then select the appropriate user, then select **Edit**, and then **Change Password**.

7. The "Change Password" screen will display:



1. New Password.

2. Right click to copy the password to provide to the user.

3. Submit - Click on the **Submit** button.


**1.4.22.3.10** **(04-30-2024)**

#### Unlock Account

1. If the user has three failed attempts within the same day to log into CATRS, the system will automatic lock the users account preventing further attempts to log in.

2. The user will notify their manager of the problem. The manager will then notify the Site Coordinator and provide the User ID to Unlock User.

3. To Unlock User, select the **Edit** and **User Profiles**.



1. Choose the user that you need to unlock.

2. Select **Edit**.

3. Select the **Unlock Account** button.

4. Click **OK** button.


**1.4.22.4** **(03-29-2018)**

### Site Coordinator /Technical Coordinator

1. The Small Business/Self Employed (SB/SE) campus' CAWR Site Coordinator is the liaison between SB/SE Headquarters CAWR staff and the campus CAWR staff. The Site Coordinator can be from the campus' Planning and Analysis staff or someone in the CAWR unit. The campus needs to provide Headquarter's staff with the name and phone number of who will be fulfilling these responsibilities.


**1.4.22.4.1** **(03-29-2018)**

#### Program Responsibilities - Site Coordinator/Technical Coordinator/Manager

1. The Site Coordinator/Coordinator has a variety of responsibilities for the CAWR program which includes:



   - Mass Requests of SSA Letter 98-C

   - Mass Requests of IRS-CAWR Letter 99-C

   - Identifying Trends

   - Batching/Assigning Work

   - IDRS Letter Setup - CAWR Developer


**1.4.22.4.2** **(04-30-2024)**

#### CAWR Mass Letter Request

1. The Coordinator is the only user able to mass request Letter 98-C or Letter 99-C.

2. The Coordinator is responsible each week for requesting the number of letters needing to be issued for that cycle/week. The total volume of 98-C SSA Letters must be generated before Cycle/ Week 33 each year. Letter 99-C can be issued thru mid December.

3. All 98-C SSA Letters will have a Status Code 90 after the letters have been generated.



### Note:



Mass requested Auto Generated Letters for CAWR and SSA-CAWR will be assigned to the coordinators IDRS number. This is done because the auto assessment process requires the cases to be assigned to the IDRS number of the user performing the processes. It works best if the coordinator that issued the auto letters is the same user that runs the auto assessment process. If it is not possible for the same coordinator to do both processes, the cases will need to be reassigned to a different coordinators IDRS number. Before the auto assessments can be completed by the new coordinator they will need to wait for the CCA 42-43 to update with the new coordinators IDRS number before the CATRS system will be able to perform the auto assessment.

4. To access the CATRS screen to Mass Generate the Case Type 08, 98-C SSA Letters, select **Edit**, Coordinator, and then click on **Mass Requests** from the menu.



1. This will bring up the "**Mass Requests**" screen.

2. Select **Request new job** and in the **Requested Count** box input the number of 98-C SSA Letters to be generated.



      ### Note:



      It is recommended keeping all CAWR Mass Requests of Letter 98-C and Letter 99-C at or below a volume of 5000 per each request because of the time it takes for generation. Multiple requests can be made as long as the generation completed successfully for each request.

3. If the volume of 98-C SSA Letters requested is incorrect, select the **Cancel** button to clear the field.



      ### Note:



      Resetting the request **must** be done before you generate the request.

4. Click on the **Run** button after completing the Request Count. This will bring up the Confirm screen which will verify the letter type and volume you are requesting. Click on the **Yes** button to generate the request after verifying the information.

5. After clicking Yes, the Information screen will appear. Click on **OK** to complete the process.

6. Select the **Close** button if you do not want to generate the notices.


**1.4.22.4.3** **(07-16-2025)**

#### Identifying Trends

1. Whenever a "trend" seems to be emerging for a specific type of taxpayer and/or their Payer Agent, Power of Attorney (POA) or Reporting Agent Authorization (RAA), tax examiners will compile documentation to show the "trend" and give the information to the Site Coordinator.

2. The Site Coordinator will inform the Headquarters CAWR analyst of the trend and forward the documentation.



### Note:



Trends can also be identified through quality review data, error trends or errors based on information within the CAWR IRMs.


**1.4.22.4.4** **(04-30-2024)**

#### CAWR Batching

1. Only Coordinators have access to the Batching screen. This screen is used to assign, unassign or reassign batches to tax examiners.

2. A typical batch will have 25 cases. The maximum number of batches a tax examiner can be assigned is 50. The Coordinator has no limit to the number of batches that can be assigned to them. This requirement is due to the Mass Generation of Case Type 08 Cases.



### Note:



The coordinator responsible for the Mass Generation of the Case Type 08 Notices will have an extremely large Overage List.

3. To access the CAWR Batching option:



   - Select **Edit** from the main menu bar

   - Highlight **Coordinator**

   - Click on **Batch Assignment**


4. Once the "CAWR Batching" option is selected a Warning will display: "The batch assignment process can have a severe effect on user response times. You may want to use this application only when there are only a few or no other users on the CATRS System." Click the **OK** button on the Warning screen to access the CAWR Assign Batch screen.

5. The CAWR Assign Screen displays the following options:



01. ASSIGNMENT - Assigns a batch and each case within to a tax examiner.

02. REASSIGNMENT - Reassigns a batch and each case assigned within from one tax examiner to another tax examiner. This process may be used if a tax examiner is in furlough status, or on extended leave.

03. UNASSIGNMENT - Unassigns a batch and each case assigned within back to the batch inventory.

04. Unassigned Batches -The screen displays the number of batches available for each batch type.

05. Unassigned Batches - The screen displays batches that are not assigned to a user.

06. Assigned Inventory - The screen displays Tax Examiners ID and number of batches assigned.

07. Current Unassigned - Displays the number of batches not assigned to tax examiners.

08. Amount To Assign - Site Coordinator designates the number of batches to assign to a tax examiner.

09. Remaining Unassigned - When batches have been assigned to tax examiners this field displays the remaining unassigned batches.

10. Assign Batches - Assigns the requested batch(es) to a tax examiner.

11. Close - Closes the screen.


**1.4.22.4.4.1** **(03-29-2018)**

##### Assign Batch(es)

1. From the "CAWR Assignment" batches will be assigned and each case within that batch to a tax examiner.



1. On this screen you will see the batch inventory. It shows the **Release Year**, **Batch Type**, the**number of Batch(es)** and **Volume** available.

2. Highlight the **Batch Type** to assign from the "Unassigned Batch(es)" column.

3. Highlight the Tax Examiner to assign batches to from the "Assigned Inventory" column.

4. Click in the "Amount to Assign" box and enter the number of batches to assign.

5. Click the **Yes** button at the bottom of the screen.

6. **Close** the screen.


**1.4.22.4.4.2** **(03-29-2018)**

##### Reassign Batch(es)

1. Reassigning work from one tax examiner and each case within that batch to another tax examiner is the responsibility of the Site Coordinator/Coordinator.



1. Click on the **REASSIGNMENT** tab.

2. Highlight the tax examiner the batch is currently assigned to from the "From Assigned" column.

3. Highlight the Batch Number in the "Select Batches" column that is currently assigned to the selected tax examiner.

4. Highlight the tax examiner in the "To Assigned" column who will receive the reassigned batch.

5. Click on the **Reassigned Batch** button to accept.

6. Click the **Cancel** button to delete the action before reassigning the batch.

7. Close the screen.


**1.4.22.4.4.3** **(03-29-2018)**

##### Unassign Batch(es)

1. This process Unassigns a batch and each case assigned within that batch from the selected tax examiner back to the batch inventory.



### Note:



Batches can only be unassigned, if correspondence has not been issued on any case within the batch.





1. Click the **UNASSIGNMENT** tab.

2. Highlight the tax examiner in the "From Assigned" column the batch is currently assigned to.

3. Highlight the batch number in the "Select Batches" column that is currently assigned to the selected tax examiner.

4. Click **Unassign Batch** button to accept. The system will unassign the batch and move it back to batch inventory.

5. Click the **Cancel** button to leave the Unassign screen before unassigning the batch.


**1.4.22.4.5** **(04-30-2024)**

#### IRS CAWR No Reply Auto Assess

1. When a taxpayer does not respond to the Letter 99-C originally generated it is referred to as a No Reply. Once the 81 day suspense period has expired, additional tax due is assessed on the last available quarter of the tax year being worked.

2. The majority of the IRS-CAWR No reply cases will now be auto assessed on the CATRS system by the technical coordinator. However, cases containing any of the following TC codes will need to be manually reviewed and assessed by a tax examiner: 160, 161, 180, 181, 340, 370, 400, 420, 424, 480, 520, 530, 766, 780, 788, 910, 912, 914, 916, or 918.

3. The coordinator must run the no reply assessment auto process each week once the SC 37 start appearing on the CATRS case status report. To run the tool the coordinator will:



1. Log into IDRS.

2. Verify you are in the IRS CAWR program on the Consolidated Annual Tax Reporting System (CATRS).

3. Go into EDIT on the CATRS screen and choose, Coordinator, Mass Requests.

4. Choose the Auto Assess option.

5. Choose Request New Job.

6. Choose All and click Run.



      ### Note:



      Mass requested Auto Generated Letters for CAWR and SSA-CAWR will be assigned on IDRS CCA to the coordinator number. This is done because the auto assessment process requires the cases of the coordinator running the auto assessment process to be assigned to them on IDRS CCA to perform the action. It works best if the coordinator that issued the auto letters is the same user that runs the auto assessment process. If that’s not possible the cases will need to be reassigned to the new coordinator and they will have to wait until the CCA 42-43 updates (usually 3 days) with the new IDRS number before that coordinator can perform the auto assessment.


4. The Coordinator must check the log at the end of the process to determine the number of batches created, how many cases were auto assessed and the number of errors. This information is reported to the Operation.

5. Once the process is complete CATRS will automatically close the cases that were assessed using SC 30. The cases that could not be assessed will automatically unassign and be batched. The coordinator will assign these to the tax examiners either by batch or by providing the CAWR No Reply money screen listing to them.

6. The coordinator must also review the IDRS CCA 42-43 listing and close any controls that remain open on the fourth quarter due to the assessment auto posting on a different quarter.


**1.4.22.4.6** **(04-30-2024)**

#### SSA CAWR No Reply Auto Assess

1. When a taxpayer does not respond to the Letter 98-C originally generated it is referred to as a No Reply. Once the 81 day suspense period has expired the CAWR program will automatically run through the nightly no reply process. Cases not requiring tax assessments will auto close using SC 91 and the civil penalty will post to master file. Cases with additional tax due will handled as outlined below.

2. Cases that meet the SSA CAWR Auto assess criteria will que for the coordinator to run the process. To run the tool the coordinator will:



1. Log into IDRS.

2. Verify you are in the SSA CAWR program on CATRS.

3. Go into EDIT on the CATRS screen and choose, Coordinator, Mass Requests.

4. Choose the Auto Assess option.

5. Choose Request New Job.

6. Choose All and click Run.



      ### Note:



      Mass requested Auto Generated Letters for CAWR and SSA-CAWR will be assigned on IDRS CCA to the coordinator number. This is done because the auto assessment process requires the cases of the coordinator running the auto assessment process to be assigned to them on IDRS CCA to perform the action. It works best if the coordinator that issued the auto letters is the same user that runs the auto assessment process. If that’s not possible the cases will need to be reassigned to the new coordinator and they will have to wait until the CCA 42-43 updates (usually 3 days) with the new IDRS number before that coordinator can perform the auto assessment.


3. Cases that don't meet the criteria for auto asses due to the presence of one or more of these transaction codes, 160, 161, 180, 181, 340, 370, 400, 420, 424, 480, 520, 530, 766, 780, 788, 910, 912, 914, 916, or 918, will need to be batched for manual review by a tax examiner. The coordinator can either assign these out by batch or by providing the CAWR No Reply money screen listing to them.

4. The Coordinator must check the log at the end of the process to determine the number of batches created, how many cases were auto assessed and the number of errors. This information is reported to the Operation.

5. The coordinator must also review the IDRS CCA 42-43 listing and close any controls that remain open on the fourth quarter due to the assessment auto posting on a different quarter.


**1.4.22.5** **(03-29-2018)**

### Work Planning and Control

1. The following describes the steps needed to successfully manage the CAWR program.


**1.4.22.5.1** **(07-16-2025)**

#### Program Completion Dates (PCD)- Manager/Site Coordinator

1. The Program Completion Dates (PCD) and Mail-out Dates are outlined below




| **PROGRAM** | **PROGRAM START-UP** | **PROGRAM COMPLETION DATE (PCD)** |
| :-: | :-: | :-: |
| IRS-CAWR | Within one week of the HUB release date. Generally the first of April | The last day of the following March (100 percent). |
| SSA-CAWR | As the cases are downloaded to CATRS and/or within one week of the HUB release date. Generally the first day of April. | The last day of November (95 percent) and two weeks later (100 percent). |
| W-2C | As received | N/A, but prior to Statute expiration. |

2. TY 2023 IRS-CAWR program processing benchmark dates are listed on the chart below:




| **BENCHMARK Dates** | **DESCRIPTION** | **ACTION** |
| :-: | :-: | :-: |
| March 31, 2025 | Hub begins for TY 2023 IRS-CAWR program. | Hub site only. |
| April 7, 2025 | The Hub is completed and the TY 2023 IRS-CAWR cases released for the campuses to work. | Campuses will begin working the TY 2023 IRS-CAWR cases. |
| September 30, 2025 | FY Closure Goal | This goal is determined by HQ and supplied to each Operation via Work Plan and the Operating Guidelines. |
| December 15, 2025 | Terminate preparation of CATRS automated Form 6209 for CAWR Reconsideration (Recon) Program for each tax year prior to the current year | Tax year 2021 cases fall off of CATRS in January 2026, therefore automated Forms 6209 are not necessary. |
| December 15, 2024 | All TY 2023 IRS-CAWR cases that are to be worked must have correspondence input to CATRS. | All correspondence to taxpayers for TY 2023 IRS-CAWR must be input and mailed. |
| January 05, 2026 | Begin performing Statute Searches | Statute search all inventory including new receipts. _IRM 1.4.22.10.1.1_, Statute Searches. and IRM 4.19.4.3.12, Statute Issues/Imminent Assessments. |
| January 2026 | New CATRS programs will be downloaded. | Replies and Undeliverables must be entered into the CATRS system as received.<br> <br>### Note:<br>IDRS dead cycles occur the last week of December thru the first two weeks of January. During dead cycles CC MFREQD must be used to control and complete adjustments when the case is not online. |
| February 27, 2026 | Statute Awareness | Research all cases for statute implications. Refer to IRM 25.6, Statute of Limitations for further instructions. |
| March 27, 2026 | 100 percent of TY 2023 IRS-CAWR cases must be completed and closed on the CATRS system and IDRS. | All control bases must be closed on IDRS.<br> <br>### Note:<br>Any cases is active disaster will remain open in SC 10 until the disaster expires, but will be considered closed toward PCD. |

3. TY 2022 SSA-CAWR programs processing benchmark dates are listed on the chart below:




| **BENCHMARK Dates** | **DESCRIPTION** | **ACTION** |
| :-: | :-: | :-: |
| March 31, 2025 | Hub begins for TY 2022 SSA-CAWR program. | Hub site only. |
| April 7, 2025 | The Hub is completed and the TY 2022 SSA-CAWR cases released for the campuses to work. Begin screening, TY 2021 data base remains on the CATRS system. | Campuses will begin working the TY 2022 SSA-CAWR cases. Weekly mass generation of Letter 98-C begins |
| August 9, 2025 | All TY 2022 SSA-CAWR cases (including Case Type 08) must have correspondence input to CATRS for issuance by August 9, 2025(cycle 33). | No TY 2022 SSA-CAWR cases should remain in status code 88 (including Case Type 08) and must have had correspondence input or been closed in screening.<br> <br>### Reminder:<br>Case Type 08 must be entered through the Coordinators screen to be issued, except those with Compliance Indicators present. All SSA cases needing Online Retrieval System (ORS) research must be worked to ensure correspondence is issued by this date. |
| September 30, 2025 | FY Closure Goal | This goal is determined by HQ and supplied to each Operation via Work Plan and the Operating Guidelines. |
| November 28, 2025 | 95 percent of TY 2022 SSA-CAWR cases must be worked and closed on CATRS. No exceptions. | SSA Codes must be entered on CATRS for any Undeliverable or Reply SSA-CAWR cases and No Reply SSA-CAWR cases. **No Reply cases must have all tax adjustments input. All control bases must be closed on IDRS.** |
| December 21 2025 | Begin performing Statute Searches | Statute search all inventory including new receipts. See Statute Issues/ Imminent Assessments and _IRM 1.4.22.10.1.1_, Statute Searches. |
| December 13, 2025 | Remaining 5 percent of TY 2022 SSA-CAWR cases must be worked and closed on CATRS and IDRS. No exceptions. | 100 percent of SSA-CAWR cases must be closed. All control bases must be closed on IDRS. **All SSA CAWR No Reply listings must be worked and adjustments input on IDRS.** |
| January 2026 | IRS wide Production of new CATRS programs. Continue working the remaining TY 2021 SSA-CAWR Recons cases. All campuses must be off the CATRS system if directed by HQ, the weekend after the IDRS dead cycle while the old program year is purged. | Replies and Undeliverables must be entered into the CATRS system as received.<br> <br>### Note:<br>IDRS dead cycles occur the last week of December thru the first two weeks of January. During dead cycles CC MFREQD must be used to control and complete adjustments when the case is not online. |

4. Manager/Site Coordinator should closely monitor the inventory to ensure all of the PCD and benchmarks are met.


**1.4.22.5.2** **(07-16-2025)**

#### Organization, Function and Program Codes (OFP) - Site Coordinator

1. Organization, Function and Program (OFP) codes are recorded on Form 3081, "Employee Time Report" to identify work the employee performs daily.

2. It is the responsibility of the Coordinator to provide PPA with the current OFP codes that will be used at the beginning of the new download. Take the following steps **four** weeks prior to the new download to ensure the OFP codes are activated and used for reporting purposes. See IRM 3.30.50.3, OFP Consistency File and Reports, for additional information.



1. Prepare a list of all of the OFP codes identifying the new tax year being worked (Refer to the SB/SE Campus Reporting Compliance Operating Guidelines for the tax year being worked) by replacing the "X" with the tax year.

2. E-mail the list to PPA to update the OFP Consistency File. Ensure all prior year codes no longer needed are deleted. Request that PPA alerts you when the OFP codes have been established.

3. Once the OFP codes have been established, E-mail the new OFP codes to the managers to be used with the new download processes and move prior year inventory to the new valid codes.

4. Verify all changes were made to the OFP Consistency File (including deletions of prior year codes) by referring to the Operation WP&C. Take necessary actions if needed.


3. All OFP codes for CAWR tax examiners and Clerks are listed in the tables below:



1. For current (open) tax year being worked, the "X" in each program code represents the tax year being worked. For example, SSA CAWR replies being worked for Tax Year 2022 should be reported under 18720.

2. For Reconsiderations (Recons) where the reply was received after the case was closed, the "X" in each program code represents the tax year being worked. Tax years prior to the most recent two years should all be reported under the oldest tax year. For example, SSA CAWR Reconsiderations for Tax Year 2022 should be reported under 18920, Tax Year 2021 under 18910, and Tax Year 2020 and prior under 18920.


**These are the OFP codes and programs used for tax examiners in CAWR:**

| Telephone Function | Tax Examiner Function | Program | CAWR Program Title | Definition |
| :-: | :-: | :-: | :-: | :-: |
| N/A | 710 | 180X0 | IRS | Screening |
| 700 | 710 | 182X0 | IRS | Replies |
| N/A | 710 | 183X0 | IRS | No Replies and Undeliverables |
| 700 | 710 | 184X0 | IRS | Recons and Prior Years |
| N/A | 710 | 185X0 | SSA | Screening |
| 700 | 710 | 187X0 | SSA | Replies |
| N/A | 710 | 188X0 | SSA | No Replies and Undeliverables |
| 700 | 710 | 189X0 | SSA | Recons and Prior Years |

**These are the OFP codes used for clerks in CAWR:**

| **OFP for Clerical** | **Definition** |
| :-: | :-: |
| 790 - 180X0 | IRS-CAWR Screening |
| 790 - 182X0 | IRS-CAWR Replies (Includes Undeliverables) |
| 790 - 184X0 | IRS-CAWR Recons and Prior Year |
| 790 - 185X0 | SSA-CAWR Screening |
| 790 - 187X0 | SSA-CAWR Replies (Includes Undeliverables) |
| 790 - 189X0 | SSA-CAWR Recons and Prior Year |

**1.4.22.5.3** **(03-28-2019)**

#### CAWR Reviews - Overview

1. All CAWR managers are required to conduct the following reviews as applicable:



   - Workload reviews

   - Inventory management

   - Clerical reviews

   - On-the-job reviews

   - Evaluative reviews


2. Reviews are performed by the manager or lead and are performed on tax examiners assigned to their team.

3. Reviews should focus on effective case resolution according to IRM guidelines.

4. Conduct a balance of these reviews throughout the year including a variety of work types.

5. If for some reason reviews cannot be conducted on an employee (for example, extended illness, furlough, managerial absence, and so forth), a review **waiver** or other documentation is placed in the Employee Performance File (EPF) explaining why the required numbers of reviews were not conducted.



### Note:



These waivers must be approved at the department level.


**1.4.22.5.3.1** **(03-28-2019)**

##### Workload Review

1. Managers are required to perform a minimum of two workload reviews per quarter for each employee.

2. For Tax Examiners (GS-0592), the workload reviews will consist of one bin review and one time utilization review per quarter per employee.

3. Managers should also review SSA-CAWR cases for proper and consistent application of reasonable cause criteria for abatements. All tax examiners should be ensuring that SSA-CAWR civil penalties are only abated if the taxpayer responds within the required time frames with the applicable Forms W-2 or if they provide proof of timely filing or a valid reasonable cause for the abatement.

4. The number of reviews should be increased when warranted; "for example, when quality results are below the target set for the year" . These reviews should include open and closed case reviews.

5. These reviews, as in all case reviews, should be documented.


**1.4.22.5.3.2** **(04-06-2020)**

##### Inventory Management Review

1. Inventory reviews are applicable to CAWR Lead Tax Examiners, Tax Examiners and Clerks. the purpose of these reviews is for the manager to determine whether the employee is:



1. Handling their work timely and according to established priorities.

2. Managing their inventory appropriately.

3. Following Policy Statement P-21-3 (previously known as Action 61 guidelines) for correspondence handled or interim letter sent within 30 days.

4. Controlling their work as required.

5. Documenting case histories.


2. Managers are responsible for routine and periodic review of each employee’s assigned inventories. This is accomplished through reviewing various types of reports and comparing the information to the employee’s physical and virtual inventory. For successfully achieving program goals and to improve employee satisfaction/engagement, it is critical each employee’s inventories are monitored and that effective performance feedback is provided on individual case progression, as well as overall inventory management practices.

3. When completing the inventory reviews, ensure:



   - Work is being properly controlled and timely processed in accordance with established guidelines and priorities

   - Aged inventory is maintained at the lowest possible level

   - Barriers to proper case movement are identified and eliminated

   - Technical feedback of the employee’s performance is provided

   - See _IRM 1.4.22.5.5_, Physical Inventory Review - Managers, for further instructions on how physical inventories reviews should be conducted


**1.4.22.5.3.3** **(03-28-2019)**

##### Clerical Reviews

1. Clerical employees perform various administrative duties which support the CAWR program. Clerical reviews must address the clerical work processes. The reviews include the following:



   - Timekeeping

   - Mail Receipt and distribution

   - Batch building

   - CATRS input

   - Maintenance of files


2. Clerical reviews should focus not only on the employee’s ability to complete their assignments, but also on their ability to set priorities and complete assignments independently and expeditiously. You must conduct Weekly/Monthly reviews to determine the accuracy and timeliness of employees' work.


**1.4.22.5.3.4** **(03-28-2019)**

##### On-The-Job Reviews

1. Managers will conduct a yearly On the Job review to evaluate employees. This review will evaluate employee performance as it relates to:



   - Time Utilization

   - Efficiency

   - Utilization of the IRM

   - Utilization of mandated Integrated Automated Technology (IAT) tool


2. The review will include a time or period when the employee is assigned to work inventory. This review can be performed by directly observing the employee (side-by-side ) during a defined period. Typically, this would be a block of time ranging from one to four hours or two complete cases.



### Note:



Perform a minimum of one On-the-Job review per employee each year.


**1.4.22.5.3.5** **(03-28-2019)**

##### Evaluative Reviews

1. Evaluative reviews must be recorded in accordance with the National Agreement established between National Treasury Employees Union (NTEU) and management.

2. Conduct a **_minimum of two evaluative reviews_** for each employee per month.

3. Evaluative reviews must be shared with the employee by a manager or individual in an official acting manager capacity.

4. When conducting reviews, ensure recordation is input into the Embedded Quality Review System (EQRS).

5. Use the Employee Feedback Report on EQRS for sharing evaluative monitoring results. Share results of the review within three workdays. (If incorrect information is given, the results must be shared within eight (8) business hours.) Notate the reason on the review sheet if you do not meet these time frames, (i.e., due to unexpected leave, etc.).



### Note:



Provide the applicable IRM reference when a defect is identified.

6. Obtain the employee's acknowledgment on the designated form. Provide one copy to the employee and retain the other copy for the EPF.



### Note:



If the employee refuses to sign the review, document that on the review and retain the copy in the EPF.


**1.4.22.5.4** **(07-16-2025)**

#### Program Reviews - Managers

1. If requested Headquarters may conduct a program review. The reviews will target recommendations made by the campus, including but not limited to adherence to the IRM and Policy directives, movement of inventory, manager and employee reviews, trends, and any areas of concern.

2. Program Reports: The following reports are generated to assist with monitoring the performance of the CAWR program:



   - Consolidated Annual Tax Reporting System (CATRS) Reports

   - Overage Report Compiler and Sorter (ORCAS) Manager Reports also known as CCA 42-43 reports

   - Embedded Quality Review System (EQRS) Reports

   - National Quality Review System (NQRS) Reports


3. During the review HQ will:



   - Establish a required action(s) item due date based on the recommendation(s) and notate on the final report

   - Request a signature acknowledging receipt of the final report or retain a read receipt upon issuance of the final report. Retain this information with the copy of this report and all applicable supporting documentation

   - Retain program review templates along with any documentation or tracking tools utilized during the Combined Annual Wage Reporting (CAWR) Program Review with a copy of the final review


**1.4.22.5.5** **(07-16-2025)**

#### Physical Inventory Review - Managers

1. Management must sort the weekly CCA 42-43 report by tax examiner IDRS number. Provide a copy of each listing to the appropriate tax examiner by either printing or sending an electronic copy to them to review weekly. _IRM 1.4.22.11.3_, CCA 42-43 - IDRS Overage Report. Each tax examiner is responsible to ensure the control assigned to them on IDRS is physically in their possession and can be retrieved at any time. Refer to IRM 4.19.4, CAWR Reconciliation Balancing, for the review process for tax examiners.

2. In addition, each manager will sign and complete a Quarterly "Physical Inventory Certification" sheet after receiving their employee's inventory forms and submit to the Department Manager for consolidation. _Exhibit 1.4.22-5_, Physical Inventory Certificate. The clerical team manager must complete a "physical Wall Inventory" , by running the CCA 42-43 for CAWR see below:



1. Sort the program listing by age beginning with the earliest received date

2. Verify each of the cases on the wall to the cases listed on the CCA 42-43

3. Verify the count in each open batch listed in the log book with the CCA 42-43

4. Provide results to the Department Manager



      ### Note:



      Note: the ORCAS-Manager is utilized to review the CCA report on a weekly basis.


3. The Department Manager will consolidate all tax examiner and the "Wall" physical inventory results, complete the Manager Wall Inventory Sheet. _Exhibit 1.4.22-6_ and submit to the Operation for signature.

4. The Operation will notify their director’s office this was completed 10 business days following the end of each quarter and provide the office documentation for review.

5. All results of the physical inventory review **must** be shared with the CAWR Coordinator to ensure all necessary actions are taken to update the WP&C.


**1.4.22.6** **(03-29-2018)**

### Servicewide Electronic Research Program (SERP)

1. Any changes made during the processing year will be posted on SERP.

2. Both Quality Review and CATRS unit personnel must be aware of all the alerts that are applicable to the current CAWR Release Year.

3. Campuses should check the SERP web site daily for a list of the most current and previous alerts.

4. If a campus is missing a specific alert(s) and needs a copy of it/them, refer to the SERP web site: SERP Home page.


**1.4.22.7** **(04-30-2024)**

### CAWR IATS

1. IATs were developed to assist to increase productivity and accuracy rates. It is imperative that these tools be used daily by all employees. Please ensure all tools are working properly.

2. CAWR Clerical process has access to an IAT, Document Matching (DM) Batcher Tool. The use of this tool is mandatory. This tool streamlines the clerical process by batching case work, inputting STAUPS, and issuing interim letters as needed.

3. A Job aid is available for the CAWR/ FUTA batcher tool by accessing web site: IAT Job Aids



   - Scroll to SB/SE DM Batcher

   - Click on Job AID

   - Open and Print


**1.4.22.8** **(07-16-2025)**

### Online Retrieval System (ORS) - Overview

1. The Social Security Administration (SSA) sends out more than 240 million letters yearly to the public. The Online Retrieval System (ORS) is the system with the print image of these SSA-related documents (W-2, W-2C, W-3). The system archives, retrieves, and reprints these documents, and is independent of the application that created them. ORS can also re-send retrieved documents.

2. The goal of ORS is to provide users with an electronic system to retrieve essential information online in a timely manner and provides the following capabilities:



   - Information can be viewed on the screen and looks like the original document sent to the recipient, including fonts, bolding, signatures, etc.

   - The entire document page will appear on the screen without having to toggle back and forth.

   - A document can be printed locally and mailed to the claimant, their representative, or to a different address.


3. ORS provides CAWR tax examiners with the ability to view W-2, W-2C, W-3, W-3C information received by SSA from the taxpayers.

4. SSA stores digital images of paper Annual Wage Reports (AWR) in ORS.

5. Additional information on the ORS process can be found on the **SB/SE Doc Matching web site**CAWR-SSA. You will find:



   - User Guide

   - Add or Delete a User

   - URL to Access ORS

   - Changing a Password

   - Resetting a Password


**1.4.22.9** **(07-16-2025)**

### CAWR Automated Program (CATRS)

1. Cases that are determined to have discrepancies or that are referred by SSA, are loaded onto the CATRS Tier II SUN domain at Enterprise Computing Center-Memphis (ECC-MEM). resides on the CATRS platform.

2. For more information on the CATRS system, see IRM 4.19.8, CAP (CAWR Automated Program) Technical System Procedures.

3. CATRS is a computer application that houses the CAWR inventory, correspondence, reports, document preparation, and updates to Master File.

4. All Master File actions affecting the taxpayer's account for the year(s) being worked will result in an update to the CATRS system. This includes Entity changes, IDRS adjustments, additional Form W-3 (Transmittal of Wage and Tax Statement) and Form W-2 (Wage and Tax Statement) processed by SSA.


**1.4.22.9.1** **(03-29-2018)**

#### Contents References Introduction Objective Nightly Run Setup (CRON)

1. CRON is a process where the system automatically generates all output files during off work hours. This is referred to as the "Nightly Run Setup" . CRON Run Dates will be established by Headquarters Staff for all Campuses. CRON automatically executes programs during the dates and the time specified for each job. CRON generates reports the Coordinator can access by selecting **View** on the Menu Bar. _IRM 1.4.22.11_, CAWR Reports - Site Coordinator/ Coordinator/ Manager for more information regarding reports.



### Note:



Any changes to the CRON Processing will be a Headquarters Directive.

2. Cases will be assigned automatically to IDRS, where correspondence has been issued or the cases have been assigned on the CATRS system.


**1.4.22.9.2** **(04-30-2024)**

#### System Problem Reporting

1. When a System problem is identified during CAWR processing, the campus who identified the problem will issue an IT IRWorks ticket.

2. Before issuing a ticket, contact a Headquarters Analyst for approval.

3. To Issue a "Get It ticket" , the user will do the following:



1. Access IRS Source Home page - click on **IRS Service Central (IRWorks)**

2. Select **New Tickets**

3. Click on **Request Help**

4. Choose **All IRS APPS**

5. Click on **Submit** to create ticket

6. Complete the form, providing an explanation of the problem. Add the statement **Forward this ticket to AD-COMP-RC-CD-CAWR/FUTA** for CATRS issues and **BU-WI-WIOS-MTT-IAT** for IAT issues. Attach any documentation or if you are faxing it notate in the remarks field you will be faxing supporting documentation

7. Click on **Submit**

8. A Get It ticket number will be issued


4. Whenever a "systemic" problem is identified, the tax examiner/Clerk will compile documentation (description of the problem and samples) and give the information to the Site Coordinator who will inform the Headquarters CAWR analyst of the problem and forward the documentation.


**1.4.22.9.3** **(04-22-2022)**

#### System Authorization and Security

1. Access to the CATRS System is restricted to **authorized users**. The CAWR Site Coordinator, appropriate management official and security personnel must authorize individual user access.

2. Access to the CATRS system requires a login and password for both Windows and the CATRS system. An automated **Online BEARS Application**is required to gain access to the CATRS system if they are a New User, to Set User Active, to Set User Inactive, to Delete User or to Reset User Password.

3. The Site Coordinator must have **ONLINE BEARS SYSTEM ADMINISTRATOR**access to receive and process the BEARS application. See below for action to be taken:



1. To give access to a new user, prepare a BEARS to be added to the CAWR database. TCC-CAWR-PIRSC (PSC Campus employees), TCC-CAWR-MIRSC (MSC Campus employees) or TCC-CAWR-CIRSC (CSC Campus employees.

2. You will receive requests for via BEARS whenever an employee needs to be Deleted, Added, or have their password reset.



      ### Exception:



      If an employee needs to be unlocked, a BEARS is not needed.


4. A security profile is established and maintained for each user.

5. User profiles are established to allow users access to the specific area/ functions of the CATRS system needed to perform assigned duties. Users must inform their manager/coordinator if they are prohibited from accessing an area of the CATRS system needed to complete an assigned task. _Exhibit 1.4.22-4_ for user profile descriptions.

6. The CATRS system produces an audit trail of information on any updates/ changes to the system. Each user must ensure only authorized accesses are performed. Do not attempt unauthorized system queries.

7. To ensure the security and integrity of the CATRS system the user must:



01. Protect their password and not reveal it to anyone.

02. Never allow anyone access to the system using your login and password.

03. Alert the manager immediately if there is reason to believe the password has been compromised.

04. Lock workstation when it is not in use.

05. Log off the system at the end of your shift.

06. Never leave sensitive information on the screen when leaving your workstation.

07. Never eat or drink near computer hardware.

08. Use computers and software for official purposes only.

09. Never copy licensed or copyrighted software for private use. It is a violation of federal law with civil and criminal penalties.

10. Promptly retrieve hard copy prints from the printer. Prints remaining near or on the printer for an extended period of time should be given to managers for disposition.


8. To Ensure the security and integrity of the CATRS system the coordinator must, on a quarterly basis:



1. Compare the BEARS access listing to the CATRS database to ensure they match.

2. Verify that the users have the correct level of permissions.

3. Make any applicable changes and send a confirmation email to the HQ policy analyst on the first Monday after the end of each quarter.


9. Once the BEARS has been approved and the Local Site Coordinator adds the user to the CATRS User Profile Table, the BEARS request is automatically forwarded to the network SA to add the user to the "CAWRFUTA\_USERS" DS Domain Group. Users will not have visibility to the screens until they have been added by the domain group. For further information contact HQ.


**1.4.22.10** **(04-21-2021)**

### Miscellaneous Coordinator/Manager Responsibilities

1. Below you will find additional Coordinator/Manager duties which need to be assigned to a specific person to ensure the program runs smoothly and timely.


**1.4.22.10.1** **(07-16-2025)**

#### Statute of Limitations - Manager/ Statute Coordinator

1. Statute Awareness - Communicating the importance of statutes to all employees is very important and the responsibility of every manager/statute coordinator. On an annual basis, management is expected to issue Statute reminders to the employees. These reminders will be procedures which include contact information, phone numbers, coordinator name, tour of duty (TOD), instructions to follow for last minute statutes discovered, and the local routing procedures to the statute unit or RACS (depending on time frame). Contact names and numbers can be located on the SB/SE Document Matching web page. It is the responsibility of the campus to alert the web master if a change in contact information is necessary.

2. Document 7368, Basic Guide for Processing Statute Cases, is available to all campuses and area offices. Management must maintain a sufficient supply of this document from the National Distribution Center using catalog number 10296-C. Document 7368 contains valuable information on statute-specific topics; therefore, a copy will be given to each employee. No Statute imminent case will be transshipped within 90 days of the statute expiration date, the case must be worked by the campus with current ownership.

3. Campuses will work together to ensure Statutes receive priority.



### Note:



The use of the Statute portal is mandatory. Information regarding the statute portal is available on the SB/SE Document Matching web page listed here: Statute Portal.


**1.4.22.10.1.1** **(07-16-2025)**

##### Statute Searches

1. Statute Searches must be performed beginning 90 days prior to statute expiration date. All inventories (paper and electronic) must be reviewed for statute imminent criteria and documented.



   - SSA-CAWR begin searching: December 01, 2025

   - IRS-CAWR begin searching: January 05, 2026


2. In addition, all new receipts must be reviewed as received, prior to controlling to a tax examiner beginning with the dates above and continuing through to the statute expiration date. If the case is statute imminent, it needs to be labeled as such and expedited for processing. The SSA CAWR No Replies must be worked weekly to ensure that any tax assessments are input. In addition, the CCA 42-43 listing should be run through the IAT MASS Screener each week to ensure any cases with potential tax assessments are addressed.

3. Use the following Forms and Procedures for Statute searches:



1. Form 11122, Employees Statute Certification: Campuses must have all employees complete Form 11122 taking responsibility and documenting the biweekly statute searches beginning 90 days prior to the statute expiration date. These searches are to be increased to weekly searches 30 days prior to the statute expiration date. During the final week prior to the statute expiration date, increase the searches to daily. Each search performed must be documented.

2. Form 11122-A, Managers Statute Certification: Campuses must have two levels of management complete Form 11122-A, taking responsibility and documenting the biweekly statute searches beginning 90 days prior to the statute expiration date. These searches are to be increased to weekly searches 30 days prior to the statute expiration date. During the final week prior to the statute expiration date, increase the searches to daily. Each search performed must be documented.

3. The Operation is to confirm to CEA the statute searches have been completed within 10 business days following the end of each quarter.

4. The Operation Manager is to ensure Form 11122 and Form 11122-A are completed and maintained in the employee's/ manager's Unofficial Personnel Folder drop file for three years. After three years, dispose of forms using classified waste procedures.



      ### Note:



      The use of the Statute portal is mandatory. Information regarding the statute portal is available here: Statute Portal.


**1.4.22.10.1.2** **(07-16-2025)**

##### Confirmation Receipt of Prompt Assessments - Statute Coordinator

1. Form 2859, request for quick or prompt assessment, must be completed when the ASED will expire in less than 60 days.

2. The use of the Statute Portal is mandated for all quick or prompt assessment statute cases. Uses the Automated Manual Assessment (AMA) application to prepare the forms. The link to the mandated AMA site is: [AMA Statute Portal](https://ama.web.irs.gov/ama/).

3. Route to the accounting function using Form 3210, Document Transmittal.



### Note:



Additional information on the Mandate Statute Portal, such as job aids is available on the Statute Portal home page listed here: Statute Portal.

4. Confirmation must be made and documentation saved on all Form 3210, "Document Transmittal," and Form 2859"Prompt Assessments" . Save a copy of the documents with the case.

5. If you do not receive confirmation, you must follow up with accounting to ensure it was received by:



1. Calling the appropriate accounting site to confirm receipt of the Prompt Assessment forms that need to be made before the ASED expires.

2. Securing confirmation from the appropriate Accounting Unit for all Prompt Assessments faxed to that office by requesting they fax you the signed Form 3210 with DLNs.

3. Notating on the Form 3210 the date, time of call and who is confirming the receipt of the faxed Prompt Assessment next to each TIN on the Form 3210.


### Note:

For multiple TINs listed on one Form 3210, ensure each Prompt Assessment case has a copy of the Form 3210 with notations and a confirmation sheet attached.

6. Depending on the ASED Expiration date, confirmation calls should be made:



1. Immediately after faxing

2. Within 12 hours

3. Within 24 hours

4. No longer than 48 hours after faxing



      ### Note:



      If the Prompt Assessment is faxed on April 15, ensure when the call for verification receipt is made, and there is enough time to re-fax documents if the Accounting Unit did not receive them.


7. Monitor the account for the posting assessment to ensure the assessment posts timely and accurately. Monitoring the assessment ensures that any possible unpostable conditions can be corrected before the ASED expires.

8. CAWR Manager, Technical Advisor or Designated CAWR Employee will serve as backups in the event the Statute Coordinator is unavailable to make confirmation calls.


**1.4.22.10.2** **(07-16-2025)**

#### Taxpayer Advocate Service (TAS)

1. The Taxpayer Advocate Service (TAS) is an independent organization within the IRS that helps taxpayers and protects taxpayer rights. TAS employees assist taxpayers who are experiencing economic harm, who are seeking help in resolving tax problems not resolved through normal channels, or who believe that an IRS system or procedure is not working as it should. Refer to IRM 13, Taxpayer Advocate Service, for more TAS information.

2. TAS independently represents taxpayer interests and concerns within the IRS by:



   - Ensuring that taxpayer problems, which have not been resolved through normal channels, are handled fairly and promptly.

   - Identifying issues that increase burden or create problems for taxpayers, bringing those issues to the attention of IRS management and making legislative proposals where necessary.


3. Refer taxpayers to TAS when the contact meets TAS criteria see IRM 13.1.7.3, TAS Case Criteria and you can’t resolve the taxpayer’s issue the same day.

4. See IRM 13.1.7.5, Same-Day Resolution by Operations, for criteria when the case can't be resolved on the "same-day." The definition of same day is within 24 hours.



### Note:



If the issue cannot be completely resolved within 24 hours, but steps have been taken within 24 hours to resolve the taxpayer's issue, these cases also meet the definition of "same-day" .

5. Do not refer cases to TAS unless they meet the TAS criteria and taxpayer asks to be transferred to TAS. Refer to IRM 13.1.7, Taxpayer Advocate Service (TAS) Case Criteria.

6. When you refer cases to the local Taxpayer Advocate, use Form 911, "Request for Taxpayer Advocate Service Assistance (and Application for Taxpayer Assistance Order)" and forward to TAS in accordance with your local procedures. Also see IRM 21.1.3.18, Taxpayer Advocate Service (TAS) Guidelines, for more information.


**1.4.22.10.2.1** **(04-22-2022)**

##### TAS Coordinator Responsibilities

1. Initial Operations Assistance Request (OARS) requests are assigned to the TAS Coordinator and placed in a designated ATAO in box.

2. Log all requests to an EXCEL tracking document notating EIN, Program, Tax Year, Date Received, Remarks, and Tax Examiner Assigned.

3. Daily review OARS received for attachments that would be applicable to resolve the discrepancy i.e., Form W-2C, tax returns submitted, etc. If they are asking for an abatement of a SSA civil penalty, and the documentation received had no bearing to reconsider, notify TAS of the documents needed, suspense for three days, if documents are not received, then reject back to TAS and close the case and update the EXCEL tracking log.

4. As TAS Coordinator it is your responsibility to ensure the TAS cases are worked promptly. The cases can be assigned out to tax examiners based upon their program skills.



### Note:



Have the tax examiner re-assign the case to themselves on IDRS, take the necessary action requested, fax the OARS back to TAS, provide a copy of the OARS to the Coordinator to update the EXCEL tracking log with the date and action taken.

5. When TAS has requested expedite processing, the SB/SE Coordinator will acknowledge receipt of the OAR to the designated TAS Liaison via Form 3210, Document Transmittal, secure messaging E-mail, facsimile or by telephone, within one (1) workday of receipt of the OAR. The TAS coordinator will provide their relief/no relief decision within three (3) workdays by telephone, facsimile, secure messaging E-mail, or hand delivery to the TAS employee. Telephone responses are acceptable if followed up within the time agreed upon, and with the necessary documentation.

6. Update the EXCEL tracking log with all actions taken to the TAS case and ensure OARS assigned to tax examiners are closed within the negotiated completion date. Verify to ensure the EXCEL tracking log balances to the ATAO cases listing on your CCA 42-43 weekly.


**1.4.22.10.3** **(04-06-2020)**

#### CAWR Appeals Coordinator Responsibilities

1. Requests for relief from civil penalty assessments received after the initial request for relief has been denied through the issuance of Letter 854-C are generally considered an appeal of the previous penalty relief denial.

2. The Appeals Coordinator acts as the liaison between the Operation and Appeals.

3. When a tax examiner has completed their required actions on a case requiring a transfer to Appeals, the case will be transferred to the Appeals Coordinator. The Coordinator will review the file to determine if all appropriate steps have been taken and if all required documentation is present. The case file must include the following:



1. The letter requesting an appeal, signed by the taxpayer or an authorized POA (with a valid Form 2848 on file).



      ### Caution:



      A Form 8821 or Form 2848, Level H (Unenrolled Return Preparer), is not considered an authorized POA.

2. A copy of the previous denied penalty relief request (the TC 290 .00 in BS 98 Source Document). If the Source Document is not available, a copy of the Files charge-out information should be present.

3. A copy of the original Letter 854-C.


4. If the case filing is incomplete, return it to the tax examiner to complete the required actions.

5. Completed case files based on taxpayer response to Letter 854-C will be forwarded to the Ogden Appeals Campus Office:



1. Close any CAWR controls.

2. Open a new control base to Appeals, assign the case to 6629800000, and control category **APPZ**.

3. Input a TC 971 with Action Code 251 for each case.

4. Input TC 470 with Closing Code 90, if applicable. See IRM 4.19.4.6(4), Processing Recons and Replies to Assessment.

5. Issue Letter 86-C to the taxpayer and use 90 days as the contact time frame. The phone number for Appeals customer service is 559-233-1267.



      ### Note:



      This address is:






      | IRS Appeals Office |
      | --- |
      | James V Hansen Federal Building |
      | 324 25th Street 6th Floor |
      | STE 6001 Stop 8500, |
      | Ogden, UT 84401-2310 |


6. Complete Form 12835, Transmittal of a Case to Appeals, for each case.

7. Complete one Form 3210, Document Transmittal, for the group of cases being sent to Appeals. Ship the cases to the address of the Ogden Appeals office.

8. Complete Form 9814, Request for Mail/Shipping Service, for clerical to package the Appeals case(s) for shipping.


**1.4.22.10.4** **(04-21-2021)**

#### Policy Statement P-21-3 (previously known as Action 61)

1. Replies received will include Letter 99-C and Letter 98-C, (CP-251 and CP-253 may also be received). Tax examiners need to conform to Policy Statement P-21-3 requirements to respond to the taxpayer within 30 days of the receive date. Policy Statement P-21-3 requires an interim letter (Letter 5825-C) to be issued if unable to close the taxpayer's response within 30 days. CATRS issues an interim Letter 5825-C on all open replies and Recons if the case reaches 25 days old. CATRS also issues a follow up Letter 5825-C when available)on all cases every 55 days until the case is closed. See _IRM 1.4.22.3_, Technical Coordinator CATRS Responsibilities IAT CAWR/FUTA Batcher Tool for streamlining the clerical process.



### Note:



However, due to the nature of the CAWR program, it has been exempted from Policy Statement P-21-3 requirements, only if other research needs to be ordered based on the contents of the reply.


**1.4.22.10.5** **(07-16-2025)**

#### Reconsiderations (Recons) received from Form 3870 Request for Adjustment

1. When a case is being worked by the field, the revenue officer will submit a Form 3870, "Request for Adjustment" to request an adjustment or abatement of the CAWR assessment and/or civil penalty. These cases will be controlled on IDRS using the Category Code "3870" .



### Note:



The IAT DM Batcher Tool has also been updated with the 3870 Edit Category Code.

2. These cases will be worked within 45 days of receipt into the department on a **first-in-first out (FIFO)** basis while workload permits. These requests may be paper or an E-mail.

3. Log all Form 3870 requests to an EXCEL tracking document, notating EIN, Program, Tax Year, Date Received, Remarks and tax examiner assigned.

4. Points of Contact (POCs) were established at each campus to provide assistance for the field ROs and managers. **It is the POCs responsibility to research problem cases and aide the RO is resolving aged Forms 3870**.


**1.4.22.10.6** **(04-30-2024)**

#### Large Corporation/Large Dollar Screening - Local Large Corporation Coordinator Instructions

1. Review the case to ensure that contact with the Large Corporation Technical Unit (LCTU) is needed.

2. For valid cases take the following action:



1. See the LCTU state mapping list to determine which LCTU needs to be contacted. IRM 21.7.1.4.11.4, Campus Contacts for Large Corp Cases.

2. FAX the CATRS MONEY AMOUNT screen to the appropriate LCTU contact. See Large Corporations Contact for the LCTU contact listing.

3. Update the Large Corporation Referral Tracking listing.


3. The LCTU has 10 business days to supply any additional information.




| **If** | **Then** |
| --- | --- |
| The information supplied by LCTU results in either a full or partial resolution to the discrepancy. | Direct the tax examiner to process the information provided by LCTU and take the appropriate action. |
| The information supplied by LCTU does not result in a full or partial resolution **OR** LCTU does not provide any additional information within the 10 business days. | Direct the tax examiner to issue the appropriate correspondence. |





### Note:



If LCTU provides information after the correspondence has been issued, see IRM 4.19.4.3, Replies.

4. Review the case to ensure that contact with the Large Corporation Technical Unit (LCTU) is needed.


**1.4.22.10.7** **(04-24-2023)**

#### Loose Forms W-2 and Form 8922

1. When Form W-2 are received with no additional correspondence attached, the Loose Forms W-2 must be immediately input on the CATRS System to show Loose Forms W-2 are on file for that EIN. Failure to input Loose Forms W-2 timely, may result in unnecessary contact with the taxpayer or incomplete information being sent to the taxpayer.

2. Form 8922 Third Party Sick Pay Recap reconciles 3rd party sick pay with Forms 94X for tax years 2014 and subsequent. This form will be mailed directly to the CAWR units based on state mapping and will be input and treated like loose Form W-2. Follow the same instructions for entering loose Form W-2 into CATRS.

3. To access the Loose Forms W-2 screen select the **Edit** option located on the main Menu Bar and select **Miscellaneous DATA** from the drop down menu and then click on the **Loose W-2** tab.

4. The screen will display the following fields:



01. Search Function

02. New - To add new Loose Form W–2

03. Delete - Deletes information

04. EIN

05. Tax Period

06. Site

07. Created date

08. By - User that entered the data

09. ID number

10. Close - Exits the Loose Form W-2 Screen


5. As loose Forms W-3/W-2, W-3C. W-2C (not submitted with a reply) are received in the CAWR unit(s), they will be given to the Coordinator or to the Loose W-2 Coordinator for input to the CATRS system and will be filed by the system assigned serial number.




| **If** | **Then** |
| --- | --- |
| The tax year is the current IRS-CAWR tax year being worked minus 2 years or plus 2 year.<br> <br>### Example:<br>For example, TY 2021 IRS-CAWR is being worked. Loose Forms W-3/W-2 and W-3C/W-2C are received in the CAWR unit for tax years, 2017, 2018, 2019, 2020 and 2021. | All of these tax year's loose Forms W-3/W-2 and W-3C/W-2C must be entered to CATRS using the Loose Forms W-2 procedures. |
| The loose Forms W-3/W-2 and W-3C/W-2C are entered to CATRS using the CAWR Loose W-2 procedures. | An indicator and a serial number are generated/assigned from CATRS to indicate there are Loose Forms W-2.<br> <br>1. Write the serial number on the first page of the tax-payer's loose forms.<br>      <br>2. File them in serial number order.<br>      <br>3. The tax examiner will retrieve them when needed. |





### Note:



These forms will be held for use in the appropriate tax year's program when it is worked. The CATRS indicator provides the serial number of the forms. If they cannot be found in your site, identify which campus has physical possession of the forms and have them faxed to you. Once the faxed forms are received alert the campus of receipt and request the originals be destroyed.

6. The tax examiner will be alerted to the Loose W-2 Information by a "Yellow Highlighted Banner" that runs across the Header Section of CATRS showing the assigned Loose W-2 Serial Number.


**1.4.22.10.7.1** **(07-16-2025)**

##### Adding New Loose Forms W-2

1. To input a Loose Form W-2 or Form 8922 onto CATRS, select the **Edit** option located on the main Menu Bar and select **Misc Data** from the drop down menu, then choose the **_Loose W-2_** tab.

2. When adding a new Loose Form W-2 record you will be required to complete the following fields:



01. New - Click on the **New** button and the "Loose Forms W-2" screen will display.

02. Filter(s) - These fields are system generated.

03. EIN - Enter the EIN from the information listed on the Loose Form W-2.

04. Tax period - Enter the tax period from the information listed on the Loose Form W-2.

05. Site ID - System generated.

06. Created Date - This is system generated with the date that the Loose Forms W-2 was added to CATRS.

07. Username - This is system generated with the Log In name of the user inputting the Loose Form W-2.

08. Serial Number - This field is system generated.

09. Undo - Close - If you select the Undo or Close button it will cancel the request.

10. Click on the **OK** button. See IRM 4.19.8.2, CAP CAWR Automated Program Technical System Procedures.

11. After clicking on Apply, this will bring up the Information Screen and display the following message, "loose W-2 successfully added" . Click on **OK** to add the W-2 information to the CATRS system.



       ### Note:



       **The Serial Number needs to be notated on the Loose Form W-2, enabling them to be filed in Numeric Order for easy retrieval once the case is going to be worked.**


**1.4.22.10.8** **(04-24-2023)**

#### Discovered Remits

1. Discovered remittance is a response and/or correspondence with an original form of payment attached such as a personal check, money order or cashier’s check. Also, a loose check(s) discovered in an envelope or attached to a blank piece of paper.



### Note:



For voided or blank checks see (8) below.

2. If any of the items listed in (1) are discovered, both the Form **3244**, Payment Posting Voucher and Form **4287**, Record of Discovered Remittance **must** be completed.

3. Two copies of Form **3244** must be completed for each discovered remittance and contain entries in the following fields:



   - TIN

   - Form number/ MFT

   - Transaction/ Received date (IRS Received date)

   - Taxpayer name, address and ZIP code

   - Transaction Data, enter remittance amount next to code 640 (Advance Payment of Deficiency)

   - Remarks (the team manager’s phone number and Mail Stop)

   - Prepared by


4. Form **4287**, Record of Discovered Remittance, must be completed to log all discovered remittances. The following fields must have entries;



   - Stop Number

   - Unit

   - Telephone number

   - Today’s Date-in MM/DD/YYYY format

   - Type of doc- (for example, Form **940**, Schedule H)

   - Tax Period- (entire tax period XXXX)

   - Type or remit- (total money amount including comma and decimal point)

   - Received Date- in MM/DD/YYYY format

   - Name (entire name)

   - TIN

   - Discoverer- Name of person who discovered the remittance and their supervisor’s name


5. **If remittance is found attached to a case while working in the office, take the following steps:**



1. Attach one copy (original) to the remittance and give it to the manager/Lead Tax Examiner who will give it to the Clerical Manager/Lead Clerk to place in a **locked box**.

2. Attach the second copy of the Form **3244** to the response.


6. **If the remittance is found attached to a case while tele working, immediately take the following steps:**



1. Notify your manager immediately.

2. Email completed Forms **3244** ad 4287 to your Manager and Coordinator/Technical Advisor.

3. Place remittance in a **sealed envelope** and store in a secure place (locked desk or cabinet).

4. Document remittance details (i.e; leave a case note or history item).

5. Make an appointment to bring Discovered Remittance into the operation and deliver to the technical Manager/Lead Tax Examiner within **2 business days**.

6. Technical Manager/Lead Tax Examiner will accept the discovered remittance, print Form **4287** and Form **3244**.

7. Manager/Lead Tax Examiner will deliver the discovered remittance to the Clerical Manager/Lead Clerk.


7. **IRS CHECKS**\- Returned IRS refund checks are handled differently than regular discovered remittance. If an IRS refund check is found, take it to the team Manager/ Lead Tax Examiner to be routed to the Refund Inquiry Unit.

8. **VOIDED CHECKS**\- If the response has a **"VOIDED"** personal check attached, remove the check from the response and attach it to the Installment Agreement (IA) request. Route the "VOIDED" check with the IA to Collections.


**1.4.22.10.9** **(04-30-2024)**

#### Disaster Areas- Disaster Coordinator

1. The Disaster Areas screen contains Disaster Area information for specific states and/or ZIP Codes. It enables the user to view and to sort information on active and inactive **O** and **S** freeze Disaster Areas. This information is used to determine whether or not a case can be updated.

2. The Disaster Coordinator is responsible for adding disaster information and editing existing Disaster information.

3. When new disasters occur, the Disaster Coordinator will receive direction from HQ of the type of freeze code (-S or -O) being issued and the actions needing to be taken. Once the directive has been received the Disaster Coordinator will search the FEMA web site to identify the information that is needed to add to the CATRS system.



### Note:



Access the FEMA web site daily for Disaster Information: [FEMA web page](https://www.fema.gov/disaster/current#current-disaster).

4. The entering and updating of Disaster Area Information is done by two specific Disaster Coordinators who have been assigned by Headquarters. One in site 05 and one in site 02. The Campuses should rotate monthly responsibilities for disaster inputs. **Viewing and searching of Disaster Area Information is accessible to all Coordinators.**

5. To access the Disaster Areas option, select **Edit** in the main Menu Bar, then select **TE Miscellaneous**, then select **Disaster Areas**. The Disaster Areas screen allows the user to view both Active and Inactive Disaster Areas.

6. The "Disaster Areas" screen will display the following fields:




| Screen Title | Definition |
| --- | --- |
| Disaster Status | This field is a Filter(s) option. Click on the drop down arrow and select the Disaster Type - Active Disasters or Inactive Disasters. You may also broaden the search by using the Input Date and/or Disaster Type. |
| Input Date | This field is a Filter(s) option. Click on the drop down arrow and select the approximate time frame the Disaster(s) was input to CATRS. The options are: Today, Yesterday, Last Week, 2 Weeks Ago, Last Month, 2 Months Ago, 3 Months Ago or Longer. This will display all information input with the time frame selected. |
| Disaster Type (select/ filter) | This field is a Filter(s) option. Click on the drop down arrow and select the type of Disaster input on the CATRS system. The options are: Earthquake, Fire, Hurricane, Terrorist, Tornado or Water. This will display all information of the Disaster Type selected. |
| Disaster Type | This field displays the disaster type(s) selected. If you selected a specific Disaster type, that type will display. If you selected <None> in the Disaster Type field, all Disaster types will display. This field can be sorted by Disaster Type by clicking on the Disaster Type box. |
| State | This field shows all States where a disaster has occurred that have been input to CATRS. This field can be sorted by State by clicking on the State box. |
| ZIP Code | This field displays all ZIP Codes where a disaster has occurred that have been input to CATRS. This field can be sorted by ZIP Code by clicking on the ZIP Code box. |
| Effective | This field displays the date that the Disaster became effective. The date will be found on the FEMA web site. This field can be sorted by Effective date by clicking on the Effective box. |
| Expires | This field displays the date the Disaster expires. The date will be found on the FEMA web site. This field can be sorted by Expires date, by clicking on the Expires box. |
| User | This field identifies the Disaster Coordinator who input the Disaster information into CATRS. This field can be sorted by User name. |
| Created | This field displays the date(s) the Disaster was input to CATRS. This field can be sorted by created date. |
| New | This box is selected when the Disaster Coordinator is adding a New Disaster. |
| Delete | This box is selected when the Disaster Coordinator determines that a Disaster was added in error. |
| View Record | This box is selected when the Disaster Coordinator needs to edit the disaster information on a specific entry. |
| Close | To close the Disaster Area Search. |


**1.4.22.10.9.1** **(03-29-2018)**

##### Adding New Disaster

1. To enter new disaster area information on the Disaster Area screen:



1. Select the **New** button to bring up the "New Disaster Area" Screen.

2. Click **Description** down arrow and highlight the Disaster Type.

3. Click **Effective Date** down arrow and a calendar displays. Use the arrows at the top of the calendar to locate the month of the Effective Date. Select the appropriate day of the month.

4. Click **Expiration Date** down arrow and a calendar displays. Use the arrows at the top of the calendar to locate the month of the Expiration Date. Select the appropriate day of the month.

5. Disaster Area - Click on **Single Zip** or **Zip Range** down button.

6. ZIP Code - If you choose to update a ZIP Code you will enter **ZIP Code** in the box. If you selected **ZIP Code Range**, the ZIP Code box will display 2 ZIP Code fields, "Beginning ZIP Code" and "Ending ZIP Code" , enter the ZIP Code range.

7. FZ - Enter the freeze code (-O or -S).

8. Add Disaster(s) - Once all the Disaster information has been entered into the screen, click on the check mark button. This will bring up the Information screen. A message will display "1 disaster record(s) added" , click the **OK** button to confirm the information.

9. Close - Click on the **Close** button to exit the screen.


**1.4.22.10.9.2** **(06-03-2011)**

##### Deleting Disaster Area Information

1. If Disaster information was entered incorrectly, you may delete the record you created.

2. To delete a Disaster Area's record:



1. Highlight the **Disaster Record**.

2. Select the **Delete** button.

3. After Selecting the Delete button this will bring up an information screen and a message will display "Are you sure you want to delete this record?" Select either **Yes** to confirm that the information is to be deleted, or **No** and the information will not be removed.



      ### Caution:



      **Once Disaster Area Information is deleted, it CANNOT be restored. Be sure the correct disaster is being deleted before clicking on the Yes Button.**

4. Once you have deleted the Disaster Information select **Close** to exit the screen.


**1.4.22.10.9.3** **(06-03-2011)**

##### Editing Disaster Information

1. You may receive information the Expiration Date on a Disaster has changed or the ZIP Code range has been extended.

2. The "Disaster Areas" screen allows you to edit the disaster information by:



   - Disaster Type

   - Effective Date

   - Expiration Date

   - ZIP Code


3. To edit Disaster information access the Disaster Areas screen:



1. Select **View Record** option.

2. Select the **Disaster Area Record** you want to edit.

3. Click on the **View Record** option to bring up the "Edit Disaster" screen.

4. Click on the down arrows to edit Disaster Type, Effective Date or Expiration Date.

5. Enter the correct ZIP Code if necessary.

6. Select the **Apply** button to update the new information.

7. Select **Cancel** if you do not want to update the information.


**1.4.22.10.10** **(04-20-2012)**

#### Online Retrieval System Coordinator Responsibilities

1. The ORS Coordinator at each campus will be responsible for adding users, deleting users, and tracking user access, as well as reporting system problems or error messages to the HQ analyst.



### Caution:



A user must change their password **and**access the ORS system every 30 days or they will be locked out of both ORS and ERQY.

2. ORS access is given by the user accessing a specific internet address. When users change location, for any reason, the HQ analyst must be notified to ensure that the new location address is able to access ORS.


**1.4.22.10.10.1** **(04-30-2024)**

##### Adding a User

1. All ORS requests must be requested by the coordinator to HQ for any employees needing access to either ORS and/or ERQY.

2. See the CAWR/FUTA home page CAWR-SSA for information on how and who to submit your ORS request to.

3. The CAWR coordinator at each site is responsible to ensure the forms are completed accurately **prior** to submitting to the HQ Coordinator.

4. Once HQ has processed the requests you will be notified to input a BEARS for each user. The user's temp password and PIN Number will be administered using the Online BEARS system and their name and information will be added to the ORS Tracking Sheet.

5. The Coordinator should send E-mail to users three weeks before the expiration date of their ORS access.


**1.4.22.10.10.2** **(07-16-2025)**

##### Deleting a User

1. To delete a user, you must complete a BEARS request supplying the reason for the deletion (ex. went to new position, resigned, retired, etc) We have limited access to ORS therefore please make sure if someone no longer needs access, they are deleted from the system immediately.

2. The HQ analyst will provide an ORS Tracking Sheet that must be updated accordingly. Any users that have been deleted since the last update must be notated on the tracking sheet and highlighted in yellow (never cross off anything on the tracking sheet without an explanation).


**1.4.22.10.10.3** **(04-30-2024)**

##### Changing Your Password

1. A user must change their password and access ORS every 30 days or they will be locked out of the system.

2. See CAWR-SSA for instructions and the URL used for changing your password.


**1.4.22.10.10.4** **(07-16-2025)**

##### Resetting Your Password

1. SSA’s Centers for Security and Integrity must be contacted for assistance with PIN/ Password resets. See CAWR-SSA for the SSA’s contact’s name for your district office code and HQ contact to determine the proper SSA contact to assist you. The contact will give you a temporary password.



### Caution:



**Do not** prepare a BEARS request to reset a password.


**1.4.22.10.10.5** **(04-30-2024)**

##### ORS Tracking Sheet

1. The HQ analyst will periodically send out a tracking sheet with information and directions that must be verified for accuracy.

2. Changes need to be **annotated** and **highlighted** before returning the tracking sheet to your HQ analyst by the due date given (Never cross off any information on the Tracking Sheet).


**1.4.22.10.11** **(04-20-2012)**

#### Training Coordinator Responsibilities

1. This person will be responsible to ensure training is administered annually to all employees. New hires will receive Basic Training and all other employees will receive CPE training. The duties of the Training Coordinator are listed below:



   - Reserve Training Rooms

   - Order supplies for students and instructors

   - Supply Forms needed for ELMS credit

   - Solicit Operation for Subject Matter Experts (SMES)

   - Prepare training plans for students and instructors

   - Monitor/Evaluate Training

   - Resources


2. **Reserve Training Rooms**: Reserve training rooms sufficient for delivering CAWR training. Reserve the rooms far enough in advance to ensure they are available for your April training. These Computer Based Training rooms need to have CATRS, IATS, IDRS and ORS (for the overhead) to be able to explain the different systems and use them throughout the class. Ensure you prepare for employees with disabilities accordingly.

3. **Order supplies for students and instructors**: Students will need paper, pens, highlighters, tabs and course training material.

4. **Supply Forms needed for ELMS credit**: Ensure the following forms are available for class startup: Form 12466, Integrated Training Evaluation and Measurement Serves (Classroom), Form 12464, Integrated Training Evaluation and Measurement Serves (Classroom CBT), Form 10268, Training Registration Record, and Form 6554, Name Card. These forms are to be brought to the CMLC staff upon completion of the class.

5. **Solicit Operation for SMES**: Contact the Operation for employees having received CIT training and are most qualified to instruct.

6. **Assist with the preparation of training plans for students and instructors**: Assist with the development of course material, handouts, disclosure. Review nature of changes listing in the most current IRM available to include in the course material. Discuss with the instructors the delivery method you will be using and what phases of the program will be covered.

7. **Monitor/Evaluate Training**: Supply the manager/ instructors with OJI and OJT Guidelines. Ensure guidelines are being followed and progress can be tracked for individual employees.

8. **Training Resources**: Prepare a report for submission to your Operation detailing the number of hours used at the end of the classes. Participate in the completion of the Operation's Training Work Plan.


**1.4.22.10.12** **(04-30-2024)**

#### Update Schedule D

1. Schedule D information will be received either by electronic transfer that will be automatically updated to CATRS or a paper Form Schedule D that will be a manual input.

2. When paper Forms Schedule D are received with no additional correspondence attached, the Schedule D must be immediately input on the CATRS System to show that Schedule D are on file for that EIN. Failure to input the Schedule D timely, may result in unnecessary contact with the taxpayer or incomplete information being sent to the taxpayer.

3. As paper Forms Schedule D (not submitted with a reply) are received and the information has been entered into the CATRS system the paper Forms Schedule D can be destroyed. IRM 4.19.8, CAP(CAWR Automated Program) Technical System Procedures.




| **If** | **Then** |
| :-: | :-: |
| The tax year is the current IRS-CAWR tax year being worked minus 2 years or plus 2 year.<br> <br>### Example:<br>For example, TY 2020 IRS-CAWR is being worked, paper Schedule Ds are received in the CAWR unit for tax years, 2017, 2018, 2019, 2020 and 2021. | All of these tax year's paper Forms Schedule D must be entered to CATRS using the CAWR Schedule D procedures. |
| Paper Schedule Ds are entered into the CATRS system. | Once the information has been entered the paper Schedule D can be destroyed. |

4. The tax examiner will be alerted to the additional Schedule D Information by a "Yellow Highlighted Banner" that runs across the Header Section of CATRS.

5. To access the Schedule D screen, select the **Edit** option located on the main Menu Bar and select **TE Miscellaneous** from the drop down menu.

6. The screen will display the following fields:




| **Field Name** | **Definition** |
| --- | --- |
| Search Function | Used to type in search information |
| New | Used to add new Schedule D's |
| Delete | Used to delete Schedule D’s |
| Form 941 | Displays EIN |
| Tax Period | Displays Tax Year |
| Other | Displays third party information |
| TRANS\_DT | Displays transaction dates |
| Created Date | Displays date the Schedule D was added to CATRS |
| By | Displays the user who input the Schedule D |
| Modified | Displays the date of the last updates |
| By | Displays use who updated the Schedule D |
| First By | Used to sort the schedule D information |
| Then By | Used to sort the user information |
| Close | Used to exit the Schedule D screen |


**1.4.22.10.13** **(04-24-2023)**

#### Generalized IDRS Interface (GII)

1. CATRS now automatically sends the second Interim Letter 5825-C on taxpayer replies and Recons. Use GII to input mass Interim Letters on CAWR cases identified as taxpayer prior (cases no longer on CATRS) Recons. Initial Interim letters should be issued if a response has not been sent to the taxpayer inquiry when the case reaches 24 days old. Subsequent interim letters should be issued within 60 days of the date of the original interim letter.



### Note:



Target the letter dates where it has been more than 53-59 days since the initial interim letter was sent when determining whether to send the second interim letter.

2. You must have an approved BEARS for one of our GII EITCRA XXXX (where XXXX is the user group MACS, EOEC, ITG, MSC, etc.) sub applications, and you must be a member of the Active Directory DS Domain global group associated with that BEARS sub application.

3. For specific instructions concerning installation and using the GII, see the SB/SE Document Matching web page.



### Note:



If you are experiencing issues with GII, please refer to _IRM 1.4.22.9.2_, System Problem Reporting for resolution.


**1.4.22.10.14** **(04-30-2024)**

#### Supervisory Approval to Assess Penalties

1. Certain replies where a tax examiner makes a determination to assess a PRN 549, 550, or TC 180 penalty must be approved by a supervisor. See IRM 4.19.4.7.1, 6751 - Supervisory Approval to Assess Penalties for instructions.


**1.4.22.11** **(04-30-2024)**

### CAWR Reports - Site Coordinator/Coordinator/Manager

1. The reports in the CATRS System serve two distinct purposes. The first is to provide reports to aid in the flow of work assigned to the users. The second is to provide managers, Site Coordinator or HQ with information to be used in the coordination and monitoring of the inventory in the IRS-CAWR and SSA-CAWR programs.

2. The CAWR reports are provided on a weekly basis by the CAWR applications development staff. Until all cases are closed, or up to one year after the program completion date (PCD) the reports should reflect any changes to the volumes previously reported. The CAWR reports are in the process of being moved to Business Objects Enterprise (BOE). Once moved coordinators and managers will access that system to view the reports.

3. Managers/Coordinators at each site must monitor these reports to insure the program is meeting the**Completion** and**Benchmark dates.**

4. The reports are generated with information for all sites. If a report or a portion of a report (information from one site) needs to be printed, the user will need to copy and to paste the specific information onto a Word Document to print.

5. CAWR Reports have a two month retention time frame. The time is determined by the date the report was created plus two months, unless otherwise specified. The Retention date is displayed on the reports main menu.

6. The table below identifies the available reports:




| **Report** | **Available** | **Used By** | **Purpose** |
| :-: | :-: | :-: | :-: |
| Daily Closure Listing | Daily | Manager-Coordinator-PAS | The report is generated daily. It provides a daily closure report which shows cases closed the previous day through the screening phase of the program. It is sorted by site, tax-year, unit and EIN. |
| CAWR Download Report | Weekly | HQ | Generates three reports showing cases not loaded during the download process. It is sorted by Tax Year. The report is not separated by site. |
| Individual Age | Daily | Manager | This is a daily report for Tax Examiners to monitor total open assigned cases. The report is in age order by status date. It is sorted by unit number, login name, tax year and status date. |
| CORRESPONDENCE REPORT | Weekly | Coordinator-HQ | This is a weekly report that contains data from the prior 30 days showing the totals of each type of correspondence issued for the three types of cases: IRS CAWR, SSA CAWR, and Other SSA (for both period and cumulative). |
| Case Status Report | Weekly/ Monday | Manager-Coordinator-HQ | This is a weekly report which generates and displays the status of each case (total volume).Each site’s information is displayed separately within the report.<br> <br>   - Section ONE displays information for the prior week of total unassigned, opened, tax examiner closures, BMF Deletes and total CATRS cases.<br>     <br>   - Section TWO displays the Current Status of Assigned Cases.<br>     <br>   - Section THREE displays the Current Status of Closed Assigned Cases. |
| Late Reply Report | Weekly | Manager-Coordinator-HQ | Weekly report of Recons received. |
| Manager Review Listing | Daily | Manager | The report is generated daily and will contain EIN(s) of CAWR, SSA-CAWR and Other SSA cases for each status code by user. Five cases will be randomly selected for each tax examiner. The list is generated by Site, user order. Manager will print and use this report, as needed, to meet their requirements for individual employee reviews. This report will be used in conjunction with the Embedded Quality system. |
| Mass letter Generation Report | Weekly | Coordinator | The report is generated weekly, immediately after the load process. It shows the total volume of cases available for automatic generation of 98-C SSA letters, the weekly projected volume of 98-C SSA necessary to meet the Cycle 33 deadline and the remaining volume of cases available for notices. |
| MILLION DOLLAR PEN ASSESS RPT | Weekly | Coordinator | The report is generated weekly showing cases with a potential penalty assessment of one million dollars or more. The report will only display users with assigned cases meeting the million dollar criteria. All cases on the report must be coordinated with the LCTU employee in the Large Corporation Unit at each campus before manually inputting a penalty assessment. Failure to work these cases in coordination with the LCTU employees(s) in the Large Corporation Unit will result in potential erroneous assessments and subsequent abatements. |
| MISTLE | Weekly | Coordinator-Manager-HQ | The report is generated weekly and is Site specific. It is a two part report, SSA-CAWR and IRS-CAWR. It displays total inventory downloaded and workable download. The report provides period and cumulative totals of various status codes. It is used to monitor correspondence inventory volume and age. This report is used to monitor the overall progress of the programs, including program benchmark dates and closures. |
| NO REPLY SOURCE DOCUMENT | Weekly | Coordinator | The report is generated weekly showing No Reply cases from the previous week that require manual review and/or input. This report needs to be printed and used as the source document for the assessment. |
| NO REPLY LISTING | Weekly | Coordinator | The report is generated weekly and displays a complete list of all No Reply cases for both CAWR and SSA programs. Status 91 SSA no replies are the main function of this report. The listing also needs to be provided to PAS for review. The listing needs to be held for 30 days before providing it to PAS.<br> <br>### Note:<br>**It takes 30 days from the time the case updates to status 91 for the auto-assessment of the Civil Penalty to post.** |
| CASES REFERRED TO CI | Weekly | Coordinator-Manager | Referral CI (Status 27),this report is used to monitor cases referred to CI. |
| CASES REFERRED TO COLLECTION | Weekly | Coordinator-Manager | Referral Coll (Status 29),this report is used to monitor cases referred to Collections. |
| CASES REFERRED TO EXAM | Weekly | Coordinator-Manager | Referral Exam (Status 25),this report is used to monitor cases referred to Examination. |
| REVENUE TRACKING REPORT | Weekly | HQ | This report is used to track revenue being secured on each case. |

7. Legend:



   - C - Coordinator

   - M - Manager

   - HQ - Head Quarters


**1.4.22.11.1** **(04-30-2024)**

#### Integrated Data Retrieval System Reports (IDRS)

1. Integrated Data Retrieval System (IDRS) reports are available to managers as tools in managing team and individual employee inventories. IDRS reports are primarily used by teams whose inventory is controlled using IDRS. All inventories received in the CAWR program must be controlled on IDRS. The report type used is the Case Control Activity System (CCA). ORCAS-Manager and Lite is now available to review the CCA reports.

2. The primary IDRS CCA reports available are:




| **Report** | **Available** | **Used By** | **Purpose** |
| :-: | :-: | :-: | :-: |
| CCA 42-42 IDRS Inventory Control | Weekly | Manager/ Coordinator | This report summarizes inventory, receipts, closures, and age by category. |
| CCA 42-43 IDRS Overage | Weekly | Manager/ Coordinator | This report lists cases assigned to an IDRS employee number in IRS receive date order. |
| CCA 42-44 IDRS Multiple Case Control | Weekly | Manager/ Coordinator | This report identifies cases when two or more employees have an open control base on the same TIN. |

3. These reports are available on Control-D. The CCA reports are available on Monday mornings. Refer to the most current Document 6209, Section 14, IDRS, for category codes shown on the CCA reports.


**1.4.22.11.2** **(04-30-2024)**

#### CCA 42-42 - IDRS Inventory Control Report

1. This report summarizes inventory, receipts, closures, and age by category. It gives a broad picture of the inventory in the entire operation by category.

2. This report is available on Control-D on Monday mornings, Report Name: "Team Inv Report" , Job Name: CCA 42-42D. The ORCAS coordinator will load the CCA report through the ORCAS delivery database. Then the CCA report will be available to the ORCAS managers and ORCAS tax examiner.

3. Items on the Report - For each case shown, the following information is provided:




| **Report and Column Names** | **Definition** |
| --- | --- |
| Case Category | Category of case See Document 6209, Section 14, IDRS |
| Begin on Hand | Ending inventory volume from prior week's report |
| Total Receipts | Total number of new cases for current report |
| Aged Receipts | Number of cases aged as determined by category code |
| Case Transfer In/Out | Number of cases transferred in or out from one team to another |
| Category Change | Number of cases transferred from one category to another |
| Cases Closed | Total number of cases closed |
| Ending on Hand | Ending inventory volume |
| Status of Cases in Ending Inventory | Suspense, Assigned, Background Monitoring |
| 0 Days | Number of cases in ending inventory within that age range |
| 1- 99 Days | Number of cases in ending inventory within that age range |
| 100 Days or Over | Number of cases in ending inventory within the age range |
| Stat Age | Number of cases that fell within the statute age range |

4. The Manager/ Lead should utilize CCA 42-42 as a tool to identify the weekly receipts and closures under each category and the number of cases that are aged upon receipt. No annotation is needed on this report; however, this report is a tool to monitor inventories and should be reviewed within 30 days of receipt.

5. It has been suggested that the Department Manager or a delegate should review the report to monitor the number of cases and age of inventory in each category to determine if resource changes are needed. The Department Manager should maintain a copy of these reports for one year.


**1.4.22.11.3** **(04-30-2024)**

#### CCA 42-43 - IDRS Overage Report

1. This report contains all cases controlled to an IDRS employee number and is used to:



   - Identify cases that require action, such as old age cases.

   - Identify specific cases for review.

   - Monitor the size of the employees' inventories.

   - Determine if employees are working inventory in the proper order, such as First in First out (FIFO).

   - Set closure expectations.

   - Identify potential management problem cases.

   - Monitor for the prevention of premature STAUP/TC 470.


2. This report is available on ORCAS delivery database/ Control-D every Monday morning, Report Name: "Overage Report" , Job Name: CCA 42-43D.

3. Items on the Report - For each case shown, the following information is provided:




| **Report and Column Name** | **Definition** |
| --- | --- |
| TIN | Tax payer identification number |
| IRS Rcd Date | The date IRS received the case |
| Status | Case History Status Code (A - Active, B- Background, C - Closed, M - Other long term delay, and S - Suspense) |
| BOD | Business Operating Division |
| CLC | Client Code |
| Category | Category of the case |
| Freeze Codes | Freeze Codes that are on the IDRS account |
| MFT | Master File Tax account code |
| Mod Per | Tax Period on assigned account |
| Assigd Date | The date the case was assigned to a tax examiner |
| Plan No | If applicable |
| Activity Code | A 10 character field on IDRS that the tax examiner uses to enter actions taken on the case |
| Name Ctrl | Name Control on taxpayer's account |
| Action Date | Date of last action input on the account |
| Age | Number of days case has aged on IDRS |
| MF Mod Balance | Module Balance on IDRS |
| Stat Age | Indicates statute conditions for current and previous years returns - over, expired, or days remaining on statute |
| STAUP Cycle | Stops notices from generating until cycle listed |
| C Letter and Date | Date and type of CRX letter sent |

4. The Manager/Lead must review this report to ensure cases are being worked according to IRS receive dates. Annotate cases for follow-up actions by COB Monday. The reports should be maintained for two months. Highlight the cases on the report where:



   - The tax examiner has failed to take timely actions such as follow-up on a case when the purge date has passed.

   - The case is in Nullified Unpostable (NLUN) category over 14 days old.

   - The Statute of Limitations will expire within 180 days.

   - The STAUP has expired or there is no STAUP on a balance due account.

   - Old age cases not being worked in FIFO order.


5. Manager/Lead will provide the tax examiner with the printed or electronic page(s) of their weekly report of all cases are controlled to their IDRS number. Tax examiner will notate on the page the actions taken on each case worked. Annotations should include C - Closed, U - Update, or S - STAUP input, tax examiner may also include additional comments if needed to explain action taken. The report should be signed and returned to the Manager/Lead by close of business Friday. The tax examiner should work cases in the following priority order:



   - NLUN category cases.

   - The statute will expire within 180 days.

   - Taxpayer was contacted and purge date has passed.

   - Remaining cases in oldest date received order.


**1.4.22.11.4** **(04-30-2024)**

#### CCA 42-44 - IDRS Multiple Case Control Report

1. This report identifies cases when two or more employees have an open control base on the same TIN. It identifies the employee's IDRS numbers, tax year, and category for the duplicate controls.

2. This report is available on Control-D every Monday morning. Report Name: "Multi Case Report" , Job Number: CCA 42-44D.

3. Items on the Report - For each case shown, the following information is provided:




| **Report and Column Name** | **Definition** |
| --- | --- |
| TIN | Tax payer identification number |
| BOD | Business Operating Division |
| BOD CLC | Business Operating Division Client Code |
| F/S | File Source |
| MFT | Master File Tax account code |
| Tax Period | Identifies the tax period that was controlled |
| PLN | Plan Number, if applicable |
| N/C | Name Control |
| C Number | Case control number |
| Employee Number | Employee number whom case is assigned to |
| Status | Case History Status Code |
| Category | Category of first case |
| IRS Recd Date | The first IRS received date |
| C Second Number | Second case control number |
| Employee Second Number | Employee number whom second case is assigned to |
| Status | Case History Status Code for second case |
| Category | Category of second case |
| IRS Recd Date | The second IRS received date |

4. The Manager/Lead should:



   - Provide the report by COB Monday to the employee identified as having controls on the case, highlighting the control number assigned to their team member.

   - Instruct the employee to write the actions taken on the case on the report and return the annotated report to the Manager/ Lead no later than close of business Friday.

   - After it is returned by the employee, review the report to determine if the correct actions were taken or return to the employee with feedback on the actions that need to be taken.

   - Maintain these reports for three months.


**Exhibit 1.4.22-1**

### Glossary of Acronyms and Terms

This is a listing of commonly used terms and definitions used in the CAWR program.

| **Terms** | **Definition/Explanation** |
| :-: | :-: |
| Account | A tax record on magnetic tape at the Electronic Computing Center (ECC-MTB) in Martinsburg, West Virginia. Tax Data is identified by social security number or by employer identification number. |
| ASED | Assessment Statute Expiration Date - three years from the filing of the return, unless the return is filed before the due date (determined without regard to any extension of time to file), in which case the ASED is three years from the due date. IRM 4.19.4.3.12, Statute Issues/Imminent Assessments. |
| BMF | Business Master File - Master File processing done at the ECC-MTB. |
| CATRS | CAWR Automated Program - A program that runs on a stand-alone mini computer system. A compatible tape can be generated on all CAWR output tapes from the ECC-MTB through the Service Center Recirculating Master File (SCRMF). These output tapes are loaded directly onto the stand-alone mini computer system to automate the CAWR Program. Weekly updates are received from the ECC-MTB. |
| Case File | The examined return, related work paper, correspondence, etc. |
| Case Type | Distinguishes CAWR Cases according to specific Out-of-Balance Conditions. See IRM 4.19.4, CAWR Reconciliation Balancing, for additional information on CAWR Case Types. |
| CAWR | Combined Annual Wage Reporting which evolved from Public Law 94-202. |
| CC | - **Closing Codes** \- CAWR Closing codes are listed in IRM 4.19.4-2, Closed Case Status Codes and are to be input into CATRS and will be reflected on IDRS CC BMFOLU.<br>  <br>- **Command Code** \- A five character code used to tell the IDRS system what function to perform. |
| Cycle | A seven-day processing period (usually Sunday-Saturday) at a Campus and the ECC-MTB. The cycle is expressed by a 6 digit code; the first four digits, are the Processing Year and the second two digits, are the Processing Week in that year. |
| DLN | Document Locator Number - A 14 digit controlled number assigned to every return or document. The DLN is used to control, identify and locate processed documents. |
| ECC-MTB | Enterprise Computing Center: Located in Martinsburg, WV. This center houses the master file records for the entire nation. |
| EIN | Employer Identification Number: A nine-digit number, also referred to as the EI number, used to identify business taxpayers on the Business Master File in NN-NNNNNNN format. The first two digits represent the district office code. |
| Entity Module | The portion of the Master File Record which identifies the taxpayer. It contains their name, address, social security or employer identification number, filing requirement codes, tax period and date of establishment. |
| ERQY | The Employer Report/Adjustment Query (ERQY) is used to obtain employer report and adjustment information from the SSA Employer Control Data Base and covers years 1937 to present. |
| Fiscal Year | A twelve month accounting period. |
| FITW | Federal Income Tax Withheld - The employer should withhold income tax from employees' pay. Tax also may be withheld from certain other income, including pensions, bonuses, commissions and gambling winnings. In each case, the amount withheld is paid to the IRS in the employees' name. |
| Freeze Code | A Freeze Code places a Taxpayer's Account in a condition which requires additional action before the account can be settled. There can be more than one Freeze Code present on an account. |
| IAT | Integrated Automation Technologies (IAT) is a program that can read information from the IDRS screen and automates the initiation of command codes to the IDRS system. It checks the input for accuracy to avoid an unposted transaction and contains convenient links to IRM references and other information for faster research.<br> <br>### Example:<br>The Address Change tool pulls up a menu where the user types in the updated address and the tool will initiate all the necessary command codes and completes the applicable fields. |
| IDRS | Integrated Data Retrieval System - A computer system with the capability to instantaneously retrieve or update stored information. IDRS works in harmony with the master file of taxpayer accounts. This system is aimed at quick resolution of problems and queries concerning current taxpayer accounts. It is used to perform case research, case control, data requests, account updates and/or adjustments and generation of letters and/or notices. |
| IMF | Individual Master File - A file containing information about taxpayers who file individual income tax returns (1040 series) and related documents. |
| IRM | Internal Revenue Manual - Outlined procedures to ensure a program is worked correctly, efficiently and consistently throughout all campuses and with other programs. |
| IRS-CAWR | Internal Revenue Service Case - Cases identified by the IRS for not filing any or all required Forms 94X or Schedules H. |
| Medicare | The tax that finances hospital insurance. |
| MFREQ | An IDRS CC used to request an Entity Module or a Tax Module and its related Entity Data from IMF or BMF when case control is not required. |
| MFT | Master File Tax is a two-digit number code that identifies the type of return filed by the taxpayer. It will also show changes or adjustments made by the IRS as 47 or 54. |
| Name Control | The first 4 letters of the Taxpayer's Last Name (in the case of individuals) and the first 4 letter of the Business Name (in the case of Partnerships, Corporations etc.). The Name Control is used to check the Master File and assure that the TIN corresponds with the proper taxpayer. |
| ORS | Online Retrieval System - is a system in which the SSA uses to maintain data. ORS is used to research information from the SSA data base within 7 days of receipt to SSA. In the future ORS will supply the CAWR tax examiner with an image of what the taxpayer submitted to the SSA. |
| PCD | Program Completion Date - The date determined by Headquarters for the completion of specific program. |
| POA | Power of Attorney - Document used by taxpayers to have an authorized representative act on their behalf. This authority is normally granted when a Form 2848 is submitted to IRS. |
| RLN | Report Locator Number is assigned by SSA and is used to request AWR microfilm replacement document stored in ORS (Online Retrieval System). It is a 14 position number replacement for the 11 position microfilm reference number (MSN). The RLN is derived as follows:<br> <br>1. Positions 1-4: Year Assigned: CCYY<br>   <br>2. Positions 5–7: Day Assigned: Julian Date<br>   <br>3. Positions 8–9: Camera Number: AA-ZZ (electronic) or 01–99 (paper)<br>   <br>4. Positions 10–14: Sequence Number: 00001–99999 |
| Social Security | The tax that finances the old age, the survivors and the disability part of FICA (social security). |
| Source Document | Backup documentation used by IRS Personnel to explain an adjustment to a Taxpayer's Account, for example: taxpayer correspondence. |
| SSA | The Social Security Administration is the nation's primary income security agency. It pays retirement, disability and survivors benefits to workers and their families, administers the Supplemental Security Income program and issues Social Security numbers. |
| SSA-CAWR | Social Security Administration Case - Cases identified by the SSA and referred to the IRS to obtain any Forms W-2 not filed from the taxpayer. |
| SSN | Social Security Number: A nine digit number used to identify an Individual Taxpayer Account in NNN-NN-NNNN format issued by the SSA. |
| Status Code (SC) | Two digit number code indicating the Master File and/or IDRS Status on a Tax Module. |
| STAUP | Used to interrupt normal notice routine by delaying, accelerating or skipping notices. |
| TAS | The Taxpayer Advocate Service (TAS) is an independent organization within the **IRS that helps taxpayers and protects taxpayer rights. TAS employees assist taxpayers who are experiencing economic harm, who are seeking help in resolving tax problems not resolved through normal channels, or who believe that an IRS system or procedure is not working as it should. Refer to IRM part 13**, Taxpayer Advocate Service,**for more TAS information.** |
| Tax Module | Part of a taxpayer's account which reflects tax data for one tax class (MFT) and one tax period.<br> <br>### Example:<br>A taxpayer has filed 12 Forms 941 and 3 Forms 940 within a three year period. They have only one account on the Master File, but 15 modules. |
| Tax Period | The period of time for which a return is filed. The IRS uses a six digit code to indicate the end of the tax period for a given return. The first four digits represent the year and the next two digits represent the month. |
| TC | Transaction Code - A three digit code used to identify actions being taken to a Taxpayer's Account on IDRS. |
| TC 470 | Used to delay issuance of a TDA notice and to stop offsets into an account because of a pending claim or adjustment. |
| TDA | Taxpayer Delinquent Account - A computer generated printout indicating that the taxpayer's account has reached a delinquent status. |
| TIN | Taxpayer Identification Number - Every taxpayer on the master file has a permanent number for identification of the tax account. The employer identification number (EIN) is used to identify a taxpayer's business account. The social security number (SSN) is used as the account number for an individual taxpayer. |
| TY | The tax year is an annual accounting period, usually made up of 12 consecutive months. |

**Exhibit 1.4.22-2**

### Assigned Case Status Codes

These are the Status codes used for assigned cases in IRS-CAWR.

| **Status Code** | **IRS-CAWR** |
| --- | :-: |
| 08 | OPEN\_ASSIGN\_SSA\_1 |
| 16 | OPEN\_LTR\_99\_AUTO |
| 24 | OPEN\_UNDELIVERABLE - IRS |
| 28 | OPEN\_LTR\_99 (Manually generated Letter 99-C) |
| 37 | OPEN\_NO\_RESPONSE (Open No Reply - IRS CAWR) |
| 44 | OPEN\_REPLY\_RECV (Open Reply Received - IRS CAWR) |

These are the Status codes used for assigned cases in SSA-CAWR.

| **Status Code** | **SSA-CAWR** |
| --- | --- |
| 13 | OPEN\_NO\_RESPONSE (Open No Reply - SSA CAWR) |
| 69 | OPEN\_LTR\_98 (Open Manually generated Letter 98-C) |
| 87 | CLS\_BMF\_IN\_BALANCE ( Closed SSA Indicator 2 in Balance) |
| 90 | OPEN\_LTR\_98\_AUTO (Open Auto Letter 98-C issued - SSA CAWR) |
| 92 | OPEN\_REPLY\_RECV (Open Reply Received - SSA CAWR) |
| 93 | OPEN\_UNDELIVERABLE - SSA |

These are the Status codes used for assigned cases in IRS and SSA CAWR

| **Status Code** | **BOTH IRS and SSA-CAWR** |
| --- | --- |
| 10 | OPEN\_SUSPENSE\_MISC |
| 21 | OPEN\_FED\_CORRESP (Federal Entity w/Correspondence) |
| 25 | OPEN\_TXFER\_EXAM (open Transfer to Exam) |
| 26 | OPEN\_ERR\_NOREPLY (Open No Reply Error Case) |
| 27 | OPEN\_TXFER\_CI (Open transfer to Criminal investigation) |
| 29 | OPEN\_TXFER\_COLL (Open transfer to Collection) |
| 42 | OPEN\_LTR\_2057 (Open Letter 2057-C Issued) |
| 45 | OPEN\_MOD\_REQ (Open Re-analysis Requested) |
| 47 | OPEN\_LATE\_REPLY |
| 55 | Reserved |
| 67 | OPEN\_LTR\_INT (Open Reply First Interim letter Issued) |
| 68 | OPEN\_LTR\_INT\_LATE (Open Recon Interim letter issued) |
| 70 | OPEN\_LTR\_INT2 (Open Reply Second interim letter issued) |
| 71 | OPEN\_LTR\_INT2\_LATE (Open Recon Second interim letter issued) |
| 86 | REOPEN (Reopened Case) |
| 88 | OPEN (Opened Out Of Balance Case) |

**Exhibit 1.4.22-3**

### Closed Case Status Codes

These are the Status codes used for CAWR case screening closures.

| **Status Code** | **Screening Closures** |
| :-: | :-: |
| 11 | CLS\_BMF\_DELETE |
| 31 | CLS\_TXFER\_EXAM (Closed To EXAM) |
| 32 | CLS\_TXFER\_COLL (Closed to Collections) |
| 33 | CLS\_TXFER\_CI (Closed to CI) |
| 36 | CLS\_NO\_CHANGE (Closed in Screening - In Balance IRS CAWR) |
| 38 | CLS\_BMF\_MERGE (Closed BMF Merge) |
| 97 | CLS\_HQ (Closed by HQ Direction) |
| 98 | CLS\_UNRECONCILED (Closed Unreconciled IRS CAWR/SSA CAWR or TC 520/530) |
| 99 | CLS\_NO\_CHANGE (Closed in Screening - In Balance SSA CAWR) |

These are the Status codes used for CAWR case no reply closures.

| **Status Code** | **No Reply Closures** |
| --- | --- |
| 30 | CLS\_NO\_RESPONSE (Closed No Reply IRS CAWR) |
| 40 | CLS\_549\_VERIFIED (SSA Adjustment - 549 posted) |
| 41 | CLS\_DEFUNCT (SSA Adjustment Bankruptcy/Defunct) |
| 91 | CLS\_NO\_RESPONSE (Closed No Reply SSA CAWR) |
| 94 | CLS\_TOLERANCE (Closed No Reply (549 Tolerance) - SSA CAWR) |

These are the Status codes used for CAWR case undeliverable closures.

| **Status Code** | **Correspondence Issued Closures** |
| --- | --- |
| 39 | CLS\_UNDELIVERABLE (Closed Undeliverable - IRS CAWR) |
| 46 | CLS\_UNDELIVERABLE (Closed Undeliverable - SSA CAWR) |

These are the Status codes used for CAWR case response closures.

| **Status Code** | **Taxpayer Response Closures** |
| --- | --- |
| 34 | CLS\_TOL\_REPLY\_RCVD (Closed TC 290 .00 - IRS CAWR) |
| 35 | CLS\_NON\_AGREED (Closed TC 290 $$ - IRS CAWR) |
| 48 | CLS\_AGREED (Closed Agreed Assessment - IRS CAWR) |
| 49 | CLS\_RTN\_SECURED (Closed Tax Return Secured - IRS CAWR) |
| 89 | CLS\_PENALTY\_550 (Closed PRN 550 $$-SSA CAWR) |
| 95 | CLS\_TOL\_REPLY\_RCVD (Closed PRN 549.00 - SSA CAWR) |
| 96 | CLS\_NON\_AGREED (Closed PRN 549 $$ - SSA CAWR) |

**Exhibit 1.4.22-4**

### Profile Descriptions

This is a list of Profiles and profile descriptions that can be granted by the Site Coordinator.

| **USER** | **PROFILES GRANTED** | **DESCRIPTION/ DUTIES** | **WHO GRANTS** |
| :-: | :-: | :-: | :-: |
| Analyst | Analyst | - Can add other analyst and coordinator profiles<br>  <br>- Can manage cron job schedules<br>  <br>- Can restrict working certain batch types | Request must go through another analyst |
| Site Coordinator | Administrator and Developer | Has the same privileges as the CAWR Coordinator profile and Disaster Coordinator. Additional duties: Create New User, Set User Inactive, Reset User Password, Unlock User, Delete Users and any system updating. Request 98-C SSA and 99-C CAWR and controlling and monitoring loose W-2 / paper Schedule D. | Request must go through the Headquarters Analyst. |
| Manager | CAWR Coordinator | Has the same privileges as the CAWR Case Updates, CAWR Clerk, CAWR Research profiles. Other duties requested by Site Coordinator. Also can access system Reports | Administrator / Developer Coordinator, Requires a BEARS. |
| Tax Examiner | CAWR Case Updates | This will allow the user to take all actions on a case. (Send notices, close the case, and update various fields.) | Administrator/ Developer Coordinator. Requires a BEARS. |
| Clerks | CAWR Clerk | The user can perform clerical functions such as inputting reply dates, build batches, issue letters, or update other fields other than the date field. | Administrator/ Developer Coordinator. Requires a BEARS. |
| TAS, PAS etc. | CAWR Research | Read only access to CATRS. (Example PAS, TAS) | Administrator and Developer Coordinator. Requires a BEARS. |
| Disaster Coordinator | Disaster Coordinator | Has the functions as CAWR Coordinator, Case Update Access, Research, Clerk and can access reports. Inputs and monitors disaster data. | Administrator/ Developer Coordinator Requires a BEARS. |

**Exhibit 1.4.22-5**

### Physical Inventory Certificate

This is used to perform the Physical Inventory Certification.

| **Tax Examiner Name:** |
| --- |
| IDRS number: |
| Date of CCA 42-43: |
| Number of cases listed on your CCA 42-43: |

| **Action Taken** | **YES/NO** |
| :-: | :-: |
| Verify received dates are correct. | Yes/ No |
| Verify case was classified as correct program. | Yes/ No |
| Correct MFT was input. | Yes/ No |
| If case is missing, have followed the missing case procedure? | Yes/ No |
| Ensured all appropriate interim letters have been issued. | Yes/ No |
| Verified need for STAUPS and input if necessary. | Yes/ No |
| Ensured you are working your cases in **FIFO (First-In-First-Out) order**. | Yes/ No |
| Are cases in the correct status? (A-Assigned, M-Monitored, S-Suspense, etc) | Yes/ No |
| Are cases in the correct Activity and Category Codes. | Yes/ No |

| **Program (IRS-CAWR, SSA, FUTA)** | **Number of cases** |
| --- | --- |
| Cases listed on your CCA 42-43 | Number |
| Missing | Number |
| Closed | Number |
| Added (newly controlled) | Number |
| **TOTAL** | Number |

| **Number of cases currently in your possession:** |
| --- |
| I certify I have taken all actions stated above. |
| Print Name: |
| Sign Name: |
| Date: |

**Exhibit 1.4.22-6**

### Wall Inventory Instruction and Certification

This is used to perform the CAWR case wall inventory certification.

| **Print Name:** |
| --- |
| Sign Name: |
| Date: |

|     |
| --- |
| **Wall Instruction and Certification** |

Run the ORCAS CCA 42-43 by program (IRS-CAWR/SSA/). Each of the program listings will then be sorted by age beginning with the earliest received date. This will now simplify the process to verify each of the cases on your wall to the cases listed on the CCA 42-43 for the entire Operation.

By program, verify the count in each open batch listed in the log book matches with the CCA 42-43.

| **Program (IRS-CAWR, SSA, FUTA)** | **Number of Cases** |
| --- | --- |
| Cases listed on your CCA 42-43 | Number |
| Missing | Number |
| Closed | Number |
| Added (Newly Controlled) | Number |
| **Total** | Number |

I certify I have reviewed the process used to complete this physical inventory and am confident it reflects true volumes currently in the Operation. I certify the actions taken by the tax examiners are correct and warranted.

| **Department Manager Signature:** |
| --- |
| Date: |

| **Operation Manager Signature:** |
| --- |
| Date: |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-022#addtoany "Show all")

A2A