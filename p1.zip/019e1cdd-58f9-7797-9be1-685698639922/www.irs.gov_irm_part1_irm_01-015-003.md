---
url: "https://www.irs.gov/irm/part1/irm_01-015-003"
title: "1.15.3 Disposing of Records | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-015-003#main-content)

- 1.15.3  [Disposing of Records](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881949689760)
  - 1.15.3.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921540064)
    - 1.15.3.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881920841680)
    - 1.15.3.1.2  [Authority to Destroy Records](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921537968)
    - 1.15.3.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921079392)
    - 1.15.3.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921076992)
    - 1.15.3.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881920822464)
    - 1.15.3.1.6  [Acronyms and Terms](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881920819888)
    - 1.15.3.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921168992)
  - 1.15.3.2  [Destroying Records in the Custody of the IRS](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921591856)
  - 1.15.3.3  [Destruction Certification for Court Purposes](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921203328)
  - 1.15.3.4  [Unauthorized Disposition of Records](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921201376)
  - 1.15.3.5  [Emergency Disposal](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921189312)
  - 1.15.3.6  [Disposal Lists](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921307296)
  - 1.15.3.7  [Destruction of Records at the Federal Records Center (FRC)](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921303840)
  - 1.15.3.8  [Form 11671, Certificate of (In-house) Records Disposal](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921345136)
  - 1.15.3.9  [Sale of Records](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921337696)
  - 1.15.3.10  [Donation for Salvage](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921334208)
  - 1.15.3.11  [Donation for Preservation and Use](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921280832)
    - 1.15.3.11.1  [Reporting Donation of Records](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921273472)
  - 1.15.3.12  [Disaster Recovery Toolkit](https://www.irs.gov/irm/part1/irm_01-015-003#idm139881921270688)

# Part 1. Organization, Finance, and Management

# Chapter 15. Records and Information Management

# Section 3. Disposing of Records

* * *

## 1.15.3 Disposing of Records

#### Manual Transmittal

January 14, 2025

#### Purpose

(1) This transmits revised IRM 1.15.3, Records and Information Management, Disposing of Records.

#### Material Changes

(1) IRM references, website links, and editorial updates have been made throughout this IRM section.

#### Effect on Other Documents

IRM 1.15.3, dated October 13, 2023, is superseded.

#### Audience

All IRS divisions and functions.

#### Effective Date

(01-14-2025)

Michael J. Oser

Acting Director, Identity and Records Protection (IRP)

Privacy, Governmental Liaison and Disclosure (PGLD)

**1.15.3.1** **(01-14-2025)**

### Program Scope and Objectives

1. **Purpose:** Records are destroyed in accordance with Document 12990, Records Control Schedules (RCS), and Document 12829, General Records Schedule (GRS). In keeping with the mission of the Records and Information Management (RIM) Program to improve the quality of, document, protect, and efficiently manage all IRS records until final disposition, a local procedure has been developed to record all internal records disposals.

2. **Audience:** These procedures apply to **all** IRS employees and contractors.

3. **Program Owner:** The Records and Information Management (RIM) Program office, under Privacy, Governmental Liaison and Disclosure (PGLD) is the program office responsible for oversight of the Servicewide records management policy.

4. **Primary Stakeholders:** The Records and Information Management (RIM) Program office, under PGLD, promotes responsible recordkeeping practices for IRS employees and contractors to follow in accordance with federal laws, regulations, and procedures.


**1.15.3.1.1** **(08-04-2017)**

#### Background

1. Information protection is a vital concern to the IRS. Every effort must be made to ensure that all documents are provided protection commensurate with the information therein. Not all records disposals are conducted by the National Archives and Records Administration’s (NARA) Federal Records Centers (FRCs). Most IRS records disposal actions are actually performed in-house by various vendors under shredding contracts, or are conducted by IRS employees using federal equipment.


**1.15.3.1.2** **(10-13-2023)**

#### Authority to Destroy Records

1. The Archivist of the United States is the sole authority for destruction of all federal records, 44 United States Code (USC) as codified in 36 Code of Federal Regulations (CFR) Chapter XII. Records may only be destroyed in accordance with authorized instructions found in Document 12990, IRS Records Control Schedules (RCS) and Document 12829, General Records Schedules (GRS).



### Note:



Site audit records are subject to the Government Accountability Office (GAO) disposal authority. Therefore, maintain and destroy these records according to GAO requirements found in Document 12829, General Records Schedules (GRS).

2. Document 12829, General Records Schedules

3. Document 12990, Records Control Schedules

4. 44 USC Chapter 33, Disposal of Records

5. 36 CFR Chapter XII, Subchapter B - Part 1226.26, How do agencies donate temporary records?

6. 36 CFR Chapter XII, Subchapter B - Part 1230, Unlawful or Accidental Removal, Defacing, Alternation, or Destruction of Records

7. Internal Revenue Code (IRC) [6103](https://www.govinfo.gov/content/pkg/USCODE-2011-title26/pdf/USCODE-2011-title26-subtitleF-chap61-subchapB-sec6103.pdf), _Confidentiality and disclosure of returns and return information_


**1.15.3.1.3** **(08-04-2017)**

#### Responsibilities

1. This IRM is used by **all** IRS employees and contractors to ensure compliance with paper and electronic records management requirements.


**1.15.3.1.4** **(10-13-2023)**

#### Program Management and Review

1. The RIM Program is evaluated using the following reviews and reports:



   - **Records Management Self-Assessment (RMSA)**: The annual RMSA asks questions that assess compliance with records management statutes and regulations, as well as NARA policies and guidance.

   - **Federal Electronic Records and Email Management Reporting**: This report not only evaluates federal agency email management, it also seeks to assess the current state of all electronic records management at federal agencies (including email and permanent electronic records).

   - **Senior Agency Official for Records Management (SAORM) Annual Report**: This report gathers data on agency progress towards the goals of the OMB/NARA Update to Transition to Electronic Records memo (M-23-07) and other important records management initiatives as identified by NARA.

   - **Form 14377, Records and Information Management Virtual Program Review Self Assessment Checklist**: This checklist is utilized as a self-assessment tool to assist the field site offices with records management policies and procedures. In addition, it measures RIM goals to stimulate better fiscal management.

   - **Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist**: PGLD requires all business unit information resource coordinator (IRC) contacts to complete this form on a quarterly basis. The purpose of the form is to ensure and document IRS recordkeeping compliance as defined by NARA. Completing the Form 14377-A identifies to PGLD:IRP:RIM potential gaps for training opportunities to assist the business unit with their recordkeeping responsibilities.


**1.15.3.1.5** **(10-13-2023)**

#### Program Controls

1. **Records Management Mandatory Briefing**: Every IRS employee and contractor must protect the information they handle daily to carry out their job responsibilities. They must annually take the Records Management Mandatory Briefing Integrated Talent Management (ITM) course #62965, Records Management Awareness, to ensure IRS records management is efficient, effective, and compliant with all applicable records management laws and regulations.


**1.15.3.1.6** **(10-13-2023)**

#### Acronyms and Terms

1. The table lists commonly used acronyms and terms:




| **Acronym** | **Term** |
| --- | --- |
| CFR | Code of Federal Regulations |
| FOIA | Freedom of Information Act |
| FRC | Federal Records Center |
| GAO | Government Accountability Office |
| GRS | General Records Schedules, Document 12829 |
| IM | Incident Management |
| IRC | Information Resource Coordinator |
| ITM | Integrated Talent Management |
| NARA | National Archives and Records Administration |
| PII | Personally Identifiable Information |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| RCS | Records Control Schedules, Document 12990 |
| RIM | Records and Information Management |
| RLR | Records Loss Reporting |
| USC | United States Code |


**1.15.3.1.7** **(10-13-2023)**

#### Related Resources

1. Employees will find helpful information on the following websites:



   - Records and Information Management SharePoint

   - [44 USC Chapter 33](https://www.archives.gov/about/laws/disposal-of-records.html), Disposal of Records

   - [36 CFR Chapter XII Subpart B](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Records Management codes

   - Document 12829, General Records Schedules

   - Document 12990, IRS Records Control Schedules

   - IRM 10.9.1, Classified National Security Information (CNSI)

   - Form 11671, Certificate of Records Disposal

   - Form 15035, Records Loss Reporting. Refer to the Records Loss SharePoint for further information on use of this form. Refer to the Internal Records Disposition and Procedures SharePoint for the processes used in carrying out in-house records destruction/deletion.

   - Form 15407, Electronic Recordkeeping System Compliance Assessment (eCA)

   - Form 15408, Digitization Validation Assessment


**1.15.3.2** **(10-13-2023)**

### Destroying Records in the Custody of the IRS

1. Determine the appropriate method to destroy records based on their category and format.




| **If the records include:** | **then:** |
| :-- | :-- |
| Tax data or Privacy Act information (tax returns, return information, copies of tax returns, charge-out documents for tax returns, microfilm registers, indexes and directories, and magnetic tape), or database files. | Choose one: shred, pulp, macerate, burn/incineration, or erase/overwrite. |
| Information which the unauthorized disclosure of could damage national security and is classified in accordance with Executive Order 13526, Classified National Security Information. | See IRM 10.9.1, Classified National Security Information (CNSI). |
| Material which does not require special protection or handling. | Treat as recyclable materials. |


**1.15.3.3** **(10-13-2023)**

### Destruction Certification for Court Purposes

1. Destruction Certification is documented on the NA13001, Notice of Eligibility for Disposal and Form 11671, Certificate of Records Disposal, to certify the destruction of IRS records for court purposes. Records Specialists are authorized to issue notarized destruction certifications after verification that a particular accession of records or that a particular record has been destroyed.


**1.15.3.4** **(10-13-2023)**

### Unauthorized Disposition of Records

1. Unauthorized disposition is the removal from the legal custody of the federal government or the alienation, alteration, or mutilation of records without regard to the provisions located in Document 12990, IRS Records Control Schedules (RCS) and Document 12829, General Records Schedules (GRS).



### Note:



The IRS is required to notify the Archivist at the National Archives and Records Administration (NARA), of any actual, impending, or threatened unlawful removal, defacing, alteration, corruption, deletion, erasure, or other destruction of records in the custody of the agency. (44 USC 3106(a))

2. The Records and Information Management (RIM) Program office manages the Records Loss Reporting (RLR) process for investigating, analyzing, and reporting IRS incidents involving the loss, theft, or destruction of records. Records loss is defined as the theft or unauthorized destruction, deletion, or removal of any record or device containing records under an employee’s control, which cannot be recreated or restored.

3. Immediately upon becoming aware of a loss, theft, or unauthorized destruction of a hardcopy or electronic record, contractors and IRS employees must report the loss using the Personally Identifiable Information (PII) Breach Reporting Form. The PGLD Incident Management (IM) office will review the PII Breach Reporting Form as outlined in IRM 10.5.4, Incident Management Program, and alert the PGLD RIM Program office that a suspected records loss has occurred. Upon receipt of the Records Loss Report from the IM office, RIM will contact the reporting point of contact to complete Form 15035, Records Loss Reporting. The RIM Program office will conduct an intake and risk assessment process that includes:



   - **Incident intake:** Receiving incident summaries sent to the \*Records Management Mailbox. Intake also includes performing an initial assessment to determine if an incident meets the definition of a records loss.

   - **Risk assessment:** Assessing risk to determine if records are retrievable or cannot be otherwise reconstructed.

   - **Records Loss Notification:** Notifying NARA of records loss, if necessary.

   - **Remediation:** Facilitating or partnering with affected records custodian to provide recommendations on preventing similar future occurrences.


4. Additionally, the penalty for loss or unauthorized destruction of federal records, whether paper or electronic, through negligence or carelessness can range from written reprimand to suspension or removal. See IRM 1.15.5, Relocating/Removing Records, for the penalties on unlawful removal, alienation, or destruction of government records. The IRS Records Officer must furnish a report to NARA after each confirmed incident of erroneous records destruction. Records Loss Reporting is included in the annual Records Management Mandatory Briefing, Integrated Talent Management (ITM) course 62965. Further information on the Records Loss Reporting process and Form 15035, Records Loss Reporting can be found at RIM’s Records Loss Reporting SharePoint.


**1.15.3.5** **(08-04-2017)**

### Emergency Disposal

1. Under certain conditions, records may be destroyed without regard to the IRS RCS. Also see [36 CFR 1229](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Emergency Authorization to Destroy Records.

2. Dangers to human life, health or to property:



1. When such records are identified, notify the IRS Records Officer, who will inform the IRS Commissioner, who will then notify NARA, specifying the nature of the records, their location and quantity, and the nature of the danger.

2. If NARA concurs, the Archivist of the United States will direct the immediate destruction of the records.



      ### Exception:



      If any still or motion picture film on nitrocellulose base has become soft, sticky, is emitting a noxious odor, contains gas bubbles, or has deteriorated to an acrid powder, the IRS Commissioner will, without prior NARA authorization, arrange for its destruction, whether by burial in landfills or by arranging for salvage destruction for its silver content when sufficient quantity warrants such salvage. In any case, such film must be removed from occupied buildings as soon as possible. Within 30 days after destruction, the IRS Records Officer will notify the IRS Commissioner and submit a written statement to NARA, College Park, Maryland, describing the film and showing when, where, and how destruction was accomplished.


3. State of war or threatened war:



1. Outside the territorial limits of the United States, records may be destroyed during a state of war between the United States and any other nation or when hostile action by a foreign power seems imminent. Only the IRS Commissioner may make such a determination and that the records' retention would be prejudicial to the United States' interests or are occupying space needed for military purposes and are without sufficient administrative, legal, research, or other value to warrant their continued preservation.

2. Within six months after the destruction, the IRS Commissioner will submit to NARA a written statement describing the character of any records destroyed and showing when and where destruction was accomplished.


**1.15.3.6** **(08-04-2017)**

### Disposal Lists

1. Disposal lists are for non-recurrent records. These lists provide one-time authority for the immediate disposal of existing records no longer accumulating and having no further value or no longer being created. These lists can be authorized only by the IRS Records Officer, and individual offices are responsible for notifying their Information Resource Coordinator (IRC) and Records Specialist of the need for such a list.



### Example:



Create and use disposal lists for administrative records associated with incomplete projects or programs, or for record series that are frozen for legal purposes and submit to the Records Specialist.

2. The IRS Records Officer will develop records disposition lists as required or based on information submitted by Records Specialists from the IRCs.


**1.15.3.7** **(10-13-2023)**

### Destruction of Records at the Federal Records Center (FRC)

1. When records at the FRC are eligible for destruction, the FRC issues a Form NA13001, Notice of Eligibility for Disposal, at least 90 days before the date the records are scheduled for destruction. The Records Specialists verify the information on the Forms against their reference copies of the SF-135 forms, Records Transmittal and Receipt, provided at the time of retirement. A copy of each NA13001 will be sent to the appropriate IRC for review and coordination. The IRC determines:




| **If the originating office:** | **then:** |
| :-- | :-- |
| Agrees with the upcoming disposal, | The IRC or appropriate manager signs and dates the copy of the NA13001 and returns them to the Records Specialist for action. The Records Specialist will keep the official copy for the IRS (SF-135 and NA13001). The Records Specialist will then forward a copy of the NA13001 to NARA, agreeing to the destruction of the identified records. |
| Still has a need for the records (typically due to pending litigation or when implementing office automation), | The IRC or the appropriate manager will submit written justification on the copy of the NA13001 to the Records Specialist within 60 days why the records will not be destroyed at this time. In addition, a new disposal date will be provided on the copy of the NA13001 by the Records Specialist based on the justification. The Records Specialist then forwards the NA13001 to the FRC. |

2. Agreements with the FRC Program will include requirements for compliance with physical security requirements for protection of [IRC 6103](https://www.govinfo.gov/content/pkg/USCODE-2011-title26/pdf/USCODE-2011-title26-subtitleF-chap61-subchapB-sec6103.pdf) records. NARA may use outside vendors to accomplish destruction of IRS records. These vendors will be obligated to comply with Section 6103 Non-Disclosure requirements for the protection of taxpayer and other records containing sensitive IRS information. These sites could be inspected by IRS Physical Security personnel prior to beginning a destruction of IRS records and will be subject to random and unannounced inspections thereafter.


**1.15.3.8** **(10-13-2023)**

### Form 11671, Certificate of (In-house) Records Disposal

1. IRS Form 11671, Certificate of Records Disposal, documents the in-house disposition of original paper and electronic IRS records. Some series of IRS records are maintained throughout their entire life cycle in a single office or in IRS maintained space (including non-recordkeeping electronic systems) rather than retired to a FRC. The recurring series of records that fall under this category must be identified prior to destruction or deletion. If they are required for work purposes, for Freedom of Information Act (FOIA) requesting or Congressional requesting purposes, or be needed for court purposes, the IRS would have to identify the exact date when the records were destroyed and under what authority. IRS Form 11671 will be used to identify the office of record, the manager or managers approving the disposal, the series/system being disposed, the RCS/GRS and Item Number, the inclusive dates of the records, the volume (number of boxes being destroyed or amount of data being deleted), and the date of the destruction. IRS records, paper or electronic, series being destroyed or deleted in-house (with exceptions, see below) will be documented in this manner. Completed IRS Form 11671, Certificate of Records Disposal will be forwarded to the Records Specialist assigned to the Post of Duty for processing. Refer to the SharePoint site on completing Form 11671 before destroying in-house documents.

2. The in-house destruction/deletion of non-record copies, including reference copies, does not require the completion of Form 11671.

3. The deletion of electronic records managed in approved recordkeeping systems (such as email and SETR) do not require the completion of Form 11671. Form 11671 is not required to destroy the original source records if Form 15408, Digitization Validation Assessment, has been completed.

4. Form 15407, Electronic Recordkeeping System Compliance Assessment (eCA), is used by the RIM Program office to assess if an electronic information system that produces, uses, or stores official IRS records is compliant with NARA’s scheduling and electronic records management requirements (e.g., disposal, reporting). System owner/managers will need to work with the RIM Program office to complete Form 15407 in order to determine if the system is approved for recordkeeping. If the disposal, reporting, and audit trail requirements are not met, system owners/managers may need to document disposal actions on Form 11671.

5. Form 15408 is used to validate that the digitized versions of the original source records meet all digitization technical, metadata, repository, scheduling, and other requirements before approval can be given to destroy the original source records. The RIM Program office approved use of Form 15408, Digitization Validation Assessment, to validate that the digitized versions of original source records (from digitization projects and/or operations) meet all digitization technical, metadata, repository, scheduling, and other requirements before approval can be given, to destroy the original source records.

6. Guidance on the use of Form 11671 and the processes for carrying out in-house records destruction/deletion are available on the Records and Information Management (RIM) Program SharePoint, or by contacting the IRS Records office at the \*Records Management Mailbox.


**1.15.3.9** **(11-01-2013)**

### Sale of Records

1. When possible, paper records will be sold as waste. The contract for the sale will prohibit resale or use as records or documents and will prohibit brokerage sales of shredded documentation to foreign located entities. The contract will further state that records containing protected information, such as taxpayer or privacy act data, will be destroyed beyond legibility or reconstruction. See the Physical Security Handbook for approved methods of destruction, e.g., shredding, burning, or pulping. All sites where IRS paper is shredded, macerated, pulped, or burned, will be available for inspection by Disclosure personnel.

2. The Privacy Act Notification and the clause entitled Privacy Act, see 48 CFR Subpart 24.1, 48 CFR 52.224–1, 52.224–2, and 31 CFR Subtitle A, Part 1, Subpart C, must also be included in the contract. If the material is removed from the IRS facility under circumstances that prohibit immediate destruction, the container used for removal must lock in such a manner that a seal may be applied. The seal will then be removed by the witnessing IRS employee at the time of destruction.


**1.15.3.10** **(11-01-2013)**

### Donation for Salvage

1. For small quantities, paper records may be donated to local public or non-profit institutions or agencies for the purposes of recycling. IRS personnel must take the necessary precautions to ensure that the materials are not sold as documents and that the interests of the United States and of private individuals are protected. In all cases, donations of records must be approved and authorized by the IRS Records Officer prior to transferring of the records for these purposes.


**1.15.3.11** **(11-01-2013)**

### Donation for Preservation and Use

1. To serve the public interest, the IRS may donate records authorized for disposal to another government agency, organization, institution, corporation or person that has made application for them. The following terms must be met:



1. The proposed recipient agrees not to sell the records as records or documents;

2. The donation is made without cost to the United States government;

3. The records do not contain information, the disclosure of which is prohibited by law or would be contrary to the public interest (no [IRC 6103](https://www.govinfo.gov/content/pkg/USCODE-2011-title26/pdf/USCODE-2011-title26-subtitleF-chap61-subchapB-sec6103.pdf) records may be donated under this purpose);

4. Donations to a foreign government will not be approved unless such a government has an official interest in the records which is amenable to that of the United States government; and

5. Donations to persons or commercial businesses will not be approved unless the records are directly related to the custody or operation of properties acquired from the United States government.


2. If, in the opinion of management officials the donation is acceptable, approval of the proposed donation must be obtained through:



1. Local management officials and

2. The IRS Records Officer.


**1.15.3.11.1** **(08-04-2017)**

#### Reporting Donation of Records

1. The IRS Records Officer will request approval of each donation of records from NARA as required by [36 CFR Part 1226.26](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), How do agencies donate temporary records? Upon approval or denial, the IRS Records Officer will notify the requestor of the appropriate action to be taken. In the case of denial, the records must be destroyed in accordance with the appropriate IRS Records Control Schedule.


**1.15.3.12** **(08-04-2017)**

### Disaster Recovery Toolkit

1. Refer to Disaster Recovery Policies on the Privacy, Governmental Liaison and Disclosure, Records and Information Management SharePoint to gain information regarding lost, destroyed or damaged records recovery procedures: Disaster Recovery Toolkit.

2. Report damaged or lost records immediately to the Records Management staff or simply send an email to \*Records Management.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-015-003#addtoany "Show all")

A2A