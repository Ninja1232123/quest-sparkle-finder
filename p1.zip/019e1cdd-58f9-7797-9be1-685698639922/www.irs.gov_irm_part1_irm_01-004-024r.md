---
url: "https://www.irs.gov/irm/part1/irm_01-004-024r"
title: "1.4.24 Central Withholding Agreement Program Team Manager Handbook | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-024r#main-content)

- 1.4.24  [Central Withholding Agreement Program Team Manager Handbook](https://www.irs.gov/irm/part1/irm_01-004-024r#id1)
  - 1.4.24.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-024r#id2)
    - 1.4.24.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-024r#id4)
    - 1.4.24.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-024r#id5)
    - 1.4.24.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-024r#id6)
    - 1.4.24.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-024r#id7)
    - 1.4.24.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-024r#id8)
    - 1.4.24.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-024r#id9)
    - 1.4.24.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-024r#id10)
  - 1.4.24.2  [CWA Team Manager Expectations](https://www.irs.gov/irm/part1/irm_01-004-024r#id11)
    - 1.4.24.2.1  [Guiding and Evaluating Employees](https://www.irs.gov/irm/part1/irm_01-004-024r#id13)
    - 1.4.24.2.2  [Case and Workload Reviews](https://www.irs.gov/irm/part1/irm_01-004-024r#id14)
    - 1.4.24.2.3  [Statistical Data Use](https://www.irs.gov/irm/part1/irm_01-004-024r#id15)
  - 1.4.24.3  [Workload Management](https://www.irs.gov/irm/part1/irm_01-004-024r#id16)
    - 1.4.24.3.1  [Case Assignments](https://www.irs.gov/irm/part1/irm_01-004-024r#id17)
    - 1.4.24.3.2  [Case Inventory Management Systems](https://www.irs.gov/irm/part1/irm_01-004-024r#id18)
    - 1.4.24.3.3  [CWA Approval](https://www.irs.gov/irm/part1/irm_01-004-024r#id19)
    - 1.4.24.3.4  [Addendum Reviews](https://www.irs.gov/irm/part1/irm_01-004-024r#id20)
      - 1.4.24.3.4.1  [Addendum for Added Events](https://www.irs.gov/irm/part1/irm_01-004-024r#id22)
      - 1.4.24.3.4.2  [Addendum for Non-performance](https://www.irs.gov/irm/part1/irm_01-004-024r#id23)
      - 1.4.24.3.4.3  [Program Manager Addendum Approvals](https://www.irs.gov/irm/part1/irm_01-004-024r#id24)
    - 1.4.24.3.5  [Policy Closure and Rescission Letter Approvals](https://www.irs.gov/irm/part1/irm_01-004-024r#id25)
    - 1.4.24.3.6  [Final Accounting Approvals](https://www.irs.gov/irm/part1/irm_01-004-024r#id26)
    - 1.4.24.3.7  [Site Visits](https://www.irs.gov/irm/part1/irm_01-004-024r#id27)
    - 1.4.24.3.8  [Closed Case Procedures](https://www.irs.gov/irm/part1/irm_01-004-024r#id28)
    - 1.4.24.3.9  [Case Control Procedures](https://www.irs.gov/irm/part1/irm_01-004-024r#id29)
  - 1.4.24.4  [Data Management and Reports](https://www.irs.gov/irm/part1/irm_01-004-024r#id30)
  - 1.4.24.5  [Customer Satisfaction](https://www.irs.gov/irm/part1/irm_01-004-024r#id31)
    - 1.4.24.5.1  [Communicating with Taxpayers and Stakeholders](https://www.irs.gov/irm/part1/irm_01-004-024r#id32)
    - 1.4.24.5.2  [Employee Protection](https://www.irs.gov/irm/part1/irm_01-004-024r#id33)
    - 1.4.24.5.3  [Authorized Representatives](https://www.irs.gov/irm/part1/irm_01-004-024r#id34)
    - 1.4.24.5.4  [Processing Delays](https://www.irs.gov/irm/part1/irm_01-004-024r#id35)
      - 1.4.24.5.4.1  [Withholding Agent Eligibility](https://www.irs.gov/irm/part1/irm_01-004-024r#id37)
      - 1.4.24.5.4.2  [Taxpayer Concerns or Complaints](https://www.irs.gov/irm/part1/irm_01-004-024r#id38)
  - 1.4.24.6  [General Team Management](https://www.irs.gov/irm/part1/irm_01-004-024r#id39)
    - 1.4.24.6.1  [Integrated Data Retrieval System (IDRS)](https://www.irs.gov/irm/part1/irm_01-004-024r#id41)
    - 1.4.24.6.2  [Time Approval Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-024r#id42)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 24. Central Withholding Agreement Program Team Manager Handbook

* * *

## 1.4.24 Central Withholding Agreement Program Team Manager Handbook

#### Manual Transmittal

February 05, 2026

#### Purpose

(1) This transmits revised IRM 1.4.24, Resource Guide for Managers - Central Withholding Agreement Program Team Manager Handbook, and is intended to supplement IRM 1.4.1, Resource Guide for Managers, Management Roles and Responsibilities.

#### Material Changes

(1) The section title was changed to from Central Withholding Agreement Program Group Manager Handbook to Central Withholding Agreement Program Team Manager Handbook.

(2) IRM 1.4.24.1, Program Scope and Objectives - Added the following paragraphs to conform to current standards in IRM 1.11.2.2.4, Address Management and Internal Controls:

1. Paragraph (3), Policy Owner

2. Paragraph (4), Program Owner

3. Paragraph (5), Primary Stakeholders

4. Paragraph (6), Contact Information


(3) IRM 1.4.24.1.1, Background - Added section to conform to standards in IRM 1.11.2.2.4, Address Management and Internal Controls.

(4) IRM 1.4.24.1.2, Authority - Added section to conform to standards in IRM 1.11.2.2.4, Address Management and Internal Controls.

(5) IRM 1.4.24.1.3, Roles and Responsibilities - Renumbered from IRM 1.4.24.1.1 due to the creation of new sections and updated with new roles and responsibilities as follows:

1. Paragraph (1) - Updated the senior executive responsible for the international division to the LB&I Deputy Commissioner.

2. Paragraph (2) - Updated the executive responsible for the WEIIC area to the Director of WEIIC.

3. Paragraph (3) - Added responsibilities of DFO, FPP and removed reference to CWA group manager.

4. Paragraph (4) - Added responsibilities for the FPP Program Office manager.

5. Paragraph (5) - Added responsibilities for the CWA FLM.


(6) IRM 1.4.24.1.4, Program Management and Review - Renumbered from IRM 1.4.24.1.2 due to the creation of a new sections and expanded the tools used to monitor the CWA program. Removed reference to IRM 4.64.1.1.4, Program Management and Review.

(7) Added the following IRM subsections to conform to standards in IRM 1.11.2.2.4, Address Management and Internal Controls:

| **IRM Section** | **IRM Section Title** |
| --- | --- |
| 1.4.24.1.5 | Program Controls |
| 1.4.24.1.6 | Terms and Acronyms |
| 1.4.24.1.7 | Related Resources |

(8) IRM 1.4.24.2, CWA Team Manager Expectations - Updated expectations for the team manager to include compliance with provisions of section 1204 of the Restructuring and Reform Act of 1998 and added annual commitments in the CWA FLM’s performance plan.

(9) IRM 1.4.24.2.1, Guiding and Evaluating Employees - Updated references in paragraphs (1) and (2) as follows:

1. Paragraph (1) - Changed "In process" to "Open case and workload reviews."

2. Paragraph (1) - Changed "Integrated Collection System (ICS) location code" to "CWA CIM application status code."

3. Paragraph (1) - Added site visits as a type of review to monitor.

4. Paragraph (2) - Added reference to IRM 6.430.1, Performance Management Requirements.


(10) IRM 1.4.24.2.1.1, Performance Feedback - Case Reviews -Removed IRM section. Moved content to IRM 1.4.24.2.2, Case and Workload Reviews to reflect changes made in the review process of the program.

(11) IRM 1.4.24.2.2, Case and Workload Reviews - Renumbered from IRM 1.4.24.2.1.1, Performance Feedback - Case Reviews to better align with the subtopic and updated content to reflect changes made to the program's review process. Added reference to IRM 6.430.1, Performance Management Requirements.

(12) IRM 1.4.24.2.3, Statistical Data Use - Renumbered from IRM 1.4.24.4.2, Use of Statistical Data.

(13) IRM 1.4.24.3, Workload Management - Updated responsibilities of the team manager as follows:

1. Paragraph (4) - Added reference to the Electronic Case Folder when the CWA FLM transfers cases and added procedures for CWA FLM relating to modifications to the current inventory assignment plan.

2. Paragraph (5) - Updated wording for clarification.


(14) IRM 1.4.24.3.1, Case Assignments - Expanded the responsibilities of the team manager for assigning and monitoring various application cases.

(15) IRM 1.4.24.3.2, Case Inventory Management Systems - Changed title from "Updating Case Inventory Control Systems" and updated the responsibilities of the CWA FLM for reviewing case inventory.

(16) IRM 1.4.24.3.3, CWA Approval - Updated the process to approve CWA applications for the team manager. Changed reference from "current delegation order" to Delegation Order LB&I 1-23-10.

(17) IRM 1.4.24.3.4, Addendum Reviews - Changed title from "Addendum" and updated the review procedures when the CWA FLM receives an addendum for a Standard or Formal Standard CWA application.

(18) IRM 1.4.24.3.4.1, Addendum for Added Events - Changed title from "Addendum - CWA Executed" and:

1. Paragraph (1) - Updated the review process procedures for an addendum that adds an event to a Standard or Formal Standard CWA itinerary.

2. Paragraph (2) - Added paragraph to provide criteria for the CWA FLM to follow when approving a Standard CWA addendum.


(19) IRM 1.4.24.3.4.2, Addendum for Non-performance - Changed title from "Addendum - Event(s) Cancelled" and:

1. Paragraph (1) - Updated team manager review procedures for a Standard or Formal Standard CWA when there is a non-performance at an itinerary event.

2. Paragraph (2) - Added paragraph to provide criteria for the CWA FLM to follow when approving a Standard CWA addendum related to non-performance.


(20) IRM 1.4.24.3.4.3, Program Manager Addendum Approvals - Updated title from "Addendum - Approval" and added paragraph (2) to indicate when it is required for the CWA FLM to send a CWA addendum to the PM.

(21) IRM 1.4.24.3.5, Policy Closure and Rescission Letter Approvals - Added "Approvals" to title and added references to Form 13930, Central Withholding Agreement Application and Form W-9, Request for Taxpayer Identification Number and Certification. Updated IRM reference to IRM 4.64.1.5.9, Policy Closure. Updated the approval process for issuing closure and rescission letters.

(22) IRM 1.4.24.3.6, Final Accounting Approvals - Added "Approvals" to title and updated wording for clarification of approval procedures. The following changes were made:

1. Paragraph (e) - Replaced paragraph content to separate artist from athlete in paragraph (d). Replaced the term entertainer with Artist.

2. Paragraph (f) - Removed content related to CWA group manager and replaced with content from paragraph (e).


(23) IRM 1.4.24.3.7, Site Visits - Updated wording for clarification and added that the CWA FLM must review all site visits submitted by an employee assigned no later than 10 days prior to the event date. Added that the CWA FLM must complete the review and approval of the Site Visit Request form.

(24) IRM 1.4.24.3.8, Closed Case Procedures - Changed title from "Closing Case" and:

1. Paragraph (1) - Updated deadlines for CWA CIM application closures and added reference to Form 13930.

2. Paragraph (2) - Added steps for CWA FLM relating to placing a closed case in an ECF and added a review and notification process for the CWA FLM relating to closed cases.


(25) IRM 1.4.24.3.9, Case Control Procedures - Updated wording in paragraph (1) for clarification. Added paragraph (2) to indicate that the CWA FLM is responsible for deleting the copied cases from all audit locations.

(26) IRM 1.4.24.4, Data Management and Reports - Changed title from "Data Gathering and Measurement (Reports)" and updated CWA FLM responsibilities relating to data management and reports the CWA FLM must provide.

(27) IRM 1.4.24.4.1, Month End Report - Removed IRM section and combined with IRM 1.4.24.4, Data Management and Reports.

(28) IRM 1.4.24.4.2, Use of Statistical Data - Removed IRM section and moved content to IRM 1.4.24.2.3, Statistical Data Use.

(29) IRM 1.4.24.5, Customer Satisfaction - Added reference to IRM 4.10.1.2.1, Taxpayer Bill of Rights (TBOR).

(30) IRM 1.4.24.5.1, Communicating with Taxpayers and Stakeholders - Changed title from "Dealing with Taxpayers and External Customers" and updated wording for clarification. Provided link to Paperwork Reduction Act for reference.

(31) IRM 1.4.24.5.2, Employee Protection - Changed title from "Potentially Dangerous Taxpayer (PDT) and Caution Upon Contact (CAU) Programs" and added reference to the Office of Employee Protection site.

(32) IRM 1.4.24.5.3, Authorized Representatives - Changed title from "Management Responsibility Regarding Right of Representation" and added reference to Form 2848, Power of Attorney and Declaration of Representative and Form 8821, Tax Information Authorization when verifying an authorized representative.

(33) IRM 1.4.24.5.4, Processing Delays - Changed title from "Procrastinating Taxpayers, Representatives, and Withholding Agents" and:

1. Paragraph (1) - Updated wording for clarification.

2. Paragraph (2) - Provided steps for CWA FLM to avoid delays.

3. Paragraph (3) - Provided steps for CWA FLM when performing a case review.


(34) IRM 1.4.24.5.4.1, Withholding Agent Eligibility - Changed title from "Withholding Agent Considerations" and updated wording for clarification.

(35) IRM 1.4.24.5.4.2, Taxpayer Concerns or Complaints - Updated wording for clarification.

(36) IRM 1.4.24.5.4.3, CWA E-mail box - Removed this IRM section and combined it as a related resource in IRM 1.4.24.1.7(8).

(37) IRM 1.4.24.6, General Team Management - Changed title from "General Group Management Issues" and updated wording for clarification.

(38) IRM 1.4.24.6.1, Integrated Data Retrieval System (IDRS) - Updated wording for clarification. Changed reference from online 5081 certification to Business Entitlement Access Request System (BEARS) entitlement certification.

(39) IRM 1.4.24.6.2, Time Approval Responsibilities - Changed title from "Time Accounting Responsibilities" and updated wording for clarification. Also, updated IRM reference to IRM 1.4.40.3.8, Time Accounting Responsibilities.

(40) Throughout: Replaced **group** with **team** and **group manager** with **team manager** to reflect terms currently being used in the program.

(41) Made various editorial changes throughout the IRM. Reviewed and updated website addresses, legal references and IRM references, as necessary throughout the IRM.

#### Effect on Other Documents

IRM 1.4.24, dated July 13, 2020 is superseded.

#### Audience

Team managers in the Large Business and International (LB&I) Central Withholding Agreement (CWA) program.

#### Effective Date

(02-05-2026)

Ronald H. Hodge II

Assistant Deputy Commissioner Compliance Integration

Large Business and International Division

**1.4.24.1** **(02-05-2026)**

### Program Scope and Objectives

1. **Purpose**: This IRM discusses responsibilities for managers in the Central Withholding Agreement (CWA) program. This IRM is a supplement to the general guidelines for all team managers contained in IRM 1.4.1, Resource Guide for Managers, Management Roles and Responsibilities.

2. **Audience**: This IRM applies to CWA team managers.

3. **Policy Owner**: LB&I Policy under the Strategy, Policy & Governance (SPG) office in the Assistant Deputy Commissioner Compliance Integration (ADCCI) organization and Director, Withholding Exchange & International Individual Compliance (WEIIC).

4. **Program Owner**: Program Office manager (PM), Foreign Payments Practice (FPP).

5. **Primary Stakeholders**: CWA front-line managers (FLMs), tax specialists, revenue agents, tax examining technicians, and tax analysts.

6. **Contact Information**: To recommend changes or to make any other suggestions to this IRM section, contact the IRM author or see SPDER’s IMD Contacts list by referencing guidelines provided in IRM 1.11.6.5, Providing Feedback About an IRM Section - Outside of Clearance. A request or inquiry can also be made at LB&I Policy Gateway.


**1.4.24.1.1** **(02-05-2026)**

#### Background

1. This IRM contains procedures, guidance, and information for a CWA FLM. The content includes general administrative responsibilities and expectations, workload management, measurements for reporting, and customer satisfaction.

2. IRM 4.64.1.1.1, Background includes information about the CWA program and its mission.


**1.4.24.1.2** **(02-05-2026)**

#### Authority

1. IRC 1441 , Withholding of Tax on Nonresident Aliens

2. IRC 1446, Withholding of Tax on Foreign Partners' Share of Effectively Connected Income

3. 26 CFR 1.1441-4(b)(3), Withholding Agreements

4. Rev. Proc. 89-47, 1989-2 C.B. 598

5. Rev. Rul. 1974-330, 1974-2 C.B. 278

6. IRM 1.2.63.2.10, Delegation Order LB&I 1-23-10, Authority to Grant and Withhold Exemption from Withholding on Nonresident Aliens and Issue Final Exemption Payment Letter


**1.4.24.1.3** **(02-05-2026)**

#### Roles and Responsibilities

1. The LB&I Deputy Commissioner is the senior executive responsible for the WEIIC practice area.

2. The Director of WEIIC is the executive responsible for FPP field operations.

3. The Director of Field Operations (DFO), FPP is the executive responsible for the FPP Program Office.

4. The FPP Program Office manager is the senior manager responsible for the CWA Program and:



1. Serves as a role model

2. Encourages change

3. Provides suggestions to implement new policies and procedures


5. The CWA FLM is responsible for a team of employees and takes the following actions to provide direction and leadership:



1. Supervises the assignment of Directed Withholding Letter (DWL) and CWA application cases,

2. Oversees the processing of assigned DWL and CWA application cases for compliance with applicable guidance,

3. Recommends new or modified policies and procedures,

4. Assists with the development and implementation of CWA program changes,

5. Empowers employees through training, additional responsibilities, and leadership opportunities,

6. Serves as a mentor and role model by transferring knowledge and skills, and

7. Ensures that team employee actions align with the communicated missions of the IRS and the CWA program.


**1.4.24.1.4** **(02-05-2026)**

#### Program Management and Review

1. The CWA program monitors case inventories using various data sources and tools including:



01. CWA Program Portal (PP) site containing SharePoint lists and document libraries

02. CWA Case Inventory Management (CIM) application

03. CWA Group Assignment list and reports

04. CWA Applicant Assignment list and reports

05. DWL list and reports

06. Venue and Facilities list and reports

07. Event list and reports

08. Festivals list and reports

09. Agents list and reports

10. Ineligible Designated Withholding Agent list

11. Site Visit list and reports


2. The CWA program measures compliance with assigned goals using various data sources and tools including:



1. Case Status reports and online dashboards

2. Open and Closed Case reports

3. Monthly and Quarterly reports

4. Assignment rotation documents

5. Site visit log

6. Archived Assignment Grid files

7. Archived Integrated Collection System (ICS) case histories


**1.4.24.1.5** **(02-05-2026)**

#### Program Controls

1. The CWA program has developed controls to oversee the program including:



1. CWA PP site

2. CWA CIM application

3. Case Status reports and online dashboards

4. Open and Closed Case reports

5. Monthly and Quarterly reports

6. Site visit log


2. The CWA program is evaluated through independent quality reviews of DWL and CWA application cases.


**1.4.24.1.6** **(02-05-2026)**

#### Terms and Acronyms

1. The table lists commonly used acronyms and their definitions:




| **Acronym** | **Definition** |
| --- | --- |
| ADCCI | Assistant Deputy Commissioner Compliance Integration |
| BEARS | Business Entitlement Access Request System |
| CIM | Case Inventory Management |
| CWA | Central Withholding Agreement |
| DFO | Director of Field Operations |
| DIM | Digital Inventory Management |
| DWA | Designated Withholding Agent |
| DWL | Directed Withholding Letter |
| ECF | Electronic Case Folder |
| FLM | Front-line Manager |
| FPP | Foreign Payments Practice |
| ICS | Integrated Collection System |
| IDR | Information Document Request |
| IDRS | Integrated Data Retrieval System |
| NRA | Nonresident Alien |
| PM | Program Office Manager |
| PP | Program Portal |
| SETR | Single Entry Time Recording |
| SPG | Strategy, Policy & Governance |
| TBOR | Taxpayer Bill of Rights |
| WEIIC | Withholding Exchange & International Individual Compliance |


**1.4.24.1.7** **(02-05-2026)**

#### Related Resources

01. Pub 515, Withholding of Tax on Nonresident Aliens and Foreign Entities

02. IRM 4.64.1, Central Withholding Agreement (CWA) Program

03. IRM 21.8.2.12.13, Central Withholding Agreements

04. [IRS.gov](https://www.irs.gov/irm/part1/www.irs.gov) references and web pages including:



    1. [Central Withholding Agreements](https://www.irs.gov/individuals/international-taxpayers/central-withholding-agreements)

    2. [Frequently Asked Questions (FAQs) About Foreign Artist and Athlete Withholding](https://www.irs.gov/individuals/international-taxpayers/frequently-asked-questions-faqs-about-central-withholding-agreements)

    3. [Help for Foreign Artists and Athletes](https://www.irs.gov/businesses/international-businesses/help-for-foreign-athletes-and-entertainers)

    4. [Taxation of Foreign Artists and Athletes](https://www.irs.gov/individuals/international-taxpayers/taxation-of-foreign-artists-and-athletes)

    5. [Withholding of Tax on Payments to Foreign Artists and Athletes](https://www.irs.gov/individuals/international-taxpayers/withholding-of-tax-on-payments-to-foreign-athletes-and-entertainers)


05. CWA News and Information List subscription

06. [Central Withholding Agreement Program](https://irsgov.sharepoint.com/sites/LBI/SitePages/ADCI12.aspx) on IRS Source

07. [Key Talking Points and Fact Sheet for speaking engagements](https://irsgov.sharepoint.com/sites/LBI/001/RS-CL-KeyPrg/CWA%20TP%202023.pdf)

08. CWA Organizational mailbox

09. CWA phone number: 949-638-7235

10. Desk guides and related job aids (access is limited to approved users):



    1. CWA Tax Examiner and Revenue Agent SharePoint Procedures Guide

    2. CWA Tax Examiner Mail Merge Procedures Guide

    3. CWA Application Case Closing Checklist

    4. DWL Case Closing Checklist

    5. Simplified CWA Desk Guide

    6. CWA e-Sign Instructions

    7. Mapping CWA Network Drives

    8. Digital Inventory Management (DIM) FAQs

    9. DIM R1.3 R2.0 Routing Guide


**1.4.24.2** **(02-05-2026)**

### CWA Team Manager Expectations

1. A CWA FLM develops the expectations for the team in conjunction with the PM by jointly identifying opportunities, agreeing on goals, and developing work plans.



1. The expectations must comply with the provisions of section 1204 of the Restructuring and Reform Act of 1998.

2. The expectations should include the annual commitments established in the CWA FLM’s performance plan.


2. A CWA FLM will update and revise the expectations as program requirements change.


**1.4.24.2.1** **(02-05-2026)**

#### Guiding and Evaluating Employees

1. A CWA FLM is responsible for guiding the activities of the team and evaluating employees. A CWA FLM can use different types of reviews to monitor adherence to program policies and procedures including, but not limited to the following:



   - Open case and workload reviews

   - Final accounting reviews

   - Closed case reviews

   - CWA CIM application status code reviews

   - Report reviews

   - Site visits

   - Ongoing observation


2. Information that is obtained from the above reviews and visits must conform to the requirements of Document 11678, National Agreement. See IRM 6.430.1 , Performance Management Requirements, for further guidance on evaluating employees.


**1.4.24.2.2** **(02-05-2026)**

#### Case and Workload Reviews

1. A CWA FLM will conduct case or workload reviews on each employee. See IRM 1.4.1, Resource Guide for Managers, Management Roles and Responsibilities.

2. A CWA FLM will choose an appropriate number of case or workload reviews throughout the year to ensure a thorough evaluation of each employee’s performance.

3. A CWA FLM may use the results of case and workload reviews to evaluate employees by following the requirements of IRM 6.430.1, Performance Management Requirements.


**1.4.24.2.3** **(02-05-2026)**

#### Statistical Data Use

1. The IRS Balanced Measurement System, provides guidance to prevent the use of statistics to:



1. Evaluate employees, or

2. Impose or suggest production quotas or goals with respect to such employees. See IRM 1.5.1, The IRS Balanced Measurement System and IRM 1.5.2, Uses of Section 1204 Statistics.


2. A CWA FLM is prohibited from using records of tax enforcement results (ROTERs) to evaluate any employee who exercises judgment regarding the determination of tax liability or the ability to pay.


**1.4.24.3** **(02-05-2026)**

### Workload Management

1. The CWA FLM should plan, monitor, and direct input of work to carry out program priorities and effectively utilize resources.

2. The CWA FLM is responsible for reviewing and analyzing employee inventories to determine if they are at appropriate levels and ensuring cases are closed timely.

3. The CWA FLM is responsible for reviewing the CWA CIM application status codes to confirm they are accurate and updated timely.

4. The CWA FLM should work with other managers to balance inventory between the teams.



1. The CWA FLM will transfer cases between teams on the Electronic Case Folder (ECF) server in coordination with other managers.

2. The CWA FLM will request modifications to the current inventory assignment plan when necessary due to changes in team staffing levels or employee availability. The PM will review any altered inventory plan and will ensure the Gatekeeper receives information about the changes.


5. The CWA FLM should:



1. Assign work to maintain equitable inventory levels that maximize efficiency, customer satisfaction, and business results.

2. Anticipate and incorporate changes in staffing levels such as an employee assigned to other program teams, lead development, acting duties, or other temporary tasks.

3. Monitor progress of open cases by reviewing CWA CIM application status codes and activity records.

4. Guide employee performance by providing informal direction on cases and preparing reviews when formal guidance is needed.


**1.4.24.3.1** **(02-05-2026)**

#### Case Assignments

1. The CWA FLM assigns each Streamline, Standard, or Formal Standard CWA application case to a program employee. When making assignments, the CWA FLM should:



1. Assess the inventory level of each employee to ensure all open cases can be processed and managed in compliance with program policies, procedures, and timeframes.

2. Match the case complexity with the knowledge, skills, abilities, and development needs of each employee.


2. The CWA FLM will provide information on previous cases for the CWA applicants in the current tax year, and on any prior year cases as appropriate. The CWA FLM will secure the activity record and withholding analysis spreadsheet for each previous case and may include additional information that can assist the employee with the analysis of income or expenses on the current assignment.


**1.4.24.3.2** **(02-05-2026)**

#### Case Inventory Management Systems

1. The CWA FLM is responsible for reviewing case inventories on the CWA CIM application and the ECF server and will ensure the lists and documents:



1. Reflect accurate representative and withholding agent entity information.

2. Show the applicable status code and closure types.

3. Report the correct income, expense and withholding amounts.

4. Address all required CWA and DWL case activities including actions taken and decisions made.


2. The CWA FLM will actively monitor the progress of each employee's case work and ensure updates are completed timely and accurately.


**1.4.24.3.3** **(02-05-2026)**

#### CWA Approval

1. The CWA FLM will review a Standard CWA for accuracy prior to approval and a Formal Standard CWA prior to forwarding it for PM review and approval. See IRM 4.64.1.12.2, Types of Central Withholding Agreements (CWAs), for information on the gross income amounts and other criteria for a Standard or Formal Standard CWA application case. The CWA FLM reviews:



1. The proposed and accepted budgets to verify that each income item is supported by any required documentation and any expenses includible under program policies are considered ordinary, necessary, and reasonable under U.S. tax laws.

2. The activity record to confirm that the entity details are accurate and all necessary activities, and decisions are included such as contacts made, documents requested and received, and budget determinations or adjustments completed.

3. Each contract, letter, and Information Document Request (IDR) to ensure the documents match the information in the activity record and withholding analysis, including the itinerary and budget


2. If there are questions or corrections, the CWA FLM will document the activity record and communicate with the employee assigned. After the case information or documents have been revised, the CWA FLM will inform the employee assigned of the final determination, or request review by the PM when required or appropriate.

3. A CWA will be approved and signed based on the delegation order in IRM 1.2.63.2.10 , Delegation Order LB&I 1-23-10.


**1.4.24.3.4** **(02-05-2026)**

#### Addendum Reviews

1. The CWA FLM will review an addendum that modifies an executed Standard or Formal Standard CWA by adding a new event or reducing the required withholding tax due to non-performance at an itinerary event.

2. The CWA FLM will review an addendum that modifies an executed CWA for any reason not related to adding a new event or reducing the required withholding tax due to non-performance at an itinerary event.

3. The CWA FLM will complete any required review by a date that ensures the addendum can be timely executed. See IRM 4.64.1.12.9 , Amending an Approved CWA.


**1.4.24.3.4.1** **(02-05-2026)**

##### Addendum for Added Events

1. The CWA FLM will review an addendum request that adds an event to a Standard or Formal Standard CWA itinerary.

2. The CWA FLM will approve a Standard CWA addendum request for an added itinerary event that meets the following requirements:



1. The request is received no later than 21 days before the last event date on the CWA itinerary, and the employee assigned has sufficient time to process the addendum.

2. The required documents for each new event are submitted no later than 30 days before the added date.

3. The request does not add an event that will occur prior to the addendum execution date.

4. Any change to a CWA budget income item is supported by all required documents or information.

5. Any new expense item is related to the added event and includible under program policies.

6. Any change to a CWA budget expense item is considered ordinary, necessary, and reasonable.


**1.4.24.3.4.2** **(02-05-2026)**

##### Addendum for Non-performance

1. The CWA FLM will review an addendum request that changes the required withholding tax on a Standard or Formal Standard CWA due to non-performance at an itinerary event.

2. The CWA FLM will approve a Standard CWA addendum request related to non-performance at an itinerary event that meets the following requirements:



1. The request is received by the latter of 21 days before the last event date on the CWA itinerary or 21 days before the last date on the CWA withholding tax deposit schedule, and the employee assigned has sufficient time to process the addendum.

2. The request is supported by documentation confirming non-performance at the event and information addressing any potential reimbursements or insurance claims.

3. The request does not remove an event from the itinerary after the scheduled performance date.

4. The request reduces the required withholding tax due to changes in the CWA budget income or expense amounts.


**1.4.24.3.4.3** **(02-05-2026)**

##### Program Manager Addendum Approvals

1. The CWA FLM will send the PM each addendum to a Formal Standard CWA for review and approval.

2. The CWA FLM will send any CWA addendum not related to adding a new event or reducing the required withholding tax due to non-performance at an itinerary event to the PM for review and approval.


**1.4.24.3.5** **(02-05-2026)**

#### Policy Closure and Rescission Letter Approvals

1. The CWA FLM must approve all CWA application and DWL cases with a policy closure type, except when the nonresident alien (NRA) will not perform in any of the itinerary events, or the NRA is considered a U.S. person based on a passport, a green card, or a Form W-9 with documentation for the claimed U.S. resident status.

2. The CWA FLM must approve all rescission letters issued on a DWL case before the documents are sent to the withholding agent. The CWA FLM will approve a rescission letter after confirming that the NRA is not subject to withholding. See IRM 4.64.1.5.4, Rescinding Directed Withholding Letters.


**1.4.24.3.6** **(02-05-2026)**

#### Final Accounting Approvals

1. The CWA FLM will review and approve the assigned employee’s determinations reflected on a final accounting letter before it is issued to the Designated Withholding Agent (DWA) or an authorized representative under the following circumstances:



1. A CWA executed under Streamline case criteria meets any requirement for Standard or Formal Standard review.

2. A CWA executed under Standard case criteria meets any requirement for Formal Standard review.

3. A CWA executed under Standard or Formal Standard case criteria has a change in total income or total expenses of ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡.

4. A CWA executed for an athlete under Standard or Formal Standard case criteria has a change in total income or total expenses of ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡.

5. A CWA executed for an artist under Standard or Formal Standard case criteria has a change in total income or total expenses of ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ ≡ .

6. A CWA executed subject to the submission of additional documentation with the final accounting, including substantiation for large, unusual, or questionable expenses, as detailed in the activity record.


2. The CWA FLM will document the activity record when a final accounting review is completed.


**1.4.24.3.7** **(02-05-2026)**

#### Site Visits

1. The CWA FLM must review all site visits submitted by an employee assigned to the case no later than 10 days prior to the event date.



1. The CWA FLM will review the Site Visit Request form and any other information to determine if the planned site visit meets all program requirements.

2. The CWA FLM will send an approved Site Visit Request form to the PM for final approval.

3. The CWA FLM will confirm that the Site Visit list on the CWA PP site is updated with all necessary information before an approved site visit occurs.

4. After the site visit is completed, the CWA FLM will verify the employee who coordinated the site visit submits a Site Visit Report no later than five business days after the last event date. The CWA FLM will review and approve the Site Visit Report and upload it to the CWA PP site for PM review.

5. The CWA FLM will ensure the Site Visit list is updated with any required information obtained during the site visit.


**1.4.24.3.8** **(02-05-2026)**

#### Closed Case Procedures

1. The CWA FLM will use case or workload reviews to confirm that pending and completed CWA CIM application closures meet the following deadlines:



1. A DWL closure on a DWL case occurs no earlier than 60 days after the last event date, or no later than 10 business days after receiving a response to each letter sent and confirming any deposits reported.

2. A policy closure on a DWL case occurs no later than 10 business days after the last required action or CWA FLM approval date.

3. A Form 13930 closure on a CWA application case occurs no later than 10 business days after the final accounting letter is sent that shows no withholding tax deposit due.

4. A Form 13930 closure on a CWA application case occurs no later than 10 business days after the settlement date of the withholding tax deposit listed on the final accounting letter.

5. A policy closure on a CWA application case occurs no later than 10 business days after the last required action or CWA FLM approval date.


2. The CWA FLM will copy the ECF for each closed case from the assigned employee's folder and paste it into the subfolder for the applicable year and month in the team's **Closed Case** folder. The CWA FLM will compare that month's Case Status Report to the files in **Closed Case** folder and confirm that all closures for the month have been successfully copied.



1. The CWA FLM will complete the process of moving each month's closed cases to the **Closed Cases** folder no later than 15 business days after receiving the Case Status Report.

2. The CWA FLM will address any missing ECF files and resolve incomplete records or identified errors in the CWA CIM application with the appropriate employee assigned or the CWA program's analyst.

3. The CWA FLM will notify the CWA program’s analyst no later than the last business day of the month that the previous month’s closed cases can be moved to the Retention server in compliance with the appropriate Records Control Schedule and the LB&I File Plan.



      ### Note:



      The CWA FLM must use the copy and paste functions to move the ECF folders. The necessary file permissions will not be correctly retained when cutting or dragging the ECF folders.


**1.4.24.3.9** **(02-05-2026)**

#### Case Control Procedures

1. The CWA FLM will collaborate with the program’s analyst to move the closed case folders and files to the Retention server using the current process and delete the copied cases from all other folder locations.

2. The CWA FLM will assist with deleting the copied cases from all audit server locations including the assigned employee and the “Closed Cases” folders.


**1.4.24.4** **(02-05-2026)**

### Data Management and Reports

1. The CWA FLM will maintain employee records and other data management systems that the program uses to track results.

2. The CWA FLM will provide information on team accomplishments including timely submitting periodic reports required by the PM.

3. The CWA FLM can conduct or participate in studies that help assess potential changes to the program’s direction, size, scope, or structure.


**1.4.24.5** **(02-05-2026)**

### Customer Satisfaction

1. All interactions with taxpayers and their authorized representatives must be conducted in a professional and competent manner.

2. See IRM 4.10.1.2.1, Taxpayer Bill of Rights (TBOR).


**1.4.24.5.1** **(02-05-2026)**

#### Communicating with Taxpayers and Stakeholders

1. The FLM will ensure employee contact with taxpayers and other stakeholders is conducted in a manner that promotes a positive image for the IRS and the CWA program. See IRM 4.10.1.3, Communication.

2. All CWA program employees must use official letters and forms unless the CWA FLM approves the use of original correspondence. The CWA FLM must review the communications prior to its distribution and will document each approval in the activity record. The [Paperwork Reduction Act](https://www.congress.gov/crs-product/IF12673?q=%7B%22search%22%3A%22paperwork+reduction+act%22%7D&s=1&r=2) requires all government agencies to obtain Office of Management and Budget (OMB) approval for activities involving more than nine taxpayers on the same topic.

3. The CWA FLM will periodically review Circular 230, Regulations Governing the Practice of Attorneys, Certified Public Accountants, Enrolled Agents, Enrolled Actuaries, and Appraisers, for any changes to the requirements for individuals practicing before the IRS.


**1.4.24.5.2** **(02-05-2026)**

#### Employee Protection

1. The CWA FLM will periodically review information about employee protection under the Potentially Dangerous Taxpayer and Caution Upon Contact programs. See IRM 25.4.1, Employee Protection, Potentially Dangerous Taxpayer and IRM 25.4.2, Employee Protection, Caution Upon Contact Taxpayer.

2. The CWA FLM can review additional information about supervising employee contact with taxpayers on the Office of Employee Protection site.


**1.4.24.5.3** **(02-05-2026)**

#### Authorized Representatives

1. An NRA artist or athlete who submits a CWA application usually designates a representative to communicate with the IRS.

2. The CWA FLM will confirm during a case review that a valid Form 2848, Power of Attorney and Declaration of Representative or Form 8821, Tax Information Authorization, has been received for each applicant who authorized a representative to submit the application or communicate with the IRS.


**1.4.24.5.4** **(02-05-2026)**

#### Processing Delays

1. The CWA FLM must effectively communicate with artists and athletes, representatives, and withholding agents. The CWA FLM must maintain control over CWA deadlines and decisions about income, expenses, and withholding.

2. The CWA FLM should not allow any individual to delay the CWA application process. The CWA FLM should consider denying the CWA application when the employee assigned does not receive requested information by the communicated due date.

3. The CWA FLM will confirm during a case review that the employee assigned set reasonable deadlines and stated the consequences of not meeting each due date for sending requested documents and information.


**1.4.24.5.4.1** **(02-05-2026)**

##### Withholding Agent Eligibility

1. The CWA FLM will determine if a DWA should be declared ineligible to participate in the CWA program when the entity does not meet the any applicable terms or conditions in the agreement.

2. The CWA FLM will request approval from the PM before adding a DWA, who has not met the terms and conditions in the CWA, to the Ineligible DWA list.


**1.4.24.5.4.2** **(02-05-2026)**

##### Taxpayer Concerns or Complaints

1. Ensuring good customer relations with taxpayers is important. The CWA FLM will listen to and address taxpayer concerns or complaints. Complex tax laws and procedures can be a source of conflict when administering the CWA program. A simple explanation, or clarification is generally sufficient to resolve most issues.

2. The CWA FLM is responsible for facilitating discussions between employees and taxpayers. The CWA FLM should let a taxpayer fully explain their position. Do not agree nor disagree with the position until the employee assigned has responded to the taxpayer’s concerns. The CWA FLM should avoid quick answers until they are able to make a fair and objective decision based on the facts presented by all parties. The CWA FLM or the employee assigned should promptly respond to the taxpayer's complaint after a decision has been made or if needed, elevate the issue to the PM.


**1.4.24.6** **(02-05-2026)**

### General Team Management

1. A CWA FLM is responsible for end-to-end management of the team which includes the following areas of responsibility:



1. The CWA FLM should timely disseminate instructions and guidelines from management to the team.

2. The CWA FLM should meet with the team and discuss emerging issues, new developments, and revised procedures as needed.

3. The CWA FLM should maintain effective team controls to ensure that work is assigned promptly, processed in an efficient manner, and completed timely and accurately.

4. The CWA FLM should ensure that each employee assigned to a case has access to all tools necessary for their jobs which includes tax law and business entity research tools, email access, online resources, SharePoint, shared servers, and the Integrated Data Retrieval System (IDRS).


**1.4.24.6.1** **(02-05-2026)**

#### Integrated Data Retrieval System (IDRS)

1. Each employee assigned to a case may be granted access to IDRS to conduct research on all covered taxpayers.

2. The CWA FLM is required to review IDRS usage reports to ensure employee access levels are appropriate and report any violations that occur.

3. The CWA FLM has a security responsibility which includes the following:



1. Controlling employee access to IDRS.

2. Conducting the annual Business Entitlement Access Request System (BEARS) entitlement certification.

3. Ensuring employees only have the command codes necessary to accomplish their official duties.


**1.4.24.6.2** **(02-05-2026)**

#### Time Approval Responsibilities

1. A CWA FLM will review and approve the time reported in the Single Entry Time Reporting (SETR) system. See IRM 1.4.40.3.8, Time Accounting Responsibilities.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-024r#addtoany "Show all")

A2A