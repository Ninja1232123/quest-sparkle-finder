---
url: "https://www.irs.gov/irm/part1/irm_01-032-015"
title: "1.32.15 Public Transportation Subsidy Program (PTSP) | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-032-015#main-content)

- 1.32.15  [Public Transportation Subsidy Program (PTSP)](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160365104)
  - 1.32.15.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161424224)
    - 1.32.15.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161829824)
    - 1.32.15.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161963776)
    - 1.32.15.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161958672)
      - 1.32.15.1.3.1  [Human Capital Officer and Deputy Human Capital Officer](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161843504)
      - 1.32.15.1.3.2  [Director, Payroll and Personnel Systems, Deputy, Payroll and Personnel Systems, and Associate Director, Ogden Payroll Center](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161841808)
      - 1.32.15.1.3.3  [Financial Services Manager - PTSP](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161839952)
      - 1.32.15.1.3.4  [Department of Transportation](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161998768)
      - 1.32.15.1.3.5  [IRS Fare Media Distributor](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161993152)
      - 1.32.15.1.3.6  [Participants](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064161989200)
      - 1.32.15.1.3.7  [Manager of Record](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160717856)
      - 1.32.15.1.3.8  [IRS Employee Resource Center](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160710848)
      - 1.32.15.1.3.9  [Public Transportation Subsidy Program Office](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160708384)
    - 1.32.15.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160703408)
    - 1.32.15.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160696176)
    - 1.32.15.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160690784)
    - 1.32.15.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160666960)
    - 1.32.15.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160653328)
  - 1.32.15.2  [Policy and Eligibility](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160647488)
    - 1.32.15.2.1  [Employees Covered](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160637088)
    - 1.32.15.2.2  [Individuals Not Covered](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160628240)
    - 1.32.15.2.3  [Authorized Modes of Transportation](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160624288)
    - 1.32.15.2.4  [Unauthorized Expenses](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160619264)
  - 1.32.15.3  [Benefit Payment Types](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160616064)
    - 1.32.15.3.1  [Transit Benefit](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160607680)
  - 1.32.15.4  [Calculating/Adjusting Benefits](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160602224)
  - 1.32.15.5  [TRANServe Website](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160130144)
  - 1.32.15.6  [Application Process](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160122576)
    - 1.32.15.6.1  [Public/Private Vanpool Guidance](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160115296)
  - 1.32.15.7  [Benefit Distribution Process for Vouchers](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160108064)
    - 1.32.15.7.1  [Distribution of Transit Subsidy](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160103872)
    - 1.32.15.7.2  [Cash Reimbursement Eligibility](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160090464)
    - 1.32.15.7.3  [Annual Recertification](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160074016)
  - 1.32.15.8  [Separated, Furloughed, Extended Leave and/or Non-Work Status Employees](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160068032)
    - 1.32.15.8.1  [Withdrawing from the Program](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160061696)
  - 1.32.15.9  [Repayment of PTSP Benefits](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160048480)
  - 1.32.15.10  [PTSP Manual Forms](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160039072)
  - 1.32.15.11  [SmartBenefits](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160034640)
  - 1.32.15.12  [Details](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160026576)
  - 1.32.15.13  [Unlimited Pass](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160022128)
  - 1.32.15.14  [TRANServe Credit Card](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160017584)
  - 1.32.15.15  [Home Delivery of TRANServe Credit Card](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160004432)
  - 1.32.15.16  [Senior Passes](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160002656)
  - 1.32.15.17  [Teleworking](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064160000752)
  - 1.32.15.18  [Natural Disaster/Evacuation Order](https://www.irs.gov/irm/part1/irm_01-032-015#idm140064159997584)

# Part 1. Organization, Finance, and Management

# Chapter 32. Servicewide Travel Policies and Procedures

# Section 15. Public Transportation Subsidy Program (PTSP)

* * *

## 1.32.15 Public Transportation Subsidy Program (PTSP)

#### Manual Transmittal

April 25, 2023

#### Purpose

(1) This transmits revised IRM 1.32.15, Servicewide Travel Policies and Procedures Public Transportation Subsidy Program (PTSP)

#### Material Changes

(1) This IRM is revised to provide overall clarity to better identify the roles and responsibilities of the Public Transportation Program Office, management, and participants in regards to the PTSP program and the TRANServe credit card.

(2) IRM 1.32.15.1, Program Scope and Objectives, removed Public Transportation Subsidy Program and put the acronym.

(3) IRM 1.32.15.1.1, Background, removed Public Transportation Subsidy Program and put the acronym.

(4) IRM 1.32.15.1.2, Authorities, removed italics and added citation tags.

(5) IRM 1.32.15.3.1, Human Capital Officer and Deputy Human Capital Officer, removed the word program.

(6) IRM 1.32.15.1.3.2, Director, Payroll and Personnel Systems, Deputy, Payroll and Personnel Systems and Associate Director, Ogden Payroll Center, added the Deputy of Personnel Systems and removed the word program.

(7) IRM 1.32.15.1.3.3, Financial Services Manager - PTSP, removed the word program from bullet (e).

(8) IRM 1.32.15.1.3.6, Participants, section updated and order changed.

(9) IRM 1.32.15.3.7, Manager of Record, section updated.

(10) IRM 1.32.15.1.3.9, Public Transportation Office, section updated.

(11) IRM 1.32.15.1.4, Program Management and Review, section updated.

(12) IRM 1.32.15.1.5, Program Controls, section updated.

(13) IRM 1.32.15.1.6, Terms/Definitions, new definition added, section updated.

(14) IRM 1.32.15.1.7, Acronyms, added acronym for Absent Without Leave (AWOL), section updated to alphabetical order.

(15) IRM 1.32.15.1.8, Related Resources, removed italics and added citation tag.

(16) IRM 1.32.15.2, Policy and Eligibility, section updated.

(17) IRM 1.32.15.3, Benefits Payment Types, section updated.

(18) IRM 1.32.15.4, Calculating/Adjusting Only to Participants Who are Receiving Quarterly Transit Vouchers, name changed to Calculating/Adjusting, section updated.

(19) IRM 1.32.15.5, TRANServe Website, section updated.

(20) IRM 1.32.15.1.6, Application Process, section updated.

(21) IRM 1.32.15.6.1, Public/Private Vanpool Guidance, section updated.

(22) IRM 1.32.15.7, Benefit Distribution Process for Vouchers, section updated.

(23) IRM 1.32.15.7.1, Distribution on Transit Subsidy, section updated.

(24) IRM 1.32.15.7.2, Cash Reimbursement Eligibility, section updated, new statement added.

(25) IRM 1.32.15.7.3, Annual Recertification, section updated .

(26) IRM 1.32.15.8, Separated. Furloughed, Extended Leave and/or Non Work Status Employees, section updated.

(27) IRM 1.32.15.8.1, Withdrawing from the Program, section updated, pay.gov information added.

(28) IRM 1.32.15.9, Repayment of PTSP Benefits, new section added.

(29) IRM 1.32.15.10, PTSP Manual Forms, section moved from 1.32.15.9 to 1.32.15.10, section updated.

(30) IRM 1.32.15.11, SmartBenefits, section moved from 1.32.15.10 to 1.32.15.11, section updated.

(31) IRM 1.32.15.12, Details, section moved from 1.32.15.11 to 1.32.15.12

(32) IRM 1.32.15.13, Unlimited Pass , section moved from 1.32.15.12 to 1.32.15.13, section updated

(33) IRM 1.32.15.14, TRANServe Card, section moved from 1.32.15.13 to 1.32.15.14, section named changed to TRANServe Credit Card, section updated.

(34) IRM 1.32.15.15 Home Delivery of TRANServe Card, section moved from 1.32.15.14 to 1.32.15.15. section name changed to TRANServe Credit Card.

(35) 1.32.15.16, Senior Passes, section moved from 1.32.15.15 to 1.32.15.16.

(36) IRM 1.32.15.17, Teleworking, section moved from 1.32.15.16 to 1.32.15.17, section updated and alpha list B - D removed.

(37) IRM 1.32.15.18, Natural Disaster/Evacuation Order, new section added.

#### Effect on Other Documents

IRM 1.32.15, dated July 22, 2020 is superseded.

#### Audience

All Divisions and Functions

#### Effective Date

(04-25-2023)

David M. Aten

Acting, Human Capital Officer

**1.32.15.1** **(04-25-2023)**

### Program Scope and Objectives

1. The Public Transportation Subsidy Program (PTSP) was established to encourage employees to use mass public transportation when commuting to and from work. The benefits will be limited to the maximum monthly amount, excluded from income under section 132(a)(5) of the Internal Revenue Code.

2. **Purpose**: This Internal Revenue Manual (IRM) contains policies and procedures for the PTSP. To provide benefits to enrolled participants to commute from their home to their permanent Post of Duty (POD).

3. **Audience**: This IRM provides information for PTSP participants, managers, National Treasury Employee Union (NTEU) and employees who need more information concerning the program.

4. **Policy Owner**: Human Capital Officer and Deputy Human Capital Officer.

5. **Program Owner**: Associate Director, Ogden Payroll Center and the Public Transportation Subsidy Program Office develops and maintains this IRM.

6. **Primary Stakeholders**: Public Transportation Subsidy Program Office and Department of Transportation.

7. **Program Goals**: The PTSP will provide monthly and quarterly benefits to employees to use for commuting to/from work through mass transportation, as well as guidance on how to enroll, use benefits, and return benefits when not in use.


**1.32.15.1.1** **(04-25-2023)**

#### Background

1. The Internal Revenue Service (IRS) PTSP was established to encourage employees to use mass public transportation when commuting to and from work. This action improves air quality, reduces traffic congestion, and conserves energy by reducing the number of single occupancy vehicles on the road.

2. Employees using public transportation to commute to and from work may apply for transit subsidy benefits under the IRS PTSP.

3. Eligible employees using an authorized public transportation method will receive an employer-provided fare subsidy to apply toward their monthly transit costs.

4. The IRS will pay the transit benefits from appropriated funding, using stipulated guidelines.

5. Transit benefits, up to the maximum monthly amount is excluded from income, nontaxable monthly limit allowed by law.


**1.32.15.1.2** **(04-25-2023)**

#### Authorities

1. [Federal Workforce Transportation, Executive Order 13150, dated April 21, 2000](https://www.transportation.gov/sites/dot.gov/files/docs/executive-order-13150.pdf)

2. [Public Transportation Program, Treasury Directive 74-10, dated November 3, 2000](https://home.treasury.gov/about/general-information/orders-and-directives/td74-10)

3. [Energy Policy Act of 1992, Pub. L. No. 102-486](https://www.gsa.gov/cdnstatic/PL102-486.pdf)

4. Deficit Reduction Act of 1984, Deficit Reduction, IRC USC 132

5. Federal Employees Clean Air Incentives Act, Pub. 103 -172IRC (5 USC 7905)

6. Transportation Equity Act for the 21st Century, Pub. 230-178


**1.32.15.1.3** **(07-22-2020)**

#### Responsibilities

1. This section lists the responsibilities for:



01. Human Capital Officer

02. Deputy Human Capital Officer

03. Director, Payroll and Personnel Systems

04. Deputy, Payroll and Personnel Systems

05. Associate Director, Ogden Payroll Center

06. Financial Services Manager - PTSP

07. Public Transportation Subsidy Program Office

08. Department of Transportation

09. IRS Fare Media Distributor

10. Participants

11. Manager of Record

12. IRS Source


**1.32.15.1.3.1** **(04-25-2023)**

##### Human Capital Officer and Deputy Human Capital Officer

1. Human Capital Officer and Deputy Human Capital Officer are responsible for the oversight of the PTSP.


**1.32.15.1.3.2** **(04-25-2023)**

##### Director, Payroll and Personnel Systems, Deputy, Payroll and Personnel Systems, and Associate Director, Ogden Payroll Center

1. Director Payroll and Personnel Systems, Deputy, Payroll and Personnel Systems, and Associate Director, Ogden Payroll Center, are responsible for administering the PTSP.


**1.32.15.1.3.3** **(04-25-2023)**

##### Financial Services Manager - PTSP

1. Financial Services Manager - PTSP is responsible for:



1. Administering the Interagency Agreement with the Department of Transportation.

2. Providing technical advice and assistance to customers and stakeholders.

3. Performing program audits and reviews.

4. Performing random sample audit reviews to ensure PTSP benefits are used correctly.

5. Ensuring separating employees are removed from the IRS PTSP.


**1.32.15.1.3.4** **(07-22-2020)**

##### Department of Transportation

1. The Department of Transportation (DOT) performs the following tasks for IRS under an interagency agreement:



1. Maintaining the [TRANServe Website](https://transitapp.ost.dot.gov/).

2. Processing applications and maintaining a record of active participants.

3. Disbursing transit subsidies.

4. Maintaining records of subsidy disbursements.

5. Providing disbursement activity reports.

6. Coordinating with local transit authorities.


**1.32.15.1.3.5** **(10-24-2017)**

##### IRS Fare Media Distributor

1. The IRS Fare Media Distributor (FMD) is responsible for:



1. Ensuring the successful disbursement of the transit subsidy within their geographic area.

2. Receiving and distributing transit vouchers in locations where the TRANServe credit card isn't accepted.

3. Tracking and maintaining records of distributed fare media using established procedures.

4. Informing participants that their PTSP issues may be forwarded to the Employee Resource Center (ERC).


**1.32.15.1.3.6** **(04-25-2023)**

##### Participants

1. The participants are responsible for:



01. Ensuring the New Transit Benefit Application, Rate Change/Address and SmarTrip Change Application, the Annual Recertification Application, and Withdrawal Application are submitted timely and following up with their manager to ensure the timely approval of their form.

02. Following program guidance by completing the PTSP Awareness Briefing 19239 on Integrated Talent Management (ITM), prior to initial enrollment and/or re-enrollment in the program.

03. Ensuring the benefit requested and received is the proper amount for the approved mode of transportation and vendor in their current application. The amount of transit subsidy must not exceed the employee’s actual monthly public transportation commuting cost.

04. Ensuring proper use of the benefit. It is allowed only for the commute between the participant's residence and work location. This work location can be the permanent POD or a minimum of 90 day detail location. It must not be sold or transferred to another individual.

05. Ensuring benefit is not sold or given to another individual.

06. Ensuring adjustments are made to transit subsidy amounts when there are changes to transit vendor/provider, commuting cost, work schedule, contact information, manager, or home/work address. Participants who have a change in benefits should have a completed application on the [TRANServe website](https://transitapp.ost.dot.gov/) before the 20th of the prior month in order for the benefits to be available for the upcoming month. A complete TRANServe application includes the certification of the participant, as well as managerial and PTSP Administrator approval.

07. Ensuring parking expenses are not included as part of the commuting cost.

08. Returning the unused transit benefit by using Form 11664-G, PTSP Participant Return of Fare Media.

09. Returning benefit received in advance, upon separating from the IRS.

10. Using the most cost-effective/cost-efficient transit benefit type for your commute.


2. If the above responsibilities are not met, the participant may be suspended, withdrawn and/or billed for discrepancies in benefits usage and/or subject to other disciplinary actions.



   - All billing of PTSP benefits for misused/abused funds will originate from the IRS-Debt Collection Unit.


**1.32.15.1.3.7** **(07-22-2020)**

##### Manager of Record

1. Manager of Record is responsible for:



1. Ensuring the employees are eligible.

2. Completing the PTSP Awareness Briefing 19239 in ITM, and ensuring their participating employees do the same.

3. Ensuring that all the Transit Benefit Applications in the [TRANServe website](https://transitapp.ost.dot.gov/) approval queue for their employees are processed (approved/disapproved) within 15 business days of the participant submission. PTSP applications that are not approved timely by the manager, may result in a disruption of PTSP benefits to the employee.

4. Assisting separating employees to ensure they withdraw from the program and return or destroy the TRANServe credit card, as well as return the transit voucher, and/or transit benefit to the PTSP Office using Form 11664-G, PTSP Return of Fare Media.

5. Ensuring employees who telework are claiming the correct amount of commuting days to/from their residence and official POD and not including telework days.

6. Ensuring participants use their PTSP benefit in accordance with program guidelines.

7. Ensuring participants within reason, use the mode of transportation that is most cost-effective/cost-efficient for the government.

8. Reporting suspected misuse/abuse of PTSP benefits.


**1.32.15.1.3.8** **(07-22-2020)**

##### IRS Employee Resource Center

1. The [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do) serves as the first contact point for employee PTSP questions or concerns. The IRS Source provides program information and instructions.


**1.32.15.1.3.9** **(04-25-2023)**

##### Public Transportation Subsidy Program Office

1. The Public Transportation Subsidy Program Office is responsible for:



1. Administering the Interagency Agreement with DOT.

2. Providing technical advice and assistance to customers and stakeholders.

3. Performing program and audit reviews, TRANServe credit card activity and reporting misuse/abuse of PTSP funds for repayment to IRS-Debt Collection Unit.

4. Ensuring separating employees are removed from the PTSP timely.

5. Ensuring parking expenses are not included as a part of the commuting costs.

6. Administering and managing the annual recertification of the PTSP.


**1.32.15.1.4** **(04-25-2023)**

#### Program Management and Review

1. The PTSP Staff is responsible for the following:



1. Performing a full review of all PTSP applications on the [TRANServe website](https://transitapp.ost.dot.gov/).

2. Random sample audit review to ensure PTSP benefits are used correctly.

3. DOT Funding Reports: These reports are received monthly and upon request from the Department of Transportation (DOT). They are reviewed to keep IRS abreast of the financial status of the PTSP .

4. Reviewing unusual transactions and program fund usage for accuracy and proper use of PTSP benefits.

5. Reporting misuse/abuse of PTSP benefits.

6. Reviewing TRANServe credit card participant activity reports and reporting misuse/abuse of PTSP funds for repayment to IRS-Debt Collection Unit.

7. Administering Annual Recertifications to ensure PTSP participants review and recertify their PTSP benefits.

8. Return of Fare Media: A review is done of all participants instructed to repay the government because of improper use of fare media.

9. Withdrawal Reviews: A monthly review ensures all separated PTSP participants are removed from the PTSP database.


**1.32.15.1.5** **(04-25-2023)**

#### Program Controls

1. The following controls are in place to ensure compliance:



1. Recertification: Participants are automatically suspended from the PTSP if they fail to complete their PTSP Annual Recertification Application within the required timeframe (one year).

2. Return of Fare Media: Participants must reimburse the government, via check or money order, [pay.gov](https://pay.gov/public/form/start/51115154/) for improper use of fare media.

3. Withdrawal: Participants are withdrawn from the program when they have not self-withdrawn from the program before separating from the IRS, they fail to complete their annual recertification timely, or following six months of inactivity.

4. All TRANServe applications will be reviewed for accuracy.

5. Internal audits may be performed to ensure compliance with the policy contained in this IRM.


**1.32.15.1.6** **(04-25-2023)**

#### Terms/Definitions

1. In this IRM, the terms below have the following meanings:



01. **Carpool** \- An arrangement between people to make a regular journey in a single vehicle, typically with each person taking turns driving.

02. **Cash Reimbursement** \- An electronic payment deposited to a participant’s bank account of record to reimburse transit expenses when the transit pass is not readily available.

03. **Commuter Highway Vehicle/Vanpool** \- A privately owned highway vehicle that seats at least six adults and one driver and uses 80% of total mileage to transport to and from work. On trips for this purpose, the number of riders must be at least 50% of the adult seating capability, not including the driver.

04. **Detail** \- Temporary assignment of an employee to a different position for a specified period, with the employee returning to regular duties at the end of the timeframe. This includes positions at equal, higher, or lower grades.

05. **Distribution Site** \- An IRS site where participants can pick up their transit subsidy from a Fare Media Distributor (FMD).

06. **Fare Media Distributor (FMD)** \- Individual responsible for receiving and distributing transit vouchers in locations where the TRANServe credit card isn’t accepted. The FMD also tracks and maintains records of distributed fare media using established procedures.

07. **Local Transit Authority** \- An area vendor that provides transportation.

08. **Manager of Record**\- The manager of record is the participant’s direct manager or another manager, given temporary access by the direct manager to review and approve applications.

09. **Misuse/Abuse** \- Failure to follow guidance listed in the PTSP IRM.

10. **Non-Temporary Work Location** \- A location where employment is realistically expected to last more than one year, or there is no realistic expectation that it will last for one year or less, regardless of whether it actually exceeds a year.

11. **Post of Duty (POD)** \- A place where an employee regularly performs their duties.

12. **Public Transportation** \- Transportation provided in a mass transit vehicle or commuter highway vehicle. Acceptable modes of public transportation are: bus, ferry, subway, train, and vanpool.

13. **Standard Employee Identifier (SEID)** \- A computer generated alpha numeric string that provides a unique identifier for each IRS employee, eliminating the need for social security number identification. SEID numbers are found on the Discovery Directory or in Outlook.

14. **Subsidized Parking Space**\- A space specifically assigned to an employee and paid for by the IRS.

15. **Time-Sensitive Fare Media** \- A fare payment for use within a specified timeframe, e.g., monthly subsidy.

16. **TRANServe Credit Card** \- A card that provides transit benefits electronically. The primary goal of the TRANServe credit card is to use a single fare media delivery system that offers enhanced internal controls to preserve the transit benefit by deterring waste, fraud, and abuse.

17. **Transit Pass/Voucher** \- A non-cash instrument that is either accepted by the local transit authority as fare payment or exchanged for an acceptable form of payment. It is tax free and issued in advance. Vouchers are used in areas that do not accept the TRANServe credit card.

18. **UBER/LYFT** \- Is a car for service, not mass transportation, therefore, the PTSP benefit may not be used for UBER, LYFT or any pay for service transportation.

19. **Unlimited Transit Pass** \- A pass that allows public transit passengers to take either a certain number of pre-purchased trips or unlimited trips within a fixed time period, such as an unlimited monthly pass.


**1.32.15.1.7** **(04-25-2023)**

#### Acronyms

1. The following chart contains acronyms that are used throughout this IRM:



|     |     |
| --- | --- |
| **ACRONYMS** | **DESCRIPTION** |
| AWOL | Absence without Leave |
| DOT | Department of Transportation |
| ERC | Employee Resource Center |
| FMD | Fare Media Distributor |
| HCO | Human Capital Office |
| ITM | Integrated Talent Management |
| POD | Post of Duty |
| PTSP | Public Transportation Subsidy Program |
| SEID | Standard Employee Identifier |
| TDY | Temporary Duty Station |
| TIGTA | Treasury Inspector General for Tax Administration |


**1.32.15.1.8** **(10-24-2017)**

#### Related Resources

1. Internal Revenue Bulletin: 2012 IRB 24, Electronic Benefits.

2. The Computer Matching and Privacy Protection Act of 1988, Pub. L. No. Pub. 100-03, amended the Privacy Act of 1974 to protect the subjects of Privacy Act records whose records are used in automated matching programs. Before covered computer matches (that may result in adverse action against match subjects) can be conducted, the required Federal Register notice, computer matching agreement, and reports for OMB and Congress must be approved.

3. Rev. Rul. 99-7, defines a non-temporary work location.

4. IRS/NTEU Letter of Understanding, dated October 20, 2000, discusses the Servicewide implementation of the PTSP.

5. IRS Memorandum on Parking Policy, dated July 9, 2002, specifies that appropriated funds are not used for employee parking and that parking is a personal expense, and it reiterates the Government's position to encourage the use of public transportation.

6. IRS/NTEU Memorandum of Understanding, dated May 5, 2003, discusses the channeling of customer service requests to the Employee Resource Center.

7. IRS/NTEU Letter of Understanding, dated May 23, 2008, discusses the annual recertification process.

8. IRS/NTEU Letter of Understanding, dated August 3, 2010, discusses the allowance for details, 90-days or more, and the use of the unlimited transit subsidy to perform "in and around" local travel within the city limits (or area covered by the issued unlimited transit subsidy).


**1.32.15.2** **(04-25-2023)**

### Policy and Eligibility

1. To be eligible to receive an IRS PTSP transit benefit, employees must use mass public transportation to commute between their residence and their permanent POD or detail location of 90 days or more.

2. The transit benefit is equal to the participant’s actual monthly commuting cost, up to the maximum nontaxable monthly amount allowed by law, regardless of the number of days the public transportation is used. View [Publication 15-B](https://www.irs.gov/forms-pubs/about-publication-15-b), Employer’s Tax Guide to Fringe Benefits for the maximum amount.

3. To remain eligible in the program, PTSP participants must submit a PTSP Recertification annually to certify their actual commuting cost.

4. In the event of a furlough, temporary shutdown, or evacuation order, participants should not use the PTSP benefits until they receive a return-to-work order. If required to report to the office during a furlough or temporary shutdown, the employee should only purchase what is needed for their commute to/from their residence and post of duty (POD). They should purchase the most cost effective transit type for their commute (ex., if only reporting to their POD once a week, purchase a daily pass).

5. Policy - Parameter of an eligible commute:



1. A commute is regular travel back and forth between the employee’s place of residence and official duty station during a 24-hour period. A place of residence will usually be the employee’s primary home, but may also include a place the employee stays regularly.

2. It requires that there be no immediate overnight stay between the home and work at a location away from the employee’s originating place of residence.

3. The complete round-trip between home and work is one that could reasonably be expected to occur on a regular basis, even if it does not, in fact, occur every weekday.

4. A commute need not occur every day; it may occur as infrequently as one time per period in accordance with the employee’s approved regular work and telework schedule.

5. A commute is not reasonable if the whole monthly transit benefit would be needed to cover a single one-way trip.

6. A commute must take place on official business day, defined as Monday through Friday unless otherwise defined by your office or applicable Collective Bargaining Agreement.

7. Transportation benefits may not be used to commute to an office other than your official post of duty (POD), case related work or for using public transportation to return to your residence for non-work days.


**1.32.15.2.1** **(07-22-2020)**

#### Employees Covered

1. The program is open to all eligible IRS and Chief Counsel employees including:



   - Full-time and Part-time employees.

   - Interns on IRS payroll and who have an SEID and official @irs.gov e-mail address.


2. Participants are not entitled to benefits during the time when they are:



01. On official business travel, including City-to-City travel where per diem is being paid and/or Local travel is used for in and around travel; case related meeting, NTEU and any other interoffice/site visits.

02. On a full day of leave or working an Alternated Work Schedule (AWS) and are out on their regularly scheduled day off.

03. Teleworking for a full day at home.

04. On jury duty.

05. Using a government-owned vehicle to commute to work.

06. Using an IRS-subsidized parking space or IRS-assigned parking permit.

07. Using a carpool or personal vehicle to commute to and/or from work on a day when you are unable to use mass transportation.

08. In non-pay status (Furlough, Extended Leave or Leave Without Pay).

09. Exiting the program or leaving the Service.

10. On a detail less than 90 days.


3. If the above requirements are not followed, participants may be withdrawn from the program.


**1.32.15.2.2** **(10-24-2017)**

#### Individuals Not Covered

1. The following employees are not eligible for PTSP:



   - Volunteers, including unpaid interns

   - Contractors or contract employees

   - Employees on intermittent work schedules

   - Employees with Home as POD

   - Others not listed on the IRS payroll


**1.32.15.2.3** **(07-22-2020)**

#### Authorized Modes of Transportation

1. Acceptable modes of public transportation are: bus, ferry (walk-on only), subway, train, and vanpool who meet program requirements.

2. Private vanpools are acceptable only if they meet the following criteria:



1. Any highway vehicle with a seating capacity of at least six adults, not including the driver.

2. At least 80% of the mileage is for transporting employees between their residence and their permanent POD, non-temporary work location, or detail location.

3. The number of employees transported is at least 50% of the adult seating capacity of such vehicle, not including the driver. If the van seating capacity is six passengers, the van must operate at 50% capacity on all commutes with at least three passengers on board at all times, plus the driver, after all riders have been picked up.

4. Vanpool participants who have the TRANServe credit card must use the card for vanpool payments. The vanpool driver must setup a Merchant Account with their bank to accept payments from the TRANServe credit card.


**1.32.15.2.4** **(07-22-2020)**

#### Unauthorized Expenses

1. Parking expenses, whether at a commuter lot or at/or near the workplace, are not recoverable and not considered a transit cost under PTSP.

2. An IRS-assigned parking permit that is non-subsidized.

3. Bicycles, scooters and other available green modes of transportation offered by other vendors are not reimbursable.

4. UBER, LYFT, and other Taxi or on demand type car services are not authorized modes of transportation.


**1.32.15.3** **(04-25-2023)**

### Benefit Payment Types

1. There are three types of subsidy payments for PTSP participants.



1. The TRANServe credit card

2. Transit voucher are available only for locations that do not accept the TRANServe credit card.

3. Cash Reimbursement on a quarterly basis for vendors who only accept cash.


2. The type of benefit distributed to the participant depends on the local transit authority’s acceptance of the transit benefit.



1. TRANServe Cards are funded one month prior to be used for the following months transit cost. For example, the TRANServe credit card is funded in January, the funds on the card are to be used for February’s transit cost.

2. The transit voucher is mailed out quarterly to the FMD.

3. The Cash Reimbursement benefit is equal to the participant’s actual monthly commuting cost, up to the monthly maximum allowed which is excluded from income by law. View [Publication 15-B](https://www.irs.gov/pub/irs-pdf/p15b.pdf), Employer’s Tax Guide to Fringe Benefits for the maximum amount. Cash reimbursements are provided quarterly **after** incurring verified out-of-pocket commuting costs. Cash reimbursements are deposited in the participants Electronic Fund Transfer (EFT) account provided by payroll.


**1.32.15.3.1** **(07-22-2020)**

#### Transit Benefit

1. Transit benefit cannot be:



1. Exchanged for cash.

2. Transferred from one employee to another.

3. Given, loaned, or sold to others.


2. Transit benefit cannot be used:



1. To travel to other offices in the area.

2. To commute home for non-work days.

3. For case related travel.


**1.32.15.4** **(04-25-2023)**

### Calculating/Adjusting Benefits

1. The IRS PTSP transit subsidy benefit is equal to the participant’s actual monthly commuting cost. The maximum transit subsidy amount is determined by Congress each calendar year. View [Publication 15-B](https://www.irs.gov/pub/irs-pdf/p15b.pdf), Employer’s Tax Guide to Fringe Benefits, for the maximum amount.

2. Participants receiving an advance of the transit subsidy must estimate their commuting costs for the upcoming quarter to ensure the appropriate benefit amount is received at the quarterly distribution (applies only to participants who receive quarterly transit vouchers).

3. Participants are not entitled to benefits for the days they do not use public transportation to commute to and from their residence and official POD. As a result, the benefits should be adjusted accordingly.

4. Ideally, estimates should be as accurate as possible to avoid any benefit overpayment or underpayment.

5. If the benefit was overestimated, the balance must be returned. There are three ways to return excess transit subsidy:



1. Return unused transit vouchers with Form 11664-G, PTSP Return of Fare Media, to the PTSP Analyst listed on the form.

2. Request less transit subsidy at the next distribution (applies only to participants who receive quarterly transit vouchers).

3. Send a personal check or money order payable to Internal Revenue Service, along with a completed Form 11664-G, **PTSP Return of Fare Media**. The form and check or money order should be mailed to the IRS-Debt Collection Office, P O Box 9002, Beckley, W. Va. 25802-9002. A Document Transmittal Form 3210 should be attached. The subject matter should be addressed as:**“To Reimburse the IRS Account for Public Transportation Subsidy.”** If paying by credit/debit card participants should input an [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do) ticket for PTSP Questions & Assistance for instructions on how to use [pay.gov](https://www.pay.gov/public/form/start/51115154).


**1.32.15.5** **(04-25-2023)**

### TRANServe Website

1. IRS employees were transitioned to the [TRANServe website](https://transitapp.ost.dot.gov/) in February of 2018. All new and/or current participants are required to complete all actions related to their PTSP benefits through the TRANServe website. To complete an action on the TRANServe website participants must be a registered user with a valid IRS e-mail address.

2. The [TRANServe website](https://transitapp.ost.dot.gov/) is accessible through the IRS network, personal computer, tablet or smartphone with an internet connection.

3. All PTSP actions require the approval of the participant’s manager of record, PTSP Office Administrator, and the DOT. The participants manager of record must be registered on the [TRANServe website](https://transitapp.ost.dot.gov/) and request elevation (through an [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do), PTSP Questions & Assistance ticket) to the manager of record role, prior to the participant inputting an application, in order for the participants to select them as the first level approver. Managers have 15 business days to review and process (approve or disapprove) applications. It’s the participants responsibility to ensure their manager is taking timely action.

4. All TRANServe applications have a comments section for participants to include necessary information. For example, listing the name of the vanpool driver and all other passengers, or including an alternate address for participants who need their TRANServe credit card mailed to a different address other than the application residence field and entering a return to office (RTO) date after an evacuation order or extended leave.


**1.32.15.6** **(04-25-2023)**

### Application Process

1. All participants must have a SEID number and valid @irs.gov e-mail address to enroll in PTSP.

2. All new participants must confirm completion of the PTSP Awareness Briefing, 19239 in ITM prior to submitting an enrollment in the [TRANServe website.](https://transitapp.ost.dot.gov/)

3. To apply for PTSP benefits, participants must be registered on the [TRANServe website](https://transitapp.ost.dot.gov/) to complete their new transit application. The applicant’s manager of record must approve the new transit benefit application on the TRANServe website. Once the employee submits their application, the manager of record will receive a system generated e-mail from the TRANServe Administrator, notifying them that there is an application awaiting approval. The effective date for benefits is the date the manager approves an accurate application on the TRANServe website.

4. After an application is approved by the participant’s manager of record, it is routed to the PTSP Administrative Office for review and processing (approval or disapproval). Once approved by the PTSP Administrative Office, the application is then routed to DOT for a final review and processing.

5. Retroactive subsidies, prior to the effective date, are not authorized.

6. If PTSP funding is not available at the time of the effective date, the participant may review the guidelines on submitting a PTSP cash reimbursement.

7. If the applicant’s POD utilizes vouchers, the applicant should input a PTSP Questions & Assistance ticket through OS GetServces to confirm availability.


**1.32.15.6.1** **(04-25-2023)**

#### Public/Private Vanpool Guidance

1. All IRS employees in the vanpool, including the alternate, are eligible to collect transit benefits and must follow the same enrollment process on the [TRANServe website](https://transitapp.ost.dot.gov/). The effective date for benefits, is the date the manager approves an accurate application on the TRANServe website.

2. If the vanpool is not being operated by an IRS employee, each vanpool must designate an IRS employee as the coordinator, who will be responsible for ensuring that the minimum requirements are met monthly. If there is only one IRS employee in the vanpool, they will automatically be considered the IRS coordinator.

3. Vanpool drivers must set up a merchant bank account with their banks. This is needed to retrieve the funds from the TRANServe credit card. Vanpool participants receive their transit benefit via the TRANServe credit card.

4. Vanpool charges must reflect reasonable costs, and rates charged must be the same for all passengers. Rates may be reduced or waived for the designated primary driver. Operating expenses for lease, fuel, or tolls qualify for the benefit; maintenance and cleaning do not qualify.

5. If the participant’s monthly expenses are less than the maximum, only the actual monthly amount spent is authorized for subsidy.

6. Participants may only collect transit benefits when actively riding in the vanpool. Vanpool riders may not use the transit benefit to **hold** a seat in the vanpool in excess of 10 working days per month, while on annual or sick leave.

7. Participants choosing to commute by vanpool must pay the out-of-pocket cost to hold a seat in a vanpool in cases of extended absences (in excess of 10 working days per month) or days absent from the vanpool due to part-time or telework schedules.


**1.32.15.7** **(04-25-2023)**

### Benefit Distribution Process for Vouchers

1. Transit vouchers are distributed quarterly. Transit vouchers are only available for those areas that do not accept the TRANServe credit card.

2. Participants can have vouchers mailed directly to their personal mailing address or to their assigned POD. In some instances vouchers are mailed to an assigned FMD at their POD.

3. If a participant is unable to pick up their transit subsidy, they can designate a co-worker to pick up the subsidy on their behalf. Form 11664-E, _PTSP Authorization for Third Party Pick-up,_ must be completely filled out and signed by the participant.

4. The FMD and the PTSP Office do not maintain an inventory of undesignated transit vouchers.


**1.32.15.7.1** **(04-25-2023)**

#### Distribution of Transit Subsidy

1. The transit benefit is funded and/or distributed in advance.



1. TRANServe credit cards are funded on the 10th of the month for the upcoming month.

2. Transit vouchers are mailed to the participant or FMD the month before the upcoming quarter.

3. Transit vouchers are provided quarterly and only available for those areas that do not accept the TRANServe credit card.


2. TRANServe credit cards (original and replacements) will be mailed to the participant's home address included in their TRANServe application. If a participant includes a comment in their application to mail the TRANServe credit card to their POD location, the card will be delivered by whatever agreement they have arranged with their local mailroom.

3. When picking up vouchers, participants must:



1. Present their IRS badge for identification.

2. Sign and date Form 11664-F, _PTSP Signature Sheet for Up-front Monthly/Quarterly Distribution,_ indicating receipt and acceptance of the transit voucher.

3. Verify the transit voucher amount collected is correct for the quarter.


4. Participants must safeguard their TRANServe credit card and/or transit voucher, as it becomes their property and responsibility upon receipt.



1. To avoid damage to the TRANServe credit card, keep magnets away from the magnetic strip.

2. The transit voucher with the oldest date must be used first, preventing expired subsidy. Do not staple, fold, or mutilate the transit voucher.


5. If your TRANServe credit card is lost, stolen or damaged you must notify US Bank Customer Service to initiate the replacement process at 1-888-994-6722 or 711 for the hearing impaired. A replacement card will be issued, and the available credit limit will transfer to the new TRANServe credit card.

6. Transit vouchers:



1. Cannot be replaced or refunded if lost or stolen.

2. If damaged or expired, contact the local transit authority, as they might accept it. If the transit voucher isn't accepted by the transit authority, please return it using Form 11664-G, _PTSP Participant Return of Fare Media._ Participants must include Form 3210, _Document Transmittal,_ for an acknowledgement of receipt of their return fare media.


**1.32.15.7.2** **(04-25-2023)**

#### Cash Reimbursement Eligibility

1. Cash reimbursements are only available when an employee is enrolled in PTSP with an accurate and approved enrollment application. The most recent date the manager approves the enrollment is the effective date. Employees will be referred to as participants on their effective date. **Eligible participants** must submit the PTSP Cash Reimbursement Certification on the [Cash Reimbursement SharePoint Site](https://organization.ds.irsnet.gov/sites/CFOts/PTSPcashRemburse/SitePages/Home.aspx) for reimbursement of **_actual expenses_** incurred in the previous quarter. Employees are not reimbursed from their Enter on Duty (EOD) date. Retroactive subsidies, prior to the effective date, are not authorized.

2. Cash Reimbursements may be available when:



1. New hires and new participants who have enrolled in the program are waiting for their TRANServe credit cards.

2. Employees re-enrolling in the program after being withdrawn.

3. The transit authority only accepts cash and doesn’t accept paper vouchers or the TRANServe credit card.

4. Seasonal participants return to work and the funds are not available on the TRANServe credit card. (Participants must use the card upon their return to work. They should not purchase a monthly pass prior to their return and expect reimbursement when funds are available on their TRANServe credit cards).

5. Receipts are required when they are available from the vendor.


3. Cash Reimbursements will _not_ be issued for:



1. Participants who fail to use their benefits in any given month.

2. Lost, stolen, or damaged TRANServe credit cards.

3. Undeliverable TRANServe credit cards due to incorrect or incomplete address information provided by the participant.

4. Participants who transfer funds to their local transit cards - Clipper, Breeze, SmarTrip, Ventra, etc, - or have malfunctions to their local transit cards. Participants will need to resolve the issue with their local transit authority.

5. Participants who fail to initiate a timely increase to their benefits through the [TRANServe website.](https://transitapp.ost.dot.gov/)

6. When funds are available on the TRANServe credit card or if a voucher is available.

7. Participants who fail to pick up transit voucher at the scheduled distribution and/or did not complete Form 11664-E, PTSP Authorization for Third Party Pickup.


_Public Law 103-172_ states that cash can only be issued when fare media is not readily available.



4. Participants must submit a cash reimbursement request through the Cash Reimbursement SharePoint Site within 30 days after the end of the quarter. The cash reimbursement request requires the managers approval along with receipts (receipts are required when they are available from the vendor) or completion of the transportation log.

5. The PTSP Administrative Office will review all cash reimbursement requests. The request must be accurate, complete and include receipts and/or transportation log. Reviewed, approved and processed cash reimbursement request will be paid via direct deposit based on the participants (EFT) data on record.


**1.32.15.7.3** **(04-25-2023)**

#### Annual Recertification

1. PTSP Participants are required to recertify their PTSP benefits annually by submitting a recertification through the [TRANServe website](https://transitapp.ost.dot.gov/). PTSP Annual Recertification is based on your enrollment or last recertification date.

2. Participants will receive a system generated e-mail notification directly from the TRANServe website informing them of the upcoming expiration date of their PTSP recertification and the requirements to submit a new recertification timely.

3. Provisions must be made for participants by their manager of record who do not have access to a computer.

4. If a participant fails to complete their PTSP Annual Recertification prior to their expiration date, they will be withdrawn from the program. A complete PTSP Annual Recertification includes the certification of the participant, as well as managerial and PTSP Administrator approval. The withdrawn individual can re-enroll in the program again at any time. If the participant has been withdrawn from the program, they are required to complete a new enrollment. Cash reimbursements are not authorized for any out-of-pocket expenses due to failure to recertify timely.

5. The PTSP Administrative Office will review all PTSP Annual Recertifications for accuracy and return (i.e., disapprove) any recertifications with; inaccurate information, overstated travel cost (i.e., not the most cost-effective method of transportation) and potential inappropriate use of the program.

6. Managers must process (approve or disapprove) the Annual PTSP Recertification within 15 business days. Unapproved recertifications are not authorized for a cash reimbursement. It is the participants responsibility to ensure their recertification is approved.


**1.32.15.8** **(04-25-2023)**

### Separated, Furloughed, Extended Leave and/or Non-Work Status Employees

1. Employees who participate in the PTSP and who are separating from the Service, must complete the withdrawal request and have their manager approve the request timely within 15 business days on the [TRANServe website](https://transitapp.ost.dot.gov/) prior to leaving the Service. If the employee is not able to or has already left the Service, it is the manager’s responsibility to request that they be withdrawn by submitting an [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do) ticket for PTSP Questions and Answers.

2. Employees who participate in the PTSP who are separating from the Service, must return or destroy their TRANServe credit card, return transit vouchers or any pro-rated portion of benefit received in advance using Form 11664-G, _PTSP Participant Return of Fare Media_ to the PTSP Office.

3. Employees who participate in the PTSP and are furloughed, placed on extended leave, or Non-Work Status (NWS) are automatically withdrawn and must recertify their PTSP benefits upon return to service in order for benefits to be restored.

4. Employees who have separated from the Service may be subject to a random review of their benefit usage to ensure no funds were used after leaving the Service. Any misused funds may be subject to collection from the IRS-Debt Collection Unit.


**1.32.15.8.1** **(04-25-2023)**

#### Withdrawing from the Program

1. Participants who no longer want to be enrolled in the PTSP must submit a timely withdrawal request through the [TRANServe website](https://transitapp.ost.dot.gov/) and not use any PTSP benefits beyond their intended withdrawal date.

2. Participants who do not have access to an IRS computer can use the following steps to withdraw:



   - Use a personal computer, tablet or smartphone to log into the TRANServe website to submit a Withdrawal request.

   - Contact the ERC to have an [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do) ticket opened for PTSP Questions & Assistance.

   - Request their manager open an OS GetServices ticket for the PTSP Questions & Assistance.


3. Your manager must approve the withdrawal request within 15 business days. If you withdraw from the program you must return or destroy the TRANServe credit card, and return the transit vouchers or any unused portion of the benefits received in advance using Form 11664-G, _PTSP Participant Return of Fare Media ,_ or input on [OS GetServices](https://www.irs.gov/irm/part1/irm_01-032-015) ticket for PTSP Questions & Assistance for information regarding the use of [pay.gov](https://www.pay.gov/public/form/start/51115154) to repay unused PTSP benefits.

4. The PTSP benefits loaded to a local transit card (ex. Clipper, Breeze, SmarTrip, Ventra Keycard, etc.) should not be returned as they are not a form of repayment for unused funds. The participant should reimburse the IRS by submitting payment via a check, money order, or by credit/debit card via [pay.gov](https://www.pay.gov/public/form/start/51115154) to the IRS-Debt Collection Office. Checks and money orders must be made out to the Internal Revenue Service, along with a completed Form 11664-G, _PTSP Return of Fare Media._ The form and check or money order should be mailed to the IRS-Debt Collection Office, P O Box 9002, Beckley, W.Va. 25802-9002. If paying by credit/debit card, participants should input an [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do) ticket for PTSP Questions & Assistance for instruction on how to use [pay.gov](https://www.pay.gov/public/form/start/51115154).

5. Participants who have not used their PTSP benefits for a minimum of six months will be automatically withdrawn from the system by DOT.


**1.32.15.9** **(04-25-2023)**

### Repayment of PTSP Benefits

1. If a participant uses or accepts PTSP Benefits when they are ineligible they are required to repay any amount used. This includes but is not limited to, participants who have retired, resigned withdrawn and/or are in possession of any unused or excess transit benefit that they have accepted or downloaded as a participants in PTSP.

2. Repayments to the IRS must be submitted via check or money order to the IRS-Debt Collection Office, P O Box 9002, Beckley, W.Va. 25802-9002, or credit or debit card via [pay,gov.](https://www.pay.gov/public/form/start/51115154) If paying by credit/debit card, participants must input an [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do) ticket for PTSP Questions & Assistance to receive instruction on how to use [pay.gov.](https://www.pay.gov/public/form/start/51115154)

3. Transit cards of any type cannot be returned to the Service or used as payment for excess benefit that has been accepted by program participants.

4. PTSP benefits loaded to local transit cards (ex. Clipper, Breeze, SmarTrip, Ventra or SEPTA keycard, etc.) should not be return as they are not a form of repayment for unused funds. The participant should reimburse the IRS by submitting payment via check, money order, or credit, debit card via [pay.gov](https://www.pay.gov/public/form/start/51115154) to the IRS-Debt Collection Office. Checks and money orders must be made out to the Internal Revenue Service, along with a completed Form 11664-G, _PTSP Return of Fare Media._ The form and check or money order should be mailed to IRS-Debt Collection Office, P O Box 9002, Beckley, W.Va. 25802-9002. If paying by credit/debit card, participants must input an [OS GetServices](https://selfservice.web.irs.gov/webtier-9.52/ess.do) ticket for PTSP Questions & Assistance to receive instructions on how to use [pay.gov](https://www.pay.gov/public/form/start/51115154)


**1.32.15.10** **(07-22-2020)**

### PTSP Manual Forms

1. Form 11664 - D - PTSP Cash Reimbursement Certification - This form may only be utilized when the Cash Reimbursement SharePoint Site is unavailable. Any forms submitted while the Cash Reimbursement SharePoint Site is available will not be accepted. The form should be submitted within 30 days after the end of the quarter by participants in those instances when the transit benefit is not accepted or available. Cash reimbursements are not authorized for participants who did not use the funds from the TRANServe credit card or failed to complete their annual recertification of benefits timely. Any approved cash reimbursement forms will have an electronic payment sent to their current EFT information.

2. Form 11664 - E - PTSP Authorization for Third Party Pick-Up - The form is prepared and signed by the participant and given to the designated co-worker authorizing them to pick up their transit subsidy on their behalf.

3. Form 11664-F - PTSP Signature Sheet for Up-Front Monthly/Quarterly Distribution - The FMD will present this form to participants at the transit benefit distribution. Participants sign and date the form indicating receipt and acceptance of the transit voucher.

4. Form 11664-G - PTSP Participant Return of Fare Media - The form is submitted when an employee withdraws from the program, separates from the Service, or has expired or damaged transit subsidy. Participants should not write void or destroy the transit subsidy. The form is also used if the participant has received more transit subsidy than entitled. The participant should send the form along with a check or money order to the PTSP Office.


**1.32.15.11** **(04-25-2023)**

### SmartBenefits

1. Participants using Washington Metro Area Transit Authority's (WMATA) metro rail and/or bus system are required to purchase a SmarTrip card. You can purchase one by mail, online or at Metro's sales offices and area transit stores. SmarTrip cards must be registered with Metro at the time of purchase by telephone at 1-888-762-7874 or on-line at [www.smartrip.com.](https://smartrip.com/rcsc.html)

2. SmarTrip cards must be registered to match the name in Discovery Directory on the IRS Source.

3. The SmarTrip card must be registered prior to submitting a TRANServe application. The SmarTrip card number must be included on the TRANServe application. Failure to include the SmarTrip card number will result in a disapproved application and may cause a delay in benefits.

4. Information pertaining to the use or functionality of the SmarTrip card may be found on the [WMATA.com website.](https://www.wmata.com/)

5. Unused SmartBenefits are automatically returned to the DOT at the end of each month.

6. Lost, stolen, damaged or malfunctioning SmarTrip cards that have been registered, can be replaced without losing any of the fare value by contacting Metro at 1-888-762-7874. The PTSP Office cannot replace the funds or assist with the replacement of the SmarTrip card. Metro will transfer the balance to the new SmarTrip card and deduct the cost of a new card from your personal purse and mail it to you. Ensure the new card is registered and then complete a SmarTrip change application [TRANServe website](https://transitapp.ost.dot.gov/) to update the SmarTrip card number to match the new number.

7. Participants should not use their SmarTrip cards with the PTSP transit benefit for personal use at any time.

8. Senior citizens (65 and older) and persons with disabilities may contact WMATA for information regarding the option to receive a reduced fare card offered under the WMATA senior/disabled SmarTrip guidelines.


**1.32.15.12** **(04-25-2023)**

### Details

1. Employees on detail assignments may qualify for the IRS PTSP program.



1. Detail must be at least 90-days or more in order to be eligible. Any detail for less than 90-days is not eligible for PTSP benefits.

2. Employees who are already enrolled in the PTSP and are detailed for more than 90-days may update their current benefits to reflect any changes to the benefit amount needed. If the detail is less than 90-days and the cost to commute remains the same no change is needed. If the cost of your commute increases for a detail of less than 90 days, the difference in cost is the employee’s responsibility and not eligible for additional funding.

3. Employees who are not already enrolled in the PTSP may enroll if the detail is for 90-days or more. If the detail is less than 90-days, the employee may not enroll in the PTSP.


**1.32.15.13** **(04-25-2023)**

### Unlimited Pass

1. Participants in the PTSP are not authorized to use the PTSP benefit for local in-and-around travel (i.e., case related meetings, site visits, union stewards., etc.). Local travel must be claimed via the [ConcurGov](https://sso.treasury.gov/login/forms/uid/tedsprod?TYPE=33554433&REALMOID=06-a93f37a4-c127-1007-85bb-862082da0000&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-hq%2bwQcYIMyICH5ANWuO7p8%2b8ZLTAiStOHLPyxj7LB3oG8PbiTYluzMaWrBRpgWMWAQjTdbV%2bCwc%2fWOQBS%2fldTz6LUrLWpo8FYR9zB4od6pNCOAbr%2f0DbtNqVQtsS%2b2EO&TARGET=-SM-HTTPS%3a%2f%2fsso%2etreasury%2egov%2flogin%2fredirect%2fuid%2ftedsprod%3fSPID%3dcge%2econcursolutions%2ecom%26SMPORTALURL%3dhttps-%3A-%2F-%2Fsso%2etreasury%2egov-%2Faffwebservices-%2Fpublic-%2Fsaml2sso%26SAMLTRANSACTIONID%3d7ea0c7cc--07f75685--6995c0e1--4f1aed3d--2adb98cf--59) program as a local travel authorization/voucher.

2. A monthly or unlimited type pass may not be the most cost-effective/efficient mode of transportation for regular commute between residence and official POD based on work schedule. Local travel should not be considered when applying for PTSP benefits and/or as part of your monthly commute. Purchasing these types of passes for use outside of commuting between residence and official POD is not authorized.

3. Participants cannot use PTSP benefits and file a local travel authorization/voucher for the same expenses.


**1.32.15.14** **(04-25-2023)**

### TRANServe Credit Card

01. In partnership with DOT, TRANServe is a program to deliver transit benefits to participants through a branded federal credit card, called the TRANServe credit card. The TRANServe credit card provides a green, cost-efficient, all electronic method for employees to receive their monthly transit benefit.

02. TRANServe credit card are accepted for the majority of transit providers throughout the United States.

03. The TRANServe credit card must be activated upon receipt by contacting US Bank at the customer service number on the back of the card (1-888-994-6722 or 711 for hearing impaired). The Interactive Voice Response (IVR) system will guide the cardholder through the automated processed.

04. Participants cannot receive a cash reimbursement for unused funds available on the TRANServe credit card.

05. The TRANServe credit card must be returned to the participants manager of record when furloughed, on approved extended leave. If the employee is separating from the Service or withdrawing they can return the TRANServe credit card to the manager or destroy it.

06. Management is responsible for the safekeeping of the card during this time and must return the TRANServe credit card to the furloughed employee upon their first day back to work status.

07. Participant is responsible for recertifying their PTSP benefits through the [TRANServe website](https://transitapp.ost.dot.gov/) upon return to work in order for benefits to be restored.

08. Each time you use your TRANServe credit card you certify:



    1. I am employed by the federal government.

    2. I am eligible for a public transportation benefit.

    3. I will only use the transit benefit for my daily commute to and from my residence and official POD.

    4. I will not use the benefit for local visits to other offices.

    5. I will not give, sell or transfer my transit benefit to anyone else.

    6. I will not use the government-provided transit benefit in excess of the statutory limit.

    7. I will not include parking fees in the computation of the daily, weekly or monthly commuting cost.


09. Participants who move to a new POD within IRS and currently have a TRANServe credit card should keep the card and take it to their new POD. The card is still active and loaded with funds which can be used towards their new commuting cost. Participants must complete a change application through the [TRANServe website](https://transitapp.ost.dot.gov/) for their updated commute to their new POD and include any applicable information in the comments for agency approver section.

10. Participants who transfer to another agency must withdraw from the program and either return the TRANServe credit card using Form 11664-G _PTSP Participant Return of Fare Media_ or destroy the card. If the participant does not withdraw from the IRS PTSP, they will not be able to enroll with another agency.


**1.32.15.15** **(07-22-2020)**

### Home Delivery of TRANServe Credit Card

1. The TRANServe credit cards are mailed by the contracted bank to the home address on the participants PTSP application unless otherwise directed by the participant.


**1.32.15.16** **(07-22-2020)**

### Senior Passes

1. The PTSP Administrative Office encourages seniors to take advantage of senior and/or Medicare cardholder discounts. Check with your local transit authority to see if they offer senior discounts. Eligible participants can update their PTSP commuting cost by completing a rate change on the TRANServe website.


**1.32.15.17** **(04-25-2023)**

### Teleworking

1. PTSP participants who telework regularly should abide by the following:



1. Ensure the transit benefits requested matches the number of days in the office per your time and attendance records. Benefits can’t exceed the amount needed. Participants may contact their local transit authority for information and/or guidance on the most cost-effective/cost-efficient type of pass for their commute.


**1.32.15.18** **(04-25-2023)**

### Natural Disaster/Evacuation Order

1. For any natural disaster or evacuation order (i.e., pandemic condition) participants should always follow the guidelines provided by the PTSP Office. PTSP guidance will be made available to all IRS employees through multiples means of communications, including the IRS Source PTSP Page, IRS Daily news articles, Headlines articles, Leaders Alerts and targeted e-mails or United States Postal Service notifications/letters when applicable.

2. Participants must ensure that they are not using PTSP benefits when not commuting via public transportation to/from residence and official POD, including any auto-pay services setup through their transit authority for automatic purchases. This will result in repayment of PTSP benefits.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-032-015#addtoany "Show all")

A2A