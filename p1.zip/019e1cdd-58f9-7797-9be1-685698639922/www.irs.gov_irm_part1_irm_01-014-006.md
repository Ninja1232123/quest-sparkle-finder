---
url: "https://www.irs.gov/irm/part1/irm_01-014-006"
title: "1.14.6 Real Property Management Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-006#main-content)

- 1.14.6 [Real Property Management Program](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408974549680)
  - 1.14.6.1 [Program Scope](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408974474880)
    - 1.14.6.1.1 [Background](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408974544736)
    - 1.14.6.1.2 [Authority](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408949237520)
    - 1.14.6.1.3 [Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408974647984)
    - 1.14.6.1.4 [Acronyms](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408974589584)
    - 1.14.6.1.5 [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408974555648)
  - 1.14.6.2 [Directives](https://www.irs.gov/irm/part1/irm_01-014-006#idm140408937405440)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 6. Real Property Management Program

* * *

## 1.14.6 Real Property Management Program

#### Manual Transmittal

September 27, 2017

#### Purpose

(1) This transmits revised Internal Revenue Manual (IRM) 1.14.6, _Facilities Management, Real Property Management Program_.

#### Material Changes

(1) On October 1, 2014, Real Estate and Facilities Management (REFM) merged with Physical Security and Emergency Preparedness (PSEP) to create Facilities Management and Security Services (FMSS). This IRM has been updated to reflect current organization titles.

(2) As of January 1, 2017, the Internal Revenue Service (IRS) instituted a requirement that the IRM addresses relevant internal controls. This will inform employees about the importance of and context for internal controls by describing the program objectives and officials charged with program management and oversight. Internal controls are the program’s policies and procedures which ensure:

1. Mission and program objectives are clearly delineated and key terms defined.

2. Program goals are established and performance is measured to assess the efficient and effective mission and objective accomplishment.

3. Program and resources are protected against waste, fraud, abuse, mismanagement and misappropriation.

4. Program operations are in conformance with applicable laws and regulations.

5. Financial reporting is complete, current and accurate.

6. Reliable information is obtained and used for decision making and quality assurance.


(3) Added the additional authority, GSA Leasing Desk Guide, to IRM 1.14.6.6(d).

(4) Added responsibilities regarding the physical security program.

(5) Included reference to IRM 10.2, Physical Security Program.

(6) Included the Department of Homeland Security (DHS) and Interagency Security Committee (ISC).

(7) Links listed in the IRM are working, however, due to the IRS firewalls, the websites may not be accessible.

#### Effect on Other Documents

This IRM supersedes IRM 1.14.6 dated July 08, 2013.

#### Audience

Facilities Management and Security Services

#### Effective Date

(09-27-2017)

Richard L. Rodriguez

Director

Facilities Management and Security Services

Agency-Wide Shared Services

**1.14.6.1** **(09-27-2017)**

### Program Scope

1. FMSS provides Real Property Management (RPM) program support to all entities of the IRS and provides:



1. management of all space occupied by IRS.

2. Standard Operating Procedures (SOP) and guidance for the use of all IRS space.

3. strategic portfolio planning to assist IRS entities with short and long-term housing needs.

4. acquisition of space through the General Services Administration (GSA), other governmental entities and IRS Lease Contracting Officers under authority delegated by GSA.

5. space planning and design services for new space.

6. alterations and reconfiguration of existing space.


2. **Purpose**: This IRM provides information pertinent to the operation of the FMSS RPM Program.

3. **Audience**: FMSS.

4. **Policy Owner**: Director, FMSS.

5. **Program Owner**: Associate Director, RPM, FMSS.

6. **Primary Stakeholders**: FMSS employees.


**1.14.6.1.1** **(09-27-2017)**

#### Background

1. This IRM provides the purpose, program description, objectives, directives, responsibilities, and authorities for the Real Property Management Program. This section is primarily for the use of space management personnel in FMSS.

2. The objectives of the FMSS RPM Program are to:



1. facilitate quality customer service and the collection of taxes by providing offices that are convenient and accessible to the public.

2. enhance productivity through a quality work environment that is secure and comfortable.

3. provide portfolio flexibility to accommodate program variability.

4. foster effective space utilization.

5. provide the most cost effective housing for IRS by utilizing telework strategies, workstation sharing, universal workstation designs, and other alternative workspace arrangements for out of office employees, where applicable.

6. ensure accurate charges for IRS space under the Federal Buildings Fund Rent system and GSA space pricing policy, including negotiation of GSA/IRS Occupancy Agreements (OA).


**1.14.6.1.2** **(09-27-2017)**

#### Authority

1. GSA prescribes the procedures and methods governing the acquisition, utilization, assignment, pricing, and release of IRS space in government-owned and leased buildings controlled by GSA, or delegated to IRS, in the United States.

2. GSA performs all functions associated with the acquisition of leasehold interest in real property for IRS, except as otherwise specified in GSA Federal Management Regulations (FMR) Bulletin C-2, _Delegations of Lease Acquisition Authority - Notification, Usage, and Reporting Requirements for General Purpose, Categorial, and Special Purpose Space Delegations_. [https://www.gsa.gov/portal/content/102955#RealPropertyManagement](https://www.gsa.gov/portal/content/102955#RealPropertyManagement)

3. The regulations and directives outlined in IRM 1.14.6.6 are necessary to administer the FMSS RPM Program:



01. FMR, Chapter 102, Subchapter C, Real Property (41 Code of Federal Regulations (CFR) Ch. 102). Parts 102-71 through 102-84 prescribe policies and procedures for agencies operating under the authority of GSA, or occupying government-owned or leased space under the control of GSA, including: facility management; maintenance and alterations; design and construction; utility services; assignment and utilization of space, pricing policy for occupancy in GSA space; real estate acquisition; fire and life safety; environmental management; and security requirements. [http://www.gsa.gov/fmr](http://www.gsa.gov/fmr)

02. [GSA Pricing Desk Guide, Latest Edition](http://www.gsa.gov/portal/content/104909) governs the pricing of GSA's real estate and related services, including agency rights and responsibilities under various types of occupancy.

03. [GSA Customer Guide to Real Property PDF](http://www.gsa.gov/graphics/pbs/Guide_to_Real_Propertybookmarked2002_R2E-c-pK_0Z5RDZ-i34K-pR.pdf) explains how to request, use, and service GSA-controlled space.

04. [GSA Leasing Desk Guide](http://www.gsa.gov/portal/category/105079), contains authorities, policies, technical and procedural guides, and administrative limitations governing the acquisition by lease of real property.

05. [Treasury Directive 72-02, Acquisition, Utilization, and Disposal of Treasury Real Property Assets, September 24, 2009](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td72-02.aspx), contains provisions for the Treasury Department’s acquisition, management, and disposal of real property assets by utilizing prudent asset management practices that optimize utilization of space.

06. [Treasury Directive 72-03, Location of New Offices and Facilities in Rural Areas, July 14, 2004](http://www.treasury.gov/about/role-of-treasury/orders-directives/Pages/td72-03.aspx), requires that first priority be given to locating new Treasury facilities in rural areas.

07. [FMR, Subchapter C, Real Property, Part 102-83 “Location of Space” (41 CFR Ch. 102-83)](http://www.gsa.gov/portal/ext/public/site/FMR/file/FMRTOC102-_83.html/category/21859/), contains provisions for ensuring that executive agencies follow certain statutes, regulations and policies when identifying a geographic service area and the delineated area within which it wishes to locate specific activities, consistent with its mission and program requirements.

08. [Executive Order 12072, Federal Space Management, August 16, 1978](http://www.archives.gov/federal-register/codification/executive-order/12072.html), requires agencies with mission needs for space in urban areas to give first consideration to centralized community business areas and adjacent areas of similar character, including other specific areas which may be recommended by local officials, except when such selection is otherwise prohibited.

09. [Executive Order 13006, Locating Federal Facilities on Historic Properties in Our Nation's Central Cities, May 21, 1996](http://www.archives.gov/federal-register/executive-orders/1996.html), encourages federal agencies to locate facilities on historic properties in central cities.

10. [Executive Order 12411, Government Work Space Management Reforms, March 29, 1983](http://www.archives.gov/federal-register/codification/executive-order/12411.html), requires agencies to establish programs to produce and maintain an inventory of work space and related furnishings, reduce the amount of work space used or held to essential minimums, utilize all agency furnishings in a manner that reflects a judicious employment of public moneys; and report to the Administrator of General Services any holdings not necessary for the mission of the agency.

11. [Executive Order 13327, Federal Real Property Asset Management, February 4, 2004](http://www.archives.gov/federal-register/executive-orders/2004.html), requires agencies to designate a Senior Real Property Officer who will be responsible for implementing and developing a continuous and comprehensive Asset Management Plan (AMP) process for the agency. This process includes identifying and categorizing all real property owned, leased or otherwise managed by the agency; prioritizing actions to be taken to improve the operational and financial management of the agency's real property inventory, and using public and commercial benchmarks and best practices to periodically evaluate all assets, among other items.

12. [Executive Order 13423, Strengthening Federal Environmental, Energy, and Transportation Management, January 24, 2007](http://www.archives.gov/federal-register/executive-orders/2007.html), requires agencies to develop and implement sustainable practices in the construction, operation, and maintenance of federal facilities including: energy efficiency, promotion of sustainable and renewable energy resources, reduction of greenhouse gases, water conservation, pollution and waste prevention, and recycling, among other items.

13. [Public Law 110-140, Energy Independence and Security Act of 2007](http://www.gpo.gov/fdsys/pkg/PLAW-110publ140/pdf/PLAW-110publ140.pdf%20), contains provisions and requirements for the management and reporting of energy requirements for leased buildings under the control of GSA and agencies via delegated lease management authority, as well as for federal buildings.

14. [FMR Amendment 2008-08, FMR Case 2008-102.3 “Real Property Policies Update – Smoking Restrictions” (41 CFR Part 102-74) PDF](http://www.gpo.gov/fdsys/pkg/FR-2008-12-19/pdf/E8-30180.pdf), contains provisions for the restrictions on the smoking of tobacco products in leased or owned space under the jurisdiction, custody, or control of the Administrator of General Services.

15. [Executive Order 13693, Planning for Federal Sustainability in the Next Decade, March 19, 2015](http://www.archives.gov/federal-register/executive-orders/obama.html), requires agencies to achieve targeted goals in sustainability in the operation of federal facilities and fleets. Emphasis is on energy and water use, greenhouse gas emissions, carbon footprint, recycling, minimization of hazardous materials and chemical pollution, retrofit of federal facilities maximizing use of energy efficient and sustainable practices, and minimizing the environmental impact on communities where federal facilities are located, among other items.

16. [FMR Bulletin 2006-B3, “Guidelines for Alternative Workplace Arrangements"](http://www.telework.gov/guidance_and_legislation/fmr_bulletins/index.aspx), establishes guidelines for implementing and operating Alternative Workplace Arrangements (AWA). These guidelines are designed to assist agencies in the design and operation of AWA programs as well as to resolve AWA issues commonly faced by agencies.

17. [Public Law 111-292 Telework Enhancement Act of 2010](http://www.telework.gov/Telework_Enhancement_Act/). The Act is a key factor in the Federal Government's ability to achieve greater flexibility in managing its workforce through the use of telework. Telework programs provide agencies a valuable tool to meet mission objectives while helping employees enhance work/life effectiveness. Specifically, telework is a useful strategy to improve continuity of operations to help ensure that essential federal functions continue during emergency situations; promotes management effectiveness when telework is used to target reductions in management costs and environmental impact and transit costs; and enhances work-life balance.

18. [Executive Order 13589, Promoting Efficient Spending, November 9, 2011 PDF](https://www.gpo.gov/fdsys/pkg/FR-2011-11-15/pdf/2011-29683.pdf), requires agencies to develop and monitor plans to reduce administrative and operating costs in several areas including: travel, extraneous promotional items, employee information technology devices, printing, and employee relocation expenses and to maximize use of electronic communications to the maximum extent practicable in conducting Federal Government business.

19. [General Services Administration Acquisition Regulation (GSAR) Part 570 - Acquiring Leasehold Interests in Real Property](https://www.acquisition.gov/gsam/current/html/Part570.html). The GSAR is included in the GSA Acquisition Manual (GSAM). GSAM Part 570 is applicable to agencies who receive delegated leasing authority from GSA.

20. Public Law 86-249 - Public Buildings Act of 1959, As Amended Certain leasing actions that GSA undertakes on behalf of federal agencies require congressional authorization if the net annual rent under a lease contract exceeds a certain value. The value, known as the prospectus threshold, is established annually by GSA and approved by Congress. Net annual rent excludes operating expenses, defined as services and utilities necessary for occupancy. Net annual rent includes fixed expenses such as real estate taxes or escrows or reserves for capital improvements and/or replacement. Additionally, congressional authorization is required for space alterations in leased space if the value of the alterations exceeds one-half of the prospectus threshold. The types of leased space alteration projects subject to the prospectus threshold include: alterations for any agency after initial occupancy by that agency; alterations to prepare vacant space for backfill by any agency other than the original tenant agency; and improvement to building systems or architectural features after initial occupancy. Architectural, design, and construction expenses are all considered in determining whether an alterations project is applicable to the prospectus threshold. Moving expenses, temporary relocation costs, and furniture are not included in the project cost for prospectus purposes. The prospectus threshold is also applicable to space alterations in government-owned space: [Real Property Asset Management Tools](http://www.gsa.gov/portal/content/104040) and [GSA Annual Prospectus Thresholds](https://www.gsa.gov/portal/content/101522).

21. [Public Law 98-369 - Competition in Contracting Act (CICA)](http://www.gsa.gov/portal/content/100915), CICA requires certain agencies to obtain full and open competition in the acquisition of supplies and services, including leased space. CICA is applicable to agencies who receive delegated leasing authority from GSA.

22. General Services Administration General Reference Guide for Real Property Policy (October 2010). IRS must adhere to other applicable laws, regulations and executive orders pertaining to real property acquisition, use and management. [https://www.gsa.gov/portal/content/129999](https://www.gsa.gov/portal/content/129999)


**1.14.6.1.3** **(09-27-2017)**

#### Responsibilities

1. The Director, FMSS in conjunction with the Deputy Director, FMSS, has overall responsibility as it relates to the management of real property for:



1. development and administration of a long-term space and housing strategy for IRS.

2. determining objectives, practices, and standards for RPM throughout IRS.

3. ensuring that effective space utilization is promoted throughout the IRS.

4. ensuring space management best practices are implemented throughout FMSS.

5. assisting the Chief, Agency-Wide Shared Services (AWSS) in administering the IRS rent budget.

6. ensuring alignment and compatibility of actions within the IRS strategic plans and business visions.

7. monitoring functional compliance with service level agreements and balanced measures systems.

8. developing strategies for improving functional service delivery to Business Units (BU) including resolution of issues of mutual concern.

9. developing and maintaining external contacts, including Treasury, DHS, ISC, National Treasury Employees Union (NTEU), GSA, National Archives and Records Administration (NARA), professional organizations, and contractors.


2. The FMSS Associate Director, Security Policy, is responsible for:



1. planning, developing, evaluating, and controlling the Physical Security program.

2. ensuring collaboration between Security Policy and Project Management to verify security requirements are considered during project planning and implementation.

3. providing physical security policy, program guidance, oversight and assistance to area and territory offices.

4. ensuring Security Work Authorizations (SWA) and all physical security funding aspects are reconciled.


3. The Associate Directors (AD), Operations, are responsible for:



1. providing RPM services to all customers through the Territory Managers (TM) in their respective geographical areas of responsibility.

2. ensuring timely execution of space management program activities, determining appropriate strategies to achieve FMSS, BU, and IRS program goals

3. managing resources and ensuring proper application of IRS and government-wide real property policies and regulations.

4. working with BU representatives to identify customer needs, meet service demands, resolve customer problems, implement service level agreements and ensure effective utilization of space and resources.

5. managing improvements in FMSS business processes and systems.

6. formulating, executing, and monitoring facilities management support funds, in conjunction with the TM and the AWSS AD for Technology & Investments Strategy (TIS) and Financial Management Branch (FMB).

7. working with GSA and other public officials to resolve issues impacting FMSS service delivery.

8. implementing physical security policy for their respective territory offices.


4. The AD, RPM, is responsible for:



01. developing and implementing guidance, procedures, objectives, practices and standards for the administration, management and oversight of the IRS real property, space management and delegated leasing programs.

02. developing and administering long-term space and housing strategy.

03. developing and managing IRS AMP through the Chief, Portfolio and Rent Management, who reports to the AD, RPM. An AMP allows for a continuous integrated strategy between RPM and the territories to effectively manage the real estate portfolio.

04. facilitating the integration of Design & Strategic Campus Planning (DSCP), FMSS requirements into the long-term space and housing strategy for campus locations.

05. reviewing and approving IRS space requests.

06. negotiating, reviewing and approving IRS OA.

07. accurately maintaining data for rent, leases and OA in the Graphic Database Interface (GDI) application.

08. tracking the inventory of IRS space holdings, forecasting rent for current and future years, monitoring actual rent expenses, verifying the accuracy of GSA bills and ensuring that billing errors get corrected.

09. ensuring that IRS real estate management practices are consistent with presidential directives and executive orders, federal laws, regulations and policies.

10. ensuring that geographic boundaries are established in accordance with Treasury Directive 72-03, _Location of New Offices and Facilities in Rural Areas_, and FMR, Subchapter C, Real Property, Part 102-83, _Location of Space_, (41 CFR Part 102-83).

11. representing IRS with Treasury, GSA, contractors, industry trade and professional organizations, and other stakeholders regarding the management of real estate and other cross-functional issues.

12. providing real property and space management subject matter expert training and technical support to FMSS staff.

13. managing and executing the IRS real property lease contracting program using authority delegated by GSA, Treasury and IRS Procurement, including acquisition and administration of leased space by Real Property Leasing Officers and management of the acquired space in conjunction with territory Contracting Officer’s Representatives (COR), as well as responding to any legal protests or litigation resulting from the program.


5. The AD, Project Management, is responsible for:



1. managing FMSS programs for project development, prioritization and approval of space projects, including the Project Investment Fund.

2. developing the National Workspace Standards (NWS) and working in conjunction with DSCP, FMSS, on office design guides for different types of space.

3. developing work space improvements and innovative housing solutions under the Servicewide Workplace Strategies initiative.

4. providing SOP, training and resources to continuously improve IRS work space through effective and efficient project delivery.

5. developing innovative and sustainable furniture design and acquisition procedures.

6. ensuring collaboration between Project Management and Security Policy to verify security requirements are considered during project planning and implementation.


6. The AD, Design and Strategic Campus Planning (DSCP), is responsible for:



1. strategic planning of the campus space portfolio.

2. working with TM to review the campus real estate portfolio related to submission processing sites to maximize utilization of space.

3. executing major space projects associated with the campus portfolio such as campus replacement or major repair and alterations.

4. development and management of the Buildings Delegation Program, including determining objectives, budget, practices and standards for building and energy management in accordance with the terms of GSA delegation agreements with Treasury and IRS, and approval of new, amended, and expiring delegations.

5. delivering architectural, engineering, construction design and cost estimating services for FMSS.

6. developing and maintaining the IRS Facilities Design Criteria.

7. assisting Project Management in the development of office design guides for different types of space.

8. ensuring that all IRS operations and occupied facilities are managed, maintained and operated in accordance with IRS _Environment, Health and Safety Policy, P-1-235_, found in IRM 1.2.10.36, _Organization, Finance, and Management, Servicewide Policies and Authorities, Policy Statements for Organization, Finance and Management Activities_, IRM 1.14.5, _Occupational Health and Safety Program_, and all applicable federal, state and local environmental, health and safety regulations.

9. ensuring that IRS occupied buildings with delegated building management and operation authority are managed, maintained and operated in accordance with IRS _Environment, Health and Safety Policy, P-1-235_, found in IRM 1.2.10.36, _Organization, Finance, and Management, Servicewide Policies and Authorities, Policy Statements for Organization, Finance and Management Activities_, IRM 1.14.12, _IRS Environmental Compliance Program_, and all applicable federal, state and local environmental, health and safety regulations.


7. The AD, Business Systems Management (BSM) is responsible for:



1. developing and implementing guidance, procedures, objectives, practices and standards for the administration, management and oversight of the IRS GDI and Computer Assisted Facilities Management (CAFM) programs.

2. developing and implementing information technology strategies to support the FMSS RPM program.

3. developing and managing the GDI application through the Chief, Technology Integration (TI), who reports to the AD, BSM.

4. providing training and technical support to FMSS staff nationwide on the GDI application and KISAM system.

5. processing the monthly IRS Rent bill and attributing costs to each BU at the individual TIMIS cost center level and the building level cost centers.

6. providing National Point of Contact (NPOC) for all FMSS functions on all ERC/KISAM-related issues, i.e., ERC Web content changes, ticket cycle time changes, establishing call types, elevated issues on the KISAM system, and feedback on customer satisfaction levels.

7. providing guidance and training on ERC/KISAM-related policies and procedures.

8. developing and managing the IRS Post-of-Duty (POD) Model application.


8. The TM, in coordination with the AD for Operations, FMSS, is responsible for:



01. providing space management services to all customers in their respective geographical areas of responsibility.

02. ensuring timely execution of program activities, determining appropriate program emphasis to achieve goals, managing territory resources, and ensuring proper application of IRS and government-wide policies and regulations.

03. working with RPM to actively review the real estate portfolio to maximize utilization of space.

04. ensuring that requests for space have been thoroughly analyzed, conform to FMSS and IRS procedures the IRM, NWS, and applicable design guides.

05. ensuring that projects are delivered timely and within scope and budget.

06. ensuring changes to planned or cancelled projects are communicated immediately to TIS, FMB, AWSS and FMSS Project Management.

07. ensuring that lessor obligations are satisfied, performance is monitored, and files are maintained for leases procured under delegated leasing or lease management authority granted by GSA.

08. accurately maintaining data for buildings, space usage, classification, measurement, floor plans and furniture in the GDI application.

09. implementing, evaluating and managing the local physical security program and for providing guidance, oversight and assistance to client sites.

10. ensuring collaboration between Project Management and Security Policy to verify security requirements are considered during project planning and implementation.

11. ensuring SWA and all physical security funding aspects are reconciled.


9. The AD, TIS, FMB, AWSS, is responsible for:



1. managing appropriated funds provided by Congress and made available to FMSS by the Chief Financial Officer (CFO) to ensure that funding is available to support the FMSS mission.

2. ensuring funds are spent properly and within the timeframes allowed for each appropriation.

3. monitoring and tracking FMSS expenditures to ensure that all funds are properly obligated or returned to the CFO for other uses.

4. funding FMSS activities including the payment of rent, space projects, acquisition of furniture, facilities maintenance, and support contracts.

5. providing funds in support of FMSS personnel including salaries and benefits, overtime, travel, training, and supplies.


**1.14.6.1.4** **(09-27-2017)**

#### Acronyms

1. The following acronyms are used throughout this document:




| **Acronym** | **Definition** |
| --- | --- |
| AD | Associate Directors |
| AMP | Asset Management Plan |
| AWA | Alternative Workplace Arrangements |
| AWSS | Agency-Wide Shared Services |
| BU | Business Units |
| CAFM | Computer Assisted Facilities Management |
| CFO | Chief Financial Officer |
| CFR | Code of Federal Regulations |
| CICA | Competition in Contracting Act |
| COR | Contracting Officer’s Representatives |
| DHS | Department of Homeland Security |
| DSCP | Design and Strategic Campus Planning |
| ERC | Employee Resource Center |
| FMB | Financial Management Branch |
| FMR | Federal Management Regulations |
| FMSS | Facilities Management and Security Services |
| GDI | Graphic Database Interface |
| GSA | General Services Administration |
| GSAM | General Services Administration Acquisition Manual |
| GSAR | General Services Administration Acquisition Regulation |
| IPS | Integrated Procurement System |
| ISC | Interagency Security Committee |
| KISAM | Knowledge, Incident/Problem, Service Asset Management |
| NARA | National Archives and Records Administration |
| NPOC | National Point of Contact |
| NTEU | National Treasury Employees Union |
| NWS | National Workspace Standards |
| OA | Occupancy Agreements |
| POD | Post of Duty |
| RPM | Real Property Management |
| RWA | Reimbursable Work Authorization |
| SOP | Standard Operating Procedures |
| SWA | Security Work Authorization |
| TAC | Taxpayer Assistance Center |
| TI | Technology Integration |
| TIMIS | Treasury Integrated Management Information System |
| TIS | Technology & Investments Strategy |
| TM | Territory Managers |


**1.14.6.1.5** **(09-27-2017)**

#### Related Resources

1. IRM 1.2.10.36, _Organization, Finance, and Management, Servicewide Policies and Authorities, Policy Statements for Organization, Finance and Management Activities, Environment, Health and Safety Policy, P-1-235_

2. IRM 1.2.40.37, Delegation Order 1-45, _Requests for Space and Occupancy Agreement_

3. IRM 1.14.5, _Occupational Health and Safety Program_

4. IRM 1.14.9, _IRS Parking Program_

5. IRM 10.2, _Physical Security Program_


**1.14.6.2** **(09-27-2017)**

### Directives

1. The directives in IRM 1.14.6.2 must be adhered to in the administration of the FMSS RPM Program.



01. The IRS FMSS NWS will be utilized when acquiring or altering space. The IRS Facilities Design Criteria and the IRS-FMSS Office Design Handbook will be utilized when space is constructed for occupancy by IRS and will be considered to the maximum extent practicable for existing space. Additionally, the IRS-FMSS Career Management and Learning Centers Training Space and IRS-FMSS Taxpayer Assistance Center (TAC) Design Guides must be used for the design of these specialized facilities. Due to security concerns, the IRS does not fund the construction of restroom facilities for general public use within IRS assigned space.

02. The AMP will be used as the basis for development of projects that best serve the mission of IRS within resource limitations. Portfolio and Rent Management, RPM, will ensure that an AMP is developed and completed in accordance with published guidance and managerial direction and will be responsible for tracking, maintaining and consolidating the asset management data for the IRS portfolio. DSCP has responsibility for campus planning where submission processing functions are performed.

03. Form FMSS-81, _IRS FMSS Request For Space_, will be used to request space from GSA or to lease space under delegated GSA authority. All FMSS-81 forms must be submitted for review and approval to the Director, FMSS, or designee, in accordance with Delegation Order 1-45, _Requests for Space and Occupancy Agreement,_ and other existing FMSS guidance.

04. GSA Form 2957, _Reimbursable Work Authorization (RWA)_, will be used to request arrangements from GSA for tenant improvements and building services which are otherwise not included in rent, as well as for special projects on an as-needed basis. All RWA must be approved by the TM, or designee. The FMB must certify funding through the Integrated Procurement System (IPS) prior to submission to GSA.

05. The FMSS GDI system Rent Module provides both current fiscal and out year data for the IRS rent budget, allowing FMSS to project the IRS rent budget requirements. The GDI Rent Module is also utilized to validate GSA rent charges.

06. The provisions contained in Federal Management Regulation (FMR), Subchapter C, Real Property, Part 102-72, Delegation of Authority (41 CFR Part 102-72) and FMR Bulletin C-2 “Delegations of Lease Acquisition Authority – Notification, Usage, and Reporting Requirements for General Purpose, Categorical, and Special Purpose Space Delegations” will be followed and utilized by the FMSS delegated leasing program under the authority granted by GSA.

07. All security, safety, and environmental requirements established by federal, state, and local authorities must be adhered to.

08. Accommodations for persons who are physically disabled will be provided in all leased facilities in accordance with the Architectural Barriers Act Accessibility Standard effective February 7, 2007. The standard was issued under the provisions of FMR, Subchapter C, Real Property, Part 102-76, Subpart C, Architectural Barriers Act of 1968, as amended. (41 CFR Part 102-76)

09. The provisions contained in IRM 1.14.9, _IRS Parking Program_, direct the management, allocation and assignment of parking at all government-owned and leased IRS facilities; and the management of taxable parking benefits.

10. The provisions contained in FMR Amendment 2008-08, FMR Case 2008-102.3 “Real Property Policies Update – Smoking Restrictions” (41 CFR Part 102-74) address smoking in federally owned and leased buildings. Further, IRS does not fund the construction of indoor or outdoor smoking areas. IRS does support and facilitate smoking cessation programs.

11. The provisions contained in FMR Bulletin 2006-B3, “Guidelines for Alternative Workplace Arrangements", established guidelines for implementing and operating AWA. These guidelines are designed to assist agencies in the design and operation of AWA programs as well as to resolve AWA issues commonly faced by agencies. These guidelines should be utilized in conjunction with FMSS provisions for out of the office employees.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-006#addtoany "Show all")

A2A