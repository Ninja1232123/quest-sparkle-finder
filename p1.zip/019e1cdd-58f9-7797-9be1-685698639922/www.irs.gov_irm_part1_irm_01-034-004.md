---
url: "https://www.irs.gov/irm/part1/irm_01-034-004"
title: "1.34.4 Unpaid Assessments | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-034-004#main-content)

- 1.34.4  [Unpaid Assessments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095891264)
  - 1.34.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885123794976)
    - 1.34.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885123790832)
    - 1.34.4.1.2  [Authorities](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885094426016)
    - 1.34.4.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885094421056)
      - 1.34.4.1.3.1  [CFO and Deputy CFO](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885094415856)
      - 1.34.4.1.3.2  [Senior Associate CFO for Financial Management](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095132912)
      - 1.34.4.1.3.3  [Associate CFO for Revenue Financial Accounting](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095131136)
      - 1.34.4.1.3.4  [Unpaid Assessments and Analysis office](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095123040)
      - 1.34.4.1.3.5  [Chief and Analysts for Custodial Analysis and Reporting](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095118240)
      - 1.34.4.1.3.6  [Chief and Analysts for Unpaid Assessments Accounting Analysis](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885094315456)
      - 1.34.4.1.3.7  [Chief and Analysts for Unpaid Assessments Account Resolution](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885094311584)
    - 1.34.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885094305408)
    - 1.34.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095309040)
    - 1.34.4.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095303520)
    - 1.34.4.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095457648)
    - 1.34.4.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095424608)
  - 1.34.4.2  [Categorizations](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095418416)
    - 1.34.4.2.1  [Taxes Receivable](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095412784)
    - 1.34.4.2.2  [Compliance Assessment](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095409216)
    - 1.34.4.2.3  [Write-Off](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095406320)
    - 1.34.4.2.4  [Memo](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095404368)
    - 1.34.4.2.5  [Criteria for Split Categorization](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095401696)
  - 1.34.4.3  [Categorization Criteria for Taxes Receivable](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095398176)
    - 1.34.4.3.1  [Tax Returns](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095395136)
    - 1.34.4.3.2  [Manual Refunds](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095387408)
    - 1.34.4.3.3  [Installment Agreements](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095385536)
    - 1.34.4.3.4  [Offer in Compromise](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095370192)
    - 1.34.4.3.5  [Examination](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095349072)
    - 1.34.4.3.6  [Agreement to Substitute for Return](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095340368)
    - 1.34.4.3.7  [Tax Equity and Fiscal Responsibility Act of 1982 Examination](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095634960)
    - 1.34.4.3.8  [Partnership Bipartisan Budget Act (PBBA)](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095629888)
    - 1.34.4.3.9  [Abusive Tax Avoidance Transactions S-Corporation Charitable Contribution Strategy 2](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095618304)
    - 1.34.4.3.10  [Appeals Cases](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095613824)
    - 1.34.4.3.11  [Court Decision Cases](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095610112)
    - 1.34.4.3.12  [Restitution Based Assessments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095603104)
    - 1.34.4.3.13  [Bankruptcy Cases - Taxpayer Agrees to Pay the IRS Assessments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095595888)
    - 1.34.4.3.14  [Judgments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095586352)
    - 1.34.4.3.15  [Stand-Alone Penalties](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095581504)
    - 1.34.4.3.16  [Affordable Care Act](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095573840)
    - 1.34.4.3.17  [Individual Shared Responsibility Payment - Silent Returns](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095569616)
    - 1.34.4.3.18  [Employer Shared Responsibility Provision](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095566048)
    - 1.34.4.3.19  [Social Security Deferral](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095563248)
    - 1.34.4.3.20  [IRC U.S. Code Section 965 Transition Tax](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095560640)
    - 1.34.4.3.21  [Identity Theft](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095554256)
    - 1.34.4.3.22  [Frivolous Returns](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095551040)
    - 1.34.4.3.23  [Form 900 Waiver](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095547456)
    - 1.34.4.3.24  [Correspondence](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095545392)
    - 1.34.4.3.25  [Pattern of Payments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095543680)
    - 1.34.4.3.26  [Transaction Code 706 Refund Offset](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095529952)
    - 1.34.4.3.27  [Defunct or Bankrupt Entities](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095527312)
    - 1.34.4.3.28  [Trust Fund Recovery Penalty](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095523952)
    - 1.34.4.3.29  [Comments Section](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095518064)
  - 1.34.4.4  [Categorization Criteria for Compliance](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095513264)
    - 1.34.4.4.1  [Unagreed or Default Compliance Assessment](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095510080)
    - 1.34.4.4.2  [Manual Refunds](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095505488)
    - 1.34.4.4.3  [Frivolous Returns](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095502064)
    - 1.34.4.4.4  [Comments Section](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095499232)
  - 1.34.4.5  [Categorization Criteria for Write-Off](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095493616)
    - 1.34.4.5.1  [Individual Master File Write-Off Indicators](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885095481312)
    - 1.34.4.5.2  [Business Master File Write-Off Indicators](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885093040032)
      - 1.34.4.5.2.1  [Trust Fund Rollups](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092993664)
      - 1.34.4.5.2.2  [Frivolous Returns](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092989872)
      - 1.34.4.5.2.3  [Comment Section](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092988032)
  - 1.34.4.6  [Categorization Criteria for Memo](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092983088)
  - 1.34.4.7  [Criteria for Split Categorizations](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092967648)
    - 1.34.4.7.1  [Trust Fund Recovery Penalty](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092963600)
    - 1.34.4.7.2  [Non Trust Fund Recovery](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092960880)
  - 1.34.4.8  [Book Value Adjustments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092947984)
    - 1.34.4.8.1  [Abatements](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092943824)
    - 1.34.4.8.2  [Assessments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092935760)
    - 1.34.4.8.3  [Amended Return with Subsequent Adjustment](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092929328)
    - 1.34.4.8.4  [Penalties](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092926176)
    - 1.34.4.8.5  [Payments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092921920)
    - 1.34.4.8.6  [Misapplied Payments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092917552)
    - 1.34.4.8.7  [Transaction Code 706 Credit Offset](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092909408)
    - 1.34.4.8.8  [User Fee Sweeps](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092907664)
    - 1.34.4.8.9  [Trust Fund Recovery Penalty Related Modules](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092905824)
    - 1.34.4.8.10  [Manual Recategorization Review](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092902656)
  - 1.34.4.9  [Categorization Data Collection Instrument for Trust Fund Modules](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092899008)
    - 1.34.4.9.1  [Trust Fund Determination](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092887824)
    - 1.34.4.9.2  [Determining if the Business is Still Operating](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092885856)
    - 1.34.4.9.3  [Recalculating the Trust Fund Assessment Amount](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092883200)
      - 1.34.4.9.3.1  [Documentation](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092880112)
    - 1.34.4.9.4  [Errors in Posting Payments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092862608)
    - 1.34.4.9.5  [Recategorizing Trust Fund Recover Penalty Assessments Manually](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092857328)
  - 1.34.4.10  [Collectibility Criteria for Taxes Receivable](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092847248)
    - 1.34.4.10.1  [Long Term Payment Arrangement Data Collection Instrument](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092834192)
      - 1.34.4.10.1.1  [Installment Agreement](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092829920)
      - 1.34.4.10.1.2  [Determining if the Taxpayer is Current with Installment Agreement Terms](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092827040)
      - 1.34.4.10.1.3  [Other Long Term Payment Arrangements](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092824080)
      - 1.34.4.10.1.4  [Analysis of Collectibility for Installment Agreements and/or other Long Term Payment Arrangements](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092820080)
    - 1.34.4.10.2  [Bankruptcy Review Data Collection Instrument](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092812864)
      - 1.34.4.10.2.1  [Chapter 7 Liquidations](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092804400)
      - 1.34.4.10.2.2  [Chapter 9, 11, 12 and 13 Reorganization](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092801328)
      - 1.34.4.10.2.3  [Determining Payments Received](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092799376)
      - 1.34.4.10.2.4  [Other File Documentation](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092797408)
      - 1.34.4.10.2.5  [Assessing Bankruptcy Discharge](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092794992)
      - 1.34.4.10.2.6  [Alternative Method for Determining Collectibility](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092793120)
    - 1.34.4.10.3  [Estate Installment Agreement Data Collection Instrument](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092788416)
      - 1.34.4.10.3.1  [Section I: Payment Information on Estate Cases](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092784096)
      - 1.34.4.10.3.2  [Section II: Estate Cases not in Compliance with Agreement](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092781920)
      - 1.34.4.10.3.3  [Comment Section](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092779360)
      - 1.34.4.10.3.4  [Collectibility of Estate Cases with Section 6161 Election - Extension of Time to Pay](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092776064)
    - 1.34.4.10.4  [Offer in Compromise Data Collection Instrument](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092765808)
      - 1.34.4.10.4.1  [Documentation](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092758192)
      - 1.34.4.10.4.2  [Offer has been Accepted](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092746576)
      - 1.34.4.10.4.3  [Offer is Still Pending](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092742816)
      - 1.34.4.10.4.4  [Offer has been Withdrawn or Rejected](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092735200)
      - 1.34.4.10.4.5  [Collection Field Function Data Collection Instrument](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092727664)
      - 1.34.4.10.4.6  [Litigation Case Data Collection Instrument](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092718848)
      - 1.34.4.10.4.7  [Collection Summary Data Collection Instrument](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092712736)
      - 1.34.4.10.4.8  [Comment Section](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092702144)
  - Exhibit  1.34.4-1  [Book Value Adjustments](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092696080)
  - Exhibit  1.34.4-2  [Payment Application on Trust Fund Penalty](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092681840)
  - Exhibit  1.34.4-3  [Custodial Detail Data Base Valid Cross Reference Definitions](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092653584)
  - Exhibit  1.34.4-4  [Stand Alone Penalties](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092498912)
  - Exhibit  1.34.4-5  [IRS Unpaid Assessments Financial Statement Estimation Process Plan](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092477392)
  - Exhibit  1.34.4-6  [Recognition of an Economic Event](https://www.irs.gov/irm/part1/irm_01-034-004#idm139885092399072)

# Part 1. Organization, Finance, and Management

# Chapter 34. Revenue Accounting

# Section 4. Unpaid Assessments

* * *

## 1.34.4 Unpaid Assessments

#### Manual Transmittal

May 15, 2025

#### Purpose

(1) This transmits revised IRM 1.34.4, Organization, Finance, and Management, Revenue Financial Accounting, Unpaid Assessments.

#### Material Changes

(1) IRM 1.34.4.1.3.3, Associate CFO for Revenue Financial Accounting - Updated position responsibilities.

(2) IRM 1.34.4.1.3.4, Unpaid Assessments and Analysis Office - Updated to provide section processes and responsibilities.

(3) IRM 1.34.4.1.3.5(1), Chief and Analysts for Custodial Analysis and Reporting - Deleted Custodial Analysis and Reporting section overseeing sequestration.

(4) IRM 1.34.4.1.3.5(2)(e), Chief and Analysts for Custodial Analysis and Reporting - Revised section responsibility for data analytics.

(5) IRM 1.34.4.1.3.7, Chief and Analysts for Unpaid Assessments Account Resolution - Updated to provide section processes and responsibilities.

(6) IRM 1.34.4.1.4(1)(a), Program Management and Review - Revised process mitigating a weakness to limitations.

(7) IRM 1.34.4.1.4(1)(b), Program Management and Review - Deleted insurance provider fees as no longer applicable.

(8) IRM 1.34.4.1.4(1)(c), Program Management and Review - Deleted Custodial from Headquarters Accounting section.

(9) IRM 1.34.4.1.4(a-c), Program Management and Review - (a) Replaced Employer Deferral with Delinquent Deferral, (b) Replaced Employee Deferral with Errors related to filing, and deleted (c).

(10) IRM 1.34.4.1.6(1)(g) - Revised definition of fiscal year.

(11) IRM 1.34.4.2.4, Memo Classification - Added programming for expired debit balance modules.

(12) IRM 1.34.4.2.5(1), Criteria for Split Categorization - Revised split categorization definition.

(13) IRM 1.34.4.3(2), Categorization Criteria for Taxes Receivable - Revised pending assessments and adjustments.

(14) IRM 1.34.4.3.1, Tax Returns - Revised tax returns as evidence.

(15) IRM 1.34.4.3.3, Installment Agreements - Revised installment agreements as evidence.

(16) IRM 1.34.4.3.4, Offer in Compromise - Revised Offer in Compromise as evidence.

(17) IRM 1.34.4.3.5(1), Examination - Updated to provide current list of examination forms with taxpayer agreements.

(18) IRM 1.34.4.3.7, Tax Equity and Fiscal Responsibility Act of 1982 Examination - Revised TEFRA definition.

(19) IRM 1.34.4.3.9, Abusive Tax Avoidance Transactions S-Corporation Charitable Contribution Strategy 2 - Revised ATAT assessment for financial categorization.

(20) IRM 1.34.4.3.10(1), Appeals Cases - Revised appeals determination for financial categorization.

(21) IRM 1.34.4.3.11(1), Court Decision Cases - Revised court decisions for financial categorization.

(22) IRM 1.34.4.3.12(3), Restitution Based Assessments - Revised division name from Financial Litigation Unit (FLU) to Financial Litigation Program (FLP).

(23) IRM 1.34.4.3.15, Stand-Alone Penalties - Revised stand-alone penalties for financial categorization.

(24) IRM 1.34.4.3.16(1), Affordable Care Act - Added repealed date to Health Insurance Provider fees.

(25) IRM 1.34.4.3.19(1), Social Security Deferral - Revised deferral and repayment period.

(26) Prior IRM 1.34.4.3.19(2), Social Security Deferral - Deleted as no longer applicable.

(27) IRM 1.34.4.3.20(2), IRC U.S. Code Section 965 Transition Tax - Updated tax form numbers and names.

(28) IRM 1.34.4.3.21(1), Identity Theft - Revised definition of identity theft.

(29) IRM 1.34.4.3.25(3), Pattern of Payments - Revised voluntary payment documentation for financial categorization.

(30) IRM 1.34.4.3.27(1), Defunct or Bankrupt Entities - Revised analysis of balance due return filed after defunct or bankrupt account period.

(31) IRM 1.34.4.3.29(1), Comments Section - Revised comment section support for categorization decisions.

(32) IRM 1.34.4.4(2), Categorization Criteria for Compliance - Revised financial categorization for accounts without supporting documentation.

(33) IRM 1.34.4.4.1, Unagreed or Default Compliance Assessment - Revised compliance assessment documentation for financial categorization.

(34) IRM 1.34.4.4.2(2), Manual Refunds - Deleted taxpayer necessity to provide information to correct math errors.

(35) IRM 1.34.4.9(2), Categorization Data Collection Instrument for Trust Fund Modules - Replaced tapes with worksheets as tapes no longer used.

(36) IRM 1.34.4.9.3(1), Recalculating the Trust Fund Assessment Amount - Replaced calculator tapes with worksheets as tapes no longer used.

(37) This revision includes changes throughout the document for the following:

1. Updated position titles and office names to correspond with organization changes within CFO.

2. Updated IRM references.

3. Added minor editorial changes for clarity and precision.


#### Effect on Other Documents

IRM 1.34.4, dated March 17, 2023, is superseded.

#### Audience

Analysts in CFO, Financial Management, Revenue Financial Accounting, Unpaid Assessments and Analysis

#### Effective Date

(05-15-2025)

Michael V. Gomes

Associate CFO for Revenue Financial Accounting,

Financial Management

**1.34.4.1** **(09-07-2018)**

### Program Scope and Objectives

1. Purpose: This IRM provides guidance and responsibilities for the Unpaid Assessment (UA) portion of the IRS financial statement estimate of net tax receivables through the estimations process and guidance on categorization and collectibility to ensure the IRS Agency Financial Report, including all corresponding notes to the financials is correctly stated in all material respects.

2. Audience: CFO, Financial Management, Unpaid Assessments and Analysis, Unpaid Assessments Accounting Analysis, Unpaid Assessments Account Resolution, Custodial Analysis and Reporting.

3. Policy Owner: The Senior Associate CFO for Financial Management.

4. Program Owner: Financial Management, Unpaid Assessments and Analysis, Unpaid Assessments Accounting Analysis Section are responsible for the administration, procedures and updates related to this program, Unpaid Assessments Account Resolution Section are responsible for the administration, procedures and updates related to this program, and Custodial Analysis and Reporting are responsible for reporting UA financial information and delivering statistical information to report net taxes receivable as an asset.

5. Primary Stakeholders: Unpaid Assessments Accounting Analysis Section.

6. Program Goals: Obtain an unmodified financial statement estimation process opinion and make progress towards eliminating the unpaid assessments significant deficiency.


**1.34.4.1.1** **(08-25-2015)**

#### Background

1. The Chief Financial Officers Act of 1990 provides for improvement, in each agency of the federal government, of systems of accounting, financial management and internal controls to assure the issuance of reliable financial information and to deter fraud, waste and abuse of government resources. The IRS produces accurate financial statements which are auditable. While other samples are mentioned, this IRM pertains exclusively to the UA portion of the financial statement estimation process. Specific details about categorization, collectibility, sampling and the Custodial Audit Support and Tracking System (CASTS) database are contained in CASTS system documentation.

2. The IRS has divided its inventory of UA into four financial categorizations based on generally accepted accounting standards. The categorizations include Taxes Receivable (TR), Compliance Assessments (CA), Write-Off (WO) and Memo. Some modules may contain two of the four categorizations which would be considered a Split Categorization.

3. The largest portion of the custodial assets reported on the financial statement are in the TR categorization. The value of the TR is reported in the IRS financial statement. Write-off and Compliance financial categorizations are included in the supplemental information while MEMO is excluded from financial reporting.

4. It is crucial that the IRS has documentation that supports the proper categorization of each sampled module and documentation to support the amount estimated as collectible for each receivable module. Otherwise, the module will be considered mis-categorized and its error value projected to the appropriate population of UA.


**1.34.4.1.2** **(08-25-2015)**

#### Authorities

1. The authorities for this IRM include:



1. [Chief Financial Officers Act of 1990](http://govinfo.library.unt.edu/npr/library/misc/cfo.html), Pub. L. No. 101–576.

2. Government Accountability Office Policy and Procedures Manual for Guidance of Federal Agencies.

3. [Federal Accounting Standard Advisory Board (FASAB).](https://fasab.gov/accounting-standards/document-by-chapter/)

4. 31 USC 3512, [Executive Agency Accounting and other Financial Reports and Plans.](https://www.govinfo.gov/content/pkg/USCODE-2013-title31/pdf/USCODE-2013-title31-subtitleIII-chap35-subchapII-sec3512.pdf)


**1.34.4.1.3** **(10-03-2019)**

#### Responsibilities

1. This section provides responsibilities for:



1. CFO and Deputy CFO.

2. Senior Associate CFO for Financial Management.

3. Associate CFO for Revenue Financial Accounting.

4. Unpaid Assessments Accounting Analysis office.

5. Chief and analysts for Custodial Analysis and Reporting.

6. Chief and analysts for Unpaid Assessments Accounting Analysis.

7. Chief and analysts for Unpaid Assessments Account Resolution.


**1.34.4.1.3.1** **(09-07-2018)**

##### CFO and Deputy CFO

1. The CFO and Deputy CFO are responsible for developing the organization and managing the portfolio of corporate-wide activities, including budget formulation, budget execution, accounting, financial management and internal control. The CFO manages IRS financial activities in compliance with the CFO Act and the authorities implementing that act.


**1.34.4.1.3.2** **(09-07-2018)**

##### Senior Associate CFO for Financial Management

1. The Senior Associate CFO for Financial Management is responsible for the oversight of the Custodial and Administrative Financial Management functions.


**1.34.4.1.3.3** **(05-15-2025)**

##### Associate CFO for Revenue Financial Accounting

1. The Revenue Financial Accounting organization ensures proper accounting and timely reporting of IRS tax-related activities and operational control for all CFO financial management systems.

2. The Revenue Financial Accounting Organization is responsible for:



1. Overseeing Federal Information Security Management Act (FISMA) process compliance for CFO financial management systems.

2. Accounting and reporting for all tax assessments, tax revenue receipts, refund activities and unpaid assessments to comply with CFO Act, FASAB and Treasury and OMB guidance.

3. Establishing and maintaining revenue accounting policies and procedures.

4. Serving as the owner of the IRS’s financial management systems and ensuring compliance with accounting standards and internal controls per the CFO Act; FASAB; Treasury; OMB; federal financial system requirements; and other financial requirements.

5. Ensuring that business units inform or share any changes in operational or system processes that may affect revenue financial systems or reporting.

6. Providing financial system modernization development support and ensuring financial system requirements and other financial requirements are addressed.


3. The Associate CFO for Revenue Financial Accounting leads the organization, including its three subordinate offices:



1. Unpaid Assessments and Analysis Office.

2. Revenue Accounting Operations Office.

3. Financial Management Systems Office.


**1.34.4.1.3.4** **(05-15-2025)**

##### Unpaid Assessments and Analysis office

1. The Unpaid Assessments and Analysis office maintains the integrity and accuracy of the data and business rules to segment the inventory of unpaid assessments for operational and financial reporting purposes and is responsible for analyzing custodial data to accurately present data to the Department of the Treasury, Congress and GAO.

2. The Unpaid Assessments and Analysis office is responsible for:



1. Unpaid assessments-for both financial reporting and data systems, analytics, and financial data oversight.

2. Collaborating with Servicewide stakeholders to improve unpaid assessments data and address data issues.

3. Addressing financial reporting system noncompliance issues.


3. The Unpaid Assessments and Analysis Office has three subordinate sections. Custodial Analysis and Reporting, Unpaid Assessments and Accounting Analysis and Unpaid Assessments Account Resolution.


**1.34.4.1.3.5** **(05-15-2025)**

##### Chief and Analysts for Custodial Analysis and Reporting

1. The Custodial Analysis and Reporting section analyzes custodial data including unpaid assessments.

2. The Custodial Analysis and Reporting section is responsible for:



1. Reporting UA financial information in the financial statements in accordance with the Federal Accounting Standards Advisory Board (FASAB).

2. Delivering statistical information to report net taxes receivable as an asset.

3. Evaluation of the Social Security Deferral (SSD) testing and unpaid assessments auditor review while providing technical guidance and assistance to the business units.

4. Statistical sampling and data querying for data review case selection.

5. Data analytics and querying unpaid assessments for external requests.

6. Reconciling and ensuring accuracy of reported components of unpaid assessments.


**1.34.4.1.3.6** **(10-03-2019)**

##### Chief and Analysts for Unpaid Assessments Accounting Analysis

1. The Unpaid Assessments Accounting Analysis section, ensures that unpaid assessments are accurately recorded in accordance with federal accounting standard categorization requirements for financial reporting purposes.

2. The Unpaid Assessments Accounting Analysis Section is responsible for:



1. Performing technical evaluations of unpaid assessment data, including the evaluation of IRS compliance with laws related to tax accounts reviewed during the GAO custodial financial statement audit.

2. Communicating audit findings and providing technical guidance and assistance to the business units.


**1.34.4.1.3.7** **(05-15-2025)**

##### Chief and Analysts for Unpaid Assessments Account Resolution

1. The Unpaid Assessments and Account Resolution section has a UA data review process to enhance data integrity. The UA data review process is used for:



1. Diagnosing cause(s) of an issue and recommending solutions.

2. Ensuring unpaid assessments are accurately recorded in accordance with the Federal Accounting Standards Advisory Board (FASAB) categorization requirements to support financial reporting.

3. Performing technical evaluations of UA data and ensuring that the transactions are properly recorded, processed, and summarized in accordance with the UA Methodology.

4. Leading the Data Quality Improvement Team to discuss findings and issues which impact data integrity.


The Unpaid Assessments and Account Resolution section’s 965 team that is responsible for:



1. Evaluating IRS compliance with the laws related to accounts reviewed during the IRC U.S. Code Section 965(h) testing and unpaid assessments quality reviews.

2. Communicating IRC U.S. Code Section 965(h) testing and quality review findings and providing technical guidance and assistance to the business units.


**1.34.4.1.4** **(05-15-2025)**

#### Program Management and Review

1. **UA Financial Reporting:**



1. **Statistical Estimation Process** \- The Unpaid Assessments statistical financial statement estimation process mitigates limitations in the design of the IRS master file system. The IRS master file system, designed in the early 1960s, does not record the level of detail required to consistently report year-end balances in accordance with federal accounting standards. IRS uses the UA statistical sampling and estimation process that materially estimates the reported balance for federal taxes receivable, although the resulting estimated balance cannot trace back to detailed taxpayer accounts. IRS conducts a financial statement estimation process using approximately 600 UA modules.


       The CFO works with the business units to obtain supporting documentation maintained in campuses, field offices or federal records centers to determine if recorded balances are accurate. CFO performs book value adjustments to the reported numbers when necessary. Interim cutoff results are projected to the population to determine the amount to report in the financial statements.

2. **Taxes Receivable Not Subject to Statistical Estimation** \- Some taxes receivable programs not used in the statistical estimation for various reasons. IRC U.S. Code Section 965 and social security deferral (SSD) taxes receivable is established by the actual amount deferred. The original source of the IRS U.S. Code Section 965 and SSD taxes receivable is obtained through master file extracts and identified by specific transaction codes and related action codes and collectability determined each year according to analyses described in white papers. Unbooked branded prescription drug fees are established and added to taxes receivable. The assessed tax amount of Restitution Based Assessments (RBA) is added to TR, with collectibility determined each year according to analysis described in the RBA white paper.

3. **Reconciliation**

      **Three Day Close** \- The monthly three-day close provides the reportable amounts for estimated taxes receivable (TR), allowance for doubtful accounts (ADA) and restitution-based assessments based on the current month’s taxpayer posting from master file. RBA’s are calculated separately since they have lower collection rates than the rest of the unpaid assessment population. IRC U.S. Code Section 965 and social security deferred taxes are also calculated separately for the 3-day close, as both have a separate collectibility rate. Beginning in fiscal year 2022, certain RRACS erroneous refund and payment over cancellations accounts were also added as new line items on the three-day close to be included as taxes receivable. The three-day close totals are created when the flat files become available from IT for month end cycle. The Headquarters Accounting section requires the ADA to be calculated to complete month-end journal entries. Embedded formulas within the three-day close spreadsheet calculate the monthly ADA using collection and adjustment percentage rates developed from the prior fiscal year's statistical estimation process.

      **Three Way Match Monthly Reconciliation** \- This reconciliation is produced monthly and is used to validate that different sources of unpaid assessment data match. This reconciliation confirms a three-way match using service center recap reports, RRACS reports and CDDB files for IMF and BMF; and a two-way comparison using RRACS reports and CDDB files of NMF data. There are no service center recap reports for NMF. This reconciliation includes taxes receivable, compliance, write-off and memo amounts.


2. **Program Reports Statistical Sample:**The following program reports are used by Unpaid Assessments Accounting Analysis analysts based on dollar thresholds to ensure the statistically selected samples along with the certainty strata cases that the Unpaid Assessments Accounting Analyst section works are correct. The Unpaid Assessments Accounting Analyst section analyzes the reports to determine if the modules are correctly categorized and recorded at the correct amount. In the reports listed below the TR cases are $25 million or greater, CA and WO cases are $10 million or greater.



01. BMF New $10 Million Cycle Reports.

02. BMF Changed $10 Million Cycle Reports.

03. BMF Dropped $10 Million Cycle Reports.

04. BMF Manual Move Report.

05. BMF Special Reports.

06. IMF New $10 Million Cycle Reports.

07. IMF Changed $10 Million Cycle Reports.

08. IMF Dropped $10 Million Cycle Reports.

09. IMF Manual Move Report.

10. IMF Special Reports.

11. IMF and BMF NMF Cycle Reports.


3. **Program Reports Tax Reform IRC U.S. Code Section 965:**



1. Payments.

2. Eight Year Election.

3. Transferee/Transferor.

4. Acceleration.


4. **Program Reports Social Security Deferral**



1. Delinquent Deferral.

2. Errors related to filing.


5. **Program Effectiveness:** The results are reviewed by a senior analyst. The section chief performs a second review on a selection of cases that are more complex. When the section chief cannot resolve the case or determines that additional review is needed, the case is elevated to higher levels of management. Depending on the complexity of the cases, the additional levels of review include: a third level of review by the Unpaid Assessments and Analysis director, a fourth level of review by the Associate CFO for Revenue Financial Accounting, a fifth level of review by the Senior Associate CFO for Financial Management and a final review by the deputy CFO. Unpaid Assessments Accounting Analyst personnel document their reviews by initialing the control sheet. See _Exhibit 1.34.4-5_, Pre-Financial Statement Estimation Process, and During Financial Statement Estimation Process Review Elevation Process.

6. **Data Review:** The Unpaid Assessments Account Resolution Office has implemented a new UA data review process within Unpaid Assessment (UA) accounts to enhance data integrity. The data review process will focus on the analysis of cases that fall below the large dollar (Big Blue) scope of Unpaid Assessments Accounting Analysis Section. If issues are identified, the Unpaid Assessments Account Resolution team will utilize all available resources and technology at its disposal to diagnose the cause of the issue and recommend solutions. The Unpaid Assessments Account Resolution section also ensures that unpaid assessments are accurately recorded in accordance with the Federal Accounting Standards Advisory Board guidance. The Unpaid Assessments Account Resolution Section is responsible for performing technical evaluations of UA data and ensuring that the transactions are properly recorded, processed, and summarized in accordance with the UA Methodology.


**1.34.4.1.5** **(09-07-2018)**

#### Program Controls

1. The Custodial Audit Support and Tracking System (CASTS) is used to oversee the Unpaid Assessments financial statement estimation process as follows:



1. Access is limited to the manager, reviewers and analysts working the Unpaid Assessments financial statement estimation process.

2. Tracks documentation for the IRS financial statement estimation process of Unpaid Assessments.

3. Generates data collection instruments for the field and campus personnel.

4. Produces weekly reports for national coordinators.

5. Records analysis of various financial statement estimation process samples, including categorization and collectibility of interim cutoff Unpaid Assessments modules.

6. Performs the final reconciliation of financial statement estimation process results and generates reports.

7. Monitors large dollar unpaid assessments.


**1.34.4.1.6** **(05-15-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program.



01. **Abatements** \- Reductions in tax assessments, penalty, and interest that are a normal part of the IRS tax administration process. Abatements may occur for a number of reasons. For example, a taxpayer may file an amended return claiming a lower tax liability than previously reported or a qualifying corporation may claim a net operating loss which created a credit that can be carried back to reduce a prior year’s tax liability.

02. **Assessment** \- An increase to the amount of tax, penalty and interest to the taxpayer’s account.

03. **Book value** \- The net amount at which an asset or liability is carried on the books of account. It equals the gross or nominal amount of an asset or liability minus an allowance or valuation amount.

04. **Book value adjustment (BVA)** \- An adjustment to a tax module balance to reflect the correct unpaid assessment categorization. Some unpaid assessment cases upon review of the supporting documentation, turn out not be unpaid assessment. In other instances, only a portion of the book value balance (total module balance) will turn out to be a true unpaid assessment. In order to reduce or increase the book value to the correct financial statement estimation process value, the Unpaid Assessments Accounting Analysis analyst will make an adjustment to the book value.

05. **Compliance assessments (CA)** \- Unpaid assessments for which there is neither taxpayer agreement nor a court has affirmed that the taxpayer owes amounts to the federal government. Examples include assessments resulting from the IRS examinations or non-filer enforcement programs in which the taxpayer does not agree with the recorded tax assessment. The IRS reports the balance of compliance assessments in its Required Supplementary Information. Statutory provisions require that the IRS maintain these accounts until the statute for the collection expires. The statutory period for collection is generally 10 years from the date the IRS records the tax assessment.

06. **Financial Statements** \- An entity’s financial activity and status for a specified period. Under federal law and applicable accounting standards, the financial statements for a federal agency usually include a balance sheet, statement of net cost, statement of changes in net position, statement of budgetary resources and statement of custodial activity.

07. **Fiscal year** \- A twelve-month accounting period, that for the U.S. Federal government is from October 1 through September 30, of each year.

08. **Government Accountability Office** \- An independent, nonpartisan agency that works for Congress. The GAO investigates how the federal government spends taxpayer dollars. The GAO performs the annual financial statement audit of the IRS financial statements since the IRS collections are significant to overall federal receipts and to the consolidated financial statements of the U.S. Government. Annually, the GAO determines whether the IRS financial statements are fairly stated in all material respects, and that the IRS management maintains effective internal controls. The GAO also tests the IRS compliance with selected provisions of significant laws and regulations and its financial systems’ compliance.

09. **Integrated Data Retrieval System (IDRS)** \- A system used to perform research on taxpayer accounts which interfaces with master file. It is used to perform additional research on all imperfect and multiple–split receipts. It is also used to process larger volumes of multiple–split receipts. IDRS is different from the Integrated Submission and Remittance Processing (ISRP) System because it is downloaded from the master files. Thus, it is used not only for payment processing, but also for research purposes and for processing assessments and abatements.

10. **Master file** \- The master file records tax information related to individual and business taxpayers by tax year or tax period. This includes such data as the assessed tax, interest and penalties, receipt of payments and other adjustments to the assessments. The master file records the type of return filed, date the return was received and processed, expiration dates for assessment of additional taxes against taxpayers, collection activity (for example, unpaid assessment account sent to revenue officer for collections) and status of the taxpayer’s account (for example, account paid in full, taxpayer filed bankruptcy, taxpayer is deceased). A detailed database system of taxpayer information and tax processing activity. The master file system consists of two major files: Individual Master File (IMF) and Business Master File (BMF).

11. **Memo accounts** \- Balance due accounts in the IRS records that are excluded from valid tax receivables according to federal financial standards. The IRS excludes the balance of Memo accounts from its gross unpaid assessment balance. Examples of assessments meeting the Memo criteria include: Federal Filers, fraudulent/frivolous assessments, assessments made clearly in error, complex global netting issues on multi-year examination cases, non-master file duplicate assessments and credits that are posted to one module with the assessment on another module not yet merged.

12. **Non master file (NMF)** \- A database which enables the IRS to process taxpayer accounts that cannot be processed on the master file.

13. **Split categorization** \- Unpaid assessment that falls into two categorizations at the same time. For example, a percentage of the assessment is TR due to the taxpayer agreement or court ruling and the remaining percentage is followed by an unagreed subsequent assessment that is categorized as CA. Other Split Categorizations would be TR and WO, TR and Memo, CA and WO, and CA and Memo.

14. **Taxes receivable** \- TR are assets that arise from specifically identifiable, legally enforceable claims to cash or other assets through an entity’s established assessment processes. A custodial line item reported on the balance sheet comprised of unpaid assessments (taxes and associated penalties and interest) due from taxpayers for which the IRS can support the existence of a receivable through a taxpayer agreement, such as filing of a tax return without sufficient payment, or a court ruling in favor of the IRS. The IRS reports TR on its balance sheet net of an allowance for doubtful accounts. TR is a proprietary (or financial) accounting term and not a budget term. TR does not constitute budget authority against which an agency may incur an obligation. For federal proprietary accounting, TR includes only unpaid assessments made through the end of the period plus related fines, penalties and interest. TR does not include amounts received or due with tax returns received after the close of the reporting period or amounts that are compliance assessments or pre-assessment work in process.

15. **Unpaid assessment financial statement estimation process** \- An analysis to determine whether the statistically selected modules of unpaid assessments are (1) categorized correctly, (2) recorded at the correct amount, and, for those items correctly categorized as TR, (3) whether they are fully or partially collectible. The results of this analysis will be used to project amounts to be reflected as gross and net TR and the corresponding allowance for doubtful accounts, CA, and WO on the IRS financial statements and/or accompanying information. The financial statement estimation process is selected from tax modules as they were posted to IMF and Business Master File (BMF). The master file records tax information related to individual and business taxpayers by tax year or tax period. This includes such data as the assessed tax, interest and penalties, receipt of payments and other adjustments to the assessments. The master file records the type of return filed, date the return was received and processed, expiration dates for assessment of additional taxes against taxpayers, collection activity (for example, unpaid assessment account sent to revenue officer for collections) and status of the taxpayer’s account (for example, account paid in full, taxpayer filed bankruptcy, taxpayer is deceased).

16. **Unpaid assessment** \- Enforceable claim for which specific amounts are due, have been determined and the person(s) or entities from which a tax is due have been identified. Unpaid assessments include both self-assessments made by a person filing tax returns and assessments made by the IRS.

17. **Write-off (WO)** \- Unpaid assessments for which the IRS does not expect further collections due to factors such as taxpayer's death, completed bankruptcy, or insolvency. A WO may at one time have been a TR or a CA, but the absence of any future collection potential prevents them from being considered as receivables under federal accounting standards.


**1.34.4.1.7** **(03-17-2023)**

#### Acronyms

1. The following acronyms apply to this program.




| **Acronyms** | **Description** |
| --- | --- |
| AC | Action Code |
| ACS | Automated Collection System |
| AIS | Automated Insolvency System |
| ARDI | Accounts Receivable Dollar Inventory |
| ASED | Assessment Statute Expiration Date |
| BMF | Business Master File |
| BVA | Book Value Adjustment |
| CA | Compliance Assessment |
| CASTS | Custodial Audit Support and Tracking System |
| CC | Closing Code |
| CDDB | Custodial Detail Data Base |
| CFf | Collection Field Function |
| CNC | Currently Not Collectible |
| CSED | Collection Status Expiration Date |
| DCI | Data Collection Instrument |
| DPC | Designated Payment Code |
| FICA | Federal Insurance Contribution Act |
| FPLP | Federal Payment Levy Program |
| IA | Installment Agreement |
| IDRS | Integrated Data Retrieval System |
| IRC | Internal Revenue Code |
| IMF | Individual Master File |
| MFT | Master File Tax |
| MFTRA | Master File Transcript |
| NMF | Non-Master File |
| OIC | Offer in Compromise |
| RBA | Restitution Based Assessment |
| RTR | Remittance Transaction Research |
| SME | Subject Matter Expert |
| SSN | Social Security Number |
| TC | Transaction Code |
| TFRP | Trust Fund Recovery Penalty |
| TIN | Taxpayer Identification Number |
| TMB | Total Module Balance |
| TR | Taxes Receivable |
| UA | Unpaid Assessments |
| WO | Write-Off |


**1.34.4.1.8** **(09-07-2018)**

#### Related Resources

1. Related Resources for this IRM include:



1. Custodial Audit Support and Tracking Systems (CASTS) Tutorial.

2. Methodology for Review of Unpaid Assessments Cases.

3. Servicewide Electronic Research Program (SERP).

4. Document 6209, IRS Processing Codes and Information.

5. [Public Access to Court Electronic Research,](https://www.pacer.gov/)(PACER).

6. [Lexis Nexis.](https://www.lexisnexis.com/en-us/gateway.page)

7. Document 12990, Records Control Schedules.


**1.34.4.2** **(08-25-2015)**

### Categorizations

1. The IRS has divided its inventory of Unpaid Assessments (UA) into four financial categorizations based on generally accepted accounting standards. The largest portion of the custodial assets reported on the financial statement are in the TR categorization. This section describes the categorizations.



1. Taxes Receivable (TR).

2. Compliance Assessment (CA).

3. Write-Off (WO).

4. Memo.


2. Some modules will need to be split between more than one categorization.

3. The IRS needs documentation that supports the categorization of each module and documentation to support the amount estimated as collectible for each TR module. Otherwise, the module will be considered mis-categorized, and its value projected to the appropriate population of unpaid assessments.

4. Once a categorization has been determined with supporting documentation a Categorization Data Collection Instrument (DCI) is prepared in CASTS and placed in the file.


**1.34.4.2.1** **(08-25-2015)**

#### Taxes Receivable

1. Taxes Receivable are taxes and associated penalties and interest due from taxpayers for which the IRS can support the existence of a receivable through taxpayer agreement (such as filing of a tax return without sufficient payment, Installment Agreement, Offer In Compromise, agreed examination), or a court ruling favorable to IRS. In addition, an unpaid assessment will be considered a TR when the IRS:



1. Disallows an unsubstantiated credit because of a missing or incorrect Taxpayer Identification Number (TIN) or increases the tax due to an unsubstantiated deduction (i.e., missing schedules), or corrects a mathematical error on the taxpayer's return.

2. Notifies the taxpayer and at least sixty (60) days have elapsed from the time the taxpayer is notified of the change.


**1.34.4.2.2** **(08-25-2015)**

#### Compliance Assessment

1. Assessments made resulting from one of the IRS's compliance programs when categorized as a Compliance Assessment are not proposed assessments, have completed the assessment process, specific amounts due have been determined, and the person(s) or entities from whom the tax or duty is due have been identified. In these cases, the taxpayer may still have some right to disagree, when assessments made at the conclusion of a financial statement estimation process that may still be in appeals or tax court waiting final decision.

2. An assessment resulting from an IRS financial statement estimation process or examination in which the taxpayer does not agree with the results is a CA and is not considered a receivable under federal accounting standards. Cases where the IRS cannot obtain sufficient documentation to support taxpayer agreement may also result in assessments categorized as a CA.


**1.34.4.2.3** **(08-25-2015)**

#### Write-Off

1. Write-Offs are unpaid assessments for which the IRS does not expect further collections due to factors such as taxpayer's death, completed bankruptcy, or insolvency. Write-Offs may at one time have been TR or a CA, but the absence of any future collection potential prevents them from being considered as receivables under federal accounting standards.


**1.34.4.2.4** **(05-15-2025)**

#### Memo

1. The IRS created an additional financial category Memo to report on unpaid tax assessments that are unique to the IRS and do not meet any of the other financial categorizations. The IRS must record assessments that are later found to be “frivolous” returns (e.g., tax protestors, fraudulent returns, etc.) and the IRS has other special processes where tax assessments are made but will not be collected pending additional actions that will resolve the receivable balance including multi-year audits on large corporations or global netting. Federal agencies with a balance due are programmed as Memo as the Federal government cannot have a debt obligation to itself. Modules with transaction codes posted that prevent a debit balance from clearing upon expiration of the CSED (i.e. criminal investigation freeze) or transaction posting are programmed as Memo and not be recorded in the financial statements.


**1.34.4.2.5** **(05-15-2025)**

#### Criteria for Split Categorization

1. A Split Categorization occurs when an unpaid assessment is defined as TR due to the taxpayer agreement or court ruling and is followed by an unagreed subsequent assessment that is categorized as CA. Other Split Categorizations include: TR and WO, TR and Memo, CA and WO, and CA and Memo.

2. A Split Categorization is not systemically defined in all cases. A manual input of an action code and percentage is required to define each categorization. The percentage will provide how much of the Total Module Balance (TMB) belongs to each categorization and may result in a variance.

3. To calculate the split categorization percentage between TR and CA assessments, the Unpaid Assessments Accounting Analysis analyst inputs a Transaction Code (TC) 971 Action Code (AC) 209. For a TR and WO split, a TC 971 AC 211, TR and Memo split, a TC 971 AC 210, CA and WO split, a TC 971 AC 212, and CA and Memo split, a TC 971 AC 213, will be input. Prior to manually transmitting an action code, the analyst will complete a split Allocation Worksheet found on the CASTS home page, to calculate the categorization split.


**1.34.4.3** **(05-15-2025)**

### Categorization Criteria for Taxes Receivable

1. The IRS refers to reportable assets as TR instead of accounts receivable. The primary determination for when an unpaid assessment becomes reportable as an asset (TR) is when there is a two-party agreement between the IRS and the taxpayer including through voluntary actions taken by the taxpayer and/or court rulings. To assist in determining whether an unpaid assessment is a TR, the following subsections are unpaid assessment cases that are generally TR, and the types of evidence that support the receivable.

2. Pending assessments and adjustments to existing assessments that have not posted and have not completed the assessment process are defined as pre-assessment work in process. Whether the amounts will be assessed or the duration of the notice period is reasonably estimable, no amounts are included in the tax or accounting systems. Estimates of the amounts of pre-assessment work in process that may ultimately be collected are not sufficiently reliable to be recognized until after posting.


**1.34.4.3.1** **(05-15-2025)**

#### Tax Returns

1. The IRS relies on the original filed tax return including increasingly prevalent electronic filed returns by the taxpayer or a copy of the return to support taxpayer agreement through a self-assessment process. Amended tax returns including copies filed by the taxpayer to increase or decrease their original amount, support self-assessments. These are sufficient evidence of a TR and do not require proof of signature.



1. An accepted original tax return or a copy of an original tax return

2. An original tax return or a copy of an original tax return with a math error. Internal Revenue Code Section 6213(b)(1) gives the IRS the authority to adjust tax returns to correct math errors without performing a financial statement estimation process. As such, this constitutes implied agreement because the assessment is based on information provided on the return filed by the taxpayer. A taxpayer may file with the Secretary within 60 days after a notice is sent under paragraph (1) a request for an abatement, with or without substantiation, of any assessment specified in such notice, and upon receipt of such request, the IRS shall abate the assessment. For abatement requests without substantiation, the case is referred to examination for a determination. If the taxpayer disagrees with the determination, the taxpayer has the opportunity to appeal the determination prior to the issuance of a notice of deficiency. If a notice of deficiency is issued, the taxpayer has the opportunity to file a petition with the United States Tax Court. If 60 days has not passed as of the sample date and the taxpayer would not have owed any tax due to a refund or full paid return the assessment will be considered Compliance. If there is a balance due the module would be split between TR and CA with only the math error portion of the assessment, plus applicable penalty and interest categorized as Compliance. If the taxpayer submits information after 60 days, the assessment remains until all administrative actions are complete.

3. An accepted electronically filed tax return. An electronically filed return will be supported by an electronic gel print which closely resembles an original paper return. An Integrated Data Retrieval System (IDRS) TRDPG screen print is an acceptable alternative, but only if time constraints prevent an Unpaid Assessments Accounting Analysis analyst from obtaining the GEL print. The TRDPG is a screen print from the same database that is the source for the GEL print. The GEL print takes three days to receive but is very user-friendly, where a TRDPG can be printed immediately but is not as user-friendly.

4. An amended or superseded return or copy of an amended/superseded tax return filed by the taxpayer. A superseded return is a return or correspondence filed after the originally filed return and filed within the filing period (including extensions). An amended return is a return filed after the originally filed return and filed after the expiration of the filing period (including extensions). For purposes of this IRM, an amended and superseded return will be treated the same and referenced as an amended return.

5. When a return in CI possession cannot be released due to Grand Jury restrictions etc., a signed statement/certificate or telephonic confirmation from CI verifying that the tax on the return matches the TC 150 will substitute for a copy of the return. If a signed statement/certificate is used, it will further state that the taxpayer filed the return and will also have a provision to encompass verification of the existence of other forms such as a Form 870, Waiver of Restriction on Assessment and Collection of Deficiency in Tax and Acceptance of Overassessment, executed by the taxpayer.


**1.34.4.3.2** **(03-03-2021)**

#### Manual Refunds

1. Unpaid assessments created by TC 840 Manual Refund, with no TC 150 posted and an unreversed TC 973 (Form 1139, Application for Tentative Refund) will be categorized as Taxes Receivable. A taxpayer filing Form 1139, agrees to any balance due until the return has been processed.


**1.34.4.3.3** **(05-15-2025)**

#### Installment Agreements

1. Installment Agreements (IA) indicate agreement because the taxpayer is voluntarily making payments on the assessed balance and can set the amounts of the payments and agrees to the terms of the agreement when it meets the criteria for their balance due for installment agreement. If there was a disagreement with the balance due, a taxpayer may file amended returns, send correspondence, or provide additional information to have the assessment eliminated or reduced. Instead, when they initiate a plan to pay the existing balance due, this constitutes implied agreement. Many IAs are initiated by phone and no signed paper agreement exists.

2. There must be systemic history in the form of a master file status code 60 (IA) or Manually Monitored Installment Agreement (MMIA) on the tax module to categorize it as TR. Also, the IRS must provide a copy of Form 433-D, Collection Information Statement, an IADIS print from IDRS, an Accounts Management System (AMS) print, Automated Collection System (ACS) Comments, documentation from Private Debt Collection, or show that the taxpayer has made at least one voluntary payment on any balance due module included in the IA.

3. If the IADIS screen is not available on MMIAs, case history or other documents of the MMIA will be provided. The IADIS print screen shows terms of the IA posted to the IDRS system. The presence of (a) Status 60 or (TC 971/AC 063 for a MMIA) along with (b) or (c) below are required before the case can be categorized as TR:



1. The presence of a status code 60 (IA) or the presence of a TC 971/AC 063 only (MMIA), posted with or after the assessment, in the taxpayer’s master file transcript.

2. The IADIS print screen or other documentation of the IA.

3. Receipt of at least one payment (TC 538, 610, 640, 650, 660, 670, 678, 680, 690, or 760) on any module included in the IA, or the user fee (TC 694 with Designated Payment Code (DPC) 44, 45, 46, 47, 48, 49, 50, or 51) is posted to the taxpayer’s Master File Tax (MFT) 55 module, after the posting date of the status code 60 or TC 971/AC 063, in the case of a MMIA.

4. IRS programming currently classifies a module as TR based on financial status code 07 to exclude modules without the TC971 AC063. If Unpaid Assessments Accounting Analysis analyst is unable to provide documentation of the IA (IADIS screen print, history print, etc.) or there is not at least one voluntary payment related to the Status code 60, then this criteria is not valid. This will be determined by the analyst at the time of the review, and if needed, the module will be recategorized.


4. If the module is in TR status because it was once an IA but has now defaulted, an IADIS screen of other case history may no longer be available, Unpaid Assessments Accounting Analysis analyst will document the presence of an IA by showing that a prior status code 60 (active IA) or TC 971/AC 063 (only for a MMIA) was posted to the taxpayer’s master file transcript at one time and there is:



1. A pattern of three or more payments (TC 670) after the posting date of the status code 60 or TC 971/AC 063 (MMIA) or,

2. One voluntary payment after the posting date of the status code 60 or TC 971/AC 063 (MMIA).


5. For continuous wage levy (CWL) cases, the pattern of three or more payments must be on the module. Otherwise, the module must be recategorized as CA. However, if the payments were involuntary, there must be additional evidence. If the taxpayer allowed involuntary payments, three or more times, and did not stop the payments or to change the assessment, the agreement is implied and will be considered sufficient evidence of the TR.

6. In the absence of the IADIS or other case history, the module must be subject to a stricter definition of implied agreement. One voluntary payment after the status code 60 or TC 971/AC 063 (MMIA) is sufficient evidence of agreement. However, if the payments were involuntary, there must be additional evidence. If the taxpayer allowed involuntary payments 3 or more times, and did not stop the payments or to change the assessment, the agreement is implied and will be considered sufficient evidence of the TR.

7. To categorize as TR, review the master file transcript to identify all the delinquent modules based on the Collection Statute Expiration Date (CSED) for each module. If the taxpayer has more than one delinquent module, payments should post first to the module with the oldest (earliest) CSED date. If no payments are posted to the module, review the unpaid modules with older CSEDs for evidence of payments or review the MFT 55 Individual Master File (IMF) or MFT 13 Business Master File (BMF) user fee module for posting of a paid user fee (TC 694 DPC 44, 45, 46, 47,48, 49, 50 or 51).

8. At times, the taxpayer sends installment payments without the installment coupon, and the IRS may inadvertently apply installment payments to the earliest tax period, instead of the period with the earliest CSED. While that should not happen, it is highly unlikely the IRS business unit will change the application of the payment. Since this condition does not adversely affect the taxpayer, and does not affect the total inventory balance of the TR, no action will be taken by the Unpaid Assessments Accounting Analysis analyst to prompt the business units to move the payments.

9. Federal Payment Levy Program (FPLP) and other involuntary payments are only considered for categorization purposes if they meet the pattern of payments on the module as explained in a later section. However, if the payment stream can reasonably be expected to reach the module, they should be used for collectibility. For example, a CA case has FPLP payments on an earlier module but payments will reach the sample module eventually. The IRS won’t recategorize the CA case on that basis; it will become TR if/when the payments begin posting to the module.


**1.34.4.3.4** **(05-15-2025)**

#### Offer in Compromise

01. Form [656,](https://www.irs.gov/pub/irs-pdf/f656.pdf) Offer in Compromise (OIC), signed by the taxpayer, lists two boxes to choose from for each of the reasons for filing the offer.



    - Doubt as to Collectibility.

    - Exceptional Circumstance (Effective Tax Administration).


One or both of these boxes must be checked/marked.



02. An OIC case may involve various types of situations as described below.



    1. A taxpayer acknowledges the liability, but is unable to pay the total assessment amount are considered Doubt as to Collectibility.

    2. A taxpayer states they owe the amount and have sufficient assets to pay the full amount, but due to exceptional circumstances, requiring full payment would cause economic hardship or would be unfair and inequitable are considered (Effective Tax Administration).


Offer cases claiming “Doubt as to Collectibility” and/or “Effective Tax Administration” should be categorized as TR. Acceptance of the offer is not required in order to be categorized as a tax receivable. The key is that the taxpayer acknowledges that they owe the assessment, but is unable to pay the assessment in full. Normal documentation will be the offer Form [656,](https://www.irs.gov/pub/irs-pdf/f656.pdf) Offer in Compromise, which is signed by the taxpayer.



03. Offer cases claiming “Doubt as to Liability” are usually categorized as CA. However, they are considered for possible Split categorization if additional collections of amounts the IRS would not otherwise have been able to collect. If this type of offer has been accepted, and the offer agreement provides for collections on the module, or an offer payment was received before the financial statement estimations pull date and posted afterwards, the payment amount applied to the module should be categorized as TR. The remainder should be categorized as CA. If the offer has not been accepted, the entire module balance is categorized as CA.

04. In the 02/2007 revision of the Form [656,](https://www.irs.gov/pub/irs-pdf/f656.pdf) Offer in Compromise, the “Doubt as to Liability” box is no longer available. The taxpayer is required to file a Form [656-L](https://www.irs.gov/pub/irs-pdf/f656l.pdf) when they believe the tax liability is incorrect. This type of offer will be posted with a TC 480 Jurisdiction Code 9, although other jurisdiction codes such as 2 are possible.

05. In the event the taxpayer files an offer claiming both Doubt as to Collectibility and Doubt as to the Liability both issues must be examined to determine whether to categorize the assessment as TR. In general, these offers are worked only on the Doubt as to Collectibility issue since, the amount being offered will not fully resolve the modules once the IRS has collected the amount being offered, the remaining balances will be cleared once the terms of the Offer have been met. Terms of the offer include:



    1. Any refund for the year following the acceptance of the OIC must be waived by the taxpayer and applied to the liability.

    2. The taxpayer must file and full pay their taxes for five years following the date of the accepted OIC.


06. In cases where the taxpayer does not check any of the boxes on the Form [656,](https://www.irs.gov/pub/irs-pdf/f656.pdf) Offer in Compromise, and submits an offer to resolve the case, review of the offer case file and the collection file (if available) to ascertain whether other supporting documentation will assist in determining whether the taxpayer acknowledges the assessment.

07. For all accepted offer scenarios described above, the IRS will clear the remaining module balance once the taxpayer has met the terms of the agreement. If they abide by the terms of the offer, there is no further collection potential. These modules should not be recategorized as a WO. When all the terms of the OIC are met, the balance will be abated. If there is evidence the assessment was not abated timely, the module may have to be recategorized to MEMO.

08. If the Unpaid Assessments Accounting Analysis staff cannot secure the Form 656, AOIC printouts stating the OIC was processable and proof that a payment came in with the OIC will substantiate TP agreement. The sample module must have the TC480 posted on the sample and proof of the payment if the payment posted on a different tax period. The OIC payments will usually contain DPC codes:



    - 33 Offer in Compromise application fee (Amount varies by year).

    - 34 Offer in Compromise 20% lump sum/initial periodic payment.

    - 35 Offer in Compromise subsequent payments made during the offer investigation.


09. Sometimes the OIC will not have a payment if the Taxpayer meets low income criteria. This information is notated on the “payment” tab of AOIC. If the waiver info is present on the AOIC “payment” tab, qualification criteria is indicated and generally not be a payment. If the tax module contains a TC480 and no payment(s) (for whatever reason), and the Unpaid Assessments Accounting Analysis staff is unable to secure Form 656, AOIC printouts showing history, processability, tax periods included, etc.

10. The AOIC website provides examples of letters sent to taxpayers. Letters can be printed out for confirmation of paragraphs used. A COMBO letter with paragraphs I is sent when there is a signature issue. A RETURN letter can be used with paragraphs H. If a signature paragraph is not selected, a lack of signature was not the issue and the Form 656 was properly signed by the taxpayer. Using the combined information on the AOIC website of the OIC agreement and “Doubt as to Collectibility”, or “ETA” with other pertinent AOIC screens along with the COMBO letter/RETURN letter would support taxes receivable categorization.


**1.34.4.3.5** **(05-15-2025)**

#### Examination

1. The IRS relies on coding input by the business owners into the tax administration systems (e.g., master file and CADE) that denotes agreement by the taxpayer on assessments made through examination. Proposed examination assessments can be signed at the conclusion of the financial statement estimation process constituting agreement. Proposed assessments without an agreement result in the issuance of a 90-day statutory notice of deficiency to provide further opportunities to agree or file for an appeal. These assessments will not be made until the 90-day period for filing or the Appeal proceedings has completed. A taxpayer’s signature on the following forms supports agreement for the processed amount:



   - Form 4549, Report of Income Tax Examination Changes

   - Form 890, Waiver of Restrictions on Assessment signed by the taxpayer for Estate, Gift, and Generation-Skipping Transfer Tax.

   - Form 5564, Notice of Deficiency - Waiver.

   - Form 870, Waiver of Restrictions on Assessment signed by the taxpayer.

   - Form [1040X](https://www.irs.gov/pub/irs-pdf/f1040x.pdf), Amended return with exam assessment.


Form 5564, Notice of Deficiency, documents the taxpayer’s consent or change to the assessment. The Form 870, Waiver, is signed in conjunction with Form 5564, Notice of Deficiency, or a similar form that proposes tax changes from the return filed or previously adjusted figures. A signed Form 870, Waiver, at the conclusion of the financial statement estimation process indicates a two-party agreement with all previous tax assessment and abatements as the present adjustment is built upon them. In addition, an amended return signed by the taxpayer documents agreement to the examination assessment. This list of forms is not all-inclusive. If the taxpayer does not respond, the assessment will be made by default and it will be categorized as CA.



2. The Form 5344, Examination Closing Record, by itself is not acceptable supporting documentation for categorization purposes. This form does not show taxpayer agreement with the examination assessment results. During case reviews, review the supporting documentation that supports the Form 5344, Examination Closing Record.


**1.34.4.3.6** **(09-07-2018)**

#### Agreement to Substitute for Return

1. Substitute for Return (SFR) (IMF returns) or Internal Revenue Code (IRC) 6020(b) (BMF returns) – are tax returns usually prepared by Exam when a filer has not timely filed a tax return. These will not have a taxpayer's signature and are assigned a specific blocking series range. IRC 6020(b) returns are submitted electronically by Exam. The IRS relies on coding input by the business owners into the tax administration systems (e.g., master files) that denote agreement by the taxpayer on assessments made through the IRS compliance programs.

2. There is evidence of taxpayer agreement to a SFR assessment or IRC 6020(b) by the taxpayer signature on the statutory notice of deficiency via:



   - TC 599 with closing codes 13 or 89 for Automated Substitute for Return (ASFR).

   - TC 599 with closing code 09, 39, 64 or 89 for IRC 6020(b).


The signature document must be secured to prove taxpayer agreement which would result in TR.



**1.34.4.3.7** **(05-15-2025)**

#### Tax Equity and Fiscal Responsibility Act of 1982 Examination

1. Tax Equity and Fiscal Responsibility Act of 1982 (TEFRA) is a complex set of examination, processing and judicial procedures that affect the way the IRS works with some partnerships and Limited Liability Companies (LLCs) that file as partnerships. When auditing TEFRA partnership returns, assessments or refunds flow through to the individual partner’s tax return. The partnership audit closure determines the appropriate categorization of the flow-through to the individual partner’s tax return. The assessments are not made to a partnership return. TEFRA procedures require all be handled in a partnership-level proceeding and not at the individual partner level. TEFRA created the Tax Matters Partner (TMP), that is designated to act as an intermediary between the IRS, the partnership and its partners.

2. If all the partners properly execute the agreements/waivers, the case is closed, and tax assessed. If the case is unagreed and no protest is made to Appeals, or if no settlement in Appeals can be reached after a timely protest, those partners who have not yet agreed to the proposed adjustments will be issued a Notice of Final Partnership Administrative Adjustments (FPAA). Issuance of the FPAA begins a period where the TMP and/or Notice Partners/Notice Groups may petition to go to tax court. No assessment is made until there is a final determination on the partnership proceedings by either a signed partner agreement, the FPAA defaults, or there is a tax court decision. If a taxpayer files a petition in District Court or the Court of Federal Claims, then the IRS can assess at that time and make corrections later based on the final court decision. Once the assessment is made, the module is considered TR. Once the TEFRA assessment has been made all administrative channels have been exhausted and the only avenue for further action by the taxpayer is to pay the tax and pursue in District Court or Court of Federal Claims.

3. The complexity of some TEFRA examinations involving multiple tax shelters, bankruptcy, criminal proceedings, etc., can result in other categorizations due to complexity of the process.


**1.34.4.3.8** **(10-03-2019)**

#### Partnership Bipartisan Budget Act (PBBA)

1. The Partnership Bipartisan Budget Act (PBBA) was passed on November 2, 2015, to repeal provisions associated with the Tax Equity and Fiscal Responsibility Act of 1982 (TEFRA) partnership procedures and the Electing Large Partnership (ELP) and created a new centralized partnership audit regime. The BBA regime is generally effective for tax years beginning on or after January 1, 2018; however, partnerships may elect to have the new regime apply to certain earlier tax periods that began after November 2, 2015.

2. BBA legislation allows for multiple avenues to report an imputed underpayment either prior to or after an audit.



1. The legislation allows IRS to impute an underpayment resulting from partnership audit adjustments to the audited partnership, instead of passing the adjustments and the resulting tax to the partners. The assessment would be made with TC300 on Form 1065 with a reason code 187 and the payment would post with a DPC 72.

2. The audited partnership may request to modify the imputed underpayment (IU) amount that the IRS proposes to them, by filing one or more partner amended returns or alternative documents. These amended returns/alternative documents will be posted as a TC290 with a reason code 188, and payments would post with a DPC 73. These amounts can be posted for Forms 990, 1040, 1041, 1065 or 1120S filed by partners.

3. Partnerships can also elect to “push out” the audit adjustments to its partners instead of paying the IU. If pushed out to another pass-through partner, that pass-through partner can pay their portion of the IU by filing a Form 8985. These IU assessments would be posted as a TC290 with a reason code 189, and payments would post with a DPC 74. These can be posted to partners accounts that originally filed Forms 1041, 1065 or 1120S.

4. Partnerships can also elect to “push out” the audit adjustments to its partners instead of paying the IU. If pushed out to another pass-through partner, that pass-through partner can pay their portion of the IU by filing a Form 8985. These IU assessments would be posted as a TC290 with a reason code 189, and payments would post with a DPC 74. These can be posted to partners accounts that originally filed Forms 1041, 1065 or 1120S.

5. Partnerships can also report an IU that is not related to an examination by filing an AAR (Administrative Adjustment Request). The assessment would be made with TC290 with a reason code 185 and the payment would post with a DPC 70.

6. Partnerships filing an AAR can also elect to ‘push out’ the adjustments to its partners instead of paying the IU. If pushed out to another pass-through partner, that pass-through partner can pay their portion of the IU by filing a F8985. The assessment of the IU would be posted as a TC290 with a reason code 186. The payment would post with a DPC 71. These can be posted for Forms 1041, 1065 or 1120S.

7. Adjustments pushed out to taxable (terminal) partners are reported on their next filed return and reflected as part of the TC150 amount. Prepayments made to offset these assessments would post with a DPC 75. These prepayments can be posted for Forms 1040, 1120, 1041 and 990T.


3. Because no PBBA audit assessment will be made until all administrative channels including tax court, district court, court of claims, or appeals have been exhausted these assessments will be considered Taxes Receivable. The other assessments made under this new legislative process are based on reporting by the taxpayer(s) and will be considered Taxes Receivable.


**1.34.4.3.9** **(05-15-2025)**

#### Abusive Tax Avoidance Transactions S-Corporation Charitable Contribution Strategy 2

1. An Abusive Tax Avoidance Transaction (ATAT) is generally a specific tax transaction or promotion that reduces tax liability to take a tax position that is not supported by tax law. A listed transaction is a generic term used to describe a transaction that is the same as, or substantially like, one that the IRS has determined to be an ATAT. These are identified by the IRS notice or other forms of published guidance. Generally, listed transactions that could not be resolved through the administrative Appeals process are returned to the originating function for the issuance of the Statutory Notice of Deficiency. If no petition is filed with the Tax Court, the assessments are made by default and the only way for either the corporation/partnership or individual to be reduced or eliminated is for the taxpayer to pay the tax and file a claim for refund for each assessment. At this point the taxpayer would have exhausted all administrative procedures, and the assessment is considered a legally enforceable assessment. This constitutes implied agreement because the taxpayer has no further recourse.

2. An example of a listed transaction is S-Corporation Charitable Contribution Strategy (SC-2). This abusive transaction results in assessments that are made against a business entity and an individual (shareholder or partner) based on different tax laws relating to corporations and individuals. Although they seem to be duplicate assessments, Appeals has determined that these assessments are mutually exclusive.

3. In most cases where Appeals has made a determination sustaining the IRS position regarding tax assessment involving listed transactions, default assessments will be considered TR. Because the taxpayer must pay the tax and then file a claim, it is a refund litigation proceeding. Subsequent litigation proceedings could change the categorization. For example, final litigation settlement terms may indicate that the IMF assessment will stand and the BMF assessments will be abated in full. In this instance, recategorize the BMF module(s) as Memo.


**1.34.4.3.10** **(05-15-2025)**

#### Appeals Cases

1. Taxpayers that appeal an assessment are worked by the IRS Appeals business owner. Proposed examination assessments result in the issuance of a 90-day statutory notice of deficiency to provide further opportunity to agree or file for an appeal. The assessment will not be made until the 90-day period for filing or the Appeal proceeding has completed. An Appeals decision in favor of the IRS is documented on Form 5278, Income Tax Changes Appeals Closing Report; Form 5403, Appeals Closing Record; the Appeals Officer Settlement report, and/or Form 5402, Appeals Case Memo, and outlines the results of the Appeals decision. The Appeals decision should clearly state that the decision is in favor of the IRS. An unagreed Appeal proceeding results in the issuance of a 90-day statutory notice of deficiency to provide further opportunity to agree or petition tax court. The assessment will not be made until the 90-day period for filing with the tax court has passed with no petition filed. If the taxpayer disagrees but does not petition tax court within the 90 days, the taxpayer must fully pay the tax assessment and file a claim for refund. Because the taxpayer has exhausted all administrative procedures, the courts will not hear the case, and the assessment is considered a legally enforceable assessment and TR. A subsequent court ruling in favor of the taxpayer would be necessary to consider changing the categorization.

2. In the case of some excise tax assessments, the taxpayer may pay a divisible portion to contest it with the court. These modules should be categorized as CA and payment does not indicate agreement; the taxpayer is making the payment in order to be able to contest the assessment in court.


**1.34.4.3.11** **(05-15-2025)**

#### Court Decision Cases

1. Court Decisions assessed are TR. The IRS has interpreted the language in SFFAS no. 7 to recognize assessments as TR if court actions determined or authorized the assessment. The dollar amount of the assessment does not need to be part of this authorization the IRS may determine the dollar amount if an amount is not specified by the court. The IRS relies on the court ruling either by an actual copy in the IRS case file or from a third-party source such as Lexis/Nexis. This court ruling should clearly state the decision rendered is in favor of the IRS. This includes decisions due to “Lack of Jurisdiction.” A decision for Lack of Jurisdiction indicates that the taxpayer did not meet the requirements for the case to be heard. This may be failure on part of the taxpayer to comply with conditions essential for exercise of jurisdiction, such as filing forms timely and paying required filing fees. The taxpayer has no recourse other than to pay the balance due and file a claim.

2. As with an appeals decision, once a court ruling has been made, further correspondence from the taxpayer stating they still disagree will not be considered in making the assessment CA. The court ruling will be supported by documentation from one or more of the following:



1. Tax Court Decision in favor of the IRS, including Lack of Jurisdiction rulings.

2. Lexis/Nexis internet court case database print-out of the tax court decision in favor of the IRS.

3. Other court ruling where taxpayer acknowledges assessment and/or ruling or court documentation provides evidence that the assessment is valid.


3. If the court rules Lack of Jurisdiction, this indicates the taxpayer was aware of the assessment, initiated action to contest the assessment, failed to take all necessary steps to follow through and has no further recourse other than to pay the tax and file a claim. Therefore, these will be considered TR, even if the court ruling does not specify the reason it was ruled as Lack of Jurisdiction. If the taxpayer had evidence to refute the assessment, they would provide it. Professional judgment will be applied on a case-by-case basis if compelling evidence exists in the file indicating the module aligns more closely with the CA categorization. In the absence of compelling evidence to the contrary, the module will be categorized as TR.


**1.34.4.3.12** **(05-15-2025)**

#### Restitution Based Assessments

1. Restitution Based Assessments (RBA) are ordered by a court. The amount of the tax loss is calculated from evidence admitted at a trial or from information contained in the plea agreement and presented to the court at sentencing. The requirement that the defendant pay restitution will be contained in a document signed by the judge called a Judgment and Commitment Order (J&C).

2. Public Law No. 111-237 amended IRC 6201 applies to restitution orders entered after August 16, 2010. It provides that the IRS shall assess and collect the amount of restitution ordered by the court in a tax case for failure to pay any tax imposed under this IRC in the same manner as if such amount was tax.

3. The amount of restitution ordered payable to the IRS creates two separate debts. The first debt is the restitution judgment which the Department of Justice Financial Litigation Program (DOJ FLP) is responsible for collecting. The second debt is the RBA which may be collected in the same manner as a tax.

4. Because these RBA debts stem from the same underlying tax liability, the full amount can only be collected once. The RBA debts may be assessed on multiple taxpayer’s accounts. Therefore, any payments that reduce the amount of the RBA must also be applied against the underlying tax liability for the same type of tax and tax periods (duplicate civil and/or codefendant assessments).

5. Restitution assessments for IMF accounts will be made on MFT 31 and can be identified by TC 971 with AC 102. Restitution ordered on an individual will also have a Reason Code (RC) from 141 to 150 and a TC 971 with an AC from 180 to 189. Restitution assessments for BMF accounts will be made on MFT 02, 06, 05, etc. with an AC from 180 to 189. Most restitution assessments will be made against individual taxpayers, even if the restitution assessment relates to a BMF source. Duplicate assessments include RBA made on MFT 31 accounts and civil tax and/or fraud penalties assessed on each respective party’s underlying tax account.

6. Without evidence to the contrary, RBA will be categorized as TR and all related duplicate civil and/or codefendant restitution assessments should be Memo.


**1.34.4.3.13** **(09-07-2018)**

#### Bankruptcy Cases - Taxpayer Agrees to Pay the IRS Assessments

1. The taxpayer agrees to pay the IRS assessments via bankruptcy. A bankruptcy court decision, settlement agreement, or other documentation which documents that the tax assessment is included in bankruptcy claim/estate is TR. Also, inclusion of the IRS balances due in the taxpayer’s bankruptcy plan demonstrates agreement. This applies to Chapter 11, 12 and 13 bankruptcies and is based on an approved reorganization plan which includes court agreement of the claim(s) on declared assets that will be used as a basis to pay creditors, to the extent possible, according to Bankruptcy Code rules. The following items are acceptable evidence to categorize the module as TR.



1. Bankruptcy court decision, settlement agreement or other documentation which documents that the tax assessment is included in bankruptcy claim/estate.

2. Westlaw internet database of federal and state court cases and/ or Lexis/Nexis printout of bankruptcy cases showing court decision.

3. The Master File Transcript (MFTRA) showing receipt of bankruptcy payment (TC 520 with a subsequent TC 521 posting indicating case is out of bankruptcy court), and a TC 670 (payment) with a DPC of 03, undesignated bankruptcy payment code or DPC 11, bankruptcy payment designated to trust fund. This indicates funds are received on an approved Bankruptcy Court decision, thus indicating acknowledgment of a balance due, even though hardcopy documentation on the case is not readily available.


2. In certain situations, the IRS proof of claim will be sufficient evidence to be a TR.



1. If accompanied by third-party court records (e.g. Lexis/Nexis, Westlaw, or PACER) that indicate the taxpayer filed an objection to the claim and was denied.

2. Certain states allow a specified length of time for the taxpayer to object to a claim. If that period has passed and the bankruptcy was filed in one of these states, the proof of claim is sufficient evidence. However, the Unpaid Assessments Accounting Analysis analyst must provide evidence of the time frame allowed within the applicable state as a part of the case file.

3. If there is credible evidence in the file that the taxpayer is on an approved plan, such as third-party court records (e.g. Lexis/Nexis, Westlaw or PACER).

4. The Unpaid Assessments Accounting Analysis analyst will provide the Automated Insolvency Systems (AIS)-4 print history record, if available, for further documentation of bankruptcy events.


3. Some modules are fully dischargeable by the courts under the bankruptcy laws, and the IRS will ultimately abate the remaining module balance once the taxpayer has been discharged by the court and all exempt assets have been addressed. While there is clearly no future collection potential, these modules should not be recategorized as a WO since this is a normal part of the tax administration process. If there is evidence in the file that the IRS should have abated the assessment prior to the financial statement estimation pull date and it has not yet occurred, the module may have to be categorized as a 100% Book Value Adjustment (BVA) to Memo.


**1.34.4.3.14** **(09-07-2018)**

#### Judgments

1. A judgment issued in favor of the IRS by the U.S. District Court is like a court ruling. A judgment legally extends the period that the IRS can collect a balance due by 20 years and again the taxpayer has no recourse. A judgment is indicated on the tax module by a TC 550 with a definer code 4. The IRS must provide a copy of the judgment for evidence of the TR.

2. When the IRS sends a suit recommendation to reduce tax assessments to judgment, the U.S. Department of Justice Tax Division attorney assigned to the case will often request a “payoff” figure which is the amount of tax, penalty, and interest due as a certain date. The judgment is then entered in this amount but will also make it clear that interest and penalties continue to accrue from that date. While interest and penalties that have accrued up to the date provided in the judgment are included in the judgment amount, and they are owed by the taxpayer, IDRS will not reflect these accruals because the accruals are systemically calculated when certain conditions take place. The Service is not required to make a separate assessment of interest on an assessed tax liability to collect the interest. The Service allows interest to accrue unassessed because the computer systems do not have the capacity to continually assess all interest accruals. See IRM 20.2.5.2.2, Assessment of Interest Accruals, for additional information on accrued interest amounts.


**1.34.4.3.15** **(05-15-2025)**

#### Stand-Alone Penalties

1. The IRS has the authority to assess penalties including civil monetary penalties, for non-compliance with filing and reporting provisions of the IRC. These penalty assessments made by the IRS are a non-tax-assessed return, assessed by the IRS per the IRC or assessed by the Joint Committee on Taxation to ensure taxpayers who fail to comply with the law are penalized. Certain penalties are a statutory requirement and create a legally enforceable assessment which the taxpayer cannot appeal. The taxpayer can seek relief through “reasonable cause” provisions for failing to comply with the law.

2. While penalties are not additional tax assessments, they are by statute treated as if tax. There is no avenue for the taxpayer to challenge or dispute the assessment of the penalties, except under reasonable cause provisions, as the penalty assessment is based on specific guidelines prescribed by the IRC for non-compliance; it is not based on additional tax assessments. Penalties are strictly the result of a failure to comply with the laws.

3. An abatement of penalty for reasonable cause provides full or partial relief for the penalty when the taxpayer provides evidence of circumstances which prevented them from complying with the law in a timely manner. Examples are serious illness, fire or natural disaster. A Reasonable Cause abatement has no bearing on financial categorization. There is no correlation between penalty abatement due to reasonable cause and the reversal/reduction of a tax assessment based on a taxpayer appeal.

4. There are options for the taxpayer to file a refund suit per a Chief Counsel Response. At this point the taxpayer would have exhausted all administrative procedures and in principle the assessment is a legally enforceable assessment. Filing a refund suit requires full or partial payment of the penalty assessment. Such an act by the taxpayer would support a categorization of TR, not Compliance.

5. Review of the paragraph descriptions that generate with the balance due notices provided in _Exhibit 1.34.4-4_, Stand Alone Penalties, confirms that no appeal of the legality of penalty assessments is possible. Notice 972(CG) A penalty is Proposed for Your 2xxx Information Returns-Action Required and Publication 1586 Reasonable Cause Regulations and Requirements for Missing and Incorrect Name/TINs (including instructions for reading CD/DVDs).

6. The Stand-Alone civil penalty assessments are categorized as TR based on the supporting analysis and several examples of applicable penalties with paragraphs and corresponding IRCs included in _Exhibit 1.34.4-4_, Stand Alone Penalties.


**1.34.4.3.16** **(05-15-2025)**

#### Affordable Care Act

1. The IRS has unique cases that resulted from certain new fees enacted in the Affordable Care Act (ACA) legislation including the Branded Prescription Drug and Health Insurance Provider (repealed 12/31/2020) fees where an established annual amount is required to be collected by the government for each of these fees by the end of the reporting period (September 30) but the formal assessment process will not be completed until after the reporting period. The IRS is required to send letters to each company notifying them of the portion of the annual revenue required to be collected for that year that they are responsible for paying and these bills provide legal notice of the receivable balance despite a delay in the formal assessment process. When the revenue has been collected by September 30, the subsequent assessment simply nets to $0 since there was no receivable balance at the end of the year. Because the initial assessment cannot be abated and while the fee can be adjusted in a subsequent year’s module, such fees should not be recorded as receivables. If the revenue is not collected by September 30, a receivable does exist based on the issuance of the letter or notice of the amount due. If the amount is paid subsequently, it is recorded as revenue for the new fiscal year and should be applied to resolve the unpaid assessment from the prior year.


**1.34.4.3.17** **(10-03-2019)**

#### Individual Shared Responsibility Payment - Silent Returns

1. Silent returns are those Form 1040 series returns where the taxpayer is silent with respect to health care coverage. This means they did not check one of the two boxes on the return if they had health care or did not have health care. This began for the 2018 filing season, the IRS rejected electronically filed silent returns with respect to health care coverage under the provision of IRC 5000A.

2. Shared Responsibility Payments (SRP) are reported on Form 1040, line 61, Health care; individual responsibility, Form 1040EZ, line 11, and Form 1040A, line 38. The amount reported is carried to MFT 35 and assessed as a TC 240 with penalty reference number (PRN) 692. If the SRP was adjusted or assessed by Compliance, there will be a TC 240, PRN 692 and RC 154 on the module. MFT 35 will post one cycle after MFT 30.

3. The SRP amount is carried to MFT 35, the total tax shown on Form 1040, Line 63, will not be in the total tax amount (TC 150) shown on MFT 30. A TC 971 AC 530 will post to MFT 30 with the SRP amount on the memo field, see IRM 5.16.1.3.6 Currently not Collectible.


**1.34.4.3.18** **(03-03-2021)**

#### Employer Shared Responsibility Provision

1. Employer Shared Responsibility Provision (ESRP) is for large employers that may be assessed an employer shared responsibility payment under IRC 4980H(a) if they do not offer health insurance with minimum essential coverage.

2. The ESRP assessments may be included when issuing a levy or filing a Notice of Federal Tax Lien when an employer fails to pay the ESRP imposed by IRC 4980H.

3. The ESRP assessments are processed on the BMF under MFT 43 and will be considered TR.


**1.34.4.3.19** **(05-15-2025)**

#### Social Security Deferral

1. Section 2302 of the Coronavirus Aid, Relief and Economic Security (CARES) Act contains a provision for employers to defer, without penalty, the entire amount of the employer’s share of Social Security tax, employer’s share of the Railroad Retirement Tax (RRTA) and 50% of social security tax on net earnings for Self-employed individuals for the period March 27, 2020 through December 31, 2020. These deferrals were to be repaid over a two-year period ending December 31, 2022. Any remaining amount unpaid after that date is included in delinquent TR.


**1.34.4.3.20** **(05-15-2025)**

#### IRC U.S. Code Section 965 Transition Tax

1. In December 2017, the Tax Cuts and Jobs ACT (TCJA) enacted IRC U.S. Code Section 965, which requires certain taxpayers to pay a transition tax on the untaxed foreign earnings of certain specified foreign corporations as if those earnings had been repatriated to the United States. Those potentially subject to the transition tax are:



   - US shareholders of a specified foreign corporation.

   - Certain direct/indirect domestic partners in domestic partnerships that are United States shareholders of specified foreign corporations.

   - Shareholders in a S Corporation that are United States shareholder of a specified foreign corporation.

   - Certain beneficiaries of another pass-through entity that are United States shareholder of a specified foreign corporation.

   - Certain beneficiaries of a cooperative association that are United States shareholder of a specified foreign corporation.

   - A United States shareholder is generally one who owns 10% or more of the foreign corporation’s stock, applying the indirect stock ownership principles of Section 958.


2. When the taxpayer has filed a 201712 to 201911 Federal Tax Return (i.e. 1040, 1120, 1041) with an IRS U.S. Code Section 965 Transition Tax Statement attached or 201812 or later Federal Tax Return with a Form 965-A, Individual Report of Net 965 Tax Liability or Form 965-B, Corporate and Real Estate Investment Trust (REIT) Report of Net 965 Tax Liability and Electing REIT Report of 965 Amounts and IRS has allowed the taxpayer to defer their IRS U.S. Code Section 965(h) Tax for a period up to eight years, the amount that IRS allows the taxpayer to defer, is the amount included in Taxes Receivable.


**1.34.4.3.21** **(05-15-2025)**

#### Identity Theft

1. Identity theft occurs when someone uses an individual’s information, such as name, social security number, or other identifying information without permission to commit fraud or other crimes. Taxpayers may notify the IRS when they believe they have been the victims of identity theft. Taxpayers must provide documentation to support claims of identity theft. Once identified, the taxpayer submits a paper copy of their tax return, and an adjustment is input on their SSN to reverse the "bad" return amounts and to match the valid tax submitted with the valid Form [1040](https://www.irs.gov/pub/irs-pdf/f1040.pdf). This account is correctly categorized as TR until all administrative actions are completed and the corrections are final.


**1.34.4.3.22** **(10-03-2019)**

#### Frivolous Returns

1. Modules $25 million and greater: The CFO/IRS will review Taxes Receivable modules over $25 million. If it is apparent that the balance due on the return is not substantiated (i.e., income has no W-2, Form 1099 or Schedule C information to back up income reported on the return - this list is not all inclusive) then these modules will be moved to Memo. This balance due is not an asset and should not be reported in the IRS’s financial statements.

2. Modules under $25 million: Frivolous/fraudulent return under $25 million modules are more apt to be only partially correct. For example, a taxpayer voluntarily files a return with inflated credits. The inflated credits are reversed but the income can have an actual basis. Frivolous or fictitious income is a question of fact that IRS can mainly determine through an examination or criminal investigation. IRS cannot readily assume based on the appearance of the return that the tax liability is not valid when reported by the taxpayer and will continue to categorize these monies as TR until all administrative actions are complete.


**1.34.4.3.23** **(09-07-2018)**

#### Form 900 Waiver

1. Form 900, Waiver signed by the taxpayer extending the CSED. Whenever the 10-year CSED for collecting the tax balance is about to expire, taxpayers may sign a Form 900, Waiver, extending the CSED which constitutes agreement to extend the IRS ability to collect the taxes owed. This is implied agreement as the taxpayer is acknowledging the balance due by allowing the extension of the CSED. Form 900, Waiver, discloses the unpaid assessment amount due to the IRS.


**1.34.4.3.24** **(09-07-2018)**

#### Correspondence

1. Correspondence from taxpayer acknowledging unpaid assessment is owed or agreement to assessment or adjustment.


**1.34.4.3.25** **(05-15-2025)**

#### Pattern of Payments

1. In the absence of evidence of taxpayer agreement or disagreement, two additional factors are currently considered in determining categorization. An unpaid assessment will be considered a TR when three or more payments are posted to the module (including a TC 538 for Trust Fund BMF modules and/or payments posted to a liable officer’s module) from any source within any time period after the assessment or one or more payments are posted to the module within any time period after the assessment where the payments on the MFTRA reflect one of the following DPC:



   - Non-trust fund (DPC 01).

   - Trust fund (DPC 02).

   - Undesignated bankruptcy payments (DPC 03.)

   - Manually monitored installment agreement (DPC 10).

   - Bankruptcy payment designated to trust fund (DPC 11).

   - Cash bond credit (DPC 12).

   - Payment in response to reminder notice OBRA 1993 (DPC 13).

   - Taxpayer authorized payment to expired CSED account (DPC 14).

   - Taxpayer payments received with Form 8519 (DPC 15).

   - Payment with Amended Return (DPC 24).

   - OIC application fee (DPC 33).

   - OIC 20% lump sum for initial periodic payments (DPC 34).

   - OIC subsequent payments made during the offer investigation (DPC 35).

   - Private Debt Collection (DPC 54).

   - Offshore Streamlined Filing Compliance payment (DPC 61).

   - Offshore Voluntary Disclosure (OVD) payment (DPC 62).

   - Repatriation payment for IRC U.S. Code Section 965 (DPC 64).

   - Partnership Bi-partisan Budget Act payments (DPC 70-75).

   - Miscellaneous payment other than above (DPC 99).

   - On MMIA installment agreements and notice status payments (DPC 00)


2. Although payments described above can be considered evidence of TR, written documentation submitted by the taxpayer (such as a SFR reconsideration return) indicating they do not agree to the posted assessment will override the systems’ use of the payments for categorization criteria.

3. The DPCs listed above indicate voluntary payments from the taxpayer, which implies that the taxpayer agrees that he/she owes the assessment amount. Prior work has shown that these DPCs have been accurate. The Unpaid Assessments Accounting Analysis analyst will provide further documentation on a payment that is being used as the sole basis for categorizing the module as TR. A copy of the payment from the Remittance Transaction Research (RTR) system, a case history entry, etc. will further support that the payment was voluntary.


**1.34.4.3.26** **(09-07-2018)**

#### Transaction Code 706 Refund Offset

1. On IMF only, the IRS has legal authority to offset taxpayer refunds against outstanding tax balances and then provide notice to the taxpayer. When three or more Refund Offsets (TC 706) post to the module, the TC 706’s must originate from three separate and consecutive tax years and post in three separate and consecutive calendar years. Because the taxpayer cannot stop this activity but can stop filing for refund returns, continuing to file and allow offsets of withholding or other credits to resolve the tax balance in each of the past three years, this constitutes implied agreement. Also, this provision applies if the taxpayer has not yet filed a current year return but has requested an extension to file. In this case, the three offset patterns can be used for the three consecutive prior tax years.


**1.34.4.3.27** **(05-15-2025)**

#### Defunct or Bankrupt Entities

1. If research shows that a balance due return was filed for any period after the account is defunct or bankrupt, (TC 530/CC 07 or 10), the IRS must exercise due diligence to determine why a return was filed. There may be accounts that have some modules with TC 530 CC 07 or 10 on some modules but not on others - particularly on more recent modules. If there is not a TC 530 posted on a more recent module, it will likely be categorized by Custodial Detail Data Base (CDDB) as TR or CA, not as WO. If research by the Unpaid Assessments Accounting Analysis analyst finds recent activity in the field related to the newer returns, this is also an indication that the entity may not be completely out of business or that some kind of collection may be possible.

2. If a new module is added after an account has a Currently Not Collectible (CNC) placed on prior years. To make a CNC determination, the IRS’s procedures are to separately review each module with a balance due over $25,000, therefore a module must be TR until the IRS makes that determination.


**1.34.4.3.28** **(03-17-2023)**

#### Trust Fund Recovery Penalty

1. Employers are required to file an employment tax return and withhold from their employees’ salary amounts for individual federal income taxes and FICA (Social Security and Medicare or hospital insurance) taxes. These amounts are held “in trust” for the federal government. The employer is to pay or turn the withheld money held “in trust” to the federal government. Individuals within a business can be held personally liable for the amounts withheld. A TFRP is a penalty that the IRS can assess against an individual who is willfully responsible for not forwarding to the federal government these taxes withheld from employees’ salaries. Typically, individuals found willful and responsible are officers of a corporation, such as a president or treasurer. This will be referenced on the person or persons responsible on their IMF account using an MFT 55 reference code 618 (TFRP Assessment). The business is still liable for the entire amount of the unpaid payroll taxes, which includes the employer’s share of the withholding.

2. For MFT 55 reference code 618 (TFRP Assessments): Existence in the MFT 55 module of any of the TR evidence supports the Taxes Receivable categorization of the MFT 55 when the underlying tax assessment (BMF module) is removed from the UA inventory.

3. When two parties are assessed duplicate or partial duplicate assessments, any evidence of TR that could be used on any related module can be used on the sample module for the same assessment amounts to support TR. As an example: The sample is TFRP MFT 55 module. There is a another TFRP MFT 55 module marked duplicate. It is a duplicate of the sample module. The related BMF Form 941 is gone or unable to secure the Form 941. There is no evidence of TR on the sample module. If there is evidence of TR (OIC, IA, etc.) on the related module that evidence can be used for the Categorization narrative to support TR on the sample module.


**1.34.4.3.29** **(05-15-2025)**

#### Comments Section

1. The comment section should be used to record additional support for the categorization decision. It is helpful if information about the case is provided, so that the primary and secondary reviewers can understand the specifics of the case without necessarily having to review the entire case file. Examples include:



   - overall synopsis of facts of the case (i.e., circumstances under which the assessment occurred),

   - details considered when reaching the categorization decision (i.e., taxpayer agreement or the lack of agreement),

   - address why or why not a TR, if applicable (i.e., taxpayer is still a wage earner and filing tax returns versus a defunct corporation),

   - brief synopsis about the taxpayer’s tax history (i.e., consistent tax filer, the IRS has been unsuccessful in locating the taxpayer for years, specify number of years),

   - description of corrective action initiated, if applicable.


**1.34.4.4** **(05-15-2025)**

### Categorization Criteria for Compliance

1. As outlined above the only distinction between the CA and TR categorization is the lack of taxpayer agreement to the assessment. If the supporting documentation does not provide evidence that the taxpayer agrees to the assessment (in writing or by actions identified above), the UA module should be categorized as a CA. An exception would be if circumstances of the case more closely align with the WO category. The most common CAs are Substitute for Returns where the IRS has determined the amount the taxpayer owes due to the taxpayer not filing a return, examination assessments where taxpayers do not agree to the examination assessment or fail to respond to the examination notice (Notice of Deficiency) and MFT 55 Trust Fund Recovery Penalty (TFRP) assessments in which the underlying assessment (the BMF module) has been removed from the UA and there is no activity on the MFT 55 module that indicates agreement. In this case (TFRP MFT 55 and no underlying BMF assessment in UA), it will not be necessary to secure the return of the underlying BMF assessment.

2. Under the IRS categorization methodology, accounts without supporting documentation would be CA.


**1.34.4.4.1** **(05-15-2025)**

#### Unagreed or Default Compliance Assessment

1. Most assessments made resulting from one of the IRS's compliance programs go through a notice stage giving the taxpayer the right to agree to the amount or provide accurate information to determine the proper tax amount. Whenever taxpayers do not respond within the time provided these assessments are made by default. This does not reflect taxpayer agreement or in some instances prohibit further amendments by the taxpayer. If the taxpayer responds they disagree but takes no further action to provide information for the IRS to properly change the amount originally assessed, the amounts are categorized as a CA.

2. Documentation supporting the assessments on CA cases is necessary when the case results from a manual process (e.g. an examination, manually calculated SFR). The Unpaid Assessments Accounting Analysis section does not need to obtain supporting documentation if the CA resulted from an automated assessment (e.g. ASFR, Combined Annual Wage Reporting (CAWR)). If there are multiple assessments on the CA module, documentation is required only for the assessment(s) created by a manual process.

3. On occasion, the Unpaid Assessments Accounting Analysis section is unable to obtain supporting documentation for a CA, due in part to the extreme age of many CAs. The CAs are contained in the supplemental information of the financial statements because they are considered estimates.

4. If the Unpaid Assessments Accounting Analysis section is unable to provide sufficient documentation to substantiate the categorization for a TR case, the module would need to be recategorized as CA. Without supporting documentation, the audit value of a TR assessment is considered an estimate. Lack of documentation is considered to be a characteristic of CA categorization.


**1.34.4.4.2** **(05-15-2025)**

#### Manual Refunds

1. Unpaid assessments created by TC 840 (manual refund), with no TC 150, TC 973 and no other evidence the taxpayer requested the refund in advance on a filed return will be categorized as Compliance. The liability that has been created is not agreed to by the taxpayer but should be reduced to zero once the return posts unless math error changes are made to the filed return during processing.

2. Tax Returns filed with math error and if 60 days has not yet passed as of the sample date and the taxpayer would not have owed any tax due to a refund or full paid return the assessment will be considered compliance. If there was a balance due the module would be split between TR and CA with only the math error portion of the assessment categorized as Compliance.

3. Unpaid assessments created by TC 840, with no TC 150, unreversed TC 973, unreversed TC 971 AC 711 (Return Integrity and Compliance Services selected return or potential frivolous filing) and it is not clear the return is frivolous will be categorized as Compliance.


**1.34.4.4.3** **(03-03-2021)**

#### Frivolous Returns

1. Compliance modules under $10 million that are frivolous returns will remain categorized as Compliance until all administrative actions are complete. Compliance modules $10 million and above that are frivolous returns will be recategorized as Memo.

2. Unpaid assessments resulting from an assessment made by the IRS to recoup a prior refund issued from a frivolous filed return will be categorized as Compliance.


**1.34.4.4.4** **(09-07-2018)**

#### Comments Section

1. The comment section should be used to record additional comments that would be helpful in explaining the basis for the categorization decision. It is helpful if information about the case is provided, so that the primary and secondary reviewers can understand the specifics of the case without necessarily having to review the entire case file. Below are examples of things the Unpaid Assessments Accounting Analysis analyst may include in the comment section.



   - Overall synopsis of facts of the case (i.e., circumstances under which the assessment occurred),

   - details considered when reaching the categorization decision (i.e., taxpayer agreement or the lack of agreement),

   - address why or why not a CA, if applicable (i.e., taxpayer is still a wage earner and filing tax returns versus a defunct corporation),

   - brief synopsis about the taxpayer’s tax history (i.e., consistent tax filer, the IRS has been unsuccessful in locating the taxpayer for years, specify number of years),

   - description of corrective action initiated, if applicable.


**1.34.4.5** **(09-07-2018)**

### Categorization Criteria for Write-Off

1. Write Off categorization represents modules which the IRS designates as not being collectible at the present time. WO accounts may at one time have been either a TR or a CA, but the absence of any future collection potential prevents them from being considered TRs under federal accounting standards. The UAs that fit into the WO category are primarily those that the IRS designates as not being collectible at the present time with closing codes in _IRM 1.34.4.5.1 Individual Master File Write-Off Indicators_ and _IRM 1.34.4.5.2 Business Master File Write-Off Indicators_. These closing codes include cases where the IRS has had no contact with the taxpayer or has been unable to locate the taxpayer, there is a short period of time before the CSED expires, and where no payment activity has occurred in several years. The IRS assigns a TC 530, CNC, to a module that has little collectibility potential. The TC 530 will usually have a 2-digit closing code that provides the reason for the module being CNC.

2. Because the IRS is measuring the designation of WO categorization, the Unpaid Assessments Accounting Analysis analyst will not secure the return/source document for the assessment on the module. The exception to this rule is when the categorization of an Officer (as TR) in a TFRP situation and that categorization is based solely on the original categorization of the BMF module.

3. If any of the following conditions exist, the module will not be considered a WO because these conditions indicate there is still some potential for collection:



1. Three of more unreversed payments within the last 24 months, except MFTs 01,11,14 and 16 Modules that meet the criteria for WO category 16 (CNC Trust Fund) or,

2. For IMF only, two or more unreversed refund offsets (TC 706 posted within the last 24 months).

3. Module is in Status 60 (IA) or MMIA.

4. Module has a pending OIC (unreversed TC 480).

5. Module has an unreversed TC 971 Action Code 62 (FPLP levy match).

6. Module has a TC 972 Action Code 54 (Returned from PDC) that posted within three months or less.

7. Modules whose entity has an unreversed TC 520 (Bankruptcy/Litigation).

8. Posting cycle of the module’s current status 22 or 26 is subsequent to the posting cycle of the latest unreversed TC 530.


4. The IRS can receive collections for various reasons on a module that has been deemed CNC. The situations listed above are either initiated solely by the taxpayer or are completely systemic. Since there is no human involvement on the part of the IRS, the CNC indicator (TC 530) remains on the module. This is appropriate in terms of the IRS policy since there is currently no active collection being pursued by the IRS. But it will not be considered a WO for financial reporting purposes if any of the exceptions listed above are met since it no longer meets the “little to no likelihood” definition.

5. The Unpaid Assessments Accounting Analysis analyst may determine that a module should be a WO when it does not strictly meet the following criteria. This would be based on professional judgment. The Unpaid Assessments Accounting Analysis analyst will include a full and detailed explanation of the circumstances that justify a deviation from these criteria.

6. If none of the preceding exceptions exist, the following are the types of unpaid assessments that fit into the WO categorization. There are similarities and differences between IMF and BMF, so the conditions for each are listed in their entirety below. Be sure to refer to the section that is applicable to the case the Unpaid Assessments Accounting Analysis analyst is reviewing. Each reason listed also shows the systemic indicator that is representative of that condition, which is on the Accounts Receivable Dollar Inventory (ARDI) transcript if the module was systemically categorized as WO. This indicator correlates directly to the Program Requirements Packages (PRPs) that the IRS uses for systemic categorization purposes.

7. The following two subsections will explain the IMF and BMF WO indicators.


**1.34.4.5.1** **(09-07-2018)**

#### Individual Master File Write-Off Indicators

01. The IRS WO indicator 1 is for a deceased taxpayer. Supporting documentation shows the taxpayer is deceased (CC 08), with no evidence of an estate. These have been investigated by a revenue officer or ACS and determined that the taxpayer is deceased with no assets.

02. The IRS WO indicator 7 is for a taxpayer that is unable to be located or contacted. The IRS is unable to locate (CC 03) or contact (CC 12) the taxpayer and the module has been in this condition for two years from the transaction date of the TC 530 to the date the was selected. Applicable to closing code 12 only, if a review of MF indicates the taxpayer has filed a return within the past four years under primary or secondary TIN do not move the module to WO. Use the assessment date or 23c date of the returns TC 150 to the date the module was selected.

03. The IRS WO indicator 8 is for certain currently not collectible conditions such as, CNC before 1/1/1968 or TC 530 with document code 51 or 52 (CC 01), CNC Narcotics Trafficker Assessment (CC 02), CSED expired on portion of assessment prior to issuance (CC 04) or CSED expired, or suit initiated to reduce claim to judgment with no follow-up (CC 05).

04. The IRS WO indicator 9 is for when the taxpayer is unable to pay due to hardship (CC 24 through 32, which are systemically reversed if the taxpayer’s income reaches a pre-determined level), deferred (status 23), CNC due to tolerance (CC 09) or shelved due to low collection potential (CC 39 – National Office directive), and a review of the MFTRA shows the taxpayer is a non-filer, it should be categorized as a WO. A non-filer is defined as a taxpayer that failed to file a return for the past four years. Use the assessment date (23c date) of the return (TC 150) to the date the module was selected.

05. The IRS WO indicator 12 is when the module meets the following criteria:



    - The TC 530 with closing code 24 through 32 or 39 posted more than 3 years ago and the taxpayer is deceased.

    - The TRCAT equals 070 (deferred) and the taxpayer is deceased.

    - The TRCAT equals 070 (deferred) and a TC 530 in the transaction portion of the transcript or a date of death in the entity section of the transcript or the Mail Filing Requirement (MFR) is equal to 08 (These are different than modules where the taxpayer is deceased and a TC 530 was already input with a CC 08). If the taxpayer is already in one of the TC 530 CC listed above, or in deferred status it is unlikely the case will reactivate for investigation and the TC 540 shows the taxpayer is deceased.


Unpaid Assessments Accounting Analysis analyst can determine if the taxpayer is deceased by locating a TC 540 in the transaction portion of the transcript or a date of death in the entity section of the transcript or the Mail Filing Requirement (MFR) is equal to “08”. (These are different than modules where the taxpayer is deceased and a TC 530 was already input with a CC 08). If the taxpayer is already in one of the TC 530 CC listed above, or in deferred status it is unlikely the case will reactivate for investigation and the TC 540 shows the taxpayer is deceased.



06. The IRS WO indicator 13 is for CNC and the Queue. The module is in CNC status with any CC, in the queue (status 24) or is deferred (status 23) and the collection statute will expire within twelve months of the date the module was selected.

07. The IRS WO indicator 17 is for modules in the queue (status 24) over one year and a review of the MFTRA shows the taxpayer is a non-filer. The module should be categorized as WO. A non-filer is defined as a taxpayer that failed to file a return for the past four years. Use the assessment date (23c date) of the return (TC 150) to the date the module was selected.

08. The IRS WO indicator 18 is for modules in the queue (status 24) over one year, and the taxpayer is deceased, the module should be categorized as WO.

09. The IRS WO indicator 19 is for Identity Theft for financial reporting, the CFO currently does the following analysis to place an unpaid assessment module in WO. The TIN is an Internal Revenue Service Number (IRSN or invalid SSN) which starts with a 9 and the 4th and 5th digit range from 00-69 or is 89). The module will contain a TC 840 with a blocking series of 9xx and the TC 840 refund is less than ten years old.



    1. Identity Theft occurs when someone uses an individual’s information, such as name, social security number or other identifying information without permission to commit fraud or other crimes. Taxpayers may notify the IRS when they believe they have been the victims of identity theft. In these instances, taxpayers must provide documentation to establish that they are identity theft victims. Once documentation is provided the modules can be identified for financial reporting. In most instances when these modules are identified, an IRSN is established. The IRSN format is in the same pattern as regular SSNs: XXX–XX–XXXX. However, the IRSN will always begin with the digit 9.

    2. The information on the valid SSN that belongs to the invalid taxpayer is moved to the IRSN, leaving only the valid information on the valid SSN. Since the invalid taxpayer often has received a refund, it is moved from the valid SSN to the IRSN. The module is often in UA because various credits are not allowed on the IRSN. The modules are generally marked with a TC 971 AC 030, cross referencing the TC 840/841 refund reversal of the IRSN with the valid SSN. The likelihood of collecting on these accounts is unlikely since Unpaid Assessments Accounting Analysis analyst does not know the taxpayer’s real name or address, the IRS classifies these modules as WO.


10. The IRS WO indicator 20 is for financial reporting, the CFO does the following analysis to place an unpaid assessment module in write-off: The SSN is an IRSN which starts with a 9 and the 4th and 5th digits are 00-69 or 89. The TRCAT age of the module is greater than 365 days.


**1.34.4.5.2** **(09-07-2018)**

#### Business Master File Write-Off Indicators

01. The IRS WO indicator 2 is for bankrupt or defunct entities (CC 07 or 10) or Desert Storm (CC 14). The closing code for Desert Storm (TC 530 CC 14) was used by the IRS to close certain defunct corporations similar to the TC 530 CC 10 closing code for periods where the TFRP assessment was not applicable. These should be categorized as WOs. The MFT 01 modules that are potential corporations require further analysis as discussed below and in Section 1 under Split Categorization.

02. The IRS WO indicator 3 (a - e) is if the module has a Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf) (MFT 01), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf) (MFT 11), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) (MFT 14) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (MFT 16) and is a potential corporation and the TC 530 is a defunct or bankrupt corporation (CC 07, 10 or 14), or have an unreversed TC 971 AC 364, or an In-Business corporation (CC 13), the module exhibits may be considered a WO under certain conditions. If the modules exhibits a) or b) and one of the conditions in c) exist, the module is considered a WO:



    1. If the CC 13 (In-Business Corporation) and the module contains a TC 971 AC 330, and the new Assessment Statute Expiration Date (ASED) on the TC 971 is over 6 months old. (This indicates the investigation is concluded and the TFRP won’t be assessed).

    2. If the TFRP modules has a Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf) (MFT 01), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf) (MFT 11), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) (MFT 14) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (MFT 16), these will be considered WO if the business is defunct/bankrupt or reported TC 530 CC 13 and the Trust Fund portion of the assessment has been paid in full or eliminated in some other manner (abatement, CSED expired, etc.). If it has been paid in full, the MFT 01, 11, 14 or 16 balance is categorized as a WO.

    3. One of the following conditions exist,



       > - The IRS WO indicator 3 (a) is if the total of all payments (TC 610, 650, 716, 538 and 670 with designated payment code 02 or 11) on the MFT 01, MFT 11, MFT 14 or MFT 16 is equal to or more than the total tax assessed.
       >
       >        - The IRS WO indicator 3 (b) is if the total of all Trust Fund designated payments (TC 538 and 670 with DPC 02 or 11) is more than the Trust Fund amount. To compute the Trust Fund Amount, add the Adjusted Total Income Tax Withheld (AITW) to half of the Adjusted Total of Federal Insurance Contribution Act (FICA) tax Withheld (AFTW) for MFT 01, 11 or 14. The Trust Fund Amount equals the Tax on the return for MFT 16.
       >
       >        - The IRS WO indicator 3 (c) is an entire MFT 01, 11, 14 or 16 TFRP module balance, other than an in-business corporation (CC 13), will be considered a WO when the Form 2749, Request for Trust Fund Recovery Penalty Assessment, cannot be located and no cross-reference TINs can be found or verified. This is indicated on the module by a TC 971 with AC 331. This transaction code is input by an IRS employee who has exhausted all avenues of research in their attempt to locate responsible officers of the corporation. Without knowing who the responsible officers are, there is no hope of future collection.
       >
       >        - The IRS WO indicator 3 (d) is an entire MFT 01, 11, 14 or 16 module balance will be considered a WO when the module has an unreversed TC 530 CC 07, 10 or 14, does not contain a TC 971 AC 93, and the ASED for assessing the TFRP has expired. The ASED for assessing the TFRP expires three years from the succeeding April 15th of the calendar year the return is due or from the actual date the return was filed, whichever is later.
       >
       >        - The IRS WO indicator 3 (e) is an entire MFT 01, 11, 14 or 16 module balance will be considered a WO when the module has an unreversed TC 530 CC 07, 10 or 14, contains a TC 971 AC 215 and does not contain a TC 971 AC 93.


03. The IRS WO indicator 4 is for a deceased taxpayer. Supporting documentation shows the taxpayer is deceased (CC 08), with no evidence of an estate. These have been investigated by a revenue officer or ACS and determined that the taxpayer is deceased with no assets.

04. The IRS WO indicator 5 is if certain currently not collectible conditions such as, CNC before 1/1/1968 or TC 530 with document code 51 or 52 (CC 01), CNC Narcotics Trafficker Assessment (CC 02), CSED expired on portion of assessment prior to issuance (CC 04) or CSED expired or suit initiated to reduce claim to judgment with no follow-up (CC 05), or Resolution Trust Corporation (CC 15), CNC due to full payment on an in-business trust fund account (CC 16) or obsolete CC 20–23, 33–38 and 40–69.

05. The IRS WO indicator 6 is Resolution Trust Company (RTC)/Federal Deposit Insurance Corporation (FDIC) assessments. These are normally identifiable by a TC 530 with closing code 15 in the detail section of the transcript. However, the IRS also uses a TIN listing of all RTC who have filed the required certification to identify RTC assessments where it may be inappropriate to use the TC 530 CC 15, and a system code is placed on the module to indicate it is an RTC account. That system code is not visible on the MFTRA. These will be supported by a RTC Certification in the file.

06. The IRS indicator 7 is when the IRS is unable to locate (CC 03 or 17) or contact (CC 12 or 18) the taxpayer and the module has been in this condition for two years when the module was selected. If the module is a Form [1120](https://www.irs.gov/pub/irs-pdf/f1120.pdf) (MFT 02), it is considered a WO regardless of the length of time it has been in this condition.

07. The IRS indicator 10 is for financial hardships. If the taxpayer is unable to pay due to hardship (CC 24 through 32), or the module is under tolerance (CC 09 or 19), or shelved due to low collection potential (CC 39 – National Office directive), or is an in business corporation (closing code 13) and not a Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (MFT is not 01, 11, 14 or 16), further review is needed. Review the transcript to determine the taxpayer’s filing requirements. The filing requirements can be found in the Entity section of the transcript.



    - If the module is a Form [1065](https://www.irs.gov/pub/irs-pdf/f1065.pdf) (MFT 06) or a Form [1120](https://www.irs.gov/pub/irs-pdf/f1120.pdf) (MFT 02) and the taxpayer is not required to file a return (Filed Return (FR) 00) or is inactive (FR 08), the module is considered a WO.

    - If the module is a Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf) (MFT 01), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf) (MFT 11), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) (MFT 14) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (MFT 16), and the filing requirements are closed (FR 00 \[or blank\], 03 or 51), the module is considered a WO.

    - If the module is any other MFT and the taxpayer is not required to file any returns (FR 00 or 08 for all forms), the module is considered a WO.

    - If the module is for a non-filer, the module is considered a WO. Non-filer, in this context, is defined as 1) filing requirements are open for only a single MFT and 2) the tax year of the last period satisfied (for the same MFT) is three or more years old. This indicates the taxpayer has not filed for at least two years (MFT 51, 52, 77 and 78 are exceptions to this definition since they do not have regular filing requirements).


08. The IRS WO indicator 13 is Currently Not Collectible: If the module is for any MFT except Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf) (MFT 01), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf) (MFT 11), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) (MFT 14) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (MFT 16) that is a potential corporation, and is in any CNC condition (any CC) except tolerance (CC 09 or CC 19) and the Collection Statute will expire within twelve months from the date the was selected.

09. The IRS WO indicator 15 is for deferred and accounts in the Queue. If the module is deferred (Status 23) or in the queue (Status 24), further review is needed. Filing requirements may also be a determining factor. Review the transcript to determine the taxpayer’s filing requirements. The filing requirements can be found in the Entity section of the transcript.



    > - If the Collection Statute will expire within twelve months from the date the module was selected, the module may be considered a WO.
    >
    >     - If the module is a Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf) (MFT 01), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf) (MFT 11), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) (MFT 14) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (MFT 16), and the filing requirements are closed (FR 00 \[or blank\], 03, or 51), the module is considered a WO.
    >
    >     - If the module is any other MFT and the taxpayer is not required to file any returns (FR 00 or 08 for all forms), the module is considered a WO.
    >
    >     - If the module is for a non-filer, the module is considered a WO. Non-filer, in this context, is defined as 1) filing requirements are open for only a single MFT and 2) the tax year of the last period satisfied (for the same MFT) is three or more years old. This indicates the taxpayer has not filed for at least two years (MFT 51, 52, 77 and 78 are exceptions to this definition since they do not have filing requirements).

10. The IRS WO indicator 16 is for CNC Trust Fund. If the module is a Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf) (MFT 01), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf) (MFT 11), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) (MFT 14) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (MFT 16) on a defunct or bankrupt corporation (CC 07 or 10), or an in-business corporation (CC 13), the module may be considered a WO under certain conditions.



    > - If the module has been in this condition for one year, first verify that a Trust Fund penalty was not assessed and,
    >
    >     - If there is no TC 971 with AC 93 on the module, this is an indication that the penalty was not assessed and,
    >
    >     - Verify that there is no open litigation (TC 520) on the module, which could be an indication that a Trust Fund penalty assessment is possible at a later date.


**1.34.4.5.2.1** **(09-07-2018)**

##### Trust Fund Rollups

1. The IRS discontinued the policy of "rolling up" TFRP assessments in August 2001. The CSED will expire within the next few years on nearly all the rollups that still exist. Because of their minimal dollar value in comparison with the overall UA inventory and their decreasing volume each year, these accounts will now be moved to WO and their corresponding MFT 55s will be moved to duplicate. If the module meets all three of the following criteria, the account is correctly categorized as WO.



   - There are TC 971s on the module linking them to at least one officer,

   - The module is part of a Rollup MFT 55, and,

   - CDDB categorized the module and gave it a Valid Cross Reference (VCR) indicator of 92. (TFRP Rollup Cases, as identified by CDDB, where both IMF and BMF modules are present in the UA inventory. CDDB will consider IMF a duplicate, and BMF a non-duplicate WO.


**1.34.4.5.2.2** **(03-03-2021)**

##### Frivolous Returns

1. Write-off modules under $10 million that are frivolous returns will remain categorized as Write-off until all administrative actions are complete. Write-off modules $10 million and above that are frivolous returns will be recategorized as Memo.


**1.34.4.5.2.3** **(09-07-2018)**

##### Comment Section

1. The comment section should be used to record additional comments that would be helpful in explaining the basis for the categorization decision. It is helpful if information about the case is provided, so that the primary and secondary reviewers can understand the specifics of the case without necessarily having to review the entire case file. Below are examples of things the Unpaid Assessments Accounting Analysis analyst may include in the comment section.



   - Overall synopsis of facts of the case (i.e., circumstances under which the assessment occurred),

   - Details considered when reaching the categorization decision (i.e., taxpayer agreement or the lack of agreement),

   - Address why or why not a WO, if applicable (i.e., taxpayer is still a wage earner and filing tax returns versus a defunct corporation),

   - Brief synopsis about the taxpayer’s tax history (i.e., consistent tax filer, the IRS has been unsuccessful in locating the taxpayer for years, specify number of years),

   - Description of corrective action initiated, if applicable.


**1.34.4.6** **(09-07-2018)**

### Categorization Criteria for Memo

1. The Memo Categorization was developed to handle accounts that should not be carried on the IRS’s books. The Memo accounts do not show anywhere on the IRS’s financial statements.

2. The Unpaid Assessments Accounting Analysis analyst manually moves modules to memo when the module categorization is incorrect. Please refer to (a) and (b) below:



1. Modules can be manually moved to Memo Categorization prior to the cycle established for the selection of the UA financial statement estimation process. These cases will then be in the proper category for the financial statement estimation process and for the September 30th inventory. This reduces the number of adjustments to the financial statements. Throughout the year, the Unpaid Assessments Accounting Analysis analysts review all $25 million and over TR, $10 million and over (CA and WO) and $500 million and over Non master file (NMF) cases. Manual move transactions can be posted to modules over $5 million. This allows Unpaid Assessments Accounting Analysis to identify other modules in an account and properly categorize those modules as Memo if appropriate.

2. During the financial statement estimation process, any of those large dollar cases that could not be reviewed prior to the cycle established for the selection of the UA financial statement estimation process (e.g. case was too new) may need to be re-categorized as Memo. In addition, modules under $25 million (TR), and modules under $10 million (CA and WO) may need to be re-categorized as Memo because the systemic categorization process was unable to determine the proper categorization. If the module is under these thresholds, the amount is projected to the inventory to determine an adjustment amount for the financial statement. If a module is over these thresholds, the adjustment to the financial statement is a one-for-one adjustment.


3. The following are examples of situations in which a tax module or part of the module should be moved to Memo.



1. There is a duplicate assessment. The IRS should report the assessment only once.

2. The assessment is due to a fraudulent or frivolous return filed by a taxpayer. Example: a taxpayer was filing large balance due frivolous returns. These returns sometimes remain on the books until CI completes their investigation, and erroneously inflate the TR, CA or WO categorizations. The analyst should perform further analysis to determine if the case should be referred out for investigation and/or possible abatement.

3. There are credits misapplied to another module or TIN that will full pay the account. This happens frequently with Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) because payments post on other MFTs.

4. The situation involves a complex case in which the taxpayer will receive refunds on some modules and deficiencies on other modules. These cases would have one or more of the following characteristics:



      > - There are many tax periods involved with related and/or intermingled issues.
      >
      >       - The examination or appeal will not be resolved for over one year.
      >
      >       - The Appeals Officer, Revenue Officer, etc. cannot reasonably estimate the resulting balance due or refund amount until all actions are completed. This is because cases are processed as an account, not by tax period, so there can be netting and global interest issues to contend with.
      >
      >       - The taxpayer requested, and the IRS agreed, not to issue a refund or pursue collection until all issues are resolved (even if several of the modules are already settled). The deficiency modules will have a STAUP, TC 470, or some other freeze that prevents notices or collection.


4. The MFT 46 modules (Form [8038](https://www.irs.gov/pub/irs-pdf/f8038.pdf), Information Returns for Tax-Exempt Private Activity Bond Issues series returns) are systemically categorized as Memo. This is since any payments associated with these forms are not “tax” payments and when there is a balance due, it is normally resolved within a few cycles with the return processing, manual/systemic refund, and/or credit posting (TC 766) reconciling the module to zero balance due.

5. In some cases professional judgement must be used. In rare circumstances, Unpaid Assessments Accounting Analysis analyst will receive a case so close to the interim cutoff date that there is not adequate time to secure documentation before the UA interim cutoff date deadline. Certain anomalies can be detected that provide decisive indications that a module is frivolous, or in some way grossly overstated, by researching the MFTRA and other IRS systems. The Unpaid Assessments Accounting Analysis analyst uses professional judgment and make the decision to manually move a module to Memo, even in the absence of conclusive physical documentation, rather than allowing an overstatement to be reflected on the financial statement. The Unpaid Assessments Accounting Analysis analyst will clearly document any anomalies that led to their determination, such as strange figures transcribed from the return, codes, account history, etc. If documentation is received later than the UA interim cutoff date deadline, and it is subsequently determined that the case should not have been manually moved to Memo, it will be manually moved back to the proper categorization but will not reflect negatively on the IRS.


**1.34.4.7** **(09-07-2018)**

### Criteria for Split Categorizations

1. There are times when an unpaid assessment falls into a Split Categorization. A Split Categorization occurs when an unpaid assessment is defined as TR due to the taxpayer agreement or court ruling and is followed by an unagreed subsequent assessment that is categorized as CA. Another Split Categorization would be TR and WO, TR and Memo, CA and WO, and CA and Memo.

2. A Split Categorization is not systemically defined in all cases. A manual input of an action code and percentage is required to define each categorization. The percentage will provide how much of the Total Module Balance (TMB) belongs to each categorization and may result in a variance.

3. To calculate the split categorization percentage between TR and CA assessments, the Unpaid Assessments Accounting Analysis analyst will input a Transaction Code (TC) 971 Action Code (AC) 209. For a TR and WO split, a TC 971 AC 211, TR and Memo split, a TC 971 AC 210, CA and WO split, a TC 971 AC 212, and CA and Memo split, a TC 971 AC 213, will be input. Prior to manually transmitting an action code, the analyst will complete a split Allocation Worksheet found on the CASTS home page, to calculate the categorization split.

4. The following subsections explain how these are worked.


**1.34.4.7.1** **(09-07-2018)**

#### Trust Fund Recovery Penalty

1. Most split categorization occurs in unpaid payroll tax cases. In these cases, a split categorization can result because a TFRP was assessed but the business with the delinquent payroll taxes is no longer in existence. In such instances, the business’ portion of the unpaid payroll taxes is categorized as a WO. The TFRP portion of the payroll tax assessment is categorized as a TR or a CA depending on whether there is evidence of taxpayer agreement, unless the Unpaid Assessments Accounting Analysis analyst believes there is no future collection potential on the TFRP. In the latter case, the entire unpaid payroll tax module would be recategorized to WO. Due to the complex nature of Single Officer/Multiple Corporation Assessments and Multiple Officer/Multiple Corporation Assessments, CDDB cannot categorize many of these. The CDDB program can categorize certain Single Officer/Multiple Corporation Assessments.


**1.34.4.7.2** **(09-07-2018)**

#### Non Trust Fund Recovery

01. A split categorization on a tax module can occur when an unpaid assessment defined as TR is followed by an unagreed subsequent assessment that should be categorized as CA.

02. A module may also have a split categorization between TR and Memo if a portion of the balance due has an expired CSED. In this situation, the earlier assessment would be Memo (not a receivable), and the later assessment would be TR. There may also be other situations that would be appropriate for a split between TR and Memo, CA and WO, and CA and Memo. For example, amounts that are assessed jointly and separately, but should be reported only once.

03. Some split categorizations are systemically defined. Others will require manual input of an AC and percentage to define each categorization. The percentage will correspond to how much of the TMB belongs to TR.

04. Modules are split between:



    - TR and CA amounts with a TC 971 AC 209.

    - TR and Memo amounts with a TC 971 AC 210.

    - TR and WO amounts with a TC 971 AC 211.

    - CA and WO amounts with a TC 971 AC 212.

    - CA and Memo amounts with a TC 971 AC 213.


05. Complete the Split Allocation Worksheet found on CASTS home page for manual splits, to calculate the categorization split and use those percentages with the TC 971 or use the ARDI transcript.

06. When using the ARDI transcript to calculate a split categorization, use the following:



    - Use IDRS or MFTRA to determine the tax amount that is TR by taking the assessed agreed tax,

    - Subtract any prepaid credits (i.e., Withholding) and,

    - Subtract any payments,

    - Divide the amount by the Uncollected Tax Assessed line item on the ARDI transcript. The result is the percentage that is TR.


07. Manual split categorizations require managerial approval. Include support showing how the TR percentage was derived on the written manual move request.

08. After receiving managerial approval, input TC 971 with AC 209 or 210, 211, 212, and 213, including the TR percentage or CA percentage (out four decimal points) derived from the split calculation using command code REQ77/FRM77. Use the MISC field to enter the TR or CA percentage as a 4-digit number. For example, TR or CA amount of 7.64 percent is entered as “0764”. CDDB will use this input to split the module and will remain in effect until a later assessment, abatement or payment occurs. If this change occurs, a manual reversal is needed to ensure correct categorization.

09. If the categorization or percentage needs to be changed after input of the initial split due to an assessment, abatement or payment, the initial manual input must be reversed with a TC 972 and, if appropriate, a new 971 AC input with a cycle delay.

10. When calculating the split ensure TC 240’s, TC 350’s and any other penalty that apply only to one of the assessments are removed before calculating the split percentages and then added back to penalty amount for the specific assessment they apply to.


**1.34.4.8** **(09-07-2018)**

### Book Value Adjustments

1. There are various scenarios that may require a book value adjustment. The definitions and rules discussed below provide guidance for most circumstances encountered. However, due to the complexity of the Service’s working environment, not all instances will be encompassed. See _Exhibit 1.34.4-1_, Book Value Adjustments.

2. The IRS receives additional correspondence and claims from taxpayers and other sources that may or may not result in an additional assessment, abatement, or transfer of a payment.

3. The recognition of when an economic event has occurred for accounting purposes is outlined in _Exhibit 1.34.4-6_, Recognition of an Economic Event.


**1.34.4.8.1** **(10-03-2019)**

#### Abatements

1. Abatements are reductions in tax assessments (tax and associated interest, penalties and fees). They are identified by specific transaction codes listed on the MFTRA, which is a record of the status and activity of unpaid tax assessments, arranged by taxpayer, tax period and type of tax. Transaction codes such as TC 291, TC 295, TC 299, etc. reflect abatements of tax assessment, TC 301, TC 309, etc. reflect abatements of an examination or other tax assessment, TC 161, TC 171, TC 181, TC 271, TC 341, etc. reflect abatements of interest or penalty assessment, TC 534 to clear a portion of the assessment balance when the CSED or a portion of the module balance has expired prior to sample cut-off but the action is taken after the cut-off, and TC 604 reflects the balance was cleared after fulfillment of an OIC or discharge from bankruptcy. Abatements are generally made for the following reasons:



   - The assessment is excessive in amount or was erroneously assessed.

   - The IRS has determined that the administrative and collection cost involved does not warrant collection of the amount due (e.g., very small balances under the tolerance for collection).

   - The module balance is cleared at the conclusion of an accepted OIC or discharged out of a bankruptcy proceeding, after all conditions are met.

   - The expired portion of the assessment module balance is cleared.

   - The assessment is attributable to certain mathematical errors by the IRS or taxpayer.

   - The taxpayer failed to file a return and was assessed under section 6020(b) of the IRC, then subsequently files a return showing a tax liability lower than originally assessed.

   - The assessment of interest is attributable to errors and delays by the IRS.

   - The assessment of any penalty or additional tax is attributable to erroneous written advice by the IRS.

   - The assessment of a penalty is eliminated when the taxpayer establishes reasonable cause for non-compliance.

   - The assessment is reduced or eliminated due to additional information provided by the taxpayer (i.e., amended return, carry back of losses or added documentation).


2. If not posted to master file as of the interim cutoff cycle - no BVA.


**1.34.4.8.2** **(09-07-2018)**

#### Assessments

1. Assessments are an increase to the amount of tax, penalty and interest to the taxpayer’s account. They are also identified by specific transaction codes listed on the MFTRA. Transaction codes such as TC 290, TC 298, etc. reflect assessments of tax, TC 160, TC 170, TC 180, TC 270, TC 340, etc. reflect assessments of penalties and interest, and TC 300, TC 308, and etc. reflect assessments of tax as the result of an examination. Assessments are generally made for the following reasons:



   - The taxpayer voluntarily files an amended return to report additional tax due.

   - To correct mathematical errors in processing the taxpayer’s original return or to disallow credits claimed because the taxpayer failed to provide adequate documentation.

   - Third-party information such as Form [1099](https://www.irs.gov/pub/irs-pdf/i1099gi.pdf) and [W-2](https://www.ssa.gov/employer/index.htm) indicate the taxpayer failed to report part or all of their taxable income.

   - The taxpayer is audited by Examination and found to owe additional tax.


2. If assessment is not posted to master file as of the interim cutoff cycle, then there is no BVA.


**1.34.4.8.3** **(09-07-2018)**

#### Amended Return with Subsequent Adjustment

1. If a taxpayer files an amended return to request an adjustment filed after the due date of the return and appears the assessment, abatement or adjustments should have been posted prior to interim cutoff, secure an e-mail and/or documentation from the responsible area indicating the status. There are many reasons why adjustment may be legitimately delayed.

2. If documentation indicates there is an unreasonable delay that cannot be justified between the time of submission and the processing of the adjustment, a BVA will be required. A delay in account action of a year or more with no extenuating circumstances could be unreasonable.

3. If the adjustment is not posted to master file as of the interim cutoff cycle, then there is no BVA.


**1.34.4.8.4** **(09-07-2018)**

#### Penalties

1. A penalty is calculated from the balance of unpaid tax. There are times under certain situation where a penalty needs to be adjusted. It is understood that there will always be exceptional situations. For instance, the methodology already includes exceptions for cases such as complex audits, frivolous returns, etc. In addition to those types of situations, the Unpaid Assessments Accounting Analysis analyst may also consider a book value adjustment on certain modules that fall outside the norm, even in the absence of solid supporting documentation. In such special circumstances, intangible evidence may indicate a near certainty the balance will be eliminated or reduced. For example, a prominent corporation has a history of total compliance with filing and paying taxes in full and on time. The interim cutoff period reflects an exorbitant penalty was charged for failure to deposit timely. While Unpaid Assessments Accounting Analysis analyst may be unable to obtain proof positive, before the conclusion of the audit, that the penalty will be abated in full, it would be considered reasonable to move the balance to Memo. Using the same example, the Unpaid Assessments Accounting Analysis analyst can obtain the return and finds that the Schedule B was attached but not input. In such a case, it may be impossible to recompute the penalty in time for the conclusion of the audit, so proof positive does not exist. But it is reasonable to conclude the balance is inaccurate, and the Unpaid Assessments Accounting Analysis analyst would move this module to Memo.

2. The correct categorization is not always obvious. When the case contains extenuating circumstances, the Analyst will exercise reasonable judgment in determining the proper categorization for the financial statements.

3. If not posted to master file as of the interim cutoff cycle - no BVA.


**1.34.4.8.5** **(03-17-2023)**

#### Payments

1. There is a normal delay of generally two weeks between the receipt of a payment and the posting of the payment to the master file.

2. Payments received before the interim cutoff pull date and posted after the interim cutoff pull date would create a BVA of the payment amount and the unassessed accruals.

3. Payments made after the interim cutoff date will not result in a BVA for the unassessed accrual amounts that are included in the TMB. The accrual amounts will remain a part of the TMB. In this situation, put a footnote at the bottom of the Control Sheet to indicate Unpaid Assessments Accounting Analysis analysts are aware of the unassessed accrual amounts.

4. Example: TMB = $10,000, $50 of which is accrued (unassessed) penalty and interest. Payment is made for $9,950 after cutoff and results in a zero balance, Status 12. no BVA. Make a footnote at bottom of control sheet, unassessed accruals of $50 considered.

5. Refund transactions (example TC846 and TC840) posted prior to interim cutoff date with subsequent refund cancellation (example TC 841) posted after the interim cutoff pull date will not create a BVA of the refund amount and the unassessed accruals.


**1.34.4.8.6** **(09-07-2018)**

#### Misapplied Payments

1. Without proof the payment was directed by the taxpayer:



   - If the change is between TR and any other categorization there will be a BVA.

   - If the overall TR dollars are unchanged there is no BVA. Include a print of the ARDI transcript on the other module to prove it is in TR.


2. If the taxpayer tells the IRS to apply a payment in a specific way, and the IRS can provide proof the IRS did that, the IRS financial statement balances are correct. Unless and until the taxpayer proves the payment was misapplied, Unpaid Assessments Accounting Analysis analyst will not adjust the balances on the module.

3. There may be other factors involved such that it would make sense to transfer a payment that the Unpaid Assessments Accounting Analysis analyst may consider:



   - The history of the taxpayer in prior tax periods with similar situations.

   - All administrative actions may appear to be complete, but the payment was not moved.

   - The exact payment amount is claimed elsewhere and there is an obvious error with the account. For example, a payment is located on another module or spouse’s TIN that matches the amount missing on the module. If a reasonable conclusion can be made that the payment was intended for the module, a BVA would be appropriate.

   - Other situations that can be documented.


4. If the taxpayer does direct the IRS to move the payment, and the IRS does not do it; the result would be an incorrect balance and would result in a BVA. If the IRS cannot prove the taxpayer directed the IRS to apply the payment where it is posted and the result is an incorrect balance, a BVA is required.

5. On misapplied payments, if the non-interim cutoff module is in zero balance and a misapplied payment is transferred from it to the module, the amount of the misapplied payment nets to an unchanged amount. Prior to the moving of the payment, the balance due was reflected in the overall UA on the module while the non-interim cutoff module was zero balance. After the payment is moved, the module is zero and the non-interim cutoff module is balance due. There is no net in this case and no BVA would be required. However, if interest and penalties are abated on the module and/or assessed on the non-interim cutoff module, a BVA needs to be done for the net of that change.


**1.34.4.8.7** **(09-07-2018)**

#### Transaction Code 706 Credit Offset

1. The TC 706 is a credit offset from another tax module. This amount is not available until the TC 706 posts so there is no BVA.


**1.34.4.8.8** **(09-07-2018)**

#### User Fee Sweeps

1. User fee sweeps fall under the category of administrative actions that are not complete. If a payment was received before the interim cutoff pull and an Installment Agreement fee posts after the interim cutoff pull date, there is no BVA.


**1.34.4.8.9** **(09-07-2018)**

#### Trust Fund Recovery Penalty Related Modules

1. When there is a mis-posted TC 538 and the two modules involved are within the same financial categorization, the overall financial statement balance for the categorization is not misrepresented. The Unpaid Assessments Accounting Analysis analyst will provide an ARDI transcript as evidence of the financial categorization of the related tax module and that there is no BVA.

2. Payment for TFRP is received prior to the interim cutoff pull date and is posted on the officer IMF module, but the related cross-referencing of the payment on the BMF TC 538 module not posted until after the interim cutoff pull date. The IRS policy allows nine weeks to process the posting of the cross-reference payment on the BMF module. Regardless of whether the IRS time frame is met, the condition will require a BVA since the BMF module balance is overstated at the time of the interim cutoff pull. If an unposted TC 538 payment for a TFRP is received prior to the interim cutoff pull date and is posted on the officer IMF module, but no related cross-referencing of the payment on the BMF TC 538 is done, this is a BVA when the BMF module is the module.


**1.34.4.8.10** **(09-07-2018)**

#### Manual Recategorization Review

1. The Unpaid Assessments Accounting Analysis analysts are responsible for closely monitoring their accounts with manual recategorization (manual move) transactions year-round using the monthly $10 million reports (especially changed and dropped modules) and ad hoc reviews using the case files and CASTS inventory reports. There is also an annual mandatory review of all accounts containing a manual move indicator (TC 971 AC 203-213). An extract is done by Information Technology (IT) and sent to the KC-CFO staff for review in March of each year. Each analyst will review every manual move module in his/her current assigned inventory range to ensure the manual move is still accurate. Their findings and actions are reported to the manager. Each module on this extract will be reviewed by a second analyst or by the manager. Manual move case folders should be clearly noted so they are easily identified. This can be achieved by the inclusion of a note on the inside front of the case folder.


**1.34.4.9** **(05-15-2025)**

### Categorization Data Collection Instrument for Trust Fund Modules

1. The Categorization DCI for TFRP modules is designated to determine:



   - If the TFRP was assessed correctly.

   - If the balance due amounts are correct based on payments and other activities on related accounts and their status.

   - The total or partial categorization.


2. The Unpaid Assessments Accounting Analysis analyst will not prepare the TFRP DCI, the TFRP Corp Page Worksheet, or the TFRP Officer Page report when the Unpaid Assessments Accounting Analysis analyst calculation matches the assessment amount of the TFRP, when the Unpaid Assessments Accounting Analysis analyst can explain the difference, if any, in the calculation/assessment amounts and there are no payments that affect the Trust Fund balance. Any differences in the calculation/assessment amounts will be explained in the Categorization DCI and the worksheet showing the recalculation of the assessment and application of non-Trust Fund payments must be included in the file.

3. This categorization DCI should be completed for BMF Form [720](https://www.irs.gov/pub/irs-pdf/f720.pdf), [941](https://www.irs.gov/pub/irs-pdf/f941.pdf), [943](https://www.irs.gov/pub/irs-pdf/f943.pdf), [944](https://www.irs.gov/pub/irs-pdf/f944.pdf), [945](https://www.irs.gov/pub/irs-pdf/f945.pdf), [1042](https://www.irs.gov/pub/irs-pdf/f1042.pdf), and CT-1 cases. This list includes BMF tax forms for returns that potentially can have a TFRP assessed. If the case is not a corporation or limited partnership or the corporation is still active and a trust fund penalty has not yet been pursued, this should be noted on this DCI and the Unpaid Assessments Accounting Analysis analyst should use a regular categorization DCI for the categorization. This DCI is not a substitute for the regular categorization DCI, rather, it assists to appropriately categorize the UA financial statement estimation process item and derive appropriate adjusted gross balances. The Unpaid Assessments Accounting Analysis analyst will complete both categorization DCIs and for the unpaid payroll tax cases in the interim cutoff. It should be noted that the module can be a BMF module related to an IMF MFT 55 AC 618 module.

4. Since TFRPs are usually assessed against the officers of a corporation, Officer will be used generically in the DCI and these instructions refer to any individual assessed a TFRP. Also, officer will be understood to include any other businesses, such as a lending bank, against which a TFRP is assessed. All questions that would apply to an officer also apply to non-officers or other businesses. If a non-officer or other business is assessed the TFRP, describe the relationship thoroughly in the comment section at the end of the TFRP DCI. In completing this DCI, the Unpaid Assessments Accounting Analysis analyst will record the TFRP assessment amount against each of the officers from this corporation for the interim cutoff module. The last four digits of each officer’s social security number will be used as the identifier.


**1.34.4.9.1** **(09-07-2018)**

#### Trust Fund Determination

1. To determine whether a TFRP was assessed in a case, refer to the module MFTRA for evidence that a TC 971 with AC 93 exists, look for an UNLCER printout available in the file and/or look for a Form 2749, Request for Trust Fund Recovery Assessments in the file. If it is determined that a TFRP was not assessed, complete a regular categorization DCI.


**1.34.4.9.2** **(09-07-2018)**

#### Determining if the Business is Still Operating

1. Examine the full BMF transcript to determine whether the IRS records indicate the business still exists. One way is to look at the entity page to see if the filing requirements have been closed out. The word “None” will appear where the filing requirements would have otherwise appeared if it is out of business, or the filing requirements may be blank, or reflect indicators of 00 or 08, all of which indicate there are no open filing requirements. If recent return filings exist, indicated by the posting of a TC 150 in either MFT 01 or MFT 02 in the past two years, the business likely still exists. TC 530 closing codes can also indicate that a business no longer exists, but sometimes a business that is defunct may not be reflected on the IRS's records as such. Closing code 07 indicates the business is bankrupt and a code 10 indicates the business is defunct.


**1.34.4.9.3** **(05-15-2025)**

#### Recalculating the Trust Fund Assessment Amount

1. The use of the various CASTS TFRP pages is no longer required when the MFTRA, TXMOD, and worksheets can be used to verify the amount of the penalty is correct. The TFRP pages can still be used if needed to support a calculation.

2. Recalculate the TFRP using the TFRP Recalculation Worksheet. If the module involves a rollup assessment and it wasn’t appropriately categorized by CDDB and is not to be categorized as a full WO, recalculate each tax period on the UNLCER involved in the rollup using the TFRP Recalculation Worksheet. If a TFRP case is a full WO case (both the BMF side and MFT 55 side), or if the TFRP assessment/amount was sustained by Appeals/Court, or the related entity module’s CSED has expired, no recalculation of the penalty will be done even if payments were made. Although the recalculation is not done, BVAs would still be reported, if applicable.


**1.34.4.9.3.1** **(09-07-2018)**

##### Documentation

1. When documenting a TFRP there are a few resources available to determine the appropriate dollar amounts used for the recalculation. The Unpaid Assessments Accounting Analysis analyst will attempt to secure the TFRP File on any assessment in which the penalty cannot be matched, and the specific reason for the difference cannot be identified. If available, the Form 4183, Recommendation re: Trust Fund Recover Penalty Assessment, and computations from ATFR Web can be secured for possible explanation. If the module is a full WO, no TFRP file documentation will be needed. BMFOLR and TXMOD prints will be used when the dollar amounts are not on the MFTRA transcript. Provide an explanation for the possible discrepancies in the figures when the original TFRP calculation cannot be matched and the return cannot be secured. If a TFRP case is so old that penalty documentation is unavailable, the case will be recategorized as CA or WO and no recalculation will be required.

2. The Trust Fund amount is calculated by using half of the total FICA plus the total Federal Income Tax Withholding (FITW) for all periods except for tax year 1984 for Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf), or Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf). For tax years 2011 and 2012 refer to [IRM 5.19.14.3.2](http://irm.web.irs.gov/Part5/Chapter19/Section14/IRM5.19.14.aspx#5.19.14.3.2), as these are calculated differently. In that year the FICA was allotted at 6.7% for the employee share, and 7% for the employer share. The Trust Fund amount is the total FITW for Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) (the TC 150 amount). The Social Security Tax Rate Tables can be found in the ADP and IDRS Information Handbook, Document 6209. The amount of FICA tax can be obtained from the return information section associated with the TC 150 posted to the BMF module for the Form [941,](https://www.irs.gov/pub/irs-pdf/f941.pdf) Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf) or Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) returns. If available, trace the TC 150 FICA and FITW amounts on the module transcript to the tax return or exam document. If the return or exam document is not available, use the amounts on the MFTRA. The full "trust fund" amount may be reduced if sufficient or designated BMF payments post prior to the TFRP assessment, or if the officer was only an officer for part of the tax period. Thus, the TFRP assessment amount may differ for officers even though the assessment is for the same module.

3. Prior to June 19, 2000, unless designated, any payments made on the BMF module prior to when the Form [941](https://www.irs.gov/pub/irs-pdf/f941.pdf), Form [943](https://www.irs.gov/pub/irs-pdf/f943.pdf), Form [944](https://www.irs.gov/pub/irs-pdf/f944.pdf) or Form [945](https://www.irs.gov/pub/irs-pdf/f945.pdf) return is filed (e.g., federal tax deposits, TC 650) are first applied toward employer FICA, then employee FICA and FITW. This is also the case for any payments remitted at the time the return is filed unless the return was filed late. Any payments made on the BMF module after the return is filed and not designated to trust fund will be first applied toward employer FICA, then assessed penalties and interest, then accrued penalties and interest, and last to employee FICA and FITW. Any payments with a designated payment code of 02 or 11 will be applied first to employee FICA and FITW, then employer FICA, and finally to penalties and interest. (NOTE: See the chart entitled Payment Application on Trust Fund Recovery Penalty for determining where payments should be applied in these cases _Exhibit 1.34.4-2_, Payment Application on Trust Fund Penalty.

4. The accruals of interest and penalty must be recalculated if the payments are sufficient to cover the employer FICA and the assessed penalties and interest. Any remaining unpaid employee FICA and FITW will be the TFRP amount for that module. When the Unpaid Assessments Accounting Analysis analyst is recalculating the penalties many years after the original assessment was made by an IRS employee, other subsequent tax assessments, penalties and interest may have posted to the module that were not there at the time the penalties were first computed. Provide an explanation when there are differences between the recalculated penalty and the original penalty assessed, or where the figures need to be adjusted to match the original TFRP penalty assessment. In many instances additional tax adjustments such as TC 290 and TC 300 assessments made to the BMF account are not considered in the TFRP calculations. This is because it is difficult for the IRS to prove responsibility and willfulness on adjustments the IRS made that were not on the original tax return filed by the business.

5. On or after June 19, 2000, any payment made on the business account is deemed to represent payment of the non-trust fund portion of the tax liability (e.g., employer's share of FICA) unless designated otherwise by the taxpayer. The taxpayer has no right of designation of payments resulting from enforced collection measures. To the extent partial payments exceed the non-trust fund portion of the tax liability, they are deemed to be applied against the trust fund portion of the tax liability (e.g., withheld income tax, employee's share of FICA, collected excise taxes). Once the non-trust fund and trust fund taxes are paid, the remaining payments will be applied to assessed fees and collection costs, assessed penalty and interest and accrued penalty and interest to the date of payment.


**1.34.4.9.4** **(09-07-2018)**

#### Errors in Posting Payments

1. Payments made by an officer assessed a TFRP are to be posted to the business’ account, as well as other officers’ accounts who also received assessments. In addition, payments by the business after the TC 240 is posted on the officer’s IMF 55 module are to be posted to the account of each officer with an assessment. If needed, the Unpaid Assessments Accounting Analysis analyst will schedule out all payments that DID NOT post to the BMF or to IMF accounts, as well as abatements that do not appear related to any payments. In scheduling out the payments, the Unpaid Assessments Accounting Analysis analyst may substitute the Payment Sorter or ATFR web prints due to certain systemic limitation of the CASTS system.

2. In some cases, a payment made by an officer should not be reflected on other officers’ accounts. For example, if one officer was assessed for an earlier period, the other officers’ account would not be adjusted for the first payment they make, since payments apply to the earliest period first. In addition, once an OIC is accepted for one officer and the TC 971 AC 032 is posted, payments by other officers should not post to the OIC officer’s account. Provide an explanation for any payments listed on the DCI that do not appear on all related accounts but for which it appears no adjustment is needed.

3. A BMF overstatement occurs when payments made to the IMF are not posted via TC 538s to the related business account. (A TC 538 is a credit transaction that posts to the BMF module to reflect a payment made by an officer). An IMF overstatement occurs when payments made to the other IMF accounts or the business account which are not posted via TC 241 to related officers’ account. (A TC 241 with reference code 697 or 699 is an adjustment of the TFRP assessment due to payments by the corporation or other related officers of the corporation who were also assessed a TFRP). When overstatements are found for the module, enter the adjusted total module balance on the Control Sheet.


**1.34.4.9.5** **(09-07-2018)**

#### Recategorizing Trust Fund Recover Penalty Assessments Manually

1. When determining if the TFRP needs to be recategorized manually, and the business or the officer is in TR, check to see if the business is bankrupt or defunct, determine whether the TFRP assessment amount related to the business has been paid in full for the tax module. If the TFRP has been paid in full, recategorize the remaining module balance (i.e., non-trust fund portion of the payroll assessment to WO). In cases where the IRS assessed a TFRP and the company appears to be defunct or bankrupt, categorize the TFRP portion of the BMF module as a TR if either (1) the company agreed to the payroll tax assessment, or (2) the officer agreed to the TFRP assessment agreement. The non-trust fund portion of the module balance is recategorized to WO.

2. When the TFRP assessment amount has not been paid, complete the Allocation Worksheet (unless categorized by CDDB, see paragraph (5) below). This worksheet will help determine the IMF amount to be categorized as a TR or CA. A calculation based on the officer’s module balance is used in the determination of BMF WO amount versus BMF duplicate amount. When there are multiple officers, Unpaid Assessments Accounting Analysis analyst will pull all officers whose categorization is TR. The officer with the largest TR balance due will become the account of record. If there are multiple officers meeting TR criteria with equal balance due amounts, Unpaid Assessments Accounting Analysis analyst will use the officer with the lowest SSN. If no officer is TR, Unpaid Assessments Accounting Analysis analyst will use the above steps for Compliance criteria. If none of the officers meet TR or CA criteria, then the case is fully WO. Only complete the Allocation Worksheet for BMF module items.

3. On the Allocation Worksheet, the first step to manually calculate the allocation percentage. The calculation involves dividing the corrected TFRP amount for the BMF module by the total TFRP assessment amount. These TFRP amounts would not include any interest or other penalty assessments, only the portion of the unpaid payroll taxes for which the officer is liable. This percentage will allow the Unpaid Assessments Accounting Analysis analyst to determine the amount of additional penalties and interest, both accrued and assessed, that should be included with the TFRP assessment as a TR (or CA if no agreement is present). Obtain the IMF assessed and accrued interest amounts from the IMF MFTRA for the appropriate officer’s TFRP assessment (see paragraph above) related to the module. Note: A recomputation to the interest cutoff date may be required; normally COMPA or INTST will be used by Unpaid Assessments Accounting Analysis analyst to accomplish this. Multiply these amounts by the percentage calculated above, obtaining the amount of assessed and accrued penalty and interest that should be retained as a TR (or CA if no agreement is present). Next, add the resulting amounts to the unpaid TFRP for the module.

4. This total is the amount of the TFRP to be categorized as TR (or CA if no agreement is present). The difference between the total module balance for the BMF and the TFRP assessment, including the assessed and accrued penalty and interest, is the amount to be recategorized as WO. The remaining BMF total module balance will be recategorized as WO when the business has been defunct or bankrupt for two or more years and the possibility of any collections are small. The TFRP assessment amount will not be recategorized as a WO in such cases if the possibility exists that the IRS might collect some amount from the officers.

5. The Custodial Detail Database (CDDB) is now categorizing qualifying TFRP cases. In this process, CDDB analyzes BMF TFRP cases and related MFT 55 cases. The process evaluates these TFRP-related modules and based on coding criteria, a systemic analysis for the categorization, duplication and allocation of the modules is performed. This is updated weekly so the huge inventory adjustments calculated via the TFRP allocation worksheets at the time of the financial statement estimation process are greatly reduced. When the module has been categorized by CDDB, the Unpaid Assessments Accounting Analysis staff will complete a CDDB worksheet to verify the results of the CDDB analysis for split categorization modules. This worksheet as well as ARDI transcripts for the module and all related modules will be part of the file. After the Unpaid Assessments Accounting Analysis analyst verification (worksheet etc.) is complete, the case is processed as any other TFRP case. However, no Allocation Worksheet is needed as CDDB has systemically accomplished this. See _Exhibit 1.34.4-3_, CDDB VCR Definitions.


**1.34.4.10** **(03-17-2023)**

### Collectibility Criteria for Taxes Receivable

1. Collectibility conclusions are documented on one of several different DCIs developed based on the circumstances and type of case. Cases determined to be TR are:



1. Systemically determined to be either partly or fully TR. If a case is determined to only be partly a TR, then a collectibility estimate will be prepared for the portion deemed to be TR.

2. Cases based on Unpaid Assessments Accounting Analysis analyst manual review(s) were determined to be either partly or fully TR.


If a case is only partly a TR the collectibility estimate will be prepared for the portion deemed to be TR. Collectibility estimates will not be prepared for portion that is other than TR.



2. In determining collectibility estimates, analyze the MFTRA, collection file, revenue officer’s notes (generally a print from the Inventory Control System (ICS)) and any other collection information available.

3. For collectibility determination, if an overpayment (credit) exists on an account that under normal circumstances would be refunded, instead the credit has or should offset manually or systemically into a balance due module, consider the offset as collection for collectibility purposes regardless of the transaction date assigned to the credit transaction.

4. For collectibility determination, if a refund transaction exists on an account prior to interim cycle cutoff date but a refund cancellation transaction is posted after the interim cutoff date, consider the cancellation as collection for collectibility purposes.

5. There are specific DCIs to document the collectibility analysis, tailored to the specific type of case. Below is a listing of the DCIs used for collectibility analyses. There are eight collectibility DCIs:



   - Long Term Payment Arrangement (e.g. IA, FPLP, Wage Levy, etc.).

   - Bankruptcy.

   - Estate Installment Agreement.

   - Offer In Compromise.

   - Collection Field Function (Revenue Officer Assigned).

   - Litigation.

   - General Information DCI is used for general conditions involving STAUPs, TC 470s, etc. Allows for formal means to obtain written explanations for the Campuses/Areas.

   - Collection Summary DCI is used to further explain or modify figures on the Bankruptcy, OIC, Litigation, and Collection Field Function DCIs, and to explain the collectibility analysis on cases where no collection information is available (notice status, queue, tolerance, etc.).


6. A statement about DCI responses from the field personnel. Responses from the field personnel (Bankruptcy, Revenue Officer (RO), OIC, etc.) will be considered when determining collectibility estimate, but their judgment may be different than the Unpaid Assessments Accounting Analysis analysts, thus the Unpaid Assessments Accounting Analysis analysts collectibility estimate might not be the same as the IRS field personnel tend to be more conservative and use other factors in estimating collectibility such as compliance history, incomplete administrative actions, etc. The basis or reasons for determining collectibility should be thoroughly documented on the Collectibility DCI in the financial statement estimation process case file.

7. Detailed amounts to be collected on unpaid payroll tax cases will require completing the appropriate collectibility DCI for the business and/or for any officers assessed TFRPs. The criteria for determining overall collectibility are included later in this section. If the BMF module is correctly categorized as TR, analyze collectibility based on all officers’ accounts combined, as well as the business. That is, each individual officer and the business may contribute to the collectibility. If a corporation has only one officer and is in an installment plan, use the date of birth, see IRM 1.34.4.10.1(2) of the officer to compute collectibility should that one officer dies and the BMF goes out of business. The trust fund taxes can be collected only once, although the interest can be collected from each officer separately. An accepted OIC or OIC-related abatement for one officer will not relieve the other officers of their liability. Separate Collection Summary DCIs for each officer and/or BMF are only required if there is collectibility occurring that may affect the module. Comments for all related cases will be summarized on the controlling DCI of the module (which can be either a BMF module or an IMF MFT 55/618 module).

8. After reviewing the case, determine which collectibility DCI applies. The following guidance is intended to assist in completing and/or reviewing the DCIs.


**1.34.4.10.1** **(09-07-2018)**

#### Long Term Payment Arrangement Data Collection Instrument

1. The Long Term Payment Arrangement DCI is used to calculate collectibility estimates for IA, FPLP and continuous wage levies. The DCI will indicate at the top which type of payment arrangement it is related to.

2. For certain types of Long Term Payment Arrangements, collectibility should be limited. Based on actuarial tables showing life expectancies, collectibility should not be calculated for the entire length of time until the CSED expiration if the taxpayer’s age at the time of review exceeds life expectancy based on actuarial tables. In such cases, the estimate of collectibility is limited to the earlier of three years or the CSED expiration date.

3. The CASTS system is the approved system used to calculate the IA/long-term payment collectibility estimate. The programming calculation was designed as a tool to estimate collectibility for modules in IA, continuous levy status or other long-term payment situation. It calculates monthly payments based on the interim cutoff day of each month rather than the actual payment date. Thus, there are times when the long-term/installment agreement calculation in CASTS might calculate one less payment or one more payment depending on the CSEDs and when the taxpayer is making payments. This is an acceptable collectibility calculation. There may be situations where a manual calculation and/or explanation are needed.


**1.34.4.10.1.1** **(09-07-2018)**

##### Installment Agreement

1. The IRC allows taxpayers to pay their tax assessments in installments if they are unable to submit full payment at the time the return is filed. The following steps will assist in estimating what portion, if any, of the module's balance is collectible under an IA along with refund offsets and other payments.

2. The collectibility estimates will be based largely on the analysis of the MFTRA (including updated MFTRA), and the IA of the IADIS print screen if a copy of the IA is unavailable. The MFTRA will show the status of the IA. An active IA is evidence by a status Code 60 as the latest status code posted to the MFTRA. The transcript will also show the frequency and dollar amount of payment the IA or the IADIS print screen will document terms, such as the total amount of the agreement, tax type and tax periods covered by the agreement, payment amounts, and payment due cycles.


**1.34.4.10.1.2** **(09-07-2018)**

##### Determining if the Taxpayer is Current with Installment Agreement Terms

1. Installment agreement scheduled payments must be current to be included in the analysis of future collectibility. A taxpayer is considered current if the MFTRA shows the required payments have been submitted for the latest three consecutive months. (The user fee can be counted as the first payment even if the entire payment amount went to user fees). If the taxpayer made irregular payments, if the total of the last three months is equivalent to what three equal payments would be, would project collectibility. Other factors may be considered in determining collectibility based on an IA. For instance, if a taxpayer made less than three payments on an IA, collectibility would need to be strongly justified by a good filing/paying history. If the IA module does not meet these criteria, the collectibility of the module must be recomputed based only on refund offsets and subsequent payments. It should not include projected installment payments.


**1.34.4.10.1.3** **(09-07-2018)**

##### Other Long Term Payment Arrangements

1. In addition to IA, the IRS may also collect regular monthly payments from the taxpayer though the FPLP or through continuous wage levies. The IRS notifies the taxpayer of the intent to levy prior to activating the FPLP or the continuous wage levy. If the MFTRA shows that the taxpayer has allowed the levy to remain in effect for more than three months, it can be assumed that the pattern of monthly payments will continue. In such cases, the collectibility will be determined in the same manner as IA.

2. In general, there is no written or verbal agreement from the taxpayer when a levy is involved, nor is there an IRS system such as IADIS that details the terms of these arrangements. However, certain continuous wage levies may be requested by the taxpayer and set up as IA and may be reflected on IADIS. In that case, there will be a Status 60 posted to the MFTRA and the Unpaid Assessments Accounting Analysis analyst will complete the DCI as a normal Installment Agreement.

3. In the absence of an IADIS screen print, the amount of the future expected payments can be determined by examining the history of payments received thus far. Payments received through the FPLP are most often the result of an IRS levy on Social Security benefits. Thus, there is a pattern of regular monthly payments that can be used to estimate future collectibility amounts. Although Social Security benefits are adjusted annually, the Unpaid Assessments Accounting Analysis analyst will calculate the collectibility using the monthly payment amount currently being collected at the time of review.


**1.34.4.10.1.4** **(09-07-2018)**

##### Analysis of Collectibility for Installment Agreements and/or other Long Term Payment Arrangements

1. The Long Term Payment Arrangement DCI is used to schedule out the balances of all delinquent tax periods for the number of months remaining to apply payments and years remaining to apply refund offsets to each module before the collection period (CSED) ends or the three-year age limitation is met to determine collectibility. The IRS applies payments to the module with the oldest CSED until the tax, penalty and interest are paid. The IRS then applies payments to other modules in CSED order. If the frequency of required installment payments is not clear on the IADIS print screen it may be inferred from the dates payments are received, as shown on the MFTRA.

2. The Long Term Payment Arrangement DCI contains a section where the Unpaid Assessments Accounting Analysis analyst lists all delinquent periods related to the module. The balance owed on the module will be as of the date the interim cutoff was selected. All other delinquent balances will be as of the date the MFTRA transcripts were produced. In the event there is more than one module for the same taxpayer, a DCI will be prepared for each of the modules. The balance due section will include the module balance as of the date the interim cutoff was selected. However, when that same module is listed on the related DCIs, its balance will be as of the date the transcripts were produced.

3. Determine the amount of refund offsets, for as much as three years, which could be used to reduce balances of outstanding tax modules. Review the complete master file transcript to determine if any recent refund offsets (which includes both federal refund offsets (TC 706) and state levy payments (TC 670, designated payment code 20) have been applied to the taxpayer’s delinquent module(s). There must be three consecutive refunds received in the past three years. However, the three-year pattern has been met if three consecutive year’s refunds have been filed by the taxpayer and the refunds have been offset in at least the most recent two years. This exception only applies in cases where the taxpayer did not have a tax liability to offset against at the time they filed for the first of the three refunds or only if it’s the third year that the refund was filed, and the offset has yet to occur. If it’s the first or second year, it is not sufficient evidence that the IRS will offset all refunds against the outstanding tax debt.

4. Monthly recurring payments apply monthly payments to each tax period, in CSED order, until each period is paid or the CSED for the period expires. This is done by combining the installment payments and refund offsets to determine if the module will be paid. Up to three years of refund offsets, or less if the CSED expires in less than three years, will be added and then the installment payments will be applied.

5. Review the module for subsequent payments and determine if the MFTRA shows there were other payments made to the module after the interim cutoff pull date that reduced the module balance. If the prior analyses resulted in zero collectibility for the module, collectibility will be solely based on the total of these subsequent payments. If the prior analyses showed the module was partly collectible, the subsequent payments may add to the collectibility of the module (TCs 670, 706 and 700). Generally, there will be no subsequent payments for this type of case. An example would be if the taxpayer makes a single lump sum payment in addition to all regular monthly payments. Include TC 706 refund offsets if posted after sample cut-off, even if included in refund offset calculation as this calculates future years and not the current year.


**1.34.4.10.2** **(09-07-2018)**

#### Bankruptcy Review Data Collection Instrument

1. This DCI is designed to gather information from the field to assist with the estimate of the amount collectible for cases where taxpayers are protected under bankruptcy proceedings. Bankruptcies fall into the following five categories:



   - Chapter 7, Liquidation.

   - Chapter 9, Adjustment of Debts of a Municipality.

   - Chapter 11, Reorganization of large business.

   - Chapter 12, Adjustment of Debts of a Family Farmer.

   - Chapter 13, Adjustment of Debts of an Individual.


2. The following information should be included in the IRS bankruptcy file depending on the type of bankruptcy case. Each of these is a separate form, which may or may not be included in the case file depending on the type of bankruptcy case.



1. **Proof of Claim -**A proof of claim is a written statement setting forth a creditor's claim. The IRS should list all amounts due to the IRS on the proof of claim. These amounts may vary from the amounts listed on the taxpayer’s petition. The Bankruptcy Court stamps the Proof of Claim to acknowledge receipt of the IRS Proof of Claim. The court does not, however, acknowledge that it is allowing the Proof of Claim. The court will only notify the IRS if the debtor or another creditor petitions the claim. The Unpaid Assessments Accounting Analysis analyst will secure Proof of Claim prints from the AIS-4 system when possible and secure copies through Centralized Case Processing (CCP) when they are not available on AIS-4.

2. **Reorganization Plan Approved by the Court -**The reorganization plan, for Chapter 9, 11, 12 and 13 Bankruptcy cases, provides a detailed payment plan for all creditors of the bankruptcy estate. The plan should describe the payment terms and the source of payment for the IRS and other creditors.


**1.34.4.10.2.1** **(09-07-2018)**

##### Chapter 7 Liquidations

1. If Proof of Claim is included in the bankruptcy case file, use the information contained in them, along with all other applicable facts of the case to perform the collectibility analysis. Take into consideration available assets, if any, and encumbrances, other priority secured claims that will supersede the IRS proof of claim, other balance due periods which will receive proceeds before the module, etc.

2. If the assumption is that the taxpayer will proceed with Chapter 7 bankruptcy proceedings, it is likely that the IRS will receive some payment from the estate. The amount to be received would depend on whether the IRS’s claims are secured and the value of and encumbrances on the property included in the bankruptcy estate.


**1.34.4.10.2.2** **(09-07-2018)**

##### Chapter 9, 11, 12 and 13 Reorganization

1. If the approved reorganization plan is provided, use information from Question 2 of the Bankruptcy Review DCI to estimate the amount collectible. If the reorganization plan has not been approved or cannot be secured, use the subsequent payment analysis on the Collection Summary DCI to enter the collectibility analysis and estimate.


**1.34.4.10.2.3** **(09-07-2018)**

##### Determining Payments Received

1. Review the MFTRA to identify payments that may have been received on a bankruptcy estate case. Include all payments (with or without a designated payment code). Unpaid Assessments Accounting Analysis Analyst will review all documentation for court orders regarding application of payments. Apply all payments according to the guidance of the court order.


**1.34.4.10.2.4** **(09-07-2018)**

##### Other File Documentation

1. Other documentation may be secured to help in assessing the ability of the taxpayer to pay or the IRS’s ability to collect in a bankruptcy case. It is very important to obtain as much documentation related to Bankruptcy cases as possible. For example, although payments may not yet be due for the case, a pending, or accepted Proof of Claim may indicate that payments could be made on the tax liability. The Unpaid Assessments Accounting Analysis analyst will secure bankruptcy case history from the AIS-4 system when possible.


**1.34.4.10.2.5** **(09-07-2018)**

##### Assessing Bankruptcy Discharge

1. Depending on the type of bankruptcy, assess the effect of the potential or actual discharge of the case on collectibility. Use information from Question 4 in the Bankruptcy Review document to assess the effect of bankruptcy discharge on collectibility.


**1.34.4.10.2.6** **(09-07-2018)**

##### Alternative Method for Determining Collectibility

1. In some cases, the reorganization plan will indicate that a specific percentage of the sales proceeds from a block of assets will be paid to the IRS, as opposed to indicating that an exact amount will be paid to the IRS. In such cases, review documentation that supports the value and related assets to be sold, before estimating future collections. Apply this percentage from the court order to be given to the IRS to factor to the assets, net of encumbrances and any administrative expenses, to determine the amount for collectibility.

2. The Unpaid Assessments Accounting Analysis analyst will review the Bankruptcy Review DCI prepared by the IRS insolvency staff to estimate the amount collectible and the portion applicable to the module. For collectibility analysis, focus on the special procedures notes, bankruptcy documents and related schedules, if available, and supporting documentation. The results of this analysis will be presented in a Collection Summary DCI. This DCI will contain a list of the modules owed by the taxpayer, refund offset information (IMF Only), subsequent payments made to the module after the interim cutoff pull date, and a final collectibility determination with substantiating remarks. In general, on bankruptcy cases, until a plan is confirmed will not consider the amount as collectible unless there is other sufficient evidence to support Unpaid Assessments Accounting Analysis analyst’s determination. The basis of collectibility determination should be thoroughly documented on the Collectibility DCI in the financial statement estimation process case file.


**1.34.4.10.3** **(03-17-2023)**

#### Estate Installment Agreement Data Collection Instrument

1. Under an estate IA, the executor may elect to pay the tax assessment through annual installments over a 15-year period if the estate qualifies under Section 6166 of the IRC. This 15-year period involves a 5-year deferral followed by a 10-year installment period for payment of the taxes. During the 5-year deferral period, only the interest on the estate’s tax must be paid annually. For the final ten years, the estate must pay principal and interest in its installments. Based on prior year audits estate cases have a high collection rate. The taxpayer may also elect to pay over a shorter amount of time. Review the election request attached to the Form 706 return to determine the details. Modules with an approved election will be in master file status 14.

2. The Estate Installment Agreement DCI contains a few questions. Historical observations show that if the module stays in status 14, the full balance due will eventually be collected. Comments and any anomalies can be explained in the Justification section. If the estate is not in Status 14, this DCI should not be used.

3. There are two sections to the estate installment agreement DCI. The first section relates to payment information on the estate case. The second section deals with collectibility based on appraised value of the estate plus payments made to the tax module.


**1.34.4.10.3.1** **(09-07-2018)**

##### Section I: Payment Information on Estate Cases

1. In this section, consider the estate case to be 100% collectible if the estates have submitted the interest and/or principal payment in accordance with the terms of the estate installment agreement. With estate IA there is usually a payment made with the estate tax return and installment payments that follow in accordance with the agreement. If the estate agreement is too recent for an installment payment to have been submitted, consider the estate case to be 100% collectible if a payment was submitted with the estate tax return.


**1.34.4.10.3.2** **(03-17-2023)**

##### Section II: Estate Cases not in Compliance with Agreement

1. If the estate has not submitted payments in accordance with the terms of the installment agreement, or if the estate is no longer in Status 14, complete the “Other Collectibility” DCI. In those cases, collectibility will be based on the Revenue Officer’s synopsis which may include a basis for collectability, unique facts about the case (i.e., the taxpayer involved in illegal activity) and evidence of any other available assets. collectibility will be based on the value of estate property. Where the estate value is zero or less, collectibility will be limited to payments, refund offsets and credits (TCs 670, 706 and 700) posted from the date after the interim cutoff pull date to the time of review.


**1.34.4.10.3.3** **(09-07-2018)**

##### Comment Section

1. The comment section should be used to record additional comments that would be helpful in explaining the basis for collectibility decision. To assist the reviewers, detailed information in this section should explain how the collectible amount was derived. Information in the comments may include:



   - Basis for the collectible amount number.

   - Unique fact about the case (i.e., the taxpayer involved in illegal activity).

   - Evidence of any other available assets.


**1.34.4.10.3.4** **(09-07-2018)**

##### Collectibility of Estate Cases with Section 6161 Election - Extension of Time to Pay

1. Some estates will file a Form 4768, Application for Extension of Time to File or Pay U.S. Estate Tax Return, for an extension of time to file and/or extension of time to pay. IRC section [6161(a)(1)](http://irm.web.irs.gov/common/scripts/ExitScriptLexisNexis.asp?GOTO=https://advance.lexis.com/api/search?source=MTA4MDE1OA%26q=IRC+6501) permits an extension of time to pay tax shown on the return or required to be shown for a reasonable period not to exceed twelve months in the case of estate tax from the date the payment is due. Extensions may be granted for one year at a time up to ten years.

2. An approved extension posts with a TC 468 and with a date that is one year from the original due date of the return. There may be more than one TC 468 as the requests can be approved for only one year at a time. Each succeeding TC 468 will have a date that is one year later than the previous one.

3. An extension request should contain a written reasonable cause statement explaining in detail why it is impossible or impractical to pay the full amount of tax by the due date. The Cincinnati Campus Estate & Gift Unit will determine the validity of the explanation and will grant or deny the request.

4. Examples of reasonable cause include the following:



   - An estate includes sufficient liquid assets to pay estate (and Generation-Skipping Transfer Tax (GST)) tax when otherwise due. The liquid assets are in several jurisdictions and are not immediately subject to the control of the executor. Such assets cannot readily be collected by the executor even with reasonable effort.

   - An estate is comprised, in substantial part, of assets consisting of rights to receive payments in the future (for example, annuities, copyright royalties, contingent fees or accounts receivable). These assets provide insufficient present cash with which to pay the estate and GST when otherwise due and the estate cannot borrow against these assets except upon terms that would cause a loss to the estate.

   - An estate includes a claim to substantial assets which cannot be collected without litigation. Consequently, the size of the gross estate is unascertainable at the time the tax is otherwise due.

   - An estate does not have sufficient funds (without borrowing at a rate of interest higher than that generally available) with which to pay the entire estate (and GST) tax when otherwise due, to provide a reasonable allowance during the remaining period of administration of the estate for the decedent’s surviving spouse and dependent children and to satisfy claims against the estate that are due and payable. In addition, the executor has made a reasonable effort to convert assets in the executor’s possession (other than an interest in a closely held business to which IRC section [6166](http://irm.web.irs.gov/common/scripts/ExitScriptLexisNexis.asp?GOTO=https://advance.lexis.com/api/search?source=MTA4MDE1OA%26q=IRC+6166) applies) into cash.


5. Because the estate has an agreement with the IRS that payment is not due at the original filing date the payments are not always an indicator for collectibility. If the module stays in status 14, there is a high likelihood that the full balance due will eventually be collected. Project full collectibility on these cases. More information is available in IRM 4.25.2, Campus Procedures for Estate Tax.


**1.34.4.10.4** **(09-07-2018)**

#### Offer in Compromise Data Collection Instrument

1. This DCI is designed to estimate the amount collectible for OIC cases. In accordance with the Internal Revenue Code, taxpayers may submit an offer in settlement of a tax debt for an amount less than that originally assessed. The settlement offer is generally referred to as an offer in compromise and is generally accepted when it is determined that the offer allows the IRS to receive revenue which it would not otherwise receive.

2. The Tax Increase Prevention and Reconciliation Act of 2005 (TIPRA) made major changes to the OIC program, tightening the rules for lump-sum offers and periodic-payment offers. When submitting Form [656,](https://www.irs.gov/pub/irs-pdf/f656.pdf) taxpayers must include an application fee, unless they qualify for the low-income exemption or are filing a doubt as to liability offer. The OIC application fee reduces the assessed tax or other amounts due. A taxpayer may not specify how to apply the application fee.

3. Under this law, taxpayers submitting requests for lump-sum OICs must include a payment equal to 20% of the offer amount. The payment is nonrefundable. It will not be returned if the OIC request is later rejected. A lump-sum OIC means any offer of payments made in five or fewer installments.

4. Taxpayers submitting requests for periodic-payment OICs must include the first proposed installment payment with their application. A periodic payment OIC is any offer of payments made in six or more installments. The taxpayer is required to pay additional installments while the offer is being evaluated by the IRS. All installment payments are nonrefundable. The IRS will credit the taxpayer’s account(s) with any payment(s) submitted with the original offer, as well as any payments that were made during offer investigation. Taxpayers must specify in writing when submitting their offers how to apply the payments to the tax, penalty and interest due. Otherwise, the IRS will apply the payments in the best interest of the government (IRC section [7122(c)(2)(A)](http://irm.web.irs.gov/common/scripts/ExitScriptLexisNexis.asp?GOTO=https://advance.lexis.com/api/search?source=MTA4MDE1OA%26q=IRC+6166)).

5. Taxpayers qualifying as low-income or filing an offer based solely on doubt to liability qualify for a waiver of the 20% payment on a lump sum offer or the required payments on a short term or deferred periodic payment offer.


**1.34.4.10.4.1** **(09-07-2018)**

##### Documentation

1. For financial categorization purposes, the Unpaid Assessments Accounting Analysis analysts’ staff will attempt to secure only the signed Form [656](https://www.irs.gov/pub/irs-pdf/f656.pdf) on offer cases. If the entire case file is needed for another purpose, such as the analyst's inability to match a TFRP calculation, only then will an attempt be made to secure the entire offer file. For collectibility purposes, an AOIC print should be in the case file.

2. The OIC DCI should be used to estimate the amount collectible from the offer and the amount applicable to the module. This DCI should be completed for accepted and pending offers only. Pending offers submitted on Form [656,](https://www.irs.gov/pub/irs-pdf/f656.pdf) Offer in Compromise, are offers that have been signed by the taxpayer and accepted by the IRS for review. However, the IRS has not decided to accept or reject the taxpayer's offer at the time the Form [656](https://www.irs.gov/pub/irs-pdf/f656.pdf) is signed. Both pending and accepted offers in compromise are identified on the MFTRA by the TC 480. An accepted OIC will have a subsequent TC 780 posted to the module to indicate that the IRS has accepted the offer. OIC typically has conditions attached. When all the conditions of an offer have been completed (the IRS OIC acceptance documentation should show the conditions) a TC 788 is posted to the module, meaning the IRS has accepted the offer and the taxpayer has fulfilled the conditions.

3. For collectibility analysis, focus on the payment of the offer amount or any evidence that indicates that the offer is no longer being evaluated and/or has been either rejected (TC 481), withdrawn (TC 482) or cancelled (TC 483). A TC 481, TC 482 or TC 483 should be recorded in the MFTRA as evidence that the investigation has been completed. Because the UA interim cutoff items were pulled at an interim period, the status of the offer may no longer be pending by the time the case file is reviewed. If the offer has been rejected, withdrawn, or cancelled; complete the Collection Summary DCI.

4. Evaluation of Collectibility for OIC cases will fall into three general categories.

5. When reviewing the offer documentation, first review Form [656](https://www.irs.gov/pub/irs-pdf/f656.pdf), and determine if the IRS has accepted the offer for investigation. Acceptance will be indicated by a check in the acceptance box on the OIC Form [656](https://www.irs.gov/pub/irs-pdf/f656.pdf) and an IRS official must sign the form. Next, determine if the offer itself has been accepted/approved by the IRS as evidenced by the completed and signed Form 7249 or other formal correspondence to the taxpayer, indicating acceptance of the offer. Also review the MFTRA for evidence of receipt of payments in compliance with the terms of the offer acceptance.

6. Payments are generally posted to the tax period with the oldest CSED first. It is necessary to review modules for tax periods covered by the offer with CSEDs preceding the module to determine whether after the offer amount is applied to those modules any portion of the offer is still available to pay down the module. Offer payments are generally noted by a TC 670 DPC 09 on the MFTRA.

7. The subsequent payment analysis should be used if the OIC itself cannot be relied on to resolve the outstanding liabilities.

8. For collectibility analysis, focus on the offer examiner notes, financial statements provided by the taxpayer, if available and supporting documentation. The results of this analysis will be presented in a Collection Summary DCI. This DCI will contain a list of the modules owed by the taxpayer, refunds offset information (IMF Only), subsequent payments made to the module after the interim cutoff pull date and a final collectibility determination with substantiating remarks.


**1.34.4.10.4.2** **(09-07-2018)**

##### Offer has been Accepted

1. If payments are current the OIC amount should be used as the amount collectible.

2. If payments are not yet due but the case file has strong (particularly third-party) evidence (such as the reviewed and approved Form 433, Collection Information Statement) demonstrating that payments are very probable, the OIC amount should be used as the amount collectible. This is an acceptable and reasonable approach because offer approval implies that the IRS determined what can be collected based on subjecting the offer to a stringent analysis of the taxpayer’s assets, liabilities, future income projections and any other applicable factors.

3. If payments are due but have not been submitted as agreed, the case should be treated as a field collection/other case and evaluated upon concrete collection action being taken against the taxpayer. Without other collection evidence, collectibility of these cases should be zero.


**1.34.4.10.4.3** **(09-07-2018)**

##### Offer is Still Pending

1. If the offer is pending, determination of collectibility will take a conservative approach. The key consideration in determining whether an estimate can be made is whether, 1) the supporting documentation clearly shows the amount being voluntarily offered by the taxpayer is supported by known assets as shown in the taxpayer’s financial statements or in the Worksheet to Calculate an Offer Amount Using Forms [433-A](https://www.irs.gov/pub/irs-pdf/f433a.pdf), Collection Information Statement, for Wage Earners and Self Employed Individuals and/or Form [433-B](https://www.irs.gov/pub/irs-pdf/f433b.pdf), Collection Information Statement for Business, completed by the taxpayer or 2) the IRS has taken concrete steps to collect on these assets or has other documentation (such as third-party verification or court supervision) that provides clear and compelling evidence that the IRS will tap these potential sources (such as a signed statement from field staff knowledgeable about the case stating that the IRS expects to accept the offer). In the absence of this kind of detailed documentation (and absent actual payments by the taxpayer or the IRS offsets) the collectibility estimate will generally be zero.



   - If the case file indicates the taxpayer’s submitted offer will be accepted and is supported by third-party evidence in the case file (such as the reviewed and approved Form 433, Collection Information Statement, proof of the funds that will be paid, etc.) demonstrating that payments are very probable, the OIC amount should be used as the amount collectible.

   - If the case file indicates the offer will be rejected because the IRS has determined that the taxpayer can pay more than their offer, determination of collectibility will be based upon the strength of evidence in the file indicating taxpayer ability to pay and the IRS’s willingness to take collection action. If both are present, the OIC amount generally can be used as the amount collectible.

   - If the case file indicates the offer will be rejected for other reasons, the case should be treated as a field collection/other case and evaluated upon concrete collection action being taken against the taxpayer.


**1.34.4.10.4.4** **(09-07-2018)**

##### Offer has been Withdrawn or Rejected

1. In these cases, the case should be treated as a field collection/other case and evaluated upon concrete collection action being taken against the taxpayer. Without other evidence, collectibility of these cases should be zero.

2. There are two primary sections to the OIC DCI. In Section 1, the IRS offer examiner will determine how they believe the case will be resolved based on the point of the investigation and the plan of action they have established working with the taxpayer. Section 2 contains requests for documentation that should provide the basis for the taxpayer’s ability to provide the funds to support the offer and potentially will provide support for Unpaid Assessments Accounting Analysis analysts determination of a collectibility amount; Part 1 of this Section pertains to sources not originating from the taxpayer. In certain instances, relatives or others are willing to provide the taxpayer with the funds necessary to pay the offer with no requirement to repay them. Part 2 is the amount collectible from the taxpayer’s assets and sources of income (in most offers, the minimum amount the IRS accepts on an OIC is the amount of equity the taxpayer has in all assets) and the amount collectible from levy sources if the Service were to proceed with enforcement action. This will generally be supported by the information provided by the taxpayer on Form 433, Collection Information Statement. Additionally, in this Section of the DCI there is a request to provide explanation and support of any special circumstances as to the application of funds.

3. The taxpayer is required to identify on Form [656](https://www.irs.gov/pub/irs-pdf/f656.pdf), Offer In Compromise, the tax type and period the offer is for as well as how it will be paid, (i.e., whether within 90 days, two years or the remaining CSED period). A taxpayer may designate TIPRA offer payments (pre-acceptance) to a specific liability including trust fund. Once the offer has been accepted (or if the offer was pre-TIPRA), payments are applied in the government’s best interest. Per the IRS guidelines contained in IRM 5.8 Offer in Compromise, payments are posted to the modules with the earliest CSEDs first. Payments are applied in the following order—tax, penalty and interest. If the taxpayer defaults on an accepted agreement, either a formal letter and/or Form 7249, Offer Acceptance Report, the IRS reinstates the unpaid balance of the original tax liability for the appropriate tax module and files an applicable federal tax lien. In this case, determine how the defaulted OIC impacts the collectibility of the outstanding tax liability for the module.


**1.34.4.10.4.5** **(09-07-2018)**

##### Collection Field Function Data Collection Instrument

1. The Collection Field Function (CFf) DCI is sent to field personnel to gather information for cases that show a field collection status indicating that they’ve been assigned to a revenue officer in the field. Revenue officer assigned cases are identified in the status section on the MFTRA by the Collection Status Code 26. These cases are generally cases in process and there may not actually have been any money collected as of the date of the investigation. The DCI response from the field should reflect the revenue officer’s plan of action to resolve the case working with the taxpayer.

2. Modules in Status Code 26 with TSIGN 8000 are not field collection. Therefore, there will be no CFf DCI for these cases. Since there is no active collection on these cases, the Unpaid Assessments Accounting Analysis analyst would use the Collection Summary DCI to estimate collectibility, if applicable.

3. There are four primary questions on the CFf DCI. In Question one and two, the IRS revenue officer will outline how they believe the case will be resolved based on the point of the investigation and the plan of action they have established working with the taxpayer. Question three requests that the revenue officer provide support for funds collectible from the taxpayer’s assets and sources of income, and the amount collectible from levy sources if the IRS were to proceed with enforcement action. Information included in this section should provide the basis for Unpaid Assessments Accounting Analysis analyst determination of collectibility. This will generally be supported by the information provided by the taxpayer on Form 433, Collection Information Statement. Question four will provide explanation and support of any special circumstances as to the application of funds.

4. The Unpaid Assessments Accounting Analysis analyst will review the CFf DCI prepared by the IRS field staff to estimate the amount collectible and the portion applicable to the module. The Analyst's conclusion will not necessarily be the same as the field. When the conclusion of the analyst differs, the basis for the discrepancy will be included in the Collection Summary DCI narrative. The reviewer can make a determination whether it is necessary to secure the field’s case file, rather than rely on the DCI and the ICS history. If the file is secured, the collectibility analysis will focus on the revenue officer notes, financial statements provided by the taxpayer, if available, and supporting documentation. And, as always the key consideration in determining whether an estimate can be made, in the absence of payments by the taxpayer or the IRS refund offsets is whether the IRS has taken concrete steps to collect on taxpayers assets or has other documented evidence (such as third-party verification or court supervision) that provides clear and compelling evidence that the IRS will tap the taxpayer’s potential income/asset sources. The results of this analysis will be presented on the Collection Summary DCI (described below). The Collection Summary DCI will contain a list of the modules owed by the taxpayer and the CSED for each module, refund offset information (IMF only), subsequent payments made to the module after the interim cut-off pull date and a final collectibility determination with substantiating remarks.


**1.34.4.10.4.6** **(09-07-2018)**

##### Litigation Case Data Collection Instrument

1. The Litigation Case DCI is sent to field personnel to gather information for cases that show a status indicating that they are currently being litigated. Litigation cases are identified on the MFTRA by a TC 520 and one of the litigation closing codes. (Closing codes can be found in the Document 6209). This DCI is designed to estimate the amount collectible for cases in litigation status. Generally, these cases involve court actions and there may not actually have been any funds collected as of the date of the investigation. This DCI is designed to capture the court documents and plan of action to resolve the case working with the taxpayer and/or courts.

2. The Unpaid Assessments Accounting Analysis analyst will review the Litigation Cases DCI prepared by the IRS field staff to estimate the amount collectible and the portion applicable to the module. The Unpaid Assessments Accounting Analysis analyst’s conclusion will not necessarily be the same as the field. For collectibility analysis, focus on the special procedures’ notes, financial statements provided by the taxpayer, if available and supporting documentation. The results of this analysis will be presented on the Collection Summary DCI (described below). The Collection Summary DCI will contain a list of the modules owed by the taxpayer and the CSED for each module, refund offset information (IMF only), subsequent payments made to the module after the interim cut-off pull date and a final collectibility determination with substantiating remarks.

3. The critical consideration in determining whether an estimate can be made, in the absence of payments by the taxpayer or the IRS refund offsets is whether there is a settlement agreement approved by the courts, the IRS has taken concrete steps to collect on taxpayer’s assets or has other documented evidence (such as third-party verification or court supervision) that provides clear and compelling evidence that the IRS will tap the taxpayer’s potential income/asset sources.

4. Settlement agreements and court orders not only determine the total amount of funds to be received but also may specify the application of payments for the entities and modules involved. The IRS will deviate from the usual “oldest CSED” payment application of funds in these cases.


**1.34.4.10.4.7** **(09-07-2018)**

##### Collection Summary Data Collection Instrument

1. There are two purposes for this DCI.



1. It is used in conjunction with the field DCIs (Bankruptcy, CFf, OIC and Litigation) to summarize the collection information received from the Revenue Officers. The Unpaid Assessments Accounting Analysis analyst will sometimes reach a different conclusion than the Revenue Officer, regarding the amount deemed to be collectible and will explain their reasons for the modification on the Collection Summary DCI.

2. Some TR modules cannot be analyzed using the DCIs previously discussed above. This DCI is used for those cases which were full paid after the interim cut-off pull date, and other types of cases such as modules in notice, tolerance, CNC, Queue, Taxpayer Delinquent Account (TDA), Automated Collection System Taxpayer Delinquent Account (ACS TDA) and other statuses where limited documentation exists or when only MFTRA are available. In assessing collectibility, the analysis should consider whether the taxpayer is current in filing, has an established pattern of paying prior delinquent tax periods and/or the only delinquent module is the module. Collectibility will be based in whole or in part on patterns of refund offsets (outlined previously under the Long Term Payment Arrangement DCI section), subsequent payments (including from notice of levy) and an evaluation of the taxpayer’s overall compliance posture based on an analysis of the prior payment and filing history and current compliance level of the taxpayer.


2. There are four parts to this DCI.



1. Part one contains a section where all delinquent periods related to the module are listed. The balance owed on the module will be as of the interim cut-off date the module was selected and should match the control sheet. All other balances will be as of the date the transcripts were produced. In the event there is more than one module for the same taxpayer, a DCI will be prepared for each of the modules. The balance due section will include the module balance as of the interim cut-off date the module was selected. However, when that same module is listed on the related DCIs, its balance will be as of the date the transcripts were produced. To complete the chart, review the transcripts to determine how much is owed for each of the tax periods and list them by CSED order and then by tax period from the oldest to the most recent. The balance due amounts in this section should not be changed to reflect late posted payments, BVAs, etc. as those are handled automatically by CASTS. The non-module balances should match the MFTRA.

2. Part two relates to refund offsets. Refer to _IRM 1.34.4.10.1.4 Analysis of Collectibility for Installment Agreements and/or other Long Term Payment Arrangements_ section of this document which explains the refund offsets analysis.

3. Part three (Subsequent Payments Made To Module), review the MFTRA to determine if any subsequent payments were applied to the module after Cycle 20. Payments include all TC 670s (including state refund offsets), TC 706 (federal refund offsets) and TC 700 (credits applied from other tax periods). Do not include payments already included in any of the prior analyses as this would be double counting.

4. Part four of the DCI, Total to be Collected, is a summary of the results of the analyses previously performed. Information for this section will be pulled from parts two and three of the DCI and will also incorporate any amounts the Unpaid Assessments Accounting Analysis analyst deemed to be collectible based on the taxpayer’s financial information and compliance history.


**1.34.4.10.4.8** **(09-07-2018)**

##### Comment Section

1. The comment section should be used to record additional comments that would be helpful in explaining the basis for collectibility decision. To assist the reviewers, detailed information in this section should explain how the collectible amount was derived. Information in the comments may include:



   - Basis for the collectibility amount number.

   - If the taxpayer has a history of voluntary compliance (e.g., consistent payment of tax assessments, other modules paid in full, etc.).

   - Most recent return information and any available wage and income information.

   - Financial position of the taxpayer.

   - Unique facts about the case (i.e. the taxpayer involved in illegal activity).

   - Evidence of current wages or any other available assessment.

   - In cases where collectibility is based on refund offsets or stream of payments give a recap of the rationale for relying on this information in assessing collectibility (i.e., refund offsets received for the last three years).


Officer DCIs – When there are no payments or refund offsets being received, do not have to do a separate DCI for the officer(s). Unpaid Assessments Accounting Analysis analyst must explain in the main narrative the basis of collectibility for each officer and for the corporation even if there is not a separate DCI.



**Exhibit 1.34.4-1**

### Book Value Adjustments

Some unpaid assessment cases upon review of the supporting documentation, turn out not be unpaid assessment. In other instances, only a portion of the book value balance (total module balance) will turn out to be a true unpaid assessment. To reduce or increase the book value to the correct financial statement estimation process value, the Unpaid Assessments Accounting Analysis analyst will make an adjustment to the Book Value. Certain situations may require a BVA. The following hypothetical situations serve as a general guide in determining when the Unpaid Assessments Accounting Analysis analyst should make BVA but is not intended to be all-inclusive. See _Exhibit 1.34.4-6_, Recognition of an Economic Event, regarding the recognition of when an economic event has occurred for accounting purposes.

Payments received before the interim cutoff, but posted after - BVA.

Refunds posted before the interim cutoff but canceled after interim cutoff – no BVA.

Misapplied payments received before the interim cutoff pull without proof of taxpayer direction:

1. The payment was applied as directed by the taxpayer - no BVA.

2. Both modules involved are in TR and both have debit balances - no BVA.

3. The module involved is in TR, but the other module involved is in a different categorization - BVA.


TC 706, not available until TC 706 posts - BVA

Mis-posted TC 538 and the TC 538 is posted to other than the module, or the TC 538 is posted in error to the module and the other module is in the same categorization - no BVA.

Return posted to an incorrect tax period and no payments are posted on the other module - no BVA.

An amended return or subsequent adjustment not posted as of the interim cutoff cycle - no BVA.

An assessment or abatement posted to the wrong module and the other module is in the same categorization, and the net effect is zero - no BVA.

An assessment is needed to correct identified error on the module, but the assessment won’t be made (e.g., ASED is expired, and assessment is barred, CSED is expired, or amount is under the IRS’s tolerance) - no BVA.

It appears an assessment or abatement is needed and proof positive does not exist; however, the case has extenuating circumstances and professional judgment deems assessment/abatement appropriate - BVA

User fee sweeps where payment was received before interim cutoff date and IA fee posts after - no BVA.

Additional guidance on actions taken regarding BVA’s or mis-categorizations regarding the completion of administrative actions and court rulings. A delay of a year or more with no extenuating circumstances could be viewed as unreasonable. The position Unpaid Assessments Accounting Analysis analyst will take on this matter the following scenarios will be used as guidance.

- When a taxpayer files an amended return which is processed within one year. No BVA or mis-categorization.

- A tax court decision in favor of the IRS with no further court action taken is TR. No BVA or mis-categorization.

- A tax court decision in favor of the IRS that is appealed by the taxpayer and the appellate court rules in favor of the IRS is TR. No BVA or mis-categorization.

- A tax court decision in favor of the IRS that is appealed by the taxpayer and the appellate court remands the case back to tax court for further review, but does not overturn the initial tax court decision is TR. No BVA or mis-categorization.

- A tax court decision in favor of the IRS that is appealed by the taxpayer and the higher appellate court overturns the lower tax court decision without sending the case back to the lower court for review, at the time the appeals court decision is made there would be no assets with the expectation the assessment will be abated. BVA or mis-categorization.

- A tax court decision in favor of the IRS that is appealed by the taxpayer and the appellate court overturns the court decision, sending the case back to the lower court for further review would warrant a mis-categorization to compliance. An appeal by the IRS would not impact the mis-categorization. BVA or mis-categorization.


A BVA or mis-categorization could be the entire assessment and applicable Penalty and Interest or create a split between Taxes Receivable and Memo or Compliance if the Appeals Court upholds a portion of the Tax Court decision in favor of the IRS.

**Exhibit 1.34.4-2**

### Payment Application on Trust Fund Penalty

To determine the application of payments for purposes of determining TFRP liability follow the guidelines below:

| **Category of Payments** | **Apply to** |
| :-- | :-: |
| Federal Tax Deposit (timely or late)\* | Non-Trust Fund Tax and Accrued Interest |
| Partial payment on or before due date | Non-Trust Fund Tax and Accrued Interest |
| Full payment of tax on or before date return is filed | Non-Trust Fund Tax and Accrued Interest |
| Partial payment after due date and before date of assessment | Non-Trust Fund Tax, Assessed Interest, Accrued Penalty & Accrued Interest |
| Partial payment on or after date of assessment | Non-Trust Fund Tax, Trust Fund Tax, Fees & Collection Costs, Assessed Penalty, Assessed Interest, Accrued Penalty and Accrued Interest |
| Involuntary Payment | Non-Trust Fund Tax, Trust Fund Tax, Fees & Collection Costs, Assessed Penalty, Assessed Interest, Accrued Penalty and Accrued Interest |
| Designated payment | Non-Trust Fund Tax, Trust Fund Tax, Fees & Collection Costs, Assessed Penalty, Assessed Interest, Accrued Penalty and Accrued Interest |

Effective January 1, 2003, all new undesignated payments will be applied under the new calculation method. Do not recalculate account that were assessed under the old method; this change only applies to new payments received on these accounts. There is no change to the application of any payments on these accounts applied prior to January 1, 2003.

For all TFRP liabilities where the Letter 1153 and Form 2751, Proposed Assessment of TFRP, were issued on or after June 19, 2000, any corporation payments received on the account after December 31, 2002, are applied in the following order:

1. Non-trust fund portion of tax (employer’s share of FICA).

2. Trust Fund portion of tax (withholding and employee’s share of FICA).

3. Assessed lien fees and collection costs.

4. Assessed penalty.

5. Assessed interest.

6. Accrued penalty to date of payment.

7. Accrued interest to date of payment.

8. Bankruptcy payments contact Insolvency.


### Note:

If the taxpayer establishes that the deposit was in the amount required by Treasury Regulation 31.6302(c)-1 (with allowance for safe haven rule), the FTD will be considered a designated payment and will be applied to 1 and 7 for the specified period covered by the FTD.

The term assessed indicates transactions posted on TXMOD. Accrual are amounts computed on the total balance due on an account (interest and penalties) but are not yet posted to TXMOD.

Prior to January 1, 2003, undesignated payment were applied under the old calculation method. Under the old calculation method, where the Letter 1153 and Form 2751, were issued prior to June 19, 2000, corporate payments received prior to December 31, 2002, were applied in the following order:

1. Non-trust fund portion of tax (employer’s share of FICA).

2. Assessed lien fees and collection costs.

3. Assessed penalty.

4. Assessed interest.

5. Accrued penalty to date of payment.

6. Accrued interest to date of payment.

7. Trust fund portion of tax (withholding and employee’s share of FICA).

8. Bankruptcy payments refer to Insolvency.


**Exhibit 1.34.4-3**

### Custodial Detail Data Base Valid Cross Reference Definitions

If a TFRP case is categorized as VCR 13 and 41 and if both IMF and BMF modules are in WO, make the BMF Non-Duplicate module and the IMF the duplicate module.

| **Valid CDDB VCR Definitions** |
| :-: |
| **VCR** | **MF** | **FS** | **Description** | **Classed as Duplicate** |
| :-: | :-: | :-: | :-: | :-: |
| 13 | IMF | TR, CA, WO | Single Officer -- Single Company BMF Mod meets WO criteria | Split Categorization Part BMF is Dup Part BMF is WO |
| 14 | BMF | TR or CA | Single Officer -- Single Company BMF Mod does not meet WO criteria | IMF is Dup |
| 15 | BMF | TR, CA, WO | Single Company -- IMF Module is not UA | IMF gone --- N/A can include Rollups |
| 16 | IMF | TR, CA, WO | Single Officer -- Single Company BMF Mod is not in UA | BMF gone -- N/A can include Rollups |
| 21 | IMF | TR, CA, WO | Multiple Officer -- Single Company/Multiple Company - BMF Mod not in UA - No other IMF Mods in UA | All IMF Gone - N/A BMF Gone --- N/A Can include MO Rollups |
| 23 | IMF | TR, CA, WO | Single Officer -- Multiple Company All BMF is WO or Split between WO and Gone | Split -- Part of each BMF is Dup -- Part of each BMF is TR, CA or WO |
| 24 | IMF | TR, CA, WO | Multiple Officer -- Multiple Company Officer has TR Activity of its own or All BMF is WO or split between WO and Gone | Split -- Part each BMF is Dup and Part each BMF is TR, CA or WO |
| 31 | IMF | TR, CA, WO | Multiple Officer -- Single Company/Multi Company -- BMF Mod not in UA -- More than 1 IMF Mod in UA | Other IMF Mods are Dup -- BMF Gone -- N/A can include MO rollups |
| 41 | IMF | TR, CA, WO | Multiple Officer -- Single Company BMF Mod meets WO criteria 1 or more IMF Mods in UA | Split -- Part BMF is Dup -- Part BMF is WO -- other IMF Mods are Dup |
| 42 | BMF | TR or CA | Multiple Officer -- Single Company BMF Mod does not meet WO criteria - 1 or more IMF Mods in UA | IMF is Dup |
| 51 | IMF | TR, CA, WO | Single Officer -- Multiple Company (Multiple Assessments) -- No BMF TINs/Mods in UA | BMF gone - N/A |
| 72 | BMF | TR or CA | Single Officer -- Multiple Company (Multiple Assessments) -- None of the BMF TINs meet WO criteria | IMF is Dup |
| 81 | IMF BMF | TR and CA | A Split Assessment between TR & CA | Part Mod is TR -- Part Mod is CA |
| 82 | IMF BMF | Memo & TR, CA, or WO | A Split Assessment between Memo and TR or CA and WO -- CSED has expired on part of module | Part Mod is Memo Part Mod is TR, CA or WO |
| 92 | IMF BMF | WO | BMF Mod is a Rollup | IMF is Dup |

| **Invalid CDDB VCR Definitions** |
| :-: |
| **Invalid Codes** | **Officer** | **BMF** | **Characteristics** |
| :-: | :-: | :-: | :-: |
| 00 | X | X | No TFRP |
| 01 | Yes | Yes | Broken linkage less than or equal to 66 days |
| 02 | Yes | X | All broke linkage from IMF to IMF, IMF to BMF and/or BMF to IMF, no linkage |
| 03 | Yes | Yes | Combined with 02 above |
| 04 | Yes | X | All TFRP MFT 55s (ref code 618) too complicated to be processed under VCR 23/24 |
| 05 | Yes | Yes | Multiple Officer/Multiple Assessment |
| 06 | Yes | Yes | Modules perceived by CDDB to be Role Ups and they do not qualify for VCR 92 |
| 07 | Yes | Yes | Single Officer/Multiple Assessment that CDDB cannot categorize |
| 08 | Yes | Yes | Any other TFRP case |
| 09 | Yes | Yes | Modules involving TC 290/TC 300 issues that CDDB cannot categorize |
| 10 | Yes | Yes | Manual Moves (TC 971 AC 203 - 213) |
| 11 | Yes | Yes | Module is too complicated to process |
| 12 | Yes | Yes | Currently not in use |

**Exhibit 1.34.4-4**

### Stand Alone Penalties

The following analysis provides evidence that stand-alone penalties are properly categorized as TR. The CFO decision to treat stand-alone penalties as TR in 1994follows Federal Accounting Standard Advisory Board and consistent with the tax regulations and the IRS administrative policies, 26 U.S. Code Section 6671 establishes the rules for application of assessable penalties and Chapter 68, Sub-chapter B - Assessable Penalties defines they should be assessed as if a tax.

1. The penalties and liabilities provided by this sub-chapter shall be paid upon notice and demand by the Secretary and shall be assessed and collected in the same manner as taxes. Except as otherwise provided, any reference in this title to "tax" imposed by this title shall be deemed also to refer to the penalties and liabilities provided by this sub-chapter.


Penalties are established for specifically identifiable amounts (mostly defined in statute) and the person(s) or entities from whom the tax (see definition of penalty above) is due has been identified.

They are legally enforceable claims through the IRS established assessment processes, and measurable for the specific amounts resulting from non-compliance actions both through self-assessments made by persons filing tax returns or entry documents and assessments made by the collecting entity (IRS).

Accounts receivable (unpaid assessments) include assessments made through the end of the period plus related fines, penalties and interest.

Most penalties are assessed related to the tax returns filed by the taxpayer and remain in balance due because they are without sufficient payments. These penalties can also occur on assessments with taxpayer agreements at the conclusion of an audit or to a substitute for a return, court actions determining an assessment and taxpayer agreements to pay through an installment agreement or through accepted OIC.

> **General Penalties**
>
> - Most of the penalties assessed are related to the general penalty provisions where the taxpayer filed a return after established due date (e.g., failure to file), did not make proper estimated or federal tax deposit payments (e.g., failure to deposit or estimate tax) or filed without sufficient payments (e.g., failure to pay).
>
> - The IRC provides for these penalties and interest to promote voluntary compliance and establishes the amounts to be assessed.
>
> - The taxpayer is afforded an ability to request relief from these penalties under reasonable cause for why they failed to comply with the law but cannot dispute the basis for the penalties.

> **Civil Monetary Penalties**
>
> - In the case of civil monetary penalties, the majority result from non-compliance with voluntary actions required to be taken by the taxpayer, employer or preparer when filing returns or providing required informational documentation.
>
> - While many civil monetary assessments are made by the IRS for non-compliance (more closely aligned with a definition of CA), these are categorized as TR because the law established in definitive amounts what can be assessed, and the taxpayer can again request relief under reasonable cause provisions but not the right to disagree or object with the penalty provision.

> **Other Background/Reference Materials**

> The Treasury Office of Tax Policy and the Joint Committee on Taxation works routinely to provide the IRS penalty and interest provisions in the Internal Revenue Code to support and encourage voluntary compliance and to bring additional revenues into the Treasury.
>
> - The U.S. Code outlines specifics for each penalty and the general provisions applicable to most returns are the penalties for failing to comply with timely filing, paying, and reporting requirements. There are also non-return penalties for failing to provide informational type returns and preparer penalties and appraisal penalties.
>
> - IRC Subtitle F, Chapter 68 contains most of the civil penalty provisions. They are called additions to the tax, additional amounts, or assessable penalties. For simplicity, they are referred to as penalties.

> The IRC established taxpayers are to assess their tax liabilities against themselves and pay them voluntarily. This system of self-assessment and payment is based on the principle of voluntary compliance. Voluntary compliance exists when taxpayers conform to the law without compulsion or threat. Compliant self-assessment requires a taxpayer to know the rules for filing returns and paying taxes. The IRS is responsible for providing information to taxpayers, which includes:
>
> - Written materials that clearly explain the rules.
>
> - Forms that permit the self-computations of the tax liability.

> Whenever taxpayers fail to comply with these rules certain penalties apply. Some are assessed systemically and others by employees working the non-compliance issue with the taxpayer.

> The amount of penalty that can be assessed is generally set by law and applied consistently. In limited circumstances where doing so will promote sound and efficient tax administration, the Service may approve a reduction of otherwise applicable penalties or penalty waiver for a group or class of taxpayers as part of a Service-wide resolution strategy to encourage efficient and prompt resolution of cases of noncompliant taxpayers. In considering the application of penalties to a particular case, all Service functions must develop procedures that will promote:
>
> - Consistency in the application of penalties compared to similar cases,
>
> - Unbiased analysis of the facts in each case; and,
>
> - The proper application of the law to the facts of the case.

> Because most penalties are assessed because of non-compliance with these filing and paying rules, they are generally subject to relief (abatement) only for the following reasons.
>
> - Reasonable Cause.
>
> - Statutory exceptions.
>
> - Administrative waivers.
>
> - Correction of Service error.

> The penalty handbook provides guidance to all areas of the IRS for all civil penalties imposed by the IRC. It sets forth general policy and procedural requirements for assessing and abating penalties, and it contains discussions on topics such as criteria for relief from certain penalties. For detailed information see [IRM 20.1, Penalty Handbook](http://serp.enterprise.irs.gov/databases/irm.dr/current/20.dr/20.1.dr/20.1.htm)

**Exhibit 1.34.4-5**

### **IRS Unpaid Assessments Financial Statement Estimation Process Plan**

**Pre-Financial Statement Estimation Process Question Elevation**

|     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ****Review Levels**** | **Step One** | **Step Two** | **Step Three** | **Step Four** | **Step Five** | **Step Six** | **Step Seven** |
| **Normal Review Process** |  |  |  |  |  |  |  |
|  | If an analyst or reviewer 1) Encounters information in a Big Blue (BB) case file that causes a question or, 2) Has a general question that is not case-specific, they will do one or more of the following as appropriate to the situation: | Research IRM, IRC, SERP, etcetera for technical information. | Discuss the case with a co-worker. | Discuss the case with several co-workers. | Contact the IRS field or campus persons whose names are provided on DCI response forms. | Contact the GAO Coordinator for the appropriate Campus or function. | Take the case to the manager to discuss. If no conclusion is made this goes to Second Level Review. |
| **Second Level Review** |  |  |  |  |  |  |  |
|  | If the manager is confident that they understand the facts of the case or question and can categorize it correctly, they will prepare a written response to the question and return the case to the initiator. The initiator should keep a copy of the response in the case file. | If the manager determines that more information is needed, and there is no consensus with staff, they will also take the same steps as the analyst did. In addition, they will do one or more of the following: | Contact a designated or undesignated Subject Matter Expert (SME) for information. | Contact SME contractor located at KC Campus. | The manager will pose hypothetical situation resolution as appropriate when Methodology is unclear. | If resolution cannot be reached, or the manager determines that the case merits an additional level of review, they will elevate the case to the director, Unpaid Assessments & Analysis. |  |
| **Third Level Review** |  |  |  |  |  |  |  |
|  | If the director is confident that they understand the facts of the case or question and can categorize it correctly, they will respond in writing to the Unpaid Assessments Accounting Analysis manager. | If the director determines that more information is needed, they will do one or more of the following: | Consult with Unpaid Assessments Accounting Analysis staff and manager for clarification. | Contact a designated or undesignated SME for information.. | If resolution cannot be reached, elevate to the Associate CFO for Revenue Financial Accounting. |  |  |
| **Fourth Level Review** |  |  |  |  |  |  |  |
|  | If the Associate CFO for Revenue Financial Accounting is confident that they understand the facts of the case or question and can categorize it correctly, they will respond in writing to the director and Unpaid Assessments Accounting Analysis manager. | If the Associate CFO for Revenue Financial Accounting determines that more information is needed, they will do one or more of the following: | Consult with Unpaid Assessments Accounting Analysis staff and manager for clarification. | Contact a designated or undesignated SME for information. | If resolution cannot be reached, elevate to the Senior Associate CFO for Financial Management. |  |  |
| **Fifth Level Review** |  |  |  |  |  |  |  |
|  | If the Senior Associate CFO for Financial Management is confident that they understand the facts of the case or questions and can categorize it correctly, they will respond in writing to the Associate CFO, director, and Unpaid Assessments Accounting Analysis Manager. | If the Senior Associate CFO for Financial Management determines that more information is needed, they will do one or more of the following: | Consult with Unpaid Assessments Accounting Analysis staff and manager as well for clarification. | Contact a designated or undesignated SME for information. | If resolution cannot be reached, Elevate to the Deputy CFO. |  |  |
| **Final Review** |  |  |  |  |  |  |  |
|  | If the Deputy CFO received a case to review, or a general question, they must provide a definitive answer to the question in writing. |  |  |  |  |  |  |

**During Financial Statement Estimation Process Case Elevation**

|     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ****Review Levels**** | **Step One** | **Step Two** | **Step Three** | **Step Four** | **Step Five** | **Step Six** | **Step Seven** |
| **Normal Review Process** |  |  |  |  |  |  |  |
|  | If an analyst or reviewer encounters information in the case file that causes a question they will do one or more of the following as appropriate to the situation: | Research IRM, IRC, SERP, etcetera for technical information. | Discuss the case with a co-worker. | Discuss the case with several co-workers. | Contact the IRS field or campus persons whose names are provided on DCI response forms. | Contact the GAO Coordinator for the appropriate Campus or function. | Take the case to the manager to discuss. If no conclusion is made this goes to Second Level Review. |
| **Second Level Review** |  |  |  |  |  |  |  |
|  | If the manager is confident that they understand the facts of the case and can categorize it correctly, they will ensure that the control sheet is completed correctly, initial the control sheet and turn the case over to GAO. | If the manager determines that more information is needed, and there is no consensus with staff, they will also take the same steps as the analyst did. In addition, they will do one or more of the following: | Contact a designated or undesignated SME for information. | Contact SME contractor located at KC Campus. | The manager will pose hypothetical situation resolution as appropriate when Methodology is unclear. | If resolution cannot be reached, or the manager determines that the case merits an additional level of review, they will elevate the case to the director, Unpaid Assessments & Analysis. |  |
| **Third Level Review** |  |  |  |  |  |  |  |
|  | If the director is confident that they understand the facts of the case and can categorize it correctly, they will ensure that the control sheet is completed correctly, initial the control sheet and turn the case over to GAO. | If the director determines that more information is needed, they will do one or more of the following: | Consult with Unpaid Assessments Accounting Analysis staff and manager for clarification. | Contact a designated or undesignated SME for information. | The director will Initial the control sheet or if no resolution is met they will elevate to the Associate CFO for Revenue Financial Accounting. |  |  |
| **Fourth Level Review** |  |  |  |  |  |  |  |
|  | If the Associate CFO for Revenue Financial Accounting is confident that they understand the facts of the case and can categorize it correctly, they will ensure that the control sheet is completed correctly, initial the control sheet and turn the case over to GAO. | If the Associate CFO for Revenue Financial Accounting determines that more information is needed, they will do one or more of the following: | Consult with Unpaid Assessments Accounting Analysis staff and manager for clarification. | Contact a designated or undesignated SME for information. | The Associate CFO for Revenue Financial Accounting will initial the control sheet or if no resolution is met, elevate to the Senior Associate CFO for Financial Management. |  |  |
| **Fifth Level Review** |  |  |  |  |  |  |  |
|  | If the Senior Associate CFO for Financial Management is confident that they understand the facts of the case and can categorize it correctly, they will ensure that the control sheet is completed correctly, initial the control sheet and turn the case over to GAO. | If the Senior Associate CFO for Financial Management determines that more information is needed, they will do one or more of the following: | Consult with Unpaid Assessments Accounting Analysis staff and manager as well for clarification. | Contact a designated or undesignated SME for information. | The Senior Associate CFO for Financial Management will initial the control sheet or if no resolution is met, elevate to the Deputy CFO. |  |  |
| **Final Review** |  |  |  |  |  |  |  |
|  | If the Deputy CFO receives a case to review, they must provide a definitive answer to the question. | The Deputy CFO must ensure that the control sheet is completed correctly, initial the control sheet, and turn the case over to GAO. |  |  |  |  |  |

**Exhibit 1.34.4-6**

### Recognition of an Economic Event

The IRS recognizes considering transactions only after they have been recorded in the taxpayer account is in compliance with SFFAS No. 7 Accounting for Revenue and Other Financing Sources.

- An accounts receivable UA is recognized when a collecting entity establishes a specifically identifiable, legally enforceable claim to cash or other assets through its established assessment processes to the extent the amount is measurable.

- An Unpaid Assessment is recognized based on completion of the assessment processes. Under such processes, assessments are enforceable claims for which specific amounts due have been determined and the person(s) or entities from whom the tax or duty is due have been identified. Assessments include both self-assessments made by persons filing tax returns or entry documents and assessments made by the collecting entities.

- An accounts receivable, therefore, includes only unpaid assessments made through the end of the period plus related fines, penalties and interest.

- A pre-assessment work in process includes assessments not yet officially asserted by the collecting entity which are subject to a taxpayer's right to conference in response to initial information notices, e.g., revenue agent reports.

- The amount or range of amounts that will ultimately be assessed or the duration of the notice period may be reasonably estimated, but there are no amounts for pre-assessment work in process presently included in the dollar-based accounting systems.

- Estimates of the amount or range of amounts of pre-assessment work in process that may ultimately be collectable are not presently sufficiently reliable to be recognized.

- Adjustments (assessments or abatements) are not recognized until they are posted to master file.

- Abatements have the same process as assessments with regard to the 23C (assessment) date. Form 2188, Voucher and Schedule of Overpayments and Overassessments, is the official recordation for abatements.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-034-004#addtoany "Show all")

A2A