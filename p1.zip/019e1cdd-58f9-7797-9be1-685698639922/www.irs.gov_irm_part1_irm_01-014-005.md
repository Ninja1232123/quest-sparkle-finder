---
url: "https://www.irs.gov/irm/part1/irm_01-014-005"
title: "1.14.5 Occupational Health and Safety Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-005#main-content)

- 1.14.5  [Occupational Health and Safety Program](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406458394288)
  - 1.14.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406458419264)
    - 1.14.5.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406458408128)
    - 1.14.5.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406458406320)
    - 1.14.5.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406458755568)
    - 1.14.5.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457903408)
    - 1.14.5.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457899472)
    - 1.14.5.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457894736)
    - 1.14.5.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457860704)
  - 1.14.5.2  [Employee Rights](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457857840)
  - 1.14.5.3  [Occupational Health and Safety Requirements](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457847600)
    - 1.14.5.3.1  [Accident and Incident Investigations](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457844912)
    - 1.14.5.3.2  [Asbestos](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457837984)
    - 1.14.5.3.3  [Bloodborne Pathogens](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457833024)
    - 1.14.5.3.4  [Chemicals](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457826272)
    - 1.14.5.3.5  [Cranes](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457818768)
    - 1.14.5.3.6  [Electrical Safety](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457816464)
    - 1.14.5.3.7  [Ergonomics Musculoskeletal Disorders (MSD)](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457803568)
    - 1.14.5.3.8  [Fall Protection](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457797888)
    - 1.14.5.3.9  [Fire Safety](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457784144)
    - 1.14.5.3.10  [First Aid](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457772816)
    - 1.14.5.3.11  [Hearing Conservation](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457766864)
    - 1.14.5.3.12  [Indoor Environmental Quality (IEQ)](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457760832)
    - 1.14.5.3.13  [Inspections, Audits and Self-Assessments](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457716032)
    - 1.14.5.3.14  [Job Hazard Analysis](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457705984)
    - 1.14.5.3.15  [Lockout and Tagout (Control of Hazardous Energy)](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457699696)
    - 1.14.5.3.16  [Permit-Required Confined Spaces](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457691776)
    - 1.14.5.3.17  [Personal Protective Equipment (PPE)](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457685856)
    - 1.14.5.3.18  [Private Employer Workspace](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457676256)
    - 1.14.5.3.19  [Power Industrial Trucks and Pallet Jacks](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457674160)
    - 1.14.5.3.20  [Reasonable Accommodations](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457667888)
    - 1.14.5.3.21  [Reporting and Recordkeeping](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457666176)
    - 1.14.5.3.22  [Welding, Cutting, Brazing and Other Hot Work](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457647424)
  - 1.14.5.4  [Workers’ Compensation Claims and Tort Claims Guidance](https://www.irs.gov/irm/part1/irm_01-014-005#idm140406457644576)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 5. Occupational Health and Safety Program

* * *

## 1.14.5 Occupational Health and Safety Program

#### Manual Transmittal

March 03, 2025

#### Purpose

(1) This transmits revised IRM 1.14.5, Occupational Health and Safety Program.

#### Material Changes

(1) Throughout: Replaced references to KISAM with IRWorks. The KISAM platform was replaced with IRWorks to process health and safety reporting.

(2) _IRM 1.14.5.1.3_, Roles and Responsibilities:

1. Updated management and program titles.

2. Paragraph (8) – Added NTEU representative for building hazards notification.

3. Paragraph (9g) – Added responsibility to notify industrial hygienist of air quality issues.

4. Paragraph (9n) – Added responsibility to forward training requests to FMSS EHS HQ staff.

5. Paragraph (9q) – Added reporting of work-related employee injury.

6. Paragraph (13a) – Replaced Environmental Protection Specialist with staff.

7. Paragraph (14b) – Added FMSS EHS HQ staff notification when hazard cannot be corrected by contractor.


(3) _IRM 1.14.5.1.5_, Program Controls: Added Program Controls subsection.

1. Paragraph (1) – Added EHS assessment.

2. Paragraph (2) – Added self-evaluation program.

3. Paragraph (3) – Added review of OSHA 300 logs and health and safety cases.


(4) _IRM 1.14.5.1.6_, Acronyms: Updated table to remove KISAM and add IRWorks.

(5) _IRM 1.14.5.3.2_(4), Asbestos: Removed referenced GSA Policy language.

(6) _IRM 1.14.5.3.4_, Chemicals:

1. Paragraph (1)- Added the availability of SDS sheets to IRS SharePoint site.

2. Paragraph (2)- Clarified aerosol use.


(7) _IRM 1.14.5.3.6_(7), Electrical Safety: Clarified the use of non-IRS supplied appliances.

(8) _IRM 1.14.5.3.9_(2f), Fire Safety: Added an exception to the use of portable fire extinguishers in note.

(9) _IRM 1.14.5.3.12_(6b), Indoor Environmental Quality (IEQ): Updated the range of workstation lighting. Removal of paragraph (6c) moved up the following subsections.

(10) _IRM 1.14.5.3.17_(1), Personal Protective Equipment (PPE): Clarified that an industrial hygienist conducts a job hazard analysis for correct equipment.

(11) _IRM 1.14.5.3.21_(1), Reporting and Record Keeping: Clarified annual reporting and incidence rates calculation.

(12) Throughout: Made editorial changes to clarify, reorganize and remove duplicate content. Incorporated plain language and updated grammar, titles, website addresses and references.

#### Effect on Other Documents

This document supersedes IRM 1.14.5 dated September 13, 2021.

#### Audience

All IRS Organizations

#### Effective Date

(03-03-2025)

Julia W. Caldwell

Acting Chief

Facilities Management and Security Services

**1.14.5.1** **(09-13-2021)**

### Program Scope and Objectives

1. **Purpose**: This IRM establishes and describes the framework for the IRS Occupational Health and Safety Program and ensures compliance with federal, state, and local occupational health and safety regulations, Executive Orders (EO), and Treasury Directives (TD).



1. Environmental compliance is described in IRM 1.14.12, IRS Environmental Compliance Program.

2. Occupant Emergency Planning is described in IRM 10.2.9, Occupant Emergency Program.


2. **Objectives**: Provide a cohesive and compliant Servicewide Occupational Health and Safety Program which supports IRS EHS Policy Statement 1-235. published in IRM 1.2.1, Servicewide Policy Statements. The objectives of the IRS occupational health and safety program are to:



1. Promote a proactive health and safety culture that supports the IRS mission through regular communications.

2. Ensure that all employees and managers comply with federal, state, and local regulations, as well as, IRS health and safety rules, policies, and laws through the Safety Inspection Program.

3. Prevent injuries, illnesses, and accidents involving IRS employees, contractors, and visitors to IRS facilities through corrective and preventive actions taken as a result of safety inspections and accident investigations.


3. **Audience**: All IRS employees and contractors.

4. **Policy Owner**: Chief, Facilities Management and Security Services (FMSS).

5. **Program Owner**: FMSS EHS Chief.

6. **Primary Stakeholders**: FMSS Safety Supervisors, FMSS Territory Managers (TM), FMSS Safety Officers (SO), FMSS personnel at IRS Headquarters (HQ) and in the field.


**1.14.5.1.1** **(09-13-2021)**

#### Background

1. On August 30, 2020, FMSS created two Safety Sections, Safety East and Safety West. This realignment allows FMSS Safety Officers to report to their respective FMSS Safety Supervisor rather than to the FMSS TM.


**1.14.5.1.2** **(09-13-2021)**

#### Authority

1. The IRS occupational health and safety program is based on the following laws, regulations, EO, TD, and IRS policy:



01. Public Law 91-596, Occupational Safety and Health (OSH) Act

02. EO 12196, Occupational Safety and Health Programs for Federal Employees

03. 29 CFR 1904, Recording and Reporting Occupational Injuries and Illness

04. 29 CFR 1910, Occupational Safety and Health Standards (General Industry)

05. 29 CFR 1926, Safety and Health Regulations for Construction

06. 29 CFR 1960, Basic Program Elements for Federal Employees OSH

07. 41 CFR 50-204, Safety and Health Standards for Federal Supply Contracts

08. 41 CFR 102-74, Facility Management

09. 41 CFR 102-80, Safety and Environmental Management

10. Treasury Directive 75-10, Safety and Health Management Program

11. Document 11500, IRS Manager’s Guide to Penalty Determinations

12. Article 27, Section 3, The National Agreement with the National Treasury Employees Union (NTEU)

13. Department of Treasury Acquisition Procedures (DTAP)


**1.14.5.1.3** **(03-03-2025)**

#### Roles and Responsibilities

01. The IRS Commissioner will ensure the provision of support and resources to achieve the IRS EHS Policy and to comply with federal, state, and local environmental, health, and safety regulations.

02. IRS Deputy Commissioners and other executive managers, commensurate with their authority, will:



    1. Furnish employees and onsite contractors with a place of employment which is free from recognized hazards that are causing or are likely to cause death or serious physical harm.

    2. Ensure compliance with the occupational health and safety regulations that apply to the IRS.

    3. Ensure compliance with IRS occupational health and safety policies.


03. The Chief, FMSS is the Designated Safety and Health Official (DSHO). The DSHO represents the interest and support of the IRS Commissioner in the management and administration of the IRS occupational health and safety program. The DSHO:



    1. Establishes and administers the IRS OHS policy and program requirements and carries out the provisions of Section 19 of the OSH Act, EO 12196, and requirements of 29 CFR 1960.

    2. Ensures adequate occupational health and safety staff, resources, and funding to implement an effective occupational health and safety program at all operational levels.

    3. Establishes procedures to ensure effective implementation of the IRS policy and program.

    4. Develops goals, objectives, and measures for improving IRS OHS program performance.


04. EHS Chief, FMSS:



    1. Ensures adequate staffing (including allocation of FMSS SO throughout IRS regions), funding, resources, and organization support to maintain the IRS EHS program.

    2. Sets goals and objectives for reducing and eliminating occupational accident, injuries, and illnesses.

    3. Establishes IRS EHS policy and ensures adherence to established EHS regulations.

    4. Ensures evaluation of the IRS EHS program is conducted at every program level.


05. The FMSS EHS HQ staff:



    1. Plans, implements, analyzes, and evaluates the IRS EHS program.

    2. Establishes policies, procedures, and directives for the IRS EHS program.

    3. Provides technical assistance and guidance to Safety Section Chiefs, FMSS SO, health and safety stakeholders, Business Units, and management.

    4. Reports to the Department of the Treasury and other federal agencies, as required or as appropriate, on the operations and performance of the IRS OHS program.

    5. Administers and conducts EHS reviews of all IRS acquisition actions and products that may have EHS impacts prior to purchase or publishing solicitations.


06. The FMSS Safety Supervisor/Chief:



    1. Establishes and manages Safety programs within their servicing areas.

    2. Ensures the development of a Safety annual program plan, including resource needs; and Safety objectives within their servicing areas.

    3. Ensures safety inspections are conducted in all areas and operations under their purview.

    4. Establishes local safety guidelines as recommended by the FMSS SO or other personnel.


07. The FMSS TM:



    1. Ensures support of the EHS program within their Territory.

    2. Ensures FMSS SO access to facilities and staff as not to impinge on their ability to carry out their assigned duties.

    3. Ensures inclusion of FMSS SO into everyday work process and project planning.

    4. Provides collaboration and territory support for correcting EHS hazards, corrective action requests and compliance/inspection/audit findings.

    5. Notifies the FMSS EHS HQ staff within 48 hours of receipt of a Notice of Violation or any other occupational health and safety or environmental compliance notice.

    6. Notifies the FMSS EHS HQ staff immediately if an Occupational Safety and Health Administration (OSHA) compliance officer has requested access to IRS facility for an inspection/audit.

    7. Reviews and signs annual OSHA 300 summary forms for each establishment under their control.

    8. Ensures IRS Standard Operating Procedures (SOP) relevant to their facility and building operations are followed.


08. The Senior Continuity Representatives (SCR)/Site Coordinators (SC):



    1. Advocate a proactive OHS program within their jurisdiction.

    2. Oversee the Safety Advisory Committees (SAC) within their jurisdiction in accordance with the provisions of Article 27, Section 3, of the National Agreement with the NTEU.

    3. Solicit volunteers from Business Units to act as safety inspectors for annual safety inspection, and working with the FMSS SO, ensure the appropriate number of inspectors are available at office locations within their jurisdiction to perform the inspection.

    4. Notify all managers and a NTEU representative within a specific building when a serious or imminent hazard is reported.

    5. Nominate outstanding volunteer inspectors and/or SAC members for appropriate EHS awards or recognition for their contributions.

    6. Authorize entry of an OSHA compliance officer to an IRS facility or office space and coordinate the inspection with the servicing FMSS SO.


09. The FMSS SO:



    01. Implements the IRS Safety Program in their servicing areas in accordance with established rules, regulations, policies and this IRM.

    02. Develops annual Safety program plans that establish occupational health and safety goals and objectives within their servicing areas.

    03. Attend and actively participate in FMSS projects and project meetings, including providing Safety support during project planning, construction, and renovation.



        ### Note:



        Support includes but is not limited to: assistance with completion of pre-construction impact assessment, applicability of OSHA regulations and safety best practices to all aspects of project work, and site evaluation for safety hazards and controls during all phases of work.

    04. Ensures annual safety inspections are performed in all areas and operations within their servicing areas, which includes facilitating the recruitment, training, and assignment of safety inspectors.

    05. Enters IRWorks case for safety inspection findings identified that have not been corrected if appropriate. The FMSS SO follows up and ensures finding has been corrected.

    06. Performs ad hoc safety inspections as needed.

    07. Ensures industrial hygiene staff is notified of indoor air quality issues including mold, asbestos, chemical concerns before taking actions or making industrial hygiene recommendations. Then works with the IH as the project develops.

    08. Conducts investigations of significant incidents, near misses, accidents, injuries, and illnesses and record findings and recommendations for corrective actions.

    09. Works, updates, and closes assigned IRWorks cases.

    10. Evaluates and coordinates actions to control hazards identified by employees, through safety inspections or investigations.

    11. Conducts injury and hazard data analyses to identify job or facility hot spots, determines root causes, and recommends effective actions.

    12. Serves as an advisor on health and safety issues to supervisors and managers, employees, SAC, Occupant Emergency Plan (OEP) Teams, IRS Incident Commanders (e.g., the senior official on site), and other committees and working groups.

    13. Develops, implements, and tracks corrective actions for open action items resulting from ad hoc investigations, EHS audits, and inspections.

    14. Provides occupational health and safety training.

    15. Forwards requests for Job Hazard Analysis (JHA) to FMSS EHS HQ staff.

    16. Ensures that the required documents are posted in IRS facilities, as applicable.

    17. Participates in internal and/or external audits/reviews of health and safety programs in their servicing areas.

    18. Immediately reports any fatality, work related hospitalization, amputation, or loss of an eye of an employee to their supervisor and to the FMSS EHS HQ staff..


10. IRS Managers:



    1. Ensure operations under their purview are conducted in a manner that complies with OHS rules, policies, and procedures that are issued by the IRS.

    2. Verify their employees receive required health and safety training, specifically those employees who work with machinery, chemicals or under any other hazardous conditions.



       ### Note:



       For further guidance, contact local FMSS SO.

    3. Support the FMSS SO in conducting investigations and gathering information on near misses, accidents, injuries, illnesses, and unsafe conditions.

    4. Ensure that any fatality, hospitalization, amputation, or loss of an eye is immediately reported to the local FMSS SO or FMSS EHS HQ Staff.

    5. Discipline their employees who violate safety rules in accordance with the Document 11500, IRS Manager’s Guide to Penalty Determinations.

    6. Nominate outstanding employees for appropriate EHS awards or recognition for their contributions.

    7. Ensure applicable IRS SOPs are implemented and followed.


11. Safety Inspectors (SI) are volunteer employees, who under guidance of the FMSS SO:



    1. Conduct annual safety inspections of work/office space as scheduled and assigned by the FMSS SO.

    2. Invite local management and local NTEU representatives to participate in inspections.

    3. Correct identified safety hazards at the time of the inspection when possible. Notify the FMSS SO if a serious hazard is found that cannot be immediately corrected.

    4. Report safety hazards that cannot be corrected immediately to the FMSS SO.

    5. Notify on-site managers of inspection results and hazards that are identified.

    6. Assist with accident investigations or other ad-hoc requests by the FMSS SO.


12. IRS Employees:



    1. Comply with occupational health and safety rules, policies, and procedures that are issued by the IRS.

    2. Perform their official duties in a manner that does not harm themselves, their fellow employees, or the general public.

    3. Report safety hazards, injuries, illnesses, and unsafe behaviors in a timely manner to their manager and to the Employee Resource Center (ERC).

    4. Report occupational injuries, illnesses, accidents in Employees’ Compensation Operation & Management Portal (ECOMP) and unsafe conditions through the ERC, inform their supervisor, and forward to their local FMSS SO.

    5. Participate in required safety and health training.

    6. When a job task requires the mandatory use of Personal Protective Equipment (PPE), employees will use PPE as required in the Job Hazard Analysis (JHA) for that specific job task.



       ### Note:



       For further information regarding PPE, training or JHA, contact your local FMSS SO.


13. IRS Contracting Officer (CO):



    1. Ensures Requests for Quotes (RFQ), Statement of Work (SOW), Performance Work Statement (PWS) and Statement of Objectives (SOO) etc. have been reviewed by the appropriate FMSS EHS staff.


14. IRS Contracting Officer’s Representatives (COR):



    1. Identify and report occupational health and safety hazards and unsafe work practices created by or affecting a contractor.

    2. Notify the CO and FMSS EHS HQ staff of serious hazards that a contractor will not or cannot correct.

    3. Ensure the contractor adheres to all EHS regulations and contractual requirements.


**1.14.5.1.4** **(09-13-2021)**

#### Program Management and Review

1. In compliance with 29 CFR 1960.79, The EHS HQ staff must conduct periodic reviews of field occupational health and safety programs.



1. The field reviews must include qualitative assessments to determine the extent to which programs are established in accordance with OSHA, Department of the Treasury, and IRS regulations, directives, and policies, as well as other federal agency requirements.


2. **Program Effectiveness:** The program is measured through the statistically significant reduction or increase in incidents, injuries, and close calls.


**1.14.5.1.5** **(03-03-2025)**

#### Program Controls

1. Delegated campus locations will undergo a comprehensive EHS Assessment by FMSS EHS HQ staff at least once every three years.

2. In order to comply with the 29 CFR 1960.79 requirement for program self- evaluations, self-assessments will be conducted during years when an external audit is not performed. The FMSS EHS HQ staff or designee will initiate a self-evaluation program to ensure the required OSH policies, materials and processes are understood and implemented. The results of the self-evaluation will be shared with the Chief, EHS.

3. The Safety Supervisors will annually review the OSHA 300 logs looking for trends and periodically review IRWorks safety or health cases submitted. Cases will be evaluated for:



1. Appropriate response

2. Timely follow-up

3. Communication such as progress notes and documentation for case close out


**1.14.5.1.6** **(03-03-2025)**

#### Acronyms

1. The following table provides acronyms that are used throughout this IRM section:




| **Acronym** | **Term** |
| --- | --- |
| ACM | Asbestos Containing Material |
| AED | Automated External Defibrillator |
| ASHRAE | American Society of Heating, Refrigeration and Air-Conditioning Engineers |
| CFR | Code of Federal Regulations |
| COR | Contracting Officer’s Representative |
| dB | Decibel |
| DSHO | Designated Safety and Health Official |
| ECOMP | Employees’ Compensation Operation & Management Portal |
| EHS | Environment, Health, and Safety |
| EO | Executive Order |
| ERC | Employee Resource Center |
| FMSS | Facilities Management and Security Services |
| FOH | Federal Occupational Health |
| FS | Facilities Support |
| GSA | General Services Administration |
| HQ | Headquarters |
| IRWorks | Internal Revenue Work Requests |
| IH | Industrial Hygienist |
| JHA | Job Hazard Analysis |
| MSD | Musculoskeletal Disorders |
| OHS | Occupational Health and Safety |
| OPIM | Other Potentially Infectious Material |
| OSHA | Occupational Safety and Health Administration |
| PACM | Presumed Asbestos Containing Material |
| PEL | Permissible Exposure Limit |
| PPE | Personal Protection Equipment |
| PPM | Parts Per Million |
| RA | Reasonable Accommodation |
| SAC | Safety Advisory Committees |
| SC | Site Coordinators |
| SCR | Senior Continuity Representative |
| SDS | Safety Data Sheet |
| SI | Safety Inspector |
| SO | Safety Officers |
| SOP | Standard Operating Procedures |
| TD | Treasury Directives |
| TM | Territory Managers |
| TWA | Time Weighted Average |
| VOC | Volatile Organic Compound |


**1.14.5.1.7** **(03-03-2025)**

#### Related Resources

1. IRM 1.2.1.2.35, Policy Statement 1-235 (Rev. 1), Environment, Health and Safety Policy

2. IRM 1.14.12, Facilities Management, IRS Environmental Compliance Program

3. IRM 10.2.9, Physical Security Program, Occupant Emergency Program

4. IRM 1.14.7, Facilities Management, Motor Vehicle Fleet Management Program


**1.14.5.2** **(03-03-2025)**

### Employee Rights

1. IRS employees have the right to:



01. Review copies of appropriate standards, rules, regulations, and requirements.

02. Request information on safety and health hazards in the workplace, appropriate precautions to take, and procedures to follow if the employee is involved in an accident or is exposed to toxic substances.

03. Submit an IRWorks case for a safety or health hazard. A case may be submitted anonymously by calling the ERC (866-743-5748) or contacting an FMSS SO and withholding identification.

04. Gain access to employee exposure records (their own or representative exposure records) and their own medical records.

05. Request an OSHA inspection if they believe hazardous conditions or violations of standards exist in the workplace.

06. Exercise the right to have an authorized employee representative (such as a union representative) accompany the OSHA compliance officer during an inspection tour.

07. Respond to questions from an OSHA compliance officer.

08. Observe any monitoring or measuring of hazardous materials and see the resulting records.

09. Review or have an authorized representative review the OSHA Form 300, Log of Work-Related Occupational Injuries and Illnesses, at a reasonable time and in a reasonable manner.

10. Object to the timeframe set by OSHA for the employer to correct a violation by writing to the OSHA Area Director within 15 working days from the date the IRS receives a notice of unsafe or unhealthful working conditions.

11. Submit a written request to the National Institute for Occupational Safety and Health for information on whether any substance in the workplace has potentially toxic effects based on the concentration being used, and, if requested, have their names withheld.

12. Receive notification if the IRS applies for a variance from an OSHA standard and have an opportunity to testify at a variance hearing and appeal the final decision.

13. Have their names withheld from the IRS, by request to OSHA, if they sign and file a written complaint.

14. Be advised of OSHA actions regarding a complaint and request an informal review of any decision not to inspect the site or issue a citation.

15. File a complaint if punished or discriminated against for acting as a whistleblower under the OSH Act or other federal statutes, or for refusing to work when faced with imminent danger of death or serious injury and there is insufficient time for OSHA to inspect.


**1.14.5.3** **(09-13-2021)**

### Occupational Health and Safety Requirements

1. This subsection of the IRM contains major occupational health and safety requirements that apply to the IRS. Compliance details are not included nor is every regulatory topic included in this IRM.



### Note:



For further information, regarding the IRS EHS program or for additional information on any of the topics found in this IRM contact the local FMSS SO servicing your area.


**1.14.5.3.1** **(09-13-2021)**

#### Accident and Incident Investigations

1. While all accidents should be investigated, including accidents involving property damage only, the extent of such investigations shall be reflective of the seriousness of the accident.

2. Investigations:



1. All injuries or illnesses that meet the recording criteria of an OSHA Recordable Injury or Illness, as described in the recording criteria of 29 CFR 1904.4 through 29 CFR 1904.11, will be investigated.

2. As part of the investigation, the root cause of the injury or illness will be determined; and action to prevent similar injuries or illnesses should be proposed.


3. As required by Federal law, the FMSS SO or EHS Headquarters will report all work-related fatalities, hospitalizations, amputation, or loss of an eye to OSHA as required _(additional recordkeeping information is in _IRM 1.14.5.3.21_ of this IRM)_:



1. Within eight hours after the death of an IRS employee from a work-related incident.

2. Within 24 hours of an inpatient hospitalization of one or more IRS employees, or an amputation, or loss of an eye if it is a result of a work-related incident.


**1.14.5.3.2** **(03-03-2025)**

#### Asbestos

1. Asbestos-Containing Materials (ACM), defined as any material containing more than 1% asbestos and/or Presumed Asbestos-Containing Materials (PACM) which is material not tested but assumed to contain asbestos, must be identified, maintained, and/or removed in compliance with federal, state and local regulations, and General Services Administration (GSA) policy.

2. Building and facility owners of privately and/or government-owned and operated buildings that were built prior to 1980 must determine the presence, location, and quantity of ACM and/or PACM in buildings. This is usually in the form of a survey.

3. IRS employees who work in buildings constructed prior to 1980 must be informed about the presence and location of ACM and/or PACM.

4. Custodial staff, contractors, and subcontractors who perform housekeeping activities in areas which contain ACM and/or PACM must be informed of the presence and location of ACM and/or PACM which may be contacted during custodial services and must be provided asbestos awareness training annually.

5. Contractors and subcontractor employees who perform activities in areas which contain ACM and/or PACM must be informed of the presence and location of ACM and/or PACM.

6. Inspections and air monitoring are coordinated by the GSA, lessor, IRS Building Manager, or IRS Project Manager. NTEU shall be provided the results of the monitoring.


**1.14.5.3.3** **(09-13-2021)**

#### Bloodborne Pathogens

1. All blood and other potentially infectious body fluid spills must be contained immediately and cleaned by appropriate professional staff or others properly trained and equipped to work with potentially infectious materials.



1. Employees are responsible for the disposal of personally used sharps (including needles, lancets, and syringes) and must adhere to any state or local regulations regarding the disposal of such items.

2. Employees must not carry unprotected used sharps through halls or work areas.

3. If an employee or a contractor is accidentally stuck by a used sharp, they should report the incident to their supervisor, ECOMP, and a health clinic within 24 hours for post-exposure evaluation and follow-up.


2. Exposure Control Plan:



1. A written exposure control plan will be developed for any employees expected to be exposed to human blood or Other Potentially Infectious Materials (OPIM) during the course of their work duties as described in 29 CFR 1910.1030, Bloodborne Pathogen Standard.

2. An employee who has an exposure incident must be offered a hepatitis B vaccination series and post-exposure evaluation and follow-up.

3. An exposure incident means contact with blood or OPIM as part of an employee’s duties, specifically contact with eye, mouth, other mucous membrane, non-intact skin, or piercing of the skin or mucous membrane that results from the performance of an employee’s duties.


**1.14.5.3.4** **(03-03-2025)**

#### Chemicals

1. A Hazard Communication Program (HazCom) in compliance with 29 CFR 1910.1200, must be implemented for employees who work with or near hazardous chemicals. The local FMSS SO can provide the written program. Safety Data Sheets (SDS) are available on the IRS SharePoint site or can be provided directly to an employee if requested. The hazard communication program includes:



1. A list of the hazardous chemicals in the workplace.

2. SDS for each chemical.

3. Provisions for container labeling.

4. Employee training for employees who work with or near hazardous materials.

5. Methods used to inform employees of the hazards of non-routine tasks and the hazards associated with chemicals in unlabeled pipes in their work areas.

6. A description of methods used at a multi-employer worksite to communicate hazards to or caused by employees of other companies.


2. Every chemical that is brought into IRS-controlled space, including chemicals purchased and used by janitorial staff, contractors, and building owners and operators, must be properly labeled and the Safety Data Sheets (SDS) must be shared with the FMSS SO. Aerosols will only be allowed if no alternative process or product is available.

3. Employees are not authorized to bring personally owned chemicals into the workplace.

4. Where the eyes or body of an employee or contractor may be exposed to injurious corrosive materials, suitable facilities for quick drenching or flushing of the eyes and body (e.g., eye wash, shower) must be provided within the work area for immediate emergency use.

5. When a regulation requires initial employee exposure assessment, representative exposure assessments will be conducted by an industrial hygienist and arranged by contacting the FMSS EHS HQ staff.


**1.14.5.3.5** **(09-13-2021)**

#### Cranes

1. In facilities that IRS has delegated operations and maintenance authority, overhead cranes and rigging must be maintained, inspected, and operated in compliance with 29 CFR 1910.179 and 29 CFR 1910.184.

2. Only trained personnel who are designated in writing are permitted to operate an IRS-controlled crane.


**1.14.5.3.6** **(03-03-2025)**

#### Electrical Safety

1. Electrical wiring and equipment must be examined, installed, and used in compliance with 29 CFR 1910.303 Subpart S.

2. Employees should report damaged or otherwise unsafe electrical conditions such as:



1. Frayed, cut, or otherwise damaged insulation.

2. Electrical cords run through walls, ceilings, floors, or doors.

3. Circuit breakers that repeatedly trip.

4. Extension cords in place for more than temporary use (i.e., more than 90 days) or being used with permanent equipment.

5. Daisy chaining of any cords, surge protectors or power strips.

6. Surge protectors, power strips and electrical outlets that are overloaded or warm to the touch.

7. Equipment other than IRS-supplied computer components plugged into partition or system furniture dividers.


3. Employees must report any electrical shock to their supervisor and the ERC, regardless of severity.



### Note:



An electrical shock is a warning that electrical equipment is faulty and must be repaired or taken out of service.

4. Non-IRS supplied appliances:



1. In accordance with 41 CFR 102-74.190, employees may not bring personally owned appliances into an IRS office or facility unless the appliance is inspected and approved by the Building Manager or other designated FMSS personnel.

2. Appliances requested under the Reasonable Accommodation Program will be evaluated on a case-by-case basis and may be approved by the Building Manager for use.

3. Refrigerators, microwave ovens and similar appliances must be located in break rooms where these areas are provided for employees. An exception may be made when approved by the Building Manager.

4. Coffee pots, air purifiers, and fans may be permitted in the work area if inspected and approved by the Building Manager or other appropriate Health, Safety, or Fire professional.

5. Appliances that are currently located in work areas may remain after the appliances are inspected and approved.

6. Inspection and approval of appliances is intended to reduce the risk of electrical shock, electrical circuit overload or fire.

7. Inspection of appliances includes but is not limited to, insulation, grounding, and circuit capacity.


### Note:

GSA will not allow personally owned appliances such as cooking appliances, toasters, hot plates etc. for use in office space, cubicle space, break rooms, kitchenettes or anywhere in the building. Personal heaters are generally banned from use. The reason for not allowing their use is that these items have exposed heating elements and are a leading cause of fires.

**1.14.5.3.7** **(09-13-2021)**

#### Ergonomics Musculoskeletal Disorders (MSD)

1. Many jobs have the potential to generate musculoskeletal problems due to ergonomic risk factor, such as excessive physical force, high task repetition, and awkward work postures.

2. Ergonomic furniture is provided in all workstations to reduce or prevent musculoskeletal injuries.

3. If requested, the local FMSS SO can provide an Ergonomic Assessment or instruct employees how to self-assess their workstation for optimal positioning.

4. When employees are initially assigned to a position or reassigned to another position that imposes high musculoskeletal loads, their manager will ensure they are:



1. Informed about the ergonomic risk factors associated with the jobs that they are expected to perform.

2. Educated about the most common types of MSD, their signs and symptoms, and the importance of early reporting of MSD symptoms.

3. Trained in methods that may control ergonomic risk factors.

4. Understanding of the requirement to report all work-related MSD using ECOMP.


**1.14.5.3.8** **(09-13-2021)**

#### Fall Protection

1. Employees who are exposed to a fall hazard of four feet or more to a surface below or a fall hazard into dangerous machinery from any height will be provided with fall protection.

2. The preferred fall protection method is an engineering control such as standard railings or elimination of the fall hazard from the workplace.

3. The second choice for fall protection is a personal fall arrest system. The purchase and use of personal fall arrest equipment must be reviewed by an IRS Industrial Hygienist who may work with fall protection specialists to develop and approve the fall protection plan for the specific task the fall arrest system is intended for:



1. A personal fall arrest system consists of a bull body harness, connectors, and an anchorage capable of supporting at least 5,000 pounds.

2. Alternatively, a personal fall arrest system must be designed and installed under the supervision of a qualified person as part of a complete personal fall arrest system, which maintains a safety factor of at least two (e.g., will support at least twice the maximum force in a fall).

3. All free falls must be limited to nor more than six feet.

4. Body belts are prohibited for fall arrest.


4. When standard railings and personal fall arrest systems are infeasible or create a greater hazard, a written fall protection plan must be prepared showing the method used to provide equivalent protection from falls.

5. Restraints:



1. Whenever possible, personal fall protection systems should be designed to prevent an employee from reaching the fall hazard (e.g., edge of the roof).

2. When the employee is restrained and cannot reach the fall hazard, the anchor point may be less than 5,000 pounds, but must be at least 200 pounds, such as a standard railing.


6. Protection from falling objects:



1. Where persons work under or pass under a work area, a method to prevent tools and materials from falling on these persons must be provided.

2. The overhead protection can be a solid canopy, a barricade for the area, or it can be toe boards, screens, or mesh from the top rail to the walking/working level and along the entire opening between top rail supports.

3. Employees will not work in or pass under a work area (including ladders) where a hazard from falling objects could occur, unless a method to prevent tools and materials from falling on these persons is provided.


7. Ladders:



1. Additional fall protection is not required for fixed ladders that are 20 feet long or less.

2. Fixed ladders that are more than 20 feet long must have landing platforms, ladder safety devices, or cages.

3. Portable ladders that are more than 20 feet long should be used with caution and always used with another person present to assist.

4. All ladders must be used in compliance with the manufacturer’s requirements and OSHA regulations.


**1.14.5.3.9** **(03-03-2025)**

#### Fire Safety

1. Fire Prevention: IRS building management and employees must strive to prevent fire hazards through proper handling and storage procedures for hazardous materials and potential ignition sources.



1. Long-term accumulations of flammable and combustible materials are not allowed.

2. Safeguards installed on heat-producing equipment to prevent the accidental ignition of combustible materials must be regularly inspected and maintained.

3. Any IRS approved materials must be non-combustible.


2. IRS employees and IRS-controlled contractors must:



1. In case of a fire emergency evacuation, keep exits, access to exits and emergency equipment clear at all times.

2. Not bring hazardous, explosive, or combustible materials in the building unless authorized by appropriate agency officials and/or by GSA.

3. Not block, hang, or otherwise obscure entry or exit from cubicles.

4. Ensure draperies, curtains or other hanging materials are of non-combustible or flame-resistant fabric.

5. Promptly report fires or suspected fires by sounding the alarm and reporting the location.

6. In case of a fire, IRS employees are to exit the building and not attempt to combat the fire including the use or discharge of a portable fire extinguisher.



      ### Note:



      Unless annually trained and certified through the IRS, IRS employees are not authorized to use or discharge portable fire extinguishers.


3. Inspection, Testing and Training:



1. Fire detection and suppression systems/equipment must be inspected at least annually by qualified persons and maintained in safe operating condition.

2. Portable fire extinguishers must be visually inspected monthly and must be subjected to an annual maintenance check.

3. In leased space, these requirements are part of the lease agreement and are the responsibility of GSA and the building owner.

4. Any person expected to use a fire extinguisher, must be trained in their use upon initial assignment to the job and at least annually.


**1.14.5.3.10** **(03-03-2025)**

#### First Aid

1. Some IRS facilities have health clinic staff by a Federal Occupational Health (FOH) nurse, where employees may receive first aid.

2. For smaller IRS facilities that do not have a health clinic or when the clinic is closed, first aid and emergency medical service must be available within 15 minutes from an ambulance service, infirmary, clinic, or hospital.



1. In the absence of nearby emergency medical service, a person or persons must be adequately trained to render first aid. The Human Capital Office (HCO) provides funds and manages first aid training.


3. Adequate first aid supplies must be readily available in IRS facilities where a health clinic is not available.



1. FMSS supplies an initial first aid kit for Business Units.

2. Business Units are responsible for checking inventory and resupplying first aid kit supplies. As agreed to in Article 27 Section 5, managers will designate employees from among volunteers to maintain the kits.


4. For further information regarding FOH clinics or first aid training, contact the Human Capital Office. For information on the Automated External Defibrillators (AED) program, contact Senior Continuity Representatives.


**1.14.5.3.11** **(09-13-2021)**

#### Hearing Conservation

1. When information indicates that an employee’s noise exposure may equal or exceed an eight-hour Time-Weighted Average (TWA) of 85 decibels (dB), noise monitoring must be performed in compliance with 29 CFR 1910.95(d).

2. If noise monitoring indicates that an employee is exposed to 8-hour TWA of 85 dB measured on the A scale (slow response), or if an employee is exposed to impact noise above 140 dB, then the employee must be included in the Hearing Conservation Program.

3. To the maximum extent possible, engineering controls will be used to reduce noise exposure. Where this is not operationally possible or practical, administrative controls and hearing protection devices must be used to reduce noise exposure to acceptable levels.

4. A Hearing Conservation Program must include:



1. An audiometric testing program

2. A choice of hearing protectors which will attenuate employee exposure to no more than an 8-hour TWA or 90 dB or less

3. Annual training; and

4. Periodic program assessment


**1.14.5.3.12** **(03-03-2025)**

#### Indoor Environmental Quality (IEQ)

01. There are few regulations that apply to indoor environmental air quality in office areas. However, the IRS recognizes that a comfortable and healthy workplace is important. Below are the guidelines the IRS will strive to meet.

02. Temperature and Relative Humidity:



    1. The air in occupied offices will be maintained within the ranges found in the American Society of Heating, Refrigerating, and Air-Conditioning Engineers (ASHRAE) Standard 55, Thermal Environmental Conditions for Human Occupancy. These ranges are applicable for persons clothed in typical summer and winter clothing, at light mainly sedentary activity:


**i. In Summer Months:**

| For a relative humidity of | The temperature should be from | to (degrees in Fahrenheit) |
| --- | --- | --- |
| 30% | 74.0 | 80.0 |
| 40% | 73.5 | 79.5 |
| 50% | 73.0 | 79.0 |
| 60% | 72.5 | 78.0 |

**ii. In Winter Months:**

| For a relative humidity of | The temperature should be from | to (degrees in Fahrenheit) |
| --- | --- | --- |
| 20% | 70.0 | 78.0 |
| 30% | 68.5 | 76.0 |
| 40% | 68.5 | 75.5 |
| 50% | 68.5 | 74.5 |
| 60% | 68.0 | 74.0 |

03. Carbon Dioxide:



    1. Carbon dioxide, at the concentrations found in an office setting, is not a health risk. Carbon dioxide is used as an indicator that there is enough fresh air entering the workspace for the number of persons occupying the workspace.

    2. The OSHA Permissible Exposure Limit (PEL) for carbon dioxide is 5000 parts per million (ppm).

    3. IRS will strive to limit carbon dioxide levels to no more than 700 ppm over background (outside air).


04. Carbon Monoxide:



    1. Carbon monoxide is a dangerous by-product of combustion engines that can cause asphyxiation.

    2. The OSHA PEL for carbon monoxide is 50 ppm.

    3. The IRS will strive to limit indoor carbon monoxide concentrations to no more than 9 ppm.

    4. Although 9 ppm carbon monoxide does not constitute an emergency, if detected about this level in an IRS occupied area, a search much be initiated immediately to locate the source and correct it.


05. Cleaning Products:



    1. The IRS will strive to ensure that low volatile organic compound (VOC), low toxicity cleaning products are used in IRS occupied workspaces.

    2. SDS will be available to employees to review for cleaning products that are used in their workplace.

    3. Aerosol spray products should be replaced with wipe and/or pump spray products.


06. Lighting:



    1. Lighting for IRS work areas will comply with 41 CFR 102-74.180.

    2. Standard lighting at workstation (desks) surfaces during working hours should be 30-50 foot-candles, measured at a height of 30 inches above floor level.

    3. Exit signs must be self-luminous or electrically illuminated.

    4. Each exit route must be adequately lighted so that an employee with normal vision can see along the exit route.


07. Mold:



    1. The IRS will strive to control and reduce mold spore levels to concentrations and species that are lower than or similar to outdoor local levels. Visible mold will be cleaned and/or removed from indoor areas of IRS space.

    2. Sampling for mold spores is not required for visible mold.

    3. Sampling for mold spores may be recommended by an industrial hygienist after mold remediation is completed to ensure clean up parameters are met.


08. Pesticides:



    1. Pesticides may be used in limited amounts to control identified pests as part of an Integrated Pest Management program.

    2. When possible, a non-chemical control of pests must be used. These methods include, but are not limited to traps, sticky pads, and vacuuming.

    3. When pesticides are applied, information about the pesticide (e.g., SDS) will be made available to the FMSS SO prior to pesticide application.

    4. SDS will be made available to employees to review prior to the pesticide application.

    5. Employees must keep food and drinks in sealed containers.


09. Plants:



    1. Live plants, if allowed, must be kept in a healthy condition or removed. Plants that exhibit signs of insect infestation, mold or other signs of decay must be removed immediately.

    2. Plants may not have standing water in their pots.


10. Building Materials and Furnishings:



    1. The IRS will strive to ensure that low odor, low toxicity products are used in IRS occupied workspaces.

    2. Off gas time will be allowed for freshly painted surfaces, fabric covered chairs and wall coverings before an area is opened/reopened for workplace occupancy.

    3. The SDS will be available to employees to review for materials that are used in their workplace.

    4. The IRS Pre-Construction Impact Assessment and communication procedures should be used to monitor and control hazards during construction and/or renovation work in IRS occupied workspaces.


**1.14.5.3.13** **(09-13-2021)**

#### Inspections, Audits and Self-Assessments

1. Occupational health and safety compliance audits will be conducted at appropriate (e.g., major) IRS facilities or organizations in order to verify compliance with applicable laws and regulations, executive orders, and IRS policies:



1. Audits will include appropriate tenant, contractor, and concessionaire activities.

2. Audits will be conducted no less than once every three years after the initial audit.

3. Possible root cause of non-compliance will be included with audit findings.

4. In order to comply with the 29 CFR 1960.79 requirement for program self- evaluations, self-assessments will be conducted during years when an external audit is not performed.


2. External Regulatory Compliance Inspections:



1. IRS employees must cooperate fully with federal, state, and local safety and health inspectors.

2. A copy of each notice of violation, compliance agreement, administrative order, consent order, or equivalent document (regarding safety or health at a facility) issued by a federal, state, or local regulatory enforcement organization must be forwarded to the EHS Chief within three days of receipt of the document.

3. A copy of each OSHA Alleged Hazard letter, notice of violation, and response/compliance agreement will be posted as required by OSHA and the Union notified.


3. Safety Inspections:



1. Safety inspections are conducted in all IRS occupied buildings at least once each calendar year.

2. Hazards identified during inspections that cannot be corrected immediately and require resolution are submitted as an IRWorks case and tracked by the FMSS SO.

3. At a telework work site, it is the responsibility of the employee to ensure a safe work environment.

4. Telework work environments are exempt from IRS annual inspections.


4. Results of inspections, audits, and self-assessments will be used to develop procedures for correcting and improving the program and will be considered in the preparation and revision of program budgets and plans.


**1.14.5.3.14** **(09-13-2021)**

#### Job Hazard Analysis

1. A written and certified Job Hazard Analysis, in compliance with 29 CFR 1910.132, will be prepared for each job that may require the use of personal protective equipment administrative or engineering control or is required by a regulation or standard.

2. A Job Hazard Analysis is recommended for each job that meets one or more of the following:



1. Has had environmental emergencies, injuries, or illnesses associated with it or has experienced significant incidents or near misses.

2. Has the ability to cause severe or disabling injury or illness, even if no previous history of injury or illness exists.

3. Is perceived as a high-hazard task (for example, it could result in a catastrophic explosion, electrocution, chemical over exposure, or spill).

4. Is a new job or is an existing job that has undergone change in process or procedure.

5. Is a job that is complex enough to require written procedures.

6. Has been identified by other studies.


3. The written Job Hazard Analysis will identify the workplace evaluated, the person certifying that the evaluation has been performed, and the date(s) of the hazard assessment, which identifies the document as an IH certification of hazard assessment.


**1.14.5.3.15** **(09-13-2021)**

#### Lockout and Tagout (Control of Hazardous Energy)

1. IRS employees and contractors who perform service, maintain, or repair machines or equipment or use the machines or equipment must comply with 29 CFR 1910.147 which includes a written lockout procedure for each type of machine or equipment.

2. IRS employees must not use tagout alone. It is recommended that tags be used with locks to provide information about who placed the lock and how to reach him or her.

3. Lockout/tagout locks and tags may not be used for other purposes.

4. An inspection of each energy control procedure must be performed and certified at least annually.

5. Authorized employees:



1. Are employees who are certified to service, maintain, or repair machines or equipment.

2. Must follow lockout/tagout procedures if they remove or bypass a machine’s guards or other safety devices, place any part of their bodies in or near a machine’s point of operations, or place any part of their bodies in a danger zone associated with machine operations.


6. Affected employees:



1. Are usually the operators of the machines or equipment.

2. Must be instructed in the purpose and use of the energy control procedure.


7. Other employees whose work operations are or may be in an area where energy control procedures may be utilized, must be instructed about the procedure, and about the prohibition relating to attempts to restart or reenergize machines or equipment which are locked out or tagged out.


**1.14.5.3.16** **(09-13-2021)**

#### Permit-Required Confined Spaces

1. In facilities where IRS has delegated operations and maintenance authority, IRS will:



1. Identify the permit-required confined spaces (also called permit spaces) under IRS control. Permit-required confined spaces at IRS facilities include, but may not be limited to electrical, sewage and storm sewer manholes; boilers; fuel tanks and oil-water separators. Permit-required confined spaces are confined spaces with one or more of the following characteristics:


       i. Contains or has a potential to contain hazardous atmosphere.


       ii. Contains a material that has the potential for engulfing an entrant.


       iii. Has an internal configuration such that an entrant could be trapped or asphyxiated by inwardly converging walls or by a floor which slopes downward and tapers to a smaller cross-section.


       iv. Contains any other recognized serious safety or health hazard.

2. Post danger signs to notify employees and others of the existence and location of and the danger posed by permit spaces. Manholes for utilities do not require a posted sign.


2. IRS employees are prohibited from entering permit-required confined spaces.

3. Contractors are prohibited from entering IRS-controlled permit-required confined spaces unless they are covered by a written Permit-required Confined Space Program.


**1.14.5.3.17** **(03-03-2025)**

#### Personal Protective Equipment (PPE)

1. If hazards that necessitate the use of PPE, are present or are likely to be present, a job hazard analysis conducted by an industrial hygienist, must be used to determine the correct equipment.

2. When possible, hazards will be controlled or eliminated using engineering controls, such as ventilation or guarding. The second choice for controlling hazards is the use of administrative controls. Administrative controls are training procedures or a shift in the work design to lessen the threat of a hazard to a person. Lastly, PPE may be used when the other controls do not fully control the hazards or while the other controls are being implemented.

3. The IRS will assess the workplace to determine if hazards that necessitate the use of PPE, are present or are likely to be present and conduct a job hazard analysis in accordance with 29 CFR 1910.132 When PPE is selected as part of a job hazard analysis:



1. The selection decisions must be communicated to each affected employee.

2. The PPE must properly fit each affected employee.

3. Training must be provided to each employee who is required to wear or use PPE.


4. Defective or damaged PPE must not be used.

5. Any acquisition of PPE must be reviewed and approved by FMSS EHS HQ.

6. Latex gloves and other latex products should not be used in IRS-controlled space because of common and often severe allergies.

7. Respirators:



1. If employees are required to wear respirators, they must be included in a Respiratory Protection Program in compliance with 29 CFR 1910.134.

2. This includes respirators maintained for emergency use.

3. Where respirators are not required, employees who voluntarily wear filtering facepiece respirators (dust masks) must be provided with the information contained in 29 CFR 1910.134, Appendix D, Information for employees Using Respirators When Not Required Under the Standard.



      ### Note:



      For additional information, contact the local FMSS SO.


**1.14.5.3.18** **(09-13-2021)**

#### Private Employer Workspace

1. IRS employees who work in establishments of private employers are covered by the IRS EHS Program.

2. IRS is required to ensure safe and healthful working conditions for their employees.


**1.14.5.3.19** **(09-13-2021)**

#### Power Industrial Trucks and Pallet Jacks

1. Powered-industrial trucks (including but not limited to forklifts, walker-type or motorized pallet jacks, golf carts, and personal lifts) operated by IRS employees and IRS controlled contractors must comply with maintenance, operation, and training regulations in 29 CFR 1910.178.

2. Employees, contractors, and vendors who operate powered industrial trucks must be trained and certified.

3. Refresher training is required when:



1. The operator has been observed to operate the vehicle in an unsafe manner.

2. The operator has been involved in an accident or near-miss incident.

3. The operator has received an evaluation that reveals that the operator is not operating the truck safely.

4. The operator is assigned to drive a different type of truck.

5. A condition in the workplace changes in a manner that could affect safe operation of the truck.


4. At a minimum, an evaluation of each powered industrial truck operator’s performance must be conducted every three years.


**1.14.5.3.20** **(09-13-2021)**

#### Reasonable Accommodations

1. A reasonable accommodation for one employee must not create a hazard for other employees.


**1.14.5.3.21** **(03-03-2025)**

#### Reporting and Recordkeeping

1. Unsafe and Unhealthy Conditions:



1. It is the right and responsibility of all employees to report hazardous conditions that have the potential for causing injury, illness, or property damage.

2. Report unsafe and unhealthy conditions immediately to your supervisor and to IRWorks. The ERC can be contacted toll-free at (866-743-5748); by TTY at (866-924-3578).

3. No employee will be subject to restraint, interference, coercion, discrimination, or reprisal as a result of filing a report of unsafe or unhealthy conditions or participating in other IRS EHS Program activities.


2. Injury and Illness Recording and Reporting:



1. IRS injury and illness recording and reporting requirements must comply with the requirements under 29 CFR 1904, subparts C, D, E, and G, except that the definition of “establishment” found in 29 CFR 1960.2(h) will remain applicable to the IRS.

2. Within seven calendar days of receiving information that a recordable injury or illness has occurred, the employee, immediate supervisor, or FMSS SO must enter the known information into ECOMP.

3. The FMSS SO must complete an injury/illness incident report within seven calendar days after receiving information that a work-related injury or illness has occurred.

4. A record or log of all occupational injuries and illnesses must be maintained by the FMSS SO for each establishment or facility.

5. The immediate supervisor of the injured or ill employee must keep track of and report the number of days away from work and/or the number of days of restricted duty or job transfer due to a recordable injury or illness.

6. The number of days away from work and the number days of restricted duty or job transfer due to a recordable injury or illness must be recorded into ECOMP.

7. An annual summary of injuries and illnesses must be completed for each facility by the local FMSS SO and posted in a visible location at that facility between February 1 and April 30 each year.

8. Incidence rate(s) for accidents or lost work day injury or illness will be calculated using: Rate=(number of cases)x(200,000)/total population at risk. If the specific total population at risk is not available, use 2,000 as the denominator.

9. The DSHO or designee (e.g., TM, FMSS) must certify that the annual summary is correct.


3. Reporting Accidents and Injuries Involving Motor Vehicles



1. Employees must report accidents that occur on official business in a Government-Owned Vehicle (GOV), rental, or Personally Owned Vehicle (POV) to their supervisor and the ERC immediately as detailed in IRM 1.14.7.2.9, Motor Vehicle Fleet Management Program. They must also fill out the [SF91](https://www.gsa.gov/reference/forms/motor-vehicle-accident-crash-report), Motor Vehicle Accident (Crash) Report and send the completed form to their supervisor and local FMSS SO.

2. The FMSS SO must forward a copy of each [SF91](https://www.gsa.gov/reference/forms/motor-vehicle-accident-crash-report), Motor Vehicle Accident (Crash) Report to the IRS Claims Manager.


4. Fatal and Catastrophic Accident Reports (also refer to section _IRM 1.14.5.3.1_ of this IRM):



1. Immediately after a fatality or catastrophic accident, notify management, the ERC, and the local FMSS SO.

2. OSHA requires the reporting within eight hours after the death of an IRS employee from a work-related incident or within 24 hours of an inpatient hospitalization of one or more IRS employees, or an amputation, or loss of an eye if it is a result of a work-related incident.


5. Annual Report



1. Annually, a report describing the IRS occupational health and safety program of the previous fiscal year and objectives for the current fiscal year must be submitted to Department of the Treasury.

2. The report must include a summary of the Agency’s self-evaluation findings as required by 29 CFR 1960.78(b).

3. The Department of the Treasury compiles a department report, which must be submitted to the Secretary of Labor by January 1 of each year.


**1.14.5.3.22** **(09-13-2021)**

#### Welding, Cutting, Brazing and Other Hot Work

1. Welding, cutting, brazing, and other hot work performed by IRS-controlled contractors must comply with maintenance, operation, and training regulations in 29 CFR 1910, Subpart Q.

2. IRS employees are not permitted to perform hot work.

3. Before hot work is performed, a hot work permit must be issued by the Building Manager. Employee and other persons working in the vicinity must be protected and a fire watch established.


**1.14.5.4** **(09-13-2021)**

### Workers’ Compensation Claims and Tort Claims Guidance

1. If an employee elects to file a medical or lost work time claim after completing the ECOMP First Report of Injury Form 301, the employee or supervisor must follow instructions provided by HCO on the Workers’ Compensation webpage or telephone 800-234-8323.

2. A non-federal person (e.g., visitor, contractor) who is injured or has property damage and wishes to file a claim must be provided with Form 5646, Claim for Damage, Injury or Death (i.e., Tort Claim) as instructed in IRM 1.14.7.2.9.



### Note:



For further information, contact the IRS Claims Manager at 202-317-6999.

3. Basic instructions and forms used for processing Tort Claims at the IRS can be found by contacting: General Legal Services (GLS) Claims Management IRS Claims Manager, Office of Chief Counsel, General Legal Services (CC:GLS:CLP), 1111 Constitution Avenue, NW - Room 6404, Washington, DC 20024.

4. Treasury Inspector General for Tax Administration (TIGTA) Office of Investigations (OI) may conduct tort investigations of accidents involving IRS employees or activities on official business. See Chapter 400, Section (400)-310 Federal Tort Claims Investigations of the TIGTA Operations Manual for detailed information.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-005#addtoany "Show all")

A2A