---
url: "https://www.irs.gov/irm/part1/irm_01-005-002"
title: "1.5.2 Uses of Section 1204 Statistics | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-005-002#main-content)

- 1.5.2  [Uses of Section 1204 Statistics](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419570679120)
  - 1.5.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419570784704)
  - 1.5.2.2  [Background](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419570772064)
  - 1.5.2.3  [Authorities](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419570752992)
  - 1.5.2.4  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419570748672)
  - 1.5.2.5  [Terms and Definitions](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419570734928)
  - 1.5.2.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419570711200)
  - 1.5.2.7  [Restructuring and Reform Act of 1998 (RRA 98) Section 1204](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569718048)
  - 1.5.2.8  [Regulation 801](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569714112)
  - 1.5.2.9  [Section 1204 Employee](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569632416)
    - 1.5.2.9.1  [Exercise of Judgment](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569627712)
    - 1.5.2.9.2  [Imposing a Production Quota or Goal](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569607120)
    - 1.5.2.9.3  [Suggesting a Production Quota or Goal](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569602416)
  - 1.5.2.10  [Tax Enforcement Results (TERs)](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569590208)
    - 1.5.2.10.1  [Permitted Use of TERs](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569579584)
    - 1.5.2.10.2  [Prohibited Use of TERs](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569565440)
  - 1.5.2.11  [Records of Tax Enforcement Results (ROTERs)](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569557216)
    - 1.5.2.11.1  [Permitted Use of ROTERs](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569549120)
    - 1.5.2.11.2  [Prohibited Use of ROTERs](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569539472)
    - 1.5.2.11.3  [One or More Cases](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569533696)
  - 1.5.2.12  [Quantity Measures](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569528000)
    - 1.5.2.12.1  [Permitted Use of Quantity Measures](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569519696)
    - 1.5.2.12.2  [Prohibited Use of Quantity Measures](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569514432)
  - 1.5.2.13  [Quality Measures](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569506032)
    - 1.5.2.13.1  [Permitted Use of Quality Measures](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569499408)
  - 1.5.2.14  [Sharing Data](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569494800)
  - 1.5.2.15  [Section 1204 and Regulation 801 Decision Table](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569486496)
  - Exhibit  1.5.2-1  [Section 1204 and Regulation 801 Decision Table](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569468560)
  - Exhibit  1.5.2-2  [Questions and Answers for Small Business/Self-Employed and Wage and Investment Operating Divisions](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569426496)
  - Exhibit  1.5.2-3  [Small Business/Self-Employed (SB/SE) and Wage and Investment (W&I) Operating Divisions Section 1204 Work Activity Determination Matrix](https://www.irs.gov/irm/part1/irm_01-005-002#idm140419569348016)

# Part 1. Organization, Finance, and Management

# Chapter 5. Managing Statistics in a Balanced Measurement System

# Section 2. Uses of Section 1204 Statistics

* * *

## 1.5.2 Uses of Section 1204 Statistics

#### Manual Transmittal

October 26, 2022

#### Purpose

(1) This transmits revised IRM 1.5.2, Managing Statistics in a Balanced Measurement System, Uses of Section 1204 Statistics.

#### Material Changes

(1) The Section 1204 program ownership is updated to reflect the IRS Human Capital Office.

(2) Added IRM 1.5.2.1, Program Scope and Objectives.

(3) Updated IRM 1.5.2.8, Regulation §801.5 Employee satisfaction measures effective date.

(4) Updated Exhibit 1.5.2-2, Questions and Answers for Small Business/Self-Employed and Wage and Investment Operating Divisions.

(5) Minor grammatical edits were made throughout the IRM.

#### Effect on Other Documents

IRM 1.5.2 dated May 19, 2017, is superseded.

#### Audience

All IRS executives, managers, and employees.

#### Effective Date

(10-26-2022)

Kevin Q. McIver

IRS Human Capital Officer

**1.5.2.1** **(10-26-2022)**

### Program Scope and Objectives

1. **Purpose:**This IRM provides guidance on the processes and procedures that apply to the Section 1204 program. The IRS regulations on the use of statistics are designed to make sure that records of tax enforcement results (ROTERs) are not used to improperly influence the handling of taxpayer cases. These rules reinforce the requirement that employees make decisions on pursuing enforcement of the tax laws (including but not limited to determining tax liability and ability to pay) that are based solely on the correct application of the law to the facts of each case and the exercise of reasonable administrative judgment in light of the circumstances of each taxpayer. This IRM:



1. Contains general background information on the use of enforcement statistics.

2. Defines key terms under Section 1204.

3. Provides detailed procedures on the use of ROTERs.

4. Explains the Section 1204 prohibited and permitted use of ROTERs.


2. **Use:** Use this IRM to determine:



1. Whether the use of a statistic is a ROTER.

2. Whether the way a ROTER is used violates Section 1204.

3. Allowable and unallowable uses of quantity and quality measures.


3. **Audience:** The policy and procedures apply to the managers and employees responsible for enforcing tax laws fairly and equitably.

4. **Program Owner:** The Human Capital Office (HCO), Office of HR Strategy (OHRS), Policy and Audits (P&A).

5. **Primary Stakeholders:** The Independent Office of Appeals (Appeals),Criminal Investigation (CI), Large Business and International (LB&I), Small Business/Self Employed (SB/SE), Taxpayer Advocate Service (TAS) ,Tax Exempt and Government Entities (TE/GE) and Wage and Investment (W&I).

6. **Policy Owner:**The IRS Human Capital Office is responsible for this IRM.


**1.5.2.2** **(01-14-2015)**

### Background

1. Section 1204 of the IRS Restructuring and Reform Act of 1998 (RRA 98) was put into place to ensure IRS manages statistics to protect taxpayer rights:



1. Section 1204(a) prohibits the IRS from using any ROTER to evaluate employees or to impose or suggest production quotas or goals.

2. Section 1204(b) requires that employees be evaluated using the fair and equitable treatment of taxpayers as a performance standard.

3. Section 1204(c) requires each appropriate supervisor to self-certify quarterly whether ROTERs were used in a prohibited manner.


2. Our system of taxation depends on the taxpayers' belief that:



1. The tax laws they follow apply to everyone.

2. The IRS will respect and protect their rights under the law.


3. In July 1998, Congress passed the Internal Revenue Service Restructuring and Reform Act of 1998 (RRA 98), Pub. L. No. 105-206, 112 Stat. 685 (1998).

4. RRA 98, Section 1201, establishes an IRS performance management system with goals or objectives for individual, group, or organizational performance.

5. RRA 98, Section 1201, Subpart I, Chapter 95, Section 9508, addresses a general workforce performance management system in lieu of the performance appraisal system established under 5 USC, §4302. It states that the Secretary of the Treasury shall, within one year after the date of enactment of this section, establish an IRS performance management system that maintains individual accountability by:



1. Establishing one or more retention standards for each employee related to the work of the employee and expressed in terms of individual performance, and communicating such retention standards to employees.

2. Making periodic determinations of whether each employee meets or does not meet the employee’s established retention standards.

3. Taking actions, in accordance with applicable laws and regulations, with respect to any employee whose performance does not meet established retention standards, including denying any increases in basic pay, promotions, and credit for performance under 5 USC, §3502.


6. RRA 98, Section 1204, prohibits the use of ROTERs to evaluate or to impose or suggest production quotas or goals for **any** IRS employee.

7. Title 26 Code of Federal Regulations, Part 801 (Regulation 801), establishes an overall IRS performance measurement system and governs the use of ROTERs. Regulation 801 supports Section 1204 by prohibiting the use of ROTERs to improperly influence the handling of taxpayer cases.

8. In October 2005, Regulation 801 was revised to allow imposing or suggesting quantity goals for organizational units. The revision authorizes using quantity measures to evaluate the performance of supervisory employees, non-Section 1204 employees, and organizational units. The amended regulation:



1. Continues to provide that performance measures, based in whole or in part on quantity measures, **will not** be used to evaluate the performance of any non-supervisory employee who is responsible for exercising judgment with respect to tax enforcement results (TERs).

2. Does not alter in any way the RRA Section 1204 prohibition on the use of ROTERs to evaluate employee performance or to impose or suggest production quotas or goals for any employee.


9. The performance evaluation aspects of the IRS Section 1204 program migrate into the performance management area. According to IRM 6.430, Performance Management integrates the processes that the IRS uses to:



1. Communicate and clarify organizational goals to employees.

2. Identify individual and, where applicable, team accountability for accomplishing organizational goals.

3. Identify and address developmental needs for individuals and/or teams.

4. Assess and improve individual, team, and organizational performance.

5. Use appropriate measures of performance as the basis for recognizing and rewarding accomplishments.

6. Use the results of performance appraisals as a basis for appropriate personnel actions.


**1.5.2.3** **(10-26-2022)**

### Authorities

1. IRM 1.5.1, The IRS Balanced Performance Measurement System.

2. IRM 1.5.3, Manager's Self-Certification and the Independent Review Process.

3. IRM 1.5.5, Section 1204 and Regulation 801 Guidance for Criminal Investigation (CI).

4. IRM 1.5.8, Guidance for Taxpayer Advocate Service (TAS).

5. IRM 6.430, Performance Management.

6. [26 CFR 801, Balanced System for Measuring Organizational and Employee Performance Within the Internal Revenue Service](http://www.gpo.gov/fdsys/pkg/CFR-2012-title26-vol20/pdf/CFR-2012-title26-vol20-chapI.pdf)


**1.5.2.4** **(10-26-2022)**

### Responsibilities

1. The IRS Section 1204 program requires the cooperation and assistance of many IRS organizations.

2. **IRS Business Units** \- Implement the Section 1204 program in their respective areas; provide managers' quarterly self-certification reporting, and assist the Human Capital Office (HCO) in various program aspects, e.g., the HCO Independent Review.

3. **Human Capital Office (HCO)** \- Manages the Section 1204 program and provides human capital strategies and tools for recruiting, hiring, developing, retaining, and transitioning a highly-skilled and high-performing workforce to support IRS mission accomplishments.



1. **Human Capital Officer** \- Is the highest executive responsible for the Section 1204 Program.

2. **HCO Office of HR Strategy** \- Provides servicewide training delivery services and training technology support in the Integrated Talent Management System (ITM), leadership and cross-functional training programs, training policy guidance, and quality assurance for all IRS training.

3. **HCO Office of HR Operations** \- Manages the IRS performance management system (HR Connect) and identifies the IRS Section 1204 employee population.


4. **Treasury Inspector General for Tax Administration (TIGTA)** \- Completes the annual Mandatory Review of IRS Compliance With Restrictions on the Use of Enforcement Statistics.

5. **General Legal Services (GLS)** \- Reviews and confirms ROTERs identified in the TIGTA audit and HCO Independent Review. Also provides guidance in response to HCO questions concerning Section 1204 law.


**1.5.2.5** **(10-26-2022)**

### Terms and Definitions

01. The following terms and definitions apply to this program and are used throughout this IRM.

02. **Appropriate supervisor** is the Section 1204 executive in an operating/functional division that directly or indirectly supervises one or more Section 1204 employees. An appropriate supervisor can identify additional appropriate supervisors.

03. **Employee evaluation** includes any written document used to appraise or measure an employee's performance to provide:



    1. Required or requested performance rating (annual, mid-year, ad hoc).

    2. Recommendation for an award.

    3. Assessment of an employee's qualifications for promotion, reassignment or other change in duties.

    4. Assessment of an employee's eligibility for incentives, allowances or bonuses.

    5. Ranking of employees for release/recall and reductions in force.


### Note:

See Regulation §801.3(e)(1)(ii). The definition of an "employee evaluation" specifically includes only the five items above. This definition indicates when/where to use TERs and that ROTERs cannot be used. Individual case reviews, progress reviews and workload reviews, are excluded in this definition.

04. **Exercise of judgment** in applying tax law is the process of making decisions to **recommend** or **determine whether or how** the IRS should pursue enforcement of the tax law, including but not limited to the taxpayer's tax liability or ability to pay. The result is that reasonable people handling the same type cases may evaluate factors differently and achieve different outcomes.

05. **One or more cases** is a term used in the definition of a ROTER, specifically "TERs reached in one or more cases." Section 1204 applies to the result reached in a single case, as well as results reached in more than one case. A manager cannot use a TER from a single case to evaluate an employee or to suggest or impose production quotas or goals.

06. **Quality measures** consist of items identified from statistically valid sample outcomes used to measure organizational units.

07. **Quantity measures** consist of outcome-neutral production and resource data that do not contain information regarding the TER reached in any case or cases involving taxpayers.

08. **Records of tax enforcement results (ROTERs)** are data, statistics, compilations of information, or other numerical or quantitative recordations of the tax enforcement results reached in one or more cases.

09. **Retention standard for the fair and equitable treatment of taxpayers** is an IRS employee performance standard based on Section 1204(b), which requires that employees be evaluated on the fair and equitable treatment provided to taxpayers and behaviors that meet or do not meet the standard.

10. **Section 1204 employee** is an employee or the manager of an employee (all levels of management) who exercises judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws, or an employee whose duties involve providing direction or guidance for field programs involving Section 1204 work activities including IRM guidance. The work activity performed, not the employee's title, location or operating/functional division, identifies whether an employee should be considered a Section 1204 employee. (Exception: The Whistleblower Office is not subject to Section 1204.)

11. **Section 1204 manager** is a manager/supervisor at any level who supervises one or more Section 1204 employees.

12. **Section 1204 organizational unit** is a unit or office within an operating/functional division that includes at least one employee who conducts Section 1204 activities.

13. **Tax enforcement result (TER)** is the outcome produced by an employee's exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws.

14. **To impose a production quota or goal** includes any communication (whether written or oral) which requires a Section 1204 employee to achieve a particular TER outcome through his or her performance activities.

15. **To suggest a production quota or goal** means to engage in conduct from which a reasonable person would infer that the manager would evaluate the employee more favorably if the employee achieved a specific enforcement result regardless of the merits of the particular case(s).


**1.5.2.6** **(10-26-2022)**

### Acronyms

1. The table below identifies acronyms used in this IRM:




| **ACRONYM** | **DESCRIPTION** |
| :-- | :-: |
| ACS | Automated Collection System |
| Appeals | Independent Office of Appeals |
| ASFR | Automated Substitute for Return |
| AURP | Automated Underreporter Program |
| CAWR | Consolidated Annual Wage Report |
| CI | Criminal Investigation |
| CJEs | Critical Job Elements |
| DATC/ASTA | Deferred Adverse Tax Consequence/Alternative Strategies for Tax Administration |
| EITC | Earned Income Tax Credit |
| ELMS | Enterprise Learning Management System |
| FUTA | Federal Unemployment Tax Act |
| GLS | General Legal Services |
| HCO | Human Capital Office |
| IDRS | Integrated Data Retrieval System |
| IMF | Individual Master File |
| ITM | Integrated Talent Management |
| LB&I | Large Business and International |
| NQRS | National Quality Review System |
| OPR | Office of Professional Responsibility |
| PMF | Payer Master File |
| PAS | Program Analysis System |
| RO | Revenue Officer |
| ROTER(s) | Records of Tax Enforcement Results |
| RRA 98 | Reform and Restructuring Act of 1998 |
| SB/SE | Small Business/Self-Employed Division |
| SSA | Social Security Administration |
| TAS | Taxpayer Advocate Service |
| TEACH | Temporary Employee Action Code History |
| TE/GE | Tax Exempt and Government Entities |
| TEPS | Total Employee Performance System |
| TER(s) | Tax Enforcement Result(s) |
| TIGTA | Treasury Inspector General for Tax Administration |
| W&I | Wage and Investment |


**1.5.2.7** **(10-26-2022)**

### Restructuring and Reform Act of 1998 (RRA 98) Section 1204

1. Section 1204 (Basis for Evaluation of IRS Employees) provides that:



1. The IRS may not use ROTERs (1) to evaluate employees or (2) to impose or suggest production quotas or goals with respect to such employees.

2. The IRS will use the fair and equitable treatment of taxpayers by employees as one of the standards for evaluating employee performance.

3. Each appropriate supervisor will certify quarterly by letter to the Commissioner of Internal Revenue whether TERs are being used in a manner prohibited by Section 1204(a).

4. This section applies to evaluations conducted on or after July 22, 1998.


**1.5.2.8** **(10-26-2022)**

### Regulation 801

1. Regulation 801 as amended is found at 26 CFR Part 801 and is reprinted below:




| **Regulation 801** |
| :-: |
| **PART 801--BALANCED SYSTEM FOR MEASURING ORGANIZATIONAL AND EMPLOYEE PERFORMANCE WITHIN THE INTERNAL REVENUE SERVICE**<br> §801.1 Balanced performance measurement system; in general.<br> §801.2 Measuring organizational performance.<br> §801.3 Measuring employee performance.<br> §801.4 Customer satisfaction measures.<br> §801.5 Employee satisfaction measures.<br> §801.6 Business results measures.<br> §801.7 Examples.<br> §801.8 Effective/applicability dates.<br>**Authority**: 5 USC 9501 _et. seq._; sects. 1201, 1204, Pub. L. 105-206, 112 Stat. 685, 715-716, 722 (26 USC 7804 note).<br>**Source:** TD 8830, 64 FR 42835, Aug. 6, 1999, unless otherwise noted.<br>**Supplementary (preamble) information:** The inclusion of some outcome-neutral production data as examples of quantity measures (for example, cycle time and number or percentage of overage cases (§801.6(c)) does not prohibit an organizational unit's use of this or other outcome-neutral production data as quality measures. |
| **§801.1 Balanced performance measurement system; in general**.<br> (a) _In general_. \-\- (1) The regulations in this part 801 implement the provisions of sections 1201 and 1204 of the Internal Revenue Service Restructuring and Reform Act of 1998 (Public Law 105-106, 112 Stat. 685, 715-716, 722) (the Act) and provide rules relating to the establishment by the Internal Revenue Service (IRS) of a balanced performance measurement system.<br> (2) Modern management practice and various statutory and regulatory provisions require the IRS to set performance goals for organizational units and to measure the results achieved by those units with respect to those goals. To fulfill these requirements, the IRS has established a balanced performance measurement system, composed of three elements: Customer Satisfaction Measures; Employee Satisfaction Measures; and Business Results Measures. The IRS is likewise required to establish a performance evaluation system for individual employees.<br> (b) {Reserved}.<br> \[TD 9227, 70 FR 60215, Oct. 17, 2005. Redesignated and amended by TD 9426, 73 FR 60628, Oct. 14, 2008\] |
| **§801.2 Measuring organizational performance**. The performance measures that comprise the balanced measurement system will, to the maximum extent possible, be stated in objective, quantifiable and measurable terms and will be used to measure the overall performance of various operational units within the IRS. In addition to implementing the requirements of the Act, the measures described here will, where appropriate, be used in establishing performance goals and making performance evaluations established, inter alia, under Division E, National Defense Authorization Act for Fiscal Year 1996 (the Clinger-Cohen Act of 1996), (Public Law 104-106, 110 Stat. 186, 679); the Government Performance and Results Act of 1993, (Public Law 103-62, 107 Stat. 285); and the Chief Financial Officers Act of 1990, (Public Law 101-576, 108 Stat. 2838). Thus, organizational measures of customer satisfaction, employee satisfaction, and business results (including quality and quantity measures as described in §801.6) may be used to evaluate the performance of or to impose or suggest production goals for, any organizational unit.<br> \[TD 9227, 70 FR 60215, Oct. 17, 2005. Redesignated and amended by TD 9426, 73 FR 60628, Oct. 14, 2008\] |
| **§801.3 Measuring employee performance**.<br> (a) _In general_. All employees of the IRS will be evaluated according to the critical elements and standards or such other performance criteria as may be established for their positions. In accordance with the requirements of 5 USC 4312, 4313 and 9508 and section 1201 of the Act, the performance criteria for each position, as are appropriate to that position, will be composed of elements that support the organizational measures of Customer Satisfaction, Employee Satisfaction and Business Results; however, such organizational measures will not directly determine the evaluation of individual employees.<br> (b) _Fair and equitable treatment of taxpayers_. In addition to all other criteria required to be used in the evaluation of employee performance, all employees of the IRS will be evaluated on whether they provided fair and equitable treatment to taxpayers.<br> (c) _Senior Executive Service and special positions_. Employees in the Senior Executive Service will be rated in accordance with the requirements of 5 USC 4312 and 4313 and employees selected to fill positions under 5 USC 9503 will be evaluated pursuant to work plans, employment agreements, performance agreements or similar documents entered into between the IRS and the employee.<br> (d) _General workforce_. The performance evaluation system for all other employees will:<br> (1) Establish one or more retention standards for each employee related to the work of the employee and expressed in terms of individual performance;<br> (2) Require periodic determinations of whether each employee meets or does not meet the employee's established retention standards;<br> (3) Require that action be taken in accordance with applicable laws and regulations, with respect to employees whose performance does not meet the established retention standards;<br> (4) Establish goals or objectives for individual performance consistent with the IRS's performance planning procedures;<br> (5) Use such goals and objectives to make performance distinctions among employees or groups of employees; and<br> (6) Use performance assessments as a basis for granting employee awards, adjusting an employee's rate of basic pay, and other appropriate personnel actions, in accordance with applicable laws and regulations.<br> (e) _Limitations_. (1) No employee of the IRS may use records of tax enforcement results (as defined in §801.6) to evaluate any other employee or to impose or suggest production quotas or goals for any employee.<br> (i) For purposes of the limitation contained in this paragraph (e), _employee_ has the meaning as defined in 5 USC 2105(a).<br> (ii) For purposes of the limitation contained in this paragraph (e), _evaluate_ includes any process used to appraise or measure an employee's performance for purposes of providing the following:<br> (A) Any required or requested performance rating.<br> (B) A recommendation for an award covered by section 45 of Title 5, USC 5384; or section 1201(a) of the Act.<br> (C) An assessment of an employee's qualifications for promotion, reassignment or other change in duties.<br> (D) An assessment of an employee's eligibility for incentives, allowances or bonuses.<br> (E) Ranking of employees for release/recall and reductions in force.<br> (2) Employees who are responsible for exercising judgment with respect to tax enforcement results in cases concerning one or more taxpayers may be evaluated on work done on such cases only in the context of their critical elements and standards.<br> (3) Performance measures based in whole or in part on quantity measures (as described in §801.6) will not be used to evaluate the performance of any non-supervisory employee who is responsible for exercising judgment with respect to tax enforcement results (as defined in §801.6).<br> \[TD 9227, 70 FR 60215, Oct. 17, 2005. Redesignated and amended by TD 9426, 73 FR 60628, Oct. 14, 2008\] |
| **§801.4 Customer satisfaction measures**.<br> The customer satisfaction goals and accomplishments of operating units within the IRS will be determined based on information gathered through various methods. For example, questionnaires, surveys and other types of information gathering mechanisms may be employed to gather data regarding customer satisfaction. Information to measure customer satisfaction for a particular work unit will be gathered from a statistically valid sample of the customers served by that operating unit and will be used to measure, among other things, whether those customers believe that they received courteous, timely and professional treatment by the IRS personnel with whom they dealt. Customers will be permitted to provide information requested for these purposes under conditions that guarantee them anonymity. For purposes of this section, customers may include individual taxpayers, organizational units or employees within the IRS and external groups affected by the services performed by the IRS operating unit.<br> \[TD 8830, 64 FR 42835, Aug. 6, 1999. Redesignated by TD 9426, 73 FR 60626, Oct. 14, 2008\] |
| **§801.5 Employee satisfaction measures**.<br> (a) The employee satisfaction numerical ratings to be given to a Business Operating Division (BOD) or equivalent office within the IRS will be determined on the basis of information gathered through various methods. For example, questionnaires, surveys, and other information gathering mechanisms may be employed to gather data regarding satisfaction. The information gathered will be used to measure, among other factors bearing upon employee satisfaction, the quality of supervision, and the adequacy of training and support services. All full and part-time permanent employees of a BOD or equivalent office who are in pay and duty status will have an opportunity to provide information regarding employee satisfaction under conditions that guarantee them confidentiality.<br> (b) This section applies to the reporting of employee satisfaction information that occurs on or after March 7, 2018. |
| **§801.6 Business results measures**.<br> (a) _In general_. The business results measures will consist of numerical scores determined under the quality measures and the quantity measures described elsewhere in this section.<br> (b) _Quality measures_. Quality measures will be determined on the basis of a review by a specially dedicated staff within the IRS of a statistically valid sample of work items handled by certain functions or organizational units determined by the Commissioner or his delegate such as the following:<br> (1) _Examination and Collection units and Automated Collection System (ACS) units_. The quality review of the handling of cases involving particular taxpayers will focus on such factors as whether IRS personnel devoted an appropriate amount of time to a matter, properly analyzed the facts, complied with statutory, regulatory and IRS procedures, including timeliness, adequacy of notifications and required contacts with taxpayers.<br> (2) _Toll-free telephone sites_. The quality review of telephone services will focus on such factors as whether IRS personnel provided accurate tax law and account information.<br> (3) _Other work units_. The quality review of other work units will be determined according to criteria prescribed by the Commissioner or his delegate.<br> (c) _Quantity measures_. Quantity measures will consist of outcome-neutral production and resource data that does not contain information regarding the tax enforcement result reached in any case involving particular taxpayers. Examples of quantity measures include, but are not limited to --<br> (1) Cases started<br> (2) Cases closed<br> (3) Work items completed<br> (4) Customer education, assistance, and outreach efforts completed<br> (5) Time per case<br> (6) Direct examination time/out of office time<br> (7) Cycle time<br> (8) Number or percentage of overage cases<br> (9) Inventory information<br> (10) Toll-free level of access<br> (11) Talk time<br> (d) _Definitions - (1) Tax enforcement results_.<br> A tax enforcement result is the outcome produced by an IRS employee's exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws. Examples of tax enforcement results include a lien filed, a levy served, a seizure executed, the amount assessed, the amount collected, and a fraud referral. Examples of data that are not tax enforcement results include a quantity measure and data derived from a quality review or from a review of an employee's or a work unit's work on a case, such as the number or percentage of cases in which correct examination adjustments were proposed or appropriate lien determinations were made.<br>_(2) Records of tax enforcement results_. Records of tax enforcement results are data, statistics, compilations of information or other numerical or quantitative recordations of the tax enforcement results reached in one or more cases. Such records may be used for purposes such as forecasting, financial planning, resource management, and the formulation of case selection criteria. Records of tax enforcement results may be used to develop methodologies and algorithms for use in selecting tax returns to audit. Records of tax enforcement results do not include tax enforcement results of individual cases when used to determine whether an employee exercised appropriate judgment in pursuing enforcement of the tax laws based upon a review of the employee's work on that individual case.<br> \[TD 9227, 70 FR 60215, Oct. 17, 2005. Redesignated by TD 9426, 73 FR 60628, Oct. 14, 2008\] |
| **§801.7 Examples**.<br> (a) The rules of §801.3 are illustrated by the following examples:<br>_Example 1_. (i) Each year Division A's Examination and Collection functions develop detailed work plans that set goals for specific activities (e.g., numbers of audits or accounts closed) and for other quantity measures such as cases started, cycle time, overage cases, and direct examination time. These quantity measure goals are developed nationally and by Area Offices based on budget allocations, available resources, historical experience, and planned improvements. These plans also include information on measures of quality, customer satisfaction, and employee satisfaction. Results are updated monthly to reflect how each organizational unit is progressing against its work plan, and this information is shared with all levels of management.<br> (ii) Although specific work plans are not developed at the Territory level, Headquarters management expects the Area Directors to use the information in the Area plans to guide the activity in their Territories. For 2005, Area Office 1's work plan has a goal to close 1,000 examinations of small business corporations and 120,000 taxpayer delinquent accounts (TDAs), and there are 10 Exam Territories and 12 Collection Territories in Area Office 1. While taking into account the mix and priority of workload, and available staffing and grade levels, the Examination Area Director communicates to the Territory Managers the expectation that, on average, each Territory should plan to close about 100 cases. The Collection Area Director similarly communicates to each Territory the expectation that, on average, they will close about 10,000 TDAs, subject to similar factors of workload mix and staffing.<br> (iii) Similar communications then occur at the next level of management between Territory Managers and their Group Managers and between Group Managers and their employees. These communications will emphasize the overall goals of the organization and each employee's role in meeting those goals. The communications will include expectations regarding the average number of case closures that would have to occur to reach those goals, taking into account the fact that each employee's actual closures will vary based upon the facts and circumstances of specific cases.<br> (iv) Setting these quantity measure goals, and the communication of those goals, is permissible because case closures are a quantity measure. Case closures are an example of outcome-neutral production data that does not specify the outcome of any specific case such as the amount assessed or collected.<br>_Example 2_. In conducting a performance evaluation, a supervisor is permitted to take into consideration information they developed showing the employee failed to propose an appropriate adjustment to the tax liability in one of the cases the employee examined, provided that information is derived from a review of the work done on the case. All information derived from such a review of individual cases handled by the employee, including time expended, issues raised, and enforcement outcomes reached should be considered and discussed with the employee and used in evaluating the employee.<br>_Example 3_. When assigning a case, a supervisor is permitted to discuss with the employee the merits, issues, and development of techniques of the case based upon a review of the case file.<br>_Example 4_. A supervisor is not permitted to establish a goal for proposed adjustments in a future examination.<br> (b) \[Reserved\].<br> \[TD 9227,70 FR 60215, Oct. 17, 2005. Redesignated and amended by TD 9426, 73 FR 60628, Oct. 14, 2008\]<br>**§801.8 Effective/applicability dates**.<br> (a) The provisions of §801.1 through 801.7 apply on or after October 17, 2005.<br> \[TD 9426, 73 FR 60628, Oct. 14, 2008\]<br> Approved: October 7, 2008<br>**Linda E. Stiff**<br>_Deputy Commissioner for Services and Enforcement_<br>**Eric Solomon,**<br>_Assistant Secretary of the Treasury (Tax Policy)_ |


**1.5.2.9** **(01-14-2015)**

### Section 1204 Employee

1. A Section 1204 employee is:



1. An employee or the manager of an employee (all levels of management) who exercises judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws.

2. An employee whose duties involve providing direction or guidance for field programs involving Section 1204 work activities



      ### Example:



      An analyst who writes a compliance IRM is a Section 1204 employee.


2. The work activity performed identifies whether an employee should be considered a Section 1204 employee, not the employee’s title, location, or operating/functional division.


**1.5.2.9.1** **(01-14-2015)**

#### Exercise of Judgment

1. The exercise of judgment in applying tax law refers to the process of making decisions to **recommend** or **determine whether or how** the IRS should pursue enforcement of the tax law (including but not limited to the taxpayer's tax liability or ability to pay). These deliberations can result in reasonable people handling the same cases and, in good faith, discerning or evaluating factors differently.

2. Decisions relating to recommending or determining whether or how the IRS should pursue the enforcement of the tax laws are Section 1204 judgments. Examples of such judgments include, but are not limited to:



1. Determination to conduct a seizure.

2. Determination to file a lien.

3. Decision to disallow an unsupported itemized deduction.


3. Generally, Section 1204 and Regulation 801 do **not** cover judgments that include decisions relating to:



1. Perfection of returns (such as correcting return errors).

2. Mathematical computations (such as interest or penalty calculations).

3. Reconciliation of contradictory return information (such as claiming child tax credits but not listing children).

4. Application of mandatory IRM provisions (decisions based on IRM policy that do not require interpretation).


4. Judgment relating to processing and handling tax returns and return information not covered by Section 1204, includes but is not limited to:



01. Extracting.

02. Batching.

03. Depositing.

04. Numbering.

05. Sorting.

06. Internal accounting.

07. Coding.

08. Editing.

09. Data entry.

10. Error correction.

11. Unpostables.

12. Reject files.

13. Entity control.

14. Generation of non-discretionary documents and computations resulting from mathematical and administrative corrections.

15. Routine decisions about the application of basic principles of law or regulation.


### Example:

Threshold income amounts for deductibility of medical expenses on Schedule A do not involve the discerning or evaluation of facts, law or principles which require the use of subjective factors such as experience, legal principles, and fairness considerations.

5. Section 1204 managers must use judgment when:



1. Planning performance expectations.

2. Monitoring progress.

3. Evaluating performance.

4. Recognizing performance.

5. Using IRS performance management guidance within the boundaries of the provisions of RRA 98, Section 1204.


**1.5.2.9.2** **(05-10-2012)**

#### Imposing a Production Quota or Goal

1. Any managerial communication, either oral or written, that requires a Section 1204 employee to achieve a TER is considered imposing a production quota or goal.



### Example:



Requiring an employee to achieve a certain average dollar amount collected per return.





### Example:



Requiring an employee to effect a certain number of seizures during a rating period.





### Example:



Requiring an employee to refer a certain number of cases for prosecution during a particular period of time.


**1.5.2.9.3** **(10-26-2022)**

#### Suggesting a Production Quota or Goal

1. Any managerial communication, oral or written, from which a reasonable person would infer that the manager will evaluate an employee more favorably if a specific enforcement result is achieved, regardless of the merits of the particular case(s), is considered suggesting a production goal or quota.



### Example:



A suggestion occurs if an employee reasonably infers from conversations with the manager that the manager would evaluate the employee more favorably if the employee increased the number of seizures in a given period regardless of the merits of the case.





### Example:



A manager may not suggest to a Section 1204 employee that they should achieve the same TER in Case B as they achieved in Case A. This suggests a production quota or goal to the employee and is a Section 1204(a) violation.

2. Determining whether a production quota or goal was suggested to an employee depends on considering all relevant facts and circumstances, including whether there is a good business reason for using the statistic. Consider the following in making this determination:



1. What is the ROTER and how is it related to an employee's decision-making process?

2. What is the business reason for communicating the ROTER to the intended recipient?

3. Does the intended recipient have a need to know?

4. What is the business risk of not providing the ROTER to the intended recipient?

5. What is the potential undesirable outcome that could come from the misuse of the ROTER?

6. What is the risk that the intended recipient would reasonably believe that the communication suggested a production quota or goal?


3. When considering the risk, weigh the following factors:



1. The degree of organizational knowledge and understanding of the employee.

2. The organizational climate at the time and place of the communication.

3. The context of the communication.

4. The guidance explaining how the ROTER can or cannot be used.

5. The manner in which the communication is delivered.

6. The expectation of follow-up with respect to the ROTER and the nature of the expected follow-up.

7. The probable employee perception of the communicated ROTER.

8. The probable public perception of the communicated ROTER.


**1.5.2.10** **(10-26-2022)**

### Tax Enforcement Results (TERs)

1. A tax enforcement result is the outcome produced by an IRS employee's exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws. A TER includes but is not limited to:



01. Lien filed.

02. Levy served.

03. Seizure executed.

04. Amount - tax or penalties assessed.

05. Amount - tax or penalties collected.

06. Fraud referral.

07. Revenue protected.

08. Type of case closure (agreed, no change, full paid, abatement).

09. Prosecution recommended (indictment/conviction).

10. Type of relief provided.


2. A TER does not include quality review data, an employee's case work review or a work unit's work on a case such as a number or percentage of correct examination adjustments proposed or appropriate lien determinations made. See _IRM 1.5.2.8_, _Regulation §801.6_.

3. A TER is **not** a quantity measure. A quantity measure, by definition, is outcome neutral. See _IRM 1.5.2.12_, _Quantity Measures_, for more information.


**1.5.2.10.1** **(10-26-2022)**

#### Permitted Use of TERs

1. TERs may be cited and discussed in employee reviews (but not employee evaluations) to determine if the employee:



1. Exercised appropriate judgment.

2. Used time efficiently.

3. Applied the laws in one or more cases properly.


2. TERs may be cited to provide guidance on future actions necessary for one or more specific cases.

3. A manager may reference an individual case to illustrate whether or not the employee's performance met specific performance standards.



### Example:



In a case review, a manager discovers that an employee failed to consider all relevant facts or correctly apply laws resulting in an incorrect proposed assessment of $1 million. The manager may comment on the TER reached, as materiality is a factor relating to the employee's judgment, and may document the TER in the write-up of the individual case review.





### Example:



During a workload review, a manager may comment to a revenue agent or revenue officer (RO) on the methods used, the level and quality of the research, and the TERs reached in each of several cases separately based on the merits of each individual case. The manager may comment on the dollar amount or the case size only as relevant to the time and efforts expended in each case.





### Example:



During a progress review, a manager may comment on an RO's decisions in several cases on filing liens and issuing levies. Since each lien or levy is a TER, the manager and RO may discuss the appropriateness of each of the collection tools used or not used (including the appropriateness of each based on the amounts at issue), and the manager may make general observations about the RO's judgment in each case considering the amounts at issue and the expected and actual TERs.





### Example:



In a case review, a manager may inform an employee that the time spent and/or methods used on a $100,000 collection case were either excessive, unwarranted, or insufficient, considering the amount at issue.

4. A manager may make recommendations on enforcement actions in a specific case.



### Example:



A manager may inform a revenue agent that, based on the facts of the case to date, a penalty should be asserted in a particular case.





### Example:



A manager may inform an RO that specified levies should be served or indicate that the next appropriate course of action would be seizure of specific property.

5. A manager may inform an employee that the IRS has handled cases involving similarly situated taxpayers, inform the employee of best practices in those cases, and may refer employees to other employees to obtain guidance based on similar cases.



### Example:



A revenue agent is assigned to an examination involving a taxpayer who has claimed improper deductions in a tax shelter. The manager may suggest that the employee obtain information about the tax shelter from other employees with experience in examining that shelter or similar shelters.





### Example:



An RO is assigned a collection case where assets may have been placed offshore. The manager may suggest that the RO contact experienced personnel to discuss best practices.


**1.5.2.10.2** **(10-26-2022)**

#### Prohibited Use of TERs

1. Although neither Section 1204 nor Regulation 801 contain restrictions on TER use, the IRS determined that managers must not include TER outcomes in a written performance appraisal or employee evaluation.

2. TER terms may be used as part of a list of enforcement tools, or indicate that the employee properly made a determination whether a particular tool was appropriate.

3. In a case review, workload review, progress review, or other employee documentation that is not an employee evaluation, the facts and details related to an individual TER may only be mentioned to fairly describe the employee's performance (that is, the employee's knowledge, skills, and abilities as applied to the case) with emphasis placed on the employee's efforts rather than on the result. In an employee evaluation, neither TERs, ROTERs, nor quantity measures may be used.



### Example:



In an employee evaluation, a manager may briefly state that a revenue agent was able to locate a significant amount of unreported offshore income, but should emphasize the particular efforts that made the TER noteworthy, and should not mention specific dollar amounts.





### Example:



In support of an award, a manager may not state that an RO was able to locate sufficient funds in two accounts to result in "full pay." The narrative should emphasize the particular efforts made. Reference to a specific TER or dollar amount may not be mentioned.





### Example:



In an evaluation, a manager may not state an RO was able to get a "full pay" in 11 of 14 cases, even if efforts of the RO are emphasized, because the aggregation of TERs constitutes a ROTER.





### Example:



In an evaluation, a manager may not state that an employee issued liens on six of seven cases reviewed. The narrative should focus on processes undertaken, not results achieved. The evaluation could be reworded to note that the employee made appropriate lien determinations on their cases.

4. The review and discussion of an employee's performance on a case should be based on that case and not external matters (for example, TERs from other similar cases).


**1.5.2.11** **(05-10-2012)**

### Records of Tax Enforcement Results (ROTERs)

1. ROTERs are data, statistics, and compilations of information or other numerical or quantitative recordations of the TERs reached in one or more cases. ROTERs include but are not limited to:



01. Number of liens filed.

02. Number of levies served.

03. Number of seizures executed.

04. Dollars collected.

05. Number of fraud referrals.

06. Dollars per hour.

07. Dollars per return.

08. Total dollars assessed.

09. Percentage of agreed cases.

10. Number of "full paid" cases.

11. Number of prosecutions recommended.

12. Percentage of Taxpayer Advocate cases where relief was granted.

13. Amount of revenue protected.

14. No change rate


**1.5.2.11.1** **(05-10-2012)**

#### Permitted Use of ROTERs

1. ROTERs may be used for forecasting, financial planning, resource management, and the formulation of case selection criteria. See Regulation §801.6(d)(2).



### Note:



ROTERs do not include TERs of individual cases when used to determine whether an employee exercised appropriate judgment in pursuing the enforcement of tax laws based on a review of the employee's work on that individual case. See Regulation §801.6(d)(2) and §801.7(a) Example 3.

2. The IRS has determined that ROTER data may be made available as follows, provided that such data will never be used to evaluate any employee or to suggest or impose production quotas or goals:



1. Compilations of national statistics as to ROTER information such as amount assessed, collected, etc., may be disclosed to the public, on IRS web sites, to IRS executives, and selectively to IRS employees on a "need-to-know" basis.

2. ROTER information may be disclosed to managers if it relates to performance of units under their span of control.

3. ROTER information may be disclosed for use among units involved in forecasting, planning, resource management, and the formulation of selection case criteria on a "need-to-know" basis.

4. Territory/department and area/operation information may be shared with groups, but only for such functions as mentioned in (c) above.



      ### Example:



      The Small Business/Self-Employed (SB/SE), Director, Collection, supervises eight area directors, who each have subordinate territory and group managers. A group manager may be provided with ROTER data, such as the amount collected by that group. The territory manager may be provided that information for each group in the territory. An area director may be provided information for each group and territory in the area. Providing ROTER information in an employee evaluation (including an award) is prohibited.





      ### Example:



      An area director or technical services employee (whose group does not conduct taxpayer examinations and is not in that chain of command) observes a substantial increase in the number of fraud referrals in a territory. The area director or technical services employee may contact the territory manager to ask about the increase in the example above.





      ### Example:



      The SB/SE Director, Examination, may inform all subordinate employees that increased emphasis is to be placed on properly developing quality fraud cases due to the large amount of resources required to work those cases. Decisions on management resource allocation does not suggest a production quota or goal.


**1.5.2.11.2** **(10-26-2022)**

#### Prohibited Use of ROTERs

1. According to Section 1204(a), the IRS may not use ROTERs to evaluate employees or to impose or suggest production quotas or goals.



### Example:



A manager informs revenue agents in a group meeting that one agent did an outstanding job by obtaining changes in the last 10 of his cases and that another agent did an outstanding job by averaging changes of $50,000 per case. Both of the statements are prohibited by Section 1204(a) because each suggests a production goal.

2. Examples of suggesting goals or imposing a production quota for a ROTER include requiring an employee to achieve a certain average dollar amount collected per return, requiring an employee to make a certain number of seizures during a rating period, or praising an employee for referring a certain percentage or number of cases for prosecution or fraud referral. See Regulation §801.7, Example 4.

3. Including ROTERs in self-assessments does not violate IRS RRA 98 Section 1204 or Regulation 801; however, to dispel the appearance of impropriety, it is IRS policy that bargaining unit and non-bargaining unit employees should not use ROTERs in self-assessments.

4. If a manager, management official, or confidential management/program analyst submits a self-assessment with ROTERs, it should be returned to the employee for removal of the ROTERs.

5. It is a Section 1204(a) violation if a ranking official or panel uses the information in the ranking process or if a supervisor uses the information when evaluating employees' performance.


**1.5.2.11.3** **(05-10-2012)**

#### One or More Cases

1. The phrase "one or more cases" is contained in the ROTER definition, specifically "TERs reached in one or more cases." The definition intentionally references one case to make it clear that Section 1204 can apply to the result reached in a single case, as well as results reached in more than one case.



### Example:



If you praise an employee for submitting a fraud referral, it is only one referral, but since your focus is on achieving the TER rather than on the steps taken to identify and develop fraud, it is a ROTER violation.





### Example:



A narrative in a performance evaluation that focuses on an employee's successful collection of $50,000 in a levy action is a ROTER violation, even though the reference is to only one case.

2. A manager cannot use a TER from a single case to evaluate an employee or suggest production quotas or goals.



### Example:



A manager cannot advise or imply that an employee should achieve the same TER in Case B as they achieved in Case A.

3. The definition specifically allows managers to discuss with employees the results that they achieved in individual cases. A manager may discuss with an employee his/her exercise of judgment in achieving a particular TER in a case when based on a review of the employee's work on that individual case.


**1.5.2.12** **(01-14-2015)**

### Quantity Measures

1. Quantity measures consist of outcome-neutral production and resource data that do not contain information regarding the TER reached in any case or cases involving particular taxpayers.

2. An organizational unit may use any outcome-neutral data, such as overage cases or cycle time, as a quantity measure. Examples of quantity measures include, but are not limited to:



01. Cases started.

02. Cases closed.

03. Work items completed.

04. Customer education, assistance, and outreach efforts completed.

05. Time per case.

06. Direct examination/investigation time.

07. Out of office time.

08. Inventory information.

09. Toll-free level of access.

10. Talk time.

11. Number or percentage of overage cases.

12. Cycle time.


3. See Regulation §801.6(c).


**1.5.2.12.1** **(05-10-2012)**

#### Permitted Use of Quantity Measures

1. Quantity measures may be used to evaluate the performance of any organizational unit and may be disseminated as determined by each organizational unit.

2. Quantity measures may be used to impose or suggest production goals for any organizational unit and may be disseminated as determined by each organizational unit.

3. Quantity performance measures may also be used to evaluate supervisory (or management) employees responsible for exercising judgment with respect to TERs.



### Example:



An area director may inform territory managers and employees that for a certain type of examination, a goal for average time per case is 10 hours, and another goal is to close 90 percent of new cases within six months. This use of a quantity measure does not violate Regulation 801 or any IRM provision. The area director must make it clear that circumstances in an organization or the complexity of inventory for certain employees may warrant a different closure rate. This example does not suggest or impose a production goal or quota for an employee.





### Example:



A territory manager, in evaluating a group manager, notes that the time per case in the group was far above the goal for the group. The territory manager should use appropriate diagnostic tools to determine whether there are good reasons for the high amount of time spent per case. Having done so, the territory manager may mention in the group manager's evaluation that the time was far above the goal, in addition to discussing the manager's actions.


**1.5.2.12.2** **(05-10-2012)**

#### Prohibited Use of Quantity Measures

1. All employees of the IRS will be evaluated according to the critical elements and standards established for their positions. The performance criteria is composed of elements that support the organizational measures for:



1. Customer Satisfaction.

2. Employee Satisfaction.

3. Business Results.


2. Regulation §801.3(a) indicates **organizational measures do not directly determine the evaluation of individual employees**.

3. Performance measures based in whole or in part on quantity measures **will not be used to evaluate the performance of any non-supervisory employee who is responsible for exercising judgment with respect to TERs**. See Regulation §801.3(e)(3).



### Example:



A group manager informs non-supervisory employees responsible for exercising judgment with respect to TERs that for a prior period, the group's average was 12 hours per case closure. The manager states their goal is to close cases in an average of ten hours per case. The group manager describes best practices to accomplish this goal. This is allowable as an organizational or employee goal, but the goal cannot be used in the evaluation of these employees. The employees must be evaluated exclusively on performance based on their critical elements, and the evaluations may not cite the goal as a benchmark. The manager must evaluate the employee's use of time based on individual cases, rather than on any assumptions as to case closing norms.

4. Employees who are responsible for exercising judgment with respect to TERs in cases concerning one or more taxpayers may be evaluated on work done only in the context of their critical elements and standards. See Regulation §801.3(e)(2).


**1.5.2.13** **(05-10-2012)**

### Quality Measures

1. Quality measures are determined by a specially dedicated IRS staff such as National Quality Review System (NQRS) analysts.

2. Quality measures are based on the review of statistically valid work item samples handled by organizational units. Examples of quality measures include, but are not limited to:



1. Overage cases.

2. Cycle time.

3. Customer accuracy percentage.

4. Regulatory accuracy percentage.

5. Procedural accuracy percentage.

6. Timeliness quality percentage.

7. Professionalism quality percentage.


3. Quality measures may be used in all the same ways as quantity measures.

4. Quality measures may be used to evaluate non-supervisory employees.


**1.5.2.13.1** **(05-10-2012)**

#### Permitted Use of Quality Measures

1. Performance measures based on quality measures may be used to evaluate employee performance. Performance measures based on quality measures may also be used to impose or suggest production goals for any employee.



### Example:



A manager may advise an employee that unnecessary steps were taken in their cases, increasing cycle time. The manager should go on to describe the appropriate steps that the employee should have taken.





### Example:



Quality review accuracy rates for the current period show a team's error rate is increasing. The manager may share this information with employees in an effort to identify corrective actions needed. There is no prohibition in Regulation 801 or the IRM against sharing quality statistics.





### Example:



A manager may establish time frames that must be met within a certain number of days. Overemphasis on time frames, however, could lead employees to focus solely on the time frame instead of on the appropriate case resolution.


**1.5.2.14** **(05-10-2012)**

### Sharing Data

1. ROTER data concerning one organizational unit may not systematically be shared with other units at the same level. It may only be shared with organizations to which it pertains.

2. ROTER data may be made available, provided that such data will never be used to evaluate any employee according to the definition of "evaluate" in Regulation §801.3(e)(1)(ii), and it will never be used to suggest production quotas or goals.

3. There is no prohibition against sharing organizational quantity or quality statistics.

4. Using results for diagnostic tools or workload indicators to compare one unit against other units may be appropriate for:



1. Conducting analysis.

2. Exploring best practices.

3. Seeking process enhancements to support improvement of the over-arching balanced measure(s).


5. The performance of any one unit at any level of the organization must not be used as a standard by which the performance of other units are evaluated due to differences that exist in:



1. The types of taxpayers served.

2. Employee skill levels.

3. Specific issues being worked.

4. Other factors.


However, results may be used to identify and share best practices.



**1.5.2.15** **(06-01-2010)**

### Section 1204 and Regulation 801 Decision Table

1. The RRA 98, Section 1204 and Regulation 801 Decision Table can be used to determine if a particular measure/data may be used for a specific purpose. See Exhibit 1.5.2-1.

2. Determine if the measure/data is a ROTER; if so, it's restrictions are governed by Section 1204.



### Note:



**The revision of Regulation 801 did not remove or alter in any way the prohibitions on the use of ROTERs established by Section 1204, and continues to prohibit the use of ROTERs to evaluate employee performance or to impose or suggest production quotas or goals for any employee.**

3. Determine if the measure/data is a quantity measure; if so, it's permissible use is governed by Regulation 801.



### Note:



**The revision of Regulation 801 removed the limitations on the use of quantity measures for organizational units in evaluating the performance of, or imposing or suggesting quantity goals.**

4. You must also determine the organizational unit or type of employee to which the measure/data is applied. If the measure/data is not a ROTER or a quantity measure, neither Section 1204 nor Regulation 801 applies.

5. The summary below provides information for determining if a particular measure/data may be used for a specific purpose.




| **Summary** |
| :-: |
| **_To establish goals:_** | Using TERs or ROTERs to impose or suggest production quotas or goals for any employee is prohibited. |
| Using quantity measures to impose or suggest production goals for any employee is allowed. |
| Using quality measures to impose or suggest production quotas or goals for any employee is allowed. |
| **_To evaluate:_** | Using TERs or ROTERs to evaluate any employee is prohibited. |
| Using quantity measures to directly evaluate non-supervisory employees is prohibited. |
| Using quality measures to evaluate any employee is allowed. |
| Using quantity measures to evaluate supervisory employees is allowed, but may lead to a ROTER violation if organizational goals are used to directly determine a supervisory employee's performance rating. |


**Exhibit 1.5.2-1**

### Section 1204 and Regulation 801 Decision Table

The table below provides questions to determine if a particular measure/data may be used for a specific purpose.

| **Section 1204 and Regulation 801 Decision Table** |
| :-: |
| **Step** | **Question** | **Yes** | **No** | **Explanation/**<br>**Comments** |
| :-- | :-- | :-- | :-- | :-- |
| 1 | Is the data a ROTER? | Go to Step 2. | Go to Step 3. | ROTERs are data, statistics, compilations of information or other numerical or quantitative recordations of the tax enforcement results reached in one or more cases, but do not include tax enforcement results of individual cases when used to determine whether an employee exercised appropriate judgment in pursuing enforcement of the tax laws based upon a review of the employee's work on that individual case. See Regulation §801.6(d)(2). |
| 2 | Is the ROTER being used to evaluate or to impose or suggest production quotas or goals for any employee (including managers and executives)? | Prohibited by Section 1204 and Regulation 801. | RRA 98 Section 1204 does not apply. | The IRS shall not use ROTERs to evaluate employees or to impose or suggest production quotas and goals with respect to such employees. (RRA 98, Section 1204) No employee of the IRS may use ROTERs (as described in Regulation §801.6) to evaluate any other employees or impose or suggest production quotas or goals for any employee. See Regulation §801.3(e)(1)**Section 1204 employees include all levels of management**. |
| 3 | Is the data a quantity measure? | Section 1204 does not apply to quantity measures; however, Regulation 801 does. See steps 4 - 7. | Neither RRA 98, Section 1204, nor Regulation 801 apply. | Quantity measures consist of outcome-neutral production and resource data that does not contain information regarding the tax enforcement result reached in any case that involves particular taxpayers. See Regulation §801.6(c). |
| 4 | Is the quantity measure used to impose or suggest production goals for:<br> <br>1. An organizational unit?<br>   <br>2. A supervisory Section 1204 employee?<br>   <br>3. A non-supervisory Section 1204 employee?<br>   <br>4. A non-Section 1204 employee? | Not prohibited by Regulation 801. | Go to step 5. | Quantity measures include measures such as cases started or closed, time per case, work items completed, hours expended, inventory information etc. which are outcome neutral and not ROTERs. Revised Regulation 801 removed the limitations on the use of quantity measures for imposing or suggesting goals for both organizational units and employees. See Regulation §801.6(c). |
| 5 | Is the quantity measure used to evaluate the performance of an organizational unit? | Not prohibited by Regulation 801. | Go to step 6. | Organizational measures of customer satisfaction, employee satisfaction and business results (including quality and quantity) may be used to evaluate the performance of or to impose or suggest production goals for, any organizational unit. See Regulation §801.2. |
| 6 | Is the quantity measure used to evaluate the performance of:<br> <br>1. A supervisory Section 1204 employee?<br>   <br>2. A non-Section 1204 employee? | Not prohibited by Regulation 801. | Go to step 7. | A performance measure may be based, in whole or in part, on a quantity measure. The performance criteria for each position, as are appropriate for that position, will be composed of elements that support the organizational measures of customer satisfaction, employee satisfaction, and business results; however such organizational measures will not directly determine the evaluation of individual employees. See Regulation §801.3(a). |
| 7 | Is the quantity measure used to evaluate the performance of a non-supervisory Section 1204 employee? | Prohibited by Regulation 801. | Regulation 801 does not apply. | Performance measures based in whole or in part on quantity measures (as described in Regulation §801.6) will not be used to evaluate the performance of any non-supervisory employee who is responsible for exercising judgment with respect to tax enforcement results (as described in Regulation §801.6). See Regulation §801.3(e)(3). |

**Exhibit 1.5.2-2**

### Questions and Answers for Small Business/Self-Employed and Wage and Investment Operating Divisions

The following questions and answers discuss the use of Tax Enforcement Results (TERs) and Records Of Tax Enforcement Results (ROTERs) within Small Business/Self-Employed and Wage and Investment Operating Divisions.

|     |
| --- |
| **_Question 1. Are Individual Master File (IMF) Refund Accuracy Rate, Notice Accuracy, Refund Timeliness - Paper (days), and Refund Dollars Subject to Interest IMF Returns ROTERs subject to Section 1204/Regulation 801?_** |
| No. Each statistic cited in the question reports the accuracy (first two) or timeliness (last two) of employee collective efforts - all of which are quality measures. They do not meet the definition of TER or quantity measures, so they are not subject to the prohibitions in Section 1204(a) or Regulation 801. |
| **_Question 2. Are statistics which measure taxpayer actions (e.g. the number of returns and return information filed electronically as well as by paper) ROTER?_** |
| No. Statistics which measure taxpayer or other third party actions do not consider the exercise of judgment by employees in recommending or determining whether or how the IRS should pursue enforcement of the tax laws and, thus, are not ROTERs and Section 1204/Regulation 801 does not apply. |
| **_Question 3. Is the measurement of telephone “idle time” a ROTERs?_** |
| “Idle time” refers to the period of time in which an employee is not conducting or wrapping up telephone calls. “Idle time” is a quantity measure. It does not measure any exercise of judgment in regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws, so it is not a ROTER. |
| **_Question 4. What activities relating to the assessment and abatement of penalties are subject to Section 1204/Regulation 801?_** |
| Abating or waiving penalties based on communications with the taxpayer may involve Section 1204 judgments. This is the case with abatement or waiver requests in which the taxpayer asserts that he or she had reasonable cause for noncompliance or exercised due diligence. While the IRM gives extensive guidance on evaluating reasonable cause or due diligence assertions, it cannot cover all possible circumstances and employees often must weigh the taxpayer's response and exercise discretion in accepting or rejecting the taxpayer's request. Therefore, making determinations of reasonable cause or due diligence for penalty abatement or waiver is a Section 1204 activity. In other instances, taxpayers will respond to penalty notices by presenting new facts indicating that the penalty does not apply. Other penalty abatements arise due to adjustments to the underlying tax on which they are computed. While the tax adjustment may involve Section 1204 judgment depending on the type of judgment involved, the related penalty abatement is merely mathematical and does not involve Section 1204 judgment in and of itself. |
| **_Question 5. Are Questionable Refund cases ROTERs for purposes of Section 1204/Regulation 801?_** |
| Yes. The determination of whether a matter is a Questionable Refund requires the exercise of judgment in determining tax liability - an analysis of legal principles, tax law, and the taxpayer's circumstances. The degree and depth of analysis required for a Questionable Refund meets the test for the exercise of Section 1204 judgment. |
| **_Question 6. The Payer Master File (PMF) is a program to assess a civil penalty for late filed information returns. If the taxpayer response meets reasonable cause criteria, the penalty is abated. Would this fall under Section 1204 employee criteria?_** |
| Yes. A Section 1204 employee is an employee who exercises judgment in regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws. The deliberations undertaken in deciding reasonable cause criteria is the exercise of judgment covered by Section 1204/Regulation 801 because it weighs factors in particular cases; there is no set formula. Accordingly, an employee who makes decisions upon reasonable criteria in abating penalties is a Section 1204 employee. |
| **_Question 7. Math error issues are processing actions. However, accounts are increased and decreased. Does this constitute action by a Section 1204 employee?_** |
| No. A Section 1204 employee is an employee who exercises judgment in regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws. The reconciliation or correction of math errors requires decision making, but that decision making is based upon the application of mathematical principles and does not require the exercise of judgment, e.g., weighing factors appropriately, deciding reasonableness, and determining credibility covered by Section 1204/Regulation 801. |
| **_Question 8. If the major portion of employees' performance is not enforcement activity, but a small percentage could be mixed with their work, would their entire performance be considered enforcement and would they be considered Section 1204 employees?_** |
| Section 1204/Regulation 801 applies to the tasks performed by employees. An employee may be a Section 1204 employee for one task, but not another. The difference depends upon whether the employee exercises judgment in regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws in performing that task. Thus, the employee would be considered a Section 1204 employee. |
| ****Question 9. Are tax examiners processing levy responses considered Section 1204 employees?**** |
| Whether an employee is a Section 1204 employee for purposes of applying Section 1204/Regulation 801 is determined by the task performed by the employee and not the title or location of the employee. As stated in this question, if the employee is only inputting information received from the third party and is following non-discretionary procedures in issuing the next available levy, that is not the kind of exercise of judgment sought to be protected by Section 1204/Regulation 801 and, therefore, is not subject to either. However, the employee who recommended the levy action be input is considered a Section 1204 employee. |
| **_Question 10. Are tax examiners who work Taxpayer Advocate cases considered Section 1204 employees as defined for the purpose of applying Section 1204/Regulation 801?_** |
| For purposes of applying Section 1204/Regulation 801, Section 1204 employees are employees who exercise judgment with regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws. Whether an employee is a Section 1204 employee for the purposes of applying Section 1204/Regulation 801 is determined by the tasks performed by the employee, not the title or location of the employee. Tax examiners who work Taxpayer Advocate cases may or may not be Section 1204 employees. For example, the tax examiner processing the manual refund or working the payment tracer according to non- discretionary criteria contained in the appropriate section of the IRM is not performing enforcement work. Certainly, these tax examiners exercise decision making in performing their tasks, but this decision making is not the type of exercise of judgment with regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws, which is covered by Section 1204/Regulation 801. Conversely, a Taxpayer Advocate tax examiner is a Section 1204 employee when working a Correspondence Examination reconsideration case. |
| **_Question 11. Are tax examiners working Correspondence Examination deficiency cases or reconsideration cases considered to be Section 1204 employees and is this work subject to Section 1204/Regulation 801?_** |
| Yes. Employees making determinations on correspondence examination deficiency and reconsideration cases are expected to review the taxpayer's return or correspondence for new issues and to weigh the credibility and reasonableness of the taxpayer's assertions. This clearly involves discretion in that two employees working the same case can reasonably come to different conclusions as to the acceptability of the taxpayer's assertions. This type of judgment falls under the purview of Section 1204/Regulation 801. |
| **_Question 12. Are tax examiners or tax auditors working innocent spouse claims considered Section 1204 employees for purposes of Section 1204/Regulation 801?_** |
| Yes. Tax examiners or tax auditors working innocent spouse claims are considered Section 1204 employees for purposes of Section 1204/Regulation 801. They exercise judgment by evaluating taxpayer's statements from both the requesting spouse and non-requesting spouse and applying community property laws, if applicable, to determine if relief should be granted. |
| **_Question 13. A tax examiner decides to report an account as currently not collectible based on financial information submitted by the taxpayer. Is this a TER for purposes of Section 1204/Regulation 801 and is the tax examiner working as a Section 1204 employee?_** |
| Yes. The activity produces a TER and the employee is working as a Section 1204 employee. The tax examiner analyzes financial information provided by the taxpayer to determine ability to pay. Based on this financial analysis, the tax examiner exercises judgment in determining if the taxpayer's income, expenses, or assets and liabilities would permit a taxpayer to pay. The tax examiner compares the expenses to the allowable expense standards to determine if the expenses are reasonable or necessary. Assets are analyzed to determine equity and the taxpayer's ability to borrow. This type of decision making in determining the ability to pay requires the type of judgment covered by Section 1204/Regulation 801. |
| **_Question 14. An employee engaged in processing returns refers a questionable return document or information item to Criminal Investigation. Is the employee exercising Section 1204 judgment?_** |
| No. In this scenario, the employee has not exercised judgment in regard to recommending or determining whether or how the IRS should pursue enforcement of the tax laws. Rather, the employee has made a decision to refer the information to Criminal Investigation for its analysis. |
| **_Question 15. Are campus employees who classify estate tax returns considered Section 1204 employees as defined for the purpose of applying Section 1204/Regulation 801?_** |
| Yes. The classifier has the discretion to apply judgment in determining other estate returns that may have other audit potential issues, or identify questionable items on the estate tax return or issue a closing letter. |
| **_Question 16. Are tax examiners making determinations in Deferred Adverse Tax Consequence/Alternative Strategies for Tax Administration (DATC/ASTA) cases considered to be enforcement employees?_** |
| Yes. DATC/ASTA programs are test programs for which only general guidelines are provided for examiners to follow. The examiners are expected to exercise considerable discretion in reviewing and making determinations on taxpayer replies to notices. The decisions made in this manner involve the type of judgment intended to be protected under Section 1204/Regulation 801. |
| **_Question 17. I am a Automated Collection System (ACS) unit manager. I need to know if it is a Section 1204 violation to bring up, in an evaluation, that a levy was not served when it was, in fact, the next appropriate action?_** |
| It is not a violation of Section 1204/Regulation 801 to review the case or to discuss the appropriate actions to be taken with the employee, even if the action is an enforcement action. Section 1204/Regulation 801 provides a specific exception in the definition of TERs for this purpose. In documenting the performance review, and in any subsequent evaluation, focus on documenting the appropriateness of the decisions, in the context of the employee's critical job elements and standards, and not on documenting the specific actions that were or were not taken. |
| **_Question 18. If “case closures” is no longer considered a ROTER, may a Section 1204 employee's production rate be addressed in performance counseling?_** |
| Yes, but not simply in terms of quantity of work done. As a diagnostic tool, an employee's production rate may alert the manager to look at the employee's work practices to see if adjustments are in order. While the quantity measure may be mentioned in discussions or evaluative recordation, the discussion with the employee must be conducted in terms of the critical job elements and standards. The quantity measure benchmark may not be mentioned in an evaluation. The specific TER should not be mentioned in a evaluation. |
| **_Question 19. Does measuring employee quality and quantity through the Total Employee Performance System (TEPS) violate Section 1204/Regulation 801?_** |
| TEPS is a tool employed in campuses to measure certain Section 1204 employee performance standards selected by management. If used appropriately, TEPS does not violate Section 1204/Regulation 801. However, if TEPS contains a performance standard which uses a ROTER to (1) evaluate any employee or (2) to impose or suggest production quotas or goals for any employee, then the use of TEPS would violate Section 1204/Regulation 801. Thus, each performance measure is examined individually for conformance with Section 1204/Regulation 801. |
| **_Question 20. I am a tax examiner working balance due accounts. In a conversation with my unit manager, she mentioned that I have not pursued requesting installment agreements during my steps to work a balance due account. Is this appropriate?_** |
| It is appropriate to discuss actions that should have been followed during the course of resolving a case, because this is part of the quality review of your case handling. This is true even if the actions are TERs. |
| **_Question 21. May a first-line manager discuss and solicit ideas for improving productivity when he or she meets with his or her employees to formulate an action plan?_** |
| Yes. This type of discussion is appropriate. |
| **_Question 22. The director asked a territory manager to provide a weekly report on average “wait time” at the Field Assistance counters during filing season. Is it appropriate to share this report with Field Assistance managers and employees?_** |
| Yes. “Wait time” is a diagnostic tool intended to minimize taxpayer burden, not a ROTER or a quantity measure. It should also be used to determine resource and training needs to better meet customer demand. However, overemphasis on wait time could lead employees to focus on completing taxpayer contacts quickly and not on providing quality service. |
| **_Question 23. May audit managers establish time frames for actions to be completed within a certain number of days?_** |
| Yes. Time frames are not ROTERs, nor is timeliness a quantity measure. However, managers need to be cautious on the use of non-ROTERs. For example, overemphasis on time frames, even though not ROTERs or quantity measures, could lead employees to focus on the time frame instead of focusing on the appropriate case resolution. |
| **_Question 24. Are program completion dates a violation of Section 1204/Regulation 801, and if so, what impact will this have on scheduled rates? How will we schedule?_** |
| No. Program completion dates are the scheduled completion of returns processing (timely filed Form 1040 processed by a certain date) or program completions (Consolidated Annual Wage Report (CAWR)/ Federal Unemployment Tax Act/Account (FUTA) programs completed and submitted to the receiving agency by a certain date). These dates are not ROTERs because program completion date establishes a timing schedule only. “Scheduled rates” is the term used to describe the work planning and control for allocation of resources to meet program completion dates. As these scheduled rates are not ROTERs, they are not subject to Section 1204/Regulation 801. |
| **_Question 25. Is it appropriate for Headquarters personnel to give Campus Exam work plans directly to the Exam operations manager (the work plans identify program goals for Earned Income Tax Credit (EITC) closures, Automated Substitute for Return (ASFR) closures, etc.)?_** |
| Yes. In the work planning process, the Headquarters must use some ROTERs for such purposes as planning and forecasting inventory levels. Because the use of ROTERs for the work planning process is permitted in Section 1204, the sharing of work plans between the Headquarters and Examination department managers is not a violation of Section 1204/Regulation 801. Although they may be used later in setting balanced measure goals, production statistics in work plans that are ROTERs do not represent goals for evaluative purposes. It is important that, in sharing work plan data, managers at all levels should be cautious not to share ROTERs or the results of analyses in any way that impose or suggest a production quota or goal against which employees will be evaluated. |
| **_Question 26. I am a ACS manager. At the beginning of each week I use my team's Daily Workload report to see where I should allocate resources. Is that a Section 1204/Regulation 801 violation?_** |
| No. Using the report is not a violation since the number of cases in inventory is not a ROTER. Workload planning and monitoring are required to assist in the effective management of an operation. |
| **_Question 27. My employees like to know the number of cases in the Daily Workload. Would it be a violation of Section 1204/Regulation 801 to share this information?_** |
| No. That is not a violation since the number of cases in a particular inventory is not a ROTER. The Daily Workload report shows how many cases are in the inventory that can be worked on a specific day. Managers use the report to determine when and where employees should work. |
| **_Question 28. The area director comments to her staff that cycle time has increased over last year's accomplishment. Is it a violation of Section 1204/Regulation 801 if the territory manager shares this with the group managers?_** |
| No. Cycle time is not a ROTER, neither is overage. They are measures of the span of time within which the process occurs and not the production time to complete the process. Therefore, they are not directly related to producing TERs. Timely, quality attention to taxpayer cases is the desired outcome. |
| **_Question 29. At a manager's meeting, the territory manager states that the number of cases that are over 90 days old are high and we need to reduce the overage inventory. Is this a violation of Section 1204/Regulation 801?_** |
| No. Age or amount in inventory is not a ROTER. Emphasizing the amount of cases in the inventory may result in premature closure. Further research to determine the reasons for high inventory, e.g., inappropriate case processing, insufficient allocation of resources, or a discussion of the results of program reviews are effective methods to ensure that the objectives are being met. |
| **_Question 30. At a staff meeting, the area director states that overage has increased by 10% this year. May the territory manager communicate this to his/her section managers?_** |
| Yes. Overage data is not a ROTER. |
| **_Question 31. I am an ACS department manager. I advise my subordinate managers that we need to increase the issuance of levies by 25%. Is this a Section 1204 violation?_** |
| Yes. This is a violation of Section 1204/Regulation 801. Levies issued is a ROTER. ROTERs may not be used to suggest production quotas or goals for any employee. |
| **_Question 32. Is it appropriate for a manager to discuss the amount of time working cases with individual front-line employees?_** |
| Yes. The amount of time used speaking to customers and concluding the contact (talk, handle, and wrap time) is available to call site managers as a diagnostic tool. This can be a valuable starting point for a discussion with an employee in respect to overall performance. Included in such a discussion would be the nature of specific contacts and the quality of service provided to the customer. The amount of talk, handle, or wrap time is not a ROTER; it is a statistic which should be discussed in conjunction with Quality and Customer Service. The actual performance of the employee is measured against their critical job elements and standards. |
| **_Question 33. How can I mention an employee's good work on a fraud case in an evaluation without violating Section 1204 rules?_** |
| Focus on the employee’s recognition of badges of fraud, investigative skills, development of key fraud indicators, and appropriate use of enforcement tools, not on the fraud referral or fraud penalty itself. |

**Exhibit 1.5.2-3**

### Small Business/Self-Employed (SB/SE) and Wage and Investment (W&I) Operating Divisions Section 1204 Work Activity Determination Matrix

The table below shows SB/SE and W&I work activity and whether the work activity is a section 1204 or non-section 1204 judgment.

|  | WORK ACTIVITY | SECTION 1204 Judgment | NON-SECTION 1204 Judgment | COMMENTS |
| :-- | :-- | :-- | :-- | :-- |
| 1. | 23C Processing<br> (Q, P, J) |  | X |  |
| 2. | Systemically Generated 6020(b) |  | X |  |
| 3. | Accounts Maintenance (working transcripts) |  | X |  |
| 4. | ACS Support (individual levy) |  | X |  |
| 5. | AIMS Processing |  | X |  |
| 6. | Processing Amended Returns |  | X |  |
| 7. | Adjust/abate ASFR/A6020(b) assessment (reconsiderations) |  | X |  |
| 8. | Generating ASFR |  | X |  |
| 9. | Processing ASFR/A6020(b) pre-assessment correspondence (other than P-5–133 determinations and disputed income items) |  | X |  |
| 10. | Processing ASFR/A6020(b) pre-assessment correspondence involving P-5-133 determinations and disputed income items. | X |  |  |
| 11. | Associating Responses |  | X |  |
| 12. | Agreed AUR cases-Assessments |  | X |  |
| 13. | Backup withholding hardship determination | X |  |  |
| 14. | Batching |  | X |  |
| 15. | CAF/RAF Processing |  | X |  |
| 16. | Case Analysis for screening (before CP2000) Matching/comparing return information to system information. (Program Code 48X20) |  | X |  |
| 17. | Reconciliation of wages reported on Forms 941 to those reported to SSA (CAWR) |  | X |  |
| 18. | Centralized files and scheduling (Installment Agreements appointments) |  | X |  |
| 19. | Processing claims under $500 |  | X |  |
| 20. | Classifying returns | X |  |  |
| 21. | Clerical/Case Prep |  | X |  |
| 22. | Clerical controls |  | X |  |
| 23. | Clerical Functions (e.g., mail sorting, classification, batching) |  | X |  |
| 24. | Clerical Processing |  | X |  |
| 25. | Closing with secured returns |  | X |  |
| 26. | Closing with previously filed returns |  | X |  |
| 27. | Coding a return |  | X |  |
| 28. | Certified copies (court) |  | X |  |
| 29. | Corr. Examination (including EITC) | X |  |  |
| 30. | Currently Non Collectible (CNC) determination | X |  | Accounts Management (AM) procedures and guidance followed results in this work activity being considered Non-Section 1204 judgment for Adjustment personnel. |
| 31. | DATC/ASTA determination | X |  |  |
| 32. | Data entry |  | X |  |
| 33. | Default/non-response assessments |  | X |  |
| 34. | Preparation of deposit |  | X |  |
| 35. | Non-routine disputed/disagreed issues resolving discrepancies when additional expertise is required | X |  | These decisions involve detailed knowledge of tax law and regulations or material factors or technical judgment or professional judgment. |
| 36. | Resolving discrepancies between information provided by the taxpayer and third party reporting |  | X | This is routine decision making relating to clear cut issues provided for and covered in the IRM. |
| 37. | Dishonored checks |  | X |  |
| 38. | DMF Offset |  | X |  |
| 39. | Editing a return |  | X |  |
| 40. | Entity (Tele-Tin/FAX-TIN/TIN) |  | X |  |
| 41. | Correcting entity |  | X |  |
| 42. | Correct entry (taxpayer or campus employee) |  | X |  |
| 43. | Estate Tax determination to file return based on application of P-5–133 | X |  |  |
| 44. | Excess Collections |  | X |  |
| 45. | Extension to file (2nd, automatic if timely & complete) |  | X |  |
| 46. | Fairness/equity determination (does not follow normal procedures) | X |  |  |
| 47. | Files |  | X |  |
| 48. | Final Category A determination (allowing/not allowing CAT A claims/amended returns) | X |  |  |
| 49. | FIRPTA |  | X |  |
| 50. | Foreign certification (PSC only) |  | X |  |
| 51. | Developing a fraud referral | X |  |  |
| 52. | Freedom of Information Act (FOIA) Privacy requests |  | X |  |
| 53. | Reconciliation of wages reported on Form 940 to those reported to state (FUTA) |  | X |  |
| 54. | IDRS input (e.g., STAUP) |  | X |  |
| 55. | Monitoring of informant claims |  | X |  |
| 56. | Innocent spouse determination using decision tree |  | X |  |
| 57. | Input of Installment Agreements |  | X |  |
| 58. | Streamlined Installment Agreements |  | X |  |
| 59. | Issue notice/request for return based on prior returns, IRP information (systemically generated) |  | X |  |
| 60. | Calculation of interest and penalties (automated-not determining) |  | X |  |
| 61. | Lien, Levy determination (whether to file or release) | X |  | AM procedures and guidance followed results in this work activity being considered Non-Section 1204 Judgment for adjustment personnel. |
| 62. | Inputting Lien, Levy source |  | X |  |
| 63. | Liable/not liable determination to file return based on application of P-5-133 |  | X |  |
| 64. | Mail processing/association |  | X |  |
| 65. | Math Error |  | X |  |
| 66. | Determining ministerial exemption (from SSA) |  | X |  |
| 67. | Non-master file processing |  | X |  |
| 68. | Numbering |  | X |  |
| 69. | Offer-in-compromise acceptance determination (whether to accept, reject, or advise the taxpayer to withdraw the OIC) | X |  |  |
| 70. | Processing Offer-in-compromise (all documents available) |  | X |  |
| 71. | Partnership control system (PCS) |  | X |  |
| 72. | Payment Tracers |  | X |  |
| 73. | Identified (or locating) payments |  | X |  |
| 74. | Moving payments |  | X |  |
| 75. | Researching payments |  | X |  |
| 76. | Penalty abatement adjusted by tax change and other non-discretionary decisions (e.g., disaster) |  | X |  |
| 77. | Penalty abatement (reasonable cause) | X |  | Use of the Reasonable Cause Assistant by AM results in this work activity being considered Non-Section 1204 Judgment for Adjustment personnel. |
| 78. | Penalty assessment (e.g., IRP, FTD) | X |  |  |
| 79. | Perfecting documents |  | X |  |
| 80. | Processability of a return |  | X |  |
| 81. | Quality Review and Correction of notices (Notice Review) |  | X |  |
| 82. | Questionable preparers in CIB | X |  |  |
| 83. | Questionable refund in CIB (paper and EFDS) | X |  |  |
| 84. | RAC processing/posting |  | X |  |
| 85. | RAIVS (transcripts) |  | X |  |
| 86. | Examination reconsiderations (includes SFR reconsiderations) | X |  |  |
| 87. | Refund activity |  | X |  |
| 88. | Manual refunds |  | X |  |
| 89. | Processing Reject returns |  | X |  |
| 90. | Assistance in return preparation (walk-in areas) |  | X |  |
| 91. | Determining correct schedule or form |  | X |  |
| 92. | Sequence |  | X |  |
| 93. | Liable/not liable determination in SFR |  | X |  |
| 94. | Signature missing |  | X |  |
| 95. | Sort |  | X |  |
| 96. | Sorting |  | X |  |
| 97. | Statute determinations |  | X |  |
| 98. | Suspense files |  | X |  |
| 99. | Posting TFRP to IDRS |  | X |  |
| 100. | Providing TIN |  | X |  |
| 101. | Expedite transcripts for disaster |  | X |  |
| 102. | Unallowable coding |  | X |  |
| 103. | Unidentified remittances |  | X |  |
| 104. | Resolving unpostable conditions |  | X |  |
| 105. | Unpostable Resolution (freeze code, hold return) |  | X |  |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-005-002#addtoany "Show all")

A2A