---
url: "https://www.irs.gov/irm/part1/irm_01-022-002"
title: "1.22.2 United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-022-002#main-content)

- 1.22.2  [United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services](https://www.irs.gov/irm/part1/irm_01-022-002#id1)
  - 1.22.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-022-002#id2)
    - 1.22.2.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-022-002#id4)
    - 1.22.2.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-022-002#id5)
    - 1.22.2.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-002#id6)
    - 1.22.2.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-022-002#id7)
    - 1.22.2.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-022-002#id8)
    - 1.22.2.1.6  [Frequently Used Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-022-002#id9)
    - 1.22.2.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-022-002#id10)
  - 1.22.2.2  [Classes of Mail and Additional Services](https://www.irs.gov/irm/part1/irm_01-022-002#id11)
    - 1.22.2.2.1  [First-Class Mail](https://www.irs.gov/irm/part1/irm_01-022-002#id13)
    - 1.22.2.2.2  [Priority Mail](https://www.irs.gov/irm/part1/irm_01-022-002#id14)
    - 1.22.2.2.3  [Marketing Mail](https://www.irs.gov/irm/part1/irm_01-022-002#id15)
    - 1.22.2.2.4  [Parcel Select](https://www.irs.gov/irm/part1/irm_01-022-002#id16)
    - 1.22.2.2.5  [Priority Mail Express](https://www.irs.gov/irm/part1/irm_01-022-002#id17)
    - 1.22.2.2.6  [Extra/Other Services](https://www.irs.gov/irm/part1/irm_01-022-002#id18)
    - 1.22.2.2.7  [Recipient Services](https://www.irs.gov/irm/part1/irm_01-022-002#id19)
  - 1.22.2.3  [Overseas Military and Diplomatic Mail](https://www.irs.gov/irm/part1/irm_01-022-002#id20)
    - 1.22.2.3.1  [Destination Treated as Domestic](https://www.irs.gov/irm/part1/irm_01-022-002#id22)
    - 1.22.2.3.2  [Extra Services](https://www.irs.gov/irm/part1/irm_01-022-002#id23)
  - 1.22.2.4  [International Mail](https://www.irs.gov/irm/part1/irm_01-022-002#id24)
    - 1.22.2.4.1  [First-Class International Mail](https://www.irs.gov/irm/part1/irm_01-022-002#id26)
  - 1.22.2.5  [Small Package Carrier (SPC) Services](https://www.irs.gov/irm/part1/irm_01-022-002#id27)
    - 1.22.2.5.1  [Ground Services](https://www.irs.gov/irm/part1/irm_01-022-002#id29)
    - 1.22.2.5.2  [Air Services](https://www.irs.gov/irm/part1/irm_01-022-002#id30)
    - 1.22.2.5.3  [Extra Services](https://www.irs.gov/irm/part1/irm_01-022-002#id31)
  - 1.22.2.6  [International Packages](https://www.irs.gov/irm/part1/irm_01-022-002#id32)
  - 1.22.2.7  [Designated Private Delivery Service - Background](https://www.irs.gov/irm/part1/irm_01-022-002#id33)
    - 1.22.2.7.1  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-002#id35)

# Part 1. Organization, Finance, and Management

# Chapter 22. Mail and Transportation Management

# Section 2. United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services

* * *

## 1.22.2 United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services

#### Manual Transmittal

August 28, 2025

#### Purpose

(1) This transmits revised IRM 1.22.2, Mail and Transportation Management, United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services.

#### Material Changes

(1) **IRM 1.22.2**revised throughout to update section title from Postal Transport and Policy (PTP) to Postal and Transport (PT).

(2) Editorial changes made throughout section 1.22.2.2.3 changing Standard Mail to Marketing Mail.

#### Effect on Other Documents

IRM 1.22.2, Mail and Transportation Management, United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services dated October 24, 2024 is superseded.

#### Audience

IRS Employees

#### Effective Date

(08-28-2025)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.22.2.1** **(12-28-2000)**

### Program Scope and Objectives

1. Purpose: This IRM section describes classes and types of mail and package services used by the IRS. These services apply to the incoming and outgoing mail.

2. Audience: This information applies to all IRS employees, and those responsible for making decisions in either mail or transportation management.

3. Policy Owner: The responsibility of administering the IRS Mail and Transportation Management program falls under the direction of the Commissioner, Taxpayer Services (TS).

4. Program Owner: Media and Publications (M&P), Distribution (D), is the program owner for the Mail and Transportation Management program and is responsible for developing policies for the effective use of Servicewide postal and transportation services.

5. Primary Stakeholders:



> - IRS Business Units
>
>    - Technology and Program Support (TPS)
>
>    - Postal and Transport (PT)
>
>    - All employees who use mailing and shipping services


**1.22.2.1.1** **(12-28-2000)**

#### Background

1. United States Postal Service (USPS) Classes of Mail, USPS Additional Services and Small Package Carrier (SPC) Services are parts of the Mail and Transportation Management Program that involves the management, control, and facilitation of mail usage to meet customers’ needs while minimizing costs. An efficient mail management program directly affects the relationship with taxpayers and the image and reputation associated with the Service.

2. Mail and Transportation Management program includes the use USPS, Small Package Carriers, and other mail services.

3. The manual contains the following information:



> - Classes of Mail and Additional Services
>
>    - Overseas Military and Diplomatic Mail
>
>    - International Mail
>
>    - SPC Services
>
>    - International Packages
>
>    - Designated Private Delivery Service (PDS)
>
>    - References


**1.22.2.1.2** **(12-28-2020)**

#### Authority

1. 26 CFR 301.7502, Timely Mailing of Documents and Payments Treated as Timely Filing and Paying

2. 31 CFR 362, Declaration of Valuables Under the Government Losses in Shipment Act

3. 39 CFR 310, Enforcement of the Private Express Statutes

4. 39 CFR 320, Suspension of the Private Express Statutes

5. 41 CFR 102-192, Mail Management

6. Policy Statement 1-113, Postage-paid envelopes furnished with third party inquires Statements - IRM 1.2.1, Servicewide Policies and Authorities, Servicewide Policy


**1.22.2.1.3** **(11-09-2022)**

#### Roles and Responsibilities

1. Taxpayer Services (TS)/Media and Publications (M&P)/Technology and Program Support (TPS):



> 1. Provides guidance and support to the affected stakeholders, including expense verification, adjustments, and reconciliation.

2. Postal and Transport (PT):



> 1. Develops and evaluates policies, systems, procedures and standards for mail and transportation services
>
> 2. Serves as Contracting Officer Representatives (CORs) on Mail and Transportation contracts and Tenders of Service
>
> 3. Stewardship of the PDS application process.

3. Facilities Management and Security Services (FMSS)/Office of the Deputy Director Facilities Support/Logistics:



> 1. Oversees the operation of the Mail Management program.
>
> 2. Establishes a Territory Point of Contact (TPOC) who provides mail management program guidance for mailroom operations and mail services within their Territory.
>
> 3. Services as the Contracting Officer’s Representatives (COR) for the National Mailroom Services Contract, and the National Postal Meter Contract
>
> 4. Communicates changes in policy to field offices
>
> 5. Provides TPOCs with training and education

4. Business Operating Divisions (BOD) assign Local Points of Contact (LPOC) in IRS Field offices not serviced by the Primary Mail Contractor. The LPOC serves as the primary contact for the FMSS Mail Program TPOC.


**1.22.2.1.4** **(12-28-2000)**

#### Program Management and Review

1. The Postal and Transport (PT) Section develops and evaluates policies, and standards for mail and transportation.

2. PT reviews and determines approval of PDS applications for designation.

3. PT provides contractual support for the small package carrier contract.


**1.22.2.1.5** **(12-28-2000)**

#### Program Controls

1. PT Section has oversight over the following activities:



> - Administers transportation related contracts that include small package delivery, bulk international mail processing and shipping supplies
>
>    - Maintains the SPC web-based shipping program
>
>    - Establishes USPS Permit and Business Reply Mail (BRM) accounts for Government Printing Office (GPO) print contractors and IRS offices
>
>    - Provides guidance on postal requirements to IRS offices
>
>    - Manages the Office Locations and Mailing Addresses (OLMA) database


**1.22.2.1.6** **(11-09-2022)**

#### Frequently Used Terms and Acronyms

1. The table below contains commonly used mail terms and their definitions.




| **Term** | **Definition** |
| --- | --- |
| Business Reply Mail (BRM) | Specially designed reply envelopes and labels preprinted with the notation "Business Reply Mail" stating that "POSTAGE WILL BE PAID BY THE INTERNAL REVENUE SERVICE" and pre-addressed to an IRS office. |
| Courtesy Reply Mail | Pre-addressed printed envelopes that require postage. |
| Extra Services | Value added products that provide greater security and accountability for mail, or improved handling. |
| First Class Mail | A mail class that includes all matter wholly or partly in writing or typewriting, all actual and personal correspondence, all bills and statements of account, and all matter sealed or otherwise closed against inspection. |
| Mail Class | The classification of domestic mail according to content (e.g., personal correspondence versus printed advertising). |

2. The table below contains acronyms and their definitions.




| **Acronym** | **Definition** |
| --- | --- |
| APOs | Army/Airforce Post Offices |
| BRM | Business Reply Mail |
| COR | Contracting Officer’s Representative |
| D | Distribution |
| DMM | Domestic Mail Manual |
| DPOs | Diplomatic Post Offices |
| FMSS | Facilities Management and Security Services |
| FPOs | Fleet Post Offices |
| GPO | Government Printing Office |
| IMpb | Intelligent Mail Package Barcodes |
| LPOC | Local Points of Contact |
| MPOs | Military Post Offices |
| M&P | Media and Publications |
| OLMA | Office Locations and Mailing Addresses |
| PDS | Private Delivery Service |
| PT | Postal and Transport |
| SP | Submission Processing |
| SPC | Small Package Carrier |
| TF&P | Tax Forms and Publications |
| TS | Taxpayer Services |
| TPS | Technology and Program Support |
| TPOC | Territory Point of Contact |
| USPS | United States Postal Service |


**1.22.2.1.7** **(12-28-2020)**

#### Related Resources

1. Related resources include:



> - USPS Domestic Mail Manual
>
>    - USPS Notice 123, Price List
>
>    - USPS Publication 370, Extra Services
>
>    - USPS Postal Bulletin
>
>    - Revenue Procedure 97-19
>
>    - Notice 2016-30, IRB 2016-18
>
>    - Memorandum of Understanding between Distribution, Submission Processing and Appeals, dated January 5, 2015


**1.22.2.2** **(08-08-2018)**

### Classes of Mail and Additional Services

1. The following sections describe the classes and types of mail and package services used by the IRS. These services apply to incoming and outgoing mail.


**1.22.2.2.1** **(08-08-2018)**

#### First-Class Mail

1. As defined by 39 CFR 310, First-Class Mail includes handwritten and typewritten correspondence, bills and statements of accounts, remittances (checks), post cards and Business Reply Mail (BRM). First-Class Mail is personal and may _not_ be opened for postal inspection. First-Class Mail is for individual pieces weighing 13 ounces or less. It includes forwarding service to a new address for up to 12 months or return service if the piece is not delivered. All envelopes or packages labeled First-Class Mail weighing more than 13 ounces are handled as Priority Mail.

2. The USPS is the primary carrier for all correspondence between IRS and the public. The following general guidelines should be used to ensure economic handling of First-Class Mail:



> 1. Single pieces of correspondence should be mailed in standard letter size envelopes, not in flat size envelopes. The only exception would be photographs or other items that may be damaged by folding. The USPS charges higher rates for large or flat size envelopes.
>
> 2. Multiple items sent to the same address should be combined into a single large envelope, as allowed by statute.
>
> 3. If damage to the insert will not occur by folding, all inserts should be folded to allow the use of a standard letter size envelope.


**1.22.2.2.2** **(12-28-2020)**

#### Priority Mail

1. All First-Class Mail weighing more than 13 ounces is designated Priority Mail and given First-Class Mail handling. Rates are based on zone and weight. USPS tracking is included at no extra cost. Priority Mail matter is closed against postal inspection.

2. Guidelines when using Priority Mail are:



> - All taxpayer correspondence weighing more than 13 ounces must be sent Priority Mail.
>
>    - USPS Priority Mail packaging should be used whenever feasible
>
>    - If not using USPS Priority Mail packaging, the mailer must prominently mark "PRIORITY MAIL" on the address side of the mail piece

3. Flat Rate can be a cost-effective alternative to Priority Mail:



> - Only USPS-produced Flat Rate boxes are eligible for the Flat Rate box prices
>
>    - Each USPS-produced Flat Rate box is charged a flat rate regardless of the actual weight (up to 70 pounds) or domestic destination
>
>    - Various USPS-produced Flat Rate boxes are available with different predetermined prices
>
>    - Flat Rate boxes ordered from USPS are free of charge


**1.22.2.2.3** **(08-08-2018)**

#### Marketing Mail

1. Marketing Mail consists of items that are not required to be mailed as First-Class Mail. It is non-personal, and each piece must weigh less than 16 ounces. Examples of Marketing Mail are:



> - Tax Products
>
>    - Printed matter, flyers, circulars, advertising
>
>    - Newsletters, bulletins, and catalogs
>
>    - Small parcels

2. This class of mail is not appropriate for mailing an individual piece of mail. Each mailing must meet a minimum quantity of 200 pieces or 50 pounds of mail. There is no single-piece Marketing Mail Postage. Refer to the Domestic Mail Manual (DMM) for detailed requirements.

3. Forwarding and return must be endorsed on each piece. The IRS pays for the forwarding and return of properly endorsed MarketingMail pieces using a weighted factor as directed by the DMM.


**1.22.2.2.4** **(08-08-2018)**

#### Parcel Select

1. Parcel Select consists of mailable matter not required to be mailed as First-Class Mail.

2. This class of mail reduces postage costs by allowing the mailer to enter bulk shipments of packages into the USPS delivery network. Each mailing must meet a 50-piece minimum. Size and weight limitations are available in the DMM.

3. All Parcel Select mail pieces must bear an intelligent mail package barcodes (IMpb) or be assessed a noncompliance fee.


**1.22.2.2.5** **(08-08-2018)**

#### Priority Mail Express

1. Priority Mail Express should be restricted to unique circumstances where the next day delivery of a mail piece is mandatory and failure to deliver the piece will have detrimental effect on conducting business. Priority Mail Express is guaranteed expedited service that offers tracking.

2. The use of this service is restricted to mail addressed to:



> - A USPS facility
>
>    - A USPS Post Office (P.O.) Box
>
>    - When an USPS postmark is required by law as proof of mailing

3. Form 9814, Request for Mail/Shipping Service, is required for all IRS locations where designated mailroom personnel are creating shipping labels or placing postage on packages.


**1.22.2.2.6** **(08-08-2018)**

#### Extra/Other Services

1. Extra Services are value-added products that provide greater security and accountability for mail, or improved handling. These services are available for a fee in addition to regular postage and are not available for all classes of mail. Certified Mail, Certificate of Mailing, Delivery Confirmation, Registered Mail, Restricted Delivery and Return Receipt are examples of Extra Services that should be used in unique situations or where required by the statute. See the DMM for limitations. Other services include Penalty Business Reply Mail.



> 1. Certified Mail provides a record of mailing to the sender and a record of delivery at the Post Office of delivery for two years. Mail pieces requiring a postmarked sender's receipt must be mailed at a USPS office. Certified Mail does not travel any faster than First-Class Mail and does not receive any extra security protection.
>
> 2. Certificate of Mailing provides evidence that mail has been presented to the USPS for mailing but does not provide a record of delivery. This method is preferred over the use of Registered or Certified Mail services when these service types are not mandated by statute.
>
> 3. Delivery Confirmation provides information about date and time when an article is delivered, or delivery was attempted but unsuccessful.
>
> 4. Registered Mail provides sender with mailing receipt at point of mailing and a delivery record is maintained at the mailing Post Office. It is the most secure service offered by the USPS, tracked from the time of mailing to time of delivery, transported under lock separately from other mail and may not be deposited in collection boxes.
>
> 5. Restricted Delivery provides mail to a specific addressee or the addressee's authorized agent as instructed by the mailer.
>
> 6. Return Receipt provides sender with proof of delivery (to whom the mail was delivered and date of delivery).
>
> 7. Penalty BRM service uses a postage paid return envelope, label, or postcard.


**1.22.2.2.7** **(12-28-2000)**

#### Recipient Services

1. P.O. Box and Caller Service are premium services offered for a fee and are now funded through the Official Mail Accounting System. Offices requiring this service should contact their servicing Facilities Management Territory Point of Contact (TPOC) for assistance.

2. Payment for P.O. Box service is required in 6-month (semi-annual) or 12-month (annual) increments. P.O. Boxes are available in various sizes and are assigned by a postal facility based on individual needs.

3. Utilization of P.O. Boxes should be reviewed annually by local offices for number of boxes required and their purpose.

4. Caller Service is available if incoming mail exceeds the capacity of the largest available P.O. Box. This service allows a customer to pick up mail at a Post Office call window or loading dock.


**1.22.2.3** **(11-09-2022)**

### Overseas Military and Diplomatic Mail

1. Mail addressed to military post offices (MPOs) and diplomatic post offices (DPOs) overseas, is subject to certain conditions or restrictions regarding content, preparation, and handling.



> 1. MPOs are operated by the Army, Navy, Air Force or the Marine Corps to serve military personnel overseas or aboard ships.
>
> 2. Army/Air Force Post Office (APO) serves the Army or Air Force personnel.
>
> 3. Fleet Post Office (FPO) serves the Coast Guard, Navy or Marine Corps personnel
>
> 4. DPOs are established by the Department of State and serve overseas personnel at the U.S. Embassies and Consulates.

2. While SPCs such as FedEx® and UPS® offer delivery to countries where military personnel may be stationed, the USPS is the only carrier that can deliver mail and packages to APO/FPO/DPO locations.


**1.22.2.3.1** **(12-28-2020)**

#### Destination Treated as Domestic

1. USPS mail sent within and between the United States, its territories, and possessions (e.g., American Samoa Guam, Puerto Rico, and the Virgin Islands), an APO/FPO/DPO, and the United Nations, NY is treated as domestic mail.

2. In addition, mail sent to or from Freely Associated States (e.g., Marshall Island and Micronesia) is treated as domestic mail when the mail:



> - Originates from Freely Associated States for delivery within and between the Freely Associated States and the U.S., its territories, and possessions, APOs/FPOs/DPOs, and the United Nations, NY
>
>    - Originates from the U.S., its territories, and possessions, an APO/FPO/DPO or the United Nations, NY for delivery to the Freely Associated States

3. Certain conditions and restrictions apply when mailing overseas to Military/Diplomatic Mail and to the Freely Associated States. These conditions and restrictions are outlined in the USPS Postal Bulletin and are available at: [https://postcalc.usps.com/MilitaryRestrictions](https://postcalc.usps.com/MilitaryRestrictions). Overseas Military/Diplomatic Mail conditions and restrictions are listed by APO/FPO/DPO ZIP codes through the use of footnoted mailing restriction codes. USPS Postal Bulletin is updated bi-weekly.


**1.22.2.3.2** **(08-08-2018)**

#### Extra Services

1. Extra services commonly used for IRS mail are available for many APO/FPO/DPO destinations and ZIP codes in U.S. territories, possessions, or Freely Associated States.

2. Extra or additional services may be added at the time of mailing if the standards for the services are met, and the applicable fees are paid.

3. Information about extra services is available in the DMM and the USPS Postal Bulletin at: [http://pe.usps.gov/text/dmm300/503.htm](http://pe.usps.gov/text/dmm300/503.htm)


**1.22.2.4** **(11-09-2022)**

### International Mail

1. International Mail is mail addressed to or received from foreign countries and excludes mail originating in the United States of America, its territories, and possessions.

2. When mailing to foreign countries, the destination and size of envelope should be considered. Postage rates are based on the level of service, zone, and weight of the mail piece.

3. Dependent upon the destination country and its rules and regulations, extra services may be available, but should only be used in unique situations or where required by statute.

4. When mailing internationally, Registered Mail is the replacement service to USPS Certified Mail.

5. Return Receipts are completed in the destination country which may not require the addressee's signature. Receipts are returned by airmail.

6. USPS International Mail Manual (IMM) contains detailed information related to services, conditions of mailing, extra services, and mail preparation, including U.S. Customs requirements.


**1.22.2.4.1** **(08-08-2018)**

#### First-Class International Mail

1. First-Class International Mail meets the criterion outlined for First-Class Mail in _IRM 1.22.2.2.1_, First-Class Mail. It is the most economical method to send letters and large envelopes using USPS.

2. Undeliverable mail will be returned in accordance with the regulations of the destination country.


**1.22.2.5** **(11-09-2022)**

### Small Package Carrier (SPC) Services

1. The following sections describe the SPC services in use by the IRS.

2. Packages not containing remittances and weighing 13 ounces or less will be sent via the USPS.

3. All packages tendered to a SPC are assigned a tracking number. This tracking number will be used to ensure delivery.

4. A SPC cannot be used for packages being sent to a USPS Post Office, USPS P.O. Box, APO, FPO or DPO address. These packages must be sent via the USPS.

5. SPC time in transit and actual delivery days are Monday through Friday.

6. The SPC does not include forwarding services to a new address. When a package is not deliverable or refused by the occupant, a SPC will attempt to locate a new address through publicly available address services. If the attempt is unsuccessful, the package is returned to the sender.

7. In consideration of the health and safety of all employees, each SPC package should not exceed 30 pounds. Additional handling charges will apply for packages weighing more than 90 pounds. Packages weighing 70 - 150 pounds must be tagged with a SPC Heavy Weight label. Packages weighing over 150 pounds are classified as freight and may not be sent by SPC. Refer to IRM 1.22.6, Transportation Management, for information on freight services.

8. In 2021, UPS converted IRS accounts for offices that ship low volumes of packages or ship infrequently to UPS Smart Pickup Service. The UPS Smart Pickup® service uses technology to arrange a pickup only when there are packages to ship.

9. To report a SPC problem or request a service, shippers should:



> 1. Submit an IRS KISAM OS GetServices request for the following:
>
>
>
>       > - Assistance with UPS CampusShip User Id or Password
>       >
>       >       - Registration for UPS CampusShip
>       >
>       >       - UPS account information, to update user’s account/location, name, or contact information.
>       >
>       >       - UPS CampusShip Ordering Shipping Supplies Information
>       >
>       >       - UPS CampusShip User Guides
>       >
>       >       - Assistance with Other UPS CampusShip Related Items such as to report a problem with UPS service or driver, for assistance with lost or missing package, or other assistance not listed.
>
> 2. For all other questions and requests, send an e-mail to: \*\*TS M&P Small Package Carriers <ts.mp.small.package@irs.gov>.


**1.22.2.5.1** **(08-08-2018)**

#### Ground Services

1. SPCs provide one-to-six-day delivery based upon distance. Packages can include documents and case files that are contained in either a corrugated cardboard box or 9 x 12 and larger envelope. SPC ground services are date delivery guaranteed that offer tracking.

2. SPC Ground Services are generally the most economical and preferred shipping option for packages weighing more than 13 ounces. Cost for ground package services is dependent on zone and weight.

3. Form 9814, Request for Mail/Shipping Service, is required for all ground shipments at locations serviced by a Campus mailroom or IRS contract mailroom.


**1.22.2.5.2** **(08-08-2018)**

#### Air Services

1. SPC Air Services should be restricted to unique circumstances where next day delivery of a package is mandatory and failure to deliver the package will have a detrimental effect on conducting business. SPC Air Services are guaranteed expedited services that offer tracking.

2. The following SPC Air Services are authorized for use:



1. 2nd Business Day Delivery Service - Guaranteed delivery by close of business on 2nd business day

2. Next Business Day Delivery Service - Guaranteed delivery by 10:30 AM (most areas)


3. There are other air delivery options offered by SPCs. The following services are not authorized due to excessive cost:



> - FedEx First Overnight
>
>    - UPS Next Day Early AM
>
>    - Any Same Day Delivery Service

4. Form 9814, Request for Mail/Shipping Service, is required for all air shipments at locations serviced by a Campus mailroom or IRS contract mailroom.


**1.22.2.5.3** **(08-08-2018)**

#### Extra Services

1. Extra services, also known as accessorial fees, are value-added options offered by SPCs that can be combined with the ground and air shipment for an additional fee. Declared Value, Delivery Confirmation, Saturday Delivery, and Residential Delivery are examples of accessorial services.



> 1. Declared Value, known as insurance, is not to be used unless specified by the Postal and Transport (PT) Section. A SPC's liability for loss or damage to a shipment is $100 without declaration of value. Shipments exceeding $100 in value are considered self-insured.
>
> 2. Delivery Confirmation is only offered in combination with "Signature Required" or "Adult Signature Required." These services do not meet statutory requirements for signature receipt related to tax assessment or collection of tax liabilities.
>
> 3. Saturday Delivery is high cost and can only be used in extreme circumstances.
>
> 4. Residential Delivery is defined as a delivery to a location that does not have an entrance open to the public. Residential charges on ground shipments are significantly less expensive than residential charges on air shipments.


**1.22.2.6** **(08-08-2018)**

### International Packages

1. International packages are addressed to foreign countries. Next Day delivery is not available to most international destinations. Standard international delivery times begin at two days but vary according to destination, country, and carrier.

2. Ground services are available from the Continental U.S. to Alaska, Hawaii, and Puerto Rico. Any other countries are considered international.

3. Rates are based on level of service, zone, and weight of the mail piece. SPC international shipping should only be utilized in unique circumstances.


**1.22.2.7** **(08-08-2018)**

### Designated Private Delivery Service - Background

1. In June 2014, the Distribution organization assumed responsibility for completing the initial and administrative reviews of private delivery service (PDS) applications and for establishing a new application address.

2. Returns, payments and certain tax court documents are considered timely mailed when using the USPS or certain designated PDS.

3. For a PDS to be deemed ‘designated,’ the company must submit an application to IRS and receive approval. There is one annual application period for a PDS to apply for designation, which ends on June 30, of the year preceding that filing season. A list of designated PDS companies is updated as a PDS is added or removed from the list.

4. The current list of designated PDS companies is published in Notice 2016-30, IRB 2016-18, for purposes of the timely mailing treated as timely filing/paying rule of section 7502 of the Internal Revenue Code.


**1.22.2.7.1** **(08-08-2018)**

#### Responsibilities

1. Media and Publications (M&P)/Distribution (D), is the steward of the designated PDS application process. Technology and Program Support (TPS)/PT) section manages the application process. The PT section office address in Dallas, TX serves as the filing address for PDS applications and related correspondence.

2. PT responsibilities include:



> - Review of initial applications in accordance with the criteria found in Revenue Procedure 97-19
>
>    - Notify the Appeals point of contact (POC) of any new applications and include them in all discussions with Chief Counsel, during the review process
>
>    - Document the initial review using a criteria checklist and include any comments or guidance provided by the Chief Counsel
>
>    - Make recommendation to approve or deny the application for PDS mail service
>
>    - If the recommendation is to approve the application, prepare and submit a memo to Chief Counsel for review and concurrence
>
>    - If the recommendation is to deny the application, prepare a denied letter to the PDS and submit to Chief Counsel for review and concurrence
>
>    - Conduct all administrative reviews, prepare a response, and provide to Chief Counsel for review and concurrence
>
>    - Establish a historical file containing all documentation for future reference
>
>    - Notify Tax Forms and Publications (TF&P) of any changes in PDS designations by October 15
>
>    - Notify Submission Processing (SP) of any changes to the current list of designated PDSs

3. Submission Processing makes the necessary updates on IRS.gov at https://www.irs.gov regarding designated PDSs upon written notification from PT. SP also updates applicable internal revenue manuals (IRMs).

4. Appeals roles and responsibilities include:



> - Review all supporting documentation submitted by the PDS
>
>    - Make determination of whether the PDS application meets the criteria as stated in Revenue Procedure 97-19
>
>    - Prepare a memo and submit to Chief Counsel if recommendation is to approve the application
>
>    - Prepare a denial letter and mail to the applicant (PDS) if recommendation is to deny the application, and send a copy to Chief Counsel
>
>    - Notify PT POC of any changes in PDS designation
>
>    - Establish a historical file containing all documentation for future reference
>
>    - Send copies to PT POC and Chief Counsel


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-022-002#addtoany "Show all")

A2A