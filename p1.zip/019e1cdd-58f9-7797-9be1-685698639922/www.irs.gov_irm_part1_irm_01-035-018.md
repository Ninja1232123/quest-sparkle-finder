---
url: "https://www.irs.gov/irm/part1/irm_01-035-018"
title: "1.35.18 Imprest Funds | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-035-018#main-content)

- 1.35.18  [Imprest Funds](https://www.irs.gov/irm/part1/irm_01-035-018#id1)
  - 1.35.18.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-035-018#id2)
    - 1.35.18.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-035-018#id3)
    - 1.35.18.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-035-018#id4)
    - 1.35.18.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-018#id5)
      - 1.35.18.1.3.1  [Chief Financial Officer and Deputy Chief Financial Officer](https://www.irs.gov/irm/part1/irm_01-035-018#id7)
      - 1.35.18.1.3.2  [Associate Chief Financial Officer for Financial Management and Deputy Associate Chief Financial Officer for Administrative Financial Management](https://www.irs.gov/irm/part1/irm_01-035-018#id8)
      - 1.35.18.1.3.3  [Director, Accounts Payable](https://www.irs.gov/irm/part1/irm_01-035-018#id9)
      - 1.35.18.1.3.4  [Director, Government Payables and Funds Management](https://www.irs.gov/irm/part1/irm_01-035-018#id10)
      - 1.35.18.1.3.5  [Director, Financial Reporting](https://www.irs.gov/irm/part1/irm_01-035-018#id11)
      - 1.35.18.1.3.6  [Chief, Criminal Investigation](https://www.irs.gov/irm/part1/irm_01-035-018#id12)
      - 1.35.18.1.3.7  [Criminal Investigation Director, Field Operations](https://www.irs.gov/irm/part1/irm_01-035-018#id13)
      - 1.35.18.1.3.8  [Criminal Investigation Director, Special Investigative Techniques](https://www.irs.gov/irm/part1/irm_01-035-018#id14)
      - 1.35.18.1.3.9  [Criminal Investigation Director/Assistant Director, Finance](https://www.irs.gov/irm/part1/irm_01-035-018#id15)
      - 1.35.18.1.3.10  [Criminal Investigation Special Agents-in-Charge](https://www.irs.gov/irm/part1/irm_01-035-018#id16)
      - 1.35.18.1.3.11  [Criminal Investigation Director, International Operations](https://www.irs.gov/irm/part1/irm_01-035-018#id17)
      - 1.35.18.1.3.12  [Criminal Investigation Special Agents and Attachés](https://www.irs.gov/irm/part1/irm_01-035-018#id18)
      - 1.35.18.1.3.13  [Criminal Investigation Cashiers](https://www.irs.gov/irm/part1/irm_01-035-018#id19)
      - 1.35.18.1.3.14  [Criminal Investigation Alternate Cashiers](https://www.irs.gov/irm/part1/irm_01-035-018#id20)
      - 1.35.18.1.3.15  [Criminal Investigation International Operations Sub-cashiers](https://www.irs.gov/irm/part1/irm_01-035-018#id21)
    - 1.35.18.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-035-018#id22)
    - 1.35.18.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-035-018#id23)
    - 1.35.18.1.6  [Terms/Definitions](https://www.irs.gov/irm/part1/irm_01-035-018#id24)
    - 1.35.18.1.7  [Acronyms](https://www.irs.gov/irm/part1/irm_01-035-018#id25)
    - 1.35.18.1.8  [Related Resources](https://www.irs.gov/irm/part1/irm_01-035-018#id26)
  - 1.35.18.2  [Types of Imprest Funds](https://www.irs.gov/irm/part1/irm_01-035-018#id27)
    - 1.35.18.2.1  [Criminal Investigation Imprest Fund (Domestic Operations)](https://www.irs.gov/irm/part1/irm_01-035-018#id29)
    - 1.35.18.2.2  [Criminal Investigation Imprest Funds (International Operations)](https://www.irs.gov/irm/part1/irm_01-035-018#id30)
  - 1.35.18.3  [Establishing an Imprest Fund](https://www.irs.gov/irm/part1/irm_01-035-018#id31)
    - 1.35.18.3.1  [Imprest Funds Requesting Officials](https://www.irs.gov/irm/part1/irm_01-035-018#id33)
    - 1.35.18.3.2  [OF 211 worksheet, Request for Change or Establishment of Imprest Fund](https://www.irs.gov/irm/part1/irm_01-035-018#id34)
  - 1.35.18.4  [Designation of Cashiers](https://www.irs.gov/irm/part1/irm_01-035-018#id35)
    - 1.35.18.4.1  [Designating a Sub-Cashier](https://www.irs.gov/irm/part1/irm_01-035-018#id37)
  - 1.35.18.5  [Establishing an Imprest Fund Checking Account](https://www.irs.gov/irm/part1/irm_01-035-018#id38)
    - 1.35.18.5.1  [Establishing or Transferring Checking Accounts](https://www.irs.gov/irm/part1/irm_01-035-018#id40)
    - 1.35.18.5.2  [Checking Account Signature Cards](https://www.irs.gov/irm/part1/irm_01-035-018#id41)
    - 1.35.18.5.3  [Change in Financial Institution or Financial Institution Information](https://www.irs.gov/irm/part1/irm_01-035-018#id42)
  - 1.35.18.6  [Funding an Imprest Fund](https://www.irs.gov/irm/part1/irm_01-035-018#id43)
    - 1.35.18.6.1  [Increases or Decreases to an Investigative Imprest Fund](https://www.irs.gov/irm/part1/irm_01-035-018#id45)
  - 1.35.18.7  [Changes in Cashiers](https://www.irs.gov/irm/part1/irm_01-035-018#id46)
    - 1.35.18.7.1  [Planned Cashier Absences and Transfer of Accountability](https://www.irs.gov/irm/part1/irm_01-035-018#id48)
    - 1.35.18.7.2  [Unplanned Cashier Absence](https://www.irs.gov/irm/part1/irm_01-035-018#id49)
    - 1.35.18.7.3  [Termination of Cashier's Designation](https://www.irs.gov/irm/part1/irm_01-035-018#id50)
  - 1.35.18.8  [Cashier Responsibilities](https://www.irs.gov/irm/part1/irm_01-035-018#id51)
    - 1.35.18.8.1  [Advances to Investigative Personnel](https://www.irs.gov/irm/part1/irm_01-035-018#id52)
    - 1.35.18.8.2  [Expenditures](https://www.irs.gov/irm/part1/irm_01-035-018#id53)
    - 1.35.18.8.3  [Income from Operations](https://www.irs.gov/irm/part1/irm_01-035-018#id54)
      - 1.35.18.8.3.1  [Authorized Churning](https://www.irs.gov/irm/part1/irm_01-035-018#id56)
      - 1.35.18.8.3.2  [Earned Interest](https://www.irs.gov/irm/part1/irm_01-035-018#id57)
    - 1.35.18.8.4  [Security Deposits](https://www.irs.gov/irm/part1/irm_01-035-018#id58)
    - 1.35.18.8.5  [Monthly Reconciliation and Reporting](https://www.irs.gov/irm/part1/irm_01-035-018#id59)
    - 1.35.18.8.6  [Checking Account Replenishment](https://www.irs.gov/irm/part1/irm_01-035-018#id60)
  - 1.35.18.9  [Imprest Fund Internal Controls](https://www.irs.gov/irm/part1/irm_01-035-018#id61)
    - 1.35.18.9.1  [Physical Security](https://www.irs.gov/irm/part1/irm_01-035-018#id62)
    - 1.35.18.9.2  [Authorizations](https://www.irs.gov/irm/part1/irm_01-035-018#id63)
    - 1.35.18.9.3  [Separation of Duties](https://www.irs.gov/irm/part1/irm_01-035-018#id64)
    - 1.35.18.9.4  [Validations](https://www.irs.gov/irm/part1/irm_01-035-018#id65)
    - 1.35.18.9.5  [Audits and Independent Reviews](https://www.irs.gov/irm/part1/irm_01-035-018#id66)
      - 1.35.18.9.5.1  [Monthly Audits](https://www.irs.gov/irm/part1/irm_01-035-018#id68)
      - 1.35.18.9.5.2  [Unannounced Cash Audits](https://www.irs.gov/irm/part1/irm_01-035-018#id69)
      - 1.35.18.9.5.3  [Transfer of Accountability Audits](https://www.irs.gov/irm/part1/irm_01-035-018#id70)
      - 1.35.18.9.5.4  [Independent Reviews](https://www.irs.gov/irm/part1/irm_01-035-018#id71)
      - 1.35.18.9.5.5  [Audit Process](https://www.irs.gov/irm/part1/irm_01-035-018#id72)
  - 1.35.18.10  [Imprest Fund Losses](https://www.irs.gov/irm/part1/irm_01-035-018#id73)
    - 1.35.18.10.1  [Required Action](https://www.irs.gov/irm/part1/irm_01-035-018#id75)
    - 1.35.18.10.2  [Debt Collection](https://www.irs.gov/irm/part1/irm_01-035-018#id76)
    - 1.35.18.10.3  [Relief of Cashiers](https://www.irs.gov/irm/part1/irm_01-035-018#id77)
    - 1.35.18.10.4  [Grounds for Relief](https://www.irs.gov/irm/part1/irm_01-035-018#id78)
    - 1.35.18.10.5  [Requesting Relief](https://www.irs.gov/irm/part1/irm_01-035-018#id79)
  - 1.35.18.11  [Closing an Investigative Imprest Fund](https://www.irs.gov/irm/part1/irm_01-035-018#id80)
  - Exhibit  1.35.18-1  [Standard Form 1129 - Cashier Reimbursement Voucher and/or Accountability Report](https://www.irs.gov/irm/part1/irm_01-035-018#id81)
  - Exhibit  1.35.18-2  [Standard Form 1149 - Statement of Designated Depositary Account](https://www.irs.gov/irm/part1/irm_01-035-018#id82)

# Part 1. Organization, Finance, and Management

# Chapter 35. Financial Accounting

# Section 18. Imprest Funds

* * *

## 1.35.18 Imprest Funds

#### Manual Transmittal

August 29, 2025

#### Purpose

(1) This transmits revised IRM 1.35.18, Financial Accounting, Imprest Funds.

#### Material Changes

(1) Updated internal controls.

(2) Added quick links to IRM’s, email addresses, forms, and websites references throughout the IRM.

(3) Removed “and Financial Operations” after “Accounts Payable” throughout the IRM.

(4) Removed “or CI Director/Assistant Director, Finance” throughout the IRM.

(5) Subsection 1.35.18.1.3.6(1)(c) removed “including approval of an undercover plan for operations.”

(6) Subsection 1.35.18.1.3.7(1)(b) removed “including approval of an undercover plan for operations.”

(7) Subsection 1.35.18.1.3.8(h) added “May be delegated to Assistant Director, Special Investigative Techniques.”

(8) Subsection 1.35.18.1.3.9 combined (1) and (1)(a) to state “The Criminal Investigation Director/Assistant Director, Finance is responsible for committing and obligating funds for the investigative fund program” and removed (b) “For additional information on these responsibilities, see IRM 1.35.18.1.3.8, CI Director, SIT (1) d through n.”

(9) Removed subsection 1.35.18.1.3.11(e) “Approving reimbursements from the international investigative authorization.”

(10) Removed subsection 1.35.18.1.3.11(f) “Reviewing month-end reports.”

(11) Removed subsection 1.35.18.1.3.11(i) “Maintaining audit reports for six years and three months and maintaining record disposal of all closed reports for ten years and three months.”

(12) Removed subsection 1.35.18.1.3.15(1)(b) “All SIT sub-cashier’s funds are advanced from the SIT cashier.”

(13) Removed subsection 1.35.18.1.6(1)(e) “Class D cashier - A cashier, officer, or employee who receives an advance from a federal agency appropriation solely for change-making purposes. They may advance funds to sub-cashiers for change-making purposes only upon authorization by the head of the federal agency from which they received the advance. The Class D cashier is personally accountable to the head of the federal agency for the entire amount of the advance.”

(14) Subsection 1.35.18.3.2(1)(f) removed “Special Agent in Charge or Criminal Investigation Attaché (International Operations)” and added “Director, SIT.”

(15) Removed subsection 1.35.18.5.1(3) “The Director, Accounts Payable and Financial Operations or his/her designee, signs the signature card.”

(16) Removed subsection 1.35.18.5.1(4) “The Accounts Payable and Financial Operations office via the Miscellaneous Programs Unit sends the original signed signature cards, the original Certification to Resolutions Governing Bank Account (from the financial institution), and the original Standard Form 3881 to the requesting official.”

(17) Removed subsection 1.35.18.5.2(5) “The Director, Accounts Payable and Financial Operations, signs the signature cards.

(18) Removed subsection 1.35.18.5.2(6) “The Accounts Payable and Financial Operations office via the Miscellaneous Programs Unit sends the original signed signature cards to the cashiers.”

(19) Subsection 1.35.18.8.1(1) updated “special agent” to “assigned Storefront Cover Agent” and “the special agent returns the funds immediately” to “the funds are returned.”

(20) Subsection 1.35.18.8.1(4) update “special agent” to “Storefront Cover Agent.” Added “from the special agents who made authorized expenditures.”

(21) Added Exhibit 1.35.18-1, Standard Form 1129 - Cashier Reimbursement Voucher and/or Accountability Report.

(22) Added Exhibit 1.35.18-2, Standard Form 1149 - Statement of Designated Depositary Account.

(23) Editorial changes made throughout the IRM that did not result in substantive changes but contributed to clarity of the subject matter.

#### Effect on Other Documents

This IRM supersedes IRM 1.35.18, dated May 28, 2024.

#### Audience

Criminal Investigation

#### Effective Date

(08-29-2025)

Justin H. Campbell

Acting Deputy Chief, Criminal Investigation

for

Guy A. Ficco

Chief, Criminal Investigation

**1.35.18.1** **(08-29-2025)**

### Program Scope and Objectives

1. Purpose: This section focuses on the process for managing imprest funds.

2. Audience: All Criminal Investigation employees.

3. Policy Owner: Executive Director, Global Operations Policy & Support.

4. Program Owners: Director, Special Investigative Techniques within Global Operations Policy & Support.

5. Primary Stakeholders: All Criminal Investigation employees.

6. Program Goals: To provide guidelines and procedures for Criminal Investigation employees to follow to ensure accuracy and timeliness for imprest funds.


**1.35.18.1.1** **(08-29-2025)**

#### Background

1. Under the Debt Collection Improvement Act of 1996, P.L. 104-134, 110 Stat. 1321 (April 26, 1996) imprest funds may only be used when the electronic funds transfer (EFT) requirement is waived.

2. The Department of the Treasury, Bureau of the Fiscal Service, Policy Directive: Imprest Funds Policy Statement (dated November 9, 1999) states that all imprest funds are to be eliminated unless they meet certain identified wavier criteria.

3. The IRS maintains imprest funds as identified in the waiver authority derived from within the Treasury Imprest Fund Policy Directive and identified in [31 CFR 208.4](https://www.ecfr.gov/current/title-31/subtitle-B/chapter-II/subchapter-A/part-208/section-208.4), Waivers:



   - Where a threat may be posed to national security, the life or physical safety of any individual may be endangered, or a law enforcement action may be compromised.

   - Where an agency’s need for goods and services is of such unusual and compelling urgency that the government would be seriously injured unless payment is made by a method other than electronic funds transfer; or, where there is only one source for goods or services and the government would be seriously injured unless payment is made by a method other than electronic funds transfer.


4. The IRS has one business unit that requires funds to support IRC law enforcement operations. Criminal Investigation serves as the law enforcement arm of the IRS and performs various undercover operations in support of its mission. Criminal Investigation establishes imprest funds to provide special agents with funding for ongoing covert operations.


**1.35.18.1.2** **(08-29-2025)**

#### Authority

1. See IRM 1.2.2.2.34, Delegation Order 1-44 (formally DO 187, Rev. 4), Investigative Imprest Funds and IRM 1.2.2.10.10, Delegation Order 9-10 (Rev 1), Authorization to Approve Confidential Expenditures, for the delegated authority relating to IRM 1.35.18, Financial Accounting, Imprest Funds.


**1.35.18.1.3** **(05-28-2024)**

#### Roles and Responsibilities

1. This section provides roles and responsibilities for:



01. Chief Financial Officer and Deputy Chief Financial Officer

02. Associate Chief Financial Officer for Financial Management and Deputy Associate Chief Financial Officer for Administrative Financial Management

03. Chief, Criminal Investigation,

04. Criminal Investigation Director of Field Operations,

05. Criminal Investigation Director, Special Investigative Techniques,

06. Criminal Investigation Director/Assistant Director, Finance,

07. Criminal Investigation Special Agents-in-Charge,

08. Criminal Investigation Director, International Operations,

09. Criminal Investigation Special Agents and Attachés,

10. Criminal Investigation cashiers,

11. Criminal Investigation alternate cashiers,

12. Criminal Investigation International sub-cashiers.


**1.35.18.1.3.1** **(05-28-2024)**

##### Chief Financial Officer and Deputy Chief Financial Officer

1. Chief Financial Officer and Deputy Chief Financial Officer are responsible for:



1. Overseeing the imprest program,

2. Ensuring financial policy and processes in support of IRS imprest fund operations are established and managed,

3. Evaluating requests for relief in accordance with IRM 1.2.2.2.16, Delegation Order 1-18 (Rev. 2), Settlement of Accounts and Relief of Accountable Officers - Administrative Accounts.


**1.35.18.1.3.2** **(05-28-2024)**

##### Associate Chief Financial Officer for Financial Management and Deputy Associate Chief Financial Officer for Administrative Financial Management

1. The Associate Chief Financial Officer for Financial Management and Deputy Associate Chief Financial Officer for Administrative Financial Management are responsible for:



1. Establishing, maintaining, and ensuring compliance with accounting policy and procedures for internal accounting operations and financial reporting.

2. Ensuring that IRS non-tax related disbursing operations comply with the law, regulations and the Treasury Financial Manual.

3. Liaising with the Department of the Treasury regarding a waiver of the requirement to disburse all funds electronically.


**1.35.18.1.3.3** **(08-29-2025)**

##### Director, Accounts Payable

1. The Director, Accounts Payable, is responsible for:



1. Ensuring that disbursements, cash advances, monthly depository account reconciliations and expense reports are received, authorized, and adhere to internal controls and regulations.

2. Approving the request for change or establishment of imprest funds.

3. Authorizing requests for all imprest funds requiring fund operations not held within Treasury approved financial institutions.

4. Authorizing all requests for permission to exceed the maximum authorized amount of an imprest fund for a temporary period in an emergency.

5. Approving, in coordination with the CI Chief, any temporary waiver authority to support operational requirements that deviate from instructions established within this IRM.

6. Acting as the primary liaison office with business unit, imprest fund managers and cashiers.


2. All correspondence should be sent to:



> IRS Beckley Office
>
> Director, Accounts Payable
>
> Attn: Miscellaneous Programs Unit
>
> 110 N. Heber Street
>
> Beckley, WV 25801
>
> Or by electronic submission to:
>
> \*CFO BFC Invoice Link


**1.35.18.1.3.4** **(08-29-2025)**

##### Director, Government Payables and Funds Management

1. The Director, Government Payables and Fund Management, is responsible for:



1. Overseeing the processes of systemic and manual obligations.

2. Providing customer support to business unit finance staff for commitments and obligations.

3. Providing compliance results to business unit managers and CFO leadership.

4. Validating aged commitments and obligations from IRS financial systems.


2. All correspondence should be sent to:



> IRS Beckley Office
>
> Director, Government Payables and Funds Management
>
> Attn: Debt Collection Unit
>
> 110 N. Heber Street
>
> Beckley, WV 25801


**1.35.18.1.3.5** **(11-24-2020)**

##### Director, Financial Reporting

1. The Director, Financial Reporting, is responsible for:



1. Preparing footnotes to the annual financial statements, when applicable.

2. Reviewing and validating that the balances in the Integrated Financial System sub-ledger agree to the Cashier Reports.


**1.35.18.1.3.6** **(08-29-2025)**

##### Chief, Criminal Investigation

1. The Chief, Criminal Investigation, is responsible for:



1. Providing oversight of the investigative imprest fund program including headquarters’ reviews that confidential expenses are compliant with IRS policy and guidelines.

2. Establishing a centralized financial plan to conduct Criminal Investigation operations.

3. Approving all Group I undercover operations.


2. For additional information on these responsibilities, see IRM 9.11.1.4.3, Approval Levels for Confidential Expenditure Authorizations.


**1.35.18.1.3.7** **(08-29-2025)**

##### Criminal Investigation Director, Field Operations

1. The Criminal Investigation Director, Field Operations, is responsible for:



1. Monitoring the overall program of expenditures made from investigative imprest funds in their respective areas.

2. Approving all Group II undercover operations.


2. For additional information on these responsibilities, see IRM 9.11.1.4.3, Approval Levels for Confidential Expenditure Authorizations.


**1.35.18.1.3.8** **(08-29-2025)**

##### Criminal Investigation Director, Special Investigative Techniques

1. The Criminal Investigation Director, Special Investigative Techniques, is responsible for:



01. Implementing a program of evaluation and follow-up, ensuring that funds are used appropriately and in a manner that is both lawful and consistent with the administration and enforcement of the laws enforceable by Criminal Investigation.

02. Ensuring review of undercover operations are conducted.

03. Receiving closing reports from special agents-in-charge no later than 60 days after the close of operations.

04. Approving increases/decreases for the applicable section Investigative imprest fund cashier’s bank account.

05. Ensuring non-confidential expenses (bank fees) from investigative imprest funds are approved by staff authorizing officials.

06. Supervising investigative imprest funds, including designating, assisting, and training applicable section cashiers, in the performance of their duties.

07. Providing supervision and control over the operations of the cashiers that are applicable section employees.

08. Approving reimbursement vouchers and accountability reports for applicable section employees. May be delegated to Assistant Director, Special Investigative Techniques.

09. Ensuring audits are performed as required for applicable section employees.

10. Implementing corrective action for matters discovered during any audit or review, or by any other means, for applicable section employees.

11. Implementing appropriate action in case of loss, or possible loss, of all or a portion of an investigative imprest fund for applicable section employees.

12. Reviewing month-end reports.

13. Maintaining investigative imprest funds at levels that are commensurate with demonstrated needs.

14. Audit reports are maintained for six years and three months, and record disposal of all closed reports are maintained for ten years and three months.


**1.35.18.1.3.9** **(08-29-2025)**

##### Criminal Investigation Director/Assistant Director, Finance

1. The Criminal Investigation Director/Assistant Director, Finance is responsible for committing and obligating funds for the investigative fund program.


**1.35.18.1.3.10** **(11-24-2020)**

##### Criminal Investigation Special Agents-in-Charge

1. Special Agents-in-Charge (SACs) are responsible for oversight of their respective field office authorization and reimbursement requests from the investigative imprest fund and ensuring the correct procedures and controls are being followed.


**1.35.18.1.3.11** **(08-29-2025)**

##### Criminal Investigation Director, International Operations

1. Criminal Investigation Director, International Operations, is responsible for:



1. Providing oversight for international investigative authorization.

2. Providing supervision and control over the operations of the International Operations sub-cashiers assigned to a foreign post.

3. Providing safeguards over the international investigative authorization and related records.

4. Approving forms for the international investigative authorization. This includes signature on the investigative imprest fund foreign bank account.

5. Ensuring funds are expended in a manner that is both lawful and consistent with the administration and enforcement of the laws enforceable by Criminal Investigation.

6. Maintaining adequate internal controls over international investigative authorization and taking appropriate action to ensure the internal controls are carried out as prescribed.

7. Implementing corrective action for matters discovered during any audit or review, or by any other means.

8. Implementing appropriate action in case of loss, or possible loss, of all or a portion of an international investigative imprest fund.

9. Certifying to the accuracy and legality of payments made from federal government funds.


**1.35.18.1.3.12** **(05-28-2024)**

##### Criminal Investigation Special Agents and Attachés

1. Criminal Investigation special agents and attachés are responsible for:



1. Complying with IRS policy and guidelines.

2. Completing requests for advances, reimbursement vouchers, accountability reports, and other necessary documentation, following established procedures.

3. Ensuring funds are spent in a manner that is both lawful and consistent with the administration and enforcement of violations within the jurisdiction of Criminal Investigation.

4. Safeguarding all funds and related records.


**1.35.18.1.3.13** **(11-24-2020)**

##### Criminal Investigation Cashiers

1. Criminal Investigation cashiers are responsible for:



1. Disbursing funds when properly authorized.

2. Maintaining detailed records and documentation of all transactions involving the imprest fund.

3. Securing and safeguarding all imprest funds.


2. For additional information on these responsibilities, see IRM 9.11.1.4.5.5, Guidelines for the Investigative Imprest Fund Cashier.


**1.35.18.1.3.14** **(12-18-2015)**

##### Criminal Investigation Alternate Cashiers

1. Criminal Investigation alternate cashiers are responsible for:



1. Serving as acting Criminal Investigation cashier in the absence of the principal cashier.

2. Performing Criminal Investigation cashier duties, as detailed in IRM 1.35.18.1.3.13, Criminal Investigation Cashiers, after accepting the transfer of accountability for an investigative imprest fund.

3. Accepting the transfer of accountability for an investigative imprest fund before a planned absence of the principal cashier and returning the accountability when the principal cashier returns.

4. Completing imprest fund training.


**1.35.18.1.3.15** **(08-29-2025)**

##### Criminal Investigation International Operations Sub-cashiers

1. Criminal Investigation International Operations sub-cashiers are responsible for the same duties as Criminal Investigation cashiers identified in IRM 1.35.18.1.3.13, Criminal Investigation Cashiers, except:



1. They do not have access to the Criminal Investigation imprest fund computer program. Therefore, all authorized expenses must be forwarded to the Special Investigative Techniques Storefront Cover Agent (with supporting documentation) for input into the Criminal Investigation Imprest Fund computer program.

2. International Operations sub-cashiers are located at overseas posts.


**1.35.18.1.4** **(08-29-2025)**

#### Program Management and Review

1. The Investigative Imprest Fund database is used by the Accounts Payable office to produce status reports on a monthly and quarterly basis. These reports include:



1. Form 1129, Cashier Reimbursement Voucher and Accountability Report,

2. Form 1149, Statement of Designated Depositary Account,

3. Form 2844, Reconciliation of Imprest Fund.


2. Program effectiveness is measured by processing and approving accurate authorizations, advances, and reimbursements, and evaluating the value received when confidential funds are expended.


**1.35.18.1.5** **(11-24-2020)**

#### Program Controls

1. Imprest fund controls are used to ensure the Investigative Imprest Fund is properly safeguarded, only for authorized purposes, maintained at an adequate level, and properly accounted for include:



1. Physical security,

2. Authorizations,

3. Separation of duties,

4. Validations,

5. Audits and Independent reviews.


**1.35.18.1.6** **(08-29-2025)**

#### Terms/Definitions

1. The following terms and definitions apply to this program:



01. **Accountable officer** \- A certifying officer, disbursing officer, collecting official, cashier and any other officer or employee who is responsible for or has custody of public funds.

02. **Cashier** \- A U.S. government employee who is responsible for issuing and reconciling requested funds from an imprest fund.

03. **Class A cashier** \- A cashier, officer, or employee who receives an advance from a federal agency appropriation and has not been authorized to advance an imprest fund to another cashier, except the alternate. The Class A cashier is personally accountable to the head of the federal agency or designee for the entire amount of the advance received.

04. **Class B cashier** \- A cashier, officer, or employee who receives an advance from a federal agency appropriation and is authorized to advance an imprest fund to his or her own alternate and to a sub-cashier. The Class B cashier is personally accountable to the head of the federal agency or designee for the entire amount of the advance received.

05. **Sub-cashier** \- A permanent officer or employee who has been designated in writing by the head of a federal department designee to receive an imprest fund from a Class B cashier, and who is under the supervision of the head of the same business unit as the cashier from whom the advance is received and is accountable to such cashier for the funds received. The provisions for payment limitations and safekeeping that apply to cashiers also apply to sub-cashiers.

06. **Certifying officer** \- An individual who is personally accountable and responsible for the accuracy and legality of payments made from federal government funds.

07. **Checking account signature cards** \- Cards signed by individuals for opening a checking account at a financial institution.

08. **Criminal Investigation imprest fund computer program** \- A computer software program used by cashiers to input and track investigative imprest fund transactions.

09. **Churning** \- The act of using income generated from an undercover operation to offset the necessary and reasonable expenses of undercover operations.

10. **Disbursing officer** \- An employee of the federal government, a Treasury disbursing officer, or non-Treasury disbursing officer, authorized to perform financial transactions (deposit collections, disburse checks, and transfer funds between agencies).

11. **Imprest fund** \- Funds advanced to a duly authorized cashier for a specific purpose which is charged against a government appropriation account.

12. **Internal orders** \- Data elements in the Integrated Financial System identifying project costs at the lowest level of budget detail issued by corporate budget.

13. **Investigative expenditures** \- Confidential and non-confidential expenses incurred by special agents in connection with an undercover program.


**1.35.18.1.7** **(08-29-2025)**

#### Acronyms

1. The following acronyms apply to this program:



|     |     |
| --- | --- |
| **Acronym** | **Description** |
| CI | Criminal Investigation |
| IFS | Integrated Financial System |
| MOU | Memorandum of Understanding |
| PPS | Procurement for Public Sector |
| SFCA | Storefront Cover Agent |
| SIT | Special Investigative Techniques |
| TIGTA | Treasury Inspector General for Tax Administration |


**1.35.18.1.8** **(08-29-2025)**

#### Related Resources

01. [31 CFR Part 202](https://www.ecfr.gov/current/title-31/subtitle-B/chapter-II/subchapter-A/part-202), Depositaries and Financial Agents of the Federal Government,

02. [31 CFR Part 208](https://www.ecfr.gov/current/title-31/subtitle-B/chapter-II/subchapter-A/part-208), Management of Federal Agency Disbursements,

03. IRM 1.2.2.2.16, Delegation Order 1-18 (Rev. 2), Settlement of Accounts and Relief of Accountable Officers - Administrative Accounts,

04. IRM 1.2.2.10.10, Delegation Order 9-10, Authorization to Approve Confidential Expenditures,

05. IRM 1.15.4.8, Retiring Criminal Investigative (CI) and Grand Jury Case Files,

06. IRM 1.36.4, Administrative Accounting and Financial Management Reports, Administrative (Non-Tax) Debt Management,

07. IRM 9.4.8, Undercover Operations,

08. IRM 9.11.1, Fiscal and Budgetary Matters,

09. IRM 10.2.8, Incident Reporting,

10. [Government Accountability Office (GAO), Principles of Federal Appropriations Law (aka the Red Book)](https://www.gao.gov/legal/appropriations-law/red-book), 3d ed., 2016 rev., Ch. 9, GAO-06-382SP (Washington, D.C.: Mar. 2016)


**1.35.18.2** **(05-28-2024)**

### Types of Imprest Funds

1. The IRS uses imprest funds to support Criminal Investigation (CI) with IRS law enforcement and investigative activities.


**1.35.18.2.1** **(08-29-2025)**

#### Criminal Investigation Imprest Fund (Domestic Operations)

1. CI establishes an investigative imprest fund when there is no other satisfactory means of providing funds essential for the enforcement of laws and regulations.

2. CI maintains investigative imprest funds in checking accounts at federally insured banks or credit unions under the account name “CI Imprest Fund”.

3. CI is authorized to certify imprest fund disbursements for the enforcement of violations within the jurisdiction of CI. All investigative imprest fund disbursements are recorded and validated within the CI Imprest Fund computer program.

4. All CI investigative imprest fund cashiers balance their financial institution account statements and their disbursements, submitting copies to the Accounts Payable office, via the Miscellaneous Programs Unit monthly.


**1.35.18.2.2** **(08-29-2025)**

#### Criminal Investigation Imprest Funds (International Operations)

1. The international operations authorizations are maintained using the same investigative authorization procedures as CI domestic operations. Exceptions to these procedures are discussed in this subsection.

2. CI manages international investigative imprest operations through a centralized imprest fund office located in Washington, DC.

3. International operations imprest funds are investigative imprest funds located in overseas posts, preferably in U.S. embassies.

4. International Operations imprest funds are maintained in checking accounts at U.S. banks in overseas locations, or in a comparable foreign bank if a U.S. bank is not available. The account name is "CI Imprest Fund." Any deviation to using the approved account name must be pre-approved by the Director, Accounts Payable.

5. Each international operation sub-cashier who performs investigative imprest fund duties at an overseas location must be a:



1. U.S. citizen, and

2. U.S. government employee.


6. If the International Operations sub-cashier is not an IRS employee, CI initiates a memorandum of understanding (MOU) on a case-by-case basis with the federal agency employing the cashier. The MOU should include all the same responsibilities and duties as other International Operations cashiers.

7. The International Operations personnel scans and emails the copies of the checks and receipts monthly to the Special Investigative Techniques (SIT) Storefront Cover Agent (SFCA). Bank statements are emailed monthly to the HQ International Operations cashier.

8. After month-end reconciliation, the CI International Operations personnel sends the original receipts and original bank statements to the SIT SFCA.


**1.35.18.3** **(08-29-2025)**

### Establishing an Imprest Fund

1. A request to establish an imprest fund is initiated by the appropriate business unit requesting official. The requesting official:



1. Establishes that an operational requirement exists that can only be satisfied through the use of an imprest fund.

2. Identifies the appropriate funding level required to meet operational requirements.

3. Identifies both a primary and alternate cashier.

4. Recommends a financial institution to support the imprest fund or forwards a request for fund operations outside of a financial institution. Funds that will not be held within a financial institution must be approved by the Director, Accounts Payable.


2. If requesting an imprest fund cash operation, to be held outside an approved financial institution, the imprest fund requesting official must also determine:



1. The cash requirement of the imprest fund (or the cash portion of the overall imprest fund, if a joint financial institution/cash operation is being recommended).

2. The security necessary to provide for the personal safety of the cashier.

3. The security requirements of the imprest fund storage location.


3. Each imprest fund must have one alternate cashier.

4. Each imprest fund is established and maintained using Optional Form (OF) 211, Request for Change or Establishment of an Imprest Fund.


**1.35.18.3.1** **(08-29-2025)**

#### Imprest Funds Requesting Officials

1. The Director/Assistant Director, SIT is authorized, as requesting official, to create memorandums to establish or make changes. Reference IRM 1.35.18.3.2, OF 211, for a complete list of actions or situations that require a change memorandum.

2. The authorized requesting officials send a memorandum with an explanation of the impending action to the Director, Accounts Payable office, via the Miscellaneous Programs Unit address listed in IRM 1.35.18.1.3.3, Director, Accounts Payable.

3. The Accounts Payable office via the Miscellaneous Programs Unit prepares OF 211 for the signature of the Director, Accounts Payable. Once signed, OF 211 is returned to the imprest fund requesting official.


**1.35.18.3.2** **(08-29-2025)**

#### OF 211 worksheet, Request for Change or Establishment of Imprest Fund

1. OF 211 is used whenever there is a need to:



01. Authorize a new investigative imprest fund.

02. Establish a new checking account.

03. Designate a principal or alternate cashier.

04. Revoke the designation of a principal or alternate cashier.

05. Change from principal cashier to alternate cashier or vice versa.

06. Change the Director, SIT, responsible for an investigative imprest fund.

07. Change a cashier's responsibilities.

08. Change a cashier's name or location.

09. Increase or decrease the amount of the investigative imprest fund.

10. Close or transfer an existing checking account to a different financial institution.

11. Close an investigative imprest fund.


**1.35.18.4** **(08-29-2025)**

### Designation of Cashiers

1. The appropriate imprest fund requesting official notifies the Director, Accounts Payable by memorandum when designation of a principal or alternate cashier is needed.

2. The person designated as cashier must not be a certifying officer.

3. A principal cashier, alternate cashier, or sub-cashier must be an employee whose duties do not require making investigative expenditures or granting approval for investigative expenditures.

4. Designation and revocation must occur concurrently to avoid having two principal cashiers accountable simultaneously for the same imprest fund.

5. Cashiers (except for the CI cashier) may not have sub-cashiers.


**1.35.18.4.1** **(05-28-2024)**

#### Designating a Sub-Cashier

1. The CI cashier is authorized to appoint sub-cashiers to conduct authorized IRS imprest operations.

2. The CI cashier is designated with Treasury Category B authority and is authorized to make disbursements and may also advance funds to a sub-cashier.

3. The CI cashier must ensure that the safeguards established for investigative imprest funds are established for each international sub-cashier overseas location. That includes funds being maintained in an approved financial institution or obtaining pre-approval for cash operations.

4. The CI cashier will maintain funds accountability for each sub-cashier within their imprest fund limitations. All advances to sub-cashiers will use electronic funds transfers to an approved international financial institution.


**1.35.18.5** **(08-29-2025)**

### Establishing an Imprest Fund Checking Account

1. All imprest funds should be maintained in checking accounts at authorized, federally insured financial institutions. Requests for the establishment of an imprest fund are approved by the Director, Accounts Payable.

2. Imprest funds are maintained in checking accounts under the account name "CI Imprest Fund" for CI imprest funds. The account is not in the name of a cashier.

3. Checking accounts are identified by the IRS Employer Identification Number.

4. Any deviations, or exceptions to the requirements established above, must be approved by the Director, Accounts Payable.

5. At the end of the calendar year, the financial institution sends each cashier Form 1099-INT, Interest Income, for the interest earned during the year. The cashier forwards the Form 1099-INT with a transmittal memorandum to the address listed in IRM 1.35.18.1.3.3, Director, Accounts Payable.

6. The cashier makes payments to the financial institution for:



1. Fees incurred,

2. Checking account maintenance charges.


7. Service charges assessed by the financial institution cannot be netted against or deducted from earned interest. The cashier requests reimbursement for these expenses from the Accounts Payable via the Miscellaneous Programs Unit when the monthly accountability report is submitted.


**1.35.18.5.1** **(08-29-2025)**

#### Establishing or Transferring Checking Accounts

1. The appropriate requesting official sends a memorandum requesting the establishment of a new checking account for an imprest fund, or the transfer of an established checking account to a different financial institution to the Director, Accounts Payable, via the Miscellaneous Programs Unit address listed in IRM 1.35.18.1.3.3, Director, Accounts Payable:

2. The memorandum must be accompanied by:



1. Signature cards (cards must have original signatures),

2. A completed Certification to Resolutions Governing Bank Account for the particular imprest fund financial institution,

3. Form 3881, ACH Vendor/Miscellaneous Payment Enrollment Form.



      ### Note:



      The signature cards, Certification to Resolutions Governing Bank Account for Unincorporated Association, and Form 3881 are obtained from the financial institution


3. The cashier establishes the checking account at a federally insured bank or credit union under the appropriate account name identified in IRM 1.35.18.5, Establishing an Imprest Fund Checking Account.

4. The financial institution's records must always reflect current signatures that are valid for making withdrawals from the checking account. The financial institution is notified promptly whenever there is a change in cashiers, or a checking account is being closed.


**1.35.18.5.2** **(08-29-2025)**

#### Checking Account Signature Cards

1. Checking account signature cards are signed by the cashier who opens the checking account. Banks and credit unions keep signature cards on file and use them to identify the cashier when the cashier returns to the bank or credit union to perform checking account transactions.

2. The following individuals must sign the signature cards:



1. Principal cashier,

2. Alternate cashier,

3. Assistant Director, SIT,

4. Director, SIT.


3. The signature cards must always be current, and new signature cards must be prepared when there is a change in personnel in the positions listed in this section.

4. When there is a change in the personnel, the Director, SIT sends a memorandum with original signature cards, to address listed in IRM 1.35.18.1.3.3, Director, Accounts Payable.


**1.35.18.5.3** **(08-29-2025)**

#### Change in Financial Institution or Financial Institution Information

1. Sometimes it is necessary to change the financial institution where the investigative imprest fund is located, or the information about the financial institution changes. For example, the financial institution name changes due to a merger. When this occurs, the Director, SIT notifies the Accounts Payable office via the Miscellaneous Programs Unit using the same procedures used in establishing the imprest fund checking account.


**1.35.18.6** **(08-29-2025)**

### Funding an Imprest Fund

1. For new imprest funds, the business unit's financial staff enters a commitment for the value of the fund through the Procurement for Public Sector (PPS) module. Additionally, the imprest fund requesting official sends a memorandum requesting funds to the Director, Accounts Payable, via the Miscellaneous Programs Unit.

2. For established imprest funds, the business unit financial staff enters a commitment for the cumulative value of all funds through PPS at the beginning of each fiscal year and periodically adjusts the balances through the year.

3. The Accounts Payable office via the Miscellaneous Programs Unit transmits the funds via EFT to the authorized financial institution checking account after the Director, Accounts Payable approves the request(s).


**1.35.18.6.1** **(08-29-2025)**

#### Increases or Decreases to an Investigative Imprest Fund

1. CI notifies the Accounts Payable office via the Miscellaneous Payables Unit whenever they wish to increase the amount of an investigative imprest fund. The Director, SIT prepares a memorandum for submission to the Director, Accounts Payable with a copy to the Director, Finance, who completes a shopping cart in PPS for increases. CI will coordinate increases or decreases with Finance.

2. The Accounts Payable and Government Payables and Funds Management units process requests for increases or decreases to an investigative imprest fund when the shopping cart reaches completed status in PPS.

3. Decreases require a transaction in Integrated Financial System (IFS) to decommit the funds.


**1.35.18.7** **(12-18-2015)**

### Changes in Cashiers

1. Cashier changes must be anticipated to allow for timely action so the continuity of the investigative imprest fund is maintained. These changes include:



1. Designation of a new cashier.

2. Revocation of a cashier's designation.

3. Transfer of accountability.


2. An audit of the investigative imprest fund must be performed before any of the activities listed above occur. See IRM 1.35.18.9.5.2, Unannounced Cash Audits, for the audit process.


**1.35.18.7.1** **(08-29-2025)**

#### Planned Cashier Absences and Transfer of Accountability

1. A cashier's responsibility and accountability for an investigative imprest fund must be formally transferred in the following circumstances:



1. When the principal cashier anticipates being absent or assigned to other duties for more than 15 consecutive workdays. Responsibility and accountability are transferred from the principal cashier to the alternate cashier or another designated principal cashier.

2. When the principal cashier resumes investigative imprest fund duties, after a period during which the alternate cashier was accountable, responsibility and accountability are transferred from the alternate cashier to the principal cashier.

3. When a principal cashier's designation is being revoked, responsibility and accountability are transferred from the former principal cashier to the alternate cashier, or to a newly designated principal cashier.


2. The transfer must include the financial institution records, checks, and other financial data for the investigative imprest fund. This is necessary to permit uninterrupted disbursing services during the absence.

3. The Director, SIT must notify the Director, Accounts Payable via the Miscellaneous Programs Unit, by memorandum, in advance of the transfer, to request the designation of the new cashier. The Director/Assistant Director, Finance needs to be notified on any change to the Imprest Fund Cashier’s bank account or bank institution.

4. The outgoing principal cashier must prepare all forms necessary for the transfer of accountability using the CI Imprest Fund Computer Program, and the incoming new principal or alternate cashier must acknowledge receipt of the fund, and the transfer.

5. The outgoing principal cashier must balance the fund in the presence of the incoming new principal or alternate cashier and two employees who are not associated with the operation of the investigative imprest fund.

6. An independent audit must be performed before the fund is transferred to the new principal or alternate cashier. This audit may not substitute for a quarterly unannounced audit. See IRM 1.35.18.9.5.5, Audit Process.


**1.35.18.7.2** **(05-28-2024)**

#### Unplanned Cashier Absence

1. Formal transfer of accountability is not required if the principal cashier's unplanned absence is less than 15 consecutive workdays. The amount of transfer must still be verified but can be informally transferred. The informal transfer documentation must be prepared and signed (or acknowledged electronically) by either the principal or alternate cashiers with the approval of the Director, SIT.

2. If the unplanned absence extends beyond 15 consecutive workdays or the cashier is not returning, the Director, SIT must formally transfer the accountability. See IRM 1.35.18.7.1, Planned Cashier Absences and Transfer of Accountability, for the procedures.

3. An independent audit of the investigative imprest fund is required within 6 weeks of the cashier’s departure. This audit does not substitute for a quarterly unannounced audit. See IRM 1.35.18.9.5.5, Audit Process, for additional information.

4. The alternate cashier retains the responsibility and accountability for the investigative imprest fund until it is formally transferred back to the principal cashier or until a new principal cashier is designated.


**1.35.18.7.3** **(08-29-2025)**

#### Termination of Cashier's Designation

1. The designation of a cashier remains in effect until the date specified on OF 211. When a cashier leaves the IRS or otherwise ceases to perform duties as a cashier the Director, SIT promptly notifies the Director, Accounts Payable via the Miscellaneous Programs Unit preferably in advance, by memorandum. CI, Finance needs to be notified of the termination of the cashier.

2. The effective date the investigative imprest fund is closed or formally transferred to a new cashier must correspond with the revocation date on OF 211 for the outgoing cashier.


**1.35.18.8** **(08-29-2025)**

### Cashier Responsibilities

1. Cashiers are responsible for the accountability of the funds advanced to them at all times. This includes the accountability of the funds maintained in financial institutions or in approved fund storage locations. Appointment to any of these positions must be documented in writing and approval establishes the cashier as an accountable official for the IRS.

2. CI cashiers are also responsible for ensuring that all disbursements are properly certified only for authorized expenses.

3. Cashiers are responsible for providing monthly accountability of bank balances and authorized expenses through their organizational managers identified in IRM 1.35.18.3.1, Imprest Funds Requesting Officials, and to the Accounts Payable office via the Miscellaneous Programs Unit.

4. Only CI accountable officials can make disbursements from imprest funds. The following subsections of IRM 1.35.18.8, Cashier Responsibilities are provided to assist CI accountable officials in maintaining accurate accountability of their assigned imprest funds.


**1.35.18.8.1** **(08-29-2025)**

#### Advances to Investigative Personnel

1. Advances may be provided to special agents to cover their expenses on an approved authorization. The special agent requests an advance of funds following procedures prescribed by CI internal operating procedures. The cashier advances funds to the assigned SFCA in anticipation of an authorized expenditure. If the expenditure does not occur, the funds are returned to the cashier by check or money order made payable to ”CI Imprest Fund”.

2. Before advancing any funds, the cashier verifies:



1. A current authorization is on file.

2. The maximum amount for the approved authorization is not exceeded.


3. The cashier maintains a detailed record for all transactions in the CI Imprest Fund Computer Program.

4. As soon as the expenditures for which the funds were advanced are complete, the SFCA follows CI internal operating procedures to report all transactions to the cashier, with the appropriate receipts from the special agents who made authorized expenditures. Unused funds are returned to the cashier by check or money order made payable to “CI Imprest Fund”.


**1.35.18.8.2** **(05-28-2024)**

#### Expenditures

1. Two types of expenditures can be made from the investigative imprest fund: confidential and non-confidential. Each disbursement must be properly authorized and documented according to CI internal operating procedures.

2. For additional information on confidential and non-confidential expenditures, see:



1. IRM 9.4.8, Undercover Operations,

2. IRM 9.11.1, Fiscal and Budgetary Matters,

3. IRM 1.2.2.10.10 - Delegation Order 9-10 (Rev. 1), Authorization to Approve Confidential Expenditures.


3. The cashier maintains a detailed record for each expenditure in the CI Imprest Fund Computer Program.

4. Special agents must follow CI internal operating procedures when requesting reimbursement, or advances, from the investigative imprest fund. Reimbursement for improper payments, including gifts and loans, are not allowed from the investigative imprest fund.

5. Expenses initially identified as unrecoverable, but subsequently recovered, are handled in the same manner as security deposits. See IRM 1.35.18.8.4, Security Deposits, for additional information.


**1.35.18.8.3** **(12-18-2015)**

#### Income from Operations

1. There are generally two sources for income earned on investigative imprest funds:



1. Authorized churning,

2. Financial institution earned interest.


**1.35.18.8.3.1** **(08-29-2025)**

##### Authorized Churning

1. Only the proceeds from a churning undercover operation may be used to offset the expenses of the operation. Income earned from an approved churning operation may be used to fully fund the operation but is limited to the amount of the confidential funds and expenses authorized for the operation. Income earned in an approved churning operation must be sent to Government Payables and Funds Management via the Debt Collection Unit to be applied against that undercover operation's internal order.

2. Undercover operations that earn minimal amounts of income, on an infrequent basis, are not required to be approved for churning. If an undercover operation which is not approved for churning earns income, the income must be sent to Government Payables and Funds Management via the Debt Collection Unit for deposit to the Treasury General Fund as miscellaneous receipts.

3. The cashier sends all checks or money orders payable to the "IRS" with a transmittal memorandum to the address listed in IRM 1.35.18.1.3.4, Director, Government Payables and Funds Management.

4. The authority for churning proceeds is in 26 USC 7608(c), Rules relating to undercover operations.

5. For additional information, see IRM 9.11.1, Fiscal and Budgetary Matters.


**1.35.18.8.3.2** **(08-29-2025)**

##### Earned Interest

1. There are instances when interest can be earned from imprest funds maintained within an authorized financial institution. Monthly, the cashier will remit all earned interest to Government Payables and Funds Management via the Debt Collection Unit for deposit to the Treasury General Fund.

2. The cashier sends a check for the earned interest, payable to the "IRS," with a memorandum to the address listed in IRM 1.35.18.1.3.4, Director, Government Payables and Funds Management.


**1.35.18.8.4** **(08-29-2025)**

#### Security Deposits

1. Security deposits are treated as an advance of funds from an investigative imprest fund. However, if it is determined that the security deposits are non-recoverable, they are expensed on the monthly report by the special agent following CI internal approval procedures.

2. When a security deposit is expensed through the investigative imprest fund, but later refunded to the special agent from the vendor, the special agent must send the security deposit to Government Payables and Funds Management via the Debt Collection Unit for re-deposit to the CI appropriation. The security deposit is not returned to the cashier. If the security deposit is paid from an open (unexpired) appropriation, the special agent must send the security deposit to Government Payables and Funds Management via the Debt Collection Unit with a transmittal memorandum including the following statements: "The amount transmitted herewith represents the refund of funds previously expensed through the investigative imprest fund. These funds should be re-deposited to CI's FY\_\_ appropriation.”

3. In cases where an appropriation has expired, Government Payables and Funds Management via the Debt Collection Unit deposits the security deposit as a miscellaneous receipt in the Treasury General Fund.

4. The special agent must send all checks or money orders payable to the "IRS" with a transmittal memorandum to the address listed in IRM 1.35.18.1.3.4, Director, Government Payables and Funds Management.

5. See IRM 9.11.1, Fiscal and Budgetary Matters for more information.


**1.35.18.8.5** **(11-24-2020)**

#### Monthly Reconciliation and Reporting

1. At the end of each month, the cashier must reconcile the imprest fund and prepare reconciliation forms. These forms are generated from the CI Imprest Fund computer program. For additional information, see IRM 9.11.1, Fiscal and Budgetary Matters.

2. The cashier sends the forms with the supporting documents to the \*CFO BFC Invoice Link.

3. The cashier must retain a copy of the forms and the supporting documents.


**1.35.18.8.6** **(08-29-2025)**

#### Checking Account Replenishment

1. The cashier must prepare a reimbursement voucher to replenish the funds in the checking account to maintain the correct balance. The cashier submits the voucher with the monthly reconciliation forms to the \*CFO BFC Invoice Link.

2. The Accounts Payable office via the Miscellaneous Payables Unit reviews the reimbursement voucher and processes the replenishment via EFT to the checking account at the financial institution.


**1.35.18.9** **(12-18-2015)**

### Imprest Fund Internal Controls

1. There are many internal controls regarding the protection of cash held outside of the Treasury. IRS imprest funds fall into the following categories:



1. Physical security,

2. Authorizations,

3. Separation of duties,

4. Validations,

5. Audits and independent reviews.


**1.35.18.9.1** **(05-28-2024)**

#### Physical Security

1. The cashier retains exclusive control of all checks and record documentation in containers which meet the requirements of IRM 9.11.1.4.5.5.1, Investigative Imprest Fund Cashier Responsibilities.

2. Checks and record documentation must not be stored in:



1. File cabinets without key locks; for example, wooden cabinets or metal cabinets not designed and/or approved for secure storage.

2. The cashier's or any other employee's desk drawer.

3. Depositories and/or safe deposit boxes in the cashier's name only.


3. Keys and combinations must be issued and accounted for in accordance with IRM 9.11.1.4.5.5.1, Investigative Imprest Fund Cashier Responsibilities.

4. The security container must always be locked and out of public view except when the cashier is making a transaction. The container must be locked whenever the cashier is absent, even if the absence is only momentary.

5. Imprest funds must not be commingled at any time with private funds or unofficial funds. They must be kept separate in a locked security container.

6. Space assigned to the cashier is subject to periodic, unannounced inspections by IRS security officers. This is to ensure proper safeguards are maintained to prevent unauthorized individuals from having access to the cashier area and to emphasize protection of the imprest funds.


**1.35.18.9.2** **(11-24-2020)**

#### Authorizations

1. The accountability for each imprest fund is vested with each designated cashier. Accountability can be formally transferred to an alternate cashier or to an incoming principal cashier, but accountability rests with only one individual at a time. Cashiers, and their alternates, are not allowed under any circumstances, during their official duty hours, to maintain any unofficial or additional funds other than the funds they are specifically designated to administer.

2. The employee requesting an advance of funds must have proper identification and authorization before the cashier disburses funds from the imprest fund.

3. Cashiers (principal, sub-cashiers or alternate) must not disburse any funds to an employee on behalf of another employee unless specifically authorized.


**1.35.18.9.3** **(12-18-2015)**

#### Separation of Duties

1. The cashier must maintain a clear separation of duties to ensure the effectiveness of internal controls. For example, cashiers must not have control or responsibility over the approval of expenditures from the investigative imprest fund.


**1.35.18.9.4** **(05-28-2024)**

#### Validations

1. The Director, SIT and the SIT program analyst reviews the fund level of each investigative imprest fund once a year to ensure it does not exceed actual needs.


**1.35.18.9.5** **(08-29-2025)**

#### Audits and Independent Reviews

1. Each imprest fund has several types of audits and reviews that can be accomplished to validate the fund balance, documentation, and the physical security of the fund.



1. Imprest funds that are entirely maintained within authorized financial institutions are validated monthly through the submission of bank statements and the CI Imprest Fund computer program reconciliation of expenses. These are validated by CI, Accounts Payable and the Financial Reporting offices ensuring each imprest fund is in balance with fund authorizations.

2. Imprest funds that have been granted authorization to conduct cash operations must be physically inspected quarterly by an independent team conducting an unannounced cash audit.

3. All imprest funds also go through a complete audit/validation any time there is a transfer of accountability.


2. Additionally, any imprest fund can be inspected at any time by an independent review team.


**1.35.18.9.5.1** **(08-29-2025)**

##### Monthly Audits

1. All cashiers operating imprest funds in an authorized financial institution must validate both the bank statement and the expenses as identified in IRM 1.35.18.8.5, Monthly Reconciliation and Reporting. These audits include a review by the appropriate business unit official in addition to a review by the Accounts Payable office via the Miscellaneous Programs Unit and the Financial Reporting office. This dual-layered audit review helps to ensure that imprest funds are being operated within authorized limitations and that expenses are authorized and approved.


**1.35.18.9.5.2** **(12-18-2015)**

##### Unannounced Cash Audits

1. Unannounced audits of investigative imprest funds utilizing cash held outside of financial institutions must be performed at least once each quarter. The timing of the audit should not be predictable, or the element of surprise will be lost.

2. The purpose of the unannounced audit is to validate the fund balance, the actual composition of the fund, all authorizing/expense documentation, and inspect the physical security of the funds.

3. Additional information on unannounced audits can be found in IRM 9.11.1, Fiscal and Budgetary Matters.


**1.35.18.9.5.3** **(11-24-2020)**

##### Transfer of Accountability Audits

1. Any time a cashier must transfer imprest fund accountability to another cashier, a full audit must be conducted by the outgoing and incoming cashiers as identified in IRM 1.35.18.7(1)-(2), Changes in Cashiers. This audit helps to validate and remove the accountability from the outgoing cashier while assigning that accountability to the new cashier.


**1.35.18.9.5.4** **(08-29-2025)**

##### Independent Reviews

1. Investigative imprest funds are audited periodically by personnel from the TIGTA in accordance with its regulations and procedures. TIGTA furnishes a copy of each audit report to:



1. Chief, CI,

2. Director, SIT,

3. Director, Accounts Payable.


2. The audit report is reviewed to evaluate the significance of any adverse findings and for initiation of appropriate procedural or systemic modifications.


**1.35.18.9.5.5** **(08-29-2025)**

##### Audit Process

1. Auditing employees must be independent and have no interest in the operation of the investigative imprest fund. For example, the employee must not be authorized to approve expenditures or other transactions from the investigative imprest fund and must not be the supervisor of the cashier.

2. Employees appointed to perform the audit must not perform two successive audits. Employees should alternate with other eligible employees.

3. The cashier provides the following documents to the auditors:



1. Form 2844, Reconciliation of Imprest Fund,

2. OF 211 for any changes that have occurred since the last audit,

3. Form 1149, Statement of Designated Depository Account,

4. Form 1129, Cashier Reimbursement Voucher and/or Accountability Report,

5. Checking account documentation, such as the check register, uncashed checks, deposits in transit, and unreimbursed vouchers,

6. Access to any cash held outside of designated financial institutions (in approved storage facility) including a copy of the fund’s operations approval letter from Director, Accounts Payable.


4. The auditing employees must provide the audit report with original signatures to the Director, SIT and forward a copy of the audit report to the \*CFO BFC Invoice Link.

5. The audit report may be destroyed six years and three months after the period covered by the report.


**1.35.18.10** **(08-29-2025)**

### Imprest Fund Losses

1. The Director, SIT is responsible for immediately reporting all losses to the investigative imprest fund to the Director, Accounts Payable.

2. The Director, SIT must send a written report immediately when any loss or shortage occurs, including:



1. Robbery, burglary, and/or theft,

2. Illegal disbursements resulting from fraud, forgery, alteration of vouchers, or other improper practices,

3. Improper accounting,

4. Any other irregularity.


3. The report to the Director, Accounts Payable, must include all of the following information:



1. A detailed statement of facts, including the type of irregularity, date, amount, names of individuals involved, and a description of how the irregularity occurred.

2. A citation to any pertinent supporting documents such as pay records, contracts, and/or vouchers.

3. Information on procedural deficiencies and the proposed corrective action, if applicable, and known at the time the report is prepared.

4. Information on the funds recouped from the individual, or expected to be recouped, if applicable, and known at the time the report is prepared.


4. See IRM 10.2.8, Incident Reporting, for additional information.


**1.35.18.10.1** **(08-29-2025)**

#### Required Action

1. If the loss of funds appears to be the result of unlawful or other improper action by the cashier, the Director, SIT impounds, audits, and transfers the remaining balance of the investigative imprest fund to the alternate cashier or to a new principal cashier.

2. There may be cases where the cashier repays the lost funds and relief is not requested. The repayment must be made by check payable to the " IRS." The Director, SIT provides the cashier with a receipt for the re-payment amount and sends the check with an appropriate transmittal memorandum to the address listed in IRM 1.35.18.1.3.4, Director, Government Payables and Funds Management.

3. If the cashier repays the lost funds, and later a determination is made that the cashier was not at fault (for example, new evidence is discovered), Director, Accounts Payable and CI will take immediate action(s) necessary to ensure the cashier is granted relief and reimbursed for the full amount paid.


**1.35.18.10.2** **(08-29-2025)**

#### Debt Collection

1. Government Payables and Funds Management via the Debt Collection Unit is responsible for managing the account receivables for administrative debts. After receipt of written report from the Director, SIT the Director, Government Payable and Funds Management, determines if a debt is owed to the IRS and maintains a record of the debt. The loss is recorded as an account receivable in IFS, in the cashier's name, until the matter is resolved.

2. After the account receivable is established, IRS mails a demand letter through the U.S. Postal Service, by first-class postage, to the cashier. The demand letter contains all due process rights and the following information:



01. Type or nature of the debt owed,

02. The amount of the debt,

03. The payment due date, usually 30 days from the date of the letter,

04. The opportunity to repay the debt in full,

05. The repayment options available to the debtor, if the debt cannot be paid in full,

06. Instructions for submitting a financial hardship request,

07. The address where to submit the payment,

08. An IRS point of contact regarding the debt,

09. The IRS policies regarding the assessment of interest, administrative charges, and penalties,

10. The collection actions that IRS may enforce if the debt is not paid by the payment due date,

11. The debtor's process rights.


3. Information on administrative debt policy is located in IRM 1.36.4, Administrative Accounting and Financial Management Reports, Administrative (Non-Tax) Debt Management.


**1.35.18.10.3** **(05-28-2024)**

#### Relief of Cashiers

1. The cashier is accountable for the entire amount of the investigative imprest fund for which the cashier is designated. If relief is granted for the loss of all or part of the fund, the amount relieved is restored to the fund by an obligation against the IRS appropriation(s). Granting relief does not imply that funds are forthcoming from another government agency or another source. Relief is made to the individual cashier not to the IRS or to the financial plan(s) involved.

2. Relief may be granted by:



1. Administrative action by the deputy associate CFO – IRM 1.2.2.2.16, Delegation Order 1-18 (Rev. 2), Settlement of Accounts and Relief of Accountable Officers - Administrative Accounts, if the loss is less than $10,000.

2. Administrative action by the CFO – IRM 1.2.2.2.16, Delegation Order 1-18 (Rev. 2), Settlement of Accounts and Relief of Accountable Officers - Administrative Accounts, if the loss is $10,000 or more.


**1.35.18.10.4** **(05-28-2024)**

#### Grounds for Relief

1. Relief will be granted only in cases where the loss occurred through no fault of the cashier.

2. Relief will not be granted in cases where the loss has occurred because of negligence on the part of the cashier. The Director, SIT determines whether the cashier has been negligent in the performance of imprest fund duties. As a guideline for this determination, negligence may be indicated by the presence of one or more of the following factors :



1. Frequent errors in transactions, record keeping, or reports.

2. Embezzlement or misappropriation of imprest funds.

3. Failure to maintain records and/or to submit reports.

4. Unprotected imprest funds, particularly if theft is involved.

5. Unauthorized or improperly documented transactions.

6. Unexplained disappearance or shortage of imprest funds.


3. Relief may not be granted for circumstances involving illegal, improper, or incorrect payments, both in nature and amount, including those resulting from fraud, forgery, alterations of vouchers, and other improper practices.


**1.35.18.10.5** **(08-29-2025)**

#### Requesting Relief

1. A cashier may request relief from repaying a loss in the imprest fund. The cashier must prepare a statement explaining the circumstances of the loss and its discovery and give it to the Director, SIT.

2. The Director, SIT must send a memorandum requesting relief, regardless of the amount, to the address listed in IRM 1.35.18.1.3.4, Director, Government Payables and Funds Management.

3. The following documents must be attached to the memorandum:



1. A detailed statement from the cashier explaining the circumstances of the loss and its discovery.

2. Statements from the cashier's supervisor supporting the recommendation for relief.

3. Statements obtained through the local Security Officer, the Federal Bureau of Investigation, the Secret Service, and/or the local police authority, as applicable, explaining their findings.

4. Other pertinent documents or information.


4. The Director, Accounts Payable sends the request for relief with the attached documents to the Associate CFO for Financial Management.

5. If relief is granted to the cashier for all or part of the fund, Government Payables and Funds Management via the Debt Collection Unit restores the amount relieved to the investigative imprest fund by obligating it against IRS appropriation(s).


**1.35.18.11** **(08-29-2025)**

### Closing an Investigative Imprest Fund

1. ) When an investigative imprest fund needs to be closed, (for example, two field offices merge), the Director, SIT must notify, in advance by memorandum, the Director, Accounts Payable through the Director/Assistant Director, Finance.

2. The investigative imprest fund may be completely liquidated by sending a check to Government Payables and Funds Management via the Debt Collection Unit. The cashier sends a check payable to the " IRS" with a transmittal memorandum to the address listed in IRM 1.35.18.1.3.4, Director, Government Payables and Funds Management.

3. Prior to closure, an audit or financial review of the investigative imprest fund must be conducted. See IRM 1.35.18.9.5.5, Audit Process, for additional information.

4. The Director, SIT must resolve all investigative imprest fund losses before the investigative imprest fund is closed. See IRM 1.35.18.10, Imprest Fund Losses, for additional information.

5. The Director, Accounts Payable signs OF 211 to revoke a cashier's designation in conjunction with closing the fund.


**Exhibit 1.35.18-1**

### Standard Form 1129 - Cashier Reimbursement Voucher and/or Accountability Report

![This is an Image: 62656001.gif](https://www.irs.gov/pub/xml_bc/62656001.gif)

> Page 1

[Please click here for the text description of the image.](https://www.irs.gov/media/441096 "")

**Exhibit 1.35.18-2**

### Standard Form 1149 - Statement of Designated Depositary Account

![This is an Image: 62656002.gif](https://www.irs.gov/pub/xml_bc/62656002.gif)

> Page 1

[Please click here for the text description of the image.](https://www.irs.gov/media/441101 "")

![This is an Image: 62656003.gif](https://www.irs.gov/pub/xml_bc/62656003.gif)

> Page 2

[Please click here for the text description of the image.](https://www.irs.gov/media/441106 "")

![This is an Image: 62656004.gif](https://www.irs.gov/pub/xml_bc/62656004.gif)

> Page 3

[Please click here for the text description of the image.](https://www.irs.gov/media/441111 "")

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-035-018#addtoany "Show all")

A2A