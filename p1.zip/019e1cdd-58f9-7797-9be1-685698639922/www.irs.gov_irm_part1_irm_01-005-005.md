---
url: "https://www.irs.gov/irm/part1/irm_01-005-005"
title: "1.5.5 Section 1204/Regulation 801 Guidance for Criminal Investigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-005-005#main-content)

- 1.5.5  [Section 1204/Regulation 801 Guidance for Criminal Investigation](https://www.irs.gov/irm/part1/irm_01-005-005#id1)
  - 1.5.5.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-005-005#id2)
    - 1.5.5.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-005-005#id4)
    - 1.5.5.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-005-005#id5)
    - 1.5.5.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-005-005#id6)
    - 1.5.5.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-005-005#id7)
    - 1.5.5.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-005-005#id8)
    - 1.5.5.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-005-005#id9)
    - 1.5.5.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-005-005#id10)
  - 1.5.5.2  [Application of the Manual](https://www.irs.gov/irm/part1/irm_01-005-005#id11)
  - 1.5.5.3  [Use of Tax Enforcement Results and Records of Tax Enforcement Results in Evaluations](https://www.irs.gov/irm/part1/irm_01-005-005#id12)
  - 1.5.5.4  [Quantity and Quality Measures](https://www.irs.gov/irm/part1/irm_01-005-005#id13)
  - 1.5.5.5  [Use of Statistics for Monitoring Programs](https://www.irs.gov/irm/part1/irm_01-005-005#id14)
  - 1.5.5.6  [Use of Statistics in Operational Reviews](https://www.irs.gov/irm/part1/irm_01-005-005#id15)
  - 1.5.5.7  [Section 1204 Quarterly Certification and Independent Review Process](https://www.irs.gov/irm/part1/irm_01-005-005#id16)

# Part 1. Organization, Finance, and Management

# Chapter 5. Managing Statistics in a Balanced Measurement System

# Section 5. Section 1204/Regulation 801 Guidance for Criminal Investigation

* * *

## 1.5.5 Section 1204/Regulation 801 Guidance for Criminal Investigation

#### Manual Transmittal

January 30, 2026

#### Purpose

(1) This transmits revised IRM 1.5.5, Managing Statistics in a Balanced Measurement System - Section 1204 / Regulation 801 Guidance for Criminal Investigation.

#### Material Changes

(1) Updated internal controls.

(2) Updated all IRM references to quick links throughout the IRM.

(3) Subsection 1.5.5.2(1) added term Section 1204 employees and law defining impacted employees.

(4) Subsection 1.5.5.2(2) removed “this circumstance of” and added “as described in paragraph (1)”.

(5) Subsection 1.5.5.2(3) updated “support personnel” to “professional staff”.

(6) Subsection 1.5.5.3 updated section title to “Use of Tax Enforcement Results and Records of Tax Enforcement Results in Evaluations.”

(7) Subsection 1.5.5.3(1) added definition of tax enforcement results (TER), records of tax enforcement results, and examples of tax enforcement results (ROTER).”

(8) Subsection 1.5.5.3(2) edited definition of "employee evaluation" to align with Regulation 801 and removed “or similar type of managerial determination. For more information related to progress and workload reviews see IRM 1.5.2”. Moved the last sentence down to be the first sentence of the Note.

(9) Subsection 1.5.5.3(3) updated to include TER and critical job elements (CJEs) and add “Note: Although the use of TERs in performance evaluations does not violate Section 1204 or Regulation 801 (see IRM 1.5.2.8, Regulation 801), it is against IRS policy to include TERs in employee evaluations or written performance appraisals.”

(10) Subsection 1.5.5.3(4) added verbiage to explain the prohibition of a ROTER for a single case, moved existing language to a note, and reworded to align with IRM 1.5.2.

(11) Subsection 1.5.5.3(5) removed duplicate information, added reference to TER, and reworded to focus on reviews to align with Regulation 801 and IRM 1.5.2.

(12) Subsection 1.5.5.3(6) reworded to add reference to commitments, objectives, qualitative measures, and to align with IRM 1.5.2.

(13) Subsection 1.5.5.3(7) reworded to combine with (8) and align with IRM 1.5.2.

(14) Subsection 1.5.5.3(9) revised language to align with Regulation 801, include reference to Section 1204 and Regulation 801, and added list of steps managers will take.

(15) Subsection 1.5.5.3(10) revised verbiage to clarify information and removed information contradicting IRM 1.5.2.

(16) Subsection 1.5.5.3(11) inserted language to clarify violation and align with IRM 1.5.2.

(17) Subsection 1.5.5.3(12) moved 1.5.5.4(5) here to align verbiage with appropriate subsection.

(18) Subsection 1.5.5.4 updated section title to “Quantity and Quality Measures” and updated focus of subsection to align with IRM 1.5.2.

(19) Subsection 1.5.5.4(1) moved verbiage to paragraph (5), moved paragraph (2) and (3) information here, added new verbiage to define and provide examples of quantity and quality measures, and aligned verbiage with Regulation 801 and IRM 1.5.2.

(20) Subsection 1.5.5.4(2) original verbiage used in paragraph (1), added verbiage to explain when quantity measures are prohibited or may be used, included language from (4), (6) and (8), and added “Note” for further clarity.

(21) Subsection 1.5.5.4(3) original verbiage used in paragraph (1), added verbiage regarding the use of quality measures in goal setting for organizational units.

(22) Subsection 1.5.5.4(4) original verbiage used in paragraph (2), clarify use of quantity measures in evaluations of supervisors that aligns with IRM 1.5.2.

(23) Subsection 1.5.5.4(5) original verbiage used in 1.5.5.3(12) to align verbiage with appropriate section, added verbiage to explain use of quality measures that aligns with IRM 1.5.2.

(24) Removed subsection 1.5.5.4(6) verbiage used in paragraph (2).

(25) Removed subsection 1.5.5.4(7) duplicate information.

(26) Removed subsection 1.5.5.4(8) verbiage used in paragraph (2).

(27) Subsection 1.5.5.5(1) updated to combine paragraphs (1) and (2).

(28) Subsection 1.5.5.5(3) verbiage moved to paragraph (2) and verbiage from paragraph (5) moved here.

(29) Subsection 1.5.5.5(4) moved verbiage to 1.5.5.6(6).

(30) Subsection 1.5.5.6(2) moved to (5), added information about use of quantity and quality measures in reviews of organizational units to align with Regulation 801 and IRM 1.5.2.

(31) Subsection 1.5.5.6(3) added information regarding appropriate use of statistics to compare organizational units to align with IRM 1.5.2.

(32) Subsection 1.5.5.6(4) added information about restricted use of statistics to compare organizational units to align with IRM 1.5.2.

(33) Subsection 1.5.5.6(6) added information regarding sharing of ROTER data between organizational units at same level to align with IRM 1.5.2.

(34) Subsection 1.5.5.6(7) added additional information regarding sharing of ROTER data between organizational units at same level to align with IRM 1.5.2.

(35) Subsection 1.5.5.7 updated title to “Section 1204 Quarterly Certification and Independent Review Process”.

(36) Subsection 1.5.5.7(2) removed reference to subsection of 1.5.3 that no longer pertains to this section and updated to current procedures

(37) Subsection 1.5.5.7(3) added the word “process” at the end of the sentence for clarity.

(38) Editorial changes made throughout the IRM that did not result in substantive changes but clarified the subject matter.

#### Effect on Other Documents

This transmittal supersedes IRM 1.5.5 dated June 12, 2024.

#### Audience

Criminal Investigation

#### Effective Date

(01-30-2026)

Justin Campbell

Acting Deputy Chief, Criminal Investigation

for

Guy A. Ficco

Chief, Criminal Investigation

**1.5.5.1** **(01-30-2026)**

### Program Scope and Objectives

1. Purpose: This section provides specific guidance on the use of statistics within Criminal Investigation. The guidance is shown in the form of examples of acceptable/non-acceptable language. See _IRM 1.5.5.3_.



### Note:



Please note, this section was not intended to be used as the sole reference source for Criminal Investigation on managing statistics. Please refer to IRM 1.5.1, IRS Balanced Performance Measurement System, and IRM 1.5.2, Uses of Section 1204 Statistics, for overall agency policy, guidance, definitions, and examples concerning the proper use of statistics.

2. Audience: All Criminal Investigation employees.

3. Policy Owner: Executive Director, Strategy.

4. Program Owner: Director, Assurance & Advisory within Strategy.

5. Primary Stakeholders: All Criminal Investigation employees.

6. Contact Information: To make changes to this IRM email \*CI-HQ-IRM.


**1.5.5.1.1** **(06-12-2024)**

#### Background

1. The mission of Assurance & Advisory is to independently review, evaluate and report on Criminal Investigation field operations, program areas and headquarter sections in a fair and objective manner to identify risks, emerging issues and best practices that affect Criminal Investigation, assess Criminal Investigation’s leadership effectiveness and ability to manage and mitigate risk, evaluate Criminal Investigation operations to ensure investigative alignment with the Compliance Strategy, and to ensure compliance with established policies, prior TIGTA, GAO and Assurance & Advisory recommendations.


**1.5.5.1.2** **(01-30-2026)**

#### Authority

1. The IRS Restructuring and Reform Act of 1998 (RRA’98) Section 1204, 26 CFR Part 801, Balanced System for Measuring Organizational and Employee Performance within the Internal Revenue Service, IRM 1.5.1, The IRS Balanced Performance Measurement System, IRM 1.5.2, Uses of Section 1204 Statistics, IRM 1.5.3, Manager’s Self-Certification and Independent Review Process, and IRM 6.430.1, Introduction to Performance Management, govern the use and management of statistics for organizational and employee performance and other uses by Criminal Investigation.


**1.5.5.1.3** **(01-30-2026)**

#### Roles and Responsibilities

1. The Director, Assurance & Advisory owns this IRM and is responsible for:



   - Providing program oversight,

   - Maintaining and overseeing updates to this IRM,

   - Updating this IRM when the content is no longer accurate,

   - Ensuring internal control content is complete, accurate, and reviewed annually,

   - Incorporating interim guidance into the next revision of this IRM prior to the expiration date,

   - Ensuring this IRM provides reliable information for decision making and quality assurance,

   - Reviewing and approving any updates to this IRM before they are published.


**1.5.5.1.4** **(01-30-2026)**

#### Program Management and Review

1. The Director, Assurance & Advisory will manage this IRM’s content by:



   - Reviewing this IRM annually,

   - Updating references to forms, letters, publications, documents, notices, etc.,

   - Removing outdated or duplicated content,

   - Reorganizing or rewording content for clarity,

   - Providing other procedural, operational, and editorial changes as needed.


**1.5.5.1.5** **(01-30-2026)**

#### Program Controls

1. The Director, Assurance & Advisory will:



   - Review this IRM to ensure their programs goals and objectives are efficiently and effectively being accomplished.

   - Review this program and ensure organizational compliance with all applicable elements of this IRM.


**1.5.5.1.6** **(01-30-2026)**

#### Acronyms

1. The table lists commonly used acronyms and their definitions:



|     |     |
| --- | --- |
| **Acronym** | **Definition** |
| A&A | Assurance & Advisory |
| CI | Criminal Investigation |
| CJE | Critical Job Elements |
| KSA | Knowledge, Skills, and Abilities |
| ROTER | Record of Tax Enforcement Result |
| TER | Tax Enforcement Result |


**1.5.5.1.7** **(01-30-2026)**

#### Related Resources

1. IRM 1.5.1, The IRS Balanced Performance Measurement System.

2. IRM 1.5.2, Uses of Section 1204 Statistics.

3. IRM 1.5.2.8, Regulation 801.

4. IRM 1.5.3, Manager’s Self-Certification and Independent Review Process.

5. IRM 6.430.1, Introduction to Performance Management.


**1.5.5.2** **(01-30-2026)**

### Application of the Manual

1. The guidelines, restrictions and prohibitions in the use of statistics as outlined in this manual applies to all Criminal Investigation (CI) employees and the managers of employees who exercise judgment in determining whether or how the IRS should pursue enforcement of the tax laws against a particular individual or entity, also referred to as Section 1204 employees as determined in The IRS Restructuring and Reform Act of 1998, Section 1204. An employee is considered a Section 1204 employee based upon the work activity performed and not the employee’s title, location, or operating/functional division.

2. For most special agents and their various levels of supervisors, exercising judgment as described in paragraph (1) applies to a majority of the tasks they perform. Those special agents who are assigned full/part time to specialty positions may be exempt from these provisions if they are not exercising judgment in determining whether or how the IRS should pursue enforcement of the tax laws.

3. Generally, professional staff do not execute the type of tasks in which they exercise judgment about enforcement of the tax laws. However, some professional staff (i.e., tax fraud investigative aides; investigative analysts; and interns) may make recommendations to special agents or management officials as to whether or how the IRS should pursue enforcement of the tax laws against specific individuals or entities. When making these types of recommendations, those professional staff come under the guidance of this manual.


**1.5.5.3** **(01-30-2026)**

### Use of Tax Enforcement Results and Records of Tax Enforcement Results in Evaluations

01. A tax enforcement result (TER) is the outcome produced by an IRS employee's exercise of judgment in recommending or determining whether or how the IRS should pursue enforcement of the tax laws. Records of Tax Enforcement Results (ROTERs) are data, statistics, and compilations of information or other numerical or quantitative recordation of the TERs reached in one or more cases.


     \- Examples of TERs include, but are not limited to:



    - Special Agent Report completion,

    - Prosecution recommended in a tax investigation,

    - Arrest (Title 26 only),

    - Conviction in a tax investigation,

    - Amount of tax restitution ordered at sentencing,

    - Amount of assets forfeited (Title 26 only),

    - Seizure (Title 26 only),

    - Investigation discontinuation.


\- Examples of ROTERs include, but are not limited to:


    - Number of fraud referrals accepted or rejected,

    - Fraud referral acceptance rate,

    - Number of prosecution recommendations,

    - Prosecution referral rate,

    - Number of discontinued investigations,

    - Number of Title 26 seizures,

    - Dollar value of assets seized (Title 26 only),

    - Number of search warrants,

    - Number of arrests (Title 26 only),

    - Number of Title 26 forfeitures,

    - Dollar value of assets forfeited (Title 26 only).


### Note:

Notwithstanding non-Title 26 exclusions, extreme care should be utilized in referring to non-Title 26 arrests, seizures, and forfeitures to avoid the inference of a quantitative goal as an element of performance measurement.

02. An employee evaluation includes any written documentation used to appraise or measure an employee’s performance to provide a performance rating, award recommendation, assessment for qualification for promotion or reassignment, eligibility for incentive or bonus, or ranking for reductions in force. Case reviews and workload reviews are excluded from this definition.



    ### Note:



    A recommendation for an award outside the IRS is not subject to ROTER restrictions. Any outside award recommendation or award resulting from such nominations is not to be considered for performance evaluations, bonus, promotions, or reassignments. In addition, outside award recommendations are not to be filed in an employee’s performance file.

03. Managers must not cite TER outcomes or ROTERs as the basis for a Section 1204 employee's performance rating, and TERs and ROTERS must not be used in employee evaluations, written performance appraisals, or to suggest or impose production quotas or goals. Employee performance is to be measured against the employee's critical job elements (CJEs) and standards. Managers may NOT use ROTERs in monitoring progress against employee CJEs. ROTERs do not convey how an employee performed in relation to requirements of the CJE performance plan. Managers must be careful to not use “soft language or phrases” that are suggestive of TERs or ROTERs. Examples of these type of items are:



    - Successful prosecution referral of individuals and entities,

    - Seizure of luxury automobiles (Title 26 only),

    - Numerous search warrants were executed,

    - Multiple currency seizures (Title 26 only),

    - Subjects were charged with various Federal crimes such as...(if includes Title 26),

    - Substantial forfeitures of assets (Title 26 only),

    - Significant amount of assets that were subject to forfeiture and seizure,

    - Seizure of an extremely large amount of currency (Title 26 only).


### Note:

Although the use of TERs in performance evaluations does not violate Section 1204 or Regulation 801 (see IRM 1.5.2.8, Regulation 801), it is against IRS policy to include TERs in employee evaluations or written performance appraisals.

04. The prohibition of the use of ROTERs in performance evaluations applies to the result reached in a single case. As Section 1204 can apply to the result reached in a single case, managers cannot use the outcome of a TER from a single case to evaluate an employee or suggest quotas or goals.



    ### Note:



    In an employee evaluation, a manager may discuss with an employee their exercise of judgment and steps undertaken in a case when based on a review of the employee's work on that individual case but cannot reference the TER of the case.

05. Managers may cite and discuss TERs in case reviews, workload reviews, or other employee documentation that does not meet the definition of an employee evaluation to determine if an employee exercised appropriate judgement, used time efficiently, and applied the law properly. The discussion must be based upon the manager's review of the employee's work on the specific case(s) and focus on the facts and details related to an individual TER to fairly describe the employee's performance with emphasis placed on the employee's efforts rather than on the result. A manager may reference a TER in an individual case to compare an employee’s performance to specific performance standards and make recommendations on enforcement actions.

06. Managers’ annual performance plans will be prepared and agreed upon without ROTERs being cited in the written plan. Commitments and objectives should be qualitative in nature but can and should be guided by the organization's quantitative performance measures. If individuals are held accountable solely for achieving specific numerical targets, the natural response is to focus attention on the numbers and not on the actions.

07. Evaluations for all levels of management will be based upon the individual manager's actions taken in accordance with that manager's annual agreed upon performance plan. An evaluation should focus on the actions taken (commitments or objectives) against the objectives and the results achieved to improve performance in each responsibility. Numerical results are helpful only for making an initial assessment of the impact those actions had on the responsibilities.

08. Numerical (quantitative) performance measures may not be used as a stand-alone measure to determine the individual manager's evaluation rating when comparing their achievements to their annual performance plan. As with all non-supervisory employee evaluations, managerial evaluations must not cite any ROTERs.

09. Managers are free to discuss TERs with the subordinate manager being evaluated, but the manager's evaluation is required to emphasize the subordinate manager's performance against their annual agreed upon performance plan.

10. Self- assessments prepared by employees or managers must not contain ROTERs. Including ROTERs in self-assessments does not violate Section 1204 or Regulation 801: however, it is IRS policy that employees should not use ROTERs in self-assessments. If an employee or manager submits self-assessment information containing a ROTER, the management official receiving the information must:



    1. Return the information to the employee or manager.

    2. Inform the employee that the information received contained a ROTER and identify the ROTER for the employee.

    3. Counsel the employee so that the employee understands the proper use of statistics within the IRS and the IRS’s policy on the use of statistics.

    4. Ask the employee to submit a new self-assessment without the ROTER. The manager may not consider or use the originally submitted ROTER in an evaluation of the employee.


11. The prohibition of using ROTERs in self-assessments includes knowledge, skills, and abilities (KSA) statements prepared and submitted as part of a promotion ranking package, such as letters of interest. It is important that supervisors review all KSA statements before they are submitted to the host personnel site or deciding official. Managers will review the KSA statements for ROTERs, as well as the accuracy of the statements made by the employee.

12. It is a Section 1204(a) violation if a ranking official or panel uses the information in the ranking process or if a supervisor uses the information when evaluating employees' performance.

13. CI measures and tracks other data that relates directly to individual cases. This data may represent the result of enforcement determinations controlled in whole or in part by another government entity and may include information which qualifies as a ROTER. If so, the data should be treated as a ROTER by CI.


**1.5.5.4** **(01-30-2026)**

### Quantity and Quality Measures

1. Quantity measures are outcome-neutral production and resource data that do not contain information regarding the TER in any case or cases involving particular taxpayers. Quality measures are outcome neutral metrics used to assess the quality of performance, effectiveness or efficiency for work tasks or processes. Quality measures are based on the review of statistically valid work items handled by organizational units. Quantity and quality measures are not TERs or ROTERs.



|     |     |
| --- | --- |
| Examples of quantity measures include: | - Number of case initiations,<br>     <br>   - Number of case completions,<br>     <br>   - Work items completed,<br>     <br>   - Direct investigative time,<br>     <br>   - Number of cases in inventory,<br>     <br>   - Number of percentage of overage cases,<br>     <br>   - Percentage of direct investigative time for legal source tax crimes, illegal source financial crimes, narcotics related financial crimes, refund crimes, electronic crimes and all major subprograms. |
| Examples of quality measures include: | - Individual overage items,<br>     <br>   - Appropriate use of statutes,<br>     <br>   - Administrative actions and resources expended,<br>     <br>   - CIMIS accuracy and timeliness. |

2. Performance measures based in whole or in part on quantity measures will not be used to evaluate non-supervisory employees who are responsible for exercising judgment with respect to TERs (See Regulation 801.3(3)). Quantity measures can be used to determine areas of performance that may require management investigation of an employee’s exercise of judgement or quality of tasks, however non-supervisory Section 1204 employees may only be evaluated on work performed in the context of their CJEs. Quantity measures may be discussed in case reviews, workload reviews, or other employee documentation that does not meet the definition of an employee evaluation to determine if an employee exercised appropriate judgement, used time efficiently, and applied the law properly. Although quantity measures are not ROTERs, managers are prohibited from using the data to set or suggest a goal or quota for non-supervisory Section 1204 employees.



### Note:



Evaluations cannot be based on the number of items completed, but the quality and efficiency of an employee’s work while completing those items.

3. Quantity measures can be used to set production goals for organizational units, and managers can share and discuss those goals with the units’ employees, such as in group meetings, however managers cannot use those unit goals to set production goals for the unit’s Section 1204 employees or in the evaluation of those employees.

4. Quantity measures may be used to evaluate the performance of supervisory employees responsible for exercising judgment with respect to TERs or who supervise such employees.

5. Quality measures may be used to evaluate all supervisory and non-supervisory employees, regardless of their responsibility for exercising judgment with respect to TERs. Performance measures based on quality measures may be used to impose or suggest production goals for any employee. Additionally, quality measures may be used in all the same ways as quantity measures.

6. Balanced performance measures were developed to assist all managers to better utilize their resources. They provide insight into organizational processes and performance. Managers are expected to use these measures and tools to help them achieve an appropriate mix of customer satisfaction, employee satisfaction, and business results. See IRM 1.5.1, for more information on balanced performance measures.


**1.5.5.5** **(01-30-2026)**

### Use of Statistics for Monitoring Programs

1. ROTERs may be used at the national, regional, or field office level to monitor, direct and control program accomplishments and direction. Management officials participating in the activities of monitoring, directing, and controlling program accomplishments and direction must use caution that their use of ROTERS in authorized circumstances does not suggest or impose goals or quotes for subordinate organization units or employees.

2. Examples of the type of authorized activities in which ROTERS may be used include:



   - Long range planning,

   - Financial planning,

   - Allocation of resources,

   - Work planning and control,

   - Formulation of case selection criteria,

   - Effective functional management,

   - Staffing utilization systems and plans.


3. Goals for the balanced measures system will be set at the national level to satisfy government reporting requirements. Goals will be set no lower than the field office level. They will not be used to directly determine the evaluation of an organizational unit or an individual employee.


**1.5.5.6** **(01-30-2026)**

### Use of Statistics in Operational Reviews

1. ROTERs may be used to prepare for operational reviews at the national, area, field office, branch and group levels. ROTERS should only be used as indicators to identify variances, whether above or below the norm. ROTERS may be used to identify areas where further investigation is needed. Specific areas will be selected for further review. The purpose of additional analysis and review is to determine the quality of the processes within the organizational unit.

2. Quantity and quality measures may be used to evaluate the performance of an organizational unit. Quantity and quality measures may also be used to impose or suggest production goals for an organizational unit. An organizational unit may disseminate quantity measures to employees of the unit as organizational or employee goals, but the information cannot be used in evaluations of unit employees.

3. Using results for diagnostic tools or workload indicators to compare one unit against other units may be appropriate for:



1. Conducting analysis,

2. Identify and share best practices,

3. Seeking process enhancements.


4. The performance of any one unit at any level of the organization must not be used as a standard by which the performance of other units is evaluated due to differences that exist in:



1. Local investigative priorities,

2. Employee skill levels,

3. Specific issues being worked,

4. Other factors.


5. The review and analysis may be conducted by local management officials or through a field visitation by outside management personnel. The specific review should go beyond the raw statistics and should focus on the process to best determine what might be causing a variance.

6. ROTER data concerning one organizational unit may not systematically be shared with other units at the same level. It may only be shared with organizations to which it pertains. If ROTER data is to be shared, it must not be used to evaluate any Section 1204 employees.

7. Organizational units may share quantity measures, quality measures and other non-ROTER data at the same level.


**1.5.5.7** **(01-30-2026)**

### Section 1204 Quarterly Certification and Independent Review Process

1. The following information cannot be disclosed pursuant to the certification process:



   - Grand jury investigation information,

   - Information relating to sensitive items such as ongoing criminal investigations,

   - Informant agreements and related documents,

   - Information concerning undercover operations.


2. The employee performance file, performance appraisal documents, and other supervisory documents are required to be sanitized or purged of any sensitive investigation-specific information and made available for independent review. Detailed information regarding the independent review process is outlined in IRM 1.5.3 and must not conflict with this subsection..

3. Operational and workload review documents containing any information identified in paragraph (1) above must be excluded from the independent review process.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-005-005#addtoany "Show all")

A2A