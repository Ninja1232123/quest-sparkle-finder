---
url: "https://www.irs.gov/irm/part1/irm_01-015-004"
title: "1.15.4 Retiring and Requesting Records | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-015-004#main-content)

- 1.15.4  [Retiring and Requesting Records](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754662448)
  - 1.15.4.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754743264)
    - 1.15.4.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754735632)
    - 1.15.4.1.2  [Authority to Retire IRS Records](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754732288)
    - 1.15.4.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754725120)
    - 1.15.4.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754684928)
    - 1.15.4.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754676976)
    - 1.15.4.1.6  [Acronyms and Terms](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754674352)
    - 1.15.4.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754202784)
  - 1.15.4.2  [Retiring Records to the Federal Records Center (FRC)](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754196544)
    - 1.15.4.2.1  [Criteria for Retiring Records](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754264608)
  - 1.15.4.3  [Archives and Records Centers Information System (ARCIS)](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754259920)
  - 1.15.4.4  [Preparing and Maintaining the Standard Form (SF) 135, Records Transmittal and Receipt and Required Box Listing](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754257216)
    - 1.15.4.4.1  [Processing the Returned SF–135](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152755149808)
  - 1.15.4.5  [Selecting, Assembling and Packing Cartons](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152755146672)
    - 1.15.4.5.1  [Determining the Appropriate Shipment Method](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152755114832)
  - 1.15.4.6  [Retiring Tax-Related Records Protected by Internal Revenue Code 6103 or Classified Records](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152755101872)
  - 1.15.4.7  [Retiring Non-Current Official Personnel Folders (OPF) and Employee Personnel Folders (EPF)](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754188992)
  - 1.15.4.8  [Retiring Criminal Investigative (CI) and Grand Jury Case Files](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754181488)
  - 1.15.4.9  [Requesting Records from the FRC](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754173632)
    - 1.15.4.9.1  [Completing Form 2275](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754168592)
    - 1.15.4.9.2  [NARA Optional Form 11](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754150480)
  - 1.15.4.10  [Emergency Requests for Tax Returns and Related Documents](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754148512)
    - 1.15.4.10.1  [Other Emergency Requests](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754142976)
  - Exhibit  1.15.4-1  [Form SF–135, Records Transmittal and Receipt](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754136096)
  - Exhibit  1.15.4-2  [Federal Records Cartons](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754132768)
  - Exhibit  1.15.4-3  [IRS Approved Tape for IRC 6103 and Grand Jury Records](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754128384)
  - Exhibit  1.15.4-4  [Form 2275, Records Request, Charge and Recharge](https://www.irs.gov/irm/part1/irm_01-015-004#idm140152754126272)

# Part 1. Organization, Finance, and Management

# Chapter 15. Records and Information Management

# Section 4. Retiring and Requesting Records

* * *

## 1.15.4 Retiring and Requesting Records

#### Manual Transmittal

February 26, 2025

#### Purpose

(1) This transmits revised IRM 1.15.4, Records and Information Management, Retiring and Requesting Records.

#### Material Changes

(1) 1.15.4.1.6 - Acronyms and Terms - Updated to include Classified National Security Information (CNSI).

(2) 1.15.4.5.1 - Determining the Appropriate Shipment Method - Updated the content to reflect the organizational name change from Wage and Investment (W&I) to Taxpayer Services (TS). Provided additional instructions on making the appropriate selection on Form 14680 , Freight Services Request, that a truck seal is required for the trailer.

(3) 1.15.4.6 - Retiring Tax-Related Records Protected by IRC 6103 or Classified Records - Removed the word “Section” from the subsection title following guidelines in Document 12835 , IRM Style Guide. Added the word **transmission** as updated terminology when referencing shipping guidelines listed in IRM 10.9.1, Classified National Security Information (CNSI).

(4) IRM references and website links were updated throughout this IRM section.

#### Effect on Other Documents

IRM 1.15.4, dated March 11, 2024, is superseded.

#### Audience

All IRS divisions and functions.

#### Effective Date

(02-26-2025)

Michael J. Oser

Acting Director, Identity and Records Protection (IRP)

Privacy, Governmental Liaison and Disclosure (PGLD)

**1.15.4.1** **(03-11-2021)**

### Program Scope and Objectives

1. **Purpose:** This IRM section covers the process for retiring records to and requesting records from Federal Records Center (FRC). The protection of information is of vital concern to the Service. Every effort must be made to ensure that all documents are provided protection commensurate with the information therein. FRCs ensure records are protected and remain available for their scheduled life (at the end of their retention schedule). FRCs store agency records and make them accessible when needed.

2. **Audience:** These procedures apply to **all** IRS employees and contractors.

3. **Policy Owner:** Director, Identity and Records Protection - Records and Information Management (RIM).

4. **Program Owner:** The Records and Information Management (RIM) office, under Privacy, Governmental Liaison and Disclosure (PGLD) is the program office that provides guidance and is responsible for oversight of the Servicewide records management policy.

5. **Primary Stakeholders:** The Records and Information Management (RIM) Program office, under PGLD, promotes responsible recordkeeping practices for IRS employees and contractors to follow in accordance with federal laws, regulations, and procedures.


**1.15.4.1.1** **(03-11-2021)**

#### Background

1. This IRM provides instructions on how to retire records to, and request records from, FRC.

2. Records, paper and/or electronic media (limited to small quantities of mixed media), are retired to the FRC for storage and servicing according to Document 12990, IRS Records Control Schedules (RCS), and Document 12829, General Records Schedules (GRS), and prescribed storage standards.

3. Federal agencies can request the return of records, excluding official personnel folders and employee medical folders, from the FRC.


**1.15.4.1.2** **(03-11-2021)**

#### Authority to Retire IRS Records

1. Retire eligible records according to the instructions in Document 12990, IRS Records Control Schedules (RCS) and Document 12829, General Records Schedules (GRS)

2. Internal Revenue Code (IRC) [6103](https://irm.web.irs.gov/common/scripts/ExitScript.asp?GOTO=https://www.govinfo.gov/content/pkg/USCODE-2011-title26/pdf/USCODE-2011-title26-subtitleF-chap61-subchapB-sec6103.pdf), Confidentiality and disclosure of returns and return information

3. [Title 36 Code of Federal Regulations (CFR) Chapter XII, Subchapter 1232](https://www.ecfr.gov/current/title-36/chapter-XII/subchapter-B/part-1232), Transfer of Records to Records Storage Facilities

4. [Title 36 CFR Chapter XII, Subchapter 1234](https://www.ecfr.gov/current/title-36/chapter-XII/subchapter-B/part-1234), Facility Standards for Records Storage Facilities

5. [Title 36 CFR Chapter XII, Subchapter 1235](https://www.ecfr.gov/current/title-36/chapter-XII/subchapter-B/part-1235), Transfer of Records to the National Archives of the United States

6. [44 United States Code (USC) 3103](https://www.archives.gov/about/laws/fed-agencies.html), Transfer of records to records centers


**1.15.4.1.3** **(08-10-2017)**

#### Responsibilities

1. This IRM is used by **all** IRS employees and contractors to ensure compliance with paper and electronic records management requirements.


**1.15.4.1.4** **(03-11-2024)**

#### Program Management and Review

1. The RIM Program is evaluated using the following reviews and reports:



   - **Records Management Self-Assessment (RMSA)**: The annual RMSA asks questions that assess compliance with records management statutes and regulations, as well as National Archives and Records Administration (NARA) policies and guidance.

   - **Federal Electronic Records and Email Management Reporting**: This report not only evaluates federal agency email management, it also seeks to assess the current state of all electronic records management at federal agencies (including email and permanent electronic records).

   - **Senior Agency Official for Records Management (SAORM) Annual Report**: This report gathers data on agency progress towards the goals of the OMB/NARA Update to Transition to Electronic Records memo (M-23-07) and other important records management initiatives as identified by NARA.

   - **Form 14377, Records and Information Management Virtual Program Review Self Assessment Checklist**: This checklist is utilized as a self-assessment tool to assist the field site offices with records management policies and procedures. In addition, it measures RIM goals to stimulate better fiscal management.

   - **Form 14377-A, IRS Records and Information Management (RIM) Evaluation Checklist**: PGLD requires all business unit information resource coordinator (IRC) contacts to complete this form on a quarterly basis. The purpose of the form is to ensure and document IRS recordkeeping compliance as defined by NARA. Completing the Form 14377-A identifies to PGLD:IRP:RIM potential gaps for training opportunities to assist the business unit with their recordkeeping responsibilities.


**1.15.4.1.5** **(03-11-2024)**

#### Program Controls

1. **Records Management Mandatory Briefing**: Every IRS employee and contractor must protect the information they handle daily to carry out their job responsibilities. They must annually take the Records Management Mandatory Briefing Integrated Talent Management (ITM) course #62965, Records Management Awareness, to ensure IRS records management is efficient, effective, and compliant with all applicable records management laws and regulations.


**1.15.4.1.6** **(02-26-2025)**

#### Acronyms and Terms

1. The table lists commonly used acronyms and terms:




| **Acronym** | **Term** |
| --- | --- |
| ARCIS | Archives and Records Centers Information System |
| CFR | Code of Federal Regulations |
| CNSI | Classified National Security Information |
| EMF | Employee Medical Folder |
| EPF | Employee Personnel Folder |
| FRC | Federal Records Center |
| GAO | Government Accountability Office |
| GRS | General Records Schedules, Document 12829 |
| IRC | Information Resource Coordinator |
| NARA | National Archives and Records Administration |
| NPRC | National Personnel Records Center |
| OPF | Official Personnel Folder |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| RCS | Records Control Schedules, Document 12990 |
| RIM | Records and Information Management |
| TDAs | Taxpayer Delinquent Accounts |
| TDIs | Taxpayer Delinquency Investigations |
| USC | United States Code |


**1.15.4.1.7** **(08-10-2017)**

#### Related Resources

1. Records and Information Management SharePoint

2. Document 12829, General Records Schedules

3. Document 12990, IRS Records Control Schedules

4. Title [36 CFR Chapter XII Subchapter B](https://www.govinfo.gov/content/pkg/CFR-2011-title36-vol3/pdf/CFR-2011-title36-vol3-chapXII-subchapB.pdf), Records Management codes

5. [44 USC 3103](https://www.archives.gov/about/laws/fed-agencies.html), Transfer of records to records centers

6. Standard Form (SF)-135, Records Transmittal and Receipt

7. IRM 10.5.1, Privacy Policy

8. IRM 10.9.1, Classified National Security Information (CNSI)


**1.15.4.2** **(03-11-2024)**

### Retiring Records to the Federal Records Center (FRC)

1. Records, paper and/or electronic media (limited to small quantities of mixed media), that are no longer required in active office space and occupying valuable storage space, are retired to FRC. The IRS and NARA have a reimbursable Interagency Agreement under which FRC stores and services these records.



### Note:



Electronic records from IRS systems are never retired to the FRC, but the mixed media related to case files (for example, thumb drives, compact discs) can be retired to FRC.

2. IRS employees, including IRCs, should never contact FRC directly. Only the IRS Records Officer and Records Specialist employees are authorized to contact FRC. For any questions, especially about retiring mixed media, please contact your Records Specialist.


**1.15.4.2.1** **(08-10-2017)**

#### Criteria for Retiring Records

1. Apply the following criteria when preparing to retire records:



1. Retirement of record series is included in an existing records control schedule,

2. Records are no longer needed for current operations, as judged by a low reference rate,

3. Records occupy at least one cubic foot of space, and

4. Records will remain at the FRC for at least a year.


### Exception:

Records can be retired earlier than the time stated in the records control schedules. If such action is necessary, contact your Records Specialist, who will make the necessary arrangements with the IRS Records Officer to coordinate your request with NARA's staff.

**1.15.4.3** **(03-11-2024)**

### Archives and Records Centers Information System (ARCIS)

1. ARCIS is a web-based system used by NARA's FRCs. The system is the online portal through which IRS retires and transfers its records to FRC.

2. ARCIS replaced the paper process of submitting SF-135 to FRC.

3. Contact your Records Specialist for information about ARCIS.


**1.15.4.4** **(03-11-2024)**

### Preparing and Maintaining the Standard Form (SF) 135, Records Transmittal and Receipt and Required Box Listing

1. An electronic version of the SF-135 is required to be submitted to the Records Specialist for processing. With every SF-135 that is submitted, an acceptable box listing must be submitted. The box listing catalogues the contents of each box of the shipment. The use of social security numbers (SSNs), employer identification numbers (EINs), taxpayer identification numbers (TINs) and entities should not be included on the box listing submitted with SF-135 for FRC.



### Note:



The retiring office can maintain a listing with SSNs, EINs, TINs and entities for future referencing when they need to retrieve records back from the FRC.

2. The Records Specialist will assist the IRC or records POC with perfecting the SF-135 and box listing before submitting the information to ARCIS.

3. After processing in ARCIS, usually a 10-day turnaround, FRC will issue a transfer number for the records to be retired.

4. The IRC or records point of contact (POC) must:



1. Prepare an electronic SF-135 and contact their Records Specialist,

2. Submit an acceptable box listing of the records being retired to the FRC, and

3. Coordinate with the retiring office to maintain a copy of the approved SF-135 and its unmasked box listing in a collaborative secure location for the life of the records so the records can be retrieved if needed for business use.



      ### Note:



      ARCIS and the Records Office maintain the original and copy of the SF-135 and masked box listing while the retiring office must maintain the SF-135 and unmasked box listing for the life of the record and six years after the record is destroyed.


5. The information cited below is required on each SF-135:


    (See _Exhibit 1.15.4-1_, Form SF-135, Records Transmittal and Receipt).




| **Item No.** | **Required Information** |
| :-- | :-- |
| Item 1 | **Addressing Information**<br> Address of the FRC that will receive the records shipment. |
| Items 2 and 3 | Item 2 the Records Specialist must sign their name approving the transfer and date. Item 3 Name, telephone number, mail code/symbol. |
| Item 4 | LEAVE BLANK. Information to be entered by the FRC. |
| Item 5 | The Records Specialist's address must be the top address. Below, indicate post of duty address or location of the records. |
| Item 6(a) | **Accession Number**<br> Record Group Number assigned to the bureau is "058" . This number will always remain the same. |
| Item 6(b) | List the last two digits of the current fiscal year. |
| Item 6(c) | Use the four-digit number that the FRC assigns the shipment. |
| Item 6(d) | **Volume**<br> List the number of boxes for each accession number. A single number which represents the entire number of boxes, i.e., 125 boxes is 125, NOT 1-125. |
| Item 6(e) | List the sequential number of boxes.<br> <br>### Example:<br>10 boxes = 1–10; 2–10; 3–10, etc. |
| Item 6(f) | Series Description --Provide the **exact** title of the series as identified in RCSs and/or GRSs. Note any additional information or restrictions in this block that will help to describe or provide details about the records, e.g., "Service By Whole Box," "IRC 6103 Restricted," "Grand Jury" . **DO NOT INCLUDE SENSITIVE OR PRIVACY ACT INFORMATION ON THIS FORM.** |
| Item 6(g) | Restriction Code--This block indicates any restrictions that apply to the use of the records. A list of codes and their meanings are on the reverse side of the SF–135. IRS offices use "W" for most of their records. Some of the more common codes are R=IRC 6103 Restricted, P=Privacy Act, W=Witnessed Disposal.<br> <br>### Note:<br>When access is restricted to only certain agency officials, identify them in column 6f, Series Description. Leave blank when submitting your electronic SF-135 for processing. |
| Item 6(h) | Disposal Authority--List the appropriate RCS or GRS number (e.g., RCS 29/56(1) or GRS 1.1/010). |
| Item 6(i) | Disposal Date--List the month and year in which the FRC may destroy the records using the instructions in block 6 (h) above. List only the month and year, e.g., 01/2025, in which the FRC may destroy the records. Disposals are done on a quarterly basis; therefore, only four months are acceptable combinations with the year (January, April, July and October). Advance the disposal date to the beginning of the next quarter for the actual disposal date.<br> <br>### Example:<br>Records close 12/2016 -- disposal date clock starts ticking 01/2017. |


**1.15.4.4.1** **(03-11-2024)**

#### Processing the Returned SF–135

1. When the SF-135 is approved, the FRC assigns a transfer number and returns the SF-135 to the Records Specialist:



1. Forward the approved SF-135 to the IRC or records POC.

2. The IRC or records POC will mark the transfer number on each box and place the approved SF-135 and masked listing inside the first box.


**1.15.4.5** **(03-11-2021)**

### Selecting, Assembling and Packing Cartons

1. **Selecting the Carton.** Use the appropriate carton to ship records based on the following criteria:




| **If the records include** | **Then use** |
| :-- | :-- |
| Payment vouchers, TDAs and TDIs | Quarter cubic-foot IRS carton measuring 4 1/1″ Long x 8″ Wide x 5″ Deep with a separate lid.<br> <br>### Note:<br>Only to be used by IRS Campus Returns/Files Functions. |
| Tax Returns | "1040" Box measuring 131/1″ Long x 87/7″ Wide x 12 1/1″.<br> <br>### Note:<br>Only to be used by IRS Campus Returns/Files Functions. |
| Other Records | Cubic foot FRC carton measuring 14 3/3″ Long x 12″ Wide x 9 1/1″ Deep. |





### Reminder:



Use of non-standard size boxes is restricted to ONLY records too large to fit into a standard FRC-IRS approved box. You must notify the Records Specialist before using non-standard boxes so that space accommodations can be made at the FRC. Under no circumstances are non-standard boxes to be shipped to the FRC without prior approval. Non-standard records include:





   - Ledgers

   - Posting binders

   - Posters

   - Any other oversized records


2. Refer to _Exhibit 1.15.4-2_, Federal Records Cartons, for illustrations of standard and approved cartons.

3. **Assembling the Cartons**. Follow instructions on the box.

4. **Packing the Carton**. The IRC is responsible for making sure that the customer knows the records are packed in the cartons as set forth below:



1. Pack each carton with records vertically and in sequential order. They must be in the same order in which they are kept in the active files. File tabs must face the "FRONT" of the box and be visible for easy access and identification.

2. Pack letter-size records in the standard FRC carton facing the numbered end where the accession number and box number are to be printed. (This is the end opposite the stapled end.)

3. Pack legal size records in the carton, the labels/tabs face the left as you face the numbered end.

4. Each carton must be packed to avoid contents' shifting or moving. Allow about one inch of space in each box for working with the files (more space for interfiles, which will be added later - but no less than 3/3 full). Leave any file guides or tabs in place if they will help in servicing the records. These precautions prevent possible damage to the records or cartons during transit. (Use packing material as filler.)

5. Do not overpack boxes. Do not add any material or filler to the bottom, side, or top of records in the box. All loose documents must be in labeled folders.

6. Mark the accession number on each box and pack the original SF-135 and box listing inside the first box.



      ### Note:



      The stapled side of the box is always the back or rear of the box.

7. All CDs and electronic media should be placed in the last box of the transfer and notated on the box listing when submitted to the Records Specialist.


**1.15.4.5.1** **(02-26-2025)**

#### Determining the Appropriate Shipment Method

1. Records must be shipped to reach the FRC within 90 days of the date the transfer number was assigned. Contact your Records Specialist if an extension past 90 days is needed.

2. Select one of the following methods of transportation:



1. IRS-owned or leased vehicles.



      ### Note:



      This method of transportation is used exclusively for retirements to FRC that use Quarter cubic-foot IRS cartons measuring 4 1/1” Long x 8” Wide x 5” Deep with a separate lid and/or boxes measuring 13 1/1” Long x 8 7/7” x 12 1/1”.

2. Contract delivery or next-day service, i.e., United Parcel Service (UPS).

3. Commercial carrier. Prepare an Internal Revenue Bill of Lading (IRBL) for commercial carriers.


### Note:

If you are shipping tax returns or records containing taxpayer data protected under IRC 6103, see _IRM 1.15.4.6_, Retiring Tax-Related Records Protected by the Internal Revenue Code (IRC) 6103 or Classified Records, for specific instructions on how these records must be packed and the approved transportation method.

3. Employees must follow proper data protection procedures when shipping personally identifiable information (PII) as outlined in IRM 10.5.1.6.9.3, Shipping through Private Delivery Carrier.

4. Consider the size of the shipment to help you determine the best method. Consult with your Records Specialist and transportation analyst for current information about transportation methods.

5. Arrange for pickup so records can be received by the FRC before closing time.



### Note:



Transfer size must not exceed 25 boxes when shipping via UPS. Transfers over 25 boxes are freight shipments that require submission of Form 14680, Freight Services Request, and coordination through the Taxpayer Services (TS) M&P Traffic Management office. **When completing Form 14680, check the "Yes" box next to Government Seal. Explain in the "Shipper shipment detail" box that a truck seal is required for the trailer.**


**1.15.4.6** **(02-26-2025)**

### Retiring Tax-Related Records Protected by Internal Revenue Code 6103 or Classified Records

1. When retiring tax-related records protected by Internal Revenue Code (IRC) [6103](https://irm.web.irs.gov/common/scripts/ExitScript.asp?GOTO=https://www.govinfo.gov/content/pkg/USCODE-2011-title26/pdf/USCODE-2011-title26-subtitleF-chap61-subchapB-sec6103.pdf) or Classified Records to the FRC, prepare shipments in a manner that ensures protection from unauthorized disclosure of information.

2. Consult IRM 10.9.1, Classified National Security Information (CNSI), for transmission of CNSI requirements, which includes the standards for shipping, handling, and storing official information that requires safeguarding.

3. Mark and ship classified records according to the transmission guidelines in IRM 10.9.1, Classified National Security Information (CNSI).

4. Employees must follow proper data protection procedures when shipping personally identifiable information (PII) as outlined in IRM 10.5.1.6.9.3, Shipping through Private Delivery Carrier.

5. Place the approved SF-135 and box listing in a sealed envelope and properly secure the envelope on the outside of the first box of the transfer.



### Reminder:



Contact your local Disclosure Officer or staff when you have questions concerning tax-related or classified records. **Records protected under IRC 6103 must be packed and sealed using the approved IRS blue and white tape. Contact your Records Specialist for instructions on how to obtain and use this tape. See _Exhibit 1.15.4-3_, IRS Approved Tape for IRC 6103 and Grand Jury Records.**


**1.15.4.7** **(03-11-2021)**

### Retiring Non-Current Official Personnel Folders (OPF) and Employee Personnel Folders (EPF)

1. Official Personnel Folders (OPF) are the property of the Office of Personnel Management (OPM). They are physically maintained and controlled by federal agencies while employees are on their roster.

2. Each Personnel Office will maintain, retire or transfer OPFs according to the Document 12829, General Records Schedules (GRS) and OPM guidelines.

3. Each Personnel Office will retire OPFs and Employee Medical Folders (EMF) of former IRS employees to the National Personnel Records Center (NPRC), St. Louis, Missouri.

4. Employees must pack non-current OPFs alphabetically. They must:



1. Prepare two copies of a shipment box listing for each shipment, and

2. Place the box listing with the Form 3210, Document Transmittal, in the first box.



      ### Note:



      (1) The originating Personnel Office will retain a copy of the shipment box listing for reference.


      (2) There are no special boxes for shipping OPFs to the NPRC; adhere to the requirements found in Document 13056, All Employee Toolkit: Shipping Procedures for personally identifiable information (PII).


5. Employees must follow proper data protection procedures when shipping personally identifiable information (PII) as outlined in IRM 10.5.1.6.9.3, Shipping through Private Delivery Carrier.

6. Managers must retire Employee Personnel Folders (EPFs), Document 12829, GRS 2.2, Items 070-073 as required. Refer to IRM 1.4.1, Management Roles and Responsibilities, for guidance on the **Employee Performance File (EPF)**.


**1.15.4.8** **(03-11-2024)**

### Retiring Criminal Investigative (CI) and Grand Jury Case Files

1. Employees must take protective measures when retiring or shipping criminal investigative case files or grand jury case files. This assists staff in complying with Facilities Management and Security Services (FMSS) and the Office of Safeguards requirements to protect personally identifiable information (PII), sensitive but unclassified (SBU) information, and official use only (OUO) information.

2. The FRCs use a "sealed box" method for storing sensitive case files. Therefore, complete the following tasks when retiring these types of records to FRC:



1. Secure every box with tape specifically designed by the Criminal Investigation function. This tape makes potential tampering difficult. The tape includes the caption, **To be Opened by IRS Only.** If a box is requested from the FRC, IRS employees will replace this tape prior to returning the box. See _Exhibit 1.15.4-3_, IRS Approved Tape for IRC 6103 and Grand Jury Records.

2. The standard records storage box fits inside a sleeve box if you need to ship to another location. This eliminates double wrapping each box in opaque paper so that the tape or writing on the box is neither visible nor legible. Make sure that the address to/from is printed on each sleeve and inside box, so that if the sleeve is damaged in transit, the box can be identified and delivered. To order record sleeve boxes, orders may go directly to Columbia Container Corp. 1798 Union Avenue, Baltimore, MD 21211, Telephone number: 410-467-1400, Fax Number: 410-467-1793. RECORDS STORAGE BOX SLEEVE - bundles of 25, plus shipping costs. Use of a different vendor is acceptable, but note that sleeve boxes must be one quarter inch in diameter larger on all six sides of a standard FRC box.



      ### Note:



      The IRS and NARA have agreed to this arrangement in order to ensure the shipment's anonymity.

3. Advise the Records Specialist of the approximate volume of boxes and whether high reference activity is anticipated.



      ### Reminder:



      Retire grand jury records separately from criminal investigation case files. This will ensure that grand jury records receive this special handling that other record series do not require.


**1.15.4.9** **(08-10-2017)**

### Requesting Records from the FRC

1. The majority of IRS records stored at and requested from the FRCs are tax returns and related documents. These documents are filed and requested by document locator number (DLN), and are directly referenced by FRC staff without reference to the SF-135, Records Transmittal and Receipt, although an SF-135 is still created, provided to the Records Specialist, and approved by the FRC.

2. Most requests for tax returns and related documents from the FRC are computer generated through the Integrated Data Retrieval System (IDRS) or related systems such as the Audit Information Management System (AIMS). These requests are printed on Form 4251, Return Charge Out or Form 5546, Examination Return Charge Out Sheet, and serviced through the appropriate IRS Campus to and from the FRC.

3. Requests for all tax returns and documents with DLNs are made through the Returns/Files function at an IRS Campus.

4. Requests for all other tax records, including expedite requests, or those that cannot be generated through IDRS may be requested using IRS Form 2275, Records Request, Charge and Recharge. See _Exhibit 1.15.4-4_, Form 2275, Records Request, Charge and Recharge.



### Note:



Generally, a Records Specialist’s assistance is not required to request tax documents.


**1.15.4.9.1** **(03-11-2021)**

#### Completing Form 2275

1. The Form 2275, Records Request, Charge and Recharge, is used to:



1. Request a tax record from the FRC.

2. Charge-out a record to an individual.

3. Re-charge a record from one individual to another.


2. On the Form 2275, Records Request, Charge and Recharge, the requestor must complete the following information:


    (See _Exhibit 1.15.4-4_, Form 2275, Records Request, Charge and Recharge, for the guidelines on preparing Form 2275.)



### Note:



The FRC will return incomplete or incorrect forms.








| **Part/Item No.** | **Required Information** |
| :-: | :-: |
| Part A<br> Document Identification | Always complete. This information is needed to request a specific document. |
| Part B<br> Originator | Always complete. This information is required to charge-out the requested record. |
| Part C<br> Researcher Information | Complete Items 16A, 16B and 16C. This information is extracted from the SF-135. |

3. When the requested records are no longer needed, they must be returned to the FRC with the Form 2275, Records Request, Charge and Recharge, attached (stapled) to the back of the document/record and clearly annotated "Refile" .


**1.15.4.9.2** **(08-10-2017)**

#### NARA Optional Form 11

1. All other offices use NARA Federal Records Center Optional Form 11 (OF-11), Reference Request Federal Records Centers, instead of Form 2275, to request administrative records or non-DLN case files. The same information is required on the OF-11 as Form 2275, except there is no DLN identifying information. The Records Specialist must input the OF-11 information in ARCIS.


**1.15.4.10** **(03-11-2024)**

### Emergency Requests for Tax Returns and Related Documents

1. Emergency telephone requests to FRCs will be limited to:



1. Requests for tax information from foreign governments under treaty provisions.

2. Requests from IRS or Department of Justice for immediate production for court proceedings or grand juries.


2. Telephone requests will be made only by authorized employees directly to the designated IRS Campus.

3. The IRS Campus Returns/Files will service requests for documents stored in-house and call or fax any remaining requests to the FRCs.

4. The IRS Campus Directors will designate six principals and six alternates to make emergency calls to the FRCs. These names must be furnished to the FRC staff.



### Note:



Review and update these lists annually. The FRCs will not accept telephone or facsimile requests from any person whose name is not on the current IRS Campus list.


**1.15.4.10.1** **(08-10-2017)**

#### Other Emergency Requests

1. Other emergency requests are limited to:



   - Congressional inquiries

   - Statute of Limitation cases

   - Criminal Investigation cases

   - Problem Resolution Program requests


2. The requestor must use IDRS to generate emergency requests. If this is not possible due to expedite reasons, the IRS Campus Returns Files staff will accept telephone emergency calls only from authorized employees, which will include Records Specialists and the IRS Records Officer.

3. The IRS Campus Returns Files staff will:



1. Complete Form 2275 for each request.

2. Batch the requests to be sent to the FRC separately from regular requests.

3. Clearly mark the batch "EMERGENCY REQUEST" .

4. Place the batch at the beginning of the next shipment of requests to the FRC.


**Exhibit 1.15.4-1**

### Form SF–135, Records Transmittal and Receipt

![This is an Image: 31426001.gif](https://www.irs.gov/pub/xml_bc/31426001.gif)

> This is an example to illustrate how the Form SF-135, Records Transmittal and Receipt is completed properly

[Please click here for the text description of the image.](https://www.irs.gov/media/129701 "")

![This is an Image: 31426002.gif](https://www.irs.gov/pub/xml_bc/31426002.gif)

> This is the step by step instruction for completing Form SF-135

[Please click here for the text description of the image.](https://www.irs.gov/media/129706 "")

**Exhibit 1.15.4-2**

### Federal Records Cartons

![This is an Image: 31426201.gif](https://www.irs.gov/pub/xml_bc/31426201.gif)

> This is an illustration of a full size records storage carton and a half size special purpose records storage carton

[Please click here for the text description of the image.](https://www.irs.gov/media/129711 "")

![This is an Image: 31426203.gif](https://www.irs.gov/pub/xml_bc/31426203.gif)

> This is an illustration of an IRS standard type 1 carton and an IRS standard type 2 carton

[Please click here for the text description of the image.](https://www.irs.gov/media/129716 "")

![This is an Image: 31426204.gif](https://www.irs.gov/pub/xml_bc/31426204.gif)

> This is an illustration of an IRS standard type 3 carton and an IRS standard type 5 carton

[Please click here for the text description of the image.](https://www.irs.gov/media/129721 "")

**Exhibit 1.15.4-3**

### IRS Approved Tape for IRC 6103 and Grand Jury Records

![This is an Image: 31426205.gif](https://www.irs.gov/pub/xml_bc/31426205.gif)

> This is an illustration of the packing tape used on record storage cartons for IRC 6103 and Grand Jury material

[Please click here for the text description of the image.](https://www.irs.gov/media/129726 "")

**Exhibit 1.15.4-4**

### Form 2275, Records Request, Charge and Recharge

Form 2275 is available on Electronic Publishing’s site. Preparation Guidelines are provided for Requesters who prepare Form 2275 when requesting:

1. tax returns and other documents and

2. abstracts of information or copies of tax returns and other documents.


Complete Form 2275, Part A (Document Identification) and Part B (Originator Information). Part C (Researcher Information) will be provided by the Files Function.

| ITEM | INPUT |
| :-: | :-: |
| _Item 1.—_ | _Enter Social Security (SS) or Employer Identification (EI) Number, if known, when requesting tax returns and related documents._ |
| _Item 2.—_ | _Complete when applicable. For example "1040" ,"941" , etc._ |
| _Item 3.—_ | _If applicable._ |
| _Item 4.—_ | _Show the period of time covered by the return or document being requested._ |
| _Item 5.—_ | _Processing year of the return, based on last digit of the DLN._ |
| _Item 6.—_ | _Always show the latest Document Locator Number, if known, including the processing year (14th digit)._ |
| _Item 7.—_ | _If SS or EI Number given in Item 1, show name of taxpayer only. If Item 1 is not filled in, show complete name and address of the taxpayer._ |
| _Item 8.—_ | _Not applicable to the originator._ |
| _Item 9.—_ | _Show identification numbers assigned returns prior to ADP and other documents of a non-ADP nature._ |
| _Item 10.—_ | _Immediate or first line supervisor will enter a signature of approval if organizationally prescribed._ |
| _Item 11.—_ | _Enter the date the requisition is forwarded._ |
|  | _If available, show the IRS identification number (encoder number) on the back of the taxpayer's remittance, which will assist in locating full-paid returns that have not been processed._ |
|  | _When requesting Federal Tax Deposit documents, the (TUS) number must always be indicated._ |
| _Item 12.—_ | _Place an "X" in the proper box indicating the purpose for the request._ |
| _Item 13.—_ | _If the originator is located in a service campus, place an "X" in the box which identifies the service campus. If the originator is located in other than a service campus, type or print originator is located in other than a service campus, type or print originating office, (Area 2 Office, National Office, etc.) after "Other (specify)."_ |
| _Item 13A._<br>_through 13D.—_ | _Enter originating office and fill in these items to the extent applicable._ |
| _Item 13E._<br>_through 13J.—_ | _Give mailing address, stop/room number, full name, telephone number, E-mail address, and fax number._ |
| _Item 14A.—_ | _Place an "X" in this box if original document is desired._ |
| _Item 14B.—_ | _Place an "X" in this box to request a microfilm transcript._ |
| _Item 14C.—_ | _Place an "X" in this box to request miscellaneous data or documents and specify exactly what is desired immediately below if there is room or in Item 19 if more space is needed._ |
| _Item 14D.—_ | _Place an "X" in this block to signify preparation of a photocopy._ |
| _Item 14D1.—_ | _Place an "X" in this box to signify preparation of a photocopy based on receipt of a request from the public provided the request meets the provisions in IRM 11.3, Disclosure of Official Information Handbook._ |
| _Item 15.—_ | _Place an "X" in the applicable box to signify the type of request._ |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-015-004#addtoany "Show all")

A2A