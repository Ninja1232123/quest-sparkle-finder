---
url: "https://www.irs.gov/irm/part1/irm_01-014-009"
title: "1.14.9 IRS Parking Program | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-014-009#main-content)

- 1.14.9  [IRS Parking Program](https://www.irs.gov/irm/part1/irm_01-014-009#id1)
  - 1.14.9.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-014-009#id2)
    - 1.14.9.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-014-009#id4)
    - 1.14.9.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-014-009#id5)
    - 1.14.9.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-014-009#id6)
    - 1.14.9.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-014-009#id7)
    - 1.14.9.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-014-009#id8)
    - 1.14.9.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-014-009#id9)
    - 1.14.9.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-014-009#id10)
  - 1.14.9.2  [Allocation and Assignment of Parking](https://www.irs.gov/irm/part1/irm_01-014-009#id11)
    - 1.14.9.2.1  [Visitor Parking](https://www.irs.gov/irm/part1/irm_01-014-009#id13)
    - 1.14.9.2.2  [Employee Parking](https://www.irs.gov/irm/part1/irm_01-014-009#id14)
    - 1.14.9.2.3  [Mission Essential Parking](https://www.irs.gov/irm/part1/irm_01-014-009#id15)
    - 1.14.9.2.4  [Parking for Employees with Disabilities](https://www.irs.gov/irm/part1/irm_01-014-009#id16)
    - 1.14.9.2.5  [Use of POV for Official Business](https://www.irs.gov/irm/part1/irm_01-014-009#id17)
    - 1.14.9.2.6  [Contractor Parking](https://www.irs.gov/irm/part1/irm_01-014-009#id18)
    - 1.14.9.2.7  [Parking Availability in Government-Owned Facilities](https://www.irs.gov/irm/part1/irm_01-014-009#id19)
    - 1.14.9.2.8  [Parking Availability in Leased Facilities](https://www.irs.gov/irm/part1/irm_01-014-009#id20)
    - 1.14.9.2.9  [Parking for Criminal Investigation](https://www.irs.gov/irm/part1/irm_01-014-009#id21)
  - 1.14.9.3  [Collective Bargaining Agreements](https://www.irs.gov/irm/part1/irm_01-014-009#id22)
  - 1.14.9.4  [Submission of Requests to GSA to Acquire Parking](https://www.irs.gov/irm/part1/irm_01-014-009#id23)
    - 1.14.9.4.1  [Use of IRS Procurement Authority](https://www.irs.gov/irm/part1/irm_01-014-009#id25)
    - 1.14.9.4.2  [Approval Authorities](https://www.irs.gov/irm/part1/irm_01-014-009#id26)
    - 1.14.9.4.3  [Funding](https://www.irs.gov/irm/part1/irm_01-014-009#id27)
    - 1.14.9.4.4  [Release of Parking](https://www.irs.gov/irm/part1/irm_01-014-009#id28)
  - 1.14.9.5  [Taxable Parking Benefits](https://www.irs.gov/irm/part1/irm_01-014-009#id29)
    - 1.14.9.5.1  [Procedures for Taxable Parking Benefits](https://www.irs.gov/irm/part1/irm_01-014-009#id31)
  - 1.14.9.6  [Applicability](https://www.irs.gov/irm/part1/irm_01-014-009#id32)

# Part 1. Organization, Finance, and Management

# Chapter 14. Facilities Management

# Section 9. IRS Parking Program

* * *

## 1.14.9 IRS Parking Program

#### Manual Transmittal

December 29, 2025

#### Purpose

(1) This transmits the new IRM 1.14.9, _IRS Parking Program_.

#### Material Changes

(1) This IRM includes Program Management and Review, and Program Controls sections.

(2) References to IRS Real Property Leasing Officer (RPLO) are deleted throughout.

(3) _IRM 1.14.9.1 (1)_ \- Reorganized content of paragraph to clarify purpose of IRM.

(4) _IRM 1.14.9.1 (5)_ \- Updated name of program.

(5) _IRM 1.14.9.1.2_ \- Inserted links to cited resources and authorities; inserted citation and link to 41 CFR 102-73.240; removed references to Executive Order 13243, January 24, 2007, Strengthening Federal Environmental, Energy and Transportation Management, and Executive Order 13514, October 5, 2009, Federal Leadership in Environmental, Energy and Economic Performance.

(6) _IRM 1.14.9.1.3_ \- Updated title and inserted links to cited resources.

(7) _IRM 1.14.9.1.4_ \- Added Program Management and Review section and renumbered subsequent sections.

(8) _IRM 1.14.9.1.5_ \- Added Program Controls section and renumbered subsequent sections.

(9) _IRM 1.14.9.1.6_ \- Updated title and linked citation, edited for plain language, and updated table of acronyms to:

1. Add acronyms for Internal Revenue Workflow Optimization Request and Knowledge System (IRWorks) and Workplace Service Delivery (WSD).

2. Update acronym for Real Property Management (RPM), to Real Property (RP).

3. Remove acronyms for Federal Management Regulation (FMR), IRS Disability Office (IDO), Knowledge/Incident Service and Asset Management (KISAM), and Real Property Leasing Officer (RPLO).


(10) _IRM 1.14.9.1.7_ \- Updated title of cited IRM.

(11) _IRM 1.14.9.2_ \- Inserted links to cited regulation resources.

(12) _IRM 1.14.9.2.2_ \- Inserted link to cited resource.

(13) _IRM 1.14.9.2.3_ \- Inserted links to cited resources, removed references to RPLO and clarified language.

(14) _IRM 1.14.9.2.3 (3)_ \- Removed bullet (c) involving competitive labor conditions as a criteria.

(15) _IRM 1.14.9.2.3 (4)_ \- Removed business units will submit their parking requirements to the FMSS TM for review.

(16) _IRM 1.14.9.2.4_ \- Updated citations and inserted citation links throughout subsection.

(17) _IRM 1.14.9.2.4 (5)_ \- Updated explanation of ride sharing to encompass additional types of ride sharing.

(18) _IRM 1.14.9.2.4 (6)_ \- Edited for plain language and to include a link to the cited resource.

(19) _IRM 1.14.9.2.4 (11)_ \- Updated and linked citations to referenced resources; removed references to IRS Disability Office (IDO) and replaced with references to the responsibilities of the Reasonable Accommodation Coordinator (RAC); and updated reference to prior ticketing system, KISAM, with new system name of IRWorks.

(20) _IRM 1.14.9.2.5_ \- Inserted links to cited IRM reference and updated title to IRM cited in Note.

(21) _IRM 1.14.9.2.7_ \- Updated and inserted links to cited resources.

(22) _IRM 1.14.9.2.9 (1)_ \- Updated and linked citation.

(23) _IRM 1.14.9.2.9 (2)_ \- Edited to remove outdated references to IRS procedures that are now conducted through GSA, and remove reference to RPLO.

(24) _IRM 1.14.9.3 (3)_ \- Updated the Article and Section of the National Treasury Employees Union (NTEU) National Agreement that is referenced to reflect the information in the current contract.

(25) _IRM 1.14.9.4_ \- Updated title to remove RPLO acronym and remove this acronym from the body of the subsection.

(26) _IRM 1.14.9.4.1_ \- Edits made to insert links, revise link information as appropriate, and conform to IRM Style Guide.

(27) _IRM 1.14.9.4.2 (1)_ \- Updated language and references for clarity and inserted links to cited resources where applicable. Added requests must be made at head of office level.

(28) _IRM 1.14.9.5 (1)_ \- Inserted links to cited form and publication.

(29) _IRM 1.14.9.5 (2)_ \- Revised language to clarify that comparison of costs must be against an arm’s length transaction with the same or similar circumstances.

(30) _IRM 1.14.9.5.1_ \- Inserted links to referenced Forms.

(31) Edits made throughout for plain language and grammar.

#### Effect on Other Documents

This IRM supersedes IRM 1.14.9, dated April 25, 2019.

#### Audience

Servicewide

#### Effective Date

(12-29-2025)

John Pekarik

Acting Chief

Facilities Management and Security Services

**1.14.9.1** **(12-29-2025)**

### Program Scope and Objectives

1. **Purpose**: The purpose of the IRS Parking Program is to:



1. Ensure the IRS complies with applicable federal statutes, executive orders, and regulations.

2. Ensure the IRS complies with Department of Treasury, IRS, and General Services Administration (GSA) directives regarding the assignment, allocation, and management of parking at all government-owned and leased IRS facilities.

3. Identify employee and manager responsibilities related to parking fringe benefit tax reporting.


2. The objectives of the IRS Parking Program are to:



1. Ensure that all IRS business operating divisions, managers and employees comply with applicable statutes, regulations, directives and agency practices applicable to parking at IRS facilities.

2. Promote proper and effective utilization of parking resources to ensure maximum value to the IRS, the federal government, and taxpayers.

3. Identify employee taxable fringe benefit parking to ensure employee tax compliance.


3. **Audience**: Servicewide

4. **Policy Owner**: Chief, Facilities Management and Security Services (FMSS)

5. **Program Owner**: Associate Director, Project Management, FMSS

6. **Primary Stakeholders**: Servicewide managers, employees, and FMSS Territory Managers (TM)


**1.14.9.1.1** **(12-29-2025)**

#### Background

1. There are numerous federal statutes, executive orders, regulations, and several Treasury, GSA and IRS directives, and agency practices pertaining to the assignment, use, and expense of parking in both government owned and leased facilities. This IRM provides guidance to ensure that the IRS complies with applicable federal parking mandates in the assignment, allocation, and management of parking at all government owned and leased IRS facilities. This IRM also provides guidance on managing taxable parking benefits.


**1.14.9.1.2** **(12-29-2025)**

#### Authority

1. The IRS Parking Program is based on the following statutes, executive orders, regulations, and agency directives:



01. [Federal Employees Clean Air Incentives Act](https://www.govinfo.gov/content/pkg/STATUTE-107/pdf/STATUTE-107-Pg1995.pdf), Pub. L. 103-172, 5 United States Code (USC) 7905.

02. [Architectural Barriers Act (ABA) of 1968](https://uscode.house.gov/view.xhtml?req=(title:42%20section:4151%20edition:prelim)), Pub. L. 90-480, 42 USC 4151 et seq.

03. [The Rehabilitation Act of 1973](https://uscode.house.gov/view.xhtml?req=(title:29%20section:701%20edition:prelim)), Pub. L. 93-112, 29 USC 701 et seq.

04. [Public Buildings Act of 1959](https://www.congress.gov/86/statute/STATUTE-73/STATUTE-73-Pg479.pdf), Pub. L. 86-249, 40 USC 601 et seq.

05. [Executive Order 12191](https://www.archives.gov/federal-register/codification/executive-order/12191.html), February 1, 1980, Federal Facility Ridesharing Program.

06. [Executive Order 13150](https://www.transportation.gov/sites/dot.gov/files/docs/executive-order-13150.pdf), April 21, 2000 Federal Workforce Transportation.

07. 41 Code of Federal Regulations (CFR) 102-71 (41 CFR 102-71).

08. 41 CFR 102-74.

09. 41 CFR 102-73.240.

10. Parking Reimbursements, [Revenue Ruling 2004-98](https://www.irs.gov/pub/irs-drop/rr-04-98.pdf).

11. Publication 15-B, _Employers Tax Guide to Fringe Benefits_.

12. [Treasury Directive 74-08](https://home.treasury.gov/about/general-information/orders-and-directives/td74-08): Department of the Treasury Parking Directive.

13. [Treasury Directive 74-10](https://home.treasury.gov/about/general-information/orders-and-directives/td74-10): Public Transportation Program.

14. [43 Comp. Gen.131, 1963, Comp. Gen. Op. B-152020.](https://www.gao.gov/products/b-152020)

15. [63 Comp. Gen. 270, 1984, Comp. Gen. Op. B- 211812.](https://www.gao.gov/products/b-211812-0)

16. [72 Comp. Gen 139,141, 1993, Comp. Gen. Op. B-248247.](https://www.gao.gov/products/b-248247)

17. [GSA Leasing Desk Guide, October 31, 2013, Appendix H, Parking Acquisition](https://www.gsa.gov/system/files/LDG-AppendixH-ParkingAcquisition-Final-11-01-2013.pdf) (applies to lease acquisition authority delegated by GSA to other agencies and was issued via GSA Public Buildings Service Lease Acquisition Circular (LAC-2013-05, November 1, 2013).


**1.14.9.1.3** **(12-29-2025)**

#### Roles and Responsibilities

1. Each FMSS Territory Manager (TM) is responsible for:



1. Ensuring public transportation alternatives and space, facilities and services for bicycles are made available to employees and visitors whenever possible.

2. Ensuring parking is assigned for official vehicles, disabled employees, executives, visitors, employees and others in accordance with the priorities established by 41 CFR 102-74 by conducting periodic reviews of assigned IRS parking.

3. Coordinating with GSA for the equitable allocation of parking spaces for the IRS in federal buildings, and in leased buildings where assigned parking is applicable, in accordance with 41 CFR 102-74.

4. Maintaining parking lots and spaces in locations where the IRS has delegated operation and maintenance responsibility received from GSA by performing routine maintenance and repair such as, but not limited to, parking lighting, pavement striping, asphalt repairs, trash removal and snow removal.

5. Ensuring regulatory, statutory, and/or site-specific signage placement (or posting).

6. Establishing and enforcing local government parking regulations, as applicable.

7. Ensuring adequate controls are in place to monitor the temporary use of parking for disabled employees.

8. Monitoring parking costs for all IRS recipients of parking that is valued in excess of the yearly taxable fringe benefit amount per the annual IRS Publication 15-B, _Employer’s Tax Guide to Fringe Benefits_,

9. As applicable, following instructions in and completing Form 9606, _Taxable Parking Benefits_ and submitting it to the Beckley Finance Center at calendar year end.


**1.14.9.1.4** **(12-29-2025)**

#### Program Management and Review

1. Every December, the parking program owner in Real Property submits a control for Form 9606, _Taxable Parking Benefits_. This control distributes Form 9606 and IRS Pub 15-B, _Employer’s Tax Guide to Fringe Benefits_, to FMSS TMs. The TMs must then distribute the forms to recipients of parking with a value exceeding the yearly taxable fringe benefit and to the Beckley Finance Center.


**1.14.9.1.5** **(12-29-2025)**

#### Program Controls

1. Program documentation and information is centralized and stored on a SharePoint site with access limited to authorized personnel.

2. The yearly control for Taxable Parking Benefits is distributed for completion via the FMSS Controls SharePoint Site.


**1.14.9.1.6** **(12-29-2025)**

#### Terms and Acronyms

1. For purposes of parking the following definitions found in 41 CFR 102-71.20 apply.



1. **Carpool** \- a group of two or more persons regularly using a motor vehicle for transportation to and from work on a continuing basis.

2. **Disabled employee** \- an employee who has a severe, permanent impairment that for all practical purposes precludes the use of public transportation, or an employee who is unable to operate a car as a result of permanent impairment who is driven to work by another.



      ### Note:



      Priority may require certification by an agency medical unit, including the Department of Veterans Affairs or the Public Health Service.

3. **Unusual hours** \- work hours that are frequently required to be varied and do not coincide with any other regular work schedule. This includes individuals who regularly or frequently work significantly more than eight hours per day. Unusual hours do not include shift workers, those on Alternate Work Schedules or those granted exceptions to the normal work schedule (e.g., flex-time).

4. **Vanpool** \- a group of at least eight persons using a passenger van or a commuter bus designed to carry 10 or more passengers. Such a vehicle must be used for transportation to and from work in a single daily round trip.


2. For the purposes of this program, the following IRS definition applies:



1. **Executive** means a Senior Executive Service (SES) government employee with management responsibilities who, in the judgment of the employing agency head or his/her designee, requires preferential assignment of parking privileges.


3. Table of acronyms and their definitions.




| **Acronym** | **Definition** |
| --- | --- |
| ABA | Architectural Barriers Act |
| CFO | Chief Financial Officer |
| CFR | Code of Federal Regulations |
| CI | Criminal Investigation |
| EOD | Enter On Duty |
| FMSS | Facilities Management and Security Services |
| GSA | General Services Administration |
| GAO | Government Accountability Office |
| IR | Internal Revenue |
| IRWorks | Internal Revenue Workflow Optimization, Request and Knowledge System |
| LAC | Lease Acquisition Circular |
| NTEU | National Treasury Employees Union |
| OPM | Office of Personnel Management |
| POV | Privately-Owned Vehicle |
| PTSP | Public Transportation Subsidy Program |
| RA | Reasonable Accommodation |
| RAC | Reasonable Accommodation Coordinator |
| RLP | Request for Lease Proposal |
| RP | Real Property |
| SES | Senior Executive Service |
| TM | Territory Manager |
| USC | United States Code |
| WSD | Workplace Service Delivery |


**1.14.9.1.7** **(12-29-2025)**

#### Related Resources

1. IRM 1.14.6, _Real Property_


**1.14.9.2** **(12-29-2025)**

### Allocation and Assignment of Parking

1. IRS will provide parking space for official government owned or leased vehicles whenever possible.

2. 41 CFR 102-74.285 establishes the following priority for assignment of parking:



1. Official postal vehicles at buildings containing the U.S. Postal Service's mailing operations.

2. Federally owned vehicles used to apprehend criminals, fight fires, and handle other emergencies.

3. Private vehicles owned by members of Congress (but not their staff).

4. Private vehicles owned by federal judges (appointed under Article III of the Constitution), which may be parked in those spaces assigned for the use of the U.S. Courts, with priority for them set by the Administrative Office of the U.S. Courts.

5. Other federally owned and leased vehicles, including those in motor pools or assigned for general use.

6. Service vehicles, vehicles used in childcare center operations, and vehicles of patrons and visitors (federal agencies must allocate parking for disabled visitors whenever an agency's mission requires visitor parking).

7. Private vehicles owned by employees, using spaces not needed for official business.



      ### Note:



      However, in major metropolitan areas, federal agencies may determine that allocations by zone would make parking more efficient or equitable while accounting for the priority for official parking set forth in this section.


3. Furthermore, once the provisions of 41 CFR 102-74.285 are met, the CFR directs federal agencies to assign available parking spaces to their employees using the following order of priority in 41 CFR 102-74.305:



1. Disabled employees (per definition in 41 CFR 102–71.20).

2. Executive personnel and persons who work unusual hours.



      ### Note:



      For purposes of parking, 41 CFR 102–71.20 defines an executive as a government employee with management responsibilities who, in the judgement of the employing agency head or his/her designee requires preferential assignment of parking privileges.

3. Vanpool and carpool vehicles.

4. Privately owned vehicles (POV) of occupant agency employees that are regularly used for government business at least 12 days per month and that qualify for reimbursement of mileage and travel expenses under government travel regulations.

5. Other POV of employees, on a space-available basis. (In locations where parking allocations are made on a zonal basis, GSA and affected agencies may cooperate to issue additional rules, as appropriate.)


**1.14.9.2.1** **(06-21-2011)**

#### Visitor Parking

1. The IRS may procure parking for IRS customers when it is determined that adequate modes of public transportation are not available to the site, or an adequate combination of public transportation and commercial parking facilities is not available.


**1.14.9.2.2** **(12-29-2025)**

#### Employee Parking

1. In most instances, appropriated funds will not be used to procure employee parking. The Office of the Comptroller General has long found that employee parking is generally considered a personal expense of the employee and expenses considered personal in nature are not payable from appropriated funds absent specific statutory authority ( [43 Comp. Gen.131, 1963, Comp. Gen. Op. B-152020](https://www.gao.gov/products/b-152020)). Since it is the Government's stated position to encourage the use of public transportation, the IRS should not take actions to acquire space that will encourage employees to drive to work rather than use public transportation.


**1.14.9.2.3** **(12-29-2025)**

#### Mission Essential Parking

1. In certain situations, parking may be procured when the IRS determines, for legitimate reasons, that to provide parking for employees, is mission essential. The "mission essential" determination may require a justification from the IRS to GSA stating employee parking is necessary to avoid a significant impairment to agency operating efficiency. The use of public transportation must not be discouraged, and limited availability of parking and inconvenience are not factors which by themselves can justify a determination that parking is mission essential.

2. After a requesting business operating division determines parking is mission essential, the FMSS TM will contact local government officials to determine whether improvements can be made in public transportation (i.e., additional buses or route changes), if additional public parking can be made available, or if any reasonable solution can be found beyond acquiring additional parking spaces.

3. The criteria to evaluate whether parking is mission essential are:



1. Inadequate availability of public transportation and public parking. However, public parking should not be over-emphasized in relationship to public transportation.

2. Need to provide a safe work environment for employees; for example, when a shift ends at times when normal public transportation or public parking are either not available or not safely accessible.


4. Parking must not automatically be procured on a one-to-one ratio for all employees, even when some parking is considered mission essential. For new or leased construction, GSA will conduct a parking survey with the local FMSS territory office to determine the specific number of parking spaces to be provided for official, visitor and employee vehicles. The survey should consider need based on the adequacy of public transportation, the availability of commercial or public parking facilities, employee shifts and other concerns such as environmental quality and energy consumption.

5. Facilities most likely to meet the mission essential criteria are the campuses and computing centers. However, for each new procurement and assignment of space, regardless of location, parking requirements will be reassessed due to changes in the building’s IRS occupants, hours of duty, available transportation, federal laws, executive orders, regulations or directives, and proper assignment in accord with 41 CFR 102-74.285 and 41 CFR 102-74.305.


**1.14.9.2.4** **(12-29-2025)**

#### Parking for Employees with Disabilities

01. The eligibility for government provided parking for reasons of a disability will be determined on the same basis as other requests for RA, which are to: give the person an equal opportunity to be considered for a job; to perform the essential functions of the job; and to enjoy equal benefits and privileges of the job.

02. In accordance with 41 CFR 102-71.20, a disabled employee is one who has "a severe, permanent impairment that for all practical purposes precludes the use of public transportation, or an employee who is unable to operate a car as a result of permanent impairment who is driven to work by another."

03. In instances where parking spaces are available for the IRS due to a lease procurement, code, or government owned building allotment after parking for official vehicles is met in accordance with 41 CFR 102-74.285, FMSS will assign approved RA parking for employees in accordance with 41 CFR 102-74.305. Where IRS assigned parking is unavailable, the IRS will acquire and fund RA parking through the lease or through assignment from GSA, if possible.

04. If RA parking is not possible through the GSA lease or assignment, and parking is not available for employees to acquire individually, the acquisition of parking for disabled personnel may be considered necessary as a RA in accordance with _IRM 1.14.9.2.4 (1)_.

05. Prior to acquiring parking for disabled employees, alternatives to consider include:



    1. Telework.

    2. Public transportation and use of the Public Transportation Subsidy Program (PTSP) and pre-tax parking fringe benefit.

    3. Ride sharing (e.g., carpools, vanpools, and other types of ride sharing).


06. If parking is available for employees to acquire on their own, the IRS will not acquire or fund the parking except for when the employee is required to pay substantially higher commercial parking costs than those paid by non-disabled employees who are able to use less expensive facilities at a greater distance. Per this exception, the employee can be reimbursed for the difference between the less expensive and the more expensive parking ( [63 Comp. Gen. 270, 1984, B-211812](https://www.gao.gov/products/b-211812-0)). The business operating division funds the difference.

07. The government may also pay if the employee would be excluded from accessing the site if the government did not provide parking. This situation occurs when the location or accessibility of public transportation or commercial parking facilities place unreasonable physical demands or impose undue safety risks on employees with disabilities. When there is doubt about availability, the government must pay for the spaces so that an RA is provided.

08. When a disabled employee must use a personal vehicle in performance of his or her duties and there is no way to ensure availability of continuous accessible parking without the government procuring the space, parking may be paid by the government. For example, urban locations may have limited accessible parking spaces that might not be available to employees if the government did not procure them with the lease.

09. Drivers who regularly provide disabled employees with rides to work must be given disabled parking preference, if available.

10. Employees with temporary disabilities may be allocated temporary use of existing parking for the disabled, if available. However, use of the parking space should be limited to the projected period of the temporary disability that impairs a major life function. The FMSS TM must ensure that adequate controls are in place to monitor temporary parking. In the event of limited spaces, employees with temporary disabilities who have been allocated an available space may be requested to give up the space if needed for an RA parking request.

11. Criteria and procedure for IRS-funded parking for an RA when parking is assigned to the IRS or when the IRS acquires parking:



    1. The Reasonable Accommodation Coordinator (RAC) is responsible for approval and administration of RA employee parking requests in accordance with 41 CFR 102-71.20; 41 CFR 102-74.305; reasonable accommodation IRM sections and other applicable procedures, including applicable business operating division management approval.

    2. The RAC ensures that: 1) proper medical documentation has been reviewed and meets the requirements of federal statutes and regulations; 2) an employee has no other means of transportation for accessing the building; and 3) that parking cannot be procured by an employee on their own.



       ### Note:



       State or municipal-issued handicapped parking hang tags, vehicle tags, stickers or decals do not suffice for medical documentation for purposes of RA parking.

    3. Once an RA parking request is approved, the servicing IDO Reasonable Accommodation Coordinator (RAC) should submit an IRS Service Central Internal Revenue Workflow Optimization, Request and Knowledge System (IRWorks) request to the appropriate FMSS TM for consultation and action, as required, requesting that RA parking be secured at a given location. The FMSS TM will then contact the RAC to discuss available options at the requested location.

    4. If no parking is available at the requested location, then the IRS may procure off-site parking through an IRS purchase order, service contract or other appropriate procurement method, and then, if necessary, through an IRS delegated leasing authority.



       ### Note:



       Parking cannot be purchased using a purchase card as it is a prohibited item under Procurement’s [Restricted Purchase List](https://www.acquisition.gov/afars/chapter-14-prohibited-and-restricted-purchases).

    5. Once parking is secured to satisfy the RA request, the IRS Service Central (IRWorks) request is closed.


**1.14.9.2.5** **(12-29-2025)**

#### Use of POV for Official Business

1. Generally, the need to acquire parking for employees who use their POV for official business is determined in the same manner as the need to provide parking for other employees. For additional information, see _IRM 1.14.9.4.2 (1)_ (d).



### Note:



For additional information on reimbursement for parking fees to employees who use their POV for official business, see IRM 1.32.1 _, IRS Local Travel Guide_.


**1.14.9.2.6** **(04-25-2019)**

#### Contractor Parking

1. The Government generally does not provide free parking spaces for contractors. However, when excess free parking is available, contractors may be allowed to park free with the acknowledgment that IRS requirements have priority. There may also be instances when service contractors, performing building or machine maintenance, may be provided with temporary free parking while performing IRS contract work if parking spaces are already available. This stipulation should be included in the service contract. Decisions regarding contractor parking should be based on the most cost-effective method consistent with market conditions, security concerns for the specific site and contract provisions.


**1.14.9.2.7** **(12-29-2025)**

#### Parking Availability in Government-Owned Facilities

1. After all official parking has been assigned according to the priority established in 41 CFR 102–74.285, the federal agency building manager (usually GSA) must allocate remaining spaces among occupant agencies on an equitable basis, such as by allocating the parking in proportion to each agency's share of building space, office space or total employee population. In certain cases, federal agencies may allow a third party, such as a board composed of representatives of agencies sharing space, to determine proper parking allocations among the occupant agencies. Any remaining spaces after IRS official use needs are met in government-owned facilities will be filled by order of priority established in 41 CFR 102-74.305.

2. If the IRS has a need for additional parking for official business during an occupancy, that requirement should be met by a reduction in non-mission essential parking in accordance with the order of priority established in 41 CFR 102-74.305. If this affects bargaining unit employees, the National Treasury Employees Union (NTEU) must be notified in advance.


**1.14.9.2.8** **(12-29-2025)**

#### Parking Availability in Leased Facilities

1. The IRS is not precluded from accepting parking privileges for its employees when local ordinances require that the owner provide off-street parking for occupants of the building and the owner is prevented from charging separately for such parking privileges.

2. The IRS is not prohibited from including provisions in a GSA or IRS delegated lease requesting that the offeror identify the amount and cost of parking that can be made available to employees to acquire on their own.



### Note:



Suggested language for the GSA or IRS Request for Lease Proposal (RLP) is as follows: "A combination of public transportation, on-site parking and commercial parking facilities must be available to service employees within a 2,000 walkable linear foot radius. The adequacy of public transportation will affect the amount of parking that must be available. The amount of parking available on site must at least meet current local code requirements. Allocation of all available on-site parking must be coordinated with a designated government official to ensure that priority consideration is given to official vehicles, disabled employees, employees working shifts or other unusual hours, and vanpools/carpools. The Lessor should identify the number and amount of parking spaces available to the government or its employees as well as the cost per space and annual escalations."

3. It is preferred, but not required, that the IRS asks GSA to negotiate all charges for parking, even if the cost is an employee expense, to gain savings through economies of scale and to ensure that charges are fair and reasonable.


**1.14.9.2.9** **(12-29-2025)**

#### Parking for Criminal Investigation

1. Since government vehicles assigned to Criminal Investigation (CI) are used in the apprehension of criminals, these vehicles are assigned a higher priority for parking in 41 CFR 102–74.285 and usually represent the highest priority for IRS and GSA assigned parking space in government owned and leased buildings.

2. CI has an obligation to bring prisoners, informants, firearms, and equipment in and out of a building and away from the public as inconspicuously as possible. Where physically practicable, at least one parking space assigned to CI must be located adjacent to or near a building's freight elevator, loading dock or service entrance. When acquiring a new lease, the FMSS TM must ensure that the GSA RLP includes this provision in the special requirements. In facilities that also have reserved parking for official vehicles from other federal agencies, CI and the FMSS TM must work with GSA and the other agencies to meet this requirement.

3. Each parking space reserved for a CI government vehicle must be identified with a sign stating, "Reserved for Federal Government Vehicles."


**1.14.9.3** **(12-29-2025)**

### Collective Bargaining Agreements

1. The IRS may require and pay for employee parking only when a determination is made that parking is essential to the mission of the IRS, as stated in the criteria in _IRM 1.14.9.2.3_.

2. Collective bargaining agreements related to parking must be consistent with federal laws and regulations.

3. The fiscal year 2025 Addendum to Article 11, Section 14 of the 2022 National Agreement states, "The Employer will provide the Chapter President of each Campus, Center, and Center Campus with a reserved parking space."


**1.14.9.4** **(12-29-2025)**

### Submission of Requests to GSA to Acquire Parking

1. The requesting business operating division performs an analysis of parking requirements and forwards it to the FMSS TM for action. The FMSS TM will review the requests and forward them to GSA for the acquisition of parking. In some instances, GSA may delegate the authority back to the IRS for procurement.


**1.14.9.4.1** **(12-29-2025)**

#### Use of IRS Procurement Authority

1. If GSA has no available parking spaces or is otherwise unwilling to procure parking, especially in instances of need for one or two spaces, the IRS is permitted to use its own procurement authority to obtain parking. The cost of such procurements is paid from the requesting organization’s service and supply budget, not from rent. The IRS may not use this authority without a determination of mission need in accordance with _IRM 1.14.9.2.3_, or in the event space is needed for government vehicles, such as for CI. The procedures for requesting parking through a purchase order, service contract or similar document will be determined locally. The FMSS TM will work with the requesting business operating division to determine which organization can acquire the necessary spaces in the most expeditious manner in conjunction with IRS Procurement.



### Note:



Parking cannot be purchased using a purchase card as it is a prohibited item under Procurement’s Restricted Purchase List.


**1.14.9.4.2** **(12-29-2025)**

#### Approval Authorities

1. Whenever parking is limited and is allocated as prescribed in _IRM 1.14.9.2_ and where available parking remains, approval for the following situations must be obtained:



1. General: In all cases of employee parking, the request must be made at the head of office level.

2. Parking requests for an executive must be approved by the overseeing executive.




       i. Once an approved parking request is received by the FMSS TM, available parking will be assigned to executives at a building with multiple executives based on their level within the organization in the following order of precedence:


       \- Level 3


       \- Level 2


       \- Level 1




       ii. If there are more executives than available parking spaces, then the Executive Level will be used as the first criteria to provide a parking space from the existing allocation. Next, Office of Personnel Management SES Certification Date will be used as the second criteria to determine assignment. Lastly, tertiary criteria such as IRS enter on duty (EOD) date or others as determined by business operating division Level 3 executives can be used.




       iii. If all parking spaces are occupied and a new executive is assigned to a building with multiple executives and needs a space in accordance with 1.14.9.4.2(b)(i), then the criteria in 1.14.9.4.2(b)(ii) should be used to determine which executive parking space will be surrendered.

3. Official Parking: The requesting business operating division must prepare a certification, approved by the appropriate business operating division manager, stating that the parking space is for official government owned or leased vehicle(s) and forward to the FMSS TM. When vehicle(s) are leased through GSA, the license plate number(s) of the vehicle(s) are to be provided to the FMSS TM unless the vehicle(s) has a suppressed license plate number for security purposes. Annual recertifications are to be provided by the business operating division to the FMSS TM to ensure proper allocation of spaces in accordance with 41 CFR 102-74.285 and 41 CFR 102-74.305.

4. Employee Parking - Mission Essential and POV for Official Business: The requesting business operating division must prepare a written determination that explains why the parking is mission essential or otherwise required. This determination should also specify how many spaces are required and the basis for determining this number and be approved as described in IRM 1.14.9.4.2 (a).

5. Parking for the Disabled: The requesting business unit must prepare a justification that includes a determination of an RA (Form 13661, _IRS Reasonable Accommodation (RA) Request_), that specifies under what exceptions the parking is being requested as discussed in _IRM 1.14.9.2.4_.

6. Visitor Parking: The requesting business unit must submit written documentation to the FMSS TM, approved at their executive level, stating that adequate modes of public transportation or commercial parking facilities are not available at a site.


**1.14.9.4.3** **(04-25-2019)**

#### Funding

1. Rent for parking assigned to the IRS from GSA, either in a government owned or leased building, will be coded to the requesting organization if GSA bills it through the rent. However, if IRS acquires parking through a purchase order, service contract or similar document, the requesting organization must fund the parking from their services and supplies budget.


**1.14.9.4.4** **(04-25-2019)**

#### Release of Parking

1. If conditions change, or an election is made to save costs, the IRS may request a reduction or elimination of parking. If this affects parking for bargaining unit employees, advance notification of such changes must be made to NTEU through the servicing labor relations office.


**1.14.9.5** **(12-29-2025)**

### Taxable Parking Benefits

1. Whenever parking is provided to an employee and the value of parking exceeds the applicable annual fringe benefit threshold amount per month, the excess amount over the threshold is considered taxable income and must be included in the employee's wages reported on their Form W-2, _Wage and Tax Statement_. The applicable monthly threshold is published annually in Publication 15-B, Employer’s Tax Guide to Fringe Benefits.

2. Generally, the value of parking provided by an employer to an employee is based on the cost (including taxes or other added fees) that an individual would incur in an arm's length transaction to obtain parking at the same site. If that cost is not ascertainable, then the value of parking is based on the cost that an individual would incur in an arm's length transaction at a general location under the same or similar circumstances. An employee's subjective perception of the value of the parking is not relevant to the determination of its fair market value.

3. For this program, the value of parking provided by the IRS to an employee will be based on the GSA rent charge if the parking is located in a government owned building, or the lease cost if the parking is provided under a lease agreement. If the IRS paid parking is located on a privately owned parking lot and acquired through a service contract, the current contract rate will determine the value.


**1.14.9.5.1** **(12-29-2025)**

#### Procedures for Taxable Parking Benefits

1. For those locations where parking is valued in excess of the applicable annual threshold per month, the FMSS TM must have the recipient complete Form 9606, _Taxable Parking Benefits_.

2. The FMSS TM will mail or fax the completed Form 9606 to the Beckley Finance Center, Chief Financial Officer (CFO), by the end of the calendar year in which the taxable fringe benefit was received.


**1.14.9.6** **(04-25-2019)**

### Applicability

1. This guidance applies to all new requests for parking and to the replacement of existing leases and parking contracts as they expire. Existing contracts and leases do not have to be modified.

2. Nothing stated in this IRM will be construed as a right of reimbursement to employees for parking fees paid prior to implementation of the program.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-014-009#addtoany "Show all")

A2A