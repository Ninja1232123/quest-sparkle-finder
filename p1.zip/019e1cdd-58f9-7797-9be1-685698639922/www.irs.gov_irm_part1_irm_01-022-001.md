---
url: "https://www.irs.gov/irm/part1/irm_01-022-001"
title: "1.22.1 Mail and Transportation Management Overview | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-022-001#main-content)

- 1.22.1  [Mail and Transportation Management Overview](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645741920624)
  - 1.22.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645742810768)
    - 1.22.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645741916368)
    - 1.22.1.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645742745264)
    - 1.22.1.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645757239168)
      - 1.22.1.1.3.1  [Distribution Requirements Branch (DRB)](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645757296624)
      - 1.22.1.1.3.2  [Postal and Transport Policy (PTP) Section](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645741974512)
      - 1.22.1.1.3.3  [TS Capital Management and Oversight](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784096496)
      - 1.22.1.1.3.4  [Facilities Management and Security Services (FMSS)](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784094624)
      - 1.22.1.1.3.5  [Privacy, Governmental Liaison and Disclosure (PGLD) Office](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645741842880)
      - 1.22.1.1.3.6  [Chief Financial Officer (CFO)](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645741840816)
    - 1.22.1.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645742804688)
    - 1.22.1.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645742800144)
    - 1.22.1.1.6  [Frequently used Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784710672)
    - 1.22.1.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784271312)
  - 1.22.1.2  [General Requirements](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784264032)
    - 1.22.1.2.1  [Official Penalty Mail](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784262240)
    - 1.22.1.2.2  [Postage and Fees Reimbursement](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784260432)
    - 1.22.1.2.3  [Licenses and Permits](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784258384)
    - 1.22.1.2.4  [Official Mail Accounting System (OMAS)](https://www.irs.gov/irm/part1/irm_01-022-001#idm139645784299200)

# Part 1. Organization, Finance, and Management

# Chapter 22. Mail and Transportation Management

# Section 1. Mail and Transportation Management Overview

* * *

## 1.22.1 Mail and Transportation Management Overview

#### Manual Transmittal

September 27, 2024

#### Purpose

(1) This transmits revised IRM 1.22.1, Mail and Transportation Management, Mail and Transportation Management Overview.

#### Material Changes

(1) IRM 1.22.1 revised throughout to update organizational title Wage and Investment to Taxpayer Services.

#### Effect on Other Documents

IRM 1.22.1, General Information on Mail Management dated November 02, 2023 is superseded.

#### Audience

IRS Employees

#### Effective Date

(09-27-2024)

Maria Cheeks

Director, Distribution

Taxpayer Services

**1.22.1.1** **(11-23-2020)**

### Program Scope and Objectives

1. Purpose: This section of the IRM describes the policy requirements governing the Mail and Transportation Management Program.

2. Audience: All IRS employees responsible for making decisions in either mail or transportation management.

3. Policy Owner: The responsibility of administering the IRS Mail Transportation Program is under the direction of the Commissioner, Taxpayer Services(TS).

4. Program Owner: Distribution Requirements Branch (DRB) is the program office responsible for overseeing and providing guidance for the Mail and Transportation Management.

5. Primary Stakeholders: The Postal and Transport Policy (PTP) section located in the DRB is responsible for maintaining the Mail and Transportation Management Program. All employees who mail correspondence or ship packages, products, items or household goods are stakeholders in the Mail and Transportation Management Program.

6. Program Goals: The goals of this IRM is to identify and describe the overall roles of employees involved in the mail and transportation activities of the IRS.


**1.22.1.1.1** **(11-23-2020)**

#### Background

1. The Mail and Transportation Management Program involves the management, control and facilitation of mail usage to meet the customers’ needs while minimizing costs. Mail serves as a vital means to exchange information between employees and their customers. An efficient Mail Management Program directly affects the relationship with taxpayers and the image and reputation associated with the Service.


**1.22.1.1.2** **(11-23-2020)**

#### Authority

1. 39 CFR 310, Enforcement of the Private Express Statutes

2. 39 CFR 320, Suspension of the Private Express Statutes

3. 41 CFR 102-192, Mail Management


**1.22.1.1.3** **(11-23-2020)**

#### Roles and Responsibilities

1. The responsibility of administering the IRS Mail and Transportation Management Program falls under the direction of the Chief, Taxpayer Services (TS).

2. Media and Publications (M&P), Distribution (D), is the program owner for the Mail and Transportation Management Program and responsible for developing policies for the effective use of Servicewide postal and transportation services.

3. TS Capital Management and Oversight (CMO) manages and coordinates the postal and transportation budgets.

4. The Distribution Requirements Branch (DRB) administers the Mail Program, monitors expenditures and promotes efficient mail handling processes through planning, management, direction and implementation of the full range of activities related to Mail and Transportation Management.

5. Privacy, Governmental Liaison and Disclosure (PGLD) office facilitates the secure transfer of data between IRS and external partners.

6. The Chief Financial Officer (CFO) provides overall financial guidance for postage and transportation funding and expenditure reporting.


**1.22.1.1.3.1** **(11-23-2020)**

##### Distribution Requirements Branch (DRB)

1. The Distribution Requirements Branch responsibilities are:



1. Develop and evaluate mail policies, systems, procedures and standards to help accomplish and aid the Service’s objectives

2. Ensure Servicewide awareness and compliance with standards and operational procedures established by all Mail and Transportation service providers

3. Monitor the Servicewide mailings and other mail and transportation management activities

4. Implement cost-effective improvements and manage expedited mail and mass mailings

5. Administer the Servicewide Mail and Transportation Management Program, providing advice, guidance and standards for all IRS offices

6. Serve as the principal point of contact with the USPS, the General Services Administration (GSA) and the mailing and transportation services industry

7. Plan, develop, administer and implement major mail management projects focusing on service improvements and compliance with Federal laws, guidelines and best practices


2. These are accomplished by executing the following responsibilities:



1. Define and keep all affected personnel informed of the objectives, policies, standards and procedures for prompt, accurate and economical mail operations

2. Provide for continuous monitoring of mail operations throughout the Service to affect improvements as needed

3. Provide liaison with the USPS and adherence to its rules, regulations and practices to ensure correct, speedy and economical movement of IRS mail in the postal system

4. Provide essential information to managers concerning the volume, types of mail processed and postage costs

5. Reduce operating and postage costs whenever possible and eliminate waste


**1.22.1.1.3.2** **(11-23-2020)**

##### Postal and Transport Policy (PTP) Section

1. PTP Section responsibilities are:



1. Plan, develop, administer and evaluate policies, systems, procedures and standards for mail and transportation services

2. Perform program and budget management for the Servicewide Mail and Transportation Program, providing advice, guidance and standards for all IRS offices

3. Solicit and/or administer contracts, Tenders of Service and purchase agreement contracts from the small package, express services and freight carrier industry, obtaining discounted rates for use by all IRS offices

4. Serve as the Agency's liaison with the GSA and the mailing and transportation services industry

5. Serve as the point of contact for mail and transportation issues within the Service

6. Serve as steward of the Private Delivery Service (PDS) application process


**1.22.1.1.3.3** **(11-23-2020)**

##### TS Capital Management and Oversight

1. Reconciliation of the USPS monthly expenditure report and its transactions are a joint responsibility of the CFO, Financial Management Unit, TS Capital Management and Oversight, and the DRB. In-depth information and guidance regarding TS CMO responsibilities is provided in IRM 1.22.4, Postage Accountability and Reporting Requirements


**1.22.1.1.3.4** **(11-23-2020)**

##### Facilities Management and Security Services (FMSS)

1. Facilities Management and Security Services (FMSS) coordinates Servicewide field office mailroom operations and mail delivery services under the direction of the Chief, FMSS.

2. The FMSS National Administrative Mail Contract, Contracting Officer Representative (NAMCCOR) reports to the Facilities Support, Logistics Manager. FMSS is responsible for:



1. Communicating changes in policy to the field

2. Educating and training Territory Points of Contact (TPOCs)

3. Conducting program reviews


3. The Territory Manager of each territory will appoint a TPOC to provide mail management program guidance and direction to mail room operations within their servicing area. The TPOC serves as the primary point of contact with the NAMCCOR. The TPOC's responsibilities include but are not limited to:



1. Implement internal guidelines for administering mail

2. Direct the proper use of the classes of mail, USPS services and alternative methods of shipment

3. Ensure the cost-effective and proper use of various USPS services (e.g., Post Office Boxes, Business Reply Mail, etc.)

4. Oversee the postage expenditure reporting and direct accountability process

5. Serve as liaison and consultant for the Local Point of Contact (LPOC)

6. Address routine questions

7. Serve as a clearinghouse for changes in mail stops

8. Facilitate unidentified mail process

9. Administer and monitor contractual services related to the Mail Program


4. In locations that are not serviced by the National Mail Contractor, LPOCs are assigned by the Business Operating Divisions for the receipt, distribution and sending of local and express mail. The LPOC should be knowledgeable in basic mail handling techniques and local mail problems. The LPOC serves as the primary contact for the Facilities Mail Program TPOC. The LPOC's responsibilities include but are not limited to:



1. Maintaining knowledge of mail management policies and guidance

2. Preparing and submitting Form 10580-A, Postage Purchase/Expenditure Report

3. Working with the local Postmaster to resolve local mail problems

4. Adhering to the postal accountability and postage expenditure reporting requirements

5. Ensuring postage is added to the postage meter as needed

6. Reporting mail equipment issues and supply needs through the TPOC


**1.22.1.1.3.5** **(11-23-2020)**

##### Privacy, Governmental Liaison and Disclosure (PGLD) Office

1. A key role of this office is to facilitate the transfer of data between IRS and various state, city and federal agencies. This program responsibility includes the secure transmission of sensitive data such as tax returns and released tax information, official use of information and classified information for National Security. The security requirements are found in IRM 10.5.1, Privacy Policy, and IRM 10.9.1, National Security Information (NSI).


**1.22.1.1.3.6** **(11-23-2020)**

##### Chief Financial Officer (CFO)

1. The Travel Management Section is responsible for:



1. Counseling employees who are relocating at IRS expense

2. Coordinating household goods transportation, storage and accessorial services relating to the employee's move

3. Assuring payment of carrier invoices for those services


2. The Government Payables Section of the Government Payables and Funds Management office is responsible for payment of mail services provided by the USPS.

3. The Accounts Payable Financial Operations Section is responsible for payment of transportation invoices.


**1.22.1.1.4** **(11-23-2020)**

#### Program Management and Review

1. The Postal and Transport Policy Section administers the Mail Program, working closely with stakeholders to monitor expenditures related to Mail and Transportation Management.

2. The reconciliation of the USPS expenditure report (OMAS Report) is a joint responsibility among the CMO, Distribution Requirements Branch and TS CARE Finance; with the support of Government Payables & Funds Management (GPFM) as needed.

3. OMAS Report - Monthly report issued by the USPS that contains postage expenditures:



   - The CMO downloads the OMAS report each month, converts the data to Excel workbook and distributes to the Agency Cost Center, Points of Contact.

   - The Points of Contact review and reconcile the information, returning the workbook to CMO.

   - PTP is responsible for reconciling the M&P postage expenditures.


**1.22.1.1.5** **(11-23-2020)**

#### Program Controls

1. All IRS Offices (except the major cost centers) expending postage funds are required to report postage purchases and expenses on a transactional basis.

2. Form 10580-A, Postage Purchases/Expenditure Report must be prepared and submitted within five business days of purchase to M&P, DRB and GPFM for verification and entry into IFS.

3. PTP cross-checks the OMAS charges to the submitted Forms 10580-A. Discrepancies are addressed with the office responsible for the charge.


**1.22.1.1.6** **(11-23-2020)**

#### Frequently used Terms and Acronyms

1. The following charts contain defined terms and acronyms used throughout this IRM:



**Terms**






| **Term** | **Definition** |
| --- | --- |
| Mail | Mail consists of letters, memoranda, post cards, documents, forms, packages, publications, computer tapes and tax data (returns and remittances). |
| Official Mail | Mail sent by U.S. Government agencies that relates solely to the business of the U.S. Government, authorized by law to be transported in the mail without prepayment of postage. |
| Official Mail Accounting System (OMAS) | The postage accounting system of the USPS for federal government agencies. |
| Penalty Mail | Official Mail sent without the prepayment of postage by U.S. Government Agencies. Mail must have the endorsement words “Official Business/Penalty for Private Use $300” printed on the mail. |







**Acronyms**






| **Acronym** | **Definition** |
| --- | --- |
| CFO | Chief Financial Officer |
| CMO | Capital Management and Oversight |
| DRB | Distribution Requirements Branch |
| FMSS | Facilities Management and Security Services |
| GPFM | Government Payables and Funds Management |
| IMM | International Mail Manual |
| IRBL | Internal Revenue Bill of Lading |
| IRSTOS | Internal Revenue Service Tender of Service |
| M&P | Media and Publications |
| NAMCCOR | National Administrative Mail Contract Contracting Officer Representative |
| PDS | Private Delivery Service |
| PGLD | Privacy, Governmental Liaison and Disclosure |
| PTP | Postal and Transport Policy |
| OMAS | Official Mail Accounting System |
| TS | Taxpayer Services |
| TPOC | Territory Point of Contact |
| USPS | United States of Postal Service |


**1.22.1.1.7** **(11-23-2020)**

#### Related Resources

1. Related resources are:



   - United States Postal Service, Domestic Mail Manual (DMM)

   - United States Postal Service, Mailers Companion

   - United States Postal Service, International Mail Manual (IMM)

   - IRS Document 12534, Mail Desk Guide Territory Point-of-Contact

   - IRS Document 12019, IRS Addressing Standards

   - IRS Publication 4065, Internal Revenue Service Tender of Service (IRSTOS)

   - IRS Document 11933, Transportation Management System (TMS) User Guide


2. Mail and Transportation Management information is available on the Postal and Transportation Policy Program web site athref=http://publish.no.irs.gov/mailtran/PTPHome.html

3. IRS publications, documents and forms are available on the M&P web site at href=http://publish.no.irs.gov.

4. USPS publications and forms are available through the USPS internet web site at [href=http://www.usps.gov](https://www.irs.gov/irm/part1/irm_01-022-001).


**1.22.1.2** **(08-03-2018)**

### General Requirements

1. The Private Express Statutes of 39 CFR 310 and 320 as amended by rules in the Federal Register are a group of laws providing the USPS the exclusive right to carry letters for compensation, with certain limited exceptions.


**1.22.1.2.1** **(08-03-2018)**

#### Official Penalty Mail

1. Official Penalty Mail is official mail sent by the U.S. Government agencies relating solely to the business of the U.S. Government, authorized by law to be transmitted in the mail without prepayment of postage.


**1.22.1.2.2** **(08-03-2018)**

#### Postage and Fees Reimbursement

1. The IRS must reimburse the USPS the amount of postage and fees due for penalty mail services received. The USPS requires the agencies to use penalty postage meters (postage evidencing systems) or other forms of direct accountability for penalty mail services to ensure proper reimbursement through the Official Mail Accounting System (OMAS). Detailed guidance is provided in IRM 1.22.4, Postage Accountability and Reporting Requirements.


**1.22.1.2.3** **(08-03-2018)**

#### Licenses and Permits

1. Agencies authorized to use penalty mail must obtain licenses or permits at specific Post Offices to use penalty postage meters, penalty permit imprints and penalty business reply mail. The IRS has been granted a penalty permit by the USPS and has been assigned the Federal Agency Control Code 218, Penalty Permit Imprint No. G-48 and Penalty Reply Mail Permit No. 12686. Each IRS Field Office is also assigned a Federal Agency Sub-Office cost code. The code is available in the current Financial Management Codes Handbook at Chief Financial Officer - Home (sharepoint.com)..

2. The private use of penalty envelopes, cards, cartons, labels, meter stamps, or penalty mail stamps is prohibited and may not be provided to any private person or organization, unless the use is directly related to the business of the U.S. Government and permitted by USPS standards.


**1.22.1.2.4** **(08-03-2018)**

#### Official Mail Accounting System (OMAS)

1. The IRS uses a centralized postage payment process for Official Penalty Mail expenditures utilizing the USPS automated system OMAS. The system is used to access, collect and account for data entered from Federal agencies' postage statements. The USPS bills the agencies according to data generated from OMAS. Agencies use data from OMAS to monitor postage costs.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-022-001#addtoany "Show all")

A2A