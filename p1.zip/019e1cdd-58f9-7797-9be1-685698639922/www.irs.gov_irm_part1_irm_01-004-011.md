---
url: "https://www.irs.gov/irm/part1/irm_01-004-011"
title: "1.4.11 Field Assistance Guide for Managers | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-004-011#main-content)

- 1.4.11  [Field Assistance Guide for Managers](https://www.irs.gov/irm/part1/irm_01-004-011#id1)
  - 1.4.11.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-004-011#id2)
    - 1.4.11.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-004-011#id4)
    - 1.4.11.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-004-011#id5)
    - 1.4.11.1.3  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id6)
    - 1.4.11.1.4  [Program Management and Review](https://www.irs.gov/irm/part1/irm_01-004-011#id7)
    - 1.4.11.1.5  [Program Controls](https://www.irs.gov/irm/part1/irm_01-004-011#id8)
    - 1.4.11.1.6  [Terms and Acronyms](https://www.irs.gov/irm/part1/irm_01-004-011#id9)
    - 1.4.11.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-004-011#id10)
  - 1.4.11.2  [Taxpayer Assistance Center (TAC) Appointment Service](https://www.irs.gov/irm/part1/irm_01-004-011#id11)
    - 1.4.11.2.1  [Unplanned Taxpayer Assistance Center (TAC) Closures](https://www.irs.gov/irm/part1/irm_01-004-011#id13)
  - 1.4.11.3  [Structuring Workflow in Taxpayer Assistance Centers (TACs)](https://www.irs.gov/irm/part1/irm_01-004-011#id14)
    - 1.4.11.3.1  [Advising Taxpayers of Wait Time](https://www.irs.gov/irm/part1/irm_01-004-011#id15)
    - 1.4.11.3.2  [Preparation for Filing Season](https://www.irs.gov/irm/part1/irm_01-004-011#id16)
    - 1.4.11.3.3  [Virtual Service Delivery (VSD)](https://www.irs.gov/irm/part1/irm_01-004-011#id17)
    - 1.4.11.3.4  [Over the Phone Interpreter (OPI) Service](https://www.irs.gov/irm/part1/irm_01-004-011#id18)
    - 1.4.11.3.5  [Alternative Work Stream](https://www.irs.gov/irm/part1/irm_01-004-011#id19)
    - 1.4.11.3.6  [Referrals](https://www.irs.gov/irm/part1/irm_01-004-011#id20)
      - 1.4.11.3.6.1  [Referral Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id22)
  - 1.4.11.4  [Taxpayer Assistance Center (TAC) Security Controls and Signs](https://www.irs.gov/irm/part1/irm_01-004-011#id23)
    - 1.4.11.4.1  [Taxpayer Assistance Center (TAC) Physical Security Requirements](https://www.irs.gov/irm/part1/irm_01-004-011#id24)
      - 1.4.11.4.1.1  [Controlled Area](https://www.irs.gov/irm/part1/irm_01-004-011#id25)
      - 1.4.11.4.1.2  [Field Assistance Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id26)
        - 1.4.11.4.1.2.1  [Employee Name Tags](https://www.irs.gov/irm/part1/irm_01-004-011#id28)
        - 1.4.11.4.1.2.2  [Obtaining Customer Satisfaction Survey (CSS) Cards](https://www.irs.gov/irm/part1/irm_01-004-011#id29)
        - 1.4.11.4.1.2.3  [Reporting a Missing Child from or Within IRS Facilities](https://www.irs.gov/irm/part1/irm_01-004-011#id30)
      - 1.4.11.4.1.3  [Controlled Access Procedures](https://www.irs.gov/irm/part1/irm_01-004-011#id31)
      - 1.4.11.4.1.4  [Cameras/Photography Prohibited](https://www.irs.gov/irm/part1/irm_01-004-011#id32)
    - 1.4.11.4.2  [Taxpayer Assistance Center (TAC) Security/Internal Controls](https://www.irs.gov/irm/part1/irm_01-004-011#id33)
      - 1.4.11.4.2.1  [Completing Form 700](https://www.irs.gov/irm/part1/irm_01-004-011#id35)
    - 1.4.11.4.3  [Use of Signs/Posters in Taxpayer Assistance Centers (TACs)](https://www.irs.gov/irm/part1/irm_01-004-011#id36)
    - 1.4.11.4.4  [Televisions (TVs) in Taxpayer Assistance Centers (TACs)](https://www.irs.gov/irm/part1/irm_01-004-011#id37)
      - 1.4.11.4.4.1  [Roles and Responsibilities for Televisions (TVs) in the Taxpayer Assistance Center (TAC)](https://www.irs.gov/irm/part1/irm_01-004-011#id38)
      - 1.4.11.4.4.2  [Removable Media and Digital Versatile Disc (DVD) Players](https://www.irs.gov/irm/part1/irm_01-004-011#id39)
        - 1.4.11.4.4.2.1  [Roles and Responsibilities for Removable Media](https://www.irs.gov/irm/part1/irm_01-004-011#id41)
    - 1.4.11.4.5  [Taxpayer Assistance Center Safes](https://www.irs.gov/irm/part1/irm_01-004-011#id42)
    - 1.4.11.4.6  [Contact with the Media](https://www.irs.gov/irm/part1/irm_01-004-011#id43)
  - 1.4.11.5  [Workers’ Compensation/Safety and Health Information System (SHIMS)](https://www.irs.gov/irm/part1/irm_01-004-011#id44)
  - 1.4.11.6  [Disclosure/Protection of Taxpayer Information](https://www.irs.gov/irm/part1/irm_01-004-011#id45)
  - 1.4.11.7  [Payment Processing - Manager’s Responsibility](https://www.irs.gov/irm/part1/irm_01-004-011#id46)
    - 1.4.11.7.1  [Management Responsibility for Form 795-A and Form 3210 Files](https://www.irs.gov/irm/part1/irm_01-004-011#id47)
      - 1.4.11.7.1.1  [Supplemental Form 795-A](https://www.irs.gov/irm/part1/irm_01-004-011#id49)
      - 1.4.11.7.1.2  [Managerial Review for Acknowledgment Transmittals Procedures](https://www.irs.gov/irm/part1/irm_01-004-011#id50)
    - 1.4.11.7.2  [Remittance Quarterly Reviews – Manager’s Requirements](https://www.irs.gov/irm/part1/irm_01-004-011#id51)
    - 1.4.11.7.3  [Remittance Strategy for Paper Check Conversion (RSPCC) Management Responsibility](https://www.irs.gov/irm/part1/irm_01-004-011#id52)
    - 1.4.11.7.4  [Form 5919 – Teller’s Error Advice](https://www.irs.gov/irm/part1/irm_01-004-011#id53)
    - 1.4.11.7.5  [Trends and Patterns Report for Territory Manager and Group Manager Responsibility](https://www.irs.gov/irm/part1/irm_01-004-011#id54)
    - 1.4.11.7.6  [Late Remittance Reports](https://www.irs.gov/irm/part1/irm_01-004-011#id55)
    - 1.4.11.7.7  [Loss of Payments](https://www.irs.gov/irm/part1/irm_01-004-011#id56)
    - 1.4.11.7.8  [Cash Payments Accountability](https://www.irs.gov/irm/part1/irm_01-004-011#id57)
      - 1.4.11.7.8.1  [Procedures for Ordering the Initial Form 809 Receipt-Book for an Employee](https://www.irs.gov/irm/part1/irm_01-004-011#id58)
      - 1.4.11.7.8.2  [Annual Reconciliation of Official Form 809 Receipts](https://www.irs.gov/irm/part1/irm_01-004-011#id59)
      - 1.4.11.7.8.3  [Separation of Duties and Form 809](https://www.irs.gov/irm/part1/irm_01-004-011#id60)
      - 1.4.11.7.8.4  [Reordering Form 809](https://www.irs.gov/irm/part1/irm_01-004-011#id61)
      - 1.4.11.7.8.5  [Returning Depleted or Partially Used Form 809 Receipt-Book](https://www.irs.gov/irm/part1/irm_01-004-011#id62)
      - 1.4.11.7.8.6  [Single Large Cash Payments](https://www.irs.gov/irm/part1/irm_01-004-011#id63)
        - 1.4.11.7.8.6.1  [Appointments for Single Large Cash Payments](https://www.irs.gov/irm/part1/irm_01-004-011#id65)
        - 1.4.11.7.8.6.2  [Large Cash Payment Appointment Exceptions](https://www.irs.gov/irm/part1/irm_01-004-011#id66)
        - 1.4.11.7.8.6.3  [Taxpayer Assistance Center Cash Counting Room](https://www.irs.gov/irm/part1/irm_01-004-011#id67)
        - 1.4.11.7.8.6.4  [Courier Service Same Day Pick Up](https://www.irs.gov/irm/part1/irm_01-004-011#id68)
        - 1.4.11.7.8.6.5  [Accepting Small Business/Self-Employed (SB/SE) Payments](https://www.irs.gov/irm/part1/irm_01-004-011#id69)
    - 1.4.11.7.9  [Disposal of Remittance and Non-Remittance Form 795-A and Form 3210 Retention Files](https://www.irs.gov/irm/part1/irm_01-004-011#id70)
      - 1.4.11.7.9.1  [Deviation for Quarterly Disposal of Remittance and Non-Remittance Form 795-A and Form 3210](https://www.irs.gov/irm/part1/irm_01-004-011#id72)
  - 1.4.11.8  [Account Management Services (AMS) - Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id73)
    - 1.4.11.8.1  [Account Management Services (AMS) Group Messages](https://www.irs.gov/irm/part1/irm_01-004-011#id75)
    - 1.4.11.8.2  [Territory Manager Responsibilities for Account Management Services (AMS)](https://www.irs.gov/irm/part1/irm_01-004-011#id76)
    - 1.4.11.8.3  [Area Director Responsibilities for Account Management Services (AMS)](https://www.irs.gov/irm/part1/irm_01-004-011#id77)
    - 1.4.11.8.4  [Account Management Services (AMS) System Security Officers (SSOs)](https://www.irs.gov/irm/part1/irm_01-004-011#id78)
  - 1.4.11.9  [Integrated Automation Technologies (IAT) - Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id79)
    - 1.4.11.9.1  [Manual Refunds Using Integrated Automation Technologies (IAT)](https://www.irs.gov/irm/part1/irm_01-004-011#id81)
  - 1.4.11.10  [Individual Taxpayer Identification Number (ITIN) Authentication](https://www.irs.gov/irm/part1/irm_01-004-011#id82)
  - 1.4.11.11  [Managing Outlying Taxpayer Assistance Centers (TACs)](https://www.irs.gov/irm/part1/irm_01-004-011#id83)
    - 1.4.11.11.1  [Commissioner's Representatives (CR) in Outlying Taxpayer Assistance Centers (TACs)](https://www.irs.gov/irm/part1/irm_01-004-011#id85)
    - 1.4.11.11.2  [Schedule Routine Visitations](https://www.irs.gov/irm/part1/irm_01-004-011#id86)
  - 1.4.11.12  [Hours of Operations and Taxpayer Assistance Center (TAC) Closing Procedures](https://www.irs.gov/irm/part1/irm_01-004-011#id87)
    - 1.4.11.12.1  [Changes in Hours of Operations](https://www.irs.gov/irm/part1/irm_01-004-011#id88)
    - 1.4.11.12.2  [Closing a Taxpayer Assistance Center (TAC)](https://www.irs.gov/irm/part1/irm_01-004-011#id89)
      - 1.4.11.12.2.1  [Actions Taken When Relocating or Releasing a Taxpayer Assistance Center (TAC)](https://www.irs.gov/irm/part1/irm_01-004-011#id91)
  - 1.4.11.13  [Publishing Taxpayer Assistance Center Information](https://www.irs.gov/irm/part1/irm_01-004-011#id92)
    - 1.4.11.13.1  [Posting Taxpayer Assistance Center (TAC) Hours of Operation](https://www.irs.gov/irm/part1/irm_01-004-011#id94)
    - 1.4.11.13.2  [Posting Taxpayer Assistance Center (TAC) Closings](https://www.irs.gov/irm/part1/irm_01-004-011#id95)
    - 1.4.11.13.3  [Section 3709-Line Recorded Messages](https://www.irs.gov/irm/part1/irm_01-004-011#id96)
  - 1.4.11.14  [Field Assistance Insider Guidelines](https://www.irs.gov/irm/part1/irm_01-004-011#id97)
  - 1.4.11.15  [Work Planning and Scheduling](https://www.irs.gov/irm/part1/irm_01-004-011#id98)
    - 1.4.11.15.1  [Scheduling for Staffing Needs](https://www.irs.gov/irm/part1/irm_01-004-011#id100)
    - 1.4.11.15.2  [Scheduling Considerations](https://www.irs.gov/irm/part1/irm_01-004-011#id101)
  - 1.4.11.16  [Capturing Field Assistance Contacts](https://www.irs.gov/irm/part1/irm_01-004-011#id102)
    - 1.4.11.16.1  [Form 13864 - Field Assistance Contact Sheet](https://www.irs.gov/irm/part1/irm_01-004-011#id104)
    - 1.4.11.16.2  [Management Review and Disposition of Form 13864 and Form 6148](https://www.irs.gov/irm/part1/irm_01-004-011#id105)
  - 1.4.11.17  [Qmatic](https://www.irs.gov/irm/part1/irm_01-004-011#id106)
    - 1.4.11.17.1  [Wait Time](https://www.irs.gov/irm/part1/irm_01-004-011#id108)
    - 1.4.11.17.2  [Qmatic Ticket Process](https://www.irs.gov/irm/part1/irm_01-004-011#id109)
    - 1.4.11.17.3  [Adding Employees on Staff Registration](https://www.irs.gov/irm/part1/irm_01-004-011#id110)
    - 1.4.11.17.4  [Partner Virtual Service Delivery (VSD) Site Qmatic](https://www.irs.gov/irm/part1/irm_01-004-011#id111)
  - 1.4.11.18  [Field Assistance Contact Recording (FACR)](https://www.irs.gov/irm/part1/irm_01-004-011#id112)
    - 1.4.11.18.1  [Field Assistance Contact Recording (FACR) Controls](https://www.irs.gov/irm/part1/irm_01-004-011#id113)
    - 1.4.11.18.2  [Field Assistance Contact Recording (FACR) Area Analyst Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id114)
    - 1.4.11.18.3  [Field Assistance Contact Recording (FACR) Headquarters Analyst Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id115)
      - 1.4.11.18.3.1  [Requests for Copies of Downloaded Contacts](https://www.irs.gov/irm/part1/irm_01-004-011#id117)
      - 1.4.11.18.3.2  [Treasury Inspector General for Tax Administration (TIGTA) Requests](https://www.irs.gov/irm/part1/irm_01-004-011#id118)
      - 1.4.11.18.3.3  [Freedom of Information Act (FOIA) Request](https://www.irs.gov/irm/part1/irm_01-004-011#id119)
      - 1.4.11.18.3.4  [Managerial Requests](https://www.irs.gov/irm/part1/irm_01-004-011#id120)
      - 1.4.11.18.3.5  [Download Approval](https://www.irs.gov/irm/part1/irm_01-004-011#id121)
      - 1.4.11.18.3.6  [Downloading Contacts](https://www.irs.gov/irm/part1/irm_01-004-011#id122)
      - 1.4.11.18.3.7  [Record Keeping and Storage of Download Contacts](https://www.irs.gov/irm/part1/irm_01-004-011#id123)
  - 1.4.11.19  [Field Assistance Quality Review](https://www.irs.gov/irm/part1/irm_01-004-011#id124)
    - 1.4.11.19.1  [Field Assistance Review Methods](https://www.irs.gov/irm/part1/irm_01-004-011#id126)
    - 1.4.11.19.2  [Field Assistance Group Manager Responsibilities and Reviews](https://www.irs.gov/irm/part1/irm_01-004-011#id127)
    - 1.4.11.19.3  [Review Plan and Scheduling Process Overview](https://www.irs.gov/irm/part1/irm_01-004-011#id128)
    - 1.4.11.19.4  [Review Documentation](https://www.irs.gov/irm/part1/irm_01-004-011#id129)
    - 1.4.11.19.5  [Providing Effective Feedback](https://www.irs.gov/irm/part1/irm_01-004-011#id130)
    - 1.4.11.19.6  [Employee Performance Appraisals, Annual, Midyear Progress Review and Departure](https://www.irs.gov/irm/part1/irm_01-004-011#id131)
    - 1.4.11.19.7  [Operational Reviews](https://www.irs.gov/irm/part1/irm_01-004-011#id132)
    - 1.4.11.19.8  [Review Process and Types of Review](https://www.irs.gov/irm/part1/irm_01-004-011#id133)
    - 1.4.11.19.9  [Group Manager Mandatory Reviews, Reports, and Certification](https://www.irs.gov/irm/part1/irm_01-004-011#id134)
    - 1.4.11.19.10  [Territory Manager Mandatory Reviews, Reports and Certification](https://www.irs.gov/irm/part1/irm_01-004-011#id135)
  - 1.4.11.20  [Embedded Quality Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id136)
    - 1.4.11.20.1  [Employee Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id138)
    - 1.4.11.20.2  [Group Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id139)
    - 1.4.11.20.3  [Territory Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id140)
    - 1.4.11.20.4  [Area Director and Area Quality Analyst Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id141)
    - 1.4.11.20.5  [Headquarters Quality Analyst Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id142)
  - 1.4.11.21  [Field Assistance Engagement Plan](https://www.irs.gov/irm/part1/irm_01-004-011#id143)
    - 1.4.11.21.1  [Awards and Recognition](https://www.irs.gov/irm/part1/irm_01-004-011#id145)
  - 1.4.11.22  [Section 1204 Certification Process](https://www.irs.gov/irm/part1/irm_01-004-011#id146)
  - 1.4.11.23  [Field Assistance Corporate Training](https://www.irs.gov/irm/part1/irm_01-004-011#id147)
    - 1.4.11.23.1  [Training Initial Actions](https://www.irs.gov/irm/part1/irm_01-004-011#id148)
    - 1.4.11.23.2  [Training Approved: ATA Host Actions](https://www.irs.gov/irm/part1/irm_01-004-011#id149)
    - 1.4.11.23.3  [Training Approved: FAHQ Training Analyst Actions](https://www.irs.gov/irm/part1/irm_01-004-011#id150)
    - 1.4.11.23.4  [Beginning of Face-to-Face Class Delivery](https://www.irs.gov/irm/part1/irm_01-004-011#id151)
    - 1.4.11.23.5  [Completed Face-to-Face Class](https://www.irs.gov/irm/part1/irm_01-004-011#id152)
    - 1.4.11.23.6  [Virtual Classroom Training](https://www.irs.gov/irm/part1/irm_01-004-011#id153)
    - 1.4.11.23.7  [Virtual Classroom Training Delivery](https://www.irs.gov/irm/part1/irm_01-004-011#id154)
    - 1.4.11.23.8  [Field Assistance Taxpayer Assistance Center (TAC) Employee Training](https://www.irs.gov/irm/part1/irm_01-004-011#id155)
      - 1.4.11.23.8.1  [On-the-Job Training (OJT)](https://www.irs.gov/irm/part1/irm_01-004-011#id156)
        - 1.4.11.23.8.1.1  [Territory Lead Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id158)
        - 1.4.11.23.8.1.2  [Group Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id159)
        - 1.4.11.23.8.1.3  [Area Training Analyst Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id160)
        - 1.4.11.23.8.1.4  [Territory Manager Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id161)
        - 1.4.11.23.8.1.5  [Area Director Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id162)
      - 1.4.11.23.8.2  [Directed Learning](https://www.irs.gov/irm/part1/irm_01-004-011#id163)
    - 1.4.11.23.9  [Training for Field Assistance Managers](https://www.irs.gov/irm/part1/irm_01-004-011#id164)
    - 1.4.11.23.10  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id165)
      - 1.4.11.23.10.1  [Project Leaders](https://www.irs.gov/irm/part1/irm_01-004-011#id167)
      - 1.4.11.23.10.2  [Field Assistance Headquarters Training Analyst](https://www.irs.gov/irm/part1/irm_01-004-011#id168)
      - 1.4.11.23.10.3  [Area Training and Budget Analysts](https://www.irs.gov/irm/part1/irm_01-004-011#id169)
      - 1.4.11.23.10.4  [Group Manager Roles](https://www.irs.gov/irm/part1/irm_01-004-011#id170)
      - 1.4.11.23.10.5  [Instructor Responsibilities](https://www.irs.gov/irm/part1/irm_01-004-011#id171)
  - Exhibit  1.4.11-1  [Field Assistance Section 3709-Line Telephone Scripts](https://www.irs.gov/irm/part1/irm_01-004-011#id172)

# Part 1. Organization, Finance, and Management

# Chapter 4. Resource Guide for Managers

# Section 11. Field Assistance Guide for Managers

* * *

## 1.4.11 Field Assistance Guide for Managers

#### Manual Transmittal

August 13, 2025

#### Purpose

(1) This transmits revised IRM 1.4.11, Resource Guide for Managers, Field Assistance Guide for Managers.

#### Material Changes

(1) IRM 1.4.11.2, Taxpayer Assistance Center (TAC) Appointment Service - Removed (3)(i).

(2) IRM 1.4.11.2.2, Qmatic Ticket Process - Removed (1)(c).

(3) IRM 1,4.11.3.3, Facilitated Self Assistance (FSA) - Removed Subsection.

(4) IRM 1.4.11.4.1(2), Taxpayer Assistance Center (TAC) Physical Security Requirements - Revised to replace Form 12149, Functional Security Review for Managers (obsolete) with new Form 15608, Field Assistance Physical Security Form. Also removed (9) in the subsection as it was a duplicate of what was already stated in (2). - IPU 24U1074 dated 10/25/2024.

(5) IRM 1.4.11.4.1.2.1, Employee Name Tags - Removed gender neutral courtesy title Mx to comply with January 2025 Executive Orders and OPM Guidance.

(6) IRM 1.4.11.4.1.3(1)(c), Controlled Access Procedures - Revised to replace Form 12149, Functional Security Review for Managers (obsolete) with new Form 15608, Field Assistance Physical Security Form. - IPU 24U1074 dated 10/25/2024.

(7) IRM 1.4.11.4.2(10), Taxpayer Assistance Center (TAC) Security/Internal Controls - Revised to replace Form 12149, Functional Security Review for Managers (obsolete) with new Form 15608, Field Assistance Physical Security Form. - IPU 24U1074 dated 10/25/2024.

(8) IRM 1.4.11.10, Individual Taxpayer Identification Number (ITIN) Authentication - Added the word “Number” to the subsection title.

(9) IRM 1.4.11.19(4), Field Assistance Quality Review - Updated last sentence to include procedural reviews, in addition to tax law and account reviews are not captured separately. - IPU 24U1074 dated 10/25/2024.

(10) IRM 1.4.11.19.9(1), Group Manager Mandatory Reviews, Reports, and Certification - Revised Physical Security section to replace Form 12149, Functional Security Review for Managers (obsolete) with new Form 15608, Field Assistance Physical Security Form. - IPU 24U1074 dated 10/25/2024.

(11) Editorial changes have been made throughout this IRM for clarity. Reviewed and updated plain language, grammar, web addresses, IRM references, and legal references.

- IRM 1.4.11 - Revised throughout to update organization title Wage and Investment to Taxpayer Services.

- IRM 1.4.11 - Revised to remove the dash from RS-PCC to RSPCC.


#### Effect on Other Documents

IRM 1.4.11 dated February 20, 2024 (effective February 20, 2024) is superseded. Interim Procedural Update (IPU) 24U1074 issued October 25, 2024 is incorporated into this IRM.

#### Audience

All Management Officials in Taxpayer Services (TS) Taxpayer Assistance Centers (TACs).

#### Effective Date

(10-01-2025)

Teresa V Givens

Director, Field Assistance

Taxpayer Services

**1.4.11.1** **(01-02-2020)**

### Program Scope and Objectives

1. **Purpose**: The purpose of this section of the IRM is to provide Field Assistance (FA) managers with various techniques and guidelines for managing a successful and effective Taxpayer Assistance Center (TAC).

2. **Audience**: This section contains guidance for all FA managers in TACs located in the United States and Puerto Rico.

3. **Policy Owner**: Director, Field Assistance under Customer, Assistance, Relationships and Education (CARE).

4. **Program Owner**: Field Assistance Headquarters (HQ).

5. **Primary Stakeholders**. Customer Assistance, Relationships, and Education (CARE), Customer Account Services (CAS), and Compliance Services.

6. **Program Goals and Objectives**: The mission of Field Assistance is to provide quality service to taxpayers requiring face-to-face assistance and to educate taxpayers on services available to them through all channels, including self-assisted services. The scope of service delivery must be clearly defined to enable FA to meet the following objectives critical to its success:



1. Clearly define services offered to taxpayers and methods of delivery.

2. Target and deliver employee training for the defined scope of services.

3. Provide a process, in partnership with other operating divisions, to correctly refer taxpayers for needs falling outside the services offered.

4. Ensure employees (permanently assigned and detailees) and managers provide highly accurate, courteous, and professional service to all taxpayers.

5. Provide specific, meaningful measures to make FA accountable for the quality of its products and services.

6. Employ effective, targeted marketing and communication of the precise scope of assistance available.


**1.4.11.1.1** **(01-02-2020)**

#### Background

1. Field Assistance managers oversee employees in TACs who provide face-to-face assistance to taxpayers whose issues cannot be resolved through other convenient and efficient methods or who choose to obtain information and assistance in the TAC.


**1.4.11.1.2** **(12-22-2021)**

#### Authority

1. The Taxpayer Bill of Rights (TBOR) lists rights that already existed in the tax code, putting them in simple language and grouping them into 10 fundamental rights. Employees are responsible for being familiar with and acting in accord with taxpayer rights. See IRC 7803(a)(3), Execution of Duties in Accord with Taxpayer Rights. For additional information about the TBOR, see [https://www.irs.gov/taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights).

2. Under these rights taxpayers have the right to receive prompt, courteous, and professional assistance in their dealings with the IRS, to be spoken to in a way they can easily understand, to receive clear and easily understandable communications from the IRS, and to speak to a supervisor about inadequate service.

3. The authorities for this IRM include:



   - Pub 5170, Taxpayer Bill of Rights (Brochure)

   - IRM 1.2.1.2.1, Policy Statement 1-1, For Mission of the Service

   - IRC 6103, Confidentiality and disclosure of returns and return information

   - IRC 6301, Collection authority

   - IRC 6402, Authority to make credits or refunds

   - IRC 6404, Abatements

   - IRC 7801, Authority of Department of the Treasury


**1.4.11.1.3** **(01-04-2021)**

#### Roles and Responsibilities

1. The Director, Field Assistance is the executive responsible for program oversight of the policies in this IRM and approves and authorizes the issuance of this Internal Management Document.

2. The area directors (ADs) oversee field activities within a specified geographic area to ensure consistency and quality of program execution.

3. The territory managers (TMs) oversee activities of groups in a specified geographic territory to ensure consistency of training, program execution, services and facilities.

4. The TAC group managers (GMs) support the duties performed in the TAC, manage the TAC operations, and oversee the TAC services provided to taxpayers.

5. TAC GMs must be fully knowledgeable and engaged in the operation of a TAC to serve a key role in the accomplishment of established goals and measures.

6. See IRM 1.1.13.6.3, Field Assistance, for responsibilities of the FA organization:



   - Director

   - Area directors

   - Territory managers

   - Headquarters staff


**1.4.11.1.4** **(01-04-2021)**

#### Program Management and Review

1. **Program Reports**: The Policy, Technology, and Measures (PT&M) section provides measures ensuring business objectives and goals are met. Due to the many and varied services offered at geographically dispersed, stand-alone offices, FA GMs have a wide array of responsibilities accompanied by the many and varied reviews that go with them. FA TMs share in this diversity of responsibilities and reviews including those to ensure the GM’s reviews are substantive, accurate, and completed in a timely manner.

2. To provide quality service to taxpayers, managers observe employees on an ongoing basis and provide timely feedback to enhance their skills. National quality reviews are performed and the results are reported to external stakeholders and the public. FA quality is a measure of the accuracy of customer contacts that are captured and reviewed via contact recording. The system used to document employee and organizational performance data is the Embedded Quality Review System (EQRS).

3. **Program Effectiveness**: The effectiveness of a TAC operation is attributable to the level of the GM's commitment to achieve the objectives of FA through, in part, conducting internal control reviews. The effectiveness of the GM is the responsibility of the TM and reflects the level of their commitment to provide support, feedback, and oversight to the GM completing their required internal control reviews. See _IRM 1.4.11.19_, Field Assistance Quality Review, for information on the quality review process and how the results are effectively used.

4. In addition to quality, FA has in place a number of internal control systems (procedures/processes), that are designed to reduce risks involved in the work we perform. These internal controls are established, for example, to help ensure the safety of employees and taxpayers in the TACs. Another example is found in the procedures FA employees must follow to protect taxpayer information and privacy. Management at all levels is responsible for ensuring internal controls are:



1. In place to reduce risk.

2. Understood and consistently followed by employees.

3. Functioning as intended.

4. Reviewed ongoing and revised as needed to effectively and efficiently reduce risk.


5. Most FA internal control reviews fall into one of the following categories or review types:



   - Employee performance

   - Operational

   - Remittance

   - Physical Security and Safety

   - Certifications


**1.4.11.1.5** **(01-04-2021)**

#### Program Controls

1. Within the Taxpayer Services division, program oversight of the internal controls program is managed under the leadership of the Director, Operations Support, TS and within the Capital Management and Oversight Office.

2. Management controls include operational and quality assurance reviews. IRM 21.10.1, Embedded Quality (EQ) Program for Accounts Management, Campus Compliance, Field Assistance, Tax Exempt/Government Entities, Return Integrity and Compliance Services (RICS), and Electronic Products and Services Support, contains procedures for evaluating TAC contacts.

3. Program controls, policies, and procedures ensure:



1. Mission and program objectives are efficiently and effectively accomplished.

2. Program and resources are protected from waste, fraud, abuse, mismanagement, and misappropriation of funds.

3. Laws and regulations are followed.

4. Financial reporting is reliable.

5. Reliable information is obtained and used for decision making.


4. Program control systems provide reasonable assurance that the following objectives are being achieved:



1. Effectiveness and efficiency of operations.

2. Reliability of financial reporting.

3. Compliance with applicable laws and regulations.


**1.4.11.1.6** **(10-01-2025)**

#### Terms and Acronyms

1. The following table lists common acronyms used throughout this IRM section.




| Common acronyms | Definition |
| --- | --- |
| AD | Area Director |
| AMS | Account Management Services |
| BEARS | Business Entitlement Access Request System |
| CII | Correspondence Imaging Inventory |
| CLS | Classroom Learning Service |
| CPR | Content Publishing Request |
| CSR | Customer Service Representative |
| CQRS | Centralized Quality Review System |
| DCI | Data Collection Instrument |
| DFA | Director, Field Assistance |
| EIN | Employer Identification Number |
| EQRS | Embedded Quality Review System |
| ETPD | Enterprise Talent Planning & Development |
| FA | Field Assistance |
| FACR | Field Assistance Contact Recording |
| FAHQ | Field Assistance Headquarters |
| FAMIS | Field Assistance Management Information System |
| FAST | Field Assistance Scheduling Tool |
|  |  |
| GM | Group Manager |
| HQ | Headquarters |
| IAR | Initial Assistance Representative |
| IAT | Integrated Automation Technologies |
| ITAS | Individual Taxpayer Advisory Specialist |
| ITIN | Individual Taxpayer Identification Number |
| ITLA | Interactive Tax Law Assistant |
| ITM | Integrated Talent Management |
| JOC | Joint Operations Center |
| ODN | Office Designation Number |
| OJI | On-The-Job Instructor |
| OJT | On-The-Job Training |
| RSPCC | Remittance Strategy for Paper Check Conversion |
| RTS | Real Time System |
| SME | Subject Matter Expert |
| SOM | Senior Operations Manager |
| SPC | Submission Processing Center |
| TAC | Taxpayer Assistance Center |
| TBOR | Taxpayer Bill of Rights |
| TM | Territory Manager |
| VSD | Virtual Service Delivery |


**1.4.11.1.7** **(01-02-2020)**

#### Related Resources

1. This section is a supplement to the general guidelines for all managers contained in IRM 1.4, Resource Guide for Managers.

2. The following lists additional sources of guidance for activities related to the managing of a TAC:



   - iManage website

   - Taxpayer Services Insider - Field Assistance

   - SERP

   - [IRS.gov - Contact Your Local IRS Office](https://www.irs.gov/help/contact-your-local-irs-office)

   - IRM 1.15.3, Disposing of Records, provides guidance on disposing of records once their life cycle is complete.

   - Document 12829, General Records Schedules, provides information on the National Archives and Records Administration (NARA) issued disposal authorizations for temporary administrative records.

   - Document 12990, Records and Information Management Records Control Schedules, provides the NARA approved records retention and disposition procedures to prevent unauthorized/unlawful destruction of records.


3. IRM 21.3.4, Field Assistance, provides procedural guidance for TACs on:



   - Providing appointment service

   - Researching and resolving account inquiries

   - Accepting payments and establishing payment arrangements

   - Providing tax law assistance

   - Explaining and assisting with procedural inquiries

   - Authenticating identity

   - Providing assistance and verification of documentation for taxpayer identification numbers (TINs)

   - Assisting with applications for taxpayer assistance orders (TAO)

   - Providing multilingual assistance

   - Assisting with alien clearances (Sailing Permits)

   - Providing tax forms, instructions, and publications

   - Assisting with Form 2290, Heavy Highway Vehicle Use Tax Return


**1.4.11.2** **(02-20-2024)**

### Taxpayer Assistance Center (TAC) Appointment Service

1. Taxpayers call the toll-free line, **1-844-545-5640**, to schedule an appointment to receive services. Directions for making an appointment are posted on [IRS.gov](https://www.irs.gov/) and can be heard on the Section 3709-Line message.

2. Refer to IRM 21.3.4.2.4, Taxpayer Assistance Center (TAC) Appointment Service, and Field Assistance Scheduling Tool (FAST) User Guides, for current TAC appointment service procedures.



1. Accounts Management (AM) toll-free Customer Service Representatives (CSRs) schedule appointments on the TAC appointment calendar after offering assistance over the phone and providing available alternative services.

2. Refer to IRM 21.1.1.3, Customer Service Representative (CSR) Duties, and IRM 21.3.4.2.4.5, Accounts Management Procedures for Appointment Service, for instructions.

3. All TACs open to the public at 8:30 a.m. Appointments are scheduled starting at 8:30 a.m. The last 30-minute appointment slot is scheduled at 3:45 p.m. or earlier. This allows the employees to serve the taxpayer and complete end of day activities.


3. Group managers:



01. Request access to the Field Assistance Scheduling Tool (FAST) for themselves and their employees who require access. Requests for access to FAST must be submitted through the Business Entitlement Access Request System (BEARS). Submitted requests will be reviewed for approval by the area analyst.

02. Group managers and all employees must have access to the FAST calendar and be active to take appointments.

03. The TAC GM reviews the calendar at the beginning of each day to identify updates, appointment changes and daily resource needs.

04. Identify ITAS availability on the appointment calendar for each day (recommend this task be completed at least 60 days in advance or as soon as the employee’s schedule is known).

05. Block the TAC appointment calendar for employee break and lunch times and when employees are not available due to training or leave. Refer to the User Guide for Field Assistance Managers for directions on blocking.

06. Review the calendar to ensure employees not servicing appointments have the appropriate blocks and/or out-of-office added to the FAST calendar, showing the specific task and timeframe required to complete the activity.

07. Regularly review blocked times to ensure the timeframe allowed is appropriate.

08. Lunches, breaks, and AWS schedules must be scheduled on FAST for all employees/resources.



       ### Note:



       Blocks are used to cover periods of time when an employee is assigned to complete other duties, such as remittance processing, mail, transmittal follow-up, etc.

09. EnsurePub 5202, Welcome Taxpayer Assistance Center Services, which explains how to make an appointment in the TAC, is displayed.

10. Print the TAC appointment calendar for the next day (recommend doing this at the end of each day). Place the next day’s appointment schedule in a central, secured location such as a locked cabinet during and after business hours.

11. Printing the FAST calendar is a snapshot of currently scheduled appointments. Managers must ensure employees are using FAST calendar, at the front counter/IAR’s desk to view current appointment activity daily.

12. The FAST calendar will recalculate in real-time and immediately shows availability for same day appointments due to the following: appointment cancellation, no-shows, current scheduled appointment ends before the allotted timeframes expires, etc.

13. This allows employees to immediately identify if appointment slots become available; opening the opportunity for a same-day appointment scheduled.


4. Regularly review the calendar in advance to check for inappropriate referrals, large cash payments, special request such as a sign language interpreter, and to ensure times are correctly blocked for appointments. This allows time for the manager to contact the taxpayer if the appointment needs to be rescheduled.

5. Alien clearance/sailing permit FAST appointments generate a notification once an alien clearance (sailing permit) appointment is scheduled in FAST. Group managers receive an email notification requiring taxpayer contact.




| Group Manager (or designee): |
| --- |
| Contacts the taxpayer and confirms his/her departure date is at least two weeks, and no more than 30 days, from his/her departure date. |
| Determines if the current appointment needs to be rescheduled as a hardship alien clearance (sailing permit) request.<br> <br>1. If so, confirm the appointment date with the taxpayer and reschedule to provide timely assistance.<br>      <br>2. If the appointment is more than 30 days from the departure date, do not reschedule the appointment. |


**1.4.11.2.1** **(02-20-2024)**

#### Unplanned Taxpayer Assistance Center (TAC) Closures

1. The group manager (GM) or designee must contact the taxpayer to reschedule an appointment when there is an unplanned TAC closure. Do not ask Accounts Management to call the taxpayer and reschedule appointments.

2. Each TAC manager pairs with another TAC manager in advance to assist with rescheduling appointments. Pairings should be within different geographical locations within the area, or across areas, if necessary, to avoid paired offices being closed at the same time. If paired offices are closed, the area analyst with oversight for the closed office notifies the taxpayer and reschedules the appointment.

3. Managers of a closed TAC must take the following steps **before** taxpayers are notified and before deleting/rescheduling the cancelled appointments:



1. Contact your "paired" manager for assistance with cancelling and rescheduling appointments, if necessary.

2. If the TAC manager or the paired manager is not available, the area analyst, or other member of the area leadership team must ensure the taxpayers are contacted and the appointments are rescheduled.

3. Make sure the first action you take **before** attempting to contact the taxpayers to reschedule the appointment is to update the TAC location to show the unplanned closure. Refer to _IRM 1.4.11.12.1_, Change in Hours of Operations, CHOR & Emergency Closure Job Aid, and the FAST User Guide for Managers for directions.

4. After the previous actions are complete, call the taxpayer following the steps below. Keep a log of the following information:


   - Date of closure

   - Number of scheduled appointments during the closure period

   - Who completed the call backs

   - Confirmation that all taxpayers were contacted (attempted contact)


4. The manager (or designee) makes one attempt to call the taxpayer. Follow the steps below when contacting the taxpayer:



1. Reach taxpayer’s voice mail. "This is (employee name), badge number (xxxxxxx), calling from the (affected TAC’s city, state) IRS office. Due to unforeseen circumstances, we must reschedule your appointment. Please call 844-545-5640 to reschedule your appointment. We apologize for the inconvenience." Refer to IRM 10.5.1, Privacy and Information Protection, Privacy Policy.

2. Unable to reach the taxpayer (i.e., no voice mail or incorrect phone number). No additional action needed.

3. Reach the taxpayer but unable to reschedule. Advise the taxpayer to call the appointment toll-free line to reschedule at their convenience.

4. Reach the taxpayer and able to reschedule the appointment. Reschedule the appointment to change the date and time of the appointment, as appropriate.



      ### Note:



      Refer to the FAST User Guide and TAC Closure Job Aid for instructions on rescheduling or cancelling appointments.


5. If the appointment calendar system goes down or is unavailable, AM CSRs follow regular procedures to target the taxpayer’s issue and provide assistance to resolve the issue over the phone. If the CSR is unable to help the taxpayer, and it is determined that an appointment is needed, the CSR advises the taxpayer to call back when the system comes back online. Do not complete a written referral to request an appointment.


**1.4.11.3** **(02-20-2024)**

### Structuring Workflow in Taxpayer Assistance Centers (TACs)

1. Service hours for TACs are based on local traffic patterns and available resources determined by the area.

2. Establish an effective workflow in the TAC. Continually balance scheduled appointments, walk-in taxpayers, and other assignments to ensure each taxpayer receives expeditious service with minimal wait time.

3. Consider employee training and expertise levels when scheduling assignments to accomplish program objectives. Establish and maintain effective lines of communication both internally and externally. Disseminate all appropriate information to the TAC employees and any employees that provide backup assistance. When possible, communicate with employees in person.

4. When you determine there are no appointments in the TAC due to cancellations or other mitigating circumstances, employees can be assigned to other tasks such as:



1. Completing Correspondence Imaging Inventory (CII) work.

2. Maintaining forms racks.

3. Processing mail, date stamped acknowledged Form 3210, Document Transmittal, forms received.

4. Maintaining and updating the remittance and non-remittance acknowledgement transmittal binders.

5. Processing payments received earlier in the day (RSPCC Scanning and/or Key Verifying).

6. Shredding.

7. E-learning.

8. Working in-house referrals.


**1.4.11.3.1** **(12-22-2021)**

#### Advising Taxpayers of Wait Time

1. An Initial Assistance Representative (IAR) directs the flow of taxpayer traffic to the respective TAC service areas. A full-time IAR is needed for heavy taxpayer traffic during the filing season in medium or large TACs. A part-time or seasonal IAR may be needed during the non-filing season.

2. Advise taxpayers who do not have a pre-scheduled appointment that service is by appointment only. Advise the taxpayer if you are able to schedule them a same day appointment. Provide them the time of their scheduled appointment.



### Note:



If you can provide immediate assistance, advise the taxpayer that you currently have an appointment opening and are able to assist them without waiting today. However, advise the taxpayer that they need to call the toll-free number, **844-545-5640**, for any future assistance.





1. In TACs with an IAR, the manager has the discretion to have the IAR provide limited same day services to taxpayers.

2. If no same day appointments are available, advise the taxpayer that they have to call the appointment number for an appointment on another day. Provide the toll-free number, **844-545-5640**, and advise of alternative services available for their issue.

3. Accounts Management employees cannot schedule a same day appointment and do not advise the taxpayer to walk in without an appointment when an appointment is needed for the requested face-to-face service.

4. TAC group managers can use managerial discretion to make exceptions to the appointment process in cases of special situations.



      ### Example:



      The elderly or disabled, taxpayer traveled long distance, etc.


3. Place printed material providing alternative methods to obtain tax assistance in clear view for the taxpayer to take with them. This could consist of publications, brochures, bookmarks, and other communication products.

4. The IRS Restructuring and Reform Act of 1998 (IRS RRA 98), Section 3705(a), provides identification requirements for all IRS employees working tax related matters.



### Note:



Under the TBOR, taxpayers have the right to receive prompt, courteous, and professional assistance in their dealings with the IRS, to be spoken to in a way they can easily understand, to receive clear and easily understandable communications from the IRS, and to speak to a supervisor about inadequate service. Additional information may be found on [IRS.gov/taxpayer-bill-of-rights](https://www.irs.gov/taxpayer-bill-of-rights).


**1.4.11.3.2** **(01-04-2021)**

#### Preparation for Filing Season

1. To prepare employees in TACs to perform their tasks for both taxpayers and the Service, advance planning is necessary. Evaluate the TAC to ensure that it is ready prior to the filing season.


**1.4.11.3.3** **(02-20-2024)**

#### Virtual Service Delivery (VSD)

1. Virtual Service Delivery (VSD) is a method for taxpayers to receive face-to-face service in areas not served by a TAC. The VSD support site GM (or designee):



1. Ensures each TAC employee providing service virtually has received the training necessary for handling VSD taxpayers.

2. Ensures equipment at the partner VSD site and support site are functional and ready for daily operations.

3. Performs the initial Qmatic/Orchestra configuration. The designated TAC manager (or designee) will have access to the Qmatic/Orchestra branch controller for all VSD sites and will monitor TAC traffic, and any other Qmatic/Orchestra system issues. The TAC GM is listed in FAMIS as the manager of the Office Designation Number (ODN) assigned to the partner VSD site. See _IRM 1.4.11.17_, Qmatic/Orchestra, for Qmatic/Orchestra procedures.


2. Employees capture time spent providing virtual assistance under a separate ODN. Employees complete two copies of Form 5311, Taxpayer Service Activity Report, one for their home TAC and one for the VSD assistance. This allows employees to capture units for the ODN where the taxpayer is located, not where the employee performed the work. See IRM 21.3.4.6, Time Reporting for TAC Employees.

3. Refer to IRM 21.3.4.3.3, Communicating with and Surveying Taxpayers, for Customer Satisfaction Survey procedures.

4. Refer to the VSD procedures located on the FA Insider for information on:



   - Requests for a manager

   - Deaf/Hard of Hearing taxpayers

   - Irate taxpayers

   - Closures

   - Technical issues


**1.4.11.3.4** **(02-20-2024)**

#### Over the Phone Interpreter (OPI) Service

1. Use bilingual employees (if available) or the OPI service when bilingual assistance is needed. If the taxpayer needs bilingual assistance, do not make taxpayers wait for a bilingual employee if the bilingual employee is assisting other taxpayers, use the OPI service.



### Note:



OPI services are NOT available in TACs co-located in a Social Security Administrative Office.

2. Employees use the OPI service while assisting TAC taxpayers. Ensure TAC employees do not share the Personal Identification Numbers (PINs) assigned with other employees, TACs or other business units.



### Note:



To obtain a PIN for new employees, have a PIN removed for employees who left FA or to obtain a listing of PINs for your group, contact the local area OPI analyst.

3. The FA Headquarters OPI analyst shares monthly reports for each area.

4. Area analysts review the following:



1. Calls lasting over 50 minutes - Employees should hang up when research is required and call back when research is completed. See IRM 21.3.4.3.4, Multilingual Assistance.

2. SEID - Only TAC employees use the OPI service.


5. After review of the reports, elevate issues identified by the area analysts to the headquarters OPI analyst.


**1.4.11.3.5** **(02-20-2024)**

#### Alternative Work Stream

1. To balance the IRS workload and maximize resources, TACs participate in alternative work stream to work cases following the One Stop Service Approach to ensure taxpayers receive complete customer service. Refer to IRM 21.3.4.2.5, Alternative Work Stream and IRM References.

2. Under alternative work stream, assign Correspondence Imaging Inventory (CII) case work as needed when there are no face-to-face taxpayers, and all required off-counter duties in the TAC are complete or in between appointments during idle time.

3. If the TAC is understaffed due to absences or an unexpected increase in demand for services, such as hardship or walk-in traffic that does not require an appointment, and no one else is available to assist, reassign an ITAS working CII cases to work face-to-face contacts.



1. Do not close a TAC when an employee is available to take scheduled appointments and/or assist walk-in taxpayers.

2. Determine whether an ITAS is reassigned to work the counter or CII inventory.

3. Determine a TAC’s capacity to allow employees to work alternative work stream.

4. Monitor their calendars and daily activities and assign work assignments based on what they see and what they can reasonably project.

5. Communicate any revisions or updates to the alternative work stream process to their employees.

6. Regularly review the appointment calendar and make adjustments to consolidate open time slots to limit employee idle time.

7. Review the daily inventory reports and perform a quality review of the prior day’s adjustments.

8. Complete the required EQRS reviews. Performing two non-evaluative reviews during the first 60 days satisfies the EQRS managerial review requirement for the non-evaluative period. See _IRM 1.4.11.20_, Embedded Quality Roles and Responsibilities.


4. Ensure an ITAS working CII cases:



1. Conducts thorough research.

2. Can work independently.

3. Works cases first in and first out, regardless of age or overage.

4. Addresses all issues identified in the taxpayer’s correspondence, within FA authority.



      ### Exception:



      An ITAS who does not have the training level to address the issue advises the GM and requests the case be reassigned to an ITAS with the appropriate training level.

5. Contacts the group manager if there are any questions or has completed the assigned work and needs additional cases.


**1.4.11.3.6** **(01-02-2019)**

#### Referrals

1. Employees are often required to initiate referrals to resolve an inquiry that is out of the employee’s scope of training.

2. Ensure employees follow the required FA procedures for referrals in:



   - IRM 21.3.4.9.2, Tax Law Referral Procedures

   - IRM 21.3.4.12.2, Account Referral Procedures

   - IRM 21.3.5, Taxpayer Inquiry Referrals Form 4442


3. Assign a designated FA employee to resolve account and technical referrals for which the front-line employee did not have the training to ensure these referrals are worked timely.

4. Review and initial all Form 4442, Inquiry Referral, or Form e-4442 referrals prior to being transferred (this review may be delegated to a lead or a referral coordinator).


**1.4.11.3.6.1** **(01-02-2019)**

##### Referral Responsibilities

1. **Headquarters Coordinator:**



01. Serves as liaison with other business units.

02. Establishes contact in Campuses for overage referrals.

03. Elevates concerns.

04. Consolidates and analyzes reports from areas on an as needed or requested basis.

05. Identifies current or emerging issues regarding process.

06. Collects and shares best practices.

07. Shares statistical reports with all on an as needed or requested basis.

08. Responds timely to questions/issues from area coordinators.

09. Serves as a resource person.

10. Sets policies.

11. Submits IRM updates.

12. Conducts reviews.


2. **Area Coordinators:**



01. Support FA employees with program initiatives.

02. Consolidate and maintain a list of referral coordinators and their backup.

03. Consolidate and maintain a list of SMEs.

04. Provide monthly reports to headquarters coordinator.

05. Provide reports to area director and Territory Manager (TM) on an as needed or requested basis.

06. Ensure changes to the referral procedures are timely disseminated to FA employees.

07. Monitor the FA in-scope tax law emails (sent to ts.fa.ot.ref@irs.gov) daily for any submissions by area employees.

08. Assign the in-scope tax law email to a designated FA specialist/SME.

09. Ensure the FA specialist/SME has closed the in-scope tax law referral timely.

10. Coordinate training.

11. Ensure proper training.

12. Communicate changes in the systems or guidelines.

13. Provide feedback to TAC managers.


3. **Group Managers:**



01. Appoint Group Referral Coordinators (GRCs).

02. Appoint SMEs.

03. Ensure GRC and SME understand their role in the program and have enough time to carry out their responsibilities.

04. Implement and monitor program to ensure timeliness, accuracy and appropriateness of referrals.

05. Ensure accurate reporting on Form 5311, Taxpayer Service Activity Report.

06. Ensure employees understand program goals, objectives and procedures.

07. Ensure referrals routed outside of FA are outside of FA scope, unless mandated by IRM.

08. Review and approve all outside referrals.

09. Review rejected and overage referrals.

10. Profile "Skill Set" for employees working in-house inventory.

11. Schedule employees to work referral inventory.


**1.4.11.4** **(10-25-2024)**

### Taxpayer Assistance Center (TAC) Security Controls and Signs

1. TACs are arranged to take under consideration available space, volume and anticipated traffic. Ensure the overall appearance of the TACs is clean, well-organized, uncluttered and as attractive as possible to maintain a professional and efficient image of the IRS to the public.

2. The office layout is designed to provide for maximum privacy for taxpayers, depending on space availability. Taxpayers seeking only forms may help themselves to limited quantities as determined by the TAC. Place self-service form racks in the outer lobby or as near to the TAC entrance as possible.

3. Coordinate the placement of self-service form racks and the forms distribution area with the local functional area. Consider placing forms distribution racks in a separate location from the TAC when forms traffic is substantial.



### Example:



In offices where the TAC is not located on the first floor, forms distribution racks can be placed in the lobby. This substantially reduces the congestion and traffic in the TAC area.

4. For guidance on products that can be stocked on the self-service racks:



   - IRM 21.3.4.10, Forms, Instructions and Publications

   - IRM 1.18.3, Tax Forms Distribution Programs

   - The current year TAC Product List

   - The Media and Publications (M&P) TAC Program Page


5. Group managers must ensure the address and order point contact information is current for their TAC(s). Order point contact information and address maintenance can be verified/updated by accessing the link Order and Subscription Management System on the TAC Program Page.

6. **Approval Authority:** The Director of FA must approve any deviations from the prescribed procedures.


**1.4.11.4.1** **(10-25-2024)**

#### Taxpayer Assistance Center (TAC) Physical Security Requirements

1. The IRS has a legal obligation to protect the confidentiality of tax returns and related information. The IRS also has the responsibility of protecting the entire Federal Tax Administration System, not just the individual components of the system but employees, computer equipment, tax returns, monies, property, facilities, and records. Therefore, established minimum-security standards minimize the potential for loss of life and property, the disruption of services and functions, and the unauthorized disclosure of documents and information.

2. Managers are required to use a Data Collection Instrument (DCI) to conduct quarterly physical security and remittance reviews. In addition, managers must complete Part I, Part II, Part III, and Part IV of Form 15608, Field Assistance Physical Security Form, and digitally sign page six.

3. The TAC Security and Remittance Review Database (TSRRD) survey captures the self-assessment results from the physical security and various remittance reviews that are completed quarterly by the group manager. The database allows FA to effectively monitor the TACs adherence to security requirements. The database addresses the following:



   - Allows the ability to collect information, identify deficiencies, and follow-up on corrective actions in a timely and comprehensive manner according to the IRM requirements.

   - Establishes the top security and remittance issues by area and TAC location (city and state).

   - Compiles data to assess effectiveness and progress in correcting weaknesses in physical security controls to protect sensitive taxpayer information and receipts.


4. The quarterly due dates for the TSRRD survey are as follows:




| Frequency | Due Date(s) |
| --- | --- |
| Quarterly | - Period ending December 31, due January 31<br>     <br>   - Period ending March 31, due April 30<br>     <br>   - Period ending June 30, due July 31<br>     <br>   - Period ending September 30, due October 31 |

5. Carefully plan and use proper measures to ensure all facilities are protected. Basic security measures include:



1. Locked perimeter doors.

2. Slab-slab exterior walls (at the IRS perimeter).

3. Duress alarms in public contact areas.

4. Intrusion detection for first floor offices and other offices as required by IRM guidelines.


In addition, property standards for building access established for employees and visitors include:



1. ID and visitor badges.

2. Employee credentials.

3. Keys and locks.

4. Alarm maintenance and testing.

5. Duress alarms.

6. Fire suppression systems.

7. Guard services.


6. Ensure compliance with the security standards contained in:




| IRM Reference | Title |
| --- | --- |
| IRM 21.1.3 | Operational Guidelines Overview |
| IRM 10.8.1 | Policy and Guidance |
| IRM 10.8.26 | Wireless and Mobile Device Security Policy |
| IRM 10.8.34.5 | Technical Controls |
| IRM 10.2.8 | Incident Reporting |
| IRM 10.2.1 | Physical Security |
| IRM 10.2.14 | Methods of Providing Protection |

7. Managers must have a basic working knowledge of security requirements for tax return information, remittances, IDRS passwords, date and disclaimer stamps, and Law Enforcement Manuals (LEM). TACs are subject to compliance reviews by Facilities Management and Security Services (FMSS), Information Technology (IT), Government Accountability Office (GAO), and Treasury Inspector General for Tax Administration (TIGTA).

8. Controlled access is an essential aspect of ensuring that FA has adequate safeguards in place to protect taxpayer information from disclosure and prevent unauthorized access to both information and property. In determining the security criteria for TACs, consideration should be given to the types and volumes of assets regularly received and stored. Examples of such assets include, but are not limited to:



   - Cash remittances

   - Check remittances

   - Form 809, Receipt for Payment of Taxes

   - Received and Received with Remittance stamps

   - Tax returns

   - Return information


**1.4.11.4.1.1** **(02-20-2024)**

##### Controlled Area

1. According to IRM 10.2.14.3.5, Security Areas, _"a controlled area requires a single-factor authentication mechanism. Each IRS space is a controlled area, which ensures only authorized personnel and visitors are allowed access."_ Additional controlled areas, which are considered “above standard” maybe established within IRS spaces for alarm panel rooms; security operations centers; rooms with large amounts of currency; or other similar areas within a business unit. Management is responsible for determining such a need and for subsequently deciding to grant or deny access. As stated in the National Agreement, Document 11678, Internal Revenue Service (IRS) and National Treasury Employees Union (NTEU), management retains the right to determine internal security practices.

2. When protecting assets and information, limit access to those persons with a need to access the information due to their official duties and/or responsibilities.


**1.4.11.4.1.2** **(02-20-2024)**

##### Field Assistance Manager Responsibilities

1. Diligently control access to the TACs to strengthen security. Implement the security requirements outlined in IRM 10.2.14, Physical Security Program, Methods of Providing Protection to the maximum extent in every TAC within space and funding constraints. Ensure all personnel adhere to federal laws and privacy guidelines for privacy and protection of taxpayer and employee Sensitive But Unclassified (SBU) data, including Personally Identifiable Information (PII) and tax information. See IRM 10.5.1, Privacy and Information Protection, Privacy Policy, for managerial roles and responsibilities for proper treatment of SBU data.

2. It is important to emphasize the need to exercise good judgment in determining how to control access. Consideration must be given to the impact that changes may have on the overall safety and security of all Post of Duty (POD) employees.

3. For the numerous space projects in process which configure TAC space according to the new TAC model designs, managers need to ensure that space layouts incorporate the security aspects required to meet controlled area requirements to limit access. Such aspects include at a minimum one or more of the following:



1. Surrounding the TAC with slab-slab exterior walls.

2. Wearing Identification (ID) cards for all TAC employees and visitors.

3. Installing doors with appropriate combination locking devices or electronic card access.


4. The type of locking device installed on the doors depends on the POD's specific security system. For instance, IRS space with electronic card access system doors have card readers installed. If there is no electronic card access system, combination locks suffice.

5. For offices where no space reconfiguration for the TAC Model is scheduled for the near term, determine what measures to take to limit access.

6. Older designed office layouts may have no practical way to "control access" when another organization has a storage room inside our space. In those situations, it is even more essential to use appropriate locking containers to store sensitive information and documents.

7. Managers must ensure that the TACs are equipped with adequate physical security controls to prevent unauthorized access. See _IRM 1.4.11.4.1.3_, Controlled Access Procedures. If controls are not already in place, management must work with local FMSS, and commissioner’s representative/administrative officer assigned to the building. All TAC security, safety, health and space concerns must be identified and elevated through the appropriate management chain (area director's office to FA headquarters) so that the appropriate corrective action can be taken.



### Note:



Other IRS business unit employees cannot be denied access to TAC space in emergency situations if their only means of emergency evacuation is through the TAC.


**1.4.11.4.1.2.1** **(08-13-2025)**

###### Employee Name Tags

1. TAC employees are required to wear a name tag displaying their name while providing face-to-face assistance to taxpayers. Employees must verbally identify themselves by providing their name and employee identification number (ten digits of their Personal Identification Number) to all taxpayers when not wearing their name tag (name tag not yet ordered and received).

2. Employee name tags are supplied by the FA headquarters staff. New or replacement name tag information must be provided to the designated headquarter employee.

3. Employee name tags display the entire first name, last name and employee identification number. Employees may use a courtesy title with the entire first and last name or with the last name. Ensure the employee identification number is included on the name tag. Do not include first name "initials" . See examples below:



1. Entire First Name, Entire Last Name, and Employee Identification Number.

2. (Mr., Mrs., Miss, or Ms.) Entire First Name, Entire Last Name and Employee Identification Number.

3. (Mr., Mrs., Miss, or Ms.) Last Name and Employee Identification Number.


**1.4.11.4.1.2.2** **(01-02-2019)**

###### Obtaining Customer Satisfaction Survey (CSS) Cards

1. The initial annual supply of survey cards is shipped to the TACs at the beginning of the fiscal year.

2. If a TAC needs additional cards before the end of the fiscal year, they can be ordered by sending an email to the FA headquarters customer satisfaction survey analyst. Include the following information in the email:



1. Office designation number (ODN).

2. TAC contact person email and phone number.

3. Complete mailing address of TAC including floor, suite, room, and/or mail stop number.

4. Number of packages needed (each package contains 300 cards).

5. Indicate if it is an emergency request that requires expedited shipping.


**1.4.11.4.1.2.3** **(04-04-2014)**

###### Reporting a Missing Child from or Within IRS Facilities

1. The "Code Adam Act of 2003" law requires that the designated authority for a public building establish procedures for a child missing within or from a federal building.

2. The Department of Homeland Security’s Federal Protective Service (FPS) implemented the policy nationwide and established procedures for locating a missing child in federal facilities.

3. General Services Administration (GSA) administers this program nationwide in both owned and leased buildings. Each agency is responsible for establishing and implementing procedures consistent with GSA requirements.

4. Be aware of these two alerts:



1. **Code Adam** \- when a child is missing _within_ an IRS facility.

2. **Code Amber** \- when a child is missing _from_ an IRS facility.


5. Once a child is determined missing "from" or "within" a federal building, a manager must follow the steps in the: Code Adam/Code Amber Alert Program IRS Manager’s Guide.

6. If a manager is not available, employees must contact the on-site Commissioner’s Representative (CR) for the POD.

7. For more information, see IRM 10.2.9, Occupant Emergency Planning.


**1.4.11.4.1.3** **(10-25-2024)**

##### Controlled Access Procedures

1. Take the following actions to control access:



01. Visually monitor traffic in and out of TACs.

02. Deny entrance to TAC space if the individual is not assigned to perform FA operations unless authorized by the TAC manager.



       ### Exception:



       Allow access to the TAC to employees from any organizational unit impacted by hurricanes or natural disasters. When non-TAC employees are located in TAC space, compensatory controls should be implemented (i.e., non-TAC employees cannot walk behind the counters). Limit their access to what is necessary.





       ### Exception:



       The Inspector General Act -120.1.1 of 1978, as amended, gives TIGTA officials the authority to access all facilities of the IRS, the IRS Chief Counsel, and the IRS Oversight Board, and to access all records, reports, audits, reviews, documents, papers, recommendations, or other material available to the IRS, the IRS Chief Counsel, or the IRS Oversight Board which relate to their programs and operations.

03. Conduct unannounced physical security reviews on a quarterly basis using Part I, Part II, Part III and Part IV of Form 15608, Field Assistance Physical Security Review Form, and digitally sign certification quarterly on page six. See _IRM 1.4.11.4.2_, TAC Security/Internal Controls.

04. Use a designated entrance feature into TAC space, which allows one of the following: Electronic card, combination lock, or a security register (log). The type of entry will depend on the post of duty.

05. Separate employee entrance from public access.

06. Ensure unguarded doors facing public access are locked from the outside at all times, especially during normal business hours. Make sure doors without high traffic cannot be opened from the outside without a smart card, combination, or key.

07. Ensure employees practice the clean desk policy, making sure tax data, cash, signature stamps, unused Form 809 receipt books, and "Official Use Only" data is properly secured at all times. Information should not be exposed when an employee has left the office for the day. See IRM 10.5.1, Privacy and Information Protection, Privacy Policy.

08. Provide keys to locked containers and combinations to safes only to authorized personnel.

09. Monitor janitorial cleaning performance during regular business hours.

10. Provide TAC employees with written information regarding the duress alarm and its response time (targeted response time is within 15 minutes).

11. Coordinate with local FMSS and the Commissioner’s Representative (CR)/administrative officer assigned to the building immediately if corrective action is needed.


**1.4.11.4.1.4** **(02-20-2024)**

##### Cameras/Photography Prohibited

1. In general, the IRS permits employees and visitors to bring personal cell phones with or without camera capability into TACs and other IRS facilities. Although the use of cell phones with camera capability raises security issues, it is impractical to prohibit cell phones with camera capability.

2. To minimize the potential for inadvertently compromising SBU data (including PII and taxpayer information), advise TAC **employees** and **visitors**:



1. Cameras may not be used in the TAC and photographs may not be taken while in the TAC unless pre-approved by the TAC manager and cleared by FMSS.

2. The use of the camera capability in cell phones is not authorized in any IRS facility.

3. The IRS may not secure personal items such as cell phones on behalf of visitors, however, the FPS may request visitors to secure personal items such as cell phones in their automobile or in some other manner.


3. Management is responsible for ensuring all employees are familiar with the rules and regulations governing the protection of sensitive data as outlined in IRC 6103. Penalties for employees compromising the protection and confidentiality of tax returns and related sensitive information are contained in the IRC, Privacy Act, Rules of Conduct, and UNAX documents. See IRM 10.5.5, IRS Unauthorized Access, Attempted Access or Inspection of Taxpayer Records (UNAX) Program Policy, Guidance and Requirements. Visit the UNAX Knowledge Management site for more information. See IRM 10.5.1, Privacy Policy, for policy relating to Recordings in the Workplace.

4. It is the responsibility of management to ensure the rules regarding the use of cameras and photography are posted in a prominent location in the TAC. If visitors attempt to compromise security procedures, local security enforcement authorities must be notified.


**1.4.11.4.2** **(10-25-2024)**

#### Taxpayer Assistance Center (TAC) Security/Internal Controls

01. Overview – The IRS has a legal obligation to protect the confidentiality of tax returns and related information.

02. Management controls are an integral component of an organization’s management. They are the programs, policies, and procedures established to ensure that the organization is managed efficiently and effectively and protected from waste, fraud, abuse, mismanagement, and misappropriation of funds. Management controls are synonymous with internal controls. See IRM 1.4.2, Monitoring and Improving Internal Control.

03. Constantly reinforce the importance of adherence to security and internal controls when processing remittances (cash and non-cash).

04. Local FMSS tests duress alarms located in each TAC annually. If necessary, FMSS contacts the TAC manager for assistance to activate and reset duress alarm(s).

05. Removable media and Digital Versatile Disc (DVD) players in the TAC do not require any additional security beyond that of any other furniture or IRS property in the TAC. Store remote controls for the television and DVD player in a safe place at all times (desk or cabinet is acceptable).

06. The TAC’s Security and Remittance Review Database (TSRRD Survey) captures self-assessment results from the physical security, remittance, and Integrated Data Retrieval System (IDRS)/IDRS Online Reports Service (IORS) Security reviews completed by the GM during each quarter.

07. The database allows FA to effectively monitor the TACs adherence to security requirements.

08. The database is used to store historical data and identify the offices that are visited for operational reviews.

09. Annually, territory and group managers receive training on TAC Security and Remittance Review Database (TSRRD) as part of CPE or Filing Season Readiness training to include updates and changes to the TSRRD database. Training includes the manager’s roles, responsibilities, and review process in completing the TSRRD surveys.



    ### Note:



    Group managers receive the initial TSRRD training as part of the “Managing a TAC” course

10. The manager is responsible for conducting physical security reviews using Part I, Part II, Part III and Part IV and digitally sign Page 6 of Form 15608, Field Assistance Physical Security Review Form, on a quarterly basis. The results of the reviews are used to answer questions in the TAC Security and Remittance Review Database Physical Security section quarterly. See _IRM 1.4.11.4.1.3_, Controlled Access Procedures.

11. At a minimum, managers ensure compliance with standards on:



    1. IRM 10.2.14, Methods of Providing Protection

    2. IRM 10.5.1, Privacy and Information Protection, Privacy Policy

    3. IRM 10.8.1, Information Technology (IT), Security, Policy and Guidance

    4. IRM 1.15.2, Records and Information Management, Types of Records and Their Life Cycles

    5. IRM 10.5.1.5.1, Clean Desk Policy

    6. IRM 10.2.5, Identification Media


12. Managers must comply with all minimum-security standards contained in IRM 10.2.14, Methods of Providing Protection, all local security requirements, for reporting any violations to the local physical security office and other individuals (e.g., TIGTA) who have security responsibilities.

13. See IRM 3.8.47.4.5, Security of Forms 809 receipt for Payment of Taxes and IRM 10.2.14.3.6, Combination Control and Safeguarding, regarding the manager's responsibilities on when to change the SF 700, Security Container Information.


**1.4.11.4.2.1** **(02-20-2024)**

##### Completing Form 700

1. Control access to the combinations of secured areas and/or containers to prevent unauthorized access. Provide combinations only to those who need to have access to the area. See IRM 10.2.14.3.6, Combination Control and Safeguarding, for more information. Managers must print legibly and enter the following information when completing Standard Form 700, Security Container Information:



01. Block 1: Area or post of duty.

02. Block 2: Building name.

03. Block 3: Room number.

04. Block 4: Division, Branch, Section or Office.

05. Block 5: Serial number of container.

06. Block 6: Manufacturer and class/type of container.

07. Block 7: Manufacturer and type of lock/model.

08. Block 8: Serial number of lock.

09. Block 9: Date combination changed. If this is a new container, list the date the container is acquired in block.

10. Block 10: Print name/organization symbol with signature of person making the change.

11. Block 11: Names of each employee with combination or key access to the safe. Annotate the business address and telephone number for each employee listed with the combination or access to the safe. In the event that additional space is required, use an addendum. The addendum must include the employee’s first and last name, business address and telephone number of each employee with access to the safe that is not listed on Form 700. **Date and sign** the addendum to identify when completed.


2. Detach Part 1 of the Form 700 and attach the Form 700 Part 1 to the inside of the container. This must be made available for viewing by internal control reviewers.

3. Complete Standard Form 700 Part 2-A as follows:



1. List the serial number of the container in the space marked Security Container Number.

2. Print the combination clearly in the Combination space.

3. Insert Part 2-A into a security envelope and retain in a secure location under control of the TM. The TM maintains Form 700 Part 2-A in a locked file cabinet. If the TM chooses to maintain Form 700 Part 2-A in a locked box, ensure the box is stored in the file cabinet.


4. Standard Form 700 must be clearly marked in legible print without error. Marking over, scratching out, use of correction fluid, use of correction tape, or lining through are not allowed.

5. Form 700 is ordered by the area secretaries and distributed to managers as necessary. They come in packs of 100. These are not stocked at NDC but ordered through [www.gsaglobalsupply.gsa.gov](https://www.irs.gov/irm/part1/www.gsaglobalsupply.gsa.gov) or [www.gsaadvantage.gov](https://www.irs.gov/irm/part1/www.gsaadvantage.gov) with either a government purchase card or AAC (Activity Address Code). The phone number is 800-525-8027, select option 1 and request product number 7540-01-214-5372, Standard Form 700.



### Note:



Change the combination to the safe and complete and new Form 700 when the safe or lock is originally received, annually thereafter and whenever the combination is compromised in any way or when an employee who knows the combination leaves on a job transfer, is a released seasonal, retires, or terminates employment. Combinations should be at least four (4) digits.


**1.4.11.4.3** **(01-02-2019)**

#### Use of Signs/Posters in Taxpayer Assistance Centers (TACs)

1. All TACs display the required signs provided by headquarters and ensure procedures outlined in IRM 21.3.4.3.5, Signs, are followed.

2. All other signs (e.g., signs from other business units, temporary signs) must be approved by the Director of FA or headquarters designee.



### Caution:



No hand-written signs are allowed.


**1.4.11.4.4** **(01-02-2019)**

#### Televisions (TVs) in Taxpayer Assistance Centers (TACs)

1. Only approved IRS informational messages are allowed on all TAC TVs. The use of cable and/or local TV stations is prohibited unless authorized by FA headquarters.

2. If the use of the IRS informational messages is not an option (e.g., TV broken, removable media damaged, lost or stolen), the TV must be turned off.

3. Playing background music is restricted. Sound interferes with the Qmatic or Contact Recording equipment located in the TAC.

4. Only FA employees (administrative support, technical staff or GMs) are authorized to operate the TV.


**1.4.11.4.4.1** **(02-20-2024)**

##### Roles and Responsibilities for Televisions (TVs) in the Taxpayer Assistance Center (TAC)

1. | Field Assistance Group Manager (GM) Responsibilities: | Facilities Management and Security Services (FMSS) Responsibilities: |
| --- | --- |
| Provide general coordination and support with FMSS for TV installation. | Fund and install existing or new TVs when a TAC is remodeled, relocated or a new TAC.<br> <br>### Exception:<br>Field Assistance provides funding when installation is not part of a FMSS TAC project for relocation, remodel, or a new TAC. |
| Operate the TV such as turning on and off (administrative support or technical staff may be designated if GM not located in TAC). | Mount TV where it is not easily accessible to the public and out of the reach of children. |
| Monitor TV operations and notify the area office when there is a problem. The area office notifies FA headquarters. | Mount TV where placement does not interfere with Qmatic/Contact Recording operations or obstruct the ITAS station numbering panels and ticket numbering system. |
| Submit an Incident Report using the Computer Security Incident Reporting (CSIRC) form and contact the TM and area office if the TV is lost or stolen. The area office notifies FA headquarters. | Consult with the TAC GM and determine the configuration of the TAC space to accommodate the TVs. |
| Input a request through IRS Service Central for TV purchase, installation, relocation or removal where applicable (when purchase, installation, relocation or removal is not part an FMSS TAC project for relocation, remodel or a new TAC. | Excess broken TVs by using Federal Management Regulations.<br> <br>### Note:<br>Field Assistance is responsible for funding replacement when it is not part of a FMSS TAC project for relocation, remodel or a new TAC. |






| Maintenance, Repair, Replacement and/or Troubleshooting: |
| --- |
| Do not allow TAC personnel attempt to repair the TV. If the TV requires service or becomes inoperable for any reason, contact the area office. Provide the location and what the TV is doing or not doing. The area office notifies FA headquarters. |


**1.4.11.4.4.2** **(01-02-2019)**

##### Removable Media and Digital Versatile Disc (DVD) Players

1. Removable media and DVD players are used in TACs to promote the use of informational messages to improve the taxpayer experience. Removable media is defined as any device that can be used to transport or store data such as a flash drive, compact disc (CD), and DVD.

2. Removable media and DVD players are used for educational and communication purposes as directed by FA headquarters. All other viewing methods such as cable, local television stations or the use of television antennas are prohibited, unless authorized by FA headquarters.

3. Removable media plays continuously and is allowed to loop so taxpayers may see repeated messages.


**1.4.11.4.4.2.1** **(01-02-2019)**

###### Roles and Responsibilities for Removable Media

1. | Headquarters: |
| --- |
| Provide IRS informational presentations to the field which are approved by Communications and Liaisons (C&L) and other designated approvers. |
| Input Publishing Services Requests (PSR) depending on the type of removable media required. |
| Procurement for Public Sector (PPS) numbering scheme and approval path to local FMSS Project Manager or Media and Publications (M&P) analyst through FA budget analyst for DVD player installation. |






| Field Assistance GMs: |
| --- |
| Ensure the installation and execution of the flash drive on the televisions. If assistance is required for flash drive installation, the GM seeks assistance from the local building maintenance or lessor before contacting the area office. The area office notifies FA headquarters. |
| Provide general coordination and support for DVD player installations with FMSS. |
| Operate the DVD player such as inputting and removing DVDs (administrative support or technical staff may be designated if GM not located in TAC). |
| Monitor removable media and/or DVD player operations and notify the area office for removable media and DVD player when there is a problem. The area office notifies FA headquarters. |
| Submit an Incident Report using the Computer Security Incident Reporting (CSIRC) Form and contact the TM and area office, if the removable media or DVD player is lost or stolen. The area office notifies FA headquarters. |






| FMSS: |
| --- |
| Mount DVD players where they are not easily accessible to the public and out of the reach of children (in secure space). |
| Place the DVD players inside the GMs office as the first option. |






| Maintenance, Repair, Replacement and/or Troubleshooting: |
| --- |
| Do not allow TAC personnel attempt to repair the removable media or DVD player. If the removable media or DVD player requires service, replacement or becomes inoperable for any reason, contact the area office and:<br> <br>1. Provide the location<br>      <br>2. Explain what the removable media or DVD player is doing or not doing.<br>      <br> The area office notifies FA headquarters. |
| For purchase and installation of new DVD players not part of a FMSS relocation or alterations project, provide Procurement for Public Sector (PPS) numbering scheme and approval path to local FMSS Project Manager. Field Assistance HQ:<br> <br>1. Funds replacement of any removable media, if required.<br>      <br>2. Maintains DVD player warranties, where applicable.<br>      <br>3. May fund replacement of DVD players if the warranty has expired. |
|  |
| See _IRM 1.4.11.4.2_, TAC Security/Internal Controls, for security guidance. |


**1.4.11.4.5** **(02-20-2024)**

#### Taxpayer Assistance Center Safes

1. All TACs are required to have a safe except when co-located within Social Security Administration (SSA) space. Some TACs may have more than one safe due to the large cash process. TAC safes are only used to store cash, Form 809 Receipt Book, and remittances.




| Safe Repair |
| --- |
| 1. Field Assistance funds the repair of safes.<br>      <br>2. Contact your area budget analyst via email to request approval. State the reason why the repair is needed in your email.<br>      <br>3. Contact the safe vendor for a quote to repair the safe once approval is granted.<br>      <br>4. Send an email to the area budget analyst with the quote attached.<br>      <br>5. Proceed with contacting the vendor after the area budget analyst has reviewed/approved the quote. |






| New Safe Purchase |
| --- |
| 1. Purchase new safes using the Area Office purchase card.<br>      <br>2. Contact your Area Budget Analyst via email to request approval. State the reason why the new safe is needed in your email.<br>      <br>3. Follow the specific procedures for ordering a new safe in the How to Order a New Safe Job Aid on the FA Insider once approval is granted. The procedures are similar to ordering office supplies.<br>      <br>4. A new safe must meet FA’s safe specifications (see table below).<br>      <br>5. Only General Services Administration (GSA) safes are approved for purchase. A link to GSA’s website can be found in the How to Order a New Safe Job Aid on the FA Insider. |






| Safe Specifications | Interior Dimensions | Exterior Dimensions |
| --- | --- | --- |
| - One (1) hour fire and burglary rating<br>     <br>   - Electronic lock (automatically locks when door is closed)<br>     <br>   - Re-locking device for extra security | Approximate dimensions should be at or above the minimum of:<br> <br>   - 26 5/8” height<br>     <br>   - 15” width<br>     <br>   - 13” depth | - Weight minimum **340 lbs.**<br>     <br>   - Capacity 3.0 cubic feet<br>     <br>   - One (1) shelf |

2. **Excess TAC Safe** \- Field Assistance may periodically have a need to excess safes.




| Follow the steps below to excess an existing safe: |
| --- |
| Input a Workplace Service request at IRS Service Central<br> <br>1. Enter “Non-IT Property Disposals” into the search bar.<br>      <br>2. Request Non-IT Property Disposals from the list of catalog items.<br>      <br>3. Fill out the required fields. |
| The safe must be empty and left open to ensure all IRS documents and remittances are removed. |
| The safe combination must be taped to the outside of the safe. |





### Note:



Locksmith services are required (see Safe Repair) If a safe cannot be opened. The excess process can proceed only when the safe is opened and cleared of all contents.

3. **Combinations to safes locks are changed:**



1. When the safe or lock is originally received or installed.

2. When an employee with access to the safe separates from the IRS or transfers out of FA (see _IRM 1.4.11.4.2_, Taxpayer Assistance Center (TAC) Security/Internal Controls.

3. At least once a year.

4. Whenever the combination is compromised.


### Note:

Safe combinations must be at least four (4) digits long.

4. Safe combinations should be memorized and not written on calendars, bulletin boards, etc. For additional information see IRM 10.2.14.3.6, Combination Control and Safeguarding.

5. **Safe Storage** \- The safe is only used to store cash, Form 809 receipt book, and remittances.

6. Treasury Standard Form 700, Security Container Information, provides information regarding those employees with access to the TAC safe.




| See below reminders regarding the placement and update to Form 700: |
| --- |
| 1. Follow _IRM 1.4.11.4.2.1_, Completing Form 700.<br>      <br>2. Attach Part 1 of Form 700 to the inside of the safe.<br>      <br>3. Review Form 700 prior to each quarterly review to ensure it is up to date.<br>      <br>4. Complete a Form 700 addendum when necessary.<br>      <br>5. The Form 700 addendum must include the employee’s name, business address, and business telephone number. Date and sign the addendum to identify when completed. |


**1.4.11.4.6** **(01-02-2019)**

#### Contact with the Media

1. IRS Media Relations is the single point of contact for all media. Media representatives usually contact the Field Media Relations Specialist to make inquiries or to arrange for contacts with other IRS officials. However, there may be instances when the media representative directly comes into the local TAC. In such instances, refer the media representative to the Field Media Relations Specialist. See IRM 11.1.3, Contact with the Public and the Media, for more information.


**1.4.11.5** **(01-02-2019)**

### Workers’ Compensation/Safety and Health Information System (SHIMS)

1. Ensure that employees are aware of their responsibility for reporting on the job injuries and complying with IRS regulations.

2. Determine if medical attention is requested from the injured employee and if so, ensure prompt medical attention is received.

3. Contact Workers’ Compensation Center (WCC) immediately upon notification from an employee of an injury at **800-234-8323**; be prepared to report all facts.

4. Complete a Supervisor’s Report in Safety and Health Information System (SHIMS) or the Supervisor's section of the CA-1 (Traumatic Injury) or Form CA-2 (Occupational Disease or Illness) claim form within two (2) days of written notification of injury.



### Note:



Refer to the iManage Overview of Workers Compensation for additional information and assistance.


**1.4.11.6** **(01-02-2019)**

### Disclosure/Protection of Taxpayer Information

1. To prevent unauthorized disclosure or breach of security, employees and managers must use caution when accessing taxpayer's information. Requests for access to taxpayer account information come from many parties.



### Example:



Taxpayers, authorized representatives, unauthorized individuals and third parties with legitimate material interest.






| For: | See IRM Reference: |
| --- | --- |
| Discussions and examples of material interest and authorized designees. | IRM 11.3.2, Disclosure to Persons with a Material Interest and IRM 11.3.3, Disclosure to Designees and Practitioners |
| IRS privacy policy on the protection of SBU data (including PII and tax information). | IRM 10.5.1, Privacy and Information Protection, Privacy Policy |
| Procedures on authenticating taxpayer/designee identities and access to information. | IRM 21.1.3, Operational Guidelines Overview |


**1.4.11.7** **(02-20-2024)**

### Payment Processing - Manager’s Responsibility

1. Remittance processing is the most time sensitive work performed in a TAC.

2. GMs must ensure that they and their employees are familiar with procedures contained in IRM 21.3.4.7, Remittance Processing.

3. GMs must ensure that employees with Form 809 receipt-book have a lockable cash box and that employees are following the requirement for safeguarding remittance listed in IRM 21.3.4.7.4, Safeguarding Remittances.

4. Payments received at the TAC must meet the 24-hour deposit standard. All payments must be processed on the day the payment is received or no later than the next business day. A payment is considered processed once it is submitted for deposit using Remittance Strategy for Paper Check Conversion (RSPCC) or transshipped to the appropriate Submission Processing Center (SPC) for processing.



### Exception:



During peak filing season, April 1 through April 15th, TACs have three (3) days to transship payments and payments with returns that are not processed using RSPCC. See IRM 21.3.4.7.10, Transshipping of Payments or Payments with Returns.

5. Non-cash payments must be processed using RSPCC per IRM 21.3.4.7.11, Non-cash Payment Processing using Remittance Strategy for Paper Check Conversion (RSPCC). Those payments that cannot be processed through RSPCC must be transshipped to the appropriate SPC for processing. Field Office Liaison contacts and email addresses can be found on the Field Office Payment Processing SharePoint by selecting "SP Center Field Office Payment Processing Addresses and Key Contacts" .

6. All payments transshipped from the TAC must be mailed via traceable overnight mail on the day of receipt or the next business day. Refer to IRM 21.3.4.7.10, Transshipping of Payments or Payments with Returns.

7. A large dollar non-cash payment is defined as a single non-cash payment of $100,000 or greater (IMF/BMF). Large dollar non-cash payments must be transshipped on the same day the payment is received or, with managerial approval, the next business day. For procedures regarding large payments, refer to:



   - IRM 21.3.4.7.6, Large Dollar Non-Cash Payments

   - IRM 21.3.4.7.10, Transshipping of Payments or Payments with Returns

   - IRM 3.8.47.5, Campus Remittance Processing (of Field Office Receipts)


8. Managers are accountable for acknowledgements of Form 795-A and Form 3210 requirements contained in IRM 21.3.4.7.12, Remittance Acknowledgments Transmittal Form 795-A and Form 3210 Process and IRM 21.3.4.8.7, Non-Remittance Acknowledgment Transmittals Form 3210 Process.

9. Payment drop boxes are not authorized in TACs and all payments must be accepted in person.



1. Appointments are required for cash payments. If availability, a same day appointment can be scheduled.

2. No appointment is required for a non-cash payment, check or money order.


**1.4.11.7.1** **(01-02-2019)**

#### Management Responsibility for Form 795-A and Form 3210 Files

01. The manager must ensure that the retention file of Form 795-A, Remittance and Return Report, and Form 3210, Document Transmittal, is maintained for each TAC for three (3) years from the month and year of the transmittal number. Refer to IRM 21.3.4.7.12.4, Retention Files for Remittance Acknowledgement Transmittal Procedures.

02. Form 795-A is the transmittal used to record all payments received at the TAC unless the payment meets an exception outlined in IRM 21.3.4.7, Remittance Processing.

03. Employees are required to prepare Form 795-A and Form 3210 as stated in IRM 21.3.4.7.9.1, Preparation of Form 795-A, Remittance and Return Report, and IRM 21.3.4.7.9.2, Reviewing and Reconciling Payments, Posting Vouchers, Form 795-A and Form 3210 for Payments and Payments with Returns.

04. All employees with an AMS User Profile must prepare Form 795-A using AMS.



    ### Exception:



    AMS is down, when posting both a multiple and split payment or employees with an AMS managerial profile (e.g., group managers, acting group managers and group referral coordinator).

05. Managers must be familiar with the AMS Module 09 – Tax Return, Data, CII Image, Returned Refund Check Processes, 3244-795-A Process and Online Name Change User Guide on the AMS End User Supportsite. See IRM 21.3.4.7.9, Form 795-A, Remittance and Return Report.

06. All Form 795-A payments and posting documents must be reviewed and reconciled before payments are processed using RSPCC or payments are transshipped to SPC for processing. See IRM 21.3.4.7.9.2, Reviewing and Reconciling Payments, Posting Vouchers, Form 795-A and Form 3210 for Payments and Payments with Returns.

07. Managers must maintain, by TAC, all Form 795-A and Form 3210 transmittals that are used to transship payments, payments with returns, and Form 809 receipts to ensure security of receipt and returns using the binder system. Refer to IRM 21.3.4.7.12.2, Remittance Acknowledgement Transmittal Binder System, and IRM 21.3.4.8.7.2, Non-Remittance Acknowledgement Transmittal Binder System.

08. All Form 795-A and Form 3210 transmittals and supporting documents must be stored in these three ring binders.

09. Each binder must have two dividers, one labeled **Acknowledgement** and one labeled "Pending Acknowledgement" . If multiple months are stored in a binder, additional dividers are necessary for each month to be labeled **Acknowledgment**.

10. All Forms 795-A and Forms 3210 must be filed in the binders, in numerical order, by the transmittal numbers and under the appropriate divider.

11. Current and previous month’s transmittal retention files must be maintained in the binder.

12. The manager or authorized designee follows the established system to track acknowledgement copies of Forms 795-A and Forms 3210 that are not received from the SPC within ten (10) business days from the date that the payments are mailed to the SPC.

13. Complete follow-up action with the designated SPC when Form 795-A and Form 3210 are not received from the SPC between the 11th and 15th business day from the original date the package is mailed. The managers must assign an employee and backup to:



    1. Open the mail daily and monitor the EEFax email inbox.

    2. Date stamp all acknowledged Form 795-A and Form 3210 received with the TAC’s official "Received" date stamp.

    3. Maintain the transmittal binders for remittance and non-remittance.

    4. Complete required follow-ups using Form 10946, Follow-up on Acknowledgement of Form 3210.

    5. Refer to IRM 21.3.4.7.12, Remittance Acknowledgements Transmittal Form 795-A and Form 3210 Process, and IRM 21.3.4.8.7, Non-Remittance Acknowledgement Transmittals Form 3210 Process, for additional information.


14. Managers of remote TACs have an option to centralize their files at the office where they are physically located rather than the originating location, if they have storage capacity available.

15. Each manager identifies the location where the files are stored for each TAC and shares with their TM, who shares with the area office.


**1.4.11.7.1.1** **(01-02-2019)**

##### Supplemental Form 795-A

1. Supplemental Forms 795-A are reviewed and approved by the GM for payments and Form 809 receipts transshipped to SPC for processing later than the close of business the day after the payment is accepted.

2. Supplemental Form 795-A is the same as Form 795-A except that the originator writes **SUPPLEMENTAL** on the top of the form. Refer to IRM 21.3.4.7.9.3, Supplemental Form 795-A.

3. The GM reviews the supplemental Form 795-A using the same steps outlined in IRM 21.3.4.7.9.1, Preparation of Form 795-A, Remittance and Return Report. In addition, the GM must ensure that the supplemental Form 795-A contains the following:



1. The date of the Form 795-A supplemental is the date the payments are received.

2. An explanation for the delay written on the back side of all copies of Form 795-A or a statement attached to each copy of Form 795-A.

3. FA manager’s signature and date is required indicating approval of the supplemental. EEFax is acceptable for remote managers.


4. The GM has the discretion of accepting or not accepting the employee’s explanation of the late remittance explanation. If the Form 795-A is not approved as a supplemental, the manager issues a Form 6067, Employee Performance Folder Record, to the employee for the late remittance.


**1.4.11.7.1.2** **(01-02-2019)**

##### Managerial Review for Acknowledgment Transmittals Procedures

1. Conduct and document monthly managerial reviews to ensure internal controls are met for all remittance and non-remittance documents transshipped on Form 795-A and Form 3210 from the TACs.

2. Complete the monthly review for the remittance and non-remittance acknowledgement transmittals:



1. Once all transmittals are accounted for with acknowledgements of Form 795-A, Form 3210 or confirmed as required in IRM 21.3.4.7.12, Remittance Acknowledgments Transmittal Form 795-A and Form 3210 Process, and IRM 21.3.4.8.7.3, Non-Remittance Acknowledgement and Follow-up Procedures.

2. No later than the fifth (5th) business day after the close of the following month.



      ### Example:



      October 2021 remittance and non-remittance month reviews are due no later than December 7, 2021, the fifth business day after the end of the following month.


3. The GM must complete managerial reviews as listed below for each TAC locations:



1. Remittance documents - 100 percent review of all remittance transmittal documents.

2. Non-remittance – Sampling review of twenty (20) non-remittance transmittal documents. If less than 20 transmittals, 100 percent must be reviewed.


4. Monthly review and reconciliation of the remittance and non-remittance acknowledgement transmittals finding must be documented directly on the Transmittal Tracker for that month. Form 14698-A, Field Assistance TAC Document Transmittal Review and Reconciliation, must be completed to certify the monthly reviews are completed. A copy of the Transmittal Tracker with the GM’s monthly review findings must be attached to the completed and signed Form 14698-A.



1. Complete two Form 14698-As for each month. One for the remittance and one for the non-remittance transmittal reviews.

2. The monthly transmittals review must be documented on the Transmittal Tracker for that month. Add a detailed description of the finding next to the transmittal number and release date of transmittal reviewed.

3. If no finding, mark N/A.

4. If no remittances are transshipped during the month, complete and sign Form 14698-A and document the Transmittal Tracker "No documents transshipped during the month" .


5. Maintain two completed and electronically signed Forms 14698-A and two Transmittals Tracker listing GM’s findings with the associated month’s retention file for three years. Refer to IRM 21.3.4.7.12.4, Retention Files for Remittance Acknowledgment Transmittal Procedures, or IRM 21.3.4.8.7.4, Retention Files for Non-Remittance Acknowledgement Transmittals Procedures.

6. Reconciliation and reviews of the remittance and non-remittance are used as an evaluative record of the employee’s performance. Reviews are documented on Form 6067, Employee Performance Folder Record, and feedback discussed with the employee. Retain the original signed Form 6067 in the Employee’s Performance Folder (EPF).



### Note:



If the manager is on leave and has not completed the monthly transmittal binder review, the acting manager must ensure the review is completed.


**1.4.11.7.2** **(02-20-2024)**

#### Remittance Quarterly Reviews – Manager’s Requirements

1. Conduct a **quarterly** review of the remittance process for each TAC. Use the mandated Group Manager’s Data Collection Instrument (DCI) to document their quarterly required remittance reviews listed below. Follow additional instructions on the DCIs. Conduct the following applicable reviews for payment processing:




| Review Type | Review Process | Reference |
| --- | --- | --- |
| Safety and Security and General Payment Processing | 1. The GM must answer the questions on the Remittance Processing (RP)-General DCI.<br>      <br>2. The RP-General DCI must be completed at the end of the quarter, but no later than the third business day of the next quarter.<br>      <br>3. The RP-General DCI is used by the GM to answer the TSRRD Survey for that quarter. | IRM 21.3.4.7, Remittance Processing |
| Payments, Forms 795-A, Forms 3244 | 1. Conduct a review, consisting of three (3) days per quarter live observation of remittance before transshipped and/or processed using RSPCC or retention file review of the RSPCC retention files before payments are shredded.<br>      <br>2. The three days do not need to be consecutive days in the quarter.<br>      <br>3. All payments, posting documents and Form 795-A for each of the three days must be reviewed in their entirety.<br>      <br>4. This review must be documented on the GM DCI tabs "RP-F795A, F3244 1st Day, RP-F795A, F3244 2nd Day and RP-F795A, F3244 3rd Day" . | IRM 21.3.4.7, Remittance Processing |
| Non-cash payment observation | 1. Conduct a review, consisting of one non-cash payment live observation per quarter. This review must be documented on the GM DCI tab **“RP-Live Non-Cash”**. | IRM 21.3.4.7, Remittance Processing |
| RSPCC live or RSPCC batch | 1. Conduct a review, consisting of one RSPCC live observation or one RSPCC batch less than 60 days from the day of the review per quarter. If possible, a live RSPCC batch must a reviewed, unless during a TAC visit, there is no live RSPCC batch available for review.<br>      <br>2. This review must be documented on the GM DCI tab "RP-RSPCC" .<br>      <br>3. Manager must complete the following section of the RSPCC DCI:<br>      <br>      <br>      <br>      > RSPCC General Questions<br>      <br>      <br>      <br>      <br>      <br>      > RSPCC Scanner Review<br>      <br>      <br>      <br>      <br>      <br>      > RSPCC Key Verifier Review | IRM 21.3.4.7.11, Non-Cash Payment Processing using Remittance Strategy for Paper Check Conversion (RSPCC) |
| RSPCC Retention Files Batch | 1. Conduct a review, consisting of three RSPCC batches that are more than 60 days but less than 120 days from the RSPCC batch settlement date per quarter.<br>      <br>2. The three RSPCC batches do not have to be in the same quarter.<br>      <br>3. This review must be documented on the GM DCI tab "RP-RSPCC" .<br>      <br>4. Managers must complete the following section of the RSPCC DCI:<br>      <br>      <br>      <br>      > RSPCC Retention Questions<br>      <br>      <br>      <br>      <br>      <br>      > RSPCC General Question | IRM 21.3.4.7.11.14, RSPCC Retention File |
| Form 809 Receipt-Book<br> <br>### Note:<br>This remittance review is only required if the TAC **does not** have an approved permanent or temporary cash deviation for the entire quarter. | 1. Conduct a review consisting of a review of each Form 809 receipt-book per quarter.<br>      <br>2. Review Form 809 receipt-book assigned to each employee within each TAC location.<br>      <br>3. This review must be documented on the GM DCI tabs for "RP-Courier Service" .<br>      <br>4. Managers must complete the following section of the "RP-Courier Service" DCI:<br>      <br>      <br>      <br>      > Form 809 Book Questions | IRM 21.3.4.7.8, Cash Payments |
| IDRS employee’s profile<br> <br>### Note:<br>This remittance review is only required if the TAC **does not** have an approved permanent or temporary cash deviation for the entire quarter. | 1. Conduct a review, consisting of a review of the IDRS profile of the Form 809 book holder and IDRS inputter for cash payments per quarter.<br>      <br>2. Required to print command code SFDISP for each employee with Form 809 book and each employee performing IDRS input for cash payment.<br>      <br>3. Review print of command code SFDISP for Form 809 book holder and IDRS inputter.<br>      <br>4. This review must be documented on the GM DCI tabs for "RP-Courier Service" and "IDRS-IORS" .<br>      <br>5. Managers must complete the following section of the "RP-Courier Service" and "IDRS-IORS" :<br>      <br>      <br>      <br>      > IDRS Profile Questions<br>      <br>      <br>      <br>      <br>      <br>      > IDRS-IORS Questions | IRM 21.3.4.7.8.7, Separation of Duties for Cash Payments |
| Live cash payment observation<br> <br>### Note:<br>This remittance review is only required if the TAC **does not** have an approved permanent or temporary cash deviation for the entire quarter. | 1. Conduct a review consisting of one cash payment live observation per quarter. If possible, a live cash payment must be reviewed unless, during a TAC visit, there is no cash payment available for review.<br>      <br>2. Whenever possible, remote managers schedule their visits to the remote TACs on the day a cash payment is scheduled.<br>      <br>3. This review must be documented on the GM DCI tab "RP-Courier Service" .<br>      <br>4. Managers must complete the following section of the "RP-Courier Service" DCIs:<br>      <br>      <br>      <br>      > Live Cash Payments Observation Questions | IRM 21.3.4.7.8, Cash Payments. |
| Live Courier Service observation<br> <br>### Note:<br>This remittance review is only required if the TAC **does not** have an approved permanent or temporary cash deviation for the entire quarter. | 1. Conduct a review, consisting of a review of Courier live observation per quarter.<br>      <br>2. Whenever possible, remote managers schedule their visits to the remote TACs on the day a cash payment is scheduled.<br>      <br>3. This review must be documented on the GM DCI tab "RP-Courier Service" .<br>      <br>4. Managers must complete the following section of the "RP-Courier Service" DCIs:<br>      <br>      <br>      <br>      > IDRS Input Questions<br>      <br>      <br>      <br>      <br>      <br>      > OTCnet Preparer Questions<br>      <br>      <br>      <br>      <br>      <br>      > OTCnet Approval Questions | IRM 21.3.4.7.8.15, Accepting Cash Payments in TACs with Courier Service |
| Courier Service Retention File, FOOD SharePoint and courier issue log<br> <br>### Note:<br>This remittance review is only required if the TAC **does not** have an approved permanent or temporary cash deviation for the entire quarter. | 1. Conduct a review, consisting of three Courier retention files for payments processed during the quarter.<br>      <br>2. This is documented on the GM DCI tab "RP-Courier" .<br>      <br>3. Managers must complete the following section of the "RP-Courier Service" DCIs:<br>      <br>      <br>      <br>      > Retention File for Courier Service Questions<br>      <br>      <br>      <br>      <br>      <br>      > Field Office OTCnet Deposits SharePoint Questions<br>      <br>      <br>      <br>      <br>      <br>      > Courier Issue Log Questions | IRM 21.3.4.7.8.15.3, Courier Service Retention Files |





### Note:



If the manager is on leave and has not completed the quarterly remittance reviews, the acting manager must ensure the reviews are completed. If, however, any one of the required quarterly remittance reviews are not completed during the quarter, the GM must document the DCI(s) and the TSRRD survey to show the specific required remittance review not completed and provide a brief explanation for non-completion.





1. Manager must retain the completed DCIs and any additional documentation used to conduct remittance review not covered on the DCIs for three years.

2. Results of the remittance quarterly review are used to complete the TSRRD survey for remittance on a quarterly basis.

3. Results of the various remittance quarterly reviews may also be used as an evaluative record of the employee’s performance. Reviews are documented on Form 6067, Employee Performance Folder Record, and feedback discussed with the employee. Retain the original signed Form 6067 with the appropriate review documentation from the GM DCI in the Employee’s Performance Folder (EPF).


**1.4.11.7.3** **(01-02-2019)**

#### Remittance Strategy for Paper Check Conversion (RSPCC) Management Responsibility

1. Group managers must ensure that employees are following procedures to process all non-cash payments received in the TAC unless the payment cannot be processed using RSPCC. Refer to IRM 21.3.4.7.11, Non-Cash Payment Processing using Remittance Strategy for Paper Check Conversion (RSPCC).

2. To meet the 24 hours deposit standard, all non-cash payments must be processed using RSPCC on the day payment is received or no later than the next business day. A payment is considered processed once the payment is scanned, key verified, and submitted for deposit.

3. For TACs with one employee, the GM has the option to request limited key verification be completed by another office within the group. Refer to IRM 21.3.4.7.11.9, Request for Temporary Change or Permanent Change for One-Person TACs in Key Verification Requirements.

4. The GM must ensure that all RSPCC scanned batches of payment are balanced a minimum of twice per week as required per IRM 21.3.4.7.11.12, RSPCC Balancing.

5. The GMs must ensure that all RSPCC scanned batches of payment are approved for shredding and shredded as required per IRM 21.3.4.7.11.13, Reconciliation Report and Shredding.

6. Retention files for RSPCC are maintained in the TAC for each RSPCC batch of payments for three years as required per IRM 21.3.4.7.11.14, RSPCC Retention File. The retention files must be maintained as follows:



1. Within binder, folders, or envelopes (must be contained, cannot be loose in a drawer or box).

2. Properly marked with the month and year.

3. Documents filed in sequential order within that month.

4. Maintained in a metal locked file cabinet.


7. The GM must ensure that all batches of payments processed using RSPCC must include Form 14443, RPSID Label. Form 14443 must be completed as required per IRM 21.3.4.7.11.2, Completing Form 14443, RPSID Label.


**1.4.11.7.4** **(12-22-2021)**

#### Form 5919 – Teller’s Error Advice

01. The e-Trak 809 Database System is used to track serialized Form 809, Receipt for Payment of Taxes, issue Form 5919, Teller's Error Advice, notices to group managers and provide management reports.

02. Form 5919, Teller's Error Advice, is issued by the e-Trak 809 Database System to inform FA managers when critical errors are observed on any remittance documents.

03. The e-Trak 809 Database System generates and sends an email containing Form 5919, Teller's Error Advice, as information to the GM, along with a link to access the system for supporting documents.

04. Critical errors are those conditions that correlate to potential waste, fraud, abuse, theft, or embezzlement such as late remittances, remittance missing, official receipts issued out of sequence, incorrect money amounts, late cash conversion or missing cash conversion information. See IRM 3.8.47.7.1, Critical Errors, for a listing of critical error items. See IRM 21.3.4.7.8.2, Completing Form 809 Receipt, for instructions when a critical error is discovered after part 2 of Form 809 is issued to a taxpayer.

05. Group managers must notify the TM of any Forms 5919 that are issued to their group.

06. Generally, FA group managers are allowed 15 days from the date of issuance to follow-up on the Form 5919 via the e-Trak 809 Database System. If there is a business need, such as a remittance missing, the time frame for responding is shortened. See IRM 21.3.4.7.8.2, Completing Form 809 Receipt, for instructions when a critical error is discovered after part 2 of Form 809 is issued to a taxpayer. If a Form 5919 is not responded to by the response due date, then the system sends a second email to the GM as a reminder on the next business day.

07. If the second notice is not responded to timely, and there is a response required, then the e-Trak 809 Database System sends an email to the TM.

08. The manager must log in to the e-Trak 809 Database System to respond to or close an error notice associated with Form 5919. Managers must share Form 5919 notices with the responsible employee, obtain a response from the employee, and take any needed corrective actions. Refer to E-Trak 809 Database System (Group Managers User Guide). Managers must request access to the e-Trak 809 Database System through the Business Entitlement Access Request System (BEARS) as follows:



    1. Access BEARS.

    2. From _My Application_ screen click the request new application button.

    3. Type PROD USER ETRAK 809 DB and select the campus sub-application name.



       ### Note:



       Select Austin if FA areas 2 or 3. Select Kansas City if FA areas 1 or 4.

    4. Click the next button.

    5. In the _Special Instructions_ box, include the effective date, job title, and EEFax number.


09. The e-Trak 809 Database System aligns and validates employee to manager based on structure in HR Connect. It is important to ensure that employee's contact information on HR Connect is correct to ensure proper routing of Form 5919. Inform the designated SPC field office payment processing liaison of any changes to managers and the employees assigned to them by following the steps in (10) and (11) below.

10. Territory manager must advise their area remittance analyst of acting assignments. The area remittance analyst notifies the SPC of long-term acting management assignments and/or to request a manual Form 5919.

11. The Notification to SPC sites must be in writing and must include:



    - Manager’s complete name

    - Manager’s SEID

    - Manager's Badge number

    - Acting assignment effective date

    - Acting assignment ending date

    - Acting assignment par action completion date (if no par action completed write N/A)


12. A listing of the designated Submission Processing sites, a listing of key remittance processing contacts, and additional data regarding remittance processing is available on the SP Field Office Payment Processing site by selecting "SP Center Field Office Payment Processing Addresses and Key Contacts" .

13. The GM maintains a retention file for Form 5919, Teller Error Advice, for three years from the date of issuance.



    ### Exception:



    Forms 5919 issued on Form 809 receipts. Retention of Form 5919 on Forms 809 is three years from the date the last Form 809 in the book is issued.


**1.4.11.7.5** **(01-02-2019)**

#### Trends and Patterns Report for Territory Manager and Group Manager Responsibility

1. The monthly Trends and Patterns report is the vehicle Submission Processing uses to provide feedback to TAC territory managers on errors that impact business results or customer satisfaction.

2. The report is based on the Forms 5919 issued via the e-Trak 809 Database System and certified by the campus manager.

3. The SPC provides the Trends and Patterns Report to the TM by the fifth day following the end of the month when there is reportable data. Managers of record may access e-Trak 809 Database System to generate reports. Refer to the e-Trak 809 Database System Group Managers User Guide.



### Note:



If there are reportable data and the TM does not get the Trends and Patterns Report, please contact remittance campus manager. SPC field office payment processing addresses and key contacts can be found on the SP Field Office Payment Processing site.

4. The TM shares the Trends and Patterns report with the GM. The TM and GM review the report and corrective actions, as needed, and develop an action plan to address errors identified on the report.

5. The GM shares the results on the Trends and Patterns report with the employees, as appropriate, addressing any corrective actions required within an established deadline.

6. The TM maintains a file of the Trends and Patterns report with corrected action for a retention period of three years from the date the report is issued.

7. The TM forwards the monthly Trends and Patterns Report, and actions taken to address errors identified, to the area analyst and senior operations manager who informs the Area Director (AD).


**1.4.11.7.6** **(01-02-2019)**

#### Late Remittance Reports

1. The SPC provides the Late Remittance report to each FA AD by the fifth day of the month following the end of the month where there is reportable data. Refer to IRM 3.8.47.5.2.4, Late Remittance Report for Area Offices.

2. Timely, accurate payment processing translates to customer satisfaction and business results.


**1.4.11.7.7** **(10-09-2019)**

#### Loss of Payments

1. The TAC manager is required to ensure all monies collected are balanced daily.




| If an employee: |
| --- |
| 1. Has a cash shortage.<br>      <br>2. Receives counterfeit funds.<br>      <br>3. Is missing negotiable checks or other instruments. |
| --- |
| The manager must immediately take steps to minimize the loss. The manager must report any potential theft/embezzlement(s) to the TIGTA Office of Investigations at 800-366-4484 or the TIGTA website or the local TIGTA site, if available. |

2. Managers must follow the procedures in IRM 21.3.4.7.16, Loss or Shortage of Payments, whenever Losses and Shortages are identified.

3. The names and telephone numbers of the current Remittance Security Coordinator (RSC) can be found on the SP Security Remittance site.

4. All out of balance conditions must be identified and explained by the TAC GM. Include the statement of explanation with the accounting package to the SPC. If there is a cash shortage or overage, completion of Form 2424, Account Adjustment Voucher, digitally signed by the manager is required with the accounting package that is uploaded to the Field Office Over the Counter Deposit (FOOD) site. In addition, advise campus accounting to either debit or credit the account on IDRS. This adjustment can be initiated using IAT Tool. Refer to IRM 21.3.4.7.8.16, Loss or Shortage in TAC with Courier Service.

5. If contacted by campus accounting that an overlooked out of balance condition exists, a completed Form 2424 is required within 24 hours. Email the digitally signed Form 2424 to the campus accounting contact.


**1.4.11.7.8** **(01-02-2019)**

#### Cash Payments Accountability

1. Group managers brief employees on IRC 7804(c) when the Form 809 book is initially received. See IRM 3.17.243.10.12, Internal Revenue Code (IRC) 7804(c).

2. IRC 7804(c) imposes liability against any officer or employee of the Treasury Department who fails to account for and pay over any amount of money or property collected or received in connection with the Internal Revenue laws.

3. Group managers prepare a memorandum of the held briefing on IRC 7804(c) and maintain in the employee’s drop file. The GM and employee both sign and date the memorandum.

4. TAC employees are responsible to protect and safeguard monies that they have collected. In the event that an employee loses or fails to account for and pay over the money collected, an assessment for the loss may be made against the responsible employee and may be collected from the employee as if it were a tax.

5. For guidance on losses and shortages, refer to IRM 21.3.4.7.16, Loss or Shortage of Payments, and IRM 3.0.167, Losses and Shortages.

6. Group managers must ensure that they and their employees are familiar with procedures contained in IRM 21.3.4.7.8, Cash Payments.


**1.4.11.7.8.1** **(02-20-2024)**

##### Procedures for Ordering the Initial Form 809 Receipt-Book for an Employee

01. Submission Processing receipt and control branches issue Form 809, Receipt for Payment of Taxes, books (official receipts) to GM with the authorization from the AD. The Field Office Payment Processing Program campus managers are listed on the homepage of the e-Trak 809 Database System.

02. An initial Form 809 receipt-book must be requested by authorized memorandum from the GM or management official, approved by the FA AD and sent to the SPC.

03. A TAC’s GM prepares the memorandum authorizing the employee to receive a Form 809 receipt-book.

04. Notification of changes to territory and group management must be provided via email to the Form 809 aligned SPC deposit managers.

05. When a new or acting manager requests a Form 809 receipt book, obtain a signed memo from the territory manager before the new/acting manager can request books for the group.



    1. A secretary must not be assigned a Form 809 receipt-book.

    2. In an office with an IAR, it is recommended that the IAR is assigned the Form 809 receipt-book.

    3. The manager rotates the Form 809 receipt-book among employees on a yearly basis when the office is not staffed with an IAR. Rotating the Form 809 receipt-book among ITAS ensures the ITAS does not lose adjustment capabilities.


06. Managers must use command code RSTRK (with definer R) to restrict sensitive command codes from a Form 809 book holder’s profile. See _IRM 1.4.11.7.8.3_, Separation of Duties and Form 809.

07. Unless the Director, Field Assistance (DFA) approved a temporary or permanent cash deviation, issue at least one employee in each TAC a Form 809 receipt book.

08. Requests for temporary or permanent cash deviation may be submitted by memorandum from the AD to the DFA for TACs with less than three (3) permanent employees or staffed by circuit riders. Refer to IRM 21.3.4.7.8, Cash Payments.

09. When submitting a Form 809 receipt-book request, provide the employee's name, SEID, position title, address, telephone number and names of managers through the AD level and the operating division, TS or Small Business/Self Employed (SBSE). A copy of the authorization must be maintained in a locked metal container clearly labeled.

10. The FA employee must sign the Receipt Page found in front of the Form 809 receipt-book upon receipt of the book and return the signed receipt/acknowledgement to the issuing Submission Processing teller unit within five (5) business days after receipt. If the receipt page is inadvertently missing or lost, an acknowledgement memorandum must be prepared and provided to the SPC.


**1.4.11.7.8.2** **(02-20-2024)**

##### Annual Reconciliation of Official Form 809 Receipts

1. Once a year, FA managers must document review of Form 809 receipt books assigned to their employees in the e-Trak 809 Database System. The servicing SPC campus manager initiates the request with an annual Form 809 receipt Annual Reconciliation Report.

2. FA group managers log into e-Trak 809 Database System and input their completed reviews. Refer to IRM 3.8.47.6.17.1, Group Manager Procedure for Annual Reconciliation of Official Receipts.

3. The TM certifies the accuracy of the reviews. Refer to IRM 3.8.47.6.17.2, Territory Manager or Department Manager Procedure for Annual Reconciliation of Official Receipts.

4. For additional information refer to IRM 3.8.47.6.17, Annual Reconciliation of Official Receipts.


**1.4.11.7.8.3** **(01-02-2019)**

##### Separation of Duties and Form 809

1. Managers must follow the procedures in IRM 21.3.4.7.8.7, Separation of Duties for Cash Payments.



1. Employees who are Form 809 book holders or process cash payments have restricted command codes in their profile.

2. Employees who process non-cash payments only are not restricted and can have sensitive or adjustment related command codes in their profile.


**1.4.11.7.8.4** **(01-02-2019)**

##### Reordering Form 809

1. Reordering Form 809, Receipt for Payment of Taxes, books requires managerial approval.

2. TAC employees may request a new Form 809 receipt-book after the issuance of the 40th receipt in the current Form 809 receipt-book. This request must be signed by the manager.

3. At management discretion, TAC employees may request a receipt-book sooner than the 40th receipt.



1. A memo is required from the TAC manager requesting the issuance of a new Form 809 receipt-book before the issuance of the 40th receipt.

2. The memo must contain the information as required on the Preliminary Reorder Certificate.


4. If the TAC has a high volume of cash payments, with management discretion, more than one Form 809 receipt-book may be requested. The GM must submit a memo to SPC requesting the employee be assigned more than one Form 809 book at a time. The memo must contain the information as required on Preliminary Reorder Certification.

5. Refer to IRM 21.3.4.7.8.5, Procedures for Ordering/Reordering Form 809, and IRM 3.8.47.5.4, Procedures for Sending Tax Receipts to a Submission Processing Center.


**1.4.11.7.8.5** **(01-02-2019)**

##### Returning Depleted or Partially Used Form 809 Receipt-Book

1. Form 809 Receipt Books must only be used by the designated employee.

2. When a partially used receipt book is no longer required by the assigned employee (due to transfer, promotion, retirement, rotation of assignments, etc.), TAC managers must ensure that the remaining receipts are voided and return to the appropriate SPC campus. Refer to IRM 21.3.4.7.8.6, Returning Form 809 Receipt Book.

3. TAC managers must ensure that depleted and partially used receipt books (the book cover and parts four) are returned to the issuing SPC per IRM 3.8.47.5.4, Procedures for Sending Tax Receipts to Submission Processing Center.

4. Depleted or partially used Form 809 books must be returned to the SPC via traceable overnight mail.

5. Return depleted Form 809 book cover, and all 50 part four issued receipts to appropriate SPC that issued the Form 809 book within ten (10) business days of last receipt issued.

6. When no longer required due to position change (transfer, promotion, retirement, approved cash deviation, etc.), return partially used Form 809 receipt books with:



   - Form 809 book cover

   - VOIDED unused receipts and

   - Part four of used receipts


Send to the appropriate SPC that issued the Form 809 book within ten (10) business days. If the book is not returned with 30 calendar days, a Form 5919 could be issued.



7. Managers must check depleted or partially used Form 809 books to ensure part four of all used receipts are attached and unused receipts are voided when returning Form 809 books to SPC.

8. Return a depleted or partially used Form 809 books using Form 3210, _Document Transmittal_, to the issuing SPC campus via overnight mail.

9. Form 3210 must be signed by the TAC’s GM. If GM is not on site, the employee with the Form 809 book must overnight the book, double-wrapped, to the manager for review and approval.


**1.4.11.7.8.6** **(10-09-2019)**

##### Single Large Cash Payments

1. All TACs without a cash deviation are required to accept cash payments. Receipt of a single large cash payment requires additional security and other processing arrangements to ensure that cash is deposited in the Federal Reserve Bank within the 24-hour requirement. Refer to IRM 3.8.47.2.2, 24-Hour Deposit Standard.

2. The primary references for processing cash payments are as follows:



1. IRM 21.3.4.7.3, Receipt for Payments

2. IRM 21.3.4.7.8, Cash Payments

3. IRM 21.3.4.7.8.15, Accepting Cash Payments in TACs with Courier Service


**1.4.11.7.8.6.1** **(03-20-2020)**

###### Appointments for Single Large Cash Payments

1. All cash payment contacts require an appointment per IRM 21.3.4.2.4, Taxpayer Assistance Center (TAC) Appointment Service. For same day appointment exceptions, see IRM 21.3.4.2.4.2, TAC Appointment Exception Procedures.

2. The Field Assistance Scheduling Tool (FAST) automatically sends an email to the GM when a large cash payment over $10,000 is scheduled. The email comes from "service-now.com" .

3. Advise employees and ensure they NEVER discuss, even in general terms, scheduled cash payment appointments.

4. Regularly check the FAST appointment calendar to determine if **any** large cash payment appointments are scheduled and take appropriate actions.

5. When a large cash payment is scheduled, the GM:



1. Confirms the appointment date and time as scheduled.

2. Ensures appropriate staffing is available to accept and process the cash payment. At least two employees are required to count the large cash payment. If a Form 809 book holder or staffing resources are not available, follow the appointment process guidelines.



      ### Note:



      IDRS and OTCnet entries can be completed remotely. See IRM 21.3.4.7.8.7, Separation of Duties for Cash Payments.


6. Employees must process cash, so it is ready for scheduled same day appointment courier pick-up.

7. For cash appointments of over $10,000 in TACs without cash counting machines, the manager can schedule a back-to-back appointment using the hardship button in FAST if additional time (exceeding the two-hour limit) is needed to process the large cash payment.


**1.4.11.7.8.6.2** **(03-20-2020)**

###### Large Cash Payment Appointment Exceptions

1. Accounts Management CSRs schedule appointments for all TACs identified as accepting cash payments.

2. Group managers must regularly review employees’ FAST profile for to ensure employees who accept cash are profiled correctly.

3. If a cash appointment is scheduled in a TAC that does not accept cash due to an approved cash deviation, the GM must do the following:



1. Update the FAST appointment calendar to correct the setting to show the TAC does not accept cash.

2. Determine if the taxpayer can be assisted at the nearest TAC that accepts cash payments.

3. Forward the FAST cash email notification in a secured message.

4. Receiving GM contacts the taxpayer to apologize and reschedule the appointment.



      ### Note:



      Elevate erroneous scheduled appointment to the Area FAST analyst.


4. If the designated TAC accepts cash and the cash appointment is under $10,000, follow IRM 21.3.4.7.8.15, Accepting Cash Payments in TACs with Courier Service.

5. Follow the procedures below for large cash payments of $10,000 or more scheduled in a TAC without a cash counting room or designated space to accept cash.




| If | Then |
| --- | --- |
| TAC with a cash counting room or designated space is located within the state. | Forward the FAST cash email notification in a secured message to the GM of the nearest TAC with a cash counting room or designated space to accept cash. |
|  | The receiving GM contacts the taxpayer to apologize and reschedule the appointment. |
| TAC with a cash counting room or designated space to accept cash is not located within the state and the taxpayer must cross state lines to make the cash payment. | The GM and area analyst coordinates with FA HQ Financial Planning and Resources (FP&R) to arrange staffing, cash counting equipment/supplies, courier service and additional security, (as applicable) in the TAC accepting cash. |
|  | The GM contacts the taxpayer to apologize and schedule an appointment once the supplies and/or resources are in place. |
|  | TAC employees accept and process the large cash payment at the TAC. |


**1.4.11.7.8.6.3** **(02-20-2024)**

###### Taxpayer Assistance Center Cash Counting Room

1. In some locations, the frequency of large cash payments dictates the need for additional security. Some TACs have a cash counting room, large safe and cash counting machines.

2. Once the taxpayer is given a Qmatic ticket and called to employee’s workstation, the designated employee follows IRM 21.3.4.7.8.1, Procedures for Accepting Cash Payments.

3. The employee:



1. Completes IDRS research and actions required for the account.

2. Prints required IDRS payment command codes to complete Form 809, Receipt for Payment of Taxes.


4. Inside the cash counting room or designated space, the employee:



1. Explains to the taxpayer (and/or third party) how to proceed if an unexpected event; such as a fire alarm, natural disaster, etc. takes place during the cash counting process.

2. Returns the cash to the taxpayer if the Form 809 receipt part 2 is not issued.

3. Refers to IRM 21.3.4.7.8.1(9), Procedures for Accepting Cash Payments, if the employee or taxpayer must leave before the Form 809 receipt is issued.

4. Completes Form 809, Receipt for Payment of Taxes, as directed in IRM 21.3.4-2, Form 809 Instructions and Definition of Critical and Noncritical Fields after the cash is counted and the cash payment amount agrees with the amount the taxpayer indicates they are paying. Also see IRM 21.3.4.7.8.2, Completing Form 809 Receipt.



      ### Note:



      For third party cash payments, see IRM 21.3.4.7.8.1, Procedures for Accepting Cash Payments.

5. Provides Part 2 of Form 809 receipt to the taxpayer.

6. Completes the bank deposit slip(s).

7. Completes Form 10160-A, Field Assistance Receipt for Transport of IRS Deposit.

8. Completes Form 2679, Teller’s Daily Balance and Reconciliation.

9. Refers to IRM 21.3.4.7.8.15.1, Procedures for Processing Cash in TACs with Courier Service.


5. Limit the cash counting room to TAC staff required to process the cash payment. Never allow more taxpayers than employees in the room to mitigate risk and balance taxpayer to employee ratio. There must always be one more TAC employee than the number of taxpayers, so limiting the number of taxpayers to two is recommended.

6. Ensure employees follow _IRM 1.4.11.4.1.3_, Controlled Access Procedures, and IRM 10.2.14.3.6, Combination Control and Safeguarding.



### Example:



TAC has two safes: Safe A is designated for cash and Safe B is designated for non-cash remittances.


Safe A - access is limited to employees listed on Form 700 designated to accept cash.


Safe B - access is limited to employees listed on Form 700 and accept or process non-cash payments.

7. Do not use the cash counting room for any other purpose or to store any items not related to accepting cash payments.

8. The GM or designee orders and maintains supplies to process cash payments in the cash counting room. These include but are not limited to:



01. Bank deposit slip/book.

02. Large dispensable tamper evident bank deposit bags.

03. Large bag/envelope.

04. Form 10160-A, Field Assistance Receipt for Transport of IRS Deposit.

05. Form 2679, Teller's Daily Balance and Reconciliation.

06. Courier log, red book.

07. Non-latex gloves.

08. Cash counting machine printer tape.

09. Rubber bands.

10. A metal cabinet to lock supplies.


**1.4.11.7.8.6.4** **(03-20-2020)**

###### Courier Service Same Day Pick Up

1. To mitigate the risk of theft, cash payments are picked up daily by the courier.


**1.4.11.7.8.6.5** **(03-20-2020)**

###### Accepting Small Business/Self-Employed (SB/SE) Payments

1. Local SB/SE managers may contact TAC managers for processing large cash payments. Once contacted, FA provides the appointment scheduling toll-free number for the taxpayer to schedule an appointment, 1-844-545-5640.

2. If an appointment is not available through normal procedures outlined above, the local SB/SE manager (or designee) coordinates with the local Field Assistance Group Manager (or designee) to schedule an appointment at a TAC designated to accept large cash payments. Schedule appointments during office hours between 8:30 a.m. and 2:30 p.m. at least one week in advance.



### Note:



Deposit penalty may apply, where applicable. Local SB/SE handles any request(s) for abatement as outlined in IRM 20.1.4.26.1.1, Unbanked Taxpayers.

3. Employees process the cash payment using:



   - IRM 21.3.4.7.8, Cash Payments

   - IRM 21.3.4.7.3, Receipt for Payments

   - IRM 21.3.4.7.8.15, Accepting Cash Payments in TACs with Courier Service


### Note:

SB/SE employees have the option to observe the cash receipt process.

**1.4.11.7.9** **(01-02-2020)**

#### Disposal of Remittance and Non-Remittance Form 795-A and Form 3210 Retention Files

1. Annually, between September 15th and October 1st, the FA area Remittance Information Resource Coordinator (RIRC) notifies all group managers to complete the survey for "Disposal Form 795-A and Form 3210" retention files located on the Field Assistance (FA) Remittance SharePoint site for each designated area. Refer to:



   - IRM 21.3.4.7.12.4, Retention Files for Remittance Acknowledgement Transmittal Procedures

   - IRM 21.3.4.7.11.14, RSPCC Retention File

   - IRM 21.3.4.7.8.15.3, Courier Service Retention Files, for the requirement of retention period prior to requesting approval to dispose Form 795-A and/Retention Files for Remittance Acknowledgement Transmittal Procedures or Form 3210

   - IRM 1.15.3, Disposing of Records

   - Document 12990, Records Control Schedules, for NARA-approved records retention and disposition requirements


2. The manager of record must complete the survey for "Disposal Form 795-A and Form 3210 retention" for each TAC location within their group located on the FA Remittance SharePoint site.

3. The FA area RIRC point of contact:



1. Extracts from the Field Assistance (FA) Remittance SharePoint Disposal Form 795-A and Form 3210 report listing custodial TAC office locations where retention files for approval of disposal are requested.

2. Completes and electronically signs Form 11671, Certificate of Records Disposal.

3. Submits via email the Disposal Form 795-A and Form 3210 retention file report and a completed and signed Form 11671 to the area Privacy, Governmental Liaison and Disclosure (PGLD) records specialists for approval. Refer to the Records and Information Management Area Specialist Map for area contact information.

4. Updates the survey for "Disposal Form 795-A and Form 3210" retention files with the date Form 11671 is sent to the PGLD records specialists for approval.


4. The PGLD records specialists reviews, approves and electronically signs Form 11671 and forwards the approved Form 11671 back to the FA area RIRC point of contact.

5. The FA area RIRC point of contact:



1. Accesses the FA Remittance SharePoint site for this area.

2. Updates survey with the records specialists approved date listed on Form 11671 for each TAC location.


Once the FA Remittance SharePoint survey is updated, the manager of record will receive an automatic email notification to destroy the approved Form 795-A and Form 3210 retention files.



6. The manager of record or designee must:



1. Destroy the approved Form 795-A and Form 3210 retention files within 30 days from the email notification date using a shred bin or shredder once the email notification is received. See IRM 10.5.1.6.10, Disposition and Destruction.

2. Update the SharePoint Survey for "Disposal Form 795-A and Form 3210" retention files with the date the files are destroyed once the files are destroyed.



      ### Note:



      If the disposed records cannot fit within the facility’s shred bin(s), manager or designee can open an OS Get Services ticket to request the required services. FMSS oversees the shred program.


7. The FA area RIRC point of contact uploads to the Remittance SharePoint Retention File site:



1. Approved Form 11671 electronically signed by PGLD.

2. Report for "Disposal Form 795-A and Form 3210" retention files document listing the date Form 11671 is sent to PGLD, the date approval is received from PGLD, and the date of disposal of files for each of the TAC locations listed.

3. Naming convention for these files:



      ### Example:



      Area 1 – Fiscal Year 2017 Approved Form 11671





      ### Example:



      Area 1 – Fiscal Year 2017 Disposal Form 795-A and Form 3210 report

4. These documents must be maintained for six (6) fiscal years.


**1.4.11.7.9.1** **(01-22-2019)**

##### Deviation for Quarterly Disposal of Remittance and Non-Remittance Form 795-A and Form 3210

01. An "approved deviation" allows the TAC to dispose of Form 795-A and Form 3210 more frequently than annually; however, approval must be granted by the area director.

02. Territory manager can request a quarterly "temporary" deviation to dispose of Form 795-A and Form 3210.

03. The request can be sent via email. The email must provide specific details to include the reason for the request (e.g., space issues).



    ### Note:



    Deviation from the annual requirement to dispose of Form 795-A and Form 3210 must be requested for each occurrence.

04. The area approves or disapproves the request for a temporary deviation for quarterly disposal of Form 795-A and Form 3210.

05. On all approved requests, the area notifies:



    1. Field Assistance Headquarter (FAHQ), Financial Planning and Resources (FP&R).

    2. Field Assistance Area Remittance Information Resource Coordinator (RIRC) of their concurrence via email.


06. The FA area RIRC point of contact notifies the GM of record to complete the survey for "Disposal Form 795-A and Form 3210" retention file for the approved TAC location.

07. The GM of record must complete the survey for "Disposal Form 795-A and Form 3210" retention file for the approved TAC location.

08. The FA area RIRC point of contact:



    1. Extracts from Field Assistance Remittance SharePoint site Disposal Form 795-A and Form 3210 report listing custodial TAC office locations where retention files for approval of disposal are requested.

    2. Completes and electronically signs Form 11671, Certificate of Records Disposal.

    3. Submits via email the Disposal Form 795-A and Form 3210 report and a completed and signed Form 11671 to the area PGLD records specialists for approval. Refer to the Records and Information Management Area Specialist Map for area contact information.


09. The PGLD records specialists reviews, approves and electronically signs Form 11671 and forwards the approved Form 11671 back to the FA area RIRC point of contact.

10. The FA area RIRC point of contact:



    1. Accesses the FA Remittance SharePoint site for their area.

    2. Updates survey with the records specialists approved date listed on Form 11671 for each TAC location.



       ### Note:



       Once the FA Remittance SharePoint survey is updated, the manager of record receives an automatic email notification to destroy the approved Form 795-A and Form 3210 retention files.


11. The manager of record or designee must:



    1. Once the email notification is received, destroy the approved Form 795-A and Form 3210 retention files within 30 days from the email notification date using a shred bin or shredder. See IRM 10.5.1.6.10, Disposition and Destruction.

    2. Once the files are destroyed, update the SharePoint Survey "Disposal Form 795-A and Form 3210" retention files survey with the date the files are destroyed.


### Note:

If the disposed records cannot fit within the facility’s burn bin(s), manager or designee can open an OS Get Services ticket to request the required services. FMSS oversees the shred program.

12. The FA area RIRC point of contact uploads to the Remittance SharePoint Retention File site:



    1. Email notification with approved "temporary" deviation to dispose of Form 795-A and Form 3210.

    2. Approved Form 11671 electronically signed by PGLD.

    3. Report for "Disposal Form 795-A and Form 3210" retention files document listing the date Form 11671 is sent to PGLD, the date approval is received from PGLD, and the date of disposal of files for each of the TAC locations listed.

    4. Naming convention for these files:



       ### Example:



       Area 1 – Quarter 1 Approved Form 11671





       ### Example:



       Area 1 – Quarter 1 Disposal Form 795-A and Form 3210 Report





       ### Example:



       Area 1 – Quarter 1 Approved Deviation for (TAC Name or Names)

    5. These documents must be maintained for six fiscal years.


**1.4.11.8** **(02-20-2024)**

### Account Management Services (AMS) - Manager Responsibilities

1. AMS provides the ability to share business data, increases the availability of key tools to IRS employees, and integrates the access of these capabilities into a common interface.

2. Managers are responsible for ensuring that all employees have access to AMS when researching taxpayer account inquiries. These responsibilities include:



1. Verifying IDRS access for all employees to use AMS.

2. Initiating BEARS request for new employees needing access to AMS.

3. Performing AMS Profile Management to verify and profile AMS application tools for each employee.

4. Ensuring all employees are trained and equipped to use AMS for all account issues.

5. Ensuring all employees use the appropriate checklist adhering to the AMS IRM requirements.

6. Ensuring employees understand the required usage of AMS for all account related inquires.

7. Monitoring employee's AMS usage via contact recording and/or other appropriate monitoring tools to ensure employees are using the system as required.


**1.4.11.8.1** **(01-02-2019)**

#### Account Management Services (AMS) Group Messages

1. Use the AMS group message as appropriate for your group.

2. Group messages can be cut and pasted from email.

3. Group messaging has a 2000-character limit.

4. To send a group message, click on:



   - "Group" (under Message Center)

   - "Create New"

   - Submit


**1.4.11.8.2** **(01-02-2019)**

#### Territory Manager Responsibilities for Account Management Services (AMS)

1. Territory managers:



1. Support the required use of AMS.

2. Ensures SMEs are available during AMS training and to provide On-The-Job Instruction (OJI) support.

3. Review territory inventory reports for timely closures and timely taxpayer contact of in-house inventory.

4. Include the required use of AMS as part of operational reviews.


**1.4.11.8.3** **(01-02-2019)**

#### Area Director Responsibilities for Account Management Services (AMS)

1. Area directors:



1. Support the required use of AMS.

2. Ensures SMEs are available during AMS training and to provide On-The-Job Instruction (OJI) support.

3. Review the required use of AMS as part of operational reviews.


**1.4.11.8.4** **(02-20-2024)**

#### Account Management Services (AMS) System Security Officers (SSOs)

1. Each area is assigned a SSO who has program oversight and is responsible for maintenance and upkeep of the AMS database.

2. SSOs are responsible for the following duties:



1. Approving Account Management Service access requests in BEARS.

2. Performing routine administration and maintenance of employee and group profiles as directed.

3. Transferring employees from group to group and updating profiles when necessary.

4. Performing checks to ensure employees are using AMS as the primary research tool for all account inquiries, per IRM requirement.

5. Staying abreast of the new features and functionality of AMS.


**1.4.11.9** **(01-02-2019)**

### Integrated Automation Technologies (IAT) - Manager Responsibilities

1. IAT is a computer tool used with IRS systems to improve quality and timeliness of tax processing by eliminating repetitive typing and making precise decisions.

2. IAT allows employees to perform the following tasks:



1. Initiate multiple Credit Transfers at a time.

2. The Manual Refund process.

3. Payment Tracer functions.

4. Document 6209 lookup functions.

5. Monitoring of cases or inventory work.

6. Address changes (Employee may use AMS or IAT to process address changes).


3. Managers ensure that all employees receive training on the use and application of IAT.

4. Managers can identify a senior ITAS or Grade 11 to process Manual Refund requests for their group.


**1.4.11.9.1** **(02-20-2024)**

#### Manual Refunds Using Integrated Automation Technologies (IAT)

1. Refunds are generated through normal Master file processing and are identified with a TC 846; however, in special circumstances a manual refund may be needed. See IRM 21.4.4, Manual Refunds.

2. The ITAS uses IAT manual refund tool to initiate and process a manual refund. The IAT manual refund tool automatically completes Form 5792, Request for IDRS Generated Refund and Form 3753, Manual Refund Posting Voucher.

3. Management appoints and delegates authority to specific persons to sign and authorize manual refunds. This is to maintain the internal controls standards required by General Accountability Office with respect to disbursements.

4. The area directors must submit a Manual Refund Signature Authorization Form annually by October 1, to campus accounting manual refund unit delegating those persons authorized to sign and approve manual refunds. See IRM 3.17.79.3.5, Employees Authorized to Sign Requests for Refunds, for further information.

5. At the discretion of the area director, group and territory managers can be delegated the authority to sign manual refund requests. Areas identify which group managers, territory managers or area directors sign manual refunds. Refer to:



1. IRM 21.4.4, Manual Refunds, to verify that correct procedures are followed prior to approval.

2. IRM 21.4.4-3, Accounting Function - Manual Refund Team Contact Information for a complete listing of addresses and contacts.

3. IRM 10.2.14.1.3, Responsibilities for the responsibilities to maintain effective controls to prevent fraud, waste or abuse of government resources and mismanagement of service programs.

4. IRM 1.4.16.4.11, Manual Refunds - Training Requirements.


6. When approving Manual Refund Form 5792, the manager reviews the "Remarks box" to ensure employees include the verbiage TS:FA:CARE. Employees select TS:AM as the FA BOD.

7. Each time a manual refund is approved, send an email notification to the TM with a copy to upper management (SOM, area account analyst, and other(s) designated by the area). The area account analyst sends a copy of the email notification to the HQ accounts analyst. In the subject line include the following: **MR Approved – date** (e.g.,11/19/2020).


**1.4.11.10** **(10-01-2025)**

### Individual Taxpayer Identification Number (ITIN) Authentication

1. ITAS employees in a limited number of TACs authenticate original supporting identification documents. See IRM 21.3.4.19.1.1(5), ITAS Responsibilities for Processing New Form W-7 Applications in the TAC, for a list of supporting identification documents.

2. All TACs with proper spacing to set up an authentication room and at least one employee (including part time and seasonal) assigned to the TAC authenticates ITIN documents. For a list of TACs with authentication trained employees see [Taxpayer Assistance Center Locations Where In-Person Document Review is Provided](http://www.irs.gov/uac/TAC-Locations-Where-In-Person-Document-Verification-is-Provided).

3. A TAC can submit a request to temporarily suspend authenticating ITIN documents if the ITIN equipment or room where the equipment is located is not operable.

4. Include the following information on a memorandum for an equipment or room not operable request:



   - The problem the TAC is encountering

   - Actions taken to resolve the problem

   - Specific amount of time that it takes to resolve the issue


5. Once the request is submitted and approved, the HQ ITIN analyst updates [IRS.gov](https://www.irs.gov/) and records and tracks the deviation.

6. Once the problem is resolved, and authentication can resume, the area ITIN analyst notifies the HQ ITIN analyst via email the effective date of when the TAC can start ITIN authentication.


**1.4.11.11** **(09-30-2008)**

### Managing Outlying Taxpayer Assistance Centers (TACs)

1. Managers may be responsible for supervising employees in offices other than where the manager is located. Regular communications with employees in outlying TACs is essential in achieving a successful and smoothly run TAC operation.

2. Oversight and assessment for each office that the manager is responsible for is equally important and aids in determining training needs, employee performance, and in identifying areas or processes that need improvement. Managers need to monitor each employee's work to ensure that the work performed meets IRS requirements as outlined in IRM 21.3.4, Field Assistance.


**1.4.11.11.1** **(11-01-2010)**

#### Commissioner's Representatives (CR) in Outlying Taxpayer Assistance Centers (TACs)

1. Each outlying TAC has a Commissioner's Representative (CR)/Administrative Officer (AO) who is responsible for the office/building.

2. It is the manager's responsibility to keep the CR/AO informed of TAC office closings or any problems (within the CR's area of responsibility) that the TAC may encounter in carrying out its function.

3. It is important to keep open lines of communication with management in other functional areas.


**1.4.11.11.2** **(01-02-2016)**

#### Schedule Routine Visitations

1. Managers must maintain close contact with employees in outlying TACs because their relative isolation tends to lessen their involvement with management.

2. Make routine visits to the TAC and maintain documented evidence of managerial reviews, as outlined in _IRM 1.4.11.19.10_, Territory Manager Mandatory Reviews, Reports and Certification and _IRM 1.4.11.19.9_, Group Manager Mandatory Reviews, Reports and Certification. Validate these reviews quarterly by inputting the review results in the TSRRD. See _IRM 1.4.11.4.1_, TAC Physical Security Requirements.

3. If items identified during a visit are the responsibility of the Commissioner's Representative (CR), schedule a discussion.


**1.4.11.12** **(01-22-2018)**

### Hours of Operations and Taxpayer Assistance Center (TAC) Closing Procedures

1. Full-time offices are open from 8:30 a.m. until 4:30 p.m. Monday through Friday, and have full-time staff five days a week, eight hours a day, 12 months a year (except for federal holidays).

2. Half an hour at the beginning of each day is provided, before the TAC opens, to allow time for employees to prepare time reports, read new procedures and information, conduct directed learning, hold group meetings, and prepare for the day’s taxpayer-related activities.

3. Schedule lunchtime for employees during times with the lower traffic periods of the day. Smaller offices (1 or 2 technical employees) with insufficient FA staff to remain open throughout the day, may close to allow the employee(s) time to take their lunch. Offices with 3 or more technical employees available to work must remain open during lunch.

4. Ensure TAC employees only provide appointment assistance to taxpayers within the regularly scheduled TAC hours. Any decision to keep a TAC open beyond the regular business hours requires supervisory approval.


**1.4.11.12.1** **(05-15-2020)**

#### Changes in Hours of Operations

1. Use FAST to initiate and approve a Change in Hours of Operation Request (CHOR). Please refer to the [Job Aid: FAST – CHOR Emergency Closure](https://irsgov.sharepoint.com/sites/WI/SitePages/FAST.aspx?csf=1&web=1&e=NTH1fh&cid=be9b96c4-efbc-4e7e-a1de-9785de2647d6) for guidance.



### Exception:



If you are designated to initiate a CHOR during the absence of the GM or TM and you are not able to approve a FAST CHOR, you must notify the area analyst to ensure the CHOR is approved timely.

2. Field Assistance TMs or designees approve temporary office closures of two or less consecutive business days. FA ADs or designee(s) approve temporary office closures of more than two consecutive business days. Partial day closures of more than two consecutive business days require AD or designee approval, including lunch closures of more than two days.



### Note:



Each TM and AD must establish delegates in the FAST system.

3. When a temporary office closure is approved, FAST automatically places a block on the calendar so that new appointments cannot be made.

4. When a temporary office closure is approved, FAST automatically sends an email to the taxpayer canceling their scheduled appointment, if they provided an email address. Ensure an attempt is made to contact all taxpayers with canceled appointments due to the closure, even those who provided an email address, to reschedule the appointment.

5. Upon approval of the closure, FAST automatically creates and sends an email to the following stakeholders:



01. Area director

02. Area technical advisor

03. Area senior operations manager

04. Area security analyst

05. HQ security analyst

06. FMSS HQ security analyst (requires notification only when a temporary TAC closure impacts a TAC guard)

07. FMSS TM (requires notification only when a temporary TAC closure impacts a TAC guard)

08. Legislative affairs representative

09. Media relations representative

10. Senior commissioner’s representative

11. NTEU representative for the TAC

12. Local taxpayer advocate office

13. AM BOD Administrator

14. Director, Field Assistance (requires notification when a temporary closure is approved or when unusual instances occur, such as flooding, shootings, personal injury, hazardous material, etc.)


6. At TM discretion, notify additional stakeholders of office closures.

7. Ensure the accuracy of stakeholder information for each TAC location in your group.

8. **Cancelling a CHOR** \- When necessary, you may cancel approved CHORs in FAST. FAST deletes the block on the location and opens appointment availability. FAST does not automatically send email notification to the stakeholders when a CHOR is canceled. The designee cancelling the CHOR must notify the stakeholders via email when a CHOR is cancelled and when the TAC reopens.

9. **Updating IRS.gov** \- IRS.gov is updated for all approved CHORs with the following exceptions:



1. Same day closure of less than a full day.

2. Inclement weather closure of any duration.

3. When the notification of the need to close the TAC is not received prior to the regularly scheduled opening of the TAC (e.g., employee not required to call in until two hours after start of TOD).


**1.4.11.12.2** **(01-22-2018)**

#### Closing a Taxpayer Assistance Center (TAC)

1. **Temporary Closings** \- Temporarily close a TAC only as a last resort to minimize the adverse impact on taxpayers and other functions at that location.

2. Temporarily closed TACs may occur in smaller TACs (generally one or two-person staff) for the following reasons:



1. Employee(s) attending training.

2. Immediate or extended illness of employee(s).

3. Staff vacancy (e.g., retirement, resignation).

4. No FA employees available within a reasonable distance (i.e., commuting area) from TAC.


3. Before temporarily closing a TAC for an extended period (eight consecutive days), the AD must determine the need to provide an employee from another TAC on a daily or part-time (limited hours or days) basis.



### Note:



DFA approval is required for all circuit riding.

4. **Release of TAC Space:** The TS Commissioner, in consultation with the IRS Commissioner and the Deputy Commissioner for Services and Enforcement, have the final approval authority to permanently release TAC space.


**1.4.11.12.2.1** **(10-02-2019)**

##### Actions Taken When Relocating or Releasing a Taxpayer Assistance Center (TAC)

1. The area office ensures the appropriate actions are completed to implement the communication plan within 90 days prior to the TAC relocating. Listed on the FA Insider is the TAC Relocation/Closure Checklist that must be completed to facilitate proper communication of the upcoming TAC move.

2. Headquarters advises the national Governmental Liaison and other stakeholders of the TAC relocation 90 days prior to the actual relocation or release.

3. The director of FA notifies the director of CARE of the effective date of the TAC relocation.

4. **Release of TAC Space:** The TS Commissioner, in consultation with the IRS Commissioner Deputy Commissioner for Services and Enforcement, have the final approval authority to permanently release TAC space.


**1.4.11.13** **(05-15-2020)**

### Publishing Taxpayer Assistance Center Information

1. To ensure taxpayers know where they can locate a TAC, it is critical that information on [IRS.gov](https://www.irs.gov/), Section 3709-Line recorded messages, and TAC signage all have correct and consistent information.

2. It is the area director's responsibility to ensure complete, correct and consistent addresses with hours of operation are published on [IRS.gov](https://www.irs.gov/) and TAC signage. Area directors are responsible for ensuring [IRS.gov](https://www.irs.gov/), Section 3709-Line recorded messages and TAC signage are reviewed for uniformity on a regular basis.

3. The [IRS.gov](https://www.irs.gov/) website reflects the following information in the prescribed format shown below and adhere to the IRS Style Guide standards:



1. **City** (IRS website only) - Each TAC is listed by the city in which it is located. If a TAC is located in a unique area, two city names are separated with a slash (e.g., Plantation/Ft. Lauderdale). If a city contains more than one TAC, a location description may be included in parenthesis (e.g., New York (Harlem); Houston (NW).

2. **Street Address** \- Each street address must be limited to only necessary data. Street number, street name, city, state and zip code.

3. **Hours of Operation** \- Each listing must be complete. Individual days/times must be spelled out (e.g., Monday - Friday 8:30 a.m. - 4:30 p.m.)

4. **Lunch Closings** \- Closings for lunch must be entered in a consistent format.

5. **Section 3709-Line Telephone Numbers** \- Telephone numbers are entered in the following format 999-999-9999.


4. CPRs are required for the following:



   - Address changes

   - Telephone number changes

   - Indefinite/Permanent TAC closures


5. Updates to any TAC information on [IRS.gov](https://www.irs.gov/) uses the procedures prescribed by Online Services.


**1.4.11.13.1** **(11-21-2016)**

#### Posting Taxpayer Assistance Center (TAC) Hours of Operation

1. Hours of operation, including lunch closings, must be posted using Form 13358, Taxpayer Assistance Center Hours of Service Insert (EN/SP).

2. TAC signage must be updated/changed as necessary to reflect the information posted on [IRS.gov](https://www.irs.gov/). All closings must be posted on the TAC door for the duration of the time the TAC is closed.


**1.4.11.13.2** **(05-15-2020)**

#### Posting Taxpayer Assistance Center (TAC) Closings

1. **Temporary Closings -** Immediately notify the management chain of command when it is necessary to temporarily close a TAC for a period of one business day or more due to unscheduled employee absence or other circumstances beyond control. The [IRS.gov](https://www.irs.gov/) website and TAC signage is updated.

2. Update IRS.gov and TAC signs for planned closures of any duration.



### Exception:










| Do not update [IRS.gov](https://www.irs.gov/) for the following situations: |
| --- |
| 1. Same day closure of less than a full day.<br>      <br>2. Inclement weather closure of any duration.<br>      <br>3. When the notification of the need to close the TAC isn’t received prior to the regularly scheduled opening of the TAC (e.g., employee not required to call in until two hours after start of TOD). |

3. Updates must be consistent and use appropriate professional language.



### Example:



"This office is closed 1/21" .

4. If an office is closed indefinitely, [IRS.gov](https://www.irs.gov/) and TAC signage is updated to say, "This TAC is currently closed" .



### Note:



These updates require an approved Content Publishing Request (CPR). The Section 3709-Line recorded message uses the appropriate script. See _Exhibit 1.4.11-1_, Field Assistance Section 3709-Line Telephone Scripts.

5. **Holiday Closings -** [IRS.gov](https://www.irs.gov/) includes language that states the TACs, SSA offices and VSD sites are closed for all federal holidays. [IRS.gov](https://www.irs.gov/) includes links to an OPM web page listing all federal holidays. Update TAC signage to reference holiday closures no less than three days prior to closure. Update signage to reflect normal business hours the next business day.


**1.4.11.13.3** **(01-02-2019)**

#### Section 3709-Line Recorded Messages

1. Field Assistance headquarters program analysts conduct reviews and certify annually that the TAC location address and phone number is consistent and correct by monitoring the designated local telephone directory and documenting the results on SharePoint.

2. The Section 3709-Line recorded message must use the approved FA script (see _Exhibit 1.4.11-1_, Field Assistance Section 3709-Line Telephone Scripts). Any deviations from the prescribed script must follow the approval authority guidelines.

3. The director of FA or designee must approve any deviations from the prescribed format. The area director or designee submits the request via email to the HQ analyst(s) responsible for [IRS.gov](https://www.irs.gov/) and the Section 3709-Line recorded message programs.


**1.4.11.14** **(01-22-2018)**

### Field Assistance Insider Guidelines

1. The _Insider_ is TS’s intranet site that is maintained by TS C&L. It features:



   - Links to all TS function web pages

   - News articles about TS initiatives and activities

   - Friendly reminders of current and upcoming events

   - _Your Neck of the Woods_, activities of local interest across the country


2. The _Insider User Group_, composed of TS C&L webmasters, works with content owners from each of the TSfunctions to produce and maintain each function's intranet pages.

3. All FA employees who own content on the Insider must do the following:



1. Work with FA webmaster who reviews, approves, and forwards information to the TS C&L webmaster for posting.

2. Verify all content is original. If the content appears elsewhere on intranet or internet, use a link to the original content.

3. Request any outdated content be deleted, unless the content needs must be retained for historical purposes. Any retained content is housed on the FA Insider Archive page.

4. Obtain approval for all new content. All new content must be approved by the applicable area director or HQ section chief. Areas must approve any content that originates from the area (such as TAC or Face of the Month). HQ sections must approve any content originating from the section (such as the TAG Newsletter or program procedural or technical information). An email acknowledgement (approval) from the area director or HQ chief must be included when requesting an item for posting to the FA Insider.


4. On a semiannual basis (June and December), the HQ Intranet program analyst reviews the FA Insider to ensure the information is timely and accurate. During the December review, the information on the FA Insider is certified by the HQ program analyst responsible for the program information.


**1.4.11.15** **(01-03-2017)**

### Work Planning and Scheduling

1. Work planning and scheduling are the foundation upon which successful FA programs are built. The purpose of the work planning and strategy plan is to enable FA to realistically plan or project the use of resources or accomplishments to meet taxpayer needs.

2. Work planning can be defined as planning according to needs, and scheduling defined as planning according to resource availability, this includes placing blocks and banners on the TAC appointment calendars.

3. When preparing a local schedule, it is necessary to analyze each portion of the TAC operation to maintain standardized services, whether responsible for a large TAC or a small, outlying TAC.


**1.4.11.15.1** **(07-01-2010)**

#### Scheduling for Staffing Needs

1. Determine the staffing needs for the scheduling period by analyzing volume statistics. These statistics can be obtained from prior year data. Business Objects reports are the best source for this type of information.

2. Business Objects reports provide data on workload volumes for the week, month, planning period and fiscal year. This data is provided on a weekly basis and is updated every Thursday.

3. Factors to consider when analyzing statistical data may include, but is not limited to:



1. Type of employee available for assignment to special TAC activities.

2. Expectations of employee's performance and expertise related to the type of work performed.

3. Volume of work anticipated.


4. An analysis of weekly data enables management to identify trends, patterns, need for additional staff and anomalies. Effective analysis helps with planning, scheduling, and using resources more efficiently.


**1.4.11.15.2** **(01-03-2017)**

#### Scheduling Considerations

1. Skill in maintaining a flexible staff and balancing the workload determines the overall success of the TAC operation.

2. Block the TAC appointment calendar to show limited staffing and ensure taxpayers with appointments receive timely service.

3. Examples of workload demands include:



   - Ordering forms and publications

   - Remittance Processing

   - Referrals

   - Adjustments

   - Correspondence

   - Directed Learning

   - Formal training

   - Away from office

   - Leave


**1.4.11.16** **(02-20-2024)**

### Capturing Field Assistance Contacts

1. It is critical that FA has timely, accurate reporting and monitoring of resource and workload information. Each TAC employee (including detailees) is responsible for correctly inputting the type of assistance they provide and length of contact and retaining a record.

2. Each GM is responsible for ensuring that each TAC employee (including detailees) accurately reports time charged to FA, correctly captures and records the type of assistance provided and the length of contact.



1. FA employees use Qmatic/Orchestra to capture contacts systemically.

2. Contact is not closed on Qmatic/Orchestra until all actions are complete.


3. Form 13864, Field Assistance Contact Sheet, is required to be used by the employees if Qmatic/Orchestra goes off-line or when conducting direct off counter work. Time on Form 13864 is recorded in minute increments.

4. Form 6148, Walk-In Contact Card, is used as a traffic management tool if the Qmatic/Orchestra ticket printer is not operational. Form 6148 is sequentially numbered and tracks wait time.

5. Form 5311, Taxpayer Service Activity Report, in the FAMIS application must be used by all employees to report the units and time on FAMIS. Then, units and time must be compared to the Qmatic/Orchestra 272d report (or the QMP Staff performance and Matter Report) data that auto-populated on Form 5311 to ensure accuracy.

6. Group managers or delegate must:



1. Review each employee's FAMIS Form 5311 for their respective TACs each week to ensure corrections are made prior to transmission.

2. Extract and electronically save or print the FAMIS Summary Report for each TAC in your group.



      ### Note:



      It must be extracted after the Form 5311s are submitted; but before Form 5311s are approved.

3. Make comments of the review on the electronically saved or printed report.

4. Sign and date each electronically saved or printed report after completion of the review.

5. Maintain the electronically saved or printed report for one year after the review is completed.

6. Approve the Form 5311s for their respective TACs by close of business (COB) Tuesday (the following week). If an error is found after the manager has approved Form 5311, the area analyst may be contacted up until COB on Wednesday to make a correction.


7. Data is transported to Business Objects on Thursday morning for the prior week's activity; therefore, any approvals/corrections not completed prior to COB Wednesday requires an open window request.


**1.4.11.16.1** **(02-20-2024)**

#### Form 13864 - Field Assistance Contact Sheet

1. Ensure employees use Form 13864, Field Assistance Contact Sheet, Qmatic/Orchestra, and FAMIS for the following scenarios:



1. When Qmatic is not available.

2. When conducting direct off counter work.


See IRM 21.3.4.6, Time Reporting for TAC Employees.



2. When using Form 13864, ensure employees:



1. Record contacts in actual minutes.

2. Save form to the computer’s hard drive and/or print.

3. Manually enter captured data into FAMIS, not Qmatic/Orchestra.

4. Submit Form 13864 for management review and retention (electronic or paper copy) after correctly entering data on FAMIS Form 5311.



      ### Note:



      Form 13864 is maintained for two months if prepared during filing season or one month if prepared during non-filing season.

5. Complete Form 5311 from Form 13864 for direct units and time if Qmatic/Orchestra is down for an entire day.

6. Add all direct units and time from Form 13864 and adjust the auto-populated Form 5311 units and time when Qmatic is down for part of a day.


**1.4.11.16.2** **(02-20-2024)**

#### Management Review and Disposition of Form 13864 and Form 6148

1. Group managers:



1. Ensure that TAC employees correctly capture and report contacts and hours.

2. Review the complete Form 13864, Field Assistance Contact Sheet, and conduct comparative reviews to FAMIS Form 5311 and Business Objects reports to ensure that the data is being reported accurately.


2. Procedures for the disposal of Form 13864 and Form 6148:



1. Form 13864 and Form 6148 prepared during the filing season may be destroyed two (2) months after the data captured is used to prepare FAMIS form.

2. Form 13864 and Form 6148 prepared during non-filing season may be destroyed one (1) month after the data captured is used to prepare FAMIS form.



      ### Note:



      Prior to disposing of these forms, submit a completed and signed Form 11671 to the area Privacy, Governmental Liaison and Disclosure (PGLD) records specialists for approval. See theRecords Specialist Territory Map to find records specialist contact information. Refer to IRM 1.15.3, Disposing of Records and Document 12990, Records Control Schedules, for NARA-approved records retention and disposition procedures for more information.


**1.4.11.17** **(02-20-2024)**

### Qmatic

01. Standardization is necessary to ensure nationwide consistency of the data collected.

02. All TACs use the HQ issued printer ticket categories.



    ### Note:



    No TAC may purposely disable, rename, or cover the standard ticket categories without the express written consent of the FA director.

03. TACs use the standardized closing codes when ending the contact. FA HQ is responsible for updating these codes. This generally happens at the beginning of every fiscal year.

04. Ensure employees enter a single closing code at the end of each contact for the service that took the longest time to provide.



    ### Note:



    Refer to Form 5311 Coding Guide, for further guidance.





    ### Exception:



    **Memo Counts** \- Employees enter a second closing code after the primary closing code in specific situations. These closing codes are memo counts and range from 700 to 799. For a current list of codes, refer to Closing Code List and Definitions on the FA Insider.





    ### Example:



    A Spanish speaking taxpayer has a refund inquiry. The taxpayer brought an interpreter since the taxpayer spoke little English. The employee closes the contact by entering closing code 324, _Refund Inquiries_, then enter one memo count 724, _Spanish Speaking Taxpayers (No OPI)_, since this is a taxpayer with limited English proficiency.

05. Ensure employees close a contact representing more than one taxpayer as a multiple contact.



    ### Example:



    An ITAS assisted a preparer who brought in 25 current year tax returns. Five of the returns include remittance. Twenty do not include remittance. He correctly records this contact in Qmatic/Orchestra by entering closing code 412 and closing the ticket. Then, he selects walk-direct and enters closing code 351, _Non-Cash Payments_. He repeats selecting walk-direct and entering 351 four more times.





    ### Note:



    Ensure employees only use the multisend closing code for forms contacts and memo counts.

06. Qmatic Report 272d, Matter Codes Served Per User, captures the number of taxpayers assisted, the time spent with each taxpayer, and the type of inquiry.

07. Matters Code Served Per User must be pulled daily for each TAC employee, including employees detailed to the TAC to verify the accuracy of Form 5311.

08. Guidance contained in the current Form 5311 Coding Guide found on the FA Insider should be interpreted as the IRM.

09. Qmatic/Orchestra report, Marks Summary, captures the total number of taxpayers served per matter code, the total transaction times per matter code, and the average transaction times per matter code. This report is used to ensure the Qmatic/Orchestra and FAMIS data matches.

10. Refer to the Qmatic/Orchestra Training on the FA Insider for understanding and managing the Qmatic system.


**1.4.11.17.1** **(02-20-2024)**

#### Wait Time

1. FA has transitioned to an appointment service-based entity, with wait time improving significantly. However, monitoring wait time is important to ensure all our customers are receiving service in a timely manner. Ensure employees make every effort to begin service to taxpayers within 30 minutes of arrival without jeopardizing quality.

2. During peak seasons, the Express Lane Services (ELS) for specific services can still be used.



1. ELS allows taxpayers with quick, transactional service tasks (e.g., non-cash remittances, return drop off, localized TAC demand, etc.) to bypass IAR screening and receive immediate assistance.

2. Through the use of roping and signage, ELS routes eligible taxpayers to a dedicated workstation with an available ITAS.


**1.4.11.17.2** **(10-01-2025)**

#### Qmatic Ticket Process

1. All FA group managers use a standard process for explaining the use of the Qmatic system.



1. **All Sites** \- Qmatic/Orchestra priorities are pre-determined by HQ and changes are not able to be made by the manager.

2. Taxpayer enters TAC and selects a Qmatic ticket or an IAR assists the taxpayer in selecting a ticket.


**1.4.11.17.3** **(02-20-2024)**

#### Adding Employees on Staff Registration

1. Each FA employee must have a valid Qmatic/Orchestra user account. Non-FA employees are **NOT** added to Qmatic/Orchestra. A BEARS request is not needed to have staff added. The manager will contact the area analyst to get employees added.


**1.4.11.17.4** **(02-20-2024)**

#### Partner Virtual Service Delivery (VSD) Site Qmatic

1. The designated TAC manager is responsible for the Qmatic branch controller used to manage traffic and capture services provided in partner VSD taxpayer facing sites. The designated TAC manager is listed in FAMIS as the manager of the ODN assigned to the taxpayer facing partner VSD site. This manager (or their designate) is responsible for:



1. Working with area analyst to add employees who support partner VSD sites to the appropriate Qmatic/Orchestra branch controller.

2. Reviewing and approving all time charged to the partner VSD site’s ODN.


2. Unless the system is not available, all ITAS assistors use Qmatic/Orchestra when serving all taxpayer contacts. See _IRM 1.4.11.16_, Capturing Field Assistance Contacts. Assistors must be careful to ensure they select the correct link depending on whether they are providing service to taxpayers in their local TAC or at a virtual partner site. If the assistor is logged in to Qmatic Orchestra for their local TAC and they need to start providing service to a virtual partner site, they must log out of Qmatic/Orchestra and then log back in and select the correct link.



### Note:



It is extremely important that the ITAS selects the correct Qmatic/Orchestra site.

3. Each morning when a VSD partner site is open, the support site GM or a designated employee checks the appointment calendar for that day’s appointments. If there are no appointments scheduled for that day, the employee sends an email to the partner’s primary and secondary points of contact notifying them that there are no appointments scheduled. If there are appointments scheduled for that day, the employee sends an email to the partners' primary and secondary points of contact that includes the time of the appointment and taxpayer’s initials.


**1.4.11.18** **(02-20-2024)**

### Field Assistance Contact Recording (FACR)

1. FACR is an automated system that records the audio portion of a taxpayer contact and synchronizes it with an employee’s computer screen activity. Qmatic/Orchestra signals the recording to begin at the start of each contact and turns it off at the appropriate time. Additional information on using Qmatic/Orchestra can be found here: Q-Matic/Orchestra Training.

2. BEARS Access is required for all Field Assistance (FA) Individual Taxpayer Assistance Specialists (ITAS) and Managers. The employee must log into BEARS and request CONTACT RECORDING – FIELD ASSISTANCE for the appropriate area.

3. FA managers use the Embedded Quality Review System (EQRS) to critique a random sample of taxpayer contacts for accuracy, timeliness and professionalism. Managers must provide positive/negative feedback from the FACR to employees. Defects identified can be used to identify training and coaching needs. Quality reviewers use statistically valid samples of contacts to verify the accuracy of managers’ reviews, analyze trends, identify opportunities and implement quality improvement measures. These individual technology tools (Qmatic/Orchestra, FACR and EQRS) work in concert to achieve these outcomes:



   - A highly skilled workforce

   - Increased efficiency for managers

   - More accurate data, leading to targeted improvements

   - Enhanced quality for our taxpayers


4. For TACs with FACR, use recorded contacts to accomplish the required monitoring. See _IRM 1.4.11.20_, Embedded Quality Roles and Responsibilities.

5. Group managers are responsible for ensuring employees are following proper procedures when closing contacts. This includes use of the proper Qmatic closing codes, the "TP requested opt-out" function, and the "TP departed (wrap-up)" function.

6. FACR agents (assistors), managers, and area analysts refer to the Verint 15.2 Quick Guide for more information.



### Example:



Refer to the Verint 15.2 Quick Guide for the following situations (list is not all inclusive):





   - Adding/removing computers

   - Adding/removing employees/managers/circuit riders (including managing the BEARS process)

   - Installing/configuring microphones

   - Refreshing/re-imaging computers

   - Other system maintenance issues


**1.4.11.18.1** **(02-20-2024)**

#### Field Assistance Contact Recording (FACR) Controls

1. Review contacts to ensure adherence to policies and procedures (periodic review not required). Territory, area and headquarters management review adherence to policy as a component of operational reviews.

2. On a quarterly basis, or as directed by FA headquarters, areas review all "opt-out" contacts (closing code 1) for proper use and verify the taxpayer requested to "opt-out" of the recording. Refer to IRM 21.3.4.27.2, FACR Opt-Out.

3. On a quarterly basis, or as directed by FA headquarters, areas analyze contacts (other than those routinely reviewed by NQRS) to determine adherence to policies and procedures and identity improvement opportunities. If opportunities for improvement exist, areas recommend corrective actions. These reviews include, but are not limited to:



1. No show (closing code 999) contacts with over 4 minutes of transaction time.

2. Memo count closing codes (e.g., closing code 724 - Spanish Speaking).

3. Non-technical contacts (e.g., closing code 413).

4. Wrap-up contacts.

5. Closing code 0 - Qmatic/Orchestra default error code.


4. When Verint shows contacts less than ten (10) business days old in "deleted" status, the user (manager or analyst) who identifies the "deleted" status inputs a ticket requesting an assessment/upgrade of the computer’s data storage capacity.


**1.4.11.18.2** **(02-20-2024)**

#### Field Assistance Contact Recording (FACR) Area Analyst Responsibilities

1. Area analysts provide guidance and support on the use of FACR to TAC managers. This includes providing new/acting managers with appropriate training materials.

2. Approve BEARS requests for access to FACR.

3. Area analysts are responsible for managing the Verint user database that includes adding/modifying groups for agents (assistors).

4. During System/Program Reviews:



1. Area analysts incorporate into their regular program/operational reviews analysis of opt-outs, no shows, Spanish speaking memorandum counts, deleted status and wrap-up contacts. This list includes minimal review requirements and is not all inclusive. Analysts share trends and corrective actions taken with the appropriate territory and group managers when necessary.

2. Area analysts use the VERINT/IMPACT360 Web Portal application, Contacts, on the home page to review contacts not associated with a specific SEID and/or name. Analysts and group managers determine corrective actions to take, if any.

3. Area analysts ensure Pub 5004, "Your Contact Will Be Recorded..." Desktop Sign for Field Assistance Taxpayer Assistance Center (English/Spanish), is posted at each TAC workstation with contact recording.



      ### Note:



      FA managers ensure that damaged signs are replaced.


**1.4.11.18.3** **(02-20-2024)**

#### Field Assistance Contact Recording (FACR) Headquarters Analyst Responsibilities

1. The roles and responsibilities of the headquarters analyst include the following:



1. Maintain the Verint Contact Recording (CR) database by adding, updating and removing groups, agents and workstations.

2. Receive, review, and coordinate all request for copies of download contacts and maintain the requests log for five (5) years.

3. Monitor application performance and troubleshoot problems.

4. Open IT tickets when the CR system (Verint) is not functioning properly and all efforts from the business unit have failed to restore functionality.

5. Coordinate, distribute and analyze mandatory reports.


**1.4.11.18.3.1** **(02-20-2024)**

##### Requests for Copies of Downloaded Contacts

1. It is occasionally necessary to download and share copies of recorded contacts. FA headquarters identifies users profiled for download permissions.

2. The ability to download contacts is generally limited to the headquarters analyst. All headquarters analysts must have secure email capabilities.

3. The retention period for CR recordings is 60 days for all recordings and 558 days for recordings where an evaluation has been submitted.

4. Download permissions allow the individual to download both audio (.wav) and screen (.avi) files from Impact360.

5. **Requests for downloading a contact must be in writing.**Form 13817, Request for Downloaded Contact, is available for this purpose but a request by memorandum or email containing the same information as in the Form 13817 is acceptable. Verbal requests are generally not accepted; however, the headquarters analyst may complete the Form 13817 and then initiate the download as long as the requester is verified. Fax and email requests suffice as documentation as long as the requester is verified, and the document contains all information necessary to complete Form 13817.

6. Download contacts in the following situations:



1. TIGTA request - See below procedures for details.

2. Freedom of Information Act (FOIA) request - See _IRM 1.4.11.18.3.3_, Freedom of Information (FOIA) Request, for details.

3. Management request - See _IRM 1.4.11.18.3.4_, Managerial Requests, for details.


7. **Procedures for Saving Downloaded Contacts:** Save copies of the downloaded contacts and the original request (form, memo or email) in a secure, encrypted location, in the sensitive but unclassified (SBU) folder.


**1.4.11.18.3.2** **(01-02-2019)**

##### Treasury Inspector General for Tax Administration (TIGTA) Requests

1. TIGTA occasionally requests that a contact be downloaded and provided to them. These requests can be made by EEFax or email.

2. The request must contain the following:



   - Date of Contact

   - Employee Name

   - TAC Name

   - Start Time of Contact

   - Name of Requestor

   - Organization Symbols

   - Function

   - Date of Request


**1.4.11.18.3.3** **(01-02-2019)**

##### Freedom of Information Act (FOIA) Request

1. Under the Freedom of Information Act, each taxpayer has the right, subject to certain limitations, to access records and documents maintained by the IRS.

2. The Disclosure Office handles FOIA requests. See IRM 11.3.13, Freedom of Information Act .

3. Written requests must contain the following:



1. Date of the contact.

2. Name of the employee.

3. Approximate time of the contact.

4. Taxpayer identification (name, address, TIN, etc.).



      ### Caution:



      Requests that do not contain this information cannot be processed.


### Note:

Screen files and audio files cannot be edited to prevent unauthorized disclosure. Notify the Disclosure Office requestors of this. They determine whether recorded audio and screens can be released to taxpayers.

**1.4.11.18.3.4** **(01-02-2019)**

##### Managerial Requests

1. Management may request a recorded contact be downloaded. The reason for the request must be stated clearly on Form 13817, Request for Downloaded Contact, and must be approved by the area director or authorized delegate. In general, the reason for these downloads is to provide a copy of the contact to another party (TIGTA, Labor Relations, etc.) when necessary.

2. Below are examples of valid requests:



1. Employee disputes the EQRS DCI, and the dispute is expected to extend beyond 18 months.

2. Gross employee misconduct.

3. Evidence of potential criminal intent by the taxpayer or employee.


3. Deny invalid requests. Below are examples:



1. Singular taxpayer complaint

2. Singular performance issue

3. "Just in case" requests


**1.4.11.18.3.5** **(01-02-2019)**

##### Download Approval

1. The download can take place once the Form 13817 with proper approval is received.



### Exception:



For TIGTA/FOIA requests - so as not to delay investigations or taxpayer requests, it is not necessary to obtain area director or delegate approval prior to the download being completed and provided to TIGTA or the Disclosure Office.

2. The headquarters analyst forwards TIGTA and FOIA requests to the Policies, Technology, and Measures (PTM) section chief.


**1.4.11.18.3.6** **(01-02-2019)**

##### Downloading Contacts

1. Download the contact onto the SBU folder (see FACR desk guide).

2. Copy the contact onto a USB flash drive or CD, encrypted with a Symantec Endpoint Encryption (SEE) default password hand delivered or sent via traceable UPS to the requester. Send an email to the requestor with the SEE default password.


**1.4.11.18.3.7** **(01-02-2020)**

##### Record Keeping and Storage of Download Contacts

1. The headquarters analyst keeps a record of all requests for download as they are subject to subsequent review. IRM 21.1.3.17.1, Freedom of Information Act (FOIA), contains specific instructions regarding Freedom of Information (FOIA) requests received from taxpayers.

2. All requests (forms and emails) for downloaded contacts that are held for retention are reviewed quarterly (every 90 days) to determine the need for continuing file retention (the downloaded and stored contact). It is often necessary to contact the initiator of the request to determine the need for ongoing storage. The headquarters analyst stores Form 13817, Request for Downloaded Contact, and similar documents according to document retention requirements for a minimum of five (5) years after the contact is deleted.


**1.4.11.19** **(10-25-2024)**

### Field Assistance Quality Review

1. EQRS is used by FA managers to house employee performance documentation, tabulate average performance ‘scores’, and run cumulative performance reports. Reviews in EQRS can be designated as evaluative or non-evaluative to the employee. While EQRS is the cornerstone of FA employee performance management, the system is designed to only capture data derived from entire taxpayer contacts.

2. EQRS is actually two separate systems; two "sides" which mirror one another. The EQRS side is used by managers to record observations of individual employee performance, while the National Quality Review System (NQRS), is used to measure FA as a whole. Field Assistance contracts with the Joint Operations Center (JOC) Centralized Quality Review Section (CQRS) to measure FA quality through the use of FA Contact Recording (FACR).

3. Like EQRS, the NQRS is designed for reviews of entire taxpayer contacts only. Results of the NQRS review are reported externally as FA’s official quality measure. The findings of these reviews are documented in NQRS, and the results are statistically valid. Statistically valid means we can be confident that the results of the review are true within an acceptable precision margin. For FA, the acceptable precision is +/- 5 percentage points at the area level on a quarterly basis, although the precision margin of the FA review is much better, usually +/- 1 or 2 percentage points.



### Example:



You pull an NQRS report, and it shows a cumulative accuracy percentage of 96 percent for the fiscal year (FY). This report shows a precision margin of one percentage point. You complete a report for the DFA showing 96 percent accuracy for the year. The information you provided really means that we are 90 percent confident that the true accuracy of FA Contacts is 96 percent plus or minus one percentage point.

4. FA uses a single Specialized Product Review Group (SPRG) called “FA Contacts” to measure the quality of all face-to-face services FA provides to taxpayers. Tax law, accounts, and procedural reviews are not captured separately.

5. FA uses the SPRG called “Accounts Paper Adjustments” owned by Accounts Management to measure the quality of closed CII cases completed by employees.

6. The CQRS quality reviewers input data from reviews of taxpayer’s contacts into NQRS to measure FA organizational performance. FA GMs input data from taxpayer contacts into EQRS to evaluate individual employee performance. Both systems use data collection templates for each contact, with quality attributes tied to the employee’s critical job elements (CJEs) and the three quality measures of accuracy, professionalism, and timeliness. This provides an objective and consistent assessment of employee performance as well as of FA as a whole. Refer to the EQRS/NQRS Campus SharePoint Support Site (EQ Web) for more information.

7. Area quality analysts (AQAs) and GMs have access to all NQRS reviews. Managers **must** share the reviews with the individual employee whose work is reviewed. Both managers and analysts may use sanitized versions of the reviews with all employees as examples to illustrate exemplary performance, as well as common pitfalls.



### Caution:



Results of the national review are not evaluative to the individual employee and cannot be used for an individual employee's performance rating nor filed in an individual employee’s EPF.

8. In FA, there are many other opportunities in addition to taxpayer contacts that managers must review. Review of this work is not entered into the EQRS database. These reviews are part of FA’s internal control systems and may include, but are not limited to, written referrals, remittance reviews, security checks, time utilization, OJI, and/or teaching assignments. These types of reviews are documented on Form 6067, Employee Performance Folder Record.


**1.4.11.19.1** **(02-20-2024)**

#### Field Assistance Review Methods

1. Field Assistance conducts multiple reviews at various levels to provide management with assurance/confidence that procedural requirements are consistently followed by employees and managers. The methods used by FA to perform these reviews include:



1. Field Assistance Contact recording (FACR) review of employee’s performance during taxpayer contacts or direct (stand-behind) observations of taxpayer contacts.

2. CII review of employee’s performance while working paper inventory cases closed by FA employees.

3. Direct observation of employees performing tasks, such as conducting research, handling remittances, or performing security checks.

4. Physical or automated review of employee records and reports derived from processes or systems including referrals, vouchers, receipts, IDRS, and other generated reports.


2. **FACR**: Used in monitoring the quality of assistance that employees provide taxpayers. Routine monitoring using Contact Recording and/or direct observation process allows managers to:



1. Determine areas needing improvement in a timely manner.

2. Identify the causes of errors or problems and take necessary action to correct them.

3. Improve employee performance, enhance and expand employee skills, and develop employees to help them reach their career aspirations.

4. Serve as a coach and role-model.

5. Identify training needs.


3. **Direct Observation**: In person review of employees performing tasks can reveal coaching opportunities that remote reviewing may miss. By observing each action taken to perform a task, it may be possible to identify and eliminate unnecessary steps an employee is taking or provide a different sequence of steps that makes the process more efficient.



1. Direct observation also allows the manager to assess the adequacy of the physical surroundings where tasks are performed and identify barriers. For example, is the space well lit, big enough, have high traffic or noise. Such observations can lead to corrective actions that lead to greater productivity.

2. During direct observation, avoid being drawn into the conversation between the taxpayer and the employee. As much as possible, managers attempt to stay in the background.



      ### Note:



      Initiate a private conversation with the employee to ensure a taxpayer does not leave with inaccurate or incomplete information.


4. **Review of Records and System Reports**: Some reviews of records/reports can be completed remotely, while others require a visit to a TAC, data input into a system can generally be reviewed remotely while manually kept or written records and reports generally must be reviewed in person. For example, to review if taxpayer data is not properly secured, an on-site after-hours review is needed. Conversely, to determine if all of a manager’s monthly employee performance reviews for a group are completed, EQRS allows you to remotely research the number of reviews complete by a manager during a given timeframe.


**1.4.11.19.2** **(01-02-2020)**

#### Field Assistance Group Manager Responsibilities and Reviews

1. FA GMs provide oversight and guidance to the TAC employees, review and assess the quality of service they provide to taxpayers, monitor and perform internal control actions, and are responsible for the day-to-day operations at the TAC(s).

2. FA GM responsibilities include:



1. Protecting IRS assets and taxpayer remittances.

2. Maintaining a safe and secure place of business for employees and taxpayers.

3. Conducting reviews to ensure employee adherence to internal control procedural requirements.

4. Performing administrative duties for employee pay, leave, awards, and conduct.

5. Training and developing employees and assigning work.

6. Achieving quality goals based on taxpayer needs and expectations.


3. Taxpayers expect interactions with the IRS to be _Quick, Right, and Polite_, just as they do from any business interaction. More specifically, FA strives to provide services that consist of controlling the direction of the contact (Quick), giving accurate and complete assistance (Right), and maintaining professional courtesy (Polite).

4. FA TMs provide oversight and guidance to the GMs, assess the effectiveness of TAC management in meeting organizational objectives, and communicate and support implementation of national policies.

5. FA TM responsibilities include:



1. Conducting operational reviews and ensuring completion of corrective actions, as needed.

2. Evaluating GM performance and development.

3. Reviewing internal control procedural adherence.

4. Allocating resources to facilitate group operations.

5. Communicating key messages and implementing service policies.


**1.4.11.19.3** **(01-02-2019)**

#### Review Plan and Scheduling Process Overview

1. Accurately completing all of the required reviews in a timely manner is second only to physical security and safety as the most critical responsibilities of a FA GM. Establish and follow a written plan and schedule to ensure required reviews are completed timely. To successfully complete all review obligations, a review plan and schedule is established. See the EQ Quality Review Plan for assistance.

2. Like any other management activity, preparation is the key in completing quality reviews. With due dates at various intervals, establishing a review plan and schedule ensures all required reviews are completed timely.

3. TMs discuss the GM’s review plan and schedule as needed, or at a minimum annually, as part of the group operational review (see _IRM 1.4.11.19.9_, Group Manager Mandatory Reviews, Reports and Certification.


**1.4.11.19.4** **(01-03-2017)**

#### Review Documentation

1. Document all reviews to provide objective and meaningful feedback aimed at improving performance. Promptly document and share the contact observed in accordance with the national agreement to ensure that important details of the direct observation are not forgotten.

2. Effective documentation is an essential part of the review process. It is the factual basis for feedback to the employee. For EQRS reviews the documentation is entered on a Data Collection Instrument (DCI). There are three sections to enter remarks:



1. Taxpayer Issue(s)

2. Employee Action/Response

3. Summary Feedback


### Note:

For an EQRS review, use the FA EQRS job aid and the Guidelines for Writing FA EQRS Remarks, to effectively document the review.

**1.4.11.19.5** **(01-02-2019)**

#### Providing Effective Feedback

1. Provide timely, continuous feedback to develop employee skills needed to provide quality service to taxpayers. Take the following actions:



1. Engage employees as partners in the identification and resolution of problems.

2. Maintain and foster open, honest communication.

3. Celebrate success.

4. Continually reinforce organizational goals by sharing business results and identifying opportunities for improvement.


2. Provide managerial feedback **_timely_** and identify **_specific_** performance. Conduct periodic counseling sessions with each employee to discuss his/her progress, self-help techniques, and interpersonal skills with taxpayers.

3. Share positive as well as negative feedback with the employee to:



1. Focus on the employee's overall job performance by building on strengths and addressing weaknesses.

2. Develop and reinforce the employee's commitment to FA operational goals.

3. Provide support and motivation.


4. Reinforce positive performance attributes and share feedback in a constructive manner, offering suggestions to ensure corrective measures are taken to improve overall taxpayer service.

5. Whenever possible, provide feedback **in-person**. Employees located in outlying TACs may be contacted by telephone, followed by written feedback when the manager’s travel schedule would delay timely sharing of feedback.


**1.4.11.19.6** **(01-03-2017)**

#### Employee Performance Appraisals, Annual, Midyear Progress Review and Departure

1. | **Annual Appraisal** |
| :-: |
| Permanent supervisors complete the annual performance appraisals for employees under their authority. The e-performance guides and job aids are available through ERC. Select Hiring, Training and Career tab, then Select Performance Management System. See the Performance Appraisal Plan. |
| **Purpose** \- The performance appraisal serves as a record of performance to support, recommend, and initiate such actions as within-grade pay increases, promotions, awards, reassignments, demotions, or separations; and to provide the employee with a basis for further training and development; and to improve the performance of individual employees. |
| **Frequency** \- Complete annual appraisals for employees based upon the last digit of the employee’s social security number. They are due by the last day of the month following the end of the employee’s rating period. |
| **Documentation** – Form 6850 BU, Bargaining Unit Performance Appraisal and Recognition Election. Form 6850 BU must be entered into HR Connect e-Performance. |
| **References** -<br> <br>   - IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non-Bargaining Unit Employees Assigned to Critical Job Elements (CJEs)<br>     <br>   - IRM 6.430.3, Performance Management Program for Evaluation Managers, Management Officials and Confidential Management/Program Analysts<br>     <br>   - National Agreement, Article 12, Section 4, Employee Performance Appraisals |






| **Mid-Year Progress Review** |
| :-: |
| The supervisor observes the employee’s performance on a regular basis through the employee’s appraisal period and must conduct a mid-year progress review. The review must include a discussion on progress in meeting expectations and discuss each performance aspect whose performance has changed from the previous rating of record. The midyear review is documented in HR Connect, e-Performance. |
| **Purpose** \- Midyear progress review discussions should indicate progress on critical performance expectations as well as any necessary adjustments to those expectations, thereby providing employees with ongoing, formal feedback during the appraisal period. |
| **Frequency** – The midyear appraisal should occur at the mid-point (six-months) of the employee's appraisal period. |
| **Documentation** – The midyear progress review discussion should be documented in writing and may be in bullet or narrative format. |
| **References** –<br> <br>   - IRM 6.430.2, Performance Management Program for Evaluating Bargaining Unit and Non-Bargaining Unit Employees Assigned to Critical Job Elements (CJEs)<br>     <br>   - IRM 6.430.3, Performance Management Program for Evaluation Managers, Management Officials and Confidential Management/Program Analysts<br>     <br>   - National Agreement, Article 12, Section 4, Employee Performance Appraisals |






| **Departure Appraisals** |
| :-: |
| A departure appraisal is a type of appraisal prepared when either the supervisor or employee moves from one permanent or temporary assignment to another permanent or temporary assignment. |
| Two events require a departure appraisal:<br> <br>1. **Supervisor Departure** – If a supervisor departs his or her position, a departure appraisal must be prepared for the employees under the supervisor’s work unit. If the employee being rated is a manager or management official, the departure appraisal becomes the employee’s rating of record if the supervisor’s departure occurs within the last 60 days of the employee’s appraisal period.<br>      <br>2. **Employee Departure** – If an employee departs his or her position, the supervisor must prepare a departure appraisal for that employee. The employee’s departure appraisal becomes his or her rating of record if the departure occurs within the last 60 days of the employee’s appraisal period. If not within the last 60 days, the employee’s new supervisor considers the departure appraisal when preparing the employee's rating of record. |
| **Purpose** \- Departure appraisals serve as a record of performance that is issued when an employee or the GM (rating official) moves from a permanent or temporary assignment to another permanent assignment. |
| **Frequency** \- Complete departure appraisals within 30 days of the departure of either the employee or manager. To receive a departure appraisal, the employee's performance must be observed under a signed performance plan for at least 60 days. |
| **Documentation** – Document departure appraisals on Form 6850 BU, Bargaining Unit Performance Appraisal and Recognition Election. A signature by a reviewing official is not required unless the departure appraisal is also used as the employee’s annual rating of record. |
| **References** -<br> <br>   - IRM 6.430.2, Performance Management Program for Evaluation Bargaining Unit and Non-Bargaining Unit Employees Assigned to Critical Job Elements (CJEs)<br>     <br>   - IRM 6.430.3, Performance Management Program for Evaluation Managers, Management Officials and Confidential Management/Program Analysts<br>     <br>   - National Agreement, Article 12, Section 4, Employee Performance Appraisals |


**1.4.11.19.7** **(02-15-2023)**

#### Operational Reviews

01. In addition to ongoing periodic mandatory reviews, reports, and certifications, FA headquarters staff, area office staff, and TMs conduct operational reviews. See IRM 1.4.10.3, Operational Reviews Overview.

02. An operational review is an in-depth review and analysis of a particular program or function. Operational reviews are conducted in the following manner:



    - Territory managers review groups within their territory

    - Area director staff reviews territory operations

    - DFA headquarters staff reviews area operations


03. Each fiscal year, FA conducts operational reviews as follows:



    1. **Headquarters Staff** – Site visit review of selected TAC(s) in each area on an annual basis as approved by the DFA.

    2. **Area Office Staff** \- Review 50 percent of territories each year with written review of TM reviews and follow-up actions for the other 50 percent.

    3. **Territory Managers** \- Reviews are completed for each group annually and include at a minimum one TAC site visit.


Exceptions/deviations – If operational reviews cannot be completed on-site due to budgetary reason, such as lack of travel funds, a deviation can be formally requested via memorandum and with approval of the DFA.



04. A schedule of planned operational reviews is prepared at each level at the beginning of the fiscal year and no later than December 31st. The schedules reflect:



    1. Completion of each operational review individually and the specific month in which each is completed.

    2. Completion by June 30 of all area /territorial operational reviews to allow for follow-up/corrective actions before the end of the fiscal year.

    3. Approval by the SOM, AD, or DFA (as appropriate) of the operational review.

    4. Sharing of the operational review with group/territory manager and posted to the operational review housing site on SharePoint.


05. Area/territory operational reviews must:



    1. Evaluate and assess performance and adherence to internal controls

    2. Identify areas where improvement is needed

    3. Assign required corrective actions and target completion dates

    4. Identify and praise accomplishments


06. The review should address the following:



    - Workload management practices

    - Personnel management practices

    - Administrative practices


07. Compare the above practices to the following:



    - Mission Statement

    - Policies and regulations

    - NTEU National Agreement

    - Memos of understanding (MOU)

    - Business measures and goals

    - DCIs


08. FA operational reviews include a combination of remote/virtual and on-site observations. The following DCIs are mandated for use by Group and Territory Managers, during FA operational reviews:



    - Remittances (non-cash payment and general)

    - Form 795/Form 3210/Form 3244

    - RSPCC live and retention

    - Form 809 book holder IDRS profile

    - Courier live and retention

    - Limited physical security (some of these questions should remain for on-site reviews, such as the Form 700 in the safe)

    - Personnel files (which includes the EPFs)



      ### Note:



      There are two parts to the on-site review, observations and retention files.


09. Area/territory operational reviews also document:



    1. Performance in areas designated for special emphasis by the DFA as identified in the Commitments.

    2. The validity of responses given during the Annual Assurance Review Process regarding the adequacy of internal controls, both administrative and program specific. These should ensure programs achieve their intended results, realize their goals, are complete, timely, and reflect accurate financial and management reports. See IRM 1.4.2.5, Annual Assurance Review Process.

    3. The timely completion of required FA managerial reviews such as employee appraisals, employee performance reviews, payment processing reviews and physical/data security requirements. See _IRM 1.4.11.19.10_, Territory Manager Mandatory Reviews, Reports and Certifications, and _IRM 1.4.11.19.9_, Group Manager Mandatory Reviews, Reports and Certification.

    4. Best practices that can be shared with others.


10. Allow sufficient time for an opening meeting or conference call upon arrival, performing the review, closing the review with an informal discussion of findings and recommendations, writing the formal report, and providing feedback from the final report to the manager or director, as appropriate.

11. Effectively managing your time is critical during on site reviews. Before you arrive, you want to:



    1. Communicate your expectations for the visit and logistics (location, arrival time, etc.)

    2. Plan to have your day-to-day responsibilities covered to minimize distractions during the visit.

    3. Request information well in advance and in writing to help ensure the information is available at the start of the review as requested.

    4. Revisit these items during your opening meeting to ensure you have what is needed to begin.


12. Operational reviewers may request the following items in advance of arrival:



    - Employee Performance file

    - Personnel files

    - Drop files (including meeting minutes)

    - Training files (access employee ITM reports)

    - AMS data (case actions documented in AMS)

    - Sample of closed cases and open cases

    - Leave tracking

    - Evaluation/Midyear sample pulls and tracking records

    - IORS reports (to verify separation of duties)

    - TSRRD submissions

    - Managerial remittance reviews


13. To further maximize the value of the time spent on-site, it is highly recommended that you create a list of reports, data, examples, references, and any other materials you think you may need to complete the reports before your visit. It is poor use of your time to travel to a TAC to do what can be done in the office (or virtually). Preparations done beforehand can allow for adequate time to thoroughly review what can only be done on site as well as activities that are better done in person, for example coaching and sharing best practices.

14. Once the area or territorial review is completed, documentation of the review in the form of a memorandum is provided to the manager or executive, as appropriate for review and approval. Include the following in the memorandum:



    - Overall review summary of findings

    - Specific observations (positive and negative)

    - Opportunities for improvement

    - Recommendations and required action items

    - A separate action plan attachment that includes the target actions, completion dates and responsible official


### Note:

Follow-up timely with the manager on action items and document all follow-up actions.

**1.4.11.19.8** **(02-20-2024)**

#### Review Process and Types of Review

1. Review written documents prepared by the FA employee to ensure a quality work product. The documents may include but are not limited to:



   - Form 4442, Inquiry Referral

   - Form 3913, Acknowledgment of Returned Refund Check

   - Form 911, Request for Taxpayer Advocate Service Assistance (And Application for Taxpayer Assistance Order)

   - Form 3244, Payment Posting Voucher

   - Form 2063, Alien Clearance

   - Form 433–D, Installment Agreement

   - Form 2159, Payroll Deduction Agreement

   - Letters/quick notes to taxpayers

   - Documents pertaining to notice accounts

   - IDRS Adjustments

   - AMS (Account Management Services) documentation

   - Form 809, Receipt for Payment of Taxes

   - FA DAS, Document Action Sheet (in ITIN authentication TACs only)

   - Annotations required on Form 2290, Heavy Highway Vehicle Use Tax Return, prior to mailing to campus for processing


2. Review administrative documents to ensure they are timely and accurately completed. These include the following:



   - Form 5311, Taxpayer Service Activity Report

   - Form 3210, Document Transmittal (both remittance and non-remittance) Document Review Plan – _IRM 1.4.11.19.10_, Territory Manager Mandatory Reviews, Reports and Certification

   - _IRM 1.4.11.19.9_, Group Manager Mandatory Reviews, Reports and Certification

   - Form 795-A, Daily Report of Collection Activity, Document Review Plan


3. Qmatic/Orchestra reports provide information regarding types of contact(s), taxpayer waiting time, and time spent per contact. Locations without Qmatic/Orchestra must use Form 13864 to record information:



1. When Qmatic/Orchestra is not available.

2. When conducting direct off counter work.


See _IRM 1.4.11.16.1_, Form 13864 - Field Assistance Contact Sheet.



### Note:

Do a periodic matching of information on Form 5311 against information on individual Qmatic/Orchestra report.

4. The review of Form 3210 helps determine the timely forwarding of returns, remittances and Form W-7, Application for IRS Individual Taxpayer Identification Number.

5. TACs where IAR/secretary or managers are located must reconcile Form 795-A of other employees before submission to the appropriate SPC. This reconciliation must not delay the transmission of the remittance packages. Remittance must be transmitted the day of receipt or the next business day.

6. Oversight and assessment of employees working VSD is unchanged from regular FA procedures. Employees in a remote location provide assistance via VSD, so the support site GM is responsible for monitoring their employee's work and performing EQRS reviews. GMs use the ULTRA inbox to collect a sample of contacts for quality reviews to ensure these contacts meet FA requirements and to identify any areas that need improvement. No additional EQRS reviews are required by GMs due to VSD.


**1.4.11.19.9** **(10-25-2024)**

#### Group Manager Mandatory Reviews, Reports, and Certification

1. Group Manager Requirements:




| **Monthly EQRS Observations:** |
| :-: |
| **Purpose** – Field Assistance GMs use the Embedded Quality Review System (EQRS) to review face-to-face contacts on Tax Law and Accounts issues and closed paper inventory cases worked in CII. EQRS provides managers a data collection template for each contact, with quality attributes tied to the employee’s critical job elements (CJEs) and the quality measures (Accuracy, Professionalism, and Timeliness), providing an objective, consistent assessment of employee performance. |
| **Frequency** – GMs are generally required to review at least one (1) evaluative taxpayer contact per employee per month, 12 evaluative reviews per year. Review employees located in Social Security offices by direct observation at least quarterly. |
| **Documentation** – Input results into EQRS using the FA Contacts SPRG or Account Paper Adjustments SPRG (with the DCI number, the format is only the 10-digit DCI Number), within three business days of the review. Print and share the EQRS feedback report with the employee in compliance with the National Agreement. |
| **References** -<br> <br>   - _IRM 1.4.11.19_, Quality Assurance and Review Process<br>     <br>   - _IRM 1.4.11.20.2_, Group Manager Responsibilities |






| **Physical Security:** |
| :-: |
| **Purpose** – The IRS has a legal obligation to protect the confidentiality of tax returns and related information. |
| **Frequency** – The results of the reviews are input into the TAC Security and Remittance Review Database on a quarterly basis. |
| **Documentation** – GMs are responsible for conducting physical security reviews using Form 15608, Parts I, II, III, IV and digitally sign page 6 and the Physical Security Data Collection Instruments (DCIs) and input the results of the reviews in the TAC Security and Remittance Review database on a quarterly basis. |
| **References** -<br> <br>   - _IRM 1.4.11.4.1_, Taxpayer Assistance Center (TAC) Physical Security Requirements<br>     <br>   - _IRM 1.4.11.4.2_, TAC Security/Internal Controls<br>     <br>   - _IRM 1.4.11.4.1.3_, Controlled Access Procedures<br>     <br>**References** \- Copies of the Form 15608 and physical security DCI documentation are required as part of the TSRRD retention file and maintained for three (3) years. |






| **Quarterly Contact Recording:** |
| :-: |
| **Purpose** – Contacts are reviewed to ensure adherence to policies and procedures and that appropriate contacts are available for national sample selection. |
| **Frequency** – On a quarterly basis (or as directed by FA headquarters), areas review: "opt-out" contacts (closing code 1) specifically verifying that the taxpayer requested the "opt-out" (refer to IRM 21.3.4.27.2, FACR opt-out), no show (closing code 999) contacts with over 4 minutes of transaction time, memo count closing codes (e.g., closing codes 724 - Spanish Speaking), Procedural (closing code 407), wrap-up contacts, and closing code 0 - Qmatic default error code. |
| **Documentation** – Area reviewers complete DCIs (DCI is provided by FA headquarters) for FACR contacts reviewed and return them to FA headquarters. |
| **Reference** \- _IRM 1.4.11.18.1_(1)(a), (b), FACR Controls |






| **Quarterly Payment Processing Reviews:** |
| :-: |
| **Purpose** – Remittance processing is the most time sensitive work performed in a TAC. All FA GMs must conduct quarterly Payment Processing reviews using the mandatory Group Manager’s DCIs. Refer to _IRM 1.4.11.7.2_, Remittance Quarterly Reviews - Manager’s Requirements, for a complete listing of all required payment processing quarterly reviews. |
| **Frequency** – Quarterly review of each TAC location. |
| **Documentation** – GM must document their quarterly remittance reviews directly on the mandatory GM DCI. These reviews may be used as an evaluative record of an employee’s performance. Reviews are documented on Form 6067 , Employee Performance Folder Record. Attach a copy of the applicable DCI to the Form 6067 . |
| **Reference** \- _IRM 1.4.11.7.2_, Remittance Quarterly Reviews - Manager’s Requirements. |
| **Retention** \- The GM DCI documentation is required to be kept as part of the TSRRD retention file and maintained for three (3) years. |






| **Acknowledgement Transmittal Review:** |
| :-: |
| **Purpose** – GMs are responsible to conduct and document managerial reviews to ensure internal controls are met and IRM 21.3.4.7.12, Remittance Acknowledgements Transmittal Form 795-A and Form 3210 Process, and IRM 21.3.4.8.5, Reviewing and Reconciliation of Form 3210, are being followed for all remittance and non-remittance documents transshipped from the TAC. |
| **Frequency** – GMs must conduct and document monthly reviews of the remittance and non-remittance transmittals. The transmittals are housed in separate binders, one for remittance and another for non-remittance. GMs are required to complete a 100 percent review and reconciliation on the remittance transmittals and a sampling of 20 non-remittance transmittals for review and reconciliation. If less than 20 non-remittance transmittals are available, a 100 percent review is required. The review must be completed no later than the fifth (5th) business day after the close of the previous month as listed in _IRM 1.4.11.7.1.2_, Managerial Review for Acknowledgment Transmittals Procedures. |
| **Documentation** – GM must document their monthly review of the remittance and non-remittance transmittal acknowledgements finding directly on the Transmittals Tracker for that month. Form 14698-A, Field Assistance TAC Documentation Transmittal Review and Reconciliations, must be completed and electronically signed to certify the monthly transmittal review is conducted. A copy of the Transmittal Tracker with the GM’s monthly review finding must be attached to the completed and electronically signed Form 14698-A. These documents must be maintained with the associated monthly retention file for three years. Two Transmittal Trackers and two Forms 14698-As are required for each month, one to document and certify the monthly review of the remittance acknowledgments and one to document and certify the monthly review of the non-remittance acknowledgments. |
| **Reference** \- _IRM 1.4.11.7.1.2_, Managerial Review for Acknowledgement Transmittals Procedures |
| **Retention** \- Two completed and electronically signed Forms 14698-A and the two Transmittals Trackers listing the GMs findings must be maintained as part of the retention file for three (3) fiscal years. For additional document requirements maintained as part of the retention file, refer to IRM 21.3.4.7.12.4, Retention Files for Remittance Acknowledgement Transmittal Procedures, and IRM 21.3.4.8.7.4, Retention Files for Non-Remittance Acknowledgement Transmittal Procedures. |






| **TAC Security and Remittances Review (TSRRD)** |
| :-: |
| **Purpose** \- The TSRRD is one of the management controls for Field Assistance. GMs are responsible for conducting physical security and remittance processing reviews throughout the year and using the TSRRD to capture the results from the managerial reviews for each TAC that they manage. |
| **Frequency** – GMs must monitor and document security and remittance procedures in each of their TACs on an on-going basis as outlined in _IRM 1.4.11.4.2_, Taxpayer Assistance Center (TAC) Security/Internal Controls and _IRM 1.4.11.7.2_, Remittance Quarterly Reviews - Manager’s Requirements. These reviews are required for each quarter and the results of the reviews are used to answer the TSRRD survey questions during the month following the end of each quarter. |
| **Documentation** \- Managers must establish and maintain appropriate recordkeeping systems which support the data that is being submitted in the TSRRD database. Keep records to support the date of the review, data collected while conducting the review which should include any issues identified and any corrective actions initiated. Do not attach a copy of the TSRRD survey report to the EPF review, only the appropriate DCIs. Use the comments section in the TSRRD database to record any necessary actions taken. For all TSRRD surveys, once the information is submitted into the TSRRD system database, SharePoint will send a link to the Territory manager via email for survey review and approval. When requested by the TM, all supporting documentation used to answer the TSRRD survey questions are also forwarded. The TM must review the TSRRD survey report for accuracy and completeness. The TM must address any questions or concerns with the GM before approving TSRRD survey report. If corrections are required, SharePoint will generate an email to the Group Manager after the Territory Manager’s review with the request for revision. The GM goes back into the TSRRD survey link, makes the necessary corrections, and then an email is generated again with a link to the corrected TSRRD survey report for the TM to review. SharePoint will generate an email to the GM notifying them of the approval. |
| **Retention** \- Copies of the approval email of the TSRRD survey report and, when applicable, the email(s) of requested revisions to the TSRRD survey report addressing TM questions or concerns, DCIs use to conduct reviews, copy of Form 14698-A, and any other supporting documentation must be maintained as part of the TSRRD retention file for three (3) fiscal years from the date of the review. |

2. **Group Manager Mandatory Reports:**




| **Monthly Trends and Patterns Report** |
| :-: |
| **Purpose** – The trends and patterns report is the vehicle SPC uses to provide feedback to TAC TMs on errors that impact business results or customer satisfaction. |
| **Frequency** – Monthly. |
| **Documentation** – The GM shares the results with the employees as appropriate. The Trends and Patterns report should be maintained in a group file for three years from the date of review. The TMs forward the monthly Trends and Patterns Report, and actions taken to address errors identified, to the area analyst and senior operations manager who informs the AD. |
| **Reference** – _IRM 1.4.11.7.5_, Trends and Patterns Report for Territory and Group Manager Responsibilities. |

3. **Group Manager Mandatory Certifications:**




| **Annual Form 809 Reconciliation:** |
| :-: |
| **Purpose** – At least once a year, GMs must review all of the official receipt books assigned to their employees. Such review is necessary to verify that all official receipts are accounted for. This yearly review is known as the _Annual Reconciliation of Official Receipts_. |
| **Frequency** – Annually. |
| **Documentation** – The TMs provide a consolidated response to the Form 809 coordinator by the due date shown in the memo issued from SPC. |
| **Reference** \- IRM 3.8.47.6.17, Annual Reconciliation of Official Receipts. |






| **Quarterly Section 1204 Certification:** |
| :-: |
| **Purpose** – Section 1204 provides guidance and instructions for the Restructuring and Reform Act of 1998 (RRA 1998) Section 1204 certification and independent review process. Section 1204(a) states that the "IRS shall not use records of tax enforcement results (ROTERs) to evaluate employees or to impose or suggest production quotas or goals with respect to such employees" . Section 1204(b) states "IRS shall use fair and equitable treatment of taxpayers as one of the standards for evaluating employee performance" . |
| **Frequency** – Certify quarterly whether or not tax enforcement results are being used in a manner prohibited by subsection (a). |
| **Documentation** – Electronic Integrated Talent Management (ITM) Learning Module with SharePoint application for sharing possible non-compliance. |
| **Reference** -_IRM 1.4.11.22_, Section 1204, Certification Process. |

4. Refer to the Mandatory Briefings website for mandatory briefing requirements for new hires.


**1.4.11.19.10** **(02-20-2024)**

#### Territory Manager Mandatory Reviews, Reports and Certification

1. **Territory Manager Requirements:**




| **Acknowledgement Transmittals Review** |
| :-: |
| **Purpose** \- Territory managers conduct quarterly reviews of the Remittance and Non-Remittance Acknowledgement Transmittals. Transmittals are housed separately, one binder for remittance and another binder for non-remittance. During the review, the TM verifies that the GM has conducted the required monthly transmittal reviews, documented their finding on the Transmittals Tracker for that month, completed and signed Form 14698-A, Field Assistance TAC Documentation Transmittal Review and Reconciliations, and follow-up actions completed timely. |
| **Frequency** \- Territory managers must review 25 percent of their TACs quarterly, with all TACs reviewed at least once annually. For each TAC reviewed, the TM selects one month from the prior quarter or a month from the current quarter where the GM has already completed their monthly transmittal review. The review consists of 100 percent of all remittance acknowledgment transmittals and a sampling review of 20 non-remittance acknowledgement transmittals, if less than 20 transmittals are available, 100 percent must be reviewed. Most reviews can be completed virtually; however, the TM conducts physical file reviews of the acknowledgement transmittals during their on-site operational review. |
| **Documentation** \- Territory managers, on a quarterly basis, complete and document the review of the remittance and non-remittance transmittal acknowledgements finding directly on the Transmittal Tracker for that month and, when required, complete an action plan for the GM to address finding. Reviews completed during an on-site annual operational review process is also documented as part of the operational review write-up. Refer to _IRM 1.4.11.19.7_, Operational Reviews. |
| The territory Transmittal Tracker listing the TMs finding, completed action plan and certification document of the quarterly review of the Remittance and Non-Remittance Acknowledgement Transmittals reviews are sent to the area staff on or before the last business day of the second month after the quarter ends.<br> <br>### Example:<br>First quarter of FY 2024 (October, November, and December) the summary and certification report is due by February 29, 2024. |
| **Reference** \- _IRM 1.4.11.7.1.2_, Managerial Review for Acknowledgment Transmittal Procedures |





|     |
| --- |
| **Quarterly EQRS Reviews** |
| **Purpose** \- Territory managers monitor that group managers are conducting the required reviews and timely inputting data into EQRS. |
| **Frequency** – Territory managers conduct a minimum of two (2) evaluative reviews per quarter of each GM’s employee performance reviews. During operational reviews, territory managers verify that group managers are utilizing FACR for at least 80 percent of their observations per employee and that they are inputting the DCI numbers in the Remarks section. Refer to the Verint 15.2 QuickGuide. Exceptions are validated and appropriate comments included in the operational review narrative. |
| **Documentation** – Written feedback for each review regarding the focus, substance and timeliness of the review. |
| **Reference** – _IRM 1.4.11.20.3_, Territory Manager Responsibilities. |






| **TAC Security and Remittances Review Database (TSRRD)** |
| :-: |
| **Purpose** \- The TSRRD is one of the management controls for FA. TMs use the TSRRD survey report to certify that the GM has conducted the required security and remittance processing reviews throughout the year and used the TSRRD to capture the results from the managerial reviews for each TAC that they manage. |
| **Frequency** – Quarterly, TMs must review the GM’s TSRRD results for accuracy. Results of the GM remittance reviews conducted during the quarter are used to answer the TSRRD survey questions. TMs must review and approve the TSRRD survey responses submitted by the GM prior to the deadline. |
| **Documentation** \- For all TSRRD surveys, once the GM completes the TSRRD survey, SharePoint will generate an email with the link to the TM for their review and approval. TMs may request documentation of the remittance reviews conducted during the quarter from GMs to support data submitted in the TSRRD survey report. The requested documentation may include the DCI, Forms 6067, Forms 14698-A and any other documentation used by the GM to complete the TSRRD survey report. The TM must review the TSRRD survey report for accuracy and completeness for each TAC within their territory and address any questions or concerns with the GM. Once the TM approves the TSRRD survey report SharePoint will generate an email to the GM with notification of the approval. |
| **Follow-up** – The operational review process can be used by the TM to document these actions. |
| **Retention** \- Copies of the approval email and when applicable, the email(s) of requested revisions to the TSRRD survey report for each TAC are part of the retention file kept by the GM which must be maintained for three (3) fiscal years from the date of review. |






| **Monthly Territory Manager’s Mandatory Reports** |
| :-: |
| **Purpose** \- The Trends and Patterns report is the vehicle Submission Processing sites use to provide feedback to TAC territory managers on errors that impact business results or customer satisfaction. |
| **Frequency** – Monthly. |
| **Documentation** \- The territory managers forward the monthly Trends and Patterns Report, and actions taken to address errors identified, to the area analyst and senior operations manager who informs the area director. |
| **Reference** – _IRM 1.4.11.7.5_, Trends and Patterns Report for Territory Manager and Group Manager Responsibility. |






| **Annual Form 809 Reconciliation** |
| :-: |
| **Purpose** \- Territory managers verify on an annual basis that the group managers conducted the annual reconciliation of official records. |
| **Frequency** – Annually. |
| **Documentation** \- The TM provides a consolidated response to the Form 809 coordinator by the due date shown in the memo issued from Submission Processing. |
| **Reference** – IRM 3.8.47.6.17, Annual Reconciliation of Official Receipts. |






| **Quarterly Section 1204 Certification** |
| :-: |
| **Purpose** \- Section 1204 provides guidance and instructions for the Restructuring and Reform Act of 1998 (RRA 1998) Section 1204 certification and independent review process. Section 1204(a) states that the "IRS shall not use records of tax enforcement results (ROTERs) to evaluate employees or to impose or suggest production quotas or goals with respect to such employees" . Section 1204(b) states "IRS shall use fair and equitable treatment of taxpayers as one of the standards for evaluating employee performance" . |
| **Frequency** – Territory managers certify quarterly whether or not tax enforcement results are being used in a manner prohibited by subsection (a). |
| **Documentation** \- Electronic Integrated Talent Management (ITM) Learning Module with SharePoint application for sharing possible non-compliance. |
| **Reference** – _IRM 1.4.11.22_, Section 1204 Certification Process. |


**1.4.11.20** **(01-02-2019)**

### Embedded Quality Roles and Responsibilities

1. To ensure the effectiveness of the Embedded Quality Review System (EQRS) specific roles and responsibilities are defined for Individual Taxpayer Advisory Specialist (ITAS), group managers, territory managers, area staff, and headquarters quality analyst staff. See _IRM 1.4.11.19_, Field Assistance Quality Review and Internal Controls, for information on the review process.


**1.4.11.20.1** **(02-20-2024)**

#### Employee Responsibilities

1. Individual Taxpayer Advisory Specialist (ITAS) use their reference material to answer accounts and tax law topics. If a tax law topic is covered in the Interactive Tax Law Assistant (ITLA), correct and complete use of ITLA is mandatory.

2. Group managers **must** share the NQRS reviews with the applicable employee to provide them with positive reinforcement as well as coaching/direction in areas identified for improvement. ITAS reviews the NQRS DCIs and advises the GM if they agree or disagree that the DCI correctly reflects the contact review. If the employee disagrees, they should present the reasons for their disagreement to their manager.

3. National reviews completed by CQRS may never be used as evaluative performance feedback or used in an employee evaluation. National Review DCIs are not filed in an employee’s Employee Performance File (EPF). The information from national reviews may be used to illustrate a point or as examples ONLY. DCI information used during group discussions about quality must be sanitized and generic; free of information that might identify an employee or a group.


**1.4.11.20.2** **(02-20-2024)**

#### Group Manager Responsibilities

1. Group managers are required to review, document and personally share at least one evaluative contact per employee per month; 12 evaluative reviews per employee per year. The focus of these managerial reviews is to document and improve employee performance. Contacts selected for review must have Customer Accuracy impact (Attribute 715 coded Y/N).

2. To the extent possible, contacts should include a mix of the work the employee performed during their rating period. FACR contacts should be selected for review based on the type of work the employee has performed. However, be cognizant of special assignment or exceptional service (positive or negative) which you observe and use the opportunity to reinforce excellent performance or bring a swift end to less than acceptable behavior. If improvement opportunities are identified, perform reviews that allow you to monitor the progress the employee is making in improving that aspect of their performance. Refer to the Verint 15.2 User Guide for FACR inbox setup and user guidance.

3. Review contacts in which new procedures are being introduced, new tax law is being applied, and/or areas of special emphasis identified by the Territory or Area. Cover the reference materials that explain the new procedures during group meetings and document this in the group meeting minutes.

4. Observe the full contact without distraction or interruption. In Social Security offices, use direct observation to accomplish this requirement. When FACR is available, recorded contacts are used to accomplish the required monitoring. The following practices should be followed in observations under either method:



1. Take detailed notes.

2. Validate the accuracy of actions through research in ITLA, Document 6209, and/or IRM(s).

3. Ensure all defects charged include specific IRM or other applicable references recorded in the feedback narrative of the DCI.

4. Use job aids located on the EQRS/NQRS Campus SharePoint Support Site (EQ Web) for guidance on attribute coding.

5. Input results into EQRS or prepare a Form 6067, Employee Performance Folder Record, within three (3) business days of the review.

6. Print and personally share (in person or over the phone) the feedback report with the ITAS in compliance with the National Agreement.


5. Advise the TM of any exceptions for not completing the required monthly reviews due to employee absences or assignments to other duties for the entire month such as acting manager details, other details, training (attending, teaching, OJI). The TM **must** provide the manager with a written waiver for any month the managers cannot complete the required reviews for these reasons and the waiver is filed in the employee’s EPF. Once the approved waiver is received there is no expectation the GM complete an additional review for that employee in the following month.

6. Review NQRS DCIs and forward any rebuttals on Form 14448, Quality Review Rebuttal Form, to the AQA. For guidance on the rebuttal process, see IRM 21.10.1.8.5, Field Assistance Quality Review Rebuttal Process.


**1.4.11.20.3** **(02-20-2024)**

#### Territory Manager Responsibilities

1. Territory managers are required to run EQRS reports for each GM and monitor to ensure required reviews are conducted and timely input into EQRS.

2. Territory managers must conduct a minimum of two evaluative reviews per quarter of each GM’s employee performance reviews and provide written feedback regarding the focus, substance and timeliness of the reviews.

3. During operational reviews, territory managers verify that group managers are utilizing FACR for at least 80 percent of their taxpayer contact observations per employee and that group managers are inputting the DCI numbers in the _Remarks_ section of the FACR recorded contact. Refer to the Verint 15.2 Quick Guide.



### Exception:



Employees in SSA offices are reviewed by direct observation.

4. Approve manager requests for waiver of the minimum monthly review requirement when an employee is absent from work or on assignment away from their ordinary customer assistance duties for the entire month. TMs must provide the approved written waivers of the monthly review requirement to the manager for placement in the EPF and provide a copy to the area quality analyst. These exceptions are validated, and appropriate comments included in the operational review narrative.



### Reminder:



Waivers are only granted for employee absences or work assignments. Managers are required to complete their monthly reviews and/or identify if assistance is needed to meet performance expectations.

5. Provide feedback and corrective actions in a formal action plan as needed for managers at risk of not completing monthly reviews and/or not providing adequate performance feedback.

6. Resolve any customer accuracy or accuracy driver discrepancies. If necessary, elevate the issue to the area quality analyst for clarification. Coach and educate group managers to reduce disparities between managerial reviews and NQRS customer accuracy rates.

7. Support the area in meeting or exceeding the accuracy goal for their area by ensuring group managers cover topics identified as reoccurring customer accuracy errors by reviewing group meeting minutes during operational reviews.


**1.4.11.20.4** **(01-02-2019)**

#### Area Director and Area Quality Analyst Responsibilities

1. Area directors and their staff support the EQRS process through the following actions:



1. Monitor completion of required minimum managerial EQRS reviews.

2. Verify territory managers are compliant with FACR responsibilities during operational reviews.

3. Review NQRS cumulative data and area analysis to ensure proactive steps are being taken to eliminate repeat customer accuracy errors.

4. Reduce the disparity between FACR managerial and NQRS customer accuracy rate by ensuring TMs are coaching and sharing a comparison of EQRS and NQRS reviews.


2. The AQAs are responsible for downloading NQRS reviews from the NQRS database weekly and sending the reviews to the group/territory manager. In addition, the area analyst should review monthly NQRS reports and determine if there is more than one customer accuracy error for the same case type. Share information with group managers and provide instruction for sharing corrective tax law or procedures during the next group meeting.

3. The AQA is responsible for determining if a rebuttal to a NQRS review should be forwarded CQRS for reconsideration. Submit any rebuttals following IRM 21.10.1.9.6, Field Assistance Quality Review Rebuttal Process. Resolve and escalate any unresolved or recurring EQ issues to the headquarters EQ analyst.


**1.4.11.20.5** **(01-02-2019)**

#### Headquarters Quality Analyst Responsibilities

1. Headquarters Quality Analysts (HQAs) are responsible ensuring the weekly sample is valid, uploaded and reviewed. The HQA maintains EQRS and NQRS attributes, Master Attribute Job Aids (MAJA), Quality Job Aides and EQ course material. In addition, the HQA has responsibility to:



01. Approve the national review quarterly sample plan and recommend annual funding allocation to CQRS to conduct the national review according to the sample plan.

02. Negotiate agreement with CQRS on rebuttals submitted by the areas and oversight for NQRS rebuttal process.

03. Decide final determinations on rebuttals at the 3rd level and communicate these decisions to the areas and CQRS.

04. Send weekly NQRS reports and communicate recommendations to area quality analysts, as needed.

05. Provide quarterly EQRS attribute use reports per the National Agreement to Labor Relations.

06. Provide quality related input/narrative for the Business Performance Review (BPR) and CARE operational review as well as for responses to external stakeholders regarding FA performance.

07. Analyze quarterly NQRS national trend reports for improvement opportunities.

08. Participate in area operational reviews, analyze area error trends, and look for efforts to improve quality.

09. Issue Quality Grams as needed.

10. Update CQRS on current FA procedures and provide guidance to advise CQRS on EQ coding guidelines.


**1.4.11.21** **(01-02-2019)**

### Field Assistance Engagement Plan

1. Managers create an engagement plan that defines how they involve their employees to improve workgroup processes and relationships.

2. The goal of the engagement plan is to enhance employee participation in improving business measures/results. This demonstrates to employees that their opinion counts and should result in measurable improvement in a specific business goal, process or problem.

3. At a minimum, the engagement plan includes:



1. Identification of the problem/process which the workgroup has the ability to control and improve.

2. Specifics of how the problem/process is connected to the Survey, Business Plan, and Performance Management System.

3. Specifics of how the workforce will be enabled and/or improved.

4. Specifics of what is communicated and how it is communicated to the workgroup.

5. Explanation of how the workforce will be motivated.

6. Explanation of how success will be celebrated.

7. Timelines.

8. Feedback mechanisms.

9. Quantitative and qualitative measurements.


4. Managers conduct workgroup meetings and ensure meeting minutes are kept. These meetings provide the manager the opportunity to employ the engagement process, and begin identifying barriers/challenges to improvement, solicit ideas, and create work group buy-in for improvement.


**1.4.11.21.1** **(01-04-2021)**

#### Awards and Recognition

1. Field Assistance is committed to providing a quality work environment that includes recognition of employee performance and contributions.

2. Two objectives guide group managers and employees regarding the work environment:



1. People should want to come to work every day.

2. People should be motivated to do their best every day.


3. Explore non-traditional means for recognizing superior performance on a daily basis and solicit feedback from employees for types of recognition that would be meaningful to them.

4. Use and encourage the use of guiding principles for employee recognition (based on industry research) listed below:



1. Recognizing good work when observed. The recognition should be as immediate as possible.

2. Recognizing good work in employees by managers and good work from managers by employees. Recognition is a two-way process.

3. Providing recognition that is not highly structured or expensive.

4. Ensuring the bulk of the recognition process is from the source closest to the employee or manager (e.g., the local or group level).


5. For guidance on awards and recognition, see Non-Monetary Awards and IRS Employee Recognition Program.


**1.4.11.22** **(12-22-2021)**

### Section 1204 Certification Process

1. Section 1204 provides guidance and instructions for the Restructuring and Reform Act of 1998 (RRA 1998) Section 1204 certification and independent review process.

2. Section 1204(a) states that the "IRS shall not use records of tax enforcement results (ROTERs) to evaluate employees or to impose or suggest production quotas or goals with respect to such employees."

3. Section 1204(b) states "IRS shall use fair and equitable treatment of taxpayers as one of the standards for evaluating employee performance" .

4. Certify quarterly whether tax enforcement results are used in a manner prohibited by subsection (a).

5. Complete Electronic Integrated Talent Management (ITM) Learning Module assigned to learning plan. If 1204 module is not in learning plan search for "1204" and add the module.

6. Each Area will send an email to HQ 1204 analyst certifying that Area certification is complete. HQ Analyst will send an email to CARE 1204 analyst certifying that Field Assistance certification is complete.

7. For further guidance, refer to IRM 1.5.3, Managing Statistics in a Balanced Measure System, Manager’s Self-Certification and the Independent Review Process.


**1.4.11.23** **(02-20-2024)**

### Field Assistance Corporate Training

1. Field Assistance (FA) has established a Training Program based on training concepts identified in IRM 6.410.1.1.1, Learning and Education (L&E) Policy, which provides essential information on education policy and procedures pertinent to conducting and managing employee training and development in the IRS to identify, develop and deliver training to all FA employees including analysts, managers, clerical/administrative staff and TAC employees. Training delivery varies based on several factors including efficiency and cost effectiveness. Training delivery methods include Adobe Connect, Microsoft Teams, DVD, Virtual Classroom, Continuing Professional Education (CPE), Self-Directed Learning Modules (SDLM), Group Meetings or Classroom.

2. No training is held during the filing season (limited exceptions).

3. This section explains the actions required prior to conducting Field Assistance (FA) Curriculum Training, as outlined in the FA Sequence classes. Responsibility is assigned for performing these actions to individuals and/or offices within FA. All training events/meeting classes must be pre-approved and the actions in the following paragraphs are organized accordingly.

4. The following activities are accomplished in an effort to most efficiently deliver training classes after headquarters receives budget approval of training pursuant to _IRM 1.4.11.23.10.2_, Field Assistance Headquarters Training Analyst.


**1.4.11.23.1** **(02-20-2024)**

#### Training Initial Actions

1. Identify employee training needs, technical classes to be delivered, and class dates for virtual or face-to-face classes. A need assessment is conducted periodically throughout each year according to a need (i.e., quarterly data call, and Annual Training Delivery Plan).

2. Prepare a needs assessment of FA training needs by:



1. Request a hiring projection report from FP&R.

2. Pull a training need report from Integrated Talent Management (ITM).

3. Use reports to determine Area/employee training needs.


3. Prepare/Submit Corporate Training Plan provided by Enterprise Talent Planning & Development (ETPD). See Treasury Directive 12-70, Policy and Guidance for Conference Approval, Planning and Reporting CARE PM/DFA for approval.



1. Secure training space via Resource Scheduler.

2. Create Servicewide Travel Estimator (STE).

3. Create Training-At-A-Glance spreadsheet.

4. Create Training Event Cost template.


4. Request re-approval for training when there is a change in the cost or if requested by CARE Planning and Analysis (P&A).



1. Document details of the change in an email and STE.

2. Send written request to CARE P&A.


5. After approval, headquarters analysts notifies the Area Training Analysts (ATA) of tentative classes, dates, and location by placing the approval documents on the Training Shared drive.

6. Prepare classroom hosting assignments.



1. Make hosting assignments equally located in all areas of Field Assistance.


7. When notified of classes being submitted for approval, the ATA Host submits a request the class support Form 13167, Request for Classroom Learning Service (CLS), to CLS. This includes requesting:



1. Course material, forms and publications, training supplies.

2. Instructor and Student Guides.

3. Class test, etc.

4. Other supporting forms and publications.


8. Copy headquarters training analyst on all email communications to CLS.



1. Block hotel rooms for the known participants/classes.

2. The CLS POC generates reporting instructions and sends then to the appropriate ATA Host.

3. Coordinate with CLS to ensure all course material is ordered including required forms and publications and training supplies.

4. Review all ordered course material and forms prior to distributing.


9. Once approved, the FAHQ training analyst notifies area training analyst of what classes are approved for delivery.


**1.4.11.23.2** **(02-20-2024)**

#### Training Approved: ATA Host Actions

1. | 30 - 45 days prior to the start of class, the ATA Host: |
| --- |
| Roster and Roster Selections – The ATA Host creates pre-populated class rosters according to:<br> <br>1. All class details including class name, course number, Internal Order (IO), class allocation, prep and class dates and class participants.<br>      <br>2. Area participant class allocations.<br>      <br>1. Review and complete _Training Needs Report_ from the ITM database and slot student according to "IRS Enter on Duty (EOD)."<br>      <br>2. Post rosters to the U: drive no later than 45 days before the start of class.<br>      <br>3. Advise the ATAs that a roster has posted and request that they notify the appropriate group manager(s) to inform the employee(s) of the requirement to attend training and confirm their availability to attend class.<br>      <br>4. Establish a specific due date for the ATAs to provide confirmation of attendance.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Employees with pre-approved leave are allowed to drop from class at that time. All subsequent requests to drop from class require documentation of emergency or medical necessity. Refer to _IRM 1.4.11.23.10.4_(3), Group Manager Roles.<br>      <br>5. Use the roster to solicit/select instructors from the other FA areas.<br>      <br>6. Distribute and request completion of the _Training Travel Worksheet_ to ALL class participants and provide a specific due date/time for response. Provide information needed to submit an accurate travel estimate such as:<br>      <br>      <br>      <br>      1. Reporting instructions and hotel information.<br>         <br>      2. Applicable lodging tax rate (include lodging tax exemption form).<br>         <br>      3. Local shuttle fees to/from the airport.<br>         <br>      4. Baggage fees. |






| 10 – 25 days prior to the start of class, the ATA Host: |
| --- |
| 1. Completes the class roster with the instructor names and cost estimates for all participants and instructors on the U: drive within ten (10) business days prior to the roster "Lock Date" .<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      the ATA host submits requests to change slot allocations to headquarters for approval. If approved, participants are added to the roster considering TAC needs, IRS EOD, Service Computation Date (SCD), etc.<br>      <br>2. Follow up with CLS on:<br>      <br>      <br>      <br>      1. Issuing Reporting Instructions.<br>         <br>      2. Ordering training materials in time for class.<br>         <br>      3. Correct materials have arrived (On the Job Instructor (OJI) material, and forms and publications) from the National Distribution Center (NDC).<br>         <br>      4. External issues are addressed:<br>         <br>         <br>          Solicit IT support to ensure all software applications required is available on the computers in the lab where training is delivered to include network connectivity, HUBS, etc.<br>         <br>         <br>          Security access issues to building and/or parking lot especially when classes are held.<br>         <br>3. The ATA for the area of the employee requesting accommodation works in conjunction with headquarters and the hosting area analyst to ensure that all special needs are accomplished.<br>      <br>4. Conduct a conference call with the instructor team and CLS to cover classroom logistics, including:<br>      <br>      <br>      <br>      1. Space, location, rental cars, special accommodations, instructor evaluations, classroom control, status of course material, and provide electronic course material and development guides to the instructor team.<br>         <br>      2. The host ensures reporting instructions are distributed and travel authorizations are input.<br>         <br>      3. The host also requests that CLS confirm whether the hotel charges lodging tax. In those instances where taxes are exempt, the _Tax Exemption Form_ is included when distributing the reporting instructions along with the travel Questions and Answers (Q&As).<br>         <br>5. Arrange for who opens the class, such as the Area Director or co-located territory/group manager.<br>      <br>      <br>      <br>      1. Class opening can also be conducted by the DFA or the Area Director using the Teams Meeting live with a webcam if prearranged with CLS and the necessary equipment is available in classroom.<br>         <br>      2. If no one is available, then CLS opens at campus locations.<br>         <br>6. Update the class roster, as needed, to ensure the travel authorizations are within the class allocation provided by Treasury and appropriate costs are reflected in the authorizations.<br>      <br>7. Verify travel authorizations are input ten (10) business days prior to students attending class and confirm that necessary expense estimates are included (i.e., shuttles, baggage fees, hotel tax, etc.), accurate travel codes are used, and authorization totals are within the allocated budget per _IRM 1.4.11.23.10.3_(1)(h), Area Training and Budget Analysts, by pulling an obligation report from the Integrated Financial System (IFS).<br>      <br>### Note:<br>If the ATA Host does not have access to IFS, he/she requests this information from the area budget analyst. If at any time the ATA host in their management of the class rosters believes there is potential for the class costs to exceed the class allocated budget, the host analyst must contact headquarters within one (1) business day and inform of the potential breach. |


**1.4.11.23.3** **(02-20-2024)**

#### Training Approved: FAHQ Training Analyst Actions

1. | 30 – 45 days prior to the start of class, the FAHQ Analysts: |
| --- |
| Roster and Roster Selections – Within 45 days prior to the start of class, The FAHQ Analysts:<br> <br>01. Send reminder for ATAs to provide pre-populated class rosters including All class details including class name, course number, Internal Order (IO), class allocation, prep and class dates and class participants. Area participant class allocations.<br>       <br>02. Review _Training Needs Report_ from the ITM database.<br>       <br>03. Send reminder to ATAs to begin providing rosters to the U: drive no later than 40-30 days before the start of class.<br>       <br>04. Advise the ATAs that a roster has posted and request that they notify the appropriate group manager(s) to inform the employee(s) of the requirement to attend training and confirm their availability to attend class.<br>       <br>05. Establish a specific due date for the ATAs to provide confirmation of attendance.<br>       <br>       <br>       <br>       ### Note:<br>       <br>       <br>       <br>       Employees with pre-approved leave are allowed to drop from class at that time. All subsequent requests to drop from class require documentation of emergency or medical necessity. Refer to _IRM 1.4.11.23.10.4_(3), Group Manager Roles.<br>       <br>06. Provide ATAs with the names of classes and the number of instructors that are needed to instruct upcoming classes. Request solicitation of instructors from areas where classes will be held.<br>       <br>07. Continue to monitor receipts of the _Training Travel Worksheet_ to ALL class participants and provide a specific due date/time for response through up to 30 days prior to the start of class.<br>       <br>08. Ensure that employee requests for reasonable accommodation and special needs are met.<br>       <br>09. Attend and support conference call with the instructor team and CLS to cover classroom logistics, including:<br>       <br>       <br>       <br>       1. Space, location, rental cars, special accommodations, instructor evaluations, classroom control, status of course material, and provide electronic course material and development guides to the instructor team.<br>          <br>       2. Ensure that CLS confirms with ATAs whether the hotel charges lodging tax. In those instances where taxes are exempt, the _Tax Exemption Form_ is included when distributing the reporting instructions along with the travel Questions and Answers (Q&As).<br>          <br>10. Request Update the class roster as needed to ensure the travel authorizations are within the class allocation provided by Treasury and appropriate costs are reflected in the authorizations. |






| 10 – 25 days prior to the start of class, the FAHQ Analysts: |
| --- |
| 01. Monitor U: drive up through ten (10) business days prior for the posting and changes made to the roster.<br>       <br>02. Continue to monitor receipts of the _Training Travel Worksheet_ to ALL class participants and provide a specific due date/time for response through up to 35-15 days prior to the start of class.<br>       <br>03. Monitor the posting of class rosters with the instructor names and cost estimates for all participants and instructors on the U: drive within ten (10) business days prior to the roster "Lock Date" .<br>       <br>       <br>       <br>       ### Note:<br>       <br>       <br>       <br>       The ATA host submits requests to change slot allocations to headquarters for approval. If approved, participants are added to the roster considering TAC needs, IRS EOD, Service Computation Date (SCD), etc.<br>       <br>04. Assist with Follow-up with CLS within 15 days prior to the start of class for the following:<br>       <br>       <br>       <br>       1. Issuing Reporting Instructions.<br>          <br>       2. Ordering training materials in time for class.<br>          <br>       3. Ensuring correct materials have arrived (On the Job Instructor (OJI) material, and forms and publications) from the National Distribution Center (NDC).<br>          <br>       4. Ensure that external issues are addressed, such as:<br>          <br>          <br>           Solicit IT support to ensure all software applications required is available on the computers in the lab where training is delivered to include network connectivity, HUBS, etc.<br>          <br>          <br>           Security access issues to building and/or parking lot especially when classes are held.<br>          <br>05. Within 15-10 days prior to class, FAHQ reconciles the list of new hire employees who have received their travel card and access to Concur to the list of new hires listed on the Financial Planning & Resources (FP&R) new hire report.<br>       <br>06. Ensure that employee requests for reasonable accommodation and special needs are met.<br>       <br>07. Attend and support conference call with the instructor team and CLS to cover classroom logistics, including:<br>       <br>       <br>       <br>       1. Space, location, rental cars, special accommodations, instructor evaluations, classroom control, status of course material, and provide electronic course material and development guides to the instructor team.<br>          <br>       2. Ensure that CLS confirm with ATAs whether the hotel charges lodging tax. In those instances where taxes are exempt, the _Tax Exemption Form_ is included when distributing the reporting instructions along with the travel Questions and Answers (Q&As).<br>          <br>08. Assist with arrangements for who opens the class, such as the Area Director or co-located territory/group manager.<br>       <br>       <br>       <br>       1. Class opening can also be conducted by the DFA or the Area Director using the Teams Meeting live with a webcam if prearranged with CLS and the necessary equipment is available in classroom.<br>          <br>       2. If no one is available, then CLS opens at campus locations.<br>          <br>09. Request Update the class roster as needed to ensure the travel authorizations are within the class allocation provided by Treasury and appropriate costs are reflected in the authorizations.<br>       <br>10. Ensure ATAs that travel authorizations are input ten (10) business days prior to students attending class and confirm: assist with resolving any discrepancies related to necessary expense estimates are included (i.e., shuttles, baggage fees, hotel tax, etc.), accurate travel codes are used, and authorization totals are within the allocated budget per _IRM 1.4.11.23.10.3_(1)(h), Area Training and Budget Analysts, by pulling an obligation report from the Integrated Financial System (IFS).<br>       <br>11. Within seven (7) days after all training travel costs are input into concur, FAHQ analyst verifies Concur travel approval request are accurate and ensure total cost do not exceed approval cost. Monitor to confirm costs are within the allocated budget, and accurate travel codes are used, per _IRM 1.4.11.23.10.3_(1)(i), Area Training and Budget Analysts. If training cost exceed total cost, training is adjusted to reduce total cost.<br>       <br>### Note:<br>If it appears that the actual amount of the voucher exceeds the approved allocation, notify headquarters immediately providing a detailed explanation of what actions and costs lead to the overage. |


**1.4.11.23.4** **(12-22-2021)**

#### Beginning of Face-to-Face Class Delivery

1. | Beginning of Face-to-Face Class Delivery |
| --- |
| 1. Headquarters locks or closes rosters to any changes or revisions seven (7) to ten (10) business days prior to the start of the class. Any additions or changes to the roster after this time require approval of the host’s area director and then headquarters by using the Training Withdrawal Form.<br>      <br>2. HQ Training monitors and updates DFA on training plan changes.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      Seven (7) business days, prior to the start of class, headquarters sends the posted class roster(s) to the area SOMs with a cc to the ADs.<br>      <br>3. Review and close the final class rosters prior to employees attending.<br>      <br>4. Confirm that rosters reflect attendees accurately on first day of class.<br>      <br>5. Five (5) business days before the start of the class, headquarters obtains an IFS report for the class and review to confirm that each student and instructor input travel authorizations.<br>      <br>6. In the event any questions or concerns arise, headquarters communicates with the ATA Host and area analysts as needed to resolve the issue. The ATA Host remains available to troubleshoot any problems the instructor team may encounter if CLS is not able to resolve.<br>      <br>7. On the first day of class FAHQ Analysts work in conjunction with ATAs to schedule a class opening. A first day opening could include one or more of:<br>      <br>      <br>      <br>      1. CLS opening involving administrative housekeeping information.<br>         <br>      2. Q&A from area or HQ Executives.<br>         <br>      3. Announcements from FA Training teams.<br>         <br>8. Provide the ATA Host a copy of the class roster signed by each student to confirm class attendance per _IRM 1.4.11.23.10.5_(1)(c), Instructor Responsibilities.<br>      <br>9. Review any discrepancies on final roster posted to the U: drive within five (5) business days of the class end.<br>      <br>      <br>      <br>      1. Provide the ATA hosting the class with a copy of the class agenda that shows a breakdown of the topics to cover in the class.<br>         <br>      2. The ATA host posts to the U: drive within five (5) business days of the class end. |


**1.4.11.23.5** **(12-22-2021)**

#### Completed Face-to-Face Class

1. | By the End of the Class |
| --- |
| 1. The CLS provides the ATA hosting the class and headquarters with a copy of the instructor evaluations if an evaluation is requested by the instructor’s area management.<br>      <br>2. Instructor team requests that CLS mail, or send electronically, the students’ development guides and/or OJI material and a copy of the class agenda to their respective Group Managers.<br>      <br>3. Within five (5) days after the end of class, CLS ensures completion of the class is entered for each participant in the Integrated Talent Management System.<br>      <br>4. Within eight (8) days after the end of class, the ATA Host initiates conference call with the instructor team and FAHQ to ensure actions to close out the class are completed or are underway.<br>      <br>      <br>      <br>      1. This call is an opportunity for the Instructor team to provide feedback about the class with emphasis on future improvements and an errata sheet on any errors found in the course material for the Learning and Education (L&E) Design Center.<br>         <br>      2. FAHQ prepares an errata sheet summarizing an informal survey of the class within 10 days of the end of the conference call.<br>         <br>5. Each ATAs must verify travel vouchers are input within five (5) business days after class completion, voucher totals are within the allocated budget, and accurate travel codes are used, per _IRM 1.4.11.23.10.3_(1)(i), Area Training and Budget Analysts. FAHQ Training follows-up with this action ten (10) business days after the class is complete.<br>      <br>      <br>      <br>      ### Note:<br>      <br>      <br>      <br>      If it appears that the actual amount of the voucher exceeds the approved allocation, notify headquarters immediately providing a detailed explanation of what actions and costs lead to the overage.<br>      <br>6. The ATA finalizes the rosters on the U: Drive by entering the final voucher amounts for each instructor and student associated with the class. |


**1.4.11.23.6** **(02-20-2024)**

#### Virtual Classroom Training

1. Virtual training is used as an alternative to face-to-face training. Virtual training utilizes electronic meeting technology such as Adobe Connect and Microsoft Teams to bring participants together in a virtual classroom rather than traveling to physical classroom in a face-to-face environment. Virtual classroom training is instructor led, not self-study.

2. The FAHQ Training Team determines which courses can be delivered virtually without diminishing effectiveness; and solicits field expertise to assist with converting traditional course material to Power Point for virtual presentation.

3. After determining a course can be delivered virtually without diminishing the effectiveness of the learning experience, FAHQ Training Analysts take the following actions to prepare the course for virtual delivery via Adobe Connect or Microsoft Teams.



1. Conduct a review of the course to estimate the resources and time needed to efficiently convert the course content into material ready for virtual delivery.

2. Use the estimate to develop a project plan to convert the course and submit it for Section Chief approval.




      | The plan includes: |
      | --- |
      | Assessment of the length and complexity of the course. |
      | If the course requires technical updates. |
      | The number, timeframe needed, and expertise level of Subject Matter Experts (SMEs). |
      | Tentative start and target end dates. |
      | A draft email to solicit SMEs (from the field) including specific skills/training level/Power Point experience. |


4. Field Assistance headquarters manages the conversion project and present the final converted course material for review and submission.


**1.4.11.23.7** **(02-20-2024)**

#### Virtual Classroom Training Delivery

1. Actions required to deliver virtual classroom training mirror those of traditional classroom delivery with the following exception:




| 30-45 days prior to the start of class, the specified analysts ensure the following are completed. |
| --- |
| 1. Roster and Roster Selections –ATA hosting the training:<br>      <br>      <br>      <br>      1. Creates class rosters according to area participant class allocations.<br>         <br>      2. Pulls a _Training Needs Report_ ITM database and slotted according to "IRS Enter on Duty (EOD)" .<br>         <br>      3. Headquarters verifies the training need report with the training need and availability according to ATA host at least 30 days before the start of class.<br>         <br>2. The analysts notify the appropriate group manager(s) to:<br>      <br>      <br>      <br>      1. Inform employees of the requirement to attend training. Employees with pre-approved leave are allowed to drop from class at that time.<br>         <br>      2. All subsequent requests to drop from class require documentation of emergency or medical necessity. Refer to _IRM 1.4.11.23.10.4_(3), Group Manager Roles, for the approval process of documentation.<br>         <br>3. The ATA host uses the roster to solicit for instructors. The ATA host:<br>      <br>      <br>      <br>      1. Solicits/selects instructors from areas hosting the training.<br>         <br>      2. Instructors are required to complete training according to IRM 6.410.1.4.4.1, Instructors.<br>         <br>4. If there are requests for changes to slot allocations, the ATA hosting the class must seek approval from headquarters. If approved, participants are added to the roster considering TAC needs, IRS EOD, Service Computation Date (SCD), etc.<br>      <br>5. The ATA hosting the class updates the roster to the U: drive within ten (10) business days prior to the roster "Lock Date" .<br>      <br>6. The ATA for the area of the employee requesting accommodation works in conjunction with headquarters and the hosting area analyst to ensure that all special needs are accomplished.<br>      <br>7. The ATA hosting the class follows up on the ordering of training material with Alternative Media and Publication to ensure correct course material, On the Job Instructor (OJI) material, and forms and publications are ordered timely from the National Distribution Center (NDC).<br>      <br>8. The ATA hosting the class ensures any and all external issues are addressed, i.e., solicit IT support to ensure all software applications required is available on the computers in the area TACs or laptops for virtual delivery to include network connectivity, etc. |






| During the 30 days prior to the start of class, the specified analysts conduct the following to ensure everyone is ready for training. |
| --- |
| 1. The ATA works in conjunction with headquarters training analysts and Virtual Learning Management Office teams to finalize delivery of status of course material and provide electronic course material and development guides to the instructor team.<br>      <br>2. The Virtual Learning Management Office support team ensures reporting instructions are distributed.<br>      <br>3. The ATA hosting the class updates the class roster where necessary and ensure that headquarters review, document and ensure the Virtual Learning Management Office makes changes to the roster prior to the start of class.<br>      <br>4. The Virtual Learning Management Office support team ensures reporting instructions are distributed to all students.<br>      <br>5. The Virtual Learning Management Office support team provides the hosting ATA and the HQ Training team with copies of the reporting instructions.<br>      <br>6. The Virtual Learning Management Office support team verifies attendance within 10 business days prior to students attending class.<br>      <br>7. ATAs lock or close rosters to any changes or revisions beginning of business seven (7) business days prior to the start of the class. Headquarters verifies any changes to the roster to the Virtual Learning Management Office team.<br>      <br>8. The Virtual Learning Management Office Primary support POC assists with technical issues with opening the class. The ATA and headquarters training schedules dates and times for attendance from upper management to open the class. Director Field Assistance, Area Director, or co-located territory/group managers may open the class by using Adobe Connect or Teams meeting. |






| By the end of the first day of class, the lead or associate instructor completes the following. |
| --- |
| 1. Provide the ATA hosting the class with an emailed copy of the class roster to confirm class attendance per _IRM 1.4.11.23.10.5_(1)(c), Instructor Responsibilities. The ATA host notifies headquarters of any discrepancies and posts the final roster to the U: drive within five (5) business days of the class end.<br>      <br>2. Provide the ATA hosting the class with a copy of the class agenda that shows a breakdown of the topics to cover in the class. The ATA host posts to the U: drive within five (5) business days of the class end.<br>      <br>3. The area analyst hosting the class is available to troubleshoot any problems the instructor team may encounter if the Virtual Learning Management Office Primary POC is not able to resolve. |






| By the end of class, the following is done. |
| --- |
| 1. The instructor team provides an attendance list to the Virtual Learning Management Office, to the hosting ATA and to headquarters on the last day of class.<br>      <br>2. The Virtual Learning Management Office assigns certified credit to each attendee on ITM.<br>      <br>3. The Virtual Learning Management Office initiates a Level 1 evaluation to each attendee in the class according to IRM 6.410.1.4.4, Instructors.<br>      <br>4. Instructor team provides development guides and/or OJI material to their respective GM and include a copy of the class agenda. If electronic versions are available, these may be forwarded to the group managers in place of the hard copy versions.<br>      <br>5. Instructor team:<br>      <br>      <br>      <br>      1. Provides feedback via conference call or email with headquarters and ATAs on the class for future improvements and an errata sheet on any errors found in the course material for elevation to the Learning and Education (L&E).<br>         <br>      2. The conference call allows for communication, exchange of ideas and an opportunity to voice concerns with the area and headquarters.<br>         <br>      3. This call takes place within two (2) weeks after the class ends. |

2. IRM references for FA training:



1. _IRM 1.4.11.23_, Field Assistance Corporate Training, for FA training program.

2. _IRM 1.4.11.23.10_, Roles and Responsibilities, for project leader, HQ training analysts, area training and budget analyst, GM responsibility and instructor responsibility.


**1.4.11.23.8** **(01-02-2019)**

#### Field Assistance Taxpayer Assistance Center (TAC) Employee Training

1. Field Assistance created ITAS and IAR curriculums to help ensure employees working in TACs receive adequate training.

2. Managers must update the ITM learning plans of new hire employees within five (5) business days of their enter on duty date to reflect their FA training needs.

3. All ITAS and IAR employees must attend continuing professional education (CPE) each year. Contact the ATA for additional information. Also, reference IRM 21.3.4.25.2, Continuing Professional Education.

4. Employee training histories should be kept up to date on ITM. See established guidelines detailed in _IRM 1.4.11.23.10.3_, Area Training and Budget Analysts.

5. To add, correct, or update information in an ITM learning history, refer to the Centralized Delivery Services website for information on how to complete Form 12201, Integrated Talent Management (ITM) System Learning/Teaching History. The manager needs to:



1. Ensure the employee has signed and dated Form 12201, Integrated Talent Management (ITM) System Learning/Teaching History.

2. Ensure proof of completed learning activities is attached to the Employee Resource Center (ERC) ticket (manager or employee may submit the ticket).


**1.4.11.23.8.1** **(01-02-2019)**

##### On-the-Job Training (OJT)

1. Provide OJT to develop employee knowledge, skills, and abilities to deliver quality service to TAC taxpayers. This program is essential in providing excellent service to taxpayers.

2. All OJT is up to half the number of hours as the corresponding formal training class and e-learning.



### Example:



A training class that is 40 classroom hours and 20 e-learning hours would allow for up to 30 hours of OJT.

3. Each territory assigns one experienced On-the-Job Instructor (OJI) with both Classroom Instructor Training Class (CITC) and OJI training as the territory lead OJI. The lead OJI devotes up to 25 - 30 percent of their time.

4. Lead OJIs are competitively selected. Once selected, candidates must complete FA lead OJI training. The lead OJI assignment is for a period of up to 24 months to allow for training and adjust to the new responsibilities. At the area’s discretion, the lead OJI positions may be announced on a rotational schedule.

5. Areas have the discretion to set up a cadre or a lead OJI per territory depending on their needs, allowing flexibility to do either depending on circumstances at the time the lead OJI position(s) are announced.

6. On-the-Job Instructors conduct non-evaluative Embedded Quality Review System (EQRS) reviews during the OJT period.


**1.4.11.23.8.1.1** **(01-02-2019)**

###### Territory Lead Responsibilities

1. Consult with the ATA to establish the list of trainees ready for OJT.

2. Assist managers and OJIs to develop individualized OJT plans for each trainee based on instructor feedback in the OJT guide and student identified opportunities for improvement.

3. Develop exercises and examples that can be made available to FA training.

4. Provide backup and assistance to territory OJIs as necessary.

5. Attend Training Analyst conference calls for all lead OJIs and conference calls for instructors, OJIs and managers following each classroom training class.

6. Ensure completed OJT is recorded in the ITM learning history of each trainee who has completed OJT.


**1.4.11.23.8.1.2** **(01-02-2020)**

###### Group Manager Responsibilities

1. Managers provide OJIs appropriate time to work with assigned trainees. Assign OJI responsibilities only to an ITAS with knowledge of the topics covered in the course material and formal OJI training. OJIs who have not had a coaching assignment in the past two years are required to be recertified.

2. Managers are required to ensure that every trainee who attends formal training is provided timely OJT that follows the following prescribed requirements:




| Group Manager OJT Requirements: |
| --- |
| Use the OJT checklist for each trainee. |
| Assign an OJI to each trainee and inform ATA of assigned OJI. |
| Attend ATA conference calls (at GM’s discretion) with the OJIs and the classroom instructors to discuss how the formal training is delivered and any problems encountered. |
| Use the OJT administrative guide, OJT toolkit, development guide and OJT workbook to deliver the OJT program within the group. |
| Develop an OJT plan for each trainee with the OJI to ensure that OJT targets the right topics and be delivered effectively. The OJT plan can be found embedded in the OJT checklist. |
| Schedule uninterrupted time for both the OJI and trainees to complete the OJT plan including completion of any required e-learning courses. |
| Ensure the OJI is completing non-evaluative EQRS reviews during the OJT period. |
| Assess each trainee’s skills and provide them with a Certificate of Proficiency letter once required skills are obtained. The certificate of proficiency grants the trainee permission to answer taxpayer’s questions on the certified topics. This marks the completion of OJT. Certificate of Proficiency should be placed in the employee performance file (EPF).<br> <br>### Note:<br>Any trainee that is not certified to answer a topic at the end of OJT must complete additional work on the topic under the GM's supervision. |


**1.4.11.23.8.1.3** **(01-02-2020)**

###### Area Training Analyst Responsibilities

1. Area Training Analysts are responsible for supporting delivery of the OJT program in the area per established guidelines detailed in _IRM 1.4.11.23.10.3_, Area Training and Budget Analysts.




| Additional oversight responsibilities for the OJT program: |
| --- |
| 1. Conduct conference calls with classroom instructors, OJIs, and trainees’ managers to discuss OJT needs by topic for each class conducted in the area.<br>      <br>2. Maintain a list of area OJIs on OJT SharePoint site.<br>      <br>3. Conduct conference calls with territory lead OJIs to support ongoing OJT and to discuss improvements to the OJT program. |


**1.4.11.23.8.1.4** **(01-02-2020)**

###### Territory Manager Responsibilities

1. The Territory manager is accountable for ensuring the territory employees attending formal training are provided with timely OJT that follows the prescribed requirements and ensuring their territory has a territory lead OJI and that the lead OJI performs the duties prescribed above.

2. If a territory employee does not receive the OJT training as prescribed, the TM discusses with the GM the requirements of the OJT program and determine when the OJT for the employee can be completed.


**1.4.11.23.8.1.5** **(01-02-2019)**

###### Area Director Responsibilities

1. Each area director is accountable for ensuring that every employee who attends formal training is provided with timely OJT that follows prescribed requirements.


**1.4.11.23.8.2** **(01-02-2019)**

##### Directed Learning

1. FA group managers are required to provide up to one hour of uninterrupted time each week for technical employees (CSR/ITAS) in TACs for directed learning of technical issues, mini-training sessions, or read time. Self-Directed Learning Modules (SDLM) are available for this purpose.

2. Time allotted for directed learning can also be used to cover other training needs identified by Quality Review results, as well as policy, procedural, and technical changes made during the year.


**1.4.11.23.9** **(01-02-2019)**

#### Training for Field Assistance Managers

1. Every GM must be trained in FA policies, procedures, and systems to effectively manage a TAC. All GMs are required to complete the "Managing a TAC" course and complete the "Continued Professional Education Workshop for Field Assistance Managers" as assigned.

2. Every TM must be trained in FA policies, procedures, and systems to effectively manage a territory. All TMs are required to complete the "Managing a Territory" course.

3. In addition, all managers are required to self-enroll in all other mandatory "Leadership Training" as directed by the Human Capitol Office.


**1.4.11.23.10** **(01-02-2019)**

#### Roles and Responsibilities

1. Project leaders, Program Analysts, and Training Analysts all have vital roles in ensuring quality training material exists and is taught in the most efficient and effective manner.


**1.4.11.23.10.1** **(01-02-2019)**

##### Project Leaders

1. Project Leaders are responsible for ensuring quality training material is developed and delivered for the projects they lead. Below is a list of required duties.



### Note:



Additional duties may be added by the DFA as needed.





01. Submit justification for all resource requirements for DFA approval (e.g., equipment, travel, tools, training, course development needs, etc.).

02. Request for Program and/or Training Funding must be submitted when forming projects.

03. Notify the headquarters training analyst of all projects prior to developing any training needs.

04. Develop and monitor project training plan and expenditures. This includes verifying timely, accurate input of travel authorizations and vouchers.



       ### Note:



       Ensure that reporting instructions, travel authorizations and vouchers have the correct funding codes. Each voucher must contain the assigned Internal Order Code. Contact the headquarters budget analyst if an Internal Order Code is needed.

05. Provide training plan, delivery and expenditure updates to budget analyst.

06. Identify new and revised course development needs, including job aids.

07. Identify number of Subject Matter Experts (SMEs) needed for course or job aid development.

08. Brief the DFA on project status.

09. Identify outsource training needs.

10. Consult with FA headquarters training and budget analysts for guidance as needed.

11. Adhere to off-site training approval requirements, including cost comparisons.


**1.4.11.23.10.2** **(12-22-2021)**

##### Field Assistance Headquarters Training Analyst

1. All FA headquarters training analysts are responsible for overall oversight of the FA training plan. Below is a list of required duties.



01. Coordinate all training and conference requests with ETPD, who processes all training and conferences in _Servicewide Training Event Tracking System_.

02. Coordinate efforts to assess FA training needs. Once the Learning Product Development Plan (LPDP), Training Needs Assessment (TNA) document, and Annual Training Delivery Plan (ATDP) are approved by the DFA, they must be timely submitted to CARE.



       ### Note:



       The DFA must approve and sign these documents.






       | Get input for Training Needs Assessment (TNA) projections/development from the following sources: |
       | --- |
       | - Quality reports<br>         <br>       - Hiring reports<br>         <br>       - ITM employee history<br>         <br>       - Area training analysts<br>         <br>       - Headquarters program analysts for new workload (new ITAS work, new project, etc.)<br>         <br>       - DFA for priority needs |

03. Incorporate Project spending and training development plan into the overall FA Annual Training Plan.

04. Issue final training delivery plan and LPDP with project managers, area training analysts, and L&E project manager.

05. Submit quarterly training requests to Strategy and Finance (S&F) for TS and/or Treasury approval.

06. Monitor and update DFA on training plan changes in scope, timelines or deliverables. Send copies to TS, L&E and area training analysts.

07. Inform DFA and appropriate staff of emerging issues, non-adherence to procedures that may jeopardize budget reports, etc.

08. Review classroom evaluation data in ITM for course improvement needs. This information must be provided to TS L&E and/or SMEs for course development.

09. Create email to solicit for bi-annual Subject Matter Expert (SME) cadre for DFA distribution using the statement of interest document.



       ### Note:



       SMEs should primarily consist of GS-11 employees. GS-9 employees may also be utilized. If GS-9 employees are the majority, DFA must be notified immediately.

10. Develop Instructor solicitation template and requirements.

11. Request new Internal Order codes for courses from Finance if needed.

12. Coordinate with FA headquarters budget analyst prior to revising budget (including changes to approved training allocations, moving training from one area or date to another, etc.). Include affected area analyst in coordination if appropriate.

13. Ensure FA headquarters budget analyst posts the IFS report to the U-Drive. All budget reports are developed using this IFS report.

14. Coordinate annual Training Analysts conference/training.



       ### Note:



       Reporting due dates for the year are established by the FA headquarters budget analyst.

15. Follow-up every 60 days to confirm FA employees, including managers, have received the mandatory and required training until completed.



       ### Note:



       Additional duties may be added by the DFA as needed.


**1.4.11.23.10.3** **(05-03-2019)**

##### Area Training and Budget Analysts

1. Area training and budget analysts are responsible for overall oversight of the FA training plan for their area. Assignment of the duties is determined by the AD. Below is a list of required duties.



01. Coordinate efforts to assess area training needs. Training needs are submitted to headquarters for consolidation. The following sources should be used to help determine area training needs: Quality reports, ITM employee history, and field input.

02. Ensure all employees receive training required by the job classiﬁcation. Use the curricula to help determine training gaps.

03. Ensure new hire employees’ training needs are added to their ITM learning plan within five (5) days of their enter on duty date.

04. Communicate to managers that the training expectation is for employees in work and non-work status to complete all mandatory or required training within 30 calendar days of return to duty.

05. Follow-up every 45 days to confirm FA employees, including managers, have received mandatory and required training and report the status to the headquarters training analyst.

06. Provide guidance and support on training issues to all field managers and employees.

07. Serve as area training point of contact.

08. Serve as host for classes (create roster for hosted classes, share roster with impacted area training analysts, and post the final roster to the U-drive).

09. Ensure students complete and submit cost estimate worksheets prior to inputting authorizations.

10. Verify travel authorizations are input prior to students attending class and accurate travel codes are used.

11. Verify travel vouchers are input within five (5) days after class completion and accurate travel codes are used.

12. Maintain a current list of instructors, SMEs and OJIs for the area.

13. Evaluate training classes (budget permitting) and review evaluations. Suggestions to improve future classes should be shared with the headquarters training analyst.

14. Ensure class registration is input into ITM by CLS. If the information has not posted within five (5) – seven (7) days of the end of class, notify CLS Point of Contact.

15. Coordinate Adobe Connect or Microsoft Teams sessions, Adobe Connect or Microsoft Teams orientation for new employees, identify instructors, set up sessions, provide material for sessions, create and maintain roster.

16. Perform other duties as needed (solicit for instructors, monitor class roster, revise and distribute reporting instructions, follow up on Form 13167, Request for Centralized Delivery Services Support, submitted to CLS by FAHQ training).

17. Ensure developmental guides are received by group managers after completion of classroom training.



       ### Note:



       Additional duties may be added by the DFA or AD as needed.


2. See the Training Delivery Check Sheet, for additional guidance when delivering classes.


**1.4.11.23.10.4** **(01-02-2020)**

##### Group Manager Roles

1. Group managers play a vital role in the FA training program. They must ensure training curriculums are completed for themselves as well as their employees. Below is a list of duties that helps determine training needs.



1. Review training history in ITM for mandatory and/or required training and take action to address employee training needs.

2. Ensure training is completed for employees in work and non-work status no later than 30 calendar days of return to duty.

3. Direct employees to complete Form 12201, Integrated Talent Management (ITM) System Learning/Teaching History, and follow the procedures in _IRM 1.4.11.23.8_, Field Assistance TAC Employee Training, if discrepancies are discovered in the training history.



      ### Note:



      Employee training courses may be waived by the GM **ONLY** if the employee has previously completed "Comparable Training Courses" in the employ of another federal agency or IRS business unit. Proof must be documented and maintained by manager.


2. Upon review and assessment take actions to address employee training needs. Action could include:



1. Schedule E-Learning.

2. Help employees put into practice training skills learned by assigning them work to reinforce those skills.

3. Ensure employees receive OJT/OJI support.



      ### Note:



      OJT is mandatory. See _IRM 1.4.11.23.8.1.2_, Group Manager Responsibilities.

4. Ensure employee received additional training for technical classes based on recommendations made by the instructor in the course developmental guide.

5. Track the completion of directed learning lessons.

6. Provide ATA the employee’s training needs.


3. Once a roster for a scheduled class is distributed to the GM by the ATA, the GM should:



1. Review the employee’s training history.

2. Confirm the employee’s availability.

3. Submit the confirmation to attend training to the ATA.



      ### Note:



      The GM should ONLY remove employees with pre-approved leave.

4. Require documentation of emergency/medical necessity for all subsequent request to not report to class.

5. Submit GM approved medical/emergency requests to the TM for final approval with a cc to ATA.



      ### Note:



      The ATA advises the headquarters training analyst of any schedule changes as soon as they are known, and HQ provides a substitute attendee from EOD/training needs roster.


4. Group managers must monitor training travel for their employees. Actions include:



1. Review and verify travel authorizations are input and cost estimates are complete and accurate prior to students attending class. This includes utilizing the Travel Authorization Worksheet and the Travel Cost Comparison Worksheet as warranted for each traveler's specific circumstances.

2. Review and verify travel vouchers with reporting instructions are accurate and submitted for approval within five (5) business days after the conclusion of training classes.

3. Direct any discrepancies or questions to the ATA.


**1.4.11.23.10.5** **(01-02-2019)**

##### Instructor Responsibilities

1. Instructors should make every effort to ensure classes are effectively and efficiently taught. Students should be actively engaged in each lesson. Additional duties are:



01. Use preparation time efficiently, including reviewing the course material and completing any ERRATA sheets as necessary. This ensures the smooth delivery of course material during class time.

02. Ensure class roster is received from ATA.

03. Verify student attendance in class for names listed on the roster. If a student does not attend or is replaced, notate this on the roster and notify the ATA immediately.

04. Return verified class roster to ATA at the end of the first day of class.

05. Reinforce the necessity of course evaluations and comments. Class evaluations and comments from students and instructors are used as appropriate during course updates.

06. Reinforce the use of correct travel codes on travel vouchers as provided by the student's specific area.

07. Reinforce the need to file travel vouchers within five (5) days after the travel has ended.

08. Ensure each trainee receives counseling at the beginning, middle and end of OJT.

09. Ensure developmental guides are completed for all tested modules.

10. After the class, submit the ERRATA sheet with any revisions made during the class to the area host analyst who then posts it to the OJI SharePoint site for future use as needed.

11. If any employee conduct issues arise, contact the ATA immediately.


2. See the Training Delivery Check Sheet, for additional guidance when delivering classes.


**Exhibit 1.4.11-1**

### Field Assistance Section 3709-Line Telephone Scripts

| **Script for Single TAC Location** |
| --- |
| Thank you for calling the Internal Revenue Service office located at \_\_\_\_\_\_\_\_\_\_ (insert street address, city, state, and zip code). We do not provide live telephone assistance at this number. To schedule an appointment, call us at 844-545-5640. Our office hours are Monday through Friday from 8:30 a.m. to 4:30 p.m. \[If applicable: This location is closed for lunch from 11:30a- 12:00p M-F\]. Many self-service options are available on [IRS.gov](https://www.irs.gov/), such as making a payment or getting a transcript. Before you request an appointment go to [IRS.gov](https://www.irs.gov/) and select 'Contact Your Local Office' for a complete list of available services at this location. You may be asked to provide valid photo identification and a Taxpayer Identification Number, such as a Social Security Number, to receive services. Thank you for calling the Internal Revenue Service. |

| **Script for Multi-TAC Location** |
| --- |
| Thank you for calling the Internal Revenue Service office located at \_\_\_\_\_\_\_\_\_\_ (insert street address, city, state, and zip code of each TAC). We do not provide live telephone assistance at this number. To schedule an appointment, call us at 844-545-5640. Our office hours are Monday through Friday from 8:30 a.m. to 4:30 p.m. \[If applicable: This location is closed for lunch from 11:30a- 12:00p M-F\]. Many self-service options are available on [IRS.gov](https://www.irs.gov/), such as making a payment or getting a transcript. Before you request an appointment go to [IRS.gov](https://www.irs.gov/) and select 'Contact Your Local Office' for a complete list of available services at this location. You may be asked to provide valid photo identification and a Taxpayer Identification Number, such as a Social Security Number, to receive services. Thank you for calling the Internal Revenue Service. |

| **Script for TACs Closing and Section 3709-Line will be Disconnected** |
| --- |
| Thank you for calling the Internal Revenue Service office located at \_\_\_\_\_\_\_\_\_\_ (insert street address, city, state, and zip code). We do not provide live telephone assistance at this number.<br> Effective \_\_\_\_\_\_\_\_ (insert date) walk-in assistance is not available in this office, but you may find the help you need at [IRS.gov](https://www.irs.gov/). If you want to call us, for individual tax information call 800-829-1040, or for business taxes you may call 800-829-4933.<br> To schedule an appointment at our office located at \_\_\_\_\_\_\_\_\_\_ (give nearest TAC address, city, state, and zip code), call 844-545-5640. You may be asked to provide valid photo identification and a Taxpayer Identification Number, such as a Social Security Number, to receive services.<br> Thank you for calling the Internal Revenue Service. |

| **Script for Section 3709-Line Post of Duty (No TAC In POD)** |
| --- |
| Thank you for calling the Internal Revenue Service office located at \_\_\_\_\_\_\_\_\_\_ (insert street address, city, state, and zip code). We do not provide live telephone assistance at this number.<br> Find the help you need at [IRS.gov](https://www.irs.gov/). If you want to call us, for individual tax information call 800-829-1040, or for business taxes you may call 800-829-4933.<br> For in-person help you can also visit our office located at \_\_\_\_\_\_\_\_\_\_ (give nearest TAC address, city, state, and zip code). To Schedule an appointment, call us at 844-545-5640. You may be asked to provide valid photo identification and a Taxpayer Identification Number, such as a Social Security Number, to receive services. Thank you for calling the Internal Revenue Service. |

| **Script for Disaster-Related TAC Closures** |
| --- |
| Thank you for calling the Internal Revenue Service office located at \_\_\_\_\_\_\_\_\_\_ (insert street address, city, state, and zip code). We do not provide live telephone assistance at this number. Due to damages sustained during\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ (Insert name of disaster, e.g., Hurricane Katrina), this office is closed indefinitely. For Disaster Assistance - dial 866-562-5227.<br> Find the help you need at [IRS.gov](https://www.irs.gov/). If you want to call us, for individual tax information call 800-829-1040, or for business taxes you may call 800-829-4933. Thank you for calling the Internal Revenue Service. |

| **Script for Temporarily Closed, Unstaffed TACs** |
| :-: |
| Thank you for calling the Internal Revenue Service office located at \_\_\_\_\_\_\_\_\_\_ (insert street address, city, state, and zip code). We do not provide live telephone assistance at this number. Effective \_\_\_\_\_\_\_\_ (insert date) walk-in assistance is currently not available in this office.<br> (**Insert ONLY if re-open date available**) This office will re-open \_\_\_\_\_\_\_\_\_\_(insert date).<br> You may find the help you need at [IRS.gov](https://www.irs.gov/). If you want to call us, for individual tax information call 800-829-1040, or for business taxes you may call 800-829-4933.<br> <br>### Note:<br>_If another TAC is located within 100 miles of closed TAC, use the following paragraph_.<br> To schedule an appointment at our office located at \_\_\_\_\_\_ (give nearest TAC address, city, state, and zip code), call us at 844-545-5640.<br> Thank you for calling the Internal Revenue Service. |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-004-011#addtoany "Show all")

A2A