---
url: "https://www.irs.gov/irm/part1/irm_01-025-002"
title: "1.25.2 Practitioner Enrollment | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-025-002#main-content)

- 1.25.2  [Practitioner Enrollment](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600541422272)
  - 1.25.2.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539601984)
    - 1.25.2.1.1  [Background of the Enrolled Practitioner Program](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569741504)
      - 1.25.2.1.1.1  [Eligibility for Enrollment](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539477984)
      - 1.25.2.1.1.2  [Special Enrollment Examination (SEE)](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540404416)
      - 1.25.2.1.1.3  [Former IRS Employees](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600570494048)
      - 1.25.2.1.1.4  [Enrollment Renewals](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539485440)
    - 1.25.2.1.2  [Authority](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539455536)
    - 1.25.2.1.3  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569485792)
    - 1.25.2.1.4  [Program Controls](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569482544)
    - 1.25.2.1.5  [Forms](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600570455856)
    - 1.25.2.1.6  [Acronyms](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600570452800)
    - 1.25.2.1.7  [Related Resources](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600541428208)
  - 1.25.2.2  [E-Trak Practitioner Database (E-Trak)](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539508912)
  - 1.25.2.3  [Responsibilities of Enrolled Agent Policy & Management (EAP&M)](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539505712)
    - 1.25.2.3.1  [Program Time Frames](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539237728)
    - 1.25.2.3.2  [Processing Incoming Mail](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600570404224)
      - 1.25.2.3.2.1  [Discovered Remittances](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569643776)
    - 1.25.2.3.3  [New Enrollment](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569597504)
      - 1.25.2.3.3.1  [Unprocessable Applications](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540293312)
      - 1.25.2.3.3.2  [Receiving and Assigning](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540446784)
      - 1.25.2.3.3.3  [Initial Review](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540444400)
      - 1.25.2.3.3.4  [Processing the Application](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539298864)
      - 1.25.2.3.3.5  [Ineligible Applicants](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600570361008)
      - 1.25.2.3.3.6  [Generating and Issuing New Enrollment Cards and Certificates](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539390176)
    - 1.25.2.3.4  [Enrollment Renewal](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539280736)
      - 1.25.2.3.4.1  [Unprocessable Renewal Applications](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539277072)
      - 1.25.2.3.4.2  [Receiving and Assigning](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539758048)
      - 1.25.2.3.4.3  [Reviewing and Processing](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539755504)
      - 1.25.2.3.4.4  [Continuing Education Requirements](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540513504)
      - 1.25.2.3.4.5  [Continuing Education Waivers](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540509536)
      - 1.25.2.3.4.6  [Inactive Retirement Status](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540474704)
      - 1.25.2.3.4.7  [Generating and Issuing Renewed Enrollment Cards](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569797696)
    - 1.25.2.3.5  [Former IRS Employees](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540379840)
      - 1.25.2.3.5.1  [TIGTA Record Check](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540373968)
    - 1.25.2.3.6  [Missing Information](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539396064)
      - 1.25.2.3.6.1  [Telephone and Email Requests for Missing Information](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600540427776)
      - 1.25.2.3.6.2  [Letter Requests for Missing Information](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539640240)
    - 1.25.2.3.7  [Referrals to RPO Suitability](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539368976)
      - 1.25.2.3.7.1  [Determinations made by RPO Suitability](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539540672)
    - 1.25.2.3.8  [Responding to Email Inquiries](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539537824)
    - 1.25.2.3.9  [The Enrolled Practitioner Helpline](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539576336)
      - 1.25.2.3.9.1  [Telephone Protocol](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539573088)
      - 1.25.2.3.9.2  [Telephone Procedures](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539628016)
      - 1.25.2.3.9.3  [Authentication](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539401840)
      - 1.25.2.3.9.4  [Common Call Topics](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539527152)
      - 1.25.2.3.9.5  [Out-of-Scope Topics](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569690976)
      - 1.25.2.3.9.6  [Wrap Time](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569687536)
    - 1.25.2.3.10  [Deceased, Expired, or Suspended PTIN](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600569685088)
  - Exhibit  1.25.2-1  [Responding to Written Requests and Other Correspondence](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539448928)
  - Exhibit  1.25.2-2  [Former Employee Examination Waiver Position Matrix](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539340592)
  - Exhibit  1.25.2-3  [Responding to Telephone Calls](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539201856)
  - Exhibit  1.25.2-4  [Responding to Email Inquiries](https://www.irs.gov/irm/part1/irm_01-025-002#idm140600539685072)

# Part 1. Organization, Finance, and Management

# Chapter 25. Practice Before the Service

# Section 2. Practitioner Enrollment

* * *

## 1.25.2 Practitioner Enrollment

#### Manual Transmittal

November 18, 2022

#### Purpose

(1) This transmits revised IRM 1.25.2, Practice Before the Service, Practitioner Enrollment.

#### Background

This IRM describes how to administer the enrolled practitioner program for Enrolled Agents and Enrolled Retirement Plan Agents.

#### Material Changes

(1) IRM 1.25.2.1.1.4 - Added ERPA renewal chart.

(2) IRM 1.25.2.3.2.1, Lockbox Mail - Removed subsection and removed or updated references to Lockbox processing throughout.

(3) IRM 1.25.2.3.3.2, Receiving and Assigning - Changed references from EAP&M Manager to System Analyst.

(4) IRM 1.25.2.3.3.4, Processing the Application - Added a requirement to write the enrollment number on the application.

(5) IRM 1.25.2.3.4.2, Receiving and Assigning - Changed references from EAP&M Manager to System Analyst.

(6) IRM 1.25.2.3.4.6, Inactive Retirement Status - Added note clarifying the active PTIN requirement.

(7) IRM 1.25.2.3.7, Referrals to RPO Suitability - Added references to tax compliance and criminal background checks.

(8) IRM 1.25.2.3.8, Responding to Email Inquiries - Updated procedures for handling incoming emails

(9) IRM 1.25.2.3.9.3, Authentication - Added procedures to continue validating a call when the caller is unable to validate with their address.

(10) IRM 1.25.2.3.10, Deceased, Expired, or Suspended PTIN - Added section for handling deceased, expired, and suspended PTIN accounts.

(11) Exhibit 1.25.2-4, Responding to Email Inquiries - Added exhibit with instructions for processing specific email inquiries.

(12) Revised the Internal Revenue Manual (IRM), where necessary, for the following types of editorial changes:

- Updated dates and processing timeframes throughout

- Spelling, grammar, formatting, and plain language

- IRM references, citations, and links


#### Effect on Other Documents

IRM 1.25.2 dated May 01, 2020, is superseded.

#### Audience

The staff of the Enrolled Agent Policy & Management unit in the Return Preparer Office.

#### Effective Date

(11-18-2022)

Carol A. Campbell

Director, Return Preparer Office

**1.25.2.1** **(11-18-2022)**

### Program Scope and Objectives

1. **Purpose**. This section describes how to administer the enrolled practitioner program for enrolled agents and enrolled retirement plan agents. The program involves receiving, evaluating, processing and approving applications for those seeking enrolled agent status in order to practice before the IRS, as well as processing renewal applications for enrolled agents (EAs) and enrolled retirement plan agents (ERPAs) and providing telephone support for program participants. Practice before the IRS includes all matters connected with a presentation to the IRS, or any of its officers or employees, relating to a taxpayer’s rights, privileges, or liabilities under laws or regulations administered by the IRS. For more information about practice before the IRS, see IRM 1.25.1, Rules Governing Practice Before the IRS.

2. **Audience**. The instructions herein are directed at employees of the Enrolled Agent Policy & Management (EAP&M) unit in the Return Preparer Office (RPO).

3. **Program Owner**. The Director, EAP&M, administers the enrolled practitioner program.

4. **Policy Owner**. The Director, RPO, is responsible for the policies and administration of the enrolled practitioner program contained in this section. The Director, Office of Professional Responsibility (OPR), is primarily responsible for administering and enforcing Treasury Department Circular 230, _Regulations Governing Practice before the Internal Revenue Service_ (Circular 230).

5. **Stakeholders**. To process applications for enrollment and renewal, EAP&M interacts with applicants, practitioners, RPO Suitability, OPR, and the Treasury Inspector General for Tax Administration (TIGTA).

6. **Contact information**. EAP&M contact information is located at [https://www.irs.gov/tax-professionals/enrolled-agents/contact-the-office-of-enrollment](https://www.irs.gov/tax-professionals/enrolled-agents/contact-the-office-of-enrollment).


**1.25.2.1.1** **(11-18-2022)**

#### Background of the Enrolled Practitioner Program

1. An enrolled practitioner (enrolled agent or enrolled retirement plan agent) is a person who has earned the privilege of representing taxpayers before the IRS by either passing a comprehensive IRS test or through experience as a former IRS employee. Enrollment is the highest credential the IRS awards. Individuals who obtain this status must adhere to ethical standards and complete 72 hours of continuing education courses every three years.

2. This section covers specifically EAs and ERPAs.

3. The IRS no longer accepts new applications to become an ERPA but continues to renew existing ERPA enrollments.


**1.25.2.1.1.1** **(11-18-2022)**

##### Eligibility for Enrollment

1. To become an EA, an applicant must:



1. Obtain a Preparer Tax Identification Number (PTIN).

2. Pass all three parts of the Special Enrollment Examination (SEE) or be a former IRS employee who held a qualifying position with the IRS.

3. Submit Form 23, Application for Enrollment to Practice before the Internal Revenue Service. If the applicant took the SEE, Form 23 must be filed within one year of the date the applicant passed the third or final exam part.

4. Pay all required application fees.

5. Pass a suitability review. The applicant must not have engaged in incompetent or disreputable conduct as described in Circular 230 §10.51.


**1.25.2.1.1.2** **(11-18-2022)**

##### Special Enrollment Examination (SEE)

1. An IRS contractor administers the SEE between May and February every year.

2. Applicants may schedule an exam by accessing the testing vendor’s website, calling the testing vendor’s telephone help line, or submitting Form 2587, Application for Special Enrollment Examination. Contact information for the testing vendor can be accessed via [https://www.irs.gov/tax-professionals/enrolled-agents/become-an-enrolled-agent](https://www.irs.gov/tax-professionals/enrolled-agents/become-an-enrolled-agent).



### Note:



An applicant must have a PTIN to take the SEE (the PTIN is used as the SEE Candidate Number).

3. Former IRS employees may not be required to take the SEE in order to become an EA (see _IRM 1.25.2.1.1.3_ for details).


**1.25.2.1.1.3** **(11-18-2022)**

##### Former IRS Employees

1. Former IRS employees qualify for a waiver of the enrollment examination and obtain enrollment status if they:



1. Apply for enrollment within three years of their separation date from the IRS;

2. Had a minimum of five years of continuous employment with the IRS in which they regularly engaged in applying and interpreting the provisions of the Internal Revenue Code and regulations relating to income, estate, gift, employment, or excise taxes;

3. Meet the technical qualifications required under Circular 230 §10.4 which include having a minimum of five consecutive years of technical qualifying experience or an aggregate of 10 years or more of IRS employment in positions involving the application and interpretation of the Internal Revenue Code, of which at least three years have occurred within the five years preceding the date of application; and

4. Have not engaged in conduct that would justify the suspension or disbarment of any practitioner. Disreputable conduct is outlined in Circular 230 §10.51.


2. A former employee will qualify for either unlimited or limited enrollment status.



1. To qualify for unlimited enrollment, a former employee must have the required experience and training in both examination and collection matters. See _Exhibit 1.25.2-2_, Former Employee Examination Waiver Position Matrix, for more information.

2. Former employees not qualifying for unlimited enrollment may be eligible for either examination or collection limited enrollment status based upon the technical qualifications and the role they served with the IRS.


**1.25.2.1.1.4** **(11-18-2022)**

##### Enrollment Renewals

1. EAs and ERPAs are required to renew their enrollment every three years. To renew enrollment, EAs and ERPAs must:



1. Have a valid PTIN (EAs only).

2. Attest that the required continuing education (CE) hours were completed. See _IRM 1.25.2.3.4.4_ for the CE requirements.

3. Submit Form 8554, Application for Renewal of Enrollment to Practice Before the Internal Revenue Service, or Form 8554-EP, Application for Renewal of Enrollment to Practice Before the Internal Revenue Service as an Enrolled Retirement Plan Agent, as applicable.

4. Pay the application renewal fee.

5. Pass a suitability review. The applicant must not be deemed incompetent or disreputable as described in Circular 230 §10.51.


2. For EAs:



1. The last digit of the EA's Social Security Number (SSN) determines the year of renewal; therefore, the first renewal cycle after enrollment may be shorter than three years. See the table below.

2. The renewal application period begins on November 1 and ends on January 31.

3. The enrollment period runs through March 31 of the third year following renewal.

4. The issue date for new enrollment cards is April 1 of the year of renewal.


| IF the SSN ends in | THEN renew between |
| --- | --- |
| 0, 1, 2 or 3 | November 1, 2021 and January 31, 2022 |
| 4, 5 or 6 | November 1, 2022 and January 31, 2023 |
| 7, 8, 9 or no SSN | November 1, 2023 and January 31, 2024 |

3. For ERPAs:



1. The renewal application period begins on April 1 and ends on June 30 every third year subsequent to initial enrollment.

2. The enrollment period runs through September 30 of the third year following renewal.

3. The issue date for new enrollment cards is October 1 of the year of renewal.


|     |     |
| --- | --- |
| IF the SSN ends in | THEN renew between |
| 0, 1, 2 or 3 | April 1, 2022 and June 30, 2022 |
| 4, 5, or 6 | April 1, 2023 and June 30, 2023 |
| 7, 8, 9, or no SSN | April 1, 2024 and June 30, 2024 |

**1.25.2.1.2** **(11-18-2022)**

#### Authority

1. Treasury Department Circular Number 230, Regulations Governing Practice before the Internal Revenue Service, or “Circular 230”, provides the authority to regulate individuals who practice before the IRS:



1. Enrolled Agents (EAs)

2. Enrolled Retirement Plan Agents (ERPAs)

3. Enrolled Actuaries

4. Certified Public Accountants (CPAs)

5. Attorneys

6. Appraisers


2. Revenue Procedure 2014-42 provides that tax return preparers who engage in practice before the IRS are subject to the rules of practice in Circular 230 and to §10.51.


**1.25.2.1.3** **(11-18-2022)**

#### Responsibilities

1. The EAP&M director is the senior manager responsible for oversight of the enrolled practitioner program.

2. The EAP&M manager is responsible for ensuring the program instructions are communicated to and carried out by the proper employees.

3. The EAP&M Legal Instrument Examiners (LIEs) are responsible for processing enrollment and renewal applications and answering inquiries from program participants.


**1.25.2.1.4** **(11-18-2022)**

#### Program Controls

1. An Unprocessable Application Report identifies applications submitted in Pay.gov that cannot be linked to an existing enrollment account or examination record. This report mitigates the risk that these unmatched applications will not be identified and timely processed.

2. A quality review team regularly monitors a randomly selected sample of telephone calls placed to the Enrolled Practitioner Helpline, listening for employees’ adherence to the policies and procedures in this section. The review team records their results in the National Quality Review System (NQRS) and generates regular reports for management.

3. The EAP&M group manager performs reviews on a sample of the employees’ work to ensure employees are following all procedures.


**1.25.2.1.5** **(11-18-2022)**

#### Forms

1. Form 23, Application for Enrollment to Practice Before the Internal Revenue Service

2. Form 8554, Application for Renewal of Enrollment to Practice Before the Internal Revenue Service

3. Form 8554-EP, Application for Renewal of Enrollment to Practice Before the Internal Revenue Service as an Enrolled Retirement Plan Agent (ERPA)

4. Form 2587, Application for Special Enrollment Examination


**1.25.2.1.6** **(11-18-2022)**

#### Acronyms

01. ALERTS - Automated Labor Employee Relations Tracking System

02. CE - Continuing education

03. CPA - Certified Public Accountant

04. EA - Enrolled agent

05. EAP&M - Enrolled Agent Policy & Management office

06. ERPA - Enrolled retirement plan agent

07. LIE - Legal Instrument Examiner

08. OPR - Office of Professional Responsibility

09. PII - Personally Identifiable Information

10. PTIN - Preparer Tax Identification Number

11. RPO - Return Preparer Office

12. SEE - Special Enrollment Examination

13. SLIE - Senior Legal Instrument Examiner

14. TIGTA - Treasury Inspector General for Tax Administration


**1.25.2.1.7** **(11-18-2022)**

#### Related Resources

1. RPO website at https://irssource.web.irs.gov/RPO/Pages/Home.aspx

2. Tax professionals website at [https://www.irs.gov/tax-professionals](https://www.irs.gov/tax-professionals)

3. OPR disciplinary website at [https://www.irs.gov/tax-professionals/search-for-disciplined-tax-professionals](https://www.irs.gov/tax-professionals/search-for-disciplined-tax-professionals)

4. Treasury Department Circular Number 230, _Regulations Governing Practice before the Internal Revenue Service_.

5. IRM 1.25.1, Rules Governing Practice Before the IRS.


**1.25.2.2** **(11-18-2022)**

### E-Trak Practitioner Database (E-Trak)

1. The E-Trak Practitioner database (E-Trak) is the system used to capture data from EA/ERPA enrollment and renewal applications.

2. Applications are entered into E-Trak electronically through the Pay.gov interface, or manually from paper applications mailed to the EAP&M unit.


**1.25.2.3** **(11-18-2022)**

### Responsibilities of Enrolled Agent Policy & Management (EAP&M)

1. EAP&M processes Forms 23, determines basic eligibility, and issues enrollment cards and certificates to all applicants who qualify for EA status.

2. EAP&M processes Forms 8554 and Forms 8554-EP for renewal of enrollment.

3. EAP&M responds to inquiries about the enrollment program that come via mail, email and telephone.


**1.25.2.3.1** **(11-18-2022)**

#### Program Time Frames

1. Time frames for performing the program work are set by management and vary depending on the time of year. Generally, time frames are as follows:



1. Discovered remittances must be processed within 24 hours of receipt in EAP&M.

2. Forms 23 and 8554/8554-EP must be processed within 60 days of receipt in EAP&M, unless an extended review is required, in which case they must be processed within 90 days.

3. Written correspondence must be processed within 30 days of receipt in EAP&M.

4. Email correspondence must be processed within 3 business days of receipt in EAP&M.

5. Undelivered mail must be handled within two weeks of receipt in EAP&M.



      ### Note:



      During December through March, undelivered mail is a lower priority and may be handled within 30 days of receipt.


**1.25.2.3.2** **(11-18-2022)**

#### Processing Incoming Mail

1. Incoming mail includes:



   - General correspondence

   - Enrollment and renewal applications

   - Checks and money orders


2. Handle incoming mail as follows:



1. Retrieve mail from the mail room at least once per day.

2. Within 24 hours of retrieval, open and date-stamp each piece of mail.

3. Separate EA/ERPA correspondence for input to E-Trak and sort all other mail by type.


3. Correspondence often includes requests for action or information. For examples of the types of requests and how to resolve them, see Exhibit 1.25.2-1.


**1.25.2.3.2.1** **(11-18-2022)**

##### Discovered Remittances

1. Applicants who apply by paper mail payments directly to EAP&M. These payments are classified as "discovered remittances."

2. EAP&M must forward discovered remittances within 24 hours of receipt using overnight mail to:


    IRS


    c/o Enrolled Agents


    110 N. Herber Street


    Beckley, WV 25802

3. Attach a Form 3210, Document Transmittal, when sending payments:



1. Enter the applicant’s full name, the dollar amount, check number, and the applicant’s enrollment number, if applicable.

2. Prepare a copy for the Beckley Finance Center.

3. Prepare another copy for the "Discovered Remittance" binder.


4. If a discovered remittance is non-negotiable, the manager will notify the LIE. The LIE will take the following actions:



1. Generate a Bad Check/Missing Payment Letter to advise the applicant of the situation.

2. Update E-Trak with the activity (Bad Check/Insufficient Funds).



      ### Note:



      Checks are deemed non-negotiable if any of the following is true: Stale, future or missing date, missing signature or missing “pay to the order of”.


**1.25.2.3.3** **(11-18-2022)**

#### New Enrollment

1. Enrollment is requested by submitting Form 23 or applying online at Pay.gov.

2. Electronic applications migrate directly into E-Trak to create a data record; EAP&M staff manually enters data from paper applications into E-Trak.

3. The names of individuals who pass all three parts of the SEE are loaded into E-Trak through a file transfer from the testing contractor. This creates an indicator that a new applicant has passed the examination.

4. E-Trak automatically links an application record with the applicant’s examination record.


**1.25.2.3.3.1** **(11-18-2022)**

##### Unprocessable Applications

1. E-Trak generates an Unprocessable Application Report for all enrollment applications that cannot be linked to an examination record.

2. For applications on the report, verify the lack of an examination record by reviewing the Pay.gov record to locate the identifying information, specifically the PTIN or name, and then attempting to locate the examination record in E-Trak using the same identifier.

3. If no examination record exists in E-Trak, review Form 23 to determine if the applicant is a former IRS employee. A former employee indicator is located at the top of the form.



1. If the applicant is a former employee, update E-Trak to show the applicant’s eligibility as "FE" , then continue processing the application according to _IRM 1.25.2.3.3.3_.

2. If the applicant is not a former employee and there is no examination record for the applicant, follow the instructions in _IRM 1.25.2.3.3.3_.


**1.25.2.3.3.2** **(11-18-2022)**

##### Receiving and Assigning

1. E-Trak sends a daily email to the EAP&M manager and System Analyst showing the new enrollment applications that have been loaded from Pay.gov.

2. The System Analyst uses this list of electronic applications, plus any incoming paper applications, to assign inventory.


**1.25.2.3.3.3** **(11-18-2022)**

##### Initial Review

1. LIEs must complete the processing of Form 23 within 60 days of receipt in EAP&M, unless a referral to RPO Suitability is necessary, in which case it should be completed within 90 days of receipt. See _IRM 1.25.2.3.7_ for criteria requiring a referral to RPO Suitability.

2. Upon being assigned an application, ensure that all information has been accurately transferred from the application into the E-Trak record.

3. Review the application for the following:



1. Completeness - Confirm that the application contains all required information.

2. Valid PTIN - Research IDRS, command code RPVUE.

3. Examination record - Search E-Trak to confirm the applicant passed the SEE.


4. If any of the above application criteria are not met, perform any additional research that may resolve the issue(s). Also determine if contact with the applicant is necessary (this may involve requesting additional documentation). Follow guidance in _IRM 1.25.2.3.6_ to obtain missing information. Add any missing information you find to the E-Trak record.

5. Indicate in E-Trak, by checking Yes or No, whether all application criteria have been met.



1. If the above criteria have been met, reassign the E-Trak record to RPO Suitability for a personal tax compliance check. See IRM 25.20.3 for information about the personal tax compliance checks.



      ### Exception:



      Do not reassign the record to RPO Suitability if the applicant does not have an SSN.

2. If any criteria have not been met, the applicant is not eligible for enrollment. Follow instructions for ineligible applicants in _IRM 1.25.2.3.3.5_.


**1.25.2.3.3.4** **(11-18-2022)**

##### Processing the Application

1. RPO Suitability will determine if the applicant passes the personal tax compliance and criminal background check.



1. If the applicant passes the personal tax compliance and criminal background check, RPO Suitability will reassign the E-Trak record to EAP&M for processing.

2. If the applicant does not pass the personal tax compliance and criminal background check, RPO Suitability will issue a Denial letter to the applicant and reassign the E-Trak record to EAP&M. Once reassigned, EAP&M will update the E-Trak record to reflect the denial status. The Legal Instrument Examiner (LIE) will take no further action on the application.


2. Review the applicant information for a finding that may cause the applicant to be unsuitable, as follows:



1. Note if the applicant responded "Yes" to any of the following questions. Also confirm that required documentation is attached.




       • Have you been sanctioned by a federal or state licensing authority?


       • Has any application you filed with a court, government department, commission, or agency for admission to practice ever been denied?


       • Have you been convicted of a tax crime or any felony?


       • Have you been permanently enjoined from preparing tax returns, or representing others before the IRS?

2. Search the OPR disciplinary website at [https://www.irs.gov/tax-professionals/search-for-disciplined-tax-professionals](https://www.irs.gov/tax-professionals/search-for-disciplined-tax-professionals) to determine if the applicant was the subject of prior disciplinary action.

3. Consider any activity found in the E-Trak record that may impact suitability.


3. If the applicant has self-identified as a former IRS employee, also perform steps in _IRM 1.25.2.3.5_.

4. If any of the above steps indicate that the applicant is potentially unsuitable for enrollment, or if the applicant is a former employee, route the application to RPO Suitability following instructions in _IRM 1.25.2.3.7_.

5. If the applicant meets the above suitability criteria, and if applicable, the former employee check has been completed by RPO Suitability, then application processing is complete and enrollment can be granted. Generate the certificate and enrollment card as described in _IRM 1.25.2.3.3.6_.


**1.25.2.3.3.5** **(11-18-2022)**

##### Ineligible Applicants

1. If any application criteria _other than suitability as described in _IRM 1.25.2.3.3.4 (2)__ are not met, update the application status to "Ineligible" in E-Trak and issue Letter 5509, Enrolled Agent (EA) Ineligibility.

2. The applicant has 30 days to respond to Letter 5509. Monitor the case for the end of the 30-day suspense period.

3. After the 30-day period has expired:




| IF | THEN |
| --- | --- |
| a response to Letter 5509 is received and resolves the unmet application criteria, | continue processing the application for enrollment. |
| a response to Letter 5509 is received but does not resolve the unmet criteria, | note in E-Trak the information received and reason it does not resolve ineligibility. |
| no response to Letter 5509is received, | no action is necessary. |

4. An EA/ERPA who is ineligible to practice before the IRS due to a disciplinary sanction must meet all enrollment requirements before eligibility can be restored.


**1.25.2.3.3.6** **(11-18-2022)**

##### Generating and Issuing New Enrollment Cards and Certificates

1. Between October 1 and October 31, check the last digit of the applicant’s SSN to determine if he or she is due for renewal in the upcoming renewal cycle. If so, delay final processing until November 1st to avoid the applicant having to apply for renewal in the upcoming cycle.

2. Confirm that the enrollment status and cycle are correct in E-Trak.

3. To generate the cards, take the following actions on the “Enrollment Process Activity” tab in E-Trak:



1. Select "Enrollment Approved" with the current date.

2. Select "Print Enrollment Card" with the current date.

3. Open and print the enrollment card.


4. Print the enrollment certificate from the EAP&M SharePoint site.

5. Select "Mailed Enrollment Package" with the current date.


**1.25.2.3.4** **(11-18-2022)**

#### Enrollment Renewal

1. Enrollment is renewed either by submitting Form 8554/Form 8554-EP or online via Pay.gov.

2. In late October or early November of each year, RPO issues a reminder notice via email to all EAs who are due for renewal in the upcoming cycle.



### Note:



Failure to receive the reminder notice is not justification for failure to file a renewal application \[Circular 230 §10.6(d)(1)\].

3. EAs/ERPAs who do not renew timely may not continue to practice before the IRS.


**1.25.2.3.4.1** **(11-18-2022)**

##### Unprocessable Renewal Applications

1. E-Trak generates an Unprocessable Application Report for all renewal applications that cannot be linked to an existing record in E-Trak.

2. For applications on the report, verify the lack of an E-Trak record by reviewing the Pay.gov record to locate the name and enrollment number and then attempting to locate the record in E-Trak using those same identifiers. The SSN may also be used as an identifier.

3. Whether or not the E-Trak record is located, continue processing the renewal application according to _IRM 1.25.2.3.4.3_.


**1.25.2.3.4.2** **(11-18-2022)**

##### Receiving and Assigning

1. On a daily basis, E-Trak sends an email to the EAP&M manager and System Analyst showing the renewal applications that have been loaded into Pay.gov.

2. The System Analyst uses this list of electronic renewal applications, plus any incoming paper Forms 8554/Forms 8554-EP, to assign inventory.


**1.25.2.3.4.3** **(11-18-2022)**

##### Reviewing and Processing

1. LIEs must complete the processing of Form 8554/Form 8554-EP within 60 days of receipt in EAP&M unless a referral to RPO Suitability is required. See _IRM 1.25.2.3.7_ for criteria requiring a referral to RPO Suitability.

2. Upon being assigned a renewal application, ensure that all information has been accurately transferred from the application into the E-Trak record.

3. Verify the following information in E-Trak and update as necessary:



   - Name

   - Address

   - Telephone number(s)

   - Email address

   - SSN


4. Review the renewal application for the following criteria:




| Application Criteria | Action(s) |
| --- | --- |
| Completeness | Confirm that the application contains all required information. |
| Valid PTIN (EAs only) | Research IDRS, command code RPVUE |
| CE requirement | 1. See _IRM 1.25.2.3.4.4_ for CE requirements.<br>      <br>2. Verify that the correct number of total hours are listed.<br>      <br>3. Verify that the correct number of ethics hours are listed.<br>      <br>4. Using the testing contractor database, determine if the applicant retook and passed the examination in order to get CE hours. Passage of the examination accounts for 56 hours of CE. |
| Suitability | Search for a finding that may cause the applicant to be unsuitable by following the steps in _IRM 1.25.2.3.3.4 (2)_. |

5. If all renewal application criteria are met, the renewal process is complete. Generate and print the new enrollment card as described in _IRM 1.25.2.3.3.6_.

6. For any unmet renewal application criteria, perform any additional research that may resolve the issue(s). Also determine if contact with the applicant is necessary. This may involve requesting additional documentation. Follow guidance in _IRM 1.25.2.3.6_ to obtain missing information. Add any missing information you found to the E-Trak record.

7. After resolving or attempting to resolve all unmet application criteria, indicate whether all application criteria have been met by checking Yes or No in E-Trak.



1. If all the above criteria are met, the renewal process is complete. Generate and print the new enrollment card as described in _IRM 1.25.2.3.3.6_.

2. If the only unmet criterion is suitability as outlined in _IRM 1.25.2.3.3.4 (2)_, route the application to RPO Suitability following instructions in _IRM 1.25.2.3.7_. Also route the application to the queue for issuance of a new enrollment card (renewed enrollment cards are issued even if the application requires further review by RPO Suitability).



      ### Note:



      If the applicant checked the Suspended or Disbarred status box in Part 1 of the application, do not refer it to RPO Suitability. Instead, refer it to the EAP&M manager, who will contact the applicant to advise that no new enrollment card will be issued until the suspension or disbarment is lifted.

3. If any renewal application criteria _other than suitability_ are not met, no action is required. The applicant will be considered inactive once the renewal period expires and will receive a systemically-generated inactive letter.


**1.25.2.3.4.4** **(11-18-2022)**

##### Continuing Education Requirements

1. During each continuing education (CE) year, which runs from January 1 through December 31, an EA/ERPA must take a minimum of 16 hours of CE, including at least two hours of ethics or professional conduct training. An EA/ERPA must complete at least 72 hours of CE during the three-year enrollment cycle.

2. EAs/ERPAs who are renewing for the first time are required to take two hours of CE for each month enrolled, including the month of enrollment. This must include at least two hours of ethics training per year.



### Note:



Enrollment for any part of a month is considered enrollment for the entire month, and enrollment for any part of a year is considered enrollment for the entire year.

3. EAs who retook the SEE at any time since their last renewal are only required to take 16 hours of CE during the last year of the renewal cycle, because passage of the SEE is worth 56 CE hours.


**1.25.2.3.4.5** **(11-18-2022)**

##### Continuing Education Waivers

1. Circular 230 §10.6(i) allows for a waiver of the CE requirement for a given period of time if the EA/ERPA requests the waiver and provides documentation to support the request. A request for waiver must be filed no later than the last day of the renewal application period (January 31 for EAs; June 30 for ERPAs). The authority to approve these requests is delegated to the EAP&M manager.

2. A waiver may be granted due to:



1. A health condition that prevented compliance with the CE requirements.

2. Extended active military duty.

3. Absence from the United States due to employment or other reasons, provided the individual does not practice before the IRS during such absence.

4. Any other compelling reason, to be determined on a case-by-case basis.


3. To process a waiver request:



1. Determine if the request is timely.

2. Determine if a related Form 8554/Form 8554-EP has been received and, if so, associate it with the request.

3. Review the reason for requesting a waiver, plus any supporting documentation, and determine if together they justify waiving the CE requirement.



      ### Note:



      Supporting documentation such as medical documents or military orders may be requested, if necessary.

4. Use the following table to determine the next actions:


|     |     |     |
| --- | --- | --- |
| IF | AND | THEN |
| the request is timely, | the explanation and documentation supports a waiver, | - prepare an EA/ERPA CE Waiver Approved letter.<br>     <br>   - send the letter to EAP&M manager for approval and signature.<br>     <br>   - after approval, issue the letter to the EA/ERPA.<br>     <br>   - continue processing Form 8554/Form 8554-EP. |
| the request is timely, | the explanation does not support a waiver, | - prepare an EA/ERPA CE Waiver Denial letter.<br>     <br>   - send the letter to the EAP&M manager for approval and signature. |
| the request is not timely, |  | - prepare an EA/ERPA CE Waiver Denial letter.<br>     <br>   - forward to the EAP&M manager for approval and signature. |

### Note:

The EA/ERPA may, within 30 days after receipt of the CE Waiver Denial letter, file a written appeal of the denial.

**1.25.2.3.4.6** **(11-18-2022)**

##### Inactive Retirement Status

1. An EA/ERPA may request to be placed into "Inactive Retirement" status by checking the box on Form 8554/Form 8554-EP. Neither EAs nor ERPAs are required to maintain CE while in "Inactive Retirement" status; however, they are still required to complete the renewal application form and pay the renewal fee each cycle they remain in this status. An EA/ERPA in "Inactive Retirement" status is no longer authorized to practice before the IRS.



### Note:



An EA is not required to have an active PTIN to be placed in Inactive Retirement status.

2. If an EA/ERPA requests "Inactive Retirement" status, check the OPR website at [https://www.irs.gov/tax-professionals/search-for-disciplined-tax-professionals](https://www.irs.gov/tax-professionals/search-for-disciplined-tax-professionals) for an active disciplinary investigation.



1. If there is an active disciplinary investigation, refer the request to the EAP&M manager to determine the appropriate resolution.

2. If there is no active disciplinary investigation, change the enrollee’s status to "Inactive Retirement" and send Letter 5512 advising of the change. Do not issue a new enrollment card.


**1.25.2.3.4.7** **(11-18-2022)**

##### Generating and Issuing Renewed Enrollment Cards

1. Generally, all cards are generated in bulk on a daily basis throughout the renewal cycle. Cards for practitioners with limited status are generated separately.

2. Ensure that the enrollment status and cycle are correct in E-Trak.

3. To generate the cards, take the following actions in the E-Trak Renewal Activity Screens:



1. Select Active status

2. If approving the renewal on March 31 or earlier, enter 04/01/YYYY as the Active status date.

3. If approving the renewal after March 31, enter the current date as the Active status date.

4. Select Print Renewal Enrollment Card and save.


**1.25.2.3.5** **(11-18-2022)**

#### Former IRS Employees

1. If an EA applicant is a former IRS employee, then within 60 days of receipt the LIE must:



1. Research the Automated Labor Employee Relations Tracking System (ALERTS) for evidence of a conduct or performance issue with the former employee. If there is no record, note in E-Trak. If ALERTS displays a report, print the report and scan it into E-Trak.

2. Access the Treasury Integrated Management Information Systems (TIMIS) to review the applicant’s job history and qualifications. Print the job history and scan it into E-Trak.


2. Request records check from the Treasury Inspector General for Tax Administration (TIGTA) to determine if the employee is or was the subject of a TIGTA investigation. Follow instructions in _IRM 1.25.2.3.5.1_.

3. Refer the applicant to RPO Suitability for an eligibility determination. See _IRM 1.25.2.3.7_.

4. RPO Suitability will recommend either enrollment or denial. Process the application accordingly.


**1.25.2.3.5.1** **(11-18-2022)**

##### TIGTA Record Check

1. Prepare a memorandum to TIGTA that includes the applicant’s full name, SSN, and the current date. Attach the Form 23 and send the package to the SLIE, who will e-mail it to the designated TIGTA representative.

2. TIGTA will respond to the SLIE, who will then refer it to RPO Suitability.



1. If the applicant has no prior or current TIGTA investigation, the response will state “no records found” or "no unfavorable information." Note E-Trak with "no negative issue."

2. If the applicant has a prior or current TIGTA investigation, the response will state “requested from Record Center,” "Copy to be Mailed" , or "Case Pending." Update E-Trak accordingly.



      ### Note:



      TIGTA will send a Report of Investigation directly to RPO Suitability.


**1.25.2.3.6** **(11-18-2022)**

#### Missing Information

1. If required information is missing on an application, use the guidance in the following table to attempt to find the information using internal resources. If internal research is unsuccessful, follow guidance in _IRM 1.25.2.3.6.1_ to contact the applicant.




| If the application is missing the: | Research the following: |
| :-- | --- |
| SSN | - IDRS command code RPVUE<br>     <br>   - E-Trak (for renewals) |
| Name | - IDRS command code INOLE with definer S<br>     <br>   - E-Trak (for renewals) |
| Address | - IDRS command code INOLE with definer S<br>     <br>   - E-Trak (for renewals) |
| PTIN | - IDRS command code RPVUE |
| Required continuing education hours | No research possible; contact applicant for the information. |
| Answers to or attachments for any of the following questions:<br> <br>   - Have you been sanctioned by a federal or state licensing authority?<br>     <br>   - Has any application you filed with a court, government department, commission, or agency for admission to practice ever been denied?<br>     <br>   - Have you been convicted of a tax crime or any felony?<br>     <br>   - Have you been permanently enjoined from preparing tax returns, or representing others before the IRS? | No research possible; contact applicant for the information. |


**1.25.2.3.6.1** **(11-18-2022)**

##### Telephone and Email Requests for Missing Information

1. If the missing information was not located via research, attempt to contact the applicant via telephone or email. When sending an email message, include your name and IRS badge number, but exclude the applicant's personally identifiable information (PII) from both the subject line and body of the email.

2. Wait two business days for the applicant to respond. If the applicant does not respond, place a second telephone call or send a second email message.

3. Wait three additional business days for the applicant to respond. If the applicant does not respond, follow instructions in _IRM 1.25.2.3.6.2_ to issue a written request.

4. Save any new documentation from the applicant in .pdf format and upload to E-Trak along with any related notations.

5. Update E-Trak as necessary.


**1.25.2.3.6.2** **(11-18-2022)**

##### Letter Requests for Missing Information

1. If there is no response to the attempted telephone or email contacts:



1. Send Letter 5499, Missing Information, with Form 15115 to the applicant.

2. Update E-Trak.

3. Suspend the case pending a response from the applicant.


2. If the missing information is proof of CE, then the applicant has 60 days from the date of the letter to respond. For all other missing information, the applicant has 14 days from the date of the letter to respond.

3. If a response is received timely, attach the correspondence to the application, scan and upload it to E-Trak, and continue with processing.

4. If a response is not received timely, consider the applicant to be ineligible. To complete processing, follow instructions in _IRM 1.25.2.3.3.5_ for new enrollments or in _IRM 1.25.2.3.4.3_ for renewals.


**1.25.2.3.7** **(11-18-2022)**

#### Referrals to RPO Suitability

1. See IRM 25.20.3, Return Preparer Suitability, for details about the suitability checks performed for EAs and ERPAs.

2. An initial referral to RPO Suitability is required for every new enrollment (Form 23) for a personal tax compliance and criminal background check.

3. A referral to RPO Suitability is required for an enrollment renewal (Form 8554/Form 8554-EP) when an applicant answers "Yes" to any of the questions found in _IRM 1.25.2.3.3.4 (2)_ or has a disciplinary action identified on the OPR website.

4. For any referral other than the initial personal tax compliance and criminal background check, ensure that E-Trak contains the following documents:



1. Form 23 or Form 8554/Form 8554-EP.

2. Additional documents obtained through research.

3. Screenshots showing any relevant information.

4. Any correspondence or documentation submitted by the applicant.

5. For a former employee, the TIMIS and ALERTS data, and TIGTA memo request.


5. Update E-Trak to note "Activity - Form 23 or Form 8554/Form 8554-EP application record sent to RPO Suitability for further review."

6. The SLIE will route the E-Trak record to RPO Suitability via spreadsheet to RPO Suitability HQ Analyst.

7. Monitor the referral every 30 days.


**1.25.2.3.7.1** **(11-18-2022)**

##### Determinations made by RPO Suitability

1. When RPO Suitability has completed work on a referred application, they will notify EAP&M of the final determination.

2. If enrollment is granted, complete the enrollment or renewal process in E-Trak. If an enrollment card has not yet been issued, route the application to the queue for issuance of a new enrollment card.

3. If enrollment is denied, RPO Suitability will complete all necessary actions.


**1.25.2.3.8** **(11-18-2022)**

#### Responding to Email Inquiries

1. As an alternative to regular mail and the telephone, EAP&M uses the email account EPP@irs.gov as a means for enrollees, applicants, IRS employees and the public to contact the office. The electronic mailbox is monitored by LIEs on a rotating basis.

2. The mailbox sends an automatic reply upon receipt of an email. The automatic reply states that the email account is only for inquiries about the enrollment program and that EAP&M will not respond to inquiries outside of this scope. It also provides alternative contact information for PTIN, IRS e-File and IRS employment verification inquiries.

3. Respond to emails within 3 business days. If unable to do so, begin the response with an apology for the delay.



### Exception:



Do not respond if the subject of the inquiry was addressed by the automatic response.

4. Use the following security protocols when responding to email:



   - For emails within the IRS that contain PII, always use secure email. If that is not an option for technical reasons, use Securezip.

   - For emails outside the IRS, always remove PII even if the sender included it.

   - Never include PII in the subject line.


5. Refer to Exhibit 1.25.2.4 for common inquiries and how to respond.


**1.25.2.3.9** **(11-18-2022)**

#### The Enrolled Practitioner Helpline

1. The IRS has a dedicated Enrolled Practitioner Helpline (“the Helpline”) for anyone with questions about applying for or maintaining EA or ERPA status. The Helpline number and hours of operation are posted online at [https://www.irs.gov/tax-professionals/enrolled-agents/contact-the-office-of-enrollment.](https://www.irs.gov/tax-professionals/enrolled-agents/contact-the-office-of-enrollment)

2. The Helpline is staffed by LIEs during all hours of operation.


**1.25.2.3.9.1** **(11-18-2022)**

##### Telephone Protocol

1. Customers expect timely, accurate and professional service. The way employees handle a call affects the way customers perceive the IRS; it is vital that each call be managed pleasantly, accurately, and efficiently.

2. When answering the Helpline:



1. Address the caller by title and last name (Mr. Jones or Ms. Smith). Use courteous phrases such as "Thank you, Mr. Jones" , "Thank you for holding" or other appropriate expressions.

2. Listen attentively and show a willingness to resolve the problem.

3. Allow the caller to finish his or her question or statement. Apologize for any interruptions or misunderstandings.

4. Avoid all distractions when handling a call.


**1.25.2.3.9.2** **(11-18-2022)**

##### Telephone Procedures

01. Greet the caller immediately, stating the name of the department, your title (e.g., Mr., Mrs., Ms., or Miss), your last name and your ID number.



    ### Note:



    Employees _must_ provide their 10-digit SmartID Number when communicating with taxpayers. Every employee has a SmartID Number in order to comply with Homeland Security Presidential Directive 12.

02. Authenticate the caller’s identity, when applicable, according to _IRM 1.25.2.3.9.3_.

03. Listen carefully to the caller’s questions and/or concerns.

04. Apologize for any clear or certain IRS error. Ask pertinent questions and pay close attention to the responses; this will help determine exactly how to assist the caller. Paraphrase the caller’s statements, if needed, to ensure you have identified the issue.

05. Research E-Trak and other applicable systems to determine the best resolution. Address _all_ of the caller’s questions and issues to avoid multiple calls back to the Helpline. This includes issues that are not raised by the caller but are evident from looking at the E-Trak record.

06. When it is necessary to put a caller on hold, ask permission first, and wait for a response. Always use the Hold button, not the Mute button, when placing a caller on hold. Do not keep the caller on hold for more than three minutes without checking back with the caller and providing a status of the call.



    ### Note:



    If it appears the research is going to take more than a few minutes, let the caller know you need additional time to research, review or locate the information. Obtain the caller’s telephone number and advise him or her you will call back within the next two business days.

07. Provide the caller with a suitable answer or resolution and advise the caller of any actions he or she must take to help resolve the problem.

08. If the caller requests to speak with a manager, state that the manager will call back within 24 hours and then notify the manager.

09. To indicate closure, ask the caller if all questions and needs have been addressed.

10. If accessing the caller’s E-Trak record, enter notes about the call in the E-Trak case history, including the issue(s), answers provided, and any actions taken.


**1.25.2.3.9.3** **(11-18-2022)**

##### Authentication

1. Authentication is the process of verifying the identity of the caller. A caller must provide certain data before you can disclose sensitive information such as PII or the status of an enrollment application. General disclosure information is located in IRM 11.3, _Disclosure of Official Information_.

2. Before accessing and releasing information from E-Trak, IDRS or other systems containing sensitive information, ask the caller for the following identifying data and compare it to what is in the E-Trak record:



1. Identification Number- Acceptable identification numbers are Enrollment number, SSN, or PTIN

2. Full name

3. Address


3. If unable to provide the correct address, ask the caller for one of the following identifying data and compare it to what is in the E-Trak record:



1. Date of Birth

2. An acceptable identification number which was not previously provided. See above, _IRM 1.25.2.3.9.3_(2)(a).


**1.25.2.3.9.4** **(11-18-2022)**

##### Common Call Topics

1. EAP&M frequently receives phone calls from EAs/ERPAs requesting information about their accounts or general information about the enrollment program. Third parties also call to inquire about the enrollment status of a specific individual.

2. For a list of common call topics and how to respond to each, refer to _Exhibit 1.25.2-3_.


**1.25.2.3.9.5** **(11-18-2022)**

##### Out-of-Scope Topics

1. If a caller’s question or concern is not within the EAP&M subject matter, do not try to provide information. Instead, refer the caller to the appropriate IRS function, or to IRS.gov for general information. The website [https://www.irs.gov/tax-professionals](https://www.irs.gov/tax-professionals) contains information and points of contact for most common tax practitioner topics, such as PTINs, continuing education, testing and e-Services, that the LIE should access to provide the relevant information.

2. When referring a caller to another office, always provide that office’s phone number and hours of operation.


**1.25.2.3.9.6** **(11-18-2022)**

##### Wrap Time

1. Wrap time is the time used by an employee to finish work related to a call after the call has been disconnected. While in wrap time, the employee is unavailable to take another call.

2. Attempt to complete all actions related to a call, including entering account history notes, before the call is disconnected. Wrap time should be minimal except in rare instances, such as when the caller is unable to stay on the line or the call prematurely disconnects.


**1.25.2.3.10** **(11-18-2022)**

#### Deceased, Expired, or Suspended PTIN

1. The PTIN Contractor sends a file to EAPM once a month with a list of active Enrolled Agents with a PTIN status that is either expired, suspended, or deceased.



|     |     |
| --- | --- |
| If the PTIN status is: | Then the LIE will: |
| Expired | 1. Update the status in E-Trak to inactive<br>      <br>2. Generate Letter 6435, Expired PTIN, to notify the Enrolled Agent |
| Suspended | 1. Update the status in E-Trak to inactive<br>      <br>2. Generate Letter 6471, Suspended PTIN, to notify the Enrolled Agent |
| Deceased | Update the status in E-Trak to deceased. No further action is required. |


**Exhibit 1.25.2-1**

### Responding to Written Requests and Other Correspondence

| Nature of Correspondence | Action |
| --- | --- |
| EA/ERPA case file information | Release case file information to the EA/ERPA only, and never to a third party. Case file information includes the documents or reports used to determine enrollment status, such as copies of TIMIS, ALERTS, and TIGTA investigation reports, position descriptions, and correspondence between EAP&M and the applicant. |
| Freedom of Information Act (FOIA) requests | Send all FOIA requests to the manager of RPO Strategy & Policy, who will provide guidance for fulfilling the request. |
| Name change | An EA/ERPA may request a name change on the enrollment card or certificate due to marriage, divorce or legal name change.<br> <br>1. Accept a name change request via mail, fax or email. Legal documentation is required to support the name change.<br>   <br>2. Send Letter 5502, Enrolled Agent Name Change, to the EA/ERPA to verify the request.<br>   <br>3. Update E-Trak with the name change and upload documentation provided.<br>   <br>4. Route the E-Trak record to the queue for reprint of the certificate and/or enrollment card. |
| Address change | Accept the address change as long as the requester provides an old address that matches the address in E-Trak and upload the documentation provided. |
| New enrollment card or certificate | Grant all requests for a new enrollment card or certificate due to name change or lost or stolen card/certificate. Before issuing a new card/certificate, verify the enrollment status and date of expiration. Note the reason for the request in E-Trak. |
| Voluntary termination | Grant a request for voluntary termination of enrollment (which the requester may call by any name, including "retirement" ) by updating E-Trak to reflect the new status. Send Letter 5504 to the EA/ERPA to confirm that the request was honored.<br> <br>### Note:<br>This does not apply to Inactive Retirement, which requires the enrollee to file a Form 8554/Form 8554-EP and pay the renewal fee each cycle. Inactive status can be reactivated, while termination cannot. |
| CE waiver | Scan all information into E-Trak and forward to the EAP&M manager for assignment and review. |
| Refund of application fees | Requests for a refund of application fees must be made via mail, fax or email, including the reason for the request. Route the request to the SLIE to determine the correct course of action. Decisions will be reviewed by the EAP&M manager for determination of reasonable cause to issue refund. Denial of a refund request cannot be appealed. |
| Notification of a deceased EA/ERPA | Update E-Trak to terminate the enrollment record and upload any documentation provided. No death certificate is required. |
| Complaints against Practitioners | For mailed complaints, fax the complaint to RPO Complaint Referrals at 855-889-7957, or scan and email it to \*RPO Referrals. For emailed complaints, forward to \*RPO Referrals. |
| Any other correspondence from an EA/ERPA, including complaints and responses to inactivation or termination notices | Send the correspondence to the EAP&M manager. |

**Exhibit 1.25.2-2**

### Former Employee Examination Waiver Position Matrix

Qualifying positions are as follows:

| Position & Series & Technical Divisions | Full Working Level | Enrollment Status |
| :-- | :-- | :-- |
| Revenue Agent – GS 512 SB/SE, LB&I (field positions) | GS 11 & above | Limited to Examination Matters |
| Revenue Officer – GS 1169 SB/SE, LB&I (field positions) | GS 9 & above | Limited to Collection Matters |
| Tax Specialist – GS 526 SB/SE, W&I (field offices) | GS 9 | Limited to Examination Matters |
| Tax Law Specialist – GS 987 SB/SE, W&I, TAS, Appeals (field offices) | GS 11 & above | Limited to Examination Matters |
| Criminal Investigator – GS 1811 | GS 11 & above | Full enrollment |
| Appeals Officer – GS 930 | GS 11 & above | Limited to Examination Matters |
| Settlement Officer – GS 1169 | GS 11 & above | Limited to Collection Matters |
| Customer Service Representative – GS 962 | GS 8 | Not eligible for SEE waiver |
| Case Advocate -GS 501 – TAS (field offices) |  | Full or limited based upon previous IRS background |
| Any of the above positions with an indication of a Campus location, or positions not listed, are not eligible for a Waiver of the Special Enrollment Examination. | Any working level | Not eligible for SEE waiver |

### Note:

_This list is not all-inclusive. Functional experience must include taxpayer-facing IRS positions otherwise known as field positions._

**Exhibit 1.25.2-3**

### Responding to Telephone Calls

| Purpose of Call | Response/Action |
| --- | --- |
| EA status verification | - If the caller is an IRS employee: refer the employee to the RPO website (https://irssource.web.irs.gov/RPO/Pages/Home.aspx).<br>  <br>- If the caller is a third party: release _only_ the following information:<br>  <br>  <br>  <br>1. Full name of EA<br>     <br>2. Status<br>     <br>3. Effective date of current status<br>     <br>4. Date of enrollment<br>     <br>5. Termination of enrollment, without disclosing reason for termination<br>     <br>6. Expiration date<br>     <br>- Note any third-party request in the E-Trak record of the enrollee. |
| EA listing | Refer the caller to the publicly accessible IRS Electronic Reading Room at [https://www.irs.gov/tax-professionals/enrolled-agents/active-enrolled-agents-and-the-freedom-of-information-act](https://www.irs.gov/tax-professionals/enrolled-agents/active-enrolled-agents-and-the-freedom-of-information-act). |
| EA/ERPA case file information | Advise the caller to make the request in writing to EAP&M.<br> <br>### Reminder:<br>Release case file information only to the EA/ERPA, never to a third party. |
| Address or name change | Advise the caller to request the change by mail, fax or email (give details for all three options, unless the caller indicates a preference). Legal documentation is required to support a name change. |
| Telephone number or email changes | Update the caller’s E-Trak record with the new information, but only after authenticating the caller’s identity using the procedures in _IRM 1.25.2.3.9.3_. |
| New enrollment card or certificate | - If the prior card or certificate was lost or stolen, grant the request after verifying the caller’s enrollment status and date of expiration.<br>  <br>- If the caller requests a new card or certificate due to a name change, verify the change has already been made in E-Trak, and verify the caller’s enrollment status and date of expiration. If the name change has not yet been made, advise the caller to request the name change in writing (see above).<br>  <br>- Cards and certificates must be mailed; they cannot be scanned or emailed. EAP&M will send a card or certificate to the same address three times. After that, the enrollee must provide a written address change before another card or certificate is sent.<br>  <br>- Inform the caller that it will take 10-14 business days to receive a new card or certificate.<br>  <br>- Note the reason for the new document(s) in E-Trak. |
| Assistance with applying for enrollment or renewal | Refer the caller to these sites for answers to questions about the application and testing processes:<br> <br>- For applications, the IRS Enrolled Agent website at [https://www.irs.gov/tax-professionals/enrolled-agents](https://www.irs.gov/tax-professionals/enrolled-agents), and,<br>  <br>- For testing, the testing vendor website. |
| Late renewals | Explain the renewal time frame and CE requirements. EAs renewing after January 31 are required to provide proof of CE. Proof of CE may be faxed, emailed, or mailed (give details for all three options, unless the caller indicates a preference). |
| Request for blank Form 23, Form 8554, Form 8554-EP | Encourage the caller to apply for enrollment or renewal online at Pay.gov. If the caller does not wish to apply online, direct him or her to IRS.gov to obtain a blank form from the Forms and Publications repository. Completion and mailing instructions are on the forms.<br> <br>### Note:<br>If the caller does not have access to a computer, offer to mail the blank form. |
| Assistance with the SEE | - If the caller needs information about taking the SEE or has questions about the test results, provide the testing vendor website and/or phone number, along with hours of operation. The vendor information can be accessed via [https://www.irs.gov/tax-professionals/enrolled-agents/become-an-enrolled-agent](https://www.irs.gov/tax-professionals/enrolled-agents/become-an-enrolled-agent).<br>  <br>- If the caller has a complaint about the testing process, gather details of the complaint and give the caller’s contact information to the EAP&M manager (for consideration by the Director, RPO Competency & Standards). Advise the caller that someone from the IRS will return his or her call within two business days. |
| Response to inactivation or termination notice | Verify the status of and reason for the inactivation or termination, then:<br> <br>- Advise an inactive EA/ERPA that he or she may submit a renewal application and pay the applicable fees if all requirements have been met. Requirements include holding an active PTIN (EAs only) and taking all required CE credits.<br>  <br>- Advise a terminated EA that to become active again, he or she must:<br>  <br>  <br>  <br>  - retake and pass the SEE,<br>    <br>  - obtain or have an active PTIN (EAs only),<br>    <br>  - file a Form 23, and<br>    <br>  - pay the applicable fees.<br>    <br>- Advise a terminated ERPA that he or she can no -longer take the ERPA-SEE and therefore has no remedy for the termination. Enter a note in E-Trak.<br>  <br>### Note:<br>Failure to receive notification of the renewal requirement is not justification for an individual’s failure to satisfy the renewal requirements. Refer the former EA/ERPA to Circular 230 §10.6(d). |
| Voluntary termination | Advise the caller to make the request for voluntary termination (which the requester may call by any name, including "retirement" ) by mail, fax or email (give details for all three options, unless the caller indicates a preference.<br> <br>### Note:<br>This does not apply to Inactive Retirement, which requires the enrollee to file a Form 8554/Form 8554-EP and pay the renewal fee each cycle. Inactive status may be reactivated, while termination cannot. |
| Status of an enrollment or renewal application | - For an initial enrollment application or timely-filed renewal application, the standard processing time is 60 days. Inform the caller of the processing time and offer to check the account for the status. If enrollment has already been granted, provide the caller with the enrollment number and a timeframe for receiving the enrollment card.<br>  <br>- For former employees, the standard processing time for initial enrollment is 60 days plus any time needed by RPO Suitability and TIGTA for additional processing. Tell the caller that the application should be processed within 120 days but it will depend on the complexity of the research.<br>  <br>- In E-Trak, if the application is unprocessable, tell the applicant that the inquiry requires further research, and someone will return his or her call within two business days. Obtain the caller’s telephone number and any information needed to assist caller (such as Pay.gov tracking number to locate a missing application). Conduct the necessary research, refer the inquiry to the employee working the case, or refer the inquiry to the SLIE or manager if assistance is needed.<br>  <br>  <br>  <br>### Note:<br>  <br>  <br>  <br>If the employee working the case is out of the office and not returning within the two-business-day period, elevate the inquiry to the SLIE.<br>  <br> Note the E-Trak account with the issue(s) and actions taken, including the return call. |
| CE waiver | Advise the EA/ERPA to review Circular 230, §10.6(i) to ensure he or she meets the qualifications, then submit the required information via mail, fax or email (give details for all three options, unless the caller indicates he or she prefers a specific method). |
| Refund of application or testing fees | - For a refund of examination fees, advise the caller that the request must be made through the testing vendor. Provide the vendor’s website and/or phone number and hours of operation.<br>  <br>- For a refund of EA/ERPA application fees, advise the caller that the request must be made in writing, via mail, fax or email (provide details for all three options, unless the caller indicates he or she prefers a specific method). The request must include the reason for requesting a refund. Also advise the caller that refunds are granted only in limited circumstances.<br>  <br>- For a refund due to overpayment, advise the caller how to request a refund, and route the request to the SLIE to verify the overpayment. |
| Notification of a deceased EA/ ERPA | Advise the caller that notification of death must be made via mail, fax or email (give details for all three options, unless the caller indicates he or she prefers a specific method). No death certificate is required. |
| Complaints against practitioners | - For complaints from the public, advise the caller to file the complaint on Form 14157, available at [https://www.irs.gov/tax-professionals/make-a-complaint-about-a-tax-return-preparer](https://www.irs.gov/tax-professionals/make-a-complaint-about-a-tax-return-preparer).<br>  <br>- For complaints from IRS employees, advise the employee to submit a Form 8484, _Suspected Practitioner Misconduct Report for the Office of Professional Responsibility_, pursuant to the instructions on the OPR website. |
| Request to Speak to a Supervisor or Another LIE | Advise the caller that you may be able to help them with their issue. Ask if they would like for you to proceed.<br> <br>- If they agree, proceed with the call as normal.<br>  <br>- If they don’t agree, obtain the caller’s name, EA number, telephone number, the best time to return the call, and a brief description of the issue. Advise that a supervisor will call them back within 24 business hours, or the LIE will call them back within 48 business hours. Email the manager or the requested LIE with the information. Notate the conversation in E-Trak. |

**Exhibit 1.25.2-4**

### Responding to Email Inquiries

|     |     |
| --- | --- |
| IF the request is for | THEN respond with |
| EA Status - Active EA requesting their own status | Your EA status is active.<br> Regards,<br> Office of Enrolled Agent Policy & Management/(LIE initials) |
| EA Status - Active, External Third Party Inquiry | NAME is an active enrolled agent.<br> Regards,<br> Office of Enrolled Agent Policy & Management/(LIE initials) |
| EA Status - Active, Internal Third Party Inquiry | NAME is an active enrolled agent.<br> Enrolled agent status for active agents can be found on the link below after selecting Enrolled Agent Listing. https://irssource.web.irs.gov/RPO/Pages/Home.aspx<br> Regards,<br> Office of Enrolled Agent Policy & Management/(LIE initials) |
| EA Status - No Record | Based on the information provided, we have no record for NAME.<br> Regards,<br> Office of Enrolled Agent Policy & Management/(LIE initials) |
| EA Status - Inactive EA requesting their own status | Your EA status is inactive. To return to active status, please submit Form 8554 with the application fee and send copies of your completed course certificates or proof of the continuing education courses you completed for the years XXXX-XXXX. You can obtain proof of your continuing education from your online PTIN account. Send the proof of your CE courses using one of the options listed below.<br> <br>- Email – EPP@irs.gov<br>  <br>- Fax – (855) 889-7959<br>  <br>- Mail-<br>  <br>  <br>Internal Revenue Service Enrolled Agent Policy & Management<br>  <br>  <br>985 Michigan Avenue<br>  <br>  <br>Detroit, MI 48226<br>  <br> To view a list of the CE courses you completed you can log into your online PTIN account.<br> Regards,<br> Office of Enrolled Agent Policy and Management/(LIE initials) |
| EA Status - Inactive | NAME’s status is inactive.<br> Regards,<br> Office of Enrolled Agent Policy and Management/(LIE initials) |
| Application Status - Form 23 Received (with no outstanding issues) | We received your application on MM/DD/YYYY. Please allow 60 days for processing<br> Regards,<br> Office of Enrolled Agent Policy and Management/(LIE initials) |
| Application Status - Form 23-FE Received (with no outstanding issues) | We received your application on MM/DD/YYYY. Please allow 120 days for processing<br> Regards,<br> Office of Enrolled Agent Policy and Management/(LIE initials) |
| Application Status - Form 23 Approved | Your application was approved on MM/DD/YYYY. Please allow 10-14 business days to receive your enrollment package in the mail.<br> Regards,<br> Office of Enrolled Agent Policy and Management/(LIE initials) |
| Application Status - Form 8554 Received (with no outstanding issues) | We received your application on MM/DD/YYYY, please allow 90 days for processing<br> Regards,<br> Office of Enrolled Agent Policy and Management/(LIE initials) |
| Application Status - Form 8554 Approved | Your application was approved on MM/DD/YYYY. Please allow 10-14 business days to receive your new card in the mail.<br> Regards,<br> Office of Enrolled Agent Policy and Management/(LIE initials) |
| Out of Scope | Do not respond to any request that is out of scope. An email is automatically sent to every email inquiry advising “We will not respond to other inquiries”. All out of scope inquiries can be deleted.<br> <br>### Exception:<br>When a response is required because an email contains an EA inquiry and a request that is out of scope respond to the out of scope request by following_IRM 1.25.2.3.9.5_, Out of Scope Topics. |
| All issues not covered above | Thank you for your inquiry. (ADD RESPONSE HERE)<br> Regards,<br> Office of Enrolled Agent Policy & Management/(LIE initials) |

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-025-002#addtoany "Show all")

A2A