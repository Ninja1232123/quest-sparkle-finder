---
url: "https://www.irs.gov/irm/part1/irm_01-054-001"
title: "1.54.1 TE/GE Roles and Responsibilities on Issue Elevation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-054-001#main-content)

- 1.54.1  [TE/GE Roles and Responsibilities on Issue Elevation](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993522816)
  - 1.54.1.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993563632)
    - 1.54.1.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004998377360)
    - 1.54.1.1.2  [Responsibilities](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004966440240)
    - 1.54.1.1.3  [Terms](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004966444832)
    - 1.54.1.1.4  [Acronyms](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004966458240)
  - 1.54.1.2  [TE/GE Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004998375392)
  - 1.54.1.3  [Elevating Issues](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004998368816)
    - 1.54.1.3.1  [Definition of "Elevation"](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004965033040)
    - 1.54.1.3.2  [Definition of "Issue"](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004998361680)
  - 1.54.1.4  [Why Issues are Elevated](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004966464384)
    - 1.54.1.4.1  [Elevation to Inform Managers or Executives](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004964930304)
    - 1.54.1.4.2  [Elevation to Obtain a Decision from Managers or Executives](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004964922224)
  - 1.54.1.5  [Issues that are Candidates for Elevation](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993400816)
  - 1.54.1.6  [Level to Which Issues Should Be Elevated](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993345088)
    - 1.54.1.6.1  [Issues of "Local" and "National Concern"](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993336752)
  - 1.54.1.7  [Determining the Level to Which Issues Should Be Elevated](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993592720)
    - 1.54.1.7.1  [Front-line Employees](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993590432)
    - 1.54.1.7.2  [Group Managers](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993585776)
    - 1.54.1.7.3  [Senior Managers](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993582208)
    - 1.54.1.7.4  [Director (TE/GE National Level)](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993483968)
    - 1.54.1.7.5  [Functional Directors](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993471232)
    - 1.54.1.7.6  [Commissioner and Deputy Commissioner, TE/GE](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004993464896)
    - 1.54.1.7.7  [Commissioner of Internal Revenue, Chief Tax Compliance Officer, and Chief Operating Officer](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004964833920)
  - 1.54.1.8  [Referral to or Consultation with Counsel](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004964829072)
    - 1.54.1.8.1  [Concurrent Elevation to Counsel and within TE/GE](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004964821632)
    - 1.54.1.8.2  [Issues to Bring to Counsel's Attention](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004964819792)
  - 1.54.1.9  [Issues Reported or Resolved Outside the IRS](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004964813424)
  - 1.54.1.10  [Avoiding Inappropriate Elevation by Appropriately Exercising Responsibility](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004966556992)
    - 1.54.1.10.1  [Issues That Should Not Be Elevated Above a Certain Level](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004966550016)
  - 1.54.1.11  [Reaching Down](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004965735168)
  - 1.54.1.12  [Consulting with Front-line Employees and Managers](https://www.irs.gov/irm/part1/irm_01-054-001#idm140004965728608)

# Part 1. Organization, Finance, and Management

# Chapter 54. TE/GE Division Organization and Management

# Section 1. TE/GE Roles and Responsibilities on Issue Elevation

* * *

## 1.54.1 TE/GE Roles and Responsibilities on Issue Elevation

#### Manual Transmittal

January 16, 2025

#### Purpose

(1) This transmits revised IRM 1.54.1, _TE/GE Division Organization and Management, TE/GE Roles and Responsibilities on Issue Elevation_.

#### Material Changes

(1) Made organizational and editorial changes throughout the IRM.

#### Effect on Other Documents

This supersedes IRM 1.54.1, dated September 9, 2021.

#### Audience

Tax Exempt and Government Entities

#### Effective Date

(01-16-2025)

Madelyn Henderson

Acting Director, Shared Services

Headquarters

Tax Exempt and Government Entities

**1.54.1.1** **(01-16-2025)**

### Program Scope and Objectives

1. **Purpose**: This IRM section describes an "issue" and the procedure for elevating an issue in the TE/GE Division.

2. **Audience**: These procedures apply to all TE/GE employees.

3. **Policy Owner**: The TE/GE Commissioner is the policy owner of this IRM.

4. **Program Owner**: The Director, Shared Services, TE/GE is the program owner of this IRM.

5. **Primary Stakeholders**: Any TE/GE employee who sees an issue of concern related to TE/GE process procedures or cases is the primary stakeholder for this IRM but any IRS employee can identify or elevate an issue to TE/GE management.

6. **Contact Information**: To recommend changes or make any other suggestions to this IRM section, e-mail the TE/GE IMD Coordinator at \*TE/GE IMD SPOC.


**1.54.1.1.1** **(09-09-2021)**

#### Background

1. The IRM identifies the procedures necessary to identify and elevate issues throughout the TE/GE management chain. Each and every employee must understand that she/he is important to the successful completion of work in TE/GE and each employee’s input is valued. If there is something of concern in working a case or a possible trend developing, the employee not only has the opportunity to elevate the concern but the responsibility to do so.


**1.54.1.1.2** **(09-09-2021)**

#### Responsibilities

1. The TE/GE Commissioner is the executive responsible for all work in the TE/GE operating Division.

2. Executives of each TE/GE function are responsible for the work affecting their respective programs.

3. Examiners, Tax Law Specialists, Tax Compliance Officers, and Tax Examining Technicians are responsible for:



1. Case work relating to each function.

2. Ensuring the instructions and procedures are communicated to and carried out by the proper employees.


4. For more information on TE/GE’s role in managing their mission-critical responsibilities, see IRM 1.1.23, Organization and Staffing, Tax Exempt and Government Entities Division.


**1.54.1.1.3** **(09-09-2021)**

#### Terms

1. **Chain of command**: the line of authority that begins with an employee’s immediate supervisor, includes the Senior Manager or their equivalent, functional Director, Program Director and goes ultimately to the Commissioner, TE/GE.

2. **Elevate**: bring an issue, concern, or situation which comes to an employee’s attention in his/her job to his/her manager’s manager or executive’s attention.

3. **Issue**: in this IRM, issue isn’t intended to have a precise or a restrictive meaning but is a question or problem that involves a new, unusual, or sensitive matter that you shouldn’t/can’t decide or resolve in a routine, standard, or uniform manner but needs careful analysis, sound judgment, discretion and experience. An example of an issue may include, but is not limited to, a question such as an interpretation or application of law or published guidance, a new administrative action or procedure, a developing or emerging issue, an allegation brought to TE/GE’s attention by an outside party.

4. **Local Issue**: one concerning a single taxpayer or group of taxpayers generally located within the geographical boundaries of one area, or a matter that is unique to or confined to the area in question.

5. **National Issue**: an issue that affects similarly-situated taxpayers throughout the country, is precedent-setting or that will serve as a model for cases in other areas or throughout the country, is non-routine that appears likely to present itself in several areas or throughout the country.


**1.54.1.1.4** **(09-09-2021)**

#### Acronyms

1. The table lists commonly used acronyms and their definitions:




| **Acronym** | **Definition** |
| --- | --- |
| CC:EEE | Associate Chief Counsel (Employee Benefits, Exempt Organizations and Employment Taxes) |
| CP&C | Compliance Planning & Classification |
| EO/GE | Exempt Organizations and Government Entities |
| EP | Employee Plans |
| Exam | Examination |
| FSL/ET | Federal, State and Local Governments / Employment Tax |
| GAO | Government Accountability Office |
| GE | Government Entities |
| IMD | Internal Management Documents |
| IRS | Internal Revenue Service |
| IT | Information Technology |
| ITG | Indian Tribal Governments |
| R&A | Rulings & Agreements |
| TEB | Tax Exempt Bonds |
| TE/GE | Tax Exempt and Government Entities |
| TEGEDC | TEGE Division Counsel |
| TIGTA | Treasury Inspector General for Tax Administration |
| VC | Voluntary Compliance |


**1.54.1.2** **(12-20-2013)**

### TE/GE Roles and Responsibilities

1. All Tax Exempt and Government Entities (TE/GE) employees report through a chain of command that begins with immediate supervisors, includes Senior Managers, or their equivalent, and Directors, and goes ultimately to the Commissioner, TE/GE. Stated another way, everyone within TE/GE is part of a single, unified organization, and the lines of authority within it run from the Commissioner, TE/GE, downward to every individual.

2. For the organization to function well, work groups must elevate certain types of information and decisions to managerial and executive levels. Employees, managers, and executives need to know what kinds of information and what decisions to elevate, and to which level within TE/GE.

3. Sometimes senior managers and executives may involve themselves directly in case selection, case direction or case consideration. They do this to apply their experience and judgment at any stage of the case’s development. In other situations, they observe to become educated in the way cases are worked in the field.

4. Employees should understand that senior managers’ and executives’ involvement in cases is:



   - Appropriate.

   - Done for good reasons and intentions.

   - Required for the sound management of an organization.

   - Not reflective of political influence or other inappropriate meddling in cases.

   - Not meant to imply criticism of work performance.


**1.54.1.3** **(08-31-2016)**

### Elevating Issues

1. First, this section describes when a TE/GE employee should elevate an issue, that is, bring an issue which comes to his/her attention in his/her job to his/her manager’s manager or executive’s attention. Terms and concepts defined include:



   - Elevation.

   - Issue.

   - Why issues should be elevated.

   - The level within the organization to which to elevate different kinds of issues.


2. Second, this section describes when a TE/GE higher-ranking manager or executive may wish to ask about an issue -- especially a case being worked or awaiting a decision at a subordinate level.

3. Third, this section notes that, when certain policies and procedures are developed, front-line employees and managers should be consulted.


**1.54.1.3.1** **(08-31-2016)**

#### Definition of "Elevation"

1. The word "elevation," in this IRM, means to bring an issue, concern or situation that managers or executives must know about to:



1. Execute the tax laws faithfully.

2. Properly manage TE/GE.


2. Elevating an issue is when you:



1. Send it to higher-ranking TE/GE officials for their information or for their decision.

2. Recognize that others within the organization need to know about the issue.

3. Recognize when you aren’t authorized, experienced, or knowledgeable enough to handle or decide the issues yourself.


3. Elevation isn’t when an employee, manager or executive either:



1. Merely refers an issue laterally within TE/GE or the IRS.

2. Coordinates an issue with another part of TE/GE or the IRS.



      ### Note:



      A referral to Counsel isn’t necessarily an elevation but can be considered one if we transfer the power of decision and the issue to Counsel.


4. Ways to elevate an issue include but aren’t limited to:



   - Conversation

   - E-mail

   - Meetings

   - Sensitive case reports (to executives) depending on the level of elevation.


**1.54.1.3.2** **(08-31-2016)**

#### Definition of "Issue"

1. The word **"issue,"** in this IRM, isn’t intended to have a precise or a restrictive meaning. In general, it means a question or a problem that:



1. You shouldn’t/can’t decide or resolve in a routine, standard, or uniform manner.

2. Often involves a new, unusual, or sensitive question.

3. You must decide or resolve using careful analysis, sound judgment, discretion and experience.


2. Examples of issues requiring elevation:



1. The interpretation or application of law or published guidance to a case.

2. A non-standard case, including, for example, unusual aspects of a determination letter application or an examination.

3. A new administrative action or procedure, or a revision or an exception to an existing action or procedure, for example, proposed amendments to a voluntary compliance program or a change in the way user fees are collected.

4. The interpretation or application to a case of a new or existing administrative action or procedure.

5. A developing or emerging issue, including issues not yet presented to TE/GE by a taxpayer or found in an exam.



      ### Example:



      An issue we learned through discussions at a practitioner’s or professional society’s meeting.

6. An allegation brought to TE/GE’s attention by an outside party, for example, a report in a newspaper, or a letter from a member of the public, suggesting a possible violation of the Code.


3. An issue doesn’t include routine and regularly scheduled reports of ordinary events. In other words, this section of the IRM is not intended to supplement or replace existing guidance for issue elevation covered by reporting procedures. Employees, managers, and executives already have instructions for preparing and reporting these matters.


**1.54.1.4** **(08-31-2016)**

### Why Issues are Elevated

1. Sound business practices require issues at subordinate levels of the organization to be elevated to higher levels. When you see an issue, consider elevating the issue to your immediate supervisor. In general, elevate issues for either of these reasons:



1. To inform managers and executives of things they need to know.

2. To present questions or problems to them for decision.


2. When you consider whether to elevate an issue, ask yourself:



1. "Am I technically capable, sufficiently experienced, authorized, and comfortable about deciding this issue myself?" If the answer to any part of the question is "no," or "doubtful," you should elevate the issue to your immediate supervisor.

2. "Is this issue something that my manager, or a higher-ranking manager or executive, would want to know about or should know about in order to perform his or her duties?" Another way of looking at the question is to put yourself in a manager’s or executive’s shoes and ask if you would want to be aware of the issue if you were the manager or executive. If the answer to any of these questions is "yes," you should elevate the issue to your immediate supervisor.


3. When in doubt about whether to elevate an issue, elevate it. The person you elevate the issue to may, at his/her discretion, refer it back to the employee or manager to resolve.


**1.54.1.4.1** **(08-31-2016)**

#### Elevation to Inform Managers or Executives

1. Reasons why you elevate an issue to inform managers or executives; you are notifying them of issues that (list isn’t all-inclusive):



1. May eventually require action, approval, or a response, or that has the potential to become a problem.



      ### Example:



      Sensitive issues, high-impact cases, matters which may generate significant publicity or controversy, issues involving substantial dollar amounts, or matters which have been handled inappropriately.

2. Deviate from established administrative practices and the reasons for the deviations.

3. Are sensitive or important issues obscured by procedural or other issues.


2. Other reasons why you elevate an issue informing managers or executives are to obtain:



1. Cooperation of or with, another part of TE/GE, IRS, or another government agency.

2. Help to solicit Counsel or Treasury views.

3. Help to solicit the TE/GE Risk Liaison’s and the IRS Chief Risk Officer’s views.

4. Help to solicit the TE/GE Senior Technical Advisor’s views.

5. Or promote the uniform application of the law, or the achievement of uniform results.


3. Another reason why you elevate an issue informing managers or executives is to recommend improved administrative practices or bring to light weaknesses in existing administrative practices.


**1.54.1.4.2** **(09-09-2021)**

#### Elevation to Obtain a Decision from Managers or Executives

1. Reasons why you elevate an issue to senior managers and executives to obtain a decision include, but aren’t limited to,:



1. Present issues that require their action, approval or response.

2. Comply with a statute, regulation, procedure, or directive that specifies the level at which a particular type of decision is made.



      ### Example:



      You must submit certain issues for mandatory technical advice; closing agreements to the Commissioner, TE/GE or to the Director, Employee Plans (EP); Director, Exempt Organizations and Government Entities (EO/GE), Director, Compliance Planning and Classification (CP&C), and Director, Shared Services; and field directives may require you to send certain cases to specific places for a decision.

3. Offer them an opportunity to agree/disagree from the issue’s proposed resolution when it is novel, sensitive, or precedent-setting.

4. Obtain personnel, Information Technology (IT), budgetary, or other resources.


2. Other reasons why you elevate an issue to senior managers and executives to obtain a decision:



1. When the issue is one of first impression, precedent-setting, sensitive, or otherwise of such significance that it should be decided at a higher level within the organization.



      ### Example:



      A case in which a decision must be made between alternative interpretations of the law.

2. When correctly resolving the issue is unclear or not well established.

3. For disagreements among employees, managers, or different TE/GE or IRS organizations on how to resolve a technical issue.

4. For disagreements among employees, managers or different TE/GE or IRS organizations on how to resolve an administrative or legal issue.

5. When different TE/GE or IRS organizational interests conflict or have reached an impasse because of the conflict.


**1.54.1.5** **(09-09-2021)**

### Issues that are Candidates for Elevation

1. Closely related to the question of _why_ you should elevate issues is the question of _what_ issues you should elevate. We can’t state a definitive or exclusive list of all issues because the list changes with changes in the tax, business, or organizational environment, and within the context in which the issue arises. However, consider some issues that ordinarily would qualify for elevation.



### Note:



Although the issues are grouped into categories of "informing" and "informing for a decision," many could be listed appropriately under both categories.

2. Inform managers and executives of issues, complaints, situations, inquiries that may:



1. Eventually require action, approval, or response, or that have the potential to become problems, but managers and executives aren’t aware of through an established reporting program.

2. Be sensitive.

3. Impact a large number of individuals.

4. Have an extreme impact on one or more individual taxpayers, organizations, or entities.

5. Have substantial dollar amounts.

6. Generate significant publicity or controversy or could generate significant publicity or controversy.

7. Deviate from an established administrative practice.


3. Also inform managers and executives of issues, complaints, situations, inquiries that involve:



1. Complaints from taxpayers about TE/GE policies, practices, employees, managers or executives.

2. A state, a municipality or an Indian tribal government.

3. A personal or physical security issue.

4. Government Accountability Office or the Treasury Inspector General for Tax Administration inquiries or recommendation.


4. Also inform managers and executives of issues, complaints, situations, inquiries that may require coordinating with:



1. Other parts of TE/GE or IRS.

2. Counsel or Treasury.

3. Or involving a policy dispute, with other federal agencies.


5. Also inform managers and executives of issues, complaints, situations, inquiries that require:



1. Correction when TE/GE or the IRS has erred.

2. Improved administrative procedures.


6. Also inform managers and executives of issues, complaints, situations, inquiries that may concern:



1. The EO/GE, EP, CP&C or SS community.

2. Treasury, Congress, including the tax-writing committees.

3. The uniform application of the law, or the achievement of uniform results.


7. Also inform managers and executives of issues to obtain a decision on issues and situations that:



1. Require their action, approval or response.

2. Are directed by statute, regulation, revenue procedure, or other directive or practice to a particular office or level to resolve or decide.

3. Are of first impression, precedent-setting, or sensitive, including issues that depart from established positions or practices.

4. The correct resolution is unclear or not well established.

5. Are sensitive, but whose sensitivity is obscured by procedural or other issues.

6. Involve disagreement among TE/GE or other IRS employees, managers on how to resolve a technical or administrative issue.

7. Involve conflicting organizational interests of different TE/GE or IRS organizations or have reached an impasse because of the conflict.

8. Concern personnel, IT, budgetary or other resources.

9. Involve revoking a compliance statement or a closing agreement or amending a compliance statement.


**1.54.1.6** **(08-31-2016)**

### Level to Which Issues Should Be Elevated

1. In most cases, you should elevate issues to your immediate manager, who, in turn, should elevate them, as appropriate, to successively higher levels in your chain of command.

2. You don’t have to predict the ultimate level to which an issue should be elevated. Issues will go to the appropriate level if each employee, manager and executive:



1. Understands his/her own area of responsibility and competence.

2. Acts on issues within their area.

3. Elevates issues to a higher level.


3. As noted above, it’s often appropriate for managers and executives to ask about or become involved in subordinate-level issues. However, taxpayers who have matters pending before TE/GE regularly monitor their progress and may be concerned if they find that their matter has been, or potentially may be, elevated above ordinary working levels.

4. This section contains generic issue descriptions that may trigger elevation to higher levels of the IRS. We’re providing this sample list to:



1. Reassure employees and taxpayers as to the reasons a case with which they are involved has become the subject of higher-level review.

2. Alleviate concerns that this review reflects an adverse judgment by senior management on either the employee’s work or on the merits of the taxpayer’s case.


5. In general, the more significant an issue, the more likely it is to be elevated, and the higher it is likely to go up the chain of command. Further, as noted previously, some issues are directed automatically to certain levels within the IRS.


**1.54.1.6.1** **(08-31-2016)**

#### Issues of "Local" and "National Concern"

1. The level to which an issue is elevated may be influenced by whether the issue is "local" or "national" in character.

2. An issue of local concern is one concerning:



   - A single taxpayer or group of taxpayers generally located within the geographical boundaries of one area.

   - A matter that is unique to or confined to the area in question.


3. Examples of issues of local concern:



1. Taxpayer complaints about the staffing of EP posts of duty at certain hours.

2. Perceived errors in the way a particular employee interprets a section of the Code

3. A conflict between a TE/GE practice with respect to a tax-exempt organization and the requirements of a state attorney general’s office with jurisdiction over the same organization would be a matter of local concern, at least initially.


4. An issue of national concern is an issue that:



   - Affects similarly-situated taxpayers throughout the country.

   - Is precedent-setting or that will serve as a model for cases in other areas or throughout the country.

   - Is non-routine that appears likely to present itself in several areas or throughout the country.


5. Examples of issues of national concern:



1. A new kind of tax-qualified pension plan would, in most cases, present novel issues of national concern that should be elevated to the Director, EP Rulings and Agreements, and ultimately to the Director, EP.



      ### Note:



      This might appear in a determination letter application, or an agent or manager might be asked a question about it, or hear a presentation on it, at a practitioners’ meeting or at a professional association’s convention.

2. An issue that affects such a large group of individuals that it draws the attention of the tax community or the public at large, so that its resolution effectively establishes a model for the country.


**1.54.1.7** **(01-01-2006)**

### Determining the Level to Which Issues Should Be Elevated

1. Considering_IRM 1.54.1.6.1_, refer to the following description of issues that should be decided at successively higher TE/GE working, managerial, and executive levels.


**1.54.1.7.1** **(08-31-2016)**

#### Front-line Employees

1. Employees are assigned work appropriate to their training and grade level. As a front-line employee, you should work closely with your group manager; you should frequently elevate these issues to your group manager:



1. Regular and frequent communication, keeping him/her informed of work progress, unusual issues, and any problems you encounter in resolving or concluding your work.

2. Issues beyond your training or competence, procedures that work well or do not work well, and taxpayer reaction to the way TE/GE serves them.

3. Any issue that must be elevated per a statute, a revenue procedure, a field directive, or similar guidance.



      ### Example:



      An EO agent must send mandatory technical advice cases to the Office of Associate Chief Counsel (per Rev. Proc. 2021-5).


**1.54.1.7.2** **(01-01-2006)**

#### Group Managers

1. Group managers are initially responsible to make sure appropriate issues are elevated to the correct level.



1. Ensure that you identify and appropriately elevate issues within your group or area that should be elevated per _IRM 1.54.1.7.1 (1)_(c).

2. Remember the reasons why issues are elevated and the types of issues to elevate, as discussed above.


**1.54.1.7.3** **(09-09-2021)**

#### Senior Managers

1. In general, issues of local and national concern should be elevated to senior managers. Senior managers will likely elevate national issues to a Director (see _IRM 1.54.1.7.4_, **Director (TE/GE National Level)**) or to the Commissioner or Deputy Commissioner, TE/GE.

2. Senior Managers include:



   - Area Managers,

   - Manager, EP Technical Manager,

   - EP Voluntary Compliance (VC) Manager,

   - Program Manager, Indian Tribal Governments (ITG),

   - Program Manager, Tax Exempt Bonds,

   - Program Manager, Federal, State and Local/Employment Tax (FSLET)

   - Program Manager, TE/GE Compliance Unit


3. Examples of issues to elevate to TE/GE senior managers are issues involving:



1. A resolution that has been delegated to managers and directors by delegation order, directive or practice.

2. Novel or unprecedented issues/areas.

3. A state, municipality or Indian tribal government within the area.

4. Potentially generated significant publicity or controversy within the area.

5. An impact on customer service within the area.

6. Complaints against employees or managers within the area.

7. Errors by TE/GE within the area.

8. Resources needed to carry out TE/GE’s mission within the area.


**1.54.1.7.4** **(08-31-2016)**

#### Director (TE/GE National Level)

1. In general, elevate issues of national concern to directors, as appropriate. Directors include:



   - EO Examination (Exam)

   - EO Rulings and Agreements (R&A)

   - Government Entities (GE)

   - EP Examination (Exam)

   - EP Rulings and Agreements (R&A)

   - Compliance Planning & Classification (CP&C)

   - Shared Services


2. Examples of issues to elevate to TE/GE Directors include:



01. National concern.

02. Resolution to them by statute, regulation, revenue procedure, functional statement, delegation order, other directive, or established practice.

03. Refunds or credits to taxpayers of $2,000,000 or more, ($5,000,000 for a C corporation) which must be reported to the Joint Committee on Taxation.

04. An entire category of taxpayers, e.g., an issue affecting all tax-advantaged bonds, or all gaming institutions.

05. A significant or enduring impact on customer service within a locality, an area, or throughout the country.

06. Unusual personnel or labor relations questions.

07. Those reported to the Treasury Inspector General for Tax Administration (TIGTA), including violations of section 1105 of RRA (requests by specified Executive Branch employees concerning audits or other investigations).

08. Disputes with other federal agencies.

09. Generated significant publicity or controversy within one or more areas, or nationally.

10. A large number of taxpayers, a large amount of money, or a well-known entity or organization.

11. A substantial tax or legal matter involving a municipality, state or Indian tribal government.

12. The revocation of a closing agreement or a compliance statement.

13. Significant errors by TE/GE, or errors with national impact.

14. Discrimination, sexual harassment, or violation of taxpayers’ rights.


**1.54.1.7.5** **(08-31-2016)**

#### Functional Directors

1. In general, issues of national concern in _IRM 1.54.1.7.4 (1)_ elevated to the Directors in _IRM 1.54.1.7.4 (1)_ may also be elevated to:



   - Director, EO/GE

   - Director, EP



     ### Note:



     The Directors, EO Exam, EO R&A, GE, EP Exam, EP R&A, have discretion to elevate to their superior.


2. The Directors, EO/GE and EP retain the authority to:



1. Request that any issue under consideration at any level within their respective organization be elevated to their office.

2. Consult with the Senior Technical Advisor on any issue under consideration at any level within their respective organization.


**1.54.1.7.6** **(08-31-2016)**

#### Commissioner and Deputy Commissioner, TE/GE

1. In general, issues of national concern in _IRM 1.54.1.7.4 (1)_ elevated to the Functional Directors in _IRM 1.54.1.7.5 (1)_ are also candidates for elevation to TE/GE’s:



   - Commissioner

   - Deputy Commissioner


### Note:

The Functional Directors have discretion to elevate to their superior.

2. The Commissioner and the Deputy Commissioner, TE/GE, retain the authority to request that any issue under consideration at any level within TE/GE be elevated to them.

3. Only the Commissioner, TE/GE has authority to decide some issues and to require those issues to be elevated to that office.



### Example:



Issues relating to the revocation of closing agreements.


**1.54.1.7.7** **(08-31-2016)**

#### Commissioner of Internal Revenue, Chief Tax Compliance Officer, and Chief Operating Officer

1. In general, issues of national concern in _IRM 1.54.1.7.4 (1)_ elevated to the Functional Directors in _IRM 1.54.1.7.5 (1)_ are also candidates for elevation to:



   - The IRS Commissioner

   - Chief Tax Compliance Officer

   - Chief Operating Officer



     ### Note:



     The Commissioner and/or the Deputy Commissioner, TE/GE have discretion to elevate to their superior.


**1.54.1.8** **(09-09-2021)**

### Referral to or Consultation with Counsel

1. TE/GE employees and managers should refer to Counsel or consult with Counsel when they need legal advice to properly interpret and apply the Code, or on other issues. Referring to or consulting Counsel isn’t necessarily an elevation but can be considered one if we transfer the power of decision and the issue to Counsel. Call/refer to Counsel when:



1. The correct interpretation or application of law is uncertain, or when a taxpayer seriously challenges the position TE/GE has taken on an issue.

2. You want to confirm that TE/GE’s interpretation of the Code is correct.

3. You are required to, per national and local procedures, refer specific issues to Counsel for guidance or agreement.


2. Division Counsel (TEGEDC) is the primary Counsel contact for TE/GE employees and managers. Consult with the TEGEDC Area Counsel office that serves your geographical area.

3. In general, Associate Chief Counsel (Employee Benefits, Exempt Organizations and Employment Taxes) CC:EEE works on:



   - Procedural and technical guidance

   - Letter rulings

   - Technical advice


4. If you need to consult the Associate Chief Counsel, go through your assigned Area Counsel office who can help determine the fastest, most efficient way to get their help.


**1.54.1.8.1** **(01-01-2006)**

#### Concurrent Elevation to Counsel and within TE/GE

1. Often, whenever TE/GE employees or managers refer a non-routine question or problem to or consult with Counsel, they should elevate the facts of the referral or consultation to their immediate supervisors.


**1.54.1.8.2** **(01-01-2006)**

#### Issues to Bring to Counsel's Attention

1. Notify TEGEDC of:



1. Novel or unsettled issues of law.

2. Cases potentially going to court, even those with a remote chance.

3. Cases in which you’re required to refer to or consult with Area Counsel by law, revenue procedure, other directive, or local practice.

4. Questions of disclosure, bankruptcy, summons, etc.

5. New or amended Code provisions.

6. Questions on proposed regulations, revenue procedures, announcements, notices and other forms of technical guidance.

7. Cases that have novel or unsettled issues of law, including candidates for technical advice.

8. Unusual personnel or labor relations questions.

9. Disputes with other federal agencies.


**1.54.1.9** **(12-20-2013)**

### Issues Reported or Resolved Outside the IRS

1. By law, you must report certain issues to specific organizations or entities outside the IRS. Although these don’t constitute referrals to higher TE/GE levels, it’s important to understand how to deal with these issues as the process is similar.




| Refer to | Applicable Law |
| --- | --- |
| Joint Committee on Taxation | Under IRC 6405, IRS must give a notice of a refund or credit in excess of $2,000,000 ($5,000,000 for a C corporation) at least 30 days before we give the refund or credit. |
| TIGTA | In general, refer reports or allegations of employee waste, theft, fraud and wrongdoing to TIGTA.<br> <br>1. RRA 98 added IRC 7217, that states with three exceptions, it’s unlawful for specified high-level Executive Branch employees to request an IRS employee to conduct or terminate a tax audit or other investigation of any particular taxpayer. IRC 7217 further requires any employee to whom such a request is made to report the request immediately to TIGTA and provides criminal penalties for failure to report.<br>      <br>2. Although you should elevate illegal contacts under IRC 7217 to higher TE/GE management and executives, this isn’t sufficient to comply with IRC 7217. Refer reports of illegal contacts directly to TIGTA. |
| Department of Labor | Director, EP must give the Secretary of Labor notice to object to IRS proposed disqualification of a plan qualified under IRC 401(a) for a violation of the exclusive benefit rule. See the Memorandum of Understanding – IRS/DOL Coordination Agreement dated June 3, 2003, and the Addendum to the IRS/DOL Coordination Agreement dated October 24, 2013, for the amount of time and other requirements. |
| Pension Benefit Guaranty Corporation | Director, EP must give PBGC 30 days in which to comment before granting or modifying a waiver of the minimum funding standard under IRC 412(c). |


**1.54.1.10** **(01-01-2006)**

### Avoiding Inappropriate Elevation by Appropriately Exercising Responsibility

1. This section doesn’t intend to discourage employees and managers from carrying out responsibilities or making decisions in their areas of responsibility and expertise. The Commissioner, TE/GE, and other high-ranking officials, cannot, and should not, make all decisions for TE/GE. Employees and managers should decide issues within their areas of responsibility and expertise.

2. When you consider whether to elevate an issue, employees and managers should ask:



   - Does the issue fall within my duties as defined in my position description?

   - Am I evaluated on my ability to decide and handle issues of this nature?

   - Am I authorized to make decisions or to handle issues of this sort?

   - Are issues like this normally decided at my level?

   - Is the issue one that has arisen before and can it be resolved according to an established practice or routine?

   - Am I personally competent to decide or handle this issue?


3. If the answer to these questions is "**yes,**" you shouldn’t elevate the issue.


**1.54.1.10.1** **(08-31-2016)**

#### Issues That Should Not Be Elevated Above a Certain Level

1. There are some exceptions to the rules for elevating issues within the IRS. The rules in this IRM serve as a guide and indicate the types of issues you should elevate to particular levels. However, where to elevate an issue is not always a precise definition. Every employee, manager and executive must use discretion and judgment to make a system of elevation work well.

2. Superior levels to whom an issue is elevated may decline to accept the elevation, and to refer it back to where the issue could be decided or resolved best.



### Note:



It’s inappropriate to decline an elevation in cases in which the level of decision is established by statute, regulation, or delegation order, and re-delegation to a subordinate level is prohibited.

3. Employees, managers and executives should keep these in mind when considering elevating an issue:




| Issue | Direction |
| --- | --- |
| Routine or Trivial Questions or Problems | Don’t elevate, even if they meet one or more criteria for elevation.<br> <br>### Example:<br>A member of the Senate Finance Committee or the House Ways and Means Committee sends a routine inquiry about the status of a determination letter application submitted by one of their constituents. Don’t elevate, even though the inquiry is coming from a member of one of the Congressional tax-writing committees.<br>### Caution:<br>However, if multiple (more than three) inquiries, even from various sources, are submitted on the same or similar topic, they may relate to a broader issue, and constitute a trend or a pattern. Don’t consider this pattern of inquiries routine or trivial; elevate it to your immediate supervisor. |
| Political Appointees | The IRS has a practice of not involving political appointees (i.e., the Commissioner of Internal Revenue and the IRS Chief Counsel) in specific taxpayer matters, to the degree possible. These should, if possible, be resolved in the Office of the Commissioner, TE/GE, or in the office of the Deputy Commissioner, Service and Enforcement. |
| Contacts by Certain Executive Branch Officials and Employees | RRA 98 Section 1105 prohibits certain Executive Branch officers and employees (the President, the Vice President, any employee of the executive offices of the President or Vice President, Cabinet Secretaries, the Commissioner of Social Security, the Director of National Drug Control Policy, the Director of the Office of Management and Budget, and the U.S. Trade Representative) to directly or indirectly request any IRS employee to conduct or terminate a tax audit or other investigation of any particular taxpayer.<br> Employees:<br> <br>1. Who receive this type of request should immediately contact the local TIGTA office and report the incident.<br>      <br>2. May contact the TIGTA Integrity Hotline, 1-800-366-4484, if unable to contact the local TIGTA office.<br>      <br>3. In addition to contacting TIGTA, employees, managers, and executives should elevate a contact up the chain of command for informational purposes but shouldn’t act on it. |


**1.54.1.11** **(08-31-2016)**

### Reaching Down

1. Sometimes, TE/GE managers and executives don’t wait for an issue to be elevated to them but will reach down into the organization for the issue. That is, they ask a subordinate TE/GE manager or employee to raise an issue arising, being worked, or awaiting decision to them so they can be informed, review it, or decide it.

2. Reasons a manager or executive may reach down for an issue:



1. To become familiar with an emerging issue.

2. To resolve a technical or administrative problem.

3. To create uniform administration of the law throughout the country.

4. To ensure we meet quality control standards.

5. To resolve a dispute or problem with taxpayers or within the IRS.

6. To ensure that the organization functions efficiently and properly.


3. When a manager or executive reaches down for an issue, he/she generally explains why they are becoming involved. Doing so helps ensure that affected taxpayers and employees, and any entity making a subsequent inquiry, such as TIGTA or GAO, understand that the manager or executive had an appropriate reason.


**1.54.1.12** **(08-31-2016)**

### Consulting with Front-line Employees and Managers

1. Although this IRM primarily discusses when to elevate issues upward to senior managers and executives, sometimes senior managers and executives may consult with front-line employees and managers when policies or procedures are developed.

2. An organization’s ability to accomplish its purpose efficiently and accurately depends on the ability of each employee, at every level, to understand and expertly perform his/her job. At every level of the organization, employees develop specialized expertise where some have an expert understanding of:



1. The tax laws we administer.

2. The needs and characteristics of the customers we serve.

3. The IRS information systems we depend upon.

4. The personnel system.

5. How TE/GE coordinates with other IRS divisions.


3. This accumulated expertise of TE/GE employees, at every level and location, is one of TE/GE‘s important assets that managers and executives should use as they develop pertinent policies and procedures. Consult front-line employees and managers who have specialized information or expertise when considering:



1. Policies or procedures within their area of expertise.

2. The best solution for elevated issues with several possible resolutions.

3. Issues about the way they perform their front-line work.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-054-001#addtoany "Show all")

A2A