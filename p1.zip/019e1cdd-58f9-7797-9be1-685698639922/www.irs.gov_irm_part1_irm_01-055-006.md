---
url: "https://www.irs.gov/irm/part1/irm_01-055-006"
title: "1.55.6 Taxpayer Services (TS) Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) Post-Audit Process | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-055-006#main-content)

- 1.55.6  [Taxpayer Services (TS) Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) Post-Audit Process](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881949660496)
  - 1.55.6.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881920841136)
    - 1.55.6.1.1  [Background](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881920818960)
    - 1.55.6.1.2  [Roles and Responsibilities](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921281056)
    - 1.55.6.1.3  [Authority](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921277040)
    - 1.55.6.1.4  [Acronyms and Definitions](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921268416)
    - 1.55.6.1.5  [Related Resources](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921314240)
  - 1.55.6.2  [The Post Audit Process](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921310496)
  - 1.55.6.3  [Identifying Planned Corrective Action (PCA) Report and Action Numbers](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921085760)
  - 1.55.6.4  [Tracking Corrective Action Plans](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881949557184)
  - 1.55.6.5  [Obtaining Access to the JAMES](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881949554720)
  - 1.55.6.6  [Verifying the JAMES Report](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881949547296)
  - 1.55.6.7  [Tracking Duplicate Planned Corrective Actions (PCAs)](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881949517776)
  - 1.55.6.8  [Placing Recommendations on Hold](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881949504064)
  - 1.55.6.9  [Closing Recommendations on Hold](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922172960)
  - 1.55.6.10  [Updating Planned Corrective Action (PCA) Reports](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922168128)
    - 1.55.6.10.1  [Implementing PCAs](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922153312)
    - 1.55.6.10.2  [Implementing PCAs with Outcome Measures](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922146160)
    - 1.55.6.10.3  [Canceling PCAs](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922139296)
    - 1.55.6.10.4  [Superseding PCAs](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922123392)
    - 1.55.6.10.5  [Extending PCAs](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922121472)
  - 1.55.6.11  [Documenting Status Updates Using Form 13872, Planned Corrective Action (PCA) Status Update](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922101008)
  - 1.55.6.12  [Transferring Planned Corrective Actions (PCAs)](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922095328)
  - 1.55.6.13  [Timeliness](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922090000)
  - 1.55.6.14  [Long-Term PCAs](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922055344)
    - 1.55.6.14.1  [Long-Term PCAs Status Update](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922051536)
  - 1.55.6.15  [Uploading Support Documentation](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922047184)
  - 1.55.6.16  [Closed Planned Corrective Action (PCA) Quality Review](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881922033408)
  - 1.55.6.17  [Final Validation of Planned Corrective Actions (PCAs)](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921504624)
  - 1.55.6.18  [Reports](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921499040)
    - 1.55.6.18.1  [JAMES Reports](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921497040)
  - 1.55.6.19  [Records and Information Management](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921481376)
  - Exhibit  1.55.6-1  [Example of a JAMES Report Verification E-mail](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921473936)
  - Exhibit  1.55.6-2  [Example of a Non-Concurrence Memorandum](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921447248)
  - Exhibit  1.55.6-3  [Example of a JAMES Report Verification Memorandum](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921439872)
  - Exhibit  1.55.6-4  [Example of a Memorandum Requesting Cancellation of a TIGTA Corrective Action](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921432864)
  - Exhibit  1.55.6-5  [Example of a Memorandum Concurring the Closure of a TIGTA Planned Corrective Action](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921414608)
  - Exhibit  1.55.6-6  [Example of a Memorandum from TIGTA Not Concurring the Closure of a Planned Corrective Action](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921407568)
  - Exhibit  1.55.6-7  [Example of a Memorandum Requesting the Transfer of a Planned Corrective Action](https://www.irs.gov/irm/part1/irm_01-055-006#idm139881921396320)

# Part 1. Organization, Finance, and Management

# Chapter 55. Wage and Investment

# Section 6. Taxpayer Services (TS) Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) Post-Audit Process

* * *

## 1.55.6 Taxpayer Services (TS) Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) Post-Audit Process

#### Manual Transmittal

January 14, 2025

#### Purpose

(1) This transmits revised IRM 1.55.6, Taxpayer Services - Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) Post-Audit Process.

#### Material Changes

(1) IRM 1.55.6 - IPU 24U0569 issued April 25, 2024 - Updated IRM title, removed W&I, added Taxpayer Services.

(2) IRM 1.55.6.1.4(2) - Updated the Joint Audit Management Enterprise System definition.

(3) IRM 1.55.6.2(1) - Added a reference to the Support Documentation Decision Table job aid.

(4) IRM 1.55.6.3 - Table 1.4 - Updated Taxpayer Services Organizational Codes

(5) IRM 1.55.6.4(1) - Clarified corrective actions and implementation date guidance.

(6) IRM 1.55.6.5(3) - Account deactivation changed to 90 days.

(7) IRM 1.55.6.6(1) - Clarified the description of the A6 Audit Summary Report.

(8) IRM 1.55.6.6(2) - Added a reference to the A6 Verification checklist.

(9) IRM 1.55.6.6(9) - Clarified TIGTA posts a $1 in the Actual Benefits Amount field at the PCA level in JAMES.

(10) IRM 1.55.6.8 - Updated guidance regarding Recommendations on Hold.

(11) IRM 1.55.6.10.1 - Clarified the use of an IGM or an IPU when implementing PCAs.

(12) IRM 1.55.6.10.5(5) - Removed the use of the PCA Justification of Extension Evaluative Form for requesting PCA extensions.

(13) IRM 1.55.6.13 - Added PCA timeliness clarification guidelines.

(14) IRM 1.55.6.15 - Removed guidance regarding changing a PCA status to either cancelled or replaced.

(15) IRM 1.55.6.19 - Updated records retention timeframe to 7 years.

(16) Exhibit 1.55.6-1 - Updated to illustrate the current version of the email notice to TS.

(17) Various editorial changes made throughout to spelling, grammar and punctuation. Updated terms, links and organizational titles.

#### Effect on Other Documents

IRM 1.55.6 dated November 8, 2022, is superseded. IRM Procedural Update (IPU) 24U0569, issued April 25, 2024 has been incorporated into this IRM.

#### Audience

Taxpayer Services and other IRS business division Government Accountability Office (GAO) and Treasury Inspector General for Tax Administration (TIGTA) audit coordinators.

#### Effective Date

(01-14-2025)

Srinivasa R. Ponakala

Acting Director, Business Technology Operations

Taxpayer Services

**1.55.6.1** **(11-08-2022)**

### Program Scope and Objectives

1. **Purpose:** This IRM provides information and guidance on the post audit process and responsibilities within Taxpayer Services (TS).

2. **Audience:** All TS executives, managers, and TS Division/Functional liaisons, audit coordinators and JAMES audit coordinators.

3. **Policy Owner:** Director, TS Operations Support

4. **Program Owner:** Director, Business Technology Organization

5. **Program Goals:**



   - Facilitate the post audit process within TS.

   - Ensure planned corrective actions (PCAs) address the highest risks and deliver the most value.

   - Track corrective action implementation and effectiveness of PCAs in response to TIGTA and GAO audit recommendations.

   - Provide support for JAMES coordination. Ensure progress is made over time.


6. **Primary Stakeholders:** TS executives and management, TS functional coordinators and liaisons, Enterprise Audit Management and TIGTA and GAO personnel.


**1.55.6.1.1** **(11-08-2022)**

#### Background

1. The IRS is subject to oversight review conducted by the [Government Accountability Office (GAO)](http://www.gao.gov/) and the [Treasury Inspector General for Tax Administration (TIGTA)](http://www.treas.gov/tigta/). The reviews may be in response to congressional requests or planned engagements to evaluate the effectiveness and efficiency of the policies and programs used by the IRS to administer the nation’s tax laws and assist taxpayers in meeting their filing and payment obligations.

2. The GAO and TIGTA issue reports of their findings and recommendations. With very limited exceptions, the final drafts of their reports are posted on their respective websites and are publicly available.

3. Within Taxpayer Services, oversight of both the audit process and the post-audit process falls under the direction of the Director, TS Operations Support (TSOS).


**1.55.6.1.2** **(11-08-2022)**

#### Roles and Responsibilities

1. The Director, Business Technology Operations (BTO), reporting to the TSOS director, is the executive responsible for administering the Planned Corrective Actions (PCA) program within TS.

2. The Chief, Program Evaluation and Improvement (PEI), reporting to the BTO director, has direct oversight of the PCA program within TS.

3. The Taxpayer Services Joint Audit Management Enterprise System (JAMES) Coordinator is the primary business unit coordinator and functional business unit contact throughout TS.

4. Functional executives have oversight responsibility for addressing, maintaining, and completing PCAs assigned to their respective functions.

5. Business unit coordinators manage the post-audit process within their business units and functional areas.


**1.55.6.1.3** **(11-08-2022)**

#### Authority

1. The following authorities govern the procedures in this IRM:



   - Federal Managers’ Financial Integrity Act of 1982 (FMFIA) (31 USC §3512(c)(d)

   - Federal Financial Management Improvement Act of 1996 (FFMIA, Pub. L. No. 104-208, 110 Stat. 3009)

   - Chief Financial Officers Act of 1990, Pub. L. No. 101-576, 104 Stat. 2838 (Nov. 15,1990), as amended by the Government Management Reform Act of 1994

   - Office of Management and Budget (OMB) Circular A-123, Managements Responsibility for Internal Control

   - Treasury Directive 40-03, Treasury Audit Resolution, Follow-Up, and Closure issued May 19, 2017

   - Inspector General Act of 1978, as amended, 5 USC app. (2012 & Supp. IV 2017)

   - Pub. L. No. 103-356, 108 Stat. 3410 (Oct. 13, 1994).

   - Title 26 authority for IRC for disclosure i.e., 26 USC 6103 and Delegation Order 11-2

   - Good Accounting Obligation in Government Act of 2019


2. Treasury Policy Statements provide authority for the work being done over the lifecycle which include:



   - Office of Management and Budget (OMB) Circular A-123, Management’s Responsibility for Internal Control

   - Treasury Directive 40-02, Corresponding with the General Accountability Office (GAO)

   - Treasury Directive 40-03, Treasury Audit Resolution, Follow-Up, and Closure

   - Treasury Order 115-01


**1.55.6.1.4** **(01-14-2025)**

#### Acronyms and Definitions

1. Below is a list of the most common acronyms found in this IRM:




| **Acronym** | **Definition of Acronym** |
| :-: | :-: |
| BOD | Business Operating Division |
| CARE | Customer Assistance, Relationships and Education |
| CAS | Customer Account Services |
| DCIR | Deputy Commissioner Internal Revenue Service |
| EAM | Enterprise Audit Management |
| FARS | Financial Analysis and Reporting System |
| FFMIA | Federal Financial Management Improvement Act |
| FMFIA | Federal Managers’ Financial Integrity Act |
| GAO | Government Accountability Office |
| HTML | Hyper Text Markup Language |
| IAO | Identity Assurance Office |
| IGM | Interim Guidance Memorandum |
| IPU | Internal Revenue Manual Procedural Update |
| JAMES | Joint Audit Management Enterprise System |
| LB&I | Large Business and International |
| MC ESC | Management Control Executive Steering Committee |
| MSP | Most Serious Problems |
| MW | Material Weakness |
| NTA | National Taxpayer Advocate |
| OpSB | Operations Strategy Board |
| PCA | Planned Corrective Action |
| REM | Remediation Plan |
| RICS | Return Integrity and Compliance Services |
| SB/SE | Small Business and Self-Employed |
| SD | Significant Deficiency |
| TE/GE | Tax Exempt and Government Entities |
| TIGTA | Treasury Inspector General for Tax Administration |
| TS | Taxpayer Services |
| TSOS | Taxpayer Services Operations Support |
| UWR | Unified Work Request |

2. Below are definitions of terms used throughout this IRM.




| **Term** | **Definition** |
| :-: | :-: |
| A6 Audit Summary Report | This is a report from JAMES which provides a summary of the source audit findings, recommendations, and corrective actions. It indicates if the IRS disagreed with a recommendation (rejected), and it identifies the due dates and business unit owner of each PCA. It also provides a history of progress on each PCA by displaying interim and closing comments transmitted via Form 13872. |
| Extended/Delayed | An option in JAMES used to extend a PCA due date. Requires the selection of a reason code from a drop-down listing. |
| Finding | Describes a deficiency or opportunity for improvement in the remediation plan or audit report. |
| Form 13872 , _Planned Corrective Action (PCA) Status update for TIGTA/GAO/MW/SD/TAS/REM Reports_ | The source document used by all BODs to update PCAs in JAMES. |
| Internal Controls | Provides reasonable assurances in an organization’s effectiveness and efficiency of operations, reliability of financial reporting and compliance with applicable laws and regulations. |
| Joint Audit Management Enterprise System (JAMES) | Treasury's web-based system for tracking audit recommendations and associated planned corrective actions. |
| Planned Corrective Action (PCA) | A detailed description of how management implements a recommendation to address an audit finding(s) |
| Recommendation/Issue | Addresses the finding and provides TIGTA and GAO comments to management that, when implemented, corrects the issue. |
| Remediation Plan | A plan to achieve FFMIA compliance when an agency's annual review determines its financial management systems cannot:<br> <br>   - prepare required financial statements and reports.<br>     <br>   - provide reliable and timely financial information for managing operations.<br>     <br>   - account for assets in accordance with Federal accounting standards and the United States Standard General Ledger |
| Status Update | Provides actions taken by the BOD that correct identified deficiencies, produce recommended improvements, and/or demonstrate that audit findings are either invalid or do not warrant corrective action. |


**1.55.6.1.5** **(11-08-2022)**

#### Related Resources

1. The following are resources related to the post audit process:



   - IRM 1.29.1, _Audit Coordination Process, Authorities and Responsibilities_

   - TD 40-02, Corresponding with the Government Accountability Office

   - TD 40-04, Treasury Internal (Management) Control Program


**1.55.6.2** **(01-14-2025)**

### The Post Audit Process

1. **The JAMES Audit Coordinator (JAC)** \- The JAMES coordinator oversees and manages the post audit process, including PCAs and updates to the JAMES. For more information on JAC responsibilities refer to IRM 1.29.1.1.3.6, **JAMES Audit Coordinators (JACs)**Additionally, the Taxpayer Services James Coordinator is also responsible for the following post audit activities:



01. Serving as the liaison between TS and The Office of Enterprise Audit Management (EAM).

02. Overseeing the completion of TS GAO/TIGTA corrective action plan inventory.

03. Coordinating status updates with each business unit coordinator.

04. Tracking performance measures.

05. Preparing and providing status reports to TS management.

06. Assisting business unit coordinators with administrative or training needs regarding the PCA process.

07. Maintaining final audit and post-audit records.

08. Reconciling the business division corrective action plan inventory for PCAs in hold status.

09. Reviewing Form 13872 requesting to extend or complete a PCA.

10. In conjunction with the TS business unit coordinators, ensuring that entries for the A6 report are correctly input and assigned to the correct Taxpayer Services business unit.

11. Reviewing responses on Form 13872 review and approval before signatures with the JAMES business unit coordinators.



       ### Note:



       Business unit coordinators are responsible for inputting comments and uploading the Form 13872 into JAMES. For more information on how to review Form 13872, see IRM 1.29.1.3.3 _, Requirements for Form 13872 and Supporting Documentation_, the Decision Matrix Tree for PCA Support Documentation Decision Table job aid in the [Audit Community Expertise (ACE)](https://irsgov.sharepoint.com/sites/ACE/Pages/Audit-Community-of-Expertise-(ACE)-Revised.aspx) SharePoint Site maintained by EAM under the Employee Guidance Section and the Exhibit IRM 1.29.1-10, _Form 13872 Closure Checklist_.

12. Reviewing all business unit coordinators’ entries into the JAMES, including supporting documentation, which implements or extends planned corrective actions.


2. **Business Unit Coordinator** \- Within each Taxpayer Services business unit, a coordinator works with the division JAMES coordinator to manage the post audit process for their business unit. The business unit coordinators are responsible for the following:



01. Verifying and tracking post-audit GAO/TIGTA activity.

02. Serving as the business unit JAMES coordinator.

03. Ensuring the proper preparation of Form 13872 and forwarding to the Taxpayer Services JAC for review and approval prior to routing for signatures and input into JAMES.

04. Obtaining the requisite managerial and executive signatures to document PCA comments, due date extensions, and closures in JAMES.

05. Uploading completed Form 13872 and documentation supporting PCA closures to the JAMES.

06. Monitoring the due dates of open PCAs.

07. Ensuring activities required to implement PCAs are completed by their business unit/field personnel.

08. Preparing and providing status reports, such as pending PCAs, and PCAs on hold through the Taxpayer Services JAMES audit coordinator and the division headquarters management.

09. Determining when extensions to open PCA due dates are needed.

10. Documenting and updating the status of PCAs in the JAMES, including uploading support documentation to implement or extend an action.

11. Conducting a review of the action status and inventory.

12. Reconciling the business unit’s inventory of PCAs.

13. Preparing ad hoc reports.

14. Maintaining audit files.


**1.55.6.3** **(01-14-2025)**

### Identifying Planned Corrective Action (PCA) Report and Action Numbers

1. The TIGTA and GAO planned corrective action (PCA) reports tracked in the JAMES are identified by a unique numbering sequence.

2. The TIGTA and GAO PCA action numbers are comprised of the finding number, the recommendation number, and the corrective action number. The TIGTA report numbers are comprised as shown in Table 1.1 and the GAO report numbers are comprised as shown in Table 1.2.



**Table 1.1. — TIGTA Report Number Explanation**






| **Digits in TIGTA Report Number** | **Represent** |
| --- | --- |
| First four digits | Fiscal year in which the final report is issued<br> <br>### Example:<br>A final report dated December 5, 2021 (Fiscal Year 2022), would have “2022” as the first four digits.<br>### Note:<br>A hyphen is present after the fourth digit. |
| Fifth, sixth, and seventh digits | The fifth and sixth digits denote the TIGTA directorate that performed the audit. The seventh digit is used for a special emphasis area, i.e., 0 = no special emphasis area, 1, 2 = not currently in use; 3 = Affordable Care Act; 4 = Tax Cuts and Jobs Act; 5 = Taxpayer First Act; 6 = CARES Act; 7 = American Rescue Plan Act; 8 = Inflation Reduction Act.<br> <br>### Note:<br>A hyphen is present after the seventh digit (e.g., 2012-000-000). |
| Eighth, ninth, and tenth digits | Sequential number assigned by TIGTA. |







**Table 1.2. — GAO Report Number Explanation**






| **Digits in GAO Report Number** | **Represent** |
| --- | --- |
| First three characters | GAO<br> <br>### Note:<br>Hyphens are present after the third and fifth digits. |
| Fourth and fifth characters | Fiscal year the report was opened.<br> <br>### Note:<br>Hyphens are present after the third and fifth digits e.g., GAO-10-000. |
| The last characters | Sequential numbers assigned by GAO.<br> <br>### Note:<br>GAO has recently changed format for an ending three-digit number to six digits. The number is the Job Code used for the audit e.g., GAO-22-102346. |









**Table 1.3. — IRS Program Areas and TIGTA Business Unit Codes**






| **TIGTA Business Units** | **Code** |
| :-: | :-: |
| Management Services and Exempt Organizations (MSE) | 1X |
| Security and Information Technology Services (SITS) | 2X |
| Compliance and Enforcement Operations (CEO) | 3X |
| Returns Processing and Account Services (RPA) | 4X |

3. Business unit codes may not always end in “0.”



### Note:



If the middle digit, or business unit code, ends in "1" that indicates the report is associated with the American Recovery and Reinvestment Act of 2009; if the middle digit ends in "2" that indicates the report is related to anti-fraud; and if the middle digit ends in "3" that indicates the report is associated with the Affordable Care Act of 2010.

4. PCA plans are assigned to a lead business division identified by the organizational symbols; referred to as the “Responsible Organization” in the JAMES.

5. PCAs are assigned to a specific business unit to implement; referred to as the “Responsible Employee” in the JAMES.

6. Organizational codes are extended to the third and fourth level. See Table 1.4. for a partial list of TS organizations and organizational codes.



**Table 1.4. — TS Responsible Organization List and Organizational Codes**






| **TS Business Organizations** | **Functional Areas** |
| :-: | :-: |
| Operations Support - C:DC:TS:O | - Capital Management Oversight (CMO) - C:DC:TS:O:CMO<br>     <br>   - Business Systems Modernization (BSM) - C:DC:TS:O:BSM<br>     <br>   - Business Technology Operations (BTO) - C:DC:TS:O:BTO<br>     <br>   - Strategies and Solutions - C:DC:TS:O:SS<br>     <br>   - Program Management Office (PMO) - C:DC:TS:O:PMO |
| Customer Assistance, Relationships and Education - C:DC:TS:CAR | - Field Assistance - C:DC:TS:CAR:FA<br>     <br>   - Media and Publications - C:DC:TS:CAR:MP<br>     <br>   - Stakeholder Partnerships, Education and Communications - C:DC:TS:CAR:SPEC |
| Customer Account Services - C:DC:TS:CAS | - Accounts Management - C:DC:TS:CAS:AM<br>     <br>   - Electronic Products & Services Support - C:DC:TS:CAS:EPSS<br>     <br>   - Joint Operations Center - C:DC:TS:CAS:JOC<br>     <br>   - Submission Processing - C:DC:TS:CAS:SP |
| Return Integrity and Compliance Services - C:DC:TS:RICS | - Refundable Credits Program Management - C:DC:TS:RICS:RCPM<br>     <br>   - Refundable Credits Examination Operations - C:DC:TS:RICS:RCEO<br>     <br>   - Return Integrity Verification Operations - C:DC:TS:RICS:RIVO<br>     <br>   - Return Integrity Verification Program Management - C:DC:TS:RICS:RIVPM |
| Taxpayer Services Communications and Liaison - C:DC:TS:C | C&L Reports to the Commissioner to Taxpayer Services Chiefs and has no other business units assigned. |


**1.55.6.4** **(01-14-2025)**

### Tracking Corrective Action Plans

1. At the close of an audit, a corrective action report is entered into JAMES. Each corrective action has an implementation date that the BOD chooses and is documented in the audit management response letter. JAMES tracks PCAs for all Treasury Department agencies by the projected implementation date.

2. A new report number is assigned in the JAMES. This number tracks post GAO and TIGTA audit activity. For the list of codes, see Table 1.3.


**1.55.6.5** **(01-14-2025)**

### Obtaining Access to the JAMES

1. To obtain access to the JAMES, the new user’s manager must send a JAMES access request to the TS headquarters JAMES Coordinator within the Program, Evaluation and Improvement (PEI) Team. If a functional coordinator is requesting access, the manager will first forward to the business unit coordinator to review before submitting to PEI. The manager must include the following information when requesting JAMES access:



   - Employee Name

   - SEID

   - E-mail Address

   - Telephone Number

   - Level of Access (read-only or full)

   - Account Type (new or modified)

   - Office Organizational Symbol (e.g., C:DC:TS:CAS:AM)


2. Users must read and acknowledge receipt of the "FARS User Responsibility Statement" and the "Rules of Behavior" document online before gaining access to the application.



### Note:



TIGTA representatives have access to the JAMES and send requests directly to their designated JAMES responsible official. GAO representatives do not have access to the JAMES; however, they may contact EAM to request PCA status updates.

3. Accounts with 90 days of inactivity will deactivate. Contact your JAMES TS Coordinator for reactivation.


**1.55.6.6** **(01-14-2025)**

### Verifying the JAMES Report

1. A6 Audit Summary Report contains a summary from the final GAO or TIGTA Audit Report's findings, recommendations and PCA’s including the amount of any potential monetary benefits and root cause. TIGTA audit reports are entered into JAMES by TIGTA. GAO audit reports are entered into JAMES by EAM. For more information regarding how the A6 Report is input, visit IRM 1.29.1.3.6.7, _Entering New Audit Reports into JAMES_.

2. When new actions are entered into the JAMES, the EAM Coordinator sends a notification e-mail to the TS JAMES Coordinator and TS Business Unit Coordinator. See _Exhibit 1.55.6-1_ for an example. The verification process involves the division and business unit coordinators reviewing the JAMES report (findings, recommendations and corrective action plan(s)) for accuracy and returning a notification of concurrence or non-concurrence.



### Note:



Please refer to the A6 Verification Checklist under Employee Guidance on Audit Community Expertise (ACE) SharePoint.

3. When a business unit concurs with the report and no outcome measures are identified, an e-mail response can be returned to EAM.

4. When a redaction request is made to a final audit report, the EAM Coordinator ensures the appropriate boxes are checked in the JAMES report to safeguard sensitive data. These JAMES reports may include redacted text from the final audit report posted on the auditing agency's website. Use caution when distributing JAMES reports containing redacted information by limiting distribution only to those with a need to know.



### Note:



Sensitive But Unclassified (SBU) reports are only accessible in the JAMES by the responsible business unit program users.

5. When there is a major discrepancy with the report and/or outcome measure, the business unit must prepare a memorandum under executive signature. See _Exhibit 1.55.6-2_ and _Exhibit 1.55.6-3_ for examples of memorandums. If more than one business unit is identified in a report, each business unit forwards a separate memorandum.



### Reminder:



Prepare all memorandums in accordance with IRM 1.10.1, **Office of the Commissioner of Internal Revenue, IRS Correspondence Manual.**

6. The EAM Coordinator, the Taxpayer Services JAMES Coordinator and the business unit coordinator each play significant roles in ensuring the implementation and timely reporting of PCAs to Congress.

7. The EAM Coordinator is responsible for:



1. Receiving notification from GAO or TIGTA of issuance of audit report.

2. Entering the GAO audit report into JAMES.

3. Notifying the responsible business division and/or business unit coordinator of the PCA plan(s).

4. Entering reports issued without recommendations in the JAMES.

5. Ensuring redacted reports are accurately identified in the JAMES.

6. Requesting missing PCA plan(s) if necessary.

7. Sending the responsible business division and/or business unit coordinator a copy of the JAMES A6 - _Audit Summary_ report tracked in the JAMES.


### Note:

For a GAO report, verification may be requested for a partial JAMES report containing only the findings and recommendations. Once the 180-day letter is received identifying the PCA, due date, and responsible official, the information is entered into the JAMES to complete the report and a second verification may be requested. Effective May 2017, the GAO financial statement audit is entered into the JAMES by the CFO FM Audit Team.

8. The TS business division coordinator is responsible for:



1. Receiving notification of new PCAs being tracked in the JAMES.



      ### Note:



      The business unit coordinator must be contacted to concur or not concur with the information in the report even if the report is entered in the JAMES as closed or without planned corrective actions.

2. Reviewing the JAMES report for accuracy.

3. Notifying the business unit coordinator of the request for review.

4. Tracking dates and any issues or concerns with the JAMES report.

5. Routing all JAMES report verification correspondence; generally, within 30 - 45 days after the issuance of the final audit report.


9. The TS business unit coordinator is responsible for:



1. Confirming that finding(s), root cause(s), recommendation(s) and PCA(s) are stated accurately.

2. Verifying if the JAMES report must be noted as redacted.

3. Ensuring the due date of the PCA is the 15th day of the month.

4. Ensuring the designation of the correct responsible official.

5. Ensuring potential outcome measures are correctly stated and a tracking method is in place to report the realized/unrealized benefits when the recommendation is implemented.



      ### Note:



      TIGTA posts a $1 in the Actual Benefits Amount field at the PCA level (Disallowed Costs, Actual Better Used Funds, Actual Revenue Enhancements) in JAMES to indicate that IRS disagrees with the outcome measure amount as stated in the management response attached to the final audit report. Outcome measures identified in Appendix IV of the final audit report may be required to track in the JAMES even if a formal recommendation is not noted. Coordinators must work with EAM to address timely and ensure accurate tracking in the JAMES.

6. Securing authorized signatures when a substantial disagreement with the findings, recommendations, PCA(s), or outcome measures are identified. When this occurs, the business unit coordinator ensures the memorandum clearly addresses the discrepancies, the monetary benefit type(s) and the amount(s); and is signed by the responsible executive. Refer to IRM 1.29.1.2.25(4) ,**Signature Process,**for more information.



      ### Reminder:



      Memorandums must be prepared according to IRM 1.10.1 _, IRS Correspondence Manual._

7. Ensuring a notification of concurrence or non-concurrence is returned to the business division coordinator on or before the requested due date.


### Note:

The data tracked in the JAMES is reported to Congress through the Department of Treasury; therefore, the accuracy of the information is important.

**1.55.6.7** **(11-08-2022)**

### Tracking Duplicate Planned Corrective Actions (PCAs)

1. When responding to an audit recommendation, it may be decided that more than one IRS business division or more than one TS business unit is responsible for implementing a PCA. If this is the case, then duplicate or multiple PCA(s) may be established and tracked in the JAMES. Communication between the affected offices, headquarters, and EAM is important and necessary. See Table 1.5, _Duplicate Planned Corrective Action Guidance_, for general guidance in recognizing when a duplicate PCA may be established if two or more officials are noted or implied as a responsible official in the final audit response.



**Table 1.5. — Duplicate PCA Guidance**






| **IF THE AUDIT RESPONSE IDENTIFIES...** | **THEN...** |
| :-: | :-: |
| One business division and/or business unit | One PCA is generally established in the JAMES with the business division and/or business unit listed as the responsible employee. |
| Two or more business divisions and/or business units are listed, but one business division and/or business unit is identified as the "lead." | Duplicate PCAs are generally _**not**_ established in the JAMES for each business division and/or business unit listed. |
| Two or more business divisions and/or business units | Duplicate PCAs are generally established in the JAMES; for each business division and/or business unit listed as a responsible official.<br> <br>### Note:<br>In some cases, the decision to duplicate or not to duplicate a PCA has already been cleared through the business unit's management and staff during the audit phase. |


**1.55.6.8** **(01-14-2025)**

### Placing Recommendations on Hold

1. The HOLD feature was instituted in 2017 due to IRS senior leadership concerns about committing to corrective action(s) when budgetary or other constraints were likely to inhibit implementation. However, beginning March 31, 2022, Interim Guidance Memo (IGM) OCRO-01-0322-0002 was issued to remove the process for placing recommendations on hold as this process has become obsolete with the agreement of the Chief Risk Officer, and the former Deputy Commissioners for Services and Enforcement and Operations Support. This IGM has since been incorporated into IRM 1.29.1.3.8, **Guidance for Recommendations on Hold**, and business units are to take the following actions:





2. Extend those recommendation due dates as necessary per the procedures for submitting extensions. See IRM 1.29.1.3.2, _Extending Planned Corrective Actions_, for more information.

3. Keep recommendations currently in Hold status until implementation or closure as unimplemented with the concurrence of the applicable oversight authority.


### Note:

Taxpayer Services deviates from IRM 1.29.1.3.8, _Guidance for Recommendations on Hold,_ in that recommendations on hold will not be aged out and closure will not be requested through the MC-ESC.

2. For any existing Hold recommendations, if a business unit decides to close the Hold as unimplemented, they must schedule a meeting with the applicable oversight authority (TIGTA or GAO) to:



   - Discuss the recommendation.

   - Go over any attempts that have been made to address it.

   - Review the challenges that could not be overcome.

   - Identify any alternative actions that still may be taken.

   - Provide documentation of these actions


3. If the oversight authority concurs with an unimplemented closure, a formal request memorandum to the oversight authority is prepared by the requesting business unit and routed through PEI for the signature of the Chief, Taxpayer Services.



### Note:



Taxpayer Services deviates from IRM 1.29.1.3.9 (2) and (3), _Managing Unique PCA Activities_, in that cancellation of PCAs will not be requested and the process for seeking agreement for unimplemented closure will be as previously described.

4. Recommendations that TS agreed to but lacked the funding and/or resources for implementation before February 03, 2021, were placed on hold.

5. The Recommendation Hold Category, which lists why a recommendation was placed on hold, is tracked in the JAMES. Generally, the responsible business organization determines the reason for a recommendation hold. The following are typical recommendation hold category reasons:



   - Funding

   - Input from other agencies

   - Legislation authority

   - Outside the Treasury’s purview


6. Status updates for TS recommendations placed on HOLD are requested twice during the year (e.g., February and September).

7. Recommendations on HOLD are reported to TS executive board monthly.

8. For more information regarding PCA Holds, see IRM 1.29.1.3.8, _Guidance for Recommendations on Hold._


**1.55.6.9** **(11-08-2022)**

### Closing Recommendations on Hold

1. When a recommendation on HOLD has been fully implemented, the business unit’s primary coordinator works with PEI and the EAM JAMES coordinators to update and close the PCA in JAMES.

2. Before closing recommendations on HOLD a Form 13872, **Planned Corrective Action (PCA) Status Update for TIGTA/GAO/MW/SD/TAS/REM Reports**, must be prepared to release the HOLD in JAMES. In box 4a of Form 13872, select HOLD Release/Add PCA from the status drop down menu. Form 13872 must state the corrective action, the responsible official, and the planned implementation date.

3. After the recommendation has been taken out of Hold status and the PCA created, another Form 13872, along with the supporting documentation will be uploaded to JAMES by the business unit coordinator to close the newly created PCA.



### Note:



Complete all TS activities to implement the recommendation before contacting EAM to close a recommendation on hold in the JAMES.


**1.55.6.10** **(04-16-2018)**

### Updating Planned Corrective Action (PCA) Reports

1. Activities in a planned corrective action (PCA) report are updated to record actions taken to implement, delay, cancel or supersede an action. The following table provides steps for updating PCA Reports:




| **Step** | **Actions** |
| --- | --- |
| 1 | Closely monitor due dates of open PCAs to ensure actions are updated timely and activities taken accurately complete the recommended task. |
| 2 | When tasks are delayed, see _IRM 1.55.6.10.5,_ _Extending PCAs,_ for a complete list of acceptable reasons to extend the due date of a PCA.<br> <br>### Note:<br>Delayed tasks generally mean extreme circumstances have prevented the implementation of the PCA. |
| 3 | Appropriately document all actions taken to implement a recommendation. Make documentation available upon request. |
| 4 | It is permissible to establish a placeholder action plan allowing management to address recommendations before the final due date. The action plan as well as the placeholder plan must clearly identify those actions management intends to take on the agreed upon recommendation(s).<br> <br>### Note:<br>Actions in a placeholder action plan are presented in complete or partial steps pending outcomes of task forces, studies, or annual reviews. |
| 5 | If a placeholder action plan is being tracked in the JAMES, management has time to address and implement the plan while considering their options or desired future goals. Also, management can do either of the following:<br> <br>   - Reassess the situation and provide a new corrective action plan with a delayed due date that fully addresses the recommendation(s).<br>     <br>   - Provide a revised placeholder PCA and delayed due date with steps management will now take to address the recommendation(s). |


**1.55.6.10.1** **(01-14-2025)**

#### Implementing PCAs

1. The PCAs are set with an implementation due date of the 15th day of the month.

2. Activities to implement a PCA must be completed prior to the due date so that completed, signed copies of Form 13872 and supporting documentation are uploaded to the JAMES at least five business days prior to the PCA due date.

3. Management officials must ensure activities are completed timely and accurately.

4. If the action requires computer programming, the programming must be complete and in use before the PCA is considered implemented.



### Note:



Submission of a work order or placing a program in test mode generally does not justify implementation.

5. If the corrective action is a procedural update, posting an Internal Revenue Manual Procedural Update (IPU) or an Interim Guidance Memorandum (IGM) to SERP will sufficiently complete the action and it may be submitted for closure.



### Note:



The actions taken to implement a PCA mitigates the risk of the audit finding. See IRM 1.29.1.3, _Monitoring Planned Corrective Actions,_ for additional guidance and _IRM 1.55.6.13, Timeliness_, for more information on timely implementing, extending, and updating planned corrective actions.


**1.55.6.10.2** **(01-14-2025)**

#### Implementing PCAs with Outcome Measures

1. Potential outcome measures represent either the possible dollar amounts available (cost savings), or the funds gained (increased revenue) when recommendations from an audit are implemented.

2. Of the eight categories of outcome measures, only three are tracked in the JAMES; they are:



   - Increased Revenue

   - Questioned Costs

   - Funds Put to Better Use


3. The amount of outcome measures realized with the implementation of a corrective action, including zero ($0) amounts, must be addressed on the Form 13872 to close an action. It must be clear what actions were taken to realize the amount reported.

4. If standard reporting will not permit IRS to determine the actual monetary benefits, it is the responsibility of the business function owning the PCA to prepare a data collection instrument or other methodology to collect the actual monetary benefit value.

5. See IRM 1.29.1.3.10, _EAM Reporting_, and IRM 1.29.1.3.11,**Tracking and Reporting Outcome Measures**, for additional guidance.


**1.55.6.10.3** **(10-14-2016)**

#### Canceling PCAs

1. When the implementation of an agreed upon PCA first identified in the final audit report is not possible, a request to cancel or close action(s) can be made to the auditing agency. The request to cancel a corrective action plan will be approved before the due date in the JAMES. The reason for the cancellation must be clear and the justification substantiated.



### Note:



Coordinate all correspondence to cancel a PCA with PEI.

2. Complete the actions below to request cancellation of a TIGTA or GAO PCA:



1. Schedule a meeting with the applicable oversight authority to discuss the recommendation, attempts that have been made to address it, challenges that could not be overcome, and provide documentation of these actions.

2. If the oversight authority concurs with an unimplemented closure, the requesting business unit prepares a formal request memorandum to the oversight authority and routes through PEI for the signature of the Chief, Taxpayer Services.


| **For TIGTA PCA Cancellations** | **For GAO PCA Cancellations** |
| :-: | :-: |
| Address the memorandum to the Deputy Inspector General.<br> <br>### Note:<br>See Exhibit 1.55.6-4, _Example of a Memorandum Requesting Cancellation of a TIGTA Corrective Action,_ for more information. | 1. Address the correspondence (e.g., memorandum or e-mail) to GAO.<br>      <br>2. Ensure any correspondence has the signature of the responsible business organization executive. |

### Note:

Taxpayer Services deviates from IRM 1.29.1.3.9 (2) and (3) in that cancellation of PCAs will not be requested and the process for seeking agreement for unimplemented closure will be as previously described.

### Note:

TIGTA will return a notification of their decision to concur or not concur. See _Exhibit 1.55.6-6_

and _Exhibit 1.55.6-4_ for guidance.



**1.55.6.10.4** **(11-08-2022)**

#### Superseding PCAs

1. When an audit results in action(s) previously recommended in another audit and those action(s) are still open, update the status of the previous action from "open" to "superseded." The recommended action is then tracked through the new report. The repeat audit indicator field in the JAMES must also be updated.


**1.55.6.10.5** **(01-14-2025)**

#### Extending PCAs

1. When an activity, program or product required to implement a PCA plan is unattainable by the original due date, implementation of the corrective action is postponed. A status update, new due date, and justification for the extension is required. The status remains open and a justification to extend the PCA is noted.

2. Justification for extending a PCA is categorized. The specific category is captured on the Form 13872, _Planned Corrective Action (PCA) Status Update,_ and in the JAMES.

3. The Department of Treasury has approved the following categories and delay definitions for extending PCA:




| **Category** | **Delay Definition** |
| :-: | :-: |
| Research/Analyze Data | Delays in implementation to perform additional analysis or studies |
| Publishing | Delays in issuing or publishing guidance or manuals |
| Concurrence | Delays due to PCAs that are coordinated with other offices before the action could be implemented, closed, or cancelled |
| Monetary Benefits | Delays to address associated actual outcome measures |
| Legislation | Delays due to waiting for the resolution of a legal issue |
| Clearance | Routing delays for comments or reviews (supporting documentation must show that it is in the final stage of the review process) |
| Budget | Delays due to waiting for the approval of funding |
| Resource | Delays due to the lack of insufficient resources due to budget constraints |
| Contract | Delays due to waiting for contract awards or when procurement activities are not complete |
| Information Technology (IT) | Unforeseen release delays due to programming or hardware/software issues |

4. Notify PEI before an action to extend a PCA is entered into the JAMES.



### Note:



**Extending the original implementation due date of a PCA beyond the fiscal year is considered a late response by the Department of Treasury. The IRS performance measures of PCAs, met and/or extended, is shared with IRS executives during operational reviews and other executive briefings (e.g., Operations Strategy Board and Management Control Executive Steering Committee). See IRM 1.29.1.3,**Monitoring Internal Control Planned Corrective Actions**, for more information on performance reporting.**

5. To request an extension, provide the assessment of the request for an extension in box 7 of the Form 13872. See IRM 1.29.1.3.2, **Extending Planned Corrective Actions**, for more information.


**1.55.6.11** **(01-14-2025)**

### Documenting Status Updates Using Form 13872, Planned Corrective Action (PCA) Status Update

1. The Form 13872, _Planned Corrective Action (PCA) Status Update,_ is used to document the status change of the PCA. The Form 13872 is uploaded into the JAMES and used by EAM to validate the status update. See IRM 1.29.1.3.1(3),**Closing Planned Corrective Actions** for more information.

2. Under section 10c, the Form 13872 requires an executive signature. The contact person listed on Form 13872 in section eight (a - e) must be a subject-matter expert able to clarify activities related to the corrective action plan if requested by EAM, TIGTA, GAO, or other management official. The signature of the responsible business unit JAMES coordinator in section nine (a - d) is required. Return for correction any documentation that does not reflect the appropriate signatures or contain the required information.



### Note:



Electronic signatures are acceptable on Form 13872. The forms must be digitally signed using the signer's HSPD-12 certificate; this is the signature that shows the signer’s name, not the SEID. If the executive is unable to electronically sign the Form 13872, a wet signature may be applied, and the Form 13872 will be scanned and put into an electronic PDF format.


**1.55.6.12** **(11-08-2022)**

### Transferring Planned Corrective Actions (PCAs)

1. If ownership of a PCA must be reassigned to another TS business unit, first obtain concurrence and documentation. A formal memorandum of concurrence is not necessary. However, an e-mail from the accepting executive is required. See IRM 1.29.1.3.9(6)(a),**Managing Unique PCA Activities.**

2. If ownership of a PCA must be reassigned to another business division, concurrence is needed from the accepting official. Prepare a formal memorandum from the transferring business division head to the reassigned business division head. See _Exhibit 1.55.6-7_.

3. Correspondence must clearly identify the report number, the PCA number, and the reason for transfer.

4. Forward the signed memorandum and/or other communications supporting the reassignment to EAM to complete the reassignment in the JAMES.



### Note:



Route all correspondence pertaining to the transfer of a PCA through PEI.


**1.55.6.13** **(01-14-2025)**

### Timeliness

1. The activities implementing PCAs must be completed by the due date to be considered timely implemented. Update in JAMES the status of a PCA on or before the controlled due date for it to be considered implemented timely. Enterprise Audit Management requires all status changes (implementations, cancellations, and extensions) to be updated in the JAMES on or before the due date. EAM requests PCA submissions 5 business days prior to the due date to help ensure a proper review. See Table 1.6, Table 1.7, and Table 1.8 for criteria on timely implementing and extending all PCAs and updating the JAMES.



### Note:



**The business unit coordinators are encouraged to submit the appropriate paperwork to document the status change of a PCA by the first of the month. This allows adequate time to process and validate the status change.**





**Table 1.6. — Timely Closing PCAs in the JAMES**






| **If...** | **And...** | **Then...** |
| --- | --- | --- |
| Activities to implement a PCA have a due date in the JAMES of December 15, and are completed by December 15. | The Form 13872 is signed on, or before December 15. | The action is considered implemented timely. |
| Activities to implement a PCA have a due date in the JAMES of December 15, and are not completed by December 15. |  | The action is considered not implemented timely. |







**Table 1.7. — Timely Extending PCAs in the JAMES**






| _If..._ | _And..._ | _Then..._ |
| --- | --- | --- |
| Activities to implement a PCA have a due date in the JAMES of December 15, and are not completed by December 15. | The status change to extend the due date is input into the JAMES on or before December 15. | The action is considered to be extended timely even if EAM has not completed their action.. |
| Activities to implement a PCA action have a due date in the JAMES of December 15, and are not completed by December 15. | The status change to extend the due date is input into the JAMES after December 15. | The action is considered not extended timely.<br> <br>### Note:<br>The PCA appears as MISSED on the Treasury scorecard until timely implemented or timely extended. |







**Table 1.8. — Timely Updating PCAs in the JAMES**






| **If...** | **And the Status Change is Input into James...** | **Then the Action is...** |
| --- | --- | --- |
| The PCA due date is December 15. | on or before December 15 | considered updated timelyeven if EAM is not timely in completing their action.The JAMES must reflect the implementation date as December 15. |
| The PCA due date is December 15. | after December 15, but by the fifth (5) workday (e.g., December 18) | considered updated timely in the JAMES. |
| The PCA due date is December 15. | after December 15 and after the fifth (5) workday (e.g., December 26) | not considered updated timely in the JAMES. |
| The PCA due date is December 15. | or after the fifth (5) workday (e.g., December 26), but sufficient supporting documentation is not uploaded | not considered updated timely in the JAMES and may be REJECTED by EAM. |







### Note:



All necessary documentation (e.g., signed Form 13872, and supporting documentation, etc.) must be uploaded timely to accurately validate actions in the JAMES on or before the due date.


**1.55.6.14** **(11-08-2022)**

### Long-Term PCAs

1. Consider various factors when setting the initial PCA due date. PCA implementation timeliness can extend for multiple years. For appropriate guidance on Managing Long-term PCAs or Long-term extensions. See IRM 1.29.1.3.9(1),**Managing Unique PCA Activities.**

2. PCAs with longer completions timeliness, warrant greater attention. PCAs are considered long-term as follows:



   - TIGTA - 24 months (730 days) or greater from the TIGTA audit report issue date

   - GAO - 18 months (547 days) or greater from the GAO 180-Day Letter issue date


**1.55.6.14.1** **(01-14-2025)**

#### Long-Term PCAs Status Update

1. For Long-Term PCAs, provide a status update every 12 months in JAMES. EAM will establish an initial milestone date. Systemic notifications from JAMES are issued 30 days prior to the milestone date prompting a progress update. Updates must include the following information:



1. What actions have been taken.

2. What actions are still remaining.

3. Whether we are still on track for implementation by the due date.


### Note:

EAM may request Interim updates outside of JAMES.

**1.55.6.15** **(01-14-2025)**

### Uploading Support Documentation

01. In September 2010, the Department of Treasury enhanced the Joint Audit Management Enterprise System (JAMES) to store documentation in support of a PCA status change.



    ### Note:



    This includes material weaknesses, significant deficiencies and remediation plan actions. For more information see IRM 1.29.1.3.6.5, **Important JAMES Data and Fields.**

02. A complete, executive approved and dated, Form 13872 and any supporting documentation must be uploaded into the JAMES at the time the PCA Status is updated in the JAMES.

03. As of April 1, 2017, PCAs reported as “Implemented” in management’s response to an audit report requires sufficient supporting documentation be provided. Refer to IRM 1.29.1.3.3, **Requirements for Form 13872 and Supporting Documentation**, for more information on the requirements for the supporting documentation.

04. EAM or the CFO assigns the initial due date in the JAMES for these PCAs to be updated. For TIGTA actions the assigned due date is 60 days following the issuance of the final report and for GAO actions, except for those from the financial statement audit, the assigned due date is 30 days from the issuance of the 180-day letter. The supporting documentation must be uploaded into the JAMES to consider a PCA accurately closed in the JAMES.

05. All due dates are set for the 15th day of the month.

06. If sufficient supporting documentation is not uploaded into the JAMES on or before the due date, a request to extend the initial due date must be processed using the Form 13872. See IRM 1.55.6.11.5**, Extending Planned Corrective Actions**, for guidance.

07. Support documents containing sensitive information must be redacted before uploading.

08. Examples of support documentation include:



    - The Form 13872

    - Final reports

    - Formal data analysis

    - Official meeting notes that document decisions made in support of PCA implementation.

    - Records of planning meetings

    - Published forms and publications.

    - Training course materials

    - Updated and published IRMs

    - Informational emails


09. Due to the significance of the GAO/TIGTA audit program, coordinators must ensure the information entered into JAMES is accurate, grammatically correct, executive approved, and entered timely.

10. Documents, once uploaded into the JAMES, cannot be edited. However, they can be deleted, and an edited version can be re-uploaded.


**1.55.6.16** **(01-14-2025)**

### Closed Planned Corrective Action (PCA) Quality Review

1. A statistical sample of closed PCAs are reviewed monthly by Enterprise Audit Management (EAM).

2. PCAs found to not have sufficient documentation to support closure uploaded in the JAMES are documented and the results are sent to the business division headquarters and the responsible organization. See Form 14668, _IRS Quality Assurance Review of Closed Planned Corrective Action (PCA) Notification_, and IRM 1.29.1.3.5.2, **Monthly Closed Sample Quality Review Controls,** for additional guidance.

3. Coordinate the submission, review and approval of new or additional documents through PEI before uploading into the JAMES.


**1.55.6.17** **(04-16-2018)**

### Final Validation of Planned Corrective Actions (PCAs)

1. The business unit coordinator thoroughly reviews the Form 13872 before obtaining executive signature.

2. The business unit coordinator forwards the Form 13872 and supporting documentation to the TS JAMES Coordinator for complete review and approval for the business unit to route to the executive for signature and then upload to JAMES. For more information see IRM 1.29.1.3.3, **Requirements for Form 13872 and Supporting Documentation.** Also, for more information on Evidentiary Documentation Examples, see IRM Exhibit 1.29.1-4.

3. Include all support documentation with the Form 13872 when forwarding to the executive for certification.

4. The EAM Coordinator performs a final review and validation of all PCAs updated in the JAMES.



### Note:



The CFO FM audit team performs the final review and validation of PCAs from the GAO financial statement audit.

5. If additional information is needed, the EAM Coordinator must communicate through the TS primary JAMES coordinator or designated point of contact to resolve.


**1.55.6.18** **(10-14-2016)**

### Reports

1. A variety of reports are used to manage the GAO/TIGTA PCA inventory and communicate related information about management controls data. Monthly, quarterly, and annual reports are prepared to capture the number of actions opened, closed, delayed, and the performance rating of timely responses. See Table 1.9 for a list of frequently used reports.


**1.55.6.18.1** **(01-14-2025)**

#### JAMES Reports

1. Standard reports are developed and enhanced by programmers at the Department of Treasury. The Reports Menu in the JAMES lists over 29 standard reports. Refer to the JAMES User Manual for a complete list of reports. Standard reports are generated in a HTML or Excel format.

2. The JAMES also allows the creation of user defined reports. Data from user defined reports are formatted using Microsoft Office applications (e.g., Excel, Word, and PowerPoint). Information from almost every data element can be extracted and/or used in a calculation to obtain needed data. User defined reports can be shared among JAMES program users. Refer to the JAMES User Manual for assistance in creating user defined reports.



**Table 1.9. — List of Frequently Used Reports**






| **REPORT TITLE** | **REPORT DESCRIPTION** |
| --- | --- |
| A3 - Open Recommendations w/o PCAs Report | Identifies reports entered without the planned corrective actions, pending submission of the final response to EAM. It is run to identify the recommendation agreed to but placed on hold usually due to undetermined resources needed for implementation. |
| A4 - Overdue Open PCAs | Identifies actions currently due, but not implemented or the due date has not been extended. Ran after the 15th of the month.<br> <br>### Note:<br>PCAs updated in the JAMES but pending validation by EAM also appear on this report. |
| A5 - Open PCAs Report | Provides detailed information of all open PCAs. |
| A6 - Audit Summary | Provides a descriptive report of findings, recommendations, and PCAs for a specific audit report. |
| S2 - Scorecard Detail Report | Reports bureau scores of "Met" , "Missed" and "Extended" PCAs during a specific time-frame. Usually ran to show Track 9 completed data. |
| User Defined - Actions Currently Due | Provides a list of open PCAs due for a specific timeframe. Ran bimonthly and sent to the business unit coordinators with actions due. |
| User Defined - Actions Entered as of | Provides a list of any new PCAs added to the JAMES during a specific timeframe. Run in the middle and end of the month. |
| User Defined - Actions Closed as of | Provides a list of PCAs closed during a specific timeframe. Run at the end of the month. |


**1.55.6.19** **(01-14-2025)**

### Records and Information Management

1. Division headquarters offices must maintain an official record of a GAO or TIGTA audit in accordance with Title 44, USC 3102. All audit records are retained electronically.

2. The IRS established a records management program to ensure the economical and efficient management of its records. The program provides for the application, on a continuing basis, of sound management practices and techniques in the creation, maintenance, retrieval, preservation and disposition of records. See IRM 1.15.1**, Records and Information Management Program,** for additional information. All Federal employees are required by law to preserve records containing adequate and proper documentation of the organization, functions, policies, decisions, procedures and essential transactions of the agency. See IRM 1.15.3.1.2,**Authority to Destroy Records**, IRM 1.15.6.7**, Managing Electronic e-mail Records**, for additional information.

3. GAO audit records are retired from the JAMES seven years after closing and destroyed when 20 years old.

4. TIGTA records are prepared for retirement from the JAMES seven years after closing and destroyed after ten years.

5. For the above, the EAM issues a data call e-mail and advises PEI of the dates in which the information will be retired or purged.



### Note:



Before the date of the purge, a copy of the A-6 TIGTA and GAO audit reports located in JAMES must be created and stored under the PEI library and destroyed after ten years.


**Exhibit 1.55.6-1**

### Example of a JAMES Report Verification E-mail

Report 2024-100-022 was entered into the JAMES on 5/20/2024. Please review the attached A6 Summary and confirm the JAMES entry.

RESPONSE DUE DATE: June 4, 2024

Enterprise Audit Management (EAM) is now tracking the following new Treasury Inspector General for Tax Administration (TIGTA) and/or Government Accountability Office (GAO) audit report(s) in Treasury’s Joint Audit Management Enterprise System (JAMES): 2024-100-022: TAXPAYER ASSISTANCE CENTERS GENERALLY PROVIDED QUALITY SERVICE, BUT ADDITIONAL ACTIONS ARE NEEDED TO REDUCE TAXPAYER BURDEN

Findings: 1, 2, 3

Root Cause Category: IIC - Control Activities

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| **Fin-Rec-PCA** | **Resp. Org** | **Resp. Employee** | **Milestone Date** | **Due Date** |
| 1-1-1 | C:DC:TS:CAS | C:DC:TS:CAS:AM |  | 10/15/2024 |
| 1-2-1 | C:DC:TS:CAS | C:DC:TS:CAS:AM |  | 8/15/2024 |
| 2-1-1 | C:DC:TS:CAR | C:DC:TS:CAR:FA |  | 8/15/2024 |
| 2-2-1 | C:DC:TS:CAR | C:DC:TS:CAR:FA |  | 8/15/2024 |
| 3-1-1 | C:DC:TS:CAR | C:DC:TS:CAR:FA |  | 8/15/2024 |

**Audit Report** \- New audit report(s) listed above has been entered in JAMES. A JAMES A6 Audit Summary report abstract is provided as an attachment. To ensure accuracy of the information reported to Treasury, please review the audit report findings, recommendations, corrective action descriptions, root cause category and monetary benefits, if applicable. The A6 report can also be reviewed in JAMES by clicking on the "Standard Reports" button; then click "Audit & Related Reports", click A6 Audit Summary, type the audit report number (including dashes) in the audit report number box, change "View Type" to "descriptive" then click Run - A6 Report":

**Please follow the steps below and respond by the response due date at the top of this e-mail:**

- Notify me immediately (phone/e-mail) if the information contained in the JAMES is incomplete and/or inaccurate.

- Indicate if you disagree with the root cause chosen by TIGTA. We will work with TIGTA to have it changed. EAM is responsible for assigning root cause for GAO audits.

- If the information contained in the JAMES is correct, the lead coordinator in the functional area responsible to address the corrective action(s) should send me an e-mail concurrence by the response due date.

- A concurrence memorandum, signed by a responsible official at the executive level, is only required if there is a substantial disagreement or if monetary benefits have been identified. See IRM 1.29.1.3.11(3). Disagreements require TIGTA's written concurrence/nonconcurrence and a copy must be provided to the EAM.


**Exhibit 1.55.6-2**

### Example of a Non-Concurrence Memorandum

This memorandum is sent to the Office of Enterprise Audit Management (EAM) by the business division when significant discrepancies are discovered in the JAMES report that need to be corrected. The executive that owns the planned corrective action in question generally prepares the memorandum. The memorandum is sent through the TS headquarters office.

### Note:

The memorandum must be left justified, printed on TS letterhead, and follow other correspondence rules in accordance with IRM 1.10.1, _Office of the Commissioner of Internal Revenue, IRS Correspondence Manual._

**RESPONSE DUE DATE: JULY 22, 2020**

MEMORANDUM FOR DIRECTOR, ENTERPRISE AUDIT MANAGEMENT

FROM: Robert Anaconda

Director, Customer Account Services (CAS), Taxpayer Services

SUBJECT: Verification of Joint Audit Management Enterprise System (JAMES) Audit Summary Report

The Customer Account Services (CAS) function has been assigned the responsibility of responding to specific corrective actions found in the attached JAMES Verification Report, GAO-05-247R, "MANAGEMENT REPORT: IMPROVEMENTS NEEDED IN IRS’ INTERNAL CONTROLS," ISSUED APRIL 27, 2019.

After careful review, we identified significant discrepancies with information pertaining to the findings, recommendations, corrective actions and or outcome measures (if applicable).

We specifically do not concur with (fill-in)

If additional information is needed, please contact Mary Copperhead, Audit Coordinator, at (XXX) XXX-XXXX.

Attachment

**Exhibit 1.55.6-3**

### Example of a JAMES Report Verification Memorandum

This memorandum is sent to the Office of Enterprise Audit Management (EAM) by the business division when the JAMES report contains outcome measures. The executive that owns the planned corrective action associated with the recommendation generally prepares the memorandum. The memorandum is forwarded PEI.

### Note:

The letter must be left justified and printed on TS letterhead in accordance with IRM 1.10.1, _Office of the Commissioner of Internal Revenue, IRS Correspondence Manual._

February 20, 2020

MEMORANDUM FOR DIRECTOR, ENTERPRISE AUDIT MANAGEMENT

FROM: Karen Viper

Director, Customer Assistance Relationships and Education (CARE) Taxpayer Services

SUBJECT: Verification of Joint Audit Management Enterprise System (JAMES) Audit Summary Report

The Customer Assistance Relationships and Education (CARE) function has been assigned the responsibility of responding to corrective actions associated with the audit report listed above. After careful review, we agree that the findings, recommendations, and corrective actions are accurately reflected in the attached Joint Audit Management Enterprise System (JAMES) A6 Audit Summary Report. While we agree with Treasury Inspector General for Tax Administration’s (TIGTA) computation of the cost savings (funds put to better use) Outcome Measure (shown below), we do not agree that it is an achievable outcome.

Funds Put to Better Use $22,185,990.00

If additional information is needed, please contact Michael Tortoise, JAMES Program Coordinator at (404) 555-9999.

Concurrence:

**Exhibit 1.55.6-4**

### Example of a Memorandum Requesting Cancellation of a TIGTA Corrective Action

This memorandum is used to request concurrence to close a TIGTA planned corrective action. The memorandum is sent from the Chief, Taxpayer Services to the TIGTA's Deputy Inspector General.

### Note:

The memorandum must be left justified, printed on TS letterhead, and follow other correspondence rules in accordance with IRM 1.10.1, _Office of the Commissioner of Internal Revenue, IRS Correspondence Manual_.

**MEMORANDUM FOR ELIZABETH BOA**

**DEPUTY INSPECTOR GENERAL FOR AUDIT**

FROM: Michael Tortoise

Chief, Taxpayer Services

SUBJECT: Request to Close Corrective Action 1-1-3 from Internal Audit Report #71399, "Quality of Information Document Processing"

I am writing to request your concurrence to close corrective action 1-1-3 from the subject Internal Audit report dated March 3, 2020. Your recommendation and our justification for closing these actions follow.

**Recommendation #1:** Issued by the GAO/TIGTA auditors, at the conclusion of the audit that addresses the audit findings which will correct the issue. List recommendation as reported in the final report, which is in JAMES.

**Corrective Action #1-1-3:** A detailed description of how management will implement a recommendation to address the audit finding(s).The corrective action information will also be found within the Appendix Section under the Recommendation that IRS management agreed to on the final report.

**Background:** As for the background information, you will find it in the first section of the final report.

**Justification to Close This Action:** The justification will address the specific actions required to address the recommendation(s) and mitigate the control issue(s).

In example: The IRS has taken actions to refine the OCR processes, modify transcription instructions, and alert filers of summary documents. These actions have reduced erroneous SCRIPS so much that the report, which we planned to create through the RIS, would be of no material value. The corrective actions we are taking and have taken to reduce erroneous SCRIPS errors, and the cursory reviews IS conducted, are the same corrective actions required if the proposed comparison report showed dollar or volume anomalies.

For a detailed description of IRS’ actions to XXXXXX, see the attached.

I hope this information justifies our conclusion that implementing this corrective action is not appropriate. If you agree that we must close this corrective action, please sign below. If you have any questions, please call Mary Copperhead, Senior Tax Analyst at (678) 555-3333.

Attachment

|     |     |
| --- | --- |
| Concurrence: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| Michael Tortoise, Deputy Inspector General |  |

**Exhibit 1.55.6-5**

### Example of a Memorandum Concurring the Closure of a TIGTA Planned Corrective Action

This cover memorandum is received from the TIGTA when they formally concur to close an IRS planned corrective action. The IRS signed request for closure memorandum is usually attached, and sent via e-mail to the Chief, Taxpayer Services.

### Note:

The memorandum is usually printed on Department of Treasury letterhead.

**DEPARTMENT OF THE TREASURY**

**WASHINGTON, D.C. 20220**

MEMORANDUM FOR CHIEF, TAXPAYER SERVICES

FROM: Robert Anaconda

Deputy Inspector General

SUBJECT: Request to Cancel Planned Corrective Action 1-1-3 from Audit Report 2020-XX-XXXX, Quality of Information Document Processing

You have requested the Treasury Inspector General for Tax Administration’s concurrence in canceling corrective action 1-1-3 relating to the subject report. As requested, I have indicated my concurrence by my signature on the attachment.

If you have any questions, please contact me, or your staff may contact Elizabeth Boa, Director, Office of Management and Policy at (470) 555-1111.

Attachment

cc:

Attn: Karen Viper

**Exhibit 1.55.6-6**

### Example of a Memorandum from TIGTA Not Concurring the Closure of a Planned Corrective Action

This cover memorandum is received from the TIGTA when they formally do not concur to close an IRS planned corrective action. The IRS signed request for closure memorandum is usually attached, and sent via e-mail to the Chief, Taxpayer Services.

### Note:

The memorandum is usually printed on Department of Treasury letterhead.

**MEMORANDUM FOR CHIEF, TAXPAYER SERVICES**

FROM: Karen Viper, Deputy Inspector General for Audit

SUBJECT: Request to Close Joint Audit Management Enterprise System (JAMES) Planned Corrective Actions (PCA) 1-X-X 2-X-X, 3-X-X, and 4-X-X from Audit Report 2020-XXX-XXX “ _Additional Security is Needed for XXXXXXXXXXXXX_ (Audit XXXXXXXX)

Thank you for the opportunity to review your justifications for closing the four unresolved corrective actions, as mentioned in the subject line of this memorandum. Based on our review of your justifications, we disagree with the closure of the four recommendations on the JAMES because the access control weaknesses associated with these recommendations still exist. These corrective actions are critical to minimize the risk of unauthorized access to data.

For all four recommendations, your corrective actions depended on the completion of the Unified Work Request (UWR) to:

- Update the Automated Suitability Analysis Program to collect and retain suitability information for specific delegated users, which would allow the IRS to initial criminal background and tax compliance checks (planned corrective action 1-X-X),

- Complete requisite programming changes to the Third-Party Data Store so that complete results of the Automated Suitability Analysis Program’s spouse tax compliance checks are posted (planned corrective action 2-X-X),

- Bring the Registered User Portal into compliance with password composition and history retention (planned corrective action 3-X-X), and

- Complete programming modifications to include a series of challenge questions to unlock user accounts (planned corrective action 4-X-X).


After reviewing the UWR, the Information Technology (IT) Executive Review Board deemed the actions as “Not Mission Critical,” and not driven by legislative need. As such, the corrective actions were not completed.

For corrective action 1-X-X, you also cite that delegated users who have Preparer Tax Identification Numbers (PTIN) are subject to return preparer suitability checks. While you also cite that there is a high probability that many delegated users have PTINs, we have not received any evidence or support as how many delegates have PTINs. In addition, we recognize that some delegated users may not be preparing tax returns, which means they do not need a PTIN and would not be subject to any suitability checks.

We would like for your organization to continue to work with the IT organization to complete your original corrective actions to our recommendations. We believe the corrective actions for four recommendations must remain open until such time when the original corrective actions are completed, or alternate correctives actions are proposed and completed that would address the access control deficiencies.

Please contact me at (XXX) XXX-XXXX if you have any questions or Joseph Salamander, Assistant Inspector General for Audit (Security and Information Technology Services), at (XXX) XXX-XXXX.

**Exhibit 1.55.6-7**

### Example of a Memorandum Requesting the Transfer of a Planned Corrective Action

This memorandum is used to request the transfer of a planned corrective action from one business division to another. The memorandum is sent from the Chief, Taxpayer Services to the head of office of the gaining office.

### Note:

The memorandum must be left justified, printed on TS letterhead, and follow other correspondence rules in accordance with IRM 1.10.1, _Office of the Commissioner of Internal Revenue, IRS Correspondence Manual_.

**MEMORANDUM FOR Joseph Buffalo COMMISSIONER SMALL BUSINESS SELF-EMPLOYED DIVISION**

FROM: Jennifer Ferret

Chief, Taxpayer Services

SUBJECT: Transfer of Open Treasury Inspector General for Tax Administration Planned Corrective Actions

With the realignment of program offices under the Electronic Tax Administration and Refundable Credits Office (ETARC), effective October 9, 2020, Taxpayer Services has identified nine planned corrective actions (PCAs), from three Treasury Inspector General for Tax Administration (TIGTA) audit reports, that must be transferred to the Office of Online Services and the Return Preparers Office under the Deputy Commissioner Internal Revenue Service (DCIR).

The PCAs to transfer are:

1. From the audit report _Additional Security Is Needed For Access To The Registered User Portal_ 2020-XX-XXX (Audit 2013XXXXX), PCAs 1-5-1 and 1-6-1 will be transferred to the Office of Online Services; and PCAs 1-1-1 and 1-3-1 will be transferred to the Return Preparers Office.

2. From the audit report _Systems Validations Are Insufficient To Prevent The Unauthorized Use of Electronic Filing Identification Numbers_ 2019-XX-XXX (Audit # 2019XXXXX), PCAs 1-1-1, 1-2-1, 1-3-1, and 1-6-1 will be transferred to the Return Preparers Office. (3) From the audit report _Individuals Who Are Not Authorized To Work In The United States Were Paid $4.2 Billion in Refundable Credits_ 2016-XX-XXX (Audit 20148XXXXX), PCA 4-1-3 will be transferred to the Return Preparers Office.


Your concurrence to transfer the identified PCAs is requested. Audit liaisons from the Office of Online Services and the Return Preparer’s Office have been briefed, and all agree with the specifics of the transfers. A detailed listing of the PCAs discussed is attached. In addition, they will work with the Department of Treasury to ensure the PCAs, currently tracked in the Joint Audit Management Enterprise System, are updated to accurately reflect the appropriate organizational codes and the responsible business organization under the Deputy Commissioner Internal Revenue Service.

For questions, or if additional information is needed, please contact me or a member of your staff may contact William Cobra Chief, Program Evaluation and Improvement, at 404-XXX-XXXX.

Attachment

|     |     |
| --- | --- |
| Concurrence: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ | Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ |
| Frank Gator, Deputy Commissioner Internal Revenue Service |  |

cc:

[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-055-006#addtoany "Show all")

A2A