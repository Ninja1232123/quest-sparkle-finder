---
url: "https://www.irs.gov/irm/part1/irm_01-001-019"
title: "1.1.19 Criminal Investigation | Internal Revenue Service"
---

[Skip to main content](https://www.irs.gov/irm/part1/irm_01-001-019#main-content)

- 1.1.19  [Criminal Investigation](https://www.irs.gov/irm/part1/irm_01-001-019#id1)
  - 1.1.19.1  [Program Scope and Objectives](https://www.irs.gov/irm/part1/irm_01-001-019#id2)
    - 1.1.19.1.1  [Guide Authority](https://www.irs.gov/irm/part1/irm_01-001-019#id4)
    - 1.1.19.1.2  [Acronyms](https://www.irs.gov/irm/part1/irm_01-001-019#id5)
  - 1.1.19.2  [Headquarters](https://www.irs.gov/irm/part1/irm_01-001-019#id6)
    - 1.1.19.2.1  [Office of the Chief](https://www.irs.gov/irm/part1/irm_01-001-019#id8)
    - 1.1.19.2.2  [International Operations](https://www.irs.gov/irm/part1/irm_01-001-019#id9)
    - 1.1.19.2.3  [Operations, Policy and Support](https://www.irs.gov/irm/part1/irm_01-001-019#id10)
    - 1.1.19.2.4  [Refund and Cyber Crimes](https://www.irs.gov/irm/part1/irm_01-001-019#id11)
    - 1.1.19.2.5  [Strategy](https://www.irs.gov/irm/part1/irm_01-001-019#id12)
    - 1.1.19.2.6  [Technology Operations and Investigative Services](https://www.irs.gov/irm/part1/irm_01-001-019#id13)
  - 1.1.19.3  [Criminal Investigation Area and Field Offices](https://www.irs.gov/irm/part1/irm_01-001-019#id14)

# Part 1. Organization, Finance, and Management

# Chapter 1. Organization and Staffing

# Section 19. Criminal Investigation

* * *

## 1.1.19 Criminal Investigation

#### Manual Transmittal

July 28, 2025

#### Purpose

(1) This transmits revised IRM 1.1.19, _Organization and Staffing, Criminal Investigation_.

#### Material Changes

(1) IRM 1.1.19 revised to comply with Executive Orders and Office of Personnel Management (OPM) memorandums regarding diversity, equity, inclusion (DEI) gender, or related subject matter.

(2) IRM 1.1.19.1.2, EDI - Equity, Diversity, and Inclusion Office, removed from acronym table.

(3) IRM 1.1.19.2.1 (2), EDI removed from bullet list of Office of the Chief sections.

(4) IRM .1.1.19.2.1 (5), paragraph outlining Equity, Diversity & Inclusion responsibilities deleted.

#### Effect on Other Documents

This IRM supersedes IRM 1.1.19 dated August 02, 2019.

#### Audience

All Divisions and Functions

#### Effective Date

(07-28-2025)

Kathy Enstrom for Don Fort

Chief, Criminal Investigation

**1.1.19.1** **(08-02-2019)**

### Program Scope and Objectives

1. The mission of Criminal Investigation (CI) is to serve the American public by investigating potential criminal violations of the Internal Revenue Code and related financial crimes in a manner that fosters confidence in the tax system and compliance with the law.

2. While tax enforcement is clearly the core mission, CI also makes significant contributions to other important national law enforcement efforts. Criminal Investigation’s participation in joint investigations has helped lead to major convictions on high profile cases involving such issues as political corruption, corporate fraud, narcotics trafficking, and terrorist financing.

3. Criminal Investigation is staffed with approximately 3,000 employees whose dedicated efforts have earned CI a reputation as the premier financial investigative agency in the world.

4. To accomplish the mission, CI:



1. Develops and implements measures that balance customer satisfaction appropriate to law enforcement, employee satisfaction and business results.

2. Ensures that criminal enforcement is an essential part of an integrated tax compliance strategy.

3. Fulfills the expectation of honest taxpayers that tax evaders will be criminally prosecuted.

4. Provides support to the US Attorney’s Office by investigating financial crimes appropriate to CI’s jurisdiction and participating in joint investigative task forces.

5. Provides advice to Congressional Committees on legislation, regulation, litigation, and Freedom of Information Act (FOIA) matters and other requests as they relate to CI provides, when necessary, personal protection for IRS employees.

6. Ensures all CI employees are properly trained to fulfill their mission.

7. Identifies, examines, and addresses the organization’s employment practices, policies, guidelines, and procedures to ensure that all employees and applicants for employment achieve equal opportunity in every facet of CI’s programs, activities, and services as directed by the IRS.


**1.1.19.1.1** **(08-02-2019)**

#### Guide Authority

1. See IRM 9.1.2, Authority, IRM 9.1.1, Mission, and IRM Chapter 1.4 – Resource Managers for the delegated authority related to IRM 1.1.19.


**1.1.19.1.2** **(07-28-2025)**

#### Acronyms

1. The table lists commonly used acronyms and their definitions:



|     |     |
| --- | --- |
| **Acronym** | **Definition** |
| ASAC | Assistant Special Agent In Charge |
| BOD | Business Operating Divisions |
| CI | Criminal Investigation |
| C&E | Communications and Education Office |
| EC | Electronic Crimes |
|  |  |
| EEO | Equal Employment Opportunity |
| FOIA | Freedom of Information Act |
| FinCEN | Financial Crimes Enforcement Network |
| GAO | Government Accountability Office |
| HQ | Headquarters |
| HR | Human Resources |
| ICs | Internal Controls |
| IO | International Operations |
| IT | Information Technology |
| NCT | Narcotics, Counterterrorism, and Transnational Organized Crime |
| NCITA | National Criminal Investigation Training Academy |
| OPS | Operations, Policy, and Support |
| PIOs | Public Information Officers |
| PMAC | Profile Management, Acquisitions, and Contracts |
| PR&A | Planning, Research, and Analysis |
| RCC | Refund and Cyber Crimes |
| RPE | Review and Program Evaluation |
| SAC | Special Agent In Charge |
| SSA | Supervisory Special Agent |
| SDC | Scheme Development Centers |
| S | Strategy |
| TIGTA | Treasury Inspector General for Tax Administration |
| TEOAF | Treasury Executive Office of Asset Forfeiture |
| TOIS | Technology Operations and Investigative Services |


**1.1.19.2** **(08-02-2019)**

### Headquarters

1. The mission of CI-HQ is to support the CI field offices in their efforts to accomplish the CI mission. Headquarters provides strategic and operational support for all areas of the organization.

2. The CI-HQ consists of the Chief; Deputy Chief; Directors; and staffs of the following offices:



1. Office of the Chief

2. IO

3. OPS

4. RCC

5. Strategy (S)

6. TOIS


**1.1.19.2.1** **(07-28-2025)**

#### Office of the Chief

1. The Chief, Criminal Investigation, is the highest ranking executive within IRS-CI. The Chief, CI, reports to the Deputy Commissioner, Services and Enforcement. The Chief, CI, is responsible for the full range of planning, managing, directing, and executing the worldwide activities of CI. The Chief, CI, together with the Deputy Chief, directly supervises the Directors of the HQ offices, as well as the Area Directors, Field Operations.

2. The Office of the Chief includes the following sections:



   - Chief of Staff

   - Deputy Chief of Staff

   - C&E

   - RPE


3. The Chief of Staff, together with the Deputy Chief of Staff, manages the Chief and Deputy Chief’s official appointments, speaking engagements, calendar items, and duties associated with the selection of senior management personnel. Additionally, the Chief of Staff supervises the Commissioner’s Protection Detail which provides daily executive protection to the IRS Commissioner.

4. Communications and Education plans, coordinates, and produces communications products and tools for CI. Communications and Education provides a wide range of products and services to help achieve communications goals to a variety of audiences; employees, managers, the media, tax, accounting and business professionals, and other external and internal stakeholders. Communications and Education also coordinates field office publicity through the PIOs who are special agents trained in media relations. Communications and Education is also the home to CI’s Legislative Liaison who manages and enhances CI’s relationship with members of Congress, ensures CI sections are informed of pending legislation affecting their areas, and responds to Congressional inquiries and correspondence.

5. Review and Program Evaluation independently reviews, evaluates, and reports on CI field operations, program areas, and headquarters sections in a fair and objective manner. Review and Program Evaluation identifies risks, emerging issues and best practices which affect CI; assess CI’s leadership effectiveness, and ability to manage and mitigate risk; evaluate CI operations to ensure investigative alignment with the Compliance Strategy; and to ensure compliance with established policies and prior TIGTA, GAO, and RPE recommendations.


**1.1.19.2.2** **(08-02-2019)**

#### International Operations

1. The Office of IO enhances CI’s ability to gather information located beyond our borders by developing and maintaining relationships with our foreign partners through the strategic placement of CI personnel around the world. The Office of IO ensures CI’s financial expertise is brought to bear on the most significant international tax, narcotics, transnational organized crimes, and counterterrorism cases.

2. The Office of IO includes the following sections:



   - International Field Operations

   - NCT Organized Crime


3. International Field Operations ensures international law enforcement cooperation between foreign governments and CI field offices as it relates to investigating potential criminal violations of the Internal Revenue Code and related financial crimes. Criminal Investigation supports international case work by maintaining Special Agent Attachés in strategic international locations. The attachés facilitate the exchange of information with our international tax and law enforcement partners.

4. Narcotics and Counterterrorism provide policy guidance, operational coordination and investigative support to CI field offices. The NCT liaisons with federal agencies and national task forces to provide inter-agency coordination, de-confliction, investigative analytical support, intelligence products, and informed guidance on a vast landscape of NCT and money laundering related cases.


**1.1.19.2.3** **(08-02-2019)**

#### Operations, Policy and Support

1. The Office of Operations, Policy, and Support provides direction, oversight, and support to the CI field offices, writes and reviews operational policies, provides recommendations to the Chief’s Office and extensively collaborates with our internal and external stakeholders in accomplishing the overall Criminal Investigation mission.

2. The Office of Operations, Policy and Support includes the following sections:



1. Financial Crimes

2. National Forensic Laboratory

3. Special Investigative Techniques

4. Warrants and Forfeiture

5. Treasury Liaison


3. The Financial Crimes section oversees many domestic tax and financial fraud program areas including: fraud referral programs, bankruptcy fraud, financial institution fraud, abusive tax schemes, money laundering, Bank Secrecy Act violations, and oversight of Financial Crimes Task Forces. The FinCEN liaison is assigned to this section and works directly with FinCEN on common issues, trends and analysis of financial crimes

4. National Forensic Laboratory is made up of three teams which include the Scientific Services, Design and Technology and Data Processing Center.

5. Special Investigative Techniques has oversight responsibilities for the authorization of undercover operations, witness protection, electronic surveillance and informants.

6. Warrants and Forfeiture administers the asset forfeiture program and oversight of fugitives. The TEOAF Liaison is assigned to this section and works directly with TEOAF in processing forfeiture packages and overseeing an annual budget given to CI in direct support of our financial investigations.

7. The Treasury Liaison is IRS-CI’s direct line to the U.S. Department of the Treasury. The Liaison collaborates extensively on initiatives involving domestic and international financial fraud.


**1.1.19.2.4** **(08-02-2019)**

#### Refund and Cyber Crimes

1. The Office of RCC supports the CI mission by identifying and developing criminal tax schemes for the purpose of referring and supporting high-impact criminal tax and related financial investigations. By utilizing a multi-faceted approach, CI creates an enhanced enforcement presence among tax practitioners, tax preparers, and other third parties in an effort to reduce return preparer fraud. Cybercrime investigations will be conducted in three broad areas: core/traditional tax crimes, related financial crimes, and Transnational Organized Crime Financing, including narcotics and terrorism support.

2. The Office of RCC includes the following sections:



   - Operations, Scheme Development & Support

   - Program Analysis & Operational Support

   - Cyber Crimes


3. Operations, Scheme Development & Support Section support the RCC Mission by analyzing data to assist the field offices with identifying and developing high impact investigations. This section will also create policy and assist national program areas in the furtherance of CI’s overall mission of investigating potential criminal violations and tax compliance. Operations, Scheme Development & Support have SDCs located across the country.

4. Program Analysis & Operational Support supports RCC’s mission by providing oversight, data analytics, and development of requirements while maintaining the integrity of scheme development, investigative systems and applications. This mission will be achieved through the use of human and artificial intelligence and collaboration with stakeholders while partnering with RCC’s Cyber as well as Operations, Scheme Development & Support by providing the following:



   - Technical training and oversight

   - Big data/link analytics

   - Statistical analysis

   - Identification and development of system rules & requirements


5. The Cyber Crimes section addresses the many challenges cyber criminals present in protecting the IRS and taxpayers from illicit acts violating our tax code. Cyber Crimes supports field investigations involving cyber-dependent or cyber-enabled criminal schemes by employing resources and experts in the cyber realm, including cryptocurrency and dark web technology. Cyber Crimes will also provide critical training to enhance the skillsets of CI personnel and combat the evolving aspects of cybercrime.


**1.1.19.2.5** **(08-02-2019)**

#### Strategy

1. The Office of Strategy develops and supports CI programs and action plans to deliver strategic objectives. The Office of Strategy is also responsible for:



   - Researching criminal compliance issues to support the development of strategic priorities and improve operational effectiveness.

   - Formulating, administering, and executing the CI financial plan consistent with national priorities.

   - Developing and delivering CI Law enforcement training consistent with national enforcement strategies and recognized training accreditation standards.

   - Implementing IRS Strategic HR programs and support CI specific human resource needs, including the development and implementation of policies and programs.

   - Coordinating the implementation of Treasury law enforcement personnel policies and special programs which impact CI.


2. The Office of Strategy includes the following branches:



   - Finance

   - HR

   - NCITA

   - PR&A


3. Finance provides overall policy and guidance on the financial management of CI resources and ensures that all acquisition-related requirements and responsibilities are met. The financial management responsibilities include management and oversight of the current fiscal year’s financial plan, development of next fiscal year’s financial plan and formulation of the future fiscal year budget requests. Budget Execution of the current fiscal year’s financial plan includes developing current fiscal year financial operating policy and guidelines for all CI field and HQ offices. This involves management of all labor and non-labor resources, appropriated and reimbursable, including asset forfeiture funding. In addition, Finance provides operational procurement guidance for all CI field and HQ offices. This involves setting policy for a wide range of activities, including: purchase cardholders, purchase card approving officials, receipt and acceptance, acquisition planning, and contract management. Finance staff works closely with IRS Procurement, to make sure all required equipment, supplies, and services are acquired in the most efficient, effective manner possible.

4. Human Resources is the BOD-based HR organization for CI. Human Resources is responsible for all of CI’s hiring, as well as implementing service wide HR programs and processes, developing unique policy to meet the needs of CI, and provides HR program oversight on behalf of CI.

5. The NCITA is dedicated to fostering the highest levels of professionalism and ethical behavior throughout the CI’s workforce. The NCITA is divided into two sections: Training Operations and Strategy. Training Operations is responsible for planning, organizing, coordinating and delivering a full range of learning and education products and programs for Basic and International Training. Training Strategy is responsible for the policies and procedures that adhere to the NCITA foundation for accreditation and supports the Course Development Unit, Leadership Development, Use of Force, and the Internal Management Document Program.

6. Planning, Research & Analysis develops and supports CI’s programs and action plans to deliver strategic objectives. This is accomplished through objective, high-quality data analysis, and operational and statistical studies. The information provides CI’s leaders the tools needed to make data-driven decisions required to measure and monitor CI’s impact on compliance.


**1.1.19.2.6** **(08-02-2019)**

#### Technology Operations and Investigative Services

1. Technology Operations and Investigative Services operates and maintains CI’s computer network, develops long-range IT strategies, plans and delivers the IT products associated with the long term strategies, evaluates the technical aspects of network software and hardware, and recovers and analyzes investigative digital evidence.

2. The Office of TOIS includes the following sections:



   - Business Systems Development

   - Cybersecurity

   - EC

   - PMAC

   - Technical Operations Center

   - User Support


3. The Business Systems Development office is charged to identify opportunities and manage the delivery of business improvement and IT projects in support of the TOIS mission and the fulfillment of the CI vision and strategic mission.

4. Cybersecurity is responsible for IT Security, primarily the development and compliance of security policies and facilitating data spill clean-up and reporting activities. In addition, the IT Security Team develops policies specific to CI and interprets general security policies as they apply to CI.

5. Electronic Crimes supports IRS Special Agents in the collection and analysis of digital evidence. Computer Investigative Specialists participate in search warrants with investigating agents and are responsible for the seizure and processing of evidence contained in various types of digital media. The Electronic Crimes Laboratory, located in Woodbridge, VA, leads CI in the forensic acquisition, preservation, investigative analysis, and reporting of digital and cyber evidence.

6. The PMAC office is responsible for oversight for the CI governance boards and CI’s demand prioritization process. In addition, PMAC coordinates budget formulation of core funding from IRS-IT in support of CI software and hardware, as well as coordinating TOIS/TEOAF funding with IRS-IT for new IT development.

7. The Technical Operations Center plans, implements, and maintains secure law enforcement computer systems through the use of innovative and leading edge technologies.

8. User Support provides information technology support to CI users around the world.


**1.1.19.3** **(08-02-2019)**

### Criminal Investigation Area and Field Offices

1. There are four Directors, Field Operations covering the North, South, Mid-states, and West.

2. The Directors, Field Operations supervise the field office SACs and oversee the field office operations under their jurisdiction. In conjunction with the SACs, the Directors, Field Operations plan, develop, direct, and implement a comprehensive criminal investigation program for their area that enhances compliance, ensures consistency in taxpayer treatment, and continuously improves business systems and processes.

3. The management team in the individual field offices consists of SACs, ASACs, and SSAs. The duties and responsibilities of these managers are described in IRM 1.4.9, Resource Guide for Managers.


[More Internal Revenue Manual](https://www.irs.gov/irm)

Copy link

✓

Thanks for sharing!

Find any service

[AddToAny](https://www.addtoany.com/ "Share Buttons")

[More…](https://www.irs.gov/irm/part1/irm_01-001-019#addtoany "Show all")

A2A